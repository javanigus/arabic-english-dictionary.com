<article class="root" id="Root_bwz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/218_bwr">بور</a></span>
				<span class="ar">بوز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/220_bws">بوس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baAzN">
				<h3 class="entry"><span class="ar">بَازٌ</span></h3>
				<div class="sense" id="baAzN_A1">
					<p><span class="ar">بَازٌ</span> <em>i. q.</em> <span class="ar">بَازٍ</span>; <span class="add">[<a href="index.php?data=02_b/097_bzw">see art. <span class="ar">بزو</span></a>;]</span> <span class="auth">(Ṣ, Ḳ;)</span> a dial. var. of the latter; <span class="auth">(Ṣ;)</span> as also <span class="ar">بَأْزٌ</span>: <span class="auth">(IJ, TA:)</span> dual. <span class="ar">بَازَانِ</span>: <span class="auth">(Ḳ:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْوَازٌ</span> and <span class="add">[of mult.]</span> <span class="ar">بِيزَانٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> the dual of <span class="ar">بَازٍ</span> is <span class="ar">بَازِيَانِ</span>; <span class="auth">(Ḳ;)</span> and the pl. is <span class="ar">بُزَاةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بَوَازٍ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0275.pdf" target="pdf">
							<span>Lanes Lexicon Page 275</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
