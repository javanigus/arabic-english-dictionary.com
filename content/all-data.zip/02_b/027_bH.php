<article class="root" id="Root_bH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/026_bjl">بجل</a></span>
				<span class="ar">بح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/028_bHt">بحت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bH_1">
				<h3 class="entry">1. ⇒ <span class="ar">بحّ</span></h3>
				<div class="sense" id="bH_1_A1">
					<p><span class="ar">بَحَّ</span>, <span class="auth">(L,)</span> first pers. <span class="ar">بَحِحْتُ</span>, aor. <span class="ar">يَبَحُّ</span>, <span class="auth">(ISk, Ṣ, L, Ḳ,)</span> and ISd says, I see, or think, that Lḥ has mentioned <span class="ar">يَبْحَحُ</span>, which is extr. with respect to rule, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَحَحٌ</span>; <span class="auth">(ISk, Ṣ, L, Ḳ;)</span> and first pers. <span class="ar">بَحَحْتُ</span>, <span class="auth">(AO, T, Ṣ, Ḳ,)</span> but the former is the more chaste, <span class="auth">(T, TA,)</span> aor. <span class="ar">يَبَعُّ</span> <span class="auth">(AO, Ṣ, Ḳ)</span> and <span class="ar">يَبِعُّ</span> and <span class="ar">يَبُعُّ</span>, <span class="add">[which last is contr. to analogy,]</span> <span class="auth">(L,)</span> inf. n. <span class="ar">بَعُّ</span> <span class="auth">(AO, Ṣ, Ḳ)</span> and <span class="ar">بَحَحٌ</span> and <span class="ar">بَحَاحٌ</span> and <span class="ar">بُحُوحٌ</span> and <span class="ar">بَحَاحَةٌ</span> and <span class="ar">بُحُوحَةٌ</span>; <span class="auth">(Ḳ;)</span> <em>He had a hoarse, rough, harsh,</em> or <em>gruff, voice;</em> <span class="auth">(L;)</span> <em>he was taken with a hoarseness, harshness, roughness,</em> or <em>gruffness, of the voice.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bH_1_A2">
					<p>It is tropically used in speaking of inanimate things; as in <span class="ar long">بَعَّ العُودُ</span>, meaning ‡ <span class="add">[<em>The lute</em>]</span> <em>was rough</em> <span class="add">[<em>in sound:</em> <a href="#OabaEBu">see <span class="ar">أَبَعُّ</span></a>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bH_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابحّ</span></h3>
				<div class="sense" id="bH_4_A1">
					<p><span class="ar">ابحّهُ</span> <em>It</em> <span class="auth">(crying out, or vociferating,)</span> <em>rendered him hoarse, rough, harsh,</em> or <em>gruff, in voice.</em> <span class="auth">(Ṣ,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bH_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتحّ</span></h3>
				<div class="sense" id="bH_8_A1">
					<p><span class="ar long">هُمْ فِى ٱبْتِحَاحٍ</span> <em>They are in a state of amplitude, and of plenty,</em> or <em>of abundance of herbage</em> or <em>of the goods</em> or <em>conveniences</em> or <em>comforts of life.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bH_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بحبح</span></h3>
				<div class="sense" id="bH_RQ1_A1">
					<p><span class="ar">بَحْبَعَ</span>: <a href="#bH_RQ2">see R. Q. 2</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bH_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تبحبح</span></h3>
				<div class="sense" id="bH_RQ2_A1">
					<p><span class="ar long">تَبَحْبَعَ الدَّارَ</span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بَحْبَعَهَا↓</span></span>, <span class="auth">(TA,)</span> † <em>He was,</em> or <em>became,</em> <span class="add">[<em>established</em>]</span> <em>in the middle,</em> or <em>midst,</em> <span class="add">[which is the <em>best part,</em>]</span> <em>of the</em> <span class="ar">دار</span> <span class="add">[i. e. <em>abode,</em> or <em>district,</em> or <em>country,</em>, &amp;c.]</span>, <span class="auth">(Ḳ, TA,)</span> <em>and became possessed of mastery, dominion,</em> or <em>authority, and power, over it.</em> <span class="auth">(TA.)</span> Fr, however, makes <span class="ar">تَبَحْبُحٌ</span> to be from <span class="ar">ٰالبَاحَةُ</span> <span class="add">[q. v.]</span>, not from a reduplicative root. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bH_RQ2_A2">
					<p><span class="ar">تبحبح</span> also signifies † <em>He was,</em> or <em>became, settled,</em> or <em>established, in authority and power,</em> <span class="auth">(syn. <span class="ar">تَمَكَّنَ</span>,)</span> in alighting, and taking up his abode, or sojourning; <span class="auth">(Ṣ, Ḳ, TA;)</span> and <em>was,</em> or <em>became,</em> <span class="add">[<em>established</em>]</span> <em>in the middle,</em> or <em>midst,</em> <span class="add">[or <em>best part,</em>]</span> <em>of the place of abode;</em> <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">بحبح↓</span></span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bH_RQ2_A3">
					<p>Also ‡ <em>He took a wide, an ample,</em> or <em>a large, range.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bH_RQ2_A4">
					<p><span class="add">[Hence,]</span> <span class="ar long">تبحبح الحَيَا</span> † <em>The rain became of wide extent, and had influence upon the land.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bH_RQ2_A5">
					<p>And <span class="ar long">تَبَحْبَحَتِ العَرَبُ فِى لُغَاتِهَا</span> ‡ <em>The Arabs were copious,</em> or <em>took a wide range, in their dialects.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bH_RQ2_A6">
					<p>And <span class="ar long">تبحبح فِى المَجْدِ</span> † <em>He became in an ample state of glory, honour,</em> or <em>dignity.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bH_RQ2_A7">
					<p>An Arab of the desert said, of a woman in labour, <span class="ar long">تَرَكْتُهَا تَبَحْبَحُ عَلَى أَيْدِى القَوَابِلِ</span> <span class="add">[app. † <em>I left her obtaining delivery by the hands of the midwives</em>]</span>. <span class="auth">(AZ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buHBapN">
				<h3 class="entry"><span class="ar">بُحَّةٌ</span></h3>
				<div class="sense" id="buHBapN_A1">
					<p><span class="ar">بُحَّةٌ</span>: <a href="#OabaHBu">see <span class="ar">أَبَحُّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buHBapN.1">
				<h3 class="entry"><span class="ar">بُحَّةٌ</span></h3>
				<div class="sense" id="buHBapN.1_A1">
					<p><span class="ar">بُحَّةٌ</span> <span class="auth">(Ṣ, A, L, Ḳ)</span> and<span class="arrow"><span class="ar">بُحَاحٌ↓</span></span> <span class="auth">(L)</span> <em>Hoarseness, roughness, harshness,</em> or <em>gruffness, of the voice;</em> <span class="auth">(E, Ḳ;)</span> which is sometimes natural: or the former is applied absolutely, and the latter to that which arises from disease. <span class="auth">(L.)</span> <span class="pb" id="Page_0155"></span>You say, <span class="ar long">فِى صَوْتِهِ بُحَّةٌ</span> <span class="add">[<em>In his voice is hoarseness,</em>, &amp;c.]</span>. <span class="auth">(Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buHaAHN">
				<h3 class="entry"><span class="ar">بُحَاحٌ</span></h3>
				<div class="sense" id="buHaAHN_A1">
					<p><span class="ar">بُحَاحٌ</span>: <a href="#buHBapN">see <span class="ar">بُحَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHobaHieBN">
				<h3 class="entry"><span class="ar">بَحْبَحِىٌّ</span></h3>
				<div class="sense" id="baHobaHieBN_A1">
					<p><span class="ar">بَحْبَحِىٌّ</span> † <em>Ample in expenditure:</em> and <em>having an ample place of abode.</em> <span class="auth">(Fr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buHobuwHN">
				<h3 class="entry"><span class="ar">بُحْبُوحٌ</span></h3>
				<div class="sense" id="buHobuwHN_A1">
					<p><span class="ar">بُحْبُوحٌ</span>: <a href="#buHobuwHapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buHobuwHapN">
				<h3 class="entry"><span class="ar">بُحْبُوحَةٌ</span></h3>
				<div class="sense" id="buHobuwHapN_A1">
					<p><span class="ar">بُحْبُوحَةٌ</span> † The <em>middle,</em> or <em>midst,</em> <span class="add">[or <em>best part,</em>]</span> syn. <span class="ar">وَسَطٌ</span>, <span class="auth">(AʼObeyd, Ṣ, A, Ḳ,)</span> of an abode, or a district, or country, <span class="auth">(Ṣ, A,)</span> or a place, <span class="auth">(Ḳ,)</span> and of a place where one alights and abides, <span class="auth">(TA,)</span> and of Paradise, and of anything, and the <em>best part</em> thereof; <span class="auth">(AʼObeyd, TA;)</span> <span class="add">[like <span class="ar">وَسَطٌ</span>, by which it is explained; because what is between the two extremes is generally the best: it may be well rendered the <em>heart,</em> or <em>very heart,</em> of a thing;]</span> and<span class="arrow"><span class="ar">بُحْبُوحٌ↓</span></span>, also, has the former of these significations <span class="add">[and by implication the other likewise]</span>. <span class="auth">(TA, voce <span class="ar">بُؤْبُؤٌ</span>, where see an ex.)</span> Jereer says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَوْمِى تَمِيمٌ هُمُ القَوْمُ الذَّينَ هُمُ</span> *</div> 
						<div class="star">* <span class="ar long">يَنْفُونَ تَغْلِبَ عَنْ بُحْبُوحَةِ الدَّارِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>My people are Temeem: they are the people who drive away Teghlib from the middle,</em> or <em>best part, of the country</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[It is said in the A, that this word, as syn. with <span class="ar">وَسَطٌ</span>, in relation to an abode or the like (<span class="ar">دار</span>), is tropical; but I see no reason for this, unless by <span class="ar">وسط</span> be meant the “best part.”]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabaHBN">
				<h3 class="entry"><span class="ar">أَبَحٌّ</span></h3>
				<div class="sense" id="OabaHBN_A1">
					<p><span class="ar">أَبَحٌّ</span>, applied to a man, <span class="auth">(Ṣ, L, Ḳ,)</span> or <span class="ar long">أَبَحٌّ الصَّوْتِ</span>, <span class="auth">(A,)</span> <em>Having a hoarse, rough, harsh,</em> or <em>gruff, voice:</em> <span class="auth">(L, Ḳ:)</span> fem. <span class="ar">بَحَّآءُ</span>; with which <span class="arrow"><span class="ar">بَحَّةٌ↓</span></span> is syn.: <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">بُحٌّ</span>. <span class="auth">(Ṣ.)</span> <span class="ar">بَاحٌّ</span> is not allowable. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: <span class="ar">أَبَحٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabaHBN_A2">
					<p>And <span class="ar">أَبَحُّ</span> applied to a lute (<span class="ar">عُودٌ</span>), ‡ <em>Rough</em> <span class="auth">(Ḳ, TA)</span> <em>in sound.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: <span class="ar">أَبَحٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OabaHBN_A3">
					<p>Also ‡ The <em>base,</em> or <em>thick, chord of a lute;</em> syn. <span class="ar">بَمُّ</span>; because of its rough sound. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: <span class="ar">أَبَحٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OabaHBN_A4">
					<p>‡ <em>A</em> <span class="add">[<em>gold coin of the kind called</em>]</span> <span class="ar">دِينَار</span>; <span class="auth">(Ḳ, TA;)</span> because of its harsh sound <span class="add">[when one rings it]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بح</span> - Entry: <span class="ar">أَبَحٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabaHBN_B1">
					<p>‡ <em>A</em> <span class="ar">قِدْح</span> <span class="add">[or <em>gaming-arrow</em>]</span> <span class="auth">(Ṣ, Ḳ, TA)</span> <em>by means of which lots,</em> or <em>portions, are divided:</em> <span class="auth">(Ṣ, TA:)</span> pl. <span class="ar">بُحٌّ</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>such an arrow that has no sound.</em> <span class="auth">(TA.)</span> Khufáf Ibn-Nudbeh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَرَوْا أَضْيَافَهُمْ رَبَحًا بِبُحٍّ</span> *</div> 
						<div class="star">* <span class="ar long">يَعِيشُ بِفَضْلِهِنَّ الحَىُّ سُمْرِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They entertained their guests with young weaned she-camels, on the superabundant remains of which the tribe lived, by means of tawny-coloured gaming-arrows whereby the lots</em> that determined who should afford the entertainment <em>were divided:</em> or, accord. to the TA, <span class="ar">ربحا</span> here signifies <em>fat,</em> as a subst.; but this is inconsistent with the affixed pronoun relating to it]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: <span class="ar">أَبَحٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OabaHBN_B2">
					<p>† <em>Fat,</em> as an epithet, not a subst. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بح</span> - Entry: <span class="ar">أَبَحٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OabaHBN_B3">
					<p><span class="ar long">كِسْرٌ أَبَحُّ</span> † <span class="add">[<em>A portion of a limb,</em>, &amp;c.,]</span> <em>having much fat.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0154.pdf" target="pdf">
							<span>Lanes Lexicon Page 154</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0155.pdf" target="pdf">
							<span>Lanes Lexicon Page 155</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
