<article class="root" id="Root_bls">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/172_blz">بلز</a></span>
				<span class="ar">بلس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/174_blsAn">بلسان</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bls_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلس</span></h3>
				<div class="sense" id="bls_4_A1">
					<p><span class="ar">ابلس</span>, <span class="auth">(inf. n. <span class="ar">إِبْلَاسٌ</span>, Ṣ, &amp;c.,)</span> <em>He despaired,</em> <span class="auth">(A boo-Bekr, Ṣ, M, Mṣb, Ḳ,)</span> or <em>gave up hope,</em> <span class="auth">(A boo-Bekr, TA,)</span> <span class="ar long">مِنْ رَحْمَةِ ٱللّٰهِ</span> <em>of the mercy of God.</em> <span class="auth">(A boo-Bekr, Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bls_4_A2">
					<p><em>He became broken</em> <span class="add">[<em>in spirit</em>]</span>, <em>and mournful.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bls_4_A3">
					<p><em>He was,</em> or <em>became, silent,</em> <span class="auth">(Ṣ, M, A, Mṣb,)</span> <em>returning no reply, or answer,</em> <span class="auth">(TA,)</span> <em>by reason of grief,</em> <span class="auth">(Ṣ,)</span> or <em>of despair.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bls_4_A4">
					<p><em>He was,</em> or <em>became, confounded</em> or <em>perplexed, and unable to see his right course.</em> <span class="auth">(Ibn-ʼArafeh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bls_4_A5">
					<p><em>He was,</em> or <em>became, cut short,</em> or <em>stopped,</em> <span class="auth">(Ḳ, TA,)</span> <span class="ar long">فِى حُجَّتِهِ</span> <span class="add">[<em>in his argument,</em> or <em>plea</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bls_4_A6">
					<p><em>He became unable to prosecute his journey:</em> or <em>was prevented from attaining his wish:</em> syn. <span class="ar long">قُطِعَ بِهِ</span>. <span class="auth">(Th, M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bls_4_A7">
					<p><em>He repented;</em> or <em>grieved for what he had done.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلس</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bls_4_B1">
					<p><em>He caused</em> a person <em>to despair.</em> <span class="auth">(Ḥar p. 138.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balisN">
				<h3 class="entry"><span class="ar">بَلِسٌ</span></h3>
				<div class="sense" id="balisN_A1">
					<p><span class="ar">بَلِسٌ</span> <em>Despairing,</em> (<span class="ar">مُبْلِسٌ</span>,) <em>and silent respecting what is in his mind,</em> <span class="auth">(Ḳ, TA,)</span> <em>by reason of grief</em> or <em>fear.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaAsN">
				<h3 class="entry"><span class="ar">بَلَاسٌ</span></h3>
				<div class="sense" id="balaAsN_A1">
					<p><span class="ar">بَلَاسٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> like <span class="ar">سَلَامٌ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">سَحَابٌ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[in a copy of the M written <span class="ar">بِلَاسٌ</span>,]</span> <em>A</em> <span class="add">[<em>garment,</em> or <em>piece of stuff, of the kind called</em>]</span> <span class="ar">مِسْح</span> <span class="add">[i. e. of <em>hair-cloth</em>]</span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> used in this sense by the people of El-Medeeneh: <span class="auth">(Ṣ:)</span> a Persian word; <span class="auth">(AO, Ṣ, Mṣb;)</span> originally <span class="ar">بَلَاسٌ</span>, without <span class="ar">ال</span>: <span class="auth">(TA:)</span> arabicized: <span class="auth">(Ṣ, Mṣb:)</span> also called by the Arabs <span class="ar">پَلَاس</span>, with the <span class="ar">ب</span> termed <span class="ar">مُشَبَّع</span>: <span class="auth">(TA:)</span> pl. <span class="ar">بُلُسٌ</span>. <span class="auth">(M, Mṣb, Ḳ.)</span> <span class="add">[The pl.]</span> <span class="ar">بُلُسٌ</span> is also applied to <em>Large sacks of</em> <span class="ar">مُسُوح</span> <span class="add">[i. e. <em>hair-cloths</em>]</span>, <em>in which figs are put,</em> <span class="add">[<em>or,</em> more probably, <em>in which straw is put,</em> for <span class="ar">التِّين</span>, which I find in two copies of the Ṣ and in the TA, can hardly be doubted to be a mistranscription of <span class="ar">التِّبْن</span>]</span>, <em>and upon which is paraded he who is made a public example that others may take warning from him, and the subject of a proclamation</em> <span class="add">[<em>acquainting the spectators with his offence</em>]</span>: whence the imprecation, <span class="ar long">أَرَانِيكَ ٱللّٰهُ عَلَى البُلُسِ</span> <span class="add">[<em>May God show me thee upon the large haircloth-sacks</em>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balasaAnN">
				<h3 class="entry"><span class="ar">بَلَسَانٌ</span></h3>
				<div class="sense" id="balasaAnN_A1">
					<p><span class="ar">بَلَسَانٌ</span> <span class="add">[The <em>balsam-tree;</em> or the <em>species that produces the balsam of Mekkeh;</em> i. e., the <em>amyris opobalsamum;</em>]</span> <em>a certain kind of tree,</em> <span class="auth">(M,)</span> or <em>shrub, resembling the</em> <span class="ar">حِنَّآء</span>, <span class="auth">(Ḳ,)</span> <em>having many leaves, inclining to white, in odour resembling the</em> <span class="ar">سَذَاب</span> <span class="add">[or <em>rue</em>]</span>, <span class="auth">(TA,)</span> <em>the berry of which has an unguent,</em> <span class="auth">(Lth, M, TA,)</span> <em>which is hot,</em> <span class="auth">(Lth, TA,)</span> <em>and its unguent is in great request:</em> <span class="auth">(Lth, Ḳ, TA:)</span> <em>its unguent</em> <span class="add">[<em>opobalsamum</em>]</span> <em>is more potent than its berry</em> <span class="add">[<em>carpobalsamum</em>]</span>, <em>and its berry is more so than its wood</em> <span class="add">[<em>xylobalsamum</em>]</span> <em>: the best of its wood is the smooth, tawny-coloured, pungent and sweet in odour: it is hot and dry in the second degree; and its berry is a little hotter than it: its wood opens stoppages of the nose, and is good for the sciatica and vertigo and headache, and clears cloudiness of the eye, and is good for asthma and oppression of the breath, and for flaccidity of the womb, used by fumigation; it is also beneficial in cases of barrenness, and counteracts poisons and the bite of vipers:</em> <span class="auth">(the Minháj, TA:)</span> it is said in the Ḳ and in the Minháj, and by most of the physicians and those who treat of drugs, that it grows only at ʼEyn-Shems, in the neighbourhood of El-Káhireh, the place called El-Matareeyeh; but MF observes that this is strange, as it is well known that it is mostly found in the district of El-Ḥijáz, between the Harameyn and El-Yembo', whence it is conveyed to all countries: the truth, however, is, that it ceased to grow at ʼEyn-Shems in the latter part of the eighth century <span class="add">[of the Flight]</span>, and it was endeavoured <span class="add">[successfully]</span> to be made to grow in El-Ḥijáz. <span class="auth">(TA.)</span> <span class="add">[See also De Sacy's “Abd-allatif,” p. 89.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balBaAsN">
				<h3 class="entry"><span class="ar">بَلَّاسٌ</span></h3>
				<div class="sense" id="balBaAsN_A1">
					<p><span class="ar">بَلَّاسٌ</span> <em>One who sells what is termed</em> <span class="ar">بَلَاس</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iiboliysu">
				<h3 class="entry"><span class="ar">إِبْلِيسُ</span></h3>
				<div class="sense" id="Iiboliysu_A1">
					<p><span class="ar">إِبْلِيسُ</span> <span class="add">[A name of <em>Satan</em>]</span>; from <span class="ar">أَبْلَسَ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> in the first of the senses assigned to it above, <span class="auth">(Ṣ, M, Mṣb,)</span> accord. to some; <span class="auth">(M, Mṣb, Ḳ;)</span> his former name being <span class="ar">عَزَازِيلُ</span>: <span class="auth">(Ṣ, TA:)</span> or it is a foreign word, <span class="auth">(Aboo-Is-ḥáḳ, M, Mṣb, Ḳ,)</span> and for this reason, <span class="auth">(Aboo-Is-ḥáḳ, M, Mṣb, TA,)</span> and its being also determinate, <span class="auth">(Aboo-Is-ḥáḳ, M, TA,)</span> or a proper name, <span class="auth">(Mṣb,)</span> it is imperfectly decl.; <span class="auth">(Aboo-Is-ḥáḳ, M, &amp;c.;)</span> for if it were an Arabic word, it would be perfectly decl., like <span class="ar">إِجْفِيلٌ</span> and <span class="ar">إِخْرِيطٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0248.pdf" target="pdf">
							<span>Lanes Lexicon Page 248</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
