<article class="root" id="Root_bSl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/118_bSq">بصق</a></span>
				<span class="ar">بصل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/120_bSm">بصم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bSl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بصّل</span></h3>
				<div class="sense" id="bSl_2_A1">
					<p><span class="ar">تَبْصِيلٌ</span> The act of <em>stripping,</em> or <em>divesting;</em> <span class="add">[<em>like as when one strips an onion</em> (<span class="ar">بَصَلَة</span>) <em>of its coats;</em>]</span> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">تَبَصُّلٌ↓</span></span>. <span class="auth">(Fr, Ḳ.)</span> You say, <span class="ar long">بَصَّلْتُ الرَّجُلَ عِنْ ثِيَابِهِ</span> <span class="add">[and<span class="arrow"><span class="ar">تَبَصَّلْتُهُ↓</span></span>]</span> <em>I stripped the man of his clothes.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبصّل</span></h3>
				<div class="sense" id="bSl_5_A1">
					<p><span class="ar">تبصّل</span> <em>It</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became, several fold,</em> or <em>many fold, like the coats of the</em> <span class="ar">بَصَل</span> <span class="add">[or <em>onion</em>]</span>. <span class="auth">(Z, TA.)</span> <a href="#mutab~SBilN">See also <span class="ar">مُتَبّصِّلٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصل</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bSl_5_B1">
					<p>It is also trans.: <a href="#bSl_2">see 2</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bSl_5_B2">
					<p><span class="add">[Hence,]</span> <span class="ar">تَبَصَّلُوهُ</span> † <em>They begged of him so much that all that he had became exhausted.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSalN">
				<h3 class="entry"><span class="ar">بَصَلٌ</span> / <span class="ar">بَصَلَةٌ</span></h3>
				<div class="sense" id="baSalN_A1">
					<p><span class="ar">بَصَلٌ</span> <span class="add">[The <em>onion; allium cepa:</em> or <em>onions,</em> collectively:]</span> what it signifies is <em>well known:</em> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَصَلَةٌ</span>}</span></add>. <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span> Hence the prov., <span class="ar long">أَكْسَى مِنَ البَصَلِ</span> <span class="add">[<em>Having more coats,</em> or <em>coverings, than the onion</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0213"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصل</span> - Entry: <span class="ar">بَصَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baSalN_A2">
					<p><span class="add">[Also <em>Any kind of bulb,</em> or <em>bulbous plant.</em>]</span> <span class="ar long">بَصَلُ الزَّعْفَرَانِ</span> <span class="add">[<em>The bulb of the saffron</em>]</span>, which is buried in the ground, is like the <span class="ar">بَصَل</span> <span class="add">[or onion]</span> commonly known. <span class="auth">(Mgh.)</span> <span class="ar long">بَصَل الفَأْرِ</span> is <em>the same as</em> <span class="ar">الإِسْقِيلُ</span> and <span class="ar">الإِسْقَالُ</span> and <span class="ar">العُنْصَلُ</span>, <span class="auth">(Ḳ in art. <span class="ar">سقل</span>,)</span> also written <span class="ar">العُنْصُلُ</span>, <span class="auth">(Ḳ in art. <span class="ar">عصل</span>,)</span> or <span class="ar long">بَصَلُ العنصل</span>, <span class="auth">(KL voce <span class="ar">زيزٌ</span>, <span class="add">[and so as written by Golius,]</span>)</span> <span class="add">[<em>Scilla,</em> or <em>squill;</em> particularly <em>scilla maritima,</em> or <em>officinal squill;</em> called by all these names, except, perhaps, <span class="ar">السقال</span>, in the present day;]</span> also called <span class="ar">زِيزٌ</span>, and <span class="ar long">البَصَلُ البَرِّىُّ</span> <span class="add">[<em>the wild onion;</em> but from what follows, it seems that there is a confusion here]</span>. <span class="auth">(KL ubi suprà.)</span> <span class="ar long">بَصَلُ الذِّئْبِ</span>, and <span class="ar long">بصل الزير</span>, <span class="auth">(Golius on the authority of Zeyn El-Attár,)</span> or <span class="ar long">بصل الرند</span>, <span class="auth">(so in the TA in art. <span class="ar">بلبس</span>,)</span> <em>i. q.</em> <span class="ar">بلبوس</span> <em>Bulbus esculentus,</em> <span class="auth">(Golius, from Zeyn El-Attár,)</span> or <span class="ar">البَلْبُوس</span>, with fet-ḥ, <span class="add">[thus generally written, though it would seem to be correctly <span class="ar">بُلْبُوس</span>,]</span> <em>the leaves of which resemble those of the</em> <span class="ar">سَذَاب</span> <span class="add">[or <em>rue</em>]</span>: <span class="auth">(TA in art. <span class="ar">بلبس</span>:)</span> the <span class="ar">بَلْبُوس</span> is <em>the wild onion</em> <span class="auth">(in Pers. <span class="ar long">پِيَازْ صَحْرَائِى</span>)</span>. <span class="auth">(KL voce <span class="ar">بلبوس</span>. <span class="add">[This last assertion suggests that <span class="ar">الزير</span> and <span class="ar">الرند</span> may be mistranscriptions for <span class="ar">الزِّيز</span>; the <span class="ar">زيز</span> mentioned before.]</span>)</span> <span class="add">[<span class="ar long">بَصَلُ القىْءَ</span> <em>Bulbus vomitorius;</em> mentioned by Golius; and by Dioscorides, <span class="auth">(l. ii. c. 201,)</span> as being emetic and diuretic.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصل</span> - Entry: <span class="ar">بَصَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baSalN_A3">
					<p>Also, <span class="auth">(Ḳ,)</span> or <span class="ar">بَصَلَةٌ</span>, <span class="auth">(M,)</span> ‡ <em>A helmet</em> <span class="auth">(M, Ḳ)</span> <em>of iron,</em> <span class="auth">(Ḳ,)</span> <em>pointed in the middle;</em> so called as being likened to what is first mentioned above. <span class="auth">(M.)</span> Lebeed likens helmets to <span class="ar">بَصَل</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabaSBilN">
				<h3 class="entry"><span class="ar">مُتَبَصِّلٌ</span></h3>
				<div class="sense" id="mutabaSBilN_A1">
					<p><span class="ar">مُتَبَصِّلٌ</span> <span class="auth">(ISh, Ḳ)</span> and<span class="arrow"><span class="ar long">ذُو تَبَصُّلٍ↓</span></span> <span class="auth">(ISh, TA)</span> A covering of any kind (<span class="ar">قِشْرٌ</span>) <em>consisting of many coats; thick;</em> <span class="auth">(ISh, Ḳ;)</span> <em>like the coats of the</em> <span class="ar">بَصَل</span> <span class="add">[or <em>onion</em>]</span>. <span class="auth">(ISh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0212.pdf" target="pdf">
							<span>Lanes Lexicon Page 212</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0213.pdf" target="pdf">
							<span>Lanes Lexicon Page 213</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
