<article class="root" id="Root_brjm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/062_brj">برج</a></span>
				<span class="ar">برجم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/064_brH">برح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="burojumapN">
				<h3 class="entry"><span class="ar">بُرْجُمَةٌ</span></h3>
				<div class="sense" id="burojumapN_A1">
					<p><span class="ar">بُرْجُمَةٌ</span> <span class="auth">(in the Ḥam p. 352 <span class="ar">بُرْجُمٌ</span>)</span> <a href="#baraAjimu">is the sing. of <span class="ar">بَرَاجِمُ</span></a> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بُرْجُمَاتٌ</span>; <span class="auth">(T, TA;)</span> and signifies <span class="add">[<em>A knuckle,</em> or <em>finger-joint;</em>]</span> the <em>outer,</em> or the <em>inner, joint,</em> or <em>place of division, of the fingers:</em> and <span class="auth">(as some say, TA)</span> the <em>middle toe of any bird:</em> <span class="auth">(Ḳ:)</span> or <span class="ar">بَرَاجِمُ</span> signifies all the <em>finger-joints;</em> <span class="auth">(AʼObeyd, Ḳ;)</span> as also <span class="ar">رَوَاجِمُ</span> <span class="add">[a mistranscription for <span class="ar">رَوَاجِب</span>]</span>: <span class="auth">(AʼObeyd, TA:)</span> or the <em>parts of the fingers that are protuberant when one clinches his hand:</em> <span class="auth">(Ḥam ubi suprà:)</span> or the <em>backs of the finger-bones:</em> <span class="auth">(Ḳ:)</span> or the <em>finger-joints</em> <span class="auth">(Ṣ, Mgh)</span> <em>that are between the</em> <span class="ar">أَشَاجِع</span> <em>and the</em> <span class="ar">رَوَاجِب</span>; <span class="auth">(Ṣ;)</span> i. e. <span class="auth">(Ṣ, Mgh)</span> <span class="add">[the <em>middle knuckles;</em> (<a href="#OaXojaEu">see <span class="ar">أَشْجَعُ</span></a> <a href="#raAjibapN">and <span class="ar">رَاجِبَةٌ</span></a>;)]</span> the <em>heads of the</em> <span class="ar">سُلَامَيَات</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>on the back,</em> or <em>outer side, of the hand,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>which become protuberant when one clinches his hand:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> or, as in the Kf, the <em>heads of the</em> <span class="ar">سلاميات</span>; and their inner and outer sides are termed the <span class="ar">رَوَاجِب</span>: <span class="auth">(Mṣb:)</span> accord. to the T, the <em>wrinkled parts at the joints of the fingers;</em> the smooth portion between which is called <span class="ar">رَاجِبَةٌ</span>: or, as in another place, <em>in the backs of the fingers;</em> the parts between them being called the <span class="ar">رَوَاجِب</span>: <em>in every finger are three</em> <span class="ar">بُرْجُمَات</span>, <em>except the thumb:</em> or, as in another place, <em>in every finger are two of what are thus termed:</em> it is also explained as signifying the <em>joints in the backs of the fingers, upon which the dirt collects.</em> <span class="auth">(TA.)</span> <span class="pb" id="Page_0181"></span>The phrase <span class="ar long">الأَخْذُ بِالبَرَاجِمِ</span>, meaning <em>The seizing with the hand,</em> is one requiring consideration <span class="add">[as of doubtful character]</span>. <span class="auth">(Mgh.)</span> <span class="add">[<a href="#burovunN">See also <span class="ar">بُرْثُنٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0180.pdf" target="pdf">
							<span>Lanes Lexicon Page 180</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0181.pdf" target="pdf">
							<span>Lanes Lexicon Page 181</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
