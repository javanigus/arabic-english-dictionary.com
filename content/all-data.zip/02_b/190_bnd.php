<article class="root" id="Root_bnd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/189_bnj">بنج</a></span>
				<span class="ar">بند</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/191_bndr">بندر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="banodN">
				<h3 class="entry"><span class="ar">بَنْدٌ</span></h3>
				<div class="sense" id="banodN_A1">
					<p><span class="ar">بَنْدٌ</span> is a Persian word arabicized, originally signifying <em>A knot,</em> or <em>tie.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="banodN_A2">
					<p>Hence, <span class="auth">(TA,)</span> ‡ <span class="add">[<em>Any of</em>]</span> <em>the stops that are put between the beads of the</em> <span class="ar">سُبْحَة</span> <em>to mark the place where the performer of</em> <span class="ar">تَسْبِيح</span> <em>pauses on the occasion of a thing's diverting his attention:</em> so in the Comm. on the Tohfeh by the seyyid ʼOmar El-Basree: <span class="auth">(MF, TA:)</span> app. post-classical and recent. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="banodN_A3">
					<p><em>A dam; a thing that stops,</em> or <em>dams,</em> <span class="add">[<em>water,</em> or]</span> <em>from water</em> (<span class="ar long">الَّذِى يُسْكِرُ مِنَ المَآءِ</span>). <span class="auth">(Ḳ. <span class="add">[In the CK, <span class="ar">يُسْكَرُ</span> is put in the place of <span class="ar">يُسْكِرُ</span>. In this sense, also, it is of Persian origin.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="banodN_A4">
					<p><em>A stratagem, a trick,</em> or <em>an expedient, of which one makes use:</em> <span class="auth">(T, Ḳ:)</span> <em>a snare by which one snares men:</em> <span class="auth">(TA in art. <span class="ar">قمط</span>:)</span> pl. <span class="ar">بُنُودٌ</span>. <span class="auth">(T.)</span> You say, <span class="ar long">فُلَانٌ كَثِيرٌ البُنُودِ</span> <em>Such a one abounds in,</em> or <em>practises much, stratagems, tricks,</em> or <em>expedients,</em> <span class="auth">(Lth, T, A,)</span> <em>and mischievous,</em> or <em>calamitous, acts.</em> <span class="auth">(A.)</span> In this sense, also, it is an arabicized Persian word. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="banodN_A5">
					<p><em>An enigma.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="banodN_A6">
					<p><em>A pawn that is tied</em> (<span class="ar">مُنْعَقِدٌ</span>, in the CK <span class="ar">مُتَعَقِّدٌ</span>,) <em>by a queen in the game of chess:</em> as though it confined and tied itself. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="banodN_A7">
					<p>Also a Persian word, arabicized, <span class="auth">(Ṣ, A,)</span> signifying <em>A large banner, standard,</em> or <em>ensign:</em> <span class="auth">(En-Naḍr, Ṣ, A, Ḳ:)</span> or <em>a banner,</em> or <em>standard,</em> or <em>an ensign, of a general,</em> or <em>leader,</em> <span class="auth">(T, M,)</span> <em>of the Greeks,</em> <span class="auth">(M,)</span> <em>under which are ten thousand men,</em> <span class="auth">(T, M,)</span> or <em>less,</em> or <em>more:</em> <span class="auth">(T:)</span> or <em>a banner,</em> or <em>standard,</em> or <em>an ensign, of horsemen:</em> <span class="auth">(El-Hujeymee, T:)</span> <span class="add">[in barbarous Latin <em>bandum;</em> and in Spanish, <em>bandera;</em> as mentioned by Golius; and in modern Arabic <span class="ar">بَنْدِيرٌ</span>:]</span> pl. as above: <span class="auth">(Ṣ, M:)</span> it has no pl. of pauc. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بند</span> - Entry: <span class="ar">بَنْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="banodN_A8">
					<p><span class="add">[The pl.]</span> <span class="ar">بُنُودٌ</span> also signifies, in Greece, <span class="add">[<em>Provinces,</em> or <em>districts;</em>]</span> <em>what are called</em> <span class="ar">أَجْنَادٌ</span> <em>in Syria, and</em> <span class="ar">أَعْرَاضٌ</span> <em>in El-Ḥijáz, and</em> <span class="ar">كُوَرٌ</span> <em>in El-'Irak, and</em> <span class="ar">مَخَالِيفٌ</span> <em>in El-Yemen.</em> <span class="auth">(Yákoot.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
