<article class="root" id="Root_bwr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/217_bwd">بود</a></span>
				<span class="ar">بور</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/219_bwz">بوز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بور</span> ⇒ <span class="ar">بار</span></h3>
				<div class="sense" id="bwr_1_A1">
					<p><span class="ar">بَارَ</span>, <span class="auth">(Ṣ, M, Mṣb,)</span> aor. <span class="ar">يَبُورُ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَوَارٌ</span> <span class="auth">(Lth, T, Ṣ, M, Ḳ)</span> and <span class="ar">بَوْرٌ</span>, <span class="auth">(M, Ḳ,)</span> or <span class="ar">بُورٌ</span>, <span class="auth">(Mṣb,)</span> <em>He,</em> <span class="auth">(Ṣ,)</span> or <em>it,</em> <span class="auth">(Mṣb,)</span> <em>perished.</em> <span class="auth">(Lth, T, Ṣ, M, Mṣb, Ḳ.)</span> You say, <span class="ar long">بَادُوا وَبَارُوا</span> <span class="add">[<em>They became extinct, and perished</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwr_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَارَتِ الأَرْضُ</span> ‡ <em>The land was,</em> or <em>became, in a bad,</em> or <em>corrupt, state, and uncultivated;</em> <span class="auth">(Ḳ,* TA;)</span> <em>was unsown.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwr_1_A3">
					<p>And <span class="ar long">بَارَ عَمَلُهُ</span> † <em>His work was,</em> or <em>proved, vain,</em> or <em>ineffectual:</em> such is the signification of the verb in the Ḳur xxxv. 11. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwr_1_A4">
					<p>And <span class="ar">بَارَ</span>, <span class="auth">(T, Ṣ, &amp;c.,)</span> aor. as above, inf. n. <span class="ar">بَوَارٌ</span>, <span class="auth">(Mṣb,)</span> ‡ <em>It</em> <span class="auth">(a thing, Mṣb, or commodity, T, Ṣ, A, Mgh)</span> <em>was,</em> or <em>became, unsaleable,</em> or <em>difficult of sale,</em> or <em>in little demand:</em> <span class="auth">(T, Ṣ, A, Mgh, Mṣb:)</span> because a thing, when neglected, becomes of no use, and thus resembles that which perishes. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bwr_1_A5">
					<p>And <span class="ar long">بَارَتِ السُّوقُ</span>, <span class="auth">(T, M,)</span> inf. n. <span class="ar">بَوْرٌ</span> and <span class="ar">بَوَارٌ</span>, <span class="auth">(Ḳ,)</span> ‡ <em>The market was,</em> or <em>became, stagnant,</em> or <em>dull, with respect to traffic.</em> <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bwr_1_A6">
					<p>And <span class="ar long">بَارَتِ الأَيِّمُ</span>, <span class="auth">(A,)</span> inf. n. <span class="ar">بَوَارٌ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> ‡ <em>The woman without a husband was not desired,</em> or <em>sought for:</em> <span class="auth">(A:)</span> or <em>remained in her house long without being demanded in marriage.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bwr_1_A7">
					<p><span class="add">[<span class="ar">بَارَ</span> is also used as an imitative sequent of <span class="ar">حَارَ</span>; like as <span class="ar">بَائِرٌ</span> is of <span class="ar">حَائِرٌ</span>: <a href="index.php?data=06_H/214_Hwr">see exs. in art. <span class="ar">حور</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwr_1_B1">
					<p><span class="ar long">بَارَ النَّاقَةَ</span>, <span class="auth">(T, Ṣ, A, Ḳ,)</span> aor. as above, <span class="auth">(T, Ṣ, A,)</span> inf. n. <span class="ar">بَوْرٌ</span>, <span class="auth">(Ṣ,)</span> <em>He brought the she-camel to the stallion to see if she were pregnant or not:</em> <span class="auth">(T, Ṣ, A, Ḳ:)</span> for if she is pregnant, she voids her urine in his face <span class="auth">(Ṣ, Ḳ)</span> when he smells her. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bwr_1_B2">
					<p>Also <em>He</em> <span class="auth">(the stallion)</span> <em>smelt the she-camel to know if she were pregnant or not;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> and so<span class="arrow"><span class="ar">ابتارها↓</span></span>. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bwr_1_B3">
					<p>Hence the saying, <span class="ar long">بُرْ لِى مَا عَنْدَ فُلَانٍ</span> ‡ <em>Try thou,</em> or <em>examine, and learn, for me, what is in the mind</em> (<span class="ar">نَفْس</span> Ṣ) <em>of such a one.</em> <span class="auth">(Ṣ, A.*)</span> You say, <span class="ar">بَارَهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. as above, <span class="auth">(T, Ṣ,)</span> inf. n. <span class="ar">بَوْرٌ</span>; <span class="auth">(T, M, Ḳ;)</span> and<span class="arrow"><span class="ar">ابتارهُ↓</span></span>, <span class="auth">(M,)</span> inf. n. <span class="ar">اِبْتِيَارٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> meaning ‡ <em>He tried him; assayed him; proved him by experiment</em> or <em>experience; examined him.</em> <span class="auth">(T, Ṣ, M, Ḳ.)</span> El-Kumeyt says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَبِيحٌ بِمِثْلِىَ نَعْتُ الفَتَاةِ</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">إِمَّا ٱبْتِهَارًا و إِمَّا ٱبْتِيَارَا↓</span></span> *</div> 
					</blockquote>
					<p><span class="auth">(T, Ṣ)</span> ‡ <em>It were foul in the like of me to characterize the damsel either by false accusation or by trying, with speaking truth, to elicit what is in her mind</em> (<span class="ar long">مَا عِنْدَهَا</span> <span class="add">[i. e. <span class="ar long">مَا فِى نَفْسِهَا</span>, agreeably with an explanation given above]</span>): <span class="auth">(Ṣ, TA:)</span> or<span class="arrow"><span class="ar">ابتيارا↓</span></span>, which is without <span class="ar">ء</span>, here signifies <em>by asserting with truth my having had sexual intercourse with her:</em> <span class="auth">(TA:)</span> <span class="add">[for]</span> <span class="ar">ابتارها</span> signifies <em>he asserted with truth that he had had sexual intercourse with her;</em> and <span class="ar">ابتهرها</span> “he asserted the same falsely:” <span class="auth">(AʼObeyd, T:)</span> and the former signifies also <em>he had sexual intercourse with her</em> <span class="auth">(Ḳ, TA)</span> <em>by force; he ravished her:</em> <span class="auth">(TA:)</span> or <span class="ar">ابتار</span> signifies <em>he charged,</em> or <em>upbraided,</em> a person <em>with that which was not in him;</em> and <span class="ar">ابتهر</span> “he charged, or upbraided, with that which was in him.” <span class="auth">(TA in art. <span class="ar">بهر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابور</span> ⇒ <span class="ar">ابار</span></h3>
				<div class="sense" id="bwr_4_A1">
					<p><span class="ar">ابارهُ</span> <em>He</em> <span class="auth">(God)</span> <em>destroyed him; caused him to perish.</em> <span class="auth">(Ṣ, M, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bwr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتور</span> ⇒ <span class="ar">ابتار</span></h3>
				<div class="sense" id="bwr_8_A1">
					<p><a href="#bwr_1">see 1</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baworN">
				<h3 class="entry"><span class="ar">بَوْرٌ</span></h3>
				<div class="sense" id="baworN_A1">
					<p><span class="ar long">أَرْضٌ بَوْرٌ</span>, <span class="auth">(AʼObeyd, T, &amp;c.,)</span> in which the latter word is an inf. n. <span class="add">[of 1]</span> used as an epithet, <span class="auth">(IAth,)</span> ‡ <em>Land not sown;</em> <span class="auth">(AʼObeyd, T, Ṣ, IAth;)</span> as also<span class="arrow"><span class="ar">بَوَارٌ↓</span></span>, <span class="add">[likewise an inf. n. used as an epithet,]</span> of which the pl. is <span class="ar">بُورٌ</span>: <span class="auth">(A, IAth:)</span> or <em>land before it is prepared for sowing</em> <span class="auth">(AḤn, M, Ḳ)</span> <em>or planting:</em> <span class="auth">(AḤn, M:)</span> or <em>land that is left to lie fallow one year, that it may be sown the next year:</em> <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar long">أَرْضٌ بَائِرٌ↓</span></span>, <span class="auth">(Zj, M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَائِرَةٌ↓</span></span>, <span class="auth">(Zj, Ḳ,)</span> and<span class="arrow"><span class="ar">بُورٌ↓</span></span>, <span class="add">[which is originally an inf. n.,]</span> <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar long">بُورُ↓ الأَرْضِ</span></span>, <span class="add">[in which the former word may be <a href="#bawaArN">pl. of <span class="ar">بَوَارٌ</span></a>, mentioned above,]</span> <span class="auth">(M,)</span> ‡ <em>land that is in a bad state, and uncultivated,</em> <span class="auth">(Ḳ,* TA,)</span> <em>unsown,</em> <span class="auth">(M, TA,)</span> <em>and not planted:</em> <span class="auth">(TA:)</span> or <em>left unsown.</em> <span class="auth">(Zj, M.)</span> You say also,<span class="arrow"><span class="ar long">أَصْبَحَتْ مَنَازِلُهُمْ بُورًا↓</span></span> † <em>Their abodes became void, having nothing in them.</em> <span class="auth">(Fr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بَوْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baworN_A2">
					<p><a href="#buwrN">See also <span class="ar">بُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwrN">
				<h3 class="entry"><span class="ar">بُورٌ</span></h3>
				<div class="sense" id="buwrN_A1">
					<p><span class="ar">بُورٌ</span> A <em>bad,</em> or <em>corrupt,</em> man; <span class="auth">(Ṣ, A, Ḳ;)</span> and one <span class="auth">(M, Ḳ)</span> <em>in a state of perdition;</em> <span class="auth">(Ṣ, M, A, Ḳ;)</span> <em>in whom is no good;</em> <span class="auth">(Ṣ, Ḳ;)</span> originally an inf. n., <span class="auth">(Fr, T,)</span> and <span class="add">[therefore, as an epithet,]</span> applied also to a female, <span class="auth">(AO, T, Ṣ, M, Ḳ,)</span> and to two persons, and more: <span class="auth">(AO, T, M, Ḳ:)</span> <span class="add">[but see what here follows:]</span> <span class="arrow"><span class="ar">بَائِرٌ↓</span></span>, also, signifies <em>bad,</em> or <em>corrupt; destitute of good;</em> <span class="auth">(Zj, M;)</span> a man <em>in a state of perdition;</em> <span class="auth">(AO, T, Ṣ;)</span> and its pl., <span class="auth">(Ḳ,)</span> or rather quasi-pl., <span class="auth">(M, TA,)</span> is <span class="arrow"><span class="ar">بَوْرٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> like as <span class="ar">نَوْمٌ</span> is of <span class="ar">نَائِمٌ</span>, and <span class="ar">صَوْمٌ</span> of <span class="ar">صَائِمٌ</span>; <span class="auth">(M, TA;)</span> and another pl. of the same is <span class="ar">بُورٌ</span>, <span class="auth">(AO, T, Ṣ, M,)</span> like as <span class="ar">حُولٌ</span> is of <span class="ar">حَائِلٌ</span>, or, accord. to some, as Akh states, this is a dial. var., not a pl., of <span class="ar">بَائِرٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buwrN_A2">
					<p><a href="#baWorN">See also <span class="ar">بَوْرٌ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buwrN_B1">
					<p><span class="ar long">إِنَّهُمْ لَفِى حُورٍ وَبُورٍ</span> <span class="auth">(A, TA <span class="add">[but in the latter, <span class="ar">جور</span> is put for <span class="ar">حَور</span>]</span>)</span> <em>Verily they are in a state of deficiency,</em> or <em>detriment.</em> <span class="auth">(TA.)</span> <a href="#baAyirN">See also <span class="ar">بَائِرٌ</span></a>. <span class="add">[<a href="#HaWorN">And see <span class="ar">حَوْرٌ</span></a>.]</span> You say also,<span class="arrow"><span class="ar long">ذَهَبَ فُلَانٌ فِى الحَوارِ وَالبَوَارِ↓</span></span> <em>Such a one went away in a defective and bad state.</em> <span class="auth">(L, TA in art. <span class="ar">حور</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baArieBN.1">
				<h3 class="entry"><span class="ar">بَارِىٌّ</span></h3>
				<div class="sense" id="baArieBN.1_A1">
					<p><span class="ar">بَارِىٌّ</span> and<span class="arrow"><span class="ar">بُورِىٌّ↓</span></span> and<span class="arrow"><span class="ar">بَارِيَّةٌ↓</span></span> <span class="auth">(Aṣ, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">بُورِيَّةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">بَارِيَآءُ↓</span></span> and<span class="arrow"><span class="ar">بُورِيَآءُ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> all arabicized words, from the Persian, <span class="auth">(M,)</span> <em>A woven mat,</em> <span class="auth">(M, Ḳ,)</span> <em>made of reeds;</em> <span class="auth">(Ṣ;)</span> <em>what is called in Persian</em> <span class="fa">بُورِيَا</span>: <span class="auth">(Aṣ, Ḳ:)</span> or <em>a rough</em> <span class="ar">حَصِير</span> <span class="add">[or <em>mat</em>]</span>. <span class="auth">(Mṣb in art. <span class="ar">برى</span> <span class="add">[to which the words belong accord. to Fei, and the same is asserted to be the case by some others]</span>.)</span> <span class="add">[The pl. is <span class="ar">بَوَارِىُّ</span>.]</span> It is said in a trad.,<span class="arrow"><span class="ar long">كَانَ لَا يَرَى بَأْسًا بِالصَّلَاةِ عَلَى البُورِىِّ↓</span></span> explained as meaning <em>He did not see any harm in praying upon a mat made of reeds.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بَارِىٌّ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baArieBN.1_A2">
					<p>Accord. to some, <span class="auth">(M,)</span> <em>A road;</em> syn. <span class="ar">طَرِيقٌ</span>: <span class="auth">(Ḳ, M:)</span> <span class="add">[so, perhaps, in the trad. cited above:]</span> arabicized. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwrieBN">
				<h3 class="entry"><span class="ar">بُورِىٌّ</span></h3>
				<div class="sense" id="buwrieBN_A1">
					<p><span class="ar">بُورِىٌّ</span>: <a href="#baArieBN">see <span class="ar">بَارِىٌّ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بُورِىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buwrieBN_B1">
					<p>Also <em>A kind of fish;</em> <span class="add">[<em>a species of mullet,</em> the <em>mugil cephalus</em> of Linnæus, of the roe and milt of which is made what the Italians call botargo, and the Arabs <span class="ar">بَطَارِخ</span>, and, accord. to Golius, <span class="ar">بوترغا</span>;]</span> so called from a town in Egypt, named <span class="ar">بُورَةُ</span>, <span class="auth">(Ḳ,)</span> between Tinnees and Dimyát, of which there are now no remains. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAriyBapN">
				<h3 class="entry"><span class="ar">بَارِيَّةٌ</span></h3>
				<div class="sense" id="baAriyBapN_A1">
					<p><span class="ar">بَارِيَّةٌ</span>: <a href="#baArieBN">see <span class="ar">بَارِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwriyBapN">
				<h3 class="entry"><span class="ar">بُورِيَّةٌ</span></h3>
				<div class="sense" id="buwriyBapN_A1">
					<p><span class="ar">بُورِيَّةٌ</span>: <a href="#baArieBN">see <span class="ar">بَارِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAriyaMCu">
				<h3 class="entry"><span class="ar">بَارِيَآءُ</span></h3>
				<div class="sense" id="baAriyaMCu_A1">
					<p><span class="ar">بَارِيَآءُ</span>: <a href="#baArieBN">see <span class="ar">بَارِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwriyaMCu">
				<h3 class="entry"><span class="ar">بُورِيَآءُ</span></h3>
				<div class="sense" id="buwriyaMCu_A1">
					<p><span class="ar">بُورِيَآءُ</span>: <a href="#baArieBN">see <span class="ar">بَارِىٌّ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawaArN">
				<span class="pb" id="Page_0275"></span>
				<h3 class="entry"><span class="ar">بَوَارٌ</span></h3>
				<div class="sense" id="bawaArN_A1">
					<p><span class="ar">بَوَارٌ</span>, <a href="#bwr_1">an inf. n. of 1</a>: <a href="#buwrN">see <span class="ar">بُورٌ</span></a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بَوَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bawaArN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">بَوَارِ</span>, like <span class="ar">قَطَامِ</span>, <span class="add">[an indecl. noun,]</span> <em>Perdition:</em> <span class="auth">(El-Aḥmar, Ṣ, M, Ḳ:)</span> as in the saying, <span class="ar long">نَزَلَتْ بَوَار عَلَى الكُفَّار</span> <em>Perdition fell upon the unbelievers.</em> <span class="auth">(El-Aḥmar, Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بَوَارٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bawaArN_B1">
					<p><a href="#baWorN">See also <span class="ar">بَوْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawaArieBN">
				<h3 class="entry"><span class="ar">بَوَارِىٌّ</span></h3>
				<div class="sense" id="bawaArieBN_A1">
					<p><span class="ar">بَوَارِىٌّ</span> <em>A seller of mats of the kind called</em> <span class="ar">بَارِىٌّ</span>, &amp;c. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYirN">
				<h3 class="entry"><span class="ar">بَائِرٌ</span></h3>
				<div class="sense" id="baAYirN_A1">
					<p><span class="ar">بَائِرٌ</span>: <a href="#buwrN">see <span class="ar">بُورٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بَائِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAYirN_A2">
					<p>You say also <span class="ar long">رَجُلٌ حَائِرٌ بَائِرٌ</span>, <span class="auth">(T, Ṣ, M, A, Ḳ,)</span> and<span class="arrow"><span class="ar long">فِى حُورٍ وَبُورٍ↓</span></span>, <span class="auth">(A,)</span> meaning <em>A man who does not apply himself rightly,</em> <span class="auth">(T, Ṣ, TA,)</span> or <em>has not applied himself rightly,</em> <span class="auth">(Ḳ,)</span> <em>to anything;</em> <span class="auth">(T, Ṣ, Ḳ;)</span> <em>erring; losing his way;</em> <span class="auth">(T;)</span> <em>who will not do right of his own accord, nor obey one directing him aright:</em> <span class="auth">(Ḳ:)</span> it may be from the signification of laziness, or sluggishness, and it may be from that of perdition: <span class="auth">(M:)</span> <span class="add">[or]</span> <span class="ar">بائر</span> is here an imitative sequent of <span class="ar">حائر</span>. <span class="auth">(Ṣ.)</span> <span class="add">[Respecting the latter phrase, <a href="index.php?data=06_H/214_Hwr">see also art. <span class="ar">حور</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بور</span> - Entry: <span class="ar">بَائِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAYirN_A3">
					<p><a href="#baWorN">See also <span class="ar">بَوْرٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibowarN">
				<h3 class="entry"><span class="ar">مِبْوَرٌ</span></h3>
				<div class="sense" id="mibowarN_A1">
					<p><span class="ar long">فَحْلٌ مِبْوَرٌ</span> <em>A stallion-camel that knows the state of the female, whether she be pregnant or not.</em> <span class="auth">(M, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubiyrN">
				<h3 class="entry"><span class="ar">مُبِيرٌ</span></h3>
				<div class="sense" id="mubiyrN_A1">
					<p><span class="ar">مُبِيرٌ</span> A <em>destructive</em> man, <em>acting exorbitantly in destroying others.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0274.pdf" target="pdf">
							<span>Lanes Lexicon Page 274</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0275.pdf" target="pdf">
							<span>Lanes Lexicon Page 275</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
