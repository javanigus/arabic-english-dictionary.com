<article class="root" id="Root_bn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/187_bm">بم</a></span>
				<span class="ar">بن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/189_bnj">بنج</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bn_1">
				<h3 class="entry">1. ⇒ <span class="ar">بنّ</span></h3>
				<div class="sense" id="bn_1_A1">
					<p><a href="#bn_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bn_2">
				<h3 class="entry">2. ⇒ <span class="ar">بنّن</span></h3>
				<div class="sense" id="bn_2_A1">
					<p><span class="ar">بنّن</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْنِينٌ</span>, <span class="auth">(TA,)</span> <em>He tied a sheep,</em> or <em>goat, in order to fatten it:</em> <span class="auth">(Ḳ:)</span> from <span class="ar long">بَنَّ بِالْمَكَانِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bn_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابنّ</span></h3>
				<div class="sense" id="bn_4_A1">
					<p><span class="ar long">ابنّ بِالْمَكَانِ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِبْنَانٌ</span>; <span class="auth">(Lth, T;)</span> and<span class="arrow"><span class="ar long">بَنَّ↓ بِهِ</span></span>, aor. <span class="ar">يَبِنُّ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَنٌّ</span>; <span class="auth">(M, TA;)</span> but Aṣ allows only the former verb; <span class="auth">(M, TA;)</span> <em>He remained, continued, stayed, dwelt,</em> or <em>abode, in the place;</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> <em>he kept,</em> or <em>clave, to the place.</em> <span class="auth">(Lth, T, TA.)</span> Accord. to Z, it is a tropical meaning, from the <span class="ar">بَنَّة</span> <span class="add">[i. e. odour]</span> of the camels or cattle <span class="add">[of a stationary people]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bn_4_A2">
					<p>And <span class="ar long">أَبَنَّتِ السَّحَابَةُ</span> † <em>The cloud remained,</em> or <em>continued raining,</em> <span class="auth">(M, TA,)</span> <em>some days,</em> <span class="auth">(TA,)</span> <em>and kept its place.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبنّن</span></h3>
				<div class="sense" id="bn_5_A1">
					<p><span class="ar">تبنّن</span> <em>He acted,</em> or <em>proceeded, deliberately, not hastily.</em> <span class="auth">(T, TA.)</span> An Arab of the desert said to Shureyh, on his desiring to pronounce judgment against him hastily, <span class="ar">تَبَنَّنْ</span>, meaning <em>Act thou deliberately, not hastily.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bano">
				<h3 class="entry"><span class="ar">بَنْ</span></h3>
				<div class="sense" id="bano_A1">
					<p><span class="ar">بَنْ</span> <a href="#balo">is a dial. var. of <span class="ar">بَلْ</span></a>, <span class="auth">(M, Ḳ,)</span> and so is <span class="ar long">لَا بَنْ</span> of <span class="ar long">لَا بَلْ</span>; or, as some say, formed by substitution <span class="add">[of <span class="ar">ن</span> for <span class="ar">ل</span>; not peculiar to any dialect]</span>. <span class="auth">(M.)</span> One says, <span class="ar long">بَنْ وَٱللّٰهِ لَا آتِيكَ</span> <span class="add">[<em>Nay, by God, I will not come to thee</em>]</span>: Fr says that it is of the dial. of Benoo-Saạd and Kelb; and that he had heard the Báhilees say, <span class="ar long">لَا بَنْ</span>, meaning <span class="ar">بَلْ</span> <span class="add">[or <span class="ar long">لَا بَلْ</span>]</span>: but IJ says, I do not trace up <span class="ar">بَنْ</span> <span class="add">[to any authority]</span> as being an independent word of a particular dialect. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بن</span> - Entry: <span class="ar">بَنْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bano_B1">
					<p><span class="add">[<span class="ar">بْنُ</span> and <span class="ar">بْنِ</span> and <span class="ar">بْنَ</span>, for <span class="ar">ٱبْنُ</span>, &amp;c.: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunBN">
				<h3 class="entry"><span class="ar">بُنٌّ</span></h3>
				<div class="sense" id="bunBN_A1">
					<p><span class="ar">بُنٌّ</span> <span class="add">[<em>Coffee-berries,</em> whether <em>green</em> or <em>roasted, whole</em> or <em>reduced to powder by pounding or grinding;</em>]</span> expl. in the Ḳ as <span class="ar long">شَىْءٌ يُتَّخَذُ كَالمُرِّىِّ</span> <span class="add">[<em>a certain thing that is taken like the condiment termed</em> <span class="ar">مُرِّيّ</span>, which is used to give relish to food or to quicken the appetite]</span>; Ibn-Es-Sim'ánee says, <span class="ar long">هُوَشَىْءٌ فِى الكَوَامِيخِ</span> <span class="add">[app. meaning <em>it is a thing reckoned among what are termed</em> <span class="ar">كواميخ</span>, <a href="#kaAmaxN">pl. of <span class="ar">كَامَخٌ</span></a>, which signifies the same as <span class="ar">مُرِّىٌّ</span>, for it seems that <span class="ar">فى</span> is here used in the sense of <span class="ar">مِنْ</span>, or it may be a mistranscription for <span class="ar">مِنْ</span>]</span>; the physician Dáwood says, it is <em>the produce of certain trees in El-Yemen; the berries thereof are put into the earth in</em> <span class="ar">آذَار</span> <span class="add">[the Syrian month corresponding to March, O. Ṣ.]</span>, <em>and it increases, and is gathered in</em> <span class="ar">أَبِيب</span> <span class="add">[the Coptic month commencing on the 25th of June, O. Ṣ.; the 7th of July, N. Ṣ.]</span>; <em>it grows to the height of about three cubits, on a stem of the thickness of the thumb, and has a white flower, which is succeeded by a berry like the hazel-nut; sometimes it is cut like beans; and sometimes, when it is divested of its covering, it divides into two halves: it has been proved to be good for alleviating humidities, and cough, and phlegm, and defluxions, and for opening obstructions, and causing a flow of the urine: when roasted,</em> <span class="add">[<em>and pounded</em> or <em>ground,</em>]</span> <em>and well cooked,</em> <span class="add">[i. e. <em>boiled in water,</em>]</span> <em>it is now commonly known by the name of</em> <span class="ar">قَهْوَة</span>. <span class="auth">(TA.)</span> <span class="add">[Golius, I think, has misunderstood the explanation of this word in the Ḳ: after having given that explanation, and rendered it by “<span class="la">res quæ sumitur instar</span> <span class="ar">المرى</span> <em>Múrriji,</em>” he adds, “Pers. <span class="ar">ابكامه</span> <span class="la">Abcâma dictæ: hæc sorbitio est rei ex hordeo et frumento paratæ multa cura et arte, quam Malajesa et Halimæus describunt.</span>” He then mentions the signification of coffee-berries as a second and distinct meaning.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="binBN">
				<h3 class="entry"><span class="ar">بِنٌّ</span></h3>
				<div class="sense" id="binBN_A1">
					<p><em>A place having a fetid odour.</em> <span class="auth">(Fr, T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بن</span> - Entry: <span class="ar">بِنٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="binBN_B1">
					<p>It also signifies <span class="ar long">طِرْقٌ مِنَ الشَّحْمِ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">السِّمَنِ</span> <span class="auth">(Ḳ, TA: in the CK <span class="ar">السَّمْنِ</span>:)</span> <span class="add">[said in the TA to mean <span class="ar long">قُوَّةٌ مِنْهُمَا</span>, i. e. <em>Strength</em> arising <em>from fat</em> and <em>from fatness:</em> but I think that <span class="ar">وَالسِّمَنِ</span> has been added in the Ḳ in consequence of a misunderstanding, and that the meaning is <em>a layer of fat;</em> this meaning seeming to be indicated by the ex. here following, and corroborated by significations of several conjugates of <span class="ar">طِرْقٌ</span>, as <span class="ar">طَرِيقَةٌ</span> and <span class="ar">طَرَقٌ</span> and <span class="ar">طِرَاقٌ</span>, &amp;c.]</span> One says <span class="auth">(T, Ḳ)</span> of a beast (<span class="ar">دَابَّة</span>) when it has become fat, <span class="auth">(T,)</span> <span class="ar long">رَكِبَهَا بِنٌّ عَلَىبِنٍ</span> <span class="auth">(T, Ḳ *)</span> and <span class="ar long">طِرْقٌ عَلَى طِرْقٍ</span> <span class="auth">(T)</span> <span class="add">[clearly I think, meaning <em>Layer upon layer, of fat, has accumulated upon it.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banBapN">
				<h3 class="entry"><span class="ar">بَنَّةٌ</span></h3>
				<div class="sense" id="banBapN_A1">
					<p><span class="ar">بَنَّةٌ</span> <em>A sweet,</em> or <em>pleasant, odour;</em> <span class="auth">(Aṣ, AA, T, Ṣ, M, Ḳ;)</span> <em>such as that of the apple</em> <span class="auth">(T, M)</span> <em>and the like,</em> <span class="auth">(M,)</span> <em>or the quince:</em> <span class="auth">(T:)</span> Sb says that it is a name for <em>a sweet,</em> or <em>pleasant, odour, like</em> <span class="ar">خَمْطَةٌ</span>: <span class="auth">(M,* TA:)</span> and <em>an unpleasant odour;</em> <span class="auth">(Aṣ, T, Ṣ;)</span> <em>a fetid odour;</em> <span class="auth">(M, Ḳ;)</span> whence <span class="ar long">بَنَّةٌ الغَزْلِ</span> <span class="add">[<em>the odour of the yarn</em>]</span> occurring in a saying of ʼAlee, respecting a weaver; <span class="auth">(M;)</span> which shows that AʼObeyd erred in asserting it to have only the first of the foregoing significations; <span class="auth">(IB, TA;)</span> which Suh, in the R, assigns also to <span class="arrow"><span class="ar">بُنَانَةٌ↓</span></span>: <span class="auth">(TA:)</span> the <em>odour of sheep,</em> or <em>goats,</em> <span class="auth">(Ṣ, M,)</span> or <em>of camels</em> or <em>cattle;</em> <span class="auth">(Z, TA;)</span> and <em>of the dung of gazelles;</em> <span class="auth">(Ṣ, Ḳ;)</span> and <em>of the lodging-places of sheep or goats</em> and <em>of oxen or bulls or cows</em> and <em>of gazelles:</em> <span class="auth">(T, M:)</span> and sometimes the <em>lodgingplaces themselves, of sheep or goats:</em> <span class="auth">(M, TA:)</span> pl. <span class="auth">(in all the senses, M)</span> <span class="ar">بِنَانٌ</span>. <span class="auth">(T, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunBieBN">
				<h3 class="entry"><span class="ar">بُنِّىٌّ</span></h3>
				<div class="sense" id="bunBieBN_A1">
					<p><span class="ar">بُنِّىٌّ</span> <em>A seller of</em> <span class="ar">بُنّ</span> <span class="add">[or <em>coffee-berries</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بن</span> - Entry: <span class="ar">بُنِّىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bunBieBN_B1">
					<p>Also, <span class="add">[vulgarly pronounced <span class="ar">بِنِّى</span>,]</span> <em>A species of fish;</em> <span class="auth">(Ḳ;)</span> <span class="add">[the <em>cyprinus Bynni</em> of Forskål; described by him in his Descr. Anim. p. 71;]</span> it is <em>white,</em> and is <em>the best kind</em> <span class="add">[<em>of fish</em>]</span>, and <em>abundant in the Nile.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banaAnN">
				<h3 class="entry"><span class="ar">بَنَانٌ</span> / <span class="ar">بَنَانَةٌ</span></h3>
				<div class="sense" id="banaAnN_A1">
					<p><span class="ar">بَنَانٌ</span> The <em>fingers;</em> syn. <span class="ar">أَصَابِعُ</span>: <span class="auth">(M, Mṣb, Ḳ:)</span> but whether it means peculiarly the <span class="ar">اصابع</span> of the hand, or those of the foot also, <span class="add">[i. e. the <em>toes,</em>]</span> is disputed: <span class="auth">(TA:)</span> or the <em>ends,</em> or <em>extremities, thereof:</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> said to be so called because by their means are ordered those circumstances whereby man continues in existence; from <span class="ar long">أَبَنَّ بِالْمَكَانِ</span>: <span class="auth">(Mṣb:)</span> mentioned in the Ḳur viii. 12 because therewith one fights, and defends himself: <span class="auth">(Er-Rághib, TA:)</span> or it there signifies all the <em>limbs,</em> or <em>members, of the body:</em> <span class="auth">(Aboo-Is-ḥáḳ, M:)</span> or the <em>fingers,</em> or <em>toes, and any other parts of all the limbs,</em> or <em>members:</em> <span class="auth">(Zj, TA:)</span> or it means in the Ḳur the <span class="ar">شَوَى</span>; <span class="auth">(Lth, T, TA;)</span> so in lxxv. 4; <span class="auth">(M;)</span> i. e. the <em>arms</em> or <em>hands</em> and the <em>legs</em> or <em>feet:</em> <span class="auth">(Lth, T, TA:)</span> accord. to El-Fárisee the meaning of the words in the Ḳur lxxv. 4 is, we are able to make their extremities like those of the camel, so that they should not profit by them in handicraft: <span class="auth">(M, TA:)</span> the n. un. is with <span class="ar">ة</span>; <span class="auth">(Lth, T, Ṣ, M, Ḳ;)</span> meaning, accord. to Lth, <em>a single</em> <span class="ar">إِصْبَع</span> <span class="add">[i. e. <em>finger,</em> or <em>toe</em>]</span>; or, accord. to AHeyth, the <em>whole</em> <span class="ar">اصبع</span>; or, as some say, the <em>highest</em> <span class="ar">عُقْدَة</span> <span class="add">[or <em>joint</em>]</span> <em>of the</em> <span class="ar">اصبع</span>: <span class="auth">(T:)</span> the pl. of pauc. is <span class="ar">بَنَانَاتٌ</span>; but a pl. of mult. is sometimes used as one of pauc.; and hence the saying of the rájiz,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">خَمْسَ بَنَانٍ قَانِئِ الأَظْفَارِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Five fingers,</em> or <em>ends of fingers, intensely red</em> from the dye of hinnà <em>in the nails</em>]</span>, meaning <span class="ar long">خَمْسًا مِنَ البَنَانِ</span>: and one says, <span class="ar long">بَنَانٌ مُخَضَّبٌ</span> <span class="add">[<em>Fingers,</em> or <em>ends of fingers, dyed,</em> or <em>much dyed,</em> with hinnà]</span>; for every pl. <span class="add">[or rather coll. gen. n.]</span> between which and its sing., or n. un., there is no difference but <span class="ar">ة</span> <span class="add">[added in the latter]</span> may be treated as sing. and masc. <span class="auth">(Ṣ.)</span> Lth cites as an ex. of the n. un.,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَاهُمَّ أَكْرَمْتَ بَنِى كِنَانَه</span> *</div> 
						<div class="star">* <span class="ar long">لَيْسَ لِحَىٍّ فَوْقَهُمْ بَنَانَهْ</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>O God, Thou hast honoured the sons of Kináneh: there belongs not to any tribe</em>]</span> excel-lence of the measure of <em>a finger above them.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baniyinN">
				<h3 class="entry"><span class="ar">بَنِيِنٌ</span></h3>
				<div class="sense" id="baniyinN_A1">
					<p><span class="ar">بَنِيِنٌ</span> <em>Deliberate and intelligent:</em> <span class="auth">(AA, T, Ḳ:)</span> from <span class="ar long">بَنَّ بِالْمَكَانِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banaAnapN">
				<h3 class="entry"><span class="ar">بَنَانَةٌ</span></h3>
				<div class="sense" id="banaAnapN_A1">
					<p><span class="ar">بَنَانَةٌ</span> <a href="#banaAnN">n. un. of <span class="ar">بَنَانٌ</span></a>. <span class="auth">(Lth, T, Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بن</span> - Entry: <span class="ar">بَنَانَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="banaAnapN_B1">
					<p><a href="#bunaAnapN">See also what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunaAnapN">
				<h3 class="entry"><span class="ar">بُنَانَةٌ</span></h3>
				<div class="sense" id="bunaAnapN_A1">
					<p><span class="ar">بُنَانَةٌ</span>: <a href="#banBapN">see <span class="ar">بَنَّةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بن</span> - Entry: <span class="ar">بُنَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bunaAnapN_A2">
					<p>Also <em>A meadow,</em> or <em>verdant tract of land somewhat watery,</em> <span class="auth">(AA, T, M, Ḳ,)</span> <em>producing herbage,</em> <span class="auth">(M, Ḳ,)</span> <em>and adorned with flowers;</em> <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">بَنَانَةٌ↓</span></span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubinBN">
				<h3 class="entry"><span class="ar">مُبِنٌّ</span></h3>
				<div class="sense" id="mubinBN_A1">
					<p><span class="ar">مُبِنٌّ</span> <em>Remaining, continuing, staying, dwelling,</em> or <em>abiding,</em> in a place. <span class="auth">(T, TA.)</span> Applied to a mixture of urine and dung (<span class="ar">عَبَس</span>) upon the tail <span class="add">[of a camel, &amp;c.]</span>, it may mean <em>Cleaving,</em> and <em>sticking:</em> or it may be from <span class="ar">بَنَّةٌ</span> signifying “a fetid odour” <span class="add">[so as to mean <em>having a fetid odour</em>]</span>: thus, in this case, it may be either a part. n. or a possessive epithet. <span class="auth">(M, TA.)</span> It signifies also <em>Having the odour of the dung of gazelles;</em> applied to a covert, or hiding-place, of those animals, among trees. <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0258.pdf" target="pdf">
							<span>Lanes Lexicon Page 258</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
