<article class="root" id="Root_bsT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/101_bsr">بسر</a></span>
				<span class="ar">بسط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/103_bsq">بسق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsT_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسط</span></h3>
				<div class="sense" id="bsT_1_A1">
					<p><span class="ar">بَسَطَهُ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُطُ</span>}</span></add>, <span class="auth">(M, TA,)</span> inf. n. <span class="ar">بَسْطٌ</span>, <span class="auth">(Ṣ, M, Mṣb,)</span> <a href="#tabosyiTN">contr. of <span class="ar">تَبْسيِطٌ</span></a>; <span class="auth">(M, TA;)</span> as also↓<span class="ar">بسّطهُ</span>, <span class="auth">(M,* TA,)</span> inf. n. <span class="ar">تَبْسيِطٌ</span>. <span class="auth">(TA.)</span> <span class="add">[As such,]</span> <em>He spread it; spread it out,</em> or <em>forth; expanded it; extended it;</em> <span class="auth">(Ṣ, Mṣb, Ḳ, B;)</span> as also↓<span class="ar">بسّطهُ</span>: <span class="auth">(Ḳ:)</span> and <em>he made it wide,</em> or <em>ample:</em> these are the primary significations; and sometimes both of them may be conceived; and sometimes, one of them: and the verb is also used, metaphorically, as relating to anything which cannot be conceived as composed or constructed: <span class="auth">(B:)</span> and <span class="ar">بَصْطٌ</span> is the same as <span class="ar">بَسْطٌ</span>, <span class="auth">(Ṣ, and Ḳ in art. <span class="ar">بصط</span>,)</span> in all its meanings. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">بَسَطَ الثَّوْبَ</span> <span class="add">[<em>He spread, spread out, expanded,</em> or <em>unfolded, the garment,</em> or <em>piece of cloth</em>]</span>. <span class="auth">(Mṣb.)</span> And <span class="ar long">بَسَطَ رِجْلَهُ</span> ‡ <span class="add">[<em>He stretched forth,</em> or <em>extended, his leg</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَسَطَ ذِرَاعَيْهِ</span>, and↓<span class="ar">بَسَّطَهُمَا</span>, † <em>He spread his fore arms upon the ground;</em> the doing of which <span class="add">[in prostrating oneself]</span> in prayer is forbidden. <span class="auth">(TA.)</span> And <span class="ar long">بَسَطَ يَدَهُ</span> <span class="auth">(M, Mṣb, Ḳ)</span> ‡ <em>He stretched forth,</em> or <em>extended, his arm,</em> or <em>hand;</em> <span class="auth">(M, Ḳ;)</span> as in the saying <span class="ar long">بَسَطَ إِلِىَّ يَدَهُ بِمَا أُحِبُّ وَأَكْرَهُ</span> ‡ <span class="add">[<em>He stretched forth,</em> or <em>extended, towards me his arm,</em> or <em>hand, with,</em> i. e. <em>to do to me, what I liked and disliked</em>]</span>: <span class="auth">(M, TA:*)</span> or <em>he stretched forth his hand opened.</em> <span class="auth">(Mṣb.)</span> It is said in the Ḳur <span class="add">[v. 31]</span>, <span class="ar long">لَئِنْ بَسَطْتَ إِلَىَّ يَدَكَ لِتَقْتُلَنِى</span> † <span class="add">[<em>Assuredly if thou stretch forth towards me thy hand to slay me</em>]</span>. <span class="auth">(M, TA.)</span> <span class="ar long">بَسْطُ اليَدِ</span> and <span class="ar">الكَفِّ</span> is sometimes used to denote assaulting and smiting: <span class="add">[as in the last of the exs. given above; and]</span> as in the words of the Ḳur <span class="add">[lx. 2]</span>, <span class="ar long">وَيَبُسُطُوا إِلَيْكُمْ أَيْدِيَهُمْ وَأَلْسِنَتَهُمْ بِالسُّوْءِ</span> ‡ <span class="add">[<em>And they will stretch forth towards you their hands and their tongues with evil</em>]</span>; <span class="auth">(TA;)</span> i. e., by slaying, <span class="auth">(Bḍ, Jel,)</span> and smiting, <span class="auth">(Jel,)</span> and reviling. <span class="auth">(Bḍ, Jel.)</span> And sometimes to denote giving liberally: <span class="auth">(TA:)</span> <span class="add">[as in]</span> <span class="ar long">بَسَطَ يَدَهُ فِى الإَنْفَاقِ</span> ‡ <em>He</em> <span class="add">[<em>stretched forth his hand, opened,</em> or]</span> <em>was liberal</em> or <em>bountiful</em> or <em>munificent</em> <span class="add">[<em>in expenditure</em>]</span>: <span class="auth">(Mṣb:)</span> <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span>, below</a>. <span class="auth">(TA.)</span> And sometimes to denote taking, or taking possession, or seizing: as in the saying, <span class="auth">(TA,)</span> <span class="ar long">بُسِطَتْ يَدُهُ عَلَيْهِ</span> ‡ <span class="add">[<em>His hand was stretched forth against him</em>]</span>; i. e. <em>he was made to have dominion over him by absolute force and power.</em> <span class="auth">(Ḳ, TA.)</span> And sometimes to denote seeking, or demanding: <span class="add">[as in <span class="ar long">بَسَطَ كَفَّيْهِ فِى الدُّعَآءِ</span> ‡ <em>He expanded his two hands in supplication;</em> a common action, in which the two hands are placed together like an open book upon a desk before the face, in supplicating God:]</span> <a href="#baAsiTN">see <span class="ar">بَاسِطٌ</span>, below</a>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsT_1_A2">
					<p><span class="add">[And hence,]</span> <span class="ar long">بَسَطْتُ لَهُ أَمْرِى</span> ‡ <em>I displayed,</em> or <em>laid open, to him my state,</em> or <em>case,</em> or <em>affair;</em> syn. <span class="ar long">فَرَشْتُهُ إِيَّاهُ</span>: <span class="auth">(A in art. <span class="ar">فرش</span>:)</span> and <span class="ar">أَمْرَهُ</span> <span class="add">[<em>his state,</em>, &amp;c.]</span>. <span class="auth">(TA in that art.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsT_1_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar long">اَللّٰهُ يَبْسُطُ الأَرْوَاحَ فِى الأَجْسَادِ عِنْدَ الحَيَاةِ</span> † <span class="add">[<em>God diffuses the souls in the bodies at the time of</em> their <em>being animated</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bsT_1_A4">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بَسَطَ ٱللّٰهُ الرِّزْقَ</span> † <em>God multiplied,</em> or <em>made abundant, and amplified, enlarged,</em> or <em>made ample</em> or <em>plentiful, the means of subsistence.</em> <span class="auth">(Mṣb, Ḳ.*)</span> It is said in the Ḳur <span class="add">[ii. 246]</span>, <span class="ar long">وَٱللّٰهُ يَبِضُ وَيَبْسُطُ</span> <span class="auth">(Mṣb and TA in art. <span class="ar">قبض</span>, q. v.)</span> And you say, <span class="ar long">بَسَطَ عَلَيْهِمُ العَدْلَ</span> ‡ <span class="add">[<em>He largely extended to them equity,</em> or <em>justice</em>]</span>; as also↓<span class="ar">بسّطهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bsT_1_A5">
					<p><span class="add">[Hence also,]</span> <span class="ar long">فُلَانٌ يَبْسُطُ عَبِيدَهُ ثُمَّ يَقْبِضُهُمْ</span> ‡ <span class="add">[<em>Such a one enlarges the liberty of his slaves; then abridges their liberty</em>]</span>. <span class="auth">(A in art. <span class="ar">قبض</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bsT_1_A6">
					<p><span class="add">[Hence also, <span class="ar long">بَسَطَ وَجْهَهُ</span> † <em>It unwrinkled, as though it dilated, his countenance:</em> <a href="#bsT_7">see 7</a>. And <span class="ar long">بَسَطَ قَلْبَهُ</span> † <em>It dilated his heart:</em> <a href="#qbD_1">see remarks on <span class="ar">قَبْضٌ</span> and <span class="ar">بَسْطٌ</span>, as used by certain of the Soofees, near the end of 1</a> <a href="#Rootr_qbD">in art. <span class="ar">قبض</span></a>. And]</span> <span class="ar">بَسَطَهُ</span>, alone, <span class="add">[signifies <em>the same;</em> or]</span> ‡ <em>it rejoiced him; rendered him joyous,</em> or <em>cheerful:</em> <span class="auth">(M, Ḳ, TA:)</span> because, when a man is rejoiced, his countenance becomes unwrinkled (<span class="ar">يَنْبَسِطُ</span>), and he becomes changed <span class="add">[and cheerful]</span> in <span class="add">[its]</span> complexion: it is wrongly said, by MF, to be not tropical: that it is tropical is asserted by Z, in the A: MF also says that it is not post-classical; and in this he is right; for it occurs in a saying of Moḥammad: thus in a trad. respecting Fátimeh, <span class="ar long">يَبْسُطُنِى مَا يَبْسُطُهَا</span> <em>What rejoices her rejoices me:</em> <span class="auth">(TA:)</span> <span class="add">[<a href="#qbD_1">see also <span class="ar">قَبَضَهُ</span></a>, where this saying is cited according to another relation:]</span> <span class="arrow">↓<span class="ar">أَبْسَطَنِى</span></span> <span class="add">[as signifying ‡ <em>it rejoiced me</em>]</span> is a mistake of the vulgar <span class="add">[obtaining in the present day]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bsT_1_A7">
					<p><span class="add">[Hence also,]</span> <span class="ar long">الخَيْرُ يَقْبِضُهُ وَالشَّرُّ يَبْسُطُهُ</span> ‡ <span class="add">[<em>Wealth makes him closefisted, tenacious,</em> or <em>niggardly; and poverty makes him open-handed, liberal,</em> or <em>generous</em>]</span>. <span class="auth">(A in art. <span class="ar">قبض</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bsT_1_A8">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بُسَطَ مِنْ فُلَانٍ</span> ‡ <em>He rendered such a one free from shyness,</em> or <em>aversion:</em> <span class="auth">(Ṣ, O, Ḳ, TA:)</span> <em>he emboldened him; incited him to</em> <span class="add">[<em>that kind of presumptuous boldness which is termed</em>]</span> <span class="ar">دَالَّة</span>. <span class="auth">(Ḥar p. 155.)</span> <span class="add">[In the CK, <span class="ar long">بَسَطَ فُلاناً من فُلانٍ</span> is erroneously put for <span class="ar long">بَسَطَ فُلَانٌ مِنْ فُلَانص</span>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bsT_1_A9">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بَسَطَ ٱللّٰهُ فُلَانًا عَلَىَّ</span> ‡ <em>God made,</em> or <em>judged, such a one to excel me.</em> <span class="auth">(Z, Ṣgh, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bsT_1_A10">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بَسَطَ المَكَانُ القَوْمَ</span> ‡ <em>The place was sufficiently wide,</em> or <em>ample, for the people,</em> or <em>company of men.</em> <span class="auth">(Ḳ, TA.)</span> And <span class="ar long">هٰذَا فِرَاشٌ يَبْسُطُكَ</span> ‡ <em>This is a bed ample,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>sufficiently wide for thee.</em> <span class="auth">(A.)</span> And <span class="ar long">فَرَشَ لِى فِرَاشاً لَا يَبْسُطُنِى</span> <em>He spread for me a bed</em> <span class="add">[<em>not wide enough for me,</em> or]</span> <em>that was</em> <span class="add">[<em>too</em>]</span> <em>narrow</em> <span class="add">[<em>for me</em>]</span>, <span class="auth">(ISk, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="bsT_1_A11">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بَسَطَ العُدْرَ</span>, <span class="auth">(Ḳ,)</span> aor. as above, <span class="auth">(TA,)</span> and so the inf. n., <span class="auth">(Ṣ, TA,)</span> ‡ <em>He accepted,</em> or <em>admitted, the excuse.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="bsT_1_A12">
					<p>All these significations of the verb are ramifications of that first mentioned above. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsT_1_B1">
					<p><span class="ar">بَسَطَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُطُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَسَاطَةٌ</span>, <span class="auth">(M,)</span> † <em>He was,</em> or <em>became, free,</em> or <em>unconstrained,</em> (<span class="ar">مُنْبَسِطٌ</span>,) <em>with his tongue.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsT_2">
				<h3 class="entry">2. ⇒ <span class="ar">بسّط</span></h3>
				<div class="sense" id="bsT_2_A1">
					<p><a href="#bsT_1">see 1</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsT_3">
				<h3 class="entry">3. ⇒ <span class="ar">باسط</span></h3>
				<div class="sense" id="bsT_3_A1">
					<p><span class="ar">باسطهُ</span>, inf. n. <span class="ar">مُبَاسَطَةٌ</span> and <span class="ar">بِسَاطٌ</span> ‡ <span class="add">[<em>He conversed,</em> or <em>acted, with him without shyness,</em> or <em>aversion; boldly; in a free and easy manner;</em> or <em>cheerfully</em>]</span>: <span class="auth">(TA:)</span> <em>he met him laughingly,</em> or <em>smilingly, so as to show his teeth.</em> <span class="auth">(So accord. to an expl. of the latter of the two inf. ns. in the TA.)</span> <span class="add">[<a href="#kXr_3">See <span class="ar">كَاشَرَهُ</span></a>.]</span> You say also, <span class="ar long">بَيْنَهُمَا مُبَاسَطَةٌ</span> ‡ <span class="add">[<em>Between them two is conversation,</em> or <em>behaviour, free from shyness,</em> or <em>aversion; bold; free and easy;</em> or <em>cheerful</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsT_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابسط</span></h3>
				<div class="sense" id="bsT_4_A1">
					<p><a href="#bsT_1">see 1</a>, latter half.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsT_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبسّط</span></h3>
				<div class="sense" id="bsT_5_A1">
					<p><a href="#bsT_7">see 7</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsT_5_A2">
					<p><span class="ar long">تبسّط فِى البِلَادِ</span> † <em>He journeyed far and wide in the countries.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsT_5_A3">
					<p><span class="ar long">خَرَجَ يَتَبَسَّطُ</span> † <em>He went forth betaking himself to the gardens and green fields:</em> from <span class="ar">بَسَاطٌ</span> signifying “land having sweet-smelling plants.” <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsT_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبسط</span></h3>
				<div class="sense" id="bsT_7_A1">
					<p><span class="ar">انبسط</span> <a href="#bsT_1">quasi-pass. of <span class="ar">بَسَطَهُ</span></a>; <a href="#bsT_5">as also<span class="arrow"><span class="ar">تبسّط↓</span></span></a> <a href="#bsT_2">is of <span class="ar">بَسَّطَهُ</span></a>; both signifying <em>It became spread</em> or <em>spread out</em> or <em>forth,</em> or <em>it spread</em> or <em>spread out</em> or <em>forth; it became expanded,</em> or <em>it expanded,</em> or <em>it expanded itself; it became extended,</em> or <em>it extended,</em> or <em>it extended itself:</em> <span class="add">[&amp;c.]</span>. <span class="auth">(M, Ḳ, TA.)</span> You say, <span class="ar long">انبسط الشَّيْءُ عَلَى الأَرْضِ</span> <span class="add">[<em>The thing became spread</em> or <em>spread out, &amp;c., upon the ground</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">انبسط النَّهَارُ</span> <em>The day became advanced, the sun being high: it became long:</em> <span class="auth">(M, Ḳ, TA:)</span> and in like manner one uses the verb in relation to other things. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsT_7_A2">
					<p><span class="add">[And hence, † <em>He expatiated.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsT_7_A3">
					<p><span class="add">[And]</span> <span class="ar long">انبسط وَجْهُهُ</span> † <span class="add">[<em>His countenance became unwrinkled, as though dilated;</em> i. e. <em>it became open,</em> or <em>cheerful;</em> and so <span class="ar">انبسط</span> alone; or <em>he became open,</em> or <em>cheerful, in countenance,</em> as is said in the KL.]</span>. <span class="auth">(TA.)</span> <span class="add">[And <span class="ar">انبسط</span>, alone, ‡ <em>He became dilated in heart;</em> or <em>he rejoiced;</em> or <em>became joyous,</em> or <em>cheerful:</em> <a href="#bsT_1">see <span class="ar">بَسَطَهُ</span></a>.]</span></p>
				</div>
				<span class="pb" id="Page_0204"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bsT_7_A4">
					<p><span class="add">[Hence also,]</span> <span class="ar">انبسط</span> ‡ <em>He left shyness,</em> or <em>aversion; he became free therefrom:</em> <span class="auth">(Ṣ, TA:)</span> <em>he was,</em> or <em>became, bold, forward, presumptuous,</em> or <em>arrogant:</em> <span class="auth">(KL, PṢ:)</span> <em>he became emboldened,</em> and <em>incited to</em> <span class="add">[<em>that kind of presumptuous boldness which is termed</em>]</span> <span class="ar">دَالَّة</span>. <span class="auth">(Ḥar p. 155.)</span> And <span class="ar long">انبسط إِلَيْهِ</span> ‡ <span class="add">[<em>He was open,</em> or <em>unreserved, to him in conversation: and he acted towards him,</em> or <em>behaved to him, without shyness</em> or <em>aversion;</em> or <em>with boldness, forwardness, presumptuousness,</em> or <em>arrogance:</em> and <em>he applied himself to it</em> <span class="auth">(namely, an affair,)</span> <em>with boldness, forwardness, presumptuousness,</em> or <em>arrogance.</em>]</span> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basoTN">
				<h3 class="entry"><span class="ar">بَسْطٌ</span></h3>
				<div class="sense" id="basoTN_A1">
					<p><span class="ar">بَسْطٌ</span>, as signifying <em>A certain intoxicating thing,</em> <span class="add">[<em>a preparation of hemp,</em>]</span> is post-classical. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busoTN">
				<h3 class="entry"><span class="ar">بُسْطٌ</span></h3>
				<div class="sense" id="busoTN_A1">
					<p><span class="ar">بُسْطٌ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a>, in seven places.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bisoTN">
				<h3 class="entry"><span class="ar">بِسْطٌ</span></h3>
				<div class="sense" id="bisoTN_A1">
					<p><span class="ar">بِسْطٌ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a>, in seven places.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busuTN">
				<h3 class="entry"><span class="ar">بُسُطٌ</span></h3>
				<div class="sense" id="busuTN_A1">
					<p><span class="ar">بُسُطٌ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a>, in seven places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basoTapN">
				<h3 class="entry"><span class="ar">بَسْطَةٌ</span></h3>
				<div class="sense" id="basoTapN_A1">
					<p><span class="ar">بَسْطَةٌ</span> <em>Width,</em> or <em>ampleness;</em> syn. <span class="ar">سَعَةٌ</span>: <span class="auth">(Ṣ, Ṣgh, Mṣb:)</span> and <em>length,</em> or <em>height:</em> <span class="auth">(Ṣgh:)</span> pl. <span class="ar">بِسَاطٌ</span>: <span class="auth">(Ṣgh:)</span> and <em>increase:</em> or <em>redundance,</em> or <em>excess:</em> <span class="auth">(TA:)</span> and, <span class="auth">(M, Ḳ,)</span> as also↓<span class="ar">بُسْطَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>excel-lence;</em> <span class="auth">(M, Ḳ;)</span> in science and in body: <span class="auth">(M:)</span> or in science, <em>expatiation,</em> or <em>dilatation:</em> <span class="auth">(Ḳ:)</span> or <em>profit to oneself and others:</em> <span class="auth">(TA:)</span> and <em>in body, height,</em> or <em>tallness;</em> and <em>perfection,</em> or <em>completeness.</em> <span class="auth">(Ḳ.)</span> It is said in the Ḳur <span class="add">[ii. 24]</span>, <span class="ar long">وَزَادَهُ بَسَطَةً فِى العِلْمِ الجِسْمِ</span> <span class="add">[<em>And hath increased him in excellence, &amp;c., in respect of science,</em> or <em>knowledge, and body</em>]</span>: <span class="auth">(M,TA:)</span> Zeyd Ibn-ʼAlee here read↓<span class="ar">بُسْطَةً</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسْطَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="basoTapN_A2">
					<p><span class="add">[<em>An arm's length.</em>]</span> <a href="#baAsiTN">See <span class="ar">بَاسِطٌ</span></a></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسْطَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="basoTapN_A3">
					<p><span class="ar long">اِمْرَأَةٌ بَسْطَةٌ</span>. <em>A woman beautiful and sleek in body:</em> and in like manner, <span class="ar">ظَبْيَةٌ</span> <em>a gazelle</em> that is so. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busoTapN">
				<h3 class="entry"><span class="ar">بُسْطَةٌ</span></h3>
				<div class="sense" id="busoTapN_A1">
					<p><span class="ar">بُسْطَةٌ</span>: <a href="#basoTapN">see <span class="ar">بَسْطَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basoTaMCu">
				<h3 class="entry"><span class="ar">بَسْطَآءُ</span></h3>
				<div class="sense" id="basoTaMCu_A1">
					<p><span class="ar long">أُذُنٌ بَسْطَآءُ</span> ‡ <em>A wide and large ear.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busoTieBN">
				<h3 class="entry"><span class="ar">بُسْطِىٌّ</span></h3>
				<div class="sense" id="busoTieBN_A1">
					<p><span class="ar">بُسْطِىٌّ</span> <em>A seller of</em> <span class="ar">بُسْط</span> <span class="add">[or <em>carpets,</em>, &amp;c.]</span>: pl. <span class="ar">بُسْطِيُّونَ</span>. <span class="auth">(TA, but only the pl. is there mentioned and explained.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="basoTaAnu">
				<h3 class="entry"><span class="ar">بَسْطَانُ</span></h3>
				<div class="sense" id="basoTaAnu_A1">
					<p><span class="ar">بَسْطَانُ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busoTaAnN">
				<h3 class="entry"><span class="ar">بُسْطَانٌ</span></h3>
				<div class="sense" id="busoTaAnN_A1">
					<p><span class="ar">بُسْطَانٌ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="basaATN">
				<h3 class="entry"><span class="ar">بَسَاطٌ</span></h3>
				<div class="sense" id="basaATN_A1">
					<p><span class="ar">بَسَاطٌ</span> Land (<span class="ar">أَرْض</span>) <em>expanded and even;</em> as also<span class="arrow"><span class="ar">بَسِيطَةٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> and <em>wide,</em> or <em>spacious;</em> <span class="auth">(AO, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بِسَاطٌ↓</span></span>, <span class="auth">(Fr, Ḳ,)</span> in his explanation of which Fr adds, <em>in which nothing is obtained;</em> <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بَسِيطٌ↓</span></span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">بَسِيطَةٌ↓</span></span>: <span class="auth">(AO, Ḳ:)</span> and in like manner, a place; <span class="auth">(Ṣ, TA;)</span> as also<span class="arrow"><span class="ar">بِسِاطٌ↓</span></span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بَسِيطٌ↓</span></span>: <span class="auth">(Ṣ, TA;)</span> and <em>land in which are sweet-smelling plants:</em> <span class="auth">(TA:)</span> or↓<span class="ar">بَسِيطةٌ</span> is a subst., <span class="auth">(IDrd, M,)</span> as some say, <span class="auth">(M,)</span> and signifies the <em>earth.</em> <span class="auth">(IDrd, M, Mṣb, Ḳ.)</span> You say, <span class="ar long">نَحْنُ فِى بِسَاطٍ↓ وَسَعَة</span> ‡ <span class="add">[<em>We are in an ample and a plentiful state</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَيْنَنَا وَبَيْنَ المَآءِ مِيلٌ بساطٌ</span> <span class="add">[the last word thus, without any vowel-sign to the <span class="ar">ب</span>]</span> † <em>Between us and the water is a long mile.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#baAsiTN">See also <span class="ar">بَاسِطٌ</span></a>.]</span> And <span class="ar long">مَا عَلَى البَسِيطَةِ↓ مِثْلُ فُلَانٍ</span> <em>There is not upon the earth the like of such a one.</em> <span class="auth">(TA.)</span> And↓<span class="ar long">ذَهَبَ فِى بُسَيْطَةَ</span>, a dim., imperfectly decl., <em>He</em> <span class="auth">(a man, TA)</span> <em>went away in the earth,</em> or <em>land.</em> <span class="auth">(A, O, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="basaATN_A2">
					<p>Also <em>A great cooking-pot.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bisaATN">
				<h3 class="entry"><span class="ar">بِسَاطٌ</span></h3>
				<div class="sense" id="bisaATN_A1">
					<p><span class="ar">بِسَاطٌ</span> <em>A thing that is spread</em> or <em>spread out</em> or <em>forth;</em> <span class="auth">(Ṣ, M, Ḳ, B;)</span> <em>whatever it be;</em> a subst. applied thereto: <span class="auth">(B:)</span> <span class="add">[and particularly <em>a carpet;</em> which is meant by its being said to be]</span> <em>a certain thing well known;</em> the word being of the measure <span class="ar">فِعَالٌ</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>, like <span class="ar">كِتَابٌ</span> in the sense of <span class="ar">مَكْتُوبٌ</span>, and <span class="ar">فِرَاشٌ</span> in the sense of <span class="ar">مَفْرُوشٌ</span>, &amp;c.: <span class="auth">(Mṣb:)</span> pl. <span class="add">[of mult.]</span> <span class="ar">بُسُطٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">بُسْطٌ</span> and <span class="add">[of pauc.]</span> <span class="ar">أَبْسطَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بِسَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bisaATN_A2">
					<p><a href="#basiyTN">See also <span class="ar">بَسِيطٌ</span></a>; near the middle of the paragraph.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بِسَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bisaATN_A3">
					<p><span class="ar long">اِنْبَرَى لِطَىِّ بِسَاطِهِ</span>. is a phrase meaning † <em>He hastened to cut short his speech.</em> <span class="auth">(Ḥar p. 280.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بِسَاطٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bisaATN_B1">
					<p>Also The <em>leaves of the tree called</em> <span class="ar">سَمُر</span> <em>that fall upon a garment,</em> or <em>piece of cloth, spread for them, the tree being beaten.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بِسَاطٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bisaATN_C1">
					<p><a href="#basaATN">See also <span class="ar">بَسَاطٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basiyTN">
				<h3 class="entry"><span class="ar">بَسِيطٌ</span> / <span class="ar">بَسِيطَةٌ</span></h3>
				<div class="sense" id="basiyTN_A1">
					<p><span class="ar">بَسِيطَ</span> and <span class="ar">بَسِيطَةٌ</span>: <a href="#basaATN">see <span class="ar">بَسَاطٌ</span></a>, in six places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="basiyTN_A2">
					<p><span class="ar long">وَقَعَ الغَيْثُ بَسِيطًا مُتَدَارِكًا</span> <em>The rain fell spreading widely upon the earth, continuously,</em> or <em>consecutively.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="basiyTN_A3">
					<p><span class="ar long">فُلَانٌ بَسِيطُ الجِسْمِ</span> † <span class="add">[<em>Such a one is tall of body</em>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="basiyTN_A4">
					<p><span class="ar long">بَسِيطُ الوَجْهِ</span> ‡ A man <span class="auth">(M)</span> <em>having the countenance</em> <span class="add">[<em>unwrinkled,</em> or]</span> <em>bright with joy:</em> <span class="auth">(M, Ḳ, TA:)</span> pl. <span class="ar">بُسُطٌ</span> <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="basiyTN_A5">
					<p><span class="ar long">بَسِيطُ اليَدَيْنِ</span> ‡ A man <em>large,</em> or <em>extensive, in beneficence;</em> <span class="auth">(M, TA;)</span> <em>liberal, bountiful:</em> <span class="auth">(Ḳ, TA:)</span> pl. <span class="ar">بُسُطٌ</span>: <span class="auth">(M, Ḳ:)</span> <span class="add">[and so]</span> <span class="ar long">بَسِيطُ البَاعِ</span> <span class="auth">(Ṣ,)</span> <span class="add">[and]</span><span class="arrow"><span class="ar long">مُنْبَسِطُ↓ البَاعِ</span></span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">يَدُهُ بِسْطٌ↓</span></span> <span class="auth">(Ṣ, Ḳ,)</span> like <span class="ar">طِحْنٌ</span> in the sense of <span class="ar">مَطْحُونٌ</span>, and <span class="ar">قِطْفٌ</span> in the sense of <span class="ar">مَقْطُوفٌ</span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بُسُطٌ↓</span></span> <span class="auth">(Z, Ḳ,)</span> like <span class="ar">أُنُفٌ</span> and <span class="ar">سُجُحٌ</span>, <span class="auth">(Z,)</span> and <span class="auth">(Z, Ḳ)</span> by contraction, <span class="auth">(Z,)</span>↓<span class="ar">بُسْطٌ</span>, <span class="auth">(Z, Ḳ,)</span> and↓<span class="ar">مَبْسُوطَةٌ</span>, <span class="auth">(TA,)</span> ‡ <em>His hand is liberal;</em> syn. <span class="ar">مُطْلَقَةٌ</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> and <span class="ar">طَلْقٌ</span>; <span class="auth">(TA;)</span> or <em>he is large in expenditure.</em> <span class="auth">(TA.)</span> It is said in the Ḳur <span class="add">[v. 69]</span>, <span class="ar long">بَلْ يَدَاهُ مَبْسُوطَتَانِ↓</span>; <span class="auth">(TA;)</span> and accord. to one reading,↓<span class="ar">بِسْطَانِ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and accord. to another, with damm, <span class="add">[as though it were <span class="arrow"><span class="ar">بُسْطَانِ↓</span></span>,]</span> <span class="auth">(Z, Ḳ, TA,)</span> <span class="add">[but it is said that]</span> in this case it is used as an inf. n., <span class="add">[and therefore↓<span class="ar">بُسْطَانٌ</span>, for an inf. n. is applied as an epithet to a dual and a pl. subst. without alteration,]</span> like <span class="ar">غُفْرانٌ</span> and <span class="ar">رُضْوَانٌ</span>; or, accord. to some, it is most probably <span class="add">[↓<span class="ar">بَسْطَانُ</span>,]</span> like <span class="ar">رَحْمَانُ</span>; and Talhah Ibn-Musarrif read↓<span class="ar">بِسَطَانِ</span>: <span class="auth">(TA:)</span> the meaning is, ‡ <em>Nay, his hands are liberal,</em> or <em>bountiful;</em> the phrase being a simile; for in this case there is no hand, nor any stretching forth. <span class="auth">(TA.)</span> And it is said in a trad., <span class="ar long">يَدَا ٱللّٰهِ بُسْطَانِ↓ لِمُسِىْءِ النَّهَارِ حَتَّى يَتُوبَ بِاللَّيْلِ وَلِمُسِىْءِ اللَّيْلِ حَتَّى يَتُوبَ بِالنَّهَارِ</span>, <span class="auth">(Ḳ,* TA,)</span> or, accord. to one relation, <span class="arrow"><span class="ar">بِسْطَانِ↓</span></span>, <span class="auth">(TA,)</span> meaning ‡ <em>God is liberal</em> in forgiveness <em>to the evil-doer of the day-time until he repent</em> <span class="add">[<em>in the night, and to the evil-doer of the night-time until he repent in the day</em>]</span>: for a king is said to be <span class="ar long">مَبْسُوطُ↓ اليَدِ</span> when he is ‡ <em>liberal in his gifts</em> by command and by sign, although he gives nothing thereof with his hand, nor stretches it forth with them at all. <span class="auth">(Ṣgh. TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="basiyTN_A6">
					<p><span class="ar">بَسِيطٌ</span> also signifies<span class="arrow"><span class="ar long">مُنْبَسِطُ↓ اللّسَانِ</span></span>, <span class="auth">(Lth,)</span> or <span class="ar long">مُنْبَسِطٌ بِلِسَانِهِ</span>, <span class="auth">(M, Ḳ,)</span> † <span class="add">[<em>Free,</em> or <em>unconstrained, in tongue, or with his tongue</em>,]</span> applied to a man: <span class="auth">(M:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَسِيطَةٌ</span>}</span></add>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="basiyTN_A7">
					<p><span class="ar">البَسِيطُ</span> is also the name of <em>A certain kind of metre of verse;</em> <span class="auth">(Ṣ, M,* Ḳ;)</span> namely, <em>the third; the measure of which consists of</em> <span class="ar long">مُسْتَفْعِلُنْ فَاعِلُنْ</span> <em>eight</em> <span class="add">[a mistake for <em>four</em>]</span> <em>times:</em> <span class="auth">(Ḳ:)</span> so called because of the extension of its <span class="ar">أَسْبَاب</span>, commencing with a <span class="ar">سَبَب</span> immediately followed by another <span class="ar">سَبَب</span>, as is said by Aboo-Is-ḥáḳ. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="basiyTN_A8">
					<p><span class="add">[<span class="ar">بَسِيطٌ</span> is also used in philosophy as signifying † <em>Simple; uncompounded</em>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basiyTapN">
				<h3 class="entry"><span class="ar">بَسِيطَةٌ</span></h3>
				<div class="sense" id="basiyTapN_A1">
					<p><span class="ar">بَسِيطَةٌ</span>, as an epithet; and as a subst.: <a href="#basaATN">see <span class="ar">بَسَاطٌ</span></a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَسِيطَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="basiyTapN_A2">
					<p><span class="add">[In philosophy, † <em>A simple element:</em> pl. <span class="ar">بَسَائِطُ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busayoTapa">
				<h3 class="entry"><span class="ar">بُسَيْطَةَ</span></h3>
				<div class="sense" id="busayoTapa_A1">
					<p><span class="ar long">ذَهَبَ فِى بُسَيْطَةَ</span>: <a href="#basaATN">see <span class="ar">بَسَاطٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAsiTN">
				<h3 class="entry"><span class="ar">بَاسِطٌ</span></h3>
				<div class="sense" id="baAsiTN_A1">
					<p><span class="ar">بَاسِطٌ</span> act. part. n. of <span class="ar">بَسَطَ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَاسِطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAsiTN_A2">
					<p>It is said in the Ḳur <span class="add">[vi. 93]</span>, <span class="ar long">وَالمَلَائِكَةُ بَاسِطُوا أَيْدِيهِمْ</span>, meaning ‡ <em>The angels being made to have dominion</em> over them <em>by absolute force and power</em> <span class="auth">(Ḳ,* TA.)</span> And again, in the Ḳur <span class="add">[xiii. 15]</span>, <span class="ar long">كَبَاسِطِ كَفَّيْهِ إِلَى المَآءِ لِيَبْلُغَ</span> ‡ <em>Like the supplicator of water, making a sign to it</em> <span class="add">[<em>with his two hands</em>]</span>, <em>in order that it may</em> <span class="add">[<em>reach his mouth</em>, and so]</span> answer his prayer; <span class="auth">(Ḳ,* TA;)</span> or, but it will not answer his prayer. <span class="auth">(O, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَاسِطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAsiTN_A3">
					<p><span class="ar">البَاسِطُ</span> † <em>God, who amplifies, or enlarges, or makes ample or plentiful, the means of subsistence, to whomsoever He will,</em> <span class="auth">(Ḳ, TA,)</span> by his liberality and his mercy: <span class="auth">(TA:)</span> <em>or who diffuses</em> (<span class="ar">يَبْسُطُ</span>) <em>the souls in the bodies at the time of</em> <span class="add">[<em>their</em>]</span> <em>being animated.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَاسِطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAsiTN_A4">
					<p><span class="ar long">مَآءٌ بَاسِطٌ</span> ‡ <em>Water that is distant from the herbage,</em> or <em>pasturage,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>but less so than what is termed</em> <span class="ar">مُطْلِبٌ</span>. <span class="auth">(M, TA.)</span> And <span class="ar long">خَمْسٌ بَاسِطٌ</span> † <em>A difficult</em> <span class="add">[<em>journey of the kind termed</em>]</span> <span class="ar">خِمْسَ</span> <span class="add">[<em>i. e. of five days, whereof the second and third and fourth are without water</em>]</span>; syn. <span class="ar">بَائِصٌ</span>. <span class="auth">(Ṣgh, Ḳ.)</span> And <span class="ar long">عُقْبَةٌ بَاسِطَةٌ</span> <span class="auth">(ISK, Ṣ, M, Ḳ <span class="add">[in the CK, erroneously, <span class="ar">عَقَبَةٌ</span>]</span>)</span> † <span class="add">[<em>A stage of a journey, or march or journey from one halting-place to another,</em>]</span> <em>that is far, or distant,</em> <span class="auth">(ISk, Ṣ,)</span> or <em>long:</em> <span class="auth">(TA:)</span> <em>or in which are two nights to the water.</em> <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">سِرْنَا عُقْبَةً بَاسِطَةً</span> † <span class="add">[<em>We journeyed a stage,</em>, &amp;c.,]</span> <em>that was far, or distant, or long</em>. <span class="auth">(ISk, Ṣ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسط</span> - Entry: <span class="ar">بَاسِطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAsiTN_A5">
					<p><span class="ar long">رَكِيَّةٌ قَامَةٌ بَاسِطَةٌ</span>, <span class="add">[in the CK,]</span> and <span class="ar long">قامَةُ باسِطَةٌ</span>, as a prefixed n. with its complement imperfectly decl., as though they made it determinate, <em>i. q.</em>↓<span class="ar long">قَامَةٌ وَبَسْطَةٌ</span> <span class="add">[<em>A well measuring, or of the depth of, a man's stature and an arm's length</em>]</span>. <span class="auth">(O, Ḳ.)</span> AZ says, <span class="ar long">حَفَرَ الرَّجُلُ قَامَةً بَاسِطَةً</span> <em>The man dug to the depth of his stature and his arm's length</em> <span class="auth">(L, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabosaTN">
				<h3 class="entry"><span class="ar">مَبْسَطٌ</span></h3>
				<div class="sense" id="mabosaTN_A1">
					<p><span class="ar">مَبْسَطٌ</span> <em>Width,</em> or <em>extent;</em> syn. <span class="ar">مُتَّسَعٌ</span>: <span class="auth">(Ḳ:)</span> as in the phrase <span class="ar long">بَلَدٌ عَرِيضُ المَبْسَطِ</span> <span class="add">[<em>A region wide in extent</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#basoTapN">See also <span class="ar">بَسْطَةٌ</span></a>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabosuwTu">
				<span class="pb" id="Page_0205"></span>
				<h3 class="entry"><span class="ar">مَبْسُوطُ</span> / 
							<span class="ar">مَبْسُوطَةٌ</span> / 
							<span class="ar">مَبْسُوطَتَانِ</span></h3>
				<div class="sense" id="mabosuwTu_A1">
					<p><span class="ar long">مَبْسُوطُ اليَدِ</span> and <span class="ar long">يَدَهُ مَبْسُوطَةٌ</span>, and <span class="ar long">يَدَاهُ مَبْسُوطَتَانِ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="munobasiTu">
				<h3 class="entry"><span class="ar">مُنْبَسِطُ</span></h3>
				<div class="sense" id="munobasiTu_A1">
					<p><span class="ar long">مُنْبَسِطُ البَاعِ</span> and <span class="ar long">مُنْبَسِطُ اللِّسَانِ</span>: <a href="#basiyTN">see <span class="ar">بَسِيطٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0203.pdf" target="pdf">
							<span>Lanes Lexicon Page 203</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0204.pdf" target="pdf">
							<span>Lanes Lexicon Page 204</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0205.pdf" target="pdf">
							<span>Lanes Lexicon Page 205</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
