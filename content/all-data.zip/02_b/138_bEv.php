<article class="root" id="Root_bEv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/137_bZr">بظر</a></span>
				<span class="ar">بعث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/139_bEvr">بعثر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEv_1">
				<h3 class="entry">1. ⇒ <span class="ar">بعث</span></h3>
				<div class="sense" id="bEv_1_A1">
					<p><span class="ar">بَعْثٌ</span> signifies The <em>removing of that which restrains one from free action.</em> <span class="auth">(TA.)</span> <span class="add">[And hence,]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEv_1_A2">
					<p><span class="ar">بَعَثَهُ</span>, <span class="auth">(Ṣ, A, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَثُ</span>}</span></add>, <span class="auth">(A, Ḳ,)</span> inf. n. <span class="ar">بَعَثٌ</span> <span class="auth">(Mgh, L, Mṣb, TA)</span> and <span class="ar">بَعَثٌ</span>, <span class="auth">(L, TA,)</span> <em>He sent him;</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ;)</span> namely, a messenger; <span class="auth">(Mṣb;)</span> and, when said of God, an apostle; <span class="auth">(A;)</span> <span class="add">[and when said of a man, a letter, &amp;c.;]</span> as also<span class="arrow"><span class="ar">ابتعثه↓</span></span>: <span class="auth">(Ṣ, A, Mṣb, Ḳ:)</span> <span class="add">[or]</span> the former is said of anything that goes, or is sent, by itself; and of anything that will not go, or be sent, by itself, as a letter, and a present, one says, <span class="ar long">بَعَثَ بِهِ</span>: <span class="auth">(Mṣb:)</span> <span class="add">[thus,]</span> <span class="ar">بَعَثَهُ</span> signifies <em>he sent him,</em> or <em>it, alone, by himself,</em> or <em>by itself;</em> and <span class="ar long">بَعَثَ بِهِ</span>, <em>he sent him,</em> or <em>it, by,</em> or <em>with, another,</em> or <em>others:</em> <span class="auth">(L:)</span> but El-Fárábee says that the former of these two has another signification, which will be found below; and that the latter signifies <em>he sent him,</em> or <em>it.</em> <span class="auth">(Mṣb.)</span> Hence, <span class="ar long">ضُرِبَ عَلَيْهِمُ البَعْثُ</span> <em>The being sent to the war was appointed them and imposed upon them as an obligation.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">بَعَثَهُ لِكَذَا</span> <span class="add">[<em>He sent him for such a thing</em> or <em>purpose</em>]</span>. <span class="auth">(A, TA.)</span> <span class="add">[And <span class="ar long">بَعَثَ إِلَيْهِ بِكَذَا</span> <em>He sent to him such a thing;</em> lit., <em>he sent to him</em> a messenger <em>with such a thing.</em>]</span> And <span class="ar long">بَعَثَ الجُنْدَ إِلَى الغَزْوِ</span> <span class="add">[<em>He sent the army to the war</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَعَثَ عَلَيْهِمُ البَلَآءَ</span> <span class="add">[<em>He sent upon them trial,</em> or <em>affliction;</em>]</span> <em>he caused trial,</em> or <em>affliction, to befall them.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEv_1_A3">
					<p>Also, <span class="auth">(A, L, TA,)</span> inf. <span class="ar">بَعْثٌ</span> <span class="auth">(Mgh, L, TA)</span> and <span class="ar">بَعَثٌ</span> <span class="auth">(L)</span> and <span class="ar">تَبْعَاثٌ</span> <span class="add">[an intensive form]</span>, <span class="auth">(TA,)</span> <em>He roused him, excited him,</em> or <em>put him in motion</em> or <em>action;</em> <span class="auth">(A, L, Mgh, TA;)</span> namely, anything; <span class="auth">(TA;)</span> <span class="add">[i. e. any person or animal; and particularly,]</span> an animal lying down, or a person sitting. <span class="auth">(L, TA.)</span> <span class="pb" id="Page_0223"></span>You say, <span class="ar long">بَعَثَ النَّاقَةَ</span> <em>He roused,</em> or <em>put in motion</em> or <em>action, the she-camel;</em> <span class="auth">(Ṣ, Mgh, Ḳ, TA;)</span> i. e., <em>loosed the cord that bound her shank to her arm, and dismissed her;</em> or <em>he roused her,</em> or <em>made her to rise, she being lying down.</em> <span class="auth">(TA.)</span> It is said in a trad. respecting ʼÁïsheh, <span class="ar long">فَبَعَثْنَا البَعِيرَ فإِذَا العِقْدُ تَحْتَهُ</span> <span class="add">[<em>And we made the camel to rise, and to, the necklace was beneath him</em>]</span>. <span class="auth">(TA.)</span> You say also, <span class="ar long">بَعَثَهُ عَلَى الأَمْرِ</span>, <span class="auth">(A,)</span> or <span class="ar">الشَّىْءِ</span>, <span class="auth">(L,)</span> <em>He roused him, excited him,</em> or <em>put him in motion</em> or <em>action, to do the affair,</em> or <em>thing:</em> <span class="auth">(A:)</span> or <em>he incited him, urged him,</em> or <em>instigated him, to do the thing.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEv_1_A4">
					<p>Also, accord. to El-Fárábee, <span class="auth">(Mṣb,)</span> or <span class="ar long">بَعَثَهُ مِنْ مَنَامِهِ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> inf. n. <span class="ar">بَعَثٌ</span> and <span class="ar">بَعَثٌ</span>, <span class="auth">(TA,)</span> <em>He roused him,</em> or <em>awoke him, from his sleep;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابتعثهُ↓</span></span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bEv_1_A5">
					<p><span class="ar">بَعْثٌ</span> <span class="auth">(Ṣ, Ḳ, TA)</span> and <span class="ar">بَعَثٌ</span> <span class="auth">(TA)</span> also signify The <em>quickening, vivifying,</em> or <em>revivifying,</em> of the dead; the <em>raising</em> of the dead <em>to life;</em> <span class="auth">(Ṣ, Ḳ,* TA;)</span> by God, <span class="auth">(TA,)</span> <em>on the day called</em> <span class="ar long">يَوْمُ البَعْثِ</span> <span class="auth">(Ṣ, TA)</span> <em>the day</em> <span class="add">[<em>of resurrection,</em>]</span> <em>when those who are in the graves shall be raised.</em> <span class="auth">(A, Mgh.)</span> You say, <span class="ar long">بَعَثَ ٱللّٰهُ الخَلْقَ</span>, and <span class="ar">المَوْتَى</span>, <em>God quickened, vivified, revivified,</em> or <em>raised to life, mankind,</em> and <em>the dead.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEv_1_B1">
					<p><span class="ar">بَعِثَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَثُ</span>}</span></add>, <span class="auth">(inf. n. <span class="ar">بَعَثٌ</span>, TḲ,)</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>was sleepless,</em> or <em>wakeful.</em> <span class="auth">(Ḳ,* TA.)</span> <span class="add">[<a href="#baEivN">See <span class="ar">بَعِثٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEv_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبعّث</span></h3>
				<div class="sense" id="bEv_5_A1">
					<p><a href="#bEv_7">see 7</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEv_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباعث</span></h3>
				<div class="sense" id="bEv_6_A1">
					<p><span class="ar">تَبَاعَثُوا</span> <span class="add">[<em>They roused, excited, incited, urged,</em> or <em>instigated, one another;</em> or <em>put one another in motion</em> or <em>action;</em> to do a thing]</span>. One says, <span class="ar long">تَوَاصَوْا بِالخَيْرِ وَتَبَاعَثُوا عَلَيْهِ</span> <span class="add">[<em>Enjoin ye,</em> or <em>charge ye, one another to do good, and rouse ye,</em> or <em>excite ye,</em>, &amp;c., <em>one another to do it</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEv_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبعث</span></h3>
				<div class="sense" id="bEv_7_A1">
					<p><span class="ar">انبعث</span> <em>He became sent;</em> <span class="add">[i. e. <em>he went, being sent;</em>]</span> <a href="#bEv_1">quasi-pass. of <span class="ar">بَعَثَهُ</span></a>, as signifying “he sent him:” <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> <em>he rose, and went away:</em> <span class="auth">(TA:)</span> <em>he rose to go forth.</em> <span class="auth">(Bḍ in ix. 46.)</span> You say, <span class="ar long">انبعث لِكَذَا</span> <span class="add">[<em>He went, being sent,</em> or <em>he rose, and went away.</em> or <em>he rose to go forth, for such a thing</em> or <em>purpose</em>]</span>. <span class="auth">(A, TA.)</span> And <span class="ar long">انبعث فُلَانٌ لِشَأْنِهِ</span> <em>Such a one rose, and went away, to perform his affair.</em> <span class="auth">(TA.)</span> And <span class="ar long">انبعث فِى السَّيْرِ</span> <em>He hastened, made haste, sped,</em> or <em>was quick</em> or <em>swift, in going, journeying,</em> or <em>pace.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">انبعث الشَّيْءُ</span>, i. e. <span class="ar">اِنْدَفَعَ</span> <span class="add">[<em>The thing became impelled,</em> or <em>propelled;</em> or <em>went quickly,</em> or <em>swiftly, as though impelled</em> or <em>propelled;</em>, &amp;c.]</span>; as also<span class="arrow"><span class="ar">تبعّث↓</span></span>. <span class="auth">(TA.)</span> <span class="add">[Thus]</span> you say, <span class="ar long">انبعث المَآءُ</span> <span class="add">[<em>The water poured out,</em> or <em>forth, as though impelled</em> or <em>propelled</em>]</span>. <span class="auth">(TA in art. <span class="ar">فجر</span>;, &amp;c.)</span> And <span class="add">[hence,]</span><span class="arrow"><span class="ar long">تبعّث↓ مِنِّىَ الشِّعْرُ</span></span>, i. e. <span class="ar">انبعث</span> <span class="add">[<em>The poetry issued quickly from me</em>]</span>, as though it flowed (<span class="ar long">كَأَنَّهُ سَالَ</span>): so in the Ṣ and Ḳ: but in some of the copies of the Ṣ, in the place of <span class="ar">سَالَ</span>, we find <span class="ar">سَارَ</span>. <span class="auth">(TA.)</span> And <span class="ar long">انبعث بِشَرٍّ</span> <span class="add">[<em>He broke forth with evil,</em> or <em>mischief</em>]</span>. <span class="auth">(JK in art. <span class="ar">بوق</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEv_7_A2">
					<p><span class="add">[<em>He became roused, excited, incited, urged, instigated,</em> or <em>put in motion</em> or <em>action.</em>]</span> You say, <span class="ar long">انبعثت النَّاقَةُ</span> <em>The she-camel became roused,</em> or <em>put in motion</em> or <em>action, and rose:</em> <span class="auth">(L, Mgh, TA:*)</span> <a href="#bEv_1_A3">quasi-pass. of <span class="ar long">بَعَثَ النَّاقَةَ</span> <span class="add">[q. v.]</span></a>. <span class="auth">(Mgh, TA.)</span> And <span class="ar long">فُلَانٌ كَسْلَانٌ لَا بَنْبَعِثُ</span> <span class="add">[<em>Such a one is sluggish, lazy,</em> or <em>indolent: he will not become roused,</em>, &amp;c.]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEv_7_A3">
					<p><em>He became roused,</em> or <em>awakened, from his sleep;</em> or <em>he awoke from his sleep.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEv_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتعث</span></h3>
				<div class="sense" id="bEv_8_A1">
					<p><a href="#bEv_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEovN">
				<h3 class="entry"><span class="ar">بَعْثٌ</span></h3>
				<div class="sense" id="baEovN_A1">
					<p><span class="ar">بَعْثٌ</span> an inf. n. used as a pass. part. n.; <em>Sent;</em> as also<span class="arrow"><span class="ar">بَعِيثٌ↓</span></span> and<span class="arrow"><span class="ar">مَبْعوثٌ↓</span></span>: pl. of the first <span class="ar">بُعُوثٌ</span>; and of the second <span class="ar">بُعُثٌ</span>. <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَعْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEovN_A2">
					<p>And <span class="add">[used as a subst., signifying]</span> <em>A person sent; a messenger:</em> pl. <span class="ar">بَعْثَانٌ</span>. <span class="auth">(L.)</span> You say also,<span class="arrow"><span class="ar long">مُحَمَّدٌ خَيْرُ مَبْعُوثٍ↓</span></span> and<span class="arrow"><span class="ar">مُبْتَعَثٍ↓</span></span> <span class="add">[<em>Moḥammad is the best person that has been sent</em>]</span>. <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">بَعَيثُكَ↓ نِعْمَةً</span></span>, i. e.<span class="arrow"><span class="ar">مَبْعُوثُكَ↓</span></span> <span class="add">[<em>He whom Thou</em> <span class="auth">(O God)</span> <em>hast sent</em> <span class="auth">(namely Moḥammad)</span> <em>as a boon,</em> or <em>benefit,</em> or <em>favour</em>]</span>. <span class="auth">(L, from a trad. <span class="add">[The latter word (<span class="ar">نعمة</span>)</span> is written in the L without any syll. signs; but the context shows that it is in the accus. case as a specificative.]</span>)</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَعْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baEovN_A3">
					<p><em>A people sent from one place to another;</em> as also<span class="arrow"><span class="ar">بَعَثٌ↓</span></span>: <span class="auth">(L, TA:)</span> <em>a people sent in any direction;</em> a word similar to <span class="ar">سَفْرٌ</span> and <span class="ar">رَكْبٌ</span>. <span class="auth">(TA.)</span> <span class="ar long">بَعْثُ النَّارِ</span>, occurring in a trad., means <em>The people sent to the fire</em> <span class="add">[<em>of Hell</em>]</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَعْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baEovN_A4">
					<p><em>An army;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> because sent; <span class="auth">(Mgh;)</span> as also<span class="arrow"><span class="ar">بَعَثٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">بَعِيثٌ↓</span></span>: <span class="auth">(TA:)</span> pl. of the first <span class="ar">بُعُوثٌ</span>; <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ;)</span> and of the last <span class="ar">بُعُثٌ</span>: <span class="auth">(TA:)</span> the first, <span class="add">[as also the second,]</span> an inf. n. used as a subst. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">كُنْتُ فِى بَعْثِ فُلَانٍ</span> <em>I was in the army of such a one, that was sent with him.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">خَرَجَ فِى البُعُوثِ</span> <em>He went forth among the forces that were sent to the frontiers.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَعْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baEovN_A5">
					<p><a href="#baEivN">See also <span class="ar">بَعِثٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buEovN">
				<h3 class="entry"><span class="ar">بُعْثٌ</span></h3>
				<div class="sense" id="buEovN_A1">
					<p><span class="ar">بُعْثٌ</span>: <a href="#baEovN">see <span class="ar">بَعْثٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baEavN">
				<h3 class="entry"><span class="ar">بَعَثٌ</span></h3>
				<div class="sense" id="baEavN_A1">
					<p><span class="ar">بَعَثٌ</span>: <a href="#baEovN">see <span class="ar">بَعْثٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَعَثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEavN_A2">
					<p><a href="#baEivN">and see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEivN">
				<h3 class="entry"><span class="ar">بَعِثٌ</span></h3>
				<div class="sense" id="baEivN_A1">
					<p><span class="ar">بَعِثٌ</span> <span class="auth">(A, L, Ḳ)</span> and<span class="arrow"><span class="ar">بَعْثٌ↓</span></span> <span class="auth">(L, TA)</span> and<span class="arrow"><span class="ar">بُعْثٌ↓</span></span>, <span class="auth">(L,)</span> or<span class="arrow"><span class="ar">بَعَثٌ↓</span></span>, <span class="auth">(TA,)</span> <em>Sleepless,</em> or <em>wakeful:</em> <span class="auth">(Ḳ:)</span> a man <em>incessantly,</em> <span class="auth">(A,)</span> or <em>often,</em> <span class="auth">(TA,)</span> <em>awaking from his sleep:</em> <span class="auth">(A, TA:)</span> a man <em>whose anxieties,</em> or <em>griefs, incessantly render him sleepless,</em> or <em>wakeful, and awake him from his sleep:</em> pl. <span class="ar">أَبْعاثٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEovapN">
				<h3 class="entry"><span class="ar">بَعْثَةٌ</span></h3>
				<div class="sense" id="baEovapN_A1">
					<p><span class="ar">بَعْثَةٌ</span> <span class="add">[inf. n. of un. of 1; and particularly signifying]</span> <em>An occasion,</em> or <em>occurrence, of raising, rousing, exciting, stirring up,</em> or <em>provoking,</em> of sedition, or the like: pl. <span class="ar">بَعَثَاتٌ</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baEiyvN">
				<h3 class="entry"><span class="ar">بَعِيثٌ</span></h3>
				<div class="sense" id="baEiyvN_A1">
					<p><span class="ar">بَعِيثٌ</span>: <a href="#baEovN">see <span class="ar">بَعْثٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAEivN">
				<h3 class="entry"><span class="ar">بَاعِثٌ</span></h3>
				<div class="sense" id="baAEivN_A1">
					<p><span class="ar">بَاعِثٌ</span> <span class="add">[act. part. n. of 1; <em>Sending:</em>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَاعِثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAEivN_A2">
					<p><span class="add">[And hence, <em>Occasioning,</em> or <em>causing: an occasion,</em> or <em>a cause;</em> and <em>a motive</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعث</span> - Entry: <span class="ar">بَاعِثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAEivN_A3">
					<p><span class="ar">البَاعِثُ</span> one of the names <span class="add">[or epithets]</span> of God; <em>The Quickener of mankind after death, on the day of resurrection.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaAEuwvu">
				<h3 class="entry"><span class="ar">البَاعُوثُ</span></h3>
				<div class="sense" id="AlbaAEuwvu_A1">
					<p><span class="ar">البَاعُوثُ</span>, <span class="auth">(L, Ḳ,)</span> or, accord. to some, <span class="ar">البَاغُوتُ</span>, q. v., with the pointed <span class="ar">غ</span> and the double-pointed <span class="ar">ت</span>, <span class="auth">(TA,)</span> <span class="add">[<em>The Christian festival of Easter;</em>]</span> <em>the</em> <span class="ar">اِسْتِسْقَآء</span> <em>of the Christians;</em> <span class="auth">(Ḳ;)</span> or <span class="add">[rather]</span> <em>what is to the Christians as the</em> <span class="ar">استسقآء</span> <em>is to the Muslims:</em> a Syriac word. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboEavN">
				<h3 class="entry"><span class="ar">مَبْعَثٌ</span></h3>
				<div class="sense" id="maboEavN_A1">
					<p><span class="ar">مَبْعَثٌ</span> <span class="add">[a noun of place and of time from 1; <em>A place,</em> and <em>a time, of sending:</em>, &amp;c. Hence, <span class="ar">المَبْعَثُ</span> is particularly applied to <em>The time of the mission of Moḥammad:</em> and it is also applied to <em>the mission</em> itself]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboEuwvN">
				<h3 class="entry"><span class="ar">مَبْعُوثٌ</span></h3>
				<div class="sense" id="maboEuwvN_A1">
					<p><span class="ar">مَبْعُوثٌ</span>: <a href="#baEovN">see <span class="ar">بَعْثٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotaEavN">
				<h3 class="entry"><span class="ar">مُبْتَعَثٌ</span></h3>
				<div class="sense" id="mubotaEavN_A1">
					<p><span class="ar">مُبْتَعَثٌ</span>: <a href="#baEovN">see <span class="ar">بَعْثٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0222.pdf" target="pdf">
							<span>Lanes Lexicon Page 222</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0223.pdf" target="pdf">
							<span>Lanes Lexicon Page 223</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
