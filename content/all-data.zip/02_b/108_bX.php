<article class="root" id="Root_bX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/107_bsn">بسن</a></span>
				<span class="ar">بش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/109_bXr">بشر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bX_1">
				<h3 class="entry">1. ⇒ <span class="ar">بشّ</span></h3>
				<div class="sense" id="bX_1_A1">
					<p><span class="ar">بَشَّ</span>, first pers. <span class="ar">بَشِشْتُ</span>, aor. <span class="ar">يَبَشُّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and, accord. to a relation of a verse of Ru-beh, <span class="ar">يَبِشُّ</span>, so that perhaps <span class="ar">بَشَشْتُ</span> was also said, <span class="auth">(TA.)</span> inf. n. <span class="ar">بَشَاشَةٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and <span class="ar">بَشٌّ</span> <span class="auth">(A, Ḳ)</span> and <span class="ar">بَشِيشٌ</span>, <span class="auth">(TA,)</span> <em>He was,</em> or <em>became, cheerful in countenance.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> You say, <span class="ar long">بَشِشْتُ بِهِ</span> <em>I was,</em> or <em>became, cheerful in countenance</em> <span class="add">[<em>by reason of meeting</em>]</span> <em>with him:</em> <span class="auth">(Ṣ:)</span> or <span class="ar long">بَشَّ بِهِ</span> <span class="auth">(TḲ,)</span> inf. n. <span class="ar">بَشٌّ</span> <span class="auth">(Lth, Ḳ)</span> and <span class="ar">بَشَاشَةٌ</span>, <span class="auth">(Ḳ,)</span> signifies <em>he rejoiced in him,</em> or <em>was pleased with him,</em> namely, a friend, <span class="auth">(Lth, Ḳ,)</span> <em>at meeting:</em> <span class="auth">(Lth:)</span> or <em>he showed joy,</em> or <em>pleasure, at meeting him.</em> <span class="auth">(TḲ.)</span> <span class="pb" id="Page_0207"></span>You say also,<span class="arrow"><span class="ar long">لَقِيتُهُ فَتَبَشْبَشَ↓ بِى</span></span> <span class="add">[app. meaning <em>I met him and he became cheerful in countenance by reason of meeting with me</em>]</span>; originally<span class="arrow"><span class="ar">تَبَشَّشَ↓</span></span>; the middle <span class="ar">ش</span> being changed into <span class="ar">ب</span>: <span class="auth">(Yaạḳoob, Ṣ:)</span> or<span class="arrow"><span class="ar long">تَبَشْبَشَ↓ بِهِ</span></span> signifies <em>he was,</em> or <em>became, sociable,</em> or <em>companionable,</em> or <em>cheerful, with him; and held loving communion with him:</em> syn. <span class="ar">آنَسَهُ</span>, and <span class="ar">وَاصَلَهُ</span>: <span class="auth">(Ḳ:)</span> but when said of God, it means ‡ <em>He regarded him with favour, and honoured him,</em> <span class="auth">(IAmb, Ḳ,)</span> <em>and received him graciously, and drew him near to Him.</em> <span class="auth">(IAmb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bX_1_A2">
					<p>Also <span class="ar long">بَشَّ لَهُ</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">بَشٌّ</span> <span class="auth">(IDrd, Ḳ)</span> and <span class="ar">بَشَاشَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>He presented a favourable aspect to him;</em> or <em>met him kindly,</em> namely, his brother; syn. <span class="ar long">أَقْبَلَ عَلَيْهِ</span>: <span class="auth">(Ḳ:)</span> <em>he behaved laughingly towards him; without shyness,</em> or <em>aversion;</em> or <em>boldly;</em> or <em>in a free and easy manner;</em> or <em>cheerfully;</em> syn. <span class="ar long">ضَحِكَ إِلَيْهِ</span>, <span class="auth">(IDrd, Ḳ,)</span> and <span class="ar">اِنْبَسَطَ</span>. <span class="auth">(IDrd.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bX_1_A3">
					<p>And <span class="ar long">بَشَّ لَهُ فِى المَسْأَلَةِ</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">بَشٌّ</span> <span class="auth">(IAạr, A, Ḳ)</span> and <span class="ar">بَشَاشَةٌ</span>, <span class="auth">(A, Ḳ,)</span> <em>He was courteous,</em> or <em>gracious, to him in asking.</em> <span class="auth">(IAạr, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bX_1_A4">
					<p>And <span class="ar long">بَشَّ لِى بِخَيْرِ</span> ‡ <em>He gave me</em> <span class="add">[<em>something good</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bX_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابشّ</span></h3>
				<div class="sense" id="bX_4_A1">
					<p><span class="ar long">ابشّت الأَرْضُ</span> ‡ <em>The land had tangled,</em> or <em>luxuriant, plants,</em> or <em>herbage:</em> <span class="auth">(Aṣ, Ḳ:)</span> or <em>produced its first plants,</em> or <em>herbage.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bX_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبشّش</span></h3>
				<div class="sense" id="bX_5_A1">
					<p><a href="#bX_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bX_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تبشبش</span></h3>
				<div class="sense" id="bX_RQ2_A1">
					<p><a href="#bX_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="rbaXBN">
				<h3 class="entry"><span class="ar">بَشٌّ</span></h3>
				<div class="sense" id="rbaXBN_A1">
					<p><span class="ar long">رَجُلٌ هَشٌّ بَشٌّ</span> <em>A man</em> <span class="add">[<em>brisk, lively,</em> or <em>sprightly;</em> or <em>joyful;</em> and]</span> <em>cheerful in countenance; pleasant</em> <span class="add">[<em>therein</em>]</span>; <span class="auth">(Ṣ, TA;)</span> as also<span class="arrow"><span class="ar">بَشَّاشٌ↓</span></span>. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=26_h/088_hX">See also art. <span class="ar">هش</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXiyXN">
				<h3 class="entry"><span class="ar">بَشِيشٌ</span></h3>
				<div class="sense" id="baXiyXN_A1">
					<p><span class="ar">بَشِيشٌ</span> The <em>face,</em> or <em>countenance.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> You say, <span class="ar long">فُلَانٌ مُضِىْءُ البَشِيشِ</span> <em>Such a one is bright in countenance.</em> <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baXBaAXN">
				<h3 class="entry"><span class="ar">بَشَّاشٌ</span></h3>
				<div class="sense" id="baXBaAXN_A1">
					<p><span class="ar">بَشَّاشٌ</span>: <a href="#baXBN">see <span class="ar">بَشٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabaXBu">
				<h3 class="entry"><span class="ar">أَبَشُّ</span></h3>
				<div class="sense" id="OabaXBu_A1">
					<p><span class="ar">أَبَشُّ</span> <span class="add">[<em>More,</em> and <em>most, cheerful in countenance</em>]</span>. You say, <span class="ar long">مَا رَأَيْتُ أَبَشَّ مِنْهُ بِاللَّاقِى</span> <span class="add">[<em>I have not seen any one more cheerful in countenance than he to the meeter</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0206.pdf" target="pdf">
							<span>Lanes Lexicon Page 206</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0207.pdf" target="pdf">
							<span>Lanes Lexicon Page 207</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
