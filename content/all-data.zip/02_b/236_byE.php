<article class="root" id="Root_byE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/235_byD">بيض</a></span>
				<span class="ar">بيع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/237_bylwn">بيلون</a></span>
			</h2>
			<hr>
			<section class="entry main" id="byE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بيع</span> ⇒ <span class="ar">باع</span></h3>
				<div class="sense" id="byE_1_A1">
					<p><span class="ar">بَاعَهُ</span>, <span class="auth">(Ṣ, Mgh, &amp;c.,)</span> aor. <span class="ar">يَبِيعُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَيْعٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">مَبِيعٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> which latter is anomalous, <span class="auth">(Ṣ,)</span> the regular form being <span class="ar">مَبَاعٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> has two contr. significacations: <em>He sold it:</em> and <em>he bought it:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> and<span class="arrow"><span class="ar">اباعهُ↓</span></span> is a dial. var. of the same: <span class="auth">(IḲṭṭ, Mṣb:)</span> <span class="add">[but app. only in the former sense:]</span> or this last signifies <em>he offered it for sale;</em> or <em>exposed it to sale:</em> <span class="auth">(Ṣ, Ḳ:)</span> and<span class="arrow"><span class="ar">ابتاعهُ↓</span></span>, as well as <span class="ar">بَاعَهُ</span>, signifies <em>he bought it.</em> <span class="auth">(Ṣ,* Mgh,* Mṣb, Ḳ.)</span> The primary signification of <span class="ar">بَيْعٌ</span> is The <em>exchanging,</em> or <em>exchange, of property;</em> or the <em>making an exchange with property;</em> as in the phrases <span class="ar long">بَيْعٌ رَابِحٌ</span> <span class="add">[<em>an exchange of property bringing gain</em>]</span>, and <span class="ar long">بَيْعٌ خَاسِرٌ</span> <span class="add">[<em>an exchange of property occasioning loss</em>]</span>: and this is a proper signification when it relates to real substances: but it is tropically used to signify the <em>making the contract</em> <span class="add">[<em>of sale and purchase</em>]</span>; because this is the means of giving <span class="add">[and obtaining]</span> possession: <span class="add">[though this signification is what is termed <span class="ar long">حَقِيقَةٌ عُرْفِيَّةٌ</span>, i. e., a sense so common as to be conventionally regarded as proper:]</span> the phrase <span class="ar long">صَحَّ البَيْعُ</span>, or <span class="ar">بَطَلَ</span>, and the like, mean <span class="ar long">صَفْقَةُ البَيْعِ</span>; <span class="add">[i. e. <em>The contract of sale,</em> or <em>purchase, was valid,</em> or <em>was null;</em>]</span> but the prefixed n. being suppressed, and its complement <span class="add">[alone]</span> used for it, and this being masc., the verb is made masc. <span class="auth">(Mṣb.)</span> <span class="ar">بَاعَ</span> <span class="add">[mostly signifies <em>He sold;</em> and]</span> is doubly trans., both by itself and by means of <span class="ar">مِنْ</span> prefixed to the second object; <span class="auth">(Mgh, Mṣb;)</span> this prep. being thus used as a corroborative: <span class="auth">(Mṣb:)</span> you say, <span class="ar long">بَاعَهُ الشَّىْءَ</span> and <span class="ar long">بَاعَهُ مِنْهُ</span> <span class="add">[<em>He sold to him the thing</em> and <em>He sold it to him</em>]</span>: <span class="auth">(Mgh:)</span> and <span class="ar long">بِعْتُ زَيْدًا الدَّارَ</span> and <span class="ar long">بِعْتُ مِنْ زَيْدٍ الدَّارَ</span> <span class="add">[<em>I sold to Zeyd the house:</em> <span class="auth">(see also an explanation of the phrase <span class="ar long">اِسْتَبَعْتُهُ الشَّىْءَ</span>: <a href="#byE_1_A3">and see <span class="ar long">بَاعَهُ مِنَ السُّلْطَانِ</span></a>: to which might be added countless similar instances; for when <span class="ar">باع</span> signifies <em>he sold,</em> <span class="ar">مِنْ</span> is generally prefixed to the noun or pronoun denoting the person to whom the thing is sold:)</span>]</span> and sometimes <span class="ar">لِ</span> is put in the place of <span class="ar">مِنْ</span>; so that you say, <span class="ar long">بِعْتُكَ الشَّىْءَ</span> and <span class="ar long">بِعْتُهُ لَكَ</span> <span class="add">[<em>I sold to thee the thing</em> and <em>I sold it to thee</em>]</span>; the <span class="ar">ل</span> being redundant <span class="add">[when the verb has this meaning, though not when it has the contr. meaning, as will be seen below]</span>. <span class="auth">(Mṣb.)</span> Of the contr. signification we have an ex. in the saying of El-Farezdaḳ,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِنَّ الشَّبَابَ لَرَابِحٌ مَنْ بَاعَهَا</span> *</div> 
						<div class="star">* <span class="ar long">وَالشَّيْبُ لَيْسَ لِبَائِعِيهِ تِجَارُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Verily youthfulness, he who buys it is a gainer; but hoariness, there are no traffickers for its sellers;</em> the part. a. being here from the verb in the former sense]</span>: <span class="auth">(Ṣ, TA:)</span> and <span class="add">[often in a case in which the verb is followed by <span class="ar">ل</span>; as]</span> in <span class="ar long">بَاعَ لَهُ الشَّىْءَ</span> <em>He bought for him the thing;</em> <span class="auth">(Mgh;)</span> <span class="add">[the <span class="ar">ل</span> not being redundant when the verb is used in this sense;]</span> and as in the saying of Tarafeh,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَيَأْتِيكَ بالْأَخْبَارِ مَنْ لَمْ تَبِعْ لَهُ</span> *</div> 
						<div class="star">* <span class="ar long">بَتَاتًا وَلَمْ تَضْرِبْ لَهُ وَقْتَ مَوْعِدِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And he will bring thee tidings for whom thou hast not bought travelling-provisions, and for whom thou hast not assigned an appointed time</em> for his bringing them]</span>: <span class="auth">(TA:)</span> and in the saying, <span class="ar long">بَاعَ دُنْيَاهُ بِآخِرَتِهِ</span> ‡ <span class="add">[<em>He purchased his enjoyments of the present world at the expense of his enjoyments of the world to come</em>]</span>: <span class="auth">(Z, TA:)</span> and <span class="add">[in like manner]</span> you say,<span class="arrow"><span class="ar long">ابتاع↓ زَيْدٌ الدَّارَ</span></span>, meaning <em>Zeyd bought the house:</em> and<span class="arrow"><span class="ar long">ابتاعها↓ لِغَيْرِهِ</span></span> <em>He bought it for another person.</em> <span class="auth">(Mṣb.)</span> The verb has this signification, also, in the trad., <span class="ar long">لَا يَبِعْ بَعْضُكُمْ عَلَى بَيْعِ أَخِيهِ</span> <span class="add">[<em>One of you shall not buy in opposition to the buying of his brother when an agreement has been manifested but the contract has not been concluded</em>]</span>; <span class="auth">(Ṣ, IAth, Mgh, Mṣb; <span class="add">[but in the Ṣ and Mṣb and by IAth, the trad. is related thus; <span class="ar long">لَا يَخْطُبِ الرَّجُلُ عَلَى خِطْبَةِ أَخِيهِ وَلَا يَبِعْ عَلَى بَيْعِ أَخِيهِ</span>; (<a href="index.php?data=07_x/105_xTb">see art. <span class="ar">خطب</span></a>;)</span>]</span>) as is shown by the relation of Bkh,<span class="arrow"><span class="ar long">لَا يَبْتَاعُ↓ الرَّجُلُ عَلَى بَيْعِ أَخِيهِ</span></span>: <span class="auth">(Mgh, Mṣb:)</span> or it may here have the contr. meaning: <span class="auth">(IAth:)</span> Az says that the seller and buyer are equal in offence when either of them does thus to another. <span class="auth">(TA.)</span> <span class="add">[Similar to this is the saying, <span class="ar long">لَا يَسُومُ الرَّجُلُ عَلَى سَوْمِ أَخِيهِ</span>: <a href="index.php?data=12_s/256_swm">see art. <span class="ar">سوم</span></a>. <a href="#baYoEihi">See also <span class="ar long">بَاعَ عَلَى بَيْعِهِ</span> below</a>, used in a tropical sense.]</span> You say also, <span class="ar long">بَاعَ عَلَيْهِ القَاضِى</span>, meaning <em>The judge sold against his will;</em> <span class="auth">(Mgh;)</span> <em>sold without his consent.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byE_1_A2">
					<p>The pass. form is <span class="ar">بِيعَ</span> <span class="add">[<em>It was sold:</em> and <em>it was bought</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> optionally either <span class="add">[thus]</span> with kesr to the <span class="ar">ب</span>, or <span class="add">[<span class="ar">بُيْعَ</span>]</span> with damm to the <span class="ar">ب</span>, <span class="auth">(Ṣ,)</span> <span class="add">[or rather with a sound between that of damm and that of kesr, which pronunciation is termed <span class="ar">إِشْمَامٌ</span>;]</span> and some say <span class="ar">بُوعَ</span>; <span class="auth">(Ṣ, Ḳ;)</span> changing the <span class="ar">ى</span> into <span class="ar">و</span>: and thus in the cases of <span class="ar">كِيلَ</span> and <span class="ar">قِيلَ</span> and the like: <span class="auth">(Ṣ:)</span> <span class="add">[but Ibn-Málik requires damm or <span class="ar">اشمام</span> in the passive of a verb of which the medial radical is <span class="ar">ى</span>, and kesr or <span class="ar">اشمام</span> in the passive of a verb of which the medial radical is <span class="ar">و</span>, to prevent the mistaking of an active verb for a passive in such cases as <span class="ar">بِعْتُ</span> and <span class="ar">سُمْتُ</span>: others, however, only prefer what Ibn-Málik absolutely requires in these cases. <span class="auth">(See I’Aḳ p. 131.)</span>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="byE_1_A3">
					<p>You say also, <span class="ar long">بَاعَهُ مِنَ السُّلْطَانِ</span>, <span class="add">[lit. <em>He sold him to the Sultán,</em>]</span> meaning ‡ <em>he slandered him,</em> or <em>calumniated him, to the Sultán.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<span class="pb" id="Page_0285"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="byE_1_A4">
					<p>And <span class="ar long">بَاعَ فُلَانٌ عَلَى بَيْعِهِ</span>, <span class="add">[of which the lit. meaning has been shown above,]</span> meaning ‡ <em>Such a one superseded him,</em> or <em>occupied his place, in respect of honourable and elevated station</em> or <em>rank, and gained the mastery over him;</em> <span class="auth">(Ḳ,* TA;)</span> and so <span class="ar long">حَلَّ بِوَادِيهِ</span>: <span class="auth">(TA:)</span> or <span class="ar long">بَاعَ فُلَانٌ عَلَى بَيْعِ فُلَانٍ</span> means ‡ <em>such a one gained the mastery over such a one, and wrested from him that which he sought to obtain from him;</em> and is an old proverb, applied by the Arabs to a man who contends with another, and seeks to obtain a thing from him by superior power or force, when he has succeeded in doing as above explained; and similar to it is the saying <span class="ar long">شَقَّ فُلَانٌ غُبَارَ فُلَانٍ</span>. <span class="auth">(El-Mufaddal Ed-Ḍabbee, TA.)</span> One also says, <span class="ar long">مَا بَاعَ عَلَى بَيْعِكَ أَحَدٌ</span>, meaning † <em>Not any one has equalled thee.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byE_1_B1">
					<p><span class="ar">بَيْعٌ</span> is also used in the sense of <span class="ar">اِنْبِسَاطٌ</span>. <span class="auth">(TA <a href="index.php?data=02_b/222_bwE">in art. <span class="ar">بوع</span></a>. <span class="add">[<a href="#IinobaAEa">See <span class="ar">اِنْبَاعَ</span></a> in that art.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byE_3">
				<h3 class="entry">3. ⇒ <span class="ar">بايع</span></h3>
				<div class="sense" id="byE_3_A1">
					<p><span class="ar">بَايَعْتُهُ</span>, <span class="auth">(Ṣ, Mgh, TA,)</span> inf. n. <span class="ar">مُبَايَعَةٌ</span> and <span class="ar">بِيَاعٌ</span>, <span class="auth">(TA,)</span> is from <span class="ar">البَيْعُ</span>; and so is <span class="arrow"><span class="ar">التَّبَايُعُ↓</span></span>; <span class="auth">(Ṣ, TA;)</span> this being syn. with <span class="ar">المُبَايَعَةُ</span>. <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar">بَايَعَا</span> and<span class="arrow"><span class="ar">تَبَايَعَا↓</span></span>, meaning <em>They two sold and bought, each with the other:</em> <span class="auth">(TḲ:)</span> and<span class="arrow"><span class="ar">تَبَايَعْنَا↓</span></span> <span class="add">[<em>We sold and bought, one with another</em>]</span>: <span class="auth">(Mgh:)</span> and <span class="ar">بايعهُ</span> also signifies <em>He bartered,</em> or <em>exchanged commodities, with him.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#byE_1">See 1</a>; where a citation from the Mṣb indicates that this latter is the primary signification accord. to the author of that work.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byE_3_A2">
					<p>It is also from <span class="ar">البَيْعَةُ</span>; and so is <span class="arrow"><span class="ar">التَّبَايُعُ↓</span></span>: <span class="auth">(Ṣ, TA:*)</span> <span class="ar">المُبَايَعَةُ</span> and<span class="arrow"><span class="ar">التَّبَايُعُ↓</span></span> from <span class="ar">البَيْعَةُ</span> signifying The <em>making a covenant, a compact, an engagement,</em> or <em>the like; as though each of the two parties sold what he had to the other, and gave him his own special property, and his obedience, and all that pertained to his case.</em> <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">بايع الأَمِيرَ</span> <em>He promised,</em> or <em>swore, allegiance to the prince; making a covenant with him to submit to him the judgment of his own case and of the cases of the Muslims</em> <span class="add">[<em>in general</em>]</span>, <em>not to dispute with him in respect of anything thereof, but to obey him in whatever command he might impose upon him, pleasing and displeasing:</em> in doing which, it was usual for the person making this covenant to place his hand in the hand of the prince, in confirmation of the covenant, like as is done by the seller and buyer; wherefore the act was termed <span class="ar">بَيْعَةٌ</span>, an inf. n. <span class="add">[of un.]</span> of <span class="ar">بَاعَ</span>. <span class="auth">(Ibn-Khaldoon, in De Sacy's Chrest. Ar., 2nd ed., ii. 256 - 7.)</span> <span class="add">[And hence the phrases, <span class="ar long">بُويِعَ بِالِخِلَافَةِ</span> and <span class="ar long">بُويِعَ لَهُ بِالخِلَافَةِ</span> <em>He had the promise,</em> or <em>oath, of allegiance made to him as being Khaleefeh.</em>]</span> You say also, <span class="ar long">بايعهُ عَلَيْهِ</span>, inf. n. <span class="ar">مُبَايَعَةٌ</span>, <em>He made a covenant, a compact, an engagement,</em> or <em>the like, with him, respecting it,</em> or <em>to do it:</em> and<span class="arrow"><span class="ar long">تبايعوا↓ عَلَى الأَمْرِ</span></span> <span class="add">[<em>they made a covenant,</em>, &amp;c., <em>respecting,</em> or <em>to do, the thing,</em> or <em>affair</em>]</span>; like as you say <span class="ar long">أَصْفَقُوا عَلَيْهِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="byE_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابيع</span> ⇒ <span class="ar">اباع</span></h3>
				<div class="sense" id="byE_4_A1">
					<p><a href="#byE_1">see 1</a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="byE_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبايع</span></h3>
				<div class="sense" id="byE_6_A1">
					<p><a href="#byE_3">see 3</a>, throughout.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byE_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبيع</span> ⇒ <span class="ar">انباع</span></h3>
				<div class="sense" id="byE_7_A1">
					<p><span class="ar">انباع</span> <em>It was,</em> or <em>became, saleable,</em> or <em>easy of sale; it had an easy,</em> or <em>a ready, sale:</em> <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> <a href="#byE_1">as though quasi-pass. of <span class="ar">بَاعَهُ</span></a> <span class="add">[and therefore primarily signifying <em>it was,</em> or <em>became, sold,</em> or <em>bought</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="byE_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتيع</span> ⇒ <span class="ar">ابتاع</span></h3>
				<div class="sense" id="byE_8_A1">
					<p><a href="#byE_1">see 1</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byE_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبيع</span> ⇒ <span class="ar">استباع</span></h3>
				<div class="sense" id="byE_10_A1">
					<p><span class="ar long">اِسْتَبَعْتُهُ الشَّىْءَ</span> <em>I asked him to sell the thing to me;</em> expl. by <span class="ar long">سَأَلْتُهُ أَنْ يَبِيعَهُ مِنِّى</span>; <span class="auth">(Ṣ, Ḳ;*)</span> for instance, <span class="ar">عَبْدَهُ</span> <span class="add">[<em>his slave.</em>]</span> <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoEN">
				<h3 class="entry"><span class="ar">بَيْعٌ</span></h3>
				<div class="sense" id="bayoEN_A1">
					<p><span class="ar">بَيْعٌ</span> <a href="#byE_1">inf. n. of 1 <span class="add">[q. v.]</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بَيْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoEN_A2">
					<p>It also signifies The <em>hire,</em> or <em>hiring,</em> of land. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بَيْعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bayoEN_B1">
					<p>Also <em>A thing sold,</em> or <em>bought:</em> <span class="auth">(Mgh, Mṣb, TA:)</span> a subst. in this sense: <span class="auth">(Mgh, TA:)</span> pl. <span class="ar">بُيُوعٌ</span>: <span class="auth">(Mgh, Mṣb, TA:)</span> which is also used as a pl. of the inf. n., to signify <em>Kinds of selling and buying.</em> <span class="auth">(Mgh.)</span> <a href="#biyaAEapN">See also <span class="ar">بِيَاعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoEapN">
				<h3 class="entry"><span class="ar">بَيْعَةٌ</span></h3>
				<div class="sense" id="bayoEapN_A1">
					<p><span class="ar">بَيْعَةٌ</span> <span class="add">[inf. n. of un. of <span class="ar">بَاعَ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بَيْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoEapN_A2">
					<p><span class="add">[Hence,]</span> <em>A striking together of the hands of two contracting parties in token of the ratification of a sale.</em> <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بَيْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayoEapN_A3">
					<p>And <span class="add">[hence,]</span> The <em>act of</em> <span class="ar">مُبَايَعَة</span> <span class="add">[or <em>promising,</em> or <em>swearing, allegiance and obedience,</em> as explained above, (<a href="#byE_3">see 3</a>,)]</span> <em>and submission,</em> or <em>obedience.</em> <span class="auth">(Mṣb, TA.)</span> Whence, <span class="ar long">أَيْمَانُ البَيْعَةِ</span> <span class="add">[<em>The oaths of allegiance and obedience</em>]</span>; <span class="auth">(Ibn-Khaldoon, in De Sacy's Chrest. Ar., 2nd ed., ii. 257; and Mṣb;)</span> which the Khaleefehs exacted; <span class="auth">(Ibn-Khaldoon;)</span> and which El-Hajjáj appointed, including hard, or difficult, matters, relating to divorce and emancipation and fasting and the like. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biyEapN">
				<h3 class="entry"><span class="ar">بِيعَةٌ</span></h3>
				<div class="sense" id="biyEapN_A1">
					<p><span class="ar">بِيعَةٌ</span> <em>A mode,</em> or <em>manner, of selling</em> or <em>buying.</em> <span class="auth">(Ṣ, Mgh, Ḳ.)</span> Hence, <span class="ar long">صَاحِبُ بِيعَةٍ</span> <span class="add">[<em>A person occupying himself in any kind of selling</em> or <em>buying</em>]</span>: occurring in a trad. of Ibn-ʼOmar. <span class="auth">(Mgh, TA.)</span> And <span class="ar long">إِنَّهُ لَحَسَنُ البِيعَةِ</span> <span class="add">[<em>Verily he is good in the manner of selling</em> or <em>buying</em>]</span>. <span class="auth">(Ṣ, Mgh, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بِيعَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="biyEapN_B1">
					<p><span class="add">[<em>A Christian church;</em>]</span> <em>a place of worship</em> <span class="auth">(Ḳ)</span> <em>pertaining to the Christians:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> or, as some say, <em>a synagogue of the Jews:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بِيَعٌ</span>, <span class="auth">(Ḳ, TA,)</span> or <span class="ar">بِيْعٌ</span>. <span class="auth">(Mṣb: <span class="add">[but this I think a mistake: if correct, it is a coll. gen. n.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayuwEN">
				<h3 class="entry"><span class="ar">بَيُوعٌ</span></h3>
				<div class="sense" id="bayuwEN_A1">
					<p><span class="ar">بَيُوعٌ</span>: <a href="#bayBiEN">see <span class="ar">بَيِّعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayaAEapN">
				<h3 class="entry"><span class="ar">بَيَاعَةٌ</span></h3>
				<div class="sense" id="bayaAEapN_A1">
					<p><span class="ar">بَيَاعَةٌ</span> <em>An article of merchandise;</em> <span class="auth">(Lth, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَيْعٌ↓</span></span> <span class="add">[q. v. suprà]</span>: <span class="auth">(Mgh:)</span> pl. of the former <span class="ar">بِيَاعَاتٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBiEN.1">
				<h3 class="entry"><span class="ar">بَيِّعٌ</span> / <span class="ar">بَيِّعَةٌ</span></h3>
				<div class="sense" id="bayBiEN.1_A1">
					<p><span class="ar">بَيِّعٌ</span>: <a href="#baAyiEN">see <span class="ar">بَائِعٌ</span></a>, in five places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بَيِّعٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayBiEN.1_A2">
					<p>Also A man <em>who sells,</em> or <em>buys, well;</em> and so<span class="arrow"><span class="ar">بَيُوعٌ↓</span></span>: fem. of the former with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَيِّعَةٌ</span>}</span></add>: pl. masc. <span class="ar">بَيِّعُونَ</span>, and pl. fem. <span class="ar">بَيِّعَاتٌ</span>; neither the masc. nor the fem. having a broken pl. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBaAEN">
				<h3 class="entry"><span class="ar">بَيَّاعٌ</span></h3>
				<div class="sense" id="bayBaAEN_A1">
					<p><span class="ar">بَيَّاعٌ</span> A man <em>who sells,</em> or <em>buys, much.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYiEN.1">
				<h3 class="entry"><span class="ar">بَائِعٌ</span></h3>
				<div class="sense" id="baAYiEN.1_A1">
					<p><span class="ar">بَائِعٌ</span> <em>Selling,</em> or <em>a seller:</em> and <em>buying,</em> or <em>a buyer:</em> <span class="auth">(Mṣb, Ḳ,* TA:)</span> as also<span class="arrow"><span class="ar">بَيِّعٌ↓</span></span>: <span class="auth">(Ḳ:)</span> the former signification is the more obvious when <span class="ar">بائع</span> is used without restriction: <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">بَيِّعٌ↓</span></span> also signifies <span class="add">[accord. to some]</span> <em>a bargainer,</em> or <em>chafferer;</em> <span class="auth">(Ḳ, TA;)</span> not a seller nor a buyer; but Esh-Sháfiʼee and Az deny that this epithet is applied to a man before he has concluded the contract: <span class="auth">(L, TA:)</span> <a href="#bAyE">the pl. of <span class="ar">بائع</span></a> is <span class="ar">بَاعَةٌ</span>: <span class="auth">(ISd, Ḳ:)</span> and the pl. of<span class="arrow"><span class="ar">بيّع↓</span></span> is <span class="ar">بِيَعَآءُ</span> <span class="add">[or rather this is a quasi-pl. n.]</span> and <span class="ar">أَبْيعَآءُ</span>: <span class="auth">(Ḳ:)</span> and Kr holds that <span class="ar">بَاعَةٌ</span> <a href="#byBE">is pl. of <span class="ar">بيّع</span></a>. <span class="auth">(TA.)</span> <span class="arrow"><span class="ar">البَيِّعَانِ↓</span></span> signifies <em>The seller and the buyer;</em> <span class="auth">(Ṣ, Mgh;)</span> and so<span class="arrow"><span class="ar">المُتَبَايِعَانِ↓</span></span>. <span class="auth">(TA.)</span> It is said in a trad.,<span class="arrow"><span class="ar long">البَيِّعَانِ↓ بِالخِيَارِ مَا لَمْ يَتَفَرَّقَا</span></span>, and in another,<span class="arrow"><span class="ar">المُتَبَايِعَانِ↓</span></span>, <span class="add">[<em>The seller and the buyer have the option</em> of cancelling the contract <em>as long as they have not separated.</em>]</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيع</span> - Entry: <span class="ar">بَائِعٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAYiEN.1_A2">
					<p><span class="ar long">اِمْرَأَةٌ بَائِعٌ</span> ‡ <em>A woman who easily obtains a suitor;</em> or <em>who is much in demand; by reason of her beauty:</em> <span class="auth">(Ḳ, TA:)</span> as though she sold herself: like <span class="ar long">نَاقَةٌ تَاجِرَةٌ</span>. <span class="auth">(Z, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabiyEN">
				<h3 class="entry"><span class="ar">مَبِيعٌ</span></h3>
				<div class="sense" id="mabiyEN_A1">
					<p><span class="ar">مَبِيعٌ</span> <em>Sold:</em> and <em>bought:</em> as also<span class="arrow"><span class="ar">مَبْيُوعٌ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> in the latter sense syn. with <span class="arrow"><span class="ar">مُبْتَاعٌ↓</span></span>. <span class="auth">(Mṣb.)</span> Kh says that the letter suppressed in <span class="ar">مَبِيعٌ</span> is the <span class="ar">و</span> of the measure <span class="ar">مَفْعُولٌ</span>, because it is augmentative: but Akh says that the letter suppressed is the medial radical; for when they made the <span class="ar">ى</span> quiescent, they transferred its vowel to the letter before it, so that it became madmoomeh, <span class="add">[the word thus being altered to <span class="ar">مَبُيْوعٌ</span>,]</span> then they changed the ḍammeh into kesreh because of the <span class="ar">ى</span> after it, then the <span class="ar">ى</span> was suppressed, and the <span class="ar">و</span> was changed into <span class="ar">ى</span>, like the <span class="ar">و</span> of <span class="ar">مِيزَانٌ</span>, because of the kesreh: accord. to El-Mázinee, each of these sayings is good; but that of Akh is the more agreeable with analogy. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboyuwEN">
				<h3 class="entry"><span class="ar">مَبْيُوعٌ</span></h3>
				<div class="sense" id="maboyuwEN_A1">
					<p><span class="ar">مَبْيُوعٌ</span>: <a href="#mabiyEN">see <span class="ar">مَبِيعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotaAEN">
				<h3 class="entry"><span class="ar">مُبْتَاعٌ</span></h3>
				<div class="sense" id="mubotaAEN_A1">
					<p><span class="ar">مُبْتَاعٌ</span>: <a href="#mabiyEN">see <span class="ar">مَبِيعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutabaAyiEN">
				<h3 class="entry"><span class="ar">مُتَبَايِعٌ</span></h3>
				<div class="sense" id="mutabaAyiEN_A1">
					<p><span class="ar">مُتَبَايِعٌ</span>: <a href="#baAyiEN">see <span class="ar">بَائِعٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0284.pdf" target="pdf">
							<span>Lanes Lexicon Page 284</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0285.pdf" target="pdf">
							<span>Lanes Lexicon Page 285</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
