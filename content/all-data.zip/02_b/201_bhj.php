<article class="root" id="Root_bhj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/200_bht">بهت</a></span>
				<span class="ar">بهج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/202_bhr">بهر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhj_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهج</span></h3>
				<div class="sense" id="bhj_1_A1">
					<p><span class="ar">بَهُجَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْهُجُ</span>}</span></add>, <span class="auth">(AZ, Ṣ, Mṣb, &amp;c.,)</span> inf. n. <span class="ar">بَهَاجَةٌ</span> <span class="auth">(AZ, Ṣ, L, Ḳ)</span> and <span class="ar">بَهْجَةٌ</span> <span class="auth">(AZ, L, <span class="add">[but some seem to regard this as a simple subst.,]</span>)</span> and <span class="ar">بَهَجَانٌ</span>, <span class="auth">(L,)</span> <em>He,</em> or <em>it, was,</em> or <em>became, beautiful,</em> or <em>goodly:</em> <span class="auth">(AZ, Ṣ, L, Mṣb, Ḳ:)</span> or <em>beautiful in colour:</em> or <em>beautiful and bright</em> or <em>splendid:</em> or <em>it</em> <span class="auth">(a plant)</span> <em>was,</em> or <em>became, beautiful and bright;</em> and <em>he</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, characterized by a laughing,</em> or <em>happy, appearance of the beautiful parts of the face, as the cheeks, and the lines of the forehead:</em> or <em>by the appearance of joy, gladness,</em> or <em>happiness;</em> or <em>by a joyful, glad,</em> or <em>happy, aspect,</em> or <em>appearance.</em> <span class="auth">(L.)</span> You say also, <span class="ar long">بَهِجَ النَّبَاتُ</span>, with kesr, meaning † <em>The plant,</em> or <em>herbage, was,</em> or <em>became, beautiful</em> <span class="add">[&amp;c.]</span>. <span class="auth">(TA, <span class="add">[but this is probably a tropical signification, from <span class="ar">بَهِجَ</span> in the sense here following.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhj_1_A2">
					<p><span class="ar">بَهِجَ</span>, <span class="auth">(Ṣ, A, L, Ḳ,)</span> with kesr, <span class="auth">(Ṣ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَجُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَهَجٌ</span>; <span class="auth">(L;)</span> and<span class="arrow"><span class="ar">ابتهج↓</span></span>; <span class="auth">(Ṣ, A, L, Mṣb, Ḳ;)</span> <em>He was,</em> or <em>became, joyful, glad,</em> or <em>happy.</em> <span class="auth">(Ṣ, A, L, Mṣb, Ḳ.)</span> You say, <span class="ar long">بَهِجَ بِهِ</span>, <span class="auth">(Ṣ, A,)</span> and <span class="ar">لَهُ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar long">ابتهج↓ بِهِ</span></span>; <span class="auth">(A, Mṣb;)</span> <em>He rejoiced in it,</em> or <em>at it;</em> or <em>became rejoiced by it,</em> or <em>at it.</em> <span class="auth">(Ṣ, A, Mṣb, TA.)</span> <span class="add">[<a href="#bhj_10">See also 10</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهج</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhj_1_B1">
					<p><span class="ar">بَهَجَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَجُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">ابهج↓</span></span>; <span class="auth">(Ṣ, A, Ḳ;)</span> the latter of which is the more approved; <span class="auth">(TA;)</span> <em>It</em> <span class="auth">(a thing, TA, or an affair or event, Ṣ, A)</span> <em>rejoiced;</em> or <em>made joyful, glad,</em> or <em>happy;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> a person. <span class="auth">(Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhj_2">
				<h3 class="entry">2. ⇒ <span class="ar">بهّج</span></h3>
				<div class="sense" id="bhj_2_A1">
					<p><span class="ar">بهّج</span>, <span class="auth">(ISd, L,)</span> inf. n. <span class="ar">تَبْهِيجٌ</span>, <span class="auth">(Ḳ,)</span> <em>He beautified; rendered beautiful,</em> or <em>goodly.</em> <span class="auth">(ISd, L, Ḳ.)</span> ISd says, I have not heard this, except in the saying of El-ʼAjjáj,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">دَعْ ذَا وَبَهِّجْ حَسَبًا مُبَهَّجَا</span> *</div> 
					</blockquote>
					<p>as though meaning <span class="add">[<em>Leave thou this</em> subject, <em>and</em>]</span> <em>beautify,</em> or <em>adorn,</em> the more this <em>nobility</em> <span class="add">[<em>already beautified,</em> or <em>adorned,</em>]</span> <em>by thy describing it.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhj_3">
				<h3 class="entry">3. ⇒ <span class="ar">باهج</span></h3>
				<div class="sense" id="bhj_3_A1">
					<p><span class="ar">بَاهجهُ</span>, <span class="auth">(A, Ḳ,)</span> inf. n. <span class="ar">مُبَاهَجَةٌ</span>, <span class="auth">(A,)</span> <em>He vied,</em> or <em>competed, with him,</em> or <em>contended with him for superiority, in beauty,</em> or <em>goodliness;</em> <span class="add">[as expl. in the TḲ; or <em>in glory,</em> or <em>excellence;</em>]</span> syn. <span class="ar">بَاهَاهُ</span> <span class="auth">(A, Ḳ)</span> and <span class="ar">بَارَاهُ</span>, <span class="auth">(Ḳ,)</span> both of these meaning the same. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhj_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابهج</span></h3>
				<div class="sense" id="bhj_4_A1">
					<p><a href="#bhj_1">see 1</a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهج</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhj_4_A2">
					<p><span class="ar long">أَبْهَجَتِ الأَرْضُ</span> <em>The land,</em> or <em>earth, became beautiful,</em> or <em>goodly,</em> <span class="auth">(Ṣ, L, Ḳ,)</span> or <em>beautiful and bright</em> or <em>splendid,</em> <span class="auth">(L,)</span> <em>in its plants,</em> or <em>herbage.</em> <span class="auth">(Ṣ, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhj_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباهج</span></h3>
				<div class="sense" id="bhj_6_A1">
					<p><span class="ar long">تباهج الرَّوْضُ</span> † <em>The meadows,</em> or <em>gardens, became abundant in blossoms</em> or <em>flowers</em> <span class="add">[<em>as though vying, one with another, in beauty,</em> or <em>goodliness:</em> <a href="#bhj_3">see 3</a>]</span>. <span class="auth">(Ḳ, TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhj_8">
				<span class="pb" id="Page_0265"></span>
				<h3 class="entry">8. ⇒ <span class="ar">ابتهج</span></h3>
				<div class="sense" id="bhj_8_A1">
					<p><a href="#bhj_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhj_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبهج</span></h3>
				<div class="sense" id="bhj_10_A1">
					<p><span class="ar">استبهج</span> <em>i. q.</em> <span class="ar">اِسْتَبْشَرَ</span> <span class="add">[i. e. <em>He rejoiced,</em> or <em>became rejoiced;</em> <span class="ar">بِهِ</span> <em>at it,</em> or <em>by it;</em> or <em>at,</em> or <em>by, the annunciation of it</em>]</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#bahija">See also <span class="ar">بَهِجَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bahojN">
				<h3 class="entry"><span class="ar">بَهْجٌ</span> / <span class="ar">بَهْجَةٌ</span></h3>
				<div class="sense" id="bahojN_A1">
					<p><span class="ar">بَهْجٌ</span> and its fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَهْجَةٌ</span>}</span></add>: <a href="#bahiyjN">see <span class="ar">بَهِيجٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahijN">
				<h3 class="entry"><span class="ar">بَهِجٌ</span></h3>
				<div class="sense" id="bahijN_A1">
					<p><span class="ar">بَهِجٌ</span> <em>Joyful, glad,</em> or <em>happy;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَهِيجٌ↓</span></span> <span class="auth">(Ṣ, A, Ḳ)</span> and<span class="arrow"><span class="ar">مُبْتَهِجٌ↓</span></span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهج</span> - Entry: <span class="ar">بَهِجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahijN_A2">
					<p><a href="#bahiyjN">See also <span class="ar">بَهِيجٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahojapN">
				<h3 class="entry"><span class="ar">بَهْجَةٌ</span></h3>
				<div class="sense" id="bahojapN_A1">
					<p><span class="ar">بَهْجَةٌ</span> <em>Beauty,</em> or <em>goodliness:</em> <span class="auth">(Ṣ, A, L, Mṣb, Ḳ:)</span> or <em>beauty of colour</em> of a thing: or its <em>beauty and brightness</em> or <em>splendour:</em> or in plants or herbage, <em>beauty and brightness</em> or <em>splendour;</em> and in a man, the <em>laughing,</em> or <em>happy, appearance of the beautiful parts of the face, as the cheeks, and the lines of the forehead:</em> or the <em>appearance of joy, gladness,</em> or <em>happiness;</em> or <em>joyfulness, gladness,</em> or <em>happiness, of aspect</em> or <em>appearance.</em> <span class="auth">(L.)</span> You say <span class="ar long">رَوْضَةٌ ذَاتُ بَهْجَةٍ غَالِبَةٍ</span> <span class="add">[<em>A meadow,</em> or <em>garden, of surpassing beauty,</em>, &amp;c.]</span>. <span class="auth">(A.)</span> And <span class="ar long">رَجُلٌ ذُو بَهْجَةٍ</span> <em>A man possessed of beauty,</em> or <em>goodliness:</em> <span class="auth">(Ṣ:)</span> or <em>of beauty and brightness,</em>, &amp;c. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهج</span> - Entry: <span class="ar">بَهْجَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahojapN_A2">
					<p>Also <em>Happiness, joy,</em> or <em>gladness.</em> <span class="auth">(Ḥam p. 403.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahiyjN">
				<h3 class="entry"><span class="ar">بَهِيجٌ</span></h3>
				<div class="sense" id="bahiyjN_A1">
					<p><span class="ar">بَهِيجٌ</span> <em>Beautiful,</em> or <em>goodly;</em> <span class="auth">(Ṣ, A, L, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَهِجٌ↓</span></span> <span class="auth">(Ḥam p. 403)</span> and<span class="arrow"><span class="ar">بَهْجٌ↓</span></span>: <span class="auth">(AZ, TA:)</span> or <em>beautiful in colour:</em> or <em>beautiful and bright</em> or <em>splendid:</em> or, applied to a plant, it has this last meaning; and, applied to a man, <em>characterized by a laughing,</em> or <em>happy, appearance of the beautiful parts of the face, as the cheeks, and the lines of the forehead:</em> or <em>characterized by the appearance of joy, gladness,</em> or <em>happiness; having a joyful, glad,</em> or <em>happy, aspect</em> or <em>appearance:</em> <span class="auth">(L:)</span> the fem. epithet is <span class="arrow"><span class="ar">مِبْهَاجٌ↓</span></span>. <span class="auth">(A, Ḳ, TA: <span class="add">[in the CK <span class="ar">مَبْهاجٌ</span>.]</span>)</span> It is applied to a plant, or herbage, <span class="auth">(Ṣ, A,)</span> in the Ḳur xxii. 5 and l. 7. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar">مِبْهَاجٌ↓</span></span> is applied to a woman, as meaning One <em>in whom beauty,</em> or <em>goodliness,</em>, &amp;c., <em>predominates;</em> <span class="auth">(L, TA;)</span> as also<span class="arrow"><span class="ar">بَهْجَةٌ↓</span></span>; <span class="auth">(TA;)</span> pl. of the former, <span class="ar">مَبَاهِيجُ</span>: <span class="auth">(A, TA:)</span> and to a camel's hump, meaning ‡ <em>fat;</em> <span class="auth">(A, Ḳ;)</span> because beauty, or goodliness, is combined <span class="add">[in this case]</span> with fatness; pl. as above. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهج</span> - Entry: <span class="ar">بَهِيجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahiyjN_A2">
					<p><a href="#bahijN">See also <span class="ar">بَهِجٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibohaAjN">
				<h3 class="entry"><span class="ar">مِبْهَاجٌ</span></h3>
				<div class="sense" id="mibohaAjN_A1">
					<p><span class="ar">مِبْهَاجٌ</span>: <a href="#bahiyjN">see <span class="ar">بَهِيجٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotahijN">
				<h3 class="entry"><span class="ar">مُبْتَهِجٌ</span></h3>
				<div class="sense" id="mubotahijN_A1">
					<p><span class="ar">مُبْتَهِجٌ</span>: <a href="#bahijN">see <span class="ar">بَهِجٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0264.pdf" target="pdf">
							<span>Lanes Lexicon Page 264</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0265.pdf" target="pdf">
							<span>Lanes Lexicon Page 265</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
