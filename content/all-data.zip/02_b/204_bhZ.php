<article class="root" id="Root_bhZ">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/203_bhrj">بهرج</a></span>
				<span class="ar">بهظ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/205_bhq">بهق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhZ_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهظ</span></h3>
				<div class="sense" id="bhZ_1_A1">
					<p><span class="ar">بَهَظَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَظُ</span>}</span></add>, inf. n. <span class="ar">بَهْظٌ</span>, <em>It</em> <span class="auth">(a load, or burden,)</span> <em>oppressed him by its weight, and he was unable to bear it:</em> <span class="auth">(Ṣ, M, TA:)</span> or <em>pressed heavily upon him, and distressed him.</em> <span class="auth">(T, TA.)</span> <span class="add">[And hence,]</span> ‡ <em>It</em> <span class="auth">(an affair, M, Ḳ, or anything, T)</span> <em>oppressed him by its weight,</em> <span class="auth">(T, M,)</span> <em>and he was unable to bear it:</em> <span class="auth">(M:)</span> or <em>overpowered him, and pressed heavily upon him, and distressed him;</em> <span class="auth">(Jm, Ḳ;)</span> and so <span class="ar">بَهَضَهُ</span>, as heard by Aboo-Turáb from an Arab of the desert; but no one has followed him in this. <span class="auth">(Az, TA.)</span> You say also, <span class="ar long">بَهَظَ الرَّاحِلَةَ</span> <em>He loaded the riding-camel heavily, and fatigued it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhiZN">
				<h3 class="entry"><span class="ar">بَاهِظٌ</span></h3>
				<div class="sense" id="baAhiZN_A1">
					<p><span class="ar long">أَمْرٌ بَاهِظٌ</span> <em>A distressing, grievous,</em> or <em>difficult, affair.</em> <span class="auth">(Ṣ, CK, but wanting in two MṢ. copies of the Ḳ.)</span> And <span class="ar">بَاهِظٌ</span> <span class="add">[alone]</span>, <span class="auth">(CK, but wanting in two MṢ. copies of the Ḳ,)</span> or<span class="arrow"><span class="ar">بَاهِظَةٌ↓</span></span>, <span class="auth">(O, TA,)</span> ‡ <em>A calamity,</em> or <em>misfortune.</em> <span class="auth">(O, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAhiZapN">
				<h3 class="entry"><span class="ar">بَاهِظَةٌ</span></h3>
				<div class="sense" id="baAhiZapN_A1">
					<p><span class="ar">بَاهِظَةٌ</span>: <a href="#baAhiZN">see <span class="ar">بَاهِظٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabohuwZN">
				<h3 class="entry"><span class="ar">مَبْهُوظٌ</span></h3>
				<div class="sense" id="mabohuwZN_A1">
					<p><span class="ar">مَبْهُوظٌ</span> <em>Oppressed by the weight of a load, and unable to bear it.</em> <span class="auth">(Ṣ.)</span> <span class="add">[And hence,]</span> † Any one <em>having a thing required of him which he is unable to do,</em> or <em>which he cannot find.</em> <span class="auth">(TA.)</span> And <span class="ar long">قِرْنٌ مَبْهُوظٌ</span> † <em>An opponent,</em> or <em>an adversary, overcome,</em> or <em>vanquished.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0267.pdf" target="pdf">
							<span>Lanes Lexicon Page 267</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
