<article class="root" id="Root_bht">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/199_bhO">بهأ</a></span>
				<span class="ar">بهت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/201_bhj">بهج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bht_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهت</span></h3>
				<div class="sense" id="bht_1_A1">
					<p><span class="ar">بُهِتَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> the most chaste form of the verb in the sense here following, <span class="auth">(Ṣ, TA,)</span> and that which most commonly obtains, and the only form allowed by Th and IḲt; <span class="auth">(TA;)</span> and <span class="ar">بَهِتَ</span>, <span class="auth">(Ṣ, L, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَتُ</span>}</span></add>; <span class="auth">(Mṣb, Ḳ;)</span> and <span class="ar">بَهُتَ</span>, <span class="auth">(Ṣ, L, Mṣb, Ḳ,)</span> in which the ḍammeh is said to give intensiveness to the signification, as in <span class="ar long">قَضُوَ الرَّجُلُ</span>, <span class="auth">(TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْهُتُ</span>}</span></add>; <span class="auth">(Mṣb, Ḳ;)</span> and <span class="ar">بَهَتَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْهُتُ</span>}</span></add> <span class="auth">(Ḳ)</span> and <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَتُ</span>}</span></add>; <span class="auth">(TA;)</span> inf. n. <span class="ar">بَهْتٌ</span>; <span class="auth">(JK, Ḳ;)</span> <em>He was,</em> or <em>became, confounded, perplexed,</em> or <em>amazed, and unable to see his right course;</em> <span class="auth">(JK, Ṣ, Mṣb, Ḳ;)</span> <em>not knowing what to prefer nor what to postpone:</em> <span class="auth">(TA in art. <span class="ar">اشر</span>:)</span> <em>he looked</em> at a thing that he saw <em>with a look of wonder:</em> <span class="auth">(A, TA:)</span> <em>he was,</em> or <em>became, affected with wonder:</em> <span class="auth">(JK:)</span> <em>he was,</em> or <em>became, cut short,</em> (<span class="ar">انْقَطَعَ</span>, Ḳ, TA,) <em>and was silent, being confounded,</em> or <em>perplexed, and unable to see his right course:</em> <span class="auth">(TA:)</span> <em>he</em> <span class="auth">(an adversary in a dispute or litigation)</span> <em>was overcome by an argument, an allegation,</em> or <em>a plea.</em> <span class="auth">(L.)</span> All these forms occur in different readings of the saying in the Ḳur <span class="add">[ii. 260]</span>, <span class="ar long">فَبُهِتَ ٱلَّذِى كَفَرَ</span> and <span class="ar">فَبَهِتَ</span>, &amp;c., <span class="auth">(IJ, TA,)</span> explained in the Wáʼee as meaning, <em>And he who disbelieved remained in confusion,</em> or <em>perplexity, not seeing his right course, looking as one in wonder:</em> <span class="auth">(Lb, TA:)</span> but accord. to him who reads <span class="ar">فَبَهَتَ</span>, the word <span class="ar">الذى</span> may hold the place of a noun in the accus. case <span class="add">[as will be seen from what follows]</span>. <span class="auth">(IJ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bht_1_B1">
					<p><span class="ar">بَهَتَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَتُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">بَهْتٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He,</em> or <em>it, caused him to become confounded, perplexed,</em> or <em>amazed, not seeing his right course:</em> <span class="auth">(Zj, Mṣb: <span class="add">[Golius, on the authority of Ibn-Maạroof, assigns this meaning to <span class="arrow"><span class="ar">بهّتهُ↓</span></span>:]</span>)</span> or <em>took him unawares,</em> or <em>by surprise,</em> or <em>unexpectedly,</em> or <em>suddenly.</em> <span class="auth">(Ṣ, Ḳ.)</span> Zj cites as an ex. of the former meaning the saying in the Ḳur <span class="add">[xxi. 41]</span>, <span class="ar long">تَأْتِيهِمْ بَغْتَةً فَتَبْهَتُهُمْ</span>, i. e., <em>It shall come upon them suddenly,</em> or <em>unawares, and cause them to become confounded,</em>, &amp;c.: <span class="auth">(TA: and so Bḍ and Jel explain it:)</span> or, <em>and shall overcome them:</em> <span class="auth">(Bḍ:)</span> J cites the same as an ex. of the latter of the two meanings in the preceding sentence; but his doing so requires consideration; for the meaning which he gives is taken from the word <span class="ar">بغتة</span>; not from <span class="ar">البَهْتُ</span>. <span class="auth">(MF, TA.)</span> <span class="add">[But it is said also that]</span> <span class="ar">مُبَاهَتَةٌ</span> <span class="add">[inf. n. of <span class="arrow"><span class="ar">باهتهُ↓</span></span>]</span> signifies The <em>taking,</em> or <em>coming upon,</em> <span class="add">[one]</span> <em>unawares, by surprise,</em> or <em>unexpectedly.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bht_1_B2">
					<p><span class="ar">بَهَتَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَتُ</span>}</span></add>, <span class="auth">(Ṣ, A, Ḳ, &amp;c.,)</span> inf. n. <span class="ar">بَهْتٌ</span> and <span class="ar">بَهَتٌ</span> and <span class="ar">بُهْتَانٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or the last is a simple subst., <span class="auth">(Mṣb,)</span> <em>He calumniated him; slandered him; accused him falsely; said against him that which he had not done:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> <span class="add">[or <em>he did so in such a manner as to make one to be confounded,</em> or <em>perplexed,</em> or <em>amazed, at the falsity of the charge, and not to see his right course:</em> (<a href="#buhotaAnN">see <span class="ar">بُهْتَانٌ</span>, below</a>:)]</span> <span class="pb" id="Page_0264"></span><em>he lied against him; forged a lie,</em> or <em>lies, against him;</em> and <em>i. q.</em> <span class="ar long">قَابَلَهُ بِالكَذِبِ</span> <span class="add">[<em>he accused him to his face falsely,</em> or <em>with falsehood</em>]</span>; <span class="auth">(TA;)</span> <span class="ar">البَهْتُ</span> signifies <span class="ar long">اِسْتِقْبَالُكَ أَخَاكَ بِمَا لَيْسَ فِيهِ</span> <span class="add">[<em>thy accusing thy brother,</em> or <em>fellow, to his face, of that which is not in him</em>]</span>: <span class="auth">(JK:)</span> and <span class="ar">بَهَتَهَا</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَتُ</span>}</span></add>, inf. n. <span class="ar">بَهْتٌ</span>, <em>he accused her falsely of adultery; and forged a lie against her.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#gyb_8">See also <span class="ar">اِغْتَابَهُ</span></a>.]</span> <em>In the saying of Abu-n-Nejm,</em></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">سُبِّى الحَمَاةَ وَٱبْهَتِى عَلَيْهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Revile thou the mother-in-law, and calumniate her,</em> or <em>forge lies against her</em>]</span>, <span class="ar">على</span> is <span class="add">[said by J to be]</span> redundant, or pleonastic; for one does not say, <span class="ar long">بَعَتَ عَلَيْهِ</span>, but only <span class="ar">بَهَتَهُ</span>. <span class="auth">(Ṣ.)</span> Upon this, F says, in the Ḳ, that <span class="ar long">فَٱبْهَتِى عليها</span> <span class="add">[thus in the Ḳ]</span> is a mistake; that J is in error, and that the right reading is <span class="ar long">فَٱنْهَتِى عليها</span>, with <span class="ar">ن</span>: but this assertion made by F depends upon the authority of relaters of the verse in which the word in question occurs. <span class="auth">(MF.)</span> IB says that <span class="ar">ابهتى</span> may be here rendered trans. by means of <span class="ar">على</span> because it is syn. with <span class="ar">اِفْتَرِى</span>, which is so rendered trans., in like manner as is done in other instances, of which he gives an ex. from the Ḳur <span class="add">[xxiv. 63]</span>, <span class="ar long">يُخَالِفُونَ عَنْ أَمْرِهِ</span>, meaning <span class="ar long">يَخْرُجُونَ عن امره</span>: he adds that, accord. to J, <span class="ar">عن</span> in this ex. should be considered redundant; but that <span class="ar">عن</span> and <span class="ar">على</span> are not used redundantly like <span class="ar">ب</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bht_1_B3">
					<p><span class="ar long">بَهَتَ الفَحْلَ عَنِ النَّاقَةِ</span> <em>He removed the stallion from the she-camel in order that a stallion of more generous race might cover her.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bht_2">
				<h3 class="entry">2. ⇒ <span class="ar">بهّت</span></h3>
				<div class="sense" id="bht_2_A1">
					<p><a href="#bht_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bht_3">
				<h3 class="entry">3. ⇒ <span class="ar">باهت</span></h3>
				<div class="sense" id="bht_3_A1">
					<p><span class="ar">باهتهُ</span>, inf. n. <span class="ar">مُبَاهَتَةٌ</span>: <a href="#bht_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bht_3_A2">
					<p><span class="add">[Also <em>He engaged with him in mutual calumny, slander,</em> or <em>false accusation:</em> a meaning indicated, but not expressed, in the A.]</span> You say, <span class="ar long">بَيْنَهُمَا مُبَاهَتَةٌ</span> <span class="add">[<em>Between them two is mutual calumniation,</em>, &amp;c.]</span>: and <span class="ar long">عَادَتُهُ أَنْ يُبَاحِثَ وَيُبَاهِتَ</span> <span class="add">[<em>His custom is to engage with another in mutual scrutiny</em> of secrets, or faults, or the like, <em>and in mutual calumniation,</em>, &amp;c.]</span>: and<span class="arrow"><span class="ar long">لَا تَبَاهَتُوا↓ وَلَا تَمَاقَتُوا</span></span> <span class="add">[<em>Calumniate ye not one another,</em>, &amp;c., <em>nor hate ye one another on account of any foul,</em> or <em>evil, affair</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bht_3_A3">
					<p>And <em>He confounded, perplexed,</em> or <em>amazed, him</em> <span class="auth">(namely, his hearer,)</span> <em>by what he forged against him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bht_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباهت</span></h3>
				<div class="sense" id="bht_6_A1">
					<p><a href="#bht_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahotN">
				<h3 class="entry"><span class="ar">بَهْتٌ</span></h3>
				<div class="sense" id="bahotN_A1">
					<p><span class="ar">بَهْتٌ</span>: <a href="#buhotaAnN">see <span class="ar">بُهْتَانٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: <span class="ar">بَهْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bahotN_B1">
					<p><em>A certain well-known kind of stone.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhotN">
				<h3 class="entry"><span class="ar">بُهْتٌ</span></h3>
				<div class="sense" id="buhotN_A1">
					<p><span class="ar">بُهْتٌ</span>: <a href="#buhotaAnN">see <span class="ar">بُهْتَانٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: <span class="ar">بُهْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buhotN_B1">
					<p><em>A certain sidereal computation,</em> or <em>calculation;</em> being <span class="add">[that of]</span> <em>the direct course of stars in a day:</em> <span class="add">[in Persian, <em>a planet's motion in any given time:</em> <span class="auth">(Johnson's Pers. Arab. and Engl. Dict.:)</span>]</span> thought by Az to be not Arabic. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhotaAnN">
				<h3 class="entry"><span class="ar">بُهْتَانٌ</span></h3>
				<div class="sense" id="buhotaAnN_A1">
					<p><span class="ar">بُهْتَانٌ</span> and<span class="arrow"><span class="ar">بَهِيتَةٌ↓</span></span> signify the same <span class="add">[when the former is used as a subst.; i. e. <em>A calumny, slander,</em> or <em>false accusation</em>]</span>: <span class="auth">(Ṣ, A, Mṣb: <span class="add">[<a href="#bht_1">see 1</a>:]</span>)</span> or both signify, the former as explained by Aboo-Is-ḥáḳ, and the latter as explained in the Ḳ, <em>a falsehood by reason of which one is confounded,</em> or <em>perplexed, and unable to see his right course;</em> <span class="auth">(TA; <span class="add">[in which it seems to be indicated that <span class="arrow"><span class="ar">بُهْتٌ↓</span></span> signifies the same;]</span>)</span> from <span class="ar">البَهْتُ</span> as meaning “the being confounded”, &amp;c.: <span class="auth">(Aboo-Is-ḥáḳ, TA:)</span> the former is a subst. signifying <span class="add">[also]</span> <em>a false accusation of adultery</em> against a woman; and <em>a forgery of a lie</em> against her: <span class="auth">(Mṣb:)</span> and<span class="arrow">↓</span> the latter, <span class="add">[and the former also, simply,]</span> <em>a lying,</em> or <em>lie,</em> or <em>falsehood;</em> <span class="auth">(Ḳ;)</span> and so<span class="arrow"><span class="ar">بُهْتٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">بَهْتٌ↓</span></span>. <span class="auth">(TA.)</span> <span class="ar long">بُهْتَانًا وَإِثْمًا مُبِينًا</span>, in the Ḳur iv. 24, is said to mean <em>Falsely accusing of adultery, and acting in a manifestly sinful</em> or <em>criminal manner:</em> <span class="auth">(Bḍ:)</span> or it means <em>acting wrongfully</em>, &amp;c. <span class="auth">(Bḍ, Jel.)</span> You say,<span class="arrow"><span class="ar long">رَمَاهُ بِالبَهِيتَةِ↓</span></span> <span class="add">[<em>He accused him with,</em> or <em>of, calumny,</em>, &amp;c.]</span>. <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">يَا ِللْبَهِيتَةِ↓</span></span>, with kesr to the <span class="add">[prep.]</span> <span class="ar">ل</span>, <span class="add">[i. e., <em>O,</em> come to my aid, or succour, <em>on account of the calumny!</em>, &amp;c.; for it is]</span> a phrase used in calling for aid, or succour. <span class="auth">(Ṣ.)</span> <span class="add">[And if you would express wonder, you say, <span class="arrow"><span class="ar long">يَا َللْبَهِيتَةِ↓</span></span>, with fet-ḥ to the prep. <span class="ar">ل</span>, i. e. <em>O the calumny!</em>, &amp;c.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahuwtN">
				<h3 class="entry"><span class="ar">بَهُوتٌ</span></h3>
				<div class="sense" id="bahuwtN_A1">
					<p><span class="ar">بَهُوتٌ</span> <span class="add">[<em>A great,</em> or <em>frequent, calumniator, slanderer,</em> or <em>false-accuser;</em> as also<span class="arrow"><span class="ar">بَهَّاتٌ↓</span></span>, mentioned in the Ṣ only as an epithet applied to him <em>who calumniates, slanders,</em> or <em>accusely falsely;</em>]</span> an intensive epithet from <span class="ar">البَهْتُ</span>; <span class="auth">(IAth;)</span> <span class="add">[i. e.]</span> an intensive form of the act. part. n. from <span class="ar">البُهْتَان</span> <span class="add">[<a href="#bht_1">inf. n. of <span class="ar">بَهَتَهُ</span></a>]</span>: <span class="auth">(Mgh:)</span> or <em>i. q.</em><span class="arrow"><span class="ar">مُبَاهِتٌ↓</span></span>; <span class="auth">(Ḳ;)</span> i. e., one <em>who confounds,</em> or <em>perplexes,</em> or <em>amazes, the hearer, by what he forges against him:</em> <span class="auth">(TA:)</span> and one <em>who falsely accuses a woman of adultery, and forges a lie against her:</em> <span class="auth">(Mṣb:)</span> pl. <span class="ar">بُهُتٌ</span> <span class="auth">(IAth, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بُهْتٌ</span>, and, accord. to the Ḳ, also <span class="ar">بُهُوتٌ</span>; but ISd and MF hold it to be <a href="#baAhitN">pl. of <span class="ar">بَاهِتٌ</span></a>, not of <span class="ar">بَهُوتٌ</span>; the former observing, that a word of the measure <span class="ar">فَاعِلٌ</span> is one of those which have a pl. of the measure <span class="ar">فُعُولٌ</span>, but not so one of the measure <span class="ar">فَعُولٌ</span>; and that, as to the saying of AʼObeyd, that <span class="ar">عُذُوبٌ</span> <a href="#EacuwbN">is pl. of <span class="ar">عَذُوبٌ</span></a>, it is a mistake; for it is only <a href="#EaAcibN">pl. of <span class="ar">عَاذِبٌ</span></a>, and <a href="#EacuwbN">the pl. of <span class="ar">عَذُوبٌ</span></a> is <span class="ar">عُذُبٌ</span>. <span class="auth">(TA. <span class="add">[<a href="index.php?data=18_E/048_Ecb">But see art. <span class="ar">عذب</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bahiytN">
				<h3 class="entry"><span class="ar">بَهِيتٌ</span></h3>
				<div class="sense" id="bahiytN_A1">
					<p><span class="ar">بَهِيتٌ</span>, <a href="#mabohuwtN">see <span class="ar">مَبْهُوتٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bahiytapN">
				<h3 class="entry"><span class="ar">بَهِيتَةٌ</span></h3>
				<div class="sense" id="bahiytapN_A1">
					<p><span class="ar">بَهِيتَةٌ</span>: <a href="#buhotaAnN">see <span class="ar">بُهْتَانٌ</span></a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bahBaAtN">
				<h3 class="entry"><span class="ar">بَهَّاتٌ</span></h3>
				<div class="sense" id="bahBaAtN_A1">
					<p><span class="ar">بَهَّاتٌ</span>: <a href="#bahuwtN">see <span class="ar">بَهُوتٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: <span class="ar">بَهَّاتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bahBaAtN_B1">
					<p><a href="#mabohuwtN">and see <span class="ar">مَبْهُوتٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhitN">
				<h3 class="entry"><span class="ar">بَاهِتٌ</span></h3>
				<div class="sense" id="baAhitN_A1">
					<p><span class="ar">بَاهِتٌ</span>: <a href="#mabohuwtN">see <span class="ar">مَبْهُوتٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: <span class="ar">بَاهِتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAhitN_B1">
					<p>Also act. part. n. <span class="add">[of <span class="ar">بَهَتَهُ</span>; signifying <em>Causing to become confounded,</em>, &amp;c.: and <em>calumniating,</em>, &amp;c.:]</span> from <span class="ar">البُهْتَانُ</span>: <span class="auth">(Mgh:)</span> <span class="ar">بُهُوتٌ</span>, as mentioned above, is held by ISd and MF to be a pl. of this word; not of <span class="ar">بَهُوتٌ</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabohuwtN">
				<h3 class="entry"><span class="ar">مَبْهُوتٌ</span></h3>
				<div class="sense" id="mabohuwtN_A1">
					<p><span class="ar">مَبْهُوتٌ</span> <em>Confounded, perplexed,</em> or <em>amazed, and unable to see his right course:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[other <span class="auth">(similar)</span> meanings may be seen from explanations of <span class="ar">بُهِتَ</span>:]</span> accord. to Ks and the Ṣ and Ṣgh and the Ḳ, one should not say <span class="arrow"><span class="ar">بَاهِتٌ↓</span></span> nor<span class="arrow"><span class="ar">بَهِيتٌ↓</span></span>; but there is no reason in analogy why he who says <span class="ar">بَهَتَ</span>, like <span class="ar">نَصَرَ</span> and <span class="ar">مَنَعَ</span>, should not say thus: <span class="auth">(TA:)</span> Lb says, in the Expos. of the Fṣ, that they said <span class="arrow"><span class="ar">بَاهِتٌ↓</span></span> and<span class="arrow"><span class="ar">بَهَّاتٌ↓</span></span> <span class="add">[which latter is an intensive form]</span> and<span class="arrow"><span class="ar">بَهِيتٌ↓</span></span>, which <span class="add">[last]</span> may be considered as having the meaning of the measure <span class="ar">مَفْعُولٌ</span>, like <span class="ar">مَبْهُوتٌ</span>, or that of the measure <span class="ar">فَاعِلٌ</span>, like <span class="ar">بَاهِتٌ</span>; but the former is the more agreeable with analogy, and the more probable. <span class="auth">(MF, TA)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهت</span> - Entry: <span class="ar">مَبْهُوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mabohuwtN_A2">
					<p>Also <em>Calumniated, slandered,</em> or <em>falsely accused.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubaAhitN">
				<h3 class="entry"><span class="ar">مُبَاهِتٌ</span></h3>
				<div class="sense" id="mubaAhitN_A1">
					<p><span class="ar">مُبَاهِتٌ</span>: <a href="#bahuwtN">see <span class="ar">بَهُوتٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0263.pdf" target="pdf">
							<span>Lanes Lexicon Page 263</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0264.pdf" target="pdf">
							<span>Lanes Lexicon Page 264</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
