<article class="root" id="Root_bdn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/045_bdl">بدل</a></span>
				<span class="ar">بدن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/047_bdh">بده</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bdn_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدن</span></h3>
				<div class="sense" id="bdn_1_A1">
					<p><span class="ar">بَدُنَ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُنُ</span>}</span></add>; <span class="auth">(T, Ṣ;)</span> and <span class="ar">بَدَنَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُنُ</span>}</span></add>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> <span class="pb" id="Page_0169"></span>inf. n. <span class="ar">بَدَانَةٌ</span> <span class="auth">(T, Ṣ, M, &amp;c.,)</span> of the former, <span class="auth">(ISk, T, Ṣ, &amp;c.,)</span> and <span class="ar">بُدْنٌ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> also of the former, <span class="auth">(ISk, T,)</span> or of the latter, <span class="auth">(Ṣ,)</span> and <span class="ar">بَدْنٌ</span>, <span class="auth">(M, Ḳ,)</span> accord. to AZ, <span class="auth">(T,)</span> and <span class="ar">بَدَانٌ</span>, <span class="auth">(M, Ḳ,)</span> or <span class="ar">بُدُونٌ</span> is the inf. n. of the latter verb; <span class="auth">(Mṣb;)</span> said of a man, <span class="auth">(ISk, T, Ṣ,)</span> and of a camel; <span class="auth">(Mṣb;)</span> and <span class="ar">بَدُنَتْ</span> and <span class="ar">بَدَنَتْ</span>, said of a woman, <span class="auth">(AZ, T, M, Ḳ,)</span> and of a <span class="ar">بَدَنَة</span>, q. v.; <span class="auth">(Zj, T, &amp;c.;)</span> <em>He,</em> and <em>she, was,</em> or <em>became, big, bulky, big-bodied,</em> or <em>corpulent;</em> <span class="auth">(ISk, T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> <em>abounding in flesh;</em> <span class="auth">(T;)</span> <em>fat:</em> <span class="auth">(Zj, T, M:)</span> or the former verb has this last signification, that of fatness; and the latter verb is syn. with <span class="ar">بَدَّنَ</span> q. v. <span class="auth">(Ḥam p. 158.)</span> <span class="add">[<a href="#budonN">See also <span class="ar">بُدْنٌ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdn_2">
				<h3 class="entry">2. ⇒ <span class="ar">بدّن</span></h3>
				<div class="sense" id="bdn_2_A1">
					<p><span class="ar">بدّن</span>, inf. n. <span class="ar">تَبْدِينٌ</span>, <em>He</em> <span class="auth">(a man, T, Ṣ, M)</span> <em>was,</em> or <em>became, aged,</em> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> <em>and weak:</em> <span class="auth">(M, Ḳ:)</span> or <em>he was, or became, heavy by reason of age;</em> as also↓<span class="ar">بَدَنَ</span>. <span class="auth">(Ḥam p. 158.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdn_2_B1">
					<p><em>He clad</em> a man <em>with a</em> <span class="ar">بَدَن</span>, i. e. a <span class="ar">دِرْع</span> <span class="add">[or <em>coat of mail</em>]</span>. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="budonN">
				<h3 class="entry"><span class="ar">بُدْنٌ</span></h3>
				<div class="sense" id="budonN_A1">
					<p><span class="ar">بُدْنٌ</span> <span class="add">[properly an inf. n.; <a href="#bdn_1">see 1</a>:]</span> <em>Fatness and compactness; </em> as also<span class="arrow"><span class="ar">بُدُنٌ↓</span></span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بُدْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="budonN_A2">
					<p>And <em>Fat;</em> i. e. the <em>substance termed</em> <span class="ar">شَحْمٌ</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بُدْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="budonN_B1">
					<p><a href="#badanapN">It is also a pl. of <span class="ar">بَدَنَةٌ</span></a>: <span class="auth">(T, Ṣ, &amp;c.:)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بُدْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="budonN_B2">
					<p><a href="#baAdinN">and of <span class="ar">بَادِنٌ</span></a>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badanN">
				<h3 class="entry"><span class="ar">بَدَنٌ</span></h3>
				<div class="sense" id="badanN_A1">
					<p><span class="ar">بَدَنٌ</span> The <em>body, without the head and arms and legs;</em> <span class="auth">(M, Mṣb, Ḳ;)</span> so says Az: <span class="auth">(Mṣb:)</span> or the <em>body without the arms and legs:</em> <span class="auth">(Mgh:)</span> or <span class="add">[the <em>part</em>]</span> <em>from the shoulder-joint to the posteriors</em> <span class="add">[<em>inclusive</em>]</span>: <span class="auth">(TA <span class="add">[as from the Mgh, in my copy of which it is not found]</span>:)</span> or the <span class="ar">جَسَدَ</span> <span class="add">[generally meaning the <em>body together with the members</em>]</span> of a man; <span class="auth">(Ṣ;)</span> often applied. to the <em>whole of the</em> <span class="ar">جَسَد</span>; <span class="auth">(Az, TA;)</span> and in the Ḳur x. 92 it is said to mean the <em>body without soul:</em> <span class="auth">(Ṣ:)</span> pl. <span class="ar">أَبْدَانٌ</span>; <span class="auth">(M, Mṣb;)</span> whence the phrase, mentioned by Lḥ, <span class="ar long">إِنَّهَا لَحَسَنَةُ الأَبْدَانِ</span> <span class="add">[meaning <em>Verily she is beautiful in respect of the body</em>]</span>, as though the term <span class="ar">بَدَنٌ</span> were applied to every portion of her. <span class="auth">(M.)</span> <span class="ar long">شِرْكَةُ الأَبْدَانِ</span> is originally <span class="ar long">شِرْكَةٌ بِالأَبْدَانِ</span>, meaning <em>Copartnership in bodily labours for the acquirement of gains.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badanN_A2">
					<p>And hence, ‡ The <em>part</em> of a shirt, <span class="auth">(Mgh, Mṣb,)</span> and of a <span class="add">[garment of the kind called]</span> <span class="ar">جُبَّة</span>, <span class="auth">(Mgh,)</span> <em>that lies against the back and the belly,</em> <span class="add">[i. e. the <em>body</em> thereof,]</span> <em>without the sleeves and the</em> <span class="ar">دَخَارِيص</span> <span class="add">[or <em>gores with which it is widened</em>]</span>: <span class="auth">(Mgh, Mṣb:)</span> pl. as above. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badanN_A3">
					<p>Also † <em>A short</em> <span class="ar">دِرْع</span> <span class="add">[or <em>coat of mail</em>]</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>of the measure of the body:</em> <span class="auth">(M:)</span> or it is <span class="add">[<em>a coat of mail</em>]</span> <em>like a</em> <span class="ar">دِرْع</span>, <em>except that it is short, only such as covers the body, with short sleeves:</em> <span class="auth">(T:)</span> or, as some say, <em>any</em> <span class="ar">دِرْع</span>: <span class="auth">(M:)</span> and so it is said to mean in the Ḳur x. 92 by IAạr <span class="auth">(T)</span> and by Th; <span class="auth">(M;)</span> but Akh says that this assertion is of no account: <span class="auth">(Ṣ:)</span> pl. as above. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="badanN_A4">
					<p>And † <em>A small</em> <span class="add">[<em>garment of the kind called</em>]</span> <span class="ar">جُبَّة</span>; as being likened to a coat of mail. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="badanN_A5">
					<p>Accord. to Kr, <span class="auth">(M,)</span> <em>A limb,</em> or <em>member:</em> or, specially, the <em>limbs,</em> or <em>members, of a slaughtered camel:</em> <span class="auth">(M, Ḳ: <span class="add">[in the latter of which, the former of these two explanations is improperly connected with the first in this paragraph by the conjunction <span class="ar">او</span>:]</span>)</span> to these he specially applies it in one instance: pl. as above. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="badanN_A6">
					<p>Also <em>An old,</em> or <em>aged, man:</em> <span class="auth">(Ḳ:)</span> or so <span class="ar long">رَجُلٌ بَدَنٌ</span>. <span class="auth">(T, Ṣ, M.)</span> <span class="add">[In like manner, <span class="arrow"><span class="ar">بَادِنٌ↓</span></span> and<span class="arrow"><span class="ar">بَدِنٌ↓</span></span> are said by Golius, as on the authority of the Ṣ, to signify <em>annosus et senior,</em> applied to a man, and also to a woman; but this explanation is wrong; and the latter word I do not find in any lexicon.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="badanN_A7">
					<p>And <em>An old mountain-goat:</em> <span class="auth">(M, Ḳ:)</span> or so <span class="ar long">وَعِلٌ بَدَنٌ</span>: <span class="auth">(Ṣ:)</span> <span class="add">[in the present day, <span class="ar">بَدَن</span> is applied to the <em>wild goat of the Arabian and Egyptian deserts and mountains;</em> the <em>capra jaela</em> of Hamilton Smith; called by some an <em>ibex;</em> as is also <span class="ar">تَيْتَل</span>, properly <span class="ar">ثَيْتَلٌ</span>:]</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْدُنُ</span> <span class="auth">(M, Ḳ <span class="add">[in the CK, erroneously, <span class="ar">أَبْدَنٌ</span>]</span>)</span> and <span class="add">[of mult.]</span> <span class="ar">بُدُونٌ</span>, which is extr. <span class="add">[with respect to rule]</span>, on the authority of IAạr. <span class="auth">(M, TA.)</span> The rájiz says, describing a bitch <span class="auth">(Ṣ, M)</span> and a mountain-goat, <span class="auth">(M, TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَدْ قُلْتُ لَمَّا بَدَتِ العُقَابُ</span> *</div> 
						<div class="star">* <span class="ar long">وَضَمَّهَا وَالبَدَنَ الحِقَابٌ</span> *</div> 
						<div class="star">* <span class="ar long">جِدِّى لِكُلِّ عَامِلٍ ثَوَابُ</span> *</div> 
						<div class="star">* <span class="ar long">اَلرَّأْسُ وَالأَكْرُعُ وَالإِهَابُ</span> *</div> 
					</blockquote>
					<p><span class="auth">(Ṣ,* M,* TA,)</span> <span class="add">[<em>I had said, when El-'Ikáb appeared, and El-Hikáb comprised her and the old mountain-goat, “Exert thyself: for every worker</em> there is <em>a recompense: the head and the shanks and the hide</em> shall be thine”]</span>: <span class="ar">العقاب</span> is the name of a bitch, and <span class="ar">الحقاب</span> is a certain mountain: he says, “Catch thou this goat, and I will make thy recompense to be the head and the shanks and the hide.” <span class="auth">(TA.)</span> <span class="add">[Hence Golius has been led to mistake <span class="ar">الحِقَاب</span> for a signification of <span class="ar">البَدَنُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="badanN_A8">
					<p>† The <em>lineage,</em> or <em>parentage,</em> of a man, <em>and</em> his <em>grounds of pretension to respect</em> or <em>honour.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badinN">
				<h3 class="entry"><span class="ar">بَدِنٌ</span></h3>
				<div class="sense" id="badinN_A1">
					<p><span class="ar">بَدِنٌ</span>: <a href="#badanN">see <span class="ar">بَدَنٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="budunN">
				<h3 class="entry"><span class="ar">بُدُنٌ</span></h3>
				<div class="sense" id="budunN_A1">
					<p><span class="ar">بُدُنٌ</span>: <a href="#budonN">see <span class="ar">بُدْنٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بُدُنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="budunN_B1">
					<p><a href="#badanapN">It is also a pl. of <span class="ar">بَدَنَةٌ</span></a>. <span class="auth">(M, Ḳ, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badanapN">
				<h3 class="entry"><span class="ar">بَدَنَةٌ</span></h3>
				<div class="sense" id="badanapN_A1">
					<p><span class="ar">بَدَنَةٌ</span> <em>A she-camel,</em> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> and <em>a male camel,</em> <span class="auth">(T, M, Mgh, Ḳ,)</span> and <em>a cow,</em> <span class="auth">(T, Ṣ, M, Mgh,* Mṣb, Ḳ,)</span> and <em>a bull,</em> <span class="auth">(M, Ḳ,)</span> accord. to some, <span class="auth">(Mṣb,)</span> or properly the first of these, <span class="auth">(Mgh, Mṣb,)</span> and the second, <span class="auth">(Mgh,)</span> but made by the Sunneh to apply to a cow also, <span class="auth">(Mgh,* Mṣb,)</span> <em>that is slaughtered at Mekkeh,</em> <span class="auth">(Ṣ,)</span> or that is, <span class="auth">(M, Ḳ,)</span> or may be, <span class="auth">(T,)</span> <em>brought thither for sacrifice;</em> <span class="auth">(T, M, Ḳ;)</span> so called because they used to fatten them, <span class="auth">(Ṣ,)</span> or because of their greatness, or bulkiness: <span class="auth">(T, Mgh, Mṣb:)</span> not applied to a sheep or goat: <span class="auth">(T, Mṣb, TA:)</span> En-Nawawee erroneously cites the T as asserting that it is thus applied; misled, it is said, by an omission in his copy: <span class="auth">(MF, TA:)</span> pl. <span class="ar">بَدَنَاتٌ</span>, <span class="auth">(T, Mgh, Mṣb,)</span> a pl. of pauc., <span class="auth">(Mgh,)</span> and <span class="ar">بُدْنٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb,)</span> or <span class="ar">بُدُنٌ</span>, <span class="auth">(Mgh, Ḳ,)</span> or both, <span class="auth">(M, Mṣb, TA,)</span> the former being a contraction of the latter, which seems to be <a href="#badiynN">pl. of <span class="ar">بَدِينٌ</span></a>: <span class="auth">(Mṣb:)</span> one should not use <span class="ar">بَدَنٌ</span> <a href="#badanapN">as a pl. of <span class="ar">بَدَنَةٌ</span></a>; though they used to say <span class="ar">خَشَبٌ</span> and <span class="ar">أَجَمٌ</span>, &amp;c. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badanieBN">
				<h3 class="entry"><span class="add">[<span class="ar">بَدَنِىٌّ</span>]</span></h3>
				<div class="sense" id="badanieBN_A1">
					<p><span class="add">[<span class="ar">بَدَنِىٌّ</span> <em>Of,</em> or <em>relating to, the</em> <span class="ar">بَدَن</span>, or <em>body; corporeal.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدن</span> - Entry: <span class="ar">بَدَنِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badanieBN_A2">
					<p><span class="add">[<a href="#baAdinN">See also <span class="ar">بَادِنٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badiynN">
				<h3 class="entry"><span class="ar">بَدِينٌ</span></h3>
				<div class="sense" id="badiynN_A1">
					<p><span class="ar">بَدِينٌ</span>: <a href="#baAdinN">see <span class="ar">بَادِنٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAdinN">
				<h3 class="entry"><span class="ar">بَادِنٌ</span></h3>
				<div class="sense" id="baAdinN_A1">
					<p><span class="ar">بَادِنٌ</span>, applied to a man, <em>Big, bulky, big-bodied,</em> or <em>corpulent;</em> <span class="auth">(ISk, T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَدِينٌ↓</span></span> <span class="auth">(Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">مُبَدَّنٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <span class="add">[and<span class="arrow"><span class="ar">بَدَنِىٌّ↓</span></span>]</span>: and <em>fat;</em> as also<span class="arrow"><span class="ar">مُبَدَّنٌ↓</span></span>: <span class="auth">(T, M:)</span> or <em>heavy in body; heavy by reason of age:</em> and<span class="arrow"><span class="ar">بَدِينٌ↓</span></span> signifies <em>fat:</em> <span class="auth">(Ḥam p. 158:)</span> <span class="ar">بَادِنٌ</span> is likewise applied to a woman, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> as are also <span class="ar">بَادِنَةٌ</span> <span class="auth">(M, Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">بَدِينٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">مُبَدَّنَةٌ↓</span></span>: <span class="auth">(T, M:)</span> the pl. is <span class="ar">بُدَّنٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">بُدْنٌ</span> <span class="auth">(M, TA)</span> and <span class="ar">بُدُنٌ</span>; <span class="auth">(Mṣb, Ḳ;)</span> the first of these being <a href="#baAdinN">pl. of <span class="ar">بَادِنٌ</span></a>, <span class="auth">(M, Mṣb,)</span> and so the second; <span class="auth">(M;)</span> and the third being pl. of<span class="arrow"><span class="ar">بَدِينٌ↓</span></span>. <span class="auth">(Mṣb.)</span> <a href="#badanN">See also <span class="ar">بَدَنٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubadBanN">
				<h3 class="entry"><span class="ar">مُبَدَّنٌ</span> / <span class="ar">مُبَدَّنَةٌ</span></h3>
				<div class="sense" id="mubadBanN_A1">
					<p><span class="ar">مُبَدَّنٌ</span>, and with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُبَدَّنَةٌ</span>}</span></add>: <a href="#baAdinN">see <span class="ar">بَادِنٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibodaAnN">
				<h3 class="entry"><span class="ar">مِبْدَانٌ</span></h3>
				<div class="sense" id="mibodaAnN_A1">
					<p><span class="ar">مِبْدَانٌ</span> <em>That becomes fat quickly, with little fodder</em> <span class="add">[or <em>food</em>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0168.pdf" target="pdf">
							<span>Lanes Lexicon Page 168</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0169.pdf" target="pdf">
							<span>Lanes Lexicon Page 169</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
