<article class="root" id="Root_byS">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/233_byr">بير</a></span>
				<span class="ar">بيص</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/235_byD">بيض</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="baASi">
				<span class="pb" id="Page_0282"></span>
				<h3 class="entry"><span class="ar">بَاصِ</span> / <span class="ar">بَيْصَ</span></h3>
				<div class="sense" id="baASi_A1">
					<p><span class="ar long">وَقَعَ فِى حَاصِ بَاصِ</span>, and <span class="ar long">حَيْصَ بَيْصَ</span>, &amp;c.: <a href="index.php?data=06_H/236_HyS">see art. <span class="ar">حيص</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoSN">
				<h3 class="entry"><span class="ar">بَيْصٌ</span></h3>
				<div class="sense" id="bayoSN_A1">
					<p><span class="ar">بَيْصٌ</span> <em>Difficulty; straitness;</em> <span class="auth">(IAạr, Ḳ;)</span> as also<span class="arrow"><span class="ar">بِيصٌ↓</span></span>. <span class="auth">(Ḳ.)</span> See above.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biySN">
				<h3 class="entry"><span class="ar">بِيصٌ</span></h3>
				<div class="sense" id="biySN_A1">
					<p><span class="ar">بِيصٌ</span>: <a href="#baYoSN">see above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0282.pdf" target="pdf">
							<span>Lanes Lexicon Page 282</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
