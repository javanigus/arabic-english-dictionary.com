<article class="root" id="Root_bsr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/100_bsc">بسذ</a></span>
				<span class="ar">بسر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/102_bsT">بسط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسر</span></h3>
				<div class="sense" id="bsr_1_A1">
					<p><span class="ar">بَسَرَ</span> <em>He took</em> anything <em>when it was fresh, juicy, moist,</em> or <em>not flaccid;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">ابتسر↓</span></span> <span class="add">[which is more commonly used]</span>. <span class="auth">(M, Ḳ,* TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">بَسَرْبُ النَّبَاتَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُرُ</span>}</span></add>, inf. n. <span class="ar">بَسْرٌ</span>, <em>I pastured</em> <span class="add">[<em>beasts</em>]</span> <em>upon the herbage when it was fresh and juicy, I being the first to do so.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsr_1_A2">
					<p>Also, <span class="auth">(Ḳ,)</span> aor. as above, <span class="auth">(TA,)</span> and so the inf. n., <span class="auth">(M,)</span> <em>i. q.</em> <span class="ar">أَعْجَلَ</span> <span class="add">[as meaning † <em>He was quick,</em> or <em>beforehand,</em> or <em>before the proper time, with</em> a person or thing, or <em>in doing,</em> or <em>seeking,</em> a thing]</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[Hence,]</span> <span class="ar long">بَسَرَ النَّاقَةَ</span>, <span class="auth">(Aṣ, Ṣ, M, Ḳ,)</span> aor. and inf. n. as above; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar">ابتسرها↓</span></span>, <span class="auth">(Ṣ, A,)</span> and<span class="arrow"><span class="ar">تبسّرها↓</span></span>; <span class="auth">(T;)</span> ‡ <em>He</em> <span class="auth">(the stallion)</span> <em>covered the she-camel without her desiring it:</em> <span class="auth">(Aṣ, Ṣ, A:)</span> or <em>before she desired it.</em> <span class="auth">(M, Ḳ.)</span> And in like manner, <span class="ar">بَسَرَ</span> and<span class="arrow"><span class="ar">تبسّر↓</span></span> ‡ <em>He</em> <span class="auth">(a stallion)</span> <em>covered</em> a mare <em>when she had only begun to feel the excitement of desire.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">ابتسر↓ الجَارِيَةَ</span></span> ‡ <em>He deflowered the girl before she had attained to puberty.</em> <span class="auth">(A, and Mṣb in art. <span class="ar">قض</span>.)</span> And <span class="ar">بَسَرَ</span> and<span class="arrow"><span class="ar">ابتسر↓</span></span> † <em>He fecundated</em> a palm-tree <em>before the proper time for doing so.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">بَسَرَ السِّقَآءَ</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> † <em>He drank the milk of the skin,</em> <span class="auth">(Ḳ,)</span> or <em>gave it to be drunk,</em> <span class="auth">(Ṣ,)</span> <em>before it had become thick, and fit for churning.</em> <span class="auth">(Ṣ, Ḳ.)</span> And <span class="ar">بَسَرَ</span>, <span class="auth">(M, Ḳ,)</span> aor. as above, <span class="auth">(M, A,)</span> and so the inf. n., <span class="auth">(Ṣ, M,)</span> ‡ <em>He broke</em> a pustule: <span class="auth">(A:)</span> or <em>he squeezed</em> a pustule, or a boil, <em>before it was ripe:</em> <span class="auth">(TA:)</span> or <em>he laid it open by peeling off its crust,</em> or <em>scab, before it was ripe;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابسر↓</span></span>. <span class="auth">(Ḳ.)</span> And, inf. n. as above, † <em>He dug rivers when water was scarce:</em> or <em>sought for,</em> or <em>after, water</em> <span class="add">[<em>when it was scarce</em>]</span>: and so, accord. to Az, <span class="arrow"><span class="ar">تبسّر↓</span></span>. <span class="auth">(L. <span class="add">[But for <span class="ar long">اذا عرا الماء او طابه</span>, as part of the explanation, I read <span class="ar long">إِذَا عَزَّ المَاءُ أَوْ طَلَبَهُ</span>.]</span>)</span> And <span class="ar long">بَسَرَ النَّهْرَ</span> † <em>He dug a well in</em> <span class="add">[<em>the bed of</em>]</span> <em>the river, it being dry.</em> <span class="auth">(L. <span class="add">[But here, for <span class="ar long">و هو صاف</span>, I read <span class="ar long">و هو جَافٌّ</span>.]</span>)</span> Also <span class="ar">بَسَرَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> aor. as above, <span class="auth">(M,)</span> and inf. n. as above <span class="auth">(Ṣ, M)</span> and <span class="ar">بِسَارٌ</span>; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar">ابتسر↓</span></span> <span class="auth">(M, A, Ḳ)</span> and<span class="arrow"><span class="ar">تبسّر↓</span></span> and<span class="arrow"><span class="ar">ابسر↓</span></span>; <span class="auth">(M, Ḳ;)</span> ‡ <em>He sought, sought for</em> or <em>after, demanded,</em> or <em>desired,</em> a thing that he wanted, or needed, <em>in an improper time:</em> <span class="auth">(M, Ḳ:)</span> or <em>in an improper place:</em> <span class="auth">(Ṣ, M:)</span> or <em>in an improper manner:</em> <span class="auth">(Jm:)</span> or <em>before its time.</em> <span class="auth">(A.)</span> And the first of these verbs, ‡ <em>He required</em> a debt <em>to be paid before the time when it was due.</em> <span class="auth">(Ḳ, TA.)</span> And ‡ <em>He required</em> his debtor <em>to pay a debt before the time when it was due:</em> from <span class="ar long">بَسَرَ النَّاقَةَ</span>, explained above. <span class="auth">(Sh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsr_1_A3">
					<p>Also, inf. n. <span class="ar">بَسْرٌ</span>, † <em>He began</em> a thing; and so<span class="arrow"><span class="ar">ابتسر↓</span></span>. <span class="auth">(Ḳ.)</span> And <span class="ar long">بَسَرَ بِهِ</span> <span class="auth">(TḲ)</span> and<span class="arrow"><span class="ar long">ابتسر↓ به</span></span> <span class="auth">(TA, TḲ)</span> † <em>He began with it.</em> <span class="auth">(TA, TḲ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsr_1_B1">
					<p>Also, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُرُ</span>}</span></add>, inf. n. <span class="ar">بَسْرٌ</span>, <em>He mixed</em> <span class="ar">بُسْر</span> <span class="add">[or <em>fullgrown unripe dates</em>]</span> <em>with others, in beverage of the kind called</em> <span class="ar">نَبِيذ</span>: the doing of which is forbidden in a trad.: <span class="auth">(Ṣ:)</span> or <em>he mixed</em> <span class="ar">بُسْر</span> <em>with fresh ripe dates,</em> or <em>with dry dates, and made with them both together that kind of beverage.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَسَرَ تَمْرًا</span>, <span class="auth">(M, Ḳ,)</span> aor. and inf. n. as above; and<span class="arrow"><span class="ar">بسّرهُ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">ابسرهُ↓</span></span>; <span class="auth">(Ḳ;)</span> <em>He made, of dry dates, that kind of beverage, and mixed</em> <span class="ar">بُسْر</span> <em>with it.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bsr_1_C1">
					<p>Also, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُرُ</span>}</span></add>, inf. n. <span class="ar">بَسْرٌ</span> and <span class="ar">بُسُورٌ</span>, <span class="auth">(M,)</span> <em>He frowned; contracted his face;</em> or <em>grinned,</em> or <em>displayed his teeth, frowning,</em> or <em>contracting his face,</em> or <em>looking sternly, austerely,</em> or <em>morosely;</em> <span class="auth">(M, Ḳ;)</span> as also <span class="ar long">بَسَرَ وَجْهَهُ</span>, inf. n. <span class="ar">بُسُوزٌ</span>: <span class="auth">(Ṣ:)</span> or <em>he did so excessively:</em> <span class="auth">(Jel in lxxiv. 22:)</span> or <em>he looked with intense dislike</em> or <em>hatred.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بسّر</span></h3>
				<div class="sense" id="bsr_2_A1">
					<p><a href="#bsr_1">see 1</a>; last sentence but one.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باسر</span></h3>
				<div class="sense" id="bsr_3_A1">
					<p><span class="ar">بَاسَرَتْ</span>, inf. n. <span class="ar">مُبَاسَرَةٌ</span>, † <em>She</em> <span class="auth">(a mare)</span> <em>desired the stallion when she had only begun to feel the excitement of lust.</em> <span class="auth">(AO.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابسر</span></h3>
				<div class="sense" id="bsr_4_A1">
					<p><span class="ar">ايسر</span>: <a href="#bsr_1">see 1</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsr_4_A2">
					<p>Also † <em>He dug in ground that had not been dug before.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsr_4_B1">
					<p><span class="ar">ابسرالنَّخْلُ</span> <em>The palm-trees had dates in the state in which they are called</em> <span class="ar">بُسْر</span>: <span class="auth">(Ṣ, M:*)</span> or <em>produced dates that did not ripen.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبسّر</span></h3>
				<div class="sense" id="bsr_5_A1">
					<p><span class="ar">تبسّر</span>: <a href="#bsr_1">see 1</a>, in four places. It signifies also † <em>He sought for,</em> or <em>after,</em> fresh water recently produced by rain. <span class="auth">(Ṣ. <span class="add">[<a href="#busorN">See <span class="ar">بُسْرٌ</span></a>.]</span>)</span> And † <em>He dug for plants before they came forth:</em> <span class="auth">(M, TA:)</span> <span class="add">[or]</span> <span class="ar long">تبسّر نَبَاتًا</span> has this meaning. <span class="auth">(TA.)</span> And † <em>He</em> <span class="auth">(a <span class="add">[wild]</span> bull)</span> <em>came to the roots of dry plants, and ate them.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتسر</span></h3>
				<div class="sense" id="bsr_8_A1">
					<p><span class="ar">ابتسر</span>: <a href="#bsr_1">see 1</a>, in seven places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsr_8_B1">
					<p><span class="ar long">اُبْتُسِرَ لَوْنُهُ</span> ‡ <em>His colour changed,</em> <span class="auth">(Ḳ, TA,)</span> <em>and became like that of</em> <span class="ar">بُسْر</span> <span class="add">[or <em>full-grown unripe dates</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basorN">
				<h3 class="entry"><span class="ar">بَسْرٌ</span></h3>
				<div class="sense" id="basorN_A1">
					<p><span class="ar">بَسْرٌ</span>: <a href="#busorN">see <span class="ar">بُسْرٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بَسْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="basorN_B1">
					<p><a href="#baAsirN">and see also <span class="ar">بَاسِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busorN">
				<h3 class="entry"><span class="ar">بُسْرٌ</span> / <span class="ar">بُسْرَةٌ</span></h3>
				<div class="sense" id="busorN_A1">
					<p><span class="ar">بُسْرٌ</span> Anything <em>fresh, juicy, moist, not flaccid.</em> <span class="auth">(IF, M, Mṣb, Ḳ.)</span> You say <span class="ar long">نَبَاتٌ بُسْرٌ</span> <em>A fresh plant:</em> <span class="auth">(Mṣb:)</span> or <em>a plant that has risen from the surface of the ground, but not grown tall;</em> because it is then fresh and juicy: <span class="auth">(TA:)</span> or such is called <span class="ar">بُسْرَةٌ</span> <span class="add">[<a href="#busorN">fem. of <span class="ar">بُسْرٌ</span></a>]</span>; as also <em>what is fresh, juicy, moist,</em> or <em>not flaccid, of the plant called</em> <span class="ar">بُهْمَى</span>. <span class="auth">(M.)</span> A plant, or herbage, when it first appears in the ground is termed <span class="ar">بَارِضٌ</span>; then, <span class="ar">جَمِيمٌ</span>; then, <span class="ar">بُسْرَةٌ</span>; then, <span class="ar">صَمْعَآءُ</span>; and then, <span class="add">[when it is dry,]</span> <span class="ar">بَسْرٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="busorN_A2">
					<p><em>Fresh water,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>recently produced by rain;</em> <span class="auth">(Ṣ, M;)</span> as also<span class="arrow"><span class="ar">بَسْرٌ↓</span></span>: <span class="auth">(M:)</span> or this latter signifies <em>cold,</em> or <em>cool, water:</em> <span class="auth">(Ḳ:)</span> pl. of the former <span class="ar">بِسَارٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> like as <span class="ar">رِمَاحٌ</span> <a href="#rumoHN">is pl. of <span class="ar">رُمْحٌ</span></a>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="busorN_A3">
					<p>‡ <em>A young,</em> or <em>youthful,</em> man, and woman: <span class="auth">(Ḳ, TA:)</span> or <em>young,</em> or <em>youthful,</em> and <em>fresh;</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُسْرَةٌ</span>}</span></add>: <span class="auth">(M, A:)</span> applied, respectively, to a man and a woman; <span class="auth">(M;)</span> or to a boy and a girl. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="busorN_A4">
					<p>And, with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُسْرَةٌ</span>}</span></add>, ‡ The sun <em>when it has just risen,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>and is red, and not yet clear.</em> <span class="auth">(A,* TA.)</span> <span class="add">[Accord. to the A, this meaning seems to be derived from that next following.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="busorN_A5">
					<p><span class="ar">بُسْرٌ</span> and<span class="arrow"><span class="ar">بُسُرٌ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> <span class="add">[the former, only, mentioned in the A and Mṣb, &amp;c., as the latter is rare; coll. gen. ns., signifying <em>Fullgrown</em>]</span> <em>unripe dates; dates before they have become</em> <span class="ar">رُطَب</span>; <span class="auth">(M, Ḳ;)</span> <em>dates that have become coloured, but have not become ripe;</em> <span class="auth">(TA;)</span> <em>dates that have begun to colour,</em> i. e., <em>to become red or yellow;</em> <span class="auth">(Mṣb in art. <span class="ar">بُلح</span>;)</span> <em>dates beginning to ripen:</em> <span class="auth">(IAth, TA in art. <span class="ar">بلح</span>:)</span> so called because fresh and juicy, and not flaccid: <span class="auth">(M:)</span> n. un. <span class="ar">بُسْرَةٌ</span> and <span class="ar">بُسُرَةٌ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> pl. <span class="ar">بُسْرَاتٌ</span> <span class="auth">(Ṣ)</span> <span class="add">[or <span class="ar">بُسْرَةٌ</span>]</span> and <span class="ar">بُسُرَاتٌ</span>: <span class="auth">(M:)</span> Sb says that <span class="ar">بُسُرَةٌ</span> <span class="add">[or <span class="ar">بُسْرَةٌ</span> or each of these]</span> has no broken pl.; but he allows <span class="ar">بُسْرَان</span> and <span class="ar">تَمْرَان</span>, as meaning <em>two sorts of</em> <span class="ar">بُسْر</span> and <em>of</em> <span class="ar">تَكْر</span>. <span class="auth">(M.)</span> <span class="add">[J says,]</span> <span class="ar">بُسْرٍ</span> in their first stage are termed <span class="ar">طَلْعٌ</span>; then, <span class="ar">خَلَالٌ</span>; then, <span class="ar">بَلَحٌ</span>; then, <span class="ar">بُسْرٌ</span>; then, <span class="ar">رُطَبٌ</span>; then, <span class="ar">تَمْرٌ</span>: <span class="auth">(Ṣ:)</span> but this saying of J is not good: the original thereof is termed <span class="ar">طلع</span>; and when they have become organized and compact (<span class="ar long">إِذَا انْعَقَدَ</span>), they are termed <span class="ar">سَيَابٌ</span> or <span class="ar">سَيَّابٌ</span> <span class="add">[accord. to different copies of the Ḳ]</span>; and when they have become green and round, <span class="ar">جَدَالٌ</span> and <span class="ar">سَرَادٌ</span> and <span class="ar">خَلَالٌ</span>; and when they have become somewhat large, <span class="ar">بَغْوٌ</span>; and when they have become large, <span class="add">[or full-grown,]</span> <span class="ar">بُسْرٌ</span>; then, <span class="ar">مُخَطَّمْ</span>; then, <span class="ar">مُوَكِّتٌ</span>; then, <span class="ar">تُذْنُوبٌ</span>; then, <span class="ar">جُمْسَةٌ</span> <span class="add">[in the CK <span class="ar">جَمِيسَةٌ</span>]</span>; then, <span class="ar">ثَعْدَهٌ</span> and <span class="ar">خَالِعٌ</span> and <span class="ar">خَالِعَةٌ</span>; and when completely ripe, <span class="ar">رُطَبٌ</span> and <span class="ar">مَعْوٌ</span>; then, <span class="ar">تَمْرٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="busorN_A6">
					<p><span class="add">[Hence,]</span> <span class="ar">بُسْرَةٌ</span> signifies also ‡ The <em>head,</em> or <em>extremity, of the penis of a dog.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسر</span> - Entry: <span class="ar">بُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="busorN_A7">
					<p>And † <em>A kind of bead;</em> syn.<span class="ar">خَرَزَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busurN">
				<h3 class="entry"><span class="ar">بُسُرٌ</span></h3>
				<div class="sense" id="busurN_A1">
					<p><span class="ar">بُسُرٌ</span>: <a href="#busorN">see <span class="ar">بُسْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busorapN">
				<h3 class="entry"><span class="ar">بُسْرَةٌ</span></h3>
				<div class="sense" id="busorapN_A1">
					<p><span class="ar">بُسْرَةٌ</span> <a href="#busorN">fem. of <span class="ar">بُسْرٌ</span></a> as an epithet, and n. un. of the same as a subst.: explained with the latter.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busurapN">
				<h3 class="entry"><span class="ar">بُسُرَةٌ</span></h3>
				<div class="sense" id="busurapN_A1">
					<p><span class="ar">بُسُرَةٌ</span> <a href="#busurN">n. un. of <span class="ar">بُسُرٌ</span></a>, <a href="#busorN">a dial. var. of <span class="ar">بُسْرٌ</span>, q. v.</a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAsirN">
				<span class="pb" id="Page_0203"></span>
				<h3 class="entry"><span class="ar">بَاسِرٌ</span></h3>
				<div class="sense" id="baAsirN_A1">
					<p><span class="ar">بَاسِرٌ</span> and<span class="arrow"><span class="ar">بَسْرٌ↓</span></span>, the latter an inf. n. used as an epithet, A face <em>frowning;</em> or <em>contracted;</em> or <em>grinning,</em> or <em>displaying the teeth, with a frowning,</em> or <em>contraction,</em> or <em>a stern, an austere,</em> or <em>a morose, look.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#bsr_1">See 1</a>, last sentence.]</span> <span class="ar long">وَوُجوهٌ يَوْمئِذٍ بَاسِرَةٌ</span>, in the Ḳur lxxv. 24, means <em>And faces on that day</em> shall be <em>excessively frowning</em> or <em>contracted,</em>, &amp;c.: <span class="auth">(Jel:)</span> or <em>expressive of dislike</em> or <em>hatred, and contracted.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#baAsilN">See also <span class="ar">بَاسِلٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAsuwrN">
				<h3 class="entry"><span class="ar">بَاسُورٌ</span></h3>
				<div class="sense" id="baAsuwrN_A1">
					<p><span class="ar">بَاسُورٌ</span> <em>A well-known disease;</em> <span class="auth">(Ḳ;)</span> <em>a swelling,</em> or <em>tumour, which nature drives to every part of the body, from a humour that comes from the anus</em> (<span class="ar">المَقْعَدَة</span>), <em>and the testicles, and the edges of the labia majora of the pudendum muliebre, and other parts; and when in the anus, attended by a swelling of the veins;</em> <span class="auth">(Mṣb;)</span> sing. of; <span class="auth">(Ṣ, Ḳ;)</span> which signifies <em>a certain disease that arises in the anus</em> (<span class="ar">المقعدة</span>), <span class="add">[namely, the <em>hemorrhoids, or piles,</em> to which this term generally applies when it is used absolutely,]</span> and also <em>in the inside of the nose;</em> <span class="auth">(Ṣ;)</span> <em>what resembles boils in the anus:</em> <span class="auth">(Mgh:)</span> sometimes the <span class="ar">س</span> is changed into <span class="ar">ص</span>: <span class="auth">(Mgh, Mṣb:)</span> and it is said that the word is not Arabic. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubosirN">
				<h3 class="entry"><span class="ar">مُبْسِرٌ</span></h3>
				<div class="sense" id="mubosirN_A1">
					<p><span class="ar">مُبْسِرٌ</span>: <a href="#mibosaArN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibosaArN">
				<h3 class="entry"><span class="ar">مِبْسَارٌ</span></h3>
				<div class="sense" id="mibosaArN_A1">
					<p><span class="ar long">نَخْلَةٌ مِبْسَارٌ</span>, <span class="auth">(M, Ḳ,)</span> and↓<span class="ar">مُبْسِرٌ</span> without <span class="ar">ة</span>, as though a possessive epithet, <span class="auth">(M,)</span> <em>A palm-tree of which the dates do not ripen.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#bsr_4">See also 4</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabosuwrN">
				<h3 class="entry"><span class="ar">مَبْسُورٌ</span></h3>
				<div class="sense" id="mabosuwrN_A1">
					<p><span class="ar">مَبْسُورٌ</span> <em>Affected by the disease termed</em> <span class="ar">بَوَاسِير</span>, <a href="#baAsuwrN">pl. of <span class="ar">بَاسُورٌ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaAsirapN">
				<h3 class="entry"><span class="ar">مُبَاسِرَةٌ</span></h3>
				<div class="sense" id="mubaAsirapN_A1">
					<p><span class="ar">مُبَاسِرَةٌ</span> † A mare <em>desiring the stallion</em> <span class="auth">(AO, Ḳ *)</span> <em>when she has only begun to feel the excitement of lust,</em> <span class="auth">(AO,)</span> or <em>before she is fully excited by lust.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#mubaAXirN">See also <span class="ar">مُبَاشِرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0202.pdf" target="pdf">
							<span>Lanes Lexicon Page 202</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0203.pdf" target="pdf">
							<span>Lanes Lexicon Page 203</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
