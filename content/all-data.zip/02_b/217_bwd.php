<article class="root" id="Root_bwd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/216_bwx">بوخ</a></span>
				<span class="ar">بود</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/218_bwr">بور</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bwd_1">
				<h3 class="entry">1. ⇒ <span class="ar">بود</span> ⇒ <span class="ar">باد</span></h3>
				<div class="sense" id="bwd_1_A1">
					<p><span class="ar">بَادَ</span>, inf. n. <span class="ar">بَوْدٌ</span> and <span class="ar">بَوَادٌ</span>: <a href="index.php?data=02_b/232_byd">see art. <span class="ar">بيد</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0274.pdf" target="pdf">
							<span>Lanes Lexicon Page 274</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
