<article class="root" id="Root_bndr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/190_bnd">بند</a></span>
				<span class="ar">بندر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/192_bndq">بندق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="banodarN">
				<h3 class="entry"><span class="ar">بَنْدَرٌ</span></h3>
				<div class="sense" id="banodarN_A1">
					<p><span class="ar">بَنْدَرٌ</span> <span class="add">[app. from the Persian <span class="ar">بَنْدَرْ</span>,]</span> <em>A place where ships or boats anchor or moor; a port</em> <span class="add">[or <em>port-town:</em> pl. <span class="ar">بَنَادِرُ</span>]</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
