<article class="root" id="Root_blwr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/184_blw">بلو</a></span>
				<span class="ar">بلور</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/186_ble">بلى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bilBaworN">
				<h3 class="entry"><span class="ar">بِلَّوْرٌ</span> / 
							<span class="ar">بَلُّورٌ</span> /  
							<span class="ar">بِلَوْرٌ</span></h3>
				<div class="sense" id="bilBaworN_A1">
					<p><span class="ar">بِلَّوْرٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">بَلُّورٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بِلَوْرٌ</span>, <span class="auth">(Ḳ,)</span> or the last only, <span class="auth">(IAạr, T,)</span> <span class="add">[a coll. gen. n., signifying <em>Crystal;</em>]</span> the <em>kind of stone called</em> <span class="ar">مَهًا</span>, <span class="auth">(M,)</span> <em>which shines by reason of its whiteness and clearness;</em> <span class="auth">(TA in art. <span class="ar">مهو</span>;)</span> <em>a well-known kind of stone, the best of which is brought from the islands of the Zinj</em> (<span class="ar">الزِّنْج</span>); <span class="auth">(Mṣb;)</span> <em>a well-known kind of precious stone,</em> <span class="auth">(Ḳ, TA,)</span> <em>white and transparent:</em> <span class="auth">(TA:)</span> <span class="add">[Golius says, but I know not on what authority, if on any better ground than the resemblance of the name, “Græc. <span class="gr">Βήρυλλος</span>, <em>beryllus,</em> lapidis genus: de quo vide Plin. xxxvii. 5: aut potius, quo illum lapidem adulterari idem scribit, <em>crystallum:</em>”]</span> n. un. with <span class="ar">ة</span>: <span class="auth">(M:)</span> some say that it is <em>a kind of glass</em> <span class="add">[or <em>factitious crystal;</em> what we term <em>crystal-glass;</em> and to this the word is commonly applied in the present day; though still also applied to <em>rock-crystal</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0257.pdf" target="pdf">
							<span>Lanes Lexicon Page 257</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
