<article class="root" id="Root_bwq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/222_bwE">بوع</a></span>
				<span class="ar">بوق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/224_bwl">بول</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوق</span> ⇒ <span class="ar">باق</span></h3>
				<div class="sense" id="bwq_1_A1">
					<p><span class="ar">بَاقَ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">يَبُوقُ</span>, inf. n. <span class="ar">بَوْقٌ</span>, <span class="auth">(TA,)</span> <em>He came with,</em> or <em>brought,</em> or <em>effected, evil,</em> or <em>mischief, and altercations.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwq_1_A2">
					<p><span class="ar long">بَاقَتِ الدَّاهِيَةُ</span> <em>The calamity, misfortune,</em> or <em>disaster, befell, betided,</em> or <em>happened.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">بَاقَتْهُمُ الدَّهِيَةُ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">البَائِقَةُ</span>, <span class="auth">(JK, Ḳ,)</span> aor. and inf. n. as above, <span class="auth">(Ṣ,)</span> <em>The calamity, misfortune,</em> or <em>disaster, befell them,</em> or <em>smote them;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar long">انباقت↓ عَلَيْهِمْ</span></span>: <span class="auth">(JK,* Ḳ:)</span> and<span class="arrow"><span class="ar long">انباقت↓ عَلَيْهِمْ بَائِقَةُ شَرٍّ</span></span> <em>A calamity,</em>, &amp;c., <em>burst upon them;</em> syn. <span class="ar">اِنْفَتَقَتْ</span>; <span class="auth">(Ṣ, Ḳ;*)</span> like <span class="ar">انباجت</span>, <span class="auth">(Ṣ,)</span> from which IF thinks it to be changed: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">انباق↓ عَلَيْهِمُ الدَّهْرُ</span></span> <em>Fortune assaulted them,</em> or <em>assailed them, with calamity, like as the sound issues from the trumpet</em> (<span class="ar">البُوق</span>): <span class="auth">(Ṣ:)</span> and <span class="ar">بُقْتُهُمْ</span> <span class="add">[<em>I assaulted them,</em> or <em>assailed them, with a calamity,</em>, &amp;c.]</span>. <span class="auth">(JK.)</span> And in like manner, one says, <span class="ar long">بَاقَتْهُمْ بَؤُوقٌ</span>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">بَوْقٌ</span> and <span class="ar">بُؤُوقٌ</span>, <em>A vehement calamity</em> or <em>misfortune</em> or <em>disaster befell them,</em> or <em>smote them.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwq_1_A3">
					<p>Also <span class="ar">بَاقَ</span>, <span class="auth">(Ḳ,)</span> aor. as above, inf. n. <span class="ar">بَوْقٌ</span>, <span class="auth">(TA,)</span> <em>He wronged a man; treated him wrongfully,</em> or <em>unjustly:</em> or <em>he came upon a people,</em> or <em>company of men, suddenly,</em> or <em>unawares, without their permission;</em> as also<span class="arrow"><span class="ar">انباق↓</span></span>: <span class="auth">(Ḳ:)</span> <span class="add">[or,]</span> as some say, <span class="ar long">بَاقُوا عَلَيْهِ</span> <em>they slew him:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">انباق↓ بِهِ</span></span> <em>he wronged him.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">بَاقَ بِكَ</span> <em>He</em> <span class="auth">(a man, JK)</span> <em>came up,</em> or <em>forth, upon thee, from a low,</em> or <em>depressed, place.</em> <span class="auth">(JK, Ḳ.)</span> And <span class="ar long">بَاقَ بِهِ</span> <em>He encompassed,</em> or <em>surrounded, him.</em> <span class="auth">(JK, Ḳ.)</span> And <span class="ar long">بَاقَ القَوْمُ عَلَيْهِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَوْقٌ</span>, <span class="auth">(TA,)</span> <em>The people,</em> or <em>company of men, gathered themselves together against him, and slew him wrongfully:</em> <span class="auth">(Ḳ,* TA:)</span> but some say that it means, as explained before, <em>they slew him.</em> <span class="auth">(TA.)</span> And <span class="ar">بَاقَهُمْ</span>, <span class="auth">(Ibn-ʼAbbád, JK, Ḳ,)</span> aor. as above, <span class="auth">(JK,)</span> inf. n. <span class="ar">بَوْقٌ</span>, <span class="auth">(Ibn-ʼAbbád, TA,)</span> <em>He stole from them; robbed them.</em> <span class="auth">(Ibn-ʼAbbád, JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwq_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبوق</span> ⇒ <span class="ar">انباق</span></h3>
				<div class="sense" id="bwq_7_A1">
					<p><a href="#bwq_1">see 1</a>, in five places. <span class="ar long">مُخْرَنْبِقٌ لِيَنْبَاقَ</span>, a prov., thus related by some, instead of <span class="ar">لِيَنْبَاعَ</span>, means <em>Silent in order to bring about,</em> or <em>effect, a</em> <span class="ar">بَائِقَة</span>, i. e., a <em>calamity,</em> or <em>misfortune:</em> <span class="auth">(Ḳ in art. <span class="ar">بوع</span>, q. v.:)</span> or, <em>to launch forth, and manifest what is in his mind.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">انباق عَلَيْنَا بِالكَلَامِ</span> <em>He broke forth upon us with evil speech.</em> <span class="auth">(JK.)</span> And <span class="ar long">انباق بِالضَّحِكَ</span> <em>He broke forth with laughter.</em> <span class="auth">(JK.)</span> And <span class="ar long">انباقت المَطْرَةُ</span> <em>The shower of rain poured forth with vehemence.</em> <span class="auth">(TA.)</span> And <span class="ar long">انباق المَآءُ</span> <em>The water became copious,</em> or <em>much in quantity.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawoqN">
				<h3 class="entry"><span class="ar">بَوْقٌ</span></h3>
				<div class="sense" id="bawoqN_A1">
					<p><span class="ar">بَوْقٌ</span> <em>Abundance of rain;</em> as also<span class="arrow"><span class="ar">بُوقٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: <span class="ar">بَوْقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bawoqN_B1">
					<p><a href="#buwqN">See also the next paragraph</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwqN">
				<h3 class="entry"><span class="ar">بُوقٌ</span></h3>
				<div class="sense" id="buwqN_A1">
					<p><span class="ar">بُوقٌ</span> <span class="add">[<em>A trumpet;</em>]</span> <em>a certain thing in which one blows;</em> <span class="auth">(IDrd, Ṣ, Mgh, Ḳ;)</span> <em>in which one blows as in a musical pipe:</em> <span class="auth">(Kr, Ḳ:)</span> <span class="add">[mostly used in war, but]</span> mentioned by a poet, cited by Aṣ, as used by the Christians: <span class="auth">(Ṣ:)</span> IDrd says, The Arabs used this word, but I know not its origin: Esh-Shiháb says, in the 'Ináyeh, that it is arabicized, from <span class="add">[the Persian]</span> <span class="ar">بُورِى</span>: <span class="auth">(TA: <span class="add">[but this is obviously improbable:]</span>)</span> pl. <span class="ar">بُوقَاتٌ</span> <span class="auth">(Mgh, Mṣb)</span> and <span class="ar">بِيقَانٌ</span> <span class="auth">(Mṣb <span class="add">[in my copy of the Mgh, erroneously, <span class="ar">بِيَقَاتٌ</span>]</span>)</span> <span class="add">[and <span class="ar">أَبْوَاقٌ</span>, a pl. of pauc., commonly used in the present day]</span>. <span class="ar long">نَفَخَ فِى البُوقِ</span> <span class="add">[<em>He blew the trumpet,</em> lit., <em>in the trumpet,</em>]</span> means <span class="add">[also]</span> ‡ <em>he spoke that in which was no profit.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: <span class="ar">بُوقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buwqN_A2">
					<p><span class="add">[Hence,]</span> † <em>One who does not conceal a secret;</em> <span class="auth">(Lth, JK, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَوْقٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: <span class="ar">بُوقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buwqN_A3">
					<p>Also <em>A certain thing in which the miller blows;</em> <span class="auth">(JK, Ḳ;)</span> accord. to the copies of the Ḳ, <em>resembling a</em> <span class="ar">مِنْقَاب</span>; but this is a mistake: <span class="auth">(TA:)</span> it is <em>a thing resembling a</em> <span class="add">[<em>shell of the kind called</em>]</span> <span class="ar">مِنْقَاب</span>, <em>the hole of which is twisted; and sometimes the miller blows in it, raising his voice; and what he means thereby is known.</em> <span class="auth">(Lth, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: <span class="ar">بُوقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buwqN_B1">
					<p><a href="#baWoqN">See also <span class="ar">بَوْقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqapN">
				<h3 class="entry"><span class="ar">بَاقَةٌ</span></h3>
				<div class="sense" id="baAqapN_A1">
					<p><span class="ar">بَاقَةٌ</span> <em>A bundle</em> of herbs, or leguminous plants. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<em>And in modern Arabic, A bunch</em> of flowers.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwqapN">
				<h3 class="entry"><span class="ar">بُوقَةٌ</span></h3>
				<div class="sense" id="buwqapN_A1">
					<p><span class="ar">بُوقَةٌ</span> <em>A shower, fall,</em> or <em>storm, of rain,</em> <span class="auth">(JK, Ṣ,)</span> <em>that has burst forth with a dash:</em> <span class="auth">(Ṣ, TA:)</span> or <em>such as is vehement;</em> or <em>disapproved, disliked,</em> or <em>deemed evil:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">بُوَقٌ</span>. <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baWuwqN">
				<h3 class="entry"><span class="ar">بَؤُوقٌ</span></h3>
				<div class="sense" id="baWuwqN_A1">
					<p><span class="ar">بَؤُوقٌ</span>, or <span class="ar long">دَاهِيَةٌ بَؤُوقٌ</span>, <em>A vehement calamity</em> or <em>misfortune</em> or <em>disaster.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوق</span> - Entry: <span class="ar">بَؤُوقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baWuwqN_A2">
					<p>And the former, applied to a man, <em>Thievish; a great thief.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYiqapN">
				<h3 class="entry"><span class="ar">بَائِقَةٌ</span></h3>
				<div class="sense" id="baAYiqapN_A1">
					<p><span class="ar">بَائِقَةٌ</span> <em>A calamity, misfortune,</em> or <em>disaster;</em> <span class="auth">(JK, Ṣ, Mṣb, Ḳ;)</span> <em>a vehement evil</em> or <em>mischief;</em> <span class="auth">(Mṣb;)</span> <em>a trail that befalls a people:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بَوَائِقٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> It is said in a trad., <span class="ar long">لَا يَدْخُلُ الجَنَّةَ مَنْ لَا يَأْمَنُ جَارَهُ بَوَائِقَهُ</span>, meaning, accord. to Ḳatádeh, <span class="add">[<em>He will not enter Paradise whose neighbour is not secure from</em>]</span> <em>his wrongful,</em> or <em>injurious, conduct:</em> or, accord. to Ks, <em>his malevolent,</em> or <em>mischievous, dispositions,</em> and <em>his evil conduct.</em> <span class="auth">(Ṣ.)</span> IF says, in the “Makáyees,” that <span class="ar">بوق</span> is not an accredited root, and that there is not, in his opinion, any correct word belonging to it. <span class="auth">(TA.)</span> <span class="add">[But this is a strange assertion.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0276.pdf" target="pdf">
							<span>Lanes Lexicon Page 276</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
