<article class="root" id="Root_bTl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/132_bTq">بطق</a></span>
				<span class="ar">بطل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/134_bTm">بطم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطل</span></h3>
				<div class="sense" id="bTl_1_A1">
					<p><span class="ar">بَطَلَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُلُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">بُطْلٌ</span> and <span class="ar">بُطُولٌ</span> and <span class="ar">بُطْلَانٌ</span>, <span class="add">[of which the last seems to be the most common,]</span> <span class="auth">(Ṣ, Mṣb, Ḳ, KL, &amp;c.,)</span> <em>It</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became,</em> <span class="ar">بَاطِل</span>, as meaning <em>contr. of</em> <span class="ar">حَقّ</span>; <span class="auth">(Ṣ;)</span> <span class="add">[i. e.,]</span> <em>it was,</em> or <em>became, false, untrue, wrong</em> or <em>incorrect, fictitious, spurious, unfounded, unsound,</em> <span class="auth">(KL,)</span> <em>vain, unreal, naught, futile, worthless, useless, unprofitable,</em> <span class="auth">(KL, PṢ,)</span> <em>devoid of virtue</em> or <em>efficacy, ineffectual, null, void, of no force,</em> or <em>of no account;</em> <span class="auth">(Mṣb;)</span> <em>it went for nothing, as a thing of no account,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> or <em>as a thing that had perished</em> or <em>become lost.</em> <span class="auth">(Ḳ.)</span> <span class="add">[It is said of an assertion or allegation and the like, and of a deed, &amp;c.]</span> Hence the saying in the Ḳur <span class="add">[vii. 115]</span>, <span class="ar long">وَبَطَلَ مَا كَانُوا يَعْمَلُونَ</span> <span class="add">[<em>And what they were doing became vain,</em> or <em>null;</em> or <em>went for nothing, as a thing of no account</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">ذَهَبَ دَمُهُ بُطْلًا</span> <em>His blood went for nothing,</em> <span class="add">[<em>unretaliated, and uncompensated by a mulet,</em>]</span> <em>as a thing of no account.</em> <span class="auth">(Ṣ, Mṣb.)</span> And <span class="ar long">بَطَلَ دَمُهُ</span> <span class="add">[signifies the same; or]</span> <em>He was slain without there being obtained for him either blood-revenge or blood-wit.</em> <span class="auth">(Er-Rághib, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTl_1_A2">
					<p>See also the inf. n. <span class="ar">بُطُولٌ</span> below, voce <span class="ar">بَطَّالٌ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTl_1_A3">
					<p><span class="ar long">لَبَطُلَ القَوْلُ</span> <span class="add">[<em>How false, untrue, wrong</em> or <em>incorrect,</em>, &amp;c., <em>is the saying!</em>]</span> is said in wonder at that which is <span class="ar">بَاطِل</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTl_1_A4">
					<p><span class="ar">بَطَلَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">بَطَلَ مِنَ العَمَلِ</span>, <span class="auth">(Mṣb,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُلُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَطَالَةٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ, KL)</span> and <span class="ar">بِطَالَةٌ</span>, which is mentioned by one of the expositors of the Moʼallaḳát, and said to be the more chaste, and sometimes one says <span class="ar">بُطَالَةٌ</span>, to make it accord with its contr. <span class="ar">عُمَالَةٌ</span>, <span class="auth">(Mṣb,)</span> <em>He</em> <span class="auth">(a hired man, or hireling,)</span> <em>was,</em> or <em>became, idle, unoccupied,</em> or <em>without work.</em> <span class="auth">(Ṣ, Mṣb,* Ḳ, KL. <span class="add">[<a href="#bTl_5">See also 5</a>.]</span>)</span> <span class="add">[Hence, <span class="ar long">يَوْمُ بَطَالَةٍ</span> <em>A day of idleness; a holiday.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bTl_1_A5">
					<p><span class="ar">بِطَالَةٌ</span>, with kesr, also signifies The <em>being diverted from that which would bring profit in the present life or in the life to come.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bTl_1_A6">
					<p><a href="#bTl_2">See also 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bTl_1_A7">
					<p><span class="ar long">بَطَلَ فِى حَدِيثِهِ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُلُ</span>}</span></add>; so it seems to be from the context in the Ḳ, but correctly <span class="ar">بَطِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْطَلُ</span>}</span></add>, as in the Jm; <span class="auth">(TA;)</span> inf. n. <span class="ar">بَطَالَةٌ</span> <span class="auth">(Ḳ)</span> <span class="add">[and app. <span class="ar">بُطُولٌ</span> also; <a href="#baTBaAlN">see <span class="ar">بَطَّالٌ</span></a>]</span>; <em>He jested,</em> or <em>joked,</em> or <em>was not serious</em> or <em>in earnest, in his discourse;</em> as also<span class="arrow"><span class="ar">ابطل↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTl_1_B1">
					<p><span class="ar">بَطُلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُلُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَطَالَةٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ, KL)</span> and <span class="ar">بِطَالَةٌ</span> <span class="auth">(Lth, Mṣb, TA)</span> and <span class="ar">بُطَالَةٌ</span> <span class="auth">(TA)</span> and <span class="ar">بُطُولَةٌ</span>, <span class="auth">(Ṣ, Ḳ, KL,)</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, courageous, brave,</em> or <em>stronghearted, on the occasion of war,</em> or <em>fight; such as is termed</em> <span class="ar">بَطَلٌ</span>, q. v.; <span class="auth">(Ṣ, Mṣb, Ḳ, KL;)</span> as also<span class="arrow"><span class="ar">تبطّل↓</span></span>: <span class="auth">(Ḳ:)</span> or this last signifies <em>he affected courage,</em>, &amp;c.; <em>he made himself,</em> or <em>constrained himself to be, courageous,</em>, &amp;c.; syn. <span class="ar">تَشَجَّعَ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bTl_1_B2">
					<p><span class="ar long">لَبَطُلَ الرَّجُلُ</span> <span class="add">[<em>How courageous,</em>, &amp;c., <em>is the man!</em>]</span> is said in wonder at <span class="ar">التَّبَطُّل</span> <span class="add">[i. e. courage, &amp;c., or the affecting of courage, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بطّل</span></h3>
				<div class="sense" id="bTl_2_A1">
					<p><span class="ar">التَّبْطِيلُ</span> <span class="add">[inf. n. of <span class="ar">بطّل</span>]</span> signifies<span class="arrow"><span class="ar long">فِعْلُ البطالهِ↓</span></span>, <span class="add">[in which the latter word is written in the TA without any indication of the vowel of the <span class="ar">ب</span>,]</span> i. e. <em>The pursuit of vain,</em> or <em>frivolous, diversion</em> or <em>sport, and foolish,</em> or <em>ignorant, conduct.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#biTaAlapN">See <span class="ar">بِطَالَةٌ</span>, above</a>, and the phrase next following it.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTl_2_B1">
					<p><a href="#bTl_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTl_4">
				<span class="pb" id="Page_0219"></span>
				<h3 class="entry">4. ⇒ <span class="ar">ابطل</span></h3>
				<div class="sense" id="bTl_4_A1">
					<p><span class="ar">ابطل</span> <em>He said,</em> or <em>spoke, what was false,</em> or <em>untrue;</em> <span class="auth">(Mgh, Mṣb, Ḳ;)</span> <span class="add">[<em>contr. of</em> <span class="ar">أَحَقَّ</span>;]</span> <em>he lied:</em> <span class="auth">(Mgh:)</span> <em>he made a false,</em> or <em>vain, claim</em> or <em>demand; he claimed,</em> or <em>demanded, for himself that which was not right,</em> or <em>just.</em> <span class="auth">(Lth, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTl_4_A2">
					<p><a href="#bTl_1">See also 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTl_4_B1">
					<p><span class="ar">ابطلهُ</span> <span class="add">[and vulgarly <span class="arrow"><span class="ar">بطّلهُ↓</span></span>]</span> <em>He made it,</em> or <em>rendered it,</em> <span class="add">[and <em>he proved it to be,</em>]</span> <span class="ar">بَاطِل</span>, i. e. <em>false, untrue, wrong</em> or <em>incorrect, fictitious, spurious, unfounded, unsound, vain, unreal, naught, futile, worthless, useless, unprofitable,</em> <span class="auth">(Ṣ,* L, Ḳ, TA,)</span> <em>devoid of virtue</em> or <em>efficacy, ineffectual, null, void, of no force,</em> or <em>of no account;</em> <span class="auth">(Mṣb, TA;)</span> <em>he nullified it, annulled it, abolished it, cancelled it;</em> whether it was true or false, right or wrong, authentic or spurious, valid or null; <span class="auth">(TA;)</span> <em>he made it to go for nothing, as a thing of no account,</em> or <em>as a thing that had perished</em> or <em>become lost.</em> <span class="auth">(Ḳ.)</span> Hence, <span class="ar long">ابطل شَهَادَتَهُ</span> <em>He annulled his testimony.</em> <span class="auth">(TA in art. <span class="ar">زور</span>.)</span> And <span class="ar long">لِيُحِقَّ الحَقَّ وَيُيْطِلَ البَاطِلَ</span>, in the Ḳur <span class="add">[viii. 8, meaning <em>That He might establish that which is true, and annul that which is false</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبطّل</span></h3>
				<div class="sense" id="bTl_5_A1">
					<p><span class="ar long">تبطّلوا بَيْنَهُمْ</span> <em>They took it by turns to say,</em> or <em>to do, that which was false, wrong, vain, futile,</em> or <em>the like;</em> syn. <span class="ar long">تَدَالُوا البَاطِلَ</span>. <span class="auth">(Az, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTl_5_A2">
					<p><span class="add">[<span class="ar">تبطّل</span>, said in the Mgh to be from <span class="ar">البَطَالَةُ</span>, (<a href="#baTala">see <span class="ar">بَطَلَ</span></a>, or <span class="ar long">بَطَلَ مِنَ العَمَلِ</span>,) app. signifies, as its part. n. <span class="auth">(q. v. voce <span class="ar">بَطَّالٌ</span>)</span> indicates, <em>He became unoccupied and lazy.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTl_5_B1">
					<p><a href="#bTl_1">See also 1</a>, near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buTolN">
				<h3 class="entry"><span class="ar">بُطْلٌ</span></h3>
				<div class="sense" id="buTolN_A1">
					<p><span class="ar">بُطْلٌ</span> <span class="add">[<a href="#bTl_1">originally an inf. n. of 1</a>, and mentioned therewith, first sentence:]</span> <em>i. q.</em> <span class="ar">بَاطِلٌ</span>, q. v. <span class="auth">(Ḥam p. 114.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTalN">
				<h3 class="entry"><span class="ar">بَطَلٌ</span></h3>
				<div class="sense" id="baTalN_A1">
					<p><span class="ar">بَطَلٌ</span>, said to be the only epithet of its measure except <span class="ar">حَسَنٌ</span>; <span class="auth">(TA in art. <span class="ar">حسن</span>;)</span> applied to a man, <em>Courageous, brave,</em> or <em>strong-hearted, on the occasion of war,</em> or <em>fight;</em> <span class="add">[commonly used as a subst., meaning <em>a man of courage</em> or <em>valour, a brave man, a hero;</em>]</span> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَطَّالٌ↓</span></span>; <span class="auth">(Ḳ;)</span> one <em>whose wound goes for nothing, so that he does not care for it,</em> <span class="auth">(Lth, Ḳ,)</span> <em>and it does not withhold him from the exercise of his courage;</em> <span class="auth">(Lth, TA;)</span> or <em>the blood of whose adversaries goes for nothing with him,</em> <span class="auth">(Ḳ,)</span> <em>unrevenged:</em> <span class="auth">(TA:)</span> or for this reason he is thus called; <span class="auth">(TA;)</span> or because life is annulled, or made to go for nothing, on the occasion of encountering him, and severe misfortunes are annulled by him, <span class="auth">(Mṣb,)</span> or by his sword, and made to be of no account: <span class="auth">(TA:)</span> and so<span class="arrow"><span class="ar">بَطَلَةٌ↓</span></span> applied to a woman; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> accord. to one of the expositors of the Ḥamáseh; <span class="auth">(Mṣb;)</span> but AZ says that this is not allowable: <span class="auth">(IDrd, TA:)</span> <a href="#baTalN">the pl. of <span class="ar">بَطَلٌ</span></a> is <span class="ar">أَبْطَالٌ</span>. <span class="auth">(Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baTalapN">
				<h3 class="entry"><span class="ar">بَطَلَةٌ</span></h3>
				<div class="sense" id="baTalapN_A1">
					<p><span class="ar">بَطَلَةٌ</span>: <a href="#baATilN">see <span class="ar">بَاطِلٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: <span class="ar">بَطَلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baTalapN_B1">
					<p><a href="#baTalN">and see also <span class="ar">بَطَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTolaAnu">
				<h3 class="entry"><span class="ar">بَطْلَانُ</span></h3>
				<div class="sense" id="baTolaAnu_A1">
					<p><span class="ar">بَطْلَانُ</span> One <em>whose powers have become weak:</em> but this is a vulgar word. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buTBalaAtN">
				<h3 class="entry"><span class="ar">بُطَّلَاتٌ</span></h3>
				<div class="sense" id="buTBalaAtN_A1">
					<p><span class="ar">بُطَّلَاتٌ</span> (<a href="#buTBalN">pl. of <span class="ar">بُطَّلٌ</span></a>, TA) <em>False,</em> or <em>vain, things;</em> or <em>unprofitable sayings.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> You say, <span class="ar long">جَآءَ بِالبُطَّلَاتِ</span> <em>He uttered false,</em> or <em>vain, things;</em>, &amp;c. <span class="auth">(El-Moḥeeṭ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTBaAlN">
				<h3 class="entry"><span class="ar">بَطَّالٌ</span></h3>
				<div class="sense" id="baTBaAlN_A1">
					<p><span class="ar">بَطَّالٌ</span>, applied to a man, signifies<span class="arrow"><span class="ar long">ذُو بَاطِلٍ↓ بَيِّنٌ البُطُولِ↓</span></span> <span class="add">[app. meaning <em>Having a vain,</em> or <em>false, object</em> or <em>pursuit; manifesting the having such an object</em> or <em>pursuit:</em> or, accord. to an explanation of <span class="ar long">ذو باطل</span> by Bḍ in xxxviii. 26, <em>i. q.</em> <span class="ar">مُبْطِلٌ</span> and <span class="ar">عَابِثٌ</span>, i. e. <em>jesting,</em> or <em>joking;</em> (<a href="#baTala">see <span class="ar long">بَطَلَ فِى حَدِيثِهِ</span></a>, or <span class="ar">بَطِلَ</span>;) or <em>saying what is untrue:</em> and <em>playing,</em> or <em>sporting,</em> and <em>doing that in which is no profit;</em> as also<span class="arrow"><span class="ar">بَاطِلٌ↓</span></span>, q. v.]</span>: <span class="auth">(Ḳ:)</span> one <em>who jests,</em> or <em>jokes, in his discourse:</em> one <em>who is diverted from that which would bring profit in the present life or in that which is to come:</em> <span class="auth">(TA:)</span> <em>idle; unoccupied:</em> <span class="auth">(Ṣ, Mṣb:)</span> or <em>exceedingly,</em> or <em>extremely, idle:</em> <span class="auth">(KL:)</span> or <em>unoccupied and lazy;</em> as also<span class="arrow"><span class="ar">مُتَبَطِّلٌ↓</span></span>. <span class="auth">(Mgh.)</span> <span class="add">[In the present day it is commonly used as signifying <em>Bad, worthless,</em> and <em>useless;</em> applied to a man and to anything.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: <span class="ar">بَطَّالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baTBaAlN_B1">
					<p><a href="#baTalN">See also <span class="ar">بَطَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baATilN">
				<h3 class="entry"><span class="ar">بَاطِلٌ</span></h3>
				<div class="sense" id="baATilN_A1">
					<p><span class="ar">بَاطِلٌ</span> <em>contr. of</em> <span class="ar">حَقٌّ</span>; <span class="auth">(Ṣ, Ḳ;)</span> i. e. <em>False, untrue, wrong</em> or <em>incorrect, fictitious, spurious, unfounded, unsound,</em> <span class="auth">(KL,)</span> <em>vain, unreal, naught, futile, worthless, useless, unprofitable,</em> <span class="auth">(KL, PṢ,)</span> <em>devoid of virtue</em> or <em>efficacy, ineffectual, null, void, of no force,</em> or <em>of no effect;</em> <span class="auth">(Mṣb;)</span> <em>that proves, when inquired into,</em> or <em>investigated, to be false, wrong, unfounded, unsound,</em> or <em>not established;</em> applying to a saying, and <span class="add">[sometimes]</span> to a deed: <span class="auth">(TA:)</span> <span class="add">[<em>going for nothing, as a thing of no account,</em> or <em>as a thing that has perished</em> or <em>become lost:</em> <span class="auth">(see the verb, 1, first sentence:)</span> often used as a subst., meaning <em>a false,</em> or <em>vain, saying,</em> or <em>assertion,</em> or <em>allegation; a lie; a falsehood:</em> and <em>a false,</em> or <em>vain, deed,</em> or <em>action,</em> or <em>affair,</em> or <em>thing;</em>, &amp;c.:]</span> and<span class="arrow"><span class="ar">بُطْلٌ↓</span></span> is syn. therewith, <span class="auth">(Ḥam p. 114,)</span> and so are <span class="arrow"><span class="ar">أُبْطُولَةٌ↓</span></span> and<span class="arrow"><span class="ar">إِبْطَالَةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> <a href="#baATilN">the pl. of <span class="ar">بَاطِلٌ</span></a> is <span class="ar">بَوَاطِلُ</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">بُطُلٌ</span> occurs as a pl. of the same; <span class="auth">(Ḥam p. 360;)</span> or its pl. is <span class="ar">أَبَاطِيلُ</span>, contr. to analogy, <span class="auth">(Ṣ, Mṣb,)</span> as though the sing. were <span class="ar">إِبْطِيلٌ</span>; <span class="auth">(Ṣ;)</span> or, accord. to AḤát, this is pl. of<span class="arrow"><span class="ar">أُبْطُولَةٌ↓</span></span>, or, as some say, of <span class="arrow"><span class="ar">إِبْطَالَةٌ↓</span></span>, <span class="auth">(Mṣb,)</span> or, accord. to Aṣ and AḤát and IDrd, of both these; <span class="auth">(TA;)</span> and signifies <em>false,</em> or <em>vain, sayings</em> and <em>actions</em> or <em>deeds.</em> <span class="auth">(Ḳ in art. <span class="ar">هتر</span>, &amp;c.)</span> You say, <span class="ar long">قَدْ قُلْتَ بَاطِلًا</span> <span class="add">[<em>Thou hast said a false,</em> or <em>vain, saying; a lie; a falsehood</em>]</span>; like as you say, <span class="ar long">قَدْ قُلْتَ حَقًّا</span>. <span class="auth">(Ḥam p. 360.)</span> And <span class="ar long">يَأْكُلُونَ أَمْوَالَ النَّاسِ بِالبَاطِلِ</span> <span class="add">[<em>They devour the possessions of men by false pretence</em>]</span>. <span class="auth">(Ḳur ix. 34.)</span> And<span class="arrow"><span class="ar long">بَيْنَهُمْ أُبْطُولَةٌ↓</span></span> and<span class="arrow"><span class="ar">إِبْطَالَةٌ↓</span></span> <span class="add">[<em>Between them is false,</em> or <em>vain, speech,</em> or <em>discourse,</em>, &amp;c.]</span>; syn. <span class="ar">بَاطِلٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: <span class="ar">بَاطِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baATilN_A2">
					<p>The <em>belief in a plurality of Gods:</em> so explained as occurring in the Ḳur xlii. 23. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: <span class="ar">بَاطِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baATilN_A3">
					<p><a href="#baTBaAlN">See also <span class="ar">بَطَّالٌ</span></a>, in two places. <span class="add">[Hence,]</span> <span class="ar">بَاطِلًا</span> <em>In play,</em> or <em>sport; acting unprofitably;</em> or <em>aiming at no profit.</em> <span class="auth">(Jel in iii. 188 and xxxviii. 26.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطل</span> - Entry: <span class="ar">بَاطِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baATilN_A4">
					<p><span class="ar">البَاطِلُ</span> <em>Iblees:</em> so in the Ḳur <span class="add">[xxxiv. 48]</span>, where it is said, <span class="ar long">مَا يُبْدِئُ ٱلْبَاطِلُ وَمَا يُعِيدُ</span> <span class="add">[<a href="../">explained in art. <span class="ar">بدأ</span></a>]</span>: <span class="auth">(Ḳatádeh, Ḳ:)</span> and again <span class="add">[xli. 42]</span>, where it is said, <span class="ar long">لَا يَأْتِيهِ ٱلْبَاطِلُ مِنْ بَيْنَ يَدَيْهِ وَلَا مِنْ خَلْفِهِ</span>, <span class="add">[accord. to some,]</span> meaning that Iblees shall not add to the Ḳur-án nor diminish therefrom: <span class="auth">(TA:)</span> <span class="arrow"><span class="ar">بَطَلَةٌ↓</span></span> <span class="add">[is its pl., and]</span> signifies <em>devils:</em> <span class="auth">(A, TA:)</span> or <em>enchanters.</em> <span class="auth">(O, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiboTaAlapN">
				<h3 class="entry"><span class="ar">إِبْطَالَةٌ</span></h3>
				<div class="sense" id="IiboTaAlapN_A1">
					<p><span class="ar">إِبْطَالَةٌ</span>: <a href="#baATilN">see <span class="ar">بَاطِلٌ</span></a>; for each in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuboTuwlapN">
				<h3 class="entry"><span class="ar">أُبْطُولَةٌ</span></h3>
				<div class="sense" id="OuboTuwlapN_A1">
					<p><span class="ar">أُبْطُولَةٌ</span>: <a href="#baATilN">see <span class="ar">بَاطِلٌ</span></a>; for each in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboTilN">
				<h3 class="entry"><span class="ar">مُبْطِلٌ</span></h3>
				<div class="sense" id="muboTilN_A1">
					<p><span class="ar">مُبْطِلٌ</span> One <em>who says a thing in which is no truth,</em> or <em>reality:</em> <span class="auth">(Er-Rághib, TA:)</span> one <em>who embellishes speech with lies:</em> <span class="auth">(Bḍ in xxx. 58:)</span> one <em>who says,</em> or <em>does, false,</em> or <em>vain, things.</em> <span class="auth">(Jel ibid.)</span> <span class="add">[See also its verb, 4.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutabaTBilN">
				<h3 class="entry"><span class="ar">مُتَبَطِّلٌ</span></h3>
				<div class="sense" id="mutabaTBilN_A1">
					<p><span class="ar">مُتَبَطِّلٌ</span>: <a href="#baTBaAlN">see <span class="ar">بَطَّالٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0218.pdf" target="pdf">
							<span>Lanes Lexicon Page 218</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0219.pdf" target="pdf">
							<span>Lanes Lexicon Page 219</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
