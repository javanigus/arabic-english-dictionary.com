<article class="root" id="Root_bcx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/051_bcO">بذأ</a></span>
				<span class="ar">بذخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/053_bcr">بذر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bcx_1">
				<h3 class="entry">1. ⇒ <span class="ar">بذخ</span></h3>
				<div class="sense" id="bcx_1_A1">
					<p><span class="ar">بَذِخَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَخُ</span>}</span></add>, inf. n. <span class="ar">بَذَخٌ</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">بَذَخَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَخُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُخُ</span>}</span></add>, <span class="auth">(see what follows,)</span>]</span> inf. n. <span class="ar">بُذُوخٌ</span>; <span class="auth">(L;)</span> <em>It</em> <span class="auth">(a mountain)</span> <em>was high,</em> or <em>lofty.</em> <span class="auth">(L, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcx_1_A2">
					<p>And hence, <span class="auth">(Mṣb,)</span> <span class="ar">بَذِخَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَخُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَذخٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and <span class="ar">بَذَخَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَخُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُخُ</span>}</span></add>, but the former is the more approved, inf. n. <span class="ar">بَذْخٌ</span> and <span class="ar">بُذُوخٌ</span>; <span class="auth">(L;)</span> † <em>He was,</em> or <em>became, proud,</em> and <em>lofty,</em> or <em>haughty;</em> <span class="auth">(Ṣ, Mṣb,* Ḳ;)</span> as also<span class="arrow"><span class="ar">تبذّخ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> ‡ <em>he exalted himself above others,</em> <span class="auth">(L, TA,)</span> as also<span class="arrow"><span class="ar">تبذّخ↓</span></span>, <span class="auth">(A,)</span> <em>by his speech, and his glorying,</em> or <em>boasting.</em> <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bcx_1_A3">
					<p>And <span class="ar">بَذَخَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَخُ</span>}</span></add>, inf. n. <span class="ar">بَذَخَانٌ</span>, ‡ <em>He</em> <span class="auth">(a camel)</span> <em>brayed in the most vehement manner,</em> <span class="auth">(L, TA,)</span> <em>and put forth his</em> <span class="ar">شِقشِقَة</span> <span class="add">[or <em>faucial bag</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bcx_1_B1">
					<p><span class="ar">بَذَخَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَخُ</span>}</span></add>, inf. n. <span class="ar">بَذْخٌ</span>, <em>He split, clave, rifted, slit,</em> or <em>rent,</em> a thing. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcx_3">
				<h3 class="entry">3. ⇒ <span class="ar">باذخ</span></h3>
				<div class="sense" id="bcx_3_A1">
					<p><span class="ar">باذخهُ</span> † <em>He vied,</em> or <em>competed,</em> or <em>contended, with him in glorying</em> or <em>boasting,</em> or <em>in glory</em> or <em>excellence,</em> or <em>for superiority in nobleness.</em> <span class="auth">(L, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bcx_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبذّخ</span></h3>
				<div class="sense" id="bcx_5_A1">
					<p><a href="#bcx_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bicoxN">
				<h3 class="entry"><span class="ar">بِذْخٌ</span></h3>
				<div class="sense" id="bicoxN_A1">
					<p><span class="ar">بِذْخٌ</span>: <a href="#baAcixN">see <span class="ar">بَاذِخٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bicixo">
				<h3 class="entry"><span class="ar">بِذِخْ</span></h3>
				<div class="sense" id="bicixo_A1">
					<p><span class="ar">بِذِخْ</span> and <span class="ar">بَذَخْ</span> <span class="add">[for the latter of which, in the CK, we find <span class="ar">بَذِخْ</span>,]</span> <em>i. q.</em> <span class="ar">بَخْ</span> <span class="add">[<em>Excellent!</em>, &amp;c.]</span>; <span class="auth">(JK, T, Ḳ, TA;)</span> and <em>wonderful!</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: <span class="ar">بِذِخْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bicixo_A2">
					<p><span class="ar long">بِذِخْ بِذِخْ</span> is also said in chiding a camel that brays in the most vehement manner, (<a href="#bacaxa">see <span class="ar">بَذَخَ</span></a>,) or in imitating his braying. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bacixN">
				<h3 class="entry"><span class="ar">بَذِخٌ</span></h3>
				<div class="sense" id="bacixN_A1">
					<p><span class="ar">بَذِخٌ</span>: <a href="#baAcixN">see <span class="ar">بَاذِخٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bucaAxiyBN">
				<h3 class="entry"><span class="ar">بُذَاخِيٌّ</span></h3>
				<div class="sense" id="bucaAxiyBN_A1">
					<p><span class="ar">بُذَاخِيٌّ</span> <em>Great;</em> syn. <span class="ar">عَظِيمٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bacBaAxN">
				<h3 class="entry"><span class="ar">بَذَّاخٌ</span></h3>
				<div class="sense" id="bacBaAxN_A1">
					<p><span class="ar">بَذَّاخٌ</span>: <a href="#baAcixN">see what next follows</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAcixN">
				<h3 class="entry"><span class="ar">بَاذِخٌ</span></h3>
				<div class="sense" id="baAcixN_A1">
					<p><span class="ar">بَاذِخٌ</span> <em>High,</em> or <em>lofty;</em> <span class="auth">(JK, A, Mṣb;)</span> applied to a mountain: <span class="auth">(JK, Mṣb:)</span> <span class="add">[and]</span> <em>a high,</em> or <em>lofty, mountain;</em> an epithet in which the quality of a subst. is predominant: <span class="auth">(L, TA:)</span> pl. <span class="ar">بَوَاذِخُ</span> <span class="auth">(JK, Ṣ, A, L, Mṣb)</span> and <span class="ar">بَاذِخَاتٌ</span> <span class="add">[both fem. forms]</span>: <span class="auth">(JK:)</span> and the former pl. applied as an epithet to mountains. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: <span class="ar">بَاذِخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAcixN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">رَجُلٌ بَاذِخٌ</span>, <span class="auth">(JK, L,)</span> and<span class="arrow"><span class="ar">بَذَّاخٌ↓</span></span>, <span class="auth">(JK, A, L,)</span> <span class="add">[the latter an intensive epithet,]</span> ‡ <em>A proud,</em> and <em>lofty,</em> or <em>haughty, man, who exalts himself above others,</em> <span class="auth">(JK, A, L,)</span> <em>by his speech, and his glorying,</em> or <em>boasting:</em> <span class="auth">(JK, L:)</span> pl. of the former <span class="ar">بُذَخَآءُ</span>, like as <span class="ar">عُلَمَآءُ</span> <a href="#EaAlimN">is pl. of <span class="ar">عَالِمٌ</span></a>, and <span class="ar">بُذَّخٌ</span>. <span class="auth">(L.)</span> You say, In speech, he is <span class="arrow"><span class="ar">بَذَّاخٌ↓</span></span>; and in poetry, <span class="ar">بَاذِخٌ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: <span class="ar">بَاذِخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAcixN_A3">
					<p>And <span class="ar long">شَرَفٌ بَاذِخٌ</span> ‡ <em>High,</em> or <em>exalted, nobility.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذخ</span> - Entry: <span class="ar">بَاذِخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAcixN_A4">
					<p><span class="ar long">بَعِيرٌ بَاذِخٌ</span>, <span class="auth">(L,)</span> and<span class="arrow"><span class="ar">بَذَّاخٌ↓</span></span>, <span class="auth">(L, Ḳ,)</span> or<span class="arrow"><span class="ar long">بَذَّاخُ↓ الهَدِيرِ</span></span>, <span class="auth">(A,)</span> and<span class="arrow"><span class="ar">بِذْخٌ↓</span></span>, and<span class="arrow"><span class="ar">بَذِخٌ↓</span></span>, <span class="auth">(Ḳ,)</span> ‡ <em>A camel that brays much,</em> <span class="auth">(Ḳ,)</span> or <em>in the most vehement manner,</em> <span class="auth">(L,)</span> <em>and puts forth his</em> <span class="ar">شِقْشِقَة</span> <span class="add">[or <em>faucial bag</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayocaxN">
				<h3 class="entry"><span class="ar">بَيْذَخٌ</span></h3>
				<div class="sense" id="bayocaxN_A1">
					<p><span class="ar">بَيْذَخٌ</span> A <em>large-bodied,</em> or <em>corpulent,</em> woman; <span class="auth">(Ṣ, Ḳ;)</span> as also <span class="ar">بَيْدَخٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0173.pdf" target="pdf">
							<span>Lanes Lexicon Page 173</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
