<article class="root" id="Root_bwm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/224_bwl">بول</a></span>
				<span class="ar">بوم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/226_bwn">بون</a></span>
			</h2>
			<hr>
			<section class="entry main" id="buwmN">
				<h3 class="entry"><span class="ar">بُومٌ</span></h3>
				<div class="sense" id="buwmN_A1">
					<p><span class="ar">بُومٌ</span> and <span class="ar">بُومَةٌ</span> <em>A certain bird;</em> <span class="add">[namely, the <em>owl;</em>]</span> each word applying to the <em>male</em> and the <em>female:</em> <span class="auth">(Ṣ, Ḳ:)</span> or the former signifies the <em>male,</em> or <em>males,</em> <span class="auth">(so in different copies of the M,)</span> <em>of the</em> <span class="ar">هَام</span> <span class="add">[or <em>owl-kind</em>]</span>; and the latter is its n. un.: <span class="auth">(M, TA:)</span> said by Az to be genuine Arabic: <span class="auth">(TA:)</span> pl. of the former <span class="ar">أَبْوَامٌ</span>. <span class="auth">(IB, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawBaAmN">
				<h3 class="entry"><span class="ar">بَوَّامٌ</span></h3>
				<div class="sense" id="bawBaAmN_A1">
					<p><span class="ar long">بُومٌ بَوَّامٌ</span> <span class="add">[<em>An owl,</em> or <em>male owls,</em>]</span> <em>that cries,</em> or <em>that cry, much.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0278.pdf" target="pdf">
							<span>Lanes Lexicon Page 278</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
