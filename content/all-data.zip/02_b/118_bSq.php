<article class="root" id="Root_bSq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/117_bSE">بصع</a></span>
				<span class="ar">بصق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/119_bSl">بصل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bSq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بصق</span></h3>
				<div class="sense" id="bSq_1_A1">
					<p><span class="ar">بَصَقَ</span>, <span class="auth">(Lth, JK, Ṣ, Ḳ,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْصُقُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَصْقٌ</span>, <span class="auth">(Ṣ,)</span> <em>i. q.</em> <span class="ar">بَزَقَ</span> <span class="auth">(Lth, Ṣ,* Ḳ)</span> or <span class="ar">بَسَقَ</span> <span class="auth">(JK)</span> <span class="add">[<em>He spat</em>]</span>: it is the most chaste of these three verbs. <span class="auth">(TA in art. <span class="ar">بسق</span>.)</span> <span class="ar long">بَصَقَ فِى وَجْهِهِ</span> <span class="add">[lit. <em>He spat in his face,</em>]</span> means † <em>he held him in contempt,</em> or <em>despised him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bSq_1_B1">
					<p><em>He milked</em> a ewe <em>when she was with young.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSq_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابصق</span></h3>
				<div class="sense" id="bSq_4_A1">
					<p><span class="ar">ابصقت</span> <em>She</em> <span class="auth">(a ewe)</span> <em>excerned the milk</em> <span class="add">[or <em>biestings into her udder before bringing forth</em>]</span>; <span class="auth">(JK, Ḳ;)</span> like <span class="ar">ابسقت</span> <span class="add">[q. v.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bSq_4_A2">
					<p><span class="ar">ابصق</span> is also said of the <span class="ar">قَصَد</span>, or small juicy branches, in the <span class="add">[species of mimosa termed]</span> <span class="ar">عُرْفُط</span> <span class="add">[app. as meaning <em>They excerned a matter like spittle</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSoqapN">
				<h3 class="entry"><span class="ar">بَصْقَةٌ</span></h3>
				<div class="sense" id="baSoqapN_A1">
					<p><span class="ar">بَصْقَةٌ</span> <em>A</em> <span class="add">[<em>stony tract such as is termed</em>]</span> <span class="ar">حَرَّة</span> <em>somewhat elevated;</em> <span class="add">[as also <span class="ar">بَسْقَةٌ</span>:]</span> pl. <span class="ar">بِصَاقٌ</span>. <span class="auth">(AA, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buSaAqN">
				<h3 class="entry"><span class="ar">بُصَاقٌ</span></h3>
				<div class="sense" id="buSaAqN_A1">
					<p><span class="ar">بُصَاقٌ</span> <em>Spittle,</em> or <em>saliva, that has gone forth from the mouth:</em> as long as it is in the mouth, it is termed <span class="ar">رِيقٌ</span>: <span class="auth">(Ḳ:)</span> <span class="add">[or <em>saliva that flows:</em> <a href="#buzaAqN">see <span class="ar">بُزَاقٌ</span></a>:]</span> <em>i. q.</em> <span class="ar">بُزَاقٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُسَاقٌ</span>: <span class="auth">(Ḳ:)</span> but it is more chaste than either of these. <span class="auth">(TA.)</span> <span class="add">[<span class="ar">بُصَاقَةٌ</span> is app. its n. un. And hence,]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصق</span> - Entry: <span class="ar">بُصَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buSaAqN_A2">
					<p><span class="ar long">بُصَاقَةُ القَمَرِ</span> <em>White glistening stone:</em> <span class="auth">(Ṣ:)</span> or <em>stone of a clear white colour.</em> <span class="auth">(JK, Ḳ.)</span> <span class="add">[Also written with <span class="ar">س</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصق</span> - Entry: <span class="ar">بُصَاقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buSaAqN_B1">
					<p><em>A species of palm-tree.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصق</span> - Entry: <span class="ar">بُصَاقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="buSaAqN_C1">
					<p>The <em>best of camels:</em> both sing. and pl. <span class="auth">(IDrd, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSuwqN">
				<h3 class="entry"><span class="ar">بَصُوقٌ</span></h3>
				<div class="sense" id="baSuwqN_A1">
					<p><span class="ar">بَصُوقٌ</span> A ewe <em>having the least quantity of milk.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0212.pdf" target="pdf">
							<span>Lanes Lexicon Page 212</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
