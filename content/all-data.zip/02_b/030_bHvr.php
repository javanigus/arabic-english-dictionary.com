<article class="root" id="Root_bHvr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/029_bHv">بحث</a></span>
				<span class="ar">بحثر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/031_bHr">بحر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bHvr_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بحثر</span></h3>
				<div class="sense" id="bHvr_Q1_A1">
					<p><span class="ar">بَحْثَرَ</span>, <span class="add">[inf. n. <span class="ar">بَحْثَرَةٌ</span>,]</span> <em>He took, drew,</em> or <em>pulled,</em> a thing <em>out,</em> or <em>forth;</em> and <em>uncovered</em> it, <em>laid</em> it <em>open,</em> or <em> exposed</em> it; <span class="auth">(Abu-l-Jarráh, Ṣ, Ḳ;)</span> as also <span class="ar">بَعْثَرَ</span>. <span class="auth">(Abu-l-Jarráh, Ṣ.)</span> It is said in the Ḳur <span class="add">[c. 9]</span>, accord. to one reading, <span class="ar long">بُعْثِرَ بُحْثِرَ مَا فِى القُبُورِ</span>, <span class="add">[instead of <span class="ar">بُعْثِرَ</span>,]</span> meaning <span class="add">[<em>When that which is in the graves is taken forth and uncovered;</em> i. e.,]</span> <em>when the dead are raised to life;</em> syn. <span class="ar">بُعِثَ</span>; and it is not improbable that <span class="ar">بَحْثَرَ</span> may be composed of <span class="ar">بَحَثَ</span> and <span class="ar">أَثَرَ</span> <span class="add">[app. a mistranscription for <span class="ar">أَثَارَ</span>]</span>, accord. to the opinion of those who hold that quadriliteral and quinqueliteral words are composed of two. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحثر</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHvr_Q1_A2">
					<p><em>He searched,</em> or <em>sought, for,</em> or <em>after,</em> a thing <em>in the dust</em> or <em>earth,</em> or <em>the like;</em> syn. <span class="ar">بَحَثَ</span> <span class="add">[which IbrD thinks may be a mistake for <span class="ar">بَعَثَ</span>: but <a href="#baEovara">see <span class="ar">بَعْثَرَ</span></a>]</span>. <span class="auth">(L, Ḳ, and Bḍ in c. 9.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحثر</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bHvr_Q1_A3">
					<p><em>He separated, disunited, scattered, dispersed,</em> or <em>dissipated,</em> <span class="auth">(Ṣ, Ḳ,)</span> a thing. <span class="auth">(Ṣ.)</span> <em>He scattered,</em> or <em>dispersed,</em> his household goods, or his commodities, <em>and turned</em> them <em>over, one upon another;</em> as also <span class="ar">بَعْثَرَ</span>. <span class="auth">(Fr, Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحثر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bHvr_1_B1">
					<p><em>It</em> <span class="auth">(milk)</span> <em>curdled,</em> or <em>coagulated, and formed little clots of curd;</em> syn. <span class="ar long">تَقَطَّعَ وَتَحَبَّبَ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHvr_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبحثر</span></h3>
				<div class="sense" id="bHvr_Q2_A1">
					<p><span class="ar">تَبَحْثَرَ</span> <em>It</em> <span class="auth">(a thing, Ṣ)</span> <em>became separated, disunited, scattered, dispersed,</em> or <em>dissipated.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaHovirN">
				<h3 class="entry"><span class="ar">مُبَحْثِرٌ</span></h3>
				<div class="sense" id="mubaHovirN_A1">
					<p><span class="ar long">لَبَنٌ مُبَحْثِرٌ</span> <em>Milk curdling,</em> or <em>coagulating, and forming little clots of curd.</em> <span class="auth">(Ḳ. <span class="add">[<a href="#bHvr_Q1">See Q. 1</a>.]</span>)</span> When the upper portion is thick and the lower thin, it is termed <span class="ar">هَادِرٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0156.pdf" target="pdf">
							<span>Lanes Lexicon Page 156</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
