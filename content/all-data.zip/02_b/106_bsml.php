<article class="root" id="Root_bsml">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/105_bsm">بسم</a></span>
				<span class="ar">بسمل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/107_bsn">بسن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsml_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بسمل</span></h3>
				<div class="sense" id="bsml_Q1_A1">
					<p><span class="ar">بَسْمَلَ</span>, <span class="auth">(T, Ṣ, &amp;c.,)</span> inf. n. <span class="ar">بَسْمَلَةٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He said,</em> <span class="auth">(Ṣ, Mṣb, Ḳ, KL,)</span> or <em>wrote,</em> <span class="auth">(T, Mṣb,)</span> <span class="ar long">بِسْمِ ٱللّٰهِ</span> <span class="add">[<em>In,</em> or <em>with, the name of God</em> I recite, or read, or I begin, &amp;c.]</span>: <span class="auth">(T, Ṣ, Mṣb, Ḳ, KL:)</span> or <span class="ar long">بِسْمِ ٱللّٰهِ الرَّحْمَانِ الرَّحِيمِ</span> <span class="add">[<em>In,</em> or <em>with, the name of God, the Compassionate, the Merciful</em>]</span>: <span class="auth">(KL:)</span> a verb of the kind termed <span class="ar">مَنْحُوت</span> i. e. compounded of two <span class="add">[or more]</span> words; like <span class="ar">حَمْدَلَ</span> and <span class="ar">حَوْقَلَ</span> and <span class="ar">حَسْبَلَ</span>, &amp;c.: <span class="auth">(Mṣb, TA:)</span> said by some to be post-classical, not heard from the chaste Arabs; but authorized by many of the leading lexicologists, as ISk and Mṭr; and occurring in the poetry of ʼOmar Ibn-Abee-Rabee'ah <span class="add">[who is said to have been born in the year of the Flight 23]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubasomalN">
				<h3 class="entry"><span class="ar">مُبَسْمَلٌ</span></h3>
				<div class="sense" id="mubasomalN_A1">
					<p><span class="ar">مُبَسْمَلٌ</span> Discourse, <span class="auth">(TA,)</span> or amorous behaviour, and coquettish boldness, <span class="auth">(Mṣb,)</span> <em>accompanied by the saying</em> <span class="ar long">بِسْمِ ٱللّٰهِ</span>: <span class="auth">(Mṣb, TA:)</span> occurring in a verse of ʼOmar Ibn-Abee-Rabee'ah <span class="add">[referred to above]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0206.pdf" target="pdf">
							<span>Lanes Lexicon Page 206</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
