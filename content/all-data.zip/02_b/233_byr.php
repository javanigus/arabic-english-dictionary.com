<article class="root" id="Root_byr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/232_byd">بيد</a></span>
				<span class="ar">بير</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/234_byS">بيص</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">بير</span></h4>
			<hr>
			<section class="entry xref" id="biyorN">
				<h3 class="entry"><span class="ar">بِيْرٌ</span> / <span class="ar">أَبْيَارٌ</span></h3>
				<div class="sense" id="biyorN_A1">
					<p><span class="ar">بِيْرٌ</span>; pl. of pauc. <span class="ar">أَبْيَارٌ</span>: <a href="#biYorN">see <span class="ar">بِئْرٌ</span></a>, <a href="../">in art. <span class="ar">بأر</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0281.pdf" target="pdf">
							<span>Lanes Lexicon Page 281</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
