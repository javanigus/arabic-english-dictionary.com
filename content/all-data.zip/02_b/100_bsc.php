<article class="root" id="Root_bsc">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/099_bsO">بسأ</a></span>
				<span class="ar">بسذ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/101_bsr">بسر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="busBacN">
				<h3 class="entry"><span class="ar">بُسَّذٌ</span></h3>
				<div class="sense" id="busBacN_A1">
					<p><span class="ar">بُسَّذٌ</span> an arabicized word, <span class="add">[because <span class="ar">س</span> and <span class="ar">ذ</span> do not occur in any one Arabic word, <span class="auth">(Mṣb, voce <span class="ar">أُسْتَاذٌ</span>,)</span>]</span> <em>Coral;</em> syn. <span class="ar">مَرْجَانٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0202.pdf" target="pdf">
							<span>Lanes Lexicon Page 202</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
