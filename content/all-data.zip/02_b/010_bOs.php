<article class="root" id="Root_bOs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/009_bOz">بأز</a></span>
				<span class="ar">بأس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/011_bOh">بأه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bOs_1">
				<h3 class="entry">1. ⇒ <span class="ar">بأس</span></h3>
				<div class="sense" id="bOs_1_A1">
					<p><span class="ar">بَؤُسَ</span>, aor. <span class="ar">يَبْؤُسُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَأْسٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> or <span class="ar">بَأْسَةٌ</span>; <span class="auth">(M; <span class="add">[so I find in a copy of the M, but perhaps it is a mistranscription for <span class="ar">بَآسَةٌ</span>;]</span>)</span> and <span class="ar">بَئِسَ</span>, <span class="add">[aor. <span class="ar">يَبْأَسُ</span>,]</span> inf. n. <span class="ar">بَأْسٌ</span>; <span class="auth">(M;)</span> <em>He was,</em> or <em>became, mighty,</em> or <em>strong, in war</em> or <em>fight;</em> <span class="auth">(Ḳ;)</span> <em>courageous,</em> or <em>valiant:</em> <span class="auth">(M, Mṣb, Ḳ:)</span> or <em>very mighty</em> or <em>strong in war</em> or <em>fight.</em> <span class="auth">(AZ, Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bOs_1_B1">
					<p><span class="ar">بَئْسُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">يَبْأَسُ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">يَبْئِسُ</span>, the latter extr., like <span class="ar">يَنْعِمُ</span> aor. of <span class="ar">نَعِمَ</span>, <span class="auth">(M,)</span> <span class="add">[and some other instances, (<a href="#Hasiba">see <span class="ar">حَسِبَ</span></a>,)]</span> inf. n. <span class="ar">بُؤْسٌ</span> <span class="auth">(Ṣ, Mṣb,* Ḳ)</span> and <span class="ar">بُؤُوسٌ</span> and <span class="ar">بُؤْسَى</span> <span class="auth">(Ḳ)</span> and <span class="ar">بَأْسٌ</span> <span class="auth">(TA)</span> and <span class="ar">بَئيسٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[in measure]</span> like <span class="ar">أَمِيرٌ</span>, <span class="auth">(TA,)</span> <span class="add">[accord. to the CK <span class="ar">بِئْسٌ</span>, which is a mistake,]</span> and <span class="ar">بَئِيسَى</span>, <span class="auth">(TṢ, TA,)</span> incorrectly written in the copies of the Ḳ <span class="ar">بِئْسَى</span>; <span class="auth">(TA;)</span> or <span class="ar">بَؤُسَ</span>; <span class="auth">(A;)</span> or both these forms; <span class="auth">(M;)</span> <em>He was,</em> or <em>became, in a state of distress; straitened in his means of subsistence,</em> or <em>in the conveniences of life;</em> <span class="auth">(M, Mṣb;)</span> <em>in a state of poverty:</em> <span class="auth">(M, A, Mṣb,* TA:)</span> or <em>in a state of pressing want:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> and <span class="ar">بَؤُسَ</span>, inf. n. <span class="ar">بَآسَةٌ</span> and <span class="ar">بَئِيسٌ</span>, whence the subst. <span class="ar">بَؤْسَى</span>, <em>he was,</em> or <em>became, in a state of trial,</em> or <em>affliction:</em> <span class="auth">(M:)</span> and <span class="add">[in like manner,]</span><span class="arrow"><span class="ar">أَبْأَسَ↓</span></span>, <span class="auth">(inf. n. <span class="ar">إِبْآسٌ</span>,S,)</span> <em>distress,</em> or <em>poverty,</em> or <em>misfortune,</em> or <em>calamity,</em> (<span class="ar">البَأْسَآءُ</span>,) <em>befell him.</em> <span class="auth">(IAạr, Ṣ,* M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bOs_1_C1">
					<p><span class="ar">بِئْسَ</span>, also written <span class="ar">بَئِسَ</span> and <span class="ar">بِئِسَ</span> and <span class="ar">بَأْسَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> is a word of dispraise or blame, <span class="auth">(Ṣ,)</span> implying all kinds of dispraise or blame, <span class="auth">(TA,)</span> <span class="add">[or superlative dispraise or blame; signifying, <em>Very evil</em> or <em>bad is he,</em> or <em>it:</em> or <em>superlatively evil</em> or <em>bad is he,</em> or <em>it:</em>]</span> <em>contr. of</em> <span class="ar">نِعمَ</span>: <span class="auth">(Ṣ, M, TA:)</span> a pret. verb, imperfectly inflected, <span class="auth">(Ṣ, Ḳ,)</span> like <span class="ar">نِعْمَ</span>, <span class="auth">(Ṣ,)</span> <span class="add">[having only one variation of form, namely, the fem. <span class="ar">بِئْسَتْ</span>, though the masc. is more commonly used even when the agent is fem. or pl.,]</span> because it is translated from its original application, <span class="auth">(Ṣ, Ḳ,)</span> i. e. from <span class="ar long">بَئِسَ فُلَانٌ</span> signifying <span class="ar long">أَصَابَ بُؤْسًا</span> <span class="add">[he found, met with, or experienced, distress, &amp;c.]</span>, to signify dispraise or blame. <span class="auth">(Ṣ, TA.)</span> When it is accompanied by a gen. n. without the article <span class="ar">ال</span>, this is always in the accus. case: but when the n. has the article <span class="ar">ال</span>, it is always in the nom. case: <span class="auth">(TA:)</span> you say, <span class="ar long">بِئْسَ رَجُلًا زَيْدً</span> <span class="add">[<em>Very evil</em> or <em>bad,</em> or <em>superlatively evil</em> or <em>bad, as a man, is Zeyd;</em> <span class="ar">رجلا</span> being a specificative]</span>: <span class="auth">(Ḳ:)</span> and <span class="ar long">بِئْسَ الرَّجُلُ زَيْدٌ</span> <span class="add">[<em>Very evil,</em>, &amp;c., <em>is the man, Zeyd</em>]</span>; and <span class="ar long">بِئْسَتِ المَرْأَةُ هِنْدٌ</span> <span class="add">[or more commonly <span class="ar long">بِئْسَ العَيْرُ</span> in this case also, <em>Very evil,</em>, &amp;c., <em>is the woman, Hind</em>]</span>. <span class="auth">(Ṣ.)</span> Some argue that it is a noun, from the saying, <span class="ar long">نِعْمَ السَّيْرُ عَلَى بِئْسَ العَيْرُ</span>, because it has a prep.; but this is explained as elliptical, and meaning, <span class="ar long">نِعَمَ السَّيْرُ عَلَى عَيْرٍ مَقُولٍ فِيهِ بِئْسَ العيْرُ</span> <span class="add">[<em>Excellent is the journeying upon an ass of which it is said Very evil,</em>, &amp;c., <em>is the ass</em>]</span>. <span class="auth">(I’Aḳ p. 232.)</span> Zj says that when it is followed by <span class="ar">مَا</span>, then <span class="ar">مَا</span>, with it, is regarded as occupying the place of an indeterminate noun; <span class="add">[namely, <span class="ar">شَيْئًا</span>, as a specificative; as in the Ḳur ii. 84,<span class="ar long">بِئْسَ مَا ٱشْتَرَوا بِهِ أَنْفُسَهُمْ</span>, or <span class="ar">بِئْسَمَا</span>, &amp;c., <em>Very evil,</em>, &amp;c., <em>as a thing, is that for which they have sold,</em> or <em>exchanged, themselves:</em>]</span> <span class="auth">(TA:)</span> but some say that it is the agent, and is a determinate noun; and this is the opinion of Ibn-Kharoof, which he ascribes to Sb. <span class="auth">(I’Aḳ ubi suprà.)</span> <span class="add">[For further illustration, <a href="#niEoma">see <span class="ar">نِعْمَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bOs_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابأس</span></h3>
				<div class="sense" id="bOs_4_A1">
					<p><a href="#bayisa">see <span class="ar">بَئِسَ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bOs_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبأّس</span></h3>
				<div class="sense" id="bOs_5_A1">
					<p><a href="#bAs_6">see 6</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bOs_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباأس</span> ⇒ <span class="ar">تبآءس</span></h3>
				<div class="sense" id="bOs_6_A1">
					<p><span class="ar">تَبَآءَسَ</span> <em>He feigned the lowliness,</em> or <em>submissiveness, of poverty, humbling,</em> or <em>abasing, himself,</em> <span class="auth">(Ḳ,* TA,)</span> with men; and<span class="arrow"><span class="ar">تَبَأَّسَ↓</span></span> is allowable in the same sense. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bOs_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتأس</span></h3>
				<div class="sense" id="bOs_8_A1">
					<p><span class="ar long">ابتأس بِهِ</span>, <span class="auth">(M, A,)</span> and <span class="ar">مِنْهُ</span>, <span class="auth">(Ṣ, TA,)</span> <em>He was distressed by it,</em> or <em>at it;</em> it does not signify dislike: <span class="auth">(IB, TA:)</span> or <em>he grieved at it,</em> <span class="auth">(Ṣ, M, A,)</span> <em>and humbled and abased himself:</em> so in the Ḳur xi. 38 and xii. 69. <span class="auth">(M, A, TA.)</span> It is said of a man when a thing that he dislikes becomes known to him. <span class="auth">(AZ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baOosN">
				<h3 class="entry"><span class="ar">بَأْسٌ</span></h3>
				<div class="sense" id="baOosN_A1">
					<p><span class="ar">بَأْسٌ</span> <em>Might,</em> or <em>strength,</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> <em>in war</em> or <em>fight:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> <em>courage; valour,</em> or <em>valiantness; prowess.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baOosN_A2">
					<p><em>War,</em> or <em>fight;</em> <span class="auth">(M, Mṣb;)</span> as also<span class="arrow"><span class="ar">بَئِيْسٌ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">بَأْسَآءُ↓</span></span>: <span class="auth">(TA:)</span> pl. of the first,<span class="ar">أَبْؤَسٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baOosN_A3">
					<p>Hence, <span class="auth">(M,)</span> † <em>Fear,</em> <span class="auth">(M, TA,)</span> in the saying, <span class="ar long">لَا بأْسَ عَلَيْكَ</span>, <span class="auth">(M, TA,*)</span> and <span class="ar">بِكَ</span>, <span class="auth">(M,)</span> <span class="add">[† <em>There is no fear for thee:</em> lit., <em>there is no war against thee,</em> or <em>with thee</em>]</span>: the saying of which to an enemy implies the granting him security, or protection: and in the same sense it is used in a trad., in the phrase <span class="ar long">اِشْتَدَّ البَأْسُ</span> <span class="add">[† <em>Fear became vehement</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baOosN_A4">
					<p><em>I. q.</em> <span class="ar">ضَرَرٌ</span> † <span class="add">[<em>Harm, injury,</em>, &amp;c.]</span>: so in the phrase <span class="ar long">لَا بَأْسَ</span> <span class="add">[<em>There is,</em> or <em>will be, no harm,</em>, &amp;c.; and <span class="ar long">لَا بَأْسَ بِكَذَا</span>, and <span class="ar long">فِى كَذَا</span>, † <em>There is,</em> or <em>will be, no harm in such a thing</em>]</span>. <span class="auth">(Ḥar p. 311.)</span> It is said in a trad., <span class="ar long">لَا بَأْسَ بِٱلْغِنَى لِمَنِ ٱتَّقَى</span> <span class="add">[<em>There is no harm in wealth to him who is pious</em>]</span>. <span class="auth">(El-Jámiʼ eṣ-Ṣagheer of Es-Suyootee.)</span> <span class="ar">بَاس</span> also occurs for <span class="ar">بَأْس</span>; the being suppressed, agreeably with analogy; not altered by permutation. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baOosN_A5">
					<p><em>Punishment:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> or <em>severe punishment;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَئِسٌ↓</span></span>, in measure like <span class="ar">كَتِفٌ</span>. <span class="auth">(IAạr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baOosN_A6">
					<p><a href="#buWosN">See also <span class="ar">بُؤْسٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buWosN">
				<h3 class="entry"><span class="ar">بُؤْسٌ</span></h3>
				<div class="sense" id="buWosN_A1">
					<p><span class="ar">بُؤْسٌ</span> <span class="auth">(also written <span class="ar">بُوسٌ</span>, with the suppressed, Mṣb)</span> <em>Distress; straitness of the means of subsistence,</em> or <em>of the conveniences of life; poverty:</em> <span class="auth">(M, Mṣb,* TA:*)</span> or <em>a state of pressing want:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>misfortune; calamity:</em> <span class="auth">(A:)</span> and<span class="arrow"><span class="ar">بُؤُوسٌ↓</span></span> and<span class="arrow"><span class="ar">بُؤْسَى↓</span></span> <span class="auth">(Ḳ, TA)</span> and<span class="arrow"><span class="ar">بَأْسَآءُ↓</span></span> <span class="auth">(M, A)</span> and<span class="arrow"><span class="ar">بَأْسٌ↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">بَئِيسٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بَئِيسَى↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">مَبْأَسَةٌ↓</span></span> <span class="auth">(M, TA)</span> <span class="add">[all of which, except <span class="arrow"><span class="ar">بَأْسَآءُ↓</span></span> and<span class="arrow"><span class="ar">مَبْأَسَةٌ↓</span></span>, are said to be inf. ns. (<a href="#bayisa">see <span class="ar">بَئِسَ</span></a>)]</span> signify the same as <span class="ar">بُؤْسٌ</span>: <span class="auth">(Ṣ, M, A, Ḳ, TA:)</span> <span class="arrow"><span class="ar">بُؤْسَى↓</span></span> and<span class="arrow"><span class="ar">بَأْسَآءُ↓</span></span> are both from <span class="ar">بُؤْسٌ</span> <span class="add">[with which they are syn. accord. to authorities indicated above]</span>; <span class="auth">(Zj, IDrd, TA;)</span> the former is <em>contr. of</em> <span class="ar">نُعْمَى</span>, <span class="auth">(Ṣ, TA,)</span> and in like manner the latter is <em>contr. of</em> <span class="ar">نَعْمَآءُ</span>: <span class="auth">(TA:)</span> the latter is of the measure <span class="ar">فَعْلَآءُ</span> without any <span class="ar">أَفْعَلُ</span>, because it is a subst.; like as <span class="ar">أَفْعَلُ</span> occurs among substs. without any <span class="ar">فَعَلَآءُ</span>, as in the instance of <span class="ar">أَحْمَدُ</span>: <span class="auth">(Akh, Ṣ:)</span> or<span class="arrow"><span class="ar">بُؤْسَى↓</span></span> signifies <em>a state of trial</em> or <em>affliction,</em> and is a subst.; and<span class="arrow"><span class="ar">بَئِيسٌ↓</span></span> and<span class="arrow"><span class="ar">بَآسَةٌ↓</span></span> signify the same, but are inf. ns.: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar">بَأْسَآءُ↓</span></span> is syn. with <span class="ar">شِدَّةٌ</span> <span class="add">[like <span class="ar">بُؤْسٌ</span> in the first of the senses explained above]</span>; <span class="auth">(Ṣ, TA;)</span> and <span class="ar">مَشَقَّةٌ</span> <span class="add">[meaning <em>distress,</em> or <em>difficulty</em>]</span>: <span class="auth">(TA:)</span> or it signifies <em>misfortune,</em> or <em>calamity,</em> <span class="auth">(A, Ḳ,)</span> like <span class="ar">بُؤْسٌ</span>; <span class="auth">(A;)</span> and so <span class="ar">أَبْؤُسٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> or rather this last signifies <em>misfortunes,</em> or <em>calamities;</em> for it is pl. of<span class="arrow"><span class="ar">بَأْسٌ↓</span></span>, i. e., a pl. of pauc.; not of <span class="ar">بُؤْسٌ</span>, as J asserts it to be; for the pl. of pauc. of <span class="ar">بُؤْسٌ</span> is <span class="ar">أَبْآسٌ</span>: <span class="auth">(IB, TA:)</span> but <span class="ar">أَبْؤُسٌ</span> may be used as pl. of<span class="arrow"><span class="ar">بَأْسَآءُ↓</span></span>. <span class="auth">(Fr, in Ṣ, voce <span class="ar">ضَرَّآءُ</span>, q. v.)</span> <span class="add">[See exs. of these two pls. in what follows.]</span> You say <span class="ar long">يَوْمُ بُؤْسٍ وَيَوْمُ نُعْمٍ</span> <span class="add">[<em>A day of distress,</em> or <em>poverty,</em>, &amp;c., <em>and a day of ease and plenty</em>]</span>. <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">بُؤْسًا لَهُ</span> <span class="add">[<em>May distress,</em> or <em>poverty,</em>, &amp;c., <em>befall him</em>]</span>: a form of imprecation. <span class="auth">(Sb, M, TA.)</span> And <span class="ar long">بُؤْسَ ٱبْنِ سُمَيَّةَ</span>, app. an expression of pity <span class="add">[meaning <em>Alas for the distress,</em>, &amp;c., <em>of Ibn-Sumeiyeh!</em>]</span>. <span class="auth">(TA, from a trad.)</span> And <span class="ar long">عَسَىَ الغُوَيْرُ أَبْؤُسًا</span> <em>Perhaps the little cave</em> <span class="add">[<em>may be attended with</em>]</span> <em>calamities;</em> not calamity, as in the Ṣ <span class="add">[and Ḳ]</span>: <span class="auth">(IB:)</span> a prov.; <span class="auth">(Ṣ;)</span> originating from a cave's having collapsed upon some men in it; or from an enemy's having come to some men in a cave, and slain them; wherefore it is applied to anything whence evil is feared: <span class="auth">(Aṣ, Ṣ, Ḳ, in art. <span class="ar">غور</span>:)</span> or it is applied to him who is suspected of a thing: <span class="auth">(IAạr, TA:)</span> or <span class="ar">الغُوَيْرُ</span> was the name of a certain water, which belonged to the tribe of Kelb, and the words of this prov. were said by Ez-Zebbà, when Kaseer turned aside from the plain road, and took the way to <span class="ar">الغُوَيْرُ</span>: <span class="auth">(Ibn-El-Kelbee, Ṣ, Ḳ, in art. <span class="ar">غور</span>:)</span><span class="ar">ابؤسا</span> is in the accus. case by reason of <span class="ar">يَكُونُ</span> understood. <span class="auth">(Mughnee.)</span> <span class="add">[See Freytag's Arab. Prov. ii. 94.]</span> ElKumeyt also says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَالُوا أَسَآءَ بَنُو كُرْزٍ فَقُلْتُ لَهُمْ</span> *</div> 
						<div class="star">* <span class="ar long">عَسَى الغُوَيْرُ بِأَبْآسٍ وَأغْوَارِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They said, Benoo-Kurz have done evil: and I said to them, Perhaps the little cave may be</em> attended <em>with calamities and</em> connected with other <em>caves</em>]</span>: <span class="ar">أَبْآس</span> is here <a href="#buWos">pl. of <span class="ar">بُؤْس</span></a>. <span class="auth">(IB, TA.)</span> <span class="add">[In the Ṣ, the last words are written <span class="ar long">بِإِبْآسٍ وَإِعْوَارٍ</span>, in one copy: in another, <span class="ar">وإِغْوَارِ</span>: both of which are app. wrong.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بُؤْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buWosN_A2">
					<p><a href="#baAyisN">See also <span class="ar">بَائِسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biYosN">
				<h3 class="entry"><span class="ar">بِئْسٌ</span></h3>
				<div class="sense" id="biYosN_A1">
					<p><span class="ar">بِئْسٌ</span> and <span class="ar">بِيْسٌ</span> and <span class="ar">بَيْسٌ</span> and <span class="ar">بَيِّسٌ</span>: <a href="#bayiysN">see <span class="ar">بَئِيسٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بِئْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biYosN_A2">
					<p><span class="ar long">بَنَاتُ بِئْسٍ</span> <em>Calamities; misfortunes.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baYisN">
				<h3 class="entry"><span class="ar">بَئِسٌ</span></h3>
				<div class="sense" id="baYisN_A1">
					<p><span class="ar">بَئِسٌ</span>: <a href="#baOosN">see <span class="ar">بَأْسٌ</span></a>, last signification:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَئِسٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baYisN_B1">
					<p><a href="#bayiysN">and see <span class="ar">بَئِيسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buWosae">
				<h3 class="entry"><span class="ar">بُؤْسَى</span></h3>
				<div class="sense" id="buWosae_A1">
					<p><span class="ar">بُؤْسَى</span>: <a href="#buWosN">see <span class="ar">بُؤْسٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baOosaMCu">
				<h3 class="entry"><span class="ar">بَأْسَآءُ</span></h3>
				<div class="sense" id="baOosaMCu_A1">
					<p><span class="ar">بَأْسَآءُ</span>: <a href="#baOosN">see <span class="ar">بَأْسٌ</span></a>: <a href="#buWosN">and <span class="ar">بُؤْسٌ</span></a>: the latter, in five places.</p>
				</div>
				<span class="pb" id="Page_0147"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baOosaMCu_A2">
					<p>Zj explains it as signifying, in the Ḳur vi. 42, <em>Hunger.</em> <span class="auth">(M, TA.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَأْسَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baOosaMCu_A3">
					<p>Also The <em>act of beating,</em> or <em>striking.</em> <span class="auth">(Lth, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baWuwsN">
				<h3 class="entry"><span class="ar">بَؤُوسٌ</span></h3>
				<div class="sense" id="baWuwsN_A1">
					<p><span class="ar">بَؤُوسٌ</span> One <em>in whom</em> <span class="ar">بُؤْس</span> <span class="add">[i. e. <em>distress</em>, &amp;c.]</span> <em>is apparent,</em> or <em>manifest.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buWuwsN">
				<h3 class="entry"><span class="ar">بُؤُوسٌ</span></h3>
				<div class="sense" id="buWuwsN_A1">
					<p><span class="ar">بُؤُوسٌ</span>: <a href="#buWosN">see <span class="ar">بُؤْسٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baYysN">
				<h3 class="entry"><span class="ar">بَئيسٌ</span></h3>
				<div class="sense" id="baYysN_A1">
					<p><span class="ar">بَئيسٌ</span>: <a href="#baOosN">see <span class="ar">بَأْسٌ</span></a>: and <span class="ar">بُؤْسٌ</span>: the latter, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَئيسٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baYysN_B1">
					<p><em>Mighty,</em> or <em>strong, in war</em> or <em>fight;</em> <span class="auth">(A;)</span> <em>courageous,</em> or <em>valiant.</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَئيسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baYysN_B2">
					<p><span class="ar long">عَذَابٌ بئِيسٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">بِئِيسٌ↓</span></span>, agreeably with a general rule applying to words of this description, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">بِئْسٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَئِسٌ↓</span></span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">بَيْئَسٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَئْئَسٌ↓</span></span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">بَيِّسٌ↓</span></span>, and<span class="arrow"><span class="ar">بَيْسٌ↓</span></span>, which last, however, is of no authority, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">بِيسٌ↓</span></span>, and <span class="ar">بَيِيسٌ</span>, with the changed into <span class="ar">ى</span>, <span class="auth">(TA,)</span> <em>A vehement punishment:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> so in the Ḳur vii. 165. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biYiysN">
				<h3 class="entry"><span class="ar">بِئِيسٌ</span></h3>
				<div class="sense" id="biYiysN_A1">
					<p><span class="ar">بِئِيسٌ</span>: <a href="#bayBsN">see <span class="ar">بَئيسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baMsapN">
				<h3 class="entry"><span class="ar">بَآسَةٌ</span></h3>
				<div class="sense" id="baMsapN_A1">
					<p><span class="ar">بَآسَةٌ</span>: <a href="#buWosN">see <span class="ar">بُؤْسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baYiysae">
				<h3 class="entry"><span class="ar">بَئِيسَى</span></h3>
				<div class="sense" id="baYiysae_A1">
					<p><span class="ar">بَئِيسَى</span>: <a href="#buWosN">see <span class="ar">بُؤْسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYisN">
				<h3 class="entry"><span class="ar">بَائِسٌ</span></h3>
				<div class="sense" id="baAYisN_A1">
					<p><span class="ar">بَائِسٌ</span> <em>Distressed; straitened in his means of subsistence,</em> or <em>in the conveniences of life;</em> <span class="auth">(Mṣb;)</span> or <em>poor:</em> <span class="auth">(A, Mṣb:*)</span> or one <em>who is in want, and an object of pity for what he suffers:</em> <span class="auth">(TA:)</span> or <em>in a state of pressing want:</em> <span class="auth">(Ṣ:)</span> or <em>in a state of trial,</em> or <em>affliction:</em> <span class="auth">(M, TA:)</span> or one <em>who is crippled,</em> or <em>deprived of the power of motion, by disease,</em> or <em>who suffers from a protracted disease, and is in need:</em> <span class="auth">(Mgh:)</span> an epithet denoting pity, <span class="auth">(Sb, M, TA,)</span> or grief: <span class="auth">(Mgh:)</span> <span class="arrow"><span class="ar">بُؤْسٌ↓</span></span> occurs as its pl.; <span class="auth">(M, TA;)</span> or is for <span class="ar">ذَوُوبُؤْسٍ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoYasN">
				<h3 class="entry"><span class="ar">بَيْئَسٌ</span></h3>
				<div class="sense" id="bayoYasN_A1">
					<p><span class="ar">بَيْئَسٌ</span> and <span class="ar">بَيْئِسٌ</span>: <a href="#bayiysN">see <span class="ar">بَئِيسٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَيْئَسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoYasN_A2">
					<p>The former also signifies <em>Strong.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأس</span> - Entry: <span class="ar">بَيْئَسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayoYasN_A3">
					<p>And hence, <span class="auth">(TA,)</span> <span class="ar">البَيْئَسُ</span> <em>The lion.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlOaboOasu">
				<h3 class="entry"><span class="ar">الأَبْأَسُ</span></h3>
				<div class="sense" id="AlOaboOasu_A1">
					<p><span class="ar">الأَبْأَسُ</span> <em>The most vehement refusal.</em> <span class="auth">(Th, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboOasapN">
				<h3 class="entry"><span class="ar">مَبْأَسَةٌ</span></h3>
				<div class="sense" id="maboOasapN_A1">
					<p><span class="ar">مَبْأَسَةٌ</span>: <a href="#buWosN">see <span class="ar">بُؤْسٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotaYisN">
				<h3 class="entry"><span class="ar">مُبْتَئِسٌ</span></h3>
				<div class="sense" id="mubotaYisN_A1">
					<p><span class="ar">مُبْتَئِسٌ</span> <em>Disliking,</em> or <em>hating:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> and <em>grieving:</em> <span class="auth">(Ṣ, Ḳ:)</span> or rather, <em>distressed,</em> by, or at, a thing; not disliking, or hating: <span class="auth">(IB, TA:)</span> or <em>grieving, and humbling and abasing himself.</em> <span class="auth">(Zj, M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0146.pdf" target="pdf">
							<span>Lanes Lexicon Page 146</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0147.pdf" target="pdf">
							<span>Lanes Lexicon Page 147</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
