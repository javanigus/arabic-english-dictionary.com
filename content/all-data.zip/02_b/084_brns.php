<article class="root" id="Root_brns">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/083_brn">برن</a></span>
				<span class="ar">برنس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/085_brnk">برنك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brns_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبرنس</span></h3>
				<div class="sense" id="brns_Q2_A1">
					<p><span class="ar">تَبَرْنَسَ</span> <em>He wore,</em> or <em>clad himself with, a</em> <span class="ar">بُرْنُس</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buronusN">
				<h3 class="entry"><span class="ar">بُرْنُسٌ</span></h3>
				<div class="sense" id="buronusN_A1">
					<p><span class="ar">بُرْنُسٌ</span> <em>A long</em> <span class="ar">قَلَنْسُوَة</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>which the devotees used to wear in the first age of El-Islám:</em> <span class="auth">(Ṣ:)</span> or <em>any garment of which the head forms a part,</em> <span class="auth">(M, Ḳ,)</span> <em>being joined to it,</em> <span class="auth">(M,)</span> <em>whether it be a</em> <span class="ar">دُرَّاعَة</span> or <em>a</em> <span class="ar">مِمْطَر</span> or <em>a</em> <span class="ar">جُبَّة</span>; <span class="auth">(M, Ḳ;)</span> and this is said to be the correct explanation: <span class="auth">(TA:)</span> <span class="add">[agreeably with the latter explanation, it is applied in the present day to <em>a hooded cloak,</em> mostly <em>of white woollen stuff;</em> but often, <em>of cloth of any colour:</em>]</span> pl. <span class="ar">بَرَانِسُ</span>: <span class="auth">(Mṣb:)</span> <span class="add">[some say]</span> it is from <span class="ar">البِرْسُ</span>, meaning “cotton,” and the <span class="ar">ن</span> is augmentative: or, accord. to some, it is not Arabic. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برنس</span> - Entry: <span class="ar">بُرْنُسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buronusN_A2">
					<p><span class="ar long">بُرْنُسُ الحُسْنِ</span> † <em>Comely,</em> or <em>goodly, hair.</em> <span class="auth">(TA in art. <span class="ar">ملأ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0196.pdf" target="pdf">
							<span>Lanes Lexicon Page 196</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
