<article class="root" id="Root_bXr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/108_bX">بش</a></span>
				<span class="ar">بشر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/110_bXE">بشع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bXr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بشر</span></h3>
				<div class="sense" id="bXr_1_A1">
					<p><span class="ar">بَشَرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْشُرُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">بَشْرٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">ابشر↓</span></span>, <span class="auth">(A,)</span> inf. n. <span class="ar">إِبْشَارٌ</span>; <span class="auth">(Ḳ;)</span> <em>He pared</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ)</span> a hide, <span class="auth">(Ṣ, A, Mṣb,)</span> <em>removing its</em> <span class="ar">بَشَرَة</span>, <span class="auth">(Ṣ,)</span> or <em>face,</em> or <em>surface,</em> <span class="auth">(A, Mṣb,)</span> or <em>the skin upon which the hair grew:</em> <span class="auth">(TA:)</span> or, as some say, <em>removing its inner part with a large knife:</em> or, accord. to Ibn-Buzurj, some of the Arabs say, <span class="ar long">بَشَرْتُ الأَدِيمَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْشِرُ</span>}</span></add>, meaning <em>I removed from the hide its</em> <span class="ar">بَشَرَة</span>; and<span class="arrow"><span class="ar">أَبْشَرْتُهُ↓</span></span> as meaning <em>I exposed to view its</em> <span class="ar">بَشَرَة</span> <em>that was next to the flesh;</em> and <span class="ar">آدَمْتُهُ</span> I exposed to view its <span class="ar">أَدَمَة</span> upon which the hair grew. <span class="auth">(TA.)</span> <span class="add">[<a href="#OadamapN">But see <span class="ar">أَدَمَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bXr_1_A2">
					<p>Hence the saying in a trad., <span class="ar long">مَنْ أَحَبَّ القُرْآنَ قَلْيَبْشُرْ</span>, accord. to him who recites it thus, with damm to the <span class="ar">ش</span>; meaning † <em>Whoso loveth the Ḳur-án, let him make himself light of flesh,</em> <span class="add">[<em>by not eating more than will be sufficient,</em> and so prepare himself]</span> for <span class="add">[reading, or reciting,]</span> it, <span class="add">[like as one prepares a horse for running,]</span> because eating much causes one to forget it. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bXr_1_A3">
					<p>Hence also, <span class="ar long">بَشَرَ الأَرْضَ</span>, <span class="auth">(TA,)</span> inf. n. as above, <span class="auth">(Ṣ, Ḳ,)</span> † <em>It</em> <span class="auth">(a swarm of locusts)</span> <em>stripped the ground;</em> <span class="auth">(TA;)</span> <em>ate what was upon the ground,</em> <span class="auth">(Ṣ, Ḳ,)</span> i. e., <em>upon its surface;</em> as though the exterior of the ground were its <span class="ar">بَشَرَة</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bXr_1_A4">
					<p>And <span class="ar">بَشَرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْشُرُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> <em>He clipped</em> his mustache <em>much, so that the</em> <span class="ar">بَشَرَة</span> <span class="auth">(i. e. the <em>exterior of the skin,</em> TA)</span> <em>became apparent.</em> <span class="auth">(Ḳ, TA.)</span> This the Muslim is commanded to do. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bXr_1_A5">
					<p><span class="ar long">بَشَرَنِى فُلَانٌ بِوَجْهٍ حَسَنٍ</span> <em>Such a one met me with a cheerful countenance.</em> <span class="auth">(Ṣ.)</span> <a href="#bXr_2">See also 2</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bXr_1_A6">
					<p><a href="#bXr_3">And see 3</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bXr_1_B1">
					<p><span class="ar">بَشِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْشَرُ</span>}</span></add>; <span class="auth">(IAạr, Ṣ, Mṣb, Ḳ;)</span> and <span class="ar">بَشَرَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْشِرُ</span>}</span></add>, <span class="auth">(IAạr, Ḳ,)</span> inf. n. <span class="ar">بَشْرٌ</span> and <span class="ar">بُشُورٌ</span>; <span class="auth">(TA;)</span> <a href="#bXr_4">and<span class="arrow"><span class="ar">ابشر↓</span></span></a>, <span class="add">[which is the most common, though extr. in respect of analogy, <a href="#bXr_1">as being quasi-pass. of <span class="ar">بَشَرَ</span></a>, <a href="#Hjm_4">like <span class="ar">احجم</span></a> and <span class="ar">احنج</span> <a href="#ErD_4">and <span class="ar">اعرض</span></a> <a href="#qXE_4">and <span class="ar">اقشع</span></a> <a href="#kb_4">and <span class="ar">اكبّ</span></a> <a href="#nhj_4">and <span class="ar">انهج</span></a>, <span class="auth">(mentioned by MF in art. <span class="ar">حنج</span> as the only other instances of the kind,)</span> <a href="#xlj_4">and <span class="ar">اخلج</span></a>, (<a href="index.php?data=07_x/124_xlj">added in the TA in art. <span class="ar">خلج</span></a>,)]</span> <span class="auth">(Ṣ, A, Mgh, Ḳ,)</span> inf. n. <span class="ar">إِبْشَارٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">استبشر↓</span></span>; <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">تبشّر↓</span></span>; <span class="auth">(A;)</span> <span class="add">[originally, <em>He became changed in his</em> <span class="ar">بَشَرَة</span> <span class="auth">(or <em>complexion</em>)</span> <em>by the annunciation of an event:</em> <a href="#bXr_2">see <span class="ar">بَشَّرَهُ</span></a>: and hence,]</span> <em>he rejoiced,</em> or <em>became rejoiced;</em> <span class="auth">(IAạr, Ṣ, A, Mṣb, Ḳ;)</span> <span class="ar">بِكَذَا</span> <span class="add">[<em>at,</em> or <em>by, such a thing;</em> or <em>at,</em> or <em>by, the annunciation of such a thing</em>]</span>. <span class="auth">(IAạr, Ṣ, Ḳ.*)</span> You say, <span class="ar long">أَتَانِى أَمْرٌ بَشِرْتُ بِهِ</span> <em>An affair happened to me whereat I rejoiced,</em> or <em>whereby I became rejoiced.</em> <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">أَبْشَرَ↓ بِمَوْلُودٍ</span></span> <em>He rejoiced</em> <span class="add">[<em>at the annunciation of a new-born child</em>]</span>. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">أَبْشِرْ↓ بِخَيْرٍ</span></span> <em>Rejoice thou</em> <span class="add">[<em>at the annunciation of a good event</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> And in the same sense<span class="arrow"><span class="ar">أَبْشِرُوا↓</span></span> is used in the Ḳur xli. 30. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بشّر</span></h3>
				<div class="sense" id="bXr_2_A1">
					<p><span class="ar">بشّرهُ</span> <span class="auth">(Ṣ, A, Mṣb, &amp;c.,)</span> the form used by the Arabs in general, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">تَبْشِيرٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.;)</span> and<span class="arrow"><span class="ar">بَشَرَهُ↓</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْشُرُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> of the dial. of Tihámeh and the adjacent parts, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَشْرٌ</span> and <span class="ar">بُشُورٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُشْرٌ</span>, <span class="auth">(TA,)</span> or this last is a simple subst.; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">ابشرهُ↓</span></span>; <span class="auth">(Ṣ, A, Mgh, Ḳ;)</span> and<span class="arrow"><span class="ar">استبشرهُ↓</span></span>; <span class="auth">(Ḳ, TA;)</span> are syn.; <span class="auth">(Ṣ, Ḳ, &amp;c.;)</span> originally signifying <em>He announced to him an event which produced a change in his</em> <span class="ar">بَشَرَة</span> <span class="add">[or <em>complexion</em>]</span>: and hence, <span class="auth">(El-Fakhr Er-Rázee,)</span> <em>he announced to him an event which rejoiced him:</em> <span class="auth">(A, El-Fakhr Er-Rázee:)</span> so in common acceptation <span class="add">[when not restricted by an adjunct that denotes its having a different meaning: <a href="#buXorae">see <span class="ar">بُشْرَى</span></a> and an ex. below in this paragraph]</span>: <span class="auth">(El-Fakhr Er-Rázee:)</span> or <em>he rejoiced him</em> <span class="add">[<em>by an annunciation</em>]</span>: <span class="auth">(Mṣb:)</span> and <em>he announced to him an event which grieved him:</em> <span class="add">[or <em>he grieved him by an annunciation:</em>]</span> both these significations are proper. <span class="auth">(El-Fakhr Er-Rázee.)</span> You say, <span class="ar long">بشّرهُ بِالأَمْرِ</span> <span class="add">[generally meaning <em>He rejoiced him by the annunciation of the event</em>]</span>; and<span class="arrow"><span class="ar long">بَشَرَهُ↓ بِهِ</span></span>, aor. and inf. ns. as above;, &amp;c. <span class="auth">(TA.)</span> And <span class="ar long">بَشَّرْتُهُ بِمَوْلُودٍ</span> <span class="add">[<em>I rejoiced him by the annunciation of a new-born child</em>]</span>. <span class="auth">(Ṣ.)</span> And it is said in the Ḳur <span class="add">[iii. 20, &amp;c.]</span>, <span class="ar long">بَشِّرْهُمْ بِعَذَابٍ أَلِيمٍ</span> <span class="add">[<em>Grieve thou them by the annunciation,</em> or <em>denunciation, of a painful punishment</em>]</span>. <span class="auth">(Ṣ.)</span> You say also, of a she-camel, <span class="ar long">بَشَّرَتْ بِاللَّقَاحِ</span>, meaning † <em>She made it known that she had begun to be pregnant.</em> <span class="auth">(TA. <span class="add">[<a href="#bXr_4">See also 4</a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باشر</span></h3>
				<div class="sense" id="bXr_3_A1">
					<p><span class="ar long">باشر المَرْأَةَ</span>, <span class="auth">(Ḳ, &amp;c.,)</span> inf. n. <span class="ar">مُبَاشَرَةٌ</span> <span class="auth">(Ṣ, Mgh, TA)</span> and <span class="ar">بِشَارٌ</span>, <span class="auth">(TA,)</span> <em>He was,</em> or <em>became, in contact with the woman, skin to skin:</em> <span class="auth">(TA:)</span> <em>he enjoyed</em> <span class="add">[<em>contact with</em>]</span> <em>her skin:</em> <span class="auth">(Mṣb:)</span> <em>he became in contact with her, skin to skin, both being within one garment</em> or <em>piece of cloth:</em> <span class="auth">(Ḳ:)</span> <em>he lay with her,</em> <span class="add">[<em>skin to skin;</em> or <em>in the sense of</em>]</span> <em>inivit eam:</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>i. q.</em> <span class="ar">وَطِئَهَا</span>, both <span class="ar long">فِى الفَرْجِ</span> and <span class="ar long">خَارِجًا مِنْهُ</span>: <span class="auth">(TA:)</span> <span class="add">[and so<span class="arrow"><span class="ar">بَشَرَهَا↓</span></span> inf. n. <span class="ar">بَشْرٌ</span>; for]</span> <span class="ar">بَشْرٌ</span> and <span class="ar">مُبَاشَرَةٌ</span> are syn. <span class="add">[in the sense of <em>congressus venereus,</em> as is shown by an ex. in the Ṣ.]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bXr_3_A2">
					<p><span class="ar long">باشرهُ النَّعِيمُ</span> ‡ <span class="add">[<em>Enjoyment attended him; as though it clave to his skin</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bXr_3_A3">
					<p><span class="ar long">فَبَاشَرُوا رَوْحَ اليَقِينِ</span>, or <span class="ar long">رُوحَ اليقين</span>, is a metaphorical expression, <span class="add">[app. meaning ‡ <em>And they felt the joy and happiness that arise from certainty,</em>]</span> occurring in a trad. of ʼAlee. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bXr_3_A4">
					<p><span class="ar long">باشر الأَمْرَ</span>, <span class="auth">(Ṣ, A, &amp;c.,)</span> inf. n. <span class="ar">مُبَاشَرَةٌ</span>, <span class="auth">(Ṣ,)</span> ‡ <em>He superintended, managed,</em> or <em>conducted, the affair himself,</em> or <em>in his own person:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> or ‡ <em>he was present, himself, at the affair:</em> <span class="auth">(A, TA:)</span> or, <span class="add">[properly,]</span> <em>he managed,</em> or <em>conducted, the affair with his</em> <span class="ar">بَشَرَة</span>, i. e., his <em>own hand:</em> <span class="auth">(Mgh,* Mṣb:)</span> and hence a later application of the verb in the sense of <span class="ar">لَاحَظَ</span> † <span class="add">[<em>He regarded,</em> or <em>attended to,</em> the thing, or affair, &amp;c.]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابشر</span></h3>
				<div class="sense" id="bXr_4_A1">
					<p><span class="ar">ابشر</span>: <a href="#bXr_1">see 1</a>, first sentence, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bXr_4_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">ابشر الأَمْرُ وَجْهَهُ</span> <em>The affair made his countenance beautiful and bright:</em> in the Ḳ we read, <span class="ar long">أَبْشَرَ الأَمْرَ حَسَّنَهُ وَنَضَّرَهُ</span>; but this is a mistake. <span class="auth">(TA.)</span> Agreeably with this explanation, AA renders a reading in the Ḳur <span class="add">[xlii. 22]</span>, <span class="ar long">ذٰلِكَ ٱلَّذِى يُبْشِرُ ٱللّٰهُ عِبَادَهُ</span>, meaning <em>That is it with which God will make beautiful and bright</em> the face of <em>his servants:</em> so in the L. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bXr_4_A3">
					<p><a href="#bXr_2">See also 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bXr_4_A4">
					<p><span class="add">[Hence,]</span> <span class="ar long">أَبْشَرَتِ النَّاقَةُ</span> † <em>The she-camel conceived,</em> or <em>became pregnant:</em> <span class="auth">(Ḳ:)</span> as though she rejoiced <span class="add">[her owner]</span> by announcing her conception. <span class="auth">(TA. <span class="add">[<a href="#bXr_2">See 2</a>, last sentence.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bXr_4_A5">
					<p>And <span class="ar long">أَبْشَرَتِ الأَرْضُ</span> ‡ <em>The earth put forth its herbage appearing upon its surface.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bXr_4_B1">
					<p><a href="#bXr_1">See also 1</a>, latter part, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bXr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبشّر</span></h3>
				<div class="sense" id="bXr_5_A1">
					<p><a href="#bXr_1">see 1</a>, latter part.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXr_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباشر</span></h3>
				<div class="sense" id="bXr_6_A1">
					<p><span class="ar long">تباشر القَوْمُ</span> <em>The people,</em> or <em>company of men, announced, one to another, a joyful event,</em> or <em>joyful events.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">هُمْ يَتَبَاشَرُونَ بِذٰلِكَ الأَمْرِ</span> <em>They rejoice one another by the annunciation of that event.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبشر</span></h3>
				<div class="sense" id="bXr_10_A1">
					<p><span class="ar">استبشر</span>: <a href="#bXr_1">see 1</a>, latter part.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bXr_10_B1">
					<p><span class="ar">استبشرهُ</span> <em>He demanded of him a reward for an annunciation of joyful tidings.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bXr_10_B2">
					<p><a href="#bXr_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buXorN">
				<h3 class="entry"><span class="ar">بُشْرٌ</span></h3>
				<div class="sense" id="buXorN_A1">
					<p><span class="ar">بُشْرٌ</span>: <a href="#buXorae">see <span class="ar">بُشْرَى</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بُشْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buXorN_A2">
					<p>It is also a contraction of <span class="ar">بُشُرٌ</span>, which <a href="#baXuwrN">is pl. of <span class="ar">بَشُورٌ</span></a> <span class="auth">(TA)</span> or <span class="ar">بَشِيرٌ</span>. <span class="auth">(TA in art. <span class="ar">نشر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biXorN">
				<span class="pb" id="Page_0208"></span>
				<h3 class="entry"><span class="ar">بِشْرٌ</span></h3>
				<div class="sense" id="biXorN_A1">
					<p><span class="ar">بِشْرٌ</span> <em>Cheerfulness,</em> or <em>openness and pleasantness, of countenance:</em> <span class="auth">(Mgh, Mṣb, Ḳ,* TA:)</span> and <em>happiness, joy,</em> or <em>gladness.</em> <span class="auth">(Ḥar p. 192.)</span> You say, <span class="ar long">هُوَ حَسَنُ البِشْرِ</span> <em>He is cheerful,</em> or <em>open and pleasant, in countenance.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXarN">
				<h3 class="entry"><span class="ar">بَشَرٌ</span></h3>
				<div class="sense" id="baXarN_A1">
					<p><span class="ar">بَشَرٌ</span>: <a href="#baXarapN">see <span class="ar">بَشَرَةٌ</span></a></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بَشَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baXarN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">البَشَرُ</span> † <em>Mankind:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> and <em>the human being:</em> <span class="auth">(Mṣb, Ḳ:)</span> applied to the male and to the female; and used alike as sing. and pl. <span class="auth">(Mṣb, Ḳ, TA)</span> and dual: <span class="auth">(TA:)</span> so that you say, <span class="ar long">هُوَ بَشَرٌ</span> <em>He is a human being,</em> and <span class="ar long">هِىَ بَشَرٌ</span> <em>She is a human being,</em> and <span class="ar long">هُمْ بَشَرٌ</span> <em>They</em> <span class="auth">(more than two)</span> <em>are human beings,</em> and <span class="ar long">هُمَا بَشَرٌ</span> <em>They two are human beings:</em> <span class="auth">(TA:)</span> but sometimes it has the dual form; <span class="auth">(Mṣb, Ḳ;)</span> as in the Ḳur xxiii. 49; <span class="auth">(Mṣb, TA;)</span> though the Arabs may have used the dual form in the sense of the sing.: <span class="auth">(MF:)</span> and sometimes it has a pl., namely, <span class="ar">أَبْشَارٌ</span>. <span class="auth">(Ḳ.)</span> This is a secondary application of the word: <span class="auth">(Mṣb:)</span> i. e., this signification is tropical; or, as some say, the word is so much used in this sense as to be, so used, conventionally regarded as proper; the sense not depending upon its having another word connected with it: but in the Ṣ and Ḳ, and by the generality of authors, this signification is given as proper. <span class="auth">(MF.)</span> Some say that a human being is thus called because his <span class="ar">بَشَرَة</span> is bare of hair and of wool. <span class="auth">(MF.)</span> <span class="add">[Hence,]</span> <span class="ar long">أَبُو البَشَرِ</span> <span class="add">[<em>The father of mankind;</em> meaning]</span> <em>Adam.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXarapN">
				<h3 class="entry"><span class="ar">بَشَرَةٌ</span></h3>
				<div class="sense" id="baXarapN_A1">
					<p><span class="ar">بَشَرَةٌ</span> <span class="auth">(Lth, Ṣ, M, A, Mgh, Mṣb)</span> and<span class="arrow"><span class="ar">بَشَرٌ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> or the latter is pl. of the former, <span class="auth">(Mṣb, Ḳ,)</span> <span class="add">[or rather a coll. gen. n., of which the former is the n. un.,]</span> like <span class="ar">قَصَبَهُ</span> and <span class="ar">قَصَبٌ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">أَبْشَارٌ</span> <a href="#baXarN">is pl. of <span class="ar">بَشَرٌ</span></a>, <span class="auth">(Ḳ,)</span> <span class="add">[The <em>external skin;</em> the <em>cuticle,</em> or <em>scarf-skin;</em> the <em>epidermis;</em>]</span> the <em>exterior of the skin</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ)</span> of a human being; <span class="auth">(Ṣ, A, Ḳ;)</span> and, as some say, of other creatures, <span class="auth">(Ḳ,)</span> such as the serpent; but this is generally disallowed: <span class="auth">(TA:)</span> or <span class="ar">بَشَرَةٌ</span> signifies the <em>exterior of the skin of the head, in which grows the hair;</em> as also <span class="ar">أَدَمَةٌ</span> and <span class="ar">شَوَاةٌ</span>: <span class="auth">(Aboo-Safwán:)</span> or the <em>upper skin</em> <span class="auth">(Lth, M)</span> <em>of the head</em> <span class="auth">(M)</span> <em>and of the face and body</em> of a human being; <span class="auth">(Lth, M;)</span> <em>that upon which the hair grows:</em> <span class="auth">(M:)</span> or, as some say, <em>that which is next the flesh.</em> <span class="auth">(M.)</span> It is said in a prov., <span class="ar long">إِنَّمَا يُعَاتَبُ الأَدِيمُ ذُو البَشَرَةِ</span>: <a href="#OadiymN">see <span class="ar">أَدِيمٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بَشَرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baXarapN_A2">
					<p><span class="ar">بَشَرَةٌ</span> sometimes means The <em>complexion,</em> or <em>hue:</em> and <em>fineness,</em> or <em>delicacy.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بَشَرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baXarapN_B1">
					<p><span class="ar long">بَشَرَةُ الأَرْضُ</span> ‡ <em>The herbage appearing upon the surface of the earth.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> You say, <span class="ar long">مَا أَحْسَنَ بَشَرَتَهَا</span> ‡ <em>How goodly is its herbage appearing upon its surface!</em> <span class="auth">(Ṣ, A.)</span> And <span class="ar">بَشَرَةٌ</span> <span class="add">[alone]</span> signifies ‡ <em>Leguminous plants; herbs,</em> or <em>herbage.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بَشَرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baXarapN_B2">
					<p><span class="ar">بَشَرَةٌ</span> is used also as signifying † A man's <em>hand.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#bXr_3">See 3</a>, last sentence.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buXorae">
				<h3 class="entry"><span class="ar">بُشْرَى</span></h3>
				<div class="sense" id="buXorae_A1">
					<p><span class="ar">بُشْرَى</span> <span class="auth">(imperfectly decl., because it terminates with a fem. alif which is inseparable from it, Ṣ)</span> and<span class="arrow"><span class="ar">بِشَارَةٌ↓</span></span> and<span class="arrow"><span class="ar">بُشَارَةٌ↓</span></span> <span class="add">[but respecting this last <a href="#biXaArapN">see <span class="ar">بِشَارَةٌ</span> below</a>]</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بُشْرٌ↓</span></span> <span class="auth">(Mṣb)</span> are substs. from <span class="ar">بَشَّرَهُ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <span class="add">[originally signifying <em>An annunciation which produces a change in the</em> <span class="ar">بَشَرَة</span> <span class="auth">(or <em>complexion</em>)</span> <em>of the person to whom it is made:</em> and hence, <em>a joyful annunciation; joyful,</em> or <em>glad, tidings; good news</em>]</span>: and<span class="arrow"><span class="ar">تَبَاشِيرُ↓</span></span> <span class="add">[q. v. infrà]</span> signifies the same as <span class="ar">بُشْرَى</span>: <span class="auth">(Ṣ, Ḳ:)</span> <span class="arrow"><span class="ar">بِشَارَةٌ↓</span></span>, when used absolutely, relates only to good; <span class="auth">(Ṣ, Mṣb;)</span> not to evil unless when expressly restricted thereto by an adjunct: <span class="add">[<a href="#bXr_2">see 2</a>:]</span> <span class="auth">(Ṣ:)</span> its pl. is <span class="ar">بِشَارَاتٌ</span> and <span class="ar">بَشَائِرُ</span>. <span class="auth">(A.)</span> <span class="ar long">يَا بُشْرَاىَ</span>, in the Ḳur <span class="add">[xii. 19, accord. to one reading, <span class="auth">(otherwise, as Bḍ mentions, <span class="ar">بُشْرَاىْ</span>, or <span class="ar">بُشْرَىَّ</span>, which is a dial. var. of the same, or <span class="ar">بُشْرَى</span>, which, as some say, was the name of a man,)</span> meaning <em>O my joyful annunciation,</em> or <em>joyful tidings,</em> or <em>good news!</em>]</span>, is like <span class="ar">عَصَاى</span>: and in the dual you say, <span class="ar long">يَا بُشْرَيَىَّ</span>. <span class="auth">(Ṣ.)</span> You say also,<span class="arrow"><span class="ar long">تَتَابَعَتِ البِشَارَاتُ↓</span></span> and <span class="ar">البَشَائِرُ</span> <span class="add">[<em>The joyful annunciations followed consecutively</em>]</span>. <span class="auth">(A.)</span> See another ex. voce <span class="ar">بَشِيرٌ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بُشْرَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buXorae_A2">
					<p><a href="#biXaArapN">See also <span class="ar">بِشَارَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXarieBN">
				<h3 class="entry"><span class="add">[<span class="ar">بَشَرِىٌّ</span>]</span></h3>
				<div class="sense" id="baXarieBN_A1">
					<p><span class="add">[<span class="ar">بَشَرِىٌّ</span> <em>Human; of,</em> or <em>belonging to,</em> or <em>relating to, mankind</em> or <em>a human being.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buXaArN">
				<h3 class="entry"><span class="ar">بُشَارٌ</span></h3>
				<div class="sense" id="buXaArN_A1">
					<p><span class="ar">بُشَارٌ</span> † The <em>refuse,</em> or <em>lowest</em> or <em>basest</em> or <em>meanest sort,</em> of mankind, or of people. <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baXuwrN">
				<h3 class="entry"><span class="ar">بَشُورٌ</span></h3>
				<div class="sense" id="baXuwrN_A1">
					<p><span class="ar">بَشُورٌ</span>: <a href="#baXiyrN">see what next follows</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXiyrN">
				<h3 class="entry"><span class="ar">بَشِيرٌ</span> / <span class="ar">بَشِيرَةٌ</span></h3>
				<div class="sense" id="baXiyrN_A1">
					<p><span class="ar">بَشِيرٌ</span> <em>i. q.</em> <span class="arrow"><span class="ar">مُبَشِّرٌ↓</span></span>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <span class="add">[and so<span class="arrow"><span class="ar">بَشُورٌ↓</span></span>, as will be seen by an ex. in what follows,]</span> <em>One who announces to a people</em> <span class="add">[<em>or person</em>]</span> <em>an event, either good or evil;</em> <span class="auth">(TA;)</span> but meaning the former oftener than the latter: <span class="auth">(Mṣb:)</span> <span class="add">[<em>an announcer of a joyful event,</em> or <em>joyful events: one who rejoices another,</em> or <em>others, by an annunciation:</em>]</span> pl. <span class="ar">بُشَرَآءُ</span> <span class="auth">(A)</span> and <span class="ar">بُشُرٌ</span>, <span class="auth">(TA in art. <span class="ar">نشر</span>,)</span> or this is pl. of<span class="arrow"><span class="ar">بَشُورٌ↓</span></span>. <span class="auth">(TA in the present art.)</span> It is said in the Ḳur <span class="add">[vii. 55]</span>, <span class="ar long">وَهُوَ ٱلَّذِى يُرْسِلُ ٱلرِّيَاحَ بُشُرًا</span>, and <span class="ar">بُشْرًا</span>, and<span class="arrow"><span class="ar">بُشْرَى↓</span></span>, and <span class="ar">بَشْرًا</span>; <span class="add">[accord. to different readings, meaning † <em>And He it is who sendeth the winds announcing coming rain;</em>]</span> in which <span class="ar">بُشُرٌ</span> is pl. of<span class="arrow"><span class="ar">بَشُورٌ↓</span></span>, <span class="add">[syn. with <span class="ar">بَشِيرٌ</span> and <span class="ar">مُبَشِّرٌ</span>, but both masc. and fem.,]</span> <span class="auth">(TA,)</span> <a href="#baXiyrN">or of <span class="ar">بَشِيرٌ</span></a>, <span class="auth">(Bḍ,)</span> <a href="#baXiyrapN">or of <span class="ar">بَشِيرَةٌ</span></a>; <span class="auth">(TA in art. <span class="ar">نشر</span>;)</span> and <span class="ar">بُشْرًا</span> is a contraction of the same; and <span class="ar">بُشْرَى</span> is syn. with <span class="ar">بِشَارَةٌ</span>; and <span class="ar">بَشْرًا</span> <a href="#bXr_1">is the inf. n. of <span class="ar">بَشَرَهُ</span></a> in the sense of <span class="ar">بَشَّرَهُ</span> <span class="auth">(TA. <span class="add">[But the reading commonly followed in this passage is <span class="ar">نُشُرًا</span>, with <span class="ar">ن</span>: another reading is <span class="ar">نُشْرًا</span>: another, <span class="ar">نَشْرًا</span>: and another, <span class="ar">نَشَرًا</span>.]</span>)</span> And<span class="arrow"><span class="ar">المُبَشِّرَاتُ↓</span></span>, <span class="auth">(A,)</span> or <span class="ar long">مُبَشِّرَاتُ الرِّيَاحِ</span>, <span class="auth">(Ṣ,)</span> signifies ‡ <em>Winds that announce</em> <span class="add">[<em>coming</em>]</span> <em>rain:</em> <span class="auth">(Ṣ, A:)</span> so in the Ḳur xxx. 45. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بَشِيرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baXiyrN_B1">
					<p>Also <em>Goodly; beautiful; elegant in form</em> or <em>features;</em> <span class="auth">(Ṣ, Ḳ;)</span> applied to a man, and to a face: <span class="auth">(TA:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَشِيرَةٌ</span>}</span></add>; <span class="auth">(Ṣ, Ḳ;)</span> applied to a woman, and to a she-camel; <span class="auth">(Ṣ;)</span> and meaning, when applied to a she-camel, <em>neither emaciated nor fat:</em> or, accord. to Aboo-Hilál, <em>neither of generous nor of ignoble breed:</em> or, as some say, <em>half-fattened:</em> <span class="auth">(TA:)</span> pl. of the fem. <span class="ar">بَشَائِرُ</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar">مَبْشُورَةٌ↓</span></span> signifies <em>beautiful in make and colour;</em> <span class="auth">(IAạr, Ḳ;)</span> applied to a girl. <span class="auth">(IAạr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXaArapN">
				<h3 class="entry"><span class="ar">بَشَارَةٌ</span></h3>
				<div class="sense" id="baXaArapN_A1">
					<p><span class="ar">بَشَارَةٌ</span> <em>Goodliness; beauty; elegance of form</em> or <em>features.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buXaArapN">
				<h3 class="entry"><span class="ar">بُشَارَةٌ</span></h3>
				<div class="sense" id="buXaArapN_A1">
					<p><span class="ar">بُشَارَةٌ</span> <em>What is pared off from the face of a hide:</em> what is pared off from its back is called <span class="ar">تِحْلِئٌ</span>. <span class="auth">(Lḥ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بُشَارَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buXaArapN_B1">
					<p><a href="#biXaArapN">See also <span class="ar">بِشَارَةٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بُشَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="buXaArapN_B2">
					<p><a href="#buXorae">and see <span class="ar">بُشْرَى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biXaArapN">
				<h3 class="entry"><span class="ar">بِشَارَةٌ</span></h3>
				<div class="sense" id="biXaArapN_A1">
					<p><span class="ar">بِشَارَةٌ</span>; pl. <span class="ar">بِشَارَاتٌ</span> and <span class="ar">بَشَائِرُ</span>: <a href="#buXorae">see <span class="ar">بُشْرَى</span></a>, in three places; <a href="#tabaAXiyru">and see also <span class="ar">تَبَاشِيرُ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">بِشَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biXaArapN_A2">
					<p>Also <em>A gift to him who announces a joyful event;</em> and so<span class="arrow"><span class="ar">بُشَارَةٌ↓</span></span>: <span class="auth">(Ḳ,* TA:)</span> or the latter, which is like the <span class="ar">عُمَالَة</span> of the <span class="ar">عَامِل</span>, has this signification; <span class="auth">(IAth;)</span> and so<span class="arrow"><span class="ar">بُشْرَى↓</span></span>; <span class="auth">(M;)</span> and <span class="ar">بِشَارَةٌ</span> <span class="add">[has the same meaning accord. to common usage, but, properly,]</span> is a subst. in the sense explained above, voce <span class="ar">بُشْرَى</span>. <span class="auth">(IAth.)</span> You say, <span class="ar long">أَعْطَيْتُهُ ثَوْبِى بِشَارَةً</span> <em>I gave him my garment as a reward for the joyful annunciation.</em> <span class="auth">(TA from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboXaru">
				<h3 class="entry"><span class="ar">أَبْشَرُ</span></h3>
				<div class="sense" id="OaboXaru_A1">
					<p><span class="ar long">هُوَ أَبْشَرُ مِنْهُ</span> <em>He is more goodly</em> or <em>beautiful, more elegant in form</em> or <em>features, and more fat, than he.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tubuXBirN">
				<h3 class="entry"><span class="ar">تُبُشِّرٌ</span> / <span class="ar">تُبُشِّرَةٌ</span></h3>
				<div class="sense" id="tubuXBirN_A1">
					<p><span class="ar">تُبُشِّرٌ</span>, in the hand writing of J <span class="ar">تُبَشِّرٌ</span>, <span class="add">[and so in my copies of the Ṣ,]</span> a word of which there is not the like except in the instances of <span class="ar">تُنُوِّطٌ</span> <span class="add">[or <span class="ar">تُنَوِّطٌ</span>]</span>, a certain bird, and <span class="ar long">وَادِى تُهُلِّكَ</span> <span class="add">[or <span class="ar">تُهَلِّكَ</span>?]</span> and <span class="ar long">وَادِى تُضُلِّلَ</span> <span class="add">[or <span class="ar">تُضَلِّلَ</span>]</span> and <span class="ar long">وَادِى تُخُيِّبَ</span> <span class="add">[or <span class="ar">تُخَيِّبَ</span>]</span>, <span class="auth">(TA,)</span> <em>A certain bird, called the</em> <span class="ar">صُفَارِيَّة</span>: <span class="auth">(Ṣ, Ḳ:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تُبُشِّرَةٌ</span>}</span></add>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabaAXiyru">
				<h3 class="entry"><span class="ar">تَبَاشِيرُ</span></h3>
				<div class="sense" id="tabaAXiyru_A1">
					<p><span class="ar">تَبَاشِيرُ</span>, as though it were <a href="#taboXiyrN">pl. of <span class="ar">تَبْشِيرٌ</span></a>, <a href="#bXr_2">inf. n. of <span class="ar">بَشَّرَ</span></a>; <span class="auth">(A;)</span> a word which has not its like except in the instances of <span class="ar">تَعَاشِيبُ</span> and <span class="ar">تَعَاجِيبُ</span> and <span class="ar">تَفَاطِيرُ</span> <span class="add">[and <span class="ar">تَبَاكِيرُ</span> and <span class="ar">تَبَارِيحُ</span>, and probably a few others]</span>; <span class="auth">(TA;)</span> ‡ <span class="add">[<em>Annunciations; foretokens; foretellers; foreshowers; prognostics; earnests;</em> of what is good:]</span> the <em>beginnings</em> of anything: <span class="auth">(Ṣ, Ḳ:)</span> the <em>first</em> of blossoms, &amp;c.: <span class="auth">(TA:)</span> the <em>beginnings,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>first annunciations,</em> <span class="auth">(A,)</span> of daybreak; <span class="auth">(Ṣ, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَشَائِرُ↓</span></span>: <span class="auth">(TA:)</span> it has no verb: <span class="auth">(Ṣ:)</span> and <span class="add">[is said to have]</span> no sing.: but in a trad. of El-Hajjáj, <span class="ar">تَبْشِيرٌ</span> occurs as meaning † the <em>commencement</em> of rain. <span class="auth">(TA.)</span> One says, <span class="ar long">فِيهِ مَخَايِلُ الرُّشْدِ وَتَبَاشِيرُهُ</span> ‡ <span class="add">[<em>In him are indications of right conduct,</em> or <em>belief, and its earnests</em>]</span>. <span class="auth">(A.)</span> <a href="#buXorae">See also <span class="ar">بُشْرَى</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">تَبَاشِيرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tabaAXiyru_A2">
					<p>† <em>Streaks of the light of daybreak in the night.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">تَبَاشِيرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tabaAXiyru_A3">
					<p>† <em>Streaks that are seen upon the surface of the ground, caused by the winds.</em> <span class="auth">(Lth, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">تَبَاشِيرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tabaAXiyru_A4">
					<p>† <em>The colours of palm-trees when their fruit begins to ripen;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">تَبَاكِيرُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">تَبَاشِيرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tabaAXiyru_A5">
					<p>† <em>Such as bear fruit early,</em> or <em>before others,</em> of palm-trees. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشر</span> - Entry: <span class="ar">تَبَاشِيرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tabaAXiyru_A6">
					<p>† <em>Marks of galls upon the side of a beast.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboXarN">
				<h3 class="entry"><span class="ar">مُبْشَرٌ</span></h3>
				<div class="sense" id="muboXarN_A1">
					<p><span class="ar long">رَجُلٌ مُؤْدَمٌ مُبْشَرٌ</span> ‡ <em>A perfect man; as though he combined the softness of the</em> <span class="ar">أَدَمَة</span> <span class="add">[or <em>inner skin</em>]</span> <em>with the roughness of the</em> <span class="ar">بَشَرَة</span> <span class="add">[or <em>outer skin</em>]</span>: <span class="auth">(Ṣ:)</span> or <em>a man who combines softness,</em> or <em>gentleness, and strength, with knowledge of affairs:</em> <span class="auth">(Aṣ:)</span> and <span class="ar long">اِمْرَأَةٌ مُؤْدَمَةٌ مُبْشَرَةٌ</span> ‡ <em>a woman perfect in every respect.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=01_A/041_Adm">See also art. <span class="ar">ادم</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubaXBirN">
				<h3 class="entry"><span class="ar">مُبَشِّرٌ</span> / <span class="ar">مُبَشِّرَاتٌ</span></h3>
				<div class="sense" id="mubaXBirN_A1">
					<p><span class="ar">مُبَشِّرٌ</span> and <span class="ar">مُبَشِّرَاتٌ</span>: <a href="#baXiyrN">see <span class="ar">بَشِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboXuwrapN">
				<h3 class="entry"><span class="ar">مَبْشُورَةٌ</span></h3>
				<div class="sense" id="maboXuwrapN_A1">
					<p><span class="ar">مَبْشُورَةٌ</span>: <a href="#baXiyrN">see <span class="ar">بَشِيرٌ</span></a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaAXirN">
				<h3 class="entry"><span class="ar">مُبَاشِرٌ</span></h3>
				<div class="sense" id="mubaAXirN_A1">
					<p><span class="ar long">حِجْرٌ مُبَاشِرٌ</span> <span class="add">[so in two copies of the Ṣ: in Golius's Lex. <span class="ar">مُبَاشِرَةٌ</span>:]</span> <em>A mare</em> <span class="add">[so I render <span class="ar">حجر</span>, which Golius renders ‘ vulva, ’]</span> <em>desiring the stallion.</em> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#mubaAsirapN">See also <span class="ar">مُبَاسِرَةٌ</span></a>, with <span class="ar">س</span>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0207.pdf" target="pdf">
							<span>Lanes Lexicon Page 207</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0208.pdf" target="pdf">
							<span>Lanes Lexicon Page 208</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
