<article class="root" id="Root_blqE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/180_blq">بلق</a></span>
				<span class="ar">بلقع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/182_bln">بلن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blqE_QQ1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بلقع</span></h3>
				<div class="sense" id="blqE_QQ1_A1">
					<p><span class="ar">بَلْقَعَ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَلْقَعَةٌ</span>, <span class="auth">(TA,)</span> <em>It</em> <span class="auth">(a country, or region,)</span> <em>was,</em> or <em>became, vacant,</em> or <em>void; destitute of herbage</em> or <em>pasturage, and of human beings, &amp;c.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blqE_Q3">
				<h3 class="entry">Q. 3. ⇒ <span class="ar">ابلنقع</span></h3>
				<div class="sense" id="blqE_Q3_A1">
					<p><span class="ar">اِبْلَنْقَعَ</span> <em>It</em> <span class="auth">(sorrow, grief, or anxiety, such as is termed <span class="ar">كَرْب</span>,)</span> <em>became removed,</em> or <em>cleared away.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلقع</span> - Entry: Q. 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blqE_Q3_A2">
					<p><em>It</em> <span class="auth">(the dawn)</span> <em>shone,</em> or <em>shone brightly.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلقع</span> - Entry: Q. 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blqE_Q3_A3">
					<p><em>It</em> <span class="auth">(a thing)</span> <em>appeared, and came forth.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baloqaEN">
				<h3 class="entry"><span class="ar">بَلْقَعٌ</span></h3>
				<div class="sense" id="baloqaEN_A1">
					<p><span class="ar">بَلْقَعٌ</span> and<span class="arrow"><span class="ar">بَلْقَعَةٌ↓</span></span> <em>A land that is vacant,</em> or <em>void; destitute of herbage</em> or <em>pasturage, and of human beings, &amp;c.;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>in which is nothing:</em> <span class="auth">(Ṣ:)</span> or the former signifies <em>a vacant,</em> or <em>void, place:</em> <span class="auth">(Mgh:)</span> <span class="add">[or instead of using the former alone, you say <span class="ar long">أَرْضٌ بَلْقَعٌ</span>; for]</span> you say <span class="ar long">مَنْزِلٌ بَلْقَعٌ</span> <span class="add">[<em>a vacant,</em> or <em>void, place of alighting</em> or <em>abiding</em>]</span>, <span class="auth">(Ṣ, TA,)</span> and <span class="ar long">دَارٌ بَلْقَعٌ</span> <span class="add">[<em>a vacant,</em> or <em>void, house</em>, &amp;c.]</span>, without <span class="ar">ة</span>, when it is an epithet, <span class="auth">(Ṣ, TA,)</span> applied to a masc. subst. and to a fem.; <span class="auth">(TA;)</span> but if it be a subst., you say,<span class="arrow"><span class="ar long">اِنْتَهَيْنَا إِلَى بَلْقَعَةٍ↓ مَلْسَآءَ</span></span> <span class="add">[<em>we came at last to a smooth, vacant,</em> or <em>void, land</em>]</span>: <span class="auth">(Ṣ, TA:)</span> and<span class="arrow"><span class="ar">بَلْقَعَةٌ↓</span></span> also signifies <em>a land in which are no trees, either in sands or in plain or level tracts:</em> <span class="auth">(TA:)</span> or <em>a vacant land, in which is no one, whether there be in it herbage or not, and whether plain or not:</em> <span class="auth">(Ḥam p. 445:)</span> pl. <span class="ar">بَلَاقِعُ</span>. <span class="auth">(Ṣ, Mgh, Ḳ.)</span> It is said in a trad., <span class="ar long">اليَمِينُ الفَاجِرَةُ تَذَرُ</span> <span class="auth">(Ṣ, Mgh, TA; but in the second and third of these, in the place of <span class="ar">تَذَرُ</span>, we find <span class="ar">تَدَعُ</span>;)</span> <em>The false oath causes the places of abode to become void,</em> or <em>vacant;</em> i. e., by reason of its evil influence, the possessions and their possessors perish; <span class="auth">(Mgh;)</span> or the <span class="add">[false]</span> swearer becomes poor, and the property that was in his house goes away; <span class="auth">(Sh;)</span> or God renders him in a state of disunion, and changes the blessings which He had conferred upon him: <span class="auth">(TA:)</span> accord. to another relation, the words of the trad. are <span class="ar long">اليَمِينُ الغَمُوسُ الخ</span>. <span class="auth">(Mgh.)</span> You say also, <span class="ar long">دِيَارٌ بَلْقَعٌ</span> <span class="add">[<em>Vacant,</em> or <em>void, places of abode</em>]</span>; as though the places were one place: <span class="auth">(TA:)</span> and Ru-beh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَأَصْبَحَتْ دَارَهُمُ بَلَاقِعَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And their abode became vacant</em>]</span>: <span class="auth">(TA:)</span> and it is said in a trad., <span class="ar long">أَصْبَحَتِ الأَرْضُ بَلَاقِعَ</span> <span class="add">[as though meaning <em>the land became altogether vacant</em>]</span>; the pl. being used to render the meaning intensive, as in the phrases <span class="ar long">أَرْضٌ سَبَاسِبُ</span> and <span class="ar long">ثَوْبٌ أَخْلَاقٌ</span>; <span class="auth">(IAth, TA;)</span> or because every portion thereof is considered as being <span class="ar">بلقع</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلقع</span> - Entry: <span class="ar">بَلْقَعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baloqaEN_A2">
					<p>Also, without <span class="ar">ة</span> <span class="new">{<span class="ar">بَلْقَعٌ</span>}</span>and<span class="arrow">↓</span> with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَلْقَعَةٌ</span>}</span></add>, ‡ A woman <em>devoid of every good quality.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلقع</span> - Entry: <span class="ar">بَلْقَعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baloqaEN_A3">
					<p>IF says that the <span class="ar">ل</span> in <span class="ar">بَلْقَعٌ</span> is augmentative. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baloqaEapN">
				<h3 class="entry"><span class="ar">بَلْقَعَةٌ</span></h3>
				<div class="sense" id="baloqaEapN_A1">
					<p><span class="ar">بَلْقَعَةٌ</span>: <a href="#baloqaEN">see <span class="ar">بَلْقَعٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baloqaEieBN">
				<h3 class="entry"><span class="ar">بَلْقَعِىٌّ</span></h3>
				<div class="sense" id="baloqaEieBN_A1">
					<p><span class="ar">بَلْقَعِىٌّ</span> An arrow, or a spear-head, <em>bright,</em> or <em>free from rust, in the point.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balanoqaEN">
				<h3 class="entry"><span class="ar">بَلَنْقَعٌ</span></h3>
				<div class="sense" id="balanoqaEN_A1">
					<p><span class="ar long">صَلَنْقَعٌ بَلَنْقَعٌ</span> is an expression applied to <em>A road</em> <span class="add">[as though meaning <em>made bare</em> by the feet of men and beasts]</span>. <span class="auth">(I'Abbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0253.pdf" target="pdf">
							<span>Lanes Lexicon Page 253</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
