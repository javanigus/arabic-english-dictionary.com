<article class="root" id="Root_bhr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/201_bhj">بهج</a></span>
				<span class="ar">بهر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/203_bhrj">بهرج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهر</span></h3>
				<div class="sense" id="bhr_1_A1">
					<p><span class="ar">بَهَرَهُ</span>, <span class="auth">(Ṣ, A, Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَرُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَهْرٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>He overcame him:</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ:)</span> <em>he overpowered him; subdued him:</em> <span class="auth">(TA:)</span> <em>he surpassed him; excelled him.</em> <span class="auth">(Mṣb.)</span> <a href="#bhr_3">See also 3</a>. You say, <span class="ar long">بَهَرَتْ فُلَانَةُ النِّسَآءَ</span> <em>Such a woman surpassed the</em> <span class="add">[other]</span> <em>women in beauty.</em> <span class="auth">(Ṣ.)</span> And <span class="ar">بَهَرَ</span> <span class="add">[alone]</span> <em>He excelled in knowledge, &amp;c.;</em> or <em>he was,</em> or <em>became, accomplished,</em> or <em>perfect, in every excellence,</em> and <em>in goodliness.</em> <span class="auth">(Ṣ, Ḳ.)</span> And <span class="ar long">بَهَرَ القَمَرُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">بَهَرَ القَمَرُ النُّجُومَ</span>, <span class="auth">(TA,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَرُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بُهُورٌ</span>, <span class="auth">(TA,)</span> ‡ <em>The moon overcame with its light the light of the stars.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span> And <span class="ar long">بَهَرَتِ الشَّمْسُ الأَرْضَ</span> † <em>The light of the sun overspread the earth.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhr_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">بَهَرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَرُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَهْرٌ</span> and <span class="ar">بُهُورٌ</span>, <span class="auth">(Ḳ,)</span> ‡ <em>It shone,</em> or <em>shone brightly:</em> <span class="auth">(Ḳ, TA:)</span> and<span class="arrow"><span class="ar long">تَبَهَّرَتِ↓ السَّحَابَةُ</span></span> ‡ <em>The cloud shone,</em> or <em>shone brightly.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhr_1_B1">
					<p><span class="ar">بَهَرَهُ</span>, <span class="auth">(Ṣ, A,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَرُ</span>}</span></add>, inf. n. <span class="ar">بُهْرٌ</span>, <span class="auth">(Ṣ,)</span> also signifies ‡ <em>It</em> <span class="auth">(a load, or burden, Ṣ, A, and running, A)</span> <span class="add">[<em>caused him to be out of breath; interrupted his breathing;</em> (<a href="#buhorN">see <span class="ar">بُهْرٌ</span></a>;)]</span> <em>caused to pant,</em> or <em>breathe</em> <span class="add">[<em>shortly</em> or]</span> <em>uninterruptedly.</em> <span class="auth">(Ṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bhr_1_B2">
					<p>Also, <span class="auth">(ISh, JK, TA,)</span> inf. n. <span class="ar">بَهْرٌ</span>, <span class="auth">(Ḳ, TA,)</span> † <em>He stopped his breath</em> by beating, or by squeezing his throat, or throttling him, or by any other means: <span class="auth">(ISh, TA:)</span> † <em>he plied him,</em> or <em>worked him,</em> (<span class="ar">عَالَجَهُ</span>,) <em>until he became out of breath,</em> or <em>until he panted:</em> <span class="auth">(JK, TA:)</span> † <em>he imposed upon him a thing that was above his power,</em> or <em>ability.</em> <span class="auth">(Ḳ, TA.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِنَّ البَخِيلَ إِذَا سَأَلْتَ بَهَرْتَهُ</span> *</div> 
					</blockquote>
					<p><em>Verily the niggardly, when thou askest</em> of him, <em>thou stoppest his breath.</em> <span class="auth">(ISh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bhr_1_B3">
					<p><span class="add">[Hence,]</span> <span class="ar">بُهِرَ</span>, <em>i. q.</em> <span class="ar">انبهر</span>, as explained below. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bhr_1_C1">
					<p><span class="ar">بَهَرَهَا</span>, <span class="auth">(JK,)</span> or <span class="ar long">بَهَرَهَا بِبُهْتَانٍ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَهْرٌ</span>, <span class="auth">(Ḳ,)</span> <em>He reproached her,</em> or <em>accused her, falsely;</em> <span class="auth">(JK;)</span> <em>he aspersed her; calumniated her;</em> or <em>brought a false accusation against her.</em> <span class="auth">(Ḳ,* TA.)</span> You say, <span class="ar long">بَهَرَهَا بِكَذَا</span> <em>He reproached her falsely with,</em> or <em>accused her falsely of, such a thing.</em> <span class="auth">(JK.)</span> <span class="add">[<a href="#bhr_8">See also 8</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باهر</span></h3>
				<div class="sense" id="bhr_3_A1">
					<p><span class="arrow"><span class="ar long">باهر صَاحِبَهُ فَبَهَرَهُ↓</span></span> <span class="auth">(Ḳ,* TA,)</span> inf. n. <span class="ar">مُبَاهَرَةٌ</span> and <span class="ar">بِهَارٌ</span>, <span class="auth">(TA,)</span> <span class="add">[aor. of the latter verb, accord. to rule, <span class="ar">ـُ</span>, not <span class="ar">ـَ</span>,]</span> <em>He contended,</em> or <em>disputed,</em> or <em>vied, with his companion for glory,</em> or <em>superiority,</em> or <em>excellence, and overcame him.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابهر</span></h3>
				<div class="sense" id="bhr_4_A1">
					<p><span class="ar">ابهر</span> <em>He did,</em> or <em>effected,</em> or <em>he said,</em> or <em>uttered, what was wonderful;</em> syn. <span class="ar long">جَآءَ بِالعَجَبِ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبهّر</span></h3>
				<div class="sense" id="bhr_5_A1">
					<p><a href="#bhr_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhr_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبهر</span></h3>
				<div class="sense" id="bhr_7_A1">
					<p><span class="ar">انبهر</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> and<span class="arrow"><span class="ar">ابتهر↓</span></span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بُهِرَ↓</span></span>, like <span class="ar">عُنِىَ</span>, <span class="auth">(Ḳ,)</span> ‡ <em>He was,</em> or <em>became, out of breath; his breath became interrupted,</em> by reason of fatigue <span class="add">[or running, or by hard work, or bearing a heavy load; <a href="#bhr_1">see 1</a>]</span>: <span class="auth">(Ḳ:)</span> <em>he panted,</em> or <em>breathed</em> <span class="add">[<em>shortly</em> or]</span> <em>uninterruptedly.</em> <span class="auth">(Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتهر</span></h3>
				<div class="sense" id="bhr_8_A1">
					<p><span class="ar">ابتهر</span> <em>He arrogated to himself,</em> or <em>professed, a thing falsely.</em> <span class="auth">(Ṣ, Ḳ.)</span> El-Akhtal says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمَا بِى إِنْ مَدَحْتُهُمُ ٱبْتِهَارُ</span> *</div> 
					</blockquote>
					<p><em>And there is not in me, if I praise them, false profession:</em> <span class="auth">(Ṣ:)</span> or <span class="ar">ابتهر</span> signifies <em>he said what was false, and swore to it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhr_8_A2">
					<p><em>He said that he had transgressed,</em> or <em>acted vitiously,</em> or <em>committed adultery</em> or <em>fornication, when he had not done so.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">ابتهر بِذَنْبٍ</span> <em>He asserted himself to have committed a crime,</em> or <em>sin, when he had not done so.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bhr_8_A3">
					<p><span class="ar">ابتهرها</span> <em>He asserted falsely that he had had sexual intercourse with her:</em> <span class="auth">(M, TA:)</span> <span class="ar">ابتارها</span> signifies “he asserted the same with truth:” <span class="auth">(TA:)</span> or <span class="ar">ابتهر</span> signifies <em>he charged,</em> or <em>upbraided,</em> a person <em>with that which was in him;</em> <span class="auth">(Ḳ, TA;)</span> and <span class="ar">ابتار</span>, “he charged, or upbraided, with that which was not in him.” <span class="auth">(TA.)</span> <a href="#baAra">See an ex. voce <span class="ar">بَارَ</span></a> <a href="index.php?data=02_b/218_bwr">in art. <span class="ar">بور</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bhr_8_A4">
					<p>Also <em>He</em> <span class="auth">(a poet)</span> <em>mentioned her</em> <span class="auth">(a girl)</span> <em>in his poetry.</em> <span class="auth">(JK.)</span> <span class="ar long">اُبْتُهِرَ بِفُلَانَةَ</span> <em>He became,</em> or <em>was rendered, notorious,</em> or <em>infamous, on account of such a woman</em> <span class="add">[<em>with whom he was said to have had an illicit connexion</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhr_8_B1">
					<p><a href="#bhr_7">See also 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhr_11">
				<h3 class="entry">11. ⇒ <span class="ar">ابهارّ</span></h3>
				<div class="sense" id="bhr_11_A1">
					<p><span class="ar long">ابهارّ اللَّيْلُ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> inf. n. <span class="ar">اِبْهِيرَارٌ</span>, <span class="auth">(Ṣ,)</span> <em>The night reached its middle point;</em> <span class="auth">(Aṣ, Ṣ, A, Ḳ;)</span> from <span class="ar">بُهْرَةٌ</span> signifying the “middle” of a thing: <span class="auth">(A:)</span> or <em>reached the point when all its stars appeared and shone:</em> <span class="auth">(Aboo-Saʼeed Ed-Dareer:)</span> or <em>became thickly dark:</em> <span class="auth">(Ḳ:)</span> or <em>for the most part passed:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>reached the point when about one third of it remained.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">ابهارّ عَلَيْنَا اللَّيْلُ</span> <em>The night became long to us.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">ابهارّ النَّهَارُ</span> <em>The day reached the point when the sun had become high.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahorN">
				<h3 class="entry"><span class="ar">بَهْرٌ</span></h3>
				<div class="sense" id="bahorN_A1">
					<p><span class="ar">بَهْرٌ</span> <a href="#bhr_1">inf. n. of 1 <span class="add">[q. v.]</span></a>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> You say, <span class="ar long">بَهْرًا لَهُ</span>, an imprecation, meaning <em>May he be overcome!</em> <span class="auth">(A:)</span> or <em>i. q.</em> <span class="ar long">تَعْسًا لَهُ</span> <span class="add">[<em>may he fall, having stumbled!</em> or <em>stumble and fall!</em>, &amp;c.]</span>: <span class="auth">(AA, Ṣ, Ḳ:)</span> and thus used <span class="add">[app. in the latter sense]</span> as an imprecation, accord. to Sb, it has no verb, but is put in the accus. case on the supposition of a verb. <span class="auth">(TA.)</span> One says also,<span class="arrow"><span class="ar long">قُهْرًا وَبُهْرًا↓</span></span>, with damm to each. <span class="auth">(TA in art. <span class="ar">قهر</span>.)</span> And <span class="ar long">بَهْرًا مَا أَسْخَاهُ</span> <span class="add">[<em>May he fall, having stumbled!</em>, &amp;c.: <em>how bountiful is he!</em>]</span>, like as one says <span class="ar long">تَعْسًا لَهُ</span> <span class="add">[when not meaning it to be understood as an imprecation]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahorN_A2">
					<p>It also signifies <em>Distance,</em> or <em>remoteness:</em> <span class="auth">(Ḳ:)</span> and <em>remoteness from good</em> or <em>prosperity.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bahorN_A3">
					<p><em>Disappointment.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bahorN_A4">
					<p><em>Wonder;</em> syn. <span class="ar">عَجَبٌ</span>. <span class="auth">(Ḳ.)</span> One says, <span class="ar">بَهْرا</span> meaning <span class="ar">عَجَبًا</span> <span class="add">[for <span class="ar long">أَعْجَبُ عَجَبًا</span> <em>I do wonder:</em> or <em>wonderful!</em>]</span>. <span class="auth">(Ṣ.)</span> So <span class="add">[sometimes]</span> in the phrase <span class="ar long">بَهْرًا لَهُ</span> <span class="add">[<em>I do wonder at him,</em> or <em>it</em>]</span>. <span class="auth">(IAạr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bahorN_A5">
					<p><em>Love.</em> <span class="auth">(Ḳ.)</span> Accord. to some, <span class="ar long">بَهْرًا لَكُمْ</span> means <em>Love to you.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bahorN_A6">
					<p><span class="ar long">الأَزْوَاجُ ثَلاَثَةٌ زَوْجُ بَهْرٍ وَزَوْجُ دَهْرٍ وَزَوْجُ مَهْرٍ</span> is a saying of the Arabs, meaning <em>Husbands are three: a husband who overcomes the eyes by his goodliness,</em> <span class="auth">(Ṣ,)</span> or <em>a husband of noble race, though he may be of little wealth;</em> <span class="auth">(TA;)</span> <em>and a husband prepared for the accidents,</em> or <em>calamities, of fortune; and a husband from whom a dowry is got,</em> <span class="auth">(Ṣ,)</span> or <em>a husband who has not nobility of race, and who therefore doubles the dowry to make himself desired.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bahorN_B1">
					<p>† <em>Distress that affects the breath</em> or <em>respiration,</em> syn. <span class="ar">كَرْبٌ</span>, <span class="auth">(Ḳ, TA,)</span> <span class="add">[particularly]</span> <em>of a camel when he is spurred on,</em> or <em>of a man when a labour above his power is imposed upon him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhorN">
				<h3 class="entry"><span class="ar">بُهْرٌ</span></h3>
				<div class="sense" id="buhorN_A1">
					<p><span class="ar">بُهْرٌ</span>: <a href="#bahorN">see <span class="ar">بَهْرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بُهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buhorN_A2">
					<p>Also ‡ The <em>state of being out of breath; interruption of the breath, by reason of fatigue,</em> <span class="auth">(Ḳ, TA,)</span> <span class="add">[or <em>by bearing a heavy load,</em> (<a href="#bhr_1">see 1</a>,)]</span> or <em>by hard work,</em> and <em>by running:</em> <span class="auth">(TA:)</span> <em>a panting,</em> or <em>breathing</em> <span class="add">[<em>shortly</em> or]</span> <em>uninterruptedly.</em> <span class="auth">(Ṣ, A, TA,)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بُهْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buhorN_B1">
					<p><em>Wide-spreading land; a wide tract of land;</em> as also<span class="arrow"><span class="ar">بُهْرَةٌ↓</span></span> <span class="add">[q. v.]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بُهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="buhorN_B2">
					<p><em>A country,</em> or <em>district;</em> or <em>a city,</em> or <em>town;</em> syn. <span class="ar">بَلَدٌ</span>: <span class="auth">(Ḳ:)</span> or the <em>middle thereof.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بُهْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="buhorN_B3">
					<p>The <em>middle,</em> and <em>best part,</em> (<span class="ar">سِرّ</span>, and <span class="ar">خَيْر</span>, for the former of which words we find <span class="ar">شَرّ</span> erroneously put in the copies of the Ḳ, TA,) <em>of a valley;</em> as also<span class="arrow"><span class="ar">بُهْرَةُ↓</span></span> <span class="add">[q. v.]</span>. <span class="auth">(Ḳ, TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhorapN">
				<span class="pb" id="Page_0266"></span>
				<h3 class="entry"><span class="ar">بُهْرَةٌ</span></h3>
				<div class="sense" id="buhorapN_A1">
					<p><span class="ar">بُهْرَةٌ</span> <em>Plain,</em> or <em>even,</em> or <em>soft, land</em> or <em>ground:</em> or <em>a wide tract of land between mountains.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بُهْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buhorapN_A2">
					<p><a href="#buhorN">See also <span class="ar">بُهْرٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بُهْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buhorapN_A3">
					<p>The <em>middle</em> <span class="auth">(Ṣ, A, Ḳ)</span> of a valley, and of the night, and of a horse, <span class="auth">(Ṣ, Ḳ,)</span> and of a camel's saddle, <span class="auth">(TA,)</span> and of a ring, <span class="auth">(Ḳ,)</span> or of a thing. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahaArN">
				<h3 class="entry"><span class="ar">بَهَارٌ</span></h3>
				<div class="sense" id="bahaArN_A1">
					<p><span class="ar">بَهَارٌ</span> <em>A certain plant, of sweet odour;</em> <span class="auth">(Ḳ;)</span> the <span class="add">[<em>plant called</em>]</span> <span class="ar">عَرَار</span>, <em>which is also called</em> <span class="ar long">عَيْنُ البَقَرِ</span>; <span class="add">[<em>buphthalmum,</em> or <em>ox-eye;</em>]</span> it is the <span class="ar long">بَهَارُ البَرِّ</span>, <em>a crisping,</em> or <em>curling, plant, having a yellow flower; growing in the days of the spring</em> (<span class="ar">الرَّبِيع</span>), and called <span class="ar">عَرَارَةٌ</span>: <span class="auth">(Ṣ:)</span> Aṣ says, The <span class="ar">عَرَار</span> is the <span class="ar long">بَهَارُ البَرِّ</span>: and Az says, The <span class="ar">عَرَارَة</span> is the <span class="ar">خَسْوَة</span>; and I regard <span class="ar">بهار</span> as a Persian word. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahaArN_A2">
					<p><em>Perfume.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bahaArN_A3">
					<p>And hence applied to The <em>flowers of the desert.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">بَهَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bahaArN_A4">
					<p>And <em>Anything goodly,</em> or <em>beautiful, and bright,</em> or <em>shining.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhaArN">
				<h3 class="entry"><span class="ar">بُهَارٌ</span></h3>
				<div class="sense" id="buhaArN_A1">
					<p><span class="ar">بُهَارٌ</span> <em>A certain thing with which one weighs;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> the <em>weight of three hundred pounds:</em> <span class="auth">(Fr, IAạr, AʼObeyd, Ṣ, Ḳ:)</span> thought by AʼObeyd to be not Arabic, but Coptic; <span class="auth">(Ṣ;)</span> having this signification in Coptic; <span class="auth">(JK;)</span> but thought by Az to be pure Arabic: <span class="auth">(TA:)</span> or <em>four hundred pounds:</em> or <em>six hundred:</em> or <em>a thousand:</em> <span class="auth">(Ḳ:)</span> and, <span class="auth">(Ḳ,)</span> or as some say, <span class="auth">(TA,)</span> <em>one half of a load</em> <span class="auth">(Ḳ, TA)</span> <em>borne by a camel,</em> <span class="auth">(TA,)</span> <em>containing four hundred pounds,</em> <span class="auth">(Ḳ, TA,)</span> in the dial. of Syria: <span class="auth">(TA:)</span> or <em>a load borne by a camel:</em> <span class="auth">(Ḳṭ:)</span> or <em>a camel-load of household-goods or furniture and utensils:</em> <span class="auth">(Aṣ:)</span> and <em>commodities,</em> or <em>utensils,</em> or <em>the like, of the sea;</em> expl. by <span class="ar long">مَتَاعَ البَحْرِ</span> <span class="add">[perhaps a mistranscription for <span class="ar long">مَتَاعَ التَّجْرِ</span> or <span class="ar">التُّجُرِ</span>, <em>commodities,</em> or <em>goods, of the merchants:</em> the poet Bureyk El-Hudhalee speaks of camels bearing <span class="ar">بُهَار</span>]</span>. <span class="auth">(JK, Ḳ.)</span> It is said that Talhah the son of ʼObeyd-Allah left a hundred <span class="ar">بُهَار</span>, in each <span class="ar">بهار</span> of which was three hundred-weight of gold <span class="auth">(Ṣ, TA)</span> and silver; <span class="auth">(TA;)</span> <span class="ar">بهار</span> being thus made to signify a receptacle: <span class="auth">(Ṣ, TA:)</span> accord. to Aṣ and Ḳṭ, the meaning is, a hundred camel-loads. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahiyrN">
				<h3 class="entry"><span class="ar">بَهِيرٌ</span></h3>
				<div class="sense" id="bahiyrN_A1">
					<p><span class="ar">بَهِيرٌ</span> and<span class="arrow"><span class="ar">مَبْهُورٌ↓</span></span> <span class="auth">(A, Ḳ)</span> and<span class="arrow"><span class="ar">مَنْبَهِرٌ↓</span></span> <span class="auth">(A)</span> <span class="add">[and<span class="arrow"><span class="ar">مُبْتَهِرٌ↓</span></span>]</span> ‡ <em>Out of breath; having his breath interrupted,</em> by reason of fatigue <span class="add">[or running, or by hard work, or bearing a heavy load; <a href="#bhr_1">see 1</a> <a href="#bhr_7">and 7</a>]</span>; <em>panting,</em> or <em>breathing</em> <span class="add">[<em>shortly</em> or]</span> <em>uninterruptedly.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhirN">
				<h3 class="entry"><span class="ar">بَاهِرٌ</span></h3>
				<div class="sense" id="baAhirN_A1">
					<p><span class="ar">بَاهِرٌ</span> <span class="add">[act. part. n. of 1, <em>Overcoming;</em>, &amp;c. And particularly,]</span> † <em>Overcoming in light.</em> <span class="auth">(JK.)</span> <span class="add">[Hence,]</span> <span class="ar long">قَمَرٌ بَاهِرٌ</span> ‡ <em>A moon that overcomes with its light the light of the stars.</em> <span class="auth">(Ṣ, A.)</span> And <span class="ar">البَاهِرُ</span> ‡ <em>The moon;</em> because it outshines the stars: <span class="auth">(Mṣb:)</span> or <em>the full moon.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboharu">
				<h3 class="entry"><span class="ar">أَبْهَرُ</span></h3>
				<div class="sense" id="Oaboharu_A1">
					<p><span class="ar">أَبْهَرُ</span> <span class="add">[The <em>aorta;</em> so in the present day;]</span> <em>a certain vein</em> <span class="add">[or <em>artery</em>]</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> <em>in the back,</em> <span class="auth">(Ḳ,)</span> <em>lying within,</em> or <em>at the inner side of, the back-bone</em> <span class="auth">(AʼObeyd, A, TA)</span> <em>and the heart,</em> <span class="auth">(AʼObeyd, TA,)</span> <em>the severing of which causes death:</em> <span class="auth">(AʼObeyd, Ṣ, A:)</span> it is name given to <em>each of two veins</em> <span class="add">[or <em>arteries,</em> or <em>the two portions of the aorta which are called the aorta ascendens and aorta descendens,</em>]</span> <em>which issue from the heart, and from which then branch off all the other arteries:</em> <span class="auth">(Ṣ:)</span> and, <span class="auth">(Ḳ,)</span> or as some say, <span class="auth">(TA,)</span> the <span class="ar">وَرِيد</span> <span class="add">[i. e. either the <em>carotid artery</em> or the <em>external jugular vein</em>]</span> <em>of the neck:</em> <span class="auth">(Ḳ:)</span> and, <span class="auth">(Ḳ,)</span> or as some say, <span class="auth">(TA,)</span> <span class="add">[the <em>vein in the arm called</em>]</span> <em>the</em> <span class="ar">أَكْحَل</span>: <span class="auth">(Ḳ:)</span> or, accord. to the more full description of IAth, <em>a certain vein</em> <span class="add">[or <em>artery</em>]</span> arising from the head, and extending to the foot, and having arteries which communicate with most of the extremities and the body: what is in the head is called the <span class="ar">نَامَّة</span>; and hence the saying, <span class="ar long">أَسْكَتَ ٱللّٰهُ نَامَّتَهُ</span>, meaning “God killed him,” or “may God kill him!” <em>and it extends to the throat, and is there called the</em> <span class="ar">وَرِيد</span>; <em>and to the chest, and is there called</em> <span class="add">[<em>especially</em>]</span> <em>the</em> <span class="ar">أَبْهَر</span> <span class="add">[meaning the <em>aorta ascendens</em>]</span>; <em>and to the back, and is there called the</em> <span class="ar">وَتِين</span> <span class="add">[meaning the <em>aorta descendens</em>]</span>; <em>and the heart is suspended to it; and it extends to the thigh, and is there called the</em> <span class="ar">نَسَا</span>; <em>and to the shank, and is there called the</em> <span class="ar">صَافِن</span>: the <span class="ar">ء</span> in it is augmentative. <span class="auth">(TA.)</span> You say, <span class="ar long">قَطَعَ أَبْهَرَهُ</span> <span class="add">[<em>It severed his aorta</em>]</span>; meaning ‡ <em>it</em> <span class="auth">(pain)</span> <em>destroyed him.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">أَبْهَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oaboharu_A2">
					<p>Also The <em>back:</em> <span class="auth">(Ḳ:)</span> or the <em>place of the vein</em> <span class="add">[or <em>artery</em>]</span> <em>so called.</em> <span class="auth">(Aṣ, in art. <span class="ar">خدع</span> of the Ṣ.)</span> One says, <span class="ar long">فُلَانٌ شَدِيدٌ الأَبْهَرِ</span> <em>Such a one is strong in the back:</em> <span class="auth">(TA:)</span> or <em>strong in the place of the vein</em> <span class="add">[or <em>artery</em>]</span> <em>called the</em> <span class="ar">ابهر</span>. <span class="auth">(Aṣ, ubi suprà.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">أَبْهَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oaboharu_A3">
					<p>And The <em>back of the curved part of the extremity</em> of a bow: <span class="auth">(Ḳ:)</span> or the <em>part between the</em> <span class="ar">طائِف</span> and the <span class="ar">كُلْيَة</span>: <span class="auth">(Ṣ, Ḳ:)</span> in the bow is its <span class="ar">كَبِد</span>, which is the part between the two extremities of its string or the like; then, next to this, the <span class="ar">كُلْيَة</span>; then, next to this, the <span class="ar">أَبْهَر</span>; then, the <span class="ar">طَائِف</span>; then, the <span class="ar">سِئَة</span>, which is the curved part of the extremity. <span class="auth">(Aṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">أَبْهَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oaboharu_A4">
					<p>And <em>A tent-pole.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهر</span> - Entry: <span class="ar">أَبْهَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oaboharu_A5">
					<p>And The <em>shorter side of a feather:</em> <span class="auth">(Ḳ:)</span> <span class="add">[or]</span> so <span class="ar">أَبَاهِرُ</span> <span class="add">[which is the pl.]</span>: <span class="auth">(JK:)</span> <span class="add">[or]</span> the latter signifies the <em>feathers</em> <span class="auth">(Lḥ, Ṣ)</span> <em>of the wing</em> <span class="auth">(Lḥ)</span> of a bird <span class="auth">(Lḥ, Ṣ)</span> <em>next after those called</em> <span class="ar">الخَوَافِى</span>, <span class="auth">(Lḥ,)</span> <span class="add">[<em>and</em>]</span> <em>next</em> <span class="add">[<em>before</em>]</span> <em>those called</em> <span class="ar">الكُلَى</span>: <span class="auth">(Ṣ:)</span> the first of them are those called <span class="ar">القَوَادِمُ</span>, <span class="auth">(Ṣ,)</span> four in number, in the fore part of the wing; <span class="auth">(Lḥ;)</span> the next, <span class="ar">المَنَاكِبُ</span>, <span class="auth">(Lḥ, Ṣ,)</span> also four; <span class="auth">(Lḥ;)</span> the next, <span class="ar">الخَوَافِى</span>, <span class="auth">(Lḥ, Ṣ,)</span> also four; <span class="auth">(Lḥ;)</span> the next, <span class="ar">الأَبَاهِرُ</span>, <span class="auth">(Lḥ, Ṣ,)</span> also four; <span class="auth">(Lḥ;)</span> and the next, <span class="ar">الكُلَى</span> <span class="add">[which are also four]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabohuwrN">
				<h3 class="entry"><span class="ar">مَبْهُورٌ</span></h3>
				<div class="sense" id="mabohuwrN_A1">
					<p><span class="ar">مَبْهُورٌ</span>: <a href="#bahiyrN">see <span class="ar">بَهِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotahirN">
				<h3 class="entry"><span class="ar">مُبْتَهِرٌ</span></h3>
				<div class="sense" id="mubotahirN_A1">
					<p><span class="ar">مُبْتَهِرٌ</span>: <a href="#bahiyrN">see <span class="ar">بَهِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="munobahir">
				<h3 class="entry"><span class="ar">مُنْبَهِر</span></h3>
				<div class="sense" id="munobahir_A1">
					<p><span class="ar">مُنْبَهِر</span>: <a href="#bahiyrN">see <span class="ar">بَهِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0265.pdf" target="pdf">
							<span>Lanes Lexicon Page 265</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0266.pdf" target="pdf">
							<span>Lanes Lexicon Page 266</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
