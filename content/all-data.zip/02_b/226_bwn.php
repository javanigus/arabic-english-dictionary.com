<article class="root" id="Root_bwn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/225_bwm">بوم</a></span>
				<span class="ar">بون</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/227_bwh">بوه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwn_1">
				<h3 class="entry">1. ⇒ <span class="ar">بون</span> ⇒ <span class="ar">بان</span></h3>
				<div class="sense" id="bwn_1_A1">
					<p><span class="ar">بَانَهُ</span>, aor. <span class="ar">يَبُونُ</span>, <span class="auth">(Ṣ in art. <span class="ar">بين</span>, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَوْنٌ</span>, <span class="auth">(Mṣb, TA,)</span> <em>i. q.</em> <span class="ar">بَانَهُ</span> aor. <span class="ar">يَبِينُ</span>, <span class="auth">(Ṣ ubi suprà Ḳ,)</span> inf. n. <span class="ar">بَيْنٌ</span>, <span class="auth">(TA,)</span> meaning <em>He excelled him;</em> <span class="auth">(Ṣ* ubi suprà, Mṣb;)</span> <em>he surpassed him in excellence and in manly virtue:</em> so in the Iktitáf. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAnN">
				<h3 class="entry"><span class="ar">بَانٌ</span> / <span class="ar">بَانَةٌ</span></h3>
				<div class="sense" id="baAnN_A1">
					<p><span class="ar">بَانٌ</span> <span class="add">[a coll. gen. n., The <em>ben-tree; a species of moringa;</em> so in the present day;]</span> <em>a kind of tree,</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>well known:</em> <span class="auth">(Mṣb:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَانَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mgh, Mṣb:)</span> <em>its seed,</em> or <em>grain,</em> <span class="add">[<em>called</em> <span class="ar long">حَبُّ البَانِ</span> <em>and</em> <span class="ar long">جَوْزُ البَانِ</span> <em>and</em> <span class="ar long">فُسْتُقُ البَانِ</span>, <em>the glans unguentaria,</em> or <em>nux unguentaria,</em> or <em>ben-nut,</em>]</span> <em>has a good,</em> or <em>pleasant,</em> <span class="add">[<em>fragrant</em>]</span> <em>oil,</em> <span class="auth">(Ḳ,)</span> <em>called</em> <span class="ar long">دُهْنُ البَانِ</span> <span class="add">[<em>oil of ben</em>]</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> <em>and simply</em> <span class="ar">بَانٌ</span>, the prefixed noun being suppressed: <span class="auth">(Mgh:)</span> <span class="add">[Az says,]</span> <a href="#baAnapN">it is the pl. of <span class="ar">بَانَةٌ</span></a>. which is <em>a certain tree having a fruit,</em> or <em>produce, which is perfumed with aromatics, after which its oil is expressed, of a good</em> <span class="add">[or <em>fragrant</em>]</span> <em>quality:</em> <span class="auth">(T in art. <span class="ar">بنى</span>:)</span> <em>its seed,</em> or <em>grain, is good for</em> <span class="add">[<em>removing</em>]</span> <em>the</em> <span class="add">[<em>affections of the skin termed</em>]</span> <span class="ar">بَرَش</span> and <span class="ar">نَمَش</span> and <span class="ar">كَلَف</span> and <span class="ar">حَصَف</span> and <span class="ar">بَهَق</span> and <span class="ar">سَعَفَة</span> <em>and the mange,</em> or <em>scab, and for the peeling of the skin, applied in the form of a liniment with vinegar; and for hardness of the liver and the spleen, made into a beverage with vinegar; and a</em> <span class="ar">مِثْقَال</span> <em>thereof, drunk, is an emetic, which loosens crude phlegm: its seed,</em> or <em>grain, is good for</em> <span class="add">[<em>removing</em>]</span> <em>the</em> <span class="add">[<em>affections of the skin termed</em>]</span> <span class="ar">بَرَش</span> and <span class="ar">نَمَش</span> and <span class="ar">كَلَف</span> and <span class="ar">حَصَف</span> and <span class="ar">بَهَق</span> and <span class="ar">سَعَفَة</span> <em>and the mange,</em> or <em>scab, and for the peeling of the skin, applied in the form of a liniment with vinegar; and for hardness of the liver and the spleen, made into a beverage with vinegar; and a</em> <span class="ar">مِثْقَال</span> <em>thereof, drunk, is an emetic, which loosens crude phlegm:</em> <span class="auth">(Ḳ:)</span> AḤn says, <span class="auth">(TA,)</span> <em>it is a kind of tree that grows tall, in a straight,</em> or <em>an erect, manner, like as grows the</em> <span class="add">[<em>species of tamarisk called</em>]</span> <span class="ar">أَثْل</span>, <em>and its leaves are</em> <span class="add">[<em>of the kind termed</em>]</span> <span class="ar">هَدَب</span>, like those of the <span class="ar">اثل</span>, <em>but its wood has no hardness:</em> the n. un. is with <span class="ar">پ</span>: Aboo-Ziyád says, <em>it is of the</em> <span class="add">[<em>trees called</em>]</span> <span class="ar">عِضَاه</span>, <em>and has long</em> <span class="ar">هدب</span>, <em>intensely green; it grows upon</em> <span class="add">[<em>hills,</em> or <em>what are termed</em>]</span> <span class="ar">هَضْب</span>; <em>and its fruit resembles the pods of the</em> <span class="add">[<em>species of kidney-bean called</em>]</span> <span class="ar">لُوبِيَآء</span>, <em>except that its greenness is intense; and in it is a seed,</em> or <em>grain, from which is extracted the oil of the</em> <span class="ar">بان</span>: <em>on account of the straightness of its growth and of the growth of its braches, and their length and tenderness, the poets liken thereto the tender girl of tall and beautiful,</em> or <em>just, stature; saying</em> <span class="ar long">كَأَنَّهَا بَانَةٌ</span> <span class="add">[<em>As though she were a ben-tree</em>]</span>, and <span class="ar long">كَأَنَّهَا غُصْنُ بَانٍ</span> <span class="add">[<em>As though she were a branch of the ben-tree</em>]</span>, &amp;c.: thus does Keys Ibn-El-Kha- teem: <span class="auth">(M in art. <span class="ar">بين</span>:)</span> and so does Imra-el-Ḳeys. <span class="auth">(TA.)</span> <span class="add">[See an ex. voce <span class="ar">بَرَهْرَهَةٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بون</span> - Entry: <span class="ar">بَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAnN_A2">
					<p><span class="add">[It is also applied in the present day to <em>A species of willow,</em> the <em>salix Aegyptia</em> of Linnæus, properly called in Arabic <span class="ar">خِلَاف</span>: and this is said to be meant by modern Arab poets when they liken an elegant girl to a twig of the <span class="ar">بان</span>; but probably from their erroneously supposing this tree to be meant in the same case by the older poets.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawonN">
				<h3 class="entry"><span class="ar">بَوْنٌ</span></h3>
				<div class="sense" id="bawonN_A1">
					<p><span class="ar">بَوْنٌ</span> <em>Excellence: an excellent quality;</em> <span class="auth">(Ṣ in art. <span class="ar">بين</span>, Mṣb;)</span> as also<span class="arrow"><span class="ar">بَوْنَةٌ↓</span></span>: <span class="auth">(IAạr; T:)</span> or the <em>distance, space,</em> or <em>interval, between tow things;</em> as also darr; <span class="ar">بُونٌ</span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">بَيْنَهُمَا بَوْنٌ بَعِيدٌ</span> <span class="auth">(T, Ṣ, Mṣb*)</span> and <span class="ar long">بَيْنٌ بَعِيدٌ</span> <span class="auth">(T, Ṣ)</span> <span class="add">[<em>Between them two</em> <span class="auth">(meaning two men)</span> <em>is a wide distance</em>]</span>; i. e. <em>between their tow degrees of rank</em> or <em>dignity,</em> or <em>between the estimations in which they are commonly held:</em> <span class="auth">(Mṣb:)</span> the former phrase is the more chaste: <span class="auth">(Ṣ:)</span> when corporeal distance is meant, one says, <span class="ar long">بَيْنَهُمَا بَيْنٌ</span>, with <span class="ar">ى</span>; <span class="auth">(Mṣb;)</span> or in the case of <span class="add">[literal]</span> distance, one says, <span class="ar long">إِنَّ بَيْنَهُمَا لَبَيْنًا</span>; not otherwise. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwnN">
				<h3 class="entry"><span class="ar">بُونٌ</span></h3>
				<div class="sense" id="buwnN_A1">
					<p><span class="ar">بُونٌ</span>: <a href="#baWonN">see <span class="ar">بَوْنٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawonapN">
				<h3 class="entry"><span class="ar">بَوْنَةٌ</span></h3>
				<div class="sense" id="bawonapN_A1">
					<p><span class="ar">بَوْنَةٌ</span>: <a href="#baWonN">see <span class="ar">بَوْنٌ</span></a></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بون</span> - Entry: <span class="ar">بَوْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bawonapN_A2">
					<p>Also <em>Mutual separation.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0278.pdf" target="pdf">
							<span>Lanes Lexicon Page 278</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
