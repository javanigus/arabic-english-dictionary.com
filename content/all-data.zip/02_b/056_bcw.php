<article class="root" id="Root_bcw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/055_bcl">بذل</a></span>
				<span class="ar">بذو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/057_br">بر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bcw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بذو</span> ⇒ <span class="ar">بذى</span></h3>
				<div class="sense" id="bcw_1_A1">
					<p><span class="ar">بَذُوَ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">يَبْذُو</span>, <span class="auth">(T, Ṣ,)</span> inf. n. <span class="ar">بَذَآءٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">بَذَآءَةٌ</span>, <span class="auth">(Ḳ,)</span> or the latter is the original form, but the <span class="ar">ة</span> is elided, as in <span class="ar">جَمَالٌ</span>, <a href="#jml_1">inf. n. of <span class="ar">جَمُلَ</span></a>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَذَآءَةٌ</span> is an inf. n. of the verb with <span class="ar">ء</span>, but <a href="#bcw">that of <span class="ar">بذو</span></a> is <span class="ar">بَذَآءٌ</span>; <span class="auth">(IB;)</span> and some say, <span class="ar">بَذِىَ</span>, <span class="auth">(T,)</span> which is a dial. var. of the former, <span class="auth">(Mṣb,)</span> aor. <span class="ar">يَبْذَى</span>, inf. n. <span class="ar">بَذَآءٌ</span>; <span class="auth">(T in art. <span class="ar">بذأ</span>;)</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, foul, unseemly,</em> or <em>obscene</em> <span class="add">[<em>in tongue</em>]</span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> <em>evil in speech;</em> <span class="auth">(T in art. <span class="ar">بذأ</span>;)</span> as also <span class="ar">بَذُؤَ</span>, <span class="auth">(T, M, Ḳ, in that art.,)</span> and <span class="ar">بَذَأَ</span>, <span class="auth">(Mṣb and Ḳ in art. <span class="ar">بذأ</span>,)</span> and <span class="ar">بَذِئَ</span>: <span class="auth">(Ḳ in that art.:)</span> and<span class="arrow"><span class="ar">ابذى↓</span></span> <em>he uttered foul, unseemly,</em> or <em>obscene, speech</em> or <em>language.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَذَوْتُ عَلَى القَوْمِ</span>, <span class="auth">(Ṣ, M, Mṣb,* Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُوُ</span>}</span></add>, inf. n. <span class="ar">بَذَآءٌ</span>; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar long">أَبْذَيْتُ↓ عَلَيْهِمْ</span></span>, <span class="auth">(Ṣ, Mṣb,*)</span> or <span class="ar">أَبْذَيْتُهُمْ</span>, <span class="auth">(M, IB, Ḳ,)</span> or both, <span class="auth">(TA,)</span> <em>I uttered foul, unseemly,</em> or <em>obscene, language against the people,</em> or <em>company of men:</em> <span class="auth">(Ṣ, M, Ḳ, TA:)</span> or <em>behaved in a lightwitted, weak, stupid,</em> or <em>foolish, manner,</em> or <em>ignorantly, towards them; and uttered foul, unseemly,</em> or <em>obscene, language against them;</em> and <em>so though with truth.</em> <span class="auth">(Mṣb.)</span> And <span class="ar">بَذَا</span> also signifies <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, evil in disposition.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcw_3">
				<h3 class="entry">3. ⇒ <span class="ar">باذو</span> ⇒ <span class="ar">باذى</span></h3>
				<div class="sense" id="bcw_3_A1">
					<p><span class="ar">باذى</span>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">مُبَاذَاةٌ</span>, <span class="auth">(TA,)</span> <span class="add">[<em>He vied with another,</em> or <em>strove to surpass him, in foul, unseemly,</em> or <em>obscene, speech</em> or <em>language:</em> or <em>he held such discourse with another:</em>]</span> the inf. n. is syn. with <span class="ar">مُفَاحَشَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bcw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابذو</span> ⇒ <span class="ar">ابذى</span></h3>
				<div class="sense" id="bcw_4_A1">
					<p><a href="#bcw_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacaMCN">
				<h3 class="entry"><span class="ar">بَذَآءٌ</span></h3>
				<div class="sense" id="bacaMCN_A1">
					<p><span class="ar">بَذَآءٌ</span> <span class="add">[<a href="#bcw_1">inf. n. of 1</a>, used as a subst,]</span> <em>Foul, unseemly,</em> or <em>obscene, speech</em> or <em>language.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacieN">
				<h3 class="entry"><span class="ar">بَذِىٌ</span> / <span class="ar">بَذِىَةٌ</span></h3>
				<div class="sense" id="bacieN_A1">
					<p><span class="ar">بَذِىٌ</span>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> or <span class="ar long">بَذِىٌ اللِّسَانِ</span>, <span class="auth">(Ṣ,)</span> A man <em>foul, unseemly,</em> or <em>obscene, in tongue:</em> <span class="auth">(T, Ṣ, M,* Ḳ:*)</span> or <em>lightwitted, weak, stupid,</em> or <em>ignorant, in behaviour; and foul, unseemly,</em> or <em>obscene, in speech;</em> and <em>so though speaking truth:</em> <span class="auth">(Mṣb:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَذِىَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mṣb:)</span> and pl. <span class="ar">أَبْذِيَآءُ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0175.pdf" target="pdf">
							<span>Lanes Lexicon Page 175</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
