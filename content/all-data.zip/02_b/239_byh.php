<article class="root" id="Root_byh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/238_byn">بين</a></span> 
				<span class="ar">بيه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/000_t">ت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="byh_1">
				<h3 class="entry">1. ⇒ <span class="ar">بيه</span> ⇒ <span class="ar">باه</span></h3>
				<div class="sense" id="byh_1_A1">
					<p><span class="ar long">بَاهَ لَهُ</span>, aor. <span class="ar">يَبَاهُ</span>, inf. n. <span class="ar">بَيْهٌ</span>; and <span class="ar long">مَا بِهْتُ لَهُ</span>: <a href="#bwh_1">see 1</a> <a href="index.php?data=02_b/227_bwh">in art. <span class="ar">بوه</span></a>.</p> 
				</div>
				<span class="pb" id="Page_0290"></span>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0289.pdf" target="pdf">
							<span>Lanes Lexicon Page 289</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
