<article class="root" id="Root_bzg">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/092_bzr">بزر</a></span>
				<span class="ar">بزغ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/094_bzq">بزق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bzg_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزغ</span></h3>
				<div class="sense" id="bzg_1_A1">
					<p><span class="ar">بُزُوغٌ</span> <span class="add">[inf. n. of <span class="ar">بَزَغَ</span>]</span> signifies The <em>beginning to rise,</em> or <em>come forth:</em> this is the primary meaning: mentioned by Zj. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزغ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzg_1_A2">
					<p>Hence, <span class="auth">(TA,)</span> <span class="ar">بَزَغَ</span>, said of a tush, or tusk, or canine tooth, <span class="auth">(A,)</span> or of the tush of a camel, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُغُ</span>}</span></add>,]</span> inf. n. <span class="ar">بُزُوغٌ</span>, <span class="auth">(Mṣb,)</span> <em>It came forth;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>it clave the flesh, and came forth.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزغ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bzg_1_A3">
					<p>And hence, <span class="auth">(A, TA,)</span> <span class="ar long">بَزَغَتِ الشَّمْسُ</span>, <span class="auth">(JK, Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُغُ</span>}</span></add>, <span class="auth">(TḲ,)</span> inf. n. as above <span class="auth">(JK, Ṣ, Ḳ)</span> and <span class="ar">بَزْغٌ</span>, <span class="auth">(Ḳ,)</span> <em>The sun began to rise;</em> <span class="auth">(JK, TA;)</span> <em>as though it clave the darkness with its light:</em> <span class="auth">(A, TA:)</span> or <em>rose,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>with spreading light:</em> <span class="auth">(TA:)</span> or <span class="ar">بُزُوغٌ</span> has the meaning first explained above; the <em>beginning to rise,</em> or <em>come forth.</em> <span class="auth">(Ḳ.)</span> And in like manner one says, <span class="ar long">بَزَغَ القَمَرُ</span> <span class="add">[<em>The moon began to rise:</em> or <em>rose</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزغ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzg_1_B1">
					<p><span class="ar">بَزَغَ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُغُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَزْغٌ</span>, <span class="auth">(JK, Mṣb,)</span> <em>He</em> <span class="auth">(a cupper, and a farrier,)</span> <em>scarified,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>and made the blood to flow:</em> <span class="auth">(Mṣb:)</span> <em>he</em> <span class="auth">(a farrier)</span> <em>scarified</em> a beast <span class="auth">(JK, Mgh, TA)</span> <em>in its</em> <span class="ar">أَشْعَر</span> <span class="add">[or <em>part next the hoof</em> <span class="auth">(in the TA, erroneously, <span class="ar">شعر</span>)</span>]</span>, <span class="auth">(JK,)</span> <em>with a</em> <span class="ar">مِبْزَع</span> <span class="auth">(JK, Mgh, TA)</span> <em>of iron;</em> <span class="auth">(JK;)</span> as also<span class="arrow"><span class="ar">بزّغ↓</span></span>, inf. n. <span class="ar">تَبْزِيغٌ</span>: <span class="auth">(JK,* TA:)</span> Aboo-ʼAdnán says that <span class="ar">تَبْزِيغٌ</span> and <span class="ar">تَعْرِيبٌ</span> signify the same, namely, the <em>making a slight incision,</em> or <em>stab, such as does not reach the sinews,</em> or <em>tendons.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزغ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bzg_1_B2">
					<p>And <em>He made</em> his blood <em>to flow.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzg_2">
				<h3 class="entry">2. ⇒ <span class="ar">بزّغ</span></h3>
				<div class="sense" id="bzg_2_A1">
					<p><a href="#bzg_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzg_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبزغ</span></h3>
				<div class="sense" id="bzg_7_A1">
					<p><span class="ar long">انبزغ الرَّبِيعُ</span>, <span class="auth">(Ṣ, and so in a copy of the Ḳ,)</span> or<span class="arrow"><span class="ar">ابتزغ↓</span></span>, <span class="auth">(so in other copies of the Ḳ and in the TA,)</span> <em>The first,</em> or <em>beginning, of the</em> <span class="add">[<em>season,</em> or <em>rain,</em> or <em>herbage, called</em>]</span> <span class="ar">ربيع</span> <em>came.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzg_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتزغ</span></h3>
				<div class="sense" id="bzg_8_A1">
					<p><a href="#bzg_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAzigN">
				<h3 class="entry"><span class="ar">بَازِغٌ</span></h3>
				<div class="sense" id="baAzigN_A1">
					<p><span class="ar long">قَمَرٌ بَازِغٌ</span>, <span class="auth">(TA,)</span> and <span class="ar long">شَمْسٌ بَازِغَةٌ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar long">نُجُومٌ بَوَازِغُ</span>, <span class="auth">(JK, A,)</span> <span class="add">[<em>A moon,</em> and <em>a sun,</em> and <em>stars,</em>]</span> <em>beginning to rise:</em> <span class="auth">(JK, TA:)</span> or <em>rising.</em> <span class="auth">(Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibozagN">
				<h3 class="entry"><span class="ar">مِبْزَغٌ</span></h3>
				<div class="sense" id="mibozagN_A1">
					<p><span class="ar">مِبْزَغٌ</span> <em>A lancet</em> <span class="auth">(Ṣ, Mgh, Ḳ)</span> <em>of a cupper</em> and <em>of a farrier.</em> <span class="auth">(JK, Mgh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0199.pdf" target="pdf">
							<span>Lanes Lexicon Page 199</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
