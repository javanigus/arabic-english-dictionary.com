<article class="root" id="Root_bv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/018_btl">بتل</a></span>
				<span class="ar">بث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/020_bvr">بثر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bv_1">
				<h3 class="entry">1. ⇒ <span class="ar">بثّ</span></h3>
				<div class="sense" id="bv_1_A1">
					<p><span class="ar">بَثَّهُ</span>, <span class="auth">(Lth, T, Ṣ, M, A, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُثُ</span>}</span></add> <span class="auth">(Lth, T, M, L, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْثِثُ</span>}</span></add>, <span class="auth">(M, L, Ḳ,)</span> the latter <span class="add">[anomalous, and therefore]</span> thought by MF to be a mistake, arising from confounding <span class="ar">بَثَّ</span> with <span class="ar">بَتَّ</span>, he not knowing any authority for it except the Ḳ, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَثٌ</span>; <span class="auth">(Lth, T, M, L;)</span> and<span class="arrow"><span class="ar">ابثّهُ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">إِبْثَاثٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بثّثهُ↓</span></span>, <span class="auth">(Ḳ,)</span> or this has an intensive signification; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">بَثْبَثَهُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَثْبَثَةٌ</span>; <span class="auth">(Ṣ;)</span> <em>He spread it;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> <em>he dispersed it, scattered it,</em> or <em>disseminated it;</em> <span class="auth">(Lth, T, Ṣ,* M, A, Ḳ;)</span> namely, a thing; <span class="auth">(Lth, T, M, A,* L;)</span> or ‡ news, tidings, or information. <span class="auth">(Ṣ, A, L, Ḳ.)</span> You say, <span class="ar long">بَثُّوا الخَيْلَ فِى الغَارَةِ</span> <em>They spread,</em> or <em>dispersed, the horses,</em> or <em>horseme in the hostile incursion.</em> <span class="auth">(T, M,* A, L.)</span> And <span class="ar long">بَثَّ الجُنْدَ فِى البِلَادِ</span> <em>He</em> <span class="auth">(the Sultán)</span> <em>spread,</em> or <em>dispersed, the army in the provinces.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">بَثَّ كِلَابَهُ</span> <em>He</em> <span class="auth">(the hunter, A, L)</span> <em>spread,</em> or <em>dispersed, his dogs</em> <span class="auth">(T, A, L)</span> <span class="ar long">عَلَ الصَّيْدِ</span> <span class="add">[<em>against the chase,</em> or <em>game</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">بَثَّ ٱللّٰهُ الخَلْقَ</span>,, <span class="auth">(aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُثُ</span>}</span></add>, inf. n. <span class="ar">بَثٌّ</span>, Mṣb,)</span> <em>God spread,</em> or <em>dispersed, mankind,</em> or <em>the beings whom He created,</em> <span class="ar long">فِى الأَرْضِ</span> <span class="add">[<em>in the earth</em>]</span>: <span class="auth">(T, A:)</span> or <em>God created them.</em> <span class="auth">(Mṣb.)</span> <span class="ar long">وَبَثٌّ مِنْهُمَا رِحَالًا كثيرًا وَنِسَآءٌ</span>, in the Ḳur <span class="add">[iv. 1.]</span>, means <em>And spread,</em> or <em>dispersed, and multiplied, from them two, many men, and women.</em> <span class="auth">(T.)</span> You say also, <span class="ar long">بُثَّتِ البُسُطُ</span> <em>The carpets were spread.</em> <span class="auth">(T.)</span> And <span class="ar long">بَثَّ المَتَاعَ بِنَوَاحِى البَيْتِ</span> <em>He spread out the furniture,</em> or <em>utensils, in the sides of the tent,</em> or <em>house,</em> or <em>chamber.</em> <span class="auth">(A.)</span> And <span class="ar long">بَثَّ الغُبَارَ</span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بَثْبَثَهُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He,</em> or <em>it, raised the dust.</em> <span class="auth">(Ṣ, Ḳ.)</span> And<span class="arrow"><span class="ar long">بَثْبَثَ↓ التُّرَابَ</span></span> <em>He,</em> or <em>it, raised the dust,</em> or <em>earth, and removed it from that which was beneath it.</em> <span class="auth">(M.)</span> And<span class="arrow"><span class="ar">بَثْبَثُوهُ↓</span></span> <em>They uncovered him.</em> <span class="auth">(Hr, M, L, from a trad. respecting a dying Jew.)</span> And <span class="ar long">بَثَّ الحَدِيثَ</span> † <em>He spread, published,</em> or <em>revealed, the discourse, narration,</em> or <em>information.</em> <span class="auth">(Mṣb.)</span> And, accord. to IF, <span class="ar long">بَثَّ السِّرَّ</span> and<span class="arrow"><span class="ar">ابثّهُ↓</span></span> † <span class="add">[<em>He spread, published,</em> or <em>revealed, the secret</em>]</span>. <span class="auth">(Mṣb.)</span> And <span class="ar long">بَثَثْتُهُ مَا فِى نَفْسِى</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُثُ</span>}</span></add>; and<span class="arrow"><span class="ar long">أَبْثَثَتُهُ↓ إِيَّاهُ</span></span>; ‡ <em>I revealed,</em> or <em>showed, to him what was in my mind.</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">أَبْثَثْتُكَ↓ سِرِىّ</span></span>, <span class="auth">(Ṣ,)</span> or <span class="ar">السِّرَّ</span>; <span class="auth">(Ḳ;)</span> and <span class="ar long">بَثَثْتُكَ السِّرَّ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَثٌّ</span>; <span class="auth">(TA;)</span> † <em>I revealed,</em> or <em>showed, to him my secret,</em> or <em>the secret:</em> <span class="auth">(Ṣ, Ḳ:)</span> or<span class="arrow"><span class="ar long">أَبْثَثْتُهُ↓ سِرِّى</span></span> <span class="auth">(T)</span> and<span class="arrow"><span class="ar long">بَاثَثْتُهُ↓ سِرِّى</span></span> <span class="auth">(A)</span> ‡ <em>I acquainted him with my secret:</em> <span class="auth">(T, A:)</span> and<span class="arrow"><span class="ar long">ابثّهُ↓ الحَدِيثَ</span></span> † <em>he acquainted him with the discourse, narration,</em> or <em>information.</em> <span class="auth">(M.)</span> And <span class="ar long">بَثَّهُ شُقُورَهُ</span> † <em>He complained to him of his state,</em> or <em>condition.</em> <span class="auth">(M, in art. <span class="ar">شقر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_2">
				<h3 class="entry">2. ⇒ <span class="ar">بثّث</span></h3>
				<div class="sense" id="bv_2_A1">
					<p><span class="ar long">بثّث الخَبَرَ</span> <em>He spread,</em> or <em>disseminated, the news, tidings,</em> or <em>information, much:</em> <span class="auth">(Ṣ:)</span> or <em>i. q.</em> <span class="ar">بَثَّهُ</span>, q. v. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_3">
				<h3 class="entry">3. ⇒ <span class="ar">باثّ</span></h3>
				<div class="sense" id="bv_3_A1">
					<p><span class="ar long">بَاثَثَتُهُ سِرِّى</span>: <a href="#bv_1">see 1</a>; last sentence but one.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بث</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bv_3_A2">
					<p><span class="ar long">بَيْنَهُمَا مُبَاثَّةٌ</span> ‡ <span class="add">[<em>Between them two is a mutual revealing of secrets:</em> <a href="#bv_6">see 6</a>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابثّ</span></h3>
				<div class="sense" id="bv_4_A1">
					<p><a href="#bv_1">see 1</a>, in six places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بث</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bv_4_A2">
					<p><span class="ar">أَبْثَثْتُكَ</span> <span class="add">[without a second objective complement,]</span> † <em>I revealed,</em> or <em>showed,</em> or <em>have revealed</em> or <em>shown, to thee my</em> <span class="ar">بَثّ</span>, <span class="auth">(Ṣ, TA,)</span> whence the verb in this sense is derived; <span class="auth">(TA;)</span> i. e., my <em>state,</em> <span class="auth">(Ṣ,)</span> or my <em>grief,</em> or <em>sorrow.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباثّ</span></h3>
				<div class="sense" id="bv_6_A1">
					<p><span class="ar">تَبَاثُّوا</span> † <span class="add">[<em>They revealed secrets, one to another:</em> <a href="#bv_3">see 3</a>]</span>. <span class="auth">(Ḳ, in art. <span class="ar">نجث</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبثّ</span></h3>
				<div class="sense" id="bv_7_A1">
					<p><span class="ar">انبثّ</span> <em>It spread;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> <em>it became dispersed, scattered,</em> or <em>disseminated;</em> <span class="auth">(Ṣ,* M, A, Ḳ;)</span> namely, a thing; <span class="auth">(M, L;)</span> or ‡ news, tidings, or information. <span class="auth">(Ṣ, A, L, Ḳ.)</span> You say, <span class="ar long">انبثّت الخَيْلُ</span> <em>The horses,</em> or <em>horsemen, spread,</em> or <em>became dispersed,</em> or <em>dispersed themselves,</em> <span class="auth">(M, L,)</span> in a hostile incursion. <span class="auth">(L.)</span> And <span class="ar long">انبثّ الجَرَادُ فِى الأَرْضِ</span> <em>The locusts spread,</em> or <em>became dispersed,</em> or <em>dispersed themselves, in the land.</em> <span class="auth">(M, A, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبثّ</span></h3>
				<div class="sense" id="bv_10_A1">
					<p><span class="ar long">استبثّهُ إِيَّاهُ</span> † <em>He asked him,</em> or <em>petitioned him, to reveal it to him.</em> <span class="auth">(M, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bv_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بثبث</span></h3>
				<div class="sense" id="bv_RQ1_A1">
					<p><span class="ar">بَثْبَثَ</span>, inf. n. <span class="ar">بَثْبَثَةٌ</span>: <a href="#bv_1">see 1</a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بث</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bv_RQ1_A2">
					<p><span class="ar long">بَثْبَثَ الأَمْرَ</span> † <em>He inquired respecting the affair</em> or <em>event, scrutinized it, and sought information respecting it.</em> <span class="auth">(T, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bavN">
				<h3 class="entry"><span class="ar">بَثٌ</span></h3>
				<div class="sense" id="bavN_A1">
					<p><span class="ar">بَثٌ</span> <span class="auth">(Aṣ, Ṣ, M, A, Ḳ)</span> and<span class="arrow"><span class="ar">مُنْبَثٌّ↓</span></span>, <span class="auth">(A, TA,)</span> both applied to dates, (<span class="ar">تَمْرٌ</span>, Aṣ, Ṣ, &amp;c.,) <em>Scattered, strewn, dispersed, and separate,</em> <span class="auth">(Aṣ, Ṣ, Ḳ,)</span> <em>one from another:</em> <span class="auth">(Aṣ, Ṣ:)</span> or <em>separate,</em> or <em>disunited, not being packed,</em> or <em>not campact:</em> <span class="auth">(A:)</span> <em>or not well packed,</em> <span class="auth">(Ṣ, M,)</span> <em>so that they are separated,</em> or <em>disunited:</em> <span class="auth">(M:)</span> or <em>scattered; not in the bag or other receptacle;</em> like <span class="ar">فَثٌّ</span>: <span class="auth">(M:)</span> <span class="ar long">تَمْرٌ بَثٌ</span> being a phrase <span class="add">[in which the latter word is an inf. n. used in the sense of a pass. part. n.,]</span> like <span class="ar long">مَآءٌ غَوْرٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بث</span> - Entry: <span class="ar">بَثٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bavN_B1">
					<p><em>A state,</em> or <em>condition.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بث</span> - Entry: <span class="ar">بَثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bavN_B2">
					<p><em>Grief,</em> or <em>sorrow,</em> <span class="auth">(T, Ṣ, M,)</span> <em>which one makes known to his companion or friend:</em> <span class="auth">(T:)</span> or <em>violent,</em> or <em>intense, grief</em> or <em>sorrow;</em> and <em>violent,</em> or <em>severe, disease</em> or <em>sickness;</em> as though, in consequence of its violence, one made it known to his companion or friend: <span class="auth">(T, TA:)</span> or the <em>most violent</em> or <em>intense grief</em> or <em>sorrow.</em> <span class="auth">(Ḳ.)</span> <span class="ar long">حَضَرَنِى بَثِّى</span>, occurring in a trad., means <em>My grief,</em> or <em>sorrow, became violent,</em> or <em>intense.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabovuwvapN">
				<h3 class="entry"><span class="ar">مَبْثُوثَةٌ</span></h3>
				<div class="sense" id="mabovuwvapN_A1">
					<p><span class="ar long">زَرِابِىُّ مَبْثُوثَةٌ</span> <span class="add">[in the Ḳur lxxxviii. 16]</span> means <em>Goodly carpets,</em> or <em>the like,</em> <span class="auth">(Bḍ,)</span> <em>spread:</em> <span class="auth">(A, Bḍ:)</span> or, accord. to Fr, <em>many in number.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="munobavBN">
				<h3 class="entry"><span class="ar">مُنْبَثٌّ</span></h3>
				<div class="sense" id="munobavBN_A1">
					<p><span class="ar">مُنْبَثٌّ</span>: <a href="#bavN">see <span class="ar">بَثٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بث</span> - Entry: <span class="ar">مُنْبَثٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="munobavBN_A2">
					<p><em>Scattered</em> dust: so in the Ḳur <span class="add">[lvi. 6]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بث</span> - Entry: <span class="ar">مُنْبَثٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="munobavBN_A3">
					<p>† <em>Swooning</em> <span class="auth">(Ḳ)</span> <em>from grief,</em> or <em>sorrow.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0151.pdf" target="pdf">
							<span>Lanes Lexicon Page 151</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
