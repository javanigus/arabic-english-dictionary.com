<article class="root" id="Root_bTw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/135_bTn">بطن</a></span>
				<span class="ar">بطو</span> / <span class="ar">بطى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/137_bZr">بظر</a></span>
			</h2>
			<h4 class="root"><span class="ar">بطو</span> or <span class="ar">بطى</span></h4>
			<hr>
			<section class="entry main" id="bTw_1">
				<span class="pb" id="Page_0222"></span>
				<h3 class="entry">1. ⇒ <span class="ar">بطو</span> ⇒ <span class="ar">بطى</span></h3>
				<div class="sense" id="bTw_1_A1">
					<p><span class="ar">بَطَا</span>, aor. <span class="ar">يَبْطُو</span>, is said by Z and Meyd to signify <em>He,</em> or <em>it, was,</em> or <em>became, wide:</em> and hence <span class="ar">بَاطِيَةٌ</span>, meaning a <span class="ar">نَاجُود</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bTw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطو</span> ⇒ <span class="ar">ابطى</span></h3>
				<div class="sense" id="bTw_4_A1">
					<p><a href="#biToyapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biToyapN">
				<h3 class="entry"><span class="ar">بِطْيَةٌ</span></h3>
				<div class="sense" id="biToyapN_A1">
					<p><span class="ar">بِطْيَةٌ</span>, with kesr, is a word mentioned by Sb; <span class="auth">(Ḳ;)</span> but ISd says, “I know not to what it is applied, unless <span class="arrow"><span class="ar">أَبْطَيْتُ↓</span></span> be <a href="#OaboTaOotu">a dial. var. of <span class="ar">أَبْطَأْتُ</span></a>, <span class="auth">(Ḳ, TA,)</span> like as <span class="ar">اِحْبَنْطَيْتُ</span> is of <span class="ar">اِحْبَنْطَأْتُ</span>; in which case it is thence derived as meaning The <em>state</em> <span class="add">[<em>of being slow,</em>, &amp;c.]</span>; and is not to be regarded as formed by substitution <span class="add">[of <span class="ar">ى</span> for <span class="ar">ء</span>]</span>, because that would be extr.:” so in the M: <span class="auth">(TA:)</span> it is asserted, however, in the Ṣ and the Fṣ and the Jámiʼ el-Loghah of Ḳz and in other lexicons, that one should not say, <span class="ar">ابطيت</span>, with <span class="ar">ى</span>, but <span class="ar">ابطأت</span>, with <span class="ar">ء</span>. <span class="auth">(MF, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baATK">
				<h3 class="entry"><span class="ar">بَاطٍ</span></h3>
				<div class="sense" id="baATK_A1">
					<p><span class="ar">بَاطٍ</span> part. n. of <span class="ar">بَطَا</span>, mentioned above, accord. to Z and Meyd. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baATiyapN">
				<h3 class="entry"><span class="ar">بَاطِيَةٌ</span></h3>
				<div class="sense" id="baATiyapN_A1">
					<p><span class="ar">بَاطِيَةٌ</span> <em>A certain vessel;</em> <span class="auth">(Ṣ;)</span> <em>a</em> <span class="ar">نَاجُود</span> <span class="add">[or <em>vessel into which wine is put</em>]</span>; <span class="auth">(AA, Ṣ, Mgh, Ḳ;)</span> <em>a large vessel of glass, which is filled with wine,</em> or <em>beverage, and placed amid the drinkers, who ladle out from it</em> <span class="add">[<em>into their cups</em>]</span>, <span class="auth">(Az, Mgh, TA,)</span> <em>and drink:</em> <span class="auth">(Az, TA:)</span> <span class="add">[<em>a wine-vase, of glass</em> or <em>of earthenware; an amphora; an earthen jar;</em> now applied to <em>a vessel of this kind into which wine and oil</em>, &amp;c. <em>are put:</em>]</span> said to be an arabicized word: <span class="auth">(TA:)</span> <span class="add">[J says,]</span> “I think it to be arabicized:” <span class="auth">(Ṣ:)</span> but accord. to Z and Meyd, it is from 1, as mentioned above. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0222.pdf" target="pdf">
							<span>Lanes Lexicon Page 222</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
