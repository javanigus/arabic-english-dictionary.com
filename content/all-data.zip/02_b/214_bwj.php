<article class="root" id="Root_bwj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/213_bwb">بوب</a></span>
				<span class="ar">بوج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/215_bwH">بوح</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">بوج</span></h4>
			<hr>
			<section class="entry main" id="baAjN">
				<h3 class="entry"><span class="ar">بَاجٌ</span></h3>
				<div class="sense" id="baAjN_A1">
					<p><span class="ar">بَاجٌ</span>; pl. <span class="ar">أَبْوَاجٌ</span>: <a href="../">see art. <span class="ar">بأج</span></a>. AZ mentions it as without <span class="ar">ء</span>: ISk, as with <span class="ar">ء</span>. <span class="auth">(ISd, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0273.pdf" target="pdf">
							<span>Lanes Lexicon Page 273</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
