<article class="root" id="Root_bXm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/111_bXq">بشق</a></span>
				<span class="ar">بشم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/113_bXnyn">بشنين</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bXm_1">
				<h3 class="entry">1. ⇒ <span class="ar">بشم</span></h3>
				<div class="sense" id="bXm_1_A1">
					<p><span class="ar">بَشِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْشَمُ</span>}</span></add>, inf. n. <span class="ar">بَشَمٌ</span>, <em>He</em> <span class="auth">(a man, Ṣ, TA, or an animal, Mṣb)</span> <em>suffered,</em> or <em>became affected with, indigestion,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> in consequence of much eating: <span class="auth">(Mṣb:)</span> or <em>he was heavy</em> in consequence of food: <span class="auth">(Ḥam p. 363:)</span> or <em>he became distressed,</em> or <em>oppressed, by eating much food.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">بَشِمْتُ مِنَ الطَّعَامِ</span> <em>I suffered indigestion from the food:</em> <span class="auth">(Ṣ:)</span> or <em>was heavy in consequence of the food.</em> <span class="auth">(Ḥam ubi suprà)</span> And <span class="ar long">بَشِمَ الفَصِيلُ مِنْ كَثْرَةِ شُرْبِ اللَّبَنِ</span> <em>The young camel suffered indigestion from drinking much milk.</em> <span class="auth">(Ṣ.)</span> Accord. to IDrd, <span class="ar">بَشَمٌ</span> specially relates to beasts: accord. to Kh, it specially arises from greasy food. <span class="auth">(Ḥar p. 164.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bXm_1_A2">
					<p>Also ‡ <em>He became affected with disgust, aversion, loathing,</em> or <em>nausea.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span> You say, <span class="ar long">بَشِمْتُ مِنَ الطَّعَامِ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">عَنِ الطعام</span>, <span class="auth">(TA,)</span> ‡ <em>I turned away with disgust from the food; was averse from it; loathed it; nauseated it.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">بَشِمَ الفَصِيلُ عَنِ اللَّبَنِ</span> † <span class="add">[<em>The young camel turned away with disgust from the milk; was averse from it;</em>, &amp;c.]</span>. <span class="auth">(Ḳ in art.<span class="ar">دقع</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXm_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابشم</span></h3>
				<div class="sense" id="bXm_4_A1">
					<p><span class="ar">ابشمهُ</span> <em>It</em> <span class="auth">(food)</span> <em>caused him to suffer,</em> or <em>be affected with, indigestion:</em> <span class="auth">(Ṣ, Ḳ,* TA:)</span> or † <em>loathing,</em> or <em>nausea.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXima">
				<h3 class="entry"><span class="ar">بَشِمَ</span></h3>
				<div class="sense" id="baXima_A1">
					<p><span class="ar">بَشِمَ</span> part. n. of 1, meaning <em>Suffering,</em> or <em>affected with, indigestion.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشم</span> - Entry: <span class="ar">بَشِمَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baXima_A2">
					<p><span class="add">[And † <em>Affected with disgust, aversion, loathing,</em> or <em>nausea.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXaAmN">
				<h3 class="entry"><span class="ar">بَشَامٌ</span> / <span class="ar">بَشَامَةٌ</span></h3>
				<div class="sense" id="baXaAmN_A1">
					<p><span class="ar">بَشَامٌ</span> <span class="add">[The <em>tree of the balsam of Mekkeh; amyris opobalsamum;</em> mentioned by Forskål in his Flora Aegypt. Arab. p. ex. as growing in the middle mountainous region of El-Yemen, and described by him in p. 79 of the same work; in both places as being called in Arabic <span class="ar long">ابو شام</span>, which is a mistake for <span class="ar">بشام</span>;]</span> <em>a certain odoriferous kind of tree,</em> <span class="auth">(Ṣ Ḳ,)</span> <em>of sweet taste,</em> <span class="auth">(TA,)</span> <em>the leaves of which,</em> <span class="auth">(AḤn, Ḳ)</span> <em>pounded, and mixed with</em> <span class="ar">الحِنَّآء</span> <span class="add">[or <em>the leaves of the Lawsonia inermis</em>]</span>, <span class="auth">(AḤn,)</span> <em>blacken the hair;</em> <span class="auth">(AḤn, Ḳ)</span> it is a <em>kind of tree having a stem and branches, and small leaves, but larger than the leaves of the</em> <span class="add">[<em>species of marjoram called</em>]</span> <span class="ar">صَعْتَر</span>, <em>and having no fruit;</em> <span class="add">[<em>but only,</em> as Forskål states, <em>a blackish seed, which is abortive;</em>]</span> <em>when its leaf or its branch is cut, it pours forth a white milk;</em> <span class="auth">(AḤn, TA;)</span> <em>and its twigs are used for cleaning the teeth:</em> <span class="auth">(Ṣ, Ḳ:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَشَامَةٌ</span>}</span></add>. <span class="auth">(TA.)</span> In a trad., mention is made of persons having no food but the leaves of the <span class="ar">بشام</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0209.pdf" target="pdf">
							<span>Lanes Lexicon Page 209</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
