<article class="root" id="Root_brn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/082_brm">برم</a></span>
				<span class="ar">برن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/084_brns">برنس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baronieBN">
				<h3 class="entry"><span class="ar">بَرْنِىٌّ</span> / <span class="ar">بَرْنِيَّةٌ</span></h3>
				<div class="sense" id="baronieBN_A1">
					<p><span class="ar">بَرْنِىٌّ</span> <em>A sort of dates,</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> <em>well known,</em> <span class="auth">(Ḳ,)</span> <em>the best of dates,</em> <span class="auth">(M,)</span> or <em>of the best of dates,</em> <span class="auth">(Mṣb,)</span> <em>red, intermixed,</em> or <em>tinged, with yellow, having much</em> <span class="ar">لِحَآء</span> <span class="add">[i. e. <em>flesh,</em> or <em>pulp</em>]</span>, <em>and very sweet,</em> <span class="auth">(T,)</span> or <em>yellow, and round:</em> <span class="auth">(M:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرْنِيَّةٌ</span>}</span></add>: <span class="auth">(M:)</span> it is an arabicized word, originally <span class="ar">بَرْنِيكْ</span>, i. e. good, or excellent, fruit: <span class="auth">(Ḳ:)</span> accord. to AḤn, of Persian origin, i. e., <span class="ar">بَارْنِىْ</span>; <span class="ar">بار</span> meaning fruit, and <span class="ar">نى</span> denoting egregiousness: <span class="auth">(M:)</span> accord. to Suh, a foreign, or Persian, word, meaning blessed <span class="add">[or good or excellent]</span> fruit; <span class="ar">بَرٌ</span> meaning fruit; and <span class="ar">هِنِى</span>, good or excellent <span class="add">[or wholesome]</span>: the Arabs introduced it into their language: <span class="auth">(Mṣb:)</span> or, accord. to the Moajam of El-Bekree, it is from <span class="ar">بَرْنٌ</span>, the name of a town, or village. <span class="auth">(TA.)</span> It is converted by a rájiz into <span class="ar">بَرْنِجّ</span>; the double <span class="ar">ى</span> being changed into <span class="add">[double]</span> <span class="ar">ج</span>. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برن</span> - Entry: <span class="ar">بَرْنِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baronieBN_A2">
					<p>You say also <span class="ar long">نَخْلٌ بَرْنِىٌّ</span> and <span class="ar long">نَخْلَةٌ بَرْنِيَّةٌ</span> <span class="add">[<em>Palm-trees,</em> and <em>a palm-tree, of which the dates are of the sort described above</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroniyBapN">
				<h3 class="entry"><span class="ar">بَرْنِيَّةٌ</span></h3>
				<div class="sense" id="baroniyBapN_A1">
					<p><span class="ar">بَرْنِيَّةٌ</span> <a href="#baronieBN">n. un. of <span class="ar">بَرْنِىٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برن</span> - Entry: <span class="ar">بَرْنِيَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baroniyBapN_B1">
					<p>Also <em>A kind of vessel,</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>well known,</em> <span class="auth">(Mṣb,)</span> <em>of baked clay:</em> <span class="auth">(Ṣ, Mgh, Ḳ:)</span> or, as some say, <em>of those that are termed</em> <span class="ar">قَوَارِير</span> <span class="add">[i. e. <em>flasks,</em> or <em>bottles,</em> generally <em>of glass</em>]</span>; <em>such as are used by the seller of perfumes:</em> <span class="auth">(Mgh:)</span> or <em>a thing like a vessel of baked clay, big,</em> or <em>bulky, and green:</em> and sometimes <em>of the kind termed</em> <span class="ar">قوارير</span>: <span class="auth">(M:)</span> or <em>a thing like vessels of baked clay, big,</em> or <em>bulky, and green; of the kind termed</em> <span class="ar">قوارير</span> <em>that are thick, with wide mouths:</em> <span class="auth">(Lth, T:)</span> pl. <span class="ar">بَرَانِىٌّ</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برن</span> - Entry: <span class="ar">بَرْنِيَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="baroniyBapN_C1">
					<p>And <em>A cock:</em> <span class="auth">(IAạr, T:)</span> or <em>a young cock,</em> <span class="auth">(M, Ḳ,)</span> <em>when it attains to maturity,</em> <span class="auth">(M,)</span> or <em>when it begins to do so:</em> <span class="auth">(Ḳ:)</span> of the dial. of El-'Irák: <span class="auth">(M:)</span> pl. as above. <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0196.pdf" target="pdf">
							<span>Lanes Lexicon Page 196</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
