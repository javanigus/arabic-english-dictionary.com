<article class="root" id="Root_bEd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/140_bEj">بعج</a></span>
				<span class="ar">بعد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/142_bEr">بعر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEd_1">
				<h3 class="entry">1. ⇒ <span class="ar">بعد</span></h3>
				<div class="sense" id="bEd_1_A1">
					<p><span class="ar">بَعُدَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْعُدُ</span>}</span></add>, inf. n. <span class="ar">بُعْدٌ</span>; <span class="auth">(Ṣ, L, Mṣb, Ḳ;)</span> and <span class="ar">بَعِدَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَدُ</span>}</span></add>, inf. n. <span class="ar">بَعَدٌ</span>; <span class="auth">(L, Ḳ;)</span> and<span class="arrow"><span class="ar">ابعد↓</span></span>, inf. n. <span class="ar">إِبْعَادٌ</span>, which is also trans.; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">تباعد↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">استبعد↓</span></span>; <span class="auth">(Ṣ, Ḳ, &amp;c.;)</span> <em>He,</em> or <em>it, was,</em> or <em>became, distant, remote, far off,</em> or <em>aloof: he went,</em> or <em>removed,</em> or <em>retired,</em> or <em>withdrew himself, to a distance,</em> or <em>far away,</em> or <em>far off: he alienated,</em> or <em>estranged, himself: he stood,</em> or <em>kept, aloof: contr. of</em> <span class="ar">قَرُبَ</span>: <span class="auth">(Ṣ, L:)</span> <span class="add">[but <span class="ar">بَعُدَ</span> generally has the first of these significations; and<span class="arrow"><span class="ar">ابعد↓</span></span>, the others, as also<span class="arrow"><span class="ar">تباعد↓</span></span> and<span class="arrow"><span class="ar">استبعد↓</span></span>:]</span> it is the general opinion of the leading lexicologists that <span class="ar">بَعِدَ</span>, as well as <span class="ar">بَعُدَ</span>, is thus used; but some deny this; and some assert that they may be employed alike, but that <span class="ar">بَعُدَ</span> is more chaste than <span class="ar">بَعِدَ</span> thus used. <span class="auth">(TA.)</span> <span class="add">[You say also, of a desert, and a tract of country, and the like, <span class="ar">بَعُدَ</span>, meaning <em>It extended far.</em>]</span> And<span class="arrow"><span class="ar long">ابعد↓ زَيْدٌ عَنِ المَنْزِلِ</span></span>, meaning<span class="arrow"><span class="ar">تباعد↓</span></span> <span class="add">[i. e. <em>Zeyd went,</em> or <em>removed, to a distance,</em> or <em>far, from the place of alighting</em> or <em>abode</em>]</span>. <span class="auth">(IḲt, Mṣb.)</span> And<span class="arrow"><span class="ar long">تباعد↓ مِنِّى</span></span>, and<span class="arrow"><span class="ar">ابتعد↓</span></span>, and<span class="arrow"><span class="ar">تبعّد↓</span></span>, <span class="add">[<em>He went,</em> or <em>removed, to a distance,</em> or <em>far, from me; he alienated,</em> or <em>estranged, himself from me; he shunned,</em> or <em>avoided, me;</em>]</span> <span class="auth">(A;)</span> and<span class="arrow"><span class="ar long">تباعد↓ عَنِّى</span></span> <span class="add">[and <span class="ar long">بَعُدَ عنّى</span> signify the same]</span>. <span class="auth">(Mṣb in art. <span class="ar">كشح</span>.)</span> And<span class="arrow"><span class="ar long">إِذَا أَرَاذَ أَحَدُكُمْ الحَاجَةِ أَبْعَدَ↓</span></span>, <span class="auth">(L, Mṣb,)</span> a trad., <span class="auth">(Mṣb,)</span> meaning <em>When one of you desires to accomplish that which is needful,</em> <span class="auth">(i. e. to ease nature,)</span> <em>he goes far,</em> or <em>to a great distance.</em> <span class="auth">(L.)</span> And<span class="arrow"><span class="ar long">أَبْعَدْتُ↓ فِى المَذْهَبِ</span></span>, meaning<span class="arrow"><span class="ar">تَبَاعَدْتُ↓</span></span>, <span class="auth">(Mṣb,)</span> <em>I went far,</em> or <em>to a great distance, to the place of ease,</em> i. e., to ease nature. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEd_1_A2">
					<p><span class="add">[<span class="ar">بَعُدَ</span> referring to a saying or the like, and an event, means <em>It was far from being probable</em> or <em>correct; it was improbable, extraordinary,</em> or <em>strange:</em> (<a href="#baEiydN">see <span class="ar">بَعِيدٌ</span></a>, <a href="#bEd_10">and see also 10</a>:) often occurring in these senses.]</span> And<span class="arrow"><span class="ar long">ابعد↓ فِى نَوْعِهِ</span></span> <em>It reached the utmost point,</em> or <em>degree, in its kind,</em> or <em>species.</em> <span class="auth">(IAth.)</span> And <span class="ar long">ابعد فِى السَّوْمِ</span> <em>He exceeded the due bounds in offering a thing for sale and demanding a price for it,</em> or <em>in bargaining for a thing.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEd_1_A3">
					<p><span class="ar long">أَخَذَهُ مَا قَرُبَ وَمَا بَعُدَ</span> <em>Recent and old griefs took hold upon him:</em> a saying similar to <span class="ar long">أَخَذَهُ مَا قَدُمَ وَمَا حَدُثَ</span>. <span class="auth">(Mgh in art. <span class="ar">قدم</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEd_1_A4">
					<p><span class="add">[<span class="ar">بَعُدَ</span> is often used, agreeably with a general rule, in the manner of a verb of praise or dispraise; and in this case is commonly contracted into <span class="ar">بُعْدَ</span>, like <span class="ar">حُسْنَ</span>; as in the phrase, in a verse of Imrael-Keys, <span class="ar long">بُعْدَ مَا مُتَأَمَّلى</span> <span class="auth">(in which <span class="ar">ما</span> is redundant)</span> <em>Distant,</em> or <em>far distant, was the object of my contemplation!</em> or <span class="auth">(as explained in the EM p. 52)</span> <em>how distant,</em>, &amp;c.!]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bEd_1_A5">
					<p><span class="ar">بَعِدَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَدُ</span>}</span></add>, inf. n. <span class="ar">بَعَدٌ</span>; <span class="auth">(Ṣ, L, Mṣb, Ḳ;)</span> and <span class="ar">بَعْدَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْعُدُ</span>}</span></add>, inf. n. <span class="ar">بُعْدٌ</span>; <span class="auth">(L, Ḳ;)</span> also signify <em>He,</em> or <em>it, perished:</em> <span class="auth">(Ṣ L, Mṣb:)</span> <em>he died:</em> <span class="auth">(Ḳ:)</span> it is the general opinion of the leading lexicologists that both these verbs are used as signifying “he perished,” and both occur in different readings of v. 98 of ch. xi. of the Ḳur: the former is said to be used in this sense by some of the Arabs; and the latter, by others; but some disallow the latter in this sense; and some say that the <em>former is more</em> chaste than the latter thus used: <span class="auth">(TA:)</span> or both signify <em>he became far distant from his home</em> or <em>native country; became a stranger,</em> or <em>estranged, therefrom:</em> <span class="auth">(L, TA:)</span> or the Arabs say, <span class="ar long">بَعِدَ الرَّجُلُ</span> and <span class="ar">بَعُدَ</span> in the sense of <span class="ar">تباعد</span>, when not reviling; but when reviling, they say, <span class="ar">بَعِدَ</span>, only. <span class="auth">(Yoo, TA.)</span> You say, <span class="ar long">لَا تَبْعَدٌ وَإِنْ بَعُدْتَ عَنَّى</span> <span class="add">[<em>Mayest thou not perish though thou be distant from me!</em>]</span> <span class="auth">(A.)</span> <span class="add">[And as an imprecation against a man, you say, <span class="ar">بَعِدْتَ</span>, meaning <em>Mayest thou perish!</em> <span class="auth">(See the printed edition of the Ḥam, pp. 89 and 90, where <span class="ar long">بَعِدْتَاىَ هلكت</span> is an evident mistake for <span class="ar long">َعِدْتَ أَى هَلَكْتَ</span>.)</span>]</span> And <span class="ar long">بُعْدًا لَهُ</span> <em>May God alienate him,</em> or <em>estrange him, from good,</em> or <em>prosperity!</em> or, <em>curse him!</em> <span class="auth">(A,* Ḳ, TA;)</span> i. e. may he not be pitied with respect to that which has befallen him! like <span class="ar long">سُحْقًا لَهُ</span>: the most approved way being to put <span class="ar">بعد</span> thus in the accus. case as an inf. n.; but the tribe of Temeem say,<span class="arrow"><span class="ar long">بُعْدٌ↓ لَهُ</span></span>, and <span class="ar">سُحْقٌ</span>, like <span class="ar long">غُلَامٌ لَهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEd_1_B1">
					<p><span class="ar">بَعُدَ</span> is made trans. by means of <span class="add">[the preposition]</span> <span class="ar">ب</span>: <a href="#bEd_4">see 4</a>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEd_2">
				<h3 class="entry">2. ⇒ <span class="ar">بعّد</span></h3>
				<div class="sense" id="bEd_2_A1">
					<p><a href="#bEd_4">see 4</a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEd_2_A2">
					<p><span class="add">[You say also, <span class="ar long">بعّدهُ عَنِ السُّوْءِ</span> <em>He declared him,</em> or <em>pronounced him, to be far removed from evil.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEd_3">
				<h3 class="entry">3. ⇒ <span class="ar">باعد</span></h3>
				<div class="sense" id="bEd_3_A1">
					<p><span class="ar">باعدهُ</span> <em>He was,</em> or <em>became,</em> <span class="add">[<em>distant, remote, far off,</em> or <em>aloof, from him;</em> or]</span> <em>in a part, quarter,</em> or <em>tract, different from that in which he</em> <span class="auth">(the other)</span> <em>was.</em> <span class="auth">(TA in art. <span class="ar">جنب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEd_3_A2">
					<p><a href="#bEd_4">See also 4</a>, in seven places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEd_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابعد</span></h3>
				<div class="sense" id="bEd_4_A1">
					<p><span class="ar">ابعد</span>, inf. n. <span class="ar">إِبْعَادٌ</span>: <a href="#bEd_1">see 1</a>, in seven places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEd_4_B1">
					<p><span class="ar">ابعدهُ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">باعدهُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">مُبَاعَدَةٌ</span> and <span class="ar">بِعَادٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">بعّدهُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَبْعِيدٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar long">بَعُدَ↓ بِهِ</span></span>; <span class="auth">(Mṣb;)</span> <em>He made,</em> or <em>caused, him,</em> or <em>it, to be,</em> or <em>become, distant, remote, far off,</em> or <em>aloof;</em> or <em>to go, remove, retire,</em> or <em>withdraw himself, to a distance, far away,</em> or <em>far off; he placed,</em> or <em>put, at a distance,</em> or <em>he put,</em> or <em>sent, away,</em> or <em>far away,</em> or <em>far off,</em> or <em>he removed far away, alienated,</em> or <em>estranged, him,</em> or <em>it.</em> <span class="auth">(Ṣ, Mṣb.)</span> You say,<span class="arrow"><span class="ar long">بَاعِدْ↓ نَفْسَكَ عَنْ زَيْدٍ</span></span> <span class="add">[<em>Remove thyself far from;</em> or <em>avoid thou, Zeyd</em>]</span>: and<span class="arrow"><span class="ar long">بَاعِدْ↓ زَيْدًا عَنْكَ</span></span> <span class="add">[<em>Remove thou Zeyd far from thee</em>]</span>. <span class="auth">(TA, voce <span class="ar">إِيَّا</span>.)</span> And<span class="arrow"><span class="ar long">بَعَّدْتُ↓ بَيْنَهُمَا</span></span>, inf. n. <span class="ar">تَبْعِيدٌ</span>, <span class="add">[<em>I made a wide separation between them two</em>]</span>; as also<span class="arrow"><span class="ar">بَاعَدْتُ↓</span></span>, inf. n. <span class="ar">مُبَاعَدَةٌ</span>. <span class="auth">(Mṣb.)</span> And<span class="arrow"><span class="ar long">بَاعَدَ↓ ٱللّٰهُ مَا بَيْنَهُمَا</span></span> <span class="add">[<em>May God make the space between them two far extending! may He make a wide separation between them two!</em>]</span>; as also<span class="arrow"><span class="ar">بَعَّدَ↓</span></span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">رَبَّنَا بَاعِدْ↓ بَيْنَ أَسْفَارِنَا</span></span>, or<span class="arrow"><span class="ar">بَعِّدْ↓</span></span>, <span class="add">[<em>O our Lord, make to be far-extending the spaces between our journeys!</em> or, <em>put wide distances between our journeys!</em>]</span> accord. to different readings <span class="add">[in the Ḳur xxxiv. 18]</span>: the former of these is the common reading: Yaạḳoob El-Hadramee read<span class="arrow"><span class="ar long">رَبُّنَا بَاعَدَ↓ الخ</span></span> <span class="add">[<em>Our Lord, He hath made to be far extending</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bEd_4_B2">
					<p><span class="ar long">أَبْعَدَهُ ٱللّٰهُ</span> means <em>May God alienate him,</em> or <em>estrange him, from good,</em> or <em>prosperity!</em> or, <em>curse him!</em> <span class="auth">(Ḳ;)</span> i. e., may he not be pitied with respect to that which has befallen him! <span class="auth">(TA.)</span> <span class="add">[You say also, <span class="ar long">أَبْعَدَ ٱللّٰهُ الأَخِرَ</span>: <a href="#OaxirN">see <span class="ar">أَخِرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bEd_4_B3">
					<p><a href="#bEd_10">See also 10</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bEd_4_C1">
					<p><span class="ar long">مَا أَبْعَدَهُ مِنَ الصَّوَابِ</span> <span class="add">[<em>How far is it</em> <span class="auth">(namely the saying)</span> <em>from what is right,</em> or <em>correct!</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبعّد</span></h3>
				<div class="sense" id="bEd_5_A1">
					<p><a href="#bEd_1">see 1</a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEd_6">
				<span class="pb" id="Page_0225"></span>
				<h3 class="entry">6. ⇒ <span class="ar">تباعد</span></h3>
				<div class="sense" id="bEd_6_A1">
					<p><span class="ar">تباعد</span>: <a href="#bEd_1">see 1</a>, in six places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEd_6_A2">
					<p><span class="add">[It also signifies <em>He became alienated,</em> or <em>estranged,</em> from his family or friends.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEd_6_A3">
					<p><span class="add">[And <span class="ar">تباعدوا</span> <em>They became distant,</em> or <em>remote, one from another; they went, removed, retired,</em> or <em>withdrew themselves, to a distance, far away,</em> or <em>far off, one from another; they removed themselves far,</em> or <em>kept aloof, one from another.</em>]</span> You say, <span class="ar long">كَانُوا مُتَقَارِبِينَ فَتَبَاعَدُوا</span> <span class="add">[<em>They were near, one to another, and they became distant,</em> or <em>remote, one from another</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEd_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتعد</span></h3>
				<div class="sense" id="bEd_8_A1">
					<p><a href="#bEd_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEd_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبعد</span></h3>
				<div class="sense" id="bEd_10_A1">
					<p><span class="ar">استبعدهُ</span> <em>He reckoned it,</em> or <em>esteemed it,</em> <span class="auth">(namely, a thing, Ḳ, or a saying, A,)</span> <span class="ar">بَعِيد</span> <span class="add">[i. e. <em>distant,</em> or <em>remote;</em> or if a saying or the like, <em>far from being probable</em> or <em>correct, improbable, extraordinary,</em> or <em>strange</em>]</span>; <span class="auth">(Ṣ, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابعدهُ↓</span></span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEd_10_B1">
					<p><a href="#bEd_1">See also 1</a>, first sentence, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEodu">
				<h3 class="entry"><span class="ar">بَعْدُ</span></h3>
				<div class="sense" id="baEodu_A1">
					<p><span class="ar">بَعْدُ</span> an adv. n. of time, signifying <em>After,</em> or <em>afterwards:</em> and allowable also, accord. to some of the grammarians, as an adv. n. of place, signifying <em>after,</em> or <em>behind:</em> <span class="auth">(TA:)</span> <em>contr. of</em> <span class="ar">قَبْلُ</span>: <span class="auth">(Ṣ, A, Ḳ:)</span> it is a vague adv. n., of which the meaning is not understood without its being prefixed to another noun <span class="add">[expressed or implied]</span>; denoting after-time. <span class="auth">(Mṣb.)</span> When it occurs without any complement, <span class="auth">(Ṣ, Ḳ,)</span> a noun or the like which should be its complement being intended to be understood as to the meaning thereof but not as to the letter, <span class="auth">(Ṣ,* TA,)</span> it is indecl., <span class="auth">(Ṣ, Ḳ,)</span> because it resembles a particle, <span class="auth">(TA,)</span> and has damm for its termination to show that it is indecl., since it cannot have damm by any rule of desinential syntax because it cannot occur as an agent nor as an inchoative or enunciative. <span class="auth">(Ṣ.)</span> Sb, however, mentions <span class="add">[as exceptions to this rule]</span> the phrases <span class="ar long">مِنْ بَعْدٍ</span> <span class="add">[<em>Afterwards</em>]</span> and <span class="ar long">أَفْعَلُ هٰذَا بَعْدًا</span> <span class="add">[<em>I will do this afterwards</em>]</span>, as having been used by the Arabs. <span class="auth">(Ḳ,* TA.)</span> <span class="add">[The latter of these phrases is common in the present day. Another exception to the rule above-mentioned will be found in what follows.]</span> Accord. to the primary rule, it is used as a prefixed n. governing its complement in the gen. case; <span class="auth">(Ṣ;)</span> <span class="add">[i. e., it is used in the manner of a preposition;]</span> and when thus used, it is decl., <span class="auth">(Ḳ,)</span> because it does not in this case <span class="add">[always]</span> resemble a particle. <span class="auth">(TA.)</span> You say, <span class="ar long">جَآءَ زَيْدٌ بَعْدَ عَمْرٍو</span> <em>Zeyd came after ʼAmr.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">رَأَيْتُهُ بَعْدَكَ</span> and <span class="ar long">مِنْ بَعْدِكَ</span> <span class="add">[<em>I saw him after thee</em>]</span>. <span class="auth">(L.)</span> The words of the Ḳur <span class="add">[xxx. 3]</span>, <span class="ar long">ٱللّٰهِ ٱلْأَمْرُ مِنْ قَبْلُ وَمِنْ بَعْدُ</span>, meaning <em>To God</em> belonged <em>the command before</em> that the Greeks were overcome <em>and after</em> that they had been overcome, <span class="add">[thus read when the complements of <span class="ar">قبل</span> and <span class="ar">بعد</span> are intended to be understood as to the meaning thereof but not as to the letter,]</span> are also read <span class="ar long">مِنْ قَبْلِ وَمِنْ بَعْدِ</span>, when each complement is intended to be understood as to the meaning and the letter, and also <span class="ar long">مِنْ قَبْلٍ وَمِنْ بَعْدٍ</span>, meaning To God belongeth the command <em>first and last,</em> <span class="add">[when neither complement is intended to be understood either as to the letter or as to the meaning,]</span> but the first of these readings is the best. <span class="auth">(L.)</span> <span class="add">[You say also, <span class="ar long">بَعْدَ ذٰلِكَ</span> and <span class="ar long">مِنْ بَعْدِ ذٰلِكَ</span> <em>After that:</em> and <span class="ar long">بَعْدَ أَنْ فَعَلْتُ</span> and <span class="ar long">مِنْ بَعْدِ أَنْ فَعَلْتُ</span> and <span class="ar long">بَعْدَ مَا فَعَلْتُ</span> and <span class="ar long">مِنْ بَعْدِ مَا فَعَلْتُ</span> <em>After I did,</em> or <em>after my doing,</em> such a thing:, &amp;c.]</span> Also <span class="ar long">جِئْتُ بَعْدَيْكُمَا</span>, meaning <span class="ar long">بَعْدَ كُمَا</span>, <em>I came after you two.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">هٰذَا مِمَّا لَيْسَ بَعْدَهُ غَايَةٌ فِى الجَوْدَةِ</span>, and <span class="ar long">فِى الرَّدَآءَة</span>, <em>This is of the things after,</em> or <em>beyond, which there is not any extreme degree in respect of goodness,</em> and <em>in respect of badness:</em> and, by way of abridgement, <span class="ar long">لَيْسَ بَعْدَهُ</span> <span class="add">[with nothing following this]</span>: and hence, app., the saying of Moḥammad, <span class="ar long">وَإِنْ كَانَ لَيْسَ بِالَّذِى لَا بَعْدَ لَهُ</span>, meaning <span class="add">[<em>And though</em>]</span> <em>it be not in the utmost degree</em> in respect of goodness: <span class="ar">بعد</span> being thus used as a decl. noun. <span class="auth">(Mgh.)</span> <span class="add">[<span class="ar">بَعْدِى</span> and the like are also frequently used as meaning <span class="ar long">بَعْدَ عَهْدِى</span> and the like; as in the phrase, <span class="ar long">قَدْ تَغَيَّرْتَ بَعْدى</span> <em>Thou hast become altered since I knew thee,</em> or <em>saw thee,</em> or <em>met thee,</em> or <em>was with thee.</em> And similar to this are many phrases in the Ḳur; as, for instance, in ii. 48,]</span> <span class="ar long">ثُمَّ ٱتَّخَذْتُمُ ٱلعِجْلَ مِنْ بَعْدِهِ</span> <em>Then ye took to yourselves the calf</em> as a god, or an object of worship, <em>after him,</em> namely Moses, i. e., <em>after his having gone away.</em> <span class="auth">(Bḍ.)</span> <span class="ar long">أَمَّا بَعْدُ</span> <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> is <span class="add">[an expression denoting transition;]</span> an expression by which an address or a discourse is divided; <span class="auth">(Ṣ;)</span> used without any complement to <span class="ar">بعد</span>, which in this case signifies <a href="#qabolu">the contr. of <span class="ar">قَبْلُ</span></a>: <span class="auth">(TA:)</span> you say, <span class="ar long">أَمَّا بَعْدُ فَقَدْ كَانَ كَذَا</span>, meaning <span class="add">[<em>Now, after these preliminary words,</em> <span class="auth">(Abu-l- ʼAbbás in TA voce <span class="ar">خِطَابٌ</span>,)</span> I proceed to say, that <em>such a thing has happened:</em> or]</span> <em>after my prayer for thee:</em> <span class="auth">(Ḳ:)</span> or <em>after praising God:</em> <span class="auth">(TA:)</span> the first who used this formula was David; <span class="auth">(Ḳ;)</span> or Jacob; <span class="auth">(TA;)</span> or Kaab Ibn-Lu-eí; <span class="auth">(Ḳ;)</span> or Kuss Ibn-Sá'ideh; or Yaarub Ibn-Kahtán. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعْدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEodu_A2">
					<p>You also use the dim. form, saying <span class="arrow"><span class="ar">بُعَيْدَهُ↓</span></span> <span class="add">[<em>A little after him,</em> or <em>it</em>]</span>, when you mean by it to denote a time near to the preceding time. <span class="auth">(Mṣb.)</span> You say also,<span class="arrow"><span class="ar long">رَأَيْتُهُ بُعَيْدَاتِ↓ بَيْنٍ</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَعِيدَاتِهِ↓</span></span>, <span class="auth">(Ḳ, TA, <span class="add">[in the CK <span class="ar">بُعَيْدَاتِه</span>,]</span>)</span> <em>I saw him a little after a separation:</em> <span class="auth">(Ṣ, Ḳ:)</span> or, <em>after intervals of separation:</em> <span class="auth">(Ṣ, L:)</span> or, <em>after a while.</em> <span class="auth">(AʼObeyd, A.)</span> And<span class="arrow"><span class="ar long">إِنَّهَا لَتَضْحَكُ بُعَيْذَاتِ↓ بَيْنٍ</span></span> <em>Verily she laughs after intervals.</em> <span class="auth">(L.)</span> <span class="add">[<a href="index.php?data=02_b/238_byn">See also art. <span class="ar">بين</span></a>.]</span> <span class="arrow"><span class="ar">بُعَيْدَات↓</span></span> is used only as an adv. n. of time. <span class="auth">(Ṣ, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعْدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baEodu_A3">
					<p><span class="ar">بَعْدُ</span> also sometimes means <em>Now; yet; as yet.</em> <span class="auth">(TA.)</span> <span class="add">[It is used in this sense mostly in negative phrases; as, for instance, in <span class="ar long">لَمْ يَمُتْ بَعْدُ</span> <em>He has not died yet.</em> The following is one of the instances of its having this meaning in affirmative phrases: <span class="ar long">سُمِّيَ الحَوْلِىُّ مِنْ أَوْلَادِ البَقَرِ تَبِيعًا لِأَنَّهُ يَنْبَعُ أُمَّهُ بَعْدُ</span> <em>The yearling of the offspring of cows is called</em> <span class="ar">تبيع</span> <em>because he yet follows his mother:</em> occurring in the Mgh, &amp;c., in art. <span class="ar">تبع</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعْدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baEodu_A4">
					<p>It occurs also in the sense of <span class="ar">مَعَ</span>; as in the words of the Ḳur <span class="add">[ii. 174 and v. 95]</span>, <span class="ar long">فَمَنِ ٱعْتَدَى بَعْدَ ذٰلِكَ</span>, i. e., <span class="auth">(as some say, MF,)</span> <span class="ar long">مَعَ ذلك</span> <span class="add">[<em>And whoso transgresseth notwithstanding that;</em> lit., <em>with that</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعْدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baEodu_A5">
					<p>It has been said that it also means <em>Before, in time;</em> thus bearing two contr. significations: that it has this meaning in two instances; in the Ḳur <span class="add">[lxxix. 30]</span>, where it is said, <span class="ar long">وَٱلْأَرْضَ بَعْدَ ذٰلِكَ دَحَاهَا</span> <span class="add">[as though signifying <em>And the earth, before that, He spread it forth</em>]</span>; and <span class="add">[xxi. 105]</span> where it is said, <span class="ar long">وَلَقَدْ كَتَبْنَا فِى ٱلزَّبُورِ مِنْ بَعْدِ ٱلذِّكْرِ</span> <span class="add">[as though meaning <em>And verily we wrote in the Psalms before the Ḳur-án</em>]</span>: <span class="auth">(MF, TA:)</span> but Az says that this is a mistake; that God created the earth not spread forth; then created the heaven; and then spread forth the earth: <span class="auth">(L, TA:)</span> and <span class="ar">الذكر</span> in the latter of these instances means <em>the Book of the Law revealed to Moses:</em> <span class="auth">(Bḍ:)</span> or <span class="ar">الزبور</span> means <em>the revealed Scriptures;</em> <span class="auth">(Bḍ, Jel;)</span> and <span class="ar">الذكر</span>, <em>the Preserved Tablet,</em> <span class="auth">(Bḍ,)</span> <span class="add">[i. e.]</span> <em>the Original of the Scriptures,</em> which is with God. <span class="auth">(Jel.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buEodN">
				<h3 class="entry"><span class="ar">بُعْدٌ</span></h3>
				<div class="sense" id="buEodN_A1">
					<p><span class="add">[<span class="ar">بُعْدٌ</span> as an inf. n. used in the manner of a subst. signifies]</span> <em>Distance,</em> or <em>remoteness;</em> <span class="auth">(Ṣ, A, L, Ḳ;*)</span> and so<span class="arrow"><span class="ar">بَعَدٌ↓</span></span>, <span class="auth">(L, Ḳ,)</span> accord. to most of the leading lexicologists, <span class="auth">(TA, <span class="add">[<a href="#baEoda">see <span class="ar">بَعْدَ</span></a>,]</span>)</span> <span class="add">[and<span class="arrow"><span class="ar">بُعْدَةٌ↓</span></span>, for]</span> you say, <span class="ar long">بَيْنَنَا بُعْدَةٌ</span>, meaning <span class="add">[<em>Between us two is a distance</em>]</span> of land or country, or of relationship. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بُعْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buEodN_A2">
					<p><span class="add">[<em>Remoteness from probability</em> or <em>correctness; improbability,</em> or <em>strangeness:</em> <a href="#baEuda">see <span class="ar">بَعُدَ</span></a>. Hence the phrase, <span class="ar long">هٰذَا مِنَ البُعْدِ بِمَكَانٍ</span> <em>This is improbable,</em> or <em>extraordinary,</em> or <em>strange:</em> often occurring in the TA, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بُعْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buEodN_A3">
					<p>Also <em>i. q.</em><span class="arrow"><span class="ar">بُعْدٌ↓</span></span>: <span class="auth">(L, Ḳ:)</span> this latter <span class="auth">(Ṣ, L, Mṣb, Ḳ)</span> and <span class="ar">بُعْدٌ</span>, <span class="auth">(L, Ḳ,)</span> accord. to most of the leading lexicologists, as, for instance, in the Ḳur xi. 98, <span class="auth">(TA, <span class="add">[<a href="#baEida">see <span class="ar">بَعِدَ</span></a>,]</span>)</span> signifying <em>Perdition;</em> <span class="auth">(Ṣ, L, Mṣb;)</span> or <em>death.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بُعْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="buEodN_A4">
					<p><em>Judgment and prudence;</em> as also<span class="arrow"><span class="ar">بُعْدَةٌ↓</span></span>: so in the phrase, <span class="ar long">إِنَّهُ لَذُو بُعْدٍ</span>, and <span class="ar">بُعْدَةٍ</span>, <em>Verily he is possessed of judgment and prudence:</em> <span class="auth">(Ḳ:)</span> or <em>penetrating,</em> or <em>effective, judgment; depth,</em> or <em>profundity; far-reaching judgment.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#OaboEadu">See also <span class="ar">أَبْعَدُ</span></a>.]</span> <span class="arrow"><span class="ar long">ذُو البُعْدَةِ↓</span></span> also signifies A man <em>who goes to a great length,</em> or <em>far, in hostility.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بُعْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="buEodN_A5">
					<p><em>A cursing; execration; malediction;</em> as also<span class="arrow"><span class="ar">بِعَادٌ↓</span></span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">بُعْدٌ لَهُ</span>, as well as <span class="ar long">بُعْدًا لَهُ</span>: <a href="#bEd_1">see 1</a>, last sentence but one. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baEadN">
				<h3 class="entry"><span class="ar">بَعَدٌ</span></h3>
				<div class="sense" id="baEadN_A1">
					<p><span class="ar">بَعَدٌ</span>: <a href="#buEodN">see <span class="ar">بُعْدٌ</span></a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعَدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baEadN_B1">
					<p><a href="#baEiydN">and <span class="ar">بَعِيدٌ</span></a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buEodN.1">
				<h3 class="entry"><span class="ar">بُعْدٌ</span></h3>
				<div class="sense" id="buEodN.1_A1">
					<p><span class="ar">بُعْدٌ</span>: <a href="#OaboEadu">see <span class="ar">أَبْعَدُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buEodapN">
				<h3 class="entry"><span class="ar">بُعْدَةٌ</span></h3>
				<div class="sense" id="buEodapN_A1">
					<p><span class="ar">بُعْدَةٌ</span>: <a href="#buEodN">see <span class="ar">بُعْدٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buEaAdN">
				<h3 class="entry"><span class="ar">بُعَادٌ</span></h3>
				<div class="sense" id="buEaAdN_A1">
					<p><span class="ar">بُعَادٌ</span>: <a href="#baEiydN">see <span class="ar">بَعِيدٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بُعَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buEaAdN_A2">
					<p><a href="#baAEidN">and see also <span class="ar">بَاعِدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biEaAdN">
				<h3 class="entry"><span class="ar">بِعَادٌ</span></h3>
				<div class="sense" id="biEaAdN_A1">
					<p><span class="ar">بِعَادٌ</span>: <a href="#buEodN">see <span class="ar">بُعْدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEiydN">
				<h3 class="entry"><span class="ar">بَعِيدٌ</span> / <span class="ar">بَعِيدَةٌ</span></h3>
				<div class="sense" id="baEiydN_A1">
					<p><span class="ar">بَعِيدٌ</span> <em>Distant; remote; far; far off;</em> <span class="auth">(Ṣ, L, Ḳ;*)</span> as also<span class="arrow"><span class="ar">بُعَادٌ↓</span></span>, and<span class="arrow"><span class="ar">بَاعِدٌ↓</span></span>: <span class="auth">(L, Ḳ:)</span> pl. <span class="auth">(of the first, Ṣ, L)</span> <span class="ar">بُعْدَانٌ</span> <span class="auth">(Ṣ, L, Ḳ)</span> and <span class="auth">(of the first also, L, TA)</span> <span class="ar">بُعُدٌ</span> <span class="auth">(L, Ḳ)</span> and <span class="ar">بِعَادٌ</span> <span class="auth">(TA)</span> and <span class="auth">(of the first and second, L)</span> <span class="ar">بُعَدَآءُ</span> <span class="auth">(L, Ḳ)</span> and of the third, <span class="arrow"><span class="ar">بَعَدٌ↓</span></span>, <span class="add">[but this <span class="auth">(which is also used as a sing. epithet, as will be shown in what follows,)</span> is properly a quasi-pl. n.,]</span> like as <span class="ar">خَدَمٌ</span> is of <span class="ar">خَادِمٌ</span>. <span class="auth">(Ṣ.)</span> As signifying <em>Distant with respect to place,</em> it is correctly used alike as masc. and fem. and sing. and dual and pl.; <span class="auth">(L, and TA in this art. and in art. <span class="ar">قرب</span>, in which latter see the authorities;)</span> but not necessarily; like its contr. <span class="ar">قَرِيبٌ</span>: <span class="auth">(L:)</span> you say, <span class="ar long">هِىَ بَعِيدٌ مِنْكَ</span> <span class="add">[<em>She is distant from thee;</em> or it is]</span> as though you said, <span class="ar long">مَكَانُهَا بَعِيدٌ</span>: <span class="auth">(L:)</span> <span class="pb" id="Page_0226"></span>also <span class="ar long">مَا أَنْتَ مِنَّا بِبَعِيدٍ</span> <span class="add">[<em>Thou art not distant from us </em>]</span>, and <span class="ar long">مَا أَنْتُمْ مِنَّا بِبَعِيدٍ</span> <span class="add">[<em>Ye are not distant from us</em>]</span>: and in like manner,<span class="arrow"><span class="ar long">مَا أَنْتَ مِنَّا بِبَعَدٍ↓</span></span>, and<span class="arrow"><span class="ar long">مَا أَنْتُمُ مِنَّا بِبَعَدٍ↓</span></span>. <span class="auth">(Ṣ, TA.)</span> <span class="add">[But it receives, sometimes, the fem. form when used in this sense; for]</span> <span class="ar long">جَلَسْتُ بَعِيدًا مِنْكَ</span> and <span class="ar long">بَعِيدَةٌ مِنْكَ</span> are phrases mentioned as signifying <em>I sat distant,</em> or <em>remote in place,</em> or <em>at a distance,</em> or <em>aloof, from thee;</em> <span class="ar">مَكَانًا</span> <span class="add">[and <span class="ar">نَاحِيَةً</span> or the like]</span> being understood. <span class="auth">(L.)</span> You say also,<span class="arrow"><span class="ar long">مَنْزِلٌ بَعَدٌ↓</span></span> <em>A distant,</em> or <em>remote, place of alighting</em> or <em>abode.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">تَنَحَّ غَيْرَ بَعِيدٍ</span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar long">غَيْرَ بَاعِدٍ↓</span></span> and<span class="arrow"><span class="ar long">غَيْرَ بَعَدٍ↓</span></span> <span class="auth">(Ḳ)</span> <span class="add">[<em>Retire thou not far;</em>]</span> meaning <em>be thou near:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[or]</span> the second and third of these phrases mean <em>retire thou not in an abject,</em> or <em>a mean,</em> or <em>contemptible,</em> or <em>despicable, state.</em> <span class="auth">(Ṣ, A.)</span> And<span class="arrow"><span class="ar long">اِنْطَلِقْ يَا فُلَانُ غَيْرَ بَاعِدٍ↓</span></span> <span class="add">[<em>Depart thou, O such a one, not far;</em>]</span> meaning <em>mayest thou not go away!</em> <span class="auth">(L.)</span> <span class="add">[And <span class="ar long">رَأَيْتُهُ مِنْ بَعِيدٍ</span> <em>I saw him,</em> or <em>it, from afar:</em> and <span class="ar long">جَآءَ مِنْ بَعِيدٍ</span> <em>He came from afar:</em> and the like. And <span class="ar">بَعِيدٌ</span> as applied to a desert and the like, meaning <em>Far extending.</em>]</span> And<span class="arrow"><span class="ar long">بُعْدٌ بَاعِدٌ↓</span></span> <em>A far distance.</em> <span class="auth">(Ḳ.)</span> <span class="add">[And <span class="ar long">نِيَّةٌ بَعِيدَةٌ</span> <em>A distant, far-reaching,</em> or <em>far-aiming, intention, purpose,</em> or <em>design.</em>]</span> And <span class="ar long">فُلَانٌ بَعِيدُ الهِمَّةِ</span> <span class="add">[<em>Such a one is far-aiming,</em> or <em>faraspiring, in purpose, desire,</em> or <em>ambition</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">هِىَ بَعِيدَةُ العَهْدِ</span> <span class="add">[<em>She was known,</em> or <em>seen,</em> or <em>met, a long time ago</em>]</span>: in this case, the fem. form, with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَعِيدَةٌ</span>}</span></add>, must be used. <span class="auth">(L.)</span> And <span class="ar long">قَوْلٌ بَعِيدٌ</span> <span class="add">[<em>A saying far from being probable</em> or <em>correct; improbable; far-fetched; extraordinary,</em> or <em>strange</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">أَمْرٌ بَعِيدٌ</span> <em>An extraordinary thing</em> or <em>affair</em> or <em>case, of which the like does not happen</em> or <em>occur.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEiydN_A2">
					<p>Also <em>Distant with respect to kindred</em> or <em>relationship:</em> in which sense, the word receives the fem. form, <span class="add">[as well as the dual form, and pl. forms, like its contr. <span class="ar">قَرِيبٌ</span>,]</span> by universal consent. <span class="auth">(TA.)</span> <span class="add">[Its pl.]</span> <span class="ar">بُعَدَآءُ</span> signifies <em>Strangers, that are not relations.</em> <span class="auth">(IAth.)</span> You say also, <span class="ar long">فُلَانٌ مِنْ بُعْدَانِ الأَمِيرِ</span> <span class="add">[meaning <em>Such a one is of the distant dependents,</em> or <em>subjects, of the governor,</em> or <em>prince</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">إِذَا لَمْ تَكُنْ مِنْ قُرْبَانِ الأَمِيرِ فَكُنْ مِنْ بُعْدَانِهِ</span> <span class="add">[<em>If thou be not of the particular companions,</em> or <em>familiars, of the governor,</em> or <em>prince, then be of his distant dependents,</em> or <em>subjects</em>]</span>; i. e., be distant from him, that his evil may not affect thee. <span class="auth">(AZ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baEiydN_A3">
					<p><span class="ar long">رَأَيْتُهُ بَعِيدَاتِ بَيْنٍ</span>: <a href="#baEodN">see <span class="ar">بَعْدٌ</span></a> in the latter half of the paragraph.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَعِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baEiydN_A4">
					<p><a href="#baAEidN">See also <span class="ar">بَاعِدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buEayod">
				<h3 class="entry"><span class="ar">بُعَيْد</span> / <span class="ar">بُعَيْدَات</span></h3>
				<div class="sense" id="buEayod_A1">
					<p><span class="ar">بُعَيْد</span> and <span class="ar">بُعَيْدَات</span>: <a href="#baEodu">see <span class="ar">بَعْدُ</span></a> in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAEidu">
				<h3 class="entry"><span class="ar">بَاعِدُ</span></h3>
				<div class="sense" id="baAEidu_A1">
					<p><span class="ar">بَاعِدُ</span>: <a href="#baEiydN">see <span class="ar">بَعِيدٌ</span></a> in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">بَاعِدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAEidu_A2">
					<p>Also <em>Perishing:</em> <span class="auth">(Ṣ, L: <span class="add">[in the Ḳ it is implied that it signifies <em>dying;</em> and so<span class="arrow"><span class="ar">بَعِيدٌ↓</span></span> and<span class="arrow"><span class="ar">بُعَادٌ↓</span></span>:]</span>)</span> or <em>far distant from his home,</em> or <em>native country; in a state of estrangement therefrom.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboEadu">
				<h3 class="entry"><span class="ar">أَبْعَدُ</span></h3>
				<div class="sense" id="OaboEadu_A1">
					<p><span class="ar">أَبْعَدُ</span> <em>More,</em> and <em>most, distant</em> or <em>remote; further,</em> and <em>furthest:</em> by poetic licence written <span class="ar">أَبْعَدُّ</span>: <span class="auth">(L:)</span> <span class="add">[pl. <span class="ar">أَبَاعِدُ</span>; as in the saying,]</span> <span class="ar long">فُلَانٌ يَسْتَجِرُّ الحَدِيثَ مِنْ أَبَاعِدِ أَطْرَافِهِ</span> <span class="add">[<em>Such a one draws forth talk,</em> or <em>discourse,</em> or <em>news,</em> or <em>the like, from its most remote sources</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">أَبْعَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboEadu_A2">
					<p><em>More,</em> and <em>most, extreme, excessive, egregious,</em> or <em>extraordinary,</em> in its kind. <span class="auth">(IAth.)</span> <span class="add">[Hence, perhaps,]</span> <span class="ar long">إِنَّهُ لَغَيْرُ أَبْعَدَ</span> <span class="add">[in the CK <span class="ar">أَبْعَدٍ</span>]</span> and<span class="arrow"><span class="ar">بُعَدٍ↓</span></span> <em>Verily there is no good in him:</em> <span class="auth">(Ḳ:)</span> or, <em>no depth in him in anything:</em> <span class="auth">(IAạr:)</span> <span class="add">[or, <em>he is not extraordinary</em> in his kind: <a href="#buEodN">see also <span class="ar">بُعْدٌ</span></a>:]</span> said in dispraising one. <span class="auth">(TA.)</span> And <span class="ar long">مَا عِنْدَهُ أَبْعَدُ</span> and<span class="arrow"><span class="ar">بُعَدٌ↓</span></span> <span class="add">[<em>He has not what is extraordinary</em> in its kind: or]</span> <em>he possesses not excellence,</em> or <em>power,</em> or <em>riches:</em> or <em>he possesses not anything profitable:</em> <span class="auth">(L, Ḳ:)</span> said only in dispraising one: <span class="auth">(AZ:)</span> or it may mean <em>he possesses not anything which one would go far to seek;</em> or, <em>anything of value:</em> or <em>what he possesses, of things or qualities that are desirable, is more extraordinary than what others possess.</em> <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">أَبْعَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaboEadu_A3">
					<p><em>Remote from good:</em> <span class="add">[which is the meaning generally intended in the present day when it is used absolutely as an epithet applied to a man; but meaning also <em>remote</em> from him or those in whose presence this epithet is used, both <em>as to place and as to moral condition:</em>]</span> and, <em>from continence:</em> <span class="auth">(L:)</span> and <em>stupid; foolish;</em> or <em>having little,</em> or <em>no, intellect</em> or <em>understanding;</em> syn. <span class="ar">حَائِنٌ</span>: <span class="auth">(so in a copy of the Ṣ and in the L and TA:)</span> or <em>treacherous,</em> or <em>unfaithful;</em> syn. <span class="ar">خَائِنٌ</span> <span class="auth">(So in two copies of the Ṣ and in a copy of the A.)</span> It is used as an allusion to the name of a person whom one would mention with dispraise; as when one says, <span class="ar long">هَلَكَ الأَبْعَدُ</span> <span class="add">[<em>May such a one, the remote from good,</em>, &amp;c., <em>perish!</em>]</span>: with respect to a woman, one says, <span class="ar long">هَلَكَتِ البُعْدَى</span>. <span class="auth">(En-Naḍr, Az.)</span> One says also, <span class="ar long">كَبَّ ٱللّٰهُ الأَبْعَدَ لِفِيهِ</span>, meaning <span class="add">[<em>May God cast down prostrate such a one, the remote from good,</em>, &amp;c., <em>upon his mouth!</em> or,]</span> <em>cast him down upon his face!</em> <span class="auth">(Ṣ.)</span> <span class="add">[It is a rule observed in decent society, by the Arabs, to avoid, as much as possible, the mention of opprobrious epithets, lest any person present should imagine an epithet of this kind to be slily applied to himself: therefore, when any malediction or vituperation is uttered, it is usual to allude to the object by the term <span class="ar">الأَبْعَد</span>, or <span class="ar">البَعِيد</span>, as meaning the remote from good, &amp;c., and also the remote from the person or persons present. <a href="#AlOaxiru">See also <span class="ar">الأَخِرُ</span></a>, which is used in a similar manner.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعد</span> - Entry: <span class="ar">أَبْعَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaboEadu_A4">
					<p><em>A more distant,</em> or <em>most distant,</em> or <em>very distant, relation;</em> <span class="auth">(Lth;)</span> <em>contr. of</em> <span class="ar">أَقْرَبُ</span>: <span class="auth">(Mṣb:)</span> pl. <span class="ar">أَبَاعِدُ</span> <span class="auth">(Lth, Ṣ, A, Mṣb, Ḳ)</span> and <span class="ar">أَبْعَدُونَ</span>; <span class="auth">(Lth;)</span> <em>contr. of</em> <span class="ar">أَقَارِبُ</span> <span class="auth">(Lth, Ṣ, Ḳ)</span> and <span class="ar">أَقْرَبُونَ</span>. <span class="auth">(Lth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboEadN">
				<h3 class="entry"><span class="ar">مِبْعَدٌ</span></h3>
				<div class="sense" id="miboEadN_A1">
					<p><span class="ar">مِبْعَدٌ</span> A man <em>who makes far journeys.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0224.pdf" target="pdf">
							<span>Lanes Lexicon Page 224</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0225.pdf" target="pdf">
							<span>Lanes Lexicon Page 225</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0226.pdf" target="pdf">
							<span>Lanes Lexicon Page 226</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
