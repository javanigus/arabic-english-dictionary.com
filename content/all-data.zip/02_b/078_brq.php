<article class="root" id="Root_brq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/077_brgv">برغث</a></span>
				<span class="ar">برق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/079_brqX">برقش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brq_1">
				<h3 class="entry">1. ⇒ <span class="ar">برق</span></h3>
				<div class="sense" id="brq_1_A1">
					<p><span class="ar">بَرَقَ</span>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُقُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh,)</span> inf. n. <span class="ar">بُرُوقٌ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَرِيقٌ</span>, <span class="auth">(Mgh, Ḳ,)</span> or this is a simple subst., <span class="auth">(Ṣ,)</span> and <span class="ar">بَرْقٌ</span> and <span class="ar">بَرَقَانٌ</span> <span class="auth">(Ḳ, TA, but in the CK <span class="ar">بُرُوقٌ</span>, as in the Ṣ,)</span> <span class="pb" id="Page_0190"></span><em>It</em> <span class="auth">(a thing, Mgh, Ḳ, a sword, &amp;c., Ṣ and the dawn, Ḳ, TA)</span> <em>shone, gleamed,</em> or <em>glistened.</em> <span class="auth">(Ṣ, Mgh, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brq_1_A2">
					<p>Also said of a cloud, aor. as above, inf. n. <span class="ar">بَرِيقٌ</span> and <span class="ar">بَرْقً</span> and <span class="ar">بَرَقَانٌ</span>, <em>It gleamed</em> or <em>shone</em> <span class="add">[<em>with lightning</em>]</span>; and so<span class="arrow"><span class="ar">ابرق↓</span></span>, <span class="auth">(JK,)</span> and<span class="arrow"><span class="ar">تبرّق↓</span></span>. <span class="auth">(Ḳ in art. <span class="ar">حلج</span>.)</span> And <span class="ar long">بَرَقَتِ السَّمَآءُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. as above, <span class="auth">(Mṣb, TA,)</span> inf. n. <span class="ar">بَرَقَانٌ</span> <span class="auth">(Aṣ, Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بَرْقٌ</span> <span class="auth">(Mṣb, TA)</span> and <span class="ar">بُرُوقٌ</span>, <span class="auth">(Ḳ,)</span> <em>The sky lightened;</em> <span class="auth">(Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابرقت↓</span></span>: <span class="auth">(AO, AA, Ḳ:)</span> or <em>gleamed</em> or <em>shone</em> <span class="add">[<em>with lightning</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>lightened much</em> before rain; as also<span class="arrow"><span class="ar">ابرقت↓</span></span>. <span class="auth">(TA in art. <span class="ar">رعد</span>.)</span> And <span class="ar long">بَرَقَ البَرْقُ</span> <em>The lightning appeared.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brq_1_A3">
					<p>And <span class="add">[hence]</span> said of a man, <span class="auth">(JK, Mṣb, Ḳ,)</span> or <span class="ar long">رَعَدَ وَبَرَقَ</span>, <span class="auth">(Ṣ,)</span> ‡ <em>He threatened;</em> <span class="auth">(JK, Ṣ, Ḳ;)</span> or <em>he threatened with evil;</em> <span class="auth">(Mṣb;)</span> <span class="add">[or <em>he threatened and menaced;</em>]</span> or <em>he frightened</em> <span class="auth">(Ṣ and Ḳ in art. <span class="ar">رعد</span>)</span> <em>and threatened;</em> <span class="auth">(Ṣ in that art.;)</span> and<span class="arrow"><span class="ar">ابرق↓</span></span> signifies the same; <span class="auth">(JK, Mṣb, Ḳ;)</span> and so <span class="ar long">أَرْعَدَ وَأَبْرَقَ</span>: <span class="auth">(Ḳ:)</span> or, accord. to Aṣ, <span class="ar">ارعد</span> and <span class="ar">ابرق</span> are not allowable. <span class="auth">(TA, and Ṣ in art. <span class="ar">رعد</span>, q. v.)</span> But <span class="ar">بَرَقَتْ</span>, inf. n. <span class="ar">بَرْقٌ</span>, said of a woman, <span class="auth">(Ḳ,)</span> or <span class="ar long">رَعَدَتْ وَبَرَقَتْ</span>, <span class="auth">(Ṣ,)</span> means ‡ <em>She beautified</em> <span class="auth">(Ṣ and A in art. <span class="ar">رعد</span>, and Ḳ)</span> <em>and adorned herself,</em> <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[as also<span class="arrow"><span class="ar">تبرّقت↓</span></span>, <span class="auth">(occurring in the Ḳ in art. <span class="ar">الق</span>, coupled with its syn. <span class="ar">تَزَيَّنَت</span>,)</span>]</span> <em>and showed,</em> or <em>presented, herself,</em> <span class="auth">(A in art. <span class="ar">رعد</span>, and TA,)</span> <span class="ar">لِى</span> <em>to me:</em> <span class="auth">(A in art. <span class="ar">رعد</span>:)</span> or <em>she exhibited her beauty intentionally:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">برّقت↓</span></span> means the same, <span class="auth">(Lḥ, Ḳ,)</span> inf. n. <span class="ar">تَبْرِيقٌ</span>; <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">ابرقت↓</span></span>: <span class="auth">(Ḳ:)</span> you say,<span class="arrow"><span class="ar long">ابرقت↓ بِوَجْهِهَا وَسَائِرِ جِسْمِهَا</span></span> ‡ <em>She beautified herself in her face and the rest of her person:</em> <span class="auth">(Lḥ, TA:)</span> and<span class="arrow"><span class="ar long">ابرقت↓ عَنْ وَجْهِهَا</span></span> ‡ <em>She showed her face.</em> <span class="auth">(JK, Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brq_1_A4">
					<p>Also, said of a star, or an asterism, <em>It rose.</em> <span class="auth">(Lḥ, Ḳ.)</span> One says, <span class="ar long">لَا أَفْعَلُهُ مَا بَرَقَ النَّجْمُ فِى السَّمَآءِ</span> <em>I will not do it as long as the star,</em> or <em>asterism,</em> <span class="add">[by which may be meant <em>the asterism of the Pleiades,</em>]</span> <em>rises in the sky.</em> <span class="auth">(Lḥ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="brq_1_A5">
					<p><span class="ar long">بَرَقَ البَصَرُ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَصَرُهُ</span>, <span class="auth">(Ḳ,)</span> <em>The eye</em> or <em>eyes,</em> or <em>his eye</em> or <em>eyes, glistened,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>being raised,</em> or <em>fixedly open:</em> <span class="auth">(Ṣ:)</span> or <em>became raised,</em> or <em>fixedly open:</em> occurring in the Ḳur <span class="add">[lxxv. 7]</span>, accord. to one reading: <span class="auth">(Fr, TA:)</span> or <em>the eye,</em> or <em>his eye, became open by reason of fright.</em> <span class="auth">(TA.)</span> <span class="ar">بَرِقَ</span> has a different meaning, which see below. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="brq_1_A6">
					<p><span class="ar">بَرَقَتْ</span>, said of a she-camel, <em>She put her tail between her thighs, making it to cleave to her belly, without being pregnant:</em> <span class="auth">(IAạr, TA:)</span> or <em>she raised her tail, and feigned herself pregnant, not being so;</em> as also<span class="arrow"><span class="ar">ابرقت↓</span></span>, <span class="auth">(Lḥ, Ṣ, Ḳ,)</span> and <span class="ar long">ابرقت بِذَنبِهَا</span>: <span class="auth">(TA:)</span> or <span class="ar">ابرقت</span> signifies <em>she smote with her tail at one time upon her vulva and another time upon her buttocks;</em> and also, <em>she feigned herself pregnant, not being so.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="brq_1_A7">
					<p><span class="ar">بَرِقَ</span> <em>He feared, so that he was astonished</em> or <em>amazed</em> or <em>stupified, at seeing the gleam of lightning:</em> <span class="auth">(TA voce <span class="ar">بَحِرَ</span>:)</span> or <em>his</em> <span class="auth">(a man's)</span> <em>sight became confused in consequence of his looking at lightning.</em> <span class="auth">(Bḍ in lxxv. 7.)</span> And hence, <span class="auth">(Bḍ ibid.,)</span> <span class="ar long">بَرِقَ البَصَرُ</span>, <span class="auth">(Ṣ, Bḍ,)</span> or <span class="ar">بَصَرُهُ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَقُ</span>}</span></add>; <span class="auth">(Ṣ, Ḳ;)</span> and <span class="ar">بَرَقَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُقُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> or the latter has <span class="add">[only]</span> a meaning explained above; <span class="auth">(Ṣ;)</span> inf. n. <span class="ar">بَرَقٌ</span>, which is of the former verb; <span class="auth">(Ṣ;)</span> accord. to the Ḳ, <span class="ar">بَرْقٌ</span>; but this is wrong; <span class="auth">(TA;)</span> and <span class="add">[of the latter verb,]</span> <span class="ar">بُرُوقٌ</span>; <span class="auth">(Lḥ, Ḳ;)</span> <em>The eye</em> or <em>eyes,</em> or <em>his eye</em> or <em>eyes, became dazzled, so as not to close,</em> or <em>move, the lid,</em> or <em>lids:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>became confused, so as not to see.</em> <span class="auth">(Ḳ.)</span> <span class="ar long">بَرِقَ بَصَرُهُ</span> signifies also <em>His eye</em> or <em>eyes,</em> or <em>his sight, became weak:</em> whence <span class="ar long">بَرِقَتْ قَدَمَاهُ</span> <em>His two feet became weak.</em> <span class="auth">(TA.)</span> Also <span class="ar">بَرِقَ</span> alone, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَرَقٌ</span>, <span class="auth">(Fr, Ḳ, TA,)</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>was frightened;</em> or <em>he feared,</em> or <em>was afraid:</em> <span class="auth">(Fr, Ḳ, TA:)</span> and <em>he became confounded,</em> or <em>perplexed, and unable to see his right course.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="brq_1_A8">
					<p><span class="ar">بَرِقَ</span> said of a skin, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَقُ</span>}</span></add>, <span class="auth">(JK, Ḳ,)</span> inf. n. <span class="ar">بَرَقٌ</span>, <span class="auth">(JK,)</span> so in the O, in which, as in the Ḳ, the part. n., being <span class="ar">بَرِقٌ</span>, indicates that the verb is like <span class="ar">فَرِحَ</span>; <span class="auth">(TA;)</span> and <span class="ar">بَرَقَ</span>, <span class="auth">(Ḳ,)</span> so in the L, <span class="auth">(TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُقُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَرْقٌ</span> and <span class="ar">بُرُوقٌ</span>; thus in the L, which indicates that the verb is like <span class="ar">نَصَرَ</span>; <span class="auth">(TA;)</span> <em>It became affected by the heat so that its butter melted and became decomposed,</em> <span class="auth">(Aṣ, JK, Ḳ,)</span> <em>and did not become compact.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brq_1_B1">
					<p><span class="ar long">بَرَقَ طَعَامًا</span>, <span class="auth">(JK,)</span> or <span class="ar long">بَرَقَهُ بِزَيْتٍ أَوْ سَمْنٍ</span> <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُقُ</span>}</span></add>, <span class="auth">(JK,)</span> inf. n. <span class="ar">بَرْقٌ</span> <span class="auth">(JK, Ṣ)</span> and <span class="ar">بُرُوقٌ</span>, <span class="auth">(L,)</span> <em>He poured upon the food,</em> <span class="auth">(JK,)</span> or <em>put into it,</em> <span class="auth">(Ṣ,* Ḳ,)</span> <em>somewhat,</em> <span class="auth">(JK,)</span> or <em>a small quantity,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>of olive-oil</em> <span class="auth">(JK, Ṣ, Ḳ)</span> or <em>of clarified butter.</em> <span class="auth">(Ṣ, Ḳ.)</span> And <span class="ar long">بَرَقْتُ لَهُ</span> <em>I made his food</em> <span class="add">[<em>somewhat</em>]</span> <em>greasy for him with clarified butter.</em> <span class="auth">(TA.)</span> And <span class="ar long">أُبْرُقُوا المَآءِ بِزَيْتٍ</span> <em>Pour ye upon the water a little olive-oil.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brq_1_C1">
					<p><span class="ar long">بَرِقَتِ الغَنَمُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَقُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَرَقٌ</span>, <span class="auth">(Ṣ,)</span> <em>The sheep,</em> or <em>goats, had a complaint in their bellies from eating the</em> <span class="ar">بَرْوَق</span>: <span class="auth">(Ṣ, Ḳ:)</span> and in like manner, <span class="ar">الإِبِلُ</span> <em>the camels.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brq_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّق</span></h3>
				<div class="sense" id="brq_2_A1">
					<p><span class="ar long">برّق بِعَيْنَيْهِ</span>, <span class="auth">(JK,)</span> or <span class="ar long">برّق بَصَرَهُ</span>, <span class="auth">(TA,)</span> <em>He glistened with his eyes by reason of looking hard,</em> or <em>intently.</em> <span class="auth">(JK, TA.*)</span> And <span class="ar long">برّق عَيْنَيْهِ</span>, inf. n. <span class="ar">تَبْرِيقٌ</span>, <em>He opened his eyes wide, and looked sharply,</em> or <em>intently.</em> <span class="auth">(Lth, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brq_2_A2">
					<p><span class="ar">برّقت</span>, said of a woman: <a href="#brq_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brq_2_A3">
					<p>And <span class="ar">برّق</span> <em>He decorated,</em> or <em>adorned,</em> his place of abode. <span class="auth">(El-Muärrij, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brq_2_A4">
					<p><span class="ar long">بَرَّقْتَ وَعَرَّقْتَ</span> <em>Thou madest a sign with a thing, that had nothing to verify it,</em> <span class="add">[app. meaning <em>thou madest a false display,</em> or <em>a vain promise,</em>]</span> <em>and didst little</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="brq_2_A5">
					<p>Also <span class="ar">برّق</span>, <span class="auth">(inf. n. as above, TA,)</span> <em>He</em> <span class="auth">(a man)</span> <em>journeyed far.</em> <span class="auth">(El-Muärrij Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="brq_2_A6">
					<p><span class="ar long">برّق فِى المَعَاصِى</span> <em>He persisted,</em> or <em>persevered, in acts of disobedience.</em> <span class="auth">(El-Muärrij, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="brq_2_A7">
					<p><span class="ar long">برّق بِىَ الأَمْرُ</span> <em>The affair was unattainable,</em> or <em>impracticable, to me.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brq_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرق</span></h3>
				<div class="sense" id="brq_4_A1">
					<p><a href="#brq_1">see 1</a>, in eight places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brq_4_A2">
					<p><span class="ar">ابرق</span>, <span class="auth">(Aboo-Naṣr, Ṣ, Ḳ,)</span> or <span class="ar long">ابرق بِسَيْفِهِ</span>, <span class="auth">(JK,)</span> said of a man, <span class="auth">(Aboo-Naṣr, JK, Ṣ,)</span> <em>He made a sign with his sword</em> <span class="add">[<em>by waving it about so as to make it glisten</em>]</span>. <span class="auth">(Aboo-Naṣr, JK, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brq_4_A3">
					<p>And <span class="ar">ابرق</span> <em>He betook himself,</em> or <em>directed his course, towards the lightning.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brq_4_A4">
					<p><em>He entered into</em> <span class="add">[<em>a tract wherein was</em>]</span> <em>lightning.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="brq_4_A5">
					<p><em>He saw lightning.</em> <span class="auth">(TA.)</span> Tufeyl uses the phrase <span class="ar long">أَبْرَقْنَ الخَرِيفَ</span> as meaning <em>They</em> <span class="auth">(women borne in vehicles upon camels)</span> <em>saw the lightning of</em> <span class="add">[<em>the season,</em> or <em>the rain, called</em>]</span> <em>the</em> <span class="ar">خريف</span>. <span class="auth">(AAF, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="brq_4_A6">
					<p><em>He was smitten,</em> or <em>assailed,</em> or <em>affected, by lightning.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brq_4_B1">
					<p><span class="ar long">ابرقهُ الفَزَعُ</span> <span class="add">[app. <em>Fright,</em> or <em>fear, made him to be confounded,</em> or <em>perplexed, and unable to see his right way:</em> <a href="#bariqa">see <span class="ar">بَرِقَ</span></a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brq_4_B2">
					<p><span class="add">[And hence, perhaps,]</span> <span class="ar long">ابرق الصَّيْدَ</span> <em>He roused the game,</em> or <em>chase.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّق</span></h3>
				<div class="sense" id="brq_5_A1">
					<p><a href="#brq_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brq_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبرق</span></h3>
				<div class="sense" id="brq_10_A1">
					<p><span class="ar">استبرق</span> <em>It</em> <span class="auth">(a place, and the horizon,)</span> <em>shone,</em> or <em>gleamed, with lightning.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroqN">
				<h3 class="entry"><span class="ar">بَرْقٌ</span></h3>
				<div class="sense" id="baroqN_A1">
					<p><span class="ar">بَرْقٌ</span> <span class="add">[<em>Lightning;</em>]</span> <em>what gleams in the clouds,</em> <span class="auth">(TA,)</span> or, <em>from the clouds;</em> from <span class="ar">بَرَقَ</span> <span class="add">[in the first of the senses explained above]</span>, said of a thing, inf. n. <span class="add">[<span class="ar">بَرْقٌ</span> and]</span> <span class="ar">بَرِيقٌ</span>: <span class="auth">(Bḍ in ii. 18:)</span> or <em>an angel's smiting the clouds, and putting them in motion, in order that they may become propelled, so that thou seest the fires</em> <span class="add">[<em>issue from them</em>]</span>: <span class="auth">(Mujáhid, Ḳ:)</span> or <em>a whip of light with which the angel drives the clouds:</em> <span class="auth">(I’Ab, TA:)</span> <a href="#buruwqN">sing. of <span class="ar">بُرُوقٌ</span></a>, i. e., of the <span class="ar">بروق</span> of the clouds: <span class="auth">(Ṣ, Ḳ:)</span> or it has no pl., being originally an inf. n. <span class="auth">(Bḍ ubi suprà.)</span> <span class="ar long">بَرْقُ الخُلَّبِ</span> and <span class="ar long">بَرْقُ خُلَّبٍ</span> and <span class="ar long">بَرْقٌ خُلَّبٌ</span> signify <em>That</em> <span class="add">[<em>lightning</em>]</span> <em>which is without rain.</em> <span class="auth">(Ṣ. <span class="add">[<a href="index.php?data=07_x/123_xlb">See also art. <span class="ar">خلب</span></a>]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroqN">
				<h3 class="entry"><span class="ar">بُرْقٌ</span></h3>
				<div class="sense" id="buroqN_A1">
					<p><span class="ar">بُرْقٌ</span> <span class="add">[<em>Lizards of the species called</em>]</span> <span class="ar">ضِبَاب</span>, <a href="#DabBN">pl. of <span class="ar">ضَبٌّ</span></a>. <span class="auth">(IAạr, Ḳ.)</span> It is app. <a href="#baruwqN">pl. of <span class="ar">بَرُوقٌ</span></a> <a href="#Oaboraqu">or of <span class="ar">أَبْرَقُ</span></a>: <span class="add">[more probably, I think, of the former; from the raising of the tail, which is a habit of those lizards.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بُرْقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buroqN_B1">
					<p><a href="#buroqapN">See also <span class="ar">بُرْقَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraqN">
				<h3 class="entry"><span class="ar">بَرَقٌ</span></h3>
				<div class="sense" id="baraqN_A1">
					<p><span class="ar">بَرَقٌ</span> <em>A lamb;</em> syn. <span class="ar">حَمَلٌ</span> <span class="add">[q. v.]</span>: <span class="auth">(Ṣ, Ḳ:)</span> a Persian word, <span class="auth">(Ṣ,)</span> arabicized; <span class="auth">(Ṣ, Ḳ;)</span> originally <span class="ar">بَرَهْ</span>: <span class="auth">(Ḳ:)</span> pl. <span class="add">[of mult.]</span> <span class="ar">بُرْقَانٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بِرْقَانٌ</span> and <span class="add">[of pauc.]</span> <span class="ar">أَبْرَاقٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariqN">
				<h3 class="entry"><span class="ar">بَرِقٌ</span></h3>
				<div class="sense" id="bariqN_A1">
					<p><span class="ar">بَرِقٌ</span> <span class="add">[part. n. of <span class="ar">بَرِقَ</span>: and particularly explained as meaning]</span> A skin <em>affected by the heat so that its butter melts and becomes decomposed,</em> <span class="auth">(JK, O, Ḳ,)</span> <em>and does not become compact.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroqapN">
				<h3 class="entry"><span class="ar">بَرْقَةٌ</span></h3>
				<div class="sense" id="baroqapN_A1">
					<p><span class="ar">بَرْقَةٌ</span> <span class="add">[app. an inf. n. of un., signifying <em>A flash of lightning</em>]</span>. <span class="auth">(M, TA in art. <span class="ar">وبص</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَرْقَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baroqapN_B1">
					<p><em>A fit of confusion,</em> or <em>perplexity, affecting one in such a manner that he is unable to see his right course.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroqapN">
				<h3 class="entry"><span class="ar">بُرْقَةٌ</span></h3>
				<div class="sense" id="buroqapN_A1">
					<p><span class="ar">بُرْقَةٌ</span> <em>A quantity of lightning:</em> <span class="auth">(Bḍ in xxiv. 43, TA:)</span> pl. <span class="arrow"><span class="ar">بُرْقٌ↓</span></span>; <span class="auth">(TA;)</span> or <span class="add">[this is a coll. gen. n., of which the former is the n. un.; or, probably, it is a mistranscription, and]</span> the pl. is <span class="ar">بُرَقٌ</span>, also pronounced <span class="ar">بُرُقٌ</span>. <span class="auth">(Bḍ ubi suprà.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بُرْقَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buroqapN_B1">
					<p><em>Rugged ground in which are stones and sand and earth mixed together,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>the stones thereof mostly white, but some being red, and black, and the earth white and of a whitish dust-colour, and sometimes by its side are meadows</em> (<span class="ar">رَوْض</span>); <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">أَبْرَقُ↓</span></span> and<span class="arrow"><span class="ar">بَرْقَآءُ↓</span></span>: <span class="auth">(Ṣ, Ḳ, TA:)</span> or <em>a portion of such land</em> (<span class="ar">أَرْض</span>) <em>as is termed</em> <span class="arrow"><span class="ar">بَرْقَآءُ↓</span></span>, <em>which consists of tracts containing black stones mixed with white sand, and which, when spacious, is termed</em> <span class="arrow"><span class="ar">أَبْرَقُ↓</span></span>: <span class="auth">(JK:)</span> <span class="add">[and]</span> <em>a mountain mixed with sand;</em> as also<span class="arrow"><span class="ar">أَبْرَقُ↓</span></span>: <span class="auth">(IAạr, TA:)</span> <a href="#buroqapN">the pl. of <span class="ar">بُرْقَةٌ</span></a> is <span class="ar">بُرَقٌ</span> <span class="auth">(Ḳ, TA)</span> and <span class="ar">بِرَاقٌ</span>; <span class="auth">(JK, Ṣ;)</span> and that of<span class="arrow"><span class="ar">ابرق↓</span></span> is <span class="ar">أَبَارِقُ</span>, <span class="auth">(JK, Ṣ, Ḳ,)</span> after the manner of a subst., because the quality of a subst. is predominant in it; <span class="auth">(TA;)</span> and that of<span class="arrow"><span class="ar">برقآء↓</span></span> is <span class="ar">بَرْقَاوَاتٌ</span>. <span class="auth">(Aṣ, IAạr, Ṣ, Ḳ.)</span> <span class="pb" id="Page_0191"></span>The <span class="ar">بُرَق</span> of the country of the Arabs are more than a hundred; and are distinguished by particular adjuncts, as <span class="ar long">بُرْقَةٌ الأَثْمَادِ</span> and <span class="ar long">بُرْقَةُ الأَجَاوِلِ</span>, &amp;c. <span class="auth">(Ḳ.)</span> One says <span class="ar long">قُنْفُذُ بُرْقَةٍ</span> <span class="add">[<em>A hedge-hog of a</em> <span class="ar">برقة</span>]</span>, like as one says <span class="ar long">ضَبُّ كُدْيَةِ</span> <span class="auth">(Ṣ)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بُرْقَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="buroqapN_B2">
					<p><span class="add">[The <em>colour denoted by the epithet</em> <span class="ar">أَبْرَقُ</span>: in a mountain, <em>a mixture of blackness and whiteness:</em> <a href="#HaqobaACu">see <span class="ar">حَقْبَآءُ</span></a>, voce <span class="ar">أَحْقَبُ</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بُرْقَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="buroqapN_C1">
					<p><em>Paucity of grease</em> or <em>gravy</em> <span class="auth">(JK, TA)</span> <em>in food.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroqaAnN">
				<h3 class="entry"><span class="ar">بُرْقَانٌ</span> / <span class="ar">بُرْقَانَةٌ</span></h3>
				<div class="sense" id="buroqaAnN_A1">
					<p><span class="ar">بُرْقَانٌ</span> <em>Shining much in the body:</em> <span class="auth">(JK, Ḳ:)</span> applied to man. <span class="auth">(JK.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بُرْقَانٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buroqaAnN_B1">
					<p><em>Locusts when they become yellow, and have variegated stripes</em> or streaks: <span class="auth">(JK:)</span> or <em>locusts that are variegated</em> <span class="auth">(Ḳ TA)</span> <em>with white and black:</em> <span class="auth">(TA:)</span> <span class="add">[a coll. gen. n.:]</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُرْقَانَةٌ</span>}</span></add>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بُرْقَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="buroqaAnN_B2">
					<p><span class="add">[<a href="#baraqN">See also <span class="ar">بَرَقٌ</span></a> of which it is a pl.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroquwqN">
				<h3 class="entry"><span class="ar">بُرْقُوقٌ</span></h3>
				<div class="sense" id="buroquwqN_A1">
					<p><span class="ar">بُرْقُوقٌ</span>, <span class="auth">(Ḳ,)</span> with damm, <span class="auth">(TA,)</span> <span class="add">[vulg. <span class="ar">بَرْقُوق</span>, The <em>plum;</em> or]</span> <em>small</em> <span class="ar">إِجَّاص</span> <span class="add">[or <em>plums</em>]</span>; <span class="auth">(Ḳ;)</span> <em>known in Syria by the name of</em> <span class="ar">جابزك</span>: <span class="auth">(TA:)</span> and <span class="auth">(as some say, TA)</span> the <span class="ar">مِشْمِش</span> <span class="add">[or <em>apricot</em>]</span>: a post-classical word <span class="add">[probably arabicized from the Persian <span class="ar">بَرْقُوقْ</span>, which is applied to both the fruits above mentioned]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlburaAqu">
				<h3 class="entry"><span class="ar">البُرَاقُ</span></h3>
				<div class="sense" id="AlburaAqu_A1">
					<p><span class="ar">البُرَاقُ</span> <em>A certain beast which Moḥammad rode on the night of the ascension</em> <span class="add">[<em>to heaven</em>]</span>; <span class="auth">(Ṣ, Mṣb,* Ḳ;)</span> or <em>which the apostles ride in ascending to heaven; resembling a mule;</em> <span class="auth">(Mṣb;;)</span> or <em>less than the mule, but greater than the ass:</em> <span class="auth">(Ḳ:)</span> so called because of the intense whiteness of his hue, and his great brightness; or because of the quickness of his motion; in respect of both of which he is likened to lightning. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baruwqN">
				<h3 class="entry"><span class="ar">بَرُوقٌ</span></h3>
				<div class="sense" id="baruwqN_A1">
					<p><span class="ar">بَرُوقٌ</span> a she-camel <em>raising her tail, and feigning herself pregnant, not being so;</em> as also<span class="arrow"><span class="ar">مُبْرِقُ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> and<span class="arrow"><span class="ar">بَارِقٌ↓</span></span> a she-camel <em>Putting her tail between her thighs, making it to cleave to her belly, not being pregnant:</em> <span class="auth">(IAạr, TA:)</span> pl. of the first <span class="ar">بُرْقٌ</span> <span class="auth">(TA;)</span> and of the second <span class="ar">مَبَارِيقُ</span>. <span class="auth">(Ṣ, Ḳ.)</span> The Arabs say, <span class="ar long">دَعْنِى مِنْ تَكْذَابِكَ وَتَأْثَامِكَ شَوَلَانَ البَرُوقِ</span> <span class="add">[<em>Let me alone and cease from they lying and thy sin like the she-camel's raising of her tail and feigning herself pregnant when she is not so</em>]</span>: <span class="ar">شولان</span> being in the accus. case as an inf. n.: i. e., thou art in the predicament of the she-camel that raises her tail so as to make one imagine her to be pregnant when she is not so. <span class="auth">(TA.)</span> The pl. <span class="ar">بُرْقٌ</span> is also applied to scorpions, as meaning <em>Raising their tails like the she-camel termed</em> <span class="ar">بروق</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَرُوقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baruwqN_A2">
					<p>Also, applied to a man, <em>Fearful,</em> or <em>timid;</em> <span class="auth">(JK;)</span> or <em>cowardly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barwaqN">
				<h3 class="entry"><span class="ar">بَروَقٌ</span></h3>
				<div class="sense" id="barwaqN_A1">
					<p><span class="ar">بَروَقٌ</span> <em>A certain kind of plant</em> <span class="auth">(JK, Ṣ)</span> <em>which camels do not feed upon except in cases of necessity;</em> <span class="auth">(JK;)</span> <em>a small, feeble tree, which, when the sky becomes clouded, grows green:</em> <span class="auth">(Ḳ:)</span> n. un. witIh <span class="ar">ة</span>: <span class="auth">(Ṣ, Ḳ:)</span> it was described by an Arab of the desert to AḤn as follows: <em>a feeble, juicy plant, having slender branches, at the heads of which are small envelopes</em> (<span class="ar long">قَمَاعِيلُ صِغَارٌ</span>) <em>like chick-peas, in which is a kind of black grain: its feebleness is such that it withers on the spot when the sun becomes hot upon it: and nothing feeds upon it; but men, when they are afflicted with dearth, or drought, express from it a bitter juice, then work it together,</em> or <em>knead it, with</em> <span class="ar">هَبِيد</span> <span class="add">[or <em>colocynths,</em> or the <em>pulp,</em> or <em>seeds, thereof</em>]</span>, <em>or some other thing, and eat it; but it is not eaten alone, because it occasions excitement: it is one of the plants that are plentiful in time of drought and scarce in time of fruitfulness; when copious rain falls upon it, it dies; and when we see it to have become abundant, and coarse,</em> or <em>rough, we fear drought:</em> accord. to another of the Arabs of the desert, the <span class="ar">بَرْوَقَة</span> is <em>a bad kind of herb,</em> or <em>leguminous plant, that grows among the first of the herbs,</em> or <em>leguminous plants: it has a reed like the</em> <span class="ar">سباط</span> <span class="add">[so I render <span class="ar long">لها قصبة مثل السباط</span>, but I thing that the right reading is, <span class="ar long">لَهَا قُضُبٌ مِثْلُ السِّيَاطِ</span> <em>it has twigs like whips,</em> agreeably with the description next preceding, in which it is said to have slender branches,]</span> <em>and a black fruit,</em> or <em>produce.</em> <span class="auth">(TA.)</span> Hence, <span class="ar long">أَشْكَرُ مِنْ بَرْوَقَةٍ</span> <span class="add">[<em>More grateful than a barwakah</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> because it grows green when it sees the clouds, <span class="auth">(Ṣ,)</span> or by means of the least moisture falling from the sky: <span class="auth">(TA:)</span> a prove. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَضْعَفُ مِنْ بَرْوَقَةٍ</span> <span class="add">[<em>Weaker than a barwakah</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariyqN">
				<h3 class="entry"><span class="ar">بَرِيقٌ</span></h3>
				<div class="sense" id="bariyqN_A1">
					<p><span class="ar">بَرِيقٌ</span> <span class="add">[accord. to the Mgh and Ḳ <a href="#brq_1">an inf. n. of <span class="ar">بَرَقَ</span></a>, but accord. to the Ṣ a simple subst.,]</span> <em>A shining, gleaming, glistening, glitter, lustre, brilliancy,</em> or <em>splendour.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariyqapN">
				<h3 class="entry"><span class="ar">بَرِيقَةٌ</span></h3>
				<div class="sense" id="bariyqapN_A1">
					<p><span class="ar">بَرِيقَةٌ</span> <em>Milk upon which is poured a little grease</em> or <em>clarified butter:</em> <span class="auth">(ISK, Ṣ, Ḳ:)</span> or <em>food in which is milk: and such as has a little clarified butter,</em> and <em>grease, put into it:</em> <span class="auth">(TA:)</span> or <em>food that has a little olive-oil poured upon it:</em> <span class="auth">(JK:)</span> or <em>condiment in which is put a little olive-oil</em> or <em>grease:</em> <span class="auth">(L:)</span> pl. <span class="ar">بَرَائِقُ</span>; <span class="auth">(JK, Ṣ, L, Ḳ;)</span> with which <span class="arrow"><span class="ar">تَبَارِيقُ↓</span></span> <span class="add">[pl. of <span class="arrow"><span class="ar">تَبْروقٌ↓</span></span>]</span> is syn., <span class="auth">(L, TA,)</span> applied to food <span class="auth">(Ṣ, TA)</span> in which is put a little olive-oil or clarified butter: <span class="auth">(Ṣ:)</span> or<span class="arrow"><span class="ar">تَبْروقٌ↓</span></span> signifies the <em>grease in a cooking-pot:</em> and <em>water with a little olive-oil poured upon it:</em> and<span class="arrow"><span class="ar">تَبَارِيقُ↓</span></span> is its pl. <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBaAqN">
				<h3 class="entry"><span class="ar">بَرَّاقٌ</span></h3>
				<div class="sense" id="barBaAqN_A1">
					<p><span class="ar">بَرَّاقٌ</span> <em>Shining, gleaming,</em> or <em>glistening, much,</em> or <em>intensely.</em> <span class="auth">(TA.)</span> <a href="#IiboriyqN">See also <span class="ar">إِبْرِيقٌ</span></a>, <a href="#baAriqN">and <span class="ar">بَارِقٌ</span></a></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَرَّاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barBaAqN_A2">
					<p><span class="ar long">فَتًى بَرَّاقُ الثَّنَايَا</span> <em>A young man whose middle pairs of teeth are beautiful and bright, glistening, when he smiles, like lightning:</em> meant to imply cheerfulness of countenance. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَرَّاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="barBaAqN_A3">
					<p><span class="ar">بَرَّاقَةٌ</span> A woman <em>characterized by beauty and splendour</em> or <em>brilliancy</em> <span class="add">[<em>of complexion</em> or <em>skin</em>]</span>: <span class="auth">(Ḳ * TA:)</span> or, as some say, <em>who shows her beauty intentionally.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#IiboriyqN">See <span class="ar">إِبْرِيقٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barowaAqN">
				<h3 class="entry"><span class="ar">بَرْوَاقٌ</span></h3>
				<div class="sense" id="barowaAqN_A1">
					<p><span class="ar">بَرْوَاقٌ</span> <em>A certain plant also called</em> <span class="ar">خُنْثَى</span> <span class="add">[i. e. the <em>asphodel,</em> called by both these names in the present day]</span>: <em>the eating of its fresh, juicy stalk, boiled with olive-oil and vinegar, counteracts jaundice; and the smearing with its root,</em> or <em>lower part, removes the two kinds of</em> <span class="ar">بَهَق</span> <span class="add">[q. v.]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAriqN">
				<h3 class="entry"><span class="ar">بَارِقٌ</span></h3>
				<div class="sense" id="baAriqN_A1">
					<p><span class="ar">بَارِقٌ</span> <em>Shining, gleaming,</em> or <em>glistening.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَارِقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAriqN_A2">
					<p>Clouds (<span class="ar">سَحَابٌ</span>) <em>having,</em> or <em>containing,</em> <span class="add">[or <em>emitting,</em>]</span> <em>lightning.</em> <span class="auth">(Ṣ.)</span> You say also <span class="ar long">سَحَابَةٌ بَارِقَةٌ</span> <span class="add">[<em>A cloud having,</em> or <em>emitting, lightning</em>]</span>: <span class="auth">(Ṣ, TA:)</span> and<span class="arrow"><span class="ar long">سحابة بَرَّاقَةٌ↓</span></span> signifies the same <span class="add">[but in an intensive manner: <a href="#barBaAqN">see <span class="ar">بَرَّاقٌ</span></a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَارِقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAriqN_A3">
					<p><span class="ar">بَارِقَةٌ</span> ‡ <em>Swords:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> so called because of their shining, or glistening: <span class="auth">(TA:)</span> pl. <span class="ar">بَوَارِقُ</span>; <span class="auth">(JK, Ḥam p. 306;)</span> applied to <em>swords</em> and <em>other weapons.</em> <span class="auth">(Ḥam ubi suprà.)</span> Hence the trad. of 'Ammàr, <span class="ar long">الجَنَّةُ تَحْتَ البَارِقَةِ</span> <span class="add">[<em>Paradise is beneath the swords</em>]</span>; <span class="auth">(JK, TA;)</span> meaning, in warring in the cause of God. <span class="auth">(JK.)</span> You also say, <span class="ar long">رَأَيْتُ البَارِقَةَ</span> meaning <em>I saw the shining,</em> or <em>glistening, of the weapons.</em> <span class="auth">(Lḥ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَارِقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAriqN_A4">
					<p><a href="#baruwqN">See also <span class="ar">بَرُوقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baworaqN">
				<h3 class="entry"><span class="ar">بَوْرَقٌ</span></h3>
				<div class="sense" id="baworaqN_A1">
					<p><span class="ar">بَوْرَقٌ</span>, <span class="auth">(JK, Mgh,)</span> with fet-ḥ to the <span class="ar">ب</span> <span class="auth">(Mgh,)</span> or <span class="ar">بُورَقٌ</span>., with damm, <span class="auth">(Ḳ,)</span> <em>A certain, thing,</em> or <em>substance, that is put into dough,</em> <span class="auth">(JK, Mgh, TA,)</span> <em>and causes it to become inflated;</em> <span class="auth">(Mgh;)</span> or <em>into flour;</em> <span class="auth">(TA voce <span class="ar">بُورَكٌ</span>;)</span> <span class="add">[or this is a particular kind thereof, as appears from what follows: accord. to Golius, <em>nitrum</em> and <em>aphronitrum:</em> but]</span> <em>it is of four kinds;</em> <span class="ar">مَائِىٌّ</span> <span class="add">[or the <em>water-kind</em>]</span>, and <span class="ar">جَبَلِىٌّ</span> <span class="add">[or the <em>mountain-kind</em>]</span>, and <span class="ar">أَرْمَنِىٌّ</span> <span class="add">[or <em>Armenian</em>]</span>, and <span class="ar">مِصْرِىٌّ</span> <span class="add">[or <em>Egyptian</em>]</span>, <em>which is the</em> <span class="ar">نَطْرُون</span> <span class="add">[q. v., i. e. <em>natron</em>]</span>: <span class="auth">(Ḳ:)</span> <em>the best thereof is the</em> <span class="ar">ارمنى</span>; <em>and this is said to be meant by the term when it is used absolutely: this is called also</em> <span class="ar long">بورقُ الصَّاغَةِ</span> <span class="add">[a term now applied to <em>borax,</em> as is <span class="ar">بورق</span> alone, and <span class="ar long">مِلْحُ الصَّاغَةِ</span>]</span>, <em>because it polishes silver well</em> <span class="add">[or <em>because of its use in soldering</em>]</span>: <em>the dust-coloured kind thereof is called</em> <span class="ar long">بورقُ الخَبَّازِينَ</span> <span class="add">[<em>the</em> <span class="ar">بورق</span> <em>of the bakers,</em> or <em>makers of bread</em>]</span>: <em>the</em> <span class="ar">نطرون</span> <em>is the red kind thereof: and there is a kind thereof having an oily quality: and a kind consisting of thin butyraceous fragments; and this, if light and hard, is the</em> <span class="ar">إِفْرِيقِى</span>: <em>and the best thereof is that which is produced in Egypt:</em> <span class="auth">(TA:)</span> <em>bruised,</em> or <em>powdered, the belly is smeared with it, near to a fire, and it expels worms: and moistened with honey or with oil of jasmine, the male organs of generation are anointed with it, for it is excellent for the venereal faculty.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">بَوْرَقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baworaqN_B1">
					<p>Also <em>A man in whom one does not trust,</em> or <em>confide:</em> pl. <span class="ar">بَوَارِقُ</span>. <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwriqieBN">
				<h3 class="entry"><span class="ar">بُورِقِىٌّ</span></h3>
				<div class="sense" id="buwriqieBN_A1">
					<p><span class="ar">بُورِقِىٌّ</span> <span class="add">[or <span class="ar">بَوْرَقِىٌّ</span>]</span> <em>A seller of</em> <span class="ar">بُورَق</span> <span class="add">[or <span class="ar">بَوْرَق</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboraqu">
				<h3 class="entry"><span class="ar">أَبْرَقُ</span></h3>
				<div class="sense" id="Oaboraqu_A1">
					<p><span class="ar">أَبْرَقُ</span> A rope (<span class="ar">حَبْل</span>) <em>having two colours;</em> <span class="auth">(Ṣ, O;)</span> <em>twisted with a black strand and a white strand:</em> <span class="auth">(JK:)</span> and in like manner, <span class="auth">(JK,)</span> a mountain (<span class="ar">جَبَل</span>, JK, Ḳ) <em>in which are two colours,</em> <span class="auth">(Ḳ, TA,)</span> <em>black and white:</em> <span class="auth">(TA:)</span> and <span class="auth">(so in the Ṣ, but in the Ḳ “or,”)</span> anything <em>having blackness and whiteness together.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say <span class="ar long">تَيْسٌ أَبْرَقٌ</span> and <span class="ar long">عَنْزٌ بَرْقَآءُ</span> <span class="add">[<em>A black and white he-goat</em> and <em>she-goat</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar long">شَاةٌ بَرْقَآءُ</span> <em>a ewe whose white wool is cleft,</em> or <em>divided, by black flocks</em> <span class="add">[or <em>streaks</em>]</span>: <span class="auth">(Ḳ:)</span> <span class="ar">أَبْرَقُ</span> and <span class="ar">بَرْقَآءُ</span> applied to sheep or goats are like <span class="ar">أَبْلَقُ</span> and <span class="ar">بَلْقَآءُ</span> applied to beasts of the equine kind, and <span class="ar">أَبْقَعُ</span> and <span class="ar">بَقْعَآءُ</span> to dogs. <span class="auth">(Lḥ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">أَبْرَقُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oaboraqu_A2">
					<p><span class="ar">بَرْقَآءُ</span> is also a name given to <em>An eye;</em> <span class="auth">(Ṣ, M;)</span> because it has blackness and whiteness mingled in it: <span class="auth">(M, TA:)</span> dual <span class="ar">بَرْقَاوَانِ</span>. <span class="auth">(TA.)</span> And <span class="ar long">عَيْنٌ بَرْقَآءُ</span> signifies <em>An eye black in the iris, with whiteness</em> <span class="add">[<em>of the rest</em>]</span> <em>of the bulb.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">أَبْرَقُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oaboraqu_A3">
					<p><span class="ar long">رَوْضَةٌ بَرْقآءُ</span> <em>A meadorc,</em> or <em>garden, in which are two colours.</em> <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0192"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">أَبْرَقُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oaboraqu_A4">
					<p><a href="#buroqapN">See also <span class="ar">بُرْقَةٌ</span></a>. in seven places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">أَبْرَقُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oaboraqu_A5">
					<p><span class="ar">أَبْرَقُ</span> also signifies <em>A certain bird.</em> <span class="auth">(Tekmileh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">أَبْرَقُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Oaboraqu_A6">
					<p>And <span class="add">[the pl.]</span> <span class="ar">بُرْقٌ</span> is used as a name for The <span class="add">[<em>locusts,</em> or <em>crickets, termed</em>]</span> <span class="ar">جَنَادِب</span>. <span class="auth">(IB, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">أَبْرَقُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oaboraqu_B1">
					<p>Also <em>A certain Persian medicine, good for the memory.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboriyqN">
				<h3 class="entry"><span class="ar">إِبْرِيقٌ</span></h3>
				<div class="sense" id="IiboriyqN_A1">
					<p><span class="ar">إِبْرِيقٌ</span> a Persian word, <span class="auth">(Ṣ, Mṣb,)</span> arabicized, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> originally <span class="ar long">آبْ رِيزْ</span> <span class="auth">(CK <span class="add">[in a MṢ. copy of the Ḳ and in the TA, incorrectly, <span class="ar long">آب رِى</span>]</span>)</span> <span class="add">[<em>A ewer, such as is used for wine,</em> and also <em>such as is used for water to be poured on the hands; each having a long and slender spout, and a handle;</em>]</span> <em>a well-known vessel;</em> <span class="auth">(TA;)</span> <em>a vessel having a spout</em> <span class="auth">(Mgh, and Bḍ and Jel in lvi. 18)</span> <em>and a handle:</em> <span class="auth">(Bḍ and Jel ibid:)</span> accord. to Kr, a <span class="ar">كُوز</span>; and so says AḤn in one place; but in another he says that it is <em>like a</em> <span class="ar">كوز</span>: <span class="auth">(TA:)</span> <span class="add">[it is <em>somewhat like a</em> <span class="ar">كوز</span> <em>with the addition of a spout:</em>]</span> pl. <span class="ar">أَبَارِيقُ</span> <span class="auth">(Ṣ, Mṣb)</span> <span class="add">[and sometimes <span class="ar">أَبَارِقَةٌ</span>]</span>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">إِبْرِيقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IiboriyqN_B1">
					<p><em>A sword such as is termed</em> <span class="arrow"><span class="ar">بَرَّاق↓</span></span>; <span class="auth">(Ḳ;)</span> i. e. <span class="auth">(TA)</span> <em>a sword that shines, gleams,</em> or <em>glistens, much,</em> or <em>intensely:</em> <span class="auth">(Ṣ, Kr:)</span> or simply a <em>sword:</em> or, as some say, <em>a bow:</em> <span class="auth">(JK:)</span> or it signifies also <em>a bow in which are</em> <span class="ar">تَلَامِيع</span> <span class="add">[<em>or places differing in colour from the rest, and,</em> app., <em>glistening</em>]</span>: <span class="auth">(Ḳ:)</span> thus, accord. to Az, in a verse of ʼAmr Ibn-Aḥmar: but correctly, accord. to Ṣgh, it has there the first of the significations explained in this sentence: and it is said, also, that <span class="ar long">سَيْفٌ إِبْرِيقٌ</span> signifies <em>a sword having much lustre, and much diversified with wavy marks</em> or <em>streaks,</em> or <em>in its grain.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برق</span> - Entry: <span class="ar">إِبْرِيقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="IiboriyqN_B2">
					<p><em>A woman who is beautiful, and splendid,</em> or <em>brilliant,</em> <span class="auth">(Lḥ, JK, Ḳ, TA,)</span> <em>in colour</em> <span class="add">[or <em>complexion</em>]</span>: <span class="auth">(Lḥ, TA:)</span> or, as some say, <em>who shows her beauty intentionally.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#barBaAqapN">See also <span class="ar">بَرَّاقَةٌ</span></a> <span class="auth">(voce <span class="ar">بَرَّاقٌ</span>)</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubayoriqN">
				<h3 class="entry"><span class="ar">أُبَيْرِقٌ</span></h3>
				<div class="sense" id="OubayoriqN_A1">
					<p><span class="ar">أُبَيْرِقٌ</span> <a href="#IisotaboraqN">dim. of <span class="ar">إِسْتَبْرَقٌ</span>, q. v.</a> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisotaboraqN.1">
				<h3 class="entry"><span class="ar">إِسْتَبْرَقٌ</span></h3>
				<div class="sense" id="IisotaboraqN.1_A1">
					<p><span class="ar">إِسْتَبْرَقٌ</span>, <span class="auth">(IDrd, Ṣ, Ḳ, &amp;c.,)</span> sometimes with the conjunctive <span class="ar">ا</span>, <span class="auth">(TA,)</span> <em>Thick</em> <span class="ar">دِيبَاج</span> <span class="add">[or <em>silk brocade</em>]</span>: <span class="auth">(Ed-Dahhak, Ṣ, Ḳ, and so Bḍ and Jel in xviii. 30, &amp;c.:)</span> or <span class="ar">ديباج</span> <em>made</em> <span class="add">[or <em>interwoven</em>]</span> <em>with gold:</em> <span class="auth">(Ḳ:)</span> or <em>closely-woven, thick, beautiful</em> <span class="ar">ديباج</span> <em>made</em> <span class="add">[or <em>interwoven</em>]</span> <em>with gold:</em> <span class="auth">(TA:)</span> or <em>closely- woven cloths, or garments, of silk, like</em> <span class="ar">ديباج</span>: <span class="auth">(IDrd, Ḳ:)</span> or <em>thick silk:</em> <span class="auth">(IAth, TA:)</span> or <em>a red thong cut from an untanned skin</em> (<span class="ar long">قِدَّةٌ حَمْرَآءُ</span>), <em>as though it were</em> <span class="add">[<em>composed of</em>]</span> <em>pieces of bow-strings, or chords:</em> <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> it is an arabicized word, <span class="auth">(IDrd, Ṣ, Ḳ,)</span> form <span class="ar">إِسْتَرْوَهٌ</span>, <span class="auth">(IDrd, Ḳ,)</span> which is Syriac; <span class="auth">(IDrd, TA;)</span> or from the Persian, <span class="auth">(Ṣ, TA,)</span> in which <span class="ar">سِتَبْر</span> and <span class="ar">إِسْتَبْر</span> signify “thick,” absolutely, whence <span class="ar">سِتَبْرَهْ</span> and <span class="ar">إِسْتَبْرَهْ</span> are particularly applied to signify “thick <span class="ar">ديباج</span>, and then the latter is arabicized by substituting <span class="ar">ق</span> for the <span class="ar">ه</span>: so says Esh-Shiháb El-Khafájee: or the <span class="ar">ا</span> and <span class="ar">س</span> and <span class="ar">ت</span> are augmentative, and it is mentioned in the present art. in the Ṣ and Ḳ as though this were the case, agreeably with the form of its dim., which is said by J and in the Ḳ to be <span class="arrow"><span class="ar">أُبَيْرِقٌ↓</span></span>; for in forming the dim., a word is reduced to its root. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taborwqN">
				<h3 class="entry"><span class="ar">تَبْروقٌ</span> / <span class="ar">تَبَارِيقُ</span></h3>
				<div class="sense" id="taborwqN_A1">
					<p><span class="ar">تَبْروقٌ</span>; pl. <span class="ar">تَبَارِيقُ</span>: <a href="#bariyqapN">see <span class="ar">بَرِيقَةٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboraqN">
				<h3 class="entry"><span class="ar">مَبْرَقٌ</span></h3>
				<div class="sense" id="maboraqN_A1">
					<p><span class="ar">مَبْرَقٌ</span> <span class="add">[<em>A shining, gleaming,</em> or <em>glistening:</em> or <em>a time thereof</em>]</span>. You say, <span class="ar long">جَاءَ عِنْدَ مَبْرَقِ الصُّبْحِ</span> <span class="add">[<em>He came at the shining,</em>, &amp;c., or <em>at the time of the shining, &amp;c., of the dawn;</em> or]</span> <em>when the dawn shone,</em> or <em>gleamed,</em> or <em>glistened.</em> <span class="auth">(Ḳ, TA. <span class="add">[In the latter, <span class="ar">مبرق</span> is said to be here a meemee inf. n.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muboriqN">
				<h3 class="entry"><span class="ar">مُبْرِقٌ</span></h3>
				<div class="sense" id="muboriqN_A1">
					<p><span class="ar">مُبْرِقٌ</span>: <a href="#baruwqN">see <span class="ar">بَرُوقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0189.pdf" target="pdf">
							<span>Lanes Lexicon Page 189</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0190.pdf" target="pdf">
							<span>Lanes Lexicon Page 190</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0191.pdf" target="pdf">
							<span>Lanes Lexicon Page 191</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0192.pdf" target="pdf">
							<span>Lanes Lexicon Page 192</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
