<article class="root" id="Root_btl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/017_btk">بتك</a></span>
				<span class="ar">بتل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/019_bv">بث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="btl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بتل</span></h3>
				<div class="sense" id="btl_1_A1">
					<p><span class="ar">بَتَلَهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِلُ</span>}</span></add>, <span class="auth">(Ṣ,)</span> or <span class="ar">ـُ</span>, <span class="auth">(Mṣb,)</span> or both, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَتْلٌ</span>, <span class="auth">(Lth, T, Ṣ, &amp;c.,)</span> <em>He cut it off,</em> or <em>severed it;</em> <span class="auth">(M, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بتّلهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَبْتِيلٌ</span>: <span class="auth">(TA:)</span> <em>he separated it</em> <span class="auth">(Lth, T, Ṣ, M, Mṣb, Ḳ)</span> from another thing. <span class="auth">(Lth, T, Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btl_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَتَلَ العُمْرَةَ</span> <em>He made the performance of the</em> <span class="ar">عمرة</span> <span class="add">[or <em>minor pilgrimage</em>]</span> <em>to be obligatory, by itself.</em> <span class="auth">(A, TA.)</span> And<span class="arrow"><span class="ar long">بتّل↓ العُمْرَى</span></span> <em>He made the</em> <span class="ar">عمرى</span> <em>to be obligatory</em> <span class="add">[<em>upon himself</em>]</span>; i. e., <em>the saying, I have assigned to thee my house that thou mayest inhabit it to the end of my life.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="btl_1_B1">
					<p><span class="ar">بَتِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْتَلُ</span>}</span></add>, inf. n. <span class="ar">بَتْلٌ</span>, <span class="add">[but accord. to analogy, this should rather be <span class="ar">بَتلٌ</span>,]</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, wide between the shoulders.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="btl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بتّل</span></h3>
				<div class="sense" id="btl_2_A1">
					<p><a href="#btl_1">see 1</a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="btl_2_B1">
					<p><a href="#btl_5">and see also 5</a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="btl_2_C1">
					<p><a href="#mubatBalN">and <span class="ar">مُبَتَّلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="btl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبتّل</span></h3>
				<div class="sense" id="btl_5_A1">
					<p><span class="ar">تبتّلا</span>: <a href="#btl_7">see 7</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btl_5_A2">
					<p><span class="add">[Hence,]</span> <em>He was,</em> or <em>became, alone.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="btl_5_A3">
					<p>Also, <span class="auth">(Ṣ,)</span> or <span class="ar long">تبتّلا إِلَى ٱللّٰهِ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بتّل↓</span></span>, <span class="auth">(Ṣ,* Ḳ,)</span> inf. n. <span class="ar">تَبْتِيلٌ</span>, <span class="auth">(Ṣ,)</span> <em>He detached himself from worldly things, and devoted himself to God:</em> <span class="auth">(Ṣ:)</span> or <em>he devoted himself to God exclusively, and was sincere,</em> or <em>without hypocrisy, towards Him:</em> <span class="auth">(M, Ḳ:)</span> <em>he forsook every other thing, and applied himself to the service of God:</em> <span class="auth">(Fr, T:)</span> <em>he devoted himself exclusively to the service of God:</em> <span class="auth">(Aboo-Is-ḥáḳ, T:)</span> or <em>he abstained from sexual intercourse:</em> <span class="auth">(Ḳ:)</span> or <span class="ar">تبتّل</span> <span class="add">[alone]</span> has this signification; <span class="auth">(M, TA;)</span> or <em>he separated himself from women, and abstained from sexual intercourse:</em> and hence, is metaphorically employed to denote exclusive devotion to God. <span class="auth">(TA.)</span> Hence, in the Ḳur <span class="add">[lxxiii. 8]</span>, <span class="ar long">وَتَبَتَّلْ إِلَيْةِ تَبْتِيلًا</span>, <span class="auth">(T, Ṣ, M,)</span> for <span class="ar long">تبتّل اليه تَبَتُّلًا</span>. <span class="auth">(T.)</span> You say also, <span class="ar long">تبتّلا إِلَى العِبَادَةِ</span> <em>He applied himself exclusively to the service of God.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="btl_5_A4">
					<p><span class="ar">تَبَتّلَتْ</span>, said of a woman, <em>She adorned and beautified herself.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="btl_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبتل</span></h3>
				<div class="sense" id="btl_7_A1">
					<p><span class="ar">انبتل</span> <em>It was,</em> or <em>became, cut off,</em> or <em>severed;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تبتّل↓</span></span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">انبتلت الفسِيلَةُ</span>, <span class="auth">(Ḳ, <span class="add">[in a copy of the M<span class="arrow"><span class="ar">ابتتلت↓</span></span>, probably a mistranscription,]</span>)</span> <em>The shoot,</em> or <em>offset, of the palm-tree was cut off,</em> or <em>severed,</em> <span class="ar long">مِنْ أُمِّهَا</span> <span class="add">[<em>from its mother-tree</em>]</span>; as also<span class="arrow"><span class="ar">تبتّلت↓</span></span> and<span class="arrow"><span class="ar">استبتلت↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btl_7_A2">
					<p><span class="ar long">انبتل فِى سَيْرِهِ</span> <em>He strove, laboured,</em> or <em>exerted himself, and made much progress, in his journeying,</em> or <em>pace.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="btl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتتل</span></h3>
				<div class="sense" id="btl_8_A1">
					<p><a href="#btl_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="btl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبتل</span></h3>
				<div class="sense" id="btl_10_A1">
					<p><a href="#btl_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batolN">
				<h3 class="entry"><span class="ar">بَتْلٌ</span></h3>
				<div class="sense" id="batolN_A1">
					<p><span class="ar long">عَطَآءٌ بَتْلٌ</span> <em>A gift that is</em> <span class="add">[<em>as it were</em>]</span> <em>cut off;</em> i. e., <em>of which there is not the like;</em> or <em>after which another is not given.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">صَدَقَةٌ بَتْلَةٌ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar long">صدقة بَتَّةٌ بَتْلَةٌ</span>, <span class="auth">(TA,)</span> <em>An alms,</em> or <em>a gift for the sake of God, cut off from its giver:</em> <span class="auth">(M, Ḳ:)</span> or <em>cut off from all the property</em> <span class="add">[<em>irrevocably</em>]</span>, <em>to be devoted to the cause of God.</em> <span class="auth">(O, TA. <span class="add">[<a href="index.php?data=02_b/014_bt">See also art. <span class="ar">بت</span></a>.]</span>)</span> You say also, <span class="ar long">أَعْطَيْتُهُ هٰذِهِ العَطِيَّةَ بَتَّا بَتْلًا</span>: <a href="index.php?data=02_b/014_bt">see art. <span class="ar">بت</span></a>. And <span class="ar long">طَلَّقَهَا بَتَّةً بَتْلَةً</span>; <span class="auth">(Ṣ;)</span> or <span class="ar long">طلّقها طَلْقَةً بَتَّةً بَتْلَةً</span>; <span class="auth">(Mṣb;)</span> <span class="add">[<em>He divorced her by a separating divorce;</em> or <em>by a decided and irrevocable divorce;</em> (<a href="index.php?data=02_b/014_bt">see art. <span class="ar">بت</span></a>;)]</span> the last word being a corroborative of that next preceding it. <span class="auth">(TA.)</span> And <span class="ar long">حَلَفَ يَمِينًا بَتْلَةً</span> <em>He swore a decided</em> <span class="add">[or <em>an irrevocable</em>]</span> <em>oath.</em> <span class="auth">(M, TA. <span class="add">[See also a similar phrase voce <span class="ar">بَتُّ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batolN_A2">
					<p>Also <em>Truth;</em> or <em>true:</em> whence <span class="ar">بَتْلًا</span> <em>in truth;</em> or <em>truly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batuwlN">
				<h3 class="entry"><span class="ar">بَتُولٌ</span></h3>
				<div class="sense" id="batuwlN_A1">
					<p><span class="ar">بَتُولٌ</span> <em>A shoot,</em> or <em>an offset, of a palm-tree, cut off from its mother-tree, and independent thereof;</em> as also<span class="arrow"><span class="ar">بَتِيلَةٌ↓</span></span>, <span class="auth">(Aṣ, T, Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَتِيلٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتُولٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batuwlN_A2">
					<p><em>A virgin, that is cut off from husbands:</em> <span class="auth">(Ṣ:)</span> <em>a woman that withholds herself from men,</em> <span class="auth">(T,)</span> or <em>that is cut off from men,</em> <span class="auth">(M, Ḳ,)</span> <em>having no desire for them,</em> <span class="auth">(T, M, TA,)</span> <em>nor need of them;</em> <span class="auth">(T;)</span> and, with the art. <span class="ar">ال</span>, applied to the Virgin Mary; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَتِيلٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> with the art. <span class="ar">ال</span>, it is applied also to Fátimeh, the daughter of Moḥammad, because she was separated from the <span class="add">[other]</span> women of her age and nation by chasteness and excel-lence and religion and <span class="add">[other]</span> grounds of pretension to respect: <span class="auth">(Aḥmad Ibn-Yaḥyà, T, Ḳ:*)</span> or it signifies, <span class="auth">(Ṣ,)</span> or signifies also, <span class="auth">(Ḳ,)</span> <em>a woman detached from worldly things, and devoted to God;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَتِيلٌ↓</span></span> and<span class="arrow"><span class="ar">بَتِيلَةٌ↓</span></span>. <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batiylN">
				<h3 class="entry"><span class="ar">بَتِيلٌ</span></h3>
				<div class="sense" id="batiylN_A1">
					<p><span class="ar">بَتِيلٌ</span>: <a href="#batuwlN">see <span class="ar">بَتُولٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batiylN_A2">
					<p>Also <em>Slender;</em> <span class="auth">(Ḥam p. 589;)</span> applied to a waist; <span class="auth">(Ḥam, TA;)</span> as also<span class="arrow"><span class="ar">مُبَتَّلٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="batiylN_A3">
					<p>A tree <em>having its racemes pendulous.</em> <span class="auth">(Ḳ. <span class="add">[<a href="#mubotilN">See also <span class="ar">مُبْتِلٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="batiylN_A4">
					<p><em>A watercourse</em> <span class="auth">(Ibn-ʼAbbád, M, Ḳ)</span> <em>in the lower part of a valley:</em> pl. <span class="ar">بُتُلٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batiylapN">
				<h3 class="entry"><span class="ar">بَتِيلَةٌ</span></h3>
				<div class="sense" id="batiylapN_A1">
					<p><span class="ar">بَتِيلَةٌ</span>: <a href="#batuwlN">see <span class="ar">بَتُولٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batiylapN_A2">
					<p>Also <em>Any limb,</em> or <em>member,</em> <span class="auth">(Lth, T, Ṣ, M, Ḳ,)</span> <em>with its flesh,</em> <span class="auth">(Lth, T, Ṣ,)</span> <em>separate from others,</em> <span class="auth">(M, Ḳ,)</span> or <em>by itself:</em> <span class="auth">(Lth, T:)</span> pl. <span class="ar">بَتَائِلُ</span>. <span class="auth">(Lth, T, Ṣ, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="batiylapN_A3">
					<p>In one dial., <span class="auth">(M,)</span> The <em>posteriors;</em> <span class="auth">(M, Ḳ;)</span> because divided <span class="add">[or distinct]</span> from the back. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">بَتِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="batiylapN_A4">
					<p><span class="ar long">مَرَّ عَلَى بَتِيلَةٍ مِنْ رَأْيِهِ</span>, and<span class="arrow"><span class="ar long">بَتْلَآءِ↓ من رأيه</span></span>, <span class="add">[<em>He proceeded according to</em>]</span> <em>an irrevocable determination</em> or <em>resolution.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabotalu">
				<h3 class="entry"><span class="ar">أَبْتَلُ</span></h3>
				<div class="sense" id="Oabotalu_A1">
					<p><span class="ar">أَبْتَلُ</span>; fem. <span class="ar">بَتْلَآءُ</span>: for the latter, <a href="#batiylapN">see what next precedes</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">أَبْتَلُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabotalu_A2">
					<p><span class="ar long">عُمْرَةٌ بَتْلَآءُ</span> <span class="add">[<em>A minor pilgrimage</em>]</span> <em>not conjoined with another.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">أَبْتَلُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabotalu_A3">
					<p>And <span class="ar">أَبْتَلُ</span>, applied to a man, <em>Wide between the shoulders.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotilN">
				<h3 class="entry"><span class="ar">مُبْتِلٌ</span></h3>
				<div class="sense" id="mubotilN_A1">
					<p><span class="ar">مُبْتِلٌ</span>, <span class="auth">(Aṣ, T, Ṣ,)</span> or <span class="ar">مُبْتِلَةٌ</span>, <span class="auth">(M, Ḳ, TA, <span class="add">[in the CK, erroneously, <span class="ar">مُبْتَلَة</span>,]</span>)</span> the first being <span class="add">[in the opinion of ISd]</span> pl. <span class="add">[or rather coll. gen. n.]</span> of the second, like as <span class="ar">تَمْرٌ</span> is of <span class="ar">تَمرَةٌ</span>, <span class="auth">(M,)</span> A palmtree (<span class="ar">نَخْلَةٌ</span>) <em>having a shoot,</em> or <em>an offset, cut off from it and independent of it;</em> <span class="auth">(Aṣ, T, Ṣ, M, Ḳ;)</span> and used in like manner as a pl.; <span class="pb" id="Page_0151"></span>i. e., the first is also used as a pl.: <span class="auth">(Ṣ:)</span> or the first signifies <em>solitary,</em> or <em>isolated:</em> <span class="auth">(Ibn-Ḥabeeb, TA:)</span> or <em>of which the racemes are pendulous.</em> <span class="auth">(TA. <span class="add">[<a href="#batiyBlN">See also <span class="ar">بَتِييلٌ</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubatBalN">
				<h3 class="entry"><span class="ar">مُبَتَّلٌ</span></h3>
				<div class="sense" id="mubatBalN_A1">
					<p><span class="ar">مُبَتَّلٌ</span>: <a href="#batyilN">see <span class="ar">بَتيِلٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">مُبَتَّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubatBalN_A2">
					<p><span class="ar">مُبَتَّلَةٌ</span>, applied to a woman, <em>Beautiful, elegant,</em> or <em>pretty;</em> <span class="auth">(Ḳ;)</span> <em>as though her beauty were divided into portions</em> (<span class="arrow"><span class="ar">بُتِّلَ↓</span></span>, i. e. <span class="ar">قُطِّعَ</span>,) <span class="add">[<em>and distributed in due proportions</em>]</span> <em>upon her limbs:</em> <span class="auth">(M,* Ḳ:)</span> or <em>perfect in make,</em> <span class="auth">(Ṣ,)</span> <em>whose flesh is not accumulated, one portion upon another,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>but distinctly disposed;</em> this latter being said by some to be the meaning: <span class="auth">(M:)</span> or, accord. to Lḥ, <span class="auth">(M, TA,)</span> <em>having a lankness,</em> or <em>looseness, in her limbs;</em> <span class="auth">(M, Ḳ, TA;)</span> <em>not having them compressed, one upon another;</em> <span class="auth">(M:)</span> or <em>as though the flesh were cut off from them:</em> <span class="auth">(TA:)</span> and in like manner, <span class="ar">مُبَتَّلٌ</span> applied to a camel: <span class="auth">(M, Ḳ:)</span> not applied as an epithet to a man: <span class="auth">(Ṣ, M, Ḳ:)</span> or <span class="ar long">مُبَتَّلَةُ الخَلْقِ</span> signifies <em>distinct in make from the generality of women; excelling them</em> <span class="add">[<em>therein</em>]</span>: <span class="auth">(Aboo-Saʼeed, T, TA:)</span> or <em>perfect in make:</em> or <em>having every part beautiful in itself; not dependent</em> <span class="add">[<em>for its beauty</em>]</span> <em>upon another part:</em> <span class="auth">(T:)</span> or <em>beautiful in make; not with one part falling short of another</em> <span class="add">[<em>in beauty</em>]</span>; <em>not being beautiful in the eye and ugly in the nose, nor beautiful in the nose and ugly in the eye; but perfect.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="munobatilN">
				<h3 class="entry"><span class="ar">مُنْبَتِلٌ</span></h3>
				<div class="sense" id="munobatilN_A1">
					<p><span class="ar">مُنْبَتِلٌ</span> <em>Cut off,</em> or <em>severed.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتل</span> - Entry: <span class="ar">مُنْبَتِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="munobatilN_A2">
					<p><span class="add">[And hence,]</span> <span class="ar long">عَزِيمَةٌ مُنْبَتِلَةٌ</span> <em>An irrevocable determination</em> or <em>resolution.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0150.pdf" target="pdf">
							<span>Lanes Lexicon Page 150</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0151.pdf" target="pdf">
							<span>Lanes Lexicon Page 151</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
