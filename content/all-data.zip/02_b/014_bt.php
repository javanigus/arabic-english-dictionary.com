<article class="root" id="Root_bt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/013_bbg">ببغ</a></span>
				<span class="ar">بت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/015_btr">بتر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bt_1">
				<h3 class="entry">1. ⇒ <span class="ar">بتّ</span></h3>
				<div class="sense" id="bt_1_A1">
					<p><span class="ar">بَتَّهُ</span>, <span class="auth">(Lth, T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْتُتُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِتُ</span>}</span></add>, <span class="auth">(Ṣ, M, Mṣb,)</span> the latter anomalous, because a reduplicative verb <span class="add">[of this kind]</span> having the aor. with kesr is not trans., except in certain instances, of which this is one; the other instances being <span class="ar">عَلَّهُ</span>, in relation to drinking,, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَعْلُلُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَعْلِلُ</span>}</span></add>, and <span class="ar long">نَمَّ الحَدِيثَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَنْمُمُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَنْمِمُ</span>}</span></add>, and <span class="ar">شَدَّهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَشْدُدُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَشْدِدُ</span>}</span></add>, and <span class="ar">حَبَّهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَحْبِبُ</span>}</span></add>; the last having but one form <span class="add">[of aor.]</span>; <span class="auth">(Ṣ;)</span> inf. n. <span class="ar">بَتٌّ</span>: <span class="auth">(Lth, T, Ṣ, M, A, &amp;c.:)</span> and<span class="arrow"><span class="ar">ابتّهُ↓</span></span>, <span class="auth">(M,)</span> inf. n. <span class="ar">إِبْتَاتٌ</span>: <span class="auth">(Mgh, Ḳ:)</span> <em>He cut it off, severed it, separated it,</em> or <em>disunited it,</em> <span class="auth">(Lth, T, Ṣ, M, A,* Mgh,* Mṣb, Ḳ,*)</span> <em>entirely,</em> or <em>utterly;</em> <span class="auth">(Lth, T, M;)</span> namely, a thing; <span class="auth">(M;)</span> a rope, or cord; <span class="auth">(Lth, T;)</span> and a tie, or bond, of union between two persons. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bt_1_A2">
					<p><span class="add">[<span class="ar">بَتَّهُ</span> and<span class="arrow"><span class="ar">ابتّهُ↓</span></span>, accord. to the TA, app. signify also <em>He,</em> or <em>it, caused him</em> <span class="auth">(a man)</span> <em>to become unable to proceed in his journey, his camel that bore him breaking down,</em> or <em>stopping from fatigue,</em> or <em>perishing:</em> for <span class="ar">انبتّ</span> as signifying “he became so” is there said to be quasi-pass. of those two verbs when it has this sense. Hence,]</span> <span class="ar long">بَتَّهُ السَّفَرُ</span> <span class="add">[<em>The journey caused him to become cut off,</em>, &amp;c.]</span>. <span class="auth">(A.)</span> And <span class="ar long">سَاقَ دَابَّتَهُ حَتَّى بَتَّهَا</span> <span class="add">[<em>He urged on his beast so that,</em> or <em>until, he caused it to become cut off,</em>, &amp;c.]</span>: <span class="auth">(A:)</span> and<span class="arrow"><span class="ar long">أَبَتَّ↓ بَعِيرَهُ</span></span> <em>He caused his camel to become cut off,</em>, &amp;c., (<span class="ar">قَطَعَةُ</span>,) <em>by travel:</em> <span class="auth">(M, TA:)</span> this is not said but of a man who has forced on his camel at a hard pace, or by laborious journeying. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bt_1_A3">
					<p><span class="ar long">بَتَّ طَلَاقَ ٱمْرَأَتِهِ</span>, <span class="auth">(T, Mṣb, TA,)</span> or <span class="ar long">طَلَاقَ المَرْأَةِ</span>, <span class="auth">(Mgh,)</span> and<span class="arrow"><span class="ar">أَبَتَّهُ↓</span></span>, <span class="auth">(Lth, T, Mgh, Mṣb,)</span> <em>He made the divorce of his wife,</em> or <em>of the woman, to be absolutely separating,</em> <span class="auth">(Lth, T, Mgh, Mṣb, TA,)</span> <em>so as to cut her off from return.</em> <span class="auth">(Mṣb.)</span> Lth, with whom AZ agrees, has erred in asserting that <span class="ar">بَتَّ</span> is intrans. and<span class="arrow"><span class="ar">أَبَتّ↓</span></span> trans.: <span class="auth">(T, TA:)</span> both are trans. and intrans., <span class="auth">(T, Mṣb, TA,)</span> as En-Nawawee asserts in the Tahdheeb el-Asmà wa-1-Loghát. <span class="auth">(TA.)</span> You say, <span class="ar long">الطَّلْقَةُ الوَاحِدَةُ تَبُتُّ</span>, and<span class="arrow"><span class="ar">تُبِتُّ↓</span></span>, i. e. <em>The single divorce cuts the matrimonial tie,</em> or <em>bond, of the woman,</em> (<span class="ar long">تَقْطَعُ عِصْمَةَ النِّكَاحِ</span>, T, Mgh,*) <em>when the period during which she must wait before contracting a new marriage has ended.</em> <span class="auth">(T.)</span> <span class="add">[<a href="#batBN">See also <span class="ar">بَتٌّ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bt_1_A4">
					<p><span class="ar long">بَتَّ عَلَيْهِ القَضَآءَ</span>, <span class="auth">(T, Ṣ, M, A,)</span> inf. n. <span class="ar">بَتٌّ</span>; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar">أَبَتَّهُ↓</span></span>; <span class="auth">(T, Ṣ, M;)</span> <em>He</em> <span class="auth">(the judge, T)</span> <em>decided the judgment,</em> or <em>sentence, against him.</em> <span class="auth">(T, Ṣ,* M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bt_1_A5">
					<p><span class="ar long">بَتَّ عَلَيْهِ الشَّهَادَةَ</span>, and<span class="arrow"><span class="ar">أَبَتَّهَا↓</span></span>, <em>He decided against him by the testimony,</em> <span class="add">[or <em>pronounced the testimony decisive against him,</em>]</span> <em>and compelled,</em> or <em>constrained, him to admit it.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bt_1_A6">
					<p><span class="ar long">بَتَّ شَهَادَتَهُ</span>, and<span class="arrow"><span class="ar">أَبَتَّهَا↓</span></span>, <em>He gave his testimony decisively.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bt_1_A7">
					<p><span class="ar long">أَبُتُّ أَنَّهُ قَالَ</span> <em>I know,</em> or <em>declare, decidedly,</em> not <span class="add">[merely]</span> thinking it, <em>that he said</em> thus. <span class="auth">(Saheeh of Muslim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bt_1_A8">
					<p><span class="ar long">بَتَّ النِّيَّةَ</span> <em>He made the intention decided;</em> or <em>fixed it decidedly.</em> <span class="auth">(A.)</span> It is said in a trad.,<span class="arrow"><span class="ar long">لَا صِيَامَ لِمَنْ لَمْ يُبِتَّ↓ الصّيَامِ مِنَ اللَّيْلِ</span></span>, <span class="auth">(T, Ṣ, Mgh,)</span> or <span class="ar long">لَمْ يَبُتَّ</span>, accord. to different recitals, <span class="auth">(Mgh,)</span> i. e. <em>There is no fasting to him</em> <span class="add">[meaning <em>his fasting is null</em>]</span> <em>who does not decisively impose it upon himself, by intention, from the night:</em> <span class="auth">(Ṣ,* Mgh:)</span> or, <em>who does not form the intention of fasting before daybreak, and thus cut it off from the time in which there is no fasting, namely, the night:</em> the intention is termed <span class="ar">بَتٌّ</span> <span class="add">[and <span class="ar">إِبْتَاتٌ</span>]</span> because it makes a division between non-fasting and fasting: <span class="auth">(T, TA:)</span> <span class="ar long">لَمْ يُبِت</span>, from <span class="ar">الإِبَاتَةُ</span>, is a mistake; but <span class="ar long">لم يُبَيِّت</span>, from <span class="ar">التَّبْيِيتُ</span>, <span class="add">[<a href="#bayBata">see <span class="ar">بَيَّتَ</span></a>,]</span> is correct. <span class="auth">(Mgh.)</span> And it is said in another trad.,<span class="arrow"><span class="ar long">أَبِتُّوا↓ نِكَاحَ هٰذِهِ النِّسَآءِ</span></span>, i. e. <em>Decide ye the affair respecting the marriage of these women, and confirm it by its</em> <span class="add">[<em>proper</em>]</span> <em>conditions:</em> an oblique prohibition of the kind of marriage termed <span class="ar long">نِكَاحُ المُتْعَةِ</span>, because it is a marriage not <span class="add">[absolutely or lawfully]</span> decided, <span class="add">[being]</span> made definite as to duration. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bt_1_A9">
					<p><span class="ar">بَتَّ</span> also signifies <em>He made to have,</em> or <em>take, effect; he executed,</em> or <em>performed;</em> <span class="auth">(Ḥar p. 210;)</span> and so<span class="arrow"><span class="ar">ابتّ↓</span></span>, as in the phrase, <span class="ar long">ابتّ يَمِينَهُ</span> <em>He made his oath to have,</em> or <em>take, effect; he executed,</em> or <em>performed, it.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bt_1_A10">
					<p><span class="ar long">سَكْرِانُ مَا يَبُتُّ كَلَامًا</span>, <span class="auth">(Ks, T, M,)</span> and <span class="ar long">ما يَبِتُّ</span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar long">ما يُبِتُّ↓</span></span>, <span class="auth">(Ks, T, M,)</span> <em>One who is drunk, who does not speak plainly,</em> or <em>distinctly;</em> lit., <em>who does not make speech plain,</em> or <em>distinct;</em> <span class="auth">(Ks, T;)</span> or <em>who does not articulate speech;</em> syn. <span class="ar long">مَا يَقْطَعُهُ</span>: <span class="auth">(M:)</span> <span class="pb" id="Page_0148"></span>or, as Aṣ says, <span class="auth">(T,)</span> <span class="ar long">سَكْرَانُ مَا يَبُتُّ</span>, <span class="auth">(T, A,)</span> or <span class="ar long">لَا يَبُتُّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar long">لا يَبِتُّ</span>, and<span class="arrow"><span class="ar long">لا يُبَتُّ↓</span></span>, <span class="auth">(Ḳ,)</span> which last form of the verb is disallowed by Aṣ, but both are correct accord. to Fr, <span class="auth">(T, Ṣ,)</span> meaning <em>one who is drunk, who does not,</em> or <em>will not,</em> <span class="add">[i. e. <em>cannot,</em>]</span> <em>decide an affair.</em> <span class="auth">(Aṣ, T, Ṣ, Ḳ.)</span> <span class="add">[<a href="#baAtBN">See also <span class="ar">بَاتٌّ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bt_1_B1">
					<p><a href="#bt_7">See also 7</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bt_1_B2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَتّتْ يَمِينُهُ</span>, <span class="auth">(M, Mṣb,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِتُ</span>}</span></add> only, inf. n. <span class="ar">بُتُوتٌ</span>, <span class="auth">(Mṣb,)</span> <em>His oath bad,</em> or <em>took, effect; was executed,</em> or <em>performed;</em> syn. <span class="ar">وَجَبَتْ</span>: <span class="auth">(M:)</span> <em>it was,</em> or <em>proved, true:</em> <span class="auth">(Mṣb:)</span> a phrase mentioned by AZ, and, if correct, not needing any explanation. <span class="auth">(M.)</span> <span class="add">[<a href="#AbtB">See <span class="ar long">ابتّ يَمِينَهُ</span>, above</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bt_1_C1">
					<p><span class="ar">بَتَّ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِتُ</span>}</span></add>, inf. n. <span class="ar">بُتُوتٌ</span>, <em>He was,</em> or <em>became, lean,</em> or <em>meagre.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#baAtBN">See <span class="ar">بَاتٌّ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bt_1_D1">
					<p><span class="ar">بَتٌّ</span> <span class="add">[inf. n. of <span class="ar">بَتَّ</span>]</span> also signifies The <em>selling,</em> and the <em>weaving, a</em> <span class="add">[<em>garment of the kind called</em>]</span> <span class="ar">طَيْلَسَان</span> <span class="add">[or <span class="ar">بَتّ</span>, q. v.]</span>. <span class="auth">(KL.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bt_2">
				<h3 class="entry">2. ⇒ <span class="ar">بتّت</span></h3>
				<div class="sense" id="bt_2_A1">
					<p><span class="ar">بتّتهُ</span>, inf. n. <span class="ar">تَبْتِيتٌ</span>, <em>He cut it off,</em> or <em>severed it,</em> <span class="add">[<em>entirely,</em> or <em>utterly, and</em>]</span> <em>much,</em> or <em>with extraordinary energy</em> or <em>effectiveness;</em> the teshdeed denoting intensiveness of signification. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bt_2_B1">
					<p><span class="ar">بَتَّتُوهُ</span> <em>They furnished him with</em> <span class="add">[<span class="ar">بَتَات</span>, or]</span> <em>travel-ling-provisions.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bt_2_C1">
					<p><span class="ar">بَتِّتْهُمْ</span> <em>Give thou to them</em> <span class="add">[<em>garments called</em>]</span> <span class="ar">بُتُوت</span> <span class="add">[<a href="#batBu">pl. of <span class="ar">بَتُّ</span>, q. v.</a>]</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bt_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابتّ</span></h3>
				<div class="sense" id="bt_4_A1">
					<p><a href="#bt_1">see 1</a>, passim:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bt_4_B1">
					<p><a href="#bt_7">and see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bt_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبتّت</span></h3>
				<div class="sense" id="bt_5_A1">
					<p><span class="ar">تبتّت</span> <em>He became furnished with</em> <span class="add">[<span class="ar">بَتَات</span>, or]</span> <em>travelling provisions:</em> and <em>he became provided with</em> <span class="add">[<span class="ar">بَتَات</span>, or]</span> <em>utensils and furniture of the house</em> or <em>tent;</em> or <em>household goods.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bt_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبتّ</span></h3>
				<div class="sense" id="bt_7_A1">
					<p><span class="ar">انبتّ</span> <em>It was,</em> or <em>became, cut off, severed, separated,</em> or <em>disunited,</em> <span class="auth">(Lth, T, Ṣ, M, Mṣb, Ḳ,)</span> <em>entirely,</em> or <em>utterly;</em> <span class="auth">(Lth, T, M;)</span> namely, a thing; <span class="auth">(M;)</span> a rope, or cord; <span class="auth">(Lth, T;)</span> and a tie, or bond, of union between two persons: <span class="auth">(T, M:*)</span> as also<span class="arrow"><span class="ar">بَتَّ↓</span></span>, <span class="auth">(Lth, AZ, T, M, Mṣb,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِتُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْتُتُ</span>}</span></add> <span class="auth">(M, <span class="add">[so accord. to a copy of that work, but it seems to be indicated in the Mṣb (<a href="#bt_1">see 1</a>, near the close of the paragraph,)</span> that it is <span class="ar">ـِ</span> only, in this case,]</span>) inf. n. <span class="ar">بَتٌّ</span>; <span class="auth">(Lth, AZ, T, M, Ḳ;)</span> and<span class="arrow"><span class="ar">ابتّ↓</span></span>, <span class="auth">(T, Mṣb, TA,)</span> inf. n. <span class="ar">إِبْتَاتٌ</span>; <span class="auth">(T, TA;)</span> the last said by Lth and AZ to be trans. only; <span class="auth">(T, TA;)</span> but it is both trans. and intrans., like the second: <span class="auth">(T, Mṣb, TA:)</span> so says En-Nawawee, as mentioned above: <a href="#bt_1">see 1</a>. <span class="auth">(TA.)</span> You say, <span class="ar long">اِنْقَطَعَ فُلَانٍ فَٱنْبَتَّ حَبْلُهُ عَنْهُ</span> <span class="add">[<em>Such a one broke off,</em> or <em>disunited himself, from such a one, and his tie,</em> or <em>bond, of union became severed from him</em>]</span>. <span class="auth">(T, TA, <span class="add">[but in a copy of the former, for <span class="ar long">عن فلان</span>, is put <span class="ar long">عَنْ مَالِهِ</span> <em>from his property.</em>]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bt_7_A2">
					<p><em>He became unable to proceed in his journey, his camel that bore him breaking down, or stopping from fatigue, or perishing:</em> <span class="auth">(A,* Mgh,* TA:)</span> <a href="#bt_1">quasi-pass. of <span class="ar">بَتَّهُ</span></a> <a href="#bt_4">and <span class="ar">أَبَتَّهُ</span></a>. <span class="auth">(TA.)</span> You say, <span class="ar long">سَارَ حَتَّى ٱنْبَتَّ</span> <em>He journeyed until he was unable to proceed</em>, &amp;c. <span class="auth">(A, Mgh, TA.)</span> <span class="add">[<a href="#munobatBN">See also <span class="ar">مُنْبَتٌّ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bt_7_A3">
					<p><em>His</em> <span class="ar">مَآء</span>, <span class="auth">(A,)</span> <em>the</em> <span class="ar">مآء</span> <em>of his back,</em> <span class="auth">(Ks, T, Ḳ,)</span> <span class="add">[i. e. <em>his seminal fluid,</em>]</span> <em>became cut off,</em> or <em>stopped,</em> or <em>ceased,</em> <span class="auth">(Ks, T, A, Ḳ,)</span> <em>by reason of age:</em> <span class="auth">(A:)</span> said of a man. <span class="auth">(Ks, T, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batBN">
				<h3 class="entry"><span class="ar">بَتٌّ</span></h3>
				<div class="sense" id="batBN_A1">
					<p><span class="ar">بَتٌّ</span> <a href="#bt_1">inf. n. of 1, q. v.</a> <span class="auth">(Lth, T, Ṣ, M, &amp;c.)</span> <span class="add">[It is sometimes used as an inf. n.; as also<span class="arrow"><span class="ar">بَتّةٌ↓</span></span> and<span class="arrow"><span class="ar">بَتَاتٌ↓</span></span>, explained in the M as syn. with <span class="ar">قَطْعٌ</span>: and sometimes, as is often the case with inf. ns., in the sense of the act. part. n. of its verb, namely <span class="arrow"><span class="ar">بَاتٌّ↓</span></span>, trans. and intrans.; as also<span class="arrow"><span class="ar">بَتَاتٌ↓</span></span>; both of which are masc. and fem., because originally inf. ns.; but <span class="ar">بَتٌّ</span> has also <span class="ar">بَتَّةٌ</span> for its fem. The following are exs.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batBN_A2">
					<p><span class="ar long">أَعْطَيْتُهُ هٰذِهِ العَطِيَّةَ بَتَّا بَتْلًا</span> <span class="add">[<em>I gave him this gift, cutting it off from my property so as to make it irrevocable;</em> or, <em>it being cut off</em>, &amp;c.]</span>. <span class="auth">(Lth, T.)</span> And<span class="arrow"><span class="ar long">تَصَدَّقَفُلَانٌ صَدَقَةً بَتَاتًا↓</span></span>, and <span class="ar long">صَدَقَةً بَتَّةً بَتْلَةُ</span>, <span class="auth">(T, Ṣ,)</span> <em>Such a one bestowed an alms,</em> or <em>a gift for the sake of God, cut off from his property;</em> <span class="auth">(T, TA;)</span> and therefore, <span class="auth">(TA,)</span> <em>parted from himself.</em> <span class="auth">(Ṣ, TA.)</span> Such a gift is termed <span class="ar long">صَدَقَةٌ بَتَّةٌ</span>, <span class="auth">(A,* Nh,)</span> and <span class="ar long">صدقة بَتَّةٌ بَتْلَةٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="batBN_A3">
					<p><span class="ar">طَلَّقَهَا</span>, <span class="auth">(Mgh, Ḳ,)</span> and<span class="arrow"><span class="ar">بَتَاتًا↓</span></span>, <span class="auth">(Ḳ,)</span> and <span class="ar">البَتَّةَ</span>, <span class="auth">(T,)</span> and <span class="ar long">طَلْقَةً بَتَّةً</span>, <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar long">طَلَاقًا بَاتَّا↓</span></span>, <span class="auth">(Lth, T, Mṣb,* TA, <span class="add">[in one copy of the T simply <span class="ar">بَاتَّا</span>,]</span>)</span> <em>He divorced her by a separating divorce;</em> <span class="auth">(Ḳ;)</span> <em>by a divorce cutting her off from returning:</em> and such a divorce is also termed <span class="arrow"><span class="ar long">طلاق مُبِتٌّ↓</span></span>: <span class="auth">(Mṣb:)</span> or the first of these phrases signifies <em>he divorced her by a divorce</em> either <em>cut off,</em> <span class="add">[<em>meaning decided and irrevocable,</em>]</span> or <em>cutting off.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">طَلَّقَهَا ثَلَاثًا بَتَّةً</span>, <span class="auth">(Aṣ, T, Ṣ, M, Mṣb,)</span> and<span class="arrow"><span class="ar">بَتَاتًا↓</span></span>, <span class="auth">(M,)</span> <em>He divorced her by three divorces so as to cut her off from returning:</em> <span class="auth">(M, Mṣb:)</span> or <em>by three divorces cut off from himself</em> <span class="add">[<em>so as to be irrevocable</em>]</span>: <span class="auth">(Ṣ:)</span> or <em>by three divorces cutting off</em> <span class="add">[<em>from returning</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="batBN_A4">
					<p><span class="ar long">حَلَفَ بَتَّا</span>, and <span class="ar">بَتَّةً</span>, and<span class="arrow"><span class="ar">بَتَاتًا↓</span></span>, <span class="add">[may mean <em>He swore decidedly,</em> or <em>decisively;</em> or <em>irrevocably:</em> or]</span> <em>he swore with effect,</em> or <em>execution,</em> or <em>performance;</em> <span class="add">[<a href="#bt_1">see 1</a>, near the end of the paragraph;]</span> from the signification of “cutting,” or “cutting off,”, &amp;c.: <span class="auth">(M:)</span> <span class="add">[or, as also]</span> <span class="ar long">حَلَفَ يَمِينًا بَتًّا</span>, and <span class="ar">بَتَّةً</span>, <span class="auth">(Mṣb, TA,)</span> and<span class="arrow"><span class="ar">بَاتَّةً↓</span></span>, <span class="auth">(Mgh,* Mṣb,)</span> and<span class="arrow"><span class="ar">بَتَاتًا↓</span></span>, <span class="auth">(TA,)</span> <em>he swore an oath that was,</em> or <em>proved, true.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="batBN_A5">
					<p><span class="ar long">طَحَنَ بِالرَّحَى بَتًّا</span> <em>He ground with the mill, turning it,</em> <span class="auth">(AZ, T,)</span> or <em>beginning the turning,</em> <span class="auth">(Ṣ,)</span> <em>from his left:</em> <span class="auth">(AZ, T, Ṣ:)</span> <span class="add">[i. e., making it to turn in the contrary way of the hands of a watch: the last word is app. an inf. n.; as though meaning <em>effectually;</em> for this is the general and easier or more powerful way of turning the handmill:]</span> the contrary way is termed <span class="ar">شَزْرًا</span>: <span class="auth">(AZ, T, Ṣ:*)</span> or <span class="ar long">طَحَنَ بَتَّا</span> signifies <em>he began in the turning</em> <span class="add">[<em>of the mill</em>]</span> <em>with the left</em> <span class="add">[<em>hand</em>]</span>. <span class="auth">(Ḳ: <span class="add">[but <span class="ar">بِاليَسَارِ</span> is here evidently put by mistake for <span class="ar long">عَنِ اليَسَارِ</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="batBN_B1">
					<p><em>A kind of</em> <span class="ar">طَيْلَسَان</span> <span class="add">[q. v.]</span> <em>called</em> <span class="ar">سَاج</span>, <span class="auth">(Lth, T,)</span> or <em>a</em> <span class="add">[<em>garment of the kind called</em>]</span> <span class="ar">كِسَآء</span>, <span class="auth">(M, Mgh,)</span> <em>square,</em> or <em>four-sided,</em> <span class="auth">(Lth, T, M,)</span> <em>thick,</em> <span class="auth">(Lth, T, M, Mgh,)</span> <em>loose,</em> or <em>uncompact, in texture,</em> <span class="auth">(M,)</span> <em>and green</em> <span class="add">[or rather <em>of a dingy ash-colour,</em> or <em>dark dust-colour,</em> for such is the general meaning of <span class="ar">أَخْضَرُ</span>, the term here used, when applied to a garment of this kind]</span>; <span class="auth">(Lth, T, M;)</span> or, as some say, <span class="auth">(M,)</span> <em>of</em> <span class="add">[<em>the soft hair termed</em>]</span> <span class="ar">وَبَر</span>, and <em>of wool;</em> <span class="auth">(M, Mgh;)</span> and thus described in the Kifáyet el-Mutaḥaffiḍh: <span class="auth">(TA:)</span> or <em>a</em> <span class="ar">طيلسان</span> <em>of</em> <span class="add">[<em>the material termed</em>]</span> <span class="ar">خَزّ</span>, <span class="auth">(Ṣ Mgh, Ḳ,)</span> and <em>the like:</em> <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">بُتُوتٌ</span>, <span class="auth">(Lth, T, Ṣ, Mgh,)</span> or <span class="ar">بِتَاتٌ</span>, <span class="auth">(M,)</span> but the former occurs in trads. <span class="add">[&amp;c.]</span>, <span class="auth">(TA,)</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">أَبُتٌّ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batBapN">
				<h3 class="entry"><span class="ar">بَتَّةٌ</span></h3>
				<div class="sense" id="batBapN_A1">
					<p><span class="ar">بَتَّةٌ</span>: <a href="#batBN">see <span class="ar">بَتٌّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batBapN_A2">
					<p><span class="ar long">لَا أَفْعَلُهُ ٱلْبَتَّةَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> as also <span class="ar">بَتَّةً</span>, <span class="auth">(Ṣ, Ḳ,)</span> the latter mentioned by IF, <span class="auth">(Mṣb,)</span> but IB says that Sb and his companions allow only the former, and that only Fr allows the latter, <span class="auth">(TA,)</span> and some say that the former has been heard pronounced with the disjunctive. <span class="add">[<span class="ar">اَلْبَتَّةَ</span>]</span>, <span class="auth">(MF,)</span> and thus it is written in a copy of the Ḳ, <span class="auth">(TA,)</span> but others greatly disapprove of this, <span class="auth">(MF,)</span> <span class="add">[meaning <em>I will not do it, decidedly,</em> or <em>absolutely,</em>]</span> is said of anything in respect of which there is no returning, or revoking; <span class="auth">(Ṣ, IF, M, Mṣb, Ḳ;)</span> <span class="ar">الَبتَّةَ</span> being said of a thing to be done, or performed, irrevocably, and from which there is no abstaining by reason of sluggishness; <span class="auth">(T;)</span> as though the speaker cut off the doing of the thing: <span class="auth">(M:)</span> the last word is in the accus. case as an inf. n.: <span class="auth">(Ṣ:)</span> Sb says, it is a corroborative inf. n., and is not used without <span class="ar">ال</span>. <span class="auth">(M.)</span> It is said in a trad., <span class="ar long">أَحْسِبُهُ قَالَ جُوَيْرِيَة أَوِ ٱلْبَةَ قَالَ</span> <span class="add">[<em>I think he said Juweyriyeh, or decidedly he said so</em>]</span>; as though the speaker doubted of the female's name, and said, “I think it was Juweyriyeh;” then corrected, and said, “or I know,” or “declare,” “decidedly, (<span class="ar">أَبُتُّ</span>, i. e. <span class="ar">أَقْطَعُ</span>,) that he said Juweyriyeh: I do not <span class="add">[merely]</span> think.” <span class="auth">(Saheeh of Muslim.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bataAtN">
				<h3 class="entry"><span class="ar">بَتَاتٌ</span></h3>
				<div class="sense" id="bataAtN_A1">
					<p><span class="ar">بَتَاتٌ</span>: <a href="#batBN">see <span class="ar">بَتٌّ</span></a>, in seven places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتَاتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bataAtN_A2">
					<p>A man is said to be <span class="ar long">عَلَى بَتَاتِ أَمْرٍ</span>, meaning <em>On the point of</em> <span class="add">[<em>accomplishing,</em> or <em>deciding,</em>]</span> <em>an affair.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> A rájiz says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَحَاجَةٍ كُنْتُ عَلَى بَتَاتِهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Many a needful affair I was on the point of accomplishing</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتَاتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bataAtN_B1">
					<p><em>Travelling provisions:</em> <span class="auth">(Ṣ, M, A, Ḳ:)</span> and <em>requisites, equipments,</em> or <em>furniture;</em> syn. <span class="ar">جَهَازٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">أَبِتَّةٌ</span>. <span class="auth">(Ṣ.)</span> A verse of Tarafeh cited voce <span class="ar">بَاعَ</span> exhibits an ex. of the former signification. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَتَاتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bataAtN_B2">
					<p>Also The <em>utensils and furniture of the house</em> or <em>tent;</em> or <em>household goods:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> pl. as above. <span class="auth">(Ḳ.)</span> It is said in a trad., <span class="ar long">لَا يُؤْخَذُ مِنْكُمْ عُشْرُ البَتَاتِ</span> <span class="add">[<em>The tithe of the utensils</em>, &amp;c. <em>of the house or tent shall not be taken from you</em>]</span>: <span class="auth">(Ṣ:)</span> i. e., no poor-rate shall be levied upon such utensils, &amp;c. that are not for traffic. <span class="auth">(AʼObeyd.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="batBaeBN">
				<h3 class="entry"><span class="ar">بَتَّىٌّ</span></h3>
				<div class="sense" id="batBaeBN_A1">
					<p><span class="ar">بَتَّىٌّ</span>: <a href="#batBaAtN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batBaAtN">
				<h3 class="entry"><span class="ar">بَتَّاتٌ</span></h3>
				<div class="sense" id="batBaAtN_A1">
					<p><span class="ar">بَتَّاتٌ</span> <span class="auth">(Ṣ, Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">بَتِّىٌّ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> <em>A maker,</em> <span class="auth">(Ṣ,)</span> or <em>seller, of the kind of garment called</em> <span class="ar">بَتّ</span>. <span class="auth">(Ṣ, Mgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAtBN">
				<h3 class="entry"><span class="ar">بَاتٌّ</span></h3>
				<div class="sense" id="baAtBN_A1">
					<p><span class="ar">بَاتٌّ</span>: <a href="#batBN">see <span class="ar">بَتٌّ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَاتٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAtBN_A2">
					<p><em>Cut off from</em> <span class="add">[<em>the possession of</em>]</span> <em>reason,</em> or <em>intellect, by drunkenness:</em> <span class="auth">(AḤn, M:)</span> or <em>drunken:</em> <span class="auth">(Ḳ:)</span> and <em>stupid,</em> or <em>foolish:</em> <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar long">أَحْمَقُ بَاتٌّ</span> signifies <em>very stupid</em> or <em>foolish,</em> <span class="auth">(T, M,)</span> accord. to Lth; but <span class="add">[Az adds,]</span> what we remember to have heard from those deserving of confidence is <span class="ar">تَابٌّ</span>, from <span class="ar">التَّبَابُ</span>, meaning <span class="ar">الخَسَارُ</span>; <span class="pb" id="Page_0149"></span>like as one says, <span class="ar long">أَحْمَقُ خَاسِرٌ دَابِرٌ دَامِرٌ</span> <span class="add">[<a href="index.php?data=07_x/073_xsr">explained in art. <span class="ar">خسر</span></a>]</span>. <span class="auth">(T.)</span> <span class="add">[<a href="#bt_1">See also 1</a>, near the end of the paragraph.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بت</span> - Entry: <span class="ar">بَاتٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAtBN_A3">
					<p>Also <em>Lean,</em> or <em>meagre,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>and unable to rise,</em> or <em>stand.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubitBN">
				<h3 class="entry"><span class="ar">مُبِتٌّ</span></h3>
				<div class="sense" id="mubitBN_A1">
					<p><span class="ar long">طَلَاقٌ مُبِتٌّ</span>: <a href="#batBN">see <span class="ar">بَتٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabotuwtapN">
				<h3 class="entry"><span class="ar">مَبْتُوتَةٌ</span></h3>
				<div class="sense" id="mabotuwtapN_A1">
					<p><span class="ar">مَبْتُوتَةٌ</span> A woman <em>absolutely separated by divorce, so as to be cut off from return:</em> originally <span class="ar long">مَبْتُوتٌ طَلَاقُهَا</span>. <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="munobatBN">
				<h3 class="entry"><span class="ar">مُنْبَتٌّ</span></h3>
				<div class="sense" id="munobatBN_A1">
					<p><span class="ar">مُنْبَتٌّ</span> A man <em>unable to proceed in his journey, his camel that bore him having broken down, or stopped from fatigue, or perished;</em> <span class="auth">(T, M,* TA;)</span> syn. <span class="ar long">مُنْقَطَعٌ بِهِ</span>: <span class="auth">(Ṣ, Mgh, TA:)</span> or <em>who remains on his road unable to attain the place to which he is directing his course, the beast</em> or <em>camel that bore him</em> (<span class="ar">ظَهْرُهُ</span>) <em>having broken down, or stopped from fatigue, or perished.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0147.pdf" target="pdf">
							<span>Lanes Lexicon Page 147</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0148.pdf" target="pdf">
							<span>Lanes Lexicon Page 148</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0149.pdf" target="pdf">
							<span>Lanes Lexicon Page 149</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
