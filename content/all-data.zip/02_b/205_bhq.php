<article class="root" id="Root_bhq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/204_bhZ">بهظ</a></span>
				<span class="ar">بهق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/206_bhl">بهل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهق</span></h3>
				<div class="sense" id="bhq_1_A1">
					<p><span class="ar">بَهِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَقُ</span>}</span></add>, inf. n. <span class="ar">بَهَقٌ</span>, <em>It</em> <span class="auth">(the body)</span> <em>was,</em> or <em>became, affected with</em> <span class="add">[<em>the disease termed</em>]</span> <span class="ar">بَهَقٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahaqN">
				<h3 class="entry"><span class="ar">بَهَقٌ</span></h3>
				<div class="sense" id="bahaqN_A1">
					<p><span class="ar">بَهَقٌ</span> <span class="add">[The <em>mild species of leprosy termed “alphus,” or “vitiligo alba;” in Hebrew</em> <span class="he">בֹּחַק</span>;]</span> <em>a whiteness, less than what is termed</em> <span class="ar">بَرَصٌ</span>, <em>that comes upon the external skin of a man;</em> <span class="auth">(JK;)</span> <em>a whiteness that affects the skin,</em> <span class="auth">(Ṣ,)</span> or <em>body,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>differing from the colour of the latter;</em> <span class="auth">(Ṣ, Mṣb;)</span> <em>not from what is termed</em> <span class="ar">بَرَص</span>, <span class="auth">(Ṣ, Mgh,)</span> or <em>not</em> <span class="ar">بَرَص</span>: <span class="auth">(Mṣb:)</span> and, accord. to IF, <em>a blackness that affects the skin;</em> <span class="add">[i. e. the <em>species of leprosy termed “melas,” or “lepra maculosa nigra;”</em>]</span> or <em>a colour differing from that of the skin:</em> <span class="auth">(Mṣb:)</span> <em>a thin whiteness that affects the exterior of the cuticle, by reason of a bad state of the temperament of the part, inclining to coldness, and the predominance of the phlegm over the blood: the black</em> <span class="add">[<em>species</em>]</span> <em>thereof alters</em> (<span class="ar">يُغَيِّرُ</span>, in the CK <span class="ar">يَعْتَرِى</span>,) <em>the skin to blackness, by reason of the mixing of the black bile with the blood.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهق</span> - Entry: <span class="ar">بَهَقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahaqN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَهَقُ الحَجَرِ</span> † <span class="add">[<em>Lichen,</em> or <em>liverwort;</em>]</span> <em>a certain plant;</em> <span class="auth">(Ḳ;)</span> i. e. <span class="ar long">حَزَّازُ الحَجَرِ</span> <span class="add">[more commonly called <span class="ar long">حَزَّازُ الصَّخْرِ</span>]</span>: <span class="auth">(TA:)</span> or <em>i. q.</em> <span class="ar long">الجَوْزُ الجَنْدُمَ</span>, <span class="auth">(Ḳ, TA,)</span> or <span class="ar long">الجَوْزَ جَنْدُمَ</span>, <span class="auth">(CK,)</span> <span class="add">[evidently from the Persian <span class="ar long">جَوْزِ گَنْدُمَ</span> explained in Johnson's Pers. Ar. and Engl. Dict. as “sandix-gum, juniper:” but SM says that]</span> this is <em>a certain plant, the body</em> <span class="add">[or <em>substance</em>]</span> <em>of which is</em> <span class="ar">مُحَبَّب</span> <span class="add">[app. meaning <em>composed of globules</em> or <em>the like;</em> probably <em>a particular species of lichen, with spherical cells</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabohaqu">
				<h3 class="entry"><span class="ar">أَبْهَقُ</span></h3>
				<div class="sense" id="Oabohaqu_A1">
					<p><span class="ar">أَبْهَقُ</span>, applied to a man, <em>Affected with</em> <span class="add">[<em>the disease termed</em>]</span> <span class="ar">بَهَقٌ</span>: <span class="auth">(JK, Mṣb:)</span> fem. <span class="ar">بَهْقَآءُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهق</span> - Entry: <span class="ar">أَبْهَقُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabohaqu_A2">
					<p><span class="add">[And hence,]</span> so applied, † <em>Very white.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0267.pdf" target="pdf">
							<span>Lanes Lexicon Page 267</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
