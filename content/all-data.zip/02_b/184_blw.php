<article class="root" id="Root_blw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/183_blh">بله</a></span>
				<span class="ar">بلو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/185_blwr">بلور</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلو</span> ⇒ <span class="ar">بلى</span></h3>
				<div class="sense" id="blw_1_A1">
					<p><span class="ar">بَلَاهُ</span>, <span class="auth">(T, Ṣ, Mgh, Mṣb,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُوُ</span>}</span></add>, <span class="auth">(T, Mṣb,)</span> inf. n. <span class="ar">بَلَآءٌ</span>, <span class="auth">(Ṣ,)</span> or this is a simple subst., and the inf. n. is <span class="ar">بَلْوٌ</span>, <span class="auth">(T, Mṣb,)</span> <em>He</em> <span class="auth">(God)</span> <em>tried, proved,</em> or <em>tested, him,</em> <span class="auth">(T, Ṣ, Mṣb,)</span> <span class="ar">بِخَيْرٍ</span> <span class="add">[<em>by,</em> or <em>with, good</em>]</span>, or <span class="ar">بِشَّرٍ</span> <span class="add">[<em>by,</em> or <em>with, evil</em>]</span>; <span class="auth">(Mṣb;)</span> for God tries his servant (<span class="ar">يَبْلُوهُ</span>) by, or with, a benefit, to test his thankfulness; and by, or with, a calamity, to test his patience; <span class="auth">(T;)</span> <span class="add">[wherefore it often means <em>He afflicted him;</em>]</span> as also<span class="arrow"><span class="ar">ابلاهُ↓</span></span>, <span class="auth">(T, Ṣ, Mṣb,)</span> inf. n. <span class="ar">إِبْلَآءٌ</span>; <span class="auth">(T, Ṣ; <span class="add">[in both restrieted to good; but in the Mṣb it seems to be common to good and evil;]</span>)</span> and<span class="arrow"><span class="ar">ابتلاه↓</span></span>: <span class="auth">(T, Ṣ, M, Mṣb:)</span> and <span class="ar">بَلَوْتُهُ</span>, inf. n. <span class="ar">بَلْوٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بَلَآءٌ</span>, <span class="auth">(M, Ḳ,)</span> <span class="add">[but from what has been said above, it seems that the latter is used only when the agent is God, and that it is properly a simple subst.,]</span> <em>I tried, proved,</em> or <em>tested, him;</em> <span class="auth">(Ṣ, M, Mgh,* Ḳ;)</span> as also<span class="arrow"><span class="ar">اِبْتَلَيْتُهُ↓</span></span>: <span class="auth">(M, Ḳ:)</span> each of these verbs implying two things; one of which is the learning the state, or condition, of the object, and becoming acquainted with what was unknown of the case thereof; and the other, the manifesting of the goodness or badness thereof; both of these things being sometimes meant, and sometimes only one of them, as when God is the agent, in which case only the latter is meant: <span class="auth">(Er-Rághib, TA:)</span> and<span class="arrow"><span class="ar">التَّبَالِى↓</span></span>, also, signifies <em>the act of trying, proving,</em> or <em>testing.</em> <span class="auth">(Ṣ.)</span> It is said in the Ḳur <span class="add">[xxi. 36]</span>, <span class="ar long">وَنَبْلُوكُمْ بِٱلشَّرِ وَٱلخَيْرِ فِتْنَةً</span> <span class="add">[<em>And we try you by,</em> or <em>with, evil and good, by way of probation</em>]</span>. <span class="auth">(TA.)</span> And in the same <span class="add">[ii. 118]</span>, <span class="arrow"><span class="ar long">وَإِذَ ٱبْتَلَى↓ إِبْرَاهِيمَ رَبُّهُ بِكَلَمَاتٍ</span></span> <span class="add">[<em>And when his Lord tried Abraham by</em> certain <em>words,</em> meaning commands and prohibitions]</span>. <span class="auth">(TA.)</span> And you say,<span class="arrow"><span class="ar long">لَا تُبْلِنَا↓ إِلَّا بِٱلَّتِى هِىَ أَحْسَنُ</span></span> <span class="add">[<em>Try Thou not us save by those things that are best</em>]</span>; <span class="auth">(T;)</span> from a trad. <span class="auth">(TA.)</span> <span class="add">[<a href="#blw_4">See also 4</a> <a href="#blw_8">and 8 below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blw_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">بَلَوْتُهُ</span> also signifies ‡ <em>I smelt it.</em> <span class="auth">(T in art. <span class="ar">بول</span>, and A and TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blw_1_A3">
					<p><span class="add">[And <span class="ar">بَلَاهُ</span> <em>He knew it,</em> or <em>became acquainted with it.</em> (<a href="#baAlK">See <span class="ar">بَالٍ</span></a>.)]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="blw_1_A4">
					<p><a href="#blw_4">See also 4</a>, in the latter half of the paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blw_1_B1">
					<p><span class="ar">بَلِى</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَوُ</span>}</span></add>, inf. n. <span class="ar">بِلًا</span>, or <span class="ar">بِلًى</span>, <span class="add">[in the CK, erroneously, <span class="ar">بَلًى</span>,]</span> and <span class="ar">بَلَآءٌ</span>, <span class="add">[in the CK, erroneously, <span class="ar">بِلاء</span>,]</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> the former with kesr and the latter with fet-ḥ, <span class="auth">(T, Ṣ, Mṣb,)</span> said of a garment, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> <em>It was,</em> or <em>became, old, and worn out:</em> <span class="auth">(Mṣb:)</span> belonging to the present art. and to art. <span class="ar">بلى</span>. <span class="auth">(M.)</span> <span class="add">[The inf. n., used as a subst., signifies <em>Wear; attrition; wear and tear:</em> <a href="#AlA1">see an ex. in a hemistich cited near the end of the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=01_A/116_AlA">of art. <span class="ar">الا</span></a>, where a dwelling is likened to a garment.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="blw_1_B2">
					<p>Also said of a plant <span class="add">[as meaning <em>It became old and withered,</em> or <em>wasted</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">عنث</span>, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="blw_1_B3">
					<p>And of a corpse, meaning <em>It became consumed by the earth.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="blw_1_B4">
					<p>And of a bone, meaning <em>It became old,</em> and <em>decayed;</em> syn. <span class="ar">رَمَّ</span>. <span class="auth">(Ṣ and Ḳ, &amp;c. in art. <span class="ar">رم</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="blw_1_B5">
					<p>And of a man's reputation, meaning † <em>It became worn out of regard or notice.</em> <span class="auth">(TA in art. <span class="ar">دثر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B6</span>
				</div>
				<div class="sense" id="blw_1_B6">
					<p>And <span class="add">[hence,]</span> <span class="ar">بَلِيَتْ</span>, <span class="auth">(M,)</span> or <span class="ar">بُلِيَتْ</span>, <span class="auth">(Ḳ,)</span> <em>She</em> <span class="auth">(a camel, M, Ḳ, or a mare, or beast of the equine kind, M)</span> <em>was,</em> or <em>became, a</em> <span class="ar">بَلَيِّة</span>; i. e., <em>was tied at her dead master's grave</em> <span class="auth">(M, Ḳ)</span> <em>without food or water</em> <span class="auth">(M)</span> <em>until she died</em> <span class="auth">(M, Ḳ)</span> <em>and wasted away.</em> <span class="auth">(M in art. <span class="ar">بلى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blw_2">
				<h3 class="entry">2. ⇒ <span class="ar">بلّو</span> ⇒ <span class="ar">بلّى</span></h3>
				<div class="sense" id="blw_2_A1">
					<p><a href="#blw_4">see 4</a>, in six places, in the latter half of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blw_3">
				<h3 class="entry">3. ⇒ <span class="ar">بالو</span> ⇒ <span class="ar">بالى</span></h3>
				<div class="sense" id="blw_3_A1">
					<p><span class="ar long">لَا أَبَالِيهِ</span> is from <span class="ar">البلآء</span>, <span class="add">[<a href="#blw_1">inf. n. of <span class="ar">بَلَاهُ</span></a>,]</span> so that it signifies <span class="add">[properly]</span> <em>I shall not,</em> or <em>I do not, care for him, mind him, heed him,</em> or <em>regard him, so as to share with him my trial and his trial:</em> <span class="auth">(Ḥam p. 94:)</span> <span class="add">[and hence,]</span> one says thus, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> or <span class="ar long">مَا أَبَالِيهِ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar long">لَا أَبَالِىبِهِ</span>, <span class="auth">(Mgh, Mṣb,)</span> or <span class="ar long">مَا أُبَالِى بِهِ</span>, <span class="auth">(MF, TA,)</span> but the verb is more chastely made trans. without the preposition <span class="ar">بِ</span>, <span class="auth">(A, TA,)</span> inf. n. <span class="ar">مُبَالَاةٌ</span> <span class="auth">(M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بِلَآءٌ</span> <span class="auth">(M, Ḳ, TA <span class="add">[in the CK, erroneously, <span class="ar">بَلاء</span>]</span>)</span> and <span class="ar">بَالَةٌ</span> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> said by some to be a quasi-inf. n. and by others to be an inf. n., <span class="auth">(MF, TA,)</span> <span class="add">[in the T it is said to be a subst., from <span class="ar">المُبَالَاةُ</span>,]</span> originally <span class="ar">بَالِيَةٌ</span>, like <span class="ar">عَافِيَةٌ</span> from <span class="ar">عَافَاهُ</span>, <span class="auth">(T, Ṣ, Mgh, Mṣb,)</span> and <span class="ar">بَالٌ</span>, <span class="add">[which is more strange,]</span> <span class="auth">(M, Ḳ,)</span> meaning <span class="add">[merely]</span> <em>I shall not,</em> or <em>I do not, care for, mind, heed,</em> or <em>regard, him,</em> or <em>it;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> <em>I shall not be,</em> or <em>I am not, disquieted by him,</em> or <em>it:</em> <span class="auth">(Mgh, Mṣb:)</span> or, as some say, <span class="ar long">لَا أُبَالِيهِ</span> is formed by transposition from <span class="ar long">لَا أُبَاوِلُهُ</span>, from <span class="ar">البَالُ</span>, i. e. <em>I will not,</em> or <em>I do not, cause him,</em> or <em>it, to move,</em> or <em>occur to, my mind; nor give,</em> or <em>pay, any attention to him,</em> or <em>it:</em> <span class="auth">(Z, TA: <span class="add">[and the like is said in the T:]</span>)</span> or the proper <span class="add">[or literal]</span> meaning is, <em>I will not,</em> or <em>I do not, contend with him for superiority in goodness,</em> or <em>excellence, by reason of my little care,</em> or <em>regard, for him:</em> <span class="auth">(Mgh:)</span> or it was employed to denote the contending with another for superiority in glory, or excellence, as will be shown by the citation of a verse in the latter portion of this paragraph; and then, in consequence of frequency of usage, came to denote contempt, or mean estimation: <span class="auth">(Ḥam p. 31:)</span> or its original meaning is, <em>I will not,</em> or <em>I do not, strive with him to be first; neglecting him,</em> or <em>leaving him to himself;</em> from <span class="ar long">تَبَالَى القَوْمُ</span> as explained below; <a href="#blw_6">see 6</a>. <span class="auth">(Mṣb.)</span> It is said in a trad., <span class="ar long">لَا يُبَالِيهِمُ ٱللّٰهُ بَالَةً</span>, or, accord. to one reading, <span class="ar long">لَا يُبَالِى بِهِمْ بَالَةً</span>, meaning <em>God will not hold them to be of any value or weight.</em> <span class="auth">(TA.)</span> And in another, <span class="ar long">هٰؤُلآءِ فِى الجَنَّةِ وَلَا أُبَالِى وَهٰؤُلَآءِ فِى النَّارِ وَلَا أُبَالِى</span>, said to mean <span class="add">[<em>These</em> will be <em>in Paradise, and</em>]</span> <em>I shall not disapprove;</em> <span class="add">[<em>and these</em> will be <em>in the fire</em> of Hell,]</span> <em>and I shall not disapprove.</em> <span class="auth">(Az, TA.)</span> And one says, <span class="ar long">لَا أُبَالِى مَا صَنَعْتَ</span> <span class="add">[<em>I shall not,</em> or <em>I do not, care for what thou didst,</em> or <em>hast done</em>]</span>. <span class="auth">(IDrd, TA.)</span> And <span class="ar long">مَا أُبَالِى أَقُمْتَ أَمْ قَعَدْتَ</span> <span class="add">[<em>I care not whether thou stand or sit</em>]</span>: and <span class="ar long">مَا أُبَالِى بِقِيَامِكَ وَعَدَمِهِ</span> <span class="add">[<em>I care not for thy standing and thy not doing so</em>]</span>. <span class="auth">(Mughnee in art. <span class="ar">ا</span>.)</span> And <span class="ar long">مَا بَالَيْتُ بِهِ</span> <span class="auth">(AZ, Mṣb, TA)</span> <em>I did not care for, mind,</em> or <em>regard, him,</em> or <em>it.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَالَى بِالشَّىْءِ</span> <span class="add">[<em>He cared for the thing;</em> or]</span> <em>he was disquieted by the thing.</em> <span class="auth">(T.)</span> The verb is sometimes thus used, in an affirmative manner; <span class="auth">(Ḥam p. 94; <span class="add">[and the like is said in the TA;]</span>)</span> though some say that it is not; <span class="auth">(Mṣb;)</span> but it is not unless it occurs with a negative in the former part of the sentence or in the latter part thereof; as when one says, <span class="ar long">مَا بَالَى بِكَ صَدِيقُكَ وَلٰكِنْ بَالَى عَبْدُكَ</span> <span class="add">[<em>Thy friend cared not for thee, but thy slave cared</em>]</span>; and as in the saying of Zuheyr,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَقَدْ بَالَيْتُ مَظْعَنَ أُمِّ أَوْفَى</span> *</div> 
						<div class="star">* <span class="ar long">وَلٰكِنْ أُمُّ أَوْفَى لَا تُبَالِى</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Verily I cared for the departure of Umm-Owfà, but Umm-Owfà cares not</em>]</span>. <span class="auth">(Ḥam p. 94.)</span> One says also, <span class="ar long">لَمْ أُبَالِ</span> and <span class="ar long">لَمْ أُبَلْ</span> <span class="add">[<em>I did not care,</em>, &amp;c.]</span>: <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ: <span class="add">[but in the CK the latter of these is omitted:]</span>)</span> in the latter the <span class="ar">ا</span> <span class="add">[of prolongation]</span> is suppressed for the purpose of alleviating the utterance, like as <span class="ar">ى</span> is suppressed in the inf. n. <span class="add">[or quasi-inf. n.]</span> <span class="ar">بَالَةٌ</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> originally <span class="ar">بَالِيَةٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> and in <span class="ar long">لَا أَدْرِ</span>: <span class="auth">(Ṣ:)</span> or the <span class="ar">ا</span> is suppressed in this case to avoid the concurrence of two quiescent letters; <span class="auth">(Kh, Sb, M, IB;)</span> not for the purpose of alleviating the utterance; <span class="auth">(IB, TA;)</span> for this is done because the <span class="ar">ل</span> is made quiescent. <span class="auth">(Kh, Sb, M.)</span> And, accord. to Kh, <span class="auth">(Sb, M,)</span> some of the Arabs say, <span class="ar long">لَمْ أُبَلِهِ</span> <span class="add">[<em>I did not care for him,</em> or <em>it</em>]</span>, <span class="auth">(Sb, M,)</span> or <span class="ar long">لَمْ أُبَلِ</span>, <span class="add">[in the CK, erroneously, <span class="ar long">لم اَبْلِ</span>,]</span> with kesr to the <span class="ar">ل</span>; <span class="auth">(Ḳ, TA;)</span> <span class="add">[for <span class="ar long">لم أُبَالِهِ</span>, or <span class="ar long">لم أُبَالِ</span>;]</span> only suppressing the <span class="ar">ا</span>, as they do in <span class="ar">عُلَبِطٌ</span> <span class="add">[for <span class="ar">عُلَابِطٌ</span>]</span>. <span class="auth">(Sb, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blw_3_A2">
					<p>IAar says that <span class="ar">بَالَى</span>, inf. n. <span class="ar">مُبَالَاةٌ</span>, is like<span class="arrow"><span class="ar">أَبْلَى↓</span></span> meaning <em>He exerted himself in a description of a war,</em> or <em>battle, or of generous conduct;</em> as when one says, <span class="ar long">أَبْلَى ذٰلِكَ اليَوْمَ بَلَآءً حَسَنًا</span> <span class="add">[<em>He exerted himself well, that day, in a description of war,</em>, &amp;c.]</span>: and he cites the following verse <span class="add">[to which reference has been made above]</span>:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَا لِى أَرَاكَ قَائِمًا تُبَالِى</span> *</div> 
						<div class="star">* <span class="ar long">وَأَنْتَ قَدْ مَتَّ مِنَ الهُزَالِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>What hath happened to me that I see thee standing exerting thyself in a description of generous qualities, when thou hast become</em> like one <em>dead by reason of leanness?</em>]</span>: he says that he <span class="add">[the poet]</span> heard him <span class="add">[whom he thus addresses]</span> saying, “We have eaten and we have drunk <span class="add">[with guests]</span>, and we have done <span class="add">[such and such things]</span>;” enumerating, or recounting, generous qualities or actions, and lying in doing so: <span class="auth">(T, TA:)</span> in another place he says that <span class="ar">تُبَالِى</span> means <em>looking to see which of them</em> <span class="add">[or <em>of thee and others</em>]</span> <em>is best in</em> <span class="ar">بال</span> <span class="add">[i. e. <em>state,</em> or <em>condition</em>]</span>, <em>while thou art dying:</em> <span class="auth">(TA:)</span> he says, also, that <span class="ar">بَالَاهُ</span>, inf. n. <span class="ar">مُبَالَاةٌ</span>, signifies <em>he contended with him for superiority in glory,</em> or <em>excellence;</em> <span class="auth">(T, TA;*)</span> <span class="pb" id="Page_0256"></span>and <span class="add">[it is said that]</span> <span class="ar">تبالى</span> in the verse here cited means <em>thus contending;</em> syn. <span class="ar">تُفَاخِرُ</span>: <span class="auth">(Ḥam p. 31:)</span> and accord. to IAạr, <span class="ar">بَالَاهُ</span> also signifies <em>he contended with him in contradiction.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلو</span> ⇒ <span class="ar">ابلى</span></h3>
				<div class="sense" id="blw_4_A1">
					<p><span class="ar">ابلاهُ</span>, inf. n. <span class="ar">إِبْلَآءٌ</span>: <a href="#blw_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blw_4_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">ابلاهُ ٱللّٰهُ إِبْلَآءً حَسَنًا</span>, <span class="auth">(T,)</span> or <span class="ar long">بَلَآءَ حَسَنًا</span>, <span class="auth">(Ṣ,)</span> <em>God did to him a good deed.</em> <span class="auth">(T.)</span> <span class="add">[And hence,]</span> it is said in the Ḳur <span class="add">[viii. 17]</span>, <span class="ar long">وَلِيُبْلِىَ المُؤْمِنِينَ مِنْهُ بَلَآءً حَسَنُا</span> <span class="auth">(TA)</span> <em>And that He might confer upon the believers a great benefit,</em> or <em>favour,</em> or <em>blessing:</em> <span class="auth">(Bḍ:)</span> or <em>a good gift;</em> meaning spoil. <span class="auth">(Jel.)</span> And <span class="ar long">أَبْلَيْتُهُ مَعْرُوفًا</span> <span class="add">[<em>I conferred upon him a favour,</em> or <em>benefit</em>]</span>. <span class="auth">(Ṣ.)</span> Zuheyr says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">جَزَى ٱللّٰهُ بِا لإِحْسَانِ مَا فَعَلَا بِكُمْ</span> *</div> 
						<div class="star">* <span class="ar long">وَأَبْلَاهُمَا خَيْرَ البَلَآءِ الَّذِى يَبْلُو</span> *</div> 
					</blockquote>
					<p><span class="auth">(T,* Ṣ,)</span> meaning, <span class="ar long">الذى يَبْلُو بِهِ عِبَادَهُ</span>, <span class="auth">(T,)</span> or <span class="ar long">الذى يَخْتَبِرُ بِهِ عِبَادَ</span>, <span class="auth">(Ṣ,)</span> i. e. <span class="add">[<em>May God recompense with beneficence what they two have done to you,</em>]</span> <em>and do to them two the best of the deeds wherewith He tries</em> <span class="add">[the thankfulness of]</span> <em>his servants.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blw_4_A3">
					<p><span class="ar">ابلاهُ</span> also signifies <em>He made him to swear;</em> <span class="add">[as though he tried his veracity by so doing;]</span> <span class="auth">(M, Ḳ;)</span> or so <span class="ar long">ابلاهُ يَمِينًا</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#blw_8">See also 8</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="blw_4_A4">
					<p>And <em>He swore to him:</em> <span class="auth">(M, Ḳ:)</span> or this, <span class="auth">(TA,)</span> or <span class="ar long">ابلاهُ يَمِينًا</span>, <span class="add">[as above,]</span> <span class="auth">(T, Ṣ,)</span> <em>he swore</em> <span class="add">[or <em>swore an oath</em>]</span> <em>to him, and thereby soothed,</em> or <em>placated, his mind.</em> <span class="auth">(T, Ṣ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="blw_4_A5">
					<p>And hence, <span class="auth">(TA,)</span> <em>He informed him, acquainted him,</em> or <em>told him.</em> <span class="auth">(IAạr, M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="blw_4_A6">
					<p><span class="add">[And hence, <em>He manifested it; revealed it; made it manifest, apparent, evident, clear,</em> or <em>plain;</em> whence a phrase in a verse cited voce <span class="ar">مُضْمَرٌ</span>; and the phrase]</span> <span class="ar long">مَا لَمْ يُبْلِ العُذْرَ</span>, i. e. <em>As long as he does not manifest, show,</em> or <em>make apparent, the excuse:</em> but the verb <span class="add">[in this sense]</span> is originally doubly trans.: one says, <span class="ar long">أَبْلَيْتُ فُلَانًا عُذْرًا</span>, meaning <em>I manifested to such a one an excuse so that I was not to be blamed after it;</em> properly signifying <em>I made such a one to be acquainted with my excuse, and to know the manner thereof;</em> <span class="auth">(Mgh;)</span> and thus it is explained in the A: <span class="auth">(TA: <span class="add">[in like manner, also, it is explained in the T:]</span>)</span> <span class="add">[or]</span> <span class="ar long">ابلاهُ عُذْرًا</span> signifies <em>He gave him an excuse which he accepted:</em> <span class="auth">(M, Ḳ:)</span> and in like manner, <span class="ar long">ابلاهُ جُهْدَهُ</span> <span class="add">[<em>He gave him his endeavour,</em> or <em>energy, in an acceptable manner</em>]</span>; and <span class="ar">نَائِلَهُ</span> <span class="add">[<em>his gift</em>]</span>. <span class="auth">(M.)</span> Hence, <span class="ar long">ابلى عُذْرَهُ</span> signifies also <em>He strove, laboured,</em> or <em>exerted himself,</em> <span class="add">[and thus manifested his excuse,]</span> <em>in work.</em> <span class="auth">(Mgh.)</span> And hence, <span class="ar long">ابلى فِى الحَرْبِ</span> <em>He manifested,</em> or <em>showed, his might, valour,</em> or <em>prowess, in war,</em> or <em>fight,</em> <span class="add">[and <em>he strove, laboured,</em> or <em>exerted himself, therein,</em> (<span class="ar">عُذْرَهُ</span> being understood,)]</span> <em>so that men proved him and knew him.</em> <span class="auth">(Mgh.)</span> <a href="#blw_3">See also 3</a>, where another explanation of <span class="ar">ابلى</span> is given, in the latter portion of the paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blw_4_B1">
					<p><span class="ar long">ابلى الثَّوْبَ</span> <span class="add">[<em>He wore out the garment;</em>]</span> trans. of <span class="ar">بَلِىَ</span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَلَّاهُ↓</span></span>; <span class="auth">(M, Ḳ;)</span> belonging to the present art. and to art. <span class="ar">بلى</span>. <span class="auth">(M.)</span> One says to the <span class="ar">مُجِدّ</span> <span class="add">[i. e. him who makes, or puts on, a new garment]</span>, <span class="ar long">أَبْلِ وَيُخْلِفُ ٱللّٰهُ</span> <span class="add">[<em>Wear out</em> thy garment, <em>and God will replace</em> it <em>with another;</em> or, <em>may God replace</em>, &amp;c.]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَبْلِ وَأَجِدَّ وَٱحْمِدَ الكَاسِى</span> <em>Wear out, and make new,</em> <span class="add">[or <em>put on new,</em>]</span> <em>and praise the Clother</em> <span class="add">[meaning God]</span>. <span class="auth">(Ṣ in art. <span class="ar">جد</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="blw_4_B2">
					<p><span class="add">[Hence,]</span><span class="arrow"><span class="ar long">بَلَّاهُ↓ السَّفَرُ</span></span> <span class="add">[<em>Journeying,</em> or <em>travel, wore him,</em> or <em>wasted him</em>]</span>; namely, a man; <span class="auth">(M, Ḳ; but in the copies of the latter,<span class="arrow"><span class="ar">بَلَاهُ↓</span></span> <span class="add">[which I think an evident mistranscription]</span>;)</span> as also<span class="arrow"><span class="ar long">بلّى↓ عَلَيْهِ</span></span>; and <span class="ar">ابلاهُ</span>: <span class="auth">(M:)</span> and so <span class="ar">الهَمُّ</span> <span class="add">[<em>anxiety</em>]</span>, <span class="auth">(M, Ḳ,)</span> and the like, <span class="auth">(M,)</span> and <span class="ar">التَّجَارِبُ</span> <span class="add">[<em>tryings,</em> or <em>trying events</em>]</span>: <span class="auth">(Ḳ:)</span> and <span class="ar long">ابلاها السَّفَرُ</span> <span class="auth">(T, Ṣ)</span> or<span class="arrow"><span class="ar">بلّاها↓</span></span> <span class="auth">(thus in a copy of the Ṣ)</span> <span class="add">[<em>journeying,</em> or <em>travel, wore her,</em> or <em>wasted her</em>]</span>; namely, a she-camel. <span class="auth">(T, Ṣ.)</span> El-ʼAjjáj says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَالمَرْءُ يُبْلِيهِ بَلَآءَ السِّرْبَالْ</span> *</div> 
						<div class="star">* <span class="ar long">كَرُّاللَّيالِى وَٱخْتِلَافُ الأَحْوَالُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And man, the returning of the nights time after time, and the alternation of states of being, wear him out as the wearing out of the shirt</em>]</span>: <span class="auth">(Ṣ, M:*)</span> he means, <span class="ar long">إِبْلَآءَ السِرْبَال</span>, or <span class="ar long">فَبَلِىَ بَلَآءَ السِّرْبَال</span>. <span class="auth">(M.)</span> And Ibn-Aḥmar says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَبِسْتُ أَبِى حَتَّى تَمَلَّيْتُ عُمْرَهُ</span> *</div> 
						<div class="star">* <span class="ar long">وَبَلَّيْتُ أَعْمَامِى وَبَلَّيْتُ خَالِيَا</span> *</div> 
					</blockquote>
					<p>he means <em>I lived the period that my father lived</em> <span class="add">[<em>so that I had long enjoyment of his life, and I outwore my paternal uncles, and I outwore my maternal uncle</em>]</span>: or, as some say, <em>I lived with my father for the length of his life</em>, &amp;c. <span class="auth">(M, TA.* <span class="add">[In the latter,<span class="arrow"><span class="ar">تَبَلَّيْتُ↓</span></span> is put in the place of <span class="ar">تَمَلَّيْتُ</span>; and hence it is there said that <span class="ar">تَبَلَّاهُ</span> is like <span class="ar">بَلَّاهُ</span>: but I think that <span class="ar">تبلّيت</span> is a mistranscription.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="blw_4_B3">
					<p><span class="ar">أَبْلَيْتُ</span> and<span class="arrow"><span class="ar">بَلَّيْتُ↓</span></span> also signify <em>I bound the foreshank of a she-camel to her arm at the grave of her</em> <span class="add">[<em>dead</em>]</span> <em>master, and left her without food or water until she died;</em> or <em>I dug for her a pit, and left her in it until she died.</em> <span class="auth">(Ṣ, TA. <span class="add">[<a href="#baliyBapN">See <span class="ar">بَلِيَّةٌ</span></a>, <a href="#mubalBFe">and <span class="ar">مُبَلًّى</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّو</span> ⇒ <span class="ar">تبلّى</span></h3>
				<div class="sense" id="blw_5_A1">
					<p><a href="#blw_4">see 4</a>, near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبالو</span> ⇒ <span class="ar">تبالى</span></h3>
				<div class="sense" id="blw_6_A1">
					<p><span class="ar">التَّبَالِى</span> <span class="add">[inf. n. of <span class="ar">تَبَالَى</span>]</span>: <a href="#blw_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 6.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blw_6_B1">
					<p><span class="ar long">تبالى القَوْمُ</span> <em>The people,</em> or <em>company of men, vied,</em> or <em>strove, one with another, in hastening to a little water, and drew from it.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blw_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتلو</span> ⇒ <span class="ar">ابتلى</span></h3>
				<div class="sense" id="blw_8_A1">
					<p><span class="ar">ابتلاهُ</span>: <a href="#blw_1">see 1</a>, in three places. <span class="add">[Hence, <span class="ar long">اُبْتِلِىَ بِكَذَا</span> <span class="auth">(vulg. <span class="ar">اِبْتَلَى</span>)</span> <em>He was tried, proved,</em> or <em>tested, by,</em> or <em>with, such a thing;</em> generally meaning <em>he was afflicted thereby,</em> or <em>therewith;</em> as, for instance, by, or with, a disease.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blw_8_A2">
					<p>Also <em>He asked,</em> or <em>sought,</em> or <em>desired, of him information,</em> or <em>news,</em> or <em>tidings.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar">ابتلى</span> signifies also <em>He conjured,</em> or <em>adjured, and asked if any had knowledge;</em> syn. <span class="ar">اِسْتَحْلَفَ</span> and <span class="ar">اِسْتَعْرَفَ</span> <span class="add">[explained by what here follows]</span>. <span class="auth">(M, Ḳ, TA. <span class="add">[In the CK, both the verb and the explanation are here wrong: the former is written <span class="ar">اُبْلِىَ</span>; and the latter, <span class="ar long">اسْتُحْلِفَ و اسْتُعْرِفَ</span>.]</span>)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَبَغَّى أَبَاهَا فِى الرِّفَاقِ وَتَبْتَلِى</span> *</div> 
						<div class="star">* <span class="ar long">وَأَوْدَى بِهِ فِى لُجَّةِ البَحْرِ تَمْسَحُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>She seeks for her father among the travellingcompanions, and conjures,</em> or <em>adjures, and asks. if any have knowledge, when a crocodile has destroyed him in the depth of the great river:</em> <span class="ar">تَبَغَّى</span> is for <span class="ar">تَتَبَغَّى</span>]</span>: he means that she says to them, “I conjure you, or adjure you, by God, (<span class="ar long">نَاشَدْتُكُمْ ٱللّٰهَ</span>,) <span class="add">[tell me,]</span> do ye know any tidings of my father?” <span class="auth">(M, TA.)</span> But Aboo-Saʼeed says that <span class="ar">تتبلى</span> here means <em>tries, proves,</em> or <em>tests;</em> and that <span class="ar">الاِبْتِلَآءُ</span> signifies <em>the trying, proving,</em> or <em>testing, whether by an oath or otherwise.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blw_8_A3">
					<p><span class="add">[Also <em>He desired it; he sought it.</em>]</span> It is said in a trad., <span class="ar long">النَّذْرُ مَا ٱبْتُلِىَ بِهِ وَجْهُ ٱللّٰهُ</span>, i. e. <span class="add">[<em>The vow that a man makes to be binding,</em> or <em>obligatory, on himself is that whereby the recompense of God</em>]</span> <em>is desired,</em> or <em>sought.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="blw_8_A4">
					<p>And <em>He chose him, made choice of him,</em> or <em>elected him.</em> <span class="auth">(Sh and T, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blw_12">
				<h3 class="entry">12. ⇒ <span class="ar">ابلولو</span> ⇒ <span class="ar">ابلولى</span></h3>
				<div class="sense" id="blw_12_A1">
					<p><span class="ar">اِبْلَوْلَى</span> <em>It</em> <span class="auth">(herbage)</span> <em>became tall, so that the camels were able to avail themselves of it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilowu">
				<h3 class="entry"><span class="ar">بِلْوُ</span></h3>
				<div class="sense" id="bilowu_A1">
					<p><span class="ar long">بِلْوُ سَفَرٍ</span>, <span class="auth">(T, Ṣ, M, A,)</span> with kesr to the <span class="ar">ب</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">بِلْىُ سَفَرٍ</span>, <span class="auth">(Ṣ, A,)</span> <em>Worn,</em> or <em>wasted, by journeying,</em> or <em>travel;</em> applied to a she-camel, <span class="auth">(T, Ṣ, M, A,)</span> and in like manner to a man, and to a he-camel: <span class="auth">(M:)</span> and <span class="ar long">بِلْىُ أَسْفَارٍ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar long">بِلْوُ أَسْفَارٍ</span>, <span class="auth">(Ḳ, TA,)</span> with kesr to the <span class="ar">ب</span> in both, <span class="auth">(TA, <span class="add">[in the CK written with fet-ḥ,]</span>)</span> a man <em>worn,</em> or <em>wasted, by journeyings,</em> or <em>travels, and anxiety,</em> <span class="auth">(M, Ḳ,*)</span> <em>and the like,</em> <span class="auth">(M,)</span> <em>and tryings,</em> or <em>trying events:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">أَبْلَآءٌ</span>. <span class="auth">(Ṣ, M.)</span> And <span class="ar long">بِلْوٌ شَرٍّ</span> and <span class="ar long">بِلْىُ شَرٍّ</span> <span class="add">[both written in the CK with fet-ḥ to the <span class="ar">ب</span>]</span> A man <em>having strength,</em> or <em>power, to endure evil; tried, proved,</em> or <em>tested, thereby:</em> <span class="auth">(M, Ḳ:)</span> and in like manner, <span class="ar long">بِلْوُ خَيْرٍ</span> and <span class="ar long">بِلْىُ خَيْرٍ</span> <span class="add">[<em>tried,</em>, &amp;c., <em>by good,</em> or <em>prosperity</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">إِنَّهُ لِبَلْوٌ مِنْ أَبْلَآءِ المَالِ</span> and <span class="ar">بِلْىٌ</span> <span class="add">[both written in the CK with fet-ḥ to the <span class="ar">ب</span> as before]</span> <em>Verily he is one of those who manage,</em> or <em>tend, camels,</em> or <em>the like, well.</em> <span class="auth">(M,* Ḳ,* TA.)</span> The <span class="ar">ى</span> in <span class="ar">بِلْى</span>, in all these instances, is originally <span class="ar">و</span>, changed into <span class="ar">ى</span> because of the kesreh, and the weakness of the intervening letter, <span class="ar">ل</span>; as is the case in <span class="ar">عِلْيَةٌ</span>: so says IJ. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balae">
				<h3 class="entry"><span class="ar">بَلَى</span></h3>
				<div class="sense" id="balae_A1">
					<p><span class="ar">بَلَى</span>: <a href="index.php?data=02_b/186_ble">see art. <span class="ar">بلى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bilowapN">
				<h3 class="entry"><span class="ar">بِلْوَةٌ</span></h3>
				<div class="sense" id="bilowapN_A1">
					<p><span class="ar">بِلْوَةٌ</span>: <a href="#balaACN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biloyapN">
				<h3 class="entry"><span class="ar">بِلْيَةٌ</span></h3>
				<div class="sense" id="biloyapN_A1">
					<p><span class="ar">بِلْيَةٌ</span>: <a href="#balaACN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balowae">
				<h3 class="entry"><span class="ar">بَلْوَى</span></h3>
				<div class="sense" id="balowae_A1">
					<p><span class="ar">بَلْوَى</span>: <a href="#balaACN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaMCN">
				<h3 class="entry"><span class="ar">بَلَآءٌ</span></h3>
				<div class="sense" id="balaMCN_A1">
					<p><span class="ar">بَلَآءٌ</span> <span class="auth">(T, Ṣ, Mṣb)</span> and<span class="arrow"><span class="ar">بَلْوَى↓</span></span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَلِيَّةٌ↓</span></span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بِلْوَةٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> with kesr, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بِلْيَةٌ↓</span></span>, <span class="auth">(so in a copy of the Ṣ, beside the third,)</span> thus in the handwriting of Aboo-Zekereeyà, in the place of the third, <span class="auth">(TA,)</span> substs. <span class="auth">(T, M, Mṣb, Ḳ)</span> from <span class="ar long">بَلَاهُ ٱللّٰهُ</span>, <span class="auth">(T, Mṣb,)</span> or from <span class="ar long">اِبْتَلَاهُ ٱللّٰهُ</span>, <span class="add">[which is the same in meaning,]</span> <span class="auth">(M,)</span> or from <span class="ar">بَلَوْتُهُ</span>, <span class="auth">(Ḳ,)</span> are one <span class="add">[in their signification; which is <em>A trial,</em> as meaning <em>a probation,</em> or <em>a test;</em> and as meaning particularly a <em>trouble</em> or <em>an affliction of any kind by which one's patience or any other grace or virtue is tried, proved,</em> or <em>tested</em>]</span>; <span class="auth">(Ṣ;)</span> and the pl. <span class="auth">(Ṣ, TA)</span> of <span class="arrow"><span class="ar">بَلِيَّةٌ↓</span></span> <span class="auth">(TA)</span> is <span class="ar">بَلَايَا</span>, of the measure <span class="ar">فَعَائِلُ</span> changed to <span class="ar">فَعَالَى</span>: <span class="auth">(Ṣ, TA:)</span> <span class="pb" id="Page_0257"></span><span class="add">[or]</span> <span class="ar">بَلَآءٌ</span> is <span class="add">[properly, or originally,]</span> an inf. n., <span class="auth">(Ṣ, M, Ḳ,)</span> and signifies the <em>act of trying, proving,</em> or <em>testing, by,</em> or <em>with, good,</em> and <em>by,</em> or <em>with, evil:</em> <span class="auth">(Ṣ, M:)</span> it is <em>evil</em> and <em>good:</em> <span class="auth">(T, M:*)</span> <em>a trial,</em> or <em>an affliction,</em> <span class="auth">(T, Ḳ,)</span> which is its original meaning; <span class="auth">(T;)</span> and <em>a</em> <span class="add">[<em>probationary</em>]</span> <em>benefit, favour,</em> or <em>blessing,</em> <span class="auth">(T,)</span> or <em>a</em> <span class="add">[<em>probationary</em>]</span> <em>gift;</em> <span class="auth">(Ḳ;)</span> the former of these requiring patience, and the latter being the greater of the two <span class="add">[as being commonly the more dangerous to the soul]</span>; <span class="auth">(TA;)</span> <span class="add">[but the latter meaning is generally indicated only by the addition of an epithet: thus]</span> <span class="ar long">بَلَآءٌ حَسَنٌ</span> means <em>a great benefit,</em> or <em>favour,</em> or <em>blessing,</em> of God; <span class="auth">(Bḍ in viii. 17;)</span> or <em>a good gift</em> of God: <span class="auth">(Jel ibid.:)</span> <span class="ar">بَلَآءٌ</span> also means <em>grief;</em> as though it tried the body: <span class="auth">(Er-Rághib, Ḳ:)</span> and the <em>imposition of a difficult,</em> or <em>troublesome, thing; a requirement; an exaction;</em> because it is difficult, or distressing, to the body; or because it is trying. <span class="auth">(Ḳ.)</span> <span class="ar">بَلَآءِ</span> <span class="auth">(like <span class="ar">قَطَامِ</span>, Ṣ, Ḳ)</span> is <em>syn. with</em> <span class="ar">البَلَآءُ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> occurring in the saying, <span class="ar long">نَزَلَتْ بَلَآءِ عَلَى الكُفَّارِ</span> <span class="add">[<em>Trial,</em> or <em>affliction, befell the unbelievers</em>]</span>: <span class="auth">(Ṣ, M,* Ḳ:*)</span> mentioned by El-Aḥmar, as heard by him from the Arabs. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilaMCN">
				<h3 class="entry"><span class="ar">بِلَآءٌ</span></h3>
				<div class="sense" id="bilaMCN_A1">
					<p><span class="ar">بِلَآءٌ</span>, like <span class="ar">كِتَابٌ</span> in form, <span class="add">[<a href="#blw_3">is an inf. n. of 3, q. v.</a>:]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: <span class="ar">بِلَآءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bilaMCN_B1">
					<p><span class="add">[and also signifies]</span> <em>Anxiety respecting which one talks to himself,</em> or <em>soliloquizes.</em> <span class="auth">(Mṣb. <span class="add">[Compare a meaning of <span class="ar">بَلَآءٌ</span>, above.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balieBN">
				<h3 class="entry"><span class="ar">بَلِىٌّ</span></h3>
				<div class="sense" id="balieBN_A1">
					<p><span class="ar">بَلِىٌّ</span>: <a href="#baliyBapN">see the paragraph next following</a>; last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baliyBapN">
				<h3 class="entry"><span class="ar">بَلِيَّةٌ</span></h3>
				<div class="sense" id="baliyBapN_A1">
					<p><span class="ar">بَلِيَّةٌ</span>: <a href="#balaACN">see <span class="ar">بَلَآءٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: <span class="ar">بَلِيَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baliyBapN_B1">
					<p>Also <em>A she-camel that has her fore shank bound to her arm at the grave of her master, and is left without food until she dies:</em> <span class="auth">(T:)</span> or <em>a she-camel,</em> <span class="auth">(M in arts. <span class="ar">بلو</span> and <span class="ar">بلى</span>, and Ḳ,)</span> or <em>a mare,</em> or <em>beast of the equine kind,</em> <span class="auth">(M in art. <span class="ar">بلو</span>,)</span> <em>that is bound at the grave of her master,</em> <span class="auth">(M, Ḳ,)</span> <em>he being dead, and is left without food or water</em> <span class="auth">(M)</span> <em>until she dies</em> <span class="auth">(M, Ḳ)</span> <em>and wastes away;</em> for they used to say that her master would be raised from the dead upon her: <span class="auth">(M:)</span> or <em>a she-camel which, in the Time of Ignorance, had her fore shank bound to her arm at the grave of her master, and was left without food or water until she died:</em> or <em>for which was dug a pit, wherein she was left until she died:</em> for they used to assert that men would be raised from the dead riding upon the <span class="ar">بَلَايَا</span>, <span class="add">[<a href="#baliyBapN">pl. of <span class="ar">بَلِيَّةٌ</span></a> in the sense above explained, <span class="auth">(T, TA,)</span>]</span> or walking if their beasts whereon they rode were not bound, with the head turned backwards, at their graves: <span class="auth">(Ṣ:)</span> or <em>a cow,</em> or <em>she-camel,</em> or <em>sheep,</em> or <em>goat, which, in the Time of Ignorance, they used to hamstring,</em> or <em>slaughter, at the grave:</em> so in a trad. <span class="auth">(TA.)</span> Suh says that this custom proves that, in the Time of Ignorance, they held the doctrine of the resurrection of the body: but they who held it were the fewer number. <span class="auth">(TA.)</span> It is said that <span class="ar">بَلِيَّةٌ</span> is originally<span class="arrow"><span class="ar">مُبْلَاةٌ↓</span></span> or<span class="arrow"><span class="ar">مُبَلَّاةٌ↓</span></span>. <span class="auth">(TA.)</span> Et-Tirimmáh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَنَازِلُ لَا تَرَى الأَنْصَابَ فِيهَا</span> *</div> 
						<div class="star">* <span class="ar long">وَلَا حُفَرَ المُبَلَّى لِلْمَنُونِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Places of abode in which thou wilt not see the stones,</em> or <em>other things, that have been set up to be worshipped, nor the pits of the beast left by the grave of the master to die</em>]</span>; meaning places of abode of the people of El-Islám, exclusively of the pagans. <span class="auth">(Ṣ.)</span> IAạr says that <span class="arrow"><span class="ar">بَلِىٌّ↓</span></span> and <span class="ar">بَلِيَّةٌ</span> signify <em>Such as is wearied,</em> or <em>jaded, and emaciated, and dying.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAlK">
				<h3 class="entry"><span class="ar">بَالٍ</span></h3>
				<div class="sense" id="baAlK_A1">
					<p><span class="ar">بَالٍ</span> <span class="add">[act. part. n. of <span class="ar">بَلَاهُ</span>; <em>Trying, proving,</em> or <em>testing.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: <span class="ar">بَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAlK_A2">
					<p><span class="add">[And hence,]</span> <em>Knowing,</em> or <em>being acquainted</em> <span class="add">[with a thing]</span>; as in the phrase, <span class="ar long">جَعَلْتُهُ بَالِيًا بِعُذْرِى</span> <em>I made him to be acquainted with my excuse, and to know the manner thereof.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: <span class="ar">بَالٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAlK_B1">
					<p>Also <em>Old, and wearing out</em> <span class="add">[or <em>worn out</em>]</span>; applied to a garment. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلو</span> - Entry: <span class="ar">بَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baAlK_B2">
					<p><span class="add">[Hence,]</span> <span class="ar">بَالِيَاتٌ</span> is used as meaning The <em>places of tents.</em> <span class="auth">(Ḥam p. 492.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubolaApN">
				<h3 class="entry"><span class="ar">مُبْلَاةٌ</span></h3>
				<div class="sense" id="mubolaApN_A1">
					<p><span class="ar">مُبْلَاةٌ</span>, <a href="#mubalFe">fem. of <span class="ar">مُبَلًى</span></a>: <a href="#baliyBapN">see <span class="ar">بَلِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubolBFe">
				<h3 class="entry"><span class="ar">مُبْلًّى</span> / <span class="ar">مُبَلَّاةٌ</span></h3>
				<div class="sense" id="mubolBFe_A1">
					<p><span class="ar">مُبْلًّى</span>, and its fem. <span class="ar">مُبَلَّاةٌ</span>: <a href="#baliyBapN">see <span class="ar">بَلِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubalBiyaAtu">
				<h3 class="entry"><span class="ar">مُبَلِّيَاتُ</span></h3>
				<div class="sense" id="mubalBiyaAtu_A1">
					<p><span class="ar">مُبَلِّيَاتُ</span> <em>Women that stand around a man's riding-camel</em> <span class="add">[<em>which they bind,</em> or <em>place in a pit, by his grave, to die of hunger and thirst,</em>]</span> <em>when he has died or been slain, wailing for him.</em> <span class="auth">(T, Ṣ.*)</span> You say, <span class="ar long">قَامَتْ مُبَلِّيَاتُ فُلَانٍ يَنُحْنَ عَلَيْهِ</span> <span class="add">[<em>The women that bound,</em> or <em>placed, the</em> <span class="ar">بَلِيَّة</span> <em>by the grave of such a one stood around it wailing for him</em>]</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0255.pdf" target="pdf">
							<span>Lanes Lexicon Page 255</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0256.pdf" target="pdf">
							<span>Lanes Lexicon Page 256</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0257.pdf" target="pdf">
							<span>Lanes Lexicon Page 257</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
