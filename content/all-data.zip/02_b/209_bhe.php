<article class="root" id="Root_bhe">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/208_bhw">بهو</a></span>
				<span class="ar">بهى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/210_bw">بو</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bhe_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهى</span></h3>
				<div class="sense" id="bhe_1_A1">
					<p><span class="ar">بَهَىَ</span>, as an intrans. v.: and <span class="ar">بَهَيْتُهُ</span>: <a href="index.php?data=02_b/208_bhw">see art. <span class="ar">بهو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0270.pdf" target="pdf">
							<span>Lanes Lexicon Page 270</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
