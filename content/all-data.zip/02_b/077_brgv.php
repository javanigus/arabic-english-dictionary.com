<article class="root" id="Root_brgv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/076_brEm">برعم</a></span>
				<span class="ar">برغث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/078_brq">برق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="buroguwvN">
				<h3 class="entry"><span class="ar">بُرْغُوثٌ</span> / <span class="ar">بُرْغُوثَةٌ</span></h3>
				<div class="sense" id="buroguwvN_A1">
					<p><span class="ar">بُرْغُوثٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> also, accord. to Es-Suyootee, with fet-ḥ and with kesr to the first letter, and Dmr says the like; <span class="add">[so that it is app. written also <span class="ar">بَرْغُوثٌ</span>, as it is commonly pronounced by the vulgar, though it is generally said that there is no word of this measure except <span class="ar">صَعْفُوق</span>; and <span class="ar">بِرْغَوْثٌ</span>, like <span class="ar">بِرْذَوْنٌ</span>, for there is no word of the measure <span class="ar">فِعْلُولٌ</span>;]</span> but each of these two forms requires proof; <span class="auth">(MF;)</span> <span class="add">[like the Hebr. <span class="he">בַּרְעש</span>, which, accord. to Gesenius, is undoubtedly from an Æthiopic root signifying “to spring,” “to dance;” The <em>flea;</em>]</span> <em>a certain insect</em> (<span class="ar">دُوَيْبَّة</span>), <em>resembling the</em> <span class="ar">حُرْقُوص</span>; <span class="auth">(TA;)</span> <em>well known:</em> <span class="auth">(Ḳ:)</span> <span class="add">[a coll. gen. n.: n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُرْغُوثَةٌ</span>}</span></add>:]</span> pl. <span class="ar">بَرَاغِيثُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0189.pdf" target="pdf">
							<span>Lanes Lexicon Page 189</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
