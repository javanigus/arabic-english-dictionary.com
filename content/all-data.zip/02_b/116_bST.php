<article class="root" id="Root_bST">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/115_bSr">بصر</a></span>
				<span class="ar">بصط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/117_bSE">بصع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bST_1">
				<h3 class="entry">1. ⇒ <span class="ar">بصط</span></h3>
				<div class="sense" id="bST_1_A1">
					<p><span class="ar">بَصْطٌ</span>, <span class="add">[inf. n. of <span class="ar">بَصَطَ</span>,]</span> <em>i. q.</em> <span class="ar">بَسْطٌ</span>, in all its meanings: <span class="auth">(Ḳ:)</span> the <span class="ar">س</span>, with <span class="ar">ط</span>, is changed into <span class="ar">ص</span> because of the nearness of the places of utterance. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0212.pdf" target="pdf">
							<span>Lanes Lexicon Page 212</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
