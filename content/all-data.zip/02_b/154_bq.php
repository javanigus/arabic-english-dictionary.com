<article class="root" id="Root_bq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/153_bge">بغى</a></span>
				<span class="ar">بق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/155_bqr">بقر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بقّ</span></h3>
				<div class="sense" id="bq_1_A1">
					<p><span class="ar">بَقَّ</span>, <span class="auth">(JK, M,)</span> aor. <span class="ar">يَبِقُّ</span>; and <span class="ar">بَقَّ</span>, <span class="add">[first pers. <span class="ar">بَقِقْتُ</span>,]</span> aor. <span class="ar">يَبَقُّ</span> <span class="add">[in the TA <span class="ar">يَبُقُّ</span>, which, being anomalous, is probably a mistake,]</span> inf. n. <span class="ar">بَقٌّ</span> and <span class="ar">بَقَقٌ</span> <span class="add">[which is of the latter verb accord. to analogy]</span> and <span class="ar">بَقِيقٌ</span>; <span class="auth">(M;)</span> <em>He spoke,</em> or <em>talked, much; was,</em> or <em>became, loquacious;</em> <span class="auth">(JK, M, TA;)</span> as also<span class="arrow"><span class="ar">ابقّ↓</span></span> <span class="auth">(JK, Ṣ, M, TA)</span> and<span class="arrow"><span class="ar">بَقْبَقَ↓</span></span>. <span class="auth">(M, TA.)</span> And <span class="ar long">بَقَّ كَلَامًا</span> <span class="add">[in which case the aor., accord. to rule, unless the noun be a specificative, is <span class="ar">يَبُقُّ</span>,]</span> and <span class="ar long">بَقَّ بِكَلَامٍ</span> <span class="add">[<em>He was,</em> or <em>became, profuse in speech</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">بَقَّ عَلَى القَوْمِ</span>, <span class="auth">(Zj, Ḳ,)</span> or <span class="ar long">بَقَّ كَلَامَهُ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">بَقٌّ</span> and <span class="ar">بَقَاقٌ</span>, <span class="auth">(Ḳ,)</span> <em>He spoke,</em> or <em>talked, much against the people,</em> or <em>company of men;</em> <span class="auth">(Zj, M,* Ḳ;)</span> as also<span class="arrow"><span class="ar">ابقّ↓</span></span>. <span class="auth">(Ḳ.)</span> Hence, <span class="auth">(TA,)</span> <span class="ar long">قَدْ مَلَأْتَ الأَرْضَ بَقَاقًا</span> <span class="add">[<em>Thou hast filled the earth,</em> or <em>land, with much discoursing</em>]</span>, said, in dispraise, to a voluminous writer. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bq_1_A2">
					<p><span class="ar">بَقَّتْ</span> and<span class="arrow"><span class="ar">ابقّت↓</span></span>, said of a woman, <em>She had many children:</em> <span class="auth">(JK, Ṣ, M, Ḳ:)</span> or, as Sb says, <span class="ar long">بَقَّتْ وَلَدًا</span> <em>she brought forth many children.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bq_1_A3">
					<p><span class="ar long">بَقَّتِ السَّمَآءُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">ابقّت↓</span></span>, <span class="auth">(M, TA,)</span> <em>The sky rained much, and consecutively,</em> or <em>uninterruptedly:</em> <span class="auth">(M, TA:*)</span> or <em>rained vehemently.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bq_1_A4">
					<p><span class="ar">بَقَّ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">يَيَقُّ</span>, <span class="auth">(M,)</span> or <span class="ar">يَبِقُّ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَقٌّ</span>, <span class="auth">(M, TA,)</span> <em>He gave largely,</em> or <em>amply:</em> <span class="auth">(IF, M, Ḳ,* TA:)</span> in some of the copies of the Ḳ, <span class="ar">العَظَمَة</span> is erroneously put for <span class="ar">العَطِيَّة</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَقَّ لَنَا العَطَآءَ</span> <em>He made the gift large,</em> or <em>ample, to us.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bq_1_A5">
					<p><span class="ar long">بَقَّ مَالَهُ</span> <em>He distributed,</em> or <em>dispersed,</em> or <em>scattered, his property;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">بقّقهُ↓</span></span>. <span class="auth">(JK,* Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bq_1_A6">
					<p><span class="ar long">بَقَّ الخَبَرَ</span>, inf. n. <span class="ar">بَقٌّ</span>, <em>He spread, and sent forth, the news,</em> or <em>information.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bq_1_A7">
					<p><span class="ar long">بَقَّ الشَّىْءَ</span>, aor. <span class="ar">يَبُقُّ</span>, <em>He put forth,</em> or <em>took forth, what was in the thing.</em> <span class="auth">(M, TA.)</span> Hence, <span class="auth">(M,)</span> <span class="ar long">بَقَّ عِيَابَهُ</span>, <span class="auth">(M, L, TA,)</span> in the Ḳ, erroneously, <span class="ar">عِيَالَهُ</span>, <span class="auth">(TA,)</span> <em>He spread out</em> <span class="auth">(Ḳ, TA)</span> <em>his</em> <span class="add">[<em>receptacles of skin,</em> or <em>leather, termed</em>]</span> <span class="ar">عياب</span>, <em>and put forth,</em> or <em>took forth, what was in them.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bq_1_A8">
					<p><em>He clave, slit, ripped,</em> or <em>rent, the thing.</em> <span class="auth">(JK.)</span> So in the phrase <span class="ar long">بَقَّ الجِرَابَ</span> <span class="add">[<em>He slit, ripped,</em> or <em>rent, and opened,</em> (<a href="#maboquwqN">see <span class="ar">مَبْقُوقٌ</span></a>,) <em>the bag,</em> or <em>receptacle, for travelling-provisions, &amp;c.</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bq_1_A9">
					<p><span class="ar">بَقَّ</span>, <span class="auth">(IF, Ḳ,)</span> inf. n. <span class="ar">بُقُوقٌ</span>, <span class="auth">(TA,)</span> said of a plant, <span class="add">[app. from its cleaving the earth,]</span> <em>It came forth.</em> <span class="auth">(IF, Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bq_1_B1">
					<p><span class="ar long">بَقَّ المَكَانُ</span>, <span class="add">[aor., app., <span class="ar">يَبِقُّ</span>, or <span class="ar">يَبَقُّ</span>,]</span> <em>The place abounded with</em> <span class="ar">بَقّ</span> <span class="add">[i. e. <em>gnats,</em> or <em>musquitoes;</em> or <em>bugs</em>]</span>; as also<span class="arrow"><span class="ar">ابقّ↓</span></span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bq_2">
				<h3 class="entry">2. ⇒ <span class="ar">بقّق</span></h3>
				<div class="sense" id="bq_2_A1">
					<p><a href="#bq_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bq_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابقّ</span></h3>
				<div class="sense" id="bq_4_A1">
					<p><a href="#bq_1">see 1</a>, in five places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bq_4_A2">
					<p><span class="ar long">ابقّ وَلَدُ فُلَانٍ</span>, inf. n. <span class="ar">إِبْقَاقٌ</span>, <em>The children of such a one multiplied; became many,</em> or <em>numerous.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bq_4_A3">
					<p><span class="ar long">أَبَقَّتِ الغَنَمُ فِى الجَدْبِ</span>, accord. to the Ḳ, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar long">اِنْبَقَّتِ↓ الغَنَمُ فِى عَامِ جَدْبٍ</span></span>, <span class="auth">(JK, and thus in the O, TA,)</span> <em>The ewes,</em> or <em>she-goats, being lean,</em> or <em>meagre, brought forth</em> <span class="add">[<em>in drought,</em> or <em>scarcity,</em> or <em>in a year of drought</em> or <em>scarcity</em>]</span>. <span class="auth">(JK, O, Ḳ, TA.)</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bq_4_A4">
					<p><span class="ar long">ابقّ الوَادِى</span> <em>The valley put forth its plants,</em> or <em>herbage.</em> <span class="auth">(O, L, TA.)</span> In the Ḳ, <span class="ar long">خَرَجَ بَقَاقُةُ</span> is erroneously put for <span class="ar long">خَرَجَ نَبَاتُهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bq_4_A5">
					<p><span class="ar long">أَبَقَّهُمْ خَيْرًا</span>, or <span class="ar">شَرًّا</span>, <em>He did to him much,</em> or <em>ample, good,</em> or <em>evil.</em> <span class="auth">(Ibn-ʼAbbád, JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bq_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبقّ</span></h3>
				<div class="sense" id="bq_7_A1">
					<p><a href="#bq_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bq_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بقبق</span></h3>
				<div class="sense" id="bq_RQ1_A1">
					<p><span class="ar long">بَقْبَقَ الكُوزُ</span>, <span class="auth">(Ṣ, M,)</span> <span class="ar">بِالمَآءِ</span>, <span class="auth">(M,)</span> <span class="add">[inf. n. <span class="ar">بَقْبَقَةٌ</span>, q. v. infrà,]</span> <em>The mug made a</em> <span class="add">[<em>guggling</em> or <em>gurgling</em>]</span> <em>sound with the water</em> <span class="add">[<em>on being dipped into it</em> or <em>on one's pouring out from it</em>]</span>. <span class="auth">(Ṣ,* M.)</span> And <span class="ar long">بَقْبَقَتِ القِدْرُ</span> <em>The cooking-pot boiled</em> <span class="add">[<em>so as to make a sound of bubbling</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bq_RQ1_A2">
					<p><a href="#bq_1">See also 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bq_RQ1_A3">
					<p><span class="ar long">بَقْبَقَ عَلَيْنَا الكَلَامَ</span> <em>i. q.</em> <span class="ar">فَرَّقَهُ</span> <span class="add">[lit. <em>He scattered speech</em> <span class="auth">(app. meaning <em>he jabbered</em>)</span> <em>at us,</em> or <em>against us:</em> compare <span class="ar long">بَقَّ عَلَى القَوْمِ</span>, or <span class="ar long">بَقَّ كَلَامَهُ</span>, above]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqBN">
				<h3 class="entry"><span class="ar">بَقٌّ</span></h3>
				<div class="sense" id="baqBN_A1">
					<p><span class="ar">بَقٌّ</span>: <a href="#baqaAqN">see <span class="ar">بَقَاقٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqBN_A2">
					<p><span class="ar">بَقَّةٌ</span> A woman <em>having many children:</em> <span class="auth">(Ibn-ʼAbbád, JK, Ḳ:)</span> and<span class="arrow"><span class="ar">مِبَقَّةٌ↓</span></span> a woman <em>that brings forth many children.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baqBN_A3">
					<p><span class="ar long">أَثَرٌ بَقٌّ</span> <span class="add">[<em>A trace, mark, track, impression,</em> or <em>the like,</em>]</span> <em>that is plainly apparent,</em> or <em>conspicuous.</em> <span class="auth">(JK, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baqBN_B1">
					<p>Also, a pl. n.; <span class="auth">(Ṣ, TA;)</span> <span class="add">[or rather a coll. gen. n.;]</span> sing., <span class="auth">(Ṣ, TA,)</span> or n. un., <span class="auth">(JK, M, Mṣb, Ḳ,*)</span> <span class="ar">بَقَّةٌ</span>; <span class="auth">(JK, Ṣ, M, &amp;c.;)</span> <em>Gnats,</em> or <em>musquitoes;</em> syn. <span class="ar">بَعُوضٌ</span>: <span class="auth">(Ṣ, M, Ḳ:*)</span> or <em>large</em> <span class="ar">بَعُوض</span>: <span class="auth">(JK, M, Mṣb:)</span> the poet 'Abder-Raḥmán Ibn-El-Hakam, cited by IB, speaks of their singing <span class="add">[or humming]</span>. <span class="auth">(TA.)</span> <span class="ar long">يَا عَيْنَ بَقَّةٍ</span> <span class="add">[<em>O eye of a gnat</em> or <em>musquito</em>]</span> denotes smallness of the person of him to whom it is said; or of the eye, as being likened to the eye of the gnat or musquito. <span class="auth">(Ḥar p. 619. <span class="add">[See an ex. voce <span class="ar">حُزُقٌّ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baqBN_B2">
					<p>Also, <span class="add">[in the M is here added “it is said,” but this implies uncertainty where none exists,]</span> <em>A kind of insect,</em> <span class="add">[namely, <em>bugs,</em>]</span> <span class="auth">(M, Ḳ,)</span> <em>resembling the louse,</em> <span class="auth">(M, TA,)</span> <span class="add">[<em>but larger,</em>]</span> <em>wide,</em> <span class="auth">(Ḳ,)</span> <em>red, and stinking,</em> <span class="auth">(M, Ḳ,)</span> <span class="add">[and hence termed <span class="ar long">بَقٌّ مُنْتِنٌ</span>,]</span> <em>found in bed-frames,</em> or <em>couch-frames, and in walls,</em> <span class="add">[and therefore termed <span class="ar long">بَقُّ الخَشَبِ</span> and <span class="ar long">بَقُّ الحِيطَانِ</span>,]</span> <span class="auth">(M, TA,)</span> <em>called also</em> <span class="ar long">بَنَاتُ الحَصِيرِ</span> <span class="add">[from being found in mats]</span>; <span class="auth">(TA;)</span> <em>when one kills them, he smells</em> <span class="add">[<em>what resembles</em>]</span> <em>the odour of bitter almonds proceeding from them.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="baqBN_B3">
					<p><span class="ar long">شَجَرَةٌ البَقِّ</span> <span class="add">[<em>The elmtree</em>]</span>: <a href="#darodaArN">see <span class="ar">دَرْدَارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqaqapN">
				<h3 class="entry"><span class="ar">بَقَقَةٌ</span></h3>
				<div class="sense" id="baqaqapN_A1">
					<p><span class="ar">بَقَقَةٌ</span>: <a href="#baqaAqN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqaAqN">
				<h3 class="entry"><span class="ar">بَقَاقٌ</span> / <span class="ar">بَقَاقَةٌ</span></h3>
				<div class="sense" id="baqaAqN_A1">
					<p><span class="ar">بَقَاقٌ</span> A man <em>who speaks,</em> or <em>talks, much; loquacious; talkative; garrulous; a great talker;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>whether incorrectly or correctly;</em> <span class="auth">(M;)</span> or such is termed <span class="arrow"><span class="ar">بَقَّاقٌ↓</span></span>; <span class="auth">(so written in a copy of the M;)</span> as also<span class="arrow"><span class="ar">بَقَاقَةٌ↓</span></span>, <span class="auth">(JK, Ṣ, Ḳ,)</span> but this has a more intensive signification, <span class="auth">(Ṣ, TA,)</span> and<span class="arrow"><span class="ar">مِبَقٌّ↓</span></span>, <span class="auth">(M, Ṣgh, Ḳ,)</span> and<span class="arrow"><span class="ar">بَقْبَاقٌ↓</span></span>, <span class="auth">(JK, Ṣ, M,)</span> or<span class="arrow"><span class="ar long">لَقْلَاقٌ بَقْبَاقٌ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar long">لَقٌّ بَقٌّ↓</span></span>, <span class="auth">(Ḳ,)</span> which last occurs in a trad., but accord. to one recital it is <span class="ar long">لَقًى بَقًى</span>, in which the former word signifies “cast away,” and the latter is an imitative sequent thereto: <span class="auth">(TA:)</span> <span class="arrow"><span class="ar">بَقَقَةٌ↓</span></span>, also, <span class="add">[app. <a href="#baAqBN">pl. of <span class="ar">بَاقٌّ</span></a>,]</span> is syn. with <span class="ar">ثَرْثَارُونَ</span> <span class="add">[<em>great talkers,</em>, &amp;c.]</span>: <span class="auth">(IAạr, TA:)</span> and <span class="ar">بَقَاقٌ</span> <span class="add">[thus written without teshdeed]</span> signifies <em>a babbler; nonsensical, irrational, foolish,</em> or <em>delirious, in his talk;</em> one <em>who speaks confusedly and improperly;</em> or <em>who speaks,</em> or <em>talks, much and badly,</em> or <em>erroneously.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#bq_1">See also 1</a>, of which it is an inf. n.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqaAqN_A2">
					<p>Also, <span class="auth">(Ḳ,)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَقَاقَةٌ</span>}</span></add>, <span class="auth">(JK, Ḳ,)</span> <em>A kind of clamorous bird:</em> <span class="auth">(JK, Ḳ:)</span> but Ṣgh writes it <span class="add">[<span class="arrow"><span class="ar">بَقَّاقٌ↓</span></span>,]</span> with teshdeed. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقَاقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baqaAqN_B1">
					<p>Also The <em>worthless,</em> or <em>mean,</em> or <em>vile, articles of the furniture or utensils of a house or tent,</em> or <em>of household-goods.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqaAqapN">
				<h3 class="entry"><span class="ar">بَقَاقَةٌ</span></h3>
				<div class="sense" id="baqaAqapN_A1">
					<p><span class="ar">بَقَاقَةٌ</span>: <a href="#baqaAqN">see <span class="ar">بَقَاقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqBaAqN">
				<h3 class="entry"><span class="ar">بَقَّاقٌ</span></h3>
				<div class="sense" id="baqBaAqN_A1">
					<p><span class="ar">بَقَّاقٌ</span>: <a href="#baqaAqN">see <span class="ar">بَقَاقٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqobaqapN">
				<h3 class="entry"><span class="ar">بَقْبَقَةٌ</span></h3>
				<div class="sense" id="baqobaqapN_A1">
					<p><span class="ar">بَقْبَقَةٌ</span> a word imitative of The <span class="add">[<em>guggling</em> or <em>gurgling</em>]</span> <em>sound of a mug</em> <span class="auth">(JK, Ṣ, Ḳ)</span> <span class="add">[<em>when dipped</em>]</span> <em>in water,</em> <span class="auth">(JK, Ḳ,)</span> and <em>the like:</em> <span class="auth">(Ḳ:)</span> and of <em>a cooking-pot in its boiling.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bq_RQ1">See also R. Q. 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqobaAqN">
				<h3 class="entry"><span class="ar">بَقْبَاقٌ</span></h3>
				<div class="sense" id="baqobaAqN_A1">
					<p><span class="ar">بَقْبَاقٌ</span>: <a href="#baqaAqN">see <span class="ar">بَقَاقٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">بَقْبَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqobaAqN_A2">
					<p>Also The <em>mouth.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibaqBN">
				<h3 class="entry"><span class="ar">مِبَقٌّ</span></h3>
				<div class="sense" id="mibaqBN_A1">
					<p><span class="ar">مِبَقٌّ</span>: <a href="#baqaAqN">see <span class="ar">بَقَاقٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بق</span> - Entry: <span class="ar">مِبَقٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mibaqBN_A2">
					<p><span class="ar">مِبَقَّةٌ</span> <span class="add">[its fem.]</span>: <a href="#baqBN">see <span class="ar">بَقٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabaqBapN">
				<h3 class="entry"><span class="ar">مَبَقَّةٌ</span></h3>
				<div class="sense" id="mabaqBapN_A1">
					<p><span class="ar long">أَرْضٌ مَبَقَّةٌ</span> <em>A land abounding with</em> <span class="ar">بَقّ</span> <span class="add">[i. e. <em>gnats,</em> or <em>musquitoes;</em> or <em>bugs</em>]</span>; <span class="auth">(M, TA;)</span> like as you say <span class="ar">مَبْعَضَةٌ</span>. <span class="auth">(TA in art. <span class="ar">بعض</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboquwqN">
				<h3 class="entry"><span class="ar">مَبْقُوقٌ</span></h3>
				<div class="sense" id="maboquwqN_A1">
					<p><span class="ar long">جِرَابٌ مَبْقُوقٌ</span> <span class="add">[<em>A bag,</em> or <em>receptacle, for travel-ling-provisions, &amp;c.</em>]</span> <em>opened:</em> <span class="auth">(JK:)</span> or <em>slit, ripped,</em> or <em>rent, and opened.</em> <span class="auth">(Ibn-ʼAbbád, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0233.pdf" target="pdf">
							<span>Lanes Lexicon Page 233</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
