<article class="root" id="Root_bx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/031_bHr">بحر</a></span>
				<span class="ar">بخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/033_bxt">بخت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bx_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بخبخ</span></h3>
				<div class="sense" id="bx_RQ1_A1">
					<p><span class="ar">بَخْبَخَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَخْبَخَةٌ</span> and <span class="ar">بِخْبَاخٌ</span>, <span class="auth">(TA,)</span> <span class="add">[a verb imitative of the sound which it signifies,]</span> <span class="pb" id="Page_0158"></span><em>He</em> <span class="auth">(a camel <span class="add">[in a state of excitement]</span>)</span> <em>brayed,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>so that his</em> <span class="ar">شِقْشِقَة</span> <span class="add">[or <em>faucial bag</em>]</span> <em>filled his mouth:</em> <span class="auth">(Ṣ:)</span> or, as some say, <em>began to bray.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bx_RQ1_A2">
					<p><span class="add">[Hence, perhaps,]</span> <em>He</em> <span class="auth">(a man)</span> <em>said</em> <span class="add">[<span class="ar">بَخْ</span>]</span> or <span class="ar long">بَخْ بَخْ</span> <span class="add">[&amp;c.]</span>. <span class="auth">(TA, and Ḥar p. 556.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bx_RQ1_A3">
					<p>And <span class="add">[hence,]</span> <span class="ar long">بَخْبَخَ بِصُحْبَتِى</span> <em>He rejoiced in my company.</em> <span class="auth">(Ḥar ubi suprà.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bx_RQ1_A4">
					<p>And <span class="ar long">بَخْبَخَ الرَّجُلَ</span> <em>He said</em> <span class="ar">بَخْ</span> or <span class="ar long">بَخْ بَخْ</span>, &amp;c. <em>to the man.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxo">
				<h3 class="entry"><span class="ar">بَخْ</span></h3>
				<div class="sense" id="baxo_A1">
					<p><span class="ar">بَخْ</span>, <span class="auth">(Ṣ, A, Ḳ, &amp;c.,)</span> <span class="add">[in some copies of the Ḳ written <span class="ar">بَخَّ</span>, which is wrong, for it is]</span> like <span class="ar">بَلْ</span>, <span class="auth">(A,)</span> <span class="add">[i. e.]</span> like <span class="ar">قَدْ</span>, <span class="auth">(TA,)</span> <span class="add">[perhaps, as I have suggested above, from the sound made by a he-camel in a state of excitement,]</span> a word used on the occasion of praising; <span class="auth">(Ṣ, A;)</span> on praising one from whom has proceeded a good and wonderful action; <span class="auth">(Ḥar p. 142;)</span> on approving a thing; <span class="auth">(T, Ṣ, Mṣb, Ḳ;)</span> on being pleased with it, or having one's admiration excited by it; <span class="auth">(A, Ḳ;)</span> or on the occasion of glorying and of praising; <span class="auth">(Ḳ;)</span> in pronouncing a thing great in estimation, <span class="auth">(IAmb,)</span> or excellent; <span class="auth">(AHeyth;)</span> in deeming a thing great in estimation, <span class="auth">(AḤei,)</span> or good; <span class="auth">(Mgh;)</span> or it means wonder, or admiration; <span class="auth">(R;)</span> and sometimes it is used <span class="add">[ironically]</span> to denote disapproval; also, as an exhortation to gentleness with a thing, and to taking extraordinary pains; <span class="auth">(TA;)</span> and in a case of expertness, or skilfulness: <span class="auth">(AḤei:)</span> it means <span class="ar long">نِعْمَ الرَّجُلُ</span> and <span class="ar long">نِعْمَ الفِعْلُ</span> <span class="add">[<em>Excellent,</em> or <em>most excellent, is the man!</em> and, <em>the deed!</em>]</span>; <span class="auth">(Ḥar p. 142;)</span> <span class="add">[or simply, <em>excellent!</em> or <em>most excellent! how good! how goodly! well done! bravo!</em> and the like;]</span> or <span class="ar long">عَظُمَ الأَمْرُ</span> and <span class="ar">فَخُمَ</span> <span class="add">[<em>great in estimation is the thing,</em> or <em>affair,</em> or <em>event,</em> or <em>case!</em>]</span>: <span class="auth">(Ḳ:)</span> MF observes, <span class="add">[probably from finding <span class="ar">بَخَّ</span> in the place of <span class="ar">بَخْ</span> in his copy or copies of the Ḳ,]</span> that this explanation is like an express assertion that it is a verb in the pret. tense, which requires consideration. <span class="auth">(TA.)</span> It is used alone; and in this case you say, <span class="ar">بَخْ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar">بَخِ</span>, <span class="auth">(Mṣb, Ḳ,)</span> with kesr for its invariable termination, <span class="auth">(Mṣb,)</span> and <span class="ar">بَخٍ</span>, and <span class="ar">بَخٌ</span>; <span class="auth">(Ḳ, TA; <span class="add">[but in the CK, in the place of <span class="ar">بَخٍ</span> and <span class="ar">بَخٌ</span>, we find <span class="ar">بُخٌ</span>;]</span>)</span> without teshdeed, <span class="auth">(T, Mṣb,)</span> in most cases; <span class="auth">(Mṣb;)</span> but also with teshdeed, <span class="auth">(T, Ṣ, A,)</span> like a noun; so that one says, <span class="ar long">بَخٍ لَكَ</span> and <span class="ar">بَخٍّ</span> <span class="add">[&amp;c., meaning I say <em>excel-lent!</em>, &amp;c., <em>to thee</em>]</span>: <span class="auth">(Ṣ:)</span>. and one repeats it, <span class="auth">(Ṣ, A, Ḳ, &amp;c.,)</span> for the sake of emphasis; <span class="auth">(Ṣ, A;)</span> saying, <span class="ar long">بَخْ بَخْ</span>, <span class="auth">(IAmb, Ṣ, A, Ḳ, &amp;c.,)</span> with the <span class="ar">خ</span> quiescent like the <span class="ar">ل</span> in <span class="ar">هَلْ</span> and <span class="ar">بَلْ</span>, <span class="auth">(IAmb,)</span> and <span class="ar long">بَخٍ بَخٍ</span>, <span class="auth">(Ṣ, A, R, Ḳ,)</span> pronounced in the latter manner, with tenween, when in connexion with a following word, <span class="add">[and in this case only, whereas it is pronounced in the former manner in any case,]</span> <span class="auth">(Ṣ, A,)</span> and <span class="ar long">بَخٍّ بَخٍّ</span>, <span class="auth">(Ṣ,* A,* R, Ḳ,)</span> and <span class="ar long">بَخٍ بَخْ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar long">بَخِّ بَخِّ</span>. <span class="auth">(R.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxobaAxu">
				<h3 class="entry"><span class="ar">بَخْبَاخُ</span></h3>
				<div class="sense" id="baxobaAxu_A1">
					<p><span class="ar long">جَمَلٌ بَخْبَاخُ الهَدِيرِ</span> <em>A camel that fills his mouth with his</em> <span class="ar">شِقْشِقَة</span> <span class="add">[or <em>faucial bag</em>]</span> <em>when he brays.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaxobaxapN">
				<h3 class="entry"><span class="ar">مُبَخْبَخَةٌ</span></h3>
				<div class="sense" id="mubaxobaxapN_A1">
					<p><span class="ar long">إِبِلٌ مُبَخْبَخَةٌ</span> <em>Camels to which one says</em> <span class="ar long">بَخْ بَخْ</span>; being pleased with them: <span class="auth">(ISd, TA:)</span> or <em>largebellied camels;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">مُخَبْخَبَةٌ</span>, which is formed from the former by transposition; from <span class="ar long">بَخْ بَخْ</span>, or <span class="ar long">بَخٍ بَخْ</span>, which is said by the Arabs in praising a thing; as though, by reason of their greatness, the people, seeing them, said, How goodly are they! <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0157.pdf" target="pdf">
							<span>Lanes Lexicon Page 157</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0158.pdf" target="pdf">
							<span>Lanes Lexicon Page 158</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
