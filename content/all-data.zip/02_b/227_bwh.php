<article class="root" id="Root_bwh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/226_bwn">بون</a></span>
				<span class="ar">بوه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/228_be">بى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwh_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوه</span> ⇒ <span class="ar">باه</span></h3>
				<div class="sense" id="bwh_1_A1">
					<p><span class="ar">بَاهَهَا</span>, <span class="auth">(JK, Ḳ,)</span> <span class="add">[aor. <span class="ar">يَبُوهُ</span>,]</span> inf. n. <span class="ar">بَوْهٌ</span>, <span class="auth">(TA,)</span> <em>He lay with her;</em> syn. <span class="ar">جَامَعَهَا</span>; <span class="auth">(Ḳ;)</span> like <span class="ar">بَاكَهَا</span>. <span class="auth">(JK.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوه</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwh_1_B1">
					<p><span class="ar long">بَاهَ لَهُ</span>, aor. <span class="ar">يَبُوهُ</span>, <span class="auth">(JK, Ḳ,)</span> inf. n. <span class="ar">بَوْهٌ</span>; <span class="auth">(Ḳ;)</span> as also <span class="ar long">بَاهَ لَهُ</span>, aor. <span class="ar">يَبَاهُ</span>, <span class="auth">(JK,* Ḳ,)</span> inf. n. <span class="ar">بَيْهٌ</span>; <span class="auth">(Ḳ;)</span> <em>His attention became roused to it;</em> <span class="auth">(Ḳ;)</span> <em>he knew it,</em> or <em>understood it;</em> or <em>knew,</em> or <em>had knowledge, of it; was cognizant of it:</em> <span class="auth">(JK, TA:)</span> like <span class="ar">بَأَهَ</span>, and <span class="ar">أَبَهَ</span> or <span class="ar">أَبِهَ</span>. <span class="auth">(TA.)</span> And <span class="ar long">مَا بُهْتُ لَهُ</span>; as also <span class="ar long">مَا بِهْتُ لَهُ</span>; <em>I did not know it,</em> or <em>understand it;</em> or <em>did not know,or had not knowledge, of it; was not cognizant of it:</em> <span class="auth">(JK, Ṣ,- Ḳ:)</span> the inf. n. of the former is <span class="ar">بَوْهٌ</span>; and that of the latter, <span class="ar">بَيْهٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhN">
				<h3 class="entry"><span class="ar">بَاهٌ</span></h3>
				<div class="sense" id="baAhN_A1">
					<p><span class="ar">بَاهٌ</span> <a href="#baACapN">a dial. var. of <span class="ar">بَآءَةٌ</span></a> <span class="auth">(IAạr, Ṣ)</span> <a href="#baACN">and of <span class="ar">بَآءٌ</span></a>, <span class="auth">(IAạr, TA,)</span> signifying <em>Coitus:</em> <span class="auth">(Ṣ Ḳ:*)</span> and <em>marriage:</em> <span class="auth">(Ḳ,* TA:)</span> as also<span class="arrow"><span class="ar">بَاهَةٌ↓</span></span>: <span class="auth">(TA:)</span> or a <em>share of coitus;</em> <span class="auth">(JK, TA;)</span> occurring in this sense in a trad., in which a woman is mentioned as having adorned herself for it: <span class="auth">(TA:)</span> also <em>venereal passion:</em> <span class="auth">(TA in art. <span class="ar">خفش</span>:)</span> <span class="add">[or the <em>venereal faculty;</em> as when one says of a drug or some other thing, <span class="ar long">يَزِيدُ فِى البَاهِ</span> <em>It increases the venereal faculty:</em>]</span> IḲt says, of this word, <span class="ar">بَاهٌ</span>, <span class="add">[though it is of very frequent occurrence,]</span> that it is a mistranscription <span class="add">[app. meaning for <span class="ar">بَآءٌ</span>]</span>. <span class="auth">(Mṣb and TA in art. <span class="ar">بوأ</span>.)</span> <span class="add">[<a href="#baACapN">See also <span class="ar">بَآءَةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhapN">
				<h3 class="entry"><span class="ar">بَاهَةٌ</span></h3>
				<div class="sense" id="baAhapN_A1">
					<p><span class="ar">بَاهَةٌ</span>: <a href="#baACN">see <span class="ar">بَاءٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوه</span> - Entry: <span class="ar">بَاهَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAhapN_B1">
					<p>Also The <em>court of a house;</em> or <em>a spacious part,</em> or <em>portion,</em> of a house, <em>in which is no building;</em> <span class="auth">(JK, Ḳ, TA;)</span> <em>where people alight,</em> or <em>lodge:</em> <span class="auth">(JK:)</span> <a href="#baAHapN">a dial. var. of <span class="ar">بَاحَةٌ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhieBN">
				<h3 class="entry"><span class="ar">بَاهِىٌّ</span></h3>
				<div class="sense" id="baAhieBN_A1">
					<p><span class="ar">بَاهِىٌّ</span> <em>That strengthens the venereal</em> <span class="add">[<em>faculty</em> or]</span> <em>appetite.</em> <span class="auth">(TA in art. <span class="ar">جزر</span>, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0278.pdf" target="pdf">
							<span>Lanes Lexicon Page 278</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
