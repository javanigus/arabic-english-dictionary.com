<article class="root" id="Root_blsAn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/173_bls">بلس</a></span>
				<span class="ar">بلسان</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/175_blT">بلط</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="balasaAnN.1">
				<h3 class="entry"><span class="ar">بَلَسَانٌ</span></h3>
				<div class="sense" id="balasaAnN.1_A1">
					<p><span class="ar">بَلَسَانٌ</span>: <a href="index.php?data=02_b/173_bls">see art. <span class="ar">بلس</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0248.pdf" target="pdf">
							<span>Lanes Lexicon Page 248</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
