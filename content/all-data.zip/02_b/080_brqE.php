<article class="root" id="Root_brqE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/079_brqX">برقش</a></span>
				<span class="ar">برقع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/081_brk">برك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brqE_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برقع</span></h3>
				<div class="sense" id="brqE_Q1_A1">
					<p><span class="ar">بَرْقَعَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَرْقَعَةٌ</span>, <span class="auth">(TA,)</span> <em>He attired him with a</em> <span class="ar">بُرْقُع</span>: <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar long">بَرْقَعَ المَرْأَةَ</span> <em>he attired the woman with a</em> <span class="ar">بُرْقُع</span> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برقع</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brqE_Q1_A2">
					<p><span class="ar long">بَرْقَعَ لِحْيَتَهُ</span> <span class="add">[<em>He veiled his beard with a</em> <span class="ar">بُرْقُع</span>;]</span> <em>He assumed the guise of such as wear the</em> <span class="ar">بُرْقُع</span>; <span class="auth">(TA;)</span> i. e. <span class="ar long">صَارَ مَأْبُونًا</span> <span class="add">[<em>he became effeminate,</em> or <em>a catamite</em>]</span>. <span class="auth">(Ḳ, TA.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَلَمْ تَرَ قَيْسًا قَيْسَ عَيْلَانَ بَرْقَعَتْ</span> *</div> 
						<div class="star">* <span class="ar long">لِحَاهَا وَبَاعَتْ نَبْلَهَا بِالمَغَازِلِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Dost thou no see that Keys, Keys-'Eylan, have veiled their beards, and sold their arrows for spindles?</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برقع</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brqE_Q1_A3">
					<p><span class="ar long">بَرْقَعَ فُلَانًا بِالعَصَا</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(TA,)</span> <em>He struck such a one with the staff,</em> or <em>stick, between his ears,</em> <span class="auth">(Ḳ, TA,)</span> <em>so that it became like the</em> <span class="ar">بُرْقُع</span> <em>upon his head.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brqE_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبرقع</span></h3>
				<div class="sense" id="brqE_Q2_A1">
					<p><span class="ar">تَبَرْقَعَ</span> <em>He attired himself with a</em> <span class="ar">بُرْقُع</span> <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar">تَبَرْقَعَتْ</span> <em>she</em> <span class="auth">(a women)</span> <em>attired herself with a</em> <span class="ar">بُرْقُع</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroqaEN">
				<h3 class="entry"><span class="ar">بُرْقَعٌ</span></h3>
				<div class="sense" id="buroqaEN_A1">
					<p><span class="ar">بُرْقَعٌ</span>: <a href="#buroquEN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroquEN">
				<h3 class="entry"><span class="ar">بُرْقُعٌ</span></h3>
				<div class="sense" id="buroquEN_A1">
					<p><span class="ar">بُرْقُعٌ</span> <span class="auth">(IAạr, Ṣ, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بُرْقَعٌ↓</span></span> <span class="auth">(IAạr, Ṣ, Mṣb, Ḳ,)</span> but some disallow this latter, <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar">بُرْقُوعٌ↓</span></span>, <span class="auth">(IAạr, Ṣ, Ḳ,)</span> but AḤát disallows this, as well as the second, <span class="auth">(TA,)</span> <em>A thing pertaining to women and to horses or similar beasts,</em> <span class="auth">(Ḳ,)</span> or <em>to horses or similar beasts and to the women of the Arabs of the desert;</em> <span class="auth">(Ṣ;)</span> <em>a thing with which a woman veils her face;</em> <span class="auth">(Mṣb;)</span> <em>having in it two holes for the eyes:</em> <span class="auth">(Lth:)</span> <em>a small piece of cloth,</em> or <em>rag, pierced for the eyes, worn by horses or similar beasts and by the women of the Arabs of the desert:</em> <span class="auth">(Mgh:)</span> <span class="add">[or, accord. to the general fashion of the present time, <em>a long strip of cotton or other cloth, black, blue, or of some other colour, or white, concealing the whole of the face of the woman wearing it, except the eyes, and reaching nearly to the feet, suspended at the top by a narrow band, or other fastening, which passes up the middle of the forehead, and which is sewed, as are also the two upper corners, to a band which is tied round the head, beneath the head-veil:</em> <span class="auth">(see my “Manners and Customs of the Modern Egyptians,” ch. i.:)</span>]</span> <span class="arrow"><span class="ar">بُرْقَعَةٌ↓</span></span>, if correct, is a more particular term: <span class="auth">(Mgh:)</span> the pl. is <span class="ar">بَرَاقِعُ</span>. <span class="auth">(Lth, Mṣb.)</span> <span class="add">[<a href="#niqaAbN">See <span class="ar">نِقَابٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برقع</span> - Entry: <span class="ar">بُرْقُعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buroquEN_A2">
					<p><span class="add">[<span class="ar">البُرْقُعُ</span> <em>The curtain of the door of the Kaabeh.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برقع</span> - Entry: <span class="ar">بُرْقُعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buroquEN_A3">
					<p><a href="#biroqiEu">See also <span class="ar">بِرْقِعُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biroqaEu">
				<h3 class="entry"><span class="ar">بِرْقَعُ</span></h3>
				<div class="sense" id="biroqaEu_A1">
					<p><span class="ar">بِرْقَعُ</span>: <a href="#biroqaEu">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biroqaEu.1">
				<h3 class="entry"><span class="ar">بِرْقَعُ</span></h3>
				<div class="sense" id="biroqaEu.1_A1">
					<p><span class="ar">بِرْقَعُ</span>, <span class="auth">(Ṣ, Ḳ,* TA,)</span> imperfectly decl., <span class="auth">(Ṣ, TA,)</span> and<span class="arrow"><span class="ar">بِرْقَعُ↓</span></span>, <span class="auth">(Fr, Az, Ibn-ʼAbbád,)</span> of a rare form, like <span class="ar">هِجْرَع</span>, <span class="auth">(Fr, Az,*)</span> or <span class="ar">البِرْقِعُ</span> and<span class="arrow"><span class="ar">البُرْقُعُ↓</span></span>, <span class="auth">(Ḳ,* TA,)</span> but perhaps this last is a mistranscription, for <span class="ar">بِرْقَعُ</span>, <span class="auth">(TA,)</span> a name of <em>The heaven,</em> or <em>sky:</em> <span class="auth">(Fr:)</span> or <em>the seventh heaven:</em> <span class="auth">(AAF, Ṣ, Ḳ:)</span> or <em>the fourth heaven:</em> <span class="auth">(Lth, Az, Ḳ:)</span> or <em>the first heaven;</em> <span class="auth">(Ḳ;)</span> i. e. <em>the lowest heaven:</em> IDrd says, so they assert; and in like manner says IF; <span class="pb" id="Page_0193"></span>and he says, the <span class="ar">ب</span> is augmentative, the radical letters being <span class="ar long">ر ق ع</span>, for every heaven is termed <span class="ar">رَقِيعٌ</span>, and the heavens <span class="add">[together]</span> are termed <span class="ar">أَرْقِعَةٌ</span>: <span class="auth">(TA:)</span> or the lowest heaven is termed <span class="ar">الرَّقِيعُ</span>. <span class="auth">(Ṣ, TA.)</span> <span class="add">[See an ex. voce <span class="ar">سَدِرٌ</span>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroqaEapN">
				<h3 class="entry"><span class="ar">بُرْقَعَةٌ</span></h3>
				<div class="sense" id="buroqaEapN_A1">
					<p><span class="ar">بُرْقَعَةٌ</span>: <a href="#buroquEN">see <span class="ar">بُرْقُعٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroquwEN">
				<h3 class="entry"><span class="ar">بُرْقُوعٌ</span></h3>
				<div class="sense" id="buroquwEN_A1">
					<p><span class="ar">بُرْقُوعٌ</span>: <a href="#buroquEN">see <span class="ar">بُرْقُعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaroqaEN">
				<h3 class="entry"><span class="ar">مُبَرْقَعٌ</span></h3>
				<div class="sense" id="mubaroqaEN_A1">
					<p><span class="ar long">فَرَسٌ مُبَرْقَعٌ</span>, <span class="auth">(TA,)</span> or <span class="ar long">فَرَسٌ أَغَرٌّ مُبَرْقَعٌ</span>, <span class="auth">(Mgh,)</span> <em>A horse having what is termed</em> <span class="ar long">غُرَّةٌ مُبَرْقِعَةٌ</span>: <span class="auth">(TA:)</span> or <em>a horse having the whole of his face white.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">شَاةٌ مُبَرْقَعَةٌ</span> <em>A sheep,</em> or <em>ewe, having the head white.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaroqiEapN">
				<h3 class="entry"><span class="ar">مُبَرْقِعَةٌ</span></h3>
				<div class="sense" id="mubaroqiEapN_A1">
					<p><span class="ar long">غُرَّةٌ مُبَرْقِعَةٌ</span> <em>A blaze,</em> or <em>whiteness, on the face of a horse, occupying the whole of his face, except that he looks</em> (<span class="ar">يَنْظُرُ</span> <span class="add">[for which <span class="ar">يُنْظَرُ</span> is erroneously substituted in the CK]</span>) <em>in blackness;</em> <span class="auth">(Ṣ, L, Ḳ;)</span> <span class="add">[i. e.]</span> <em>this whiteness passing downwards to the cheeks without reaching to the eyes.</em> <span class="auth">(L, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0192.pdf" target="pdf">
							<span>Lanes Lexicon Page 192</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0193.pdf" target="pdf">
							<span>Lanes Lexicon Page 193</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
