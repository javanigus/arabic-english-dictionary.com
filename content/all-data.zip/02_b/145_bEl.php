<article class="root" id="Root_bEl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/144_bEq">بعق</a></span>
				<span class="ar">بعل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/146_bgt">بغت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بعل</span></h3>
				<div class="sense" id="bEl_1_A1">
					<p><span class="ar">بَعَلَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> or <span class="ar">ـُ</span> <span class="add">[contr. to rule]</span>; <span class="auth">(Mṣb;)</span> or the pret. is <span class="ar">بَعُلَ</span>; <span class="auth">(so in the Ḥam p. 337;)</span> inf. n. <span class="ar">بُعُولَةٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بَعَالَةٌ</span> also <span class="auth">(Ḥam ubi suprà)</span> <span class="add">[and app. <span class="ar">بَعْلٌ</span>, for it is said in the Ḥam p. 359 that the primary signification of <span class="ar">البَعْلُ</span> is <span class="ar">النِّكَاحُ</span>]</span>; <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>became a husband;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">استبعل↓</span></span>: <span class="auth">(Ḳ:)</span> <em>he married,</em> or <em>took a wife.</em> <span class="auth">(Mṣb.)</span> And in like manner, <span class="ar">بَعَلَتْ</span>, inf. n. <span class="ar">بُعُولَةٌ</span>, <em>She became a wife:</em> <span class="auth">(TA:)</span> <span class="add">[and it seems to be indicated in the Ḥam p. 359 that <span class="arrow"><span class="ar">ابتعلت↓</span></span> and<span class="arrow"><span class="ar">تبعّلت↓</span></span> signify the same:]</span> and<span class="arrow"><span class="ar">باعلت↓</span></span> <em>she took to herself a husband.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEl_1_A2">
					<p><span class="ar long">بَعَلَ عَلَيْهِ</span> <span class="add">[as though originally signifying <em>He became a</em> <span class="ar">بَعْل</span>, or <em>lord, over him:</em>]</span> <em>he was incompliant,</em> or <em>unyielding, to him; he resisted him,</em> or <em>withstood him.</em> <span class="auth">(Ḳ.)</span> Hence, in a trad., <span class="ar long">فَمَنْ بَعَلَ عَلَيْكُمْ أَمْرَكُمْ فَٱقْتُلُوهُ</span> <em>And whoso resisteth and disobeyeth your command, slay ye him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEl_1_B1">
					<p><span class="ar">بَعِلَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="ar">بِأَمْرِهِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> † <em>He became confounded,</em> or <em>perplexed, so that he was unable to see his right course,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>by his affair,</em> or <em>case, and feared, and was disgusted,</em> <span class="auth">(Ḳ,)</span> <em>and remained fixed in his place like as do the palm-trees termed</em> <span class="ar">بَعْل</span>, <span class="auth">(TA,)</span> <em>not knowing what to do.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEl_3">
				<h3 class="entry">3. ⇒ <span class="ar">باعل</span></h3>
				<div class="sense" id="bEl_3_A1">
					<p><span class="ar">باعلت</span>: <a href="#bEl_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEl_3_A2">
					<p><span class="ar long">باعل القَوْمُ قَوْمًا</span> <em>The people intermarried with a people.</em> <span class="auth">(Ḳ.)</span> You say also, <span class="ar long">بَنُو فُلَانٍ لَا يُبَاعَلُونَ</span> <em>The sons of such a one, none is married to them, nor are they married</em> <span class="add">[<em>to any but persons of their own tribe</em>]</span>. <span class="auth">(Ḥam p. 337.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEl_3_A3">
					<p><span class="add">[The inf. n.]</span> <span class="ar">بِعَالٌ</span> signifies also The <em>playing,</em> or <em>toying, together,</em> of a man with his wife; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> and so <span class="ar">مُبَاعَلَةٌ</span> <span class="add">[also an inf. n. of the same verb]</span>, <span class="auth">(Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">تَبَاعُلٌ↓</span></span> <span class="add">[<a href="#bEl_6">inf. n. of 6</a>]</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">باعل ٱمْرَأَتَهُ</span> <em>He played,</em> or <em>toyed, with his wife.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">تُبَاعِلُ زَوْجَهَا</span> <em>She plays,</em> or <em>toys, with her husband.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">بَيْنَهُمَا مُبَاعَلَةً</span> <em>Between them two is playing,</em> or <em>toying.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">هُمَا يَتَبَاعَلَانِ↓</span></span> <em>They two play,</em> or <em>toy, together, each with the other.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEl_3_A4">
					<p>And metonymically, <span class="auth">(TA,)</span> <span class="ar">بِعَالٌ</span> signifies also ‡ <em>I. q.</em> <span class="ar">جِمَاعٌ</span>; <span class="auth">(Az, Ḳ, TA;)</span> and so <span class="ar">مُبَاعَلَةٌ</span>. <span class="auth">(TḲ.)</span> You say, <span class="ar">بَاعَلَهَا</span>, meaning ‡ <em>He lay with her.</em> <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bEl_3_A5">
					<p>And <span class="ar long">باعل فُلَانٌ فُلَانًا</span> ‡ <em>Such a one sat with such a one:</em> <span class="auth">(Ḳ, TA:)</span> the idea of playing, or toying, being imagined to be implied. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبعّل</span></h3>
				<div class="sense" id="bEl_5_A1">
					<p><span class="ar">تبعّلت</span>: <a href="#bEl_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEl_5_A2">
					<p>Also <em>She was obedient to her husband;</em> <span class="auth">(Ḳ;)</span> <span class="add">[so too<span class="arrow"><span class="ar">ابتعلت↓</span></span>, as will be seen from what follows;]</span> and so <span class="ar long">تبعّلت زَوْجَهَا</span>: <span class="auth">(TA:)</span> or <em>she adorned herself for her husband.</em> <span class="auth">(Ḳ.)</span> You say<span class="arrow"><span class="ar long">اِمْرَأَةٌ حَسَنَةٌ الاِبْتِعَالِ↓</span></span> <em>A woman who is good in obedience to her husband.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEl_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباعل</span></h3>
				<div class="sense" id="bEl_6_A1">
					<p><a href="#bEl_3">see 3</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتعل</span></h3>
				<div class="sense" id="bEl_8_A1">
					<p><a href="#bEl_1">see 1</a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEl_8_A2">
					<p><a href="#bEl_5">and see also 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبعل</span></h3>
				<div class="sense" id="bEl_10_A1">
					<p><span class="ar">استبعل</span>: <a href="#bEl_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEl_10_A2">
					<p>Also, said of palm-trees (<span class="ar">نَخْل</span>), <em>They became what are termed</em> <span class="ar">بَعْل</span>, q. v., <span class="auth">(Ṣ, TA,)</span> <em>and great.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEl_10_A3">
					<p>And, said of a place, <em>It became what is termed</em> <span class="ar">بَعْل</span>: <span class="auth">(Ḳ:)</span> or <em>it became elevated.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEolN">
				<h3 class="entry"><span class="ar">بَعْلٌ</span></h3>
				<div class="sense" id="baEolN_A1">
					<p><span class="ar">بَعْلٌ</span> <em>A husband:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> pl. <span class="ar">بُعُولَةٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بُعُولٌ</span> and <span class="ar">بِعَالٌ</span>. <span class="auth">(Ḳ.)</span> And <em>A wife;</em> as also <span class="ar">بَعْلَةٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> like <span class="ar">زَوْجٌ</span> and <span class="ar">زَوْجَةٌ</span>. <span class="auth">(Ṣ, Mṣb.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEolN_A2">
					<p><em>A lord, a master, an owner,</em> or <em>a possessor,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> of a thing, <span class="auth">(Ḳ,)</span> such as a house, and a beast, <span class="auth">(TA,)</span> or a she-camel: <span class="auth">(Ṣ:)</span> <em>a head, chief, ruler,</em> or <em>person of authority.</em> <span class="auth">(El-Khaṭṭábee, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baEolN_A3">
					<p><span class="add">[And hence,]</span> <em>A certain idol,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>of gold,</em> <span class="auth">(TA,)</span> <em>belonging to the people of Ilyás,</em> <span class="auth">(Ṣ, Ḳ,)</span> who is said to be the same as Idrees, the grandfather, or an ancestor, of Noah, or to have been a grandson of Aaron, <span class="auth">(Bḍ in vi. 85,)</span> or the son of the brother of Aaron: <span class="auth">(Jel ibid.:)</span> it is mentioned in the Ḳur xxxvii. 123: accord. to one copy of the Ḳ, <em>it belonged to the people of Jonas;</em> and so in the Kitáb el-Mujarrad of Kr: accord. to Mujáhid, it means <em>a deity that is not God:</em> <span class="auth">(TA:)</span> or <em>a certain king:</em> <span class="auth">(IAạr, Ḳ:)</span> but <span class="add">[SM says,]</span> the correct explanation is the first: <span class="auth">(TA:)</span> or <em>a certain idol belonging to the people of Bekk, in Syria;</em> i. e., <em>of the town now called Baala-Bekk:</em> so in the Ḳur: <span class="auth">(Bḍ, Jel:*)</span> or it means in the dial. of El-Yemen <em>a lord;</em> and so in the Ḳur. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baEolN_A4">
					<p>Also <em>One whom it is a necessary duty to obey;</em> as <em>a father,</em> and <em>a mother,</em> and <em>the like.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baEolN_A5">
					<p>And <em>A family,</em> or <em>household, whose maintenance is incumbent on a man.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baEolN_A6">
					<p>And it may be a contraction of <span class="ar">بَعِلٌ</span>, as meaning <em>Lacking strength,</em> or <em>power,</em> or <em>ability; unable to find the right way to accomplish his affair.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baEolN_A7">
					<p>Also ‡ <em>A weight,</em> or <em>burden.</em> <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar long">أَصْبَحَ فُلَانٌ بَعْلًا عَلَى أَهْلِهِ</span> ‡ <em>Such a one became a weight,</em> or <em>burden, upon his family;</em> because of his ascendency over them. <span class="auth">(Er-Rághib, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="baEolN_A8">
					<p>† <em>Elevated land,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>upon which comes neither running water nor torrent,</em> <span class="auth">(Ṣ,)</span> or <em>that is not rained upon more than once in the year:</em> <span class="auth">(Ḳ:)</span> or ‡ <em>land elevated above other land;</em> as being likened to the man who is thus termed. <span class="auth">(Er-Rághib, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="baEolN_A9">
					<p>† <em>Any palm-trees,</em> and <em>other trees,</em> and <em>seed-produce, not watered:</em> or <em>such as are watered by the rain:</em> <span class="auth">(Ḳ:)</span> or ‡ <em>palm-trees</em> (<span class="ar">نَخْل</span>) <em>that imbibe with their roots, and so need not to be watered:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> metaphorically so applied: <span class="auth">(Mgh:)</span> AA says that it is <em>syn. with</em> <span class="ar">عِذْىٌ</span>, meaning <em>what is watered by the rain:</em> but Aṣ says that this latter word has the meaning just given, whereas <span class="ar">بعل</span> signifies <em>what imbibes with its roots, without irrigation or rain:</em> <span class="auth">(Ṣ, Mṣb:)</span> or <em>palm-trees growing in land whereof the supply of water is near</em> <span class="add">[<em>to the surface</em>]</span>, <em>so that it suffices without their having irrigation or rain:</em> <span class="auth">(TA:)</span> or <em>large, so as to imbibe with the roots:</em> <span class="auth">(Er-Rághib, TA:)</span> and ‡ <em>a male palm-tree;</em> <span class="auth">(Ḳ, TA;)</span> likened to the man who is thus termed: <span class="auth">(TA:)</span> and Az says that it is used as meaning † <span class="add">[<em>dates such as are termed</em>]</span> <span class="ar">قَسْب</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="baEolN_A10">
					<p>And † The <em>tax,</em> or <em>impost, that is given for the watering of palm-trees.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEilN">
				<h3 class="entry"><span class="ar">بَعِلٌ</span></h3>
				<div class="sense" id="baEilN_A1">
					<p><span class="ar">بَعِلٌ</span> part. n. of <span class="ar">بَعِلَ</span>, <em>Confounded,</em> or <em>perplexed,</em>, &amp;c. <span class="auth">(Ḳ.)</span> And <em>Lacking strength,</em> or <em>power,</em> or <em>ability; unable to find the right way to accomplish his affair.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعل</span> - Entry: <span class="ar">بَعِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEilN_A2">
					<p>With <span class="ar">ة</span>, applied as an epithet to a woman, <span class="auth">(Ṣ,)</span> and meaning One <em>who does not dress,</em> or <em>wear clothes, well,</em> <span class="auth">(Ḳ, TA,)</span> <em>nor well adjust her personal state</em> or <em>condition.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0228.pdf" target="pdf">
							<span>Lanes Lexicon Page 228</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
