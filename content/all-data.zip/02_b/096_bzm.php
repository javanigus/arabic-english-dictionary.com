<article class="root" id="Root_bzm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/095_bzl">بزل</a></span>
				<span class="ar">بزم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/097_bzw">بزو</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="IibozaAmN">
				<h3 class="entry"><span class="ar">إِبْزَامٌ</span></h3>
				<div class="sense" id="IibozaAmN_A1">
					<p><span class="ar">إِبْزَامٌ</span>: <a href="#IiboziymN">see what follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboziymN">
				<h3 class="entry"><span class="ar">إِبْزِيمٌ</span></h3>
				<div class="sense" id="IiboziymN_A1">
					<p><span class="ar">إِبْزِيمٌ</span> <span class="auth">(Ṣ, Mgh, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">إِبْزَامٌ↓</span></span> <span class="auth">(Ḳ)</span> <span class="add">[<em>A buckle;</em>]</span> the <em>thing that is at the head</em> <span class="add">[or <em>end</em>]</span> <em>of the</em> <span class="add">[<em>zone,</em> or <em>waist-belt, called</em>]</span> <span class="ar">مِنْطَقَة</span> <span class="auth">(Ṣ, Ḳ)</span> <em>and the like, and that has a tongue, into which</em> <span class="add">[<em>thing</em>]</span> <em>the other extremity</em> <span class="add">[<em>of the</em> <span class="ar">منطقة</span>]</span> <em>enters;</em> <span class="auth">(Ḳ;)</span> <em>a ring with a tongue, which is at the head of the</em> <span class="ar">منطقة</span> <em>and the like, and with which it is fastened;</em> <span class="auth">(Mgh;)</span> the <em>ring that has a tongue which enters into the hole in the lowest part of the shoulderbelt of the sword, and upon which the ring then bites,</em> or <em>presses;</em> the ring altogether <span class="add">[with the tongue]</span> being termed <span class="ar">ابزيم</span>; <span class="auth">(ISh, TA;)</span> the <em>iron thing that is at the end of the girth of the horse's saddle, which is fastened therewith; and sometimes it is at the end of the</em> <span class="ar">منطقة</span>: <span class="auth">(IB, TA:)</span> pl. <span class="ar">أَبَازِيمُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزم</span> - Entry: <span class="ar">إِبْزِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiboziymN_A2">
					<p>Also <em>A lock;</em> and so <span class="ar">إِبْزِينٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزم</span> - Entry: <span class="ar">إِبْزِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiboziymN_A3">
					<p>You say, <span class="ar long">إِنَّ فُلَانًا لَإِبْزِيمٌ</span>, meaning † <em>Verily such a one is a niggard.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0200.pdf" target="pdf">
							<span>Lanes Lexicon Page 200</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
