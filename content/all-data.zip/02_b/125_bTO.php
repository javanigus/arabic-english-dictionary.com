<article class="root" id="Root_bTO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/124_bT">بط</a></span>
				<span class="ar">بطأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/126_bTH">بطح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطأ</span></h3>
				<div class="sense" id="bTO_1_A1">
					<p><span class="ar">بَطُؤَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُأُ</span>}</span></add>, inf. n. <span class="ar">بُطْءٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بَطَآءَةٌ</span>, with fet-ḥ and medd, <span class="auth">(Mṣb,)</span> or <span class="ar">بِطَآءٌ</span>, like <span class="ar">كِتَابٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">ابطأ↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>He was,</em> or <em>became, slow, tardy, dilatory, late,</em> or <em>backward; contr. of</em> <span class="ar">أَسْرَعَ</span>; <span class="auth">(Ḳ;)</span> in his going or course, and in his gait <span class="add">[&amp;c.]</span>: <span class="auth">(TA:)</span> or the latter is said of a man; <span class="auth">(Ṣ, Mṣb;)</span> meaning <span class="add">[as above; or]</span> <em>his coming was late,</em> or <em>backward;</em> <span class="auth">(Mṣb;)</span> <span class="add">[and is app. elliptical, for <span class="ar long">ابطأ مَشْيَهُ</span> <em>he made his pace,</em> or <em>going, slow,</em>, &amp;c.; or the like; <a href="#AsrE">see <span class="ar">اسرع</span></a>:]</span> and <span class="ar">بَطُؤَ</span> <span class="add">[denotes what is as it were an innate quality; see, again, <span class="ar">أَسْرَعَ</span>; or]</span> is said of one's coming; <span class="add">[meaning <em>it was,</em> or <em>became, slow,</em>, &amp;c.;]</span> <span class="auth">(Ṣ, Mṣb;)</span> <span class="ar">بُطْءٌ</span> being the <em>contr. of</em> <span class="ar">سُرْعَةٌ</span>. <span class="auth">(Ṣ.)</span> One should not say <span class="arrow"><span class="ar">أَبْطَيْتَ↓</span></span> for <span class="ar">أَبْطَأْتَ</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#bTA6">See also 6</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTO_1_A2">
					<p><span class="ar long">بَطُءَ ذَا خُرُوجًا</span>: <a href="#buToAna">see <span class="ar">بُطْآنَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTO_2">
				<h3 class="entry">2. ⇒ <span class="ar">بطّأ</span></h3>
				<div class="sense" id="bTO_2_A1">
					<p><span class="ar">بطّأبِهِ</span> <span class="add">[and <span class="ar">بطّأهُ</span>, inf. n. as below, <em>It made him slow, tardy, dilatory, late,</em> or <em>backward;</em>]</span> <em>it kept him,</em> or <em>held him, back;</em> or <em>put him back,</em> or <em>backward.</em> <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">مَنْ بَطَّأَ بِهِ عَمَلُهُ لَمْ يُسْرِعْ بِهِ نَسَبُهُ</span> <em>Him whom his</em> evil <em>deeds keep,</em> or <em>hold, back,</em> or <em>put back,</em> or <em>backward, his</em> nobility of <em>lineage will not profit,</em> <span class="add">[or <em>advance,</em> or <em>put forward,</em>]</span> in the life to come, or in the world to come. <span class="auth">(TA.)</span> <span class="arrow"><span class="ar long">مَا أَبْطَأَ↓ بِكَ</span></span> and <span class="ar long">مَا بَطَّأَ</span> signify the same <span class="add">[<em>What made thee,</em> or <em>hath made thee, slow?</em>, &amp;c.]</span>; <span class="auth">(Ṣ, TA;)</span> and so <span class="ar long">مَا بَطَّأَكَ</span>. <span class="auth">(TA.)</span> And you say, <span class="ar long">بَطَّأَ عَلَيْهِ بِالأَمْرِ</span>, inf. n. <span class="ar">تَبْطِىْءٌ</span>; <span class="pb" id="Page_0216"></span>and<span class="arrow"><span class="ar long">ابطأ↓ بِهِ</span></span>; <em>He delayed to him</em> <span class="add">[<em>the doing of</em>]</span> <em>the thing,</em> or <em>affair.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطأ</span></h3>
				<div class="sense" id="bTO_4_A1">
					<p><a href="#bTA1">see 1</a> <a href="#bTA2">and 2</a>; each in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTO_4_A2">
					<p><span class="ar">أَبْطَؤُوا</span> <em>Their beasts on which they rode were,</em> or <em>became, slow.</em> <span class="auth">(AZ, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTO_4_A3">
					<p><span class="ar long">مَا أَبْطَأَهُ</span> <em>How slow,</em> or <em>tardy, &amp;c., is</em> <span class="add">[<em>he,</em> or]</span> <em>it!</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTO_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباطأ</span></h3>
				<div class="sense" id="bTO_6_A1">
					<p><span class="ar">تباطأ</span> <span class="add">[accord. to general analogy, <em>He feigned,</em> or <em>affected, to be slow, tardy,</em>, &amp;c.: or]</span> <em>he was slow,</em> or <em>sluggish;</em> or <em>he made delay;</em> in going, or pace: and <em>he held back</em> from work, or action. <span class="auth">(KL.)</span> You say of a man, <span class="ar long">تباطأ فِى مَسِيرِهِ</span> <span class="add">[<em>He feigned,</em> or <em>affected, to be slow, &amp;c., in his going, course,</em> or <em>pace</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTO_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبطأ</span></h3>
				<div class="sense" id="bTO_10_A1">
					<p><span class="ar">استبطأهُ</span> <span class="auth">(Ṣ, TA)</span> <em>He deemed him,</em> or <em>reckoned him, slow, tardy,</em>, &amp;c. <span class="auth">(KL.)</span> You say, <span class="ar long">كَتَبَ إِلَىَّ يَسْتَبْطِئُنِى</span> <span class="add">[<em>He wrote to me, deeming me,</em> or <em>reckoning me, slow,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buToCN">
				<h3 class="entry"><span class="ar">بُطْءٌ</span></h3>
				<div class="sense" id="buToCN_A1">
					<p><span class="ar">بُطْءٌ</span> <a href="#bTA1">inf. n. of 1</a>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطأ</span> - Entry: <span class="ar">بُطْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buToCN_A2">
					<p>One says, in the dial. of Benoo-Yarbooa, <span class="auth">(TA,)</span> <span class="ar long">لَمْ أَفْعَلْهُ بُطْءًا يَاهٰذَا</span>, and<span class="arrow"><span class="ar">بُطْأَى↓</span></span>, <span class="add">[<em>I never did it,</em> lit.]</span> <em>I did it not ever, O thou!</em> i. e. <span class="ar">الدَّهْرَ</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buToOae">
				<h3 class="entry"><span class="ar">بُطْأَى</span></h3>
				<div class="sense" id="buToOae_A1">
					<p><span class="ar">بُطْأَى</span>: <a href="#buToCN">see <span class="ar">بُطْءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buToMna">
				<h3 class="entry"><span class="ar">بُطْآنَ</span></h3>
				<div class="sense" id="buToMna_A1">
					<p><span class="ar long">بُطْآنَ ذَا خُرُوجًا</span>, and <span class="ar">بَطْآنَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> but the latter is extr., <span class="auth">(TA,)</span> <em>i. q.</em><span class="arrow"><span class="ar long">بَطُؤَ↓ ذَا خُرُوجًا</span></span> <span class="add">[<em>Slow,</em> or <em>very slow,</em> or <em>how slow, is this in coming forth!</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> the fet-ḥah in <span class="add">[the last syllable of]</span> <span class="ar">بَطُؤَ</span> is transferred to the <span class="ar">ن</span> of <span class="ar">بُطْآن</span>, and the ḍammeh of the <span class="ar">ط</span> <span class="add">[in the former]</span> to the <span class="ar">ب</span> <span class="add">[in the latter]</span>; the meaning being one of wonder; i. e. <span class="ar long">مَا أَبْطَأَهُ</span>. <span class="auth">(Ṣ, TA.)</span> <span class="add">[<span class="ar">بطآن</span> is an enunciative placed before its inchoative: and, being originally <span class="ar">بَطُؤَ</span>, it may be a simple enunciative, or an enunciative having an intensive signification; as that verb signifies simply “it was slow,”, &amp;c., and may be used as co-ordinate to <span class="ar">رَمُوَ</span>, meaning “excellent is he in his shooting!”, &amp;c., and <span class="ar">قَضُوَ</span> “excellent is he in his judging!”, &amp;c.: or it may be equivalent to <span class="ar long">مَا أَبْطَأَ</span>, as it is said to be in the Ṣ. <a href="#saroEaAna">See also <span class="ar">سَرْعَانَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTieoCN">
				<h3 class="entry"><span class="ar">بَطِىْءٌ</span></h3>
				<div class="sense" id="baTieoCN_A1">
					<p><span class="ar">بَطِىْءٌ</span> <em>Slow, tardy, dilatory, late,</em> or <em>backward;</em> applied to a man, <span class="auth">(Ṣ, Mṣb, TA,)</span> and to a horse or the like: <span class="auth">(Ṣ, TA:)</span> pl. <span class="ar">بَطَآءٌ</span>. <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطأ</span> - Entry: <span class="ar">بَطِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baTieoCN_A2">
					<p>Also an imitative sequent to <span class="ar">حَطِىْءٌ</span>. <span class="auth">(Ṣ in art. <span class="ar">حطأ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboTaOu">
				<h3 class="entry"><span class="ar">أَبْطَأُ</span></h3>
				<div class="sense" id="OaboTaOu_A1">
					<p><span class="ar">أَبْطَأُ</span> <em>More,</em> and <em>most, slow,</em>, &amp;c. <span class="auth">(Meyd, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmaboTaOu">
				<h3 class="entry"><span class="ar">المَبْطَأُ</span></h3>
				<div class="sense" id="AlmaboTaOu_A1">
					<p><span class="ar">المَبْطَأُ</span> for <span class="ar">المَبْدَأُ</span> is mentioned by AO. <span class="auth">(TA on the letter <span class="ar">ط</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0215.pdf" target="pdf">
							<span>Lanes Lexicon Page 215</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0216.pdf" target="pdf">
							<span>Lanes Lexicon Page 216</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
