<article class="root" id="Root_bXE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/109_bXr">بشر</a></span>
				<span class="ar">بشع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/111_bXq">بشق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bXE_1">
				<span class="pb" id="Page_0209"></span>
				<h3 class="entry">1. ⇒ <span class="ar">بشع</span></h3>
				<div class="sense" id="bXE_1_A1">
					<p><span class="ar">بَشِعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْشَعُ</span>}</span></add>, <span class="auth">(Ḳ, TA,)</span> inf. n. <span class="ar">بَشَاعَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بَشَعٌ</span>, <span class="auth">(Ḳ,)</span> said of a thing, <span class="auth">(Ṣ,)</span> or of food, <span class="auth">(Ḳ, TA,)</span> <em>It was,</em> or <em>became, disagreeable in taste, and choking:</em> <span class="auth">(Ṣ:)</span> or <em>disagreeable,</em> or <em>unpleasant, having in it dryness and bitterness.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bXE_1_A2">
					<p><span class="ar long">بَشِعَ الرَّجُلُ</span>, <span class="auth">(Ḳ,* TA,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْشَعُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَشَعٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بَشَاعَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>The man was,</em> or <em>became, disagreeable in the odour of the mouth,</em> <span class="auth">(Ṣ,* Ḳ,)</span> <em>from eating food disagreeable in taste, and choking;</em> <span class="auth">(Ṣ;)</span> <em>not removing the remains of food from between his teeth, nor cleaning them with the tooth-stick.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">بَشِعَ مِنْهُ</span> <span class="add">[<em>He was,</em> or <em>became, disagreeable in the odour of the mouth from it</em>]</span>; meaning, from eating food such as is described above. <span class="auth">(Ṣ.)</span> <span class="add">[Or this phrase in the Ṣ may have another meaning, which see in what follows.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bXE_1_A3">
					<p>And <span class="add">[hence,]</span> ‡ <em>The man was,</em> or <em>became, evil in his disposition, and in his social intercourse.</em> <span class="auth">(Mṣb.)</span> You say also, <span class="ar long">فِى خُلُقِهِ بَشَاعَةٌ</span> ‡ <em>In his disposition is evilness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bXE_1_A4">
					<p><span class="ar">بَشَعٌ</span> also signifies, in relation to wood, ‡ The <em>abounding in knots.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bXE_1_A5">
					<p>Also The fauces' <em>being straitened,</em> or <em>choked, by coarse,</em> or <em>rough, food.</em><span class="auth">(TA.)</span> <span class="add">[And <span class="ar long">بَشِعَ مِنْهُ</span> means <em>He experienced a straitened state,</em> or <em>choking, of the fauces from it;</em> namely coarse, or rough, food; or food disagreeable in taste, and choking: <a href="#bXE_4">see 4</a>: and see another meaning of this phrase above.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bXE_1_A6">
					<p>And <span class="add">[hence,]</span> <span class="ar">بَشِعَ</span> <span class="add">[or <span class="ar long">بَشِعَ بِالمَآءِ</span>,]</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْشَعُ</span>}</span></add>, ‡ <em>It</em> <span class="auth">(a valley)</span> <em>was,</em> or <em>became, choked, surcharged,</em> or <em>overfilled, with the water.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">بَشِعَ بِالنَّاسِ</span> ‡ <em>It</em> <span class="add">[a place]</span> <em>was,</em> or <em>became, choked,</em> or <em>overfilled, with men,</em> or <em>the people.</em> <span class="auth">(Z, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bXE_1_A7">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بَشِعَ بِالأَمْرِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَشَعٌ</span> and <span class="ar">بَشَاعَةٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He was unable to do,</em> or <em>accomplish, the thing,</em> or <em>affair.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bXE_1_B1">
					<p><span class="ar long">بَشِعَ بِالشَّىْءِ</span>, and <span class="ar long">بَشَعَ بِهِ</span>, inf. n.<span class="ar">بَشْعٌ</span>, <em>He seized the thing in a violent and an abominable manner.</em> <span class="auth">(L,TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXE_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابشع</span></h3>
				<div class="sense" id="bXE_4_A1">
					<p><span class="ar long">أَبْشَعَنِى الطَّعَامُ</span> <em>The food caused me to experience a straitened state,</em> or <em>choking, of the fauces,</em> (<span class="ar long">حَمَلَنِى عَلَى البَشَعِ</span>,) <em>by reason of its coarseness,</em> or <em>roughness.</em> <span class="auth">(IAạr.)</span> <span class="add">[<a href="#bXE_1">See 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bXE_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبشع</span></h3>
				<div class="sense" id="bXE_10_A1">
					<p><span class="ar">استشعهُ</span> <em>i. q.</em> <span class="ar long">عَدَّهُ بَشِعًا</span> <span class="add">[<em>He reckoned it disagreeable in taste, and choking;</em> or <em>disagreeable,</em> or <em>unpleasant, as having in it dryness and bitterness</em>]</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> namely, a thing. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bXE_10_A2">
					<p>And <span class="add">[hence,]</span> <span class="ar long">استبشع المُقَامَ فِى مَحَلِّ كَذَا</span> <em>He reckoned unpleasant,</em> or <em>uncomfortable, the remaining in such a place of abode;</em> syn.<span class="ar">اِسْتَخْشَنَهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bXE_10_B1">
					<p><span class="ar">اِسْتِبْشَاعٌ</span> also signifies <em>The being bad, unpleasant,</em> or <em>disapproved.</em> <span class="auth">(KL.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXiEN">
				<h3 class="entry"><span class="ar">بَشِعٌ</span> / <span class="ar">بَشِعَةٌ</span></h3>
				<div class="sense" id="baXiEN_A1">
					<p><span class="ar">بَشِعٌ</span> A thing <em>disagreeable in taste, and choking;</em> or<span class="arrow"><span class="ar">بَشِيعٌ↓</span></span> has this signification: <span class="auth">(so accord. to different copies of the Ṣ:)</span> or both, applied to food, have the same signification: <span class="auth">(TA:)</span> or the former signifies also <em>disagreeable,</em> or <em>unpleasant,</em> food, <em>having in it dryness and bitterness;</em> <span class="auth">(Lth, Z, Ḳ;)</span> <em>like the taste of the myrobalan:</em> <span class="auth">(TA:)</span> or <em>food rough,</em> or <em>coarse, and disagreeable in taste:</em> or <em>dry food, in which is no seasoning,</em> or <em>condiment:</em> <span class="auth">(TA:)</span> or <em>rough,</em> or <em>coarse;</em> applied to food; <span class="auth">(Nh;)</span> and so ‡ applied to clothing; <span class="auth">(IAạr, Nh;)</span> and ‡ to speech, or language; <span class="auth">(Nh;)</span> and<span class="arrow"><span class="ar">بَشِيعٌ↓</span></span> applied to speech, or language, signifies ‡ <em>rough,</em> or <em>coarse, and disagreeable.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: <span class="ar">بَشِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baXiEN_A2">
					<p>Applied to a man, <span class="auth">(Ṣ TA,)</span> as is also <span class="arrow"><span class="ar">بَشِيعٌ↓</span></span>, in the same sense, <span class="auth">(TA, <span class="add">[but in what sense is not there said,]</span>)</span> it signifies, <em>Disagreeable in the odour of the mouth,</em> <span class="auth">(Mṣb,ast; Ḳ,)</span> <em>who does not remove the remains of food from between his teeth, nor clean them with the tooth-stick;</em> <span class="auth">(Ḳ;)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَشِعَةٌ</span>}</span></add>: <span class="auth">(TA:)</span> and one <em>who has eaten a thing such as is thus termed,</em> <span class="auth">(Ṣ Ḳ TA,)</span> <em>and not swallowed it easily,</em> <span class="auth">(TA,)</span> <em>and has become disagreeable in the odour of the mouth from it,</em> or <em>has experienced a straitened state,</em> or <em>choking, of the fauces from it.</em> <span class="auth">(Ṣ, TA: <span class="add">[the last words of the explanation being <span class="ar long">فَبَشِعَ مِنْهُ</span>]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: <span class="ar">بَشِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baXiEN_A3">
					<p>Also ‡ <em>One whose soul is heavy,</em> or <em>heaving,</em> or <em>agitated by a tendency to vomit.</em> <span class="auth">(ISh, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: <span class="ar">بَشِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baXiEN_A4">
					<p>And ‡ <em>Evil in disposition,</em> <span class="auth">(Ḳ, TA,)</span> <em>and in social intercourse.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">هُوَ بَشِعَ الخُلُقِ</span> ‡ <em>He is evil in disposition.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: <span class="ar">بَشِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baXiEN_A5">
					<p>Also, <span class="auth">(Ḳ, TA,)</span> or <span class="ar long">بَشِعُ المَنْظَرِ</span>, <span class="auth">(Mṣb,)</span> ‡ <em>Foul,</em> or <em>ugly, in aspect;</em> <span class="auth">(Mṣb; Ḳ)</span> <em>not pleasing to the eyes.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: <span class="ar">بَشِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baXiEN_A6">
					<p>Also, <span class="auth">(Ḳ,)</span> or <span class="ar long">بَشِعُ الوَجْهِ</span>, <span class="auth">(ISh, Mṣb,)</span> ‡ <em>Having a frowning, a contracted, a stern, an austere,</em> or <em>a morose, countenance.</em> <span class="auth">(ISh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بشع</span> - Entry: <span class="ar">بَشِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baXiEN_A7">
					<p><span class="ar long">خَشَبَةٌ بَشِعَةٌ</span> ‡ <em>A piece of wood abounding in knots.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baXiyEN">
				<h3 class="entry"><span class="ar">بَشِيعٌ</span></h3>
				<div class="sense" id="baXiyEN_A1">
					<p><span class="ar">بَشِيعٌ</span>: <a href="#baXiEN">see <span class="ar">بَشِعٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0209.pdf" target="pdf">
							<span>Lanes Lexicon Page 209</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
