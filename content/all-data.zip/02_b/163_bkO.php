<article class="root" id="Root_bkO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/162_bqe">بقى</a></span>
				<span class="ar">بكأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/164_bkt">بكت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bkO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بكأ</span></h3>
				<div class="sense" id="bkO_1_A1">
					<p><span class="ar">بَكَأَتْ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْكَأُ</span>}</span></add>; and <span class="ar">بَكُؤَتْ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْكُأُ</span>}</span></add>, inf. n. <span class="ar">بَكْءٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُكْءٌ</span> <span class="auth">(AZ, TA)</span> and <span class="ar">بَكَأَةٌ</span>, or <span class="ar">بَكْأَةٌ</span>, <span class="auth">(accord. to different copies of the Ḳ,)</span> or <span class="ar">بَكَآءَةٌ</span>, <span class="auth">(as in the O and CK,)</span> and <span class="ar">بُكُوْءٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> which is inf. n. of <span class="ar">بَكُؤَ</span>, <span class="auth">(Ṣ, TA,)</span> as is also that next preceding it, <span class="auth">(TA,)</span> and <span class="ar">بُكَآءٌ</span>, <span class="auth">(AZ, Ḳ, TA,)</span> in some copies of the Ḳ <span class="ar">بُكْءٌ</span>, <span class="auth">(TA,)</span> <em>She</em> <span class="auth">(a camel, Ṣ, Ḳ, or a ewe or goat, Ṣ)</span> <em>had little milk; her milk became little:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> or, as some say, <em>her milk ceased,</em> or <em>stopped.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkO_1_A2">
					<p>And <span class="add">[hence,]</span> <span class="ar long">بَكَأَتْ عَيْنِى</span> † <em>My eye had few tears.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bkO_1_A3">
					<p>And <span class="ar">بَكُؤَ</span>, inf. n. <span class="ar">بَكَآءَةٌ</span>, <span class="add">[app. † <em>He became poor; had little wealth;</em> being]</span> said of a man. <span class="auth">(TA.)</span> <span class="add">[<a href="#bkA4">See also 4</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bkO_1_A4">
					<p>And <span class="ar">بَكِئ</span> † <em>He failed of attaining the object of his want.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bkO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابكأ</span></h3>
				<div class="sense" id="bkO_4_A1">
					<p><span class="ar long">قَدْ أَبْكَأَ الدَّرَّ</span>, occurring in a verse, <span class="add">[see Ḥam p. 758,]</span> is asserted by Aboo-Riyásh to mean <em>He</em> <span class="auth">(the milker)</span> <em>has found the milk to be little in quantity;</em> like as <span class="ar">أَحْمَدَهُ</span> signifies “he found him to be such as is praised:” ISd holds that it may signify <em>he has made the milk to be little in quantity</em> <span class="add">[app. by his niggardness]</span>; but he confesses his not having heard the verb used in this sense by any one. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bkO_4_B1">
					<p><span class="ar">ابكأ</span> also signifies † <em>He</em> <span class="auth">(a man)</span> <em>became poor;</em> or <em>in the condition of having little,</em> or <em>no, wealth.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bakuwa">See also <span class="ar">بَكُؤَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakoCN">
				<h3 class="entry"><span class="ar">بَكْءٌ</span></h3>
				<div class="sense" id="bakoCN_A1">
					<p><span class="ar">بَكْءٌ</span> <span class="add">[<a href="#bkA1">originally inf. n. of 1, q. v.</a>: and hence,]</span> † <em>Poverty;</em> or <em>paucity of wealth.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: <span class="ar">بَكْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bakoCN_A2">
					<p>And † <em>Paucity of speech, except as to things requiring speech.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakieoCN">
				<h3 class="entry"><span class="ar">بَكِىْءٌ</span></h3>
				<div class="sense" id="bakieoCN_A1">
					<p><span class="ar">بَكِىْءٌ</span> and <span class="ar">بَكِيْئَةٌ</span> A she-camel, <span class="auth">(Ṣ, Ḳ,)</span> or a ewe or she-goat, <span class="auth">(Ṣ,)</span> <em>having little milk; whose milk has become little:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> or, as some say, <em>whose milk has ceased,</em> or <em>stopped:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بِكَآءٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بَكَايَا</span> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: <span class="ar">بَكِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bakieoCN_A2">
					<p>And <span class="add">[hence,]</span> <span class="ar long">دَرٌّ بَكِىْءٌ</span> † <span class="add">[<em>Milk,</em> or <em>a flow of milk, little in quantity</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: <span class="ar">بَكِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bakieoCN_A3">
					<p>And <span class="ar long">رَكِيَّةٌ بَكِيَّةٌ</span> † <em>A well of which the water has sunk into the earth;</em> or <em>become low:</em> the latter word having its <span class="ar">ء</span> changed into <span class="ar">ى</span> to assimilate it to the former. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: <span class="ar">بَكِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bakieoCN_A4">
					<p>And <span class="ar long">عُيُونٌ بِكَآءٌ</span> † <em>Eyes having few tears.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكأ</span> - Entry: <span class="ar">بَكِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bakieoCN_A5">
					<p>And <span class="ar long">أَيْدٍ بِكَآءٌ</span> † <em>Hands of which the gifts are few.</em> <span class="auth">(TA.)</span> And <span class="ar long">رَجُلٌ بَكِىةءٌ</span> † <span class="add">[app. <em>A poor man; a man having little wealth:</em> or <em>of few words:</em> or <em>unable to speak:</em> <a href="#bakoCN">see <span class="ar">بَكْءٌ</span></a>; <a href="#bakieBN">and see <span class="ar">بَكِىٌّ</span></a>, <a href="index.php?data=02_b/167_bke">in art. <span class="ar">بكى</span></a>]</span>: pl. <span class="ar">بِكَآءٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0239.pdf" target="pdf">
							<span>Lanes Lexicon Page 239</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
