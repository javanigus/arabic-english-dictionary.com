<article class="root" id="Root_blh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/182_bln">بلن</a></span>
				<span class="ar">بله</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/184_blw">بلو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blh_1">
				<h3 class="entry">1. ⇒ <span class="ar">بله</span></h3>
				<div class="sense" id="blh_1_A1">
					<p><span class="ar">بَلِهَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَهُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَلَهٌ</span>, <span class="auth">(Ṣ,* Mṣb, Ḳ,* TA,)</span> <span class="add">[and irregularly <span class="ar">بَلَاهَةٌ</span> and <span class="ar">بُلَهْنِيَةٌ</span>, (<a href="#balahN">see <span class="ar">بَلَهٌ</span>, below</a>,)]</span> <em>He was,</em> or <em>became,</em> <span class="ar">أَبْلَه</span> <span class="add">[q. v.]</span>; as also<span class="arrow"><span class="ar">تبلّه↓</span></span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">ابتله↓</span></span>: <span class="auth">(TA:)</span> or <em>he was,</em> or <em>became, weak in intellect.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blh_1_A2">
					<p>Also <em>He was unable to adduce his argument, proof,</em> or <em>evidence,</em> <span class="auth">(Ḳ, TA,)</span> <em>by reason of his heedlessness, and his smallness,</em> or <em>lack, of discrimination.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blh_3">
				<h3 class="entry">3. ⇒ <span class="ar">باله</span></h3>
				<div class="sense" id="blh_3_A1">
					<p><span class="ar">مُبَالَهَةٌ</span> The <em>showing stupidity</em> <span class="add">[<em>in an action</em> or <em>in one's actions,</em> i. e. the <em>acting stupidly,</em>]</span> <em>with any one.</em> <span class="auth">(KL.)</span> <span class="add">[You say, <span class="ar">بالههُ</span> <em>He acted stupidly,</em> or <em>in the manner of him who is termed</em> <span class="ar">أَبْلَه</span>, <em>with him.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blh_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابله</span></h3>
				<div class="sense" id="blh_4_A1">
					<p><span class="ar">ابلههُ</span> <em>He found him,</em> or <em>knew him by experience, to be</em> <span class="ar">أَبْلَه</span> <span class="add">[q. v.]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blh_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّه</span></h3>
				<div class="sense" id="blh_5_A1">
					<p><span class="ar">تبلّه</span>: <a href="#blh_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blh_5_A2">
					<p><a href="#blh_6">And see 6</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blh_5_A3">
					<p>Also ‡ <em>He journeyed,</em> or <em>proceeded,</em> or <em>pursued his way, without any sign of the road,</em> or <em>any track, to guide him,</em> <span class="auth">(Az, Ḳ, TA,)</span> <em>without following the right course,</em> <span class="auth">(Az, TA,)</span> <em>and without asking</em> <span class="add">[<em>to be directed</em>]</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="blh_5_A4">
					<p>And † <em>He prosecuted a search after a stray,</em> or <em>lost, beast.</em> <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blh_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباله</span></h3>
				<div class="sense" id="blh_6_A1">
					<p><span class="ar">تباله</span> <em>He feigned</em> <span class="ar">بَلَه</span>, or <em>the attribute denoted by the term</em> <span class="ar">أَبْلَه</span>: <span class="auth">(Ṣ:)</span> or <em>he made use of that attribute</em> <span class="add">[<em>as a mask</em>]</span>; i. q. <span class="ar long">اِسْتَعْمَلَ البَلَهَ</span>; as also<span class="arrow"><span class="ar">تبلّه↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blh_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتله</span></h3>
				<div class="sense" id="blh_8_A1">
					<p><a href="#blh_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baloha">
				<h3 class="entry"><span class="ar">بَلْهَ</span></h3>
				<div class="sense" id="baloha_A1">
					<p><span class="ar">بَلْهَ</span> is an indecl. word with fet-ḥ for its termination, like <span class="ar">كَيْفَ</span>, and means <span class="ar">دَعْ</span> <span class="add">[<em>Let alone,</em> or <em>say nothing of</em>]</span>; <span class="auth">(Ṣ;)</span> <span class="add">[i. e.]</span> it is a noun for <span class="ar">دَعْ</span>; indecl.; <span class="auth">(Mughnee, Ḳ;)</span> a verbal noun, meaning <span class="ar">دَعْ</span> and <span class="ar">أُتْرُكْ</span>; <span class="auth">(IAth, TA;)</span> <span class="pb" id="Page_0254"></span>and the noun that follows it, when it is thus used, is in the accus. case; <span class="auth">(Mughnee, Ḳ;)</span> i. e. it is indecl., with fet-ḥ for its termination, when the noun following it is in the accus. case; so that you say, <span class="ar long">بَلْهَ زَيْدًا</span> <span class="add">[<em>Let alone Zeyd,</em> or <em>say nothing of Zeyd</em>]</span>; like as you say, <span class="ar long">رُوَيْدَ زَيْدًا</span>: <span class="auth">(IB, TA:)</span> and it is also an inf. n. in the sense of <span class="ar">التَّرْكُ</span>; likewise with fet-ḥ for its termination, but decl.; and when it is thus used, the noun that follows it is in the gen. case; <span class="auth">(Mughnee, Ḳ;)</span> or it is put in the place of an inf. n., meaning <span class="ar">تَرْكَ</span> <span class="add">[which is virtually the same as <span class="ar">اُتْرُكْ</span> and <span class="ar">دَعْ</span>]</span>, and is prefixed to a noun in the gen. case; so that you say, <span class="ar long">بَلْهَ زَيْدٍ</span>, i. e. <span class="ar long">تَرْكَ زَيْدٍ</span> <span class="add">[which is virtually the same as <span class="ar long">بَلْهَ زَيْدًا</span> explained above; for <span class="ar long">تَرْكَ زَيْدٍ</span> is originally <span class="ar long">اُتْرُكْ زَيْدًا تَرْكًا</span>, like as <span class="ar long">فَضَرْبَ الرِّقَابِ</span> in the Ḳur xlvii. 4 is originally <span class="ar long">فٱضْرِبُوا الرِّقَابَ ضَرْبًا</span>]</span>; <span class="auth">(IAth, TA;)</span> for in this case it cannot be regarded as a verbal noun, since verbal nouns are not prefixed to other nouns, governed by them in the gen. case: <span class="auth">(IB, TA:)</span> and it is also a noun syn. with <span class="ar">كَيْفَ</span> <span class="add">[<em>How?</em>]</span>; likewise with fet-ḥ for its termination, indecl.; and when it is thus used, the noun that follows it is in the nom. case. <span class="auth">(Mughnee, Ḳ.)</span> A poet says, describing swords, <span class="auth">(Ṣ, Mughnee,)</span> namely, Kaab Ibn-Málik, <span class="auth">(Ṣ,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَذَرُ الجَمَاجِمَ ضَاحِيًا هَامَتُهَا</span> *</div> 
						<div class="star">* <span class="ar long">بَلْهَ الأَكُفَّ كَأَنَّهَا لَمْ تُخْلَقِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They leave the skulls with their crowns lying open to the sun</em> (<em>let alone,</em> or <em>say nothing of, the hands</em>) <em>as though they had not been created</em>]</span>: <span class="auth">(Ṣ, Mughnee:)</span> he says, when they cut, or cut off, the crowns, then let alone, or say nothing of, the hands (<span class="ar long">فَدَعِ الأَكُفَّ</span>): i. e., they are more fit for cutting off the hands: <span class="auth">(TA:)</span> Akh says that <span class="ar">بله</span> is here in the place of an inf. n.; that it is as when you say, <span class="ar long">ضَرْبَ زَيْدٍ</span>: but <span class="ar">الاكفّ</span> may be in the accus. case; so that the meaning may be <span class="ar long">دَعِ الأَكُفَّ</span>: <span class="auth">(Ṣ:)</span> the verse is thus recited in two different ways: and also <span class="ar long">بَلْهَ الأَكُفُّ</span> <span class="add">[<em>how</em> then must be the case of <em>the hands?</em>]</span>. <span class="auth">(Mughnee.)</span> And hence the prov., <span class="ar long">تُحْرِقُكَ النَّارُ إِنْ تَرَاهَا بَلْهَ أَنْ تَصْلَاهَا</span>, i. e. <em>The fire will burn thee if thou see it</em> from a distance: <em>then let alone,</em> or <em>say nothing of,</em> (<span class="ar">فَدَعْ</span>,) <em>thy entering into it.</em> <span class="auth">(TA.)</span> A strange instance occurs in the Saheeh of El-Bukháree, in the explanation of the <span class="ar">آلٓمٓ</span> of the chapter of <span class="ar">السَّجْدَة</span> <span class="add">[the 32nd ch. of the Ḳur]</span>: he says, God says <span class="add">[by these three letters]</span>, <span class="ar long">أَعْدَدْتُ لِعِبَادِى الصَّالِحِينَ مَا لَا عَيْنٌ رَأَتْ وَلَا أُذُنٌ سَمِعَتْ وَلَا خَطَرِ عَلَى قَلْبِ بَشَرٍ ذُخْرًا مِنْ بَلْهِ مَا ٱطَّلَعْتُمْ عَلَيْهِ</span>: <span class="auth">(Mughnee, Ḳ:*)</span> or <span class="ar long">ما أَطَلَعْتُهُمْ عَلَيْهِ</span>: <span class="auth">(so in some copies of the Ḳ:)</span> thus <span class="ar">بله</span> is used as a decl. word, governed in the gen. case by <span class="ar">من</span>, and deviating from the three meanings <span class="add">[explained above]</span>: <span class="auth">(Mughnee, Ḳ:)</span> but the reading commonly known is, <span class="ar long">على قلب بشر بَلْهَ مَ أَطْلَعْتُهُمْ عليه</span>; and this is the reading in the work of J, <span class="add">[the Ṣ,]</span> and in the Nh, and other lexicological works: <span class="auth">(TA:)</span> it has been explained by <span class="ar">غَيْر</span>; <span class="add">[so that the meaning of the sentence as first related above is, <em>I have prepared for my righteous servants what eye hath not seen, nor ear heard, nor hath it occurred to the mind of man, as a treasure for the future,</em> <span class="auth">(obviously taken from Isaiah lxiv. 4, quoted by St. Paul in 1 Cor. ii. 9,)</span> <em>save,</em> or <em>except, that with which ye have become acquainted,</em> or <em>that with which I have acquainted them;</em> and the same, with the omission of “as a treasure for the future, “is the meaning of the sentence as related in the Ṣ and Nh, &amp;c.;]</span> <span class="auth">(Mughnee, Ḳ;)</span> i. e. <span class="ar">سِوَى</span>, as in the Ṣ; <span class="auth">(TA;)</span> and this corroborates, <span class="auth">(Mughnee,)</span> or is agreeable with, <span class="auth">(Ḳ,)</span> the opinion of those who reckon <span class="ar">بله</span> as an exceptive word: <span class="auth">(Mughnee, Ḳ:)</span> and as meaning <span class="ar">أَجَلْ</span> <span class="add">[app. a mistranscription for <span class="ar">أَجْل</span>; i. e., it has been explained also as meaning I have done all this because of my promise to them; (<span class="ar long">مِنْ أَجْلِ مَا أَطْلَعْتُهُمْ عَلَيْهِ</span> <em>because of that with which I have acquainted them;</em>) and thus it may have been read by SM, for he has written <span class="ar">اجل</span> without any syll. signs; and has given no other ex. of <span class="ar">بله</span> in the sense here intended except one commencing with the words, <span class="ar long">بَلْهَ انِّى لَمْ أَخُنْ عَهْدًا</span>, which may mean <em>because I have not broken a covenant,</em> or <em>yea, verily I have not</em>, &amp;c., accord. as we read <span class="ar">أَنِّى</span> or <span class="ar">إِنِّى</span>]</span>: or as meaning <span class="ar">كُفَّ</span> <span class="add">[or rather <span class="ar long">كُفَّ عَنْ</span>]</span> and <span class="ar">دَعْ</span> <span class="add">[<em>let alone,</em> or <em>say nothing of;</em> but this explanation must relate to the sentence as given in the Ṣ and Nh]</span>: <span class="auth">(Ḳ, but omitted in an excellent copy of that work:)</span> or, accord. to El-Aḥmar, it means, in this trad. <span class="add">[as commonly known]</span>, <span class="ar">كَيُفَ</span> <span class="add">[<em>how?</em> which seems to be the least suitable of all these explanations]</span>. <span class="auth">(TA.)</span> IAmb relates, on the authority of others, that <span class="ar">بَلْهَ</span> is also <em>syn. with</em> <span class="ar">عَلَى</span>: <span class="add">[but I think that this is a mistake, arising from a misunderstanding of what here follows:]</span> Fr says that he who makes it to govern a gen. case regards it as used in the manner of <span class="ar">عَلَى</span>, and similar particles governing the gen. case. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: <span class="ar">بَلْهَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baloha_A2">
					<p><span class="ar long">مَا بَلْهَكَ</span> means <span class="ar long">مَا بَالُكَ</span> <span class="add">[<em>What is thy state,</em> or <em>condition,</em> or <em>case?</em>]</span>: <span class="auth">(Ḳ, TA:)</span> or <span class="ar long">مَا لَكَ</span> <span class="add">[which often has this meaning: see the letter <span class="ar">ل</span>]</span>. <span class="auth">(So in some copies of the Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balahN">
				<h3 class="entry"><span class="ar">بَلَهٌ</span></h3>
				<div class="sense" id="balahN_A1">
					<p><span class="ar">بَلَهٌ</span> and<span class="arrow"><span class="ar">بَلَاهَةٌ↓</span></span> <span class="add">[both properly inf. ns.; <a href="#blh_1">see 1</a>;]</span> The <em>attribute,</em> or <em>quality, denoted by the epithet</em> <span class="ar">أَبْلَهٌ</span> <span class="add">[q. v.]</span>; <span class="auth">(Ṣ, Ḳ;)</span> i. e. <em>heedlessness:</em> <span class="auth">(Ḳ:)</span> or <em>heedlessness of evil;</em> <span class="auth">(JK in explanation of the former, and Ḳ;)</span>, &amp;c.; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">بُلَهْنِيَةٌ↓</span></span> signifies the same; and <em>stupidity and languor.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balahaMCu">
				<h3 class="entry"><span class="ar">بَلَهَآءُ</span></h3>
				<div class="sense" id="balahaMCu_A1">
					<p><span class="ar">بَلَهَآءُ</span>: <a href="#Oabolahu">see <span class="ar">أَبْلَهُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulahoniyapN">
				<h3 class="entry"><span class="ar">بُلَهْنِيَةٌ</span></h3>
				<div class="sense" id="bulahoniyapN_A1">
					<p><span class="ar">بُلَهْنِيَةٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">بَلَهْنِيَةُ العَيْشِ</span>, <span class="auth">(JK,)</span> or <span class="ar long">مِنَ العَيْشِ</span>, <span class="auth">(Ṣ,)</span> ‡ <em>An easy and a plentiful,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> or <em>a pleasant and heedless,</em> <span class="auth">(JK, TA,*)</span> <em>state,</em> or <em>condition, of life:</em> <span class="auth">(JK, Ṣ, Ḳ, TA:)</span> from <span class="ar long">عَيْشٌ أَبْلَهُ</span> <span class="add">[q. v.]</span>: <span class="auth">(Ḥar p. 216:)</span> the word <span class="ar">بلهنية</span> is rendered quasi-coordinate to the quinqueliteral-radical class by <span class="ar">ا</span> at the end, which is changed into <span class="ar">ى</span> because of the kesreh before it: <span class="auth">(Ṣ in art. <span class="ar">بلهن</span>:)</span> it is like <span class="ar">رُفَغْنِيَةٌ</span> and <span class="ar">رُفَهْنِيَةٌ</span>: IB says that it should be mentioned in art. <span class="ar">بله</span>, and means <span class="ar long">عَيْشٌ أَبْلَهُ</span>; the <span class="ar">ن</span> and <span class="ar">ى</span> being augmentative, to render it quasicoordinate to <span class="ar">خُبَعْثِنَةٌ</span>: it is mentioned in the Ḳ <span class="add">[and Ṣ]</span> in arts. <span class="ar">بلهن</span> and <span class="ar">بله</span>: <span class="auth">(TA in art. <span class="ar">بلهن</span>:)</span> the <span class="ar">ن</span> is augmentative accord. to Sb. <span class="auth">(Ṣ in the present art.)</span> One says, <span class="ar long">لَا زِلْتَ مُلَقًّى بِتَهْنِئَةٍ مُبَقًّى فِىبُلَهْنِيَةٍ</span> ‡ <span class="add">[<em>Mayest thou not cease to be greeted with congratulation,</em> and <em>made to continue in an easy and a plentiful state of life</em>]</span>. <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: <span class="ar">بُلَهْنِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulahoniyapN_A2">
					<p><a href="#balahN">See also <span class="ar">بَلَهٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balaAhapN">
				<h3 class="entry"><span class="ar">بَلَاهَةٌ</span></h3>
				<div class="sense" id="balaAhapN_A1">
					<p><span class="ar">بَلَاهَةٌ</span>: <a href="#balahN">see <span class="ar">بَلَهٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabolahu">
				<h3 class="entry"><span class="ar">أَبْلَهُ</span></h3>
				<div class="sense" id="Oabolahu_A1">
					<p><span class="ar">أَبْلَهُ</span> <em>Heedless:</em> <span class="auth">(Ḳ:)</span> or <em>heedless of evil</em> <span class="auth">(Ḳ, TA)</span> <em>by reason of his goodness:</em> <span class="auth">(TA:)</span> or <em>simple, foolish,</em> or <em>of little sense, without discrimination:</em> <span class="auth">(Ḳ:)</span> or <em>weak in intellect:</em> <span class="auth">(Mṣb:)</span> accord. to En-Naḍr, <span class="auth">(TA,)</span> one <em>whose evilness is dead,</em> <span class="auth">(Ḳ, TA,)</span> <em>so that he is not cognizant of it:</em> <span class="auth">(TA:)</span> <em>good in disposition; having little cognizance,</em> or <em>understanding, of subtilties;</em> or <em>having little skill therein:</em> <span class="auth">(Ḳ:)</span> or one <em>whose predominant quality is freedom of the bosom,</em> or <em>heart,</em> or <em>mind, from evil affections;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> <em>and good opinion of men:</em> <span class="auth">(TA:)</span> <em>simple-hearted:</em> <span class="auth">(TḲ:)</span> <em>naturally disposed to goodness, and therefore heedless of evil, not knowing it:</em> <span class="auth">(T, TA:)</span> or <em>heedless with respect to the present world and its people and their corruptness and malevolence, but intelligent and skilled in the law with respect to that which is commanded and that which is forbidden:</em> <span class="auth">(Ah- mad Ibn-Hambal, TA:)</span> fem. <span class="ar">بَلْهَآءُ</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:*)</span> pl. <span class="ar">بُلْهٌ</span>: <span class="auth">(Ṣ, Mṣb:)</span> and<span class="arrow"><span class="ar">بُلَهَآءُ↓</span></span>, a pl., <span class="add">[as though the sing. were <span class="ar">بَلِيهٌ</span>,]</span> signifies <em>dull, stupid,</em> or <em>wanting in intelligence:</em> but this is post-classical. <span class="auth">(TA.)</span> Hence, <span class="ar long">شَابٌّ أَبْلَهُ</span> <span class="add">[<em>A youth,</em> or <em>young man, who is heedless,</em>, &amp;c.]</span>, because of his inexperience in affairs: the epithet is applied to a youth in like manner as freedom from care, or thought, and like as insanity, are attributed to him. <span class="auth">(Ṣ.)</span> And <span class="ar long">خَيْرُ أَوْلَادِنَا الأَبْلَهُ العَقُولُ</span> ‡ <span class="add">[<em>The best of our children is the heedless,</em>, &amp;c., <em>that has much intelligence</em>]</span>; <span class="auth">(Ṣ, Mṣb;)</span> a saying of Ez-Zibrikán Ibn-Bedr; <span class="auth">(Ṣ;)</span> meaning such as, by reason of his bashfulness, is like the <span class="ar">ابله</span>, <span class="auth">(Ṣ, Mṣb,)</span> so that he feigns heedlessness, and passes over things, <span class="auth">(Mṣb,)</span> though he has much intelligence; <span class="auth">(Ṣ;)</span> or such as is thought to be stupid, but, when examined, is found to be <span class="add">[very]</span> intelligent. <span class="auth">(IAth, TA in art. <span class="ar">عقل</span>.)</span> And <span class="ar long">أَكْثَرُ أَهْلِ الجَنَّةِ البُلْهُ</span>, a trad., meaning <em>Most of the people of Paradise are the</em> <span class="ar">بُلْه</span> <span class="add">[or <em>heedless,</em>, &amp;c.,]</span> with respect to the present world, because of their being little concerned thereby, while they are intelligent with respect to the world to come; <span class="auth">(Ṣ;)</span> or they are thus termed because they are heedless of their affairs in the present world, and unskilful in the management thereof, and busy themselves with their affairs relating to the world to come. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: <span class="ar">أَبْلَهُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabolahu_A2">
					<p><span class="ar">بَلْهَآءُ</span>, applied to a woman, <em>Generous, strong-hearted,</em> (<span class="ar">مَزِيرَةٌ</span>, for <span class="ar">المَرِيرَةُ</span> in the copies of the Ḳ is a mistake for <span class="ar">المَزِيرَةُ</span>, with <span class="ar">زاى</span>, TA, <span class="add">[app. here meaning <em>bold,</em>]</span>) <em>inexperienced in affairs, and simple,</em> or <em>unintelligent.</em> <span class="auth">(Ḳ,* TA.)</span> ISh cites a poet as applying this epithet to a young girl with whom he had sported, and who acquainted him with her secrets, by reason of her inexperience, and want of cunning, not knowing what that implied against her. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: <span class="ar">أَبْلَهُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabolahu_A3">
					<p>Also, applied to a she-camel, ‡ <em>That does not take fright, and flee from a thing,</em> <span class="auth">(ISh, A, Ḳ,)</span> <em>by reason of staidness,</em> <span class="auth">(ISh, Ḳ,)</span> or <em>heaviness,</em> <span class="auth">(A,)</span> <em>as though she were stupid.</em> <span class="auth">(ISh, A, Ḳ.)</span> <span class="pb" id="Page_0255"></span>One does not say <span class="ar long">جَمَلٌ أَبْلَهُ</span>. <span class="auth">(ISh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: <span class="ar">أَبْلَهُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oabolahu_A4">
					<p><span class="ar long">شَبَابٌ أَبْلَهُ</span> ‡ <em>Soft,</em> or <em>delicate, youth;</em> <span class="auth">(T, A, Ḳ;)</span> as though he who enjoys it were heedless of nocturnal accidents or calamities. <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بله</span> - Entry: <span class="ar">أَبْلَهُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oabolahu_A5">
					<p>And <span class="ar long">عَيْشٌ أَبْلَهُ</span> ‡ <em>A soft,</em> or <em>delicate,</em> or <em>pleasant,</em> or <em>plentiful and easy, life:</em> <span class="auth">(Ḳ, TA:)</span> or <em>a life in which are few anxieties:</em> <span class="auth">(CK:)</span> or <em>a life in which are few griefs,</em> or <em>sorrows.</em> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#bulahoniyapN">See also <span class="ar">بُلَهْنِيَةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0253.pdf" target="pdf">
							<span>Lanes Lexicon Page 253</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0254.pdf" target="pdf">
							<span>Lanes Lexicon Page 254</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0255.pdf" target="pdf">
							<span>Lanes Lexicon Page 255</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
