<article class="root" id="Root_bqs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/155_bqr">بقر</a></span>
				<span class="ar">بقس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/157_bqX">بقش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baqosN">
				<h3 class="entry"><span class="ar">بَقْسٌ</span></h3>
				<div class="sense" id="baqosN_A1">
					<p><span class="ar">بَقْسٌ</span> and<span class="arrow"><span class="ar">بَقْسِيسٌ↓</span></span>, <span class="auth">(Ḳ,)</span> the latter written, in some copies of the Ḳ, <span class="ar">بقبيس</span>, <span class="auth">(TA,)</span> <span class="add">[The <em>boxtree;</em> Greek <span class="gr">πυξος</span>;]</span> <em>a certain kind of tree, resembling the</em> <span class="ar">آس</span> <span class="add">[or <em>myrtle</em>]</span> <em>in leaves and berries:</em> or <em>i. q.</em> <span class="ar">شَمْشَاد</span> <span class="add">[a Persian word, also applied to the <em>box-tree</em>]</span>: <span class="auth">(Ḳ:)</span> <em>it grows in the country of the Greeks; and spoons and doors are made of it, because of its hardness:</em> <span class="pb" id="Page_0235"></span>and it may be with <span class="ar">ش</span> <span class="add">[<span class="ar">بَقْشٌ</span>, which is explained by Ṣgh and in the Ḳ as a kind of tree called in Persion <span class="ar long">خُوشْ سَاىْ</span>; and this, also, is a name of the <em>box-tree</em>]</span>: <span class="auth">(TA:)</span> it is astringent, having the property of drying up the moisture of the intestines; and its saw-dust, kneaded with honey, strengthens the hair, and makes it abundant, and is good for <span class="auth">(or prevents, as in the CK,)</span> the headache, and with the white of the egg is good for what is termed <span class="ar">وَثْىٌ</span>, <span class="auth">(Ḳ,)</span> i. e., a fracture <span class="add">[of the flesh]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqosiysN">
				<h3 class="entry"><span class="ar">بَقْسِيسٌ</span></h3>
				<div class="sense" id="baqosiysN_A1">
					<p><span class="ar">بَقْسِيسٌ</span>: <a href="#baqosN">see <span class="ar">بَقْسٌ</span>, above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0234.pdf" target="pdf">
							<span>Lanes Lexicon Page 234</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0235.pdf" target="pdf">
							<span>Lanes Lexicon Page 235</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
