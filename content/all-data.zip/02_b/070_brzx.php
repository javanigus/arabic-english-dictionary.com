<article class="root" id="Root_brzx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/069_brz">برز</a></span>
				<span class="ar">برزخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/071_brsm">برسم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="barozaxN">
				<h3 class="entry"><span class="ar">بَرْزَخٌ</span></h3>
				<div class="sense" id="barozaxN_A1">
					<p><span class="ar">بَرْزَخٌ</span> <em>A thing that intervenes between any two things:</em> <span class="auth">(L:)</span> or <em>a bar, an obstruction,</em> or <em>a thing that makes a separation, between two things:</em> <span class="auth">(Ṣ, A, L, Ḳ:)</span> so in the Ḳur lv. 20: pl. <span class="ar">بَرَازِخُ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برزخ</span> - Entry: <span class="ar">بَرْزَخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barozaxN_A2">
					<p>The <em>interval between the present life and that which is to come,</em> <span class="auth">(Ṣ, A,)</span> <em>from the period of death to the resurrection,</em> <span class="auth">(Ṣ, A, Ḳ,)</span> <em>upon which he who dies enters;</em> <span class="auth">(Ṣ, Ḳ;)</span> the <em>period,</em> or <em>state, from the day of death to the day of resurrection:</em> so in the Ḳur xxiii. 102. <span class="auth">(Fr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برزخ</span> - Entry: <span class="ar">بَرْزَخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="barozaxN_A3">
					<p><span class="ar long">بَرَازِخُ الإِيمَانِ</span> <em>What is between the beginning of faith,</em> <span class="auth">(L, Ḳ,)</span> which is the acknowledgment, or confession, of God, <span class="auth">(L,)</span> <em>and the end thereof,</em> <span class="auth">(L, Ḳ,)</span> which is the removal of what is hurtful from the road: <span class="auth">(L:)</span> or <em>what is between doubt and certainty.</em> <span class="auth">(L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0187.pdf" target="pdf">
							<span>Lanes Lexicon Page 187</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
