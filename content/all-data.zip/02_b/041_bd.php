<article class="root" id="Root_bd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/040_bxl">بخل</a></span>
				<span class="ar">بد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/042_bdO">بدأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bd_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدّ</span></h3>
				<div class="sense" id="bd_1_A1">
					<p><span class="ar">بَدَّ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُدُ</span>}</span></add>, inf. n. <span class="ar">بَدٌّ</span>: <a href="#bd_2">see 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bd_1_A2">
					<p><span class="ar long">بَدَّ رِجْلَيْهِ</span> <em>He parted his legs,</em> or <em>straddled,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> in the stocks, or otherwise. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bd_1_A3">
					<p><span class="ar">بَدَّهُ</span>, <span class="auth">(M, Ḳ,)</span> aor. and inf. n. as above, <span class="auth">(M,)</span> <em>He removed with it, withdrew with it, drew away with it,</em> <span class="add">[or <em>drew it away,</em> from its place,]</span> <span class="auth">(M, Ḳ,)</span> namely, a thing. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bd_1_A4">
					<p><em>He made him</em> <span class="auth">(namely, his companion, M)</span> <em>to retire,</em> or <em>withdraw, far away;</em> and <em>to refrain, forbear,</em> or <em>abstain;</em> <span class="auth">(M, Ḳ;)</span> <span class="ar long">عَنِ الشَّىْءِ</span> <em>from the thing.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bd_1_A5">
					<p><span class="ar long">أَنَا أَبُدُّ بِكَ عَنْ ذٰلِكَ الأَمْرِ</span> <em>I will defend thee from that thing,</em> or <em>event, by repelling it,</em> or <em>averting it, from thee.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bd_1_A6">
					<p><span class="ar long">بُدَّ عَنْ دَبَرِ الدَّابَّةِ</span> <em>It</em> <span class="auth">(a felt cloth)</span> <em>was cut,</em> or <em>slit, so as to be clear of the galls,</em> or <em>sores, on the back of the beast.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bd_1_B1">
					<p><span class="ar">بَدَّ</span>, <span class="auth">(M,)</span> second pers. <span class="ar">بَدِدْتَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">يَبَدُّ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">بَدَدٌ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> <span class="pb" id="Page_0161"></span><em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, wide between the thighs,</em> <span class="auth">(ISk, T, Ṣ, M, Ḳ,)</span> <em>by reason of abundance of flesh:</em> <span class="auth">(ISk, Ṣ, M:)</span> <em>or wide between the arms;</em> <span class="auth">(Ḳ;)</span> <em>having the arms far from the sides:</em> <span class="auth">(M:)</span> or <em>wide between the shoulder-joints:</em> <span class="auth">(M:)</span> or <em>large in make, having one part far from another.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bd_1_B2">
					<p>Also <em>He</em> <span class="auth">(a quadruped, ISk, T, Ṣ, or a horse, M)</span> <em>had his fore legs far apart:</em> <span class="auth">(ISk, T, Ṣ, M:)</span> or <em>he</em> <span class="auth">(a horse)</span> <em>had his fore legs far from his sides:</em> <span class="auth">(Lth, T:)</span> and <em>he</em> <span class="auth">(a camel)</span> <em>had his elbows far from his sides.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bd_1_C1">
					<p><span class="ar long">بَدَّ قَتَبَهُ</span>,, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُدُ</span>}</span></add>, <em>He furnished his camel's saddle with what are called</em> <span class="ar">بِدَادَانِ</span> <em>and</em> <span class="ar">بَدِيدَانِ</span> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#bidaAdN">See <span class="ar">بِدَادٌ</span></a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_2">
				<h3 class="entry">2. ⇒ <span class="ar">بدّد</span></h3>
				<div class="sense" id="bd_2_A1">
					<p><span class="ar">بدّد</span>, inf. n. <span class="ar">تَبْدِيدٌ</span>, <em>He separated, disunited, dispersed,</em> or <em>dissipated;</em> <span class="auth">(Ṣ, M, A, Mgh, L, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَدَّ↓</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُدُ</span>}</span></add>, inf. n. <span class="ar">بَدٌّ</span>: <span class="auth">(Ṣ, L:)</span> or the latter has this meaning, and the former signifies <em>he separated, disunited, dispersed,</em> or <em>dissipated, much.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bd_2_A2">
					<p><em>He</em> <span class="auth">(a man)</span> <em>gave his equal share of the expenses for a journey.</em> <span class="auth">(IAạr, T.)</span> <span class="add">[<a href="#bd_3">See also 3</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bd_2_B1">
					<p><em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, weary, tired,</em> or <em>fatigued:</em> <span class="auth">(IAạr, T, M, Ḳ:)</span> or <em>he drowsed,</em> or <em>slumbered, while sitting, without sleeping.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_3">
				<h3 class="entry">3. ⇒ <span class="ar">بادّ</span></h3>
				<div class="sense" id="bd_3_A1">
					<p><span class="ar long">بادّ القَوْمُ</span>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">مُبَادَّةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">بِدَادٌ</span>, <span class="auth">(T, M, Ḳ,)</span> with which the subst. <span class="arrow"><span class="ar">بَدَادٌ↓</span></span> is syn., <span class="auth">(M, and mentioned also in a MṢ. copy of the Ḳ, and in the CK, and in the TA, but not as from the Ḳ,)</span> as also<span class="arrow"><span class="ar">بِدَادَةٌ↓</span></span>, <span class="auth">(TA, as from the Ḳ, but not in the CK nor in my MṢ. copy of the Ḳ,)</span> <em>The people,</em> or <em>company of men, contributed what was necessary to be expended</em> (<em>in a journey,</em> T, M, L), <em>each man giving something, and then collected the sum, and expended it among themselves.</em> <span class="auth">(T, M, L, Ḳ.)</span> In a copy of the Ḳ, for <span class="ar">يُنْفِقُونَهُ</span>, is erroneously put <span class="ar">يُبْقُونَهُ</span>. <span class="auth">(TA. <span class="add">[In the CK, <span class="ar">يَبْقُونَهُ</span>.]</span>)</span> Accord. to IAạr, <span class="ar">بِدَادٌ</span> signifies The <em>contributing equally for the purchasing of corn,</em> or <em>food, to eat:</em> and also a people's <em>having money,</em> or <em>property, divided into lots,</em> or <em>portions, and distributed in shares among them:</em> <span class="auth">(L:)</span> <span class="add">[and]</span> accord. to the same, the <em>dividing property among a people in shares.</em> <span class="auth">(T. <span class="add">[<a href="#bd_4">See also 4</a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bd_3_A2">
					<p>Also, <span class="ar">بادّهُ</span>, <span class="auth">(M, A, Ḳ,)</span> or <span class="ar long">بادّهُ فى البَيْعِ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">مُبَادَّةٌ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> or <span class="ar">مُبَادَدَة</span>, <span class="auth">(TA,)</span> and <span class="ar">بِدَادٌ</span>; <span class="auth">(Ṣ, M, A, Ḳ;)</span> and so<span class="arrow"><span class="ar long">بَايَعَهُ بَدَدًا↓</span></span>, <span class="auth">(Ṣ M, Ḳ,)</span> or <span class="ar">مُبَادَّةً</span>; <span class="auth">(A;)</span> <em>He bartered,</em> or <em>exchanged commodities, with him;</em> syn. <span class="ar long">عَارَضَهُ بِالبَيْعِ</span>, <span class="auth">(M, A,* L,)</span> and <span class="ar long">بَاعَهُ مُعَارَضَهً</span>: <span class="auth">(Ṣ, Ḳ:)</span> from the saying, <span class="ar long">ٰهٰذَا بِذُّهُ</span>, and <span class="ar">بِدُّهُ</span>, “this is the like of it:” <span class="auth">(L:)</span> from IAạr. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bd_3_A3">
					<p><span class="add">[<a href="#budBN">See also <span class="ar">بُدٌّ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابدّ</span></h3>
				<div class="sense" id="bd_4_A1">
					<p><span class="ar long">ابدّ فِيهِمُ العَطَآء</span>, <span class="auth">(Aṣ, T,)</span> and <span class="ar long">ابدّ بَيْنَهُمْ العَطَآءَ</span>, <span class="auth">(Ṣ, M, L, Ḳ,)</span> and <span class="ar long">أَبَدَّهُمْ العَطَآءَ</span>, <span class="auth">(M, A, Mgh,)</span> <em>He divided among them the gift, giving to each of them his lot,</em> or <em>share,</em> or <em>portion,</em> <span class="auth">(Ṣ, M, A, Mgh, L, Ḳ,)</span> <em>singly, not giving a portion to be shared by two:</em> <span class="auth">(Aṣ, T, M,* Mgh, L:)</span> said with respect to food and property and any other thing. <span class="auth">(M.)</span> You say, <span class="ar long">أَبْدَدْتُهُمْ المَالَ وَالطَّعَامَ</span> <em>I divided among them, in shares, the property and the food.</em> <span class="auth">(IAạr, T.)</span> <span class="add">[Hence,]</span> <span class="ar long">أَبِدِّيهِمْ تَمْرَةً تَمْرَةً</span> <span class="auth">(T, Ṣ, A, Mgh, from a trad.)</span> <span class="add">[<em>Give thou to each of them a date;</em> or]</span> <em>distribute thou among them to each a date:</em> <span class="auth">(T:)</span> said by Umm-Selemeh, <span class="auth">(T, A, Mgh,)</span> to a slave-girl, when beggars had become numerous. <span class="auth">(A.)</span> <span class="ar">إِبْدَادٌ</span> in relation to a gift signifies The <em>giving</em> <span class="add">[persons]</span> <em>one by one;</em> and <span class="ar">قِرَانٌ</span>, the “giving two by two.” <span class="auth">(AʼObeyd, T.)</span> <span class="add">[<a href="#bd_3">See also 3</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bd_4_A2">
					<p><span class="ar">يُبِدُّهُمْ</span> is used by a poet, referring to a saying, and is explained by IAạr as meaning <em>It</em> <span class="auth">(the saying)</span> <em>shall be distributed among them</em> (<span class="ar long">يُفَّرقُ فِيهِمْ</span>); opposed to <span class="ar">يَجْمَعُ</span> <span class="add">[i. e. <span class="ar">يَجْمَعُهُمْ</span>; which shows that the former means <em>it shall be addressed to them one by one,</em> or <em>separately</em>]</span>. <span class="auth">(M, TA. <span class="add">[The author of the former adds, “I know not, in discourse, <span class="ar">أَبْدَدْتُهُ</span> as meaning <span class="ar">فَرَّقْتُهُ</span>:” but this is not what IAạr means.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bd_4_A3">
					<p><span class="ar long">أَبِدَّهُمَا نَعْجَتَيْنَ</span> <em>Allot thou to them</em> <span class="auth">(namely, two lambs,)</span> <em>two ewes, to each lamb a ewe,</em> to suckle it: said when one ewe is not sufficient for both the lambs. <span class="auth">(T,* Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bd_4_A4">
					<p><span class="ar long">ابدّ ضَبْعَيْهِ</span> <em>He extended his upper arms, separating them from his sides,</em> in prostrating himself in prayer. <span class="auth">(T, A, Mgh, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bd_4_A5">
					<p><span class="ar long">ابدّ يَدَهُ إِلَى الأَرْضِ</span> <em>He extended his arm,</em> or <em>hand, to the ground,</em> or <em>earth,</em> <span class="auth">(T, Ṣ, Mgh, L,)</span> as one does when he takes up something from it. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bd_4_A6">
					<p><span class="ar long">ابدّ نَظَرَهُ</span> <em>He prolonged his look.</em> <span class="auth">(T, L.)</span> And <span class="ar long">ابدّهُ بَصَرَهُ</span> <span class="auth">(T, A, L)</span> <em>He prolonged his look at him,</em> or <em>it;</em> as one does when he sees a thing that he dislikes. <span class="auth">(T, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبدّد</span></h3>
				<div class="sense" id="bd_5_A1">
					<p><span class="ar">تبدّد</span> <em>It</em> <span class="auth">(a thing, Ṣ, M, L, and a people, or company of men, T, L)</span> <em>became separated, disunited, dispersed,</em> or <em>dissipated;</em> <span class="auth">(T, Ṣ, M, L, Ḳ;)</span> <span class="add">[as also<span class="arrow"><span class="ar">بَدْبَدَ↓</span></span>, for its inf. n.]</span> <span class="ar">بَدْبَدَةٌ</span> likewise signifies the <em>being separated, disunited,</em>, &amp;c. <span class="auth">(AA, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bd_5_B1">
					<p><span class="ar long">تبدّدوا شَيْئًا</span> <em>They divided a thing among themselves in lots, shares,</em> or <em>portions,</em> <span class="auth">(Ḳ,)</span> <em>equally.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bd_5_B2">
					<p><span class="ar long">تبدّد صَدْرَ الجَارِيَةِ</span> <em>It</em> <span class="auth">(an ornament)</span> <em>occupied the two sides,</em> <span class="auth">(A,)</span> or <em>the whole,</em> <span class="auth">(Ḳ,)</span> <em>of the bosom of the girl.</em> <span class="auth">(A, Ḳ.)</span> <span class="add">[See an ex. voce <span class="ar">جَلِيفً</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبادّ</span></h3>
				<div class="sense" id="bd_6_A1">
					<p><span class="ar">تبادّوا</span> <em>They removed to a distance, one from another.</em> <span class="auth">(Ḥam p. 823.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bd_6_A2">
					<p><em>They went,</em> or <em>passed, two by two, each one of a pair removing,</em> or <em>withdrawing, with the other,</em> or <em>making the other to retire,</em> or <em>withdraw, far away.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bd_6_A3">
					<p><em>They went forth into the field</em> <span class="add">[<em>of battle</em>]</span>, <em>one to another:</em> <span class="auth">(A:)</span> or <em>they took their adversaries,</em> or <em>opponents,</em> <span class="add">[<em>with whom to fight,</em>]</span> <span class="auth">(T, Ṣ, Ḳ,)</span> <em>each man his man;</em> as also<span class="arrow"><span class="ar long">لَقُوا بَدَادَهُمْ↓</span></span>: <span class="auth">(Ḳ:)</span> or this latter signifies <em>they met their numbers, to each man a man.</em> <span class="auth">(T, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتدّ</span></h3>
				<div class="sense" id="bd_8_A1">
					<p><span class="ar long">ابتدّاهُ بِاالضَّرْبِ</span> <em>They two took him on both sides of him,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> or <em>came to him on both sides of him,</em> <span class="auth">(Ḳ,)</span> <em>with beating.</em> <span class="auth">(T, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bd_8_A2">
					<p><span class="ar long">السَّبُعَانِ يَبْتَدَّانِ الرَّجُلَ</span> <em>The two wild beasts come upon both sides of the man.</em> <span class="auth">(Ṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bd_8_A3">
					<p><span class="ar long">الرَّضِيعَانِ يَبْتَدَّانِ أُمَّهُمَا</span> <span class="auth">(T, Ṣ, A *)</span> <em>The two sucklings suck their mother on either side, one from one breast and the other from the other breast.</em> <span class="auth">(T, A,* TA.)</span> You do not say, <span class="ar long">يَبْتَدُّهَا ٱبْنُهَا</span>, but <span class="ar long">يَبْتَدُّهَا ٱبْنَاهَا</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبدّ</span></h3>
				<div class="sense" id="bd_10_A1">
					<p><span class="ar">استبدّ</span> <em>He was,</em> or <em>became, alone; independent of others;</em> <span class="auth">(Ṣ, M, L, Mṣb, Ḳ; in the first and last expl. by <span class="ar">تَفَرَّدَ</span>; and in the others, by <span class="ar">اِنْفَرَدَ</span>;)</span> <em>exclusively of others;</em> <span class="auth">(L;)</span> <em>without any to share,</em> or <em>participate, with him;</em> or <em>he had none to share,</em> or <em>participate, with him:</em> <span class="auth">(Mṣb:)</span> <span class="ar">بِهِ</span> <span class="add">[<em>in it;</em> i. e. <em>he had it,</em> or <em>kept it, to himself, exclusively, with none to share with him in it</em>]</span>: <span class="auth">(Ḳ:)</span> and <span class="ar">بِكَذَا</span> <span class="add">[<em>in such a thing</em>]</span>: <span class="auth">(Ṣ, L:)</span> and <span class="ar">بِرَأْيِهِ</span> <span class="add">[<em>in his opinion;</em> i. e. <em>he followed his own opinion only, with none to agree with him;</em> or <em>he was singular in his opinion</em>]</span>: <span class="auth">(M, L:)</span> and <span class="ar">بِأَمْرٍ</span> <span class="add">[<em>in a thing,</em> or <em>an affair</em>]</span>: <span class="auth">(L, Mṣb:)</span> and <span class="ar">بِأَمْرِهِ</span> <span class="add">[<em>in his affair</em>]</span>; meaning <em>he obtained</em> <span class="add">[<em>absolute</em>]</span> <em>predominance,</em> or <em>control, over his affair, so that people would not hear</em> <span class="add">[or <em>obey</em>]</span> <em>any other.</em> <span class="auth">(A.)</span> It is said in a trad., <span class="ar long">كُنَّا نَرَى أَنَّ لَنَافِىِ هٰذَا الأَمْرِ حَقَّا فَٱسْتَبَدْتُمْ عَلَيْنَا</span> <span class="add">[<em>We used to opine that we had a right</em> to act <em>in this affair, and ye have been alone</em> the actors, predominant <em>over us</em>]</span>. <span class="auth">(L.)</span> And you say, <span class="ar long">استبدّ الأَمْرُ بِفُلَانٍ</span>, meaning ‡ <em>The thing,</em> or <em>affair, overcame such a one, so that he could not manage it well,</em> or <em>thoroughly.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bd_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بدبد</span></h3>
				<div class="sense" id="bd_RQ1_A1">
					<p><span class="ar">بَدْبَدَ</span>, inf. n. <span class="ar">بَدْبَدَةٌ</span>: <a href="#bd_5">see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="budN">
				<h3 class="entry"><span class="ar">بُدٌ</span></h3>
				<div class="sense" id="budN_A1">
					<p><span class="ar">بُدٌ</span> as signifying <em>A separating oneself,</em> or <em>an artifice whereby one may avoid</em> a thing or <em>escape</em> from it, <span class="auth">(MF,)</span> or <em>an avoiding</em> a thing, <span class="auth">(Mṣb,)</span> is not used but in negative phrases, <span class="auth">(Mṣb, MF,)</span> except by post-classical writers. <span class="auth">(MF.)</span> You say, <span class="ar long">لَا بُدَّ مِنْ كَذَا</span> <span class="auth">(T, Ṣ, M, &amp;c.)</span> <em>There is no separating oneself from such a thing:</em> <span class="auth">(AA, T, Ṣ, A, Ḳ:)</span> or <em>there is no artifice whereby one may avoid it,</em> or <em>escape from it:</em> <span class="auth">(M, Ḳ:)</span> or <em>there is no avoiding it:</em> <span class="auth">(Mṣb:)</span> <em>it is absolutely necessary: it is not possible to separate oneself from it, nor is there anything that can serve in its stead.</em> <span class="auth">(TA.)</span> And <span class="ar long">مَا لَكَ مِنْهُ بُدٌّ</span> <span class="add">[<em>Thou hast not any means,</em> or <em>way, of separating thyself from it,</em> or <em>avoiding it</em>]</span>. <span class="auth">(M, L.)</span> And <span class="ar long">لَيْسَ لِهٰذَا الأَمْرِ بُدٌّ</span> <em>There is no artifice for this affair.</em> <span class="auth">(T.)</span> <span class="add">[It is also said, with reference to the first of these phrases, that]</span> <span class="ar">بُدٌّ</span> signifies <em>Amplitude;</em> from <span class="ar">أَبَدُّ</span> meaning “wide between the legs.” <span class="auth">(Ḥam p. 348.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بُدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="budN_B1">
					<p>Also, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بِدٌّ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">بِدَادٌ↓</span></span> <span class="auth">(IAạr, T, M, Ḳ)</span> and<span class="arrow"><span class="ar">بُدَادٌ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> or<span class="arrow"><span class="ar">بَدَادٌ↓</span></span>, <span class="auth">(CK,)</span> and<span class="arrow"><span class="ar">بُدَّةٌ↓</span></span>, <span class="auth">(IAạr, T, M, Ḳ,)</span> or<span class="arrow"><span class="ar">بِدَّةٌ↓</span></span>, <span class="auth">(Ṣ, A, IAth, and mentioned also in a copy of the Ḳ,)</span> but J has been charged with error in writing it thus, <span class="auth">(Ḳ,)</span> by Ṣgh, <span class="auth">(TA,)</span> <em>A lot, share, portion,</em> or <em>set portion;</em> <span class="auth">(T, Ṣ, M, A, IAth, Ḳ;)</span> of anything: <span class="auth">(M, Ḳ:)</span> <span class="add">[or]</span> the last signifies <em>a piece,</em> or <em>portion, separated, disunited,</em> or <em>dispersed:</em> <span class="auth">(Ḥam p. 823:)</span> <a href="#bidaAdN">the pl. of <span class="ar">بِدَادٌ</span></a> is <span class="ar">بُدُدٌ</span>; <a href="#budBapN">and of <span class="ar long">بُدَدٌ بُدَّةٌ</span></a>; <span class="auth">(IAạr, T, M;)</span> <a href="#bidBapN">and of <span class="ar long">بِدَدٌ بِدَّةٌ</span></a>. <span class="auth">(IAth, and Ḥam p. 823.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بُدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="budN_B2">
					<p>Also the first, <em>A substitute; a thing given,</em> or <em>received,</em> or <em>put,</em> or <em>done, instead of, in the place of,</em> or <em>in exchange for, another thing; a compensation;</em> syn. <span class="ar">عِوَضٌ</span>: <span class="auth">(Ṣ, L, TA:)</span> it is said to have this signification. <span class="auth">(Ṣ.)</span> <span class="add">[In the copies of the Ḳ, <span class="ar">البَعُوضُ</span> is put in the place of <span class="ar">العِوَضُ</span>: but this is said in the TA to be a mistake.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بُدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="budN_C1">
					<p><span class="ar">بُدٌّ</span> is also an arabicized word, from <span class="ar">بُتْ</span>, <span class="auth">(T, Ṣ, M, Ḳ, <span class="add">[in a copy of the M, <span class="ar">بُتّ</span>,]</span>)</span> which is Persian; <span class="auth">(T, Ṣ;)</span> meaning <em>An idol;</em> <span class="auth">(IDrd, Ṣ, M, Ḳ;)</span> pl. <span class="ar">بَدَدَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أَبْدَادٌ</span>: <span class="auth">(Ḳ:)</span> <span class="pb" id="Page_0162"></span>and <span class="auth">(or accord. to some, TA)</span> the <em>house of an idol:</em> <span class="auth">(Ḳ:)</span> or <em>a house in which are idols and images</em> or <em>pictures.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidBN">
				<h3 class="entry"><span class="ar">بِدٌّ</span></h3>
				<div class="sense" id="bidBN_A1">
					<p><span class="ar">بِدٌّ</span>: <a href="#budBN">see <span class="ar">بُدٌّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بِدٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bidBN_A2">
					<p>Also, and<span class="arrow"><span class="ar">بَدِيدٌ↓</span></span> <span class="auth">(T, Ḳ)</span> and<span class="arrow"><span class="ar">بَدِيدَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A like; a fellow; an equal.</em> <span class="auth">(T, Ḳ.)</span> You say, <span class="ar long">هُوَ بِدُّهُ</span> and<span class="arrow"><span class="ar">بَدِيدُهُ↓</span></span> <em>He,</em> or <em>it, is the like, &amp;c., of him,</em> or <em>it.</em> <span class="auth">(T.)</span> And <span class="ar long">هُمَ بِدَّانِ</span> <em>They two are likes,</em> or <em>fellows,</em> or <em>equals.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">مَا أَنْتَ لِى بِبَدِيدٍ↓ فَتُكَلِّمَنِى</span></span> <em>Thou art not my like,</em> or <em>fellow,</em> or <em>equal, that thou shouldst speak to me.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badBapN">
				<h3 class="entry"><span class="ar">بَدَّةٌ</span></h3>
				<div class="sense" id="badBapN_A1">
					<p><span class="ar">بَدَّةٌ</span>: <a href="#badadN">see <span class="ar">بَدَدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="budBapN">
				<h3 class="entry"><span class="ar">بُدَّةٌ</span></h3>
				<div class="sense" id="budBapN_A1">
					<p><span class="ar">بُدَّةٌ</span>: <a href="#budBN">see <span class="ar">بُدٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بُدَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="budBapN_B1">
					<p>Also <em>A distance; a space; an interval; an extent,</em> or <em>an extreme extent; a long space,</em> or <em>any space, of time.</em> <span class="auth">(M, Ḳ,* TA.)</span> So in the saying, <span class="ar long">بَيْنِى وَبَيْنَكَ بُدَّةٌ</span> <span class="add">[<em>Between me and thee is a distance,</em>, &amp;c.]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bidBapN">
				<h3 class="entry"><span class="ar">بِدَّةٌ</span></h3>
				<div class="sense" id="bidBapN_A1">
					<p><span class="ar">بِدَّةٌ</span>: <a href="#budBN">see <span class="ar">بُدٌّ</span></a>, <a href="#bidaAdi">and <span class="ar">بِدَادِ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بِدَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bidBapN_B1">
					<p><a href="#badadN">and see also <span class="ar">بَدَدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badada">
				<h3 class="entry"><span class="ar">بَدَدَ</span></h3>
				<div class="sense" id="badada_A1">
					<p><span class="ar">بَدَدَ</span> and <span class="ar">بَدَدًا</span>: <a href="#badaAdi">see <span class="ar">بَدَادِ</span></a>, in three places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدَدَ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badada_B1">
					<p><a href="#bd_3">and see also 3</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدَدَ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="badada_C1">
					<p><span class="ar long">مَا لَكَ بِهِ بَدَدٌ</span> and<span class="arrow"><span class="ar">بَدَّةٌ↓</span></span> and<span class="arrow"><span class="ar">بِدَّةٌ↓</span></span> <em>Thou hast not power,</em> or <em>ability, to do it,</em> or <em>to bear it,</em> or <em>to cope with him.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaAdi">
				<h3 class="entry"><span class="ar">بَدَادِ</span></h3>
				<div class="sense" id="badaAdi_A1">
					<p><span class="ar long">جَآءَتِ الخَيْلُ بَدَادِ</span>; <span class="auth">(T, Ṣ;)</span> in which <span class="ar">بداد</span> is indecl., with kesr for its termination because it deviates from its original form, i. e., the inf. n. <span class="ar">بَدَدٌ</span>; and it is indecl. because it deviates from its original form and is of the fem. gender and has the quality of an epithet; for two of these causes render it imperfectly decl., and the three render it indecl.; <span class="auth">(Ṣ;)</span> or <span class="ar long">بَدَادِ بَدَادِ</span>, and <span class="ar long">بَدَادَ بَدَادَ</span>, <span class="auth">(Lḥ, M, Ḳ,)</span> the last indecl. with fet-ḥ for its termination, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar long">بَدَدَ بَدَدَ↓</span></span>, <span class="auth">(Lḥ, M, Ḳ,)</span> also indecl., with fet-ḥ, <span class="auth">(TA,)</span> and composed in the same manner as <span class="ar long">خَمْسَةَ عَشَرَ</span>, <span class="auth">(Lḥ, M, TA,)</span> and<span class="arrow"><span class="ar long">بَدَدًا بَدَدًا↓</span></span>; <span class="auth">(Lḥ, M, Ḳ;)</span> all of these indecl. except the last, and each virtually in the accus. case as a denotative of state, except the last, <span class="auth">(MF,)</span> which is literally in the accus. case, as an inf. n.; <span class="auth">(M, MF;)</span> <em>The horses,</em> or <em>horsemen, came in a state of dispersion:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> or <em>one by one;</em> or <em>one after another.</em> <span class="auth">(T, L.)</span> And <span class="ar long">تَفّرَّقَ القَوْمُ بَدَاد</span> <em>The people,</em> or <em>company of men, became separated, in a state of dispersion.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">ذَهَبَ القَوْمُ بَدَادِ بَدادِ</span> <em>The people,</em> or <em>company of men, went away</em> <span class="add">[<em>in a state of dispersion;</em> or]</span> <em>one by one;</em> or <em>one after another.</em> <span class="auth">(T, L.)</span> <span class="add">[<a href="#OabaAdiyd">See also <span class="ar">أَبَادِيد</span></a>.]</span> It is said in a form of prayer,<span class="arrow"><span class="ar long">اَللٰهُمَّ ٱقْتُلْهُمْ بَدَدًا↓ وَأَحْصِهِمْ عَدَدًا</span></span> <span class="add">[<em>O God, slay them one by one, and reckon them by number</em>]</span>: <span class="auth">(M:)</span> or <span class="ar long">أَحْصِهِمْ عَدَدًا وَٱلْعَنْهُمْ بِدَدًا</span>, or, accord. to one recital, <span class="ar long">وَٱقْتُلْهُمْ بِدَدًا</span>, pl. of<span class="arrow"><span class="ar">بِدَّةٌ↓</span></span>, the meaning being <span class="add">[<em>reckon them by number, and</em>]</span> <em>curse them,</em> or <em>slay them, with a cursing,</em> or <em>slaughter, distributed among them by shares.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدَادِ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badaAdi_A2">
					<p><span class="ar long">يَا قَوْمِ بَدَادِ بَدَادِ</span> means <em>O my people, take each one of you his adversary,</em> or <em>opponent</em> <span class="add">[<em>with whom to fight</em>]</span>. <span class="auth">(Aṣ, T, Ṣ, Ḳ.*)</span> Here <span class="ar">بداد</span> is indecl., with kesr for its termination, because it is an imperative verbal noun, and the imperative is alike uninfluenced with respect to its termination by any governing word; and it is said to be with kesr because two quiescent letters would otherwise occur together, <span class="add">[and]</span> because it occupies the place of an imperative verb <span class="add">[which in like manner is terminated with kesr when it is necessary to prevent the occurrence of two quiescent letters together]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدَادِ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badaAdi_A3">
					<p>With the article, you say, <span class="ar">البَدَادُ</span>, <span class="auth">(Aṣ, T,)</span> which signifies The <em>going forth to encounter another in fight,</em> or <em>to single combat;</em> as in the saying, <span class="ar long">لَوْ كَانَ البَدَادُ لَمَا أَطَاقُونَا</span> <em>Had we gone forth to encounter them in fight,</em> <span class="auth">(Aṣ, T, Ṣ, Ḳ,)</span> <em>man to man,</em> <span class="add">[<em>they had not been able to cope with us;</em>]</span> <span class="auth">(Aṣ, T;)</span> or <em>man by man.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say also, <span class="ar long">لَقُوا بَدَادَهُمْ</span>, explained above: <a href="#bd_6">see 6</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدَادِ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badaAdi_B1">
					<p><a href="#budBN">See also <span class="ar">بُدٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدَادِ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="badaAdi_C1">
					<p><a href="#bd_3">And see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="budaAdN">
				<h3 class="entry"><span class="ar">بُدَادٌ</span></h3>
				<div class="sense" id="budaAdN_A1">
					<p><span class="ar">بُدَادٌ</span>: <a href="#budBN">see <span class="ar">بُدٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidaAdN">
				<h3 class="entry"><span class="ar">بِدَادٌ</span></h3>
				<div class="sense" id="bidaAdN_A1">
					<p><span class="ar">بِدَادٌ</span>: <a href="#budBN">see <span class="ar">بُدٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بِدَادٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bidaAdN_B1">
					<p>Also <em>A stuffed lining put beneath a</em> <span class="add">[<em>camel's saddle of the kind called</em>]</span> <span class="ar">قَتَب</span>, <em>to defend the animal's back from being hurt thereby:</em> there is one such on each side: <span class="auth">(T:)</span> or, of a horse's saddle, and of a <span class="ar">قَتَب</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> the <em>stuffed thing,</em> or <em>pad, that is placed beneath, in order that it may not gall the animal's back;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَدِيدٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or the <span class="ar">بِدَادَانِ</span> and<span class="arrow"><span class="ar">بَدِيدَانِ↓</span></span> are <em>two bags</em> (<span class="ar">خَرِيطَتَانِ</span>), <em>which are stuffed, and placed under the curved pieces of wood, in order that the wood may not gall the animal's back;</em> derived from <span class="ar long">بَدَّ رِجْلَيْهِ</span> “he parted his legs:” <span class="auth">(Ṣ:)</span> <span class="add">[<a href="#badiydN">see also <span class="ar">بَدِيدٌ</span></a>:]</span> or the <span class="ar">بِدَادَانِ</span> of a <span class="ar">قَتَب</span> are <em>two things like provender-bags, 'which are stuffed, and bound with strings,</em> or <em>cords, to the pieces of wood called the</em> <span class="ar">ظَلِفَات</span> <em>and</em> <span class="ar">أَحْنَآء</span>: <span class="auth">(T:)</span> or they are, <em>to the</em> <span class="ar">قَتَب</span>, <em>like the</em> <span class="ar">كَرّ</span> <em>to the</em> <span class="ar">رَحْل</span>, <em>except that they do not appear before the</em> <span class="ar">ظَلِفَة</span>, <em>being only within</em> <span class="add">[<em>it</em>]</span>: <span class="auth">(M:)</span> <span class="add">[<a href="#HidojN">see also <span class="ar">حِدْجٌ</span></a>:]</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبِدَّةٌ</span> <span class="auth">(T, Ṣ)</span> and <span class="add">[of mult.]</span> <span class="ar">بَدَائِدُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بِدَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bidaAdN_B2">
					<p>Also <em>A piece of felt cloth, that is bound upon a beast which has a galled,</em> or <em>sore, back,</em> <span class="auth">(L, Ḳ,)</span> <em>cut,</em> or <em>slit, so as to be clear of the galls,</em> or <em>sores.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badiydN">
				<h3 class="entry"><span class="ar">بَدِيدٌ</span></h3>
				<div class="sense" id="badiydN_A1">
					<p><span class="ar">بَدِيدٌ</span>: <a href="#bidBN">see <span class="ar">بِدٌّ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدِيدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badiydN_B1">
					<p>Also <em>A saddlebag;</em> syn. <span class="ar">خُرْجٌ</span>: <span class="auth">(Ḳ:)</span> <span class="add">[and]</span> <span class="ar">بَدِيدَانِ</span> <em>a pair of saddle-bags;</em> syn. <span class="ar">خُرْجَانِ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="badiydN_B2">
					<p><a href="#bidaAdN">See also <span class="ar">بِدَادٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَدِيدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="badiydN_C1">
					<p>Also <em>A wide</em> <span class="add">[<em>desert such as is termed</em>]</span> <span class="ar">مَفَازَة</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <span class="ar long">فَلَاةٌ بَدِيدٌ</span> <span class="add">[<em>a desert,</em> or <em>waterless desert,</em>]</span> <em>in which is no one.</em> <span class="auth">(T, L. <span class="add">[In a copy of the former written <span class="ar long">بَدْ بَدٌ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bidaAdapN">
				<h3 class="entry"><span class="ar">بِدَادَةٌ</span></h3>
				<div class="sense" id="bidaAdapN_A1">
					<p><span class="ar">بِدَادَةٌ</span>: <a href="#bd_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badiydapN">
				<h3 class="entry"><span class="ar">بَدِيدَةٌ</span></h3>
				<div class="sense" id="badiydapN_A1">
					<p><span class="ar">بَدِيدَةٌ</span>: <a href="#bidBN">see <span class="ar">بِدٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAdBN">
				<h3 class="entry"><span class="ar">بَادٌّ</span></h3>
				<div class="sense" id="baAdBN_A1">
					<p><span class="ar">بَادٌّ</span> The <em>inner side of the thigh:</em> <span class="auth">(M, A, Ḳ:)</span> or the <em>part of the horseman's thigh that is next the saddle:</em> <span class="auth">(T, M, A, L:)</span> or the <em>part between the legs:</em> <span class="auth">(M, L:)</span> the <em>inner sides of the two thighs are called the</em> <span class="ar">بَادَّانِ</span>, <span class="auth">(Ṣ,)</span> because the saddle separates them; <span class="auth">(IAạr, M;)</span> and if so, <span class="ar">بَادٌّ</span> is of the measure <span class="ar">فَاعِلٌ</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>; or it may be a possessive epithet <span class="add">[meaning <span class="ar long">ذُو بَدٍّ</span>]</span>. <span class="auth">(M, L.)</span> You say, <span class="ar long">هُوَ حَسَنُ البَادِّ عَلَى السَّرجِ</span>, meaning <em>He is a good rider upon the saddle.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">بَادٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAdBN_A2">
					<p>Also the <em>part</em> of a horse's back <em>upon which the thigh of the rider presses.</em> <span class="auth">(Ḳṭ, T, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabadBN">
				<h3 class="entry"><span class="ar">أَبَدٌّ</span></h3>
				<div class="sense" id="OabadBN_A1">
					<p><span class="ar">أَبَدٌّ</span> A man <em>wide between the thighs,</em> <span class="auth">(ISk, Ṣ, M, Ḳ,)</span> <em>by reason of abundance of flesh:</em> <span class="auth">(ISk, Ṣ, M:)</span> or <em>wide between the arms;</em> <span class="auth">(Ḳ;)</span> <em>having the arms far from the sides:</em> <span class="auth">(M:)</span> or <em>wide between the shoulder-joints:</em> <span class="auth">(M:)</span> or <span class="auth">(so in the Ḳ; but accord. to the Ṣ, “and”)</span> <em>large in make,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> <em>having one part far from another:</em> <span class="auth">(M, Ḳ:)</span> and <em>wide in the breast:</em> <span class="auth">(Aboo-Málik, T:)</span> fem. <span class="ar">بَدَّآءُ</span>: <span class="auth">(Ṣ:)</span> which also signifies a woman <span class="auth">(M, L)</span> <em>large in the</em> <span class="ar">إِسْكَتَانِ</span> <span class="add">[or <em>labia majora of the vulva</em>]</span>, <span class="auth">(M, L, Ḳ,)</span> <em>having their edges far apart:</em> <span class="auth">(M, L:)</span> or <em>having much flesh in the thighs.</em> <span class="auth">(T, L.)</span> <span class="ar">الأَبَدٌّ</span> is used to signify <em>The weaver,</em> <span class="auth">(T, M, Ḳ,)</span> because of the distance between his thighs. <span class="auth">(M.)</span> The following saying, <span class="auth">(Ḳ,)</span> quoted by J, from the rájiz Aboo-Nukheyleh Es-Saadee,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَلَدُّ يَمْشِى مِشَيَةَ الأَبَدِّ</span> *</div> 
					</blockquote>
					<p>is incorrect, and should be thus,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَدَّآءُ تَمْشِى مِشْيَةَ الأَبَدِّ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>A woman of large make, walking in the manner of the man of large make;</em> or <em>a woman wide between the thighs,</em>, &amp;c.]</span>; <span class="auth">(Ḳ;)</span> for it is descriptive of a woman, as IB and Aboo-Sahl El-Harawee have observed before the author of the Ḳ. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">أَبَدٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabadBN_A2">
					<p>Also A horse <span class="add">[or any quadruped (<a href="#badBa">see <span class="ar">بَدَّ</span></a>)]</span> <em>having the fore legs far apart:</em> <span class="auth">(M, Ḳ:)</span> or <em>having the fore legs far from the sides:</em> <span class="auth">(TA:)</span> or <em>wide between the legs:</em> <span class="auth">(Ḥam p. 348:)</span> and a camel <em>having the elbows far from the sides:</em> <span class="auth">(TA:)</span> and the fem. <span class="ar">بَدَّآءُ</span>, a cow <em>having her fore legs far apart.</em> <span class="auth">(Ṣ.)</span> <span class="add">[Hence,]</span> <span class="ar long">الأَبَدُّ الزَّنِيمُ</span> <span class="add">[in the CK <span class="ar">الرَّثِيمُ</span>]</span> <em>The lion;</em> <span class="auth">(M, Ḳ;)</span> the former epithet being applied to him because his fore legs are far apart, and the latter because he is <span class="add">[often]</span> alone. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">أَبَدٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OabadBN_A3">
					<p><span class="ar long">كَتِفٌ بَدَّآءُ</span> <em>A broad shoulder-blade, the sides of which are distant, one from another.</em> <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabaAdiydu">
				<h3 class="entry"><span class="ar">أَبَادِيدُ</span></h3>
				<div class="sense" id="OabaAdiydu_A1">
					<p><span class="ar long">طَيْرٌ أَبَادِيدُ</span>, <span class="auth">(Fr, Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">تَبَادِيدُ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> <span class="add">[in the CK <span class="ar">نَبادِيدُ</span>,]</span> erroneously written by J <span class="arrow"><span class="ar">يَبَادِيدُ↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="add">[but see what follows; like <span class="ar">أَنَادِيدُ</span> and <span class="ar">يَنَادِيدُ</span>;]</span> <em>Birds in a state of dispersion.</em> <span class="auth">(Ṣ, Ḳ.)</span> In the following verse of 'Otárid Ibn-Kurrán, quoted by J,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">كَأَنَّمَا أَهُلُ حَجْرٍ يَنْظُرُونَ مَتَى</span> *</div> 
						<div class="star">* <span class="ar long">يَرَوْنَنِى خَارِجًا طَيْرٌ يَبَادِيدُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>As though the people of Hajr, watching when they should see me going forth, were birds in a state of dispersion</em>]</span>, <span class="auth">(Ḳ,)</span> thus related also by Yaạḳoob, and thus in the handwriting of Az, <span class="auth">(TA,)</span> the last two words should be <span class="ar long">طَيْرُ اليَنَادِيدِ</span>, the latter with <span class="ar">ن</span>, and governed by the former in the gen. case, the rhyme being with kesr: <span class="auth">(Ḳ:)</span> so says Aboo-Sahl El-Harawee. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بد</span> - Entry: <span class="ar">أَبَادِيدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabaAdiydu_A2">
					<p><span class="ar long">ذَهَبُوا أَبَادِيدُ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">تَبَادِيدُ↓</span></span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">يَبَادِيدُ↓</span></span>, <span class="auth">(as in the T, from Fr, and in the M and L, and in some copies of the Ḳ, <span class="add">[but see above,]</span>)</span> <span class="add">[as also <span class="ar">أَنَادِيدُ</span>, and <span class="ar">يَنَادِيدُ</span>, or <span class="ar">تَنَادِيدُ</span>,]</span> <em>They went away in a state of dispersion.</em> <span class="auth">(M, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tabaAdiydu">
				<h3 class="entry"><span class="ar">تَبَادِيدُ</span></h3>
				<div class="sense" id="tabaAdiydu_A1">
					<p><span class="ar">تَبَادِيدُ</span>: <a href="#OabaAdiydu">see <span class="ar">أَبَادِيدُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubidBN">
				<h3 class="entry"><span class="ar">مُبِدٌّ</span></h3>
				<div class="sense" id="mubidBN_A1">
					<p><span class="ar">مُبِدٌّ</span> <span class="add">[act. part. n. of 4, q. v.]</span>. The following words of ʼOmar Ibn-Abee-Rabee'ah,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَمُبِدٌّ سُؤَالَكَ العَالَمِينَ</span> *</div> 
					</blockquote>
					<p>are said to signify <em>Dost thou distribute thy petition among mankind one by one, so</em> as to include them universally? <span class="pb" id="Page_0163"></span>or <em>dost thou constrain them by thy petition?</em> from the saying, <span class="ar long">مَا لَكَ مِنْهُ بُدٌّ</span> <span class="add">[“thou hast no means,” or “way,” “of separating thyself from it,” or “avoiding it”]</span>. <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubadBadN">
				<h3 class="entry"><span class="ar">مُبَدَّدٌ</span></h3>
				<div class="sense" id="mubadBadN_A1">
					<p><span class="ar long">شَمْلٌ مُبَدَّدٌ</span> <span class="add">[<em>A united state of affairs</em>]</span>. <em>become disunited</em> <span class="add">[or <em>discomposed</em> or <em>disorganized</em>]</span>. <span class="auth">(Ṣ, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabadBidapN">
				<h3 class="entry"><span class="ar">مُتَبَدِّدَةٌ</span></h3>
				<div class="sense" id="mutabadBidapN_A1">
					<p><span class="ar long">اِمْرَأَةٌ مُتَبَدِّدَةٌ</span> <em>An emaciated woman,</em> <span class="add">[<em>as though</em>]</span> <em>having one part far from another.</em> <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="yabaAdiydu">
				<h3 class="entry"><span class="ar">يَبَادِيدُ</span></h3>
				<div class="sense" id="yabaAdiydu_A1">
					<p><span class="ar">يَبَادِيدُ</span>: <a href="#OabaAdiydu">see <span class="ar">أَبَادِيدُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0160.pdf" target="pdf">
							<span>Lanes Lexicon Page 160</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0161.pdf" target="pdf">
							<span>Lanes Lexicon Page 161</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0162.pdf" target="pdf">
							<span>Lanes Lexicon Page 162</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0163.pdf" target="pdf">
							<span>Lanes Lexicon Page 163</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
