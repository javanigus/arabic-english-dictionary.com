<article class="root" id="Root_bkr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/164_bkt">بكت</a></span>
				<span class="ar">بكر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/166_bkm">بكم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bkr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بكر</span></h3>
				<div class="sense" id="bkr_1_A1">
					<p><span class="ar">بَكَرَ</span> and <span class="ar">غَدَا</span> both <span class="add">[properly]</span> relate to the beginning of the day: <span class="auth">(AZ, Mṣb:)</span> the former of these verbs, <span class="auth">(T, Ṣ, A,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْكُرُ</span>}</span></add>, inf. n. <span class="ar">بُكُورٌ</span>; <span class="auth">(T, Ṣ;)</span> and<span class="arrow"><span class="ar">بكّر↓</span></span>, <span class="auth">(T, Ṣ, A,)</span> inf. n. <span class="ar">تَبْكِيرٌ</span>; <span class="auth">(T, Ṣ;)</span> and<span class="arrow"><span class="ar">ابكر↓</span></span>, and<span class="arrow"><span class="ar">ابتكر↓</span></span>, <span class="auth">(Ṣ, A,)</span> and<span class="arrow"><span class="ar">باكر↓</span></span>; <span class="auth">(Ṣ;)</span> all signify the same; <span class="auth">(Ṣ;)</span> <em>He</em> <span class="auth">(a traveller, A)</span> <em>went forth early in the morning, in the first part of the day;</em> or <em>between the time of the prayer of daybreak and sunrise;</em> syn. <span class="ar long">خَرَجَ فِى البُكْرَةِ</span>: <span class="auth">(T, A:)</span> or<span class="arrow"><span class="ar">ابكر↓</span></span>, inf. n. <span class="ar">إِبْكَارٌ</span>, signifies <em>he entered upon that time:</em> <span class="auth">(T:)</span> one should not say <span class="ar">بَكُرَ</span> nor <span class="ar">بَكِرَ</span> in the sense of <span class="ar">بكّر</span> <span class="add">[&amp;c.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkr_1_A2">
					<p>You say also, <span class="ar long">بَكَرَ إِلَيْهِ</span>, and <span class="ar">عَلَيْهِ</span>, and <span class="ar">فِيهِ</span>, inf. n. as above; and<span class="arrow"><span class="ar">بكّر↓</span></span>, and<span class="arrow"><span class="ar">ابكر↓</span></span>, and<span class="arrow"><span class="ar">ابتكر↓</span></span>; and<span class="arrow"><span class="ar">باكرهُ↓</span></span>; meaning <span class="ar long">أَتَاهُ بُكْرَةٌ</span> <span class="add">[i. e. <em>He came to him,</em> or <em>it, early in the morning, in the first part of the day;</em> or <em>between the time of the prayer of daybreak and sunrise:</em> and <em>he did it at that time:</em> or <span class="ar">بَكَرَ</span>, &amp;c. with <span class="ar">فِيهِ</span> following may be rendered <em>he occupied himself at that time in doing it</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bkr_1_A3">
					<p>And <span class="add">[hence,]</span> <span class="ar long">بَكَرَ إِلَيْهِ</span>, <span class="add">[and <span class="ar">عَلَيْهِ</span>,]</span> aor. and inf. n. as above; <span class="auth">(Mṣb;)</span> and <span class="ar long">بَكِرَ اليه</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْكَرُ</span>}</span></add> <span class="auth">(ISd, Ḳ;* <span class="add">[but see a remark respecting this verb above;]</span>)</span> and<span class="arrow"><span class="ar long">بكر↓ اليه</span></span>, <span class="auth">(Ṣ, Mṣb, TA,)</span> and <span class="ar">عليه</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar long">ابكر↓ اليه</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">عليه</span>; <span class="add">[and<span class="arrow"><span class="ar">ابكرهُ↓</span></span>;]</span> and<span class="arrow"><span class="ar">باكرهُ↓</span></span>; <span class="auth">(TA;)</span> signify also † <em>He hastened</em> <span class="add">[or <em>betook himself early</em>]</span> <em>to it,</em> or <em>to do it,</em> at any time, <span class="auth">(Ṣ, Mṣb, Ḳ, TA,)</span> morning or evening. <span class="auth">(TA.)</span> You say, <span class="ar long">بَكَرْتُ عَلَى الحَاجَةِ</span> † <span class="add">[<em>I hastened to do,</em> or <em>accomplish,</em> or <em>attain, the thing needed</em>]</span>, inf. n. as above: and in like manner,<span class="arrow"><span class="ar long">أَبْكَرْتُ↓ عَلَى الوِرْدِ</span></span> † <span class="add">[<em>I hastened to come to water</em>]</span>: <span class="auth">(AZ, Ṣ:)</span> and<span class="arrow"><span class="ar long">ابكر↓ الوِرْدَ</span></span>, <span class="auth">(TA,)</span> and <span class="ar">الغَدَآءَ</span>, <span class="auth">(AZ, Ṣ, TA,)</span> † <em>He hastened to come to water,</em> and to <em>take the morning-meal.</em> <span class="auth">(TA.)</span> Lebeed says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَاكَرْتُ جَاجَتَهَا الدَّجَاجَ بِسُحْرَةٍ</span> *</div> 
					</blockquote>
					<p>meaning † <em>I hastened to be before</em> the crowing of <em>the cock, at the close of night, in obtaining what was wanted</em> <span class="add">[<em>of it,</em> namely, of wine,]</span> by me: <span class="auth">(TA:)</span> <span class="ar">حاجتها</span> being for <span class="ar long">حَاجَتِى إِلَيْهَا</span>, i. e., <span class="ar long">إِلَى الخَمْرِ</span>. <span class="auth">(EM p. 170: but the first word is there written <span class="ar">بَادَرْتُ</span>.)</span> <span class="add">[<a href="#bkr_2">See also 2, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bkr_1_A4">
					<p><span class="add">[It is also said that]</span> <span class="ar">بكر</span> <span class="add">[app. <span class="ar">بَكِرَ</span>,]</span> inf. n. <span class="ar">بكر</span>, <span class="add">[app. <span class="ar">بَكَرٌ</span>,]</span> signifies † <em>He possessed the quality of applying himself early,</em> or <em>of hastening;</em> expl. by <span class="ar long">كَانَ صَاحِبَ بُكُورٍ</span>. <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#bakurN">But see <span class="ar">بَكُرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bkr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بكّر</span></h3>
				<div class="sense" id="bkr_2_A1">
					<p><span class="ar">بكّر</span>, inf. n. <span class="ar">تَبْكِيرٌ</span>: <a href="#bkr_1">see 1</a>, in three places: <a href="#bkr_1">and see 1</a>. You say also, <span class="ar long">بكّر إِلَى الجُمْعَةِ</span> ‡ <em>He went forth to the</em> <span class="add">[<em>prayers of</em>]</span> <em>Friday at the commencement of the time thereof.</em> <span class="auth">(A.)</span> And <span class="ar">بكّر</span> <span class="add">[alone]</span>, inf. n. as above, ‡ <em>He came to prayer at the commencement of its time.</em> <span class="auth">(Ḳ, TA.)</span> And <span class="ar long">بكّر بِالصَّلَاةِ</span> ‡ <em>He performed the prayer at the commencement of its time:</em> <span class="auth">(A, Mgh, Mṣb, TA:)</span> <em>he was regardful of it, and performed it early.</em> <span class="auth">(TA.)</span> <span class="pb" id="Page_0240"></span>And <span class="ar long">بَكِّرُوا بِصَلَاةِ المَغْرِبِ</span> ‡ <em>Perform ye the prayer of sunset at the setting of the</em> <span class="add">[<em>sun's</em>]</span> disc. <span class="auth">(Ṣ.)</span> And <span class="ar long">بَكَّرَتِ النَّخْلَةُ بِحَمْلِهَا</span> ‡ <span class="add">[<em>The palmtree was early with its fruit</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkr_2_A2">
					<p>Also ‡ <em>He was,</em> or <em>became,</em> or <em>went, before; preceded; had,</em> or <em>took, precedence;</em> syn. <span class="ar">تَقَدَّمَ</span>; and so<span class="arrow"><span class="ar">ابكر↓</span></span> and<span class="arrow"><span class="ar">تبكّر↓</span></span>. <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar long">بَكَّرْتُ فِى كَذَا</span> ‡ <em>I was,</em> or <em>became,</em> or <em>went, before,</em>, &amp;c., <em>in such a thing;</em> syn. <span class="ar">تَقَدَّمْتُ</span>. <span class="auth">(IJ, IB, TA.)</span> And <span class="ar long">بكّر عَلَى أَصْحَابِهِ</span> † <span class="add">[<em>He was,</em> or <em>became,</em> or <em>went, before his companions; preceded them;</em> or <em>had,</em> or <em>took, precedence of them</em>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bkr_2_B1">
					<p><span class="ar long">بكّرهُ عَلَى أَصْحَابِهِ</span> signifies <span class="ar long">جَعَلَهُ يُبَكِّرُ عَلَيْهِمْ</span> † <span class="add">[<em>He made him to be,</em> or <em>become,</em> or <em>go, before his companions; to precede them;</em> or <em>to have,</em> or <em>take, precedence of them</em>]</span>; and so<span class="arrow"><span class="ar long">ابكرهُ↓ عَلَيْهِمْ</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bkr_2_B2">
					<p><a href="#bkr_4">See also 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bkr_2_B3">
					<p><span class="ar long">بكّر الفَاكِهَةَ</span>: <a href="#bkr_8">see 8</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bkr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باكر</span></h3>
				<div class="sense" id="bkr_3_A1">
					<p><a href="#bkr_1">see 1</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bkr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابكر</span></h3>
				<div class="sense" id="bkr_4_A1">
					<p><a href="#bkr_1">see 1</a>, in seven places: <a href="#bkr_1">and see 1</a> as meaning <span class="ar">تَقَدَّمَ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkr_4_A2">
					<p><span class="ar">ابكر</span> also signifies <em>He had camels coming to water early in the morning, in the first part of the day;</em> or <em>between the time of the prayer of daybreak and sunrise.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bkr_4_B1">
					<p>It is also trans. of <span class="ar">بَكَرَ</span>: <span class="auth">(Ṣ, Ṣgh, Mṣb:)</span> you say, <span class="ar long">أَبْكَرْتُ غَيْرِى</span> <span class="add">[<em>I made another to go forth early in the morning, in the first part of the day;</em> or <em>between the time of the prayer of daybreak and sunrise:</em> and <em>I made another to go</em> to a person, &amp;c. <em>at that time;</em> and <em>to betake himself</em> to an action <em>at that time:</em> and † <em>to hasten,</em> or <em>betake himself early,</em> to a thing at any time, morning or evening: and<span class="arrow"><span class="ar long">بَكَّرْتُ↓ غَيْرِى</span></span> app. signifies the same]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bkr_4_B2">
					<p>You say also, <span class="ar long">ابكرهُ عَلَى أَصْحَابِهِ</span>: <a href="#bkr_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bkr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبكّر</span></h3>
				<div class="sense" id="bkr_5_A1">
					<p><a href="#bkr_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bkr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتكر</span></h3>
				<div class="sense" id="bkr_8_A1">
					<p><span class="ar">ابتكر</span>: <a href="#bkr_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkr_8_A2">
					<p>Also ‡ <em>He arrived</em> <span class="add">[at the mosque on the occasion of the Friday-prayers]</span> <em>in time to hear the first portion of the</em> <span class="ar">خُطْبَة</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>he heard the first portion of the</em> <span class="ar">خُطْبَة</span>; <span class="auth">(A, Mṣb;)</span> <span class="add">[and]</span> <span class="ar long">ابتكر الخُطْبَةَ</span> has this meaning. <span class="auth">(Mgh.)</span> <span class="arrow"><span class="ar long">مَنْ بَكَّرَ↓ وَٱبْتَكَرَ</span></span>, occurring in a trad., <span class="auth">(Ṣ, Mṣb,)</span> respecting <span class="add">[the prayers of]</span> Friday, <span class="auth">(Ṣ,)</span> means ‡ <em>Whoso hasteneth,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>and arriveth in time to hear the first portion of the</em> <span class="ar">خُطْبَة</span>, <span class="auth">(Ṣ,)</span> or <em>heareth the first portion thereof:</em> <span class="auth">(Mṣb:)</span> or <em>whoso hasteneth, going forth to the mosque early, and performeth the prayer at the first of its time:</em> or, accord. to Aboo-Saʼeed, <em>whoso hasteneth to the Fridayprayers, before the call to prayer, and arriveth at the commencement of their time:</em> or both the verbs signify the same, and the <span class="add">[virtual]</span> repetition is to give intensiveness and strength to the meaning. <span class="auth">(TA. <span class="add">[<a href="#bkr_2">See 2</a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bkr_8_A3">
					<p>You say also, <span class="ar">ابتكرهُ</span>, meaning ‡ <em>He took,</em> <span class="auth">(A, Mṣb,)</span> or <em>obtained possession of,</em> <span class="auth">(Ṣ, TA,)</span> <em>its</em> <span class="ar">بَاكُورَة</span>, <span class="auth">(Ṣ, TA,)</span> i. e., <span class="auth">(TA,)</span> <em>the first of it:</em> <span class="auth">(A, Mṣb, TA:)</span> which is the primary signification <span class="add">[of the trans. verb]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bkr_8_A4">
					<p>And <span class="ar">ابتكر</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">ابتكر الفَاكِهَةَ</span>, <span class="auth">(A, Mgh, Mṣb,)</span> and<span class="arrow"><span class="ar">بَكَّرَهَا↓</span></span>, <span class="auth">(TA,)</span> ‡ <em>He ate the first that had come to maturity of fruit,</em> or <em>of the fruit.</em> <span class="auth">(A, Mgh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bkr_8_A5">
					<p>And hence, <span class="auth">(Mgh,)</span> <span class="ar long">ابتكر الجَارِيَةَ</span> ‡ <em>He took the girl's virginity:</em> <span class="auth">(A, Mgh:)</span> or <em>he did so before she had attained to puberty.</em> <span class="auth">(Mṣb in art. <span class="ar">قض</span>, and TA in art. <span class="ar">خضر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bkr_8_A6">
					<p>And <span class="ar long">ابتكر عَجِينًا</span> † <span class="add">[<em>He took,</em> or <em>made use of, fresh dough</em> for preparing bread]</span>. <span class="auth">(Ḳ in art. <span class="ar">غرض</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bkr_8_B1">
					<p>And <span class="ar">اِبْتَكَرَتْ</span>, <span class="auth">(Abu-l-Beydà,)</span> or <span class="ar long">ابتكرت بِوَلَدِهَا</span>, <span class="auth">(AHeyth,)</span> <em>She brought forth her first offspring:</em> <span class="auth">(AHeyth, Abu-l-Beydà:)</span> or the former signifies <em>she</em> <span class="auth">(a woman)</span> <em>brought forth a male at her first birth.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakorN">
				<h3 class="entry"><span class="ar">بَكْرٌ</span> / <span class="ar">بَكْرَةٌ</span></h3>
				<div class="sense" id="bakorN_A1">
					<p><span class="ar">بَكْرٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">بُكْرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> but this latter is hardly to be found in any of the lexicons, <span class="auth">(MF,)</span> and<span class="arrow"><span class="ar">بِكْرٌ↓</span></span>, <span class="auth">(ISd, TA,)</span> <em>A youthful he-camel; one in a state of youthful vigour:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَكْرَةٌ</span>}</span></add>; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> and also <span class="ar">بَكْرٌ</span>, without <span class="ar">ة</span>: <span class="auth">(TA:)</span> the term <span class="ar">بَكْرٌ</span>, applied to a camel, corresponds to <span class="ar">فَتًى</span>, applied to a human being; and <span class="ar">بَكْرَةٌ</span>, to <span class="ar">فَتَاةٌ</span>; and <span class="ar">قَلُوصٌ</span>, to <span class="ar">جَارِيَةٌ</span>; and <span class="ar">بَعِيرٌ</span>, to <span class="ar">إِنْسَانٌ</span>; and <span class="ar">جَمَلٌ</span>, to <span class="ar">رَجُلٌ</span>; and <span class="ar">نَاقَةٌ</span>, to <span class="ar">مَرْأَةٌ</span>: <span class="auth">(AO, Ṣ:)</span> or the <em>offspring,</em> or <em>young one, of a she-camel;</em> <span class="auth">(Ḳ;)</span> thus indefinitely explained: <span class="auth">(TA:)</span> or <em>a camel in his sixth year</em> (<span class="ar">ثَنِىٌّ</span>) <span class="add">[and]</span> <em>until he becomes a</em> <span class="ar">جَذَع</span>: <span class="add">[but it seems that the reverse must be meant; for a <span class="ar">جذع</span>, of camels, is one in his fifth year:]</span> or <em>a camel in his second year</em> <span class="add">[and]</span> <em>until he enters his sixth year:</em> or <em>a camel in his second year,</em> or <em>that has entered his third year,</em> or <em>that has completed his second year and entered his third year;</em> syn. <span class="ar long">اِبْنُ لَبُونٍ</span>: <span class="auth">(Ḳ:)</span> and <em>a camel that has just entered upon his fourth year:</em> and <em>a camel in his fifth year:</em> <span class="auth">(IAạr, Az:)</span> or <em>a camel that has not entered his ninth year:</em> <span class="auth">(Ḳ:)</span> and sometimes it is metaphorically applied to a human being; <span class="add">[meaning ‡ <em>a young man;</em>]</span> and <span class="ar">بَكْرَةٌ</span> to ‡ <em>a young woman:</em> <span class="auth">(TA:)</span> the pl. <span class="auth">(of pauc., Ṣ)</span> is <span class="ar">أَبْكُرٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">أُبَيْكِرُونَ↓</span></span> occurs as pl. of <a href="#OabokurN">the dim. of <span class="ar">أَبْكُرٌ</span></a>; <span class="auth">(Ṣ, TA;)</span> and <span class="auth">(pl. of mult., Ṣ, TA)</span> <span class="ar">بِكَارٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> like as <span class="ar">فِرَاخٌ</span> <a href="#faroxN">is pl. of <span class="ar">فَرْخٌ</span></a>; <span class="auth">(Ṣ;)</span> or this <a href="#bakorapN">is pl. of <span class="ar">بَكْرَةٌ</span></a>; <span class="auth">(Mṣb, Ḳ;)</span> and there are other pls. of <span class="ar">بَكْرٌ</span>, namely, <span class="ar">بُكْرَانٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بِكَارَةٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and <span class="add">[quasi-pl. n.]</span> <span class="arrow"><span class="ar">بَكَارَةٌ↓</span></span>. <span class="auth">(Ḳ.)</span> Hence the well-known prov., <span class="auth">(TA,)</span> <span class="ar long">صَدَقَنِى سِنَّ بَكْرِهِ</span>, and <span class="ar long">سِنُّ بَكْرِهِ</span>, meaning <em>He hath told me what is in his mind, and what his ribs infold:</em> a saying originating from the following fact: a man bargained with another for a youthful camel (<span class="ar">بَكْر</span>), and said, “What is his age (<span class="ar">سِنُّهُ</span>)?” the other answered, “He is in his ninth year:” then the young camel took fright and ran away: whereupon his owner said to him, <span class="ar long">هِدَعْ هِدَعْ</span>; and this is an expression by which are quieted young ones, <span class="auth">(Ḳ,)</span> of the camel; <span class="auth">(TA;)</span> so when the purchaser heard it, he said, <span class="ar long">صدقنى سنّ بكره</span> <span class="add">[<em>He hath told me truly the age,</em> or <em>as to the age, of his youthful camel:</em> or <em>the age of his youthful camel has spoken truly to me</em>]</span>: if <span class="ar">سنّ</span> is in the accus. case, the meaning <span class="add">[of the verb]</span> is <span class="ar">عَرَّفَنِى</span>, <span class="auth">(Ḳ,)</span> and <span class="ar">سنّ</span> is in the accus. case as a second objective complement; <span class="auth">(TA;)</span> or <span class="ar long">خَبَرَ سِنِّ</span> is meant; <span class="add">[in the CK, erroneously, <span class="ar">خَبَرَ</span>;]</span> or <span class="ar long">فِى سِنِّ</span>; the prefixed noun <span class="add">[<span class="ar">خَبَرَ</span>]</span> or the proposition <span class="add">[<span class="ar">فِى</span>]</span> being suppressed <span class="add">[and <span class="ar">سنّ</span> being therefore in the accus. case]</span>: but if <span class="ar">سنّ</span> is in the nom. case, veracity is attributed to the <span class="add">[animal's]</span> age, by an amplification: <span class="auth">(Ḳ:)</span> or, as some say, the buyer said to the owner of the camel, “How many years has he?” and he told him; and he looked at the teeth of the camel, and found him to be as he had said; whereupon he said, <span class="ar long">صدقنى سِنُّ بكره</span>. <span class="auth">(Ḥar p. 95.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bukorN">
				<h3 class="entry"><span class="ar">بُكْرٌ</span></h3>
				<div class="sense" id="bukorN_A1">
					<p><span class="ar">بُكْرٌ</span>: <a href="#bakorN">see <span class="ar">بَكْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bikorN">
				<h3 class="entry"><span class="ar">بِكْرٌ</span></h3>
				<div class="sense" id="bikorN_A1">
					<p><span class="ar">بِكْرٌ</span> <em>A virgin;</em> <span class="auth">(Ṣ, Ḳ;)</span> and <em>a man who has not yet drawn near to a woman;</em> <span class="auth">(TA;)</span> <em>contr. of</em> <span class="ar">ثَيِّبٌ</span>, <em>applied to a man as well as to a female:</em> <span class="auth">(Mgh, Mṣb:)</span> pl. <span class="ar">أَبْكَارٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bikorN_A2">
					<p>And <span class="add">[hence,]</span> † <em>A pearl unpierced.</em> <span class="auth">(MF.)</span> And † <em>A bow when one first shoots with it.</em> <span class="auth">(TA.)</span> And ‡ <em>A cloud abounding with water:</em> <span class="auth">(Ḳ, TA:)</span> likened to a virgin, because her blood is more than that of her who is not a virgin: and the phrase <span class="ar long">سَحَابٌ بِكْرٌ</span> is sometimes used. <span class="auth">(TA.)</span> And <span class="ar long">نَارٌ بِكْرٌ</span> ‡ <em>Fire not lighted from another fire.</em> <span class="auth">(Aṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bikorN_A3">
					<p>Also She <em>that has not yet brought forth offspring:</em> <span class="auth">(AHeyth:)</span> and a cow <em>that has not yet conceived:</em> <span class="auth">(Ḳ:)</span> or a heifer <span class="auth">(Ḳ, TA)</span> <em>that has not yet conceived:</em> <span class="auth">(TA:)</span> and a woman, <span class="auth">(Ṣ, Ḳ,)</span> and a she-camel, <span class="auth">(Aṣ, Ḳ,)</span> <em>that has brought forth but once:</em> pl. <span class="ar">أَبْكَارٌ</span> and <span class="ar">بِكَارٌ</span>: <span class="auth">(TA:)</span> or a she-camel <em>in her first state</em> or <em>condition.</em> <span class="auth">(Ḥam p. 340.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bikorN_A4">
					<p>And <span class="add">[hence,]</span> ‡ A grape-vine <em>that has produced fruit but once:</em> <span class="auth">(A, Ḳ:)</span> pl. <span class="ar">أَبْكَارٌ</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bikorN_A5">
					<p>Also <em>i. q.</em> <span class="ar">بَكْرٌ</span>, q. v. <span class="auth">(ISd, TA.)</span> And <span class="add">[hence,]</span> <span class="ar long">أَبْكَارُ الأَوْلَادِ</span> † <em>Young children.</em> <span class="auth">(TA, from a trad.)</span> And <span class="ar long">أَبْكَارُ النَّحْلِ</span> † <em>Young bees.</em> <span class="auth">(TA.)</span> Whence, <span class="ar long">عَسَلُ أَبْكَارٍ</span> ‡ <em>Honey produced by young bees:</em> or this means <em>honey of which the preparation has been superintended by virgin-girls.</em> <span class="auth">(A,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bikorN_A6">
					<p>Also ‡ The <em>first-born of his,</em> or <em>her, mother</em> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>and father;</em> <span class="auth">(Mṣb, Ḳ;)</span> applied alike to the <em>male</em> and the <em>female:</em> <span class="auth">(Ṣ:)</span> and sometimes to that which is not the offspring of human beings; <span class="auth">(TA;)</span> the <em>first-born</em> of camels; <span class="auth">(Ṣ;)</span> and of a serpent: <span class="auth">(TA:)</span> pl. <span class="ar">أَبْكَارٌ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">هٰذَا بِكْرُ أَبَوَيْهِ</span> ‡ <em>This is the first-born of his parents.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَشَدُّ النَّاسِ بِكْرٌ ٱبْنُ بِكْرَيْنِ</span> <span class="auth">(A)</span> or <span class="ar long">بِكْرُ بِكْرَيْنِ</span> <span class="auth">(M, TA)</span> ‡ <span class="add">[<em>The strongest of men is the first-born of a man and woman each a first-born</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bikorN_A7">
					<p>† The <em>first</em> of anything; <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">بَاكُورَةٌ↓</span></span>: <span class="auth">(TA:)</span> and † <em>an action that has not been preceded by its like.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">مَا هٰذَا الأَمْرُ مِنْكَ بِكْرًا وَلَا ثَنِيًا</span> ‡ <em>This thing,</em> or <em>affair, is not thy first nor thy second.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bikorN_A8">
					<p><span class="ar long">حَاجَةٌ بِكْرٌ</span> ‡ <em>A want,</em> or <em>needful thing, recently sought to be accomplished</em> or <em>attained:</em> <span class="auth">(TA:)</span> or <em>that is the first in being referred to him of whom its accomplishment is sought.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بِكْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bikorN_A9">
					<p><span class="ar long">ضَرْبَةٌ بِكْرٌ</span> ‡ <em>A cutting blow</em> or <em>stroke,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>that kills</em> <span class="auth">(Ḳ)</span> <em>at once,</em> <span class="auth">(TA,)</span> <em>not requiring to be struck a second time:</em> <span class="auth">(Ṣ, A:)</span> pl. <span class="ar long">ضَرَبَاتٌ أَبْكَارٌ</span>; occurring in a trad., in which it is said that such were the blows of ʼAlee; <span class="auth">(Ṣ, TA;)</span> but in that trad., as some recite it, the latter word is <span class="arrow"><span class="ar">مُبْتَكِرَاتٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bakarN">
				<h3 class="entry"><span class="ar">بَكَرٌ</span></h3>
				<div class="sense" id="bakarN_A1">
					<p><span class="ar">بَكَرٌ</span>: <a href="#bukorapN">see <span class="ar">بُكْرَةٌ</span></a>, in three places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَكَرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bakarN_B1">
					<p><a href="#bakorapN">and see also <span class="ar">بَكْرَةٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakurN">
				<span class="pb" id="Page_0241"></span>
				<h3 class="entry"><span class="ar">بَكُرٌ</span></h3>
				<div class="sense" id="bakurN_A1">
					<p><span class="ar long">رَجُلٌ بَكُرٌ فِى حَاجَتِهِ</span>, <span class="add">[in the CK, erroneously, <span class="ar">بَكْرٌ</span>,]</span> and↓<span class="ar">بَكِرٌ</span>, <span class="auth">(Ṣ, Ḳ,* TA,)</span> like <span class="ar">حَذُرٌ</span> and <span class="ar">حَذِرٌ</span>, <span class="auth">(Ṣ,)</span> and↓<span class="ar">بَكِيرٌ</span>, <span class="auth">(TA,)</span> † <em>A man possessing the quality of applying himself early,</em> or <em>of hastening,</em> or <em>having strength to apply himself early,</em> or <em>to hasten,</em> (<span class="ar long">صَاحِبُ بُكُورٌ</span>, Ṣ, or <span class="ar long">قَوِىٌّ عَلَى البُكُورِ</span>, Ḳ,) <em>to do,</em> or <em>accomplish, the thing that he needs,</em> or <em>wants:</em> <span class="auth">(Ṣ:)</span> <span class="ar">بَكُرٌ</span> and <span class="ar">بَكِرٌ</span> <span class="add">[and <span class="ar">بَكِيرٌ</span>]</span> are <span class="add">[said to be]</span> possessive epithets; for they have no simple triliteral verb. <span class="auth">(TA.)</span> <span class="add">[<a href="#bkr_1">But see 1</a>, last sentence.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bakirN">
				<h3 class="entry"><span class="ar">بَكِرٌ</span></h3>
				<div class="sense" id="bakirN_A1">
					<p><span class="ar">بَكِرٌ</span>: <a href="#bakurN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakorapN">
				<h3 class="entry"><span class="ar">بَكْرَةٌ</span></h3>
				<div class="sense" id="bakorapN_A1">
					<p><span class="ar">بَكْرَةٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and↓<span class="ar">بَكَرَةٌ</span> <span class="auth">(Mṣb, Ḳ)</span> The <em>thing upon which</em> <span class="add">[<em>passes the rope wherewith</em>]</span> <em>one draws water</em> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>from a well</em> <span class="add">[<em>or the like</em>]</span>; <span class="auth">(Ṣ;)</span> <span class="add">[i. e. the <em>sheave of a pulley;</em>]</span> <em>a round piece of wood, in the middle</em> <span class="add">[<em>of the circumference</em>]</span> <em>whereof is a groove</em> <span class="auth">(Ḳ, TA)</span> <em>for the rope, and in the interior</em> <span class="add">[or <em>centre</em>]</span> <em>whereof is an axis upon which it turns:</em> <span class="auth">(TA:)</span> or <em>a quick</em> <span class="ar">مَحَالَة</span> <span class="add">[or <em>large sheave of a pulley</em>]</span>: <span class="auth">(M, Ḳ:)</span> <span class="add">[but MF disapproves of this last explanation: sometimes, by a synecdoche, it is used to signify <em>a pulley</em> complete:]</span> the pl. is <span class="arrow"><span class="ar">بَكَرٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> a pl. of the former, anomalous, like <span class="ar">حَلَقٌ</span> <a href="#HaloqapN">pl. of <span class="ar">حَلْقَةٌ</span></a>, and <span class="ar">حَمَأٌ</span> <a href="#HamoOapN">pl. of <span class="ar">حَمْأَةٌ</span></a>, <span class="auth">(Ṣ,)</span> or of the latter; <span class="auth">(Mṣb;)</span> or a coll. gen. n., of which <span class="ar">بَكَرَةٌ</span> is the n. un.; <span class="auth">(MF;)</span> and <span class="ar">بَكَرَات</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> a pl. of the former <span class="add">[as well as of the latter]</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَكْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bakorapN_A2">
					<p>Hence, app., the former signifies also † <em>A small ring, like a bead, in the ornamental part of a sword:</em> <span class="auth">(Mgh:)</span> <span class="add">[and the pl.]</span> <span class="ar">بَكَرَاتٌ</span> signifies † the <em>rings that are attached to the ornamental part</em> <span class="add">[<em>of the scabbard</em>]</span> <em>of a sword,</em> <span class="auth">(Ḳ,)</span> <em>resembling the </em> <span class="add">[<em>rings called</em>]</span> <span class="ar">قَتَخ</span> <span class="add">[<em>which are worn upon the fingers or toes</em>]</span> <em>of women.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَكْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bakorapN_A3">
					<p><span class="add">[And hence, perhaps,]</span> † <em>An assembly, a company,</em> or <em>a congregated body.</em> <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَكْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bakorapN_A4">
					<p><span class="ar long">جَاؤُوا عَلَى بَكْرَةِ أَبِيهِمْ</span> is a prov., <span class="auth">(TA,)</span> meaning ‡ <em>They came together, not one remaining behind,</em> <span class="auth">(Ṣ, TA;)</span> <em>they came all of them,</em> <span class="auth">(AA, IJ, A, TA,)</span> <em>without exception:</em> <span class="auth">(TA:)</span> or <em>they came in a multitude, and all together, none remaining behind:</em> <span class="auth">(TA:)</span> or <em>they came in succession, one after,</em> or <em>at the heels of, another:</em> <span class="auth">(AO:)</span> or <em>they came in one way,</em> or <em>manner:</em> <span class="auth">(Aṣ:)</span> <span class="add">[accord. to some, from <span class="ar">بكرة</span> as explained in the next preceding sentence; and, if so, <span class="ar">على</span> is used in the sense of <span class="ar">مَعَ</span>, or <span class="ar">مُشْتَمِلِينَ</span> is understood before it: or it is from <span class="ar">بكرة</span> signifying “a youthful she-camel;” and thus implies that they were few: <span class="auth">(see Freytag's Arab. Prov. i. 312:)</span> or]</span> from <span class="ar long">بَكَّرْتُ فِى كَذَا</span> meaning “I was,” or “became,” or “went,” “before in such a thing;” so that it signifies that they came from first to last: <span class="auth">(IJ:)</span> or from <span class="ar">بكرة</span> in the first of the senses explained in this paragraph; though in this case there is no <span class="ar">بكرة</span> in reality. <span class="auth">(AO, Ṣ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bukorapN">
				<h3 class="entry"><span class="ar">بُكْرَةٌ</span></h3>
				<div class="sense" id="bukorapN_A1">
					<p><span class="ar">بُكْرَةٌ</span> and<span class="arrow"><span class="ar">بَكَرٌ↓</span></span> The <em>early morning,</em> or <em>first part of the day;</em> <span class="auth">(Bḍ and Jel in xix. 12 and xxxiii. 41 and xlviii. 9, as relating to the former word; and Ḳ;*)</span> <em>between the time of the prayer of daybreak and sunrise;</em> syn. <span class="ar">غُدْوَةٌ</span>; and<span class="arrow"><span class="ar">إِبْكَارٌ↓</span></span> is a subst. in the same sense, <span class="auth">(Ḳ,)</span> accord. to the lexicologists, as Sb says; but he adds that he holds it to be <span class="add">[only]</span> the inf. n. of <span class="ar">أَبْكَرَ</span>: <span class="auth">(TA: <span class="add">[and the like is said in the Ṣ with reference to its occurrence in the Ḳur iii. 36 and xl. <em>57:</em>]</span>)</span> pl. <span class="add">[of pauc.]</span> of the first, <span class="ar">أَبْكَارٌ</span>, and <span class="add">[of mult.]</span> <span class="ar">بُكَرٌ</span>. <span class="auth">(T, Mṣb.)</span> You say, <span class="ar long">أَتَيْتُهُ بُكْرَةٌ</span> <span class="auth">(Ṣ, A, Mṣb)</span> and<span class="arrow"><span class="ar">بَكَرًا↓</span></span>, <span class="auth">(A,)</span> meaning<span class="arrow"><span class="ar">بَاكِرٍا↓</span></span> <span class="add">[<em>I came to him early in the morning,</em>, &amp;c.]</span>. <span class="auth">(Ṣ, A, Mṣb.)</span> But if you mean the <span class="ar">بُكْرَةٌ</span> of a particular day, you say, <span class="ar long">أَتَيْتُهُ بُكْرَةَ</span>, making the noun imperfectly decl.; <span class="add">[meaning <em>I came to him early in the morning,</em>, &amp;c., <em>of this day;</em>]</span> and in this case it is not to be used otherwise than as an adv. n. of time. <span class="auth">(Ṣ.)</span> If you say <span class="arrow"><span class="ar">بَاكِرًا↓</span></span>, using this word as an epithet, you use <span class="ar">بَاكِرَة</span> for the fem. <span class="auth">(TA.)</span> You say also, <span class="ar long">سِرْ عَلَى فَرَسِكَ بُكْرَةً</span> and<span class="arrow"><span class="ar">بَكَرًا↓</span></span> <span class="add">[<em>Go thou on thy horse early in the morning,</em>, &amp;c.]</span>; like as you say, <span class="ar">سَحَرًا</span>. <span class="auth">(Ṣ, TA. <span class="add">[But in two copies of the Ṣ, for <span class="ar">سرْ</span>, I find <span class="ar">سِيرَ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bakarapN">
				<h3 class="entry"><span class="ar">بَكَرَةٌ</span></h3>
				<div class="sense" id="bakarapN_A1">
					<p><span class="ar">بَكَرَةٌ</span>: <a href="#bakorapN">see <span class="ar">بَكْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakuwrN">
				<h3 class="entry"><span class="ar">بَكُورٌ</span></h3>
				<div class="sense" id="bakuwrN_A1">
					<p><span class="ar">بَكُورٌ</span> <span class="auth">(A, Ḳ)</span> and<span class="arrow"><span class="ar">بَاكُورٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">بَاكِرٌ↓</span></span> <span class="auth">(A)</span> and<span class="arrow"><span class="ar">مُبْكِرٌ↓</span></span> <span class="auth">(Ḳ)</span> ‡ Rain <em>that falls in the first of its season:</em> <span class="auth">(A:)</span> or <em>that comes</em> <span class="auth">(TA)</span> <em>in the commencement of</em> <span class="add">[<em>the season of</em>]</span> <em>the</em> <span class="ar">وَسْمِىّ</span> <span class="add">[q. v.]</span>: <span class="auth">(Ḳ, TA:)</span> and <em>that comes in the end of the night,</em> or <em>the beginning of the day.</em> <span class="auth">(TA.)</span> You say also <span class="ar long">سَحَابَةٌ مِدْلَاجٌ بَكُورٌ</span> ‡ <span class="add">[<em>A cloud that comes in the latter part of the night, in the first of its season, bringing rain</em>]</span>: <span class="auth">(A:)</span> and<span class="arrow"><span class="ar long">سَحَابَةٌ مِبْكَارٌ↓</span></span> <em>a cloud that comes in the end of the night.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَكُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bakuwrN_A2">
					<p>Also <span class="ar">بَكُورٌ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَكِيرَةٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بَاكُورَةٌ↓</span></span> <span class="auth">(Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَاكِرٌ↓</span></span> <span class="auth">(A)</span> and<span class="arrow"><span class="ar">مِبْكَارٌ↓</span></span> <span class="auth">(A in art. <span class="ar">اخر</span> and Ḳ)</span> ‡ A palm-tree (<span class="ar">نَخْلَةٌ</span>, A) <em>that comes to maturity first,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>before the other palm-trees:</em> <span class="auth">(Ṣ:)</span> or <em>that produces its fruit early;</em> <span class="auth">(A;)</span> <em>contr. of</em> <span class="ar">مِئْخَارٌ</span> <span class="auth">(A in art. <span class="ar">اخر</span>:)</span> pl. <span class="auth">(of the first, Mṣb, Ḳ)</span> <span class="ar">بُكُرٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ; <span class="add">[in the CK <span class="ar">بُكْرٌ</span>;]</span>)</span> and <span class="add">[pl. of<span class="arrow"><span class="ar">بَاكِرٌ↓</span></span> or <span class="ar">بَاكِرَةٌ</span>]</span> <span class="ar">بَوَاكِرُ</span> <span class="auth">(Ḳ voce <span class="ar">تَبَاشِيرُ</span>)</span> <span class="arrow"><span class="ar">بَاكُورَةٌ↓</span></span> <a href="#baAkuwrN">is fem. of <span class="ar">بَاكُورٌ</span></a>, <span class="auth">(Ḳ, TA,)</span> which signifies † Anything <em>that hastens its coming</em> <span class="auth">(TA)</span> <em>and its attaining to maturity.</em> <span class="auth">(Ḳ, TA.)</span> You say also<span class="arrow"><span class="ar long">أَرْضٌ مِبْكَارٌ↓</span></span> † <em>Land that produces plants,</em> or <em>herbage, quickly.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bakiyrN">
				<h3 class="entry"><span class="ar">بَكِيرٌ</span> / <span class="ar">بَكِيرَةٌ</span></h3>
				<div class="sense" id="bakiyrN_A1">
					<p><span class="ar">بَكِيرٌ</span>, and its fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَكِيرَةٌ</span>}</span></add>: <a href="#bakurN">see <span class="ar">بَكُرٌ</span></a> <a href="#bakuwrN">and <span class="ar">بَكُورٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakaArapN">
				<h3 class="entry"><span class="ar">بَكَارَةٌ</span></h3>
				<div class="sense" id="bakaArapN_A1">
					<p><span class="ar">بَكَارَةٌ</span> <em>Virginity:</em> <span class="auth">(Ṣ, Ḳ:)</span> the <em>virginity,</em> or <em>maidenhead,</em> of a woman. <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَكَارَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bakaArapN_B1">
					<p><a href="#bakorN">See also <span class="ar">بَكْرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAkirN">
				<h3 class="entry"><span class="ar">بَاكِرٌ</span></h3>
				<div class="sense" id="baAkirN_A1">
					<p><span class="ar">بَاكِرٌ</span> <span class="add">[part. n. of <span class="ar">بَكَرَ</span>]</span>: <a href="#bukorapN">see <span class="ar">بُكْرَةٌ</span></a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَاكِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAkirN_B1">
					<p><a href="#bakuwrN">and see <span class="ar">بَكُورٌ</span></a>, in three places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَاكِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baAkirN_B2">
					<p>and see an ex. of the pl. of its fem. <span class="ar">بَاكِرَةٌ</span>, i. e. <span class="ar">بَوَاكِرُ</span>, voce <span class="ar">بَاصِرٌ</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَاكِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="baAkirN_B3">
					<p>Also † Fruit when <em>first ripe:</em> pl. <span class="ar">بِكَارٌ</span>, like as <span class="ar">صِحَابٌ</span> <a href="#SaAHibN">is pl. of <span class="ar">صَاحِبٌ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAkuwrN">
				<h3 class="entry"><span class="ar">بَاكُورٌ</span> / <span class="ar">بَاكُورَةٌ</span></h3>
				<div class="sense" id="baAkuwrN_A1">
					<p><span class="ar">بَاكُورٌ</span>, and its fem. <span class="ar">بَاكُورَةٌ</span>: <a href="#bakuwrN">see <span class="ar">بَكُورٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAkuwrapN">
				<h3 class="entry"><span class="ar">بَاكُورَةٌ</span></h3>
				<div class="sense" id="baAkuwrapN_A1">
					<p><span class="ar">بَاكُورَةٌ</span> <span class="add">[as a subst.]</span>: <a href="#bikorN">see <span class="ar">بِكْرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَاكُورَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAkuwrapN_A2">
					<p>Also, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">بَاكُورَةٌ الفَا كِهَةِ</span>, <span class="auth">(A, Mṣb,)</span> ‡ The <em>first of fruit:</em> <span class="auth">(Ṣ:)</span> or the <em>first that comes to maturity, of fruit:</em> <span class="auth">(A, Mṣb, Ḳ:)</span> or <em>fruit that hastens to come forth:</em> <span class="auth">(AḤát, Mṣb:)</span> pl. <span class="ar">بَوَاكِيرُ</span> and <span class="ar">بَاكُورَاتٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكر</span> - Entry: <span class="ar">بَاكُورَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAkuwrapN_A3">
					<p>The pl. <span class="ar">بَوَاكِيرُ</span> also signifies † <em>Winds that announce</em> <span class="add">[<em>coming</em>]</span> <em>rain.</em> <span class="auth">(A in art. <span class="ar">بشر</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibokaArN">
				<h3 class="entry"><span class="ar">إِبْكَارٌ</span></h3>
				<div class="sense" id="IibokaArN_A1">
					<p><span class="ar">إِبْكَارٌ</span>: <a href="#bukorapN">see <span class="ar">بُكْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubayokirN">
				<h3 class="entry"><span class="ar">أُبَيْكِرٌ</span></h3>
				<div class="sense" id="OubayokirN_A1">
					<p><span class="ar">أُبَيْكِرٌ</span> <a href="#OabokirN">dim. of <span class="ar">أَبْكِرٌ</span></a>, pl. of pauc. of <span class="ar">بَكْرٌ</span>: see its pl. <span class="ar">أُبَيْكِرُونَ</span> voce <span class="ar">بَكْرٌ</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabaAkiyru">
				<h3 class="entry"><span class="ar">تَبَاكِيرُ</span></h3>
				<div class="sense" id="tabaAkiyru_A1">
					<p><span class="ar">تَبَاكِيرُ</span> † The <em>colours of palm-trees when the fruit begins to ripen.</em> <span class="auth">(TA voce <span class="ar">تَبَاشِيرُ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubokirN">
				<h3 class="entry"><span class="ar">مُبْكِرٌ</span></h3>
				<div class="sense" id="mubokirN_A1">
					<p><span class="ar">مُبْكِرٌ</span>: <a href="#bakuwrN">see <span class="ar">بَكُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibokaArN">
				<h3 class="entry"><span class="ar">مِبْكَارٌ</span></h3>
				<div class="sense" id="mibokaArN_A1">
					<p><span class="ar">مِبْكَارٌ</span>: <a href="#bakuwrN">see <span class="ar">بَكُورٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotakiraAtN">
				<h3 class="entry"><span class="ar">مُبْتَكِرَاتٌ</span></h3>
				<div class="sense" id="mubotakiraAtN_A1">
					<p><span class="ar long">ضرَبَاتٌ مُبْتَكِرَاتٌ</span>: <a href="#bikorN">see <span class="ar">بِكْرٌ</span></a>. last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0239.pdf" target="pdf">
							<span>Lanes Lexicon Page 239</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0240.pdf" target="pdf">
							<span>Lanes Lexicon Page 240</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0241.pdf" target="pdf">
							<span>Lanes Lexicon Page 241</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
