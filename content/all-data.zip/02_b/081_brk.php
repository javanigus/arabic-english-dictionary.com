<article class="root" id="Root_brk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/080_brqE">برقع</a></span>
				<span class="ar">برك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/082_brm">برم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brk_1">
				<h3 class="entry">1. ⇒ <span class="ar">برك</span></h3>
				<div class="sense" id="brk_1_A1">
					<p><span class="ar">بَرَكَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُكُ</span>}</span></add>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">بُرُوكٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">تَبْرَاكٌ</span>, <span class="auth">(Ḳ,)</span> said of a camel, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> <em>i. q.</em> <span class="ar">اِسْتَنَاخَ</span> <span class="add">[i. e. <em>He lay down,</em> or <em>kneeled and lay down, upon his breast, with his legs folded</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> <em>he made his breast to cleave to the ground;</em> <span class="auth">(Mgh;)</span> <em>he fell upon his</em> <span class="ar">بَرْك</span>, i. e. <em>breast;</em> <span class="auth">(Mṣb;)</span> <em>he threw his</em> <span class="ar">برك</span>, i. e. <em>breast, upon the ground;</em> <span class="auth">(TA;)</span> and in like manner,<span class="arrow"><span class="ar">برّك↓</span></span>, <span class="auth">(TA, and so in some copies of the Ḳ,)</span> inf. n. <span class="ar">تَبْرِيكٌ</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَرَكَتِ النَّعَامَةُ</span> <em>The ostrich lay upon its breast.</em> <span class="auth">(TA.)</span> And <span class="ar">بَرَكَ</span> is also said of a lion, and of a man. <span class="auth">(Ḳ voce <span class="ar">ربض</span>.)</span> <span class="add">[Of the latter, one also says, <span class="ar long">بَرَكَ عَلَى رُكْبَتَيْهِ</span> <em>He fell,</em> or <em>set himself, upon his knees; he kneeled.</em>]</span> The <span class="ar">بُرُوك</span> of a man praying, which is forbidden, is The <em>putting down the hands before the knees,</em> after the manner of the camel <span class="add">[when he lies down; for the latter falls first upon his knees, and then upon his stiflejoints]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brk_1_A2">
					<p>Hence, i. e., from the verb said of a camel, inf. n. <span class="ar">بُرُوكٌ</span>, <span class="auth">(TA,)</span> <em>He,</em> or <em>it,</em> <span class="auth">(i. e. anything, Ṣ,)</span> <em>was,</em> or <em>became, firm, steady, steadfast,</em> or <em>fixed; continued, remained,</em> or <em>stayed;</em> <span class="auth">(Ṣ, Ḳ;)</span> in a place: <span class="auth">(TḲ:)</span> <span class="add">[and so, app., with <span class="ar">ـِ</span> for its aor.; for]</span> you say, <span class="ar long">بَرَكَ لِلْقِتَالِ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْرِكُ</span>}</span></add>, <span class="add">[<em>He was,</em> or <em>became, firm,</em>, &amp;c., <em>for the purpose of fighting,</em>]</span> and in like manner <span class="ar">بَرِكَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَكُ</span>}</span></add>. <span class="auth">(TA. <span class="add">[See also a similar signification of 8.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brk_1_A3">
					<p>† <em>It</em> <span class="auth">(the night)</span> <em>was,</em> or <em>became, long,</em> or <em>protracted; as though it did not quit its place.</em> <span class="auth">(A and TA in art. <span class="ar">قعس</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brk_1_A4">
					<p><a href="#brk_8">See also 8</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brk_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّك</span></h3>
				<div class="sense" id="brk_2_A1">
					<p><a href="#brk_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brk_2_B1">
					<p><span class="ar">تَبْرِيكٌ</span> also signifies The <em>praying for</em> <span class="ar">بَرَكَة</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> for a man, &amp;c. <span class="auth">(TA.)</span> You say, <span class="ar long">بَرَّكْتُ عَلَيْهِ</span>, inf. n. <span class="ar">تَبْرِيكٌ</span>, <em>I said to him,</em> <span class="ar long">بَارَكَ ٱللّٰهَ عَلَيْكَ</span> <span class="add">[or <span class="ar">فِيكَ</span>, &amp;c., <em>God bless thee!</em>, &amp;c.]</span>. <span class="auth">(TA.)</span> And <span class="ar long">برّك على الطَّعَامِ</span> <em>He prayed for,</em> or <em>invoked, a blessing on the food.</em> <span class="auth">(TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brk_3">
				<h3 class="entry">3. ⇒ <span class="ar">بارك</span></h3>
				<div class="sense" id="brk_3_A1">
					<p><span class="ar long">بارك عَلَيْهِ</span> <em>He kept,</em> or <em>applied himself, constantly,</em> or <em>perseveringly, to it;</em> <span class="auth">(Lḥ, Ḳ;)</span> namely, an affair, <span class="auth">(TA in art. <span class="ar">حفظ</span>,)</span> or commerce, or traffic, &amp;c. <span class="auth">(Lḥ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brk_3_B1">
					<p><span class="ar long">بارك ٱللّٰهُ فِيكَ</span>, <span class="auth">(Fr, Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">لَكَ</span>, and <span class="ar">عَلَيْكَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">بَارَكَكَ</span>, <span class="auth">(Fr, Ṣ, Ḳ,)</span> inf. n. <span class="ar">مُبَارَكَةٌ</span>, <span class="auth">(TḲ,)</span> <span class="add">[<em>God bless, beatify, felicitate,</em> or <em>prosper, thee;</em>]</span> <em>God put in thee,</em> <span class="auth">(TA,)</span> <em>give thee, make thee to possess,</em> <span class="auth">(T, Ḳ,)</span> <span class="ar">بَرَكَة</span> <span class="add">[i. e. <em>a blessing, good of any kind, prosperity</em> or <em>good fortune, increase,</em>, &amp;c.]</span>. <span class="auth">(TA, TḲ.)</span> <span class="ar long">بَارِكْ عَلَى مُحَمِّدٍ وَعَلَى آلِ مُحَمَّدٍ</span> <span class="auth">(in a trad., TA,)</span> means <em>Continue Thou,</em> or <em>perpetuate Thou,</em> <span class="auth">(O God,)</span> <em>to Moḥammad and to the family of Moḥammad the eminence and honour which Thou hast given them:</em> <span class="auth">(Ḳ, TA:)</span> <span class="add">[or <em>still bless</em> or <em>beatify,</em> or <em>continue to bless</em> or <em>beatify, Moḥammad</em>, &amp;c.: though it may well be rendered simply <em>bless</em> or <em>beatify</em>, &amp;c.:]</span> Az says that it is from <span class="ar">بَرَكَ</span> said of a camel, meaning “he lay down upon his breast in a place and clave thereto.” <span class="auth">(TA.)</span> And <span class="ar long">اَللّٰهُمَ بَارِكْ لَنَا فِى المَوْتِ</span>, in another trad., means <span class="add">[<em>O God, bless us</em>]</span> <em>in</em> the state to which <em>death</em> will bring us. <span class="auth">(TA.)</span> The Arabs say to the beggar, <span class="ar long">بُورِكَ فِيكَ</span> <span class="add">[<em>Mayest thou be blest;</em> and, in the present day, <span class="ar long">اَللّٰه يُبَارِك فِيك</span> <em>God bless thee</em>]</span>; meaning thereby to repel him; not to pray for him: and by reason of frequency of usage of this phrase, they have made <span class="arrow"><span class="ar">بُورِك↓</span></span> a noun: a poet <span class="add">[in Ḥar <span class="ar long">شريش العدوى</span> <span class="auth">(app. Sherees, not Shereesh, El-'Adawee)</span>, in the TA Aboo-Fir'own,]</span> says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَظُنُّ أَنَّ بُورِكًا يَكْفِينِى</span> *</div> 
						<div class="star">* <span class="ar long">إِذَا خَرَجْتُ بَاسِطًا يَمِينِى</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>She imagines that the saying “Mayest thou be blest” will suffice me when I go forth stretching out my right hand</em> for an alms]</span>. <span class="auth">(Ḥar p. 378. <span class="add">[This verse is differently cited in the TA; for there, instead of <span class="ar">تظنّ</span> and <span class="ar">خرجت</span>, we find <span class="ar">تُحِبُّ</span> and <span class="ar">غَدَوْتُ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brk_3_B2">
					<p><span class="add">[You also say of a man, <span class="ar long">بارك فِيهِ</span>, and <span class="ar">لَهُ</span>, &amp;c., meaning <em>He blessed him;</em> i. e. <em>he prayed God to bless him.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="brk_3_B3">
					<p><a href="#brk_6">See also 6</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brk_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرك</span></h3>
				<div class="sense" id="brk_4_A1">
					<p><span class="ar">ابركهُ</span> <em>He made him</em> <span class="auth">(namely, a camel,)</span> <em>to lie down</em> <span class="add">[or <em>kneel and lie down</em>]</span> <em>upon his breast.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">أَبْرَكْتُهُ فَبَرَكَ</span> <em>I made him to lie down upon his breast, and he lay down upon his breast:</em> but this is rare: the more common phrase is <span class="ar long">أَنْخَتُهُ فَٱسْتَنّاخَ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brk_4_B1">
					<p><a href="#brk_8">See also 8</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brk_4_C1">
					<p><span class="ar long">مَا أَبْرَكَهُ</span> <span class="add">[<em>How blessed is he,</em> or <em>it!</em>]</span> is an instance of a verb of wonder with a passive meaning <span class="add">[and irregularly derived]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brk_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّك</span></h3>
				<div class="sense" id="brk_5_A1">
					<p><span class="ar long">تبرّك بِهِ</span> <em>i. q.</em> <span class="ar long">تَيَمَّنَ بِهِ</span> <span class="add">[<em>He had a blessing;</em> and <em>he was,</em> or <em>became, blest; by means of him,</em> or <em>it:</em> so accord. to explanations of <span class="ar">تَبَرُّكْ</span> in the KL: but very often signifying <em>he looked for a blessing by means of him,</em> or <em>it; he regarded him,</em> or <em>it, as a means of obtaining a blessing; he augured good from him,</em> or <em>it;</em> <span class="ar long">تيمّن به</span> being opposed to <span class="ar long">تَشَأَّمَ به</span>; as in the Ḳ in art. <span class="ar">طير</span>, and in Bḍ in xvii. 14, &amp;c.]</span>: <span class="auth">(Ṣ, Ḳ:)</span> and<span class="arrow"><span class="ar long">تبارك↓ بِالشَّيْءِ</span></span> <em>He augured good from the thing.</em> <span class="auth">(Lth, Ḳ.)</span> One says so of a man. <span class="auth">(Ḳ in art. <span class="ar">مسح</span>.)</span> And one says, <span class="ar long">تبرّك بِٱسْمِ ٱللّٰهِ</span> <span class="add">[<em>He looked for a blessing by means of</em> uttering <em>the name of God,</em> or saying <span class="ar long">بِسْمِ ٱللّٰهِ</span>]</span>. <span class="auth">(Ksh, on the <span class="ar">بسملة</span>;, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brk_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبارك</span></h3>
				<div class="sense" id="brk_6_A1">
					<p><span class="ar">تبارك</span>, accord. to Zj, <a href="#fEl_6">is an instance of <span class="ar">تَفَاعَلَ</span></a> <span class="add">[<a href="#fEl_3">as quasi-pass. of <span class="ar">فَاعَلَ</span></a>, <a href="#brk_3">i. e., of <span class="ar">بَارَكَ</span></a>, <a href="#bEd_6">like as <span class="ar">تَبَاعَدَ</span></a> <a href="#bEd_3">is of <span class="ar">بَاعَدَ</span></a>,]</span> from <span class="ar">البَرَكَةُ</span>; and so say the lexicologists <span class="add">[in general]</span>. <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">تبارك ٱللّٰهُ</span> means <span class="add">[<em>Blessed is,</em> or <em>be, God;</em> or]</span> <em>hallowed is,</em> or <em>be, God;</em> or <em>far removed is,</em> or <em>be, He from every impurity</em> or <em>imperfection,</em> or <em>from everything derogatory from his glory;</em> <span class="auth">(Ḳ)</span> or <em>highly to be exalted,</em> or <em>extolled, is God; or highly exalted,</em> or <em>extolled, be He;</em> <span class="auth">(Abu-l-ʼAbbás, TA;)</span> <em>greatly to be magnified is God;</em> or <em>greatly magnified be He:</em> <span class="auth">(TA:)</span> or <em>i. q.</em><span class="arrow"><span class="ar">بَارَكَ↓</span></span>, like <span class="ar">قَاتَلَ</span> and <span class="ar">تَقاَتَلَ</span>, except that <span class="ar">فَاعَلَ</span> is trans. and <span class="ar">تَفَاَعَلَ</span> is intrans.: <span class="auth">(Ṣ:)</span> accord. to IAmb, it means <span class="add">[that]</span> one looks for a blessing by means of <span class="add">[uttering]</span> his name (<span class="ar long">يُتَبَرَّكُ بِٱسْمِهِ</span>) in every affair, or case: accord. to Lth, it is a phrase of glorification and magnification: <span class="auth">(TA:)</span> or <span class="ar">تبارك</span> signifies <em>He is abundant in good;</em> from <span class="ar">البَرَكَةُ</span>, which is “abundance of good:” or <em>He exceeds everything, and is exalted above it, in his attributes and his operations;</em> because <span class="ar">البَرَكَةُ</span> implies the meaning of increase, accession, or redundance: or <em>He is everlasting;</em> syn. <span class="ar">دَامَ</span>; from <span class="ar long">بُرُوكُ الطَّيْرِ عَلَى المَآءِ</span> <span class="add">[“the continuing of the birds at the water”]</span>; whence <span class="ar">البِرْكَةُ</span>, because of the continuance of the water therein: the verb is invariable <span class="add">[when thus used, being considered as divested of all signification of time, or used in an optative sense]</span>; and is not employed <span class="add">[in any of the senses above]</span> otherwise than in relation to God: <span class="auth">(Bḍ in xxv. 1:)</span> it is an attributive peculiar to God. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brk_6_A2">
					<p><span class="ar long">تبارك بِالشَّىْءِ</span>: <a href="#brk_5">see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brk_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابترك</span></h3>
				<div class="sense" id="brk_8_A1">
					<p><span class="ar">ابترك</span> <em>He</em> <span class="auth">(a man)</span> <em>threw his</em> <span class="ar">بَرْك</span> <span class="add">[i. e. <em>breast</em> upon the ground <span class="auth">(as the camel does in lying down)</span>, or upon some other thing]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brk_8_A2">
					<p><em>He</em> <span class="auth">(a sword-polisher)</span> <em>leaned upon the polishing-instrument,</em> <span class="auth">(Ḳ,)</span> <em>on one side.</em> <span class="auth">(TA.)</span> And <em>He</em> <span class="auth">(a horse)</span> <em>inclined on one side in his running.</em> <span class="auth">(TA: <span class="add">[accord. to which, this is from what next follows.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brk_8_A3">
					<p><em>He hastened,</em> or <em>sped, and strove, laboured,</em> or <em>exerted himself, in running:</em> <span class="auth">(Ṣ, Ḳ:)</span> and<span class="arrow"><span class="ar">بَرَكَ↓</span></span>, inf. n. <span class="ar">بُرُوكٌ</span>, <span class="auth">(Ḳ,)</span> or, as some say, this is a subst. from the former verb, <span class="auth">(TA,)</span> <em>He strove, laboured,</em> or <em>exerted himself.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brk_8_A4">
					<p>† <em>It</em> <span class="auth">(a cloud)</span> <em>rained continually,</em> or <em>incessantly:</em> <span class="auth">(TA:)</span> and <span class="ar long">ابتركت السَّمَآءُ</span> † <em>the sky rained continually;</em> as also<span class="arrow"><span class="ar">بَرَكَت↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">ابركت↓</span></span>; but Ṣgh says that the first of these three is the most correct. <span class="auth">(TA.)</span> And <span class="ar long">ابتركت السَّحَابَةُ</span> ‡ <em>The cloud rained vehemently.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="brk_8_A5">
					<p><span class="ar long">ابترك فِى عِرْضِهِ</span>, and <span class="ar">عَلَيْهِ</span>, ‡ <em>He detracted from his reputation, censured him,</em> or <em>impugned his character, and reviled him,</em> <span class="auth">(Ḳ, TA,)</span> <em>and laboured in vituperating him.</em> <span class="auth">(TA.)</span> <span class="ar long">ابتركوا فِى الحَرْبِ</span> ‡ <em>They fell upon their knees in battle, and so fought one another.</em> <span class="auth">(Ḳ, TA. <span class="add">[<a href="#barakaACu">See <span class="ar">بَرَكَآءُ</span>, below</a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brk_8_B1">
					<p><span class="ar">اِبْتَرَكْتُهُ</span> <em>I prostrated him,</em> or <em>threw him down prostrate, and put him beneath my</em> <span class="ar">بَرْك</span> <span class="add">[i. e. <em>breast</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barokN">
				<h3 class="entry"><span class="ar">بَرْكٌ</span></h3>
				<div class="sense" id="barokN_A1">
					<p><span class="ar">بَرْكٌ</span> <em>Many camels:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>a herd of camels lying down upon their breasts:</em> <span class="auth">(Ḳ:)</span> or <em>any camels, males and females, lying down upon their breasts by the water or in the desert by reason of the heat of the sun or by reason of satiety:</em> <span class="auth">(TA:)</span> <span class="pb" id="Page_0194"></span>or <em>all the camels of the people of an encampment, that return to them from pasture in the evening,</em> or <em>afternoon, to whatever number they may amount, even if they be thousands:</em> <span class="auth">(Ḳ:)</span> <em>one thereof</em> is termed <span class="arrow"><span class="ar">بَارِكٌ↓</span></span>; <span class="auth">(Ḳ;)</span> the two words being like <span class="ar">تَجْرٌ</span> and <span class="ar">تَاجِرٌ</span>; <span class="auth">(TA;)</span> fem. <span class="arrow"><span class="ar">بَارِكَةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> pl. <span class="ar">بُرُوكٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> i. e., <a href="#barokN">pl. of <span class="ar">بَرْكٌ</span></a>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بَرْكٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barokN_B1">
					<p>Also, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بِرْكَةٌ↓</span></span>, which is with kesr, <span class="auth">(Ṣ, Ḳ,)</span> The <em>breast</em> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> of a camel: <span class="auth">(Mṣb, TA:)</span> this is the primary signification: <span class="auth">(TA:)</span> as some say, the former signifies the <em>breast of the camel with which he crushes a thing beneath it:</em> <span class="auth">(TA:)</span> and <span class="auth">(Ḳ)</span> accord. to Lth, <span class="auth">(TA,)</span> the latter is the <em>part next to the ground of the skin of the breast of the camel;</em> <span class="auth">(or, as in the ʼEyn, <em>of the skin of the belly of the camel and of the portion of the breast next to it;</em> TA;)</span> as also the former: <span class="auth">(Ḳ:)</span> or, as some say, the former is the <em>middle of the breast, where</em> <span class="add">[<em>the two prominences of flesh called</em>]</span> <em>the</em> <span class="ar">فَهْدَتَانِ</span> <em>conjoin at their upper parts:</em> <span class="auth">(Ḥam p. 66:)</span> or <em>the latter is pl. of the former,</em> like as <span class="ar">حِلْيَةٌ</span> is of <span class="ar">حَلْىٌ</span>: or the former is <em>of man;</em> and the latter, <em>of others:</em> or the former is the <em>interior of the breast;</em> <span class="auth">(or, as Yaạḳoob says, the <em>middle of the breast;</em> TA;)</span> and the latter, the <em>exterior thereof:</em> <span class="auth">(Ḳ:)</span> or the former is the <em>breast,</em> primarily <em>of the camel,</em> because camels lie down (<span class="ar">تَبْرُكُ</span>) upon the breast; and metaphorically <em>of others.</em> <span class="auth">(Ḥam p. 145.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بَرْكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="barokN_B2">
					<p>Hence, <span class="ar long">بَرْك الشِّتَآءِ</span> ‡ <em>The first part of winter;</em> <span class="auth">(L, TA;*)</span> and <em>the main part thereof.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بَرْكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="barokN_B3">
					<p>And hence, <span class="auth">(TA,)</span> <span class="ar">البُرُوكُ</span> is an appellation applied to ‡ <em>The stars composing the constellation of the Scorpion,</em> of which are <span class="ar">الزُّبَانَى</span> and <span class="ar">الإِكْلِيلُ</span> and <span class="ar">القَلْبُ</span> and <span class="ar">الشَّوْلَةُ</span> <span class="add">[the 16th and 17th and 18th and 19th of the Mansions of the Moon]</span>, which rise <span class="add">[aurorally]</span> in the time of intense cold; as is also <span class="ar">الجُثُومُ</span>: <span class="auth">(L, TA:*)</span> or, accord. to IF, to <em>a</em> <span class="ar">نَوْء</span> <em>of the</em> <span class="ar">أَنْوَآء</span> <em>of</em> <span class="ar">الجَوْزَآء</span>; because the <span class="ar">انواء</span> thereof do not set <span class="add">[aurorally]</span> without there being during their period a day and a night in which the camels lie upon their breasts (<span class="ar">تَبْرُكُ</span>) by reason of the vehemence of the cold and rain. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burokN">
				<h3 class="entry"><span class="ar">بُرْكٌ</span></h3>
				<div class="sense" id="burokN_A1">
					<p><span class="ar">بُرْكٌ</span>: <a href="#burakN">see <span class="ar">بُرَكٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="birokN">
				<h3 class="entry"><span class="ar">بِرْكٌ</span></h3>
				<div class="sense" id="birokN_A1">
					<p><span class="ar">بِرْكٌ</span>: <a href="#birokapN">see <span class="ar">بِرْكَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burakN">
				<h3 class="entry"><span class="ar">بُرَكٌ</span></h3>
				<div class="sense" id="burakN_A1">
					<p><span class="ar">بُرَكٌ</span> <em>Remaining fixed</em> (<span class="arrow"><span class="ar">بَارِكٌ↓</span></span>) at, or by, a thing. <span class="auth">(IAạr, Ḳ.)</span> So in the phrase <span class="ar long">بُرَكُ عَلَى جَنْب الإِنَآءِ</span> <span class="add">[<em>Remaining fixed at,</em> or <em>by, the side of the vessel</em>]</span>, in a verse describing a <span class="add">[gluttonous]</span> man, who swallows closely-consecutive mouthfuls. <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بُرَكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="burakN_A2">
					<p>† <em>Incubus,</em> or <em>nightmare;</em> as also<span class="arrow"><span class="ar">بَارُوكٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بُرَكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="burakN_A3">
					<p>‡ <em>A coward;</em> and so<span class="arrow">↓</span> the latter word. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بُرَكٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="burakN_B1">
					<p>Also, <span class="add">[and by contraction <span class="arrow"><span class="ar">بُرْكٌ↓</span></span>, as in a verse cited in the M and TA in art. <span class="ar">وبص</span>,]</span> <em>A name of the month</em> <span class="ar long">ذُو الحِجَّة</span>; <span class="auth">(AA, Ḳ;)</span> <em>one of the ancient names of the months.</em> <span class="auth">(AA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burokapN">
				<h3 class="entry"><span class="ar">بُرْكَةٌ</span></h3>
				<div class="sense" id="burokapN_A1">
					<p><span class="ar">بُرْكَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or<span class="arrow"><span class="ar">بُرَكَةٌ↓</span></span>, <span class="auth">(Mṣb,)</span> <em>A certain aquatic bird, white,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>and small:</em> <span class="auth">(Ḳ:)</span> <span class="add">[the former applied in Barbary, in the present day, to <em>a duck:</em>]</span> pl. <span class="ar">بُرَكٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بُرْكَانٌ</span> and <span class="ar">بِرْكَانٌ</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">أَبْرَاكٌ</span>; <span class="auth">(Ḳ;)</span> or, in the opinion of ISd, <span class="ar">ابراك</span> and <span class="ar">بركان</span> are pls. of the pl. <span class="add">[<span class="ar">بُرَكٌ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="birokapN">
				<h3 class="entry"><span class="ar">بِرْكَةٌ</span></h3>
				<div class="sense" id="birokapN_A1">
					<p><span class="ar">بِرْكَةٌ</span> <em>A mode,</em> or <em>manner, of</em> <span class="ar">بُرُوك</span> <span class="add">[i. e. of a camel's <em>kneeling and lying down upon the breast</em>]</span>; <span class="auth">(Ṣ,* O,* Ḳ;)</span> a noun like <span class="ar">رِكْبَةٌ</span> and <span class="ar">جِلْسَةٌ</span>. <span class="auth">(Ṣ, O.)</span> One says, <span class="ar long">مَا أَحْسَنَ بِرْكَةَ هٰذِهِ النَّاقَةِ</span> <span class="add">[<em>How good is this she-camel's manner of lying down on the breast!</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بِرْكَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="birokapN_B1">
					<p><a href="#barokN">See also <span class="ar">بَرْكٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بِرْكَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="birokapN_C1">
					<p><em>A</em> <span class="ar">حَوْض</span> <span class="add">[i. e. <em>watering-trough</em> or <em>tank</em>]</span>: <span class="auth">(Ḳ:)</span> or the <em>like thereof,</em> <span class="auth">(Ṣ, TA,)</span> <em>dug in the ground, not having raised sides constructed for it above the surface of the ground;</em> <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بِرْكٌ↓</span></span> signifies the same: <span class="auth">(Lth, Ḳ:)</span> said to be so called because of the continuance of the water therein: <span class="auth">(Ṣ:)</span> pl. <span class="ar">بِرَكٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> which Az found to be applied by the Arabs to the <em>tanks,</em> or <em>cisterns, that are constructed with baked bricks, and plastered with lime, in the road to Mekkeh, and at its wateringplaces;</em> sing. <span class="ar">بِرْكَةٌ</span>; and sometimes a <span class="ar">بركة</span> is a thousand cubits <span class="add">[in length]</span>, and less, and more: but the watering-troughs, or tanks, that are made for the rain-water, and not cased with baked bricks, are called <span class="ar">أَصْنَاعٌ</span>, sing. <span class="ar">صِنْعٌ</span>: <span class="auth">(TA:)</span> <span class="add">[<span class="ar">بِرْكَةٌ</span> often signifies <em>a basin; a pool; a pond;</em> and <em>a lake:</em> and in the present day, also <em>a bay of the sea:</em> and <em>a reach of a river:</em>]</span> also <em>a place where water remains and collects,</em> or <em>collects and stagnates,</em> or <em>remains long and becomes altered.</em> <span class="auth">(ISd, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barakapN">
				<h3 class="entry"><span class="ar">بَرَكَةٌ</span></h3>
				<div class="sense" id="barakapN_A1">
					<p><span class="ar">بَرَكَةٌ</span> <span class="add">[<em>A blessing; any good that is bestowed by God;</em> and particularly <em>such as continues and increases and abounds:</em>]</span> <em>good,</em> <span class="auth">(Jel in xi. 50,)</span> <em>or prosperity,</em> or <em>good fortune,</em> <span class="auth">(Fr, Ḳ,)</span> <em>that proceeds from God:</em> <span class="auth">(Fr, in explanation of the pl. as used in the Ḳur xi. 76:)</span> <em>increase; accession; redundance; abundance,</em> or <em>plenty;</em> <span class="auth">(Ṣ, Mṣb, Ḳ, Kull;)</span> whether <em>sensible</em> or <em>intellectual:</em> and the <em>continuance of divinely-bestowed good, such as is perceived by the intellect, in,</em> or <em>upon, a thing:</em> <span class="auth">(Kull:)</span> or <em>firmness, stability,</em> or <em>continuance, coupled with increase:</em> <span class="auth">(Ḥam p. 587:)</span> or <em>increasing good:</em> <span class="auth">(Bḍ in xi. 50:)</span> and <em>abundance of good; implying the meaning of increase, accession,</em> or <em>redundance:</em> <span class="auth">(Bḍ in xxv. 1:)</span> or <em>abundant and continual good:</em> <span class="auth">(so in an Expos. of the Jámiʼ eṣ-Ṣagheer, cited in the margin of a copy of the MṢ:)</span> and, accord. to Az, God's <em>superiority over everything.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burakapN">
				<h3 class="entry"><span class="ar">بُرَكَةٌ</span></h3>
				<div class="sense" id="burakapN_A1">
					<p><span class="ar">بُرَكَةٌ</span>: <a href="#burokapN">see <span class="ar">بُرْكَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraAki">
				<h3 class="entry"><span class="ar">بَرَاكِ</span></h3>
				<div class="sense" id="baraAki_A1">
					<p><span class="ar long">بَرَاكِ بَرَاكِ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> like <span class="ar">قَطَامِ</span>, <span class="auth">(Ḳ,)</span> said in war, or battle, <span class="auth">(Ṣ,)</span> means <span class="ar">أُبْرُكُوا</span> <span class="add">[<em>Be ye firm, steady,</em> or <em>steadfast:</em> in the CK, erroneously, <span class="ar">اَبْرِكُوا</span>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baruwkN">
				<h3 class="entry"><span class="ar">بَرُوكٌ</span></h3>
				<div class="sense" id="baruwkN_A1">
					<p><span class="ar">بَرُوكٌ</span> A woman <em>that marries having a big son</em> <span class="auth">(Ṣ, Ḳ)</span> <em>of the age of puberty.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buruwkN">
				<h3 class="entry"><span class="ar">بُرُوكٌ</span></h3>
				<div class="sense" id="buruwkN_A1">
					<p><span class="ar">بُرُوكٌ</span> <em>A hasting, speeding, striving, labouring,</em> or <em>exerting oneself, in running;</em> <a href="#Abtrk">a subst. from <span class="ar">ابترك</span></a>: <a href="#brk_1">and inf. n. of <span class="ar">بَرَكَ</span></a> in a sense in which it is explained above with the former verb. <span class="auth">(Ḳ: but <a href="#brk_8">see 8</a>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bariykN">
				<h3 class="entry"><span class="ar">بَرِيكٌ</span></h3>
				<div class="sense" id="bariykN_A1">
					<p><span class="ar">بَرِيكٌ</span>: <a href="#mubaAraka">see <span class="ar">مُبَارَكَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraAkaMCu">
				<h3 class="entry"><span class="ar">بَرَاكَآءُ</span></h3>
				<div class="sense" id="baraAkaMCu_A1">
					<p><span class="ar">بَرَاكَآءُ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُرَاكَآءُ</span> <span class="auth">(TA)</span> <em>Firmness, steadiness,</em> or <em>steadfastness, in war,</em> or <em>battle;</em> <span class="auth">(IDrd, Ṣ;)</span> and <em>a striving, labouring,</em> or <em>exerting oneself</em> <span class="add">[<em>therein</em>]</span>; from <span class="ar">البُرُوكُ</span> <span class="add">[<a href="#brk_1">inf. n. of <span class="ar">بَرَكَ</span></a>]</span>: <span class="auth">(Ṣ:)</span> or <em>a falling upon the knees in battle, and so fighting;</em> as also<span class="arrow"><span class="ar">بَرُوكَآءُ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بَرَاكَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baraAkaMCu_A2">
					<p>Also The <em>field of battle:</em> or, accord. to Er-Rághib, <span class="ar long">برآكاءُ الحَرْبِ</span> and<span class="arrow"><span class="ar">بَرُوكَاؤُهَا↓</span></span> signify <em>the place to which the men of valour cleave.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baruwkaMCu">
				<h3 class="entry"><span class="ar">بَرُوكَآءُ</span></h3>
				<div class="sense" id="baruwkaMCu_A1">
					<p><span class="ar">بَرُوكَآءُ</span>: <a href="#baraAkaACu">see what next precedes</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brBakaAnN">
				<h3 class="entry"><span class="ar">برَّكَانٌ</span></h3>
				<div class="sense" id="brBakaAnN_A1">
					<p><span class="ar">برَّكَانٌ</span> and <span class="ar">بَرَّكَانِىٌّ</span> <span class="auth">(Fr, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَرْنَكَانٌ↓</span></span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> which is the form commonly obtaining, <span class="auth">(Mṣb,)</span> and mentioned by El-Ghooree as well as J, <span class="auth">(Mgh,)</span> but disallowed by Fr, <span class="auth">(Mgh, TA,)</span> and<span class="arrow"><span class="ar">بَرْنَكَانِىٌّ↓</span></span>, <span class="auth">(Ḳ,)</span> but this also is disallowed by Fr, <span class="auth">(Mgh, TA,)</span> or, accord. to IDrd, <span class="arrow"><span class="ar">بَرْنَكَآءُ↓</span></span> and<span class="arrow"><span class="ar long">كِسَآءٌ بَرْنَكانِىٌّ↓</span></span>, but he says that it is not Arabic, <span class="auth">(TA,)</span> <em>A kind of</em> <span class="add">[<em>garment such as is called</em>]</span> <span class="ar">كِسَآء</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> <span class="add">[<em>similar to a</em> <span class="ar">بُرْدَة</span>,]</span> <em>well-known;</em> <span class="auth">(Mṣb;)</span> the <em>black</em> <span class="ar">كسآء</span>; <span class="auth">(Fr, Mgh, Ḳ;)</span> <em>a woollen</em> <span class="ar">كسآء</span> <em>having two ornamental borders:</em> <span class="auth">(Fr, TA. in art. <span class="ar">برنك</span>:)</span> <span class="add">[in Spanish <em>barangane:</em> <span class="auth">(Golius:)</span>]</span> pl. <span class="add">[of all except the first two]</span> <span class="ar">بَرَانِكُ</span>. <span class="auth">(IDrd, Ḳ.)</span> <span class="ar">بَرَكَانٌ</span>, without teshdeed, is not mentioned by any one. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baronakaMCu">
				<h3 class="entry"><span class="ar">بَرْنَكَآءُ</span> / 
							<span class="ar">بَرْنَكَانٌ</span> / 
							<span class="ar">برْنَكَانِىٌّ</span></h3>
				<div class="sense" id="baronakaMCu_A1">
					<p><span class="ar">بَرْنَكَآءُ</span> and <span class="ar">بَرْنَكَانٌ</span> and <span class="ar">برْنَكَانِىٌّ</span>: <a href="#barBakaAnN">see <span class="ar">بَرَّكَانٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baArikN">
				<h3 class="entry"><span class="ar">بَارِكٌ</span> / <span class="ar">بَارِكَةٌ</span></h3>
				<div class="sense" id="baArikN_A1">
					<p><span class="ar">بَارِكٌ</span> and its fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَارِكَةٌ</span>}</span></add>: <a href="#barokN">see <span class="ar">بَرْكٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">بَارِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baArikN_A2">
					<p><a href="#burakN">and see <span class="ar">بُرَكٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwrakN">
				<h3 class="entry"><span class="ar">بُورَكٌ</span></h3>
				<div class="sense" id="buwrakN_A1">
					<p><span class="ar">بُورَكٌ</span> <em>i. q.</em> <span class="ar">بُورَقٌ</span>; <span class="auth">(Ḳ;)</span> <em>that is put into flour,</em> <span class="auth">(TA,)</span> or <em>into dough.</em> <span class="auth">(JK and Mgh and TA in explanation of the latter word.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwrik">
				<h3 class="entry"><span class="ar">بُورِك</span></h3>
				<div class="sense" id="buwrik_A1">
					<p><span class="ar">بُورِك</span>, as a noun: <a href="#brk_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAruwkN">
				<h3 class="entry"><span class="ar">بَارُوكٌ</span></h3>
				<div class="sense" id="baAruwkN_A1">
					<p><span class="ar">بَارُوكٌ</span>: <a href="#burakN">see <span class="ar">بُرَكٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maborakN">
				<h3 class="entry"><span class="ar">مَبْرَكٌ</span></h3>
				<div class="sense" id="maborakN_A1">
					<p><span class="ar">مَبْرَكٌ</span> <em>A place where camels lie upon their breasts:</em> pl. <span class="ar">مَبَارِكٌ</span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">فُلَانٌ لَيْسَ لَهُ مِبْرَكٌ جَمَلٍ</span> <span class="add">[<em>Such a one has not a place in which a camel lies;</em> meaning <em>he does not possess a single camel</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaArakN">
				<h3 class="entry"><span class="ar">مُبَارَكٌ</span></h3>
				<div class="sense" id="mubaArakN_A1">
					<p><span class="ar">مُبَارَكٌ</span> is originally <span class="ar long">مُبَارَكٌ فِيهِ</span> <span class="add">[or <span class="ar">لَهُ</span> or <span class="ar">عَلَيْهِ</span>, accord. to those who know not, or disallow, <span class="ar">بَارَكَ</span> as trans. without a preposition; and signifies <em>Blessed, beatified, felicitated,</em> or <em>prospered; gifted with,</em> or <em>made to possess,</em> <span class="ar">بَرَكة</span>, i. e. <em>a blessing, any good that is bestowed by God, prosperity</em> or <em>good fortune, increase,</em>, &amp;c.]</span>; <span class="auth">(Mṣb;)</span> <em>abounding in good;</em> <span class="auth">(Ksh and Bḍ in iii. 90;)</span> <em>abounding in advantage</em> or <em>utility:</em> <span class="auth">(Bḍ in vi. 92 and 156, and xxxviii. 28, and 1. 9:)</span> the pl. applied to irrational things is <span class="ar">مُبَارَكَاتٌ</span>. <span class="auth">(Mṣb.)</span> You say also<span class="arrow"><span class="ar">بَرِيكٌ↓</span></span> as meaning <span class="ar long">مُبَارَكَ فِيهِ</span>: <span class="auth">(Ḳ:)</span> or <span class="ar long">طَعَامٌ بَرِيكٌ</span> is as though meaning <span class="ar">مُبَارَكٌ</span> <span class="add">[i. e. <em>Blessed food;</em> or <em>food in which is a blessing,</em>, &amp;c.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotarikN">
				<h3 class="entry"><span class="ar">مُبْتَرِكٌ</span></h3>
				<div class="sense" id="mubotarikN_A1">
					<p><span class="ar">مُبْتَرِكٌ</span>, <span class="add">[in the CK <span class="ar">مُتَبَرِّكٌ</span>,]</span> applied to a man, ‡ <em>Leaning,</em> or <em>bearing, upon a thing; applying himself</em> <span class="add">[<em>thereto</em>]</span> <em>perseveringly, assiduously,</em> or <em>constantly.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برك</span> - Entry: <span class="ar">مُبْتَرِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubotarikN_A2">
					<p>Also, applied to a cloud, ‡ <em>Bearing down</em> <span class="add">[<em>upon the earth</em>]</span>, <em>and paring off the surface of the ground</em> <span class="add">[<em>by its vehement rain:</em> <a href="#brk_8">see 8</a>]</span>. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabaArikN">
				<span class="pb" id="Page_0195"></span>
				<h3 class="entry"><span class="ar">مُتَبَارِكٌ</span></h3>
				<div class="sense" id="mutabaArikN_A1">
					<p><span class="ar">مُتَبَارِكٌ</span> <span class="add">[app. applied to God <span class="auth">(see its verb)</span>]</span> <em>High,</em> or <em>exalted.</em> <span class="auth">(Th, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0193.pdf" target="pdf">
							<span>Lanes Lexicon Page 193</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0194.pdf" target="pdf">
							<span>Lanes Lexicon Page 194</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0195.pdf" target="pdf">
							<span>Lanes Lexicon Page 195</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
