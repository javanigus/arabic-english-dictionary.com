<article class="root" id="Root_brh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/085_brnk">برنك</a></span>
				<span class="ar">بره</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/087_brhn">برهن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brh_1">
				<h3 class="entry">1. ⇒ <span class="ar">بره</span></h3>
				<div class="sense" id="brh_1_A1">
					<p><span class="ar">بَرِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَهُ</span>}</span></add>, inf. n. <span class="ar">بَرَهٌ</span>, or, as in some copies of the Ḳ, <span class="ar">بَرَهَانٌ</span>, <span class="auth">(TA, <span class="add">[and so I find in an excellent copy of the Ḳ, but in the CK <span class="ar">بُرْهَان</span>,]</span>)</span> <em>His body returned to a healthy state,</em> or <em>his health of body returned to him,</em> or <em>his bodily condition became good, after having been altered by disease.</em> <span class="auth">(IAạr, Ḳ.*)</span> <span class="add">[The <span class="ar">ه</span> is perhaps a substitute for <span class="ar">ء</span>: <a href="#bariya">see <span class="ar">بَرِئَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بره</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brh_1_A2">
					<p>And <em>He was,</em> or <em>became, white in person,</em> or <em>body and members.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بره</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brh_1_A3">
					<p><a href="#barahN">See also <span class="ar">بَرَهٌ</span>, below</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brh_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابره</span></h3>
				<div class="sense" id="brh_4_A1">
					<p><span class="ar">ابره</span> <em>He adduced the evidence</em> or <em>proof:</em> <span class="auth">(Mṣb, Ḳ:)</span> but as to <span class="arrow"><span class="ar">بَرْهَنَ↓</span></span>, meaning <em>he manifested the evidence</em> or <em>proof,</em> it is said, on the authority of IAạr, to be post-classical; the former being the correct word: <span class="auth">(AA, T, Z, Mṣb, TA:)</span> or the former signifies <em>he adduced,</em> or <em>uttered,</em> or <em>did, wonderful things, and overcame men.</em> <span class="auth">(Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brh_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">بَرْهَنَ</span></h3>
				<div class="sense" id="brh_QQ1_A1">
					<p>Q. Q., or, as some say, Q., 1. <span class="ar">بَرْهَنَ</span>: <a href="#brh_4">see 4</a>; <a href="index.php?data=02_b/087_brhn">and see art. <span class="ar">برهن</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barahN">
				<h3 class="entry"><span class="ar">بَرَهٌ</span></h3>
				<div class="sense" id="barahN_A1">
					<p><span class="ar">بَرَهٌ</span> <span class="add">[perhaps an inf. n., of which the verb is <span class="arrow"><span class="ar">بَرِهَ↓</span></span>,]</span> <em>Softness, thinness of skin, and plumpness,</em> <span class="auth">(Ḳ, TA,)</span> of a woman; as also<span class="arrow"><span class="ar">بَرَهْرَهَةٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="barohapN">
				<h3 class="entry"><span class="ar">بَرْهَةٌ</span></h3>
				<div class="sense" id="barohapN_A1">
					<p><span class="ar">بَرْهَةٌ</span>: <a href="#burohapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burohapN">
				<h3 class="entry"><span class="ar">بُرْهَةٌ</span></h3>
				<div class="sense" id="burohapN_A1">
					<p><span class="ar">بُرْهَةٌ</span> and<span class="arrow"><span class="ar">بَرْهَةٌ↓</span></span> <em>A long space</em> or <em>period</em> of time: <span class="auth">(JK, Ṣ:)</span> or <em>a long time:</em> <span class="auth">(ISk, Ḳ:)</span> or they have a more general sense; <span class="auth">(Ḳ;)</span> i. e. <em>a space,</em> or <em>period,</em> of time: pl. of the former <span class="ar">بُرَهٌ</span> and <span class="ar">بُرْهَاتٌ</span> and <span class="ar">بُرَهَاتٌ</span> and <span class="ar">بُرَهَاتٌ</span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَتَتْ عَلَيْهِ بُرْهَةٌ مِنَ الدَّهْرِ</span> and <span class="ar">بَرْهَةٌ</span> <span class="add">[<em>A long space</em> or <em>period of time,</em> or merely <em>a space</em> or <em>period of time, passed over him</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burohaAnN">
				<h3 class="entry"><span class="ar">بُرْهَانٌ</span></h3>
				<div class="sense" id="burohaAnN_A1">
					<p><span class="ar">بُرْهَانٌ</span>: <a href="index.php?data=02_b/087_brhn">see art. <span class="ar">برهن</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barahorahapN">
				<h3 class="entry"><span class="ar">بَرَهْرَهَةٌ</span></h3>
				<div class="sense" id="barahorahapN_A1">
					<p><span class="ar">بَرَهْرَهَةٌ</span> A <em>white</em> <span class="auth">(IAạr, JK, Mṣb)</span> girl <span class="auth">(IAạr, Mṣb)</span> or female: <span class="auth">(JK:)</span> or a woman <span class="auth">(Ṣ, Ḳ,)</span> <em>white and youthful:</em> or <em>soft,</em> or <em>tender:</em> <span class="auth">(Ḳ:)</span> or <em>that quivers,</em> <span class="auth">(Ḳ,)</span> or <em>almost quivers,</em> <span class="auth">(Ṣ,)</span> <em>from sappiness, softness,</em> or <em>tenderness:</em> <span class="auth">(Ṣ,* Ḳ:)</span> or <em>that shines,</em> or <em>glistens, by reason of her clearness</em> <span class="add">[<em>of complexion</em>]</span>: or <em>thin-skinned; appearing as though water were running upon her, by reason of her softness,</em> or <em>tenderness:</em> <span class="auth">(TA:)</span> of the measure <span class="ar">فَعَلْعَلَةٌ</span>, <span class="auth">(Ṣ, TA,)</span> from <span class="ar">بَرَهٌ</span>: <span class="auth">(TA:)</span> dim. <span class="arrow"><span class="ar">بُرَيْهَةٌ↓</span></span> <span class="auth">(JK, TA)</span> and<span class="arrow"><span class="ar">بُرَيْرِهَةٌ↓</span></span>, <span class="auth">(JK,)</span> or<span class="arrow"><span class="ar">بُرَيْرِيهَةٌ↓</span></span>; but<span class="arrow"><span class="ar">بُرَيْهِرَهَةٌ↓</span></span> is bad, and seldom used. <span class="auth">(TA.)</span> Imra-el-Ḳeys says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَرَهْرَهَةٌ رُؤَدَةً رَخْصَةٌ</span> *</div> 
						<div class="star">* <span class="ar long">كَخُرْعُويَةِ البَانَةِ المُنْفَطِرْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>White,</em> or <em>white and youthful,</em>, &amp;c., <em>soft,</em> or <em>beautiful, tender, like the shoot of the ben-tree breaking forth with leaves:</em> the last word being made masc. by poetic license, for the sake of the metre.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بره</span> - Entry: <span class="ar">بَرَهْرَهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barahorahapN_A2">
					<p><span class="add">[Hence, app.,]</span> it is said to signify also <em>A white knife, of clear, pure,</em> or <em>bright, iron.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بره</span> - Entry: <span class="ar">بَرَهْرَهَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barahorahapN_B1">
					<p><a href="#barahN">See also <span class="ar">بَرَهٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burayohapN">
				<h3 class="entry"><span class="ar">بُرَيْهَةٌ</span> / <span class="ar">بُرَيْهِرَهَةٌ</span></h3>
				<div class="sense" id="burayohapN_A1">
					<p><span class="ar">بُرَيْهَةٌ</span> and <span class="ar">بُرَيْهِرَهَةٌ</span>: <a href="#barahorahapN">see <span class="ar">بَرَهْرَهَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burayorihapN">
				<h3 class="entry"><span class="ar">بُرَيْرِهَةٌ</span> / <span class="ar">بُرَيْرِيهَةٌ</span></h3>
				<div class="sense" id="burayorihapN_A1">
					<p><span class="ar">بُرَيْرِهَةٌ</span>, or <span class="ar">بُرَيْرِيهَةٌ</span>: <a href="#barahorahapN">see <span class="ar">بَرَهْرَهَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaborahu">
				<h3 class="entry"><span class="ar">أَبْرَهُ</span></h3>
				<div class="sense" id="Oaborahu_A1">
					<p><span class="ar">أَبْرَهُ</span> <span class="add">[app.]</span> <em>Having the body in a healthy state,</em> or <em>in good condition, after disease:</em> and <em>white in person,</em> or <em>body and members:</em> <span class="add">[but whether it have both these significations, or only the latter of them, is not clear:]</span> fem. <span class="ar">بَرْهَآءُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0196.pdf" target="pdf">
							<span>Lanes Lexicon Page 196</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
