<article class="root" id="Root_brj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/061_brvn">برثن</a></span>
				<span class="ar">برج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/063_brjm">برجم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brj_1">
				<h3 class="entry">1. ⇒ <span class="ar">برج</span></h3>
				<div class="sense" id="brj_1_A1">
					<p><span class="ar">بَرِجَ</span> <span class="add">[written in the TA without the vowel-signs, but the context seems to show that it is thus, and that the inf. n. is <span class="ar">بَرَجٌ</span>]</span> <em>It</em> <span class="auth">(anything)</span> <em>was,</em> or <em>became, apparent, manifest,</em> or <em>conspicuous,</em> and <em>high,</em> or <em>elevated:</em> whence <span class="ar">بُرْجٌ</span>, applied to a certain kind of structure. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brj_1_A2">
					<p><span class="ar">بَرِجَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَجُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَرَجٌ</span>, <span class="add">[also signifies]</span> <em>He had that quality of the eye which is termed</em> <span class="ar">بَرَجٌ</span>, explained below. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brj_1_A3">
					<p>Also, <span class="auth">(Ḳ,)</span> or <span class="ar long">بَرِجَ أَمْرُهُ</span>, <span class="auth">(TA,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَجُ</span>}</span></add>, <em>His state, condition,</em> or <em>case, became ample in respect of eating and drinking.</em> <span class="auth">(IAạr, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brj_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّج</span></h3>
				<div class="sense" id="brj_2_A1">
					<p><a href="#brj_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brj_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرج</span></h3>
				<div class="sense" id="brj_4_A1">
					<p><span class="ar">ابرج</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>built a</em> <span class="ar">بُرْج</span> <span class="add">[or <em>tower,</em>, &amp;c.]</span>; as also<span class="arrow"><span class="ar">برّج↓</span></span>, inf. n. <span class="ar">تَبْرِيجٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brj_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّج</span></h3>
				<div class="sense" id="brj_5_A1">
					<p><span class="ar">تَبَرَّجَتْ</span> <em>She</em> <span class="auth">(a woman)</span> <em>showed,</em> or <em>displayed, her finery,</em> or <em>ornaments,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>and beauties of person</em> or <em>form</em> or <em>countenance,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>to men,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>to strangers,</em> or <em>men distantly related to her;</em> <span class="auth">(Mṣb;)</span> to do which is culpable; but to do so to the husband is not: <span class="auth">(TA:)</span> or <em>she showed her face:</em> or <em>she showed the beauties of her neck and face:</em> or <em>she did so exhibiting a pretty look:</em> <span class="auth">(TA:)</span> or <em>she showed,</em> or <em>displayed, her finery,</em> or <em>ornaments, and what excites a man's lust.</em> <span class="auth">(A boo-Is-ḥáḳ, TA.)</span> Fr, referring to verse 33 of ch. xxxiii. of the Ḳur, says that in the time when Abraham was born, the women used to wear a shirt of pearls, not sewed at the two sides; or, as some say, they used to wear garments which did not conceal their persons. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burojN">
				<h3 class="entry"><span class="ar">بُرْجٌ</span></h3>
				<div class="sense" id="burojN_A1">
					<p><span class="ar">بُرْجٌ</span> <span class="add">[Gr. <span class="gr">πύργος</span>, <span class="auth">(Golius,)</span> <em>A tower;</em>]</span> <em>an angle,</em> syn. <span class="ar">رُكْن</span>, <span class="auth">(Ṣ, Ḳ,)</span> of a fortress, <span class="auth">(Ṣ,)</span> or of a city: <span class="auth">(TA:)</span> and sometimes <em>a fortress itself:</em> <span class="auth">(Ṣ, Ḳ:)</span> so called from its conspicuousness and construction and height: <span class="auth">(TA: <span class="add">[<a href="#brj_1">see 1</a>:]</span>)</span> or the primary signification of <span class="ar">برج</span> is <em>strength;</em> whence <span class="ar">أَبْرَجُ</span> in a sense explained below: <span class="auth">(Ḥar p. 286:)</span> pl. <span class="add">[of mult.]</span> <span class="ar">بُرُوجٌ</span> and <span class="add">[of pauc.]</span> <span class="ar">أَبْرَاجٌ</span>: <span class="auth">(Ṣ:)</span> the <span class="ar">بُرُوجٌ</span> of the wall of a city or fortress are <em>chambers</em> (<span class="ar">بُيُوت</span> <span class="add">[meaning <em>towers</em>]</span>) <em>built upon the wall:</em> and <em>such chambers</em> (<span class="ar">بيوت</span>) <em>built upon the sides of the angles of a</em> <span class="ar">قَصْر</span> <span class="add">[i. e. <em>pavilion</em> or <em>palace</em>, &amp;c.]</span> are sometimes thus called. <span class="auth">(Lth.)</span> <span class="add">[Hence,]</span> <span class="ar long">بُرْجُ حَمَامٍ</span> <span class="add">[<em>A pigeon-turret; a pigeon-house;</em> being generally constructed in the form of a turret, or of a sugar-loaf;]</span> <em>a lodging-place of pigeons:</em> pl. as above. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برج</span> - Entry: <span class="ar">بُرْجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="burojN_A2">
					<p>Also † <span class="add">[<em>A sign of the Zodiac;</em>]</span> <em>one of the</em> <span class="ar">بُرُوج</span> <em>of the heaven;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>which are twelve in number;</em> every one having a distinct name: <span class="auth">(TA:)</span> the Arabs in ancient times did not know them: <span class="auth">(Ḥam p. 560:)</span> pl. <span class="ar">أَبْرَاجٌ</span> as well as <span class="ar">بُرُوجٌ</span>: <span class="auth">(Mṣb, TA:)</span> these are meant by the <span class="ar">بُرُوج</span> mentioned in the Ḳur xv. 16 and xxv. 62 and lxxxv. 1: <span class="auth">(Bḍ, Jel:)</span> or in the last of these instances, <span class="auth">(Bḍ,)</span> by the <span class="ar">بروج</span> in the heaven are meant the <em>Mansions of the Moon:</em> <span class="auth">(Bḍ, Mṣb:)</span> or the <em>stars</em> or <em>asterisms</em> or <em>constellations:</em> <span class="auth">(TA:)</span> or the <em>great stars</em> or <em>asterisms</em> or <em>constellations;</em> <span class="auth">(Bḍ, Mṣb;)</span> and so, accord. to Zj, in the second of the said passages of the Ḳur: <span class="auth">(TA:)</span> or the <em>gates of heaven:</em> <span class="auth">(Bḍ, Mṣb:)</span> or, as some say, i. q. <span class="ar">قُصُور</span> <span class="add">[i. e. <em>pavilions</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barajN">
				<h3 class="entry"><span class="ar">بَرَجٌ</span></h3>
				<div class="sense" id="barajN_A1">
					<p><span class="ar">بَرَجٌ</span> <em>Such a constitution of the eye that the white entirely surrounds the black,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>no part of the black being concealed:</em> <span class="auth">(Ṣ, M:)</span> or <em>width of the eye:</em> or <em>width of the white of the eye, and largeness of the eyeball, and beauty of the black part:</em> or <em>clearness of the white and black parts theeeof:</em> <span class="auth">(M, TA:)</span> or <em>width of the eye, and largeness of the eyeball:</em> <span class="auth">(Ḥam p. 560:)</span> or <em>width of the eye with intense whiteness of the person:</em> <span class="auth">(TA:)</span> and <em>distance between the eyebrows.</em> <span class="auth">(L, TA.)</span> <span class="add">[<a href="#balajN">See also <span class="ar">بَلَجٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برج</span> - Entry: <span class="ar">بَرَجٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barajN_B1">
					<p><em>Goodly, elegant,</em> or <em>pretty; beautiful of face:</em> or <span class="add">[so in copies of the Ḳ, and in the TA, but in the CK “and”]</span> <em>shining,</em> or <em>splendid; conspicuous; and well known.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baArijN">
				<h3 class="entry"><span class="ar">بَارِجٌ</span></h3>
				<div class="sense" id="baArijN_A1">
					<p><span class="ar long">خُلُقٌ بَارِجٌ</span> <em>A large,</em> or <em>liberal, disposition;</em> syn. <span class="ar">وَاسِعٌ</span>. <span class="auth">(Ḥam p. 560.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboraAjN">
				<h3 class="entry"><span class="ar">أَبْرَاجٌ</span></h3>
				<div class="sense" id="OaboraAjN_A1">
					<p><span class="ar">أَبْرَاجٌ</span> A man <em>having that quality of the eye which is termed</em> <span class="ar">بَرَجٌ</span>: <span class="auth">(M, TA:)</span> fem. <span class="ar">بَرْجَآءُ</span>; applied to a woman; <span class="auth">(Ṣ)</span> and also to an eye (<span class="ar">عَيْنٌ</span>) <em>having the quality termed</em> <span class="ar">بَرَجٌ</span>: <span class="auth">(M, TA:)</span> pl. <span class="ar">بُرْجٌ</span>. <span class="auth">(Ḥam p. 560.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برج</span> - Entry: <span class="ar">أَبْرَاجٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaboraAjN_B1">
					<p><span class="ar long">هٰذَا أَبْرَجُ مِنْ هٰذَا</span> <em>This is stronger than this.</em> <span class="auth">(Ḥar p. 286.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboriyjN">
				<h3 class="entry"><span class="ar">إِبْرِيجٌ</span></h3>
				<div class="sense" id="IiboriyjN_A1">
					<p><span class="ar">إِبْرِيجٌ</span> The <em>vessel,</em> or <em>receptacle,</em> <span class="add">[generally <em>a skin,</em>]</span> <em>in which milk is churned,</em> or <em>beaten and agitated,</em> or <em>in which the butter of the milk is extracted,</em> or <em>fetched out, by putting water in it, and agitating it;</em> syn. <span class="ar">مِمْخَضَةٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubarBajN">
				<h3 class="entry"><span class="ar">مُبَرَّجٌ</span></h3>
				<div class="sense" id="mubarBajN_A1">
					<p><span class="ar long">ثَوْبٌ مُبَرَّجٌ</span> <em>A garment whereon are figures of</em> <span class="ar">بُرُوج</span> <span class="add">[or <em>towers</em>]</span>: <span class="auth">(Zj, TA:)</span> or <em>whereon are depicted figures resembling the</em> <span class="ar">بُرُوج</span> <span class="add">[or <em>towers</em>]</span> <em>of the wall of a city or the like:</em> <span class="auth">(T, A, TA:)</span> or <em>figured with eyes, of the garments termed</em> <span class="ar">حُلَلٌ</span>; from <span class="ar">البَرَجُ</span> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0180.pdf" target="pdf">
							<span>Lanes Lexicon Page 180</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
