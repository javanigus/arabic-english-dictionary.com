<article class="root" id="Root_bzx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/090_bz">بز</a></span>
				<span class="ar">بزخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/092_bzr">بزر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bzx_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزخ</span></h3>
				<div class="sense" id="bzx_1_A1">
					<p><span class="ar">بَزِخَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْزَخُ</span>}</span></add>, <span class="auth">(L,)</span> inf. n. <span class="ar">بَزَخٌ</span>, <span class="auth">(Ṣ, L, Ḳ,)</span> <em>He had a prominent breast and hollow back:</em> <span class="auth">(Ṣ, L, Ḳ:)</span> or <em>he had the lower part of his belly prominent, and the part between the hips,</em> or <em>haunches,</em> <span class="add">[<em>behind,</em>]</span> <em>hollow,</em> or <em>depressed:</em> or <em>he had the middle of his back hollow,</em> or <em>depressed, and the lower part of his belly prominent:</em> or <em>he had his back retiring from his belly:</em> or <em>he had his belly depressed, and the</em> <span class="ar">ثنَّة</span> <span class="add">[here app. meaning the <em>pubes</em>]</span>, <em>and the part next thereto, prominent:</em> <span class="auth">(L:)</span> <span class="ar">بَزَخٌ</span> is similar to <span class="ar">قَعَسٌ</span>: <span class="add">[<a href="#qaEisa">see <span class="ar">قَعِسَ</span></a>:]</span> <span class="auth">(A:)</span> and<span class="arrow"><span class="ar">انبزخ↓</span></span> signifies the same as <span class="ar">بَزِخَ</span>. <span class="auth">(IAạr, TA.)</span> The epithet applied to a man is <span class="arrow"><span class="ar">أَبْزَخُ↓</span></span>; and to a woman, <span class="ar">بَزْخَآءُ</span>. <span class="auth">(Ṣ, A, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzx_1_A2">
					<p>Also, inf. n. as above, <em>He</em> <span class="auth">(a horse)</span> <span class="add">[<em>was saddle-backed;</em> i. e.,]</span> <em>had a hollow back, and prominent croup and withers.</em> <span class="auth">(ISd, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzx_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبازخ</span></h3>
				<div class="sense" id="bzx_6_A1">
					<p><span class="ar">تبازخ</span> <em>He walked,</em> or <em>sat, in the manner of him who is termed</em> <span class="ar">أَبْزَخ</span>. <span class="auth">(L.)</span> And <span class="ar">تبازخت</span> <em>She</em> <span class="auth">(a woman)</span> <em>made her posteriors to stick out:</em> <span class="auth">(Ṣ:)</span> or <em>she had prominent posteriors:</em> <span class="auth">(Ḳ:)</span> or <em>she</em> <span class="auth">(an old woman, in walking,)</span> <em>erected her backbone, and made the part between her shoulders to recede, and bent the part above it, next her neck:</em> <span class="auth">(L:)</span> or <em>she had her posteriors prominent, and the upper part of her back, next the neck, bent.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزخ</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzx_6_A2">
					<p><em>He</em> <span class="auth">(a horse)</span> <em>bent his hoof towards his belly, because of the shortness of his neck, at the time of drinking.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزخ</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bzx_6_A3">
					<p><span class="ar long">تبازخ عَنِ الأَمْرِ</span> ‡ <em>He drew back, held back,</em> or <em>hung back, from the thing,</em> or <em>affair; would not go forward in it.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzx_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبزخ</span></h3>
				<div class="sense" id="bzx_7_A1">
					<p><a href="#bzx_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabozaxu">
				<h3 class="entry"><span class="ar">أَبْزَخُ</span></h3>
				<div class="sense" id="Oabozaxu_A1">
					<p><span class="ar">أَبْزَخُ</span> A man <em>having a prominent breast and hollow back:</em>, &amp;c.: (<a href="#bzx_1">see 1</a>:) fem. <span class="ar">بَزْخَآءُ</span>. <span class="auth">(Ṣ, A, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزخ</span> - Entry: <span class="ar">أَبْزَخُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabozaxu_A2">
					<p>A horse <em>having a depressed croup and backbone:</em> <span class="auth">(Ṣ:)</span> or <span class="add">[<em>saddle-backed;</em> i. e.]</span> <em>having a hollow back, and prominent croup and withers.</em> <span class="auth">(ISd, L.)</span> It is applied to a horse such as is termed <span class="ar">بِرْذَوْنٌ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزخ</span> - Entry: <span class="ar">أَبْزَخُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabozaxu_A3">
					<p>And the fem., A she-camel <em>having a plain,</em> or <em>even, croup,</em> or <em>rump.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabaAzixFA">
				<h3 class="entry"><span class="ar">مُتَبَازِخًا</span></h3>
				<div class="sense" id="mutabaAzixFA_A1">
					<p><span class="ar long">مَشَى مُتَبَازِخًا</span> <em>He</em> <span class="auth">(a man)</span> <em>walked like an old woman affecting,</em> or <em>constraining herself, to erect her backbone, so that the part between her shoulders recedes:</em> <span class="auth">(A:)</span> or, <em>like an old woman having her posteriors prominent, and the upper part of her back, next the neck, bent.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0199.pdf" target="pdf">
							<span>Lanes Lexicon Page 199</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
