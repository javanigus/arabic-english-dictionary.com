<article class="root" id="Root_bhrj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/202_bhr">بهر</a></span>
				<span class="ar">بهرج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/204_bhZ">بهظ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhrj_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بهرج</span></h3>
				<div class="sense" id="bhrj_Q1_A1">
					<p><span class="ar">بُهْرِجَ</span>, in the pass. form, <span class="auth">(Ḳṭ, Mṣb,)</span> inf. n. <span class="ar">بَهْرَجَةٌ</span>, <span class="auth">(Ḳ,)</span> † <em>It</em> <span class="auth">(a thing)</span> <em>was taken otherwise than by,</em> or <em>in, the right way:</em> <span class="auth">(Mṣb:)</span> or ‡ <em>it was turned away,</em> or <em>conveyed by turning away,</em> <span class="auth">(Ḳṭ, Ḳ, TA,)</span> <em>from the beaten way</em> or <em>road,</em> <span class="auth">(Ḳṭ, TA,)</span> or <em>from the direct,</em> or <em>right, main road.</em> <span class="auth">(Ḳ, TA.)</span> And <span class="ar long">بَهْرَجَ بِهِمْ</span> ‡ <em>It</em> <span class="auth">(the road, A)</span> <em>lead them otherwise than in the beaten track.</em> <span class="auth">(T, A, TA.)</span> <span class="add">[<a href="#bahorajN">See <span class="ar">بَهْرَجٌ</span></a>, from which the verb is derived.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهرج</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhrj_Q1_A2">
					<p>‡ <em>It</em> <span class="auth">(a man's blood)</span> <em>was made to be of no account, to go for nothing, unretaliated,</em> or <em>uncompensated by a mulct; was made allowable to be taken</em> or <em>shed.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">بَهْرَجَ دَمَهُ</span> ‡ <em>He made his blood to be of no account,</em>, &amp;c. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهرج</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bhrj_Q1_A3">
					<p>Hence, <span class="auth">(TA,)</span> <span class="ar long">أَمَا إِذْ بَهْرَجْتَنِى فَلَا أَشْرَبُهَا أَبَدًا</span> <span class="auth">(Ḳ,* TA)</span> ‡ <em>Verily, since thou hast made me</em> <span class="add">[meaning my offence]</span> <em>to pass unnoticed,</em> or hast <em>taken no account of me,</em> (<span class="ar">هَدَرْتَنِى</span>,) by annulling in respect of me the prescribed castigation, <span class="auth">(Ḳ, TA,)</span> <em>I will not drink it</em> <span class="auth">(i. e. wine)</span> <em>henceforth:</em> <span class="auth">(TA:)</span> said by Aboo-Mihjen <span class="auth">(Ḳ, TA)</span> Eth-Tha- kafee, <span class="auth">(TA,)</span> to Ibn-Abee-Wakkás. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهرج</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bhrj_Q1_A4">
					<p>You say also, <span class="ar long">بَهْرَجَ المَكَانِ</span> † <em>He made the place free to the people in general to pasture their beasts in it.</em> <span class="auth">(IAạr, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhrj_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبهرج</span></h3>
				<div class="sense" id="bhrj_Q2_A1">
					<p><span class="ar">تَبَهْرَجَ</span> <em>It</em> <span class="auth">(a place)</span> <em>became,</em> or <em>was made, free to the people in general to pasture their beasts in it.</em> <span class="auth">(IAạr, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahorajN">
				<h3 class="entry"><span class="ar">بَهْرَجٌ</span></h3>
				<div class="sense" id="bahorajN_A1">
					<p><span class="ar">بَهْرَجٌ</span> an arabicized word, <span class="auth">(T, Ṣ, Mgh, L, TA,)</span> from <span class="ar">نَبَهْرَهْ</span>, <span class="auth">(T, Mgh, L, TA,)</span> which is Persian; <span class="auth">(L, TA;)</span> or, as some say, it is an Indian word, originally <span class="ar">نَبَهْلَهْ</span>, meaning <em>Bad,</em> whence the Persian <span class="ar">نَبَهْرَهْ</span>, and hence the arabicized <span class="ar">بَهْرَجٌ</span>; <span class="auth">(TA;)</span> applied to a dirhem, as meaning <em>bad;</em> <span class="auth">(Kr, Ṣ;)</span> <em>false;</em> <span class="auth">(Ṣ, El-Marzookee;)</span> <em>adulterated;</em> <span class="auth">(Shifá el-Ghaleel, El-Marzookee;)</span> <em>of bad silver;</em> <span class="auth">(A, Mgh, L, Mṣb;)</span> <em>with which one cannot buy:</em> <span class="auth">(IAạr, TA:)</span> or, as some say, <em>in which the silver is predominant:</em> or, accord. to IAạr, <em>of which the die has been falsified:</em> <span class="auth">(Mgh:)</span> or <em>not coined in the government-mint:</em> <span class="auth">(Lb, TA:)</span> and<span class="arrow"><span class="ar">مُبْهَرَجٌ↓</span></span> signifies the same, applied to a dirhem; <span class="auth">(Lḥ, A, Mgh;)</span> and so<span class="arrow"><span class="ar">نَبَهْرَجٌ↓</span></span>; <span class="auth">(Lḥ, El-Marzookee;)</span> but <span class="add">[Mṭr says,]</span> I have not found it with <span class="ar">ن</span>, except on the authority of Lḥ <span class="auth">(Mgh;)</span> and IKh says that it is a word of the vulgar: <span class="auth">(TA:)</span> the pl. <span class="add">[of <span class="ar">بهرج</span>]</span> is <span class="ar">بَهَارِجُ</span>, and <span class="add">[of <span class="ar">نبهرج</span>,]</span> <span class="ar">نَبَهْرَجَاتُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهرج</span> - Entry: <span class="ar">بَهْرَجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahorajN_A2">
					<p>Hence, metaphorically, <span class="auth">(Mgh,)</span> ‡ <em>Bad;</em> <span class="auth">(Ṣ, A, Mgh, L, Mṣb, Ḳ;)</span> and <em>false,</em> or <em>of no account;</em> <span class="auth">(Ṣ, A, Mgh, Ḳ;)</span> applied to a thing <span class="auth">(Ṣ, A, Mgh, L, Mṣb)</span> of any kind: <span class="auth">(A, Mgh, L:)</span> anything <em>rejected; not received</em> or <em>accepted; rejected as wrong</em> or <em>bad;</em> as also<span class="arrow"><span class="ar">نَبَهْرَجٌ↓</span></span>: <span class="auth">(TA:)</span> and a thing is termed <span class="arrow"><span class="ar">مُبَهْرَجٌ↓</span></span> when it is <em>as though it were cast away, and not an object of emulous desire</em> or <em>envy,</em> or <em>not in request.</em> <span class="auth">(El-Marzookee, TA.)</span> You say, <span class="ar long">كَلَامٌ بَهْرَجٌ</span> ‡ <em>Bad language.</em> <span class="auth">(A, L.)</span> And <span class="ar long">عَمَلٌ بَهْرَجٌ</span> ‡ <em>A bad action.</em> <span class="auth">(A, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهرج</span> - Entry: <span class="ar">بَهْرَجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bahorajN_A3">
					<p>† <em>Allowed</em> or <em>allowable</em> <span class="add">[<em>to any person, to be taken</em> or <em>let alone,</em> or <em>to be possessed</em> or <em>made use of</em> or <em>done</em>]</span>; <em>made allowable, free,</em> or <em>lawful.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">دَمٌ بَهْرَجٌ</span> ‡ <em>Blood made to be of no account, to go for nothing, unretaliated,</em> or <em>uncompensated by a mulct; allowed to be taken</em> or <em>shed;</em> <span class="auth">(A, L;)</span> as also<span class="arrow"><span class="ar">مُبَهْرَجٌ↓</span></span>. <span class="auth">(Ḳ.)</span> And <span class="ar long">مَكَانٌ بَهْرَجٌ</span> † <em>A place free to the people in general to pasture their beasts in it.</em> <span class="auth">(IAạr, L.)</span> And<span class="arrow"><span class="ar long">مَآءٌ مُبَهْرَجٌ↓</span></span> † <em>A water left free to those who come to water at it.</em> <span class="auth">(A, Ḳ,* TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubahorajN">
				<span class="pb" id="Page_0267"></span>
				<h3 class="entry"><span class="ar">مُبَهْرَجٌ</span></h3>
				<div class="sense" id="mubahorajN_A1">
					<p><span class="ar">مُبَهْرَجٌ</span>: <a href="#bahorajN">see <span class="ar">بَهْرَجٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="nabahorajN">
				<h3 class="entry"><span class="ar">نَبَهْرَجٌ</span></h3>
				<div class="sense" id="nabahorajN_A1">
					<p><span class="ar">نَبَهْرَجٌ</span>: <a href="#bahorajN">see <span class="ar">بَهْرَجٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0266.pdf" target="pdf">
							<span>Lanes Lexicon Page 266</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0267.pdf" target="pdf">
							<span>Lanes Lexicon Page 267</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
