<article class="root" id="Root_byD">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/234_byS">بيص</a></span>
				<span class="ar">بيض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/236_byE">بيع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="byD_1">
				<h3 class="entry">1. ⇒ <span class="ar">بيض</span> ⇒ <span class="ar">باض</span></h3>
				<div class="sense" id="byD_1_A1">
					<p><span class="ar">بَاضَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> first pers. <span class="ar">بِضْتُ</span>, <span class="auth">(M,)</span> aor. <span class="ar">يَبِيضُ</span>, for which one should not say <span class="ar">يَبُوضُ</span>, <span class="add">[though it would be agreeable with a general rule respecting verbs denoting surpassingness,]</span> <span class="auth">(Ṣ, O,)</span> <em>He surpassed him in whiteness.</em> <span class="auth">(Ṣ, M, O, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byD_1_B1">
					<p><span class="ar">بَاضَتْ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ, except that in the M and Mṣb we find the masc. form, <span class="ar">بَاضَ</span>, followed by <span class="ar">الطَّائِرُ</span>,)</span> aor. <span class="ar">تَبِيضُ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَيْضٌ</span>, <span class="auth">(M, Mṣb,)</span> said of an ostrich, <span class="auth">(M,)</span> or a hen, <span class="auth">(Ḳ,)</span> or any bird, <span class="auth">(Ṣ, M, Mṣb,)</span> and the like, <span class="auth">(Mṣb,)</span> <em>She laid her eggs,</em> <span class="auth">(M, Mṣb, TA,)</span> or <em>egg.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="byD_1_B2">
					<p><span class="ar long">بَاضَ السَّحَابُ</span> ‡ <em>The clouds rained.</em> <span class="auth">(IAạr, O, Ḳ.)</span> A poet says, <span class="add">[using a phrase from which this application of the verb probably originated,]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَاضَ النَّعَامُ بِهِ فَنَفَّرَ أَهْلَهُ</span> *</div> 
						<div class="star">* <span class="ar long">إِلَّا المُقِيمَ عَلَى الدَّوَى المُتَأَفِّنِ</span> *</div> 
					</blockquote>
					<p><span class="auth">(IAạr,)</span> i. e. ‡ <em>The</em> <span class="ar">نعام</span>, meaning the <span class="ar">نَعَائِم</span>, <span class="add">[or Twentieth Mansion of the Moon,]</span> <em>sent down rain upon it, and so put to flight its occupants, except him who remained incurring the risk of</em> dying from <em>disease, wasting away:</em> <span class="add">[the last word being in the gen. case, by poetic license, because the next before it is in that case; like <span class="ar">خَرِبٍ</span> in the phrase <span class="ar long">هٰذَا جُحْرُ ضَبٍّ خَرِبٍ</span>:]</span> the poet is describing a valley rained upon and in consequence producing herbage; for the rain of the asterism called <span class="ar">النعائم</span> is in the hot season, <span class="add">[when that asterism sets aurorally, (<a href="#manaAzilu">see <span class="ar long">مَنَازِلُ القَمَرِ</span></a>, <a href="index.php?data=25_n/110_nzl">in art. <span class="ar">نزل</span></a>,)]</span> whereupon there grows, at the roots of the <span class="ar">حَلِىّ</span>, a plant called <span class="ar">نَشْر</span>, which is poisonous, killing beasts that eat of it: the verse is explained as above by El-Mohellebee: <span class="auth">(IB:)</span> or, as IAạr says, the poet means rain that falls at the <span class="ar">نَوْء</span> <span class="add">[by which we are here to understand the setting aurorally]</span> of <span class="ar">النعائم</span>; and that when this rain falls, the wise flees and the stupid remains. <span class="auth">(O.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="byD_1_B3">
					<p><span class="ar long">بَاضَ بِالمَكَانِ</span> ‡ <em>He remained, stayed,</em> or <em>abode, in the place</em> <span class="add">[like as a bird does in the place where she lays her eggs]</span>. <span class="auth">(O, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="byD_1_B4">
					<p><span class="ar long">بَاضَتِ الأَرْضُ</span> † <em>The earth produced</em> <span class="ar">كَمْأَة</span> <span class="add">[or <em>truffles,</em> which are thus likened to eggs]</span>: <span class="auth">(A, TA:)</span> or † <em>the earth produced the plants that it contained:</em> or † <em>it became changed in its greenness to yellowness, and scattered the fruit,</em> or <em>produce, and dried up.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="byD_1_B5">
					<p><span class="ar long">بَاضَ الحَرُّ</span> ‡ <em>The heat became vehement,</em> or <em>intense.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="byD_1_C1">
					<p><span class="ar long">بَاضَ القَوْمَ</span>;, &amp;c.: <a href="#byD_8">see 8</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byD_2">
				<h3 class="entry">2. ⇒ <span class="ar">بيّض</span></h3>
				<div class="sense" id="byD_2_A1">
					<p><span class="ar">بيّض</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَبْيِضٌ</span>, <span class="auth">(Ṣ,)</span> <em>He whitened</em> a thing; <em>made</em> it <em>white;</em> <span class="auth">(Ṣ, M;)</span> <em>contr. of</em> <span class="ar">سَوَّدَ</span>. <span class="auth">(Ḳ.)</span> <em>He bleached</em> clothes. <span class="auth">(M.)</span> <span class="add">[<em>He whitewashed</em> a wall, &amp;c. <em>He tinned</em> a copper vessel or the like.]</span> You say, <span class="ar long">بَيَّضَ ٱللّٰهُ وَجْهَهُ</span> <span class="add">[lit., <em>God whitened his face:</em> or <em>may God whiten his face:</em> meaning ‡ <em>God rendered his face expressive of joy,</em> or <em>cheerfulness;</em> or <em>rejoiced,</em> or <em>cheered, him:</em> or <em>may God</em>, &amp;c.: and also <em>God cleared his character;</em> or <em>manifested his honesty,</em> or <em>the like:</em> or <em>may God</em>, &amp;c.: see the contr. <span class="ar">سَوَّدَ</span>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بيّض لَهُ</span> <span class="add">[<em>He left a blank space for it;</em> namely, a word or sentence or the like: probably post-classical]</span>. <span class="auth">(TA in art. <span class="ar">شمس</span>;, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byD_2_A2">
					<p><span class="add">[<em>He wrote out fairly,</em> after having made a first rough draught: in this sense, also, opposed to <span class="ar">سَوَّدَ</span>: probably post-classical.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="byD_2_A3">
					<p>‡ <em>He filled</em> a vessel: <span class="auth">(M, A, Ḳ:*)</span> or <em>he filled</em> a vessel, and a skin, <em>with water</em> and <em>milk.</em> <span class="auth">(Ṣ, O.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="byD_2_A4">
					<p>And ‡ <em>He emptied</em> <span class="auth">(A, Ḳ)</span> a vessel: <span class="auth">(A:)</span> thus it bears two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byD_3">
				<h3 class="entry">3. ⇒ <span class="ar">بايض</span></h3>
				<div class="sense" id="byD_3_A1">
					<p><span class="ar">بايضهُ</span>, <span class="auth">(Ṣ, M,)</span> inf. n. <span class="ar">مُبَايَضَةٌ</span>, <span class="auth">(TA,)</span> <em>He contended with him for superiority in whiteness.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byD_3_A2">
					<p><span class="ar long">بَايَضَنِى فُلَانٌ</span> ‡ <em>Such a one acted openly with me;</em> syn. <span class="ar">جَاهَرَنِى</span>: from<span class="arrow"><span class="ar long">بَيَاضُ↓ النَّهَارِ</span></span> <span class="add">[the whiteness of day, or daylight]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byD_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابيض</span> ⇒ <span class="ar">اباض</span></h3>
				<div class="sense" id="byD_4_A1">
					<p><span class="ar">أَبْيَضَتْ</span> and <span class="ar">أَبَاضَتْ</span><em>She</em> <span class="auth">(a woman)</span> <em>brought forth white children:</em> and in like manner one says of a man <span class="add">[<span class="ar">أَبْيَضَ</span> and <span class="ar">أَبَاضَ</span>, meaning <em>He begat white children</em>]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byD_4_A2">
					<p><a href="#byD_9">See also 9</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byD_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتيض</span> ⇒ <span class="ar">ابتاض</span></h3>
				<div class="sense" id="byD_8_A1">
					<p><span class="ar">ابتاض</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>put upon himself a</em> <span class="ar">بَيْضَة</span> <span class="add">[or <em>helmet</em>]</span> <span class="auth">(Ṣ, Ḳ, TA)</span> <em>of iron.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byD_8_B1">
					<p><span class="ar">ابتاضهُمْ</span> <em>He entered into their</em> <span class="ar">بَيْضَة</span> <span class="add">[or <em>territory,</em>, &amp;c.]</span>: <span class="auth">(A, TA:)</span> and <span class="ar long">ابتاضوا القَوْمَ</span> <em>They exterminated the people,</em> or <em>company of men; they extirpated them;</em> <span class="auth">(M, Ḳ;*)</span> as also<span class="arrow"><span class="ar">بَاضُوهُمْ↓</span></span>: <span class="auth">(M:)</span> and <span class="ar">اُبْتِيضُوا</span> <span class="add">[originally <span class="ar">اُبْتُيِضُوا</span>; in the CK, incorrectly, <span class="ar">ابتَيَضُوا</span>;]</span> <em>They were exterminated,</em> or <em>extirpated,</em> <span class="auth">(Ḳ, TA,)</span> <em>and their</em> <span class="ar">بَيْضَة</span> <span class="add">[or <em>quarter,</em>, &amp;c.,]</span> <em>was given up to be plundered:</em> <span class="auth">(TA:)</span> and <span class="ar">اِبْتَضْنَاهُمْ</span> <em>We smote their</em> <span class="ar">بيضة</span> <span class="add">[or <em>collective body,</em>, &amp;c.,]</span> <em>and took all that belonged to them by force;</em> as also<span class="arrow"><span class="ar">بِضْنَاهُمْ↓</span></span>: and<span class="arrow"><span class="ar long">بِيضَ↓ الحَىُّ</span></span> <em>The tribe was so smitten</em>, &amp;c. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byD_9">
				<h3 class="entry">9. ⇒ <span class="ar">ابيضّ</span></h3>
				<div class="sense" id="byD_9_A1">
					<p><span class="ar">ابيضّ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> and, by poetic license, <span class="ar">اِبْيَضَضَّ</span>, <span class="add">[<a href="#xafaDa">of which see an ex. voce <span class="ar">خَفَضَ</span></a>, <a href="#Hw_9">and see also 9</a> <a href="index.php?data=06_H/206_Hw">in art. <span class="ar">حو</span></a>,]</span> <span class="auth">(M, TA,)</span> inf. n. <span class="ar">اِبْيِضَاضٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>It was,</em> or <em>became, white;</em> <span class="auth">(Ṣ, M, Mṣb;)</span> <em>contr. of</em> <span class="ar">اِسْوَدَّ</span>; <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">ابياضّ↓</span></span>, inf. n. <span class="ar">اِبْيِيضَاضٌ</span>;. <span class="auth">(Ṣ;)</span> <em>contr. of</em> <span class="ar">اِسْوَادَّ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">أَبَاضَ↓</span></span>: which<span class="arrow">↓</span> last also signifies <em>it</em> <span class="auth">(herbage or pasture)</span> <em>became white, and dried up.</em> <span class="auth">(M, TA.)</span> <span class="add">[You say also, <span class="ar long">ابيضّ وَجْهُهُ</span>, lit., <em>His face became white:</em> meaning ‡ <em>his face became expressive of joy,</em> or <em>cheerfulness;</em> or <em>he became joyful,</em> or <em>cheerful:</em> and also <em>his character became cleared;</em> or <em>his honesty,</em> or <em>the like, became manifested:</em> <a href="#byD_2">see 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="byD_11">
				<h3 class="entry">11. ⇒ <span class="ar">ابياضّ</span></h3>
				<div class="sense" id="byD_11_A1">
					<p><a href="#byD_9">see 9</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayoDN">
				<h3 class="entry"><span class="ar">بَيْضٌ</span></h3>
				<div class="sense" id="bayoDN_A1">
					<p><span class="ar">بَيْضٌ</span>: <a href="#baYoDapN">see <span class="ar">بَيْضَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoDapN">
				<h3 class="entry"><span class="ar">بَيْضَةٌ</span></h3>
				<div class="sense" id="bayoDapN_A1">
					<p><span class="ar">بَيْضَةٌ</span> <em>An egg</em> <span class="auth">(Mṣb)</span> of an ostrich, <span class="auth">(Mgh,)</span> and of any bird, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> and the like, i. e. of anything that is termed <span class="ar">صَمُوخٌ</span> <span class="add">[or having merely an ear-hole]</span> as distinguished from such as is termed <span class="ar">أَذُونٌ</span> <span class="add">[or having an ear that is called <span class="ar">أُذُنٌ</span>]</span>: so called because of its whiteness: <span class="auth">(TA:)</span> n. un. of <span class="arrow"><span class="ar">بَيْضٌ↓</span></span>: <span class="auth">(Ṣ, M,* Mṣb, Ḳ:)</span> pl. <span class="add">[of the former]</span> <span class="ar">بَيْضَاتٌ</span> <span class="auth">(M, Ṣgh, Ḳ)</span> and <span class="ar">بَيَضَاتٌ</span>, which latter is irreg., <span class="auth">(M, Ṣgh,)</span> and only used by poetic license; <span class="auth">(Ṣgh;)</span> and <span class="auth">(of <span class="ar">بَيْضٌ</span>, M)</span> <span class="ar">بُيُوضٌ</span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">أَفْرَخَتِ البَيْضَةُ</span> <em>The egg had in it a young bird.</em> <span class="auth">(ISh.)</span> And <span class="ar long">أَفْرَخَ بَيْضَةُ القَوْمِ</span> † <em>What was hidden, of the affair,</em> or <em>case, of the people,</em> or <em>company of men, became apparent.</em> <span class="auth">(ISh.)</span> <span class="add">[<a href="index.php?data=20_f/072_frx">See also art. <span class="ar">فرخ</span></a>.]</span> <span class="ar long">بَيْضَةُ البَلَدِ</span> signifies <em>The egg which the ostrich abandons.</em> <span class="auth">(Ṣ, M, Ḳ.)</span> And hence the saying, <span class="ar long">هُوَ أَذَلُّ مِنْ بَيْضَةِ البَلَدِ</span> ‡ <em>He is more abject,</em> or <em>vile, than the egg of the ostrich which it abandons</em> <span class="auth">(Ṣ, A,* Ḳ)</span> <em>in the desert.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">هُوَ بَيْضَةُ البَلَدِ</span> in dispraise and in praise. <span class="auth">(IAạr, Aboo-Bekr, M.)</span> When said in dispraise, it means ‡ <em>He is like the egg of the ostrich from which the young bird has come forth, and which the male ostrich has cast away, so that men and camels tread upon it:</em> <span class="auth">(IAạr, M:)</span> or <em>he is alone, without any to aid him; like the egg from which the male ostrich has arisen, and which he has abandoned as useless:</em> <span class="auth">(TA:)</span> or <em>he is an obscure man,</em> or <em>one of no reputation, whose lineage is unknown.</em> <span class="auth">(Ḥam p. 250.)</span> And when said in praise, it means ‡ <em>He is like the ostrich's egg in which is the young bird;</em> because the male ostrich in that case protects it: <span class="auth">(IAạr, M:)</span> or <em>he is unequalled in nobility;</em> like the egg that is left alone: <span class="auth">(M:)</span> or <em>he is a lord,</em> or <em>chief:</em> <span class="auth">(IAạr, M:)</span> or <em>he is the unequalled of the</em> <span class="ar">بَلَد</span> <span class="add">[or <em>country</em> or <em>the like</em>]</span>, <em>to whom others resort, and whose words they accept:</em> <span class="auth">(Ḳ:)</span> or <em>he is a celebrated,</em> or <em>wellknown, person.</em> <span class="auth">(Ḥam p. 250.)</span> <span class="add">[<a href="index.php?data=02_b/171_bld">See also art. <span class="ar">بلد</span></a>. And for another meaning of <span class="ar long">بَيْضَةُ البَلَدِ</span> see below.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoDapN_A2">
					<p>‡ <em>A helmet of iron,</em> <span class="auth">(AO, Ṣ,* M,* Mgh,* Ḳ,*)</span> <em>which is composed of plates like the bones of the skull, the edges whereof are joined together by nails; and sometimes of one piece:</em> <span class="auth">(AO:)</span> so called because resembling in shape the egg of an ostrich: <span class="auth">(AO, M, Mgh:*)</span> in this sense, also, n. un. of <span class="arrow"><span class="ar">بَيْضٌ↓</span></span>. <span class="auth">(Ṣ, Ḳ: <span class="add">[in the CK, for <span class="ar">والحَدِيدُ</span> we should read <span class="ar">والحَدِيدِ</span>.]</span>)</span> This may be meant in a trad. in which it is said that a man's hand is to be cut off for his stealing a <span class="ar">بَيْضَة</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayoDapN_A3">
					<p>† <em>A testicle:</em> <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">بِيضَانٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bayoDapN_A4">
					<p>‡ The <em>bulb</em> of the saffron-plant <span class="add">[&amp;c.]</span>: as resembling an egg in shape. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bayoDapN_A5">
					<p>† <span class="add">[<em>A tuber:</em> for the same reason.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bayoDapN_A6">
					<p>† <em>A kind of grape of Et-Táïf, white and large.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bayoDapN_A7">
					<p>‡ The <em>core</em> of a boil: as resembling an egg. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bayoDapN_A8">
					<p>‡ The <em>fat</em> of a camel's hump: for the same reason. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bayoDapN_A9">
					<p><span class="ar long">بَيْضَةُ البَلَدِ</span>, in addition to its meanings mentioned above, also signifies † <em>The white truffle:</em> <span class="auth">(O, Ḳ:)</span> or simply <em>truffles;</em> syn. <span class="ar">الكَمْأَةُ</span>; <span class="auth">(TA;)</span> or these are called<span class="arrow"><span class="ar long">بَيْضُ↓ الأَرْضِ</span></span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bayoDapN_A10">
					<p><span class="ar">بَيْضَةٌ</span> also signifies ‡ The <em>continent,</em> or <em>container,</em> or <em>receptacle,</em> (<span class="ar">حَوْزَة</span>,) of anything. <span class="auth">(Ṣ, Ḳ, TA.)</span> And <span class="add">[hence]</span> <span class="ar long">بَيْضَةُ الإِسْلَامِ</span> ‡ <em>The place</em> <span class="add">[or <em>territory</em>]</span> <em>which comprises El-Islám</em> <span class="add">[meaning <em>the Muslims</em>]</span>; like as the egg comprises the young bird: <span class="auth">(Mgh:)</span> or this signifies <em>the congregation,</em> or <em>collective body, of the Muslims.</em> <span class="auth">(AZ, M.)</span> <span class="pb" id="Page_0283"></span>And <span class="ar long">بَيْضَةُ القَوْمِ</span> ‡ <em>The quarter, tract, region,</em> or <em>district, of the people,</em> or <em>company of men:</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>the heart;</em> or <em>midst,</em> or <em>main part, of the abode thereof:</em> <span class="auth">(Ṣ, TA:)</span> <em>the principal place of abode</em> (<span class="ar">أَصْل</span>) <em>thereof;</em> <span class="auth">(M, TA;)</span> <em>the place that comprises them; the place of their government,</em> or <em>regal dominion;</em> and <em>the seat of their</em> <span class="ar">دعوة</span> <span class="add">[i. e. <span class="ar">دِعْوَة</span> or <em>kindred and brotherhood</em>]</span>: <span class="auth">(TA:)</span> <em>the midst of them:</em> <span class="auth">(M:)</span> or, as some say, <em>their</em> <span class="add">[<em>kinsfolk such as are termed</em>]</span> <span class="ar">عَشِيرَة</span>: <span class="auth">(TA:)</span> but when you say, <span class="ar long">أَتَاهُمُ العَدُوُّ فِى بَيْضَتِهِمْ</span>, the meaning is <span class="add">[<em>the enemy came to them in</em>]</span> <em>their principal place of abode</em> (<span class="ar">أَصْل</span>), and <em>the place where they were congregated.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَيْضَةُ الدَّارِ</span> ‡ <em>The midst of the country</em> or <em>place of abode</em> or <em>the like:</em> <span class="auth">(AZ, M, TA:)</span> <em>the main part thereof.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَيْضَةُ المُلْكِ</span> <em>i. q.</em> <span class="ar">حَوْزَتُهُ</span> † <span class="add">[<em>The seat of regal power: or the heart,</em> or <em>principal part, of the kingdom</em>]</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">حوز</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="bayoDapN_A11">
					<p><span class="ar long">بَيْضَةُ الخِدْرِ</span> <span class="auth">(M, A, Ḳ)</span> ‡ <em>The damsel</em> <span class="auth">(M, Ḳ)</span> <em>of the</em> <span class="ar">خدر</span> <span class="add">[or <em>curtain</em>, &amp;c.]</span>: <span class="auth">(Ḳ: <span class="add">[in the CK, <span class="ar">جَارِيَتُهَا</span> is erroneously put for <span class="ar">جَارِيَتُهُ</span>:]</span>)</span> because she is kept concealed within it. <span class="auth">(TA.)</span> You say also, <span class="ar long">هِىَ مِنْ بَيْضَاتِ الحِجَالِ</span> ‡ <span class="add">[<em>She is of the damsels of the curtained bridal canopies</em>]</span>. <span class="auth">(A, TA.)</span> <span class="ar">بَيْضَةٌ</span> is used by a metonymy to signify ‡ <em>A woman,</em> by way of likening her thereto <span class="add">[i. e. to an egg]</span> in colour, and in respect of her being protected as beneath the wing. <span class="auth">(B.)</span> <span class="add">[See Ḳur xxxvii. 47.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="bayoDapN_A12">
					<p><span class="ar">بَيْضَةٌ</span> also signifies † <em>White land, in which is no herbage;</em> opposed to <span class="ar">سَوْدَةٌ</span>: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">بِيضَةٌ↓</span></span>, with kesr, <em>white, smooth land;</em> <span class="auth">(Ḳ;)</span> thus accord. to IAạr, with kesr to the <span class="ar">ب</span>: <span class="auth">(Sh:)</span> and<span class="arrow"><span class="ar long">أَرْضٌ بَيْضَآءُ↓</span></span> signifies <em>smooth land, in which is no herbage;</em> as though herbage blackened land: or <em>untrodden land:</em> as also <span class="ar">بَيْضَةٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="bayoDapN_A13">
					<p><span class="ar long">بَيْضَةُ النَّهَارِ</span> <em>The whiteness of day;</em> <span class="add">[<em>daylight;</em>]</span> <em>i. q.</em><span class="arrow"><span class="ar">بَيَاضُهُ↓</span></span>; <span class="auth">(Ḳ;)</span> i. e. <em>its light.</em> <span class="auth">(Ḥar p. 222.)</span> You say, <span class="ar long">أَتَيْتُهُ فِى بَيْضَةِ النَّهَارِ</span> <em>I came to him in the whiteness of day.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيْضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="bayoDapN_A14">
					<p><span class="ar long">بَيْضَةُ الحِرِّ</span> † <em>The vehemence,</em> or <em>intenseness, of heat.</em> <span class="auth">(M.)</span> And <span class="ar long">بَيْضَةُ القَيْظِ</span> ‡ <em>The most vehement,</em> or <em>intense, heat of summer,</em> or <em>of the hottest period of summer, from the</em> <span class="add">[<em>auroral</em>]</span> <em>rising of</em> <span class="ar">الدَّبَرَان</span> <em>to that of</em> <span class="ar">سُهَيْل</span>; <span class="add">[i. e., reckoning for the commencement of the era of the Flight, in central Arabia, <em>from about the 26th of May to about the 4th of August, O. Ṣ.;</em>]</span> <span class="auth">(A,* TA;)</span> as also<span class="arrow"><span class="ar long">بَيْضَآءُ↓ القَيْظِ</span></span>. <span class="auth">(A, TA.)</span> And <span class="ar long">بَيْضَةُ الصَّيْفِ</span> † <em>The main part of the</em> <span class="ar">صيف</span> <span class="add">[or <em>summer</em>]</span>: <span class="auth">(M, TA:)</span> or <em>the vehement,</em> or <em>intense, heat thereof.</em> <span class="auth">(Ḥam p. 250.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayDapN">
				<h3 class="entry"><span class="ar">بَيضَةٌ</span></h3>
				<div class="sense" id="bayDapN_A1">
					<p><span class="ar">بَيضَةٌ</span>: <a href="#baYoDapN">see <span class="ar">بَيْضَةٌ</span></a>, in the latter part of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayaADN">
				<h3 class="entry"><span class="ar">بَيَاضٌ</span></h3>
				<div class="sense" id="bayaADN_A1">
					<p><span class="ar">بَيَاضٌ</span> <em>Whiteness; contr. of</em> <span class="ar">سَوَادٌ</span>; in an animal, and in a plant, and in other things; and, accord. to IAạr, in water also; <span class="auth">(M;)</span> the colour of that which is termed <span class="ar">أَبْيَضُ</span>: <span class="auth">(Ṣ, Mṣb,* Ḳ:)</span> they said <span class="ar">بَيَاضٌ</span> and<span class="arrow"><span class="ar">بَيَاضَةٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> like as they said <span class="ar">مَنْزِلٌ</span> and <span class="ar">مَنْزِلَةٌ</span>: <span class="auth">(Ṣ:)</span> <span class="ar">بَيَاضَةٌ</span> being applied to <em>a whiteness</em> in the eye. <span class="auth">(M.)</span> You say, <span class="ar long">هٰذَا أَشَدُّ بَيَاضًا مِنْ كَذَا</span> <span class="add">[<em>This is whiter than such a thing</em>]</span>: <span class="auth">(Ṣ, Ḳ:*)</span> but not <span class="arrow"><span class="ar long">أَبْيَضُ منْهُ↓</span></span>: <span class="auth">(Ṣ:)</span> the latter is anomalous; <span class="auth">(Ḳ;)</span> <span class="add">[like <span class="ar long">أَسْوَدُ مِنْهُ</span>; q. v.;]</span> but it was said by the people of El-Koofeh, <span class="auth">(Ṣ, Ḳ,)</span> who adduced as authority the saying of the rájiz,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">جَارِيَةٌ فِى دِرْعِهَا الفَضْفَاضِ</span> *</div> 
						<div class="star">* <span class="ar long">أَبْيَضُ مِنْ أُخْتِ بَنِى إِبَاضِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>A damsel in her ample shift, whiter than the sister of</em> the tribe of <em>Benoo-Ibád</em>]</span>: Mbr, however, says that an anomalous verse is no evidence against a rule commonly approved: and as to the saying of another,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَا الرِّجَالُ شَتَوْا وَٱشْتَدَّ أَكْلُهُمُ</span> *</div> 
						<div class="star">* <span class="ar long">فَأَنْتَ أَبْيَضُهُمْ سِرْبَالَ طَبَّاخِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When men experience dearth in winter, and their eating becomes vehement, thou art the whitest of them,</em> or rather <em>the white of them, in respect of cook's clothing,</em> having little or nothing to do with entertaining them]</span>, the word in question may be considered as an epithet of the measure <span class="ar">أَفْعَلُ</span> that is followed by <span class="ar">مِنْ</span> to denote excess: but it is only like the instances in the sayings <span class="ar long">هُوَ أَحْسَنُهُمْ وَجْهًا</span> and <span class="ar long">أَكْرَمُهُمْ أَبًا</span>, meaning <span class="ar long">حَسَنُهُمْ وَجْهًا</span> and <span class="ar long">كَرِيِمُهُمْ أَبًا</span>; so it is as though he said <span class="ar long">فَأَنْتَ مُبْيَضُّهُمْ سِرْبَالًا</span>; and as he has prefixed it to a complement which it governs in the gen. case, what follows is in the accus. case as a specificative. <span class="auth">(Ṣ.)</span> This latter verse is by Tarafeh, who satirizes therein ʼAmr Ibn-Hind; and is also differently related in respect of the first hemistich, and the first word of the second. <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayaADN_A2">
					<p><span class="ar long">بَيَاضُ النَّهَارِ</span>: <a href="#byD_3">see 3</a>; <a href="#baYoDapN">and see <span class="ar">بَيْضَةٌ</span></a>, near the end of the paragraph.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayaADN_A3">
					<p><span class="ar">بَيَاضٌ</span> is also used elliptically for <span class="ar long">ذُو بَيَاضٍ</span>; and thus means † <em>White clothing;</em> as in the saying, <span class="ar long">فُلَانٌ يَلْبَسُ السَّوَادَ وَالبَيَاضَ</span> <em>Such a one wears black and white clothing.</em> <span class="auth">(Mgh.)</span> <span class="add">[Hence, also, it has other significations, here following.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bayaADN_A4">
					<p>† <em>Milk.</em> <span class="auth">(Ḳ.)</span> See an ex., voce <span class="ar">سَوَادٌ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bayaADN_A5">
					<p><span class="add">[† The <em>white</em> of an egg.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bayaADN_A6">
					<p><span class="ar long">بَيَاضُ الأَرْضِ</span> † <em>That part of land wherein is no cultivation nor population and the like.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bayaADN_A7">
					<p><span class="ar long">بَيَاضُ الجِلْدِ</span> † <em>That part of the skin upon which is no hair.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bayaADN_A8">
					<p>‡ <span class="ar">بَيَاضٌ</span> also signifies ‡ A man's <em>person;</em> like <span class="ar">سَوَادٌ</span>; syn. <span class="ar">شَخْصٌ</span>; as in the saying, <span class="ar long">لَا يُزَايِلُ سَوَادِى بَيَاضَكَ</span> ‡ <em>My person will not separate itself from thy person.</em> <span class="auth">(Aṣ, A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayuwDN">
				<h3 class="entry"><span class="ar">بَيُوضٌ</span></h3>
				<div class="sense" id="bayuwDN_A1">
					<p><span class="ar">بَيُوضٌ</span> A hen <em>that lays many eggs;</em> <span class="auth">(Ṣ, M, A,* Ḳ;*)</span> as also<span class="arrow"><span class="ar">بَيَّاضَةٌ↓</span></span>: <span class="auth">(M:)</span> <span class="add">[but in the Mṣb it is evidently used as signifying simply <em>oviparous:</em>]</span> pl. <span class="auth">(of the former, Ṣ, M *)</span> <span class="ar">بُيُضٌ</span> <span class="auth">(Ṣ, M, A, Ḳ)</span> and <span class="ar">بِيضٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> the latter in the dial. of those who say <span class="ar">رُسْلٌ</span> for <span class="ar">رُسُلٌ</span>, the <span class="ar">ب</span> being with kesr in order that the <span class="ar">ى</span> may remain unchanged; <span class="auth">(Ṣ, M;)</span> but sometimes they said <span class="ar">بُوضٌ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayaADapN">
				<h3 class="entry"><span class="ar">بَيَاضَةٌ</span></h3>
				<div class="sense" id="bayaADapN_A1">
					<p><span class="ar">بَيَاضَةٌ</span>: <a href="#bayaADN">see <span class="ar">بَيَاضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYiDN">
				<h3 class="entry"><span class="ar">بَائِضٌ</span></h3>
				<div class="sense" id="baAYiDN_A1">
					<p><span class="ar">بَائِضٌ</span> A hen, <span class="auth">(Az, Ḳ,)</span> or bird, <span class="auth">(Ṣ, Mṣb,)</span> and the like, <span class="auth">(Mṣb,)</span> <em>laying an egg</em> or <em>eggs:</em> <span class="auth">(Az, Ṣ,* Mṣb, Ḳ:*)</span> without <span class="ar">ة</span> because the cock does not lay eggs: <span class="auth">(Az, TA:)</span> or it is applied also to a cock, <span class="auth">(M, TA,)</span> and to a crow, <span class="auth">(M, A, TA,)</span> <span class="add">[as meaning <em>begetting an egg</em> or <em>eggs,</em>]</span> in like manner as one uses the word <span class="ar">وَالِدٌ</span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBaADN">
				<h3 class="entry"><span class="ar">بَيَّاضٌ</span></h3>
				<div class="sense" id="bayBaADN_A1">
					<p><span class="ar">بَيَّاضٌ</span> <em>A bleacher of clothes;</em> as a kind of rel. n.; not as a verbal epithet; for were it this, it would be <span class="ar">مُبَيِّضٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَّاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayBaADN_A2">
					<p><em>A seller of eggs.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">بَيَّاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayBaADN_A3">
					<p><span class="ar">بَيَّاضَةٌ</span>: <a href="#bayuwDN">see <span class="ar">بَيُوضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboyaDu">
				<h3 class="entry"><span class="ar">أَبْيَضُ</span></h3>
				<div class="sense" id="OaboyaDu_A1">
					<p><span class="ar">أَبْيَضُ</span> <em>White; contr. of</em> <span class="ar">أَسْوَدُ</span>; <span class="auth">(A, Ḳ;)</span> <em>having whiteness:</em> <span class="auth">(Mṣb:)</span> fem. <span class="ar">بَيْضَآءُ</span>: <span class="auth">(Mṣb:)</span> pl. <span class="ar">بِيضٌ</span>, originally <span class="ar">بُيْضٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> the damm being converted into kesr in order that the <span class="ar">ى</span> may remain unchanged, <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[i. e.]</span> to suit the <span class="ar">ى</span>. <span class="auth">(Mṣb.)</span> In the phrase <span class="ar long">أَعْطِنِى أَبْيَضَّهْ</span>, mentioned by Sb, as used by some of the Arabs, meaning <span class="ar">أَبْيَضَ</span>, <span class="add">[i. e. <em>Give thou to me a white one,</em>]</span> <span class="ar">ه</span> is subjoined as it is in <span class="ar">هُنَّهْ</span> for <span class="ar">هُنَّ</span>, and the <span class="ar">ض</span> is doubled because the letter of declinability cannot have <span class="ar">ه</span> subjoined to it; wherefore the letter of declinability is the first <span class="ar">ض</span>, and the second is the augmentative, and for this reason it has subjoined to it the <span class="ar">ه</span> whereof the purpose is to render plainly perceivable the vowel <span class="add">[which is necessarily added after the doubled <span class="ar">ض</span>]</span>: Aboo-ʼAlee says, <span class="add">[app. of the <span class="ar">ه</span>,]</span> that it should properly have neither fet-ḥ nor any vowel. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboyaDu_A2">
					<p>Applied to a man, &amp;c., it was sometimes used to signify <em>White in complexion:</em> but in this sense they generally used the epithet <span class="ar">أَحْمَرُ</span>. <span class="auth">(IAth, TA in art. <span class="ar">حمر</span>.)</span> They also said, <span class="ar long">فُلَانٌ أَبْيَضُ الوَجْهِ</span> and <span class="ar long">فُلَانَةُ بَيْضَآءُ الوَجْهِ</span>, meaning <em>Such a man,</em> and <em>such a woman, is clear, in face, from freckles or the like, and unseemly blackness.</em> <span class="auth">(Az, TA.)</span> And they used <span class="ar">بِيضَانٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <a href="#OaboyaDu">a pl. of <span class="ar">أَبْيَضُ</span></a>, <span class="auth">(TA,)</span> in the contr. of the sense of <span class="ar">سُودَانٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[i. e. as signifying <em>Whites,</em>]</span> applied to men: <span class="auth">(Ṣ:)</span> though they applied the appellation <span class="ar long">أَبُو البَيْضَآءِ</span> to <em>the Abyssinian:</em> <span class="auth">(TA in art. <span class="ar">عور</span>:)</span> or to <em>the negro:</em> and <span class="ar long">أَبُو الجَوْنِ</span> to the white man. <span class="auth">(ISk.)</span> But accord. to Th, <span class="ar">أَبْيَضُ</span> applied to a man signifies only ‡ <em>Pure; free from faults:</em> <span class="auth">(IAth, TA in art. <span class="ar">حمر</span>:)</span> or, so applied, <em>unsullied in honour, nobility,</em> or <em>estimation;</em> <span class="auth">(Az, Ḳ;)</span> <em>free from faults;</em> and <em>generous:</em> and so <span class="ar">بَيْضَآءُ</span> applied to a woman. <span class="auth">(Az.)</span> <span class="add">[In the lexicons, however, <span class="auth">(see, for ex., among countless other instances, an explanation of <span class="ar">بَضَّةٌ</span> in the Ṣ,)</span> and in other post-classical works, it is generally used, when thus applied, in its proper sense, of <em>White;</em> or <em>fair in complexion.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaboyaDu_A3">
					<p><span class="ar long">كَتِيبَةٌ بَيْضَآءُ</span> <em>An army,</em> or <em>a portion thereof, upon which the whiteness of the</em> <span class="add">[<em>arms or armour of</em>]</span> <em>iron is apparent.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaboyaDu_A4">
					<p>And <span class="ar">بَيْضَآءُ</span> alone, <span class="add">[as a subst.,]</span> <em>A piece of paper</em> <span class="add">[<em>without writing</em>]</span>. <span class="auth">(Ḥar p. 311.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaboyaDu_A5">
					<p><span class="ar">الأَبْيَضُ</span> <em>The sword:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> because of its whiteness: <span class="auth">(TA:)</span> pl. <span class="ar">بِيضٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaboyaDu_A6">
					<p><em>Silver:</em> <span class="auth">(A, Ḳ:)</span> because of its whiteness: like as gold is called <span class="ar">الأَحْمَرُ</span> <span class="add">[because of its redness]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaboyaDu_A7">
					<p><em>The saliva</em> (<span class="ar">رضاب</span>) <em>of the mouth.</em> <span class="auth">(Ḥam p. 348.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaboyaDu_A8">
					<p><em>A certain star in the margin of the milky way.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaboyaDu_A9">
					<p><span class="ar">البَيْضَآءُ</span> <em>The sun:</em> because of its whiteness. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="OaboyaDu_A10">
					<p><em>Waste,</em> or <em>uncultivated,</em> or <em>uninhabited, land:</em> <span class="auth">(Ḳ,* TA: <span class="add">[in the CK <span class="ar">الجِرابُ</span> is erroneously put for <span class="ar">الخَرَابُ</span>:]</span>)</span> opposed to <span class="ar">السَّوْدَآءُ</span>: because dead lands are white; and when planted, become black and green. <span class="auth">(TA.)</span> <a href="#baYoDapN">See also <span class="ar">بَيْضَةٌ</span></a>, near the end.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="OaboyaDu_A11">
					<p><em>Wheat:</em> <span class="auth">(Ḳ:)</span> as also <span class="ar">السَّمْرَآءُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="OaboyaDu_A12">
					<p><em>Fresh</em> <span class="add">[<em>grain of the kind called</em>]</span> <span class="ar">سُلْت</span>. <span class="auth">(El-Khaṭṭábee, Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0284"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="OaboyaDu_A13">
					<p><em>A certain kind of wood; that which is called</em> <span class="ar">الحَوَرُ</span>: <span class="auth">(Ḳ in art. <span class="ar">حور</span>:)</span> because of its whiteness. <span class="auth">(TA in that art.)</span> <span class="add">[<a href="#HawarN">See <span class="ar">حَوَرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="OaboyaDu_A14">
					<p><em>The cooking-pot;</em> as also <span class="ar long">أُمُّ بَيْضَآءَ</span>. <span class="auth">(AA, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="OaboyaDu_A15">
					<p><em>The snare with which one catches game.</em> <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="OaboyaDu_A16">
					<p><span class="ar">الأَبْيَضَانِ</span> <em>Milk and water.</em> <span class="auth">(ISk, Ṣ, M, A, Ḳ.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمَا لِىَ إِلَّا الأَبْيَضَيْنِ شَرَابُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And I have not any beverage except milk and water</em>]</span>. <span class="auth">(ISk, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A17</span>
				</div>
				<div class="sense" id="OaboyaDu_A17">
					<p><em>Bread and water:</em> <span class="auth">(Aṣ, M, Ḳ:)</span> or <em>wheat and water:</em> <span class="auth">(Fr, Ḳ:)</span> or <em>fat and milk.</em> <span class="auth">(AO, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A18</span>
				</div>
				<div class="sense" id="OaboyaDu_A18">
					<p><em>Fat and youthfulness</em> <span class="auth">(AZ, IAạr, M, A, Ḳ.)</span> You say, <span class="ar long">ذَهَبَ أَبْيَضَاهُ</span> <em>His fat and youthfulness departed.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A19</span>
				</div>
				<div class="sense" id="OaboyaDu_A19">
					<p><span class="ar long">مَا رَأَيْتُهُ مُذْ أَبْيَضَانِ</span> <em>I have not seen him for,</em> or <em>during, two days:</em> <span class="auth">(Ks, M, A, Ḳ:)</span> or <em>two months.</em> <span class="auth">(Ks, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A20</span>
				</div>
				<div class="sense" id="OaboyaDu_A20">
					<p><span class="ar long">أَيَّامُ البِيضِ</span>, <span class="auth">(Mṣb, Ḳ,)</span> or simply <span class="ar">البِيضُ</span>, <span class="auth">(Mgh,)</span> for <span class="ar long">أَيَّامُ اللَّيَالِى البِيضِ</span>; <span class="add">[<em>The days of the white nights;</em>]</span> i. e. <em>the days of the thirteenth and fourteenth and fifteenth nights of the month;</em> <span class="auth">(Mgh, Mṣb, Ḳ;)</span> so called because they are lighted by the moon throughout: <span class="auth">(Mṣb:)</span> or <em>of the twelfth and thirteenth and fourteenth nights:</em> <span class="auth">(Ḳ:)</span> but this is of weak authority, and extr.: the former is the correct explanation: <span class="auth">(MF, TA:)</span> you should not say <span class="ar long">الأَيَّامُ البِيضُ</span>: <span class="auth">(Ibn-El-Jawá- leekee, IB, Ḳ:)</span> yet thus it is in most relations of a trad. in which it occurs; and some argue for it; and the author of the Ḳ has himself explained <span class="ar">الأَوَاضِحُ</span> by <span class="ar long">الأَيَّامُ البِيضُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A21</span>
				</div>
				<div class="sense" id="OaboyaDu_A21">
					<p><span class="ar long">سَنَةٌ بَيْضَآءُ</span> † <em>A year</em> <span class="add">[<em>of scarcity of herbage,</em>]</span> <em>such as is a mean between that which is termed</em> <span class="ar">شَهْبَآء</span> <em>and that which is termed</em> <span class="ar">حَمْرَآء</span>. <span class="auth">(TA in art. <span class="ar">شهب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A22</span>
				</div>
				<div class="sense" id="OaboyaDu_A22">
					<p><span class="ar long">كَلَامٌ أَبْيَضُ</span> ‡ <em>Language expounded</em> or <em>explained.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A23</span>
				</div>
				<div class="sense" id="OaboyaDu_A23">
					<p><span class="ar long">كَلَّمْتُهُ فَمَا رَدَّ عَلَىَّ سَوْدَآءَ وَلَا بَيْضَآءَ</span> ‡ <em>I spoke to him, and he did not return to me a bad word nor a good one.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A24</span>
				</div>
				<div class="sense" id="OaboyaDu_A24">
					<p><span class="ar long">يَدٌ بَيْضَآءُ</span> † <em>A demonstrating,</em> or <em>demonstrated, argument, plea, allegation,</em> or <em>evidence.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A25</span>
				</div>
				<div class="sense" id="OaboyaDu_A25">
					<p>And † <em>A favour,</em> or <em>benefit, for which one is not reproached;</em> and <em>which is conferred without its being asked.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#yadN">See also <span class="ar">يَدٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A26</span>
				</div>
				<div class="sense" id="OaboyaDu_A26">
					<p><span class="ar long">المَوْتُ الأَبْيَضُ</span> † <em>Sudden death;</em> <span class="auth">(Ḳ, TA;)</span> <em>such as is not preceded by disease which alters the complexion:</em> or, as some say, <em>death without the repentance, and the prayer for forgiveness, and the accomplishment of necessary duties, usual with him who is not taken unawares;</em> from <span class="ar">بَيَّضَ</span> signifying “he emptied” a vessel: so says Ṣgh: opposed to <span class="ar long">المَوْتُ الأَحْمَرُ</span>, which is slaughter. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A27</span>
				</div>
				<div class="sense" id="OaboyaDu_A27">
					<p><span class="ar">بَيْضَآءُ</span> also signifies † <em>A calamity,</em> or <em>misfortune:</em> <span class="auth">(Ṣgh, Ḳ:)</span> app. as a term of good omen; like <span class="ar">سَلِيمٌ</span> applied to one who is stung by a scorpion or bitten by a serpent. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A28</span>
				</div>
				<div class="sense" id="OaboyaDu_A28">
					<p><span class="ar long">بَيْضَآءُ القَيْظِ</span>: <a href="#baYoDapN">see <span class="ar">بَيْضَةٌ</span></a>, last sentence but one.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">أَبْيَضُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaboyaDu_B1">
					<p><span class="ar long">هٰذَا أَبْيَضُ مِنْ كَذَا</span>;, &amp;c.: <a href="#bayaADN">see <span class="ar">بَيَاضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabiyDN">
				<h3 class="entry"><span class="ar">مَبِيضٌ</span></h3>
				<div class="sense" id="mabiyDN_A1">
					<p><span class="ar">مَبِيضٌ</span> <em>A place for laying eggs.</em> <span class="auth">(ISd, TA in art. <span class="ar">فحص</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubiyDapN">
				<h3 class="entry"><span class="ar">مُبِيضَةٌ</span></h3>
				<div class="sense" id="mubiyDapN_A1">
					<p><span class="ar">مُبِيضَةٌ</span> A woman <em>who brings forth white children:</em> the contr. is termed <span class="ar">مُسْوِدَةٌ</span>: <span class="auth">(Fr, Ḳ:)</span> but <span class="ar">مُوضِحَةٌ</span> is more commonly used in the former sense. <span class="auth">(O.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboyaDBapN">
				<h3 class="entry"><span class="add">[<span class="ar">مُبْيَضَّةٌ</span>]</span></h3>
				<div class="sense" id="muboyaDBapN_A1">
					<p><span class="add">[<span class="ar">مُبْيَضَّةٌ</span> The <em>fair copy,</em> or <em>transcript, made from a first rough draught;</em> which latter is called <span class="ar">مُسْوَدَّةٌ</span>: probably post-classical.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubayBiDN">
				<h3 class="entry"><span class="ar">مُبَيِّضٌ</span></h3>
				<div class="sense" id="mubayBiDN_A1">
					<p><span class="ar">مُبَيِّضٌ</span> A man <em>wearing white clothing.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيض</span> - Entry: <span class="ar">مُبَيِّضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubayBiDN_A2">
					<p>Hence, <span class="ar">المُبَيِّضَةُ</span> <em>A sect of</em> <span class="add">[<em>the class called</em>]</span> <em>the</em> <span class="ar">ثَنَوِيَّة</span>, <span class="auth">(Ṣ, Ḳ,)</span> the companions of <span class="ar">المُقَنَّع</span>; <span class="auth">(Ṣ;)</span> <em>so called because they made their clothes white, in contradistinction to the</em> <span class="ar">مُسَوِّدَة</span>, <em>the partisans of the dynasty of the 'Abbásees;</em> <span class="auth">(Ṣ, Ḳ,*)</span> <em>for the distinction of these was black: they dwelt in Kasr ʼOmeyr.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#AlHaruwriyBapu">See also <span class="ar">الحَرُورِيَّةُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0282.pdf" target="pdf">
							<span>Lanes Lexicon Page 282</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0283.pdf" target="pdf">
							<span>Lanes Lexicon Page 283</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0284.pdf" target="pdf">
							<span>Lanes Lexicon Page 284</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
