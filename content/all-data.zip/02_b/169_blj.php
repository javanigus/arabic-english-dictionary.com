<article class="root" id="Root_blj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/168_bl">بل</a></span>
				<span class="ar">بلج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/170_blH">بلح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blj_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلج</span></h3>
				<div class="sense" id="blj_1_A1">
					<p><span class="ar">بَلِجَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَجُ</span>}</span></add>, <span class="auth">(ISh, TA,)</span> inf. n. <span class="ar">بَلَجٌ</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>He</em> <span class="auth">(a man)</span> <em>had a clear, a conspicuous,</em> or <em>a white, space between the eyes, not having the eyebrows joined;</em> <span class="auth">(ISh, TA;)</span> <em>he had a clear space between the eyebrows;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> <em>he had a wide space,</em> or <em>a space clear of hair, between the eyebrows.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blj_1_A2">
					<p><span class="add">[Hence, <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, bright</em> in countenance: or <em>fair, beautiful, and wide in countenance:</em> or † <em>open and pleasant,</em> or <em>cheerful, in countenance:</em> or † <em>liberal with acts of beneficence:</em> or ‡ <em>generous, beneficent, and open and pleasant,</em> or <em>cheerful, in countenance:</em> see the part. n. <span class="ar">أَبْلَجُ</span>, below.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blj_1_A3">
					<p>And <span class="add">[hence,]</span> aor. as above, <span class="auth">(Ḳ,)</span> and so the inf. n., <span class="auth">(TA,)</span> ‡ <em>He</em> <span class="auth">(a man, TA)</span> <em>was,</em> or <em>became, joyful, glad,</em> or <em>happy.</em> <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar long">بَلِجَ بِالشَّيْءِ</span> ‡ <em>He rejoiced at the thing;</em> or <em>was rejoiced by it;</em> as also <span class="ar">ثَلِجَ</span>. <span class="auth">(Aṣ, TA.)</span> And <span class="ar long">بَلِجَ بِهِ الصَّدْرُ فَرَحًا</span> ‡ <em>The bosom became dilated with joy thereat.</em> <span class="auth">(A.)</span> And <span class="ar long">بَلِجَ بَعْدَ مَا حَرِجَ</span> ‡ <span class="add">[<em>It</em> <span class="auth">(the bosom)</span> <em>became dilated</em> with joy <em>after it had been contracted</em> with grief]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="blj_1_A4">
					<p><span class="add">[And hence,]</span> aor. and inf. n. as above; <span class="auth">(Mṣb;)</span> and <span class="ar">بَلَجَ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُجُ</span>}</span></add>, inf. n. <span class="ar">بُلُوجٌ</span>; <span class="auth">(Ṣ, Mṣb;)</span> and<span class="arrow"><span class="ar">انبلج↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> or<span class="arrow"><span class="ar">ابتلج↓</span></span>; <span class="auth">(so in copies of the A and Mṣb;)</span> and<span class="arrow"><span class="ar">تبلّج↓</span></span>; <span class="auth">(Ṣ, A, Ḳ;)</span> and<span class="arrow"><span class="ar">ابلج↓</span></span>; <span class="auth">(Mṣb, Ḳ;)</span> † <em>It</em> <span class="auth">(the dawn, or daybreak,)</span> <em>shone, was bright,</em> or <em>shone brightly.</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ.)</span> And<span class="arrow"><span class="ar long">أَبْلَجَتِ↓ الشَّمْسُ</span></span> † <em>The sun shone, was bright,</em> or <em>shone brightly.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">ابلاجّ↓ الشَّىْءُ</span></span> † <em>The thing shone, was bright,</em> or <em>shone brightly.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="blj_1_A5">
					<p>And hence, <span class="auth">(Mṣb,)</span> <span class="ar long">بَلَجَ الحَقُّ</span>, and <span class="ar">بَلِجَ</span>; <span class="auth">(Mṣb;)</span> or<span class="arrow"><span class="ar">ابلج↓</span></span>; <span class="auth">(A, TA;)</span> ‡ <em>The truth became apparent,</em> <span class="auth">(A, Mṣb, TA,)</span> <em>manifest, evident,</em> or <em>clear.</em> <span class="auth">(A, Mṣb.)</span> And<span class="arrow"><span class="ar">ابلاجّ↓</span></span>, inf. n. <span class="ar">اِبْلِيجَاجٌ</span>, <span class="auth">(Ṣ, and so the inf. n. is written in a copy of the Ḳ: in another copy of the Ḳ it is written <span class="ar">اِبْلِجَاجٌ</span> <span class="add">[<a href="#blj_9">inf. n. of<span class="arrow"><span class="ar">ابلجّ↓</span></span></a>]</span>, and the verb is written <span class="ar">ابلجّ</span> in a copy of the Ṣ: accord. to the CK, the inf. n. is <span class="ar">اِبْلِيلَاجٌ</span> <span class="add">[of which the verb is<span class="arrow"><span class="ar">ابلولج↓</span></span>]</span>:)</span> said of anything, <span class="auth">(Ṣ, TA,)</span> signifies ‡ <em>It was,</em> or <em>became, apparent, manifest, evident,</em> or <em>clear.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<span class="pb" id="Page_0246"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blj_1_B1">
					<p><span class="ar">بَلَجَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِجُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَلْجٌ</span>, <span class="auth">(TA,)</span> <em>He opened;</em> syn. <span class="ar">فَتَحَ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blj_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلج</span></h3>
				<div class="sense" id="blj_4_A1">
					<p><a href="#blj_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blj_4_B1">
					<p><span class="ar">ابلجهُ</span> † <em>He made it apparent, manifest, evident,</em> or <em>clear.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="blj_4_B2">
					<p>And † <em>He made him joyful, glad,</em> or <em>happy;</em> syn. <span class="ar">فَرَّحَهُ</span>: <span class="auth">(Ḳ accord. to the TA <span class="add">[and so in a MṢ. copy of the Ḳ in my hands]</span>:)</span> or † <em>he removed it,</em> or <em>cleared it away;</em> syn. <span class="ar">فَرَّجَهُ</span>. <span class="auth">(So accord. to the CK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blj_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّج</span></h3>
				<div class="sense" id="blj_5_A1">
					<p><span class="ar">تبلّج</span> † <em>He laughed, and was cheerful, brisk, lively,</em> or <em>sprightly.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blj_5_A2">
					<p><a href="#blj_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blj_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبلج</span></h3>
				<div class="sense" id="blj_7_A1">
					<p><a href="#blj_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blj_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتلج</span></h3>
				<div class="sense" id="blj_8_A1">
					<p><a href="#blj_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blj_9">
				<h3 class="entry">9. ⇒ <span class="ar">ابلجّ</span></h3>
				<div class="sense" id="blj_9_A1">
					<p><a href="#blj_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blj_11">
				<h3 class="entry">11. ⇒ <span class="ar">ابلاجّ</span></h3>
				<div class="sense" id="blj_11_A1">
					<p><a href="#blj_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blj_12">
				<h3 class="entry">12. ⇒ <span class="ar">ابلولج</span></h3>
				<div class="sense" id="blj_12_A1">
					<p><a href="#blj_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baloju">
				<h3 class="entry"><span class="ar">بَلْجُ</span></h3>
				<div class="sense" id="baloju_A1">
					<p><span class="ar">بَلْجُ</span>: <a href="#OabolajN">see <span class="ar">أَبْلَجٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balajN">
				<h3 class="entry"><span class="ar">بَلَجٌ</span></h3>
				<div class="sense" id="balajN_A1">
					<p><span class="ar">بَلَجٌ</span>: <a href="#bulojapN">see <span class="ar">بُلْجَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balijN">
				<h3 class="entry"><span class="ar">بَلِجٌ</span></h3>
				<div class="sense" id="balijN_A1">
					<p><span class="ar">بَلِجٌ</span> ‡ <em>Joyful, glad,</em> or <em>happy.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#OabolajN">See also <span class="ar">أَبْلَجٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulujN">
				<h3 class="entry"><span class="ar">بُلُجٌ</span></h3>
				<div class="sense" id="bulujN_A1">
					<p><span class="ar">بُلُجٌ</span>, with two dammehs, Men <em>clear of hair in the</em> <span class="add">[<em>parts of the face called the</em>]</span> <span class="ar">قَسَمَات</span>. <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balojapN">
				<h3 class="entry"><span class="ar">بَلْجَةٌ</span></h3>
				<div class="sense" id="balojapN_A1">
					<p><span class="ar">بَلْجَةٌ</span>: <a href="#buljapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buljapN">
				<h3 class="entry"><span class="ar">بُلجَةٌ</span></h3>
				<div class="sense" id="buljapN_A1">
					<p><span class="ar">بُلجَةٌ</span> <em>Clearness of the space between the eyebrows:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> or <em>width of the space between the eyebrows;</em> or <span class="add">[<em>of</em>]</span> <em>the space between the eyebrows when clear of hair;</em> as also<span class="arrow"><span class="ar">بَلَجٌ↓</span></span> <span class="add">[<a href="#blj_1">which is the inf. n. of <span class="ar">بَلِجَ</span></a>]</span>. <span class="auth">(TA.)</span> One says, <span class="ar long">مَا أَحْسَنَ بُلْجَتَهُ</span> <em>How beautiful is the clearness of the space between his eyebrows!</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: <span class="ar">بُلجَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buljapN_A2">
					<p>The <em>part behind the</em> <span class="ar">عَارِض</span> <span class="add">[or <em>side of the cheek</em> or <em>face</em>]</span>, <em>to the ear, when there is no hair upon it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: <span class="ar">بُلجَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buljapN_A3">
					<p>Also, and<span class="arrow"><span class="ar">بَلْجَةٌ↓</span></span>, † The <em>light</em> <span class="auth">(Ṣ, L, Ḳ)</span> of the dawn, or daybreak, <span class="auth">(Ṣ, L,)</span> <em>in the last part of the night,</em> <span class="auth">(Ṣ, TA,)</span> <em>at the breaking of the dawn.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">رَأَيْتُ بُلْجَةٌ الصُّبْحِ</span> † <em>I saw the light of the dawn.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">لَقِيتُهُ عِنْدَ البُلْجَةِ</span> † <span class="add">[<em>I met,</em> or <em>found, him,</em> or <em>it, at the break of the dawn</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">سَرَيْتُ الدُّلْجَةَ وَالبَلْجَةَ حَتَّى وَصْلَتُ</span> † <span class="add">[<em>I journeyed during the whole night,</em> or <em>from the beginning of the night,</em> or <em>during the latter part of the night, and the breaking of the dawn, until I arrived</em>]</span>. <span class="auth">(A.)</span> And it is said in a trad., <span class="ar long">لَيْلَةُ القَدْرِ بُلْجَةِ</span> † <em>The night of</em> <span class="ar">القدر</span> <em>is bright</em> <span class="add">[<em>like the dawn</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baliyjN">
				<h3 class="entry"><span class="ar">بَلِيجٌ</span></h3>
				<div class="sense" id="baliyjN_A1">
					<p><span class="ar">بَلِيجٌ</span>: <a href="#Oabolaju">see <span class="ar">أَبْلَجُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biliylajN">
				<h3 class="entry"><span class="ar">بِلِيلَجٌ</span></h3>
				<div class="sense" id="biliylajN_A1">
					<p><span class="ar">بِلِيلَجٌ</span>, with kesr to the <span class="ar">ب</span> and to the first <span class="ar">ل</span>, and with fet-ḥ to the second <span class="ar">ل</span>; <span class="auth">(Mṣb;)</span> or <span class="ar">بَلِيلَجٌ</span>; <span class="auth">(so written in some copies of the Ḳ, in other copies of which it is omitted;)</span> <span class="add">[<span class="la"><em>Myrobalana Bellerica:</em></span> <span class="auth">(Golius and Freytag:)</span> <span class="la"><em>Terminaria Chebula:</em></span> Sprengel. hist. rei herb. p. 262: <span class="auth">(Freytag:)</span>]</span> <em>a certain well-known Indian medicine;</em> <span class="auth">(Mṣb;)</span> <em>very beneficial to the stomach and to the intestinum rectum.</em> <span class="auth">(Ḳ.)</span> <span class="add">[For other properties, &amp;c. assigned to it, see Ibn-Seenà <span class="auth">(Avicenna)</span>, book ii. p. 144. <a href="#IiholiylajN">See also <span class="ar">اِهْلِيلَجٌ</span></a>, <a href="index.php?data=26_h/110_hlj">in art. <span class="ar">هلج</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabolaju">
				<h3 class="entry"><span class="ar">أَبْلَجُ</span></h3>
				<div class="sense" id="Oabolaju_A1">
					<p><span class="ar">أَبْلَجُ</span> A man <em>having a clear, a conspicuous,</em> or <em>a white, space between the eyes, not having the eyebrows joined:</em> <span class="auth">(ISh, TA:)</span> or <em>having such a space between the eyebrows,</em> <span class="auth">(Ḳ,* TA,)</span> <em>not having the eyebrows joined:</em> <span class="auth">(Ṣ, TA:)</span> or <em>having a wide space,</em> or <em>a space clear of hair, between the eyebrows:</em> fem. <span class="ar">بَلْجَآءُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: <span class="ar">أَبْلَجُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabolaju_A2">
					<p><span class="add">[Hence,]</span> <em>Bright</em> of countenance; the Prophet being said by UmmMaabad to have been <span class="ar long">أَبْلَجُ الوَجْهِ</span>; by which she did not mean the <span class="ar">بَلَج</span> of the eyebrows, for she described him as having joined eyebrows: <span class="auth">(AʼObeyd, Ṣ, TA:)</span> or <em>fair, beautiful, and wide in countenance,</em> whether long or short: or <span class="add">[alone, or]</span> followed by <span class="arrow"><span class="ar">بَلْجٌ↓</span></span>, † <em>open and pleasant,</em> or <em>cheerful, in countenance;</em> <span class="auth">(TA;)</span> and so<span class="arrow">↓</span> the latter alone: <span class="auth">(Ḳ:)</span> or<span class="arrow">↓</span> the latter, ‡ <em>open and pleasant,</em> or <em>cheerful, in countenance, with beneficence:</em> <span class="auth">(TA:)</span> or the former, and<span class="arrow">↓</span> the latter, and<span class="arrow"><span class="ar">بَلِيجٌ↓</span></span>, † <em>liberal with acts of beneficence:</em> <span class="auth">(TA:)</span> or the first, ‡ <em>generous, beneficent, and open and pleasant,</em> or <em>cheerful, in countenance;</em> although having joined eyebrows. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلج</span> - Entry: <span class="ar">أَبْلَجُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabolaju_A3">
					<p>Also † <em>Shining, bright,</em> or <em>shining brightly;</em> applied to the dawn, or daybreak; <span class="auth">(Ṣ, A, Mṣb;)</span> and so<span class="arrow"><span class="ar">بَلِيجٌ↓</span></span>, applied to a thing <span class="add">[of any kind]</span>: <span class="auth">(TA:)</span> and the former, anything † <em>apparent, manifest, evident,</em> or <em>clear;</em> <span class="auth">(Ḳ;)</span> thus applied to a face, and to the dawn, <span class="auth">(TA,)</span> and to the truth, <span class="auth">(Mṣb, TA,)</span> and to an affair or event, or a case, &amp;c. <span class="auth">(TA.)</span> It is an act. part. n. of <span class="ar">بَلِجَ</span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">الحَقُّ أَبْلَجُ وَالبَاطِلُ لَجْلَجٌ</span> ‡ <em>The truth is apparent, manifest, evident,</em> or <em>clear;</em> <span class="add">[<em>and falsity is a cause of embarrassment,</em> or <em>hesitation, to the speaker;</em>]</span> <span class="auth">(Ṣ, A;*)</span> i. e., the latter is agitated to and fro, without having utterance: <span class="auth">(Ṣ in art. <span class="ar">لج</span>:)</span> or <em>the truth is lucid and direct; and falsity is confused and indirect.</em> <span class="auth">(TA in that art.)</span> And <span class="ar long">حُجَّةٌ بَلْجَآءُ</span> † <em>A manifest, an evident,</em> or <em>a clear, proof</em> or <em>argument.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ouboluwju">
				<h3 class="entry"><span class="ar">أُبْلُوجُ</span></h3>
				<div class="sense" id="Ouboluwju_A1">
					<p><span class="ar long">أُبْلُوجُ السُّكَّرِ</span>, with damm, <span class="add">[meaning <em>Sugar-candy,</em> and <em>loaf-sugar,</em> thus applied in the present day,]</span> is an arabicized term <span class="add">[from the Persian <span class="ar">آبْلُوجْ</span>]</span>: <span class="auth">(Ḳ, TA:)</span> in one copy of the Ḳ, it is said that <span class="ar">أُبْلُوجٌ</span>, with damm, is <span class="add">[syn. with]</span> <span class="ar">السُّكَّرٌ</span> <span class="add">[<em>sugar</em>]</span>: by the people <span class="add">[who are makers]</span> of <span class="ar">الحَسَا</span> and <span class="ar">القَطِيف</span>, <span class="add">[see these words, the latter of which is a coll. gen. n., of which the n. un. is with <span class="ar">ة</span>, pl. <span class="ar">قَطَائِفٌ</span>,]</span> it is called <span class="ar">أُمْلُوجٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0245.pdf" target="pdf">
							<span>Lanes Lexicon Page 245</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0246.pdf" target="pdf">
							<span>Lanes Lexicon Page 246</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
