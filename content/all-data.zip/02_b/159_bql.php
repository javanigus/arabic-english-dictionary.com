<article class="root" id="Root_bql">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/158_bqE">بقع</a></span>
				<span class="ar">بقل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/160_bqm">بقم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bql_1">
				<h3 class="entry">1. ⇒ <span class="ar">بقل</span></h3>
				<div class="sense" id="bql_1_A1">
					<p><span class="ar">بَقَلَ</span>: <a href="#bql_4">see 4</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bql_1_A2">
					<p><span class="add">[Hence,]</span> said of a boy's face, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْقُلُ</span>}</span></add>, inf. n. <span class="ar">بُقُولٌ</span>, <span class="auth">(Ṣ,)</span> ‡ <em>It put forth its beard,</em> <span class="auth">(Ṣ, TA,)</span> or <em>hair;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">ابقل↓</span></span> and<span class="arrow"><span class="ar">بقّل↓</span></span>; <span class="auth">(Ḳ;)</span> or this last is not allowable: <span class="auth">(Ṣ:)</span> similar to <span class="ar">اِخْضَرَّ</span> said of a boy's mustache. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bql_1_A3">
					<p>And said of a camel's tush, ‡ <em>It cut,</em> or <em>came forth.</em> <span class="auth">(ISk, Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bql_1_A4">
					<p>† <em>It</em> <span class="auth">(a thing, TA)</span> <em>appeared:</em> <span class="auth">(Ḳ, TA:)</span> derived from <span class="ar">بَقْلٌ</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bql_1_B1">
					<p><em>He collected</em> <span class="add">[<em>plants,</em> or <em>herbs, of the kind termed</em>]</span> <span class="ar">بَقْل</span> for his camel. <span class="auth">(Fr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bql_1_B2">
					<p><span class="ar long">بَقَلَ البَقْلَ</span> <em>He cut the</em> <span class="ar">بقل</span>: so in the “Mufradát. “<span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bql_2">
				<h3 class="entry">2. ⇒ <span class="ar">بقّل</span></h3>
				<div class="sense" id="bql_2_A1">
					<p><span class="ar">بقّل</span>, inf. n. <span class="ar">تَبْقِيِلٌ</span>, <em>He</em> <span class="auth">(a pastor)</span> <em>left</em> camels <em>to pasture upon</em> <span class="ar">بَقْل</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bql_2_A2">
					<p>And, <span class="add">[hence, app.,]</span> inf. n. as above, <em>i. q.</em> <span class="ar">سَاسَ</span> <span class="auth">(Ṣgh, Ḳ.)</span> You say, <span class="ar long">بقّل الدَّايَّةَ</span>, i. e. <span class="ar">سَاسَهَا</span>, meaning <em>He tended,</em> or <em>took care of, the beast well.</em> <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bql_2_B1">
					<p><a href="#bql_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bql_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابقل</span></h3>
				<div class="sense" id="bql_4_A1">
					<p><span class="ar long">ابقلت الأَرْضُ</span> <em>The land produced</em> <span class="add">[<em>plants,</em> or <em>herbs, of the kind termed</em>]</span> <span class="ar">بَقْل</span>: <span class="auth">(Mṣb:)</span> or <em>produced its</em> <span class="ar">بقل</span>: <span class="auth">(Ṣ:)</span> or <em>produced plants,</em> or <em>herbage:</em> <span class="auth">(Ḳ:)</span> or <em>became green with plants,</em> or <em>herbage:</em> <span class="auth">(Mgh:)</span> and<span class="arrow"><span class="ar">بَقَلَت↓</span></span> signifies the same: <span class="auth">(IDrd, Ḳ:)</span> both are chaste words. <span class="auth">(IDrd, TA.)</span> In like manner one says also of a place, <span class="ar">ابقل</span>, <span class="auth">(JK, Mṣb,)</span> from <span class="ar">بَقْلٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bql_4_A2">
					<p><span class="ar long">ابقل الرِّمْثُ</span> <em>The</em> <span class="add">[<em>tree,</em> or <em>shrub, called</em>]</span> <span class="ar">رمث</span> <em>became green;</em> as also<span class="arrow"><span class="ar">بَقَلَ↓</span></span>: <span class="auth">(Ḳ:)</span> or <em>it put forth what resembled young wingless locusts, and the greenness of its leaves became apparent.</em> <span class="auth">(Ṣ. <span class="add">[<a href="#HanaTa">See also <span class="ar">حَنَطَ</span></a>.]</span>)</span> And <span class="ar long">ابقل الشَّجَرُ</span> <em>The trees put forth their</em> <span class="ar">بَاقِل</span> <span class="add">[q. v., app. <em>buds,</em>]</span> <em>in the days of the</em> <span class="ar">رَبِيع</span> <span class="add">[or <em>spring</em>]</span>, <em>before their leaves became apparent:</em> <span class="auth">(JK:)</span> or <em>they put forth, in the time of the</em> <span class="ar">ربيع</span> <em>in their sides, what resembled the necks of locusts.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bql_4_A3">
					<p><a href="#bql_1">See also 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bql_4_B1">
					<p><span class="ar long">ابقل القَوْمُ</span> <em>The people,</em> or <em>company of men, found</em> <span class="add">[<em>plants,</em> or <em>herbs, such as are termed</em>]</span> <span class="ar">بَقْل</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bql_4_B2">
					<p><a href="#bql_8">See also 8</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bql_4_C1">
					<p><span class="ar long">ابقل وَجْهَهُ</span> ‡ <em>He</em> <span class="auth">(God)</span> <em>made his</em> <span class="auth">(a boy's)</span> <em>face to put forth its hair,</em> <span class="auth">(Ḳ, TA,)</span> meaning, <em>its beard.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bql_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبقّل</span></h3>
				<div class="sense" id="bql_5_A1">
					<p><span class="ar">تبقّل</span> <em>He went forth seeking</em> <span class="add">[<em>plants,</em> or <em>herbs, of the kind called</em>]</span> <span class="ar">بَقْل</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bql_5_A2">
					<p><a href="#bql_8">See also 8</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bql_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتقل</span></h3>
				<div class="sense" id="bql_8_A1">
					<p><span class="ar long">ابتقل الحِمَارُ</span> and<span class="arrow"><span class="ar">تبقّل↓</span></span>; <span class="auth">(Ṣ;)</span> or <span class="ar long">ابتقلت المَاشِيَةُ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">الإِبِلُ</span>, <span class="auth">(JK,)</span> and<span class="arrow"><span class="ar">تبقّلت↓</span></span>; <span class="auth">(JK, Ḳ;)</span> <em>The ass,</em> or <em>the beasts,</em> or <em>camels, pastured upon</em> <span class="add">[<em>plants,</em> or <em>herbs, of the kind called</em>]</span> <span class="ar">بَقْل</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>became fat from pasturing upon</em> <span class="ar">بقل</span>. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bql_8_A2">
					<p>And <span class="ar long">ابتقل القَوْمُ</span> <em>The people,</em> or <em>company of men, had their cattle pasturing upon</em> <span class="ar">بَقْل</span>; as also<span class="arrow"><span class="ar">تبقّلوا↓</span></span> and<span class="arrow"><span class="ar">ابقلوا↓</span></span>: <span class="auth">(Ḳ:)</span> or <em>they pastured their cattle upon</em> <span class="ar">بقل</span>. <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqolN">
				<h3 class="entry"><span class="ar">بَقْلٌ</span> / <span class="ar">بَقْلَةٌ</span></h3>
				<div class="sense" id="baqolN_A1">
					<p><span class="ar">بَقْلٌ</span> a word of which the meaning is well known; <span class="auth">(Ṣ;)</span> <span class="add">[<em>Leguminous,</em> or <em>tender, plants; such as we term herbs;</em> i. e. <em>plants,</em> or <em>vegetables, that may be gathered, with the hand, or depastured down to the ground, and that are only annuals;</em>]</span> <em>plants which are neither shrubs nor trees;</em> <span class="auth">(Lth, JK,* Mgh;)</span> <em>such as, when depastured, have no stem remaining; thus differing from trees and shrubs, which have stems remaining</em> <span class="add">[<em>when they have been depastured</em>]</span>: <span class="auth">(Lth, Mgh:)</span> or the <em>herbs,</em> or <em>herbage, produced by</em> <span class="add">[<em>the rain,</em> or <em>the season, called</em>]</span> <em>the</em> <span class="ar">رَبِيع</span>: <span class="auth">(Mgh:)</span> or <em>whatever herbs,</em> or <em>plants, grow from seed,</em> <span class="auth">(AḤn, Mgh, Ḳ,*)</span> <em>not upon a permanent</em> <span class="ar">أَرُومَة</span> <span class="add">[i. e. <em>root-stock,</em> or <em>root</em>]</span>: <span class="auth">(AḤn, Ḳ:)</span> and accord. to this definition may be explained the saying that the cucumber is of the things termed <span class="ar">بُقُولٌ</span> <span class="add">[<a href="#baqolN">pl. of <span class="ar">بَقْلٌ</span></a>, meaning <em>sorts,</em> or <em>species, of</em> <span class="ar">بَقْل</span>]</span>, not of those termed <span class="ar">فَوَاكِهُ</span>: <span class="auth">(Mgh:)</span> or the <em>kind of which the root and branch do not last in the winter:</em> <span class="auth">(Er-Rághib, TA:)</span> or, it is said, <span class="auth">(Ṣ, Mgh,)</span> <em>any plants,</em> or <em>herbs, whereby the earth becomes green:</em> <span class="auth">(Ṣ, IF, Mgh, Mṣb:)</span> <span class="add">[pl. of pauc. <span class="ar">أَبْقَالٌ</span>: the pl. of mult. has been mentioned above:]</span> the n. un. is with <span class="ar">ة</span>, i. e. <span class="ar">بَقْلَةٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> Hence the prov., <span class="ar long">لَا تُنْبِتُ البَقْلَةَ إِلَّا الحَقْلَةُ</span> <span class="add">[<em>Nothing produces the leguminous,</em> or <em>tender, plant,</em> or <em>herb, but the clear and open piece of good land</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[i. e., only a good parent produces good offspring: <span class="auth">(see Freytag's Arab. Prov. ii. 516:)</span>]</span> it is said to be applied to the case of a vile saying proceeding from a vile man. <span class="auth">(TA in art. <span class="ar">حقل</span>.)</span> The saying <span class="ar long">بَاعَ الزَّرْعَ وَهُوَ بَقْلٌ</span> means <span class="add">[<em>He sold the seedproduce</em>]</span> <em>when it was green, not yet ripe.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqolN_A2">
					<p><span class="ar">البَقْلَةُ</span>, also, and <span class="ar long">البَقْلَةُ الحَمْقَآءُ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">بَقْلَةُ الحَمْقَآءِ</span>, <span class="auth">(Ḳ,)</span> or all these, <span class="auth">(TA,)</span> signify the same as <span class="ar">الرِّجْلَةُ</span> <span class="add">[i. e. <em>Purslane;</em> called by these names in the present day]</span>; <span class="auth">(Ṣ, Ḳ;)</span> and so <span class="ar long">البَقْلَةُ اللَّيِّنةُ</span> and <span class="ar long">البَقْلَةُ المُبَارَكَةُ</span>: or this last, <em>i. q.</em> <span class="ar">الهِنْدَبَآءُ</span> <span class="add">[i. e. <em>wild and garden succory,</em> or <em>endive</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baqolN_A3">
					<p><span class="ar long">بَقْلَةُ الأَنْصَارِ</span> <em>i. q.</em> <span class="ar">الكُرْنُبُ</span> <span class="add">[or <span class="ar">الكُرْنَبُ</span>, q. v., the name now given to <em>Cabbage:</em> in the CK <span class="ar">الكُرْنَبُ</span>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baqolN_A4">
					<p><span class="ar long">بَقْلَةُ الخَطَاطِيفِ</span> <span class="add">[<em>Chelidonium,</em> or <em>celandine;</em> thus called in the present day;]</span> <em>i. q.</em> <span class="ar long">العُرُوقُ الصُّفْرُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baqolN_A5">
					<p><span class="ar long">بَقْلَةُ المَلِكِ</span> <em>i. q.</em> <span class="ar">الشَّاهْتَرَجُ</span> <span class="add">[<em>Fumaria officinalis,</em> or <em>common fumitory</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baqolN_A6">
					<p><span class="ar long">البَقْلَةُ البَارِدَةُ</span> <em>i. q.</em> <span class="ar">اللَّبْلَابُ</span> <span class="add">[now commonly applied to the <em>Dolichos lablab of</em> of Linnæus; but Golius explains the former appellation by <em>hedera,</em> i. e. <em>ivy,</em> though only as on the authority of the Ḳ]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baqolN_A7">
					<p><span class="ar long">البَقْلَةُ الذَّهَبِيَّةُ</span> <em>i. q.</em> <span class="ar">القِطْفُ</span> <span class="add">[or <span class="ar">القَطَفُ</span>, a name now given to <em>Atriplex,</em> or <em>orache:</em> Golius explains the former appellation by <em>spinachium</em> seu <em>atriplex;</em> and the latter, in its proper art., by <em>atriplex herba,</em> and <em>androsœnum</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="baqolN_A8">
					<p><span class="ar long">البَقْلَةُ اليَهُودِيَّةُ</span> <span class="add">[<em>Sonchus,</em> or <em>sow-thistle;</em> thus called in the present day]</span>. <span class="auth">(TA voce <span class="ar">خُبَّازٌ</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="baqolN_A9">
					<p><span class="ar long">البَقْلَةُ اليَمَانِيَّةُ</span> <span class="add">[<em>Blitum,</em> or <em>blite;</em> and particularly the species called <em>strawberry blite;</em>]</span> <em>a certain herb.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="baqolN_A10">
					<p><span class="ar long">البَقْلَةٌ الأُتْرُجِيَّةُ</span> <span class="add">[<em>Citrago,</em> or <em>balmgentle;</em>]</span> <em>a certain herb.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="baqolN_A11">
					<p><span class="ar long">بَقْلَةُ الضَّبِّ</span> and <span class="ar long">بَقْلَةُ الرُّمَاةِ</span> and <span class="ar long">بَقْلَةُ الرَّمْلِ</span> and <span class="add">[in the CK “or”]</span> <span class="ar long">بَقْلَةُ البَرَارِى</span> and <span class="ar long">البَقْلَةُ الحَمْضَآءُ</span>, <span class="auth">(Ḳ, TA,)</span> or <span class="ar long">بَقْلَةُ الحَامِضَةُ</span>, <span class="auth">(CK,)</span> are also <em>Certain herbs.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="baqolN_A12">
					<p><span class="ar long">بُقُولُ الأَرْجَاعِ</span> <em>A certain plant proved by experience to remove pains from the belly.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqilN">
				<h3 class="entry"><span class="ar">َقِلٌ</span></h3>
				<div class="sense" id="baqilN_A1">
					<p><span class="ar long">بَلَدٌ بَقِلٌ</span> and<span class="arrow"><span class="ar">مُبْقِلٌ↓</span></span> <span class="add">[<em>A country,</em> or <em>region,</em> or <em>district, producing plants,</em> or <em>herbs, of the kind termed</em> <span class="ar">بَقْل</span>]</span>. <span class="auth">(JK.)</span> And <span class="ar long">أَرْضٌ بَقِلَةٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <span class="add">[in the CK <span class="ar">بَقْلَةٌ</span>, but it is]</span> like <span class="ar">فَرِحَةٌ</span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بَقِيلَةٌ↓</span></span> and<span class="arrow"><span class="ar">مُبْقِلَةٌ↓</span></span>, <span class="auth">(JK, Mṣb, Ḳ,)</span> <em>Land producing</em> <span class="ar">بَقْل</span>: <span class="auth">(Mṣb:)</span> or <em>producing plants,</em> or <em>herbage:</em> <span class="auth">(Ḳ:)</span> and the first and<span class="arrow">↓</span> second of these, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بَقَّالةٌ↓</span></span>, erroneously written in the copies of the Ḳ <span class="ar">بَقَّالَةٌ</span>, without teshdeed, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">مَبْقَلَةٌ↓</span></span> and<span class="arrow"><span class="ar">مَبْقُلَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>land having,</em> or <em>containing,</em> <span class="ar">بَقْل</span> <span class="auth">(Ḳ,* TA)</span> <em>of</em> <span class="add">[<em>the rain,</em> or <em>season, called</em>]</span> <em>the</em> <span class="ar">رَبِيع</span>: <span class="auth">(Ḳ:)</span> or<span class="arrow"><span class="ar">مَبْقَلَةٌ↓</span></span> <span class="add">[used alone, as a subst.,]</span> signifies <em>a land having,</em> or <em>containing,</em> <span class="ar">بَقْل</span>; <span class="auth">(JK;)</span> or <em>a place of</em> <span class="ar">بَقْل</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar">بَاقِلٌ↓</span></span> <span class="add">[app. as meaning <em>producing</em> <span class="ar">بَقْل</span>]</span> is applied as an epithet to a place; <span class="auth">(JK, Mṣb;)</span> but not <span class="arrow"><span class="ar">مُبْقِلٌ↓</span></span>; <span class="auth">(JK;)</span> or this last sometimes occurs, thus applied. <span class="auth">(IJ, IB.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buqolapN">
				<h3 class="entry"><span class="ar">بُقْلَةٌ</span></h3>
				<div class="sense" id="buqolapN_A1">
					<p><span class="ar">بُقْلَةٌ</span> The <span class="add">[<em>plants,</em> or <em>herbs, termed</em>]</span> <span class="ar">بَقْل</span> <em>of</em> <span class="add">[<em>the rain,</em> or <em>season, called</em>]</span> <em>the</em> <span class="ar">رَبِيع</span>. <span class="auth">(JK, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqiylapN">
				<h3 class="entry"><span class="ar">بَقِيلَةٌ</span></h3>
				<div class="sense" id="baqiylapN_A1">
					<p><span class="ar long">أَرْضٌ بَقِيلَةٌ</span>: <a href="#baqilN">see <span class="ar">بَقِلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buquwlieBN">
				<h3 class="entry"><span class="add">[<span class="ar">بُقُولِىٌّ</span>]</span></h3>
				<div class="sense" id="buquwlieBN_A1">
					<p><span class="add">[<span class="ar">بُقُولِىٌّ</span> <em>Of,</em> or <em>relating to, the plants,</em> or <em>herbs, termed</em> <span class="ar">بَقْل</span>: from the pl. <span class="ar">بُقُولٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqBaAlN">
				<h3 class="entry"><span class="ar">بَقَّالٌ</span></h3>
				<div class="sense" id="baqBaAlN_A1">
					<p><span class="ar">بَقَّالٌ</span> <span class="add">[properly <em>A green-grocer;</em> i. e.]</span> <em>a seller of</em> <span class="ar">تَرَهْ</span> <span class="add">[Persian for <span class="ar">بَقْل</span>]</span>: and <span class="add">[by extension of its application]</span> <em>a shop-keeper:</em> <span class="auth">(KL:)</span> or <em>a seller of dry fruits:</em> <span class="auth">(Ibn-Es-Sem'ánee, TA:)</span> vulgarly, <em>a seller of eatables</em> <span class="add">[<em>of various kinds,</em> and particularly <em>of dried and salted provisions, cheese, &amp;c.; a grocer</em>]</span>; correctly, <span class="ar">بَدَّالٌ</span>. <span class="auth">(AHeyth, T in art. <span class="ar">بدل</span>, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَقَّالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqBaAlN_A2">
					<p><span class="ar long">أَرْضٌ بَقَّالةٌ</span>: <a href="#baqilN">see <span class="ar">بَقِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqlN">
				<h3 class="entry"><span class="ar">بَاقلٌ</span></h3>
				<div class="sense" id="baAqlN_A1">
					<p><span class="ar">بَاقلٌ</span>: <a href="#baqilN">see <span class="ar">بَقِلٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَاقلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAqlN_A2">
					<p>Also, as an epithet applied to the <span class="add">[tree, or shrub, called]</span> <span class="ar">رِمْث</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>Becoming green:</em> <span class="auth">(Ḳ:)</span> or <em>putting forth what resemble young wingless locusts, and showing the greenness of its leaves:</em> they did not say <span class="arrow"><span class="ar">مُبْقِلٌ↓</span></span> <span class="add">[in this sense]</span>, in like manner as <span class="add">[it is commonly asserted that]</span> they did not say <span class="ar">مُورِسٌ</span>, from <span class="ar">أَوْرَسَ</span>, but <span class="ar">وَاِرسٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَاقلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAqlN_A3">
					<p>Also <em>What comes forth,</em> or <em>come forth, in the sides of trees, in the days of the</em> <span class="ar">رَبِيع</span> <span class="add">[or <em>spring</em>]</span>, <em>before their leaves become apparent.</em> <span class="auth">(JK.)</span> <span class="add">[<a href="#bql_4">See 4</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqilBFe">
				<h3 class="entry"><span class="ar">بَاقِلًّى</span> / 
							<span class="ar">بَاقِلَّاةٌ</span> / 
							<span class="ar">بَاقِلَآءٌ</span> / 
							<span class="ar">بَاقِلَآءَةٌ</span> / 
							<span class="ar">بَاقِلًى</span> /
							<span class="ar">بَاقِلَاةٌ</span></h3>
				<div class="sense" id="baAqilBFe_A1">
					<p><span class="ar">بَاقِلًّى</span> and <span class="ar">بَاقِلَآءٌ</span>, <span class="auth">(JK, Ṣ, Mgh, Mṣb, Ḳ,)</span> the former with teshdeed and the latter without teshdeed, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> and <span class="ar">بَاقِلًى</span>, <span class="auth">(Ḳ,)</span> <span class="add">[every one with tenween when it has not the article <span class="ar">ال</span>, for]</span> <span class="pb" id="Page_0237"></span>the n. un. is with <span class="ar">ة</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> i. e. <span class="ar">بَاقِلَّاةٌ</span> and <span class="ar">بَاقِلَآءَةٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb)</span> <span class="add">[and <span class="ar">بَاقِلَاةٌ</span>]</span> or the sing. and pl. are alike, <span class="auth">(El-Aḥmar, Ḳ,)</span> <span class="add">[and if so, the word may be fem., as Ibn-Buzurj, cited in the TA voce <span class="ar">هِنْدَبٌ</span>, asserts <span class="ar">بَقِلَآء</span> to be, and therefore in every case without tenween,]</span> <em>i. q.</em> <span class="ar">فُولٌ</span> <span class="add">[<em>Beans;</em> or the <em>bean; faba sativa</em> of Jussieu; <em>vicia faba</em> of Linnæus]</span>; <span class="auth">(JK, Ḳ;)</span> a name of the dial. of the Sawád <span class="add">[of El-'Irák]</span>; <em>its produce is called</em> <span class="ar">الجِرْجِرُ</span>; <span class="auth">(TA; <span class="add">[<a href="#jarojiyrN">but see <span class="ar">جَرْجِيرٌ</span></a>; <a href="#turomusN">and see <span class="ar">تُرْمُسٌ</span></a>;]</span>)</span> <span class="add">[or it is applied to the plant and to its produce;]</span> <em>a certain well-known</em> <span class="ar">حَبّ</span> <span class="add">[or <em>grain</em>]</span>: <span class="auth">(Mgh:)</span> <em>the eating of it produces exhalations</em> <span class="auth">(Ḳ)</span> <em>of a gross kind,</em> <span class="auth">(TA,)</span> <em>and bad dreams, and</em> <span class="ar">سَدَر</span>, <span class="auth">(Ḳ,)</span> i. e. <em>vertigo,</em> <span class="auth">(TA,)</span> <em>and anxiety, and gross humours; but it is good for the cough, and for rendering the body fruitful</em> (<span class="ar long">تَخْصِيب البَدَن</span>); <em>when properly qualified</em> <span class="add">[app. <em>by seasoning</em> or <em>by some admixture</em>]</span> (<span class="ar long">إِذَا أُصْلِحَ</span>), <em>it preserves the health; and in its green state, together with ginger, it has the utmost effect in strengthening the venereal faculty:</em> <span class="auth">(Ḳ:)</span> the pl. is <span class="ar">بَوَاقِلُ</span>: and <a href="#bAqBle">the dim. of <span class="ar">باقّلى</span></a> is <span class="arrow"><span class="ar">بُوَيْقِلَةٌ↓</span></span> and<span class="arrow"><span class="ar">بُوَيْقِلْيَةٌ↓</span></span>, the latter with the <span class="ar">ل</span> quiescent because kesreh is disapproved in so long a word; <span class="add">[both forms indicating that <span class="ar">باقلّى</span> is held to be fem.;]</span> <a href="#bAqlAC">and that of <span class="ar">باقلآء</span></a> is <span class="ar">بُوَيْقِلَآء</span> <span class="add">[with or without tenween accord. as it is held to be masc. or fem.]</span>, or, if one will, he <span class="add">[who holds <span class="ar">باقلآء</span> to be fem.]</span> may say <span class="arrow"><span class="ar">بُوَيْقلَةٌ↓</span></span>, suppressing the augmentative meddeh, and adding <span class="ar">ة</span> to indicate the fem. gender; <a href="#bAqlBAp">and that of <span class="ar">باقلّاة</span></a> is <span class="arrow"><span class="ar">بُوَيْقِلَاةٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">بَاقِلًّى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAqilBFe_A2">
					<p><span class="ar long">البَاقِلَّى القبْطِىُّ</span> <span class="add">[app. the same as <span class="ar long">الباقّلى المِصْرِىُّ</span> mentioned in the Ḳ voce <span class="ar">تُرْمُسٌ</span>, &amp;c., i. e. <em>The Egyptian bean;</em> an appellation said to be applied by some in the present day to <em>the colocasia;</em> but what it properly denotes is doubtful;]</span> <em>a certain plant, the grain of which is smaller than the</em> <span class="ar">فُول</span> <span class="add">[or <em>bean</em>]</span>: <span class="auth">(Ḳ:)</span> <em>the people of Egypt know it by the name of</em> <span class="ar">الجَامِسَة</span>, with <span class="ar">جيم</span>, and with the unpointed <span class="ar">سين</span>: he who says that it is the <span class="ar">تُرْمُس</span> is in error. <span class="auth">(Ibn-Beytár, cited by De Sacy in his “Relation de l'Égypte par Abd-allatif,” q. v., p. 97.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqilBieBN">
				<h3 class="entry"><span class="ar">بَاقِلِّىٌّ</span></h3>
				<div class="sense" id="baAqilBieBN_A1">
					<p><span class="ar">بَاقِلِّىٌّ</span> and <span class="ar">بَاقِلَائِىٌّ</span> rel. ns. of <span class="ar">بَاقِلّى</span> and <span class="ar">بَاقِلَآء</span>, respectively. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAquwlN">
				<h3 class="entry"><span class="ar">بَاقُولٌ</span></h3>
				<div class="sense" id="baAquwlN_A1">
					<p><span class="ar">بَاقُولٌ</span>, <span class="auth">(JK, A, O,)</span> or<span class="arrow"><span class="ar">بُوقَالٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A mug</em> (<span class="ar">كُوزٌ</span>) <em>having no</em> <span class="ar">عُرْوَة</span> <span class="add">[or <em>handle</em>]</span>; <span class="auth">(JK, O, Ḳ;)</span> <em>i. q.</em> <span class="ar">كُوبٌ</span>: <span class="auth">(A, TA:)</span> <span class="add">[in Spanish <em>bokal,</em> <span class="auth">(Golius,)</span> which favours the form in the Ḳ; but the Spanish word may be from <span class="ar">بُوقَالَةٌ</span>, if from the Arabic:]</span> pl. <span class="ar">بَوَاقِيلُ</span>. <span class="auth">(JK, A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwqaAlN">
				<h3 class="entry"><span class="ar">بُوقَالٌ</span></h3>
				<div class="sense" id="buwqaAlN_A1">
					<p><span class="ar">بُوقَالٌ</span>: <a href="#baAquwlN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwqaAlapN">
				<h3 class="entry"><span class="ar">بُوقَالَةٌ</span></h3>
				<div class="sense" id="buwqaAlapN_A1">
					<p><span class="ar">بُوقَالَةٌ</span> <em>A kind of drinking-vessel, like a</em> <span class="ar">طَاس</span>, or <em>like a</em> <span class="ar">كَأْسِ</span>; syn. <span class="ar">طَرْجَهَارَةٌ</span>. <span class="auth">(IAạr, TA.)</span> <span class="add">[<a href="#baAquwlN">See also <span class="ar">بَاقُولٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwayoqilapN">
				<h3 class="entry"><span class="ar">بُوَيْقِلَةٌ</span></h3>
				<div class="sense" id="buwayoqilapN_A1">
					<p><span class="ar">بُوَيْقِلَةٌ</span>: <a href="#baAqilBKe">see <span class="ar">بَاقِلٍّى</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwayoqilaApF">
				<h3 class="entry"><span class="ar">بُوَيْقِلَاةً</span></h3>
				<div class="sense" id="buwayoqilaApF_A1">
					<p><span class="ar">بُوَيْقِلَاةً</span>: <a href="#baAqilBKe">see <span class="ar">بَاقِلٍّى</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwayoqilaApN">
				<h3 class="entry"><span class="ar">بُوَيْقِلَاةٌ</span></h3>
				<div class="sense" id="buwayoqilaApN_A1">
					<p><span class="ar">بُوَيْقِلَاةٌ</span>: <a href="#baAqilBKe">see <span class="ar">بَاقِلٍّى</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muboqilN">
				<h3 class="entry"><span class="ar">مُبْقِلٌ</span></h3>
				<div class="sense" id="muboqilN_A1">
					<p><span class="ar">مُبْقِلٌ</span>: <a href="#baqilN">see <span class="ar">بَقِلٌ</span></a>, in three places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقل</span> - Entry: <span class="ar">مُبْقِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muboqilN_A2">
					<p><a href="#baAqilN">and see <span class="ar">بَاقِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboqalapN">
				<h3 class="entry"><span class="ar">مَبْقَلَةٌ</span></h3>
				<div class="sense" id="maboqalapN_A1">
					<p><span class="ar">مَبْقَلَةٌ</span>: <a href="#baqilN">see <span class="ar">بَقِلٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboqulapN">
				<h3 class="entry"><span class="ar">مَبْقُلَةٌ</span></h3>
				<div class="sense" id="maboqulapN_A1">
					<p><span class="ar">مَبْقُلَةٌ</span>: <a href="#baqilN">see <span class="ar">بَقِلٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0236.pdf" target="pdf">
							<span>Lanes Lexicon Page 236</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0237.pdf" target="pdf">
							<span>Lanes Lexicon Page 237</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
