<article class="root" id="Root_bdl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/044_bdE">بدع</a></span>
				<span class="ar">بدل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/046_bdn">بدن</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bdl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدل</span></h3>
				<div class="sense" id="bdl_1_A1">
					<p><span class="ar">بَدَلَ</span>, inf. n. <span class="ar">بَدَالٌ</span>: <a href="#bdl_2">see 2</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بدّل</span></h3>
				<div class="sense" id="bdl_2_A1">
					<p><span class="ar">تَبْدِيلٌ</span> properly signifies <span class="add">[The <em>changing,</em> or <em>altering,</em> a thing; or]</span> the <em>changing,</em> or <em>altering, the form,</em> or <em>fashion,</em> or <em>semblance,</em> or <em>the quality,</em> or <em>condition,</em> <span class="add">[of a thing,]</span> <em>to another form,</em>, &amp;c., <em>while the substance remains the same;</em> <span class="auth">(Th, T, TA;)</span> or the <em>changing</em> a thing <em>from its state,</em> or <em>condition;</em> <span class="auth">(Ibn-ʼArafeh, TA;)</span> or the <em>changing</em> a thing <em>without substitution:</em> <span class="auth">(Ṣ:)</span> but the Arabs have used it also in the sense of<span class="arrow"><span class="ar">إِبْدَالٌ↓</span></span>, <span class="auth">(Mbr, T, TA,)</span> which signifies <span class="add">[the <em>changing</em> a thing <em>by substitution; exchanging</em> it; <em>replacing</em> it <em>with another thing;</em> or]</span> the <em>removing,</em> or <em>displacing, the substance</em> <span class="add">[of a thing]</span>, <em>and introducing anew another substance.</em> <span class="auth">(Th, T, TA.)</span> You say, <span class="ar">بَدَّلْتُهُ</span>, inf. n. <span class="ar">تَبْدِيلٌ</span>, <span class="auth">(M,* Mṣb, Ḳ,)</span> meaning <em>I changed it,</em> or <em>altered it;</em> <span class="auth">(M, Ḳ)</span> or <em>I changed,</em> or <em>altered, the form,</em> or <em>fashion,</em> or <em>semblance,</em> or <em>the quality,</em> or <em>condition, of it;</em> <span class="auth">(Mṣb;)</span> as in the phrase, <span class="ar long">بَدَّلْتُ الخَاتَمَ بِالحَلْقَةِ</span> <span class="add">[<em>I changed,</em> or <em>altered, the signet-ring into the simple ring</em>]</span>, said when one has melted the former and made of it a simple ring; <span class="auth">(Fr, T, TA;)</span> and <span class="ar long">بَدَّلَ ٱللّٰهُ السَّيِئَّاتِ حَسَنَاتٍ</span> <span class="add">[<em>God changed the evil deeds into good deeds</em>]</span>; the verb being doubly trans. by itself because it has the meaning of <span class="ar">جَعَلَ</span> and <span class="ar">صَيَّرَ</span>. <span class="auth">(Mṣb. <span class="add">[But see what follows.]</span>)</span> <span class="arrow"><span class="ar long">أَبْدَلْتُهُ↓ بِكَذَا</span></span>, <span class="add">[in the Ṣ, <span class="ar long">أَبْدَلْتُ الشَّىْءَ بِغَيْرِهِ</span>, without explanation,]</span> inf. n. <span class="ar">إِبْدَالٌ</span>, <span class="add">[<em>I changed it by substituting for it such a thing,</em> or <em>exchanged it for such a thing,</em> or <em>replaced it with such a thing,</em>]</span> is said when one has removed the first, and put the second in its place; <span class="auth">(Mṣb;)</span> as in the phrase, <span class="ar long">أَبْدَلْتُ الخَاتَمَ بِالحَلْقَةِ</span> <span class="add">[<em>I changed the signet-ring by substituting for it the simple ring; exchanged the signet-ring for the simple ring;</em> or <em>replaced the signet-ring with the simple ring</em>]</span>; said when one removes the one, and puts the other in its place: <span class="auth">(Fr, T, TA:)</span> and this verb is also made doubly trans. by itself, like <span class="ar">بَدَّلْتُ</span>, <span class="auth">(Mṣb,)</span> which is used in the sense of <span class="ar">أَبْدَلْتُ</span> <span class="add">[as shown above]</span>; <span class="auth">(Mbr, T, TA;)</span> for instance, where it is said, <span class="add">[in the Ḳur lxvi. 5,]</span> <span class="ar long">عَسَى رَبُّهُ إِنْ طَلَّقَكُنَّ أَنْ يُبْدِلَهُ أَزْوَجًا خَيْرًا مِنْكُنَّ</span> <span class="add">[<em>May-be, his Lord, if he divorce you, will give him in exchange wives better than you</em>]</span>; accord to one reading, <span class="ar">يُبَدِّلَهُ</span> <span class="auth">(Mṣb.)</span> An ex. of the latter of these two verbs in the sense of the former is the saying in the Ḳur <span class="add">[xxv. 70]</span>, <span class="ar long">يُبَدِّلُ ٱللّٰهُ سَيِّآتِهِمْ حَسَنَاتٍ</span> <span class="add">[<em>God will change their evil deeds by substituting for them good deeds</em>]</span>; i. e. will cancel the evil deeds and put in their place good deeds: but in the saying in the Ḳur <span class="add">[iv. 59]</span>, <span class="ar long">كُلَّمَا نَضِجَتْ جُلُودُهُمْ بَدَّلْنَاهُمْ جُلُودًا غَيْرَهَا</span> <span class="add">[<em>Whenever their skins are thoroughly burned, we will change the condition thereof to them into the condition of other skins</em>]</span>, the meaning is, that the first condition of their skins shall be restored; so that the substance is one, but the condition is different. <span class="auth">(Mbr, T, TA.)</span> <span class="pb" id="Page_0168"></span>You say also, <span class="ar long">بَدَّلَهُ ٱللّٰهُ مَنَ الخَوْفِ أَمْنًا</span> <span class="add">[<em>God gave him in exchange for fear,</em> or <em>in lieu of fear, security</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[And <span class="ar long">بَدَّلَهُ بِهِ كَذَا</span> <em>He gave him in exchange for it,</em> or <em>in lieu of it, such a thing:</em> see Ḳur xxxiv. 15. And <span class="ar long">بدّل مَكَانَهُ كَذَا</span> <em>He gave in exchange for it,</em> or <em>in lieu of it, such a thing:</em> see Ḳur vii. 93 and xvi. 103.]</span> <span class="ar long">بَدَّلَ حُسْنًا بَعْدَ سُوْءٍ</span>, in the Ḳur <span class="add">[xxvii. 11]</span>, means <em>He hath done good</em> <span class="add">[<em>by way of exchange after evil</em>]</span>; i. e., <em>repented;</em> <span class="auth">(Jel;)</span> or <span class="ar long">بَدَّلَ ذَنْبُهُ بِالتَوْبَةِ</span> <span class="add">[<em>hath exchanged his sin for repentance</em>]</span>. <span class="auth">(Bḍ.)</span> <span class="ar">تَبْدِيلٌ</span> and<span class="arrow"><span class="ar">إِبْدَالٌ↓</span></span> both signify The act of <em>exchanging</em> <span class="add">[a thing for another thing]</span>; or <em>making</em> <span class="add">[a thing]</span> <em>to be a substitute</em> <span class="add">[for another thing]</span>; <span class="auth">(KL, PṢ;)</span> and so does<span class="arrow"><span class="ar">بَدَالٌ↓</span></span>. <span class="auth">(KL.)</span> You say, <span class="ar long">بدّل الشَّىْءَ مِنَ الشَىْءِ</span>, <span class="auth">(M, Ḳ,*)</span> and<span class="arrow"><span class="ar long">ابدلهُ↓ مِنْهُ</span></span>, i. e. <span class="ar long">اِتَّخَذَهُ مِنْهُ بَدلًا</span> <span class="add">[here meaning <em>He exchanged the thing for the thing;</em> or, more literally, <em>he made the thing a substitute for the thing</em>]</span>. <span class="auth">(M, Ḳ. <span class="add">[In the text of the former of these, as given in the TT, instead of <span class="ar">اِتَّخَذَهُ</span>, I find <span class="ar">تَخِذَ</span> (<a href="#IitBaxaca">a dial. var. of <span class="ar">اِتَّخَذَ</span></a>)</span> without the affixed pronoun, which is meant to be understood or is omitted inadvertently by the transcriber: and here it should be observed, that the explanation which I have rendered as above admits of another meaning, namely, <span class="ar long">أَخَذَهُ مِنْهُ بَدَلًا</span> “he took it as a substitute for it:” in the M, immediately before, <span class="ar long">أَخَذَهُ مِنْهُ بَدَلًا</span> is given as the explanation of the phrases <span class="ar long">تبدّل الشَّىْءَ</span> and <span class="ar">بِالشَّىْءِ</span>, and <span class="ar">استبدلهُ</span> and <span class="ar">بِهِ</span>: <a href="#bdl_10">see 10</a>.]</span>) You say also,<span class="arrow"><span class="ar long">بَدَلْتُ↓ الثَّوْبَ بِغَيْرِهِ</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُلُ</span>}</span></add> <span class="add">[inf. n. <span class="ar">بَدَالٌ</span>, mentioned and explained above, <em>I exchanged the garment,</em> or <em>piece of cloth, for another;</em> or <em>made it to be a substitute for another;</em>]</span> and<span class="arrow"><span class="ar long">اِسْتَبْدَلْتُهُ↓ بِغَيْرِهِ</span></span> signifies the same. <span class="auth">(Mṣb. <span class="add">[But the latter phrase has more frequently another meaning, explained below: <a href="#bdl_10">see 10</a>.]</span>)</span> <span class="add">[<span class="arrow"><span class="ar">ابدلهُ↓</span></span> in the phrases <span class="ar long">ابدلهُ كَذَا</span> as meaning <em>He changed it into,</em> or <em>substituted for it, such a thing,</em> and <span class="ar long">ابدلهُ مِنْ كَذَا</span> as meaning <em>he changed it from,</em> or <em>substituted it for, such a thing,</em> is more common than <span class="ar">بدّله</span>, which is used in the same sense; as <span class="arrow"><span class="ar">بَدَلَهُ↓</span></span> is also; for]</span> AO applies the term <span class="arrow"><span class="ar">مَبْدُولٌ↓</span></span> <span class="add">[in lieu of the more common term <span class="arrow"><span class="ar">مُبْدَلٌ↓</span></span>]</span> to a letter that is <em>changed</em> from another letter, as in <span class="ar">مَدَهْتُهُ</span> for <span class="ar">مَدَحْتُهُ</span>; and this shows that <span class="ar">بَدَلْتُ</span> is trans. <span class="add">[and signifies <em>I changed,</em>, &amp;c.]</span>. <span class="auth">(Az, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdl_3">
				<h3 class="entry">3. ⇒ <span class="ar">بادل</span></h3>
				<div class="sense" id="bdl_3_A1">
					<p><span class="ar">مُبَادَلَةٌ</span> and<span class="arrow"><span class="ar">تَبَادَلٌ↓</span></span> signify the same, <span class="auth">(Ṣ,)</span> namely, The act of <em>exchanging with another</em> or <em>others.</em> <span class="auth">(PṢ.)</span> You say, <span class="ar">بادلهُ</span>, inf. n. <span class="ar">مُبَادَلَةٌ</span> and <span class="ar">بِدَالٌ</span> <span class="add">[in the CK erroneously written with fet-ḥ to the <span class="ar">ب</span>, <em>He exchanged,</em> or <em>made an exchange, with him;</em> or]</span> <em>he gave him the like of that which he took,</em> or <em>received, from him;</em> <span class="auth">(IDrd,* M, Ḳ;)</span> for instance, a garment, or piece of cloth, in the place of another; <span class="auth">(Lth, T, Mṣb,* in explanation of the former inf. n.;)</span> and a brother in the place of a brother. <span class="auth">(Lth, T.)</span> And<span class="arrow"><span class="ar">تَبَادَلَا↓</span></span> <em>They exchanged,</em> or <em>made an exchange, each with the other;</em> or <em>each gave to the other the like of that which he took,</em> or <em>received, from him.</em> <span class="auth">(TA.)</span> <span class="ar">نُبَادِلُهْ</span>, ending a verse of El-Kulákh, means <em>for whom we would take a substitute:</em> El-Marzookee says, it is for <span class="ar long">نُبَادِلُ بِهِ النَّاسَ</span> <span class="add">[<em>for whom we would make an exchange with the people</em>]</span>; the preposition being suppressed. <span class="auth">(Ḥam p. 465.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bdl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابدل</span></h3>
				<div class="sense" id="bdl_4_A1">
					<p><span class="ar">ابدلهُ</span>, inf. n. <span class="ar">إِبْدَالٌ</span>: <a href="#bdl_2">see 2</a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبدّل</span></h3>
				<div class="sense" id="bdl_5_A1">
					<p><span class="ar">تبدّل</span> <em>It</em> <span class="auth">(a thing, M)</span> <em>became changed,</em> or <em>altered.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdl_5_A2">
					<p>In the saying of the rájiz,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَبُدِّلَتْ وَالدَّهْرُ ذُو تَبَدُّلِ</span> *</div> 
					</blockquote>
					<p>the meaning is, <span class="ar long">ذو تَبْدِيل</span> <span class="add">[i. e. the meaning of the whole is, <em>And,</em> or <em>but, she was changed,</em> or <em>altered; for time has the property of changing,</em> or <em>altering</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdl_5_B1">
					<p><a href="#bdl_10">See also 10</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bdl_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبادل</span></h3>
				<div class="sense" id="bdl_6_A1">
					<p><a href="#bdl_3">see 3</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبدل</span></h3>
				<div class="sense" id="bdl_10_A1">
					<p><span class="ar long">استبدل الشَّىْءَ</span> and <span class="ar">بِالشَّىْءِ</span>, and<span class="arrow"><span class="ar">تبدّلهُ↓</span></span> and <span class="ar">بِهِ</span>, <span class="auth">(M, Ḳ,*)</span> <em>He took a substitute,</em> or <em>a thing in exchange, for the thing.</em> <span class="auth">(M.)</span> You say, <span class="ar long">استبدل الشَّىْءَ بِغَيْرِهِ</span>, and<span class="arrow"><span class="ar long">تبدّلهُ↓ بِهِ</span></span>, <em>He took the thing</em> <span class="add">[<em>as a substitute,</em> or <em>in exchange, for another;</em> or]</span> <em>in the place of another.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">استبدل ثَوْبًا مَكَانَ ثَوْبٍ</span> <span class="add">[<em>He took a garment,</em> or <em>piece of cloth, in the place,</em> or <em>in lieu, of a garment,</em>, &amp;c.]</span>; and <span class="ar long">أَخًا مَكَانَ أَخٍ</span> <span class="add">[<em>a brother in the place,</em> or <em>in lieu, of a brother</em>]</span>. <span class="auth">(Lth, T.)</span> It is said in the Ḳur <span class="add">[ii. 58]</span>, <span class="ar long">أَتَسْتَبْدِلُونَ ٱلَّذِى هُوَ أَدْنَى بِالَّذِى هُوَ خَيْرٌ</span> <em>Will ye take in exchange that which is worse for that which is better?</em> <span class="auth">(Jel. <span class="add">[See also other exs. in the Ḳur ix. 39 and xlvii. last verse.]</span>)</span> And<span class="arrow"><span class="ar long">مَنْ يَتَبَدَّلِ↓ الكُفْرَ بِالْإِيمَانِ</span></span> <span class="add">[<em>Whoso adopteth infidelity in lieu of faith</em>]</span>. <span class="auth">(Ḳur ii. 102. <span class="add">[See also other exs. in the Ḳur iv. 2 and xxxiii. 52.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdl_10_A2">
					<p><a href="#bdl_2">See also 2</a>, last sentence but one.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bidolN">
				<h3 class="entry"><span class="ar">بِدْلٌ</span></h3>
				<div class="sense" id="bidolN_A1">
					<p><span class="ar">بِدْلٌ</span>: <a href="#badalN">see the next paragraph</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badalN">
				<h3 class="entry"><span class="ar">بَدَلٌ</span></h3>
				<div class="sense" id="badalN_A1">
					<p><span class="ar">بَدَلٌ</span> and<span class="arrow"><span class="ar">بِدْلٌ↓</span></span>, <span class="auth">(Fr, T, Ṣ, M, Mṣb, Ḳ,)</span> like <span class="ar">مَثَلٌ</span> and <span class="ar">مِثْلٌ</span>, and <span class="ar">شَبَهٌ</span> and <span class="ar">شِبْهٌ</span>, <span class="auth">(Fr, T, Ṣ,)</span> and <span class="ar">نَكَلٌ</span> and <span class="ar">نِكَلٌ</span>, the only other instances of the kind, i. e. of words of both these measures, that have been heard, accord. to AO, <span class="auth">(Ṣ, TA, <span class="add">[but in one copy of the Ṣ, I find AʼObeyd,]</span>)</span> and<span class="arrow"><span class="ar">بَدِيلٌ↓</span></span> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> all signify the same; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> namely, <em>A substitute; a thing given,</em> or <em>received,</em> or <em>put,</em> or <em>done, instead</em> of, <em>in place</em> of, <em>in lieu</em> of, or <em>in exchange</em> for, another thing; <em>a compensation;</em> syn. <span class="ar">خَلَفٌ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar">عِوَضٌ</span>: <span class="auth">(Kull:)</span> <span class="ar long">بَدَلُ الشَّىْءِ</span> <span class="add">[and <span class="ar long">البَدَلُ مِنَ الشَّىْءِ</span>]</span> and<span class="arrow"><span class="ar">بِدْلُهُ↓</span></span> and<span class="arrow"><span class="ar">بَدِيلُهُ↓</span></span> meaning <span class="ar long">الخَلَفُ مِنْهُ</span> <span class="add">[<em>the substitute for the thing;</em>, &amp;c.]</span>; <span class="auth">(M, Ḳ;)</span> i. e., another thing: <span class="auth">(Ṣ:)</span> pl. <span class="ar">أَبْدَالٌ</span>, <span class="auth">(IDrd, Mṣb, Ḳ,)</span> which, as pl. of<span class="arrow"><span class="ar">بَدِيلٌ↓</span></span>, has few parallels. <span class="auth">(IDrd, TA.)</span> Sb says, <span class="add">[making a distinction between <span class="ar">بَدَلٌ</span> and<span class="arrow"><span class="ar">بَدِيلٌ↓</span></span>,]</span> you say, <span class="ar long">إِنَّ بَدَلَكَ زَيْدٌ</span>, i. e. <em>Verily Zeyd is in thy place:</em> but if you put <span class="ar">بَدَل</span> in the place of <span class="ar">بَدِيلِ</span>, you say, <span class="ar long">إِنَّ بَدَلَكَ زَيْدٌ</span>, i. e.<span class="arrow"><span class="ar long">إِنَّ بِدَيلَكَ↓ زَيْدٌ</span></span> <span class="add">[<em>Verily thy substitute is Zeyd</em>]</span>: and a man says to another, Go thou with such a one; and he replies, <span class="ar long">مَعِىَ رَجُلٌ بَدَلُهُ</span>, i. e. <em>With me is a man who stands in his stead,</em> and is <em>in his place,</em> or who will stand, &amp;c. <span class="auth">(M.)</span> You say also, <span class="ar long">بَلَ كَذَا</span> <span class="add">[and <span class="ar long">بَدَلًا مِنْ كَذَا</span>]</span>, meaning <em>Instead of, in the place of, in lieu of,</em> or <em>in exchange for, such a thing.</em> <span class="auth">(Kull.)</span> <span class="add">[And <span class="ar long">بَدَلَ أَنْ تَفْعَلَ كَذَا</span> <em>Instead of thy doing thus.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: <span class="ar">بَدَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badalN_A2">
					<p><span class="ar">الأَبْدَالُ</span> <span class="auth">(IDrd, Ṣ, M, Ḳ, &amp;c.)</span> and <span class="ar">البُدَلَآءُ</span> <span class="auth">(TA)</span> <span class="add">[<em>The Substitutes,</em> or <em>Lieutenants;</em>]</span> <em>certain righteous persons, of whom the world is never destitute; when one dies, God substituting another in his place:</em> <span class="auth">(Ṣ:)</span> <em>certain persons by means of whom God rules the earth;</em> <span class="auth">(M, Ḳ;)</span> <em>consisting of seventy men,</em> <span class="auth">(IDrd, M, Ḳ,)</span> <em>according to their assertion, of whom the earth is never destitute;</em> <span class="auth">(IDrd, TA;)</span> <em>forty of whom are in Syria, and thirty in the other countries;</em> <span class="auth">(IDrd, M, Ḳ;)</span> <em>none of them dying without another's supplying his place,</em> <span class="auth">(M, Ḳ,)</span> <em>from the rest of mankind;</em> <span class="auth">(Ḳ;)</span> <em>and therefore they are named</em> <span class="ar">ابدال</span>: <span class="auth">(M:)</span> accord. to Abu-lBakà, as stated by El-Munáwee, it seems that they meant <span class="add">[by this appellation]</span> <em>the substitutes and successors of the prophets;</em> and accord. to some, they were <em>seven, neither more nor fewer, by means of whom God takes care of the seven climates; one being successor of Abraham</em> (<em>El-Khaleel</em>), <em>and to him pertains the first climate; the second, of Moses</em> (<em>El-Keleem</em>); <em>the third, of Aaron; the fourth, of Idrees; the fifth, of Joseph; the sixth, of Jesus; and the seventh, of Adam:</em> <span class="auth">(TA: <span class="add">[in which is also mentioned a treatise denying their existence, and disapproving of the assertion that by means of them God takes care of the earth:]</span>)</span> the sing. is <span class="ar">بَدَلٌ</span> and<span class="arrow"><span class="ar">بِدْلٌ↓</span></span>, <span class="auth">(T,)</span> or<span class="arrow"><span class="ar">بَدِيلٌ↓</span></span>. <span class="auth">(IDrd, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: <span class="ar">بَدَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badalN_A3">
					<p><span class="ar long">حُرُوفُ البَدَلِ</span> <span class="auth">(M, Ḳ)</span> <em>The letters of substitution; those which are substituted for other letters; not those which are substituted in consequence of idghám.</em> <span class="auth">(M.)</span> <span class="add">[The letters included under this appellation differ accord. to different authors: see De Sacy's Gram. Ar. 2nd ed. i. 33.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: <span class="ar">بَدَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="badalN_A4">
					<p><span class="arrow"><span class="ar">بِدْلٌ↓</span></span> <span class="auth">(Kr, M, Ḳ)</span> and <span class="ar">بَدَلٌ</span> <span class="auth">(M, Ḳ,)</span> applied to a man, also signify <em>Generous,</em> and <em>noble:</em> <span class="auth">(Kr,* M, Ḳ:)</span> and used in these senses, <span class="add">[says ISd,]</span> they are, in my opinion, not devoid of implication of the meaning of a substitute: <span class="auth">(M:)</span> the pl. is <span class="ar">أَبْدَالٌ</span> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badiylN">
				<h3 class="entry"><span class="ar">بَدِيلٌ</span></h3>
				<div class="sense" id="badiylN_A1">
					<p><span class="ar">بَدِيلٌ</span>: <a href="#badalN">see <span class="ar">بَدَلٌ</span></a>, in six places</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badBaAlN">
				<h3 class="entry"><span class="ar">بَدَّالٌ</span></h3>
				<div class="sense" id="badBaAlN_A1">
					<p><span class="ar">بَدَّالٌ</span> <em>A seller of eatables</em> <span class="auth">(AHeyth, T, Ḳ)</span> <em>of every kind:</em> thus he is called by the Arabs; <span class="auth">(AHeyth, T;)</span> because he changes one sale for another; selling one thing to-day and another to-morrow: <span class="auth">(AḤát, TA:)</span> the vulgar say, <span class="ar">بَقَّالٌ</span>. <span class="auth">(AHeyth, T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدل</span> - Entry: <span class="ar">بَدَّالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badBaAlN_A2">
					<p>Also <em>One who has no more property than is sufficient for his purchasing one thing, and who, when he sells this, buys another thing in exchange for it.</em> <span class="auth">(TA in art. <span class="ar">جدل</span>.)</span> <span class="add">[Hence,]</span> <span class="ar long">هٰذَا رَأْىُ الجَدَّالِينَ وَالبَدَّالِينَ</span> is a phrase used as meaning <em>This is flimsy opinion.</em> <span class="auth">(TA in the present art. and in art. <span class="ar">جدل</span>, <span class="add">[but in the latter without the <span class="ar">و</span>,]</span> on the authority of AHeyth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubodalN">
				<h3 class="entry"><span class="ar">مُبْدَلٌ</span></h3>
				<div class="sense" id="mubodalN_A1">
					<p><span class="ar">مُبْدَلٌ</span>: <a href="#bdl_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabodalN">
				<h3 class="entry"><span class="ar">مَبْدَلٌ</span></h3>
				<div class="sense" id="mabodalN_A1">
					<p><span class="ar">مَبْدَلٌ</span>: <a href="#bdl_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0167.pdf" target="pdf">
							<span>Lanes Lexicon Page 167</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0168.pdf" target="pdf">
							<span>Lanes Lexicon Page 168</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
