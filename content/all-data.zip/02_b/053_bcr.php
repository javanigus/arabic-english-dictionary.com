<article class="root" id="Root_bcr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/052_bcx">بذخ</a></span>
				<span class="ar">بذر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/054_bcq">بذق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bcr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بذر</span></h3>
				<div class="sense" id="bcr_1_A1">
					<p><span class="ar">بَذَرَ</span>, <span class="auth">(T, Ṣ, A, Mṣb,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُرُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَذْرٌ</span>, <span class="auth">(T, Mṣb, Ḳ,)</span> <em>He sowed</em> seed; <span class="auth">(Ṣ, TA;)</span> <em>he cast</em> grain <em>upon the ground to sow it;</em> <span class="auth">(Mṣb;)</span> <em>he cast</em> grain upon the ground, <em>scattering it;</em> <span class="auth">(A;)</span> <em>he scattered</em> seed <span class="auth">(T, MF)</span> <em>upon the ground;</em> as also<span class="arrow"><span class="ar">بذّر↓</span></span>, <span class="add">[but app. in an intensive sense,]</span> <span class="auth">(MF,)</span> inf. n. <span class="ar">تَبْذِيرٌ</span> <span class="auth">(T, MF)</span> and <span class="ar">تَبْذِرَةٌ</span>: <span class="auth">(T:)</span> this is the primary signification. <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcr_1_A2">
					<p>Also, <span class="auth">(M,)</span> inf. n. as above, <span class="auth">(M, Ḳ,)</span> <em>He sowed</em> land; <span class="auth">(M, L, Ḳ;)</span> and so<span class="arrow"><span class="ar">بذّر↓</span></span>, <span class="auth">(M, L,)</span> inf. n. <span class="ar">تَبْذِيرٌ</span>. <span class="auth">(L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bcr_1_A3">
					<p>Also, <span class="auth">(M,)</span> inf. n. as above, <span class="auth">(M, Ḳ,)</span> <em>He scattered,</em> or <em>dispersed,</em> <span class="auth">(M, Ḳ,)</span> a thing; <span class="auth">(M;)</span> and so<span class="arrow"><span class="ar">بذّر↓</span></span>, <span class="add">[or rather <em>he scattered,</em> or <em>dispersed, much,</em>]</span> inf. n. <span class="ar">تَبْذِيرٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bcr_1_A4">
					<p><span class="ar long">بَذَرَ ٱللّٰهُ الخَلْقِ</span>, <span class="auth">(M, A,)</span> inf. n. as above, <span class="auth">(M,)</span> <em>God scattered,</em> or <em>dispersed, mankind</em> <span class="auth">(M, A)</span> in the earth. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bcr_1_A5">
					<p><span class="ar long">بَذَرَ الكَلَامَ</span> ‡ <em>He disseminated, scattered,</em> or <em>diffused, talk,</em> or <em>speech,</em> <span class="auth">(Mṣb, TA,)</span> <span class="ar long">بَيْنَ النَّاسِ</span> <em>among the people,</em> or <em>mankind,</em> like as seed is scattered: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">بذّرهُ↓</span></span> <em>he did so much.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bcr_1_A6">
					<p><span class="ar long">بَذَرَتِ الأَرْضُ</span>, <span class="auth">(M, A,)</span> aor. as above, <span class="auth">(M,)</span> and so the inf. n., <span class="auth">(M, Ḳ,)</span> ‡ <em>The land put forth its plants,</em> or <em>herbage,</em> <span class="auth">(Aṣ, M, A, Ḳ,)</span> <em>in a scattered state:</em> <span class="auth">(Aṣ, M, A:)</span> or <em>put forth its</em> <span class="ar">بَذْر</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bcr_1_B1">
					<p><span class="ar">بَذُرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُرُ</span>}</span></add>, inf. n. <span class="ar">بَذَارَةٌ</span>, ‡ <em>He divulged what was secret; he revealed what he had heard.</em> <span class="auth">(T, L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bcr_1_C1">
					<p><span class="ar">بَذِرَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَرُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَذَرٌ</span>, <em>He talked much; was loquacious.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بذّر</span></h3>
				<div class="sense" id="bcr_2_A1">
					<p><a href="#bcr_1">see 1</a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcr_2_A2">
					<p><span class="ar">بذّر</span>, inf. n. <span class="ar">تَبْذِيرٌ</span>, also signifies <em>He was extravagant in expenditure;</em> and so<span class="arrow"><span class="ar">باذر↓</span></span>, inf. n. <span class="ar">مُبَاذَرَةٌ</span>: <span class="auth">(TA:)</span> or the former, <em>he dissipated,</em> or <em>squandered,</em> <span class="auth">(his wealth, or property, Ṣ, M, and any other thing, M, TA,)</span> <em>by extravagant expenditure,</em> <span class="auth">(Ṣ, M, Ḳ, TA,)</span> <em>and destroyed, consumed, wasted,</em> or <em>ruined, it:</em> <span class="auth">(M, Ḳ, TA: <span class="add">[in the CK, <span class="ar">جَرَّبَهُ</span> is here put for <span class="ar">خَرَّبَهُ</span>: in the M it is <span class="ar">أَفْسَدَهُ</span>:]</span>)</span> or <em>he expended</em> his wealth, or property, <em>so largely as not to leave of it that whereby he might subsist:</em> or <em>he expended</em> it <em>in acts of disobedience:</em> <span class="auth">(TA:)</span> or <em>he dissipated,</em> or <em>squandered,</em> his wealth, or property, <em>in a way that was not right:</em> <span class="auth">(Mṣb:)</span> or <em>in a way that did not behoove:</em> it includes the meaning of <span class="ar">أَسْرَفَ</span> in common, or conventional, acceptation, and is used in the proper sense of this latter verb: or, as some say, <span class="ar">تَبْذِيرٌ</span> denotes excess in respect of the right objects of expenditure, which is ignorance of the <span class="add">[right]</span> manner, and of things that should prevent it; and <span class="ar">إِسْرَافٌ</span> denotes excess with respect to quantity, and is ignorance of the values of the right objects. <span class="auth">(MF.)</span> <span class="add">[<a href="#bacaArBapN">See also <span class="ar">بَذَارَّةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bcr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باذر</span></h3>
				<div class="sense" id="bcr_3_A1">
					<p><a href="#bcr_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبذّر</span></h3>
				<div class="sense" id="bcr_5_A1">
					<p><span class="ar">تبذّر</span> <em>It became scattered</em> or <em>dispersed;</em> or <em>much scattered</em> or <em>dispersed.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcr_5_A2">
					<p>‡ <em>It</em> <span class="auth">(talk, or speech,)</span> <em>became much disseminated</em> or <em>scattered</em> or <em>diffused.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacorN">
				<h3 class="entry"><span class="ar">بَذْرٌ</span></h3>
				<div class="sense" id="bacorN_A1">
					<p><span class="ar">بَذْرٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">بُذْرٌ↓</span></span>, <span class="auth">(M,)</span> the former either an inf. n. used as a proper subst. or of the measure <span class="ar">فَعْلٌ</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>, <span class="auth">(Mṣb,)</span> <em>Grain that is set apart for sowing;</em> <span class="auth">(Lth, M, Ḳ;)</span> <em>any seed,</em> or <em>grain that is sown;</em> as also <span class="ar">بِزْرٌ</span> or <span class="ar">بَزْرٌ</span>: <span class="auth">(Kh, Mṣb:)</span> or <em>grain such as wheat, that is sown;</em> distinguished from <span class="ar">بزر</span>, which is applied to the seed of sweet-smelling plants and of leguminous herbs: and this distinction commonly obtains: <span class="auth">(Mṣb:)</span> or <span class="add">[so accord. to the M, but in the Ḳ “and,”]</span> the <em>first that comes forth, of seed-produce and of leguminous and other plants,</em> <span class="auth">(M, Ḳ,*)</span> <em>as long as it has but two leaves:</em> <span class="auth">(M:)</span> or <span class="ar">بَذْرٌ</span> signifies <em>any plant,</em> or <em>herbage, when just come forth from the earth:</em> <span class="auth">(M:)</span> or <em>such as has assumed a colour,</em> <span class="auth">(M, Ḳ,)</span> or <em>shown its kind</em> or <em>species:</em> <span class="auth">(M:)</span> pl. <span class="ar">بُذُورٌ</span> and <span class="ar">بِذَارٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَذْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bacorN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">بَذْرٌ</span> signifies also ‡ <em>Progeny;</em> <span class="auth">(T, M, Ḳ;)</span> and so<span class="arrow"><span class="ar">بُذَارَةٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span> One says, <span class="ar long">أِنَّ هٰؤُلَآءِ لَبَذْرُ سَوْءٍ</span> ‡ <em>Verily these are a progeny of evil,</em> or <em>an evil progeny.</em> <span class="auth">(T, A.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bucorN">
				<h3 class="entry"><span class="ar">بُذْرٌ</span></h3>
				<div class="sense" id="bucorN_A1">
					<p><span class="ar">بُذْرٌ</span>: <a href="#bacorN">see <span class="ar">بَذْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacara">
				<h3 class="entry"><span class="ar">بَذَرَ</span></h3>
				<div class="sense" id="bacara_A1">
					<p><span class="ar long">تَفَرَّقُوا شَذَرَ بَذَرَ</span> and<span class="arrow"><span class="ar long">شِذَرَ بِذَرَ↓</span></span> <em>They dispersed,</em> or <em>became dispersed, in every direction:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> <span class="add">[namely, men: and]</span> the like is said of a man's camels: <span class="auth">(Ṣ:)</span> <span class="ar">بذر</span> is an imitative sequent to <span class="ar">شذر</span>: <span class="auth">(Ṣ:)</span> some say that the <span class="ar">ب</span> in the former is a substitute for <span class="ar">م</span> <span class="add">[in <span class="ar">مَذَرَ</span> or <span class="ar">مِذَرَ</span>]</span>; but others hold that in each case the word is an original. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacirN">
				<h3 class="entry"><span class="ar">بَذِرٌ</span></h3>
				<div class="sense" id="bacirN_A1">
					<p><span class="ar">بَذِرٌ</span>: <a href="#tibocaArapN">see <span class="ar">تِبْذَارَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَذِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bacirN_A2">
					<p>Also, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَيْذَارٌ↓</span></span> and<span class="arrow"><span class="ar">بَيْذَارَة↓</span></span> and<span class="arrow"><span class="ar">تِبْذَارٌ↓</span></span> and<span class="arrow"><span class="ar">بَيْذَارَانِيٌّ↓</span></span>, <span class="auth">(Ḳ,)</span> ‡ A man <em>who talks much; loquacious;</em> <span class="auth">(M, Ḳ;)</span> and so<span class="arrow"><span class="ar long">هُذَرَةٌ بُذَرَةٌ↓</span></span> <span class="auth">(IDrd, M)</span> and<span class="arrow"><span class="ar long">هَيْذَارَةٌ بَيْذَارَةٌ↓</span></span>: <span class="auth">(M:)</span> <em>irrationally,</em> or <em>vainly,</em> or <em>frivolously, loquacious; a great babbler.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَذِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bacirN_A3">
					<p><a href="#bacuwrN">See also <span class="ar">بَذُورٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَذِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bacirN_A4">
					<p><span class="ar long">طَعَامٌ بَذِرٌ</span> <span class="add">[<em>Wheat,</em> or <em>food,</em>]</span> <em>in which is</em> <span class="ar">بُذَارَة</span>, i. e. <em>increase, redundance, exuberance, plenty,</em> or <em>abundance.</em> <span class="auth">(T,* M, L, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bicara">
				<h3 class="entry"><span class="ar">بِذَرَ</span></h3>
				<div class="sense" id="bicara_A1">
					<p><span class="ar long">شِذَرَ بِذَرَ</span>: <a href="#bacara">see <span class="ar long">شَذَرَ بَذَرَ</span>, above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bucarapN">
				<h3 class="entry"><span class="ar">بُذَرَةٌ</span></h3>
				<div class="sense" id="bucarapN_A1">
					<p><span class="ar long">هُذَرَةٌ بُذَرَةٌ</span>: <a href="#bacirN">see <span class="ar">بَذِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbucurBae">
				<h3 class="entry"><span class="ar">البُذُرَّى</span></h3>
				<div class="sense" id="AlbucurBae_A1">
					<p><span class="ar">البُذُرَّى</span> <em>What is false, vain,</em> or <em>ineffectual;</em> syn. <span class="ar">البَاطِلُ</span>: <span class="auth">(Seer, M, L, Ḳ:)</span> <span class="add">[like <span class="ar">الحُذُرَّى</span>:]</span> the radical idea denoted by it is that of dispersion. <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacuwrN">
				<h3 class="entry"><span class="ar">بَذُورٌ</span></h3>
				<div class="sense" id="bacuwrN_A1">
					<p><span class="ar">بَذُورٌ</span> <span class="auth">(Ṣ, M, A, Ḳ)</span> and<span class="arrow"><span class="ar">بَذِيرٌ↓</span></span> <span class="auth">(M, Ḳ)</span> ‡ A man <em>who divulges secrets;</em> <span class="auth">(Ṣ, M, A;)</span> as also<span class="arrow"><span class="ar">بَذِرٌ↓</span></span>, of which the fem. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَذِرَةٌ</span>}</span></add>: <span class="auth">(L:)</span> or one <em>who cannot keep his secret:</em> <span class="auth">(T, Ḳ:)</span> pl. of the first <span class="ar">بُذُرٌ</span>. <span class="auth">(T, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَذُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bacuwrN_A2">
					<p>Also, both the first and second, ‡ <em>A calumniator; a slanderer:</em> <span class="auth">(Ḳ, TA:)</span> pl. of the former as above. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baciyrN">
				<h3 class="entry"><span class="ar">بَذِيرٌ</span></h3>
				<div class="sense" id="baciyrN_A1">
					<p><span class="ar">بَذِيرٌ</span> is <span class="add">[said to be]</span> an imitative sequent to <span class="ar">كَثِيرٌ</span>; <span class="auth">(M, Ḳ;)</span> like <span class="ar">بَثِيرٌ</span>, of which it is <span class="add">[held to be]</span> a dial. var., or a corruption occasioned by mispronunciation. <span class="auth">(Fr, Ṣ.)</span> <span class="add">[But I think it is more probably syn. with <span class="arrow"><span class="ar">مَبْذُورٌ↓</span></span>, as signifying <em>Scattered,</em> or <em>dispersed,</em> like <span class="ar">نَثِيرٌ</span> in the sense of <span class="ar">مَنْثُورٌ</span>, &amp;c.; and that for this reason it is used as a corroborative of <span class="ar">كثير</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَذِيرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baciyrN_B1">
					<p><a href="#bacuwrN">See also <span class="ar">بَذُورٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bacaArapN">
				<span class="pb" id="Page_0174"></span>
				<h3 class="entry"><span class="ar">بَذَارَةٌ</span></h3>
				<div class="sense" id="bacaArapN_A1">
					<p><span class="ar">بَذَارَةٌ</span>: <a href="#bacaArBapN">see <span class="ar">بَذَارَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bucaArapN">
				<h3 class="entry"><span class="ar">بُذَارَةٌ</span></h3>
				<div class="sense" id="bucaArapN_A1">
					<p><span class="ar">بُذَارَةٌ</span> <em>Increase, redundance, exuberance, plenty,</em> or <em>abundance,</em> in wheat, or food. <span class="auth">(Lḥ,* T,* M, L, Ḳ.*)</span> You say, <span class="ar long">طَعَامٌ كَثِيرُ البُذَارَةِ</span> <em>Wheat,</em> or <em>food, in which is much increase,</em>, &amp;c. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بُذَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bucaArapN_A2">
					<p><a href="#bacorN">See also <span class="ar">بَذْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacaArBapN">
				<h3 class="entry"><span class="ar">بَذَارَّةٌ</span></h3>
				<div class="sense" id="bacaArBapN_A1">
					<p><span class="ar">بَذَارَّةٌ</span>, and sometimes <span class="arrow"><span class="ar">بَذَارَةٌ↓</span></span>, <span class="auth">(Lḥ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">يَبْذَرَةٌ↓</span></span>, <span class="auth">(AA,)</span> and<span class="arrow"><span class="ar">نَبْذَرَةٌ↓</span></span>, with <span class="ar">ن</span>, <span class="auth">(T, Ḳ,)</span> <em>i. q.</em> <span class="ar">تَبْذِيرٌ</span>, <span class="auth">(M, Ḳ,)</span> The <em>dissipating,</em> or <em>squandering, of wealth,</em> or <em>property, in a way that is not right.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayocarapN">
				<h3 class="entry"><span class="ar">بَيْذَرَةٌ</span></h3>
				<div class="sense" id="bayocarapN_A1">
					<p><span class="ar">بَيْذَرَةٌ</span>: <a href="#bacaArBapN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayocaraAnieBN">
				<h3 class="entry"><span class="ar">بَيْذَرَانِىٌّ</span></h3>
				<div class="sense" id="bayocaraAnieBN_A1">
					<p><span class="ar">بَيْذَرَانِىٌّ</span>: <a href="#bacirN">see <span class="ar">بَذِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baycaArN">
				<h3 class="entry"><span class="ar">بَيذَارٌ</span></h3>
				<div class="sense" id="baycaArN_A1">
					<p><span class="ar">بَيذَارٌ</span>: <a href="#bacirN">see <span class="ar">بَذِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayocaArapN">
				<h3 class="entry"><span class="ar">بَيْذَارَةٌ</span></h3>
				<div class="sense" id="bayocaArapN_A1">
					<p><span class="ar">بَيْذَارَةٌ</span>: <a href="#tibocaArapN">see <span class="ar">تِبْذَارَةٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">بَيْذَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayocaArapN_A2">
					<p><a href="#bacirN">and see also <span class="ar">بَذِرٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tibocaArN">
				<h3 class="entry"><span class="ar">تِبْذَارٌ</span></h3>
				<div class="sense" id="tibocaArN_A1">
					<p><span class="ar">تِبْذَارٌ</span>: <a href="#bacirN">see <span class="ar">بَذِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tibocaArapN">
				<h3 class="entry"><span class="ar">تِبْذَارَةٌ</span></h3>
				<div class="sense" id="tibocaArapN_A1">
					<p><span class="ar">تِبْذَارَةٌ</span> A man <em>who dissipates,</em> or <em>squanders, his wealth,</em> or <em>property, by extravagant expenditure, and consumes, destroys, wastes,</em> or <em>ruins, it;</em> <span class="auth">(AZ, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">مُبَذِّرٌ↓</span></span> and<span class="arrow"><span class="ar">مُبَاذِرٌ↓</span></span> and<span class="arrow"><span class="ar">بذِرٌ↓</span></span> and<span class="arrow"><span class="ar">بَيْذَارَةٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubacBirN">
				<h3 class="entry"><span class="ar">مُبَذِّرٌ</span></h3>
				<div class="sense" id="mubacBirN_A1">
					<p><span class="ar">مُبَذِّرٌ</span>: <a href="#tibocaArapN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibocaArN">
				<h3 class="entry"><span class="ar">مِبْذَارٌ</span></h3>
				<div class="sense" id="mibocaArN_A1">
					<p><span class="ar long">أَرْضٌ مِبْذَارٌ النَّبَاتِ</span> <span class="add">[or more probably <span class="ar long">مِبْذَارٌ لِلنَّبَاتِ</span>]</span> ‡ <em>Land that yields increase.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabocuwrN">
				<h3 class="entry"><span class="ar">مَبْذُورٌ</span></h3>
				<div class="sense" id="mabocuwrN_A1">
					<p><span class="ar">مَبْذُورٌ</span>: <a href="#baciyrN">see <span class="ar">بَذِيرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذر</span> - Entry: <span class="ar">مَبْذُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mabocuwrN_A2">
					<p>‡ <em>Many; much; abundant:</em> <span class="auth">(Ḳ, TA:)</span> water that is <em>abundant;</em> or <em>blessed with abundance, plenty,</em> or <em>increase.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubaAcirN">
				<h3 class="entry"><span class="ar">مُبَاذِرٌ</span></h3>
				<div class="sense" id="mubaAcirN_A1">
					<p><span class="ar">مُبَاذِرٌ</span>: <a href="#tibocArapN">see <span class="ar">تِبْذارَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="nabocarapN">
				<h3 class="entry"><span class="ar">نَبْذَرَةٌ</span></h3>
				<div class="sense" id="nabocarapN_A1">
					<p><span class="ar">نَبْذَرَةٌ</span>: <a href="#bacaArBapN">see <span class="ar">بَذَارَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0173.pdf" target="pdf">
							<span>Lanes Lexicon Page 173</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0174.pdf" target="pdf">
							<span>Lanes Lexicon Page 174</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
