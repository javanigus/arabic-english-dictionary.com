<article class="root" id="Root_bTrk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/129_bTrq">بطرق</a></span>
				<span class="ar">بطرك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/131_bTX">بطش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baTorakN">
				<h3 class="entry"><span class="ar">بَطْرَكٌ</span></h3>
				<div class="sense" id="baTorakN_A1">
					<p><span class="ar">بَطْرَكٌ</span> and <span class="ar">بِطَرْكٌ</span> <em>i. q.</em> <span class="ar">بِطْرِيقٌ</span>, <span class="auth">(Aṣ, Ḳ,)</span> i. e. <em>A leader of the Christians:</em> <span class="auth">(TA:)</span> or the <em>chief of the Magians:</em> <span class="auth">(Ḳ:)</span> <span class="add">[in the present day, the former is applied to <em>a Patriarch of a Christian church;</em> as also<span class="arrow"><span class="ar">بِطْرِيكٌ↓</span></span>: (<a href="#jaAvaliyqN">see <span class="ar">جَاثَلِيقٌ</span></a>:) pl. <span class="ar">بَطَارِكَةٌ</span> and <span class="ar">بَطَارِيكُ</span>]</span>: adventitious; not Arabic. <span class="auth">(Az, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTorakieBN">
				<h3 class="entry"><span class="add">[<span class="ar">بَطْرَكِىٌّ</span>]</span></h3>
				<div class="sense" id="baTorakieBN_A1">
					<p><span class="add">[<span class="ar">بَطْرَكِىٌّ</span> <em>Patriarchal;</em> i. e. <em>of,</em> or <em>belonging to,</em> or <em>relating to, a Patriarch of a Christian church;</em> as also<span class="arrow"><span class="ar">بِطْرِيكِىٌّ↓</span></span>: both modern terms.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTorakiyBapN">
				<h3 class="entry"><span class="add">[<span class="ar">بَطْرَكِيَّةٌ</span>]</span></h3>
				<div class="sense" id="baTorakiyBapN_A1">
					<p><span class="add">[<span class="ar">بَطْرَكِيَّةٌ</span> <em>A patriarchate;</em> i. e. the <em>office,</em> or <em>jurisdiction, of a Patriarch of a Christian church;</em> as also<span class="arrow"><span class="ar">بِطْرِيكِيَّةٌ↓</span></span>: both modern terms.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biToriykN">
				<h3 class="entry"><span class="ar">بِطْرِيكٌ</span></h3>
				<div class="sense" id="biToriykN_A1">
					<p><span class="ar">بِطْرِيكٌ</span>: <a href="#baTorakN">see <span class="ar">بَطْرَكٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biToriyikeBN">
				<h3 class="entry"><span class="ar">بِطْرِيِكىٌّ</span></h3>
				<div class="sense" id="biToriyikeBN_A1">
					<p><span class="ar">بِطْرِيِكىٌّ</span>: <a href="#baTorakieBN">see <span class="ar">بَطْرَكِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biToriyikyBahu">
				<h3 class="entry"><span class="ar">بِطْرِيِكيَّهُ</span></h3>
				<div class="sense" id="biToriyikyBahu_A1">
					<p><span class="ar">بِطْرِيِكيَّهُ</span>: <a href="#baTorakiyBapN">see <span class="ar">بَطْرَكِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0218.pdf" target="pdf">
							<span>Lanes Lexicon Page 218</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
