<article class="root" id="Root_bOh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/010_bOs">بأس</a></span>
				<span class="ar">بأه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/012_bbr">ببر</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="baOahotu">
				<h3 class="entry"><span class="ar">بَأَهْتُ</span></h3>
				<div class="sense" id="baOahotu_A1">
					<p><span class="ar long">مَا بَأَهْتُ لَهُ</span>: <a href="#bahaOa">see <span class="ar">بَهَأَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0147.pdf" target="pdf">
							<span>Lanes Lexicon Page 147</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
