<article class="root" id="Root_bDE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/122_bD">بض</a></span>
				<span class="ar">بضع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/124_bT">بط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bDE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بضع</span></h3>
				<div class="sense" id="bDE_1_A1">
					<p><span class="ar">بَضَعَهُ</span>, <span class="auth">(Ṣ, Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْضَعُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَضْعٌ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>He cut it;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> namely, flesh, or flesh-meat: <span class="auth">(Ṣ, TA:)</span> and <em>it</em> <span class="auth">(a sword)</span> <em>cut a piece off from it;</em> namely, a thing: <span class="auth">(Aṣ, Ṣ:)</span> and <em>he cut it in pieces;</em> namely, flesh, or flesh-meat: <span class="auth">(Ḳ, TA:)</span> and<span class="arrow"><span class="ar">بضّعهُ↓</span></span>, inf. n. <span class="ar">تَبْضِيعٌ</span>, has the first of these significations: <span class="auth">(Ḳ: <span class="add">[but only the inf. n. is there mentioned:]</span>)</span> or this latter signifies <em>he cut it much,</em> or <em>in several pieces,</em> or <em>in many pieces.</em> <span class="auth">(Mṣb, TA.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bDE_1_A2">
					<p><em>He slit it;</em> or <em>cut it lengthwise;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> namely, flesh, or flesh-meat, <span class="auth">(Mṣb,)</span> or a wound, <span class="auth">(Ṣ, TA,)</span> and a vein, and a hide. <span class="auth">(Ṣ.)</span></p>
				</div>
				<span class="pb" id="Page_0214"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bDE_1_A3">
					<p><span class="add">[And hence,]</span> <span class="ar">بَضَعَهَا</span>, <span class="auth">(Sb, Mṣb, TA,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْضَعُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَضْعٌ</span> <span class="auth">(Ḳ, TA)</span> and <span class="ar">بُضْعٌ</span>, like <span class="ar">شُكْرٌ</span> and <span class="ar">شُغْلٌ</span> and <span class="ar">كُفْرٌ</span>, for <span class="ar">فُعْلٌ</span> is not rare as a measure of inf. ns., <span class="auth">(Sb, TA,)</span> or accord. to some it is an inf. n. of this verb, <span class="auth">(Mṣb,)</span> but accord. to others it is a simple subst., <span class="auth">(TA,)</span> ‡ <em>Inivit eam; he lay with her,</em> or <em>compressed her;</em> <span class="auth">(Sb, Mṣb, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">باضعها↓</span></span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">مُبَاضَعَةٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بِضَاعٌ</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> because in the act which it signifies is a kind of slitting. <span class="auth">(Mgh.)</span> You say, <span class="ar long">مَلَكَ بُضْعَهَا</span>, i. e. <span class="ar">جِمَاعَهَا</span>. <span class="auth">(Mṣb.)</span> And it is said in a prov., <span class="arrow"><span class="ar long">كَمُعَلِّمَةِ أُمَّهَا البِضَاعَ↓</span></span> ‡ <span class="add">[<em>Like her who teaches her mother</em> <span class="ar">المُجَامَعَة</span>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bDE_1_A4">
					<p><span class="ar">بَضْعٌ</span> also signifies ‡ The <em>taking in marriage:</em> <span class="auth">(Ḳ, TA:)</span> and <span class="ar">بُضْعٌ</span>, as an inf. n., † The <em>making a contract of marriage.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bDE_2">
				<h3 class="entry">2. ⇒ <span class="ar">بضّع</span></h3>
				<div class="sense" id="bDE_2_A1">
					<p><a href="#bDE_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bDE_3">
				<h3 class="entry">3. ⇒ <span class="ar">باضع</span></h3>
				<div class="sense" id="bDE_3_A1">
					<p><a href="#bDE_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bDE_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابضع</span></h3>
				<div class="sense" id="bDE_4_A1">
					<p><span class="ar">ابضعها</span>, <span class="auth">(Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِبْضَاعٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> ‡ <em>He gave her in marriage.</em> <span class="auth">(Mgh, Mṣb, Ḳ.)</span> It is said in a trad., <span class="auth">(TA,)</span> <span class="ar long">تُسْتَأْمَرُ النِّسَآءُ فِى إِبْضَاعِهِنَّ</span> ‡ <em>Women shall be consulted respecting the giving them in marriage:</em> <span class="auth">(T, Mgh, Mṣb, TA:)</span> or, accord. to one relation, <span class="arrow"><span class="ar">أَبْضَاعِهِنَّ↓</span></span>, <span class="auth">(Mgh, Mṣb,)</span> which <span class="add">[virtually]</span> means the same; <span class="auth">(Mṣb;)</span> but this is a pl., namely, of <span class="ar">بُضْعٌ</span>. <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bDE_4_B1">
					<p><span class="ar long">ابضع الشَّىْءَ</span> <em>He made the thing to be</em> <span class="ar">بِضَاعَة</span> <span class="add">[i. e. <em>an article of merchandise</em>]</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> whatever it was; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">استبضعهُ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> or<span class="arrow"><span class="ar long">اِسْتَبْضَعْتُ↓ الشَّىْءَ</span></span> signifies <em>I made</em> <span class="add">[or <em>took</em>]</span> <em>the thing as</em> <span class="ar">بضاعة</span> <span class="add">[<em>an article of merchandise</em>]</span> <em>for myself:</em> and you say, <span class="ar long">أَبْضَعْتُهُ غَيْرِى</span> <span class="add">[<em>I made it,</em> or <em>gave it as, an article of merchandise to another than me</em>]</span>: <span class="auth">(Mgh, Mṣb:)</span> and <span class="ar long">ابضعهُ البِضَاعَةَ</span> <em>he gave him the article of merchandise.</em> <span class="auth">(TA.)</span> Hence the phrase, in a trad. relating to El-Medeeneh, accord. to one relation, <span class="ar long">تُبْضِعُ طِيبَهَا</span>, meaning † <em>It gives the good that it possesses</em> to its inhabitants; as explained by Z; but accord. to the relation commonly known, it is <span class="ar">تَنْصَعُ</span>, with <span class="ar">ن</span> and with the unpointed <span class="ar">ص</span>; <span class="add">[meaning “it purifies;”; <span class="auth">(L in art. <span class="ar">نصع</span>;)</span>]</span> and there are two other relations, which are <span class="ar">تَنْضَخُ</span> and <span class="ar">تَنْضَخُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bDE_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبضع</span></h3>
				<div class="sense" id="bDE_7_A1">
					<p><span class="ar">انبضع</span> <em>It was,</em> or <em>became, cut,</em> or <em>cut off.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bDE_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتضع</span></h3>
				<div class="sense" id="bDE_8_A1">
					<p><span class="ar long">ابتضع مِنْهُ</span> <em>He took,</em> or <em>received,</em> <span class="add">[<em>merchandise</em>]</span> <em>from him.</em> <span class="auth">(TA: <span class="add">[in which the word <span class="ar">بِضَاعَةً</span> requires to be supplied in the explanation, and is indicated by the context.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bDE_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبضع</span></h3>
				<div class="sense" id="bDE_10_A1">
					<p><span class="ar">اِسْتِبْضَاعٌ</span> denotes a kind of matrimonial connection practised by people in the Time of Ignorance; i. e., A woman's <em>desiring sexual intercourse with a man only to obtain offspring by him:</em> a man of them used to say to his female slave or his wife, <span class="ar long">أَرْسِلِى إِلَى فُلَان فَآسْتَبْضِعِى مِنْهُ</span> <span class="add">[<em>Send thou to such a one, and demand of him sexual intercourse to obtain offspring</em>]</span>; and he used to separate himself from her, and not touch her, until her pregnancy by that man became apparent: and this he did from a desire of obtaining generous offspring. <span class="auth">(IAth, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bDE_10_B1">
					<p><a href="#bDE_4">See also 4</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baDoEN">
				<h3 class="entry"><span class="ar">بَضْعٌ</span></h3>
				<div class="sense" id="baDoEN_A1">
					<p><span class="ar">بَضْعٌ</span>: <a href="#biDoEN">see <span class="ar">بِضْعٌ</span></a>, first sentence, and near the end: <a href="#baDoEapN">and see also <span class="ar">بَضْعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buDoEN">
				<h3 class="entry"><span class="ar">بُضْعٌ</span></h3>
				<div class="sense" id="buDoEN_A1">
					<p><span class="ar">بُضْعٌ</span> <em>Initus; sexual intercourse:</em> <span class="auth">(Mgh, Mṣb, Ḳ:)</span> a subst., <span class="auth">(Mgh, Mṣb, TA,)</span> accord. to some; but accord. to others, an inf. n.; <span class="auth">(Mṣb;)</span> held by Sb to be the latter: <span class="auth">(TA:)</span> <span class="add">[<a href="#bDE_1">see 1</a>:]</span> and <em>marriage;</em> or the <em>taking in marriage;</em> syn. <span class="ar">نِكَاحٌ</span>; <span class="auth">(ISk, Ṣ, Mṣb, TA;)</span> <span class="add">[which has also the first of the meanings given above;]</span> as in the phrase <span class="ar long">مَلَكَ فُلَانٌ بُضْعَ فُلَانَةَ</span> <span class="add">[explained above (<a href="#bDE_1">see 1</a>)]</span>: <span class="auth">(ISk, Ṣ:)</span> or, <span class="auth">(Ḳ,)</span> in this phrase, <span class="auth">(Mgh,)</span> ‡ the <em>pudendum muliebre;</em> the <em>vulva;</em> <span class="auth">(Az, Mgh, Mṣb, Ḳ,* TA;)</span> and so in the saying, in a trad., <span class="ar long">عُتِقَ بُضْعُكِ فَٱخْتَارِى</span> ‡ <em>Thy vulva hath become freed, therefore choose thou</em> whether thou wilt remain with thy husband or separate thyself from him; <span class="auth">(TA;)</span> and in the saying, <span class="ar long">تُسْتَأْمَرُ النِّسَآءُ فِى أَبْضَاعِهِنَّ</span>, accord. to those who thus relate it, others saying <span class="ar">إِبْضَاعِهِنَّ</span>; (<a href="#bDE_1">see 1</a>;) <span class="ar">أَبْضَاعٌ</span> being <a href="#buDoEN">pl. of <span class="ar">بُضْعٌ</span></a>. <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بُضْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buDoEN_A2">
					<p>Also ‡ The <em>marriage-contract.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بُضْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buDoEN_A3">
					<p>And ‡ <em>A dowry;</em> or <em>gift given to,</em> or <em>for, a bride:</em> <span class="auth">(Ḳ, TA:)</span> pl. <span class="ar">بُضُوعٌ</span>. <span class="auth">(TA.)</span> So in the saying of ʼAmr Ibn-Maadee-Kerib,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَفِى كَعْبٍ وَإِخْوَتِهَا كِلَابٍ</span> *</div> 
						<div class="star">* <span class="ar long">سَوَامِى الطَّرْفِ غَالِيَةُ البُضُوعِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And among Kaab, and their brethren Kiláb, are females lofty in look,</em> or]</span> <em>proud,</em> and <em>dear in respect of dowries.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بُضْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="buDoEN_A4">
					<p>Also † <em>Divorce:</em> <span class="auth">(Az, Ḳ:)</span> thus having two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بُضْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="buDoEN_A5">
					<p>And † The <em>authority possessed over a woman by her guardian who affiances her.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بُضْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="buDoEN_A6">
					<p>And † <em>An equal;</em> particularly as a suitor in a case of marriage: as in the saying, in a trad., <span class="ar long">هٰذَا البُضْعُ لَا يُقْرَعُ أَنْفُهُ</span> † <em>This equal's marriage shall not be refused,</em> nor shall it be desired, or wished for; <em>he shall not be rejected.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biDoEN">
				<h3 class="entry"><span class="ar">بِضْعٌ</span> / <span class="ar">بِضْعَةٌ</span></h3>
				<div class="sense" id="biDoEN_A1">
					<p><span class="ar">بِضْعٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">بَضْعٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> some of the Arabs pronouncing it with kesr, <span class="auth">(Ṣ, Mṣb,)</span> <span class="add">[<em>A number under ten;</em> and <em>an odd number,</em> meaning]</span> <em>a number between two round,</em> or <em>decimal, numbers;</em> <span class="auth">(AZ, Ḳ;)</span> <em>from one to ten</em> <span class="add">[<em>exclusive of the latter</em>]</span>; and <em>from eleven to twenty</em> <span class="add">[<em>exclusive of the latter</em>]</span>; so accord. to Mebremán; <span class="auth">(Ḳ;)</span> i. e. Moḥammad Ibn-ʼAlee Ibn-Ismá'eel the Lexicologist, Mebremán being his surname: <span class="auth">(TA:)</span> or <em>from three to nine;</em> <span class="auth">(Ṣ, Mṣb, Ḳ <span class="add">[in the first and last the ns. being in the fem. gender; but in the second, masc.]</span>;)</span> so accord. to Ḳatádeh; <span class="auth">(Mgh;)</span> <em>from three to less than ten:</em> <span class="auth">(Fr <span class="add">[the ns. of number in the masc. gender]</span>:)</span> or <em>not less than three nor more than ten;</em> <span class="auth">(Sh <span class="add">[the first n. of number in the fem. gender, and the second masc.]</span>;)</span> <em>from three to ten:</em> <span class="auth">(Mgh <span class="add">[the ns. of number in the masc. gender]</span>:)</span> or <em>to seven:</em> <span class="auth">(Mujáhid, Mgh:)</span> or <em>to five:</em> <span class="auth">(AO, Ḳ <span class="add">[the n. of number in the fem. gender]</span>:)</span> or <em>from one to four:</em> <span class="auth">(AO, O, Ḳ <span class="add">[the ns. of number in the masc. gender]</span>:)</span> or <em>to five;</em> an explanation ascribed to AO: <span class="auth">(TA:)</span> or <em>from four to nine;</em> <span class="auth">(ISd, Ḳ <span class="add">[the ns. of number fem.]</span>;)</span> and this is the signification preferred by Th: <span class="auth">(TA:)</span> or it signifies <em>five:</em> <span class="auth">(Mukátil <span class="add">[this n. of number masc.]</span>:)</span> or <em>seven;</em> <span class="auth">(Mukátil, Ḳ <span class="add">[in the Ḳ this n. of number being fem.]</span>;)</span> so accord. to some: <span class="auth">(AO:)</span> or <em>ten:</em> <span class="auth">(Eḍ-Ḍaḥḥák <span class="add">[this n. of number masc.]</span>:)</span> or <em>an undefined number;</em> <span class="ar long">غَيْرُ مَحْدُودٍ</span>; so says Ṣgh; <span class="add">[and the like is said in the Mṣb;]</span> in the Ḳ, erroneously, <span class="ar long">غَيْرُ مَعْدُودٍ</span>; <span class="auth">(TA;)</span> because it means <em>a portion,</em> <span class="auth">(Ṣgh, Ḳ,)</span> which is undefined: <span class="auth">(Ṣgh, TA:)</span> it also signifies, <em>with ten,</em> <span class="add">[in like manner; i. e. <em>ten and a number under ten;</em> or the like: as]</span> <em>from thirteen to nineteen.</em> <span class="auth">(Mṣb.)</span> When used as signifying from three to nine, <span class="auth">(Mgh, Mṣb,)</span> or to ten, or to seven, <span class="auth">(Mgh,)</span> <span class="add">[or to signify some number under ten, without another n. of number,]</span> it is masc. and fem. without variation: <span class="auth">(Mgh, Mṣb:)</span> you say <span class="ar long">بِضْعُ رِجَالٍ</span> <em>From three to nine</em> <span class="add">[&amp;c.]</span> <em>men:</em> and <span class="ar long">بِضْعُ نِسْوَةٍ</span> <em>from three to nine</em> <span class="add">[&amp;c.]</span> <em>women:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">بِضْعُ سِنِينَ</span> <em>from three to nine</em> <span class="add">[&amp;c.]</span> <em>years:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">فِى بِضْعِ سِنِينَ</span> <span class="add">[<em>in from three to nine,</em>, &amp;c., <em>years</em>]</span>: <span class="auth">(Ḳur xxx. 3:)</span> and <span class="ar long">فَلَبِثَ فِى السِّجْنِ بِضْعَ سِنِينَ</span> <span class="add">[<em>And he remained in the prison from three to nine,</em>, &amp;c., <em>years</em>]</span>. <span class="auth">(Ḳur xii. 42.)</span> But when used to denote a number above ten, <span class="auth">(Mgh, Mṣb,)</span> with a masc. n. it is with <span class="ar">ة</span>, (<span class="arrow"><span class="ar">بِضْعَة↓</span></span>,) and with a fem. n. it is without <span class="ar">ة</span>: <span class="auth">(ISk, Mgh, Mṣb, Ḳ:)</span> you say <span class="ar long">بِضْعَةَ عَشَرَ رَجُلًا</span> <em>From thirteen to nineteen</em> <span class="add">[&amp;c.]</span> <em>men:</em> and <span class="ar long">بِضْعَ عَشْرَةَ ٱمْرَأَةً</span> <em>from thirteen to nineteen</em> <span class="add">[&amp;c.]</span> <em>women:</em> <span class="auth">(Ṣ, Mgh,* TA:)</span> like as you say <span class="ar long">ثَلَاثَةَ عَشَرَ رَجُلًا</span> and <span class="ar long">ثَلَاثَ عَشْرةَ ٱمْرَأَةً</span>. <span class="auth">(Mgh.)</span> When you have passed the word denoting ten, <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[i. e.]</span> to denote a number above twenty, <span class="auth">(Mṣb,)</span> it is not used: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> you do not say <span class="ar long">بِضْعٌ وَعِشْرُونَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> but <span class="ar long">نَيِّفٌ وَعِشْرُونَ</span>; and so in the cases of the remaining numbers: <span class="auth">(Ṣ:)</span> or you do say <span class="ar long">بِضْعٌ وَعِشْرُونَ</span>: <span class="auth">(Ṣgh, Ḳ:)</span> accord. to AZ, <span class="auth">(Mṣb,)</span> you say <span class="ar long">بِضْعَةٌ وَعِشْرُونَ رَجُلًا</span> <span class="auth">(Mgh, Mṣb, Ḳ)</span> meaning <em>Twenty and odd men:</em> <span class="auth">(AZ, TA:)</span> and <span class="ar long">بِضْعٌ وَعِشْرُونَ ٱمْرَأَةً</span> <span class="auth">(Mgh, Mṣb, Ḳ)</span> meaning <em>twenty and odd women:</em> <span class="auth">(AZ, TA:)</span> but not the reverse: <span class="auth">(Ḳ:)</span> ISd says, we have not heard this, but there is no objection to it: <span class="auth">(TA:)</span> and Fr says, <span class="ar">بِضْعٌ</span> is not mentioned save with ten and twenty to ninety; <span class="auth">(IB, Ḳ;)</span> not with what exceeds this: <span class="auth">(IB:)</span> you do not say <span class="ar long">بِضْعٌ وَمِائَةٌ</span> nor <span class="ar long">بِضْعٌ وَأَلْفٌ</span>, <span class="auth">(IB, Ḳ,)</span> but <span class="ar long">مِائَةٌ وَنَيِّفٌ</span> <span class="add">[and <span class="ar long">أَلْفٌ وَنَيِّفٌ</span>]</span>: <span class="auth">(IB:)</span> it occurs in trads. with <span class="ar">عِشْرُونَ</span> and with <span class="ar">ثَلَاثُونَ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بِضْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biDoEN_A2">
					<p><span class="ar">بِضْعٌ</span> and<span class="arrow"><span class="ar">بَضْعٌ↓</span></span> also signify <em>A part,</em> or <em>portion,</em> of the night: <span class="auth">(Ḳ:)</span> <em>a time</em> thereof. <span class="auth">(Lḥ.)</span> You say, <span class="ar long">مَضَى بِضْعٌ مِنَ اللَّيْلِ</span> <span class="add">[<em>A part,</em> or <em>portion, of the night passed</em>]</span>. <span class="auth">(TA.)</span> J mentions it with <span class="ar">ص</span> <span class="add">[in the place of <span class="ar">ض</span>]</span>; and explains it by <span class="ar">جَوْشٌ</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDoEapN">
				<h3 class="entry"><span class="ar">بَضْعَةٌ</span></h3>
				<div class="sense" id="baDoEapN_A1">
					<p><span class="ar">بَضْعَةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> with fet-ḥ, other words of like meaning being with kesr, as <span class="ar">قِطْعَةٌ</span> and <span class="ar">فِلْذَةٌ</span> and <span class="ar">فِدْرَةٌ</span>, <span class="auth">(Ṣ,)</span> and sometimes with kesr, <span class="add">[<span class="arrow"><span class="ar">بِضْعَةٌ↓</span></span>,]</span> <span class="auth">(Ḳ,)</span> <span class="pb" id="Page_0215"></span>and<span class="arrow"><span class="ar">بُضْعَةٌ↓</span></span> also is mentioned, <span class="auth">(TA,)</span> of which the first is the most chaste, though EshShiháb asserts the second to be more common, <span class="auth">(TA,)</span> <em>A piece,</em> or <em>lump,</em> or <em>portion cut off;</em> <span class="auth">(TA;)</span> particularly <em>of flesh,</em> or <em>flesh-meat,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>in a compact,</em> or <em>collective, state:</em> <span class="auth">(TA:)</span> pl. <span class="arrow"><span class="ar">بَضْعٌ↓</span></span>, <span class="add">[or rather this is a coll. gen. n., of which <span class="ar">بَضْعَةٌ</span> is the n. un.,]</span> and <span class="ar">بِضَعٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> as some say, <span class="auth">(Ṣ,)</span> but this is disallowed by ʼAlee Ibn-Hamzeh, <span class="auth">(TA,)</span> <span class="add">[or it may be a correct <a href="#biDoEapN">pl. of <span class="ar">بِضْعَةٌ</span></a> agreeably with analogy,]</span> and <span class="ar">بِضَاعٌ</span>, and <span class="ar">بَضَعَاتٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> and <span class="add">[quasi-pl. n.]</span> <span class="ar">بَضِيعٌ</span>, which is extr., like <span class="ar">رَهِينٌ</span> and <span class="ar">كَلِيبٌ</span> and <span class="ar">مَعِيزٌ</span> <span class="add">[&amp;c.]</span>. <span class="auth">(TA.)</span> Hence the saying <span class="add">[of Moḥammad]</span> in a trad., <span class="ar long">فَاطِمَةُ بَضْعَةٌ مِنَّى يَرِيبُنِى مَا رَابَهَا وَيُؤْذِينِى مَا آذَاهَا</span> ‡ <em>Fátimeh is a part of me:</em> <span class="add">[<em>that displeases and disquiets me which has displeased and disquieted her, and that hurts me which has hurt her:</em>]</span> or, accord. to one relation, he said <span class="ar">بُضَيْعَةٌ</span> <span class="add">[<em>a little part</em>]</span>. <span class="auth">(TA.)</span> One says also, <span class="ar long">إِنَّ فُلَانًا لَشَدِيدُ البَضْعَةِ حَسَنُهَا</span> meaning <em>Verily such a one is corpulent and fat.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بَضْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baDoEapN_A2">
					<p><a href="#baDaEapN">See also <span class="ar">بَضَعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buDoEapN">
				<h3 class="entry"><span class="ar">بُضْعَةٌ</span></h3>
				<div class="sense" id="buDoEapN_A1">
					<p><span class="ar">بُضْعَةٌ</span>: <a href="#baDoEapN">see <span class="ar">بَضْعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biDoEapN">
				<h3 class="entry"><span class="ar">بِضْعَةٌ</span></h3>
				<div class="sense" id="biDoEapN_A1">
					<p><span class="ar">بِضْعَةٌ</span>: <a href="#baDoEapN">see <span class="ar">بَضْعَةٌ</span></a>: <a href="#biDoEN">and, as a noun of number, see <span class="ar">بِضْعٌ</span></a>, latter half of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDaEapN">
				<h3 class="entry"><span class="ar">بَضَعَةٌ</span></h3>
				<div class="sense" id="baDaEapN_A1">
					<p><span class="ar">بَضَعَةٌ</span> The <em>sound of cutting</em> of swords: occurring in the saying, <span class="ar long">سَمِعْتُ لِلسِّيَاطِ خَضَعَةً وَلِلسُّيُوفِ بَضَعَةً</span> <em>I heard a sound of falling of the whips, and a sound of cutting of the swords:</em> <span class="auth">(TA:)</span> but in the Ṣ and A in art. <span class="ar">خضع</span>, and by IB, <span class="ar">خضعة</span> and <span class="ar">بضعة</span> are written <span class="ar">خَضْعَةٌ</span> and<span class="arrow"><span class="ar">بَضْعَةٌ↓</span></span>; and IB explains the former as signifying the sounds of swords; and the latter, the <em>sounds of whips.</em> <span class="auth">(TA in art. <span class="ar">خضع</span>.)</span> <span class="add">[<a href="#baADiEN">See also <span class="ar">بَاضِعٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biDaAEN">
				<h3 class="entry"><span class="ar">بِضَاعٌ</span></h3>
				<div class="sense" id="biDaAEN_A1">
					<p><span class="ar">بِضَاعٌ</span> <span class="add">[The <em>giving and receiving merchandise;</em>]</span> a subst. from <span class="ar long">أَبْضَعَهُ البِضَاعَةَ</span> and <span class="ar long">اِبْتَضَعَ مِنْهُ</span>; <span class="add">[or rather an inf. n. of which the verb, <span class="ar">بَاضَعَ</span>, is not used;]</span> similar to <span class="ar">قِرَاضٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDiyEN">
				<h3 class="entry"><span class="ar">بَضِيعٌ</span> / <span class="ar">بَضِيعَةٌ</span></h3>
				<div class="sense" id="baDiyEN_A1">
					<p><span class="ar">بَضِيعٌ</span> <em>Flesh.</em> <span class="auth">(Aṣ, Ṣ.)</span> You say, <span class="ar long">دَابَّةٌ كَثِيرَةُ البَضِيعِ</span> <span class="auth">(Aṣ, Ṣ, TA)</span> <em>A beast abounding in what is distinct from the rest of the flesh of the thigh:</em> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَضِيعَةٌ</span>}</span></add>. <span class="auth">(TA.)</span> And <span class="ar long">رَجُلٌ خَاظِى البَضِيعِ</span> <span class="auth">(Aṣ, Ṣ)</span> <em>A fat man.</em> <span class="auth">(TA.)</span> And <span class="ar long">سَاعِدٌ خَاظى البَضِيعِ</span> <span class="add">[<em>A fore arm,</em> or <em>an upper arm,</em>]</span> <em>full of flesh.</em> <span class="auth">(IB.)</span> <span class="add">[<a href="#baDoEapN">See also <span class="ar">بَضْعَةٌ</span></a>, of which it is a quasi-pl. n.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biDaAEapN">
				<h3 class="entry"><span class="ar">بِضَاعَةٌ</span></h3>
				<div class="sense" id="biDaAEapN_A1">
					<p><span class="ar">بِضَاعَةٌ</span> <em>Merchandise;</em> or <em>an article of merchandise;</em> <span class="auth">(TA;)</span> <em>a portion of one's property which one sends for traffic;</em> <span class="auth">(Ṣ;)</span> <em>a portion of property prepared for traffic,</em> <span class="auth">(Mgh,* Mṣb,)</span> or <em>with which one traffics;</em> from <span class="ar">بَضْعٌ</span> signifying the act of “cutting,” or “cutting off;” and vulgarly pronounced <span class="ar">بُضَاعَةٌ</span>: <span class="auth">(TA:)</span> pl. <span class="ar">بَضَائِعُ</span>. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baADiEN">
				<h3 class="entry"><span class="ar">بَاضِعٌ</span></h3>
				<div class="sense" id="baADiEN_A1">
					<p><span class="ar">بَاضِعٌ</span> A sword <em>that cuts off a piece of a thing that it strikes:</em> <span class="auth">(Ṣ, TA:)</span> or a <em>sharp,</em> or <em>cutting,</em> sword: <span class="auth">(Ḳ:)</span> or a sword <em>that cuts everything:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بَضَعَةٌ</span>: <span class="auth">(Ḳ:)</span> Fr says that <span class="ar">بَضَعَةٌ</span> signifies <em>swords;</em> and <span class="ar">خَضَعَةٌ</span>, whips: but some say the reverse. <span class="auth">(TA.)</span> <span class="add">[<a href="#baDaEapN">See also <span class="ar">بَضَعَةٌ</span> above</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بَاضِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baADiEN_A2">
					<p><span class="add">[<a href="#baADiEapN">See also the next paragraph</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بَاضِعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baADiEN_B1">
					<p><span class="add">[<em>A broker who acts as an intermediary between the sellers and buyers of camels;</em>]</span> the <em>same with respect to camels as the</em> <span class="ar">دَلَّال</span> <em>with respect to houses:</em> <span class="auth">(O, L, Ḳ:)</span> or <em>one who carries the articles of merchandise of the tribe, and conveys those articles from place to place for sale:</em> <span class="auth">(Ibn-ʼAbbád, Ṣgh, Ḳ:)</span> it is said in the A that <span class="ar long">بَاضِعُ الحَىِّ</span> signifies <em>the person who carries the articles of merchandise of the tribe.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baADiEapN">
				<h3 class="entry"><span class="ar">بَاضِعَةٌ</span></h3>
				<div class="sense" id="baADiEapN_A1">
					<p><span class="ar">بَاضِعَةٌ</span> <em>A wound by which the head is broken,</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>which cuts the skin, and cleaves the flesh</em> <span class="auth">(Ṣ, Ḳ)</span> <em>in a slight degree,</em> <span class="auth">(Ḳ,)</span> <em>and brings blood, but does not make it to flow:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>which wounds the skin, and cleaves the flesh:</em> <span class="auth">(Mgh:)</span> or <em>which cleaves the flesh, but does not reach to the bone, nor cause the blood to flow:</em> <span class="auth">(Mṣb:)</span> that from which the blood flows is termed <span class="ar">دَامِيَةٌ</span> <span class="add">[app. a mistake for <span class="ar">دَامِعَةٌ</span>]</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بضع</span> - Entry: <span class="ar">بَاضِعَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baADiEapN_B1">
					<p><em>A large flock</em> (<span class="ar">فِرْقٌ</span> <span class="add">[in the CK, erroneously, <span class="ar">فِرَق</span>,]</span>) of sheep or goats: <span class="auth">(Ṣ, Ṣgh, Ḳ:)</span> or <em>a portion separated from the rest</em> of the sheep or goats: <span class="auth">(Lth, Ḳ:)</span> pl. <span class="ar">بَوَاضِعُ</span>: you say, <span class="ar long">فِرَقٌ بَوَاضِعُ</span>. <span class="auth">(Lth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboDaEu">
				<h3 class="entry"><span class="ar">أَبْضَعُ</span></h3>
				<div class="sense" id="OaboDaEu_A1">
					<p><span class="ar">أَبْضَعُ</span> as a corroborative after <span class="ar">أَجْمَعُ</span>: <a href="#OaboSaEu">see <span class="ar">أَبْصَعُ</span></a>, with the unpointed <span class="ar">ص</span>. Az says that it is an evident mistranscription. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboDaEN">
				<h3 class="entry"><span class="ar">مِبْضَعٌ</span></h3>
				<div class="sense" id="miboDaEN_A1">
					<p><span class="ar">مِبْضَعٌ</span> <em>A lancet; an instrument with which a vein is cut:</em> <span class="auth">(Ṣ, Mgh,* Ḳ, TA:)</span> and <span class="add">[<em>a currier's knife</em>]</span> <em>with which leather is cut:</em> <span class="auth">(Ṣ, TA:)</span> <span class="add">[pl. <span class="ar">مَبَاضِعُ</span>: accord. to the Mirḳát el-Loghah, as cited by Golius, it signifies <em>a farrier's fleam;</em> differing from <span class="ar">مِشْرَطٌ</span>, which signifies a surgeon's lancet: but this distinction is probably post-classical; for accord. to the TA, these two words signify the same.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboDuwEapN">
				<h3 class="entry"><span class="ar">مَبْضُوعَةٌ</span></h3>
				<div class="sense" id="maboDuwEapN_A1">
					<p><span class="ar">مَبْضُوعَةٌ</span> <span class="add">[used as a subst.]</span> <em>A bow: a bow cut</em> from a branch. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaboDiEN">
				<h3 class="entry"><span class="ar">مُسْتَبْضِعٌ</span></h3>
				<div class="sense" id="musotaboDiEN_A1">
					<p><span class="ar">مُسْتَبْضِعٌ</span>. It is said in a prov., <span class="ar long">كَمُسْتَبْضِعِ تَمْرٍ إِلَى هَجَرٍ</span> <span class="add">[<em>Like the taker of dates as merchandise to Hejer</em>]</span>; because Hejer is <span class="add">[famous as]</span> the place of production (<span class="ar">مَعْدِن</span>) of dates. <span class="auth">(Ṣ.)</span> <span class="ar">مستبضع</span> is here made trans. by means of <span class="ar">الى</span> because it has the meaning of <span class="ar">حَامِل</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0213.pdf" target="pdf">
							<span>Lanes Lexicon Page 213</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0214.pdf" target="pdf">
							<span>Lanes Lexicon Page 214</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0215.pdf" target="pdf">
							<span>Lanes Lexicon Page 215</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
