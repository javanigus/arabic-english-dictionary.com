<article class="root" id="Root_bjr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/023_bjd">بجد</a></span>
				<span class="ar">بجر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/025_bjs">بجس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bjr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بجر</span></h3>
				<div class="sense" id="bjr_1_A1">
					<p><span class="ar">يَجِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْجَرُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَجَرٌ</span>, <span class="auth">(Ṣ, M,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>had his navel,</em> or <em>the part remaining of the navel-string after it had been cut, protruding,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>elevated, and hard,</em> <span class="auth">(TA,)</span> <em>and thick at the base,</em> <span class="auth">(Ṣ, M,)</span> <em>and fleshy at the neck,</em> or <em>slender part, with wind remaining in the enlarged part.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bjr_1_A2">
					<p><em>He was,</em> or <em>became, large in the belly.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bjr_1_A3">
					<p><em>His</em> <span class="auth">(a man's, TA)</span> <em>belly became full of milk,</em> <span class="auth">(Ḳ,)</span> or <em>pure milk,</em> <span class="auth">(TA,)</span> and <em>of water, and he was not satiated;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">مَجِرَ</span>: <span class="auth">(TA:)</span> or <em>he drank much milk,</em> or <em>water, and was hardly,</em> or <em>not at all, satiated.</em> <span class="auth">(Lḥ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bajorN">
				<h3 class="entry"><span class="ar">بَجْرٌ</span></h3>
				<div class="sense" id="bajorN_A1">
					<p><span class="ar">بَجْرٌ</span>: <a href="#bujorN">see <span class="ar">بُجْرٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bujorN">
				<h3 class="entry"><span class="ar">بُجْرٌ</span></h3>
				<div class="sense" id="bujorN_A1">
					<p><span class="ar">بُجْرٌ</span> <em>A swelling,</em> or <em>inflation, of the belly;</em> as also<span class="arrow"><span class="ar">بَجَرٌ↓</span></span>: <span class="auth">(Fr, TA:)</span> or <em>prominence in the belly.</em> <span class="auth">(Ḥar p. 639.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">بُجْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bujorN_B1">
					<p><em>Evil; mischief: a great, terrible,</em> or <em>momentous, thing</em> or <em>case;</em> <span class="auth">(AZ, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَجْرٌ↓</span></span> and<span class="arrow"><span class="ar">بُجْرِىٌّ↓</span></span>: <span class="auth">(TA:)</span> <em>a wonderful thing:</em> <span class="auth">(Ḳ:)</span> <em>a calamity,</em> or <em>misfortune;</em> <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">بَجْرٌ↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">بُجْرِىٌّ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بُجْرِيَّةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> <a href="#bujorN">pl. of <span class="ar">بُجْرٌ</span></a> <span class="add">[or pl. pl., being app. pl. of the pl. of pauc. <span class="ar">أَبْجُرٌ</span>,]</span> <span class="ar">أَبَاجِرُ</span>; and pl. pl. <span class="auth">(as though pl. of the pl. <span class="ar">أَبْجَارٌ</span>, T)</span> <span class="ar">أَبَاجِيرُ</span>: <span class="auth">(Ḳ:)</span> and pl. of<span class="arrow"><span class="ar">بُجْرِىٌّ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and of <span class="arrow"><span class="ar">بُجْرِيَّةٌ↓</span></span> <span class="auth">(Ḳ)</span> <span class="ar">بَجَارِىٌّ</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say <span class="ar long">أَمْرٌ بُجْرٌ</span> <em>A great, terrible,</em> or <em>momentous, thing</em> or <em>case.</em> <span class="auth">(TA.)</span> And <span class="ar long">قَالَ هُجْرًا وَبُجْرًا</span> <span class="add">[<em>He said a foul and</em>]</span> <em>a wonderful thing.</em> <span class="auth">(TA.)</span> And <span class="ar long">إِنَّهُ لَيَجِىْءُ بِالأَبَاجِرِ</span> <em>Verily he brings to pass calamities,</em> or <em>misfortunes.</em> <span class="auth">(A.)</span> And <span class="ar long">لَقِيتُ مِنْهُ البَجَارِىَّ</span> <em>I experienced from him calamities,</em> or <em>misfortunes.</em> <span class="auth">(AZ, Ṣ.)</span> And<span class="arrow"><span class="ar long">إِنَّمَا هُوَ الفَجْرُ أَوِ البَجْرُ↓</span></span> or <span class="ar">البُجْرُ</span> <span class="add">[<em>It is only the daybreak or misfortune</em>]</span>: a saying of Aboo-Bekr; meaning, if thou wait until the daybreak shine, thou wilt see the way; but if thou journey without a guide in the darkness, it will lead thee to evil: but the saying is recited differently; with <span class="ar">البحر</span> in the place of <span class="ar">البجر</span>. <span class="auth">(L. <span class="add">[<a href="#baHorN">See <span class="ar">بَحْرٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">بُجْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bujorN_B2">
					<p><span class="add">[<a href="#bujolN">See also <span class="ar">بُجْلٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bajarN">
				<h3 class="entry"><span class="ar">بَجَرٌ</span></h3>
				<div class="sense" id="bajarN_A1">
					<p><span class="ar">بَجَرٌ</span> <a href="#bjr_1">inf. n. of 1 <span class="add">[q. v.]</span></a>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">بَجَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bajarN_A2">
					<p><a href="#bujorN">See also <span class="ar">بُجْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajarN.1">
				<h3 class="entry"><span class="ar">بَجَرٌ</span></h3>
				<div class="sense" id="bajarN.1_A1">
					<p><span class="ar">بَجَرٌ</span> A man <span class="auth">(TA)</span> <em>having his belly full of milk,</em> <span class="auth">(Ḳ,)</span> or <em>pure milk,</em> <span class="auth">(TA,)</span> and <em>of water, without being satiated:</em> <span class="auth">(Ḳ:)</span> or <em>drinking much milk,</em> or <em>water, and being hardly,</em> or <em>not at all, satiated.</em> <span class="auth">(Lḥ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajorahN">
				<h3 class="entry"><span class="ar">بَجْرَهٌ</span></h3>
				<div class="sense" id="bajorahN_A1">
					<p><span class="ar">بَجْرَهٌ</span> <em>Prominence,</em> or <em>protrusion, in the navel:</em> <span class="auth">(Mgh:)</span> or <em>largeness of the belly:</em> pl. <span class="ar">بَجَرَاتٌ</span>. <span class="auth">(Yákoot, TA.)</span> <span class="add">[<a href="#bujorapN">See what next follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bujorapN">
				<h3 class="entry"><span class="ar">بُجْرَةٌ</span></h3>
				<div class="sense" id="bujorapN_A1">
					<p><span class="ar">بُجْرَةٌ</span> <em>A tumour,</em> or <em>swelling,</em> or <em>an inflation, in the navel;</em> the like of which in the back is termed <span class="ar">عُجْرَهٌ</span>: <span class="auth">(IAạr, IAth:)</span> or the <em>part of the navel-string which remains after it has been cut, when it is thick at the base, and fleshy at the neck,</em> or <em>slender part, with wind remaining in the enlarged part;</em> as also<span class="arrow"><span class="ar">بَجَرَةٌ↓</span></span>: <span class="auth">(ISd, L:)</span> or the <em>navel,</em> <span class="auth">(L, Ḳ,)</span> of a man and of a camel, <span class="auth">(L,)</span> <em>whether large or not:</em> <span class="auth">(L, Ḳ:)</span> and <em>a knot in the belly:</em> <span class="auth">(L, Ḳ:)</span> or <em>a knotted vein in the belly;</em> the like of which in the back is termed <span class="ar">عُجْرَةً</span>: <span class="auth">(L:)</span> and <span class="auth">(as some say, L)</span> <em>a knot in the face,</em> and <em>in the neck:</em> <span class="auth">(L, Ḳ:)</span> pl. <span class="ar">بُجَرٌ</span>. <span class="auth">(L.)</span> <span class="add">[<a href="#EujorapN">See also <span class="ar">عُجْرَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">بُجْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bujorapN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">ذَكَرَ عُجَرَهُ وَبُجَرَهُ</span> ‡ <em>He mentioned his vices,</em> or <em>faults,</em> and <em>his whole state</em> or <em>case:</em> <span class="auth">(Ḳ:)</span> or <em>all his affairs; those which were apparent and those which were hidden:</em> or <em>his secrets:</em> or <em>his vices,</em> or <em>faults.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَفَضَيْتُ إِلَيْكَ بِعُجَرِى وَبُجَرِى</span> ‡ <em>I have revealed to thee my vices,</em> or <em>faults;</em> meaning, <em>my whole state</em> or <em>case.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">أَخْبَرْتُهُ بِعُجَرِى وَبُجَرِى</span> ‡ <em>I acquainted him with my vices,</em> or <em>faults, which I conceal from others,</em> by reason of my confidence in him. <span class="auth">(Aṣ.)</span> And <span class="ar long">أَشْكُو إِلَى ٱللّٰهِ عُجَرِى وَبُجَرِى</span>, said by ʼAlee, ‡ <em>I complain unto God of my sorrows and my griefs;</em> <span class="auth">(IAạr, IAth;)</span> meaning, <em>all my affairs</em> or <em>circumstances; those which are apparent and those which are hidden.</em> <span class="auth">(IAth.)</span> <span class="add">[See, again, <span class="ar">عُجْرَةٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">بُجْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bujorapN_A3">
					<p>It is said in a prov., <span class="arrow"><span class="ar long">عَيَّرَ بُجَيْرٌ↓ بُجَرَهْ نَسِىَ بُجَيْرٌ خَبَرَهْ</span></span>, meaning † <span class="add">[<em>Bujeyr cast reproach upon</em>]</span> <em>his vices,</em> or <em>faults:</em> <span class="add">[<em>Bujeyr forgot his own state</em> or <em>condition:</em>]</span> or, as some say, they were two men: <span class="add">[so that the meaning is, <em>Bujeyr reproached Bujarah:</em>, &amp;c.:]</span> <span class="auth">(Ṣ:)</span> accord. to El-Mufaddal, Bujeyr and Bujarah were two brothers, in an ancient age: but accord. to the lexicologists, the meaning is, that <em>one affected with what is termed a</em> <span class="ar">بُجْرَة</span> <em>in his navel reproached another for that which was in him.</em> <span class="auth">(Az, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bajarapN">
				<h3 class="entry"><span class="ar">بَجَرَةٌ</span></h3>
				<div class="sense" id="bajarapN_A1">
					<p><span class="ar">بَجَرَةٌ</span>: <a href="#bujorapN">see <span class="ar">بُجْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bujorieBN">
				<h3 class="entry"><span class="ar">بُجْرِىٌّ</span></h3>
				<div class="sense" id="bujorieBN_A1">
					<p><span class="ar">بُجْرِىٌّ</span>: <a href="#bujorN">see <span class="ar">بُجْرٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bujoriyBapN">
				<h3 class="entry"><span class="ar">بُجْرِيَّةٌ</span></h3>
				<div class="sense" id="bujoriyBapN_A1">
					<p><span class="ar">بُجْرِيَّةٌ</span>: <a href="#bujorN">see <span class="ar">بُجْرٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajiyrN">
				<h3 class="entry"><span class="ar">بَجِيرٌ</span></h3>
				<div class="sense" id="bajiyrN_A1">
					<p><span class="ar">بَجِيرٌ</span> is an imitative sequent to <span class="ar">كَثِيرٌ</span>. <span class="auth">(Fr, Ṣ, Ḳ.)</span> Accord. to AA, it signifies <em>Abundant,</em> or <em>much, wealth:</em> <span class="add">[or rather this seems to be the meaning of the phrase <span class="ar long">مَالٌ بَجِيرٌ</span>: for it is added,]</span> and in like manner <span class="add">[it is used in the phrase]</span>, <span class="ar long">مَكَانٌ عَمِيرٌ بَجِيرٌ</span> <span class="add">[<em>A place inhabited, peopled, well stocked with people and the like,</em> or <em>in a flourishing state,</em> and <em>large,</em> or <em>ample</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bujayorN">
				<h3 class="entry"><span class="ar">بُجَيْرٌ</span></h3>
				<div class="sense" id="bujayorN_A1">
					<p><span class="ar">بُجَيْرٌ</span>: <a href="#bujorapN">see <span class="ar">بُجْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAjirN">
				<h3 class="entry"><span class="ar">بَاجِرٌ</span></h3>
				<div class="sense" id="baAjirN_A1">
					<p><span class="ar">بَاجِرٌ</span>: <a href="#Oabojaru">see what follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabojaru">
				<h3 class="entry"><span class="ar">أَبْجَرُ</span></h3>
				<div class="sense" id="Oabojaru_A1">
					<p><span class="ar">أَبْجَرُ</span> A man <span class="auth">(Ṣ)</span> <em>having his navel,</em> or <em>the part remaining of the navel-string after its having been cut, protruding,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <em>and elevated, and hard,</em> <span class="auth">(TA,)</span> <em>and thick at the base,</em> <span class="auth">(Ṣ, M,)</span> <em>and fleshy at the neck,</em> or <em>slender part, with wind remaining in the enlarged part:</em> <span class="auth">(M:)</span> fem. <span class="ar">بَجْرَآءُ</span>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">بُجْرٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُجْرَانٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">أَبْجَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabojaru_A2">
					<p><em>Large in the belly:</em> pl. as above: and<span class="arrow"><span class="ar">بَاجِرٌ↓</span></span> signifies the same: <span class="auth">(TA:)</span> or this latter, <em>having a swollen,</em> or <em>an inflated, belly:</em> <span class="auth">(IAạr, Ḳ:)</span> or <em>having a large belly and a protruding navel:</em> and its pl. is <span class="ar">بَجَرَةٌ</span>, occurring in a trad., in which the tribe of Kureysh are described as <span class="ar long">أَشِحَّةٌ بَجَرَةٌ</span>: or <span class="ar">بجرة</span> may here mean ‡ <em>hoarders and acquirers of wealth.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">أَبْجَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabojaru_A3">
					<p>One says also <span class="ar long">حَقِيبَةٌ بَجْرَآءُ</span> † <em>A full</em> <span class="add">[<em>receptacle of the kind called</em>]</span> <span class="ar">حقيبة</span>; and <span class="ar long">صُرَرٌ بُجْرٌ</span> † <em>full purses;</em> and <span class="ar long">كِيسٌ أَعْجَزُ</span> <span class="add">[or <span class="ar">أَعْجَرُ</span>?]</span>: but they did not say, <span class="ar long">حَقِيبَةٌ عَجْزَآءُ</span> <span class="add">[or <span class="ar">عَجْرَآءُ</span>?]</span>; nor <span class="ar long">كِيسٌ أَبْجَرُ</span>; though analogy does not disagree to it: it is from <span class="ar">بُجْرٌ</span> signifying “prominence in the belly.” <span class="auth">(Ḥar p. 639.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">أَبْجَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oabojaru_A4">
					<p>And <span class="ar long">أَرْضٌ بَجْرَآءُ</span> † <em>Ground,</em> or <em>land, that is elevated,</em> <span class="auth">(Ḳ,* TA,)</span> <em>and hard.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجر</span> - Entry: <span class="ar">أَبْجَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oabojaru_A5">
					<p><span class="ar">أَبْجَرُ</span> also signifies † The <em>rope of a ship;</em> <span class="auth">(Ḳ;)</span> because of its greatness in relation to ropes in general. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0153.pdf" target="pdf">
							<span>Lanes Lexicon Page 153</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
