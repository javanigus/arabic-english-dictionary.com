<article class="root" id="Root_blq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/179_blgm">بلغم</a></span>
				<span class="ar">بلق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/181_blqE">بلقع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blq_1">
				<span class="pb" id="Page_0253"></span>
				<h3 class="entry">1. ⇒ <span class="ar">بلق</span></h3>
				<div class="sense" id="blq_1_A1">
					<p><span class="ar">بَلِقَ</span> and <span class="ar">بَلُقَ</span>: <a href="#blq_9">see 9</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blq_1_B1">
					<p><span class="ar">بَلَقَ</span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُقُ</span>}</span></add>, <span class="auth">(MSb, TA,)</span> inf. n. <span class="ar">بَلْقٌ</span>, <span class="auth">(TA,)</span> <em>He opened</em> a door <em>wholly:</em> <span class="auth">(JK, Ṣ, Ḳ:)</span> or <em>opened</em> it <em>vehemently:</em> <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar">ابلق↓</span></span> signifies the same. <span class="auth">(JK, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="blq_1_B2">
					<p>And <span class="add">[hence,]</span> <em>He devirginated,</em> or <em>defloured,</em> a girl. <span class="auth">(AA, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="blq_1_C1">
					<p>Also <em>He shut,</em> or <em>closed,</em> a door. <span class="auth">(IF, Ḳ.)</span> Thus it bears two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blq_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلق</span></h3>
				<div class="sense" id="blq_4_A1">
					<p><span class="ar">ابلق</span> <em>He</em> <span class="auth">(a stallion)</span> <em>begot offspring such as are termed</em> <span class="ar">بُلْق</span> <span class="add">[<a href="#Oabolaqu">pl. of <span class="ar">أَبْلَقُ</span>, q. v.</a>]</span>. <span class="auth">(Zj, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلق</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blq_4_B1">
					<p><a href="#blq_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blq_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبلق</span></h3>
				<div class="sense" id="blq_7_A1">
					<p><span class="ar">انبلق</span> <em>It</em> <span class="auth">(a door)</span> <em>became opened wholly:</em> <span class="auth">(JK, Ṣ, Ḳ:)</span> or <em>became opened with vehemence.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blq_9">
				<h3 class="entry">9. ⇒ <span class="ar">ابلقّ</span></h3>
				<div class="sense" id="blq_9_A1">
					<p><span class="ar">ابلقّ</span>, inf. n. <span class="ar">اِبْلِقَاقٌ</span>; <span class="auth">(IDrd, Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">ابلاقّ↓</span></span>, <span class="auth">(IDrd, Ḳ,)</span> inf. n. <span class="ar">اِبْلِيقَاقٌ</span>; <span class="auth">(IDrd, TA;)</span> and<span class="arrow"><span class="ar">ابلولق↓</span></span>, inf. n. <span class="ar">اِبْلِيلَاقٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بَلِقَ↓</span></span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَقُ</span>}</span></add>, <span class="auth">(JK, Ḳ,)</span> inf. n. <span class="ar">بَلقٌ</span>; <span class="auth">(Ḳ,* TA; <span class="add">[accord. to the CK <span class="ar">بَلقٌ</span>, but this is a mistake;]</span>)</span> and<span class="arrow"><span class="ar">بَلُقَ↓</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُقُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> but IDrd asserts only the first and second of these verbs to be known; <span class="auth">(TA;)</span> <em>He</em> <span class="auth">(a horse)</span> <em>was,</em> or <em>became,</em> <span class="ar">ابلق</span>, i. e., <em>black and white:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>white in the kind legs as high as the thighs.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blq_11">
				<h3 class="entry">11. ⇒ <span class="ar">ابلاقّ</span></h3>
				<div class="sense" id="blq_11_A1">
					<p><a href="#blq_9">see 9</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blq_12">
				<h3 class="entry">12. ⇒ <span class="ar">ابلولق</span></h3>
				<div class="sense" id="blq_12_A1">
					<p><a href="#blq_9">see 9</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaqN">
				<h3 class="entry"><span class="ar">بَلَقٌ</span></h3>
				<div class="sense" id="balaqN_A1">
					<p><span class="ar">بَلَقٌ</span> and<span class="arrow"><span class="ar">بُلْقَةٌ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> <a href="#blq_1">the former an inf. n. of <span class="ar">بَلِقَ</span></a>, <span class="auth">(Ḳ,* TA,)</span> <em>Blackness and whiteness</em> <span class="add">[<em>together,</em> generally in horses]</span>: <span class="auth">(Ṣ, Ḳ:)</span> or the <em>extension of whiteness in the hind legs of</em> a horse <em>as high as the thighs:</em> <span class="auth">(ISd, Ḳ:)</span> and the latter, <em>any colour with which white is mixed.</em> <span class="auth">(Golius on the authority of Meyd.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buloqapN">
				<h3 class="entry"><span class="ar">بُلْقَةٌ</span></h3>
				<div class="sense" id="buloqapN_A1">
					<p><span class="ar">بُلْقَةٌ</span>: <a href="#balaqN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulayqN">
				<h3 class="entry"><span class="ar">بُلَيقٌ</span></h3>
				<div class="sense" id="bulayqN_A1">
					<p><span class="ar">بُلَيقٌ</span> <a href="#Oabolaqu">a contracted dim. of <span class="ar">أَبْلَقُ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balBuwqN">
				<h3 class="entry"><span class="ar">بَلُّوقٌ</span></h3>
				<div class="sense" id="balBuwqN_A1">
					<p><span class="ar">بَلُّوقٌ</span>: <a href="#balBuwqapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balBuwqapN">
				<h3 class="entry"><span class="ar">بَلُّوقَةٌ</span></h3>
				<div class="sense" id="balBuwqapN_A1">
					<p><span class="ar">بَلُّوقَةٌ</span>, <span class="auth">(JK, Ṣ, &amp;c.,)</span> <span class="add">[said to be]</span> like <span class="ar">عَجُوزَةٌ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[but this is wrong, and is probably a mistranscription, for <span class="ar">عَجُّورَة</span>, with teshdeed and the unpointed <span class="ar">ر</span>, <a href="#EajBuwr">n. un. of <span class="ar">عَجُّور</span></a>,]</span> and with damm, <span class="add">[<span class="arrow"><span class="ar">بُلُّوقَةٌ↓</span></span>,]</span> <span class="auth">(IDrd, Ḳ,)</span> both mentioned by AA, <span class="auth">(TA,)</span> but more commonly with fet-ḥ <span class="add">[to the <span class="ar">بِ</span>]</span>, <span class="auth">(IDrd, TA,)</span> <em>A</em> <span class="add">[<em>desert such as is termed</em>]</span> <span class="ar">مَفَازَة</span>: <span class="auth">(AA, Ṣ, Ḳ:)</span> or <em>a tract of sand that gives growth to nothing except the</em> <span class="add">[<em>plant or tree called</em>]</span> <span class="ar">رُخَامَى</span>, <span class="auth">(Aṣ, Ḳ,* TA,)</span> <em>of which the</em> <span class="add">[<em>wild</em>]</span> <em>bulls are fond, and the roots of which they dig up and eat:</em> <span class="auth">(TA:)</span> or <em>a wide tract of fertile land in which no one shares with thee:</em> <span class="auth">(Fr, TA:)</span> or <em>a hard place among sands, as though it were swept, asserted by the Arabs of the desert to be of the dwellingplaces of the Jinn:</em> <span class="auth">(Aboo-Kheyreh, TA:)</span> or <em>a desert land, destitute of vegetable produce and of water,</em> or <em>of human beings, inhabited by none but Jinn:</em> <span class="auth">(TA:)</span> or <em>a level, soft land:</em> <span class="auth">(Ḳ:)</span> or <em>a place in which no trees grow:</em> <span class="auth">(JK:)</span> or <em>white places in sand, which give growth to nothing:</em> <span class="auth">(ISh, TA in art. <span class="ar">برص</span>:)</span> or <em>a piece of ground differing in colour or appearance from that which is next to it, that produces nothing whatever:</em> as also<span class="arrow"><span class="ar">بَلُّوقٌ↓</span></span>, like <span class="ar">تَنُّورٌ</span>: and, with the art. <span class="ar">ال</span>, particularly applied to a place in the district of El-Bahreyn, asserted <span class="auth">(as IDrd says, TA)</span> to be of the dwelling-places of the Jinn: <span class="auth">(Ḳ:)</span> pl. <span class="ar">بَلَالِيقُ</span>; <span class="auth">(JK, Ṣ, Ḳ;)</span> which is <em>syn. with</em> <span class="ar">مَوَامٍ</span> <span class="auth">(AʼObeyd, Ṣ)</span> and <span class="ar">سَبَارِيتٌ</span>, meaning <em>lands wherein is nothing:</em> <span class="auth">(AʼObeyd, TA:)</span> in poetry, <span class="ar">بَلَالِقُ</span> occurs as its pl. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulBuwqapN">
				<h3 class="entry"><span class="ar">بُلُّوقَةٌ</span></h3>
				<div class="sense" id="bulBuwqapN_A1">
					<p><span class="ar">بُلُّوقَةٌ</span>: <a href="#balBuwqapN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabolaqu">
				<h3 class="entry"><span class="ar">أَبْلَقُ</span></h3>
				<div class="sense" id="Oabolaqu_A1">
					<p><span class="ar">أَبْلَقُ</span>, applied to a horse, fem. <span class="ar">بَلْقَآءُ</span>, <em>Black and white:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>white in the hind legs as high as the thighs:</em> <span class="auth">(ISd, Ḳ:)</span> pl. <span class="ar">بُلْقٌ</span>: which is applied by Ru-beh to mountains: but the Arabs apply the epithet <span class="ar">ابلق</span> to a beast of the equine kind, and <span class="ar">أَبْرَقُ</span> to a mountain <span class="auth">(TA)</span> and to a sheep or goat: <span class="auth">(Lḥ, TA in art. <span class="ar">برق</span>:)</span> the former is also applied to a rope. <span class="auth">(JK.)</span> <span class="ar long">طَلَبَ الأَبْلَقَ العَقُوقَ</span> <span class="auth">(which is a prov., TA)</span> means <em>He sought an impossible thing;</em> because <span class="ar">ابلق</span> is applied to a male, and <span class="ar">عقوق</span> means pregnant: or <span class="ar long">الابلق العقوق</span> means <em>the dawn;</em> because it breaks, <span class="auth">(lit., cleaves,)</span> from <span class="ar">عَقَّهُ</span> signifying <span class="ar">شَقَّهُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0253.pdf" target="pdf">
							<span>Lanes Lexicon Page 253</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
