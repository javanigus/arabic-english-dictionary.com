<article class="root" id="Root_brvn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/060_brbT">بربط</a></span>
				<span class="ar">برثن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/062_brj">برج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="burovunN">
				<h3 class="entry"><span class="ar">بُرْثُنٌ</span></h3>
				<div class="sense" id="burovunN_A1">
					<p><span class="ar">بُرْثُنٌ</span>, of the lion, <span class="auth">(AZ, T,)</span> and of any animal of prey, <span class="auth">(AZ, Aṣ, T, Ṣ, M, Ḳ,)</span> and of birds, <span class="auth">(Aṣ, Ṣ,)</span> <span class="add">[The <em>toe;</em> i. e.]</span> <em>what corresponds to the</em> <span class="ar">إِصْبَع</span> <em>of a man;</em> <span class="auth">(AZ, Aṣ, T, Ṣ, M, Ḳ;)</span> <span class="add">[in the Lex. of Golius, as on the authority of the Ṣ, and in that of Freytag, <span class="la"><em>idem quod</em></span> <span class="ar">انملة</span> <span class="la"><em>in homine;</em></span> but this is a mistake, app. occasioned by a mistranscription in a copy of the Ṣ;]</span> and the <span class="ar">مِخْلَب</span> is its claw, i. e., nail: <span class="auth">(AZ, Aṣ, T, Ṣ:)</span> or the <em>paw</em> (<span class="ar">كَفّ</span>), <span class="auth">(M, Ḳ,)</span> <em>altogether,</em> <span class="auth">(M,)</span> <em>with the</em> <span class="ar">أَصَابِع</span> <span class="add">[or <em>toes</em>]</span>: <span class="auth">(M, Ḳ:)</span> or the <em>claw,</em> i. e. <em>nail,</em> of the lion, <span class="auth">(Lth, T, M, Ḳ,)</span> likened to the instrument for perforating leather; <span class="auth">(Lth, T;)</span> and of <span class="add">[all]</span> animals of prey, and of birds that do not prey, <em>corresponding to the</em> <span class="ar">ظُفْر</span> <em>of man:</em> Th says, of man, it is <span class="add">[termed]</span> the <span class="ar">ظُفْر</span>; of animals having the kind of foot called <span class="ar">خُفّ</span>, the <span class="ar">مَنْسِمْ</span>; of solidhoofed animals, the <span class="ar">حَافِر</span>; of cloven-hoofed animals, the <span class="ar">ظِلْف</span>; of beasts and birds of prey, the <span class="ar">مِخْلَب</span>; and of birds that do not prey, and of dogs and the like, the <span class="ar">بُرْثُن</span>; though it may be also used <span class="add">[in like manner]</span> of all animals of prey: <span class="auth">(Mṣb:)</span> <span class="add">[but properly]</span> it is of birds that do not prey, as the crow-kind, and the pigeon; <span class="auth">(M;)</span> and sometimes, of the <span class="add">[lizard called]</span> <span class="ar">ضَبّ</span>, <span class="auth">(Ṣ, M,)</span> and of the rat, or mouse, and of the jerboa: <span class="auth">(M:)</span> and is, in the pl. form, <span class="auth">(M, TA,)</span> which is <span class="ar">بَرَاثِنُ</span>, <span class="auth">(T, Ṣ, M, TA,)</span> metaphorically applied, by Sá'ideh Ibn-Jueiyeh, to the <em>fingers</em> of a man gathering honey <span class="add">[deposited by wild bees in a hollow of a rock]</span>. <span class="auth">(M,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برثن</span> - Entry: <span class="ar">بُرْثُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="burovunN_A2">
					<p><span class="ar long">بُرْثُنُ الأَسَدِ</span> also signifies † <em>A certain brand,</em> or <em>mark made with a hot iron, upon camels,</em> <span class="auth">(Ḳ, TA,)</span> <em>in the form of the claw of the lion.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برثن</span> - Entry: <span class="ar">بُرْثُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="burovunN_A3">
					<p>This, also, is the name of a sword of Marthad Ibn-'Alas. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برثن</span> - Entry: <span class="ar">بُرْثُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="burovunN_A4">
					<p><span class="add">[<span class="ar">بُرْثُنَةٌ</span> seems to signify the same as <span class="ar">بُرْثُنٌ</span> or <span class="ar">بَرَاثِنُ</span>: for]</span> Temeem are termed in a trad. the <span class="ar">بُرْثُمَة</span> and <span class="ar">بُرْجُمَة</span> of the tribes of Mudar; and El-Khaṭṭábee says that it should be the <span class="ar">بُرْثُنَة</span>, i. e. † <span class="add">[The <em>claw,</em> or]</span> the <em>claws;</em> meaning thereby their impetuous valour, and strength: but <span class="ar">برثمة</span> may be <a href="#brvnp">a dial. var. of <span class="ar">برثنة</span></a>, or the <span class="ar">م</span> may be substituted for the <span class="ar">ن</span> for the purpose of assimilation <span class="add">[to <span class="ar">برجمة</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0180.pdf" target="pdf">
							<span>Lanes Lexicon Page 180</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
