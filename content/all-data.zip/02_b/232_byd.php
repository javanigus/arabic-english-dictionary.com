<article class="root" id="Root_byd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/231_byH">بيح</a></span>
				<span class="ar">بيد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/233_byr">بير</a></span>
			</h2>
			<hr>
			<section class="entry main" id="byd_1">
				<h3 class="entry">1. ⇒ <span class="ar">بيد</span> ⇒ <span class="ar">باد</span></h3>
				<div class="sense" id="byd_1_A1">
					<p><span class="ar">بَادَ</span>, aor. <span class="ar">يَبِيدُ</span>, inf. n. <span class="ar">بَيْدٌ</span> <span class="auth">(T, Ṣ, M, &amp;c.)</span> and <span class="ar">بُيُودٌ</span> <span class="auth">(Ṣ, M, L, Mṣb, Ḳ)</span> and <span class="ar">بَيَادٌ</span> <span class="auth">(M, L, Mṣb, Ḳ)</span> and <span class="ar">بَيْدُودَةٌ</span> <span class="auth">(Lḥ, M, L, Ḳ)</span> and <span class="ar">بَوَادٌ</span> <span class="auth">(L, Ḳ)</span> and <span class="ar">بَوْدٌ</span>, <span class="auth">(CK,)</span> the last but one disapproved by MF, <span class="auth">(TA,)</span> <span class="add">[and the last equally doubtful,]</span> <em>He,</em> or <em>it, perished;</em> <span class="auth">(T, Ṣ, A, Mgh, L, Mṣb;)</span> <em>went away; passed away; became cut off,</em> or <em>extinct; came to an end.</em> <span class="auth">(M, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byd_1_A2">
					<p><span class="ar long">بَادَتِ الشَّمْسُ</span>, inf. n. <span class="ar">بُيُودٌ</span>, <em>The sun set.</em> <span class="auth">(Sb, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byd_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابيد</span> ⇒ <span class="ar">اباد</span></h3>
				<div class="sense" id="byd_4_A1">
					<p><span class="ar">أَبَادَهُمْ</span> <em>He</em> <span class="auth">(God)</span> <em>destroyed them;</em> <span class="auth">(T, Ṣ, A, Mgh,* Mṣb;)</span> <em>caused them to go away, pass away, become cut off</em> or <em>extinct,</em> or <em>come to an end.</em> <span class="auth">(M.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoda">
				<h3 class="entry"><span class="ar">بَيْدَ</span></h3>
				<div class="sense" id="bayoda_A1">
					<p><span class="ar">بَيْدَ</span>, <span class="auth">(T, Ṣ, M, L, Mughnee, Ḳ,)</span> as also<span class="arrow"><span class="ar">بَايَدَ↓</span></span>, <span class="auth">(L, Ḳ,)</span> or <span class="ar">بَائِدَ</span>, <span class="auth">(so in the Mughnee and in a MṢ. copy of the Ḳ and in the CK, and in a MṢ. copy of the Ḳ omitted,)</span> a noun inseparably prefixed to <span class="ar">أَنَّ</span> with its complement, <span class="auth">(Mughnee,)</span> used as <em>syn. with</em> <span class="ar">غَيْر</span>, <span class="auth">(Ks, T, Ṣ, M, &amp;c.,)</span> but never otherwise than in the accus. case, nor as an epithet, nor otherwise than as an exceptive in a case in which the thing excepted is disunited in kind from that from which the exception is made. <span class="auth">(Mughnee.)</span> You say, <span class="ar long">هُوَ كَثِيرُ المَالِ بَيْدَ أَنَّهُ بَخِيلٌ</span> <em>He is possessed of abundant,</em> or <em>much, wealth, but he is niggardly.</em> <span class="auth">(ISk, Ṣ, M, A, Mṣb, Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيد</span> - Entry: <span class="ar">بَيْدَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoda_A2">
					<p>Also as <em>syn. with</em> <span class="ar">عَلَى</span>, <span class="auth">(M, Ḳ,)</span> as some say; <span class="auth">(AʼObeyd, M;)</span> but to render it in the former manner is preferable. <span class="auth">(M.)</span> Accord. to some, <span class="auth">(L,)</span> it is syn. with <span class="ar">عَلَى</span> in the following trad.: <span class="ar long">نَحْنُ الآخِرُونَ السَّابِقُونَ يَوْمَ القيَامَةِ بَيْدَ أَنَّهُمْ أُوتُو الكِتَابَ مِنْ قَبْلِنَا وَأُوتِينَاهُ مِنْ بَعْدِهِمْ</span> <span class="add">[<em>We, the latter</em> people, <em>shall be those who will precede on the day of resurrection, although they were given the Scripture before us, and we were given it after them</em>]</span>: <span class="auth">(T, L:)</span> El-Umawee holds it to be so: <span class="auth">(T:)</span> but Ks says that it here signifies <span class="ar">غَيْر</span> <span class="add">[as in the former ex.]</span>: <span class="auth">(T, L: <span class="add">[and so says IHsh in the Mughnee:]</span>)</span> accord. to one recital, it is <span class="ar">بايَد</span>; <span class="auth">(L;)</span> or <span class="ar">بَائِدَ</span>; so in the Musnad of the Imám Esh-Sháfiʼee: <span class="auth">(Mughnee:)</span> IAth says, I have not found this in the classical language in the sense of <span class="ar">عَلَى</span>: some say that it is <span class="ar">بِأَيْدٍ</span>, i. e. <em>by means of strength,</em> or <em>power;</em> and that the meaning is, <em>we shall be those who will precede</em> to Paradise <em>on the day of resurrection by means of strength,</em> or <em>power,</em> given us by God. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيد</span> - Entry: <span class="ar">بَيْدَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayoda_A3">
					<p>Also, <span class="add">[accord. to some,]</span> as <em>meaning</em> <span class="ar long">مِنْ أَجْلِ</span>: <span class="auth">(L, Mughnee, Ḳ:)</span> as in the saying of Moḥammad, <span class="ar long">أَنَا أَفْصَحُ العَرَبِ بَيْدَ أَنِّى مِنْ قُرَيْشٍ وَنَشَأْتُ فِى بَنِى سَعْدٍ</span> <span class="add">[<em>I am the most chaste in speech of the Arabs because I am of the tribe of Kureysh and I grew up among the children of Saạd</em>]</span>: <span class="auth">(T, L: <span class="add">[in the Mughnee given somewhat differently:]</span>)</span> but Ibn-Málik and others say that it here, also, means <span class="ar">غير</span>, after the manner in which the latter is used in the saying <span class="add">[of a poet]</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَلَا عَيْبَ فِيهِمْ غَيْرَ أَنَّ سُيُوفَهُمْ</span> *</div> 
						<div class="star">* <span class="ar long">بِهِنَّ فُلُولٌ مِنْ قِرَاعِ الكَتَائِبِ</span> *</div> 
					</blockquote>
					<p><span class="add">[And there is no blemish in them, save that their swords have in them notches from the conflicting of the troops]</span>. <span class="auth">(Mughnee.)</span> This manner of praising is termed by Abu-l-ʼAbbás Moḥammad Ibn-Yezeed <span class="ar">اِسْتِثْبَاتٌ</span>. <span class="auth">(Ḥam p. 474.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيد</span> - Entry: <span class="ar">بَيْدَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bayoda_A4">
					<p><span class="ar">مَيْدَ</span> is also a dial. var. of the same. <span class="auth">(AʼObeyd, T, Mughnee.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayodaMCu">
				<h3 class="entry"><span class="ar">بَيْدَآءُ</span></h3>
				<div class="sense" id="bayodaMCu_A1">
					<p><span class="ar">بَيْدَآءُ</span> <em>A desert;</em> or <em>a waterless desert:</em> <span class="auth">(Ṣ, M, A, Mgh, Mṣb, Ḳ:)</span> or <em>one that is plain,</em> or <em>level, in which horses are made to run:</em> <span class="auth">(M:)</span> or <em>one wherein is nothing:</em> <span class="auth">(TA:)</span> so called, accord. to IJ, because it <span class="add">[often]</span> destroys him who alights, or sojourns, in it: <span class="auth">(M, Mṣb:*)</span> or <em>a plain tract, slightly elevated, with few trees, and without herbage, extending to the distance of a day's journey,</em> or <em>half a day's journey,</em> or <em>less, rugged and hard, and only in a country of mould,</em> or <em>clay:</em> <span class="auth">(ISh:)</span> pl. <span class="ar">بِيْدٌ</span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> it has a pl. of a form proper to epithets because it is originally an epithet: <span class="auth">(M:)</span> by rule it should be <span class="ar">بَيْدَاوَاتٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayodaAnapN">
				<h3 class="entry"><span class="ar">بَيْدَانَةٌ</span></h3>
				<div class="sense" id="bayodaAnapN_A1">
					<p><em>A she-ass;</em> a subst. applied to that animal: <span class="auth">(Ṣ:)</span> or <em>a wild she-ass:</em> <span class="auth">(M, Ḳ:)</span> or one <em>that inhabits a desert</em> (<span class="ar">بَيْدَآء</span>); <span class="auth">(T, Ḳ;)</span> <span class="add">[an epithet;]</span> not a subst. applied to the animal; J being in error in asserting it to be such: <span class="auth">(Ḳ:)</span> the <span class="add">[wild]</span> she-ass is thus called, accord. to most of the lexicologists, because it inhabits the <span class="ar">بيداء</span>; and if so, the <span class="ar">ن</span> is an augmentative letter: or, accord. to some, because it is <em>large in the body</em> (<span class="ar">البَدَن</span>); and if so, the <span class="ar">ن</span> is a radical letter: <span class="auth">(L:)</span> the pl. is <span class="ar">بَيْدَانَاتٌ</span>. <span class="auth">(L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAyada">
				<h3 class="entry"><span class="ar">بَايَدَ</span> / <span class="ar">بَائِدَ</span></h3>
				<div class="sense" id="baAyada_A1">
					<p><span class="ar">بَايَدَ</span>, or <span class="ar">بَائِدَ</span>: <a href="#baYoda">see <span class="ar">بَيْدَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0281.pdf" target="pdf">
							<span>Lanes Lexicon Page 281</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
