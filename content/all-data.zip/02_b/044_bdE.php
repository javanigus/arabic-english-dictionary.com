<article class="root" id="Root_bdE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/043_bdr">بدر</a></span>
				<span class="ar">بدع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/045_bdl">بدل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bdE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدع</span></h3>
				<div class="sense" id="bdE_1_A1">
					<p><span class="ar">بَدَعَهُ</span>: <a href="#bdE_4">see 4</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdE_1_B1">
					<p><span class="ar">بَدُعَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُعُ</span>}</span></add>, inf. n. <span class="ar">بَدَاعَةٌ</span> and <span class="ar">بُدُوعٌ</span>, <em>He became superlative in his kind;</em> or <em>it became so in its kind;</em> <span class="auth">(Ks, Ḳ;)</span> in good or in evil. <span class="auth">(Ks.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bdE_1_C1">
					<p><span class="ar">بَدِعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْدَعُ</span>}</span></add>, <em>He was,</em> or <em>became, fat.</em> <span class="auth">(Aṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdE_2">
				<h3 class="entry">2. ⇒ <span class="ar">بدّع</span></h3>
				<div class="sense" id="bdE_2_A1">
					<p><span class="ar">بدّعهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَبْدِيعٌ</span>, <span class="auth">(Ḳ,)</span> <em>He attributed to him, imputed to him, charged him with,</em> or <em>accused him of, innovation,</em> or <em>what is termed</em> <span class="ar">بِدْعَة</span>; expl. by <span class="ar long">نَسَبَهُ إِلَى البِدْعَةِ</span> <span class="add">[which means <span class="ar long">نَسَبَ إِلَيْهِ البِدْعَةَ</span>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdE_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابدع</span></h3>
				<div class="sense" id="bdE_4_A1">
					<p><span class="ar">ابدعهُ</span> <em>He originated it; invented it; devised it; excogitated it; innovated it; made it, did it, produced it, caused it to be</em> or <em>exist,</em> or <em>brought it into existence, newly, for the first time, it not having been</em> or <em>existed before, and not after the similitude of anything pre-existing;</em> syn. <span class="ar long">اِخْتَرَعَهُ لَا عَلَى مِثَالٍ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar">اسْتَخْرَجَهُ</span>, and <span class="ar">أَحْدَثَهُ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">أَبْدَأَهُ</span>; <span class="auth">(Ḳ, TA; but in both without the pronoun;)</span> as also<span class="arrow"><span class="ar">ابتدعه↓</span></span>; <span class="auth">(Mṣb;)</span> syn. <span class="ar">اِبْتَدَأَهُ</span>, and <span class="ar">أَحْدَثَهُ</span>, <span class="auth">(Mgh,)</span> and <span class="ar">أَنْشَأَهُ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar">بَدَأَهُ</span>; <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">بَدَعَهُ↓</span></span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْدَعُ</span>}</span></add>, <span class="auth">(Ḳ, TA,)</span> inf. n. <span class="ar">بَدْعٌ</span>; <span class="auth">(TA;)</span> but <span class="ar">أَبْدَعَ</span> is more commonly used than <span class="ar">بَدَعَ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">ابدع ٱللّٰهُ الخَلْقَ</span> <em>God created the creation, not after any similitude.</em> <span class="auth">(Mṣb.)</span> And in the Ḳur <span class="add">[lvii. 27]</span>, we find, <span class="arrow"><span class="ar long">وَرَهْبَانِيَّةً ٱبْتَدَعُوهَا↓</span></span> <em>And monkery which they originated,</em> or <em>innovated.</em> <span class="auth">(TA.)</span> And you say,<span class="arrow"><span class="ar long">بَدَعَ↓ الرَّكِيَّةَ</span></span>, <span class="auth">(IDrd, Ḳ,)</span> inf. n. <span class="ar">بَدْعٌ</span>, <span class="auth">(IDrd,)</span> <em>He produced,</em> or <em>fetched out, by his labour in digging, the water of the well;</em> <span class="auth">(IDrd, Ḳ;)</span> and <em>originated it;</em> or <em>made it to be for the first time, it not having been before.</em> <span class="auth">(IDrd.)</span> And <span class="ar long">ابدع الرَّجُلُ</span> <em>The man introduced an innovation,</em> or <em>what is termed a</em> <span class="ar">بِدْعَة</span>; <span class="add">[the object being understood;]</span> as also<span class="arrow"><span class="ar">ابتدع↓</span></span>. <span class="auth">(TA.)</span> And <span class="ar long">ابدع الشَّاعِرُ</span> <em>The poet produced a new saying,</em> or <em>new poetry, not after the similitude of anything preceding.</em> <span class="auth">(Ṣ,* Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdE_4_A2">
					<p><span class="ar long">ابدعت الرَّاحِلَةُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">الرِّكَابُ</span>, <span class="auth">(Ks, Mgh,)</span> <em>The ridden camel,</em> or <em>travelling camel, became fatigued,</em> or <em>jaded, and broke down,</em> or <em>perished;</em> <span class="auth">(Ks, Ṣ, Mgh, Ḳ;)</span> <em>as though doing a new thing:</em> <span class="auth">(Ks, Mgh:)</span> or the former phrase, <span class="auth">(Ḳ,)</span> followed by <span class="ar">بِهِ</span>, <span class="auth">(TA,)</span> <em>she limped</em> <span class="add">[<em>with him</em>]</span>, <em>halted,</em> or <em>was slightly lame:</em> <span class="auth">(Ḳ, TA:)</span> or <em>she lay down upon her breast in the road, by reason of emaciation or disease:</em> or <em>she ceased from going on, by reason of fatigue, or of limping, or halting, or slight lameness; as though she did a new and unaccustomed thing:</em> <span class="auth">(TA:)</span> or <span class="ar">ابداع</span> is not without limping, or halting, or slight lameness, <span class="auth">(Ḳ, TA,)</span> accord. to certain of the Arabs of the desert; but, says AO, this is not at variance with the explanations given. <span class="auth">(TA.)</span> And <span class="ar long">أُبْدِعَ بِالرَّجُلِ</span> <em>The man's camel which he rode became fatigued,</em> or <em>jaded:</em> <span class="auth">(Ṣ:)</span> or <span class="ar long">أُبْدِعَ بِفُلَانٍ</span> <span class="auth">(Mgh, Ḳ)</span> <em>such a one's camel which he rode ceased from going on, by reason of fatigue or lameness:</em> <span class="auth">(Mgh:)</span> or <em>broke down,</em> or <em>perished,</em> <span class="auth">(Ḳ, TA,)</span> or <em>became fatigued,</em> or <em>jaded,</em> <span class="auth">(TA,)</span> <em>and he became unable to prosecute his journey;</em> <span class="auth">(Ḳ, TA;)</span> and <em>his beast became so fatigued that it was left to remain where it was;</em> or <em>stood still with him.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#OuEobida">See also <span class="ar long">أُعْبِدَ بِهِ</span></a>.]</span> It is said in a proverb, <span class="ar long">إِذَا طَلَبْتَ البَاطِلَ أُبْدِعَ بِكَ</span> <span class="add">[<em>When thou seekest what is vain,</em> or <em>false, thou wilt be prevented from attaining thine object</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bdE_4_A3">
					<p><span class="ar long">أَبْدَعَ فُلَانٌ بِفُلَانٍ</span> ‡ <em>Such a one prevented such a one from attaining his wish,</em> (<span class="ar long">قَطَعَ بِهِ</span>,) <em>and abstained from aiding,</em> or <em>assisting, him, and did not undertake the accomplishment of his want,</em> <span class="auth">(Lḥ, Ḳ, TA,)</span> <em>and was not</em> <span class="add">[<em>at hand</em>]</span> <em>when he thought he would be.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bdE_4_A4">
					<p><span class="ar long">أَبْدَعَتْ حُجَّتُهُ</span> ‡ <em>His argument,</em> or <em>plea,</em> or <em>the like, was,</em> or <em>became, vain,</em> or <em>false,</em> or <em>ineffectual:</em> <span class="auth">(Aboo-Saʼeed, Ḳ:)</span> or <em>was,</em> or <em>became, weak.</em> <span class="auth">(A, TA.)</span> And <span class="ar long">أُبْدِعَتْ حُجَّتُهُ</span> ‡ <em>His argument,</em> or <em>plea,</em>, &amp;c., <em>was rendered vain,</em> or <em>ineffectual.</em> <span class="auth">(Aboo-Saʼeed, Ḳ,* TA.)</span> <span class="ar long">أَبْدَعَ بِرُّهُ بِشُكْرِى وَفَضْلُهُ وَإيجَابُهُ بِوَصْفِى</span> † <span class="add">[<em>His kindness has crippled my power of thanking, and his bounty, and the obligation which he has imposed, my power of description</em>]</span>: so in the L; but in the O and Ḳ, <span class="ar">قَصْدُهُ</span> <span class="add">[<em>his intention</em>]</span> is put in the place of <span class="ar">فضله</span>; and in the Ḳ, <span class="ar">وايجابه</span> is omitted: <span class="auth">(TA:)</span> said when one thanks another for his beneficence, acknowledging that his thanks are inadequate to his beneficence. <span class="auth">(Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0167"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdE_4_B1">
					<p><span class="ar long">ابدع بِالحَجِّ</span>, and <span class="ar">بِالسَّفَرِ</span>, <em>He determined, resolved,</em> or <em>decided, upon pilgrimage,</em> and <em>upon journeying.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bdE_4_B2">
					<p><span class="ar long">ابدع يَمِينًا</span> <em>He rendered an both binding,</em> or <em>obligatory.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bdE_4_C1">
					<p><span class="ar long">ابدعوا بِهِ</span> <em>They beat him,</em> or <em>struck him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdE_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبدّع</span></h3>
				<div class="sense" id="bdE_5_A1">
					<p><span class="ar">تبدّع</span> <em>He turned innovator.</em> <span class="auth">(O, Ḳ.)</span> Ru-beh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أِنْ كُنْتَ لِلٰهِ التَّقِىَّ الأَطْوَعَا</span> *</div> 
						<div class="star">* <span class="ar long">فَلَيْسَ وَجْهَ الحَقِّ أَنْ تَبَدَّعَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>If thou be, towards God, the pious, the very obedient, it is not the right way that thou shouldst turn innovator</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bdE_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتدع</span></h3>
				<div class="sense" id="bdE_8_A1">
					<p><a href="#bdE_4">see 4</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdE_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبدع</span></h3>
				<div class="sense" id="bdE_10_A1">
					<p><span class="ar">استبدعهُ</span> <em>He reckoned it</em> <span class="ar">بَدِيع</span> <span class="add">[i. e. <em>new, wonderful, unknown before</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidoEN">
				<h3 class="entry"><span class="ar">بِدْعٌ</span> / <span class="ar">بِدْعَةٌ</span></h3>
				<div class="sense" id="bidoEN_A1">
					<p><span class="ar">بِدْعٌ</span> <em>i. q.</em> <span class="arrow"><span class="ar">بَدِيعٌ↓</span></span>, q. v., and<span class="arrow"><span class="ar">مُبْتَدَعٌ↓</span></span>; <span class="auth">(Ṣ;)</span> <span class="add">[but generally used as an epithet in which the quality of a subst. is predominant; signifying]</span> <em>A novelty;</em> or <em>thing existing for the first time:</em> <span class="auth">(Ḳ:)</span> and <em>i. q.</em><span class="arrow"><span class="ar">بَدِيعٌ↓</span></span> and<span class="arrow"><span class="ar">مُبْتَدِعٌ↓</span></span>, <em>a first doer;</em> as though meaning <em>one who has none among his fellows to share,</em> or <em>participate, with him</em> in a thing, or an affair: <span class="auth">(Mṣb:)</span> pl. <span class="ar">أَبْدَاعٌ</span>. <span class="auth">(Akh, Ṣ.)</span> You say, <span class="ar long">فُلَانٌ بِدْعٌ فِى هٰذا الأَمْرِ</span>, <span class="auth">(Ṣ, Mṣb,)</span> i. e.<span class="arrow"><span class="ar">بَدِيعٌ↓</span></span>, <span class="auth">(Ṣ,)</span> meaning <em>Such a one is the first doer in this affair; the first who has done it.</em> <span class="auth">(Mṣb.)</span> And hence the saying in the Ḳur <span class="add">[xlvi. 8]</span>, <span class="ar long">قُلْ مَا كُنْتُ بِدْعًا مِنَ الرُّسُلِ</span> <span class="auth">(Ṣ, Mṣb, TA)</span> <em>Say thou, I am not the first who has been sent of the apostles:</em> <span class="auth">(Mṣb, TA:)</span> or the meaning is, <em>I am not an innovator among the apostles;</em> inviting you to that to which they do not invite you; or able to do that which they were not able to do: and accord. to one reading, it is <span class="arrow"><span class="ar">بِدَعًا↓</span></span>; as being <span class="add">[a sing. epithet]</span> like <span class="ar">قِيَمٌ</span>; or for <span class="ar long">ذَا بِدَعٍ</span> <span class="add">[in which the latter word <a href="#bidoEapN">is pl. of <span class="ar">بِدْعَةٌ</span></a>]</span>. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: <span class="ar">بِدْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bidoEN_A2">
					<p>Applied to a man, <span class="auth">(TA,)</span> <em>Superlative</em> <span class="auth">(Ks, Ḳ)</span> <em>in his kind</em> <span class="auth">(Ks)</span> in anything; <span class="auth">(Ḳ;)</span> in good and in evil; <span class="auth">(Ks;)</span> or in knowledge, or courage, or nobility: <span class="auth">(Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بِدْعَةٌ</span>}</span></add>: pl. of the masc. <span class="ar">أَبْدَاعٌ</span> <span class="add">[a pl. of pauc., which is also, as is said in the L, applied to women,]</span> and <span class="ar">بُدُعٌ</span> <span class="add">[a pl. of mult.]</span>; and pl. of the fem. <span class="ar">بِدَعٌ</span>. <span class="auth">(Ḳ.)</span> <span class="arrow">↓</span> A man <em>liberal in disposition;</em> syn. <span class="ar">غَمْرٌ</span>. <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: <span class="ar">بِدْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bidoEN_A3">
					<p>A <em>full</em> body. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidaEN">
				<h3 class="entry"><span class="ar">بِدَعٌ</span></h3>
				<div class="sense" id="bidaEN_A1">
					<p><span class="ar">بِدَعٌ</span>: <a href="#bidoEN">see <span class="ar">بِدْعٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: <span class="ar">بِدَعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bidaEN_A2">
					<p><a href="#bidoEapN">It is also pl. of <span class="ar">بِدْعَةٌ</span></a>, <span class="add">[both as a subst. and]</span> <a href="#bidoEN">as fem. of <span class="ar">بِدْعٌ</span></a>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidoEapN">
				<h3 class="entry"><span class="ar">بِدْعَةٌ</span></h3>
				<div class="sense" id="bidoEapN_A1">
					<p><span class="ar">بِدْعَةٌ</span> <em>An innovation; a novelty; anything originated, invented,</em> or <em>innovated; anything made, done, produced, caused to be</em> or <em>exist,</em> or <em>brought into existence, newly, for the first time, it not having been</em> or <em>existed before, and not after the similitude of anything pre-existing:</em> <span class="auth">(ISK:)</span> <em>a dissentient state</em> or <em>condition:</em> <span class="auth">(Mṣb:)</span> a subst. from <span class="ar">اِبْتِدَاعٌ</span>, like <span class="ar">رِفْعَةٌ</span> from <span class="ar">اِرْتِفَاعٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> and <span class="ar">خِلْفَةٌ</span> from <span class="ar">اِخْتِلَافٌ</span>: <span class="auth">(Mgh:)</span> subsequently and generally applied to <em>an addition,</em> or <em>an impairment, in religion:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>a novelty,</em> or <em>an innovation, in religion, after the completion</em> <span class="add">[<em>thereof</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>an opinion declining,</em> or <em>swerving, from the right way,</em> and <em>an action, innovated after</em> <span class="add">[<em>the time of</em>]</span> <em>the Prophet:</em> <span class="auth">(Lth, Ḳ:)</span> or <em>an action at variance with the Sunneh:</em> <span class="auth">(KT:)</span> <span class="add">[generally <em>a heretical innovation;</em> or <em>a new heresy:</em> but]</span> there is a <span class="ar">بدعة</span> not disapproved, termed <span class="ar long">بِدْعَةٌ مُبَاحَةٌ</span> <span class="add">[<em>an allowed,</em> or <em>allowable, innovation</em>]</span>; which is that whereof the goodness is attested by some principle in the law, or which is required to prevent some cause of evil; such as the Khaleefeh's seclusion of himself from the promiscuous classes of the people: <span class="auth">(Mṣb:)</span> there are two kinds of <span class="ar">بدعة</span>; namely <span class="ar long">بِدْعَةٌ هُدًى</span> <span class="add">[<em>an innovation of a right kind</em>]</span>, and <span class="ar long">بِدْعَةٌ ضَلَالٍ</span> <span class="add">[<em>an innovation of an erroneous kind</em>]</span>. <span class="auth">(IAth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badiyEN">
				<h3 class="entry"><span class="ar">بَدِيعٌ</span></h3>
				<div class="sense" id="badiyEN_A1">
					<p><span class="ar">بَدِيعٌ</span> <em>i. q.</em> <span class="ar">بِدْعٌ</span>, which see in three places, <span class="auth">(Ṣ, Mṣb,)</span> and<span class="arrow"><span class="ar">مُبْتَدَعٌ↓</span></span>; <span class="add">[i. e. <em>Originated; invented; innovated; made, done, produced, caused to be</em> or <em>exist,</em> or <em>brought into existence, newly, for the first time, not having been</em> or <em>existed before, and not after the similitude of anything pre-existing;</em>]</span> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>new; wonderful; unknown before.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">جِئْتَ بِأَمْرٍ بَدِيعٍ</span> <em>Thou hast done a new thing; a wonderful thing; a thing unknown before:</em> and<span class="arrow"><span class="ar long">أَمْرٌ بَادِعٌ↓</span></span> signifies <em>the same as</em> <span class="ar long">أَمْرٌ بَدِيعٌ</span>. <span class="auth">(TA.)</span> And <span class="ar long">جَآءَ بِا لبَدِيعِ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">أَتَى بِالبَدَيعِ</span>, <span class="auth">(Ḳ,)</span> said of a poet, <span class="auth">(Ṣ, Ḳ,)</span> <em>He produced a new saying,</em> or <em>new poetry, not after the similitude of anything preceding.</em> <span class="auth">(TA.)</span> And <span class="ar long">حَبْلٌ بَدشيعٌ</span> <em>A new rope:</em> <span class="auth">(AḤn:)</span> or <em>a rope begun to be twisted, not being yet a rope, but undone, then spun, then twisted again.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">زِمَامٌ بَدِيعٌ</span> <em>A new nose-rein of a camel.</em> <span class="auth">(TA.)</span> And <span class="ar long">رَكِيَّةٌ بَدِيعٌ</span> <em>A newly-dug well.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#badieoCN">See also <span class="ar">بَدِىْءٌ</span></a>.]</span> And <span class="ar">بَدِيعٌ</span> alone, <em>A skin for wine, &amp;c.:</em> <span class="auth">(Ṣ:)</span> or <em>a new skin for wine, &amp;c.:</em> <span class="auth">(Ḳ:)</span> and <em>a new skin for water or milk:</em> an epithet in which the quality of a subst. is predominant. <span class="auth">(TA.)</span> Hence the trad., <span class="ar long">إِنَّ تِهَامَةَ كَبَدِيعِ العَسَلِ حُلْوٌ أَوَّلُهُ حُلْوٌ آخِرُهُ</span> <span class="add">[<em>Verily Tihámeh is like the skin,</em> or <em>new skin, of honey: the first part thereof is sweet: the last part thereof is sweet</em>]</span>: <span class="auth">(Ṣ, Ḳ *:)</span> because honey does not change in flavour, whereas milk does change. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: <span class="ar">بَدِيعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badiyEN_A2">
					<p><em>Fat;</em> as an epithet: <span class="auth">(Aṣ, Ḳ:)</span> pl. <span class="ar">بُدْعٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدع</span> - Entry: <span class="ar">بَدِيعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badiyEN_B1">
					<p>Also <em>i. q.</em><span class="arrow"><span class="ar">مُبْتَدِعٌ↓</span></span> <span class="add">[<em>An originator, inventor,</em> or <em>innovator; one who makes, does, produces, causes to be</em> or <em>exist,</em> or <em>brings into existence, newly, for the first time, and not after the similitude of anything pre-existing</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> of the measure <span class="ar">فَعِيلٌ</span> in the sense of the measure <span class="ar">فَاعِلٌ</span>, like <span class="ar">قَدِيرٌ</span> in the sense of <span class="ar">قَادِرٌ</span>; from <span class="ar">بَدَعَ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#bidoEN">See also <span class="ar">بِدْعٌ</span></a>.]</span> You say, <span class="ar long">اَللّٰهُ بَدِيعٌ السَّمٰوَاتِ وَالأَرْضِ</span> <em>God is the Creator of the heavens and the earth, not after the similitude of anything pre-existing.</em> <span class="auth">(Aboo-Is-ḥáḳ, Ṣ.*)</span> And hence <span class="ar">البَدِيعُ</span> is a name of God, meaning <em>The Originator of the creation, according to his own will, not after the similitude of anything pre-existing.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badiyEapN">
				<h3 class="entry"><span class="add">[<span class="ar">بَدِيعَةٌ</span>]</span></h3>
				<div class="sense" id="badiyEapN_A1">
					<p><span class="add">[<span class="ar">بَدِيعَةٌ</span> <em>A new,</em> and <em>an admirable,</em> or <em>a wonderful, thing;</em> and especially such in speech, or language, in poetry, and in answering, or replying: pl. <span class="ar">بَدَائِعُ</span>: see an ex. voce <span class="ar">بَدِيهَةٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAdiEN">
				<h3 class="entry"><span class="ar">بَادِعٌ</span></h3>
				<div class="sense" id="baAdiEN_A1">
					<p><span class="ar">بَادِعٌ</span>: <a href="#badiyEN">see <span class="ar">بَدِيعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotadaEN">
				<h3 class="entry"><span class="ar">مُبْتَدَعٌ</span></h3>
				<div class="sense" id="mubotadaEN_A1">
					<p><span class="ar">مُبْتَدَعٌ</span>: <a href="#bidoEN">see <span class="ar">بِدْعٌ</span></a> <a href="#badiyEN">and <span class="ar">بَدِيعٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotadiEN">
				<h3 class="entry"><span class="ar">مُبْتَدِعٌ</span></h3>
				<div class="sense" id="mubotadiEN_A1">
					<p><span class="ar">مُبْتَدِعٌ</span>: <a href="#bidoEN">see <span class="ar">بِدْعٌ</span></a> <a href="#badiyEN">and <span class="ar">بَدِيعٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0166.pdf" target="pdf">
							<span>Lanes Lexicon Page 166</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0167.pdf" target="pdf">
							<span>Lanes Lexicon Page 167</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
