<article class="root" id="Root_bbr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/011_bOh">بأه</a></span>
				<span class="ar">ببر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/013_bbg">ببغ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baborN">
				<h3 class="entry"><span class="ar">بَبْرٌ</span></h3>
				<div class="sense" id="baborN_A1">
					<p><span class="ar">بَبْرٌ</span> <em>A certain beast of prey,</em> <span class="auth">(M, Ḳ,)</span> <em>well known;</em> <span class="auth">(Ḳ;)</span> <em>a certain animal,</em> <span class="auth">(Mṣb,)</span> namely, the <span class="ar">فُرَانِق</span> <span class="add">[or <em>lion's provider</em>]</span>, <span class="auth">(Ṣ,)</span> <em>that emulates,</em> or <em>vies with, the lion in running,</em> or <em>that is hostile to the lion:</em> <span class="add">[so may be rendered the words <span class="ar long">يُعَادِى الأَسَدَ</span>; and in the uncertainty that exists respecting the animal in question, the meaning of this expression is doubtful: an animal may be called <span class="auth">(as the jackal is)</span> the lion's provider merely because the lion follows it and deprives it of its prey:]</span> <span class="auth">(Ṣ, Mṣb:)</span> or <em>a certain Indian animal, stronger than the lion, between which and the lion and leopard,</em> or <em>panther,</em> (<span class="ar">نَمِر</span>,) <em>exists hostility</em> (<span class="ar">مُعَادَاةٌ</span>); <em>when it attacks the leopard,</em> or <em>panther,</em> (<span class="ar">نمر</span>,), <em>the lion aids the latter; but the scorpion is on friendly terms with it, and sometimes makes its abode in its hair:</em> <span class="auth">(Ḳzw:)</span> the word is foreign, or Persian, (<span class="ar">أَعْجَمِىٌّ</span>,) <span class="add">[app. the Persian <span class="ar">بَبَرْ</span>, which is said to be applied to the <em>tiger, leopard,</em> and <em>lion,</em>]</span> arabicized: <span class="auth">(M, Ḳ:)</span> Az thinks it to be a foreign word introduced into the Arabic language: <span class="auth">(Mṣb:)</span> pl. <span class="ar">بُبُورٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0147.pdf" target="pdf">
							<span>Lanes Lexicon Page 147</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
