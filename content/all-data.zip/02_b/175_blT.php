<article class="root" id="Root_blT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/174_blsAn">بلسان</a></span>
				<span class="ar">بلط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/176_blE">بلع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blT_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلط</span></h3>
				<div class="sense" id="blT_1_A1">
					<p><span class="ar">بَلَطَ</span>, <span class="auth">(IDrd, Ḳ,)</span> <span class="add">[aor., accord. to a rule observed in the Ḳ, <span class="ar">ـُ</span>,]</span> inf. n. <span class="ar">بَلْطٌ</span>, <span class="auth">(IDrd, TA,)</span> <em>He spread,</em> or <em>paved,</em> <span class="auth">(Ḳ, TA,)</span> a house, <span class="auth">(Ḳ,)</span> and the ground, <span class="auth">(TA,)</span> <em>with</em> <span class="ar">بَلَاط</span> <span class="add">[or <em>flag-stones</em>]</span>, <span class="auth">(Ḳ, TA,)</span> or <em>with baked bricks;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بلّط↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْلِيطٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">ابلط↓</span></span>: <span class="auth">(Ḳ:)</span> <span class="pb" id="Page_0249"></span>or, as also<span class="arrow">↓</span> the second, <em>he made</em> <span class="add">[or <em>constructed</em>]</span> a wall <em>with</em> <span class="ar">بَلَاط</span>: <span class="auth">(IDrd, TA:)</span> or<span class="arrow">↓</span> the second, <em>he made</em> a house <em>plain,</em> or <em>even.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blT_1_B1">
					<p><em>He struck</em> him, or it, <em>with the</em> <span class="ar">بَلْط</span> <span class="add">[q. v.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blT_2">
				<h3 class="entry">2. ⇒ <span class="ar">بلّط</span></h3>
				<div class="sense" id="blT_2_A1">
					<p><a href="#blT_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blT_2_B1">
					<p>The vulgar phrase <span class="ar long">بَلِّطِ السَّفِينَةَ</span> signifies <em>Make thou fast the ship;</em> as though it were an order to make it cleave to the ground. <span class="auth">(TA.)</span> <span class="add">[You say, <span class="ar long">بَلَّطَ السَّفِينَةَ فِى الرَّمْلِ</span>, meaning <em>He ran the ship aground upon the sand.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blT_3">
				<h3 class="entry">3. ⇒ <span class="ar">بالط</span></h3>
				<div class="sense" id="blT_3_A1">
					<p><span class="ar long">بالط القَوْمُ بَنِى فُلَانٍ</span> <em>The people,</em> or <em>company of men, alighted with the sons of such a one, each party to oppose the other, upon the ground:</em> <span class="auth">(Ḳ,* TA:)</span> from <span class="ar">بَلَاطٌ</span> signifying the “earth,” or “ground;” or “even, smooth ground.” <span class="auth">(TA.)</span> <span class="ar long">بالط القَوْمُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُبَالَطَةٌ</span>, <span class="auth">(Ṣ,)</span> <em>The people,</em> or <em>company of men, contended, one with another, in fight with swords,</em> <span class="auth">(Ṣ,* Ḳ, TA,)</span> <em>upon their feet;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">تبالطوا↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> <span class="ar">مبالطة</span> is only upon the ground; <span class="auth">(Z, TA;)</span> and you do not say <span class="ar">تبالطوا</span> when the people are riders. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blT_3_A2">
					<p><span class="ar">بَالَطَنِى</span> <em>He fled from me,</em> <span class="auth">(AḤn, Ḳ,)</span> <em>and went away in the land:</em> <span class="auth">(AḤn, TA:)</span> or <em>he left me; quitted me.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blT_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلط</span></h3>
				<div class="sense" id="blT_4_A1">
					<p><span class="ar">أَبْلَطَ</span> <em>He clave to the</em> <span class="add">[<span class="ar">بَلَاط</span>, i. e.]</span> <em>earth,</em> or <em>ground;</em> <span class="auth">(Ḳ;)</span> said of a man: <span class="auth">(TA:)</span> <em>he became bankrupt,</em> or <em>insolvent,</em> or <em>reduced to a state of difficulty</em> or <em>poverty,</em> or <em>without any property, and clave to the</em> <span class="ar">بَلَاط</span>: <span class="auth">(AHeyth:)</span> <em>he became poor, and his property went away;</em> as also <span class="ar">أُبْلِطَ</span>: <span class="auth">(Ṣ, Ḳ:)</span> so says Ks; and AZ says the like: <span class="auth">(Ṣ:)</span> or <em>he became poor;</em> or <em>had little property.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blT_4_B1">
					<p><span class="ar long">أَبْلَطَ اللِّصُّ القَوْمَ</span> <em>The robber left the people,</em> or <em>company of men, upon the surface of the ground, and left them not anything:</em> <span class="auth">(Lḥ, TA:)</span> or simply, <em>left them not anything.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="blT_4_B2">
					<p><span class="ar long">ابلط المَطَرُ الأَرْضَ</span> <em>The rain fell upon the</em> <span class="ar">بَلَاط</span> <span class="add">[or <em>surface</em>]</span> <em>of the earth,</em> <span class="auth">(Ḳ, TA,)</span> <em>so that no dust was seen upon it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="blT_4_B3">
					<p><a href="#blT_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blT_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبالط</span></h3>
				<div class="sense" id="blT_6_A1">
					<p><a href="#blT_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baloTN">
				<h3 class="entry"><span class="ar">بَلْطٌ</span></h3>
				<div class="sense" id="baloTN_A1">
					<p><span class="ar">بَلْطٌ</span> and<span class="arrow"><span class="ar">بُلْطٌ↓</span></span> <span class="add">[<em>An axe;</em>]</span> i. <em>q.</em> <span class="ar">مِخْرَطٌ</span>; <span class="auth">(Ḳ, TA;)</span> i. e. the <em>iron instrument with which the</em> <span class="ar">خَرَّاط</span> <em>barks and planes</em> (<span class="ar">يَخْرِطُ</span>) <span class="add">[<em>a branch of a tree</em>]</span>: an Arabic word: the vulgar call it <span class="arrow"><span class="ar">بَلْطَةٌ↓</span></span> <span class="add">[now mostly applied to <em>a battle-axe;</em> in Turkish <span class="ar">بَالْتَهْ</span>]</span>. <span class="auth">(TA.)</span> AḤn says, An Arab of the desert quoted to me,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَٱلْبَلْطُ يَبْرِى حِيَدَ الفَرْفَارِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And the axe pares off the knobs,</em> or <em>knots, of the</em> tree called <em>farfár</em>]</span>: <span class="ar">حَيْدَةٌ</span> <span class="add">[<a href="#HiyadN">the sing. of <span class="ar">حِيَدٌ</span></a>]</span> signifying a knob (<span class="ar">سِلْعَة</span>) in a tree; or a knot; which is cut off, and whereof vessels are shaped out, so that they are variegated and beautiful. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buloTN">
				<h3 class="entry"><span class="ar">بُلْطٌ</span></h3>
				<div class="sense" id="buloTN_A1">
					<p><span class="ar">بُلْطٌ</span>: <a href="#baloTN">see <span class="ar">بَلْطٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baloTapN">
				<h3 class="entry"><span class="ar">بَلْطَةٌ</span></h3>
				<div class="sense" id="baloTapN_A1">
					<p><span class="ar">بَلْطَةٌ</span>: <a href="#baloTN">see <span class="ar">بَلْطٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buloTieBN">
				<h3 class="entry"><span class="ar">بُلْطِىٌّ</span></h3>
				<div class="sense" id="buloTieBN_A1">
					<p><span class="ar">بُلْطِىٌّ</span> <span class="add">[The <em>labrus Niloticus;</em>]</span> <em>a kind of fish that is found in the Nile, said to eat of the leaves of Paradise: it is the best of fish:</em> and they liken to it him who is rising out of childhood, in a state of youthfulness and tenderness or delicateness. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaATN">
				<h3 class="entry"><span class="ar">بَلَاطٌ</span></h3>
				<div class="sense" id="balaATN_A1">
					<p><span class="ar">بَلَاطٌ</span> The <em>earth,</em> or <em>ground:</em> <span class="auth">(TA:)</span> <em>or even, smooth ground.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balaATN_A2">
					<p>The <em>face,</em> or <em>surface,</em> of the earth, or ground: <span class="auth">(Ḳ:)</span> or the <em>part where what is hard, thereof,</em> i. e. of the earth or ground, <em>ends:</em> <span class="auth">(AḤn, Ḳ:)</span> or the <em>hard part of the exterior</em> thereof. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balaATN_A3">
					<p><span class="add">[<em>Flag-stones,</em> or <em>flat stones for pavement;</em> and <em>baked bricks for pavement;</em> <span class="auth">(a coll. gen. n., of which the n. un. is with <span class="ar">ة</span>;)</span>]</span> <em>stones,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and <em>any other things,</em> <span class="auth">(Mṣb,)</span> <em>which are spread in a house</em> <span class="auth">(Ṣ, Ḳ)</span>, &amp;c., <span class="auth">(Ṣ,)</span> or <em>with which a house is spread</em> or <em>paved.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balaATN_A4">
					<p><em>Any ground,</em> or <em>floor, paved with such stones,</em> or <em>with baked bricks;</em> <span class="auth">(Ḳ;)</span> <span class="add">[<em>a pavement.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="balaATN_A5">
					<p>You say with respect to a niggardly and mean man, <span class="ar long">مَا ذَا يَأْخُذُ الرِّيحُ مِنَ البَلَاطِ</span> <span class="add">[<em>What will the wind take from the pavement?</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="balaATN_A6">
					<p>And <span class="ar long">رَجُلٌ بَلَاطٌ</span> † <em>A man poor,</em> or <em>in want.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلَاطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="balaATN_A7">
					<p>And <span class="ar long">إِنَّهَا حَسَنَةُ البَلَاطِ إِذَا جُرِّدَتْ</span> ‡ <em>Verily she is goodly,</em> or <em>beautiful, in skin when she is stripped.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balBuwTo">
				<h3 class="entry"><span class="ar">بَلُّوطْ</span></h3>
				<div class="sense" id="balBuwTo_A1">
					<p><span class="ar">بَلُّوطْ</span> <span class="add">[The <em>acorn;</em>]</span> <em>a certain thing well known;</em> <span class="auth">(Ṣ;)</span> the <em>fruit,</em> or <em>produce, of a kind of tree,</em> <span class="add">[namely, <em>the oak,</em>]</span> <em>which is eaten,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>sometimes,</em> <span class="auth">(Mṣb,)</span> <em>and with the bark of which one tans,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>sometimes:</em> <span class="auth">(Mṣb:)</span> or <span class="add">[the <em>oak;</em> or this kind of tree is properly called <span class="ar long">شَجَرُ البَلُّوطِ</span>;]</span> <em>a kind of tree; the fruit,</em> or <em>produce, whereof they used as food, in ancient times; cold and dry</em> <span class="auth">(Ḳ, TA)</span> <em>in the second degree, or, as some say, in the first; or its dryness is in the third degree;</em> or <em>it is hot in the first degree;</em> <span class="auth">(TA;)</span> <em>heavy, coarse,</em> <span class="auth">(Ḳ, TA,)</span> <em>slow of digestion, bad for the stomach, occasioning headache, injurious to the bladder, but rendered good by its being roasted and having sugar added to it;</em> <span class="auth">(TA;)</span> <em>suppressing the urine,</em> <span class="auth">(Ḳ, TA,)</span> <em>and rendering it difficult; preventing exhaustion by loss of blood, and the emission of blood</em> <span class="add">[<em>from a wound</em>]</span>; <em>good for hardnesses, with the fat of a kid; preventing the progress of</em> <span class="add">[<em>the disease in the mouth called</em>]</span> <span class="ar">قُلَاع</span>, <em>and</em> <span class="ar">فروع</span> <span class="add">[app. a mistake for <span class="ar">قُرُوح</span>, or <em>wounds</em>]</span>, <em>when it is burnt; preventing also excoriation, and poisons, and looseness of the bowels; and very nutritious when easily digested.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#EafoSN">See also <span class="ar">عَفْصٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلُّوطْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balBuwTo_A2">
					<p><span class="add">[Forskål, in his Flora Aegypt., p. lvi., mentions this name as applied to The <em>common ash-tree; fraxinus excelsior.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلُّوطْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balBuwTo_A3">
					<p><span class="ar long">بَلُّوطُ المَلِكِ</span>, according to some, The <em>walnut:</em> accord. to others, the <span class="ar">شَاهْبَلُّوط</span> <span class="add">[a Persian word, and also used by Arabs in the present day, applied to the <em>chestnut</em>]</span>: as is said in the Minháj. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلط</span> - Entry: <span class="ar">بَلُّوطْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balBuwTo_A4">
					<p><span class="ar long">بَلُّوط الأَرْضِ</span> <span class="add">[applied in the present day to The herb <em>germander,</em> or <em>chamædrys;</em>]</span> <em>a certain plant, the leaves of which resemble the</em> <span class="ar long">هِنْدِ بَآء</span> <span class="add">[or <em>endive</em>]</span>: it is <em>diuretic; aperient; and wasting to the spleen.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaAliyTN">
				<h3 class="entry"><span class="ar">بَلَالِيطٌ</span></h3>
				<div class="sense" id="balaAliyTN_A1">
					<p><span class="ar">بَلَالِيطٌ</span> <em>Level,</em> or <em>even, lands,</em> or <em>tracts of ground:</em> <span class="auth">(Ḳ:)</span> no sing. to it is known. <span class="auth">(Seer.)</span> <span class="add">[<a href="#balaATN">See also <span class="ar">بَلَاطٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboliTN">
				<h3 class="entry"><span class="add">[<span class="ar">مُبْلِطٌ</span>]</span></h3>
				<div class="sense" id="muboliTN_A1">
					<p><span class="add">[<span class="ar">مُبْلِطٌ</span> and <span class="ar">مُبْلَطٌ</span>, as epithets applied to a man, part. ns. of <span class="ar">أَبْلَطَ</span> and <span class="ar">أُبْلِطَ</span>, which see above.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0248.pdf" target="pdf">
							<span>Lanes Lexicon Page 248</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0249.pdf" target="pdf">
							<span>Lanes Lexicon Page 249</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
