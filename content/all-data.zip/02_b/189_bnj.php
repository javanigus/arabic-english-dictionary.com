<article class="root" id="Root_bnj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/188_bn">بن</a></span>
				<span class="ar">بنج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/190_bnd">بند</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bnj_2">
				<h3 class="entry">2. ⇒ <span class="ar">بنّج</span></h3>
				<div class="sense" id="bnj_2_A1">
					<p><span class="ar">بنّجهُ</span>, inf. n. <span class="ar">تَبْنِيجٌ</span>, <span class="add">[<em>He dosed him,</em> or <em>stupified him, with</em> <span class="ar">بَنْج</span>, q. v.;]</span> <em>he gave him</em> <span class="ar">بَنْج</span> <em>to eat.</em> <span class="auth">(Ḳ.)</span> <span class="add">[See the act. part. n. below.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banojN">
				<h3 class="entry"><span class="ar">بَنْجٌ</span></h3>
				<div class="sense" id="banojN_A1">
					<p><span class="ar">بَنْجٌ</span> <span class="add">[<em>Hyoscyamus,</em> or <em>henbane;</em>]</span> an arabicized word, <span class="add">[said to be]</span> from <span class="add">[the Persian]</span> <span class="fa">بَنْكْ</span>; <span class="add">[but see a quotation from Hammer-Purgstall, near the close of this paragraph;]</span> <span class="pb" id="Page_0259"></span><em>a certain plant,</em> <span class="auth">(Mgh, and Ḥar p. 365,)</span> <em>having an intoxicating kind of grain,</em> or, as some say, <span class="auth">(Mgh,)</span> <em>of which the leaves and peel and seeds torpify:</em> <span class="auth">(Mgh, Ḥar:)</span> it is said, in the Kánoon, <span class="auth">(Mgh,)</span> by Aboo-ʼAlee <span class="add">[Ibn-Seenà, or Avicenna]</span>, <span class="auth">(Ḥar,)</span> that <em>it is a poison which confuses the intellect, and annuls the memory, and occasions insanity and</em> <span class="add">[<em>the disorder termed</em>]</span> <span class="ar">خُنَاق</span> <span class="add">[or <em>quinsy</em>]</span>; <span class="auth">(Mgh, Ḥar;)</span> <em>and it is red, and white:</em> <span class="auth">(Ḥar:)</span> <em>a certain plant having a kind of grain that confuses the intellect, and occasions alienation of the mind,</em> or <em>insanity; and sometimes it intoxicates, when a man drinks it after it has been dissolved; and it is said to occasion forgetfulness:</em> <span class="auth">(Mṣb:)</span> <em>a certain torpifying plant, well known; different from</em> <span class="ar long">حَشِيشُ الحَرَافِيشِ</span>; <em>disordering the intellect</em> (<span class="ar long">مُخَبِّطٌ لِلْعَقْلِ</span>), <em>rendering insane, allaying the pains of humours and pustules, and the earache,</em> <span class="auth">(Ḳ, TA,)</span> <em>applied as a liniment or as a poultice;</em> <span class="auth">(TA;)</span> <em>the worst kind</em> <span class="auth">(Ḳ, TA)</span> <em>for use</em> <span class="auth">(TA)</span> <em>is the black; then, the red; and the safest kind is the white.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[Ḳzw says that the leaves of the garden-hemp (<span class="ar long">قِنَّب بُسْتَانِىّ</span>, or <span class="ar">شَهْدَانَجِ</span>, the latter of which properly signifies hemp-seed,) are the <span class="ar">بَنْج</span> which, when eaten, disorders the intellect. And El-Idreesee applies the appellation <span class="ar">حَشِيشِيَّة</span> to the “Assassins.” This establishes the correctness of De Sacy's opinion, that the appellation “Assassins” is derived from the vulgar pl. <span class="ar">حَشَّاشِين</span>, <span class="auth">(hemp-eaters, or persons who intoxicate themselves with hemp,)</span> for <span class="ar">حَشَّاشِين</span> is syn. with <span class="ar">حَشِيشَّة</span>, and the sect called by us the “Assassins” are expressly said by the Arabs to have made frequent use of <span class="ar">بَنْج</span>. Baron Hammer-Purgstall, correctly regarding <span class="ar">بَنْج</span> as hyoscyamus <span class="auth">(or henbane)</span>, makes the following important observations, “‘ Bendj, ’ the pl. of which in Coptic is ‘ nibendj, ’ is without doubt the same plant as the ‘ nepenthe, ’ which has hitherto so much perplexed the commentators of Homer. Helen evidently brought the nepenthe from Egypt, and bendj is there still reputed to possess all the wonderful qualities which Homer attributes to it.” <span class="auth">(Trébutien, “Contes Inédits des Mille et une Nuits,” tome i. p. 12, note.)</span>]</span> The phrase <span class="ar long">شَرِبَ البَنْجَ</span> is used by El-Karkhee <span class="add">[as meaning <em>He drank the</em> <span class="ar">بنج</span>]</span> because it is mixed with water; or <span class="add">[as meaning <em>he took,</em> or <em>swallowed, the</em> <span class="ar">بنج</span>,]</span> according to the conventional language of the physicians. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubanBijN">
				<h3 class="entry"><span class="ar">مُبَنِّجٌ</span></h3>
				<div class="sense" id="mubanBijN_A1">
					<p><span class="ar">مُبَنِّجٌ</span> One <em>who employs a stratagem by means of food containing</em> <span class="ar">بَنْج</span> <span class="add">[<em>in order to obtain some advantage over another, by stupifying him therewith;</em> as the “Assassins” used to do]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0258.pdf" target="pdf">
							<span>Lanes Lexicon Page 258</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
