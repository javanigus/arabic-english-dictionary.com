<article class="root" id="Root_bgm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/150_bgl">بغل</a></span>
				<span class="ar">بغم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/152_bgw">بغو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgm_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغم</span></h3>
				<div class="sense" id="bgm_1_A1">
					<p><span class="ar">بَغَمَتْ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْغِمُ</span>}</span></add> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَمُ</span>}</span></add> and <span class="ar">ـُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بُغَامٌ</span> <span class="auth">(JK, Ṣ, Ḳ)</span> and <span class="ar">بُغُومٌ</span>; <span class="auth">(JK, Ḳ;)</span> and<span class="arrow"><span class="ar">تبغّمت↓</span></span>; <span class="auth">(Ḳ;)</span> <em>She</em> <span class="auth">(a gazelle)</span> <em>uttered a cry:</em> <span class="auth">(Ṣ:)</span> or <em>uttered her softest,</em> or <em>gentlest, cry</em> <span class="auth">(JK, Ḳ)</span> <em>to her young one:</em> <span class="auth">(Ḳ:)</span> and sometimes it is said of a <span class="add">[wild]</span> cow: <span class="auth">(TA:)</span> so too <span class="ar">بَغَمَ</span> said of a male gazelle: and the verb is also used transitively, said of a female gazelle uttering this cry to her young one. <span class="auth">(JK.)</span> Also, <span class="auth">(Ṣ, Ḳ,)</span><span class="arrow">↓</span> both verbs, <span class="auth">(Ḳ,)</span> <em>She</em> <span class="auth">(a camel)</span> <em>uttered a cry without clearness:</em> <span class="auth">(Ṣ:)</span> or <em>uttered a broken,</em> or <em>an interrupted, not a prolonged, yearning cry, to,</em> or <em>for, her young one:</em> <span class="auth">(Ḳ:)</span> or <em>uttered a weak cry, below that</em> <span class="add">[<em>grumbling cry</em>]</span> <em>which is termed</em> <span class="ar">رُغَآء</span>. <span class="auth">(Ḥam p. 233.)</span> <span class="add">[See an ex. in a verse of Dhu-rRummeh cited voce <span class="ar">إِلَّا</span>.]</span> <span class="pb" id="Page_0231"></span>And <span class="ar">بَغَمَ</span> and<span class="arrow"><span class="ar">تبغّم↓</span></span> said of the <span class="ar">ثَيْتَل</span> and <span class="ar">إِيَّل</span> and <span class="ar">وَعِل</span>, <span class="add">[all of which words are said to signify the mountain goat,]</span> <em>He uttered a cry.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bgm_1_A2">
					<p><span class="ar">بَغَمَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar long">بَغَمَ لَهُ</span>, <span class="auth">(TA,)</span> † <em>He spoke to him obscurely, not expressing clearly to him the meaning of his speech to him;</em> <span class="auth">(Ṣ, Ḳ;)</span> taken from the <span class="ar">بُغَام</span> of the she-camel; because it is a cry not uttered clearly. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgm_3">
				<h3 class="entry">3. ⇒ <span class="ar">باغم</span></h3>
				<div class="sense" id="bgm_3_A1">
					<p><span class="ar">باغمهُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُبَاغَمَةٌ</span>, <span class="auth">(Ṣ,)</span> ‡ <em>He talked with him with a soft,</em> or <em>gentle, voice:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> or <span class="ar">المُبَاغَمَةٌ</span> is like <span class="ar">المُنَاغَمَةُ</span>, and means <em>the speaking</em> <span class="add">[<em>with another</em>]</span> <em>faintly;</em> taken from the <span class="ar">بُغَام</span> <span class="add">[<a href="#bgm_1">see 1</a>]</span> of the gazelle and the she-camel: <span class="auth">(Ḥam p. 233:)</span> or <em>the holding amatory and enticing talk,</em> or <em>conversation, with another, with a soft,</em> or <em>gentle, voice.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bgm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبغّم</span></h3>
				<div class="sense" id="bgm_5_A1">
					<p><a href="#bgm_1">see 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgm_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباغم</span></h3>
				<div class="sense" id="bgm_6_A1">
					<p><span class="ar">تَبَاغَمَتْ</span> <span class="add">[<em>They</em> <span class="auth">(gazelles)</span> <em>uttered cries,</em> or <em>their softest</em> or <em>gentlest cries, one to another.</em>]</span> One says, <span class="ar long">مَرَرْتُ بِرَوْضَةٍ تَتَبَاغَمُ فِيهَا الظِّبَآءُ</span> <span class="add">[<em>I passed by a meadow in which the gazelles were uttering cries,</em>, &amp;c., <em>one to another</em>]</span>: and <span class="ar long">بِغِزْلَانٍ يَتَبَاغَمْنَ</span> <span class="add">[<em>by gazelles uttering cries,</em>, &amp;c., <em>one to another</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bugomapN">
				<h3 class="entry"><span class="ar">بُغْمَةٌ</span></h3>
				<div class="sense" id="bugomapN_A1">
					<p><span class="ar">بُغْمَةٌ</span> <em>A thing like the</em> <span class="ar">قِلَادَة</span>, <span class="add">[<em>a necklace,</em>]</span> <em>with which women ornament themselves.</em> <span class="auth">(TA.)</span> <span class="add">[But this is apparently post-classical, from the Turkish <span class="ar">بُوغْمَقْ</span>. In the present day, it is applied to <em>A necklace of pearls.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bugaAmN">
				<h3 class="entry"><span class="ar">بُغَامٌ</span></h3>
				<div class="sense" id="bugaAmN_A1">
					<p><span class="ar">بُغَامٌ</span> The <em>crying,</em> or <em>cry, of the female gazelle,</em> and <em>of the she-camel, as explained above:</em> <a href="#bgm_1">see 1</a>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baguwmN">
				<h3 class="entry"><span class="ar">بَغُومٌ</span></h3>
				<div class="sense" id="baguwmN_A1">
					<p><span class="ar">بَغُومٌ</span> A female gazelle <em>uttering,</em> or <em>that utters, the cry termed</em> <span class="ar">بُغَام</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغم</span> - Entry: <span class="ar">بَغُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baguwmN_A2">
					<p>† A woman <em>having a soft,</em> or <em>gentle, voice.</em> <span class="auth">(JK, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboguwmN">
				<h3 class="entry"><span class="ar">مَبْغُومٌ</span></h3>
				<div class="sense" id="maboguwmN_A1">
					<p><span class="ar">مَبْغُومٌ</span> A young gazelle, and a young camel, <em>to which the cry termed</em> <span class="ar">بُغَام</span> <em>is addressed by its mother.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغم</span> - Entry: <span class="ar">مَبْغُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maboguwmN_A2">
					<p>One says, also, <span class="ar long">بُغَامٌ مَبْغُومٌ</span> <span class="add">[<em>A cry</em>, &amp;c. <em>uttered</em>]</span>; like as one says, <span class="ar long">قَوْلٌ مَقُولٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0230.pdf" target="pdf">
							<span>Lanes Lexicon Page 230</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0231.pdf" target="pdf">
							<span>Lanes Lexicon Page 231</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
