<article class="root" id="Root_bdw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/047_bdh">بده</a></span>
				<span class="ar">بدو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/049_bde">بدى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bdw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدو</span> ⇒ <span class="ar">بدى</span></h3>
				<div class="sense" id="bdw_1_A1">
					<p><span class="ar">بَدَا</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">يَبْدُو</span>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">بُدُوٌّ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">بَدْوٌ</span> and <span class="ar">بَدَآءٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">بَدَآءَةٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بَدًا</span>, <span class="auth">(M, on the authority of Sb,)</span> for which last we find, in <span class="add">[some of]</span> the copies of the Ḳ, <span class="ar">بُدُوٌّ</span>, a repetition, <span class="auth">(TA,)</span> or <span class="ar">بُدُوْءٌ</span>, <span class="auth">(so in other copies of the Ḳ,)</span> <em>It appeared; it became apparent, open, manifest, plain,</em> or <em>evident:</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ:)</span> and<span class="arrow"><span class="ar">تبدّى↓</span></span> <span class="add">[signifies the same; or <em>he showed himself,</em> or <em>it showed itself;</em> (<a href="index.php?data=05_j/199_jyX">see an ex. in art. <span class="ar">جيش</span></a>, <a href="#jaAXa">voce <span class="ar">جَاشَ</span></a>, last sentence;) or]</span> <em>he,</em> or <em>it, came in sight,</em> or <em>within sight.</em> <span class="auth">(KL.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdw_1_A2">
					<p><span class="ar long">بَدَا لَهُ فِى الأَمْرِ</span>, <span class="auth">(T, M, Mṣb, Ḳ, and Ḥar p. 665,)</span> inf. n. <span class="ar">بَدْوٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">بَدًا</span> <span class="auth">(M, and so in a copy of the Ḳ)</span> and <span class="ar">بَدَآءٌ</span>, <span class="auth">(T, M, and so in the CK,)</span> or <span class="ar">بَدَآءَةٌ</span> and <span class="ar">بَدَاةٌ</span>; <span class="auth">(as in some copies of the Ḳ;)</span> or<span class="arrow"><span class="ar long">بَدَا لَهُ فِى الأَمْرِ بَدَآءٌ↓</span></span>, <span class="auth">(Ṣ, IB,)</span> the last word being in the nom. case because it is the agent; <span class="auth">(IB, TA;)</span> <em>An opinion presented itself,</em> or <em>occurred, to him,</em> or <em>arose in his mind,</em> syn. <span class="ar">نَشَأَ</span>, <span class="auth">(Ṣ, Ḳ, and Ḥar ubi suprà,)</span> or <em>appeared to him,</em> <span class="auth">(M,)</span> <span class="add">[<em>respecting the affair,</em> or <em>case,</em>]</span> <em>different from his first opinion, so that it turned him therefrom:</em> <span class="auth">(Ḥar ubi suprà:)</span> or <em>there appeared to him, respecting the affair,</em> or <em>case, what did not appear at first:</em> <span class="auth">(Mṣb:)</span> accord. to Fr, <span class="arrow"><span class="ar long">بَدَا لِى بَدَآءٌ↓</span></span> means <em>another opinion appeared to me:</em> accord. to Az, <span class="ar long">بَدَا لِى بَدًا</span> means <em>my opinion changed from what it was.</em> <span class="auth">(TA.)</span> Esh-Shemmàkh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَعَلَّكَ وَالمَوْعُودُ حَقٌّ وَفَاؤُهُ</span> *</div> 
						<div class="star">* <span class="ar long">بَدَا لَكَ فِى تِلْكَ القَلُوصِ بَدَآءُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>May-be</em> (<em>but it is right that the promise be fulfilled</em>) <em>an opinion different from thy first opinion hath arisen in thy mind respecting that youthful she-camel</em>]</span>. <span class="auth">(M, TA.)</span> <span class="ar long">ثُمَّ بَدَا لَهُمْ مِنْ بَعْدِ مَا رَأَوُا ٱلْآيَاتِ لَيَسْجُنَنَّهُ</span>, in the Ḳur <span class="add">[xii.35]</span>, means<span class="arrow"><span class="ar long">بَدَا لَهُمْ بَدَآءٌ↓ وَقَالُوا لَيَسْجُنُنَّهُ</span></span>, <span class="add">[i.e. <em>Then an opinion arose in their minds, after they had seen the signs</em> of his innocence, <em>and they said that they should certainly imprison him,</em>]</span> because <span class="ar">ليسجننّه</span>, being a proposition, cannot be the agent: so says Sb. <span class="auth">(M.)</span> <span class="ar long">بَدَا لِلّهِ أَنْ يَقْتُلَهُمْ</span>, occurring in a trad., means ‡ <em>God determined that He would slay them:</em> for, as IAth says, <span class="ar">بَدَآءٌ</span> signifies the <em>deeming to be right a thing that is known after its having been not known;</em> and this may not be attributed to God: but as is said by Suh, in the R, one may say, <span class="add">[of God,]</span> <span class="ar long">بَدَا لَهُ أَنْ يَفْعَلَ كَذَا</span>, <span class="add">[properly signifying <em>It occurred to him,</em> or <em>appeared to him, that he should do such a thing,</em>]</span> as meaning ‡ <em>He desired to do such a thing;</em> <span class="add">[as also <span class="ar long">بَدَا لَهُ فِى فِعْلِ كَذَا</span>;]</span> and thus the phrase in the trad., here mentioned, has been explained. <span class="auth">(TA.)</span> <span class="add">[One says also, <span class="ar long">اِفْعَلْ كَذَا مَا بَدَا لَكَ</span> <em>Do thou thus as long as it seems fit to thee:</em> see, a verse of El-Aḥmar cited voce <span class="ar">جَلَّ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bdw_1_A3">
					<p><span class="ar long">بَدَا القَوْمُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">بَدْوٌ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَدَآءٌ</span>; <span class="auth">(M, Ḳ;)</span> <span class="add">[the latter of which is said in the TA to be the right;]</span> or <span class="ar long">بَدَا إِلَى البَادِيَةِ</span>, inf. n. <span class="ar">بَدَاوَةٌ</span> and <span class="ar">بِدَاوَةٌ</span>; <span class="auth">(Mṣb;)</span> <em>The people, or company of men, went forth to the</em> <span class="ar">بَادِيَة</span> <span class="add">[<em>or desert</em>]</span>: <span class="auth">(M, Mṣb, Ḳ:)</span> or, the former, <em>went forth to their</em> <span class="ar">بَادِيَة</span>: <span class="auth">(Ṣ:)</span> or <em>went forth from the region, or district, of towns or villages or of cultivated land, to the pasturingplaces in the deserts:</em> <span class="auth">(T:)</span> <span class="add">[ISd says,]</span> <span class="ar">بَدْوٌ</span> may be used as meaning <span class="ar">بِدَاوَةٌ</span>, which is the <em>contr. of</em> <span class="ar">حِضَارَةٌ</span>: <span class="auth">(M:)</span> <span class="add">[J says,]</span> <span class="ar">بَدَاوَةٌ</span> and <span class="ar">بِدَاوَةٌ</span> signify the <em>dwelling,</em> or <em>abiding, in the</em> <span class="ar">بَادِيَة</span> <span class="add">[or <em>desert</em>]</span>; the <em>contr. of</em> <span class="ar">حِضَارَةٌ</span>: but Th says, I know not <span class="ar">بَدَاوَةٌ</span>, with fet-ḥ, except on the authority of AZ alone: <span class="auth">(Ṣ:)</span> Aṣ says that <span class="ar">بداوة</span> and <span class="ar">حضارة</span> are with kesr to the <span class="ar">ب</span> and fet-ḥ to the <span class="ar">ح</span>; but AZ says the reverse, i. e. with fet-ḥ to the <span class="ar">ب</span> and kesr to the <span class="ar">ح</span>: <span class="auth">(T:)</span> both are also explained as signifying the <em>going forth to the</em> <span class="ar">بَادِيَة</span>: and some mention <span class="ar">بُدَاوَةٌ</span>, with damm; but this is not known: <span class="auth">(TA:)</span> <span class="arrow"><span class="ar">تبدّى↓</span></span> like wise signifies <em>he went forth from the constant sources of water to the places where herbage was to be sought</em> <span class="add">[<em>in the desert</em>]</span>; <span class="auth">(T;)</span> or <em>he dwelt,</em> or <em>abode, in the</em> <span class="ar">بَادِيَة</span>. <span class="auth">(Ṣ, Ḳ.)</span> It is said in a trad., <span class="ar long">مَنْ بَدَا جَفَا</span>, i. e. <em>He who abides in the desert becomes rude, rough, coarse,</em> or <em>uncivil, like the desert-Arabs.</em> <span class="auth">(Ṣ.)</span> And in another, <span class="ar long">كَانَ يَبْدُو إِلَى هٰذِهِ التِّلَاعِ</span> <span class="add">[<em>He used to go forth to these water-courses in the desert,</em> or <em>these high grounds, </em> or <em>low grounds,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bdw_1_A4">
					<p><span class="add">[Hence,]</span> <span class="ar">بَدَا</span> <em>He voided his excrement,</em> or <em>ordure;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابدى↓</span></span> <span class="auth">(T, Ḳ)</span> <span class="add">[and <span class="ar">ابدأ</span>]</span>: because he who does so goes forth from the tents or houses into the open country. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdw_1_B1">
					<p><span class="ar long">بَدَانِى بِكَذَا</span>, aor. <span class="ar">يَبْدُو</span>, is like <span class="ar">بَدَأَنِى</span> <span class="add">[i. e. <em>He began with me by</em> doing <em>such a thing</em>]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<span class="pb" id="Page_0171"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bdw_1_C1">
					<p><span class="ar long">بَدِيَتِ الأَرْضُ</span> <em>The land produced,</em> or <em>abounded with,</em> <span class="ar">بَدَاة</span>, i. e. <em>truffles:</em> <span class="auth">(Ḳ,* TA:)</span> or <em>had in it truffles.</em> <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="bdw_1_C2">
					<p>And <em>The land had in it</em> <span class="ar">بَدَاة</span>, meaning <em>dust,</em> or <em>earth.</em> <span class="auth">(Ḳ,* TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdw_2">
				<h3 class="entry">2. ⇒ <span class="ar">بدّو</span> ⇒ <span class="ar">بدّى</span></h3>
				<div class="sense" id="bdw_2_A1">
					<p><span class="ar">بدّى</span>, inf. n. <span class="ar">تَبْدِيَةٌ</span>, <em>He showed,</em> or <em>made apparent, a want that occurred,</em> or <em>presented itself, to him.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bdaACapN">See <span class="ar">بدَآءَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdw_2_A2">
					<p><em>He sent forth</em> a horse <span class="add">[or beast]</span> <em>to the place of pasture</em> <span class="add">[app. <em>in the</em> <span class="ar">بَادِيَة</span>, or <em>desert</em>]</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdw_3">
				<h3 class="entry">3. ⇒ <span class="ar">بادو</span> ⇒ <span class="ar">بادى</span></h3>
				<div class="sense" id="bdw_3_A1">
					<p><span class="ar">مُبَادَاةٌ</span> The <em>going,</em> or <em>coming, out,</em> or <em>forth, in the field, to encounter another in battle,</em> or <em>war.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdw_3_A2">
					<p>And <span class="add">[more commonly]</span> The <em>showing open enmity,</em> or <em>hostility, with any one:</em> <span class="auth">(KL, TA:)</span> <span class="add">[a meaning more fully expressed by the phrase <span class="ar long">مُبَادَاةٌ بِالعَدَاوَةِ</span>: for you say,]</span> <span class="ar long">بَادَى بِالعَدَاوَةِ</span> <em>He showed open enmity,</em> or <em>hostility,</em> <span class="add">[<em>with another;</em>]</span> syn. <span class="ar long">جَاهَرَ بِهَا</span>; <span class="auth">(Ṣ, Ḳ;*)</span> as also<span class="arrow"><span class="ar">تبادى↓</span></span>: <span class="auth">(Ḳ:)</span> or you say,<span class="arrow"><span class="ar long">تبادوا↓ بالعدواة</span></span> <em>they showed open enmity,</em> or <em>hostility, one with another;</em> syn. <span class="ar long">تَجَاهَرُوا بِهَا</span>. <span class="auth">(Ṣ.)</span> You say also, <span class="ar long">بادى النَّاسَ بِأَمْرِهِ</span> <em>He showed,</em> or <em>revealed, to the people,</em> or <em>to men, his affair,</em> or <em>case.</em> <span class="auth">(TA.)</span> <span class="add">[Thus, <span class="ar long">باداهُ بِالأَمْرِ</span> and<span class="arrow"><span class="ar long">ابدى↓ لَهُ الأَمْرَ</span></span> signify the same; i. e. <em>He showed,</em> or <em>revealed, to him the affair,</em> or <em>case.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bdw_3_A3">
					<p>And <span class="ar long">بادى بَيْنَهُمَا</span> <em>He measured,</em> or <em>compared, them both together, each with the other.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابدو</span> ⇒ <span class="ar">ابدى</span></h3>
				<div class="sense" id="bdw_4_A1">
					<p><span class="ar">ابداهُ</span> <em>He made it apparent, open, manifest, plain,</em> or <em>evident; he showed, exhibited, manifested, evinced, discovered,</em> or <em>revealed, it;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> and it has been said <span class="add">[correctly, as will be seen below,]</span> that <span class="ar long">ابدى عَنْهُ</span> signifies the same. <span class="auth">(MF, TA.)</span> It is said in a trad., <span class="ar long">مَنْ يُبْدِ لَنَا صَفْحَتَهُ نَقَمَ عَلَيْهِ كِتَابُ ٱللّٰهِ</span>, i. e. ‡ <em>Whoso showeth,</em> or <em>revealeth, to us his deed</em> <span class="add">[or <em>crime</em>]</span> <em>which he was concealing,</em> <span class="add">[<em>the book of God shall execute vengeance upon him,</em> meaning]</span> <em>we will inflict upon him the punishment ordained by the book of God.</em> <span class="auth">(TA.)</span> <span class="ar long">ابدى لَهُ صَفْحَتَهُ</span> also means ‡ <em>He showed open enmity,</em> or <em>hostility, with him.</em> <span class="auth">(A and TA in art. <span class="ar">صفح</span>.)</span> And <span class="ar long">ابدى عَنْ قَعْرِهِ</span>, said of water, means <em>It showed its bottom,</em> by reason of its clearness. <span class="auth">(L in art. <span class="ar">مكد</span>.)</span> <a href="#bdw_3">See also 3</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdw_4_A2">
					<p><span class="ar long">أَبْدَيْتَ فِى مَنْطِقِكَ</span> <em>Thou deviatedst,</em> or <em>hast deviated, from the right way in thy speech.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bdw_4_A3">
					<p><a href="#bdw_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبدّو</span> ⇒ <span class="ar">تبدّى</span></h3>
				<div class="sense" id="bdw_5_A1">
					<p><span class="ar">تبدّى</span>: <a href="#bdw_1">see 1</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdw_5_B1">
					<p>In the common dial. of the people of El-Yemen, it signifies <em>He ate the morning-meal;</em> syn. <span class="ar">تَغَدَّى</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبادو</span> ⇒ <span class="ar">تبادى</span></h3>
				<div class="sense" id="bdw_6_A1">
					<p><span class="ar">تبادى</span>: <a href="#bdw_3">see 3</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdw_6_A2">
					<p>Also <em>He affected to be like,</em> or <em>imitated, the people of the</em> <span class="ar">بَادِيَة</span> <span class="add">[or <em>desert</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badK">
				<h3 class="entry"><span class="ar">بَدٍ</span></h3>
				<div class="sense" id="badK_A1">
					<p><span class="ar">بَدٍ</span>: <a href="#badowN">see <span class="ar">بَدْوٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badFA">
				<h3 class="entry"><span class="ar">بَدًا</span></h3>
				<div class="sense" id="badFA_A1">
					<p><span class="ar">بَدًا</span> The <em>excrement from the anus</em> <span class="auth">(M, Ḳ *)</span> of a man. <span class="auth">(M.)</span> <span class="add">[And <span class="ar">بَدَآءٌ</span>, from <span class="ar">أَبْدَأَ</span>, signifies the same.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدًا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badFA_A2">
					<p><em>A joint</em> (<span class="ar">مَفْصِل</span>) of a man; <span class="auth">(AA, M, Ḳ;)</span> as also <span class="ar">بَدْءٌ</span>: <span class="auth">(AA, M:)</span> pl. <span class="ar">أَبْدَآءٌ</span>. <span class="auth">(AA, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدًا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badFA_B1">
					<p><span class="ar">بَدَا</span> for <span class="ar">بَدًا</span>: <a href="#badowN">see <span class="ar">بَدْوٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badowN">
				<h3 class="entry"><span class="ar">بَدْوٌ</span></h3>
				<div class="sense" id="badowN_A1">
					<p><span class="ar">بَدْوٌ</span>: <a href="#baAdiyapN">see <span class="ar">بَادِيَةٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badowN_B1">
					<p><a href="#baAdK">and see also <span class="ar">بَادٍ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="badowN_C1">
					<p>Also The <em>first</em> of a thing; originally <span class="add">[<span class="ar">بَدْءٌ</span>,]</span> with hemzeh: <span class="auth">(Ḥar p. 583:)</span> and<span class="arrow"><span class="ar">بَدِىٌّ↓</span></span>, also, <span class="add">[originally <span class="ar">بَدِىْءٌ</span>,]</span> signifies the <em>first:</em> <span class="auth">(TA:)</span> <span class="add">[and<span class="arrow"><span class="ar">بَدٍ↓</span></span> and<span class="arrow"><span class="ar">بَدَا↓</span></span>, the latter for <span class="ar">بَدًا</span>, are used for <span class="ar">بَدْءٍ</span>. Hence,]</span> one says,<span class="arrow"><span class="ar long">اِفْعَلْ ذٰلِكَ بَادِى بَدٍ↓</span></span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">بَادِىَ بَدٍ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar long">بَادِى بَدِى↓</span></span>, <span class="auth">(Fr, Ṣ, M,)</span> or <span class="ar long">بَادِىَ بَدِى</span>, <span class="auth">(as in some copies of the Ḳ,)</span> or<span class="arrow"><span class="ar long">بادى بَدِىٍ↓</span></span>, <span class="auth">(as in other copies of the Ḳ and in the TA,)</span> and<span class="arrow"><span class="ar long">بَادَىَ بَدًا↓</span></span>, <span class="auth">(M, Ḳ,)</span> mentioned by Sb, who says that it is without tenween, though analogy does not forbid its being with tenween, <span class="auth">(M,)</span> meaning <em>Do thou that first;</em> <span class="auth">(Ṣ, TA;)</span> or, <em>the first thing:</em> <span class="auth">(Fr, TA:)</span> originally <span class="add">[<span class="ar long">بَادِئَ بَدْءٍ</span>, &amp;c.,]</span> with hemz. <span class="auth">(Ṣ, Ḳ. <span class="add">[<a href="#badoCN">See <span class="ar">بَدْءٌ</span></a>.]</span>)</span> Hence also the phrase, <span class="arrow"><span class="ar long">الحَمْدُلِلٰهِ بَدِيًّا↓</span></span> <span class="add">[<em>Praise be to God in the first place</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badie">
				<h3 class="entry"><span class="ar">بَدِى</span></h3>
				<div class="sense" id="badie_A1">
					<p><span class="ar">بَدِى</span> for <span class="ar">بَدٍ</span>: <a href="#badowN">see <span class="ar">بَدْوٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaApN">
				<h3 class="entry"><span class="ar">بَدَاةٌ</span></h3>
				<div class="sense" id="badaApN_A1">
					<p><span class="ar">بَدَاةٌ</span>: <a href="#badaACN">see <span class="ar">بَدَآءٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badaApN_A2">
					<p><a href="#baAdiyapN">and see also <span class="ar">بَادِيَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدَاةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badaApN_B1">
					<p>Also, <span class="auth">(Ḳ, TA,)</span> like <span class="ar">قَطَاةٌ</span>, <span class="auth">(TA, <span class="add">[but in the CK <span class="ar">بَدْأَة</span>, q. v.,]</span>)</span> <em>Truffles;</em> syn. <span class="ar">كَمْأَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="badaApN_B2">
					<p>And <em>Dust,</em> or <em>earth.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badowapN">
				<h3 class="entry"><span class="ar">بَدْوَةٌ</span></h3>
				<div class="sense" id="badowapN_A1">
					<p><span class="ar">بَدْوَةٌ</span> Either <em>side</em> of a valley. <span class="auth">(AḤn, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badawieBN">
				<h3 class="entry"><span class="ar">بَدَوِىٌّ</span></h3>
				<div class="sense" id="badawieBN_A1">
					<p><span class="ar">بَدَوِىٌّ</span> <span class="add">[<em>Of,</em> or <em>belonging to,</em> or <em>relating to, the</em> <span class="ar">بَدْو</span>, or <em>desert:</em> and, used as a subst., <em>a man,</em> and particularly <em>an Arab, of the desert:</em>]</span> a rel. n. from <span class="ar">بَدْوٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> extr. <span class="add">[with respect to rule]</span>, <span class="auth">(M, Ḳ,)</span> for by rule it should be <span class="ar">بَدْوِىٌّ</span>; <span class="auth">(El-Tebreezee, TA;)</span> or it is an irregular rel. n. from <span class="ar">بَادِيَةٌ</span>: <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">بَدَاوِىٌّ↓</span></span> and<span class="arrow"><span class="ar">بِدَاوِىٌّ↓</span></span> are similar rel. ns., <span class="auth">(M, Ḳ,)</span> from <span class="ar">بَدَاوَةٌ</span> and <span class="ar">بِدَاوَةٌ</span>, as syn. with <span class="ar">بَدْوٌ</span> and <span class="ar">بَادِيَةٌ</span>, agreeably with rule; or the former of these two may be a rel. n. from <span class="ar">بَدْوٌ</span> and <span class="ar">بَادِيَةٌ</span>, and therefore extr. <span class="add">[with respect to rule]</span>; but it is said that when a rel. n. may be regarded as regular or irregular, it is more proper to regard it as regular; <span class="auth">(M;)</span> or the former is a rel. n. signifying <em>of,</em> or <em>belonging to,</em> or <em>relating to,</em> <span class="ar">البَدَاوَة</span> as meaning <em>the dwelling,</em> or <em>abiding, in the desert,</em> <span class="auth">(Ṣ, TA,)</span> accord. to the opinion of AZ; and the latter is a rel. n. from <span class="ar">البِدَاوَة</span> accord. to the opinion of Aṣ and others; and is held by Th to be the chaste form: <span class="auth">(TA:)</span> but <span class="ar">بَدَوِىٌّ</span> is the only one of these rel. ns. that is known to the common people: <span class="auth">(M:)</span> it is opposed to a townsman or villager. <span class="auth">(TA.)</span> <span class="add">[The pl. is <span class="ar">بَدَاوَى</span>, and vulg. <span class="ar">بِدْوَانٌ</span>. <a href="#baAdK">See also <span class="ar">بَادٍ</span></a>, often applied to a man as syn. with <span class="ar">بَدَوِىٌّ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badawaAtN">
				<h3 class="entry"><span class="ar">بَدَوَاتٌ</span></h3>
				<div class="sense" id="badawaAtN_A1">
					<p><span class="ar">بَدَوَاتٌ</span>: <a href="#badaACN">see <span class="ar">بَدَآءٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaMCN.1">
				<h3 class="entry"><span class="ar">بَدَآءٌ</span></h3>
				<div class="sense" id="badaMCN.1_A1">
					<p><span class="ar">بَدَآءٌ</span> <span class="add">[<em>An opinion that occurs to one,</em> or <em>arises in the mind;</em> and particularly <em>one that is different from a former opinion;</em>]</span> a subst. from <span class="ar">بَدَا</span> in the phrase <span class="ar long">بَدَا لَهُ فِى الأَمْرِ</span>. <span class="auth">(Mṣb.)</span> <a href="#bdw_1">See 1</a>, in four places. One says also,<span class="arrow"><span class="ar long">هُوَ ذُو بَدَوَاتٍ↓</span></span> <em>He is one who has various opinions occurring to him,</em> or <em>arising in his mind,</em> <span class="auth">(IDrd, Ṣ,* Ḳ,* and Ḥar p. 665,)</span> <em>of which he chooses some and rejects others:</em> <span class="auth">(IDrd, TA:)</span> it is said in praise, <span class="auth">(IDrd, TA, and Kzz in Ḥar ubi suprà,)</span> and sometimes in dispraise: <span class="auth">(Kzz in Ḥar ubi suprà:)</span> <span class="ar">بَدَوَاتٌ</span> is pl. of<span class="arrow"><span class="ar">بَداةٌ↓</span></span>, <span class="add">[which is therefore syn. with <span class="ar">بَدَآءٌ</span>,]</span> like as <span class="ar">قَطَوَاتٌ</span> <a href="#qaTaApN">is pl. of <span class="ar">قَطَاةٌ</span></a>. <span class="auth">(IDrd, TA, and Ḥar ubi supra.)</span> One says likewise <span class="arrow"><span class="ar long">أَبُو البَدَوَاتِ↓</span></span>, meaning <em>The father</em> <span class="add">[i. e. <em>originator</em>]</span> <em>of opinions that present themselves to him.</em> <span class="auth">(IDrd, TA.)</span> And<span class="arrow"><span class="ar long">السُّلْطَانُ ذُو عَدَوَاتٍ وَذُو بَدَوَاتٍ↓</span></span> <span class="auth">(Ṣ, <span class="add">[in which the context indicates it to mean <em>The Sultán is characterized by deviations from the right way:</em>]</span> but accord. to SM, it is)</span> a trad., meaning <em>the Sultán ceases not to have some new opinion presenting itself to him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidaMCN">
				<h3 class="entry"><span class="ar">بِدَآءٌ</span></h3>
				<div class="sense" id="bidaMCN_A1">
					<p><span class="ar">بِدَآءٌ</span>, in the common dial. of the people of El-Yemen, signifies The <em>morning-meal;</em> syn. <span class="ar">غَدَآءٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badieN">
				<h3 class="entry"><span class="ar">بَدِىٌ</span></h3>
				<div class="sense" id="badieN_A1">
					<p><span class="ar">بَدِىٌ</span>: <a href="#baAdiyapN">see <span class="ar">بَادِيَةٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدِىٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badieN_A2">
					<p><a href="#badowN">and see <span class="ar">بَدْوٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدِىٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badieN_A3">
					<p>Also, <span class="add">[or <span class="ar long">بِئْرٌ بَدِىٌّ</span>,]</span> <a href="#badieoCN">originally <span class="ar">بَدِىْءٌ</span>, q. v.</a> <a href="../">in art. <span class="ar">بدأ</span></a>, <span class="auth">(TA,)</span> <em>A well:</em> <span class="auth">(T:)</span> or <em>a well that is not ancient:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بُودَانٌ</span>, formed by transposition from <span class="ar">بُدْيَانٌ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaMCapN.1">
				<h3 class="entry"><span class="ar">بَدَآءَةٌ</span></h3>
				<div class="sense" id="badaMCapN.1_A1">
					<p><span class="ar">بَدَآءَةٌ</span> <em>What appears,</em> or <em>becomes apparent,</em> of wants, or needful things: pl. <span class="ar">بَدَاآتٌ</span>; for which one may also say, <span class="ar">بَدَاوَاتٌ</span>. <span class="auth">(T.)</span> These two pls. also signify <em>Wants that appear,</em> or <em>become apparent, to one.</em> <span class="auth">(TA.)</span> <span class="add">[The latter of them is likewise pl. of what next follows.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaAwapN">
				<h3 class="entry"><span class="ar">بَدَاوَةٌ</span></h3>
				<div class="sense" id="badaAwapN_A1">
					<p><span class="ar">بَدَاوَةٌ</span> and <span class="ar">بِدَاوَةٌ</span>: <a href="#baAdiyapN">see <span class="ar">بَادِيَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَدَاوَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badaAwapN_A2">
					<p>The former also signifies The <em>first that appears,</em> or <em>becomes apparent,</em> of a thing. <span class="auth">(Lḥ, M, Ḳ.)</span> <span class="add">[<a href="#badaACapN">See <span class="ar">بَدَآءَةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badaAwieBN">
				<h3 class="entry"><span class="ar">بَدَاوِىٌّ</span> / <span class="ar">بِدَاوِىٌّ</span></h3>
				<div class="sense" id="badaAwieBN_A1">
					<p><span class="ar">بَدَاوِىٌّ</span> and <span class="ar">بِدَاوِىٌّ</span>: <a href="#badawieBN">see <span class="ar">بَدَوِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAdK">
				<h3 class="entry"><span class="ar">بَادٍ</span></h3>
				<div class="sense" id="baAdK_A1">
					<p><span class="ar">بَادٍ</span> <em>Appearing,</em> or <em>apparent;</em> or <em>becoming,</em> or <em>being, apparent, open, manifest, plain,</em> or <em>evident.</em> <span class="auth">(Mṣb.)</span> <span class="add">[Hence,]</span> <span class="ar long">بَادِىَ الرَّأْىِ</span> <em>At the</em> <span class="add">[<em>first</em>]</span> <em>appearance of opinion;</em> <span class="auth">(Fr, Lḥ, M;)</span> or <em>according to the appearance of opinion;</em> <span class="auth">(Zj, Ṣ, Ḳ;*)</span> which may mean either <em>insincerely</em> or <em>inconsiderately:</em> <span class="auth">(Zj, TA:)</span> so in the Ḳur xi. 29; <span class="auth">(Zj, Ṣ;)</span> where only AA read it with hemz: <span class="auth">(TA:)</span> if with hemz, it is from <span class="ar">بَدَأْتُ</span>, and means <em>at first thought,</em> or <em>on the first opinion.</em> <span class="auth">(Ṣ; and Lḥ in M, art. <span class="ar">بدأ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>.)</span> For <span class="ar long">بَادِى بَدٍ</span>, or <span class="ar long">بَادِىَ بَدٍ</span>, and <span class="ar long">بَادِى بَدِى</span>, &amp;c., <a href="#badowN">see <span class="ar">بَدْوٌ</span></a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَادٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAdK_A2">
					<p><span class="ar long">بَادِى بَدِى</span> is sometimes used as a name for <em>Calamity,</em> or <em>misfortune:</em> it consists of two nouns made one, like <span class="ar long">مَعْدِىْ كَرِبَ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَادٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAdK_A3">
					<p><span class="ar">بَادٍ</span> also signifies A man <em>going forth to the</em> <span class="ar">بَادِيَة</span> <span class="add">[or <em>desert</em>]</span>: <span class="auth">(M,* Mṣb, Ḳ,* TA:)</span> or one <em>who is in the</em> <span class="ar">بَادِيَة</span>, <em>dwelling in the tents, and not remaining in his place:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بَادُونَ</span> and <span class="ar">بُدًّا</span> <span class="add">[in the TA erroneously said to be <span class="ar">بُدًى</span> like <span class="ar">هُدًى</span>]</span> and <span class="ar">بُدَّآءٌ</span>: <span class="auth">(M, Ḳ:)</span> and<span class="arrow"><span class="ar">بَدْوٌ↓</span></span> is a quasi-pl. n. of <span class="ar">بَادٍ</span>; <span class="auth">(M, TA;)</span> or is for <span class="ar long">أَهْلُ بَدْوٍ</span>, meaning <em>people who go forth to the desert;</em> <span class="auth">(M;)</span> or it means <em>dwellers in the desert,</em> or <em>people of the desert:</em> <span class="auth">(MF:)</span> <span class="arrow"><span class="ar">بَادِيَةٌ↓</span></span> also signifies the same as <span class="ar">بَادُونَ</span>, i. e. people <em>migrating from the constant sources of water, and going forth to the desert, seeking the vicinity of herbage; contr. of</em> <span class="ar">حَاضِرَةٌ</span>; and <span class="ar">بَوَادِى</span> <span class="add">[or <span class="ar">بَوَادٍ</span>]</span> <a href="#baAdiyapN">is pl. of <span class="ar">بَادِيَةٌ</span></a>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAdaApN">
				<h3 class="entry"><span class="ar">بَادَاةٌ</span></h3>
				<div class="sense" id="baAdaApN_A1">
					<p><span class="ar">بَادَاةٌ</span>: <a href="#baAdiyapN">see what next follows</a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAdiyapN">
				<span class="pb" id="Page_0172"></span>
				<h3 class="entry"><span class="ar">بَادِيَةٌ</span></h3>
				<div class="sense" id="baAdiyapN_A1">
					<p><span class="ar">بَادِيَةٌ</span> <span class="auth">(T, Ṣ, &amp;c.)</span> <em>A desert;</em> so called because of its being open, or uncovered; <span class="auth">(TA;)</span> <em>contr. of</em> <span class="ar">حَضَرٌ</span>; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَدْوٌ↓</span></span>, <span class="auth">(Ṣ,* M, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بَادَاةٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> or<span class="arrow"><span class="ar">بَدَاةٌ↓</span></span>, <span class="auth">(TA, <span class="add">[thought by SM to be the correct form because found by him in the M, in which I find <span class="ar">باداة</span>,]</span>)</span> and<span class="arrow"><span class="ar">بَدِىٌّ↓</span></span>, said to be used as syn. with <span class="ar">بَادِيَةٌ</span> in a verse of Lebeed cited among the exs. of the preposition <span class="ar">بِ</span>, p. 142, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بدَاوَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">بِدَاوَةٌ↓</span></span>; <span class="auth">(M;)</span> <span class="add">[of which the last two and the second <span class="auth">(namely, <span class="ar">بَدْوٌ</span>,)</span> seem to be originally inf. ns.; <a href="#bdw_1">see 1</a>:]</span> or <em>a land in which are no towns or villages or cultivated soil:</em> <span class="auth">(Lth, T:)</span> or the <em>places to which people migrate from the constant sources of water, when they go forth to the desert, seeking the vicinity of herbage;</em> also termed <span class="ar">مَبَادٍ</span>, which is <em>syn. with</em> <span class="ar">مَنَاجِعُ</span>, <em>contr. of</em> <span class="ar">مَحَاضِرُ</span>, and pl. of<span class="arrow"><span class="ar">مَبْدًى↓</span></span>, <span class="auth">(T,)</span> this last signifying the <em>contr. of</em> <span class="ar">مَحْضَرٌ</span>: <span class="auth">(Ṣ:)</span> <a href="#baAdiyapN">the pl. of <span class="ar">بَادِيَةٌ</span></a> is <span class="ar">بَوَادٍ</span>. <span class="auth">(T, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدو</span> - Entry: <span class="ar">بَادِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAdiyapN_A2">
					<p><a href="#baAdK">See also <span class="ar">بَادٍ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabodFe">
				<h3 class="entry"><span class="ar">مَبْدًى</span> / <span class="ar">مَبَادٍ</span></h3>
				<div class="sense" id="mabodFe_A1">
					<p><span class="ar">مَبْدًى</span>: pl. <span class="ar">مَبَادٍ</span>: <a href="#baAdiyapN">see <span class="ar">بَادِيَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubodK">
				<h3 class="entry"><span class="ar">مُبْدٍ</span></h3>
				<div class="sense" id="mubodK_A1">
					<p><span class="ar long">رَكِىٌّ مُبْدٍ</span> <em>Wells showing their water; having it uncovered by dust</em> or <em>earth; contr. of</em> <span class="ar long">رَكِىٌ غَامِدٌ</span>. <span class="auth">(A in art. <span class="ar">غمد</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0170.pdf" target="pdf">
							<span>Lanes Lexicon Page 170</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0171.pdf" target="pdf">
							<span>Lanes Lexicon Page 171</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0172.pdf" target="pdf">
							<span>Lanes Lexicon Page 172</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
