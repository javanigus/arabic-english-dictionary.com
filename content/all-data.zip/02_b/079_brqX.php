<article class="root" id="Root_brqX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/078_brq">برق</a></span>
				<span class="ar">برقش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/080_brqE">برقع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brqX_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برقش</span></h3>
				<div class="sense" id="brqX_Q1_A1">
					<p><span class="ar">برْقَشَهُ</span>, <span class="auth">(Ṣ, A, TA,)</span> inf. n. <span class="ar">بَرْقَشَةٌ</span>, <span class="auth">(TA,)</span> <em>He variegated it with divers,</em> or <em>different, colours;</em> <span class="auth">(Ṣ, TA;)</span> from <span class="ar long">أَبُو بَرَاقِشَ</span>, the bird so called: <span class="auth">(Ṣ:)</span> or <em>he adorned him,</em> or <em>it.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#baroqaXapN">See also <span class="ar">بَرْقَشَةٌ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برقش</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brqX_Q1_A2">
					<p>Hence, <span class="ar long">بَرْقَشَ قَوْلَهُ</span> † <em>He embellished his saying.</em> <span class="auth">(Ḥar p. 235.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brqX_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبرقش</span></h3>
				<div class="sense" id="brqX_Q2_A1">
					<p><span class="ar">تَبَرْقَشَ</span> <em>He adorned himself</em> <span class="auth">(A, Ḳ)</span> <em>with various colours.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">تَبَرْقَشَ لَنَا</span> <em>He adorned himself with various colours for us:</em> <span class="auth">(Ḳ:)</span> or <em>with various colours of every kind.</em> <span class="auth">(TA.)</span> And <span class="ar">تَبَرْقَشَتْ</span> <em>She assumed various colours:</em> or <em>she varied in dispositions:</em> syn. <span class="ar">تَلَوَّنَتْ</span>. <span class="auth">(A.)</span> And <span class="ar long">تبرقش البَيْتُ</span> <em>The house,</em> or <em>chamber,</em> or <em>tent, became variegated.</em> <span class="auth">(TA.)</span> And <span class="ar long">تبرقشت البِلَادُ</span> <em>The countries became adorned with various colours;</em> from <span class="ar long">أَبُو بَرَاقِشَ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biroqiXN">
				<h3 class="entry"><span class="ar">بِرْقِشٌ</span></h3>
				<div class="sense" id="biroqiXN_A1">
					<p><span class="ar">بِرْقِشٌ</span> <em>A certain bird,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>different from that called</em> <span class="ar long">أَبُو بَرَاقِشَ</span>, <span class="auth">(Ḳ, accord. to the TA, <span class="add">[for we there read <span class="ar long">طَائِرٌ آخَرُ</span>; the bird called <span class="ar long">ابو براقش</span> having been mentioned before; but in the CK, in the place of <span class="ar">آخَرُ</span>, we find <span class="ar">أَخْضَرُ</span>, i. e., <em>green;</em>]</span>)</span> <em>of small size,</em> <span class="auth">(Ṣ, TA,)</span> <em>that assumes various colours, of the kind called</em> <span class="ar">حُمَّر</span>, <span class="auth">(TA,)</span> <em>like the sparrow,</em> <span class="auth">(Ṣ, TA,)</span> <em>and called</em> <span class="ar">شُرْشُورٌ</span> <span class="auth">(Ṣ, Ḳ)</span> <em>by the people of El-Ḥijáz:</em> <span class="auth">(Ṣ, TA:)</span> but Az states his having heard certain of the Arabs of the desert call it <span class="ar long">ابو براقش</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroqaXapN">
				<h3 class="entry"><span class="ar">بَرْقَشَةٌ</span></h3>
				<div class="sense" id="baroqaXapN_A1">
					<p><span class="ar">بَرْقَشَةٌ</span> The <em>diversity of colour of that which is termed</em> <span class="ar">أَرْقَشُ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#brqX_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraAqiXa">
				<h3 class="entry"><span class="ar">بَرَاقِشَ</span></h3>
				<div class="sense" id="baraAqiXa_A1">
					<p><span class="ar long">أَبُو بَرَاقِشَ</span> <em>A certain bird that assumes various colours;</em> <span class="auth">(Ṣ;)</span> <em>a small wild bird, like the</em> <span class="ar">قَنْفُذ</span> <span class="add">[or <em>hedge-hog,</em> but <span class="ar">قُنْفُذ</span> is probably a mistranscription for <span class="ar">قُنْبُر</span>, or <em>lark</em>]</span>, <em>the upper part of whose feathers is dust-coloured</em> (<span class="ar">أَغْبَرُ</span>, as in the Ḳ, accord. to the TA), or <em>white</em> (<span class="ar">أَغَرُّ</span>, as in some copies of the Ḳ), <em>and the middle red, and the lower part black, so that when it is roused,</em> or <em>provoked, it ruffles its feathers and becomes variously changed in colour:</em> <span class="auth">(Lth, Ḳ:)</span> <em>or a certain bird that is found in the trees called</em> <span class="ar">عِضَاه</span>, and the colour of which is <em>between blackness and whiteness, having six</em> <span class="ar">قَوَادِم</span> <span class="add">[<em>or primary feathers</em>]</span>, <em>three on each side, heavy in the rump, that makes a noise with its wings when it flies, and assumes various colours:</em> <span class="auth">(IKh:)</span> <em>a certain variegated bird.</em> <span class="auth">(TA in art. <span class="ar">ابو</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برقش</span> - Entry: <span class="ar">بَرَاقِشَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baraAqiXa_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">هُوَ أَبُو بَرَاقِشَ</span> † <em>He is varying,</em> or <em>variable, in dispositions.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaraAqiXiyBu">
				<h3 class="entry"><span class="ar">البَرَاقِشِيُّ</span></h3>
				<div class="sense" id="AlbaraAqiXiyBu_A1">
					<p><span class="ar long">الجَارُ البَرَاقِشِيُّ</span> <em>The neighbour that is variable in his actions;</em> like <span class="ar long">الجَارُ اليَرْبُوعِىىُّ</span>. <span class="auth">(IAạr, TA in art. <span class="ar">جور</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0192.pdf" target="pdf">
							<span>Lanes Lexicon Page 192</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
