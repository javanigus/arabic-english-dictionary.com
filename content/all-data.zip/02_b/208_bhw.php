<article class="root" id="Root_bhw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/207_bhm">بهم</a></span>
				<span class="ar">بهو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/209_bhe">بهى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهو</span> ⇒ <span class="ar">بهى</span></h3>
				<div class="sense" id="bhw_1_A1">
					<p><span class="ar">بَهَا</span>, <span class="auth">(JK, Mṣb, Ḳ,)</span> aor. <span class="ar">يَبْهَا</span>, <span class="auth">(JK,)</span> or <span class="ar">يَبْهُو</span>; <span class="auth">(Mṣb, Ḳ;)</span> and <span class="ar">بَهُوَ</span>, aor. <span class="ar">يَبْهُو</span>; and <span class="ar">بَهِىَ</span>, aor. <span class="ar">يَبْهَى</span>; <span class="auth">(Ṣ,* Ḳ;)</span> and <span class="ar">بَهَى</span>, <span class="add">[first pers. <span class="ar">بَهَيْتُ</span>,]</span> aor. <span class="ar">يَبْهَى</span>; <span class="auth">(Ḳ;)</span> inf. n. <span class="ar">بَهَآءٌ</span> and <span class="ar">بَهَآءَةٌ</span>; <span class="auth">(JK, TA;)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> or <em>it, was, </em> or <em>became, characterized by,</em> or <em>possessed of,</em> <span class="ar">بَهَآء</span>, meaning <em>beauty,</em> or <em>goodliness</em> <span class="add">[&amp;c.]</span>. <span class="auth">(JK, Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhw_1_B1">
					<p><span class="ar">بَهَوْتُهُ</span> and <span class="ar">بَهَيْتُهُ</span>: <a href="#bhw_3">see 3</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bhw_1_C1">
					<p><span class="ar">بَهِىَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَوُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَهًا</span>, <span class="auth">(TA,)</span> <em>It</em> <span class="auth">(a tent, Ṣ, Ḳ)</span> <em>was,</em> or <em>became, empty,</em> or <em>vacant:</em> <span class="auth">(Ḳ:)</span> or <em>it was,</em> or <em>became, rent,</em> or <em>pierced with holes, and rendered vacant.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bhw_1_D1">
					<p><span class="ar long">بَهِىَ بِهِ</span> <em>i. q.</em> <span class="ar long">بَهَأَ بِهِ</span> <span class="add">[q. v.]</span>. <span class="auth">(JK.)</span> And <span class="ar long">بَهَؤُوا بِهِ</span> occurs in a trad., as they relate it, for <span class="ar long">بَهَؤُوا بِهِ</span>. <span class="auth">(AʼObeyd, TA in art. <span class="ar">بهأ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhw_2">
				<h3 class="entry">2. ⇒ <span class="ar">بهّو</span> ⇒ <span class="ar">بهّى</span></h3>
				<div class="sense" id="bhw_2_A1">
					<p><span class="ar">بهّاهُ</span>, inf. n. <span class="ar">تَبْهِيَةٌ</span>, <em>He made it wide,</em> or <em>ample;</em> or <em>widened it;</em> and <em>made it;</em> namely, a <span class="ar">بَيْت</span> <span class="add">[i. e. tent, or house]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhw_3">
				<h3 class="entry">3. ⇒ <span class="ar">باهو</span> ⇒ <span class="ar">باهى</span></h3>
				<div class="sense" id="bhw_3_A1">
					<p><span class="ar">باهاهُ</span>, <span class="auth">(TA,)</span> <span class="add">[and <span class="ar long">باهى بِهِ</span>, as will be seen from what follows,]</span> inf. n. <span class="ar">مُبَاهَاةٌ</span>, <span class="auth">(Ṣ, TA,)</span> <em>He vied,</em> or <em>competed, with him,</em> or <em>contended with him for superiority, in beauty,</em> or <em>goodliness,</em> or <em>in glorying,</em> or <em>boasting,</em> or <em>in glory,</em> or <em>excellence; he emulated,</em> or <em>rivalled, him therein;</em> or, simply, <em>he vied with him;</em> syn. <span class="ar">بَارَاهُ</span>; <span class="auth">(TA in art. <span class="ar">بهج</span>;)</span> and <span class="ar">فَاخَرَهُ</span>. <span class="auth">(Ṣ,* TA.)</span> Hence, in a trad. respecting ʼArafeh, <span class="ar long">تُبَاهِى بِهِمُ المَلَائِكَةُ</span> <span class="add">[<em>The angels vie with them</em>]</span>. <span class="auth">(TA.)</span> You say,<span class="arrow"><span class="ar long">بَاهَانِى فَبَهَوْتُهُ↓</span></span> <span class="auth">(Lḥ, JK, Ḳ *)</span> and<span class="arrow"><span class="ar">بَهَيْتُهُ↓</span></span> <span class="auth">(Lḥ, JK)</span> i. e. <span class="add">[<em>He vied,</em> or <em>competed, with me,</em> or <em>contended with me for superiority, in beauty,</em> or <em>goodliness,</em>, &amp;c.,]</span> <em>and I became,</em> <span class="auth">(Lḥ,)</span> or <em>I was,</em> <span class="auth">(JK,)</span> <em>more beautiful,</em> or <em>goodly,</em> <span class="add">[&amp;c.,]</span> <em>than he,</em> <span class="auth">(Lḥ, JK,)</span> or <em>I surpassed him in beauty,</em> or <em>goodliness</em> <span class="add">[&amp;c.]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابهو</span> ⇒ <span class="ar">ابهى</span></h3>
				<div class="sense" id="bhw_4_A1">
					<p><span class="ar">ابهى</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, beautiful,</em> or <em>handsome, in face.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0270"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhw_4_B1">
					<p><span class="ar">ابهاهُ</span> <span class="add">[<em>He deprived it of beauty,</em> or <em>goodliness;</em> the <span class="ar">ا</span> being a privative, as it often is, like the Greek <em>a:</em> this is probably the primary signification: <span class="auth">(see Freytag's Arab. Prov. ii. 604:)</span> and hence,]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bhw_4_B2">
					<p><em>He made it empty,</em> or <em>vacant:</em> <span class="auth">(Ḳ:)</span> or <em>he rent it,</em> or <em>made holes in it:</em> <span class="auth">(JK:)</span> or <em>he rent it,</em> or <em>made holes in it, and rendered it vacant:</em> <span class="auth">(Ṣ:)</span> namely, a tent. <span class="auth">(JK, Ṣ, Ḳ.)</span> Hence the saying, <span class="ar long">المِعْزَى تُبْهِى وَلَا تُبْنِى</span> <span class="add">[<a href="index.php?data=02_b/198_bne">explained in art. <span class="ar">بنى</span></a>]</span>: <span class="auth">(JK, Ṣ:)</span> applied to him who injures and does not profit. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bhw_4_B3">
					<p><em>He emptied it;</em> namely, a vessel. <span class="auth">(AʼObeyd, JK, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bhw_4_B4">
					<p><span class="ar long">ابهى الخَيْلَ</span> <em>He freed the horses from service</em> <span class="auth">(JK, Ṣ, Ḳ)</span> <em>in warfare;</em> <span class="auth">(Ṣ, Ḳ;)</span> i. e. <em>he did not go to war upon the horses:</em> <span class="auth">(TA:)</span> or <em>he divested the horses of their furniture, and did not ride them:</em> or <em>he supplied the horses amply with fodder, and gave them rest:</em> but the first is the-approved explanation. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباهو</span> ⇒ <span class="ar">تباهى</span></h3>
				<div class="sense" id="bhw_6_A1">
					<p><span class="ar">تَبَاهَوْا</span> <em>They vied,</em> or <em>competed,</em> or <em>contended for superiority, one with another,</em> <span class="add">[<em>in beauty,</em> or <em>goodliness,</em> or]</span> <em>in glorying,</em> or <em>boasting,</em> or <em>in glory,</em> or <em>excellence; they emulated,</em> or <em>rivalled, one another therein;</em> or, simply, <em>they vied, one with another;</em> syn. <span class="ar">تَفَاخَرُوا</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhw_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتهو</span> ⇒ <span class="ar">ابتهى</span></h3>
				<div class="sense" id="bhw_8_A1">
					<p><span class="ar">يَبْتَهِى</span> occurs in a verse of El-Aạshà for <span class="ar">يَبْتَهِئُ</span>. <span class="auth">(O, TṢ, L, on the authority of Aṣ, in art. <span class="ar">بهأ</span>, q. v.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahowN">
				<h3 class="entry"><span class="ar">بَهْوٌ</span></h3>
				<div class="sense" id="bahowN_A1">
					<p><span class="ar">بَهْوٌ</span> <em>Ampleness;</em> or <em>an ample state,</em> or <em>condition:</em> so in the saying, <span class="ar long">هُوَ فِى بَهْوٍ مِنَ العَيْشِ</span> <span class="add">[<em>He is in an ample state,</em> or <em>condition, of life</em>]</span>: and this is <span class="add">[said to be]</span> the primary signification. <span class="auth">(Aṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahowN_A2">
					<p>Anything <em>ample, wide,</em> or <em>spacious.</em> <span class="auth">(Ḳ.)</span> <span class="add">[Hence,]</span> <span class="ar long">نَاقَةٌ بَهْوَةٌ الجَنَبَيْنِ</span> <em>A she-camel wide in the two sides.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bahowN_A3">
					<p><em>A wide,</em> or <em>spacious, tract of land,</em> <span class="auth">(Ḳ, TA,)</span> <em>in which are no mountains, between two elevated tracts.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bahowN_A4">
					<p><em>A wide covert,</em> or <em>hiding-place, of a</em> <span class="add">[<em>wild</em>]</span> <em>bull,</em> <span class="auth">(JK, Ḳ, TA,)</span> <em>which he makes for himself at the foot of the kind of tree called</em> <span class="ar">أَرْطًى</span> <span class="add">[q. v.]</span>: <span class="auth">(TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْهَآءٌ</span> and <span class="add">[of mult.]</span> <span class="ar">بُهُوٌّ</span> and <span class="add">[quasi-pl.-n.]</span> <span class="ar">بَهِىٌّ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bahowN_A5">
					<p>Any <em>vacant,</em> or <em>intervening, space.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bahowN_A6">
					<p>The <em>interior of the chest,</em> or <em>breast,</em> <span class="auth">(Ḳ, TA,)</span> of a man and of any beast: <span class="auth">(TA:)</span> or the <em>space that intervenes between the two breasts and the uppermost part of the chest</em> <span class="auth">(Ḳ, TA)</span> is called <span class="ar long">بَهْوُ الصَّدْرِ</span>: <span class="auth">(TA:)</span> or the <em>part between</em> <span class="add">[or <em>within</em>]</span> <em>the extremities of the ribs that project over the belly:</em> <span class="auth">(TA:)</span> and in her that is pregnant, <span class="auth">(JK, Ḳ,)</span> whatever she be, <span class="auth">(JK,)</span> the <em>resting-place of the fœtus, between the two haunches:</em> <span class="auth">(JK, Ḳ:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْهَآءٌ</span> and <span class="ar">أَبْهٍ</span> and <span class="add">[of mult.]</span> <span class="ar">بُهِىٌّ</span> and <span class="add">[quasi-pl. n.]</span> <span class="ar">بَهِىٌّ</span> <span class="add">[in the TA <span class="ar">بِهِىٌّ</span>, which seems to be a mistake]</span>. <span class="auth">(Ḳ)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bahowN_A7">
					<p><em>A tent that is placed in advance, before the other tents:</em> <span class="auth">(JK, Ṣ, TA:)</span> pl. <span class="ar">أَبْهَآءٌ</span>. <span class="auth">(JK.)</span> In a trad., Arabs are spoken of as removing with their <span class="ar">أَبْهَآء</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahK">
				<h3 class="entry"><span class="ar">بَهٍ</span></h3>
				<div class="sense" id="bahK_A1">
					<p><span class="ar">بَهٍ</span> <span class="add">[originally <span class="ar">بَهِوٌ</span>]</span>: <a href="#bahieBN">see <span class="ar">بَهِىٌّ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahaMCN.1">
				<h3 class="entry"><span class="ar">بَهَآءٌ</span></h3>
				<div class="sense" id="bahaMCN.1_A1">
					<p><span class="ar">بَهَآءٌ</span> <em>Beauty,</em> or <em>goodliness:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> <em>beauty of aspect, of mien,</em> or <em>of external state</em> or <em>condition:</em> <span class="auth">(Mṣb:)</span> <em>a beautiful aspect, that excites admiration, and satisfies the eye:</em> <span class="auth">(TA:)</span> and, as an attribute of God, <span class="auth">(Mṣb,)</span> <em>greatness,</em> or <em>majesty.</em> <span class="auth">(Mṣb, Ḥar p. 271.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهَآءٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahaMCN.1_A2">
					<p>‡ The <em>froth of milk:</em> <span class="auth">(JK:)</span> or the <em>glistening of the froth of milk.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَهَآءٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bahaMCN.1_B1">
					<p>As an epithet applied to a she-camel, <a href="../">it belongs to art. <span class="ar">بهأ</span></a> <span class="add">[in which it is explained]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahieBN">
				<h3 class="entry"><span class="ar">بَهِىٌّ</span></h3>
				<div class="sense" id="bahieBN_A1">
					<p><span class="ar">بَهِىٌّ</span> <em>Possessing the quality,</em> or <em>attribute, of</em> <span class="ar">بَهَآء</span> <span class="add">[i. e. <em>beauty,</em> or <em>goodliness,</em>, &amp;c.]</span>; <span class="auth">(JK, Ṣ, Mṣb;)</span> <em>the beauty of which,</em> <span class="auth">(JK,)</span> or <em>the pleasing appearance of which,</em> <span class="auth">(TA,)</span> <em>satisfies the eye;</em> <span class="auth">(JK, TA;)</span> as also<span class="arrow"><span class="ar">بَهٍ↓</span></span> and<span class="arrow"><span class="ar">بَاهٍ↓</span></span>: <a href="#bahieBN">the fem. of <span class="ar">بَهِىٌّ</span></a> is <span class="ar">بَهِيَّةٌ</span>; of which the pl. is <span class="ar">بَهِيَّاتٌ</span> and <span class="ar">بَهَايَا</span>: and the fem. of <span class="arrow"><span class="ar">بَهٍ↓</span></span> is <span class="ar">بَهِيَةٌ</span>; and the pl. is <span class="ar">أَبْهِيَآءُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhK">
				<h3 class="entry"><span class="ar">بَاهٍ</span></h3>
				<div class="sense" id="baAhK_A1">
					<p><span class="ar">بَاهٍ</span>: <a href="#bahieBN">see <span class="ar">بَهِىٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَاهٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAhK_B1">
					<p>Also, applied to a <span class="ar">بَيْت</span> <span class="add">[or tent (<a href="#bahiea">see <span class="ar">بَهِىَ</span></a>)]</span>, <em>Empty,</em> or <em>vacant;</em> <span class="auth">(JK, Ṣ, Ḳ;)</span> <em>containing nothing:</em> <span class="auth">(Ṣ:)</span> or <em>containing little furniture,</em> or <em>few goods</em> or <em>utensils.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهو</span> - Entry: <span class="ar">بَاهٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baAhK_B2">
					<p><span class="ar long">بِئْرٌ بَاهِيَةٌ</span> <em>A wide-mouthed well.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabohae">
				<h3 class="entry"><span class="ar">أَبْهَى</span></h3>
				<div class="sense" id="Oabohae_A1">
					<p><span class="ar">أَبْهَى</span> <span class="add">[<em>More,</em> and <em>most, beautiful,</em> or <em>goodly;</em>]</span> <em>surpassingly,</em> or <em>superlatively, beautiful,</em> or <em>goodly:</em> fem. <span class="ar">بُهْيَا</span>; which is applied to a woman, and, by Honeyf El-Hanátim, to a she-camel. <span class="auth">(Az, TA.)</span> <span class="add">[Hence,]</span> one says, <span class="ar long">إِنَّ هٰذَا لَبُهْيَاىَ</span> <span class="add">[<em>This is my superlatively beautiful quality;</em> or]</span> <em>this is of the things in which I vie with others.</em> <span class="auth">(AA, ISk.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0269.pdf" target="pdf">
							<span>Lanes Lexicon Page 269</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0270.pdf" target="pdf">
							<span>Lanes Lexicon Page 270</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
