<article class="root" id="Root_brw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/087_brhn">برهن</a></span>
				<span class="ar">برو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/089_bre">برى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brw_1">
				<h3 class="entry">1. ⇒ <span class="ar">برو</span> ⇒ <span class="ar">برى</span></h3>
				<div class="sense" id="brw_1_A1">
					<p><span class="ar">بَرَوْتُهَا</span>, i. e. <span class="ar">النَّاقَةَ</span>: <a href="#brw_4">see 4</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brw_1_B1">
					<p><span class="ar">بَرَوْتُهُ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُوُ</span>}</span></add>, <span class="auth">(Lth, T,)</span> inf. n. <span class="ar">بَرْوٌ</span>, <span class="auth">(M,)</span> <em>I formed it,</em> or <em>fashioned it, by cutting; shaped it out;</em> or <em>pared it;</em> <span class="auth">(Ḳ;)</span> namely, a reed for writing, <span class="auth">(Lth, T, M, Mṣb, Ḳ,)</span> and a stick, or piece of wood, <span class="auth">(M, Ḳ,)</span> and an arrow, <span class="auth">(Ḳ,)</span> <span class="add">[&amp;c.;]</span> <a href="#bre_1">a dial. var. of <span class="ar">بَرَيْتُهُ</span></a>, <span class="auth">(Lth, T, M, Mṣb,)</span> used by some, <span class="auth">(Lth, T,)</span> but the latter is the more approved: <span class="auth">(M, TA:)</span> mentioned by AZ. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brw_1_B2">
					<p><span class="add">[Hence, perhaps,]</span> <span class="ar">بَرَاهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُوُ</span>}</span></add>, inf. n. <span class="ar">بَرْوٌ</span>, <em>He</em> <span class="auth">(i. e. God)</span> <em>created him,</em> or <em>it:</em> <span class="auth">(Fr, Ṣ, Ḳ:)</span> <span class="add">[but]</span> they affirm that it is originally <span class="ar">بَرَأَهُ</span>, with hemz: <span class="auth">(MF:)</span> so says IAth: <span class="auth">(TA:)</span> or it is from <span class="ar">بَرًا</span> or <span class="ar">بَرًى</span>, signifying “dust,” or “earth.” <span class="auth">(Fr, Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brw_1_C1">
					<p><span class="ar">بَرَا</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُوُ</span>}</span></add>, is also a bad <a href="#baraOa">dial. var. of <span class="ar">بَرَأَ</span></a> <span class="add">[signifying <em>He,</em> or <em>it, recovered</em> from disease, or <em>became convalescent,</em>, &amp;c.]</span>, aor. <span class="ar">يَبْرُؤُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرو</span> ⇒ <span class="ar">ابرى</span></h3>
				<div class="sense" id="brw_4_A1">
					<p><span class="ar">أَبْرَيْتُهَا</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> i. e. <span class="ar">النَّاقَةَ</span>, <span class="auth">(Ṣ, M,)</span> <em>I put a</em> <span class="add">[<em>ring such as is termed</em>]</span> <span class="ar">بُرَة</span> <em>in her</em> <span class="auth">(a camel's)</span> <em>nose;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَرَوْتُهَا↓</span></span>: <span class="auth">(IJ, M, Ḳ:)</span> and <span class="ar">ابريتهُ</span>, namely, a camel, <em>I put him a</em> <span class="ar">بُرَة</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برو</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brw_4_B1">
					<p><span class="ar">ابرى</span> <em>Dust,</em> or <em>earth, came,</em> or <em>lighted, upon it.</em> <span class="auth">(Ḳ,* TA, in art. <span class="ar">برى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burapN">
				<h3 class="entry"><span class="ar">بُرَةٌ</span></h3>
				<div class="sense" id="burapN_A1">
					<p><span class="ar">بُرَةٌ</span> <span class="auth">(in which the final radical letter is elided, <span class="add">[and replaced by <span class="ar">ة</span>,]</span> Msb)</span> <em>A ring</em> <span class="auth">(T, Ṣ, M, &amp;c.)</span> <em>of brass,</em> <span class="auth">(Lth, Lḥ, T, Ṣ, M, <span class="add">[in a copy of the Mṣb, <span class="ar long">من صوف</span> is erroneously put for <span class="ar long">مِنْ صُفْرٍ</span>,]</span>)</span> or <em>of silver,</em> <span class="auth">(Lth, T,)</span> or <em>of some other material,</em> <span class="auth">(Lḥ, M,)</span> <em>slender, and bent at the two ends</em> <span class="add">[lest it should open at the place where the two ends meet]</span>, <em>that is put in the nose of a she-camel,</em> <span class="auth">(Lth, T,)</span> or <em>put in the nose of the camel,</em> <span class="auth">(M, Mṣb, Ḳ,)</span> or <em>in the flesh of the nose of the camel,</em> <span class="auth">(Lḥ, Ṣ, M, Ḳ,)</span> or, as Aṣ says, <em>in one of the two sides of the two nostrils,</em> <span class="auth">(Ṣ,)</span> app. <em>either for the purpose of ornament or to render the animal obedient;</em> <span class="auth">(MF;)</span> <span class="add">[<em>generally for the latter purpose, to attach the rein thereto:</em>]</span> when the ring is of hair, it is termed <span class="ar">خِزَامَةٌ</span>; <span class="auth">(Aṣ, Ṣ, Mṣb;)</span> and when of wood, <span class="ar">خِشَاشٌ</span>: <span class="auth">(Mṣb:)</span> Aboo-ʼAlee mentions, and explains in like manner, <span class="arrow"><span class="ar">بَرْوَةٌ↓</span></span> and <span class="ar">بُرًى</span>; <span class="add">[the latter as pl. of the former;]</span> but this is extr.: <span class="auth">(M:)</span> J says, <span class="add">[in the Ṣ,]</span> Aboo-ʼAlee says that <span class="ar">بُرَةٌ</span> is originally <span class="ar">بَرْوَةٌ</span>, because it has <span class="ar">بُرًى</span> for a pl., like as <span class="ar">قَرْيَة</span> has <span class="ar">قُرًى</span>; but Aboo-ʼAlee does not say this; he only desires to show that the final radical letter of <span class="ar">بُرَةٌ</span> is <span class="ar">و</span> by the fact that <span class="ar">بَرْوَةٌ</span> is a dial. var. thereof: <span class="auth">(IB, TA:)</span> some, however, remarking upon J's saying that the original of <span class="ar">بَرَةٌ</span> is <span class="ar">بَرْوَةٌ</span>, assert that it is correctly <span class="arrow"><span class="ar">بُرْوَةٌ↓</span></span>: <span class="auth">(TA:)</span> <span class="ar">بُرَةٌ</span> also signifies <em>an anklet:</em> <span class="auth">(M, Ḳ:)</span> or <em>any ring; such as a bracelet</em> and <em>an earring</em> and <em>an anklet</em> and <em>the like of these:</em> <span class="auth">(Ṣ:)</span> the pl. <span class="auth">(in the former and the latter senses, M, TA)</span> is <span class="ar">بُرَاتٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> in <span class="add">[some of]</span> the copies of the Ḳ erroneously written <span class="ar">بُرَاةٌ</span>, <span class="auth">(TA,)</span> and <span class="ar">بُرًى</span>, <span class="auth">(T, Ṣ, M,)</span> and <span class="ar">بُرُونَ</span>, contr. to analogy, <span class="auth">(Mṣb,)</span> or <span class="ar">بُرِينَ</span> <span class="auth">(T, Ṣ, M, Ḳ, <span class="add">[in all of which, except the last, this is in the accus. or the gen. case, but, as it is the nom. case in the Ḳ, it may be that <span class="ar">بُرُونَ</span> and <span class="ar">بُرِينَ</span> are dial. vars., like <span class="ar">سِنُونَ</span> and <span class="ar">سِنِينَ</span>,]</span>)</span> and <span class="ar">بُرِينَ</span>. <span class="auth">(M, Ḳ: <span class="add">[in a copy of the former of which, accord. to the TT, <span class="ar">بُرِىٌّ</span> and <span class="ar">بِرِىٌّ</span> are put in the place of the last two of these pls.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barFA">
				<h3 class="entry"><span class="ar">بَرًا</span></h3>
				<div class="sense" id="barFA_A1">
					<p><span class="ar">بَرًا</span>, or <span class="ar">بَرًى</span>, <em>Dust,</em> or <em>earth:</em> <span class="auth">(Fr, Ṣ, M, Mṣb, Ḳ, mentioned in the M and Ḳ in art. <span class="ar">برى</span>:)</span> whence <span class="ar">بَرَاهُ</span>, <span class="add">[if not originally <span class="ar">بَرَأَهُ</span>,]</span> meaning “He <span class="auth">(i. e. God)</span> created him.” <span class="auth">(Fr, Ṣ.)</span> Hence the saying, <span class="ar long">بِفِيهِ البَرَا</span>, or <span class="ar">البَرَى</span>, <span class="add">[<em>In his mouth</em> be <em>dust,</em> or <em>earth</em>]</span>, <span class="auth">(Ṣ, M,)</span> a form of imprecation against a man. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barowapN">
				<h3 class="entry"><span class="ar">بَرْوَةٌ</span></h3>
				<div class="sense" id="barowapN_A1">
					<p><span class="ar">بَرْوَةٌ</span> <em>Cuttings, chips, parings,</em> or <em>the like,</em> of a reed for writing, and of a stick, or piece of wood, and of soap, and the like. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برو</span> - Entry: <span class="ar">بَرْوَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barowapN_B1">
					<p><a href="#burapN">See also <span class="ar">بُرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burowapN">
				<h3 class="entry"><span class="ar">بُرْوَةٌ</span></h3>
				<div class="sense" id="burowapN_A1">
					<p><span class="ar">بُرْوَةٌ</span>: <a href="#burapN">see <span class="ar">بُرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbariyBapN">
				<h3 class="entry"><span class="ar">البَرِيَّةٌ</span></h3>
				<div class="sense" id="AlbariyBapN_A1">
					<p><span class="ar">البَرِيَّةٌ</span> <em>The creation; as meaning the beings,</em> or <em>things, that are created;</em> or, particularly, <em>mankind;</em> syn. <span class="ar">الخَلْقُ</span>: originally with <span class="ar">ء</span>: <span class="auth">(Ṣ:)</span> but not pronounced with <span class="ar">ء</span>: <span class="auth">(IAth, TA in art. <span class="ar">برى</span>:)</span> or, accord. to Fr, if from <span class="ar">بَرًا</span>, or <span class="ar">بَرًى</span>, i. e. “dust,” or “earth,” it is originally without <span class="ar">ء</span>: pl. <span class="ar">بَرَايَا</span> and <span class="ar">بَرِيَّاتٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboraApN">
				<h3 class="entry"><span class="ar">مُبْرَاةٌ</span></h3>
				<div class="sense" id="muboraApN_A1">
					<p><span class="ar">مُبْرَاةٌ</span> A she-camel <span class="auth">(T, Ṣ)</span> <em>having a</em> <span class="add">[<em>ring such as is termed</em>]</span> <span class="ar">بُرَة</span> <em>put in her nose:</em> <span class="auth">(T, Ṣ, Ḳ:)</span> pl. <span class="ar">مُبْرَيَاتٌ</span>. <span class="auth">(TA in art. <span class="ar">عرف</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboruwBapN">
				<h3 class="entry"><span class="ar">مَبْرُوَّةٌ</span></h3>
				<div class="sense" id="maboruwBapN_A1">
					<p><span class="ar long">بُرَةٌ مَبْرُوَّةٌ</span> <span class="auth">(T, M, Ḳ)</span> <em>A</em> <span class="ar">بُرَة</span> <em>made,</em> or <em>manufactured.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0197.pdf" target="pdf">
							<span>Lanes Lexicon Page 197</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
