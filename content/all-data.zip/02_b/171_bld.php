<article class="root" id="Root_bld">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/170_blH">بلح</a></span>
				<span class="ar">بلد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/172_blz">بلز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bld_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلد</span></h3>
				<div class="sense" id="bld_1_A1">
					<p><span class="ar">بَلَدَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِدُ</span>}</span></add>, <span class="add">[inf. n. <span class="ar">بُلُودٌ</span>,]</span> <em>He</em> <span class="auth">(a man)</span> <em>remained, stayed, abode,</em> or <em>dwelt, in the</em> <span class="ar">بَلَد</span> <span class="add">[i. e. <em>country,</em> or <em>town,</em>, &amp;c.]</span>: <span class="auth">(Mṣb:)</span> or <span class="ar long">بَلَدَ بِالمَكَانَ</span>, <span class="auth">(T, Ṣ, M, L, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُدُ</span>}</span></add>, <span class="auth">(M, L,)</span> inf. n. <span class="ar">بُلُودٌ</span>, <span class="auth">(T, M, L, Ḳ,)</span> <em>he remained, stayed, abode,</em> or <em>dwelt, in the place,</em> <span class="auth">(AZ, T, Ṣ, L, Ḳ,)</span> <em>and kept to it:</em> <span class="auth">(Ḳ:)</span> or <em>he took it as his</em> <span class="ar">بَلَد</span> <span class="add">[or <em>country,</em> or <em>town,</em>, &amp;c.]</span>, <span class="auth">(M, L, Ḳ,)</span> <em>and kept to it.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bld_1_A2">
					<p>And <span class="ar">بَلِدُوا</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَدُ</span>}</span></add>; <span class="auth">(M, Ḳ;)</span> and <span class="ar">بَلَدُوا</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُدُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> or the latter is correctly <span class="arrow"><span class="ar">بلّدوا↓</span></span>; <span class="auth">(M,* TA;)</span> <em>They kept to the ground, fighting upon it:</em> <span class="auth">(M, Ḳ:)</span> said to be derived from <span class="ar long">بِلَادُ الأَرْضِ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bld_1_B1">
					<p><span class="ar">بَلِدَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَدُ</span>}</span></add>, <em>His skin had</em> <span class="ar">أَبْلَاد</span>, or <em>marks,</em> <span class="add">[<a href="#baladN">pl. of <span class="ar">بَلَدٌ</span></a>,]</span> <em>remaining upon it.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bld_1_B2">
					<p>Also, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَلَدٌ</span>, <span class="auth">(Ṣ, M,)</span> <em>He</em> <span class="auth">(a man, M)</span> <em>had a space clear from hair between his eyebrows:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or <em>had eyebrows not joined.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bld_1_C1">
					<p><span class="ar">بَلُدَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُدُ</span>}</span></add>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَلَادَةٌ</span>, <span class="auth">(T, Ṣ, M, A, Mṣb,)</span> <em>He was,</em> or <em>became, stupid, dull, wanting in intelligence:</em> <span class="auth">(Ṣ, A, Mṣb:)</span> <em>inert; wanting in vigour; not penetrating, sharp, vigorous,</em> or <em>effective, in the performance of affairs;</em> <span class="auth">(T, M, Ḳ,* TA;)</span> <span class="add">[or <em>soft, weak, feeble, wanting in endurance,</em> or <em>patience;</em> (<a href="#baliydN">see <span class="ar">بَلِيدٌ</span></a>;)]</span> as also <span class="ar">بَلِدَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَدُ</span>}</span></add>, <span class="auth">(Ḳ, TA,)</span> inf. n. <span class="ar">بَلَدٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="bld_1_C2">
					<p>Also, inf. n. as above, said of a horse, meaning <em>He lagged behind those that outstripped in running.</em> <span class="auth">(T, TA.)</span> <span class="add">[<a href="#bld_2">See also 2</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="bld_1_C3">
					<p><span class="ar long">بَلَدَ السَّحَابُ</span>: <a href="#bld_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bld_2">
				<h3 class="entry">2. ⇒ <span class="ar">بلّد</span></h3>
				<div class="sense" id="bld_2_A1">
					<p><span class="ar">بلّد</span>, inf. n. <span class="ar">تَبْلِيدٌ</span>, <em>He remained, stayed,</em> or <em>abode;</em> <span class="add">[like <span class="ar">بَلَدَ</span>;]</span> or <em>cast,</em> or <em>laid, himself down upon the ground;</em> syn. <span class="ar long">ضَرَبَ بِنَفْسِهِ الأَرْضَ</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>he did so by reason of fatigue.</em> <span class="auth">(TA. <span class="add">[<a href="#bld_5">See 5</a>.]</span>)</span> <a href="#baliduwA">See also <span class="ar">بَلِدُوا</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bld_2_A2">
					<p><em>He became languid, and affected laziness,</em> after being brisk, lively, or sprightly. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bld_2_A3">
					<p><em>He</em> <span class="auth">(a man)</span> <em>was impotent</em> in work, and <em>was weak;</em> <span class="auth">(T, L;)</span> and so even in bounty, or liberality, <span class="auth">(T,)</span> or in running. <span class="auth">(T,* L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bld_2_A4">
					<p><em>He</em> <span class="auth">(a horse)</span> <em>failed to outstrip in running.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#baluda">See also <span class="ar">بَلُدَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bld_2_A5">
					<p><em>He was niggardly,</em> or <em>avaricious; was not liberal, nor generous.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[And hence,]</span> <span class="ar long">بَلَّدَتِ السَّحَابَةُ</span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar long">بَلَدَ↓ السَّحَابُ</span></span>, <span class="auth">(M,)</span> <span class="add">[but the latter is probably imperfectly transcribed,]</span> <em>The cloud,</em> or <em>clouds, gave no rain.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bld_2_A6">
					<p><em>He did not apply himself rightly to anything.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bld_2_B1">
					<p><span class="ar long">بَلَّدَتِ الجِبَالِ</span> ‡ <em>The mountains appeared low to the eye by reason of the darkness of the night:</em> so in the L, confirmed by a citation from a poet: in the A,<span class="arrow"><span class="ar long">تَبَلَّدَتِ↓ البِلَادُ</span></span> ‡ <em>The countries,</em> or <em>regions, appeared short</em> <span class="add">[<em>in extent</em>]</span> <em>to the eye by reason of the darkness of the night.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bld_3">
				<span class="pb" id="Page_0247"></span>
				<h3 class="entry">3. ⇒ <span class="ar">بالد</span></h3>
				<div class="sense" id="bld_3_A1">
					<p><span class="ar">مُبَالَدَةٌ</span> <span class="add">[inf. n. of <span class="ar">بَالَدَ</span>]</span> The <em>contending with another,</em> or <em>others, in fight,</em> (<em>i. q.</em> <span class="ar">مُبَالَطَةٌ</span>, T, Ṣ, M, Ḳ,) <em>with swords</em> and <em>staves.</em> <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bld_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلد</span></h3>
				<div class="sense" id="bld_4_A1">
					<p><span class="ar">ابلد</span> <em>He clave to the ground,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>in submissiveness.</em> <span class="auth">(TA.)</span> <span class="add">[Perhaps formed by transposition from <span class="ar">أَلْبَدَ</span>: <a href="#mubolidN">see <span class="ar">مُبْلِدٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bld_4_A2">
					<p><a href="#bld_5">See also 5</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bld_4_A3">
					<p><em>His beast became dull; not to be rendered brisk, lively,</em> or <em>sprightly, by being put in motion.</em> <span class="auth">(AZ, Ṣ,* Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bld_4_B1">
					<p><span class="ar long">ابلدهُ مَكَانًا</span> <em>He made him to keep to a place.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bld_4_C1">
					<p><span class="ar">ابلد</span>, inf. n. <span class="ar">إِبْلَادٌ</span>, <em>It</em> <span class="auth">(a water-ing-trough or tank)</span> <em>was,</em> or <em>became, abandoned, and no longer used, so that it threatened to fall to ruin.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bld_4_D1">
					<p><span class="add">[And]</span> <span class="ar long">ابلدهُ الدَّهْرُ</span> <em>Time caused it</em> <span class="auth">(a watering-trough or tank)</span> <em>to become abandoned, and worn, and no longer used, so that it threatened to fall to ruin.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#mubolidN">See <span class="ar">مُبْلِدٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bld_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّد</span></h3>
				<div class="sense" id="bld_5_A1">
					<p><span class="ar">تبلّد</span> <em>He obtained,</em> or <em>exercised, dominion over a</em> <span class="ar">بَلَد</span> <span class="add">[i. e. <em>country,</em> or <em>town,</em>, &amp;c.,]</span> <em>belonging to others.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bld_5_A2">
					<p><em>He alighted,</em> or <em>sojourned, in a</em> <span class="ar">بَلَد</span> <span class="add">[or <em>country,</em>, &amp;c.,]</span> <em>wherein was no one,</em> <span class="auth">(L, Ḳ,)</span> <em>saying within himself, O my grief,</em> or <em>sorrow,</em> or <em>regret!</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bld_5_A3">
					<p><em>He was,</em> or <em>became, confounded,</em> or <em>perplexed, and unable to see his right course;</em> <span class="auth">(M, Ḳ;)</span> <em>he went backwards and forwards in confusion or perplexity, unable to see his right course:</em> <span class="auth">(T,* Ṣ:)</span> because he who is in this state is like one in a <span class="ar">بَلْدَة</span>, meaning a desert in which he cannot find his way: <span class="auth">(T, L:)</span> <em>he was overtaken by confusion,</em> or <em>perplexity, such that he was unable to see his right course;</em> as also<span class="arrow"><span class="ar">أَبْلَدَ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bld_5_A4">
					<p><em>He fell to the ground,</em> <span class="auth">(Ḳ,)</span> <em>by reason of weakness.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bld_2">See also 2</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bld_5_A5">
					<p><em>He became submissive, and humble;</em> <span class="auth">(T, TA;)</span> <em>contr. of</em> <span class="ar">تَجَلَّدَ</span>. <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bld_5_A6">
					<p><em>He affected</em> <span class="ar">بَلَادَة</span> <span class="add">[i. e. <em>stupidity, dulness, want of intelligence,</em>, &amp;c.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bld_5_A7">
					<p>† <em>He turned his hands over,</em> or <em>upside-down:</em> <span class="auth">(Ḳ:)</span> <span class="add">[thus one does in sorrow, or regret, or in perplexity: see Ḳur xviii. 40:]</span> or the meaning is that which here next follows: <span class="auth">(TA:)</span> † <em>he clapped his hands;</em> or <em>smote palm upon palm;</em> syn. <span class="ar">صَفَّقَ</span> <span class="auth">(M, Ḳ)</span> <span class="ar">بِالكَفِّ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#balodapN">See <span class="ar">بَلْدَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bld_5_A8">
					<p><span class="add">[And hence, app.,]</span> ‡ <em>He felt,</em> or <em>expressed, grief, sorrow,</em> or <em>regret.</em> <span class="auth">(M, A, L, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bld_5_B1">
					<p><span class="ar long">تَبَلَّدَتِ البِلَادُ</span>: <a href="#bld_2">see 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bld_5_C1">
					<p>Accord. to AAF, <span class="ar">تبلّد</span> also signifies <em>It</em> <span class="auth">(the dawn, or daybreak,)</span> <em>shone, was bright,</em> or <em>shone brightly; i. q.</em> <span class="ar">تبلّج</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baladN">
				<h3 class="entry"><span class="ar">بَلَدٌ</span></h3>
				<div class="sense" id="baladN_A1">
					<p><span class="ar">بَلَدٌ</span> <span class="auth">(which is masc. and fem., Mṣb)</span> and<span class="arrow"><span class="ar">بَلْدَةٌ↓</span></span> both signify the same; <span class="auth">(M, A, Mṣb, Ḳ;)</span> namely, <span class="add">[<em>A country, land, region, province, district,</em> or <em>territory:</em> and <em>a city, town,</em> or <em>village:</em> or]</span> <em>any portion of the earth,</em> or <em>of land, comprehended within certain limits,</em> <span class="add">[thus I render <span class="ar">مُسْتَحِيزَة</span>, and in like manner it is rendered in the TḲ,]</span> <em>cultivated,</em> or <em>inhabited,</em> or <em>uncultivated,</em> or <em>uninhabited:</em> <span class="auth">(M, Mṣb,* Ḳ:)</span> or the former signifies <em>any place of this description;</em> and the latter, <em>a portion thereof:</em> <span class="auth">(T:)</span> or the former is a generic name of <em>a place</em> <span class="add">[or <em>country</em> or <em>region</em> or <em>province</em>]</span> <em>such as El-'Irák and Syria;</em> and the latter signifies <em>a particular portion thereof such as</em> <span class="add">[<em>the city</em> or <em>town of</em>]</span> <em>El-Basrah and Damascus;</em> <span class="auth">(M, Ḳ;)</span> or these are post-classical applications: <span class="auth">(TA:)</span> or the former, <em>a tract of land,</em> or <em>district, which is an abode,</em> or <em>a place of resort, of animals,</em> or <em>genii, even if containing no building:</em> <span class="auth">(Nh:)</span> or <em>a land,</em> or <em>country,</em> absolutely: and also <em>a town,</em> or <em>village,</em> syn. <span class="ar">قَرْيَةٌ</span>: but this latter is a conventional adventitious application: <span class="auth">('Ináyeh, TA:)</span> and the latter, <em>a land, country,</em> or <em>territory,</em> <span class="add">[<em>belonging to,</em> or <em>inhabited by, a people,</em>]</span> syn. <span class="ar">أَرْضٌ</span>: <span class="auth">(Ṣ, TA: <span class="add">[a meaning assigned in the Ḳ to <span class="ar">بَلَدٌ</span>; but this appears to be a mistake occasioned by the accidental omission of the word <span class="ar">البَلْدَةٌ</span>:]</span>)</span> you say, <span class="ar long">هٰذِهِ بَلْدَتُنَا</span> <span class="add">[<em>This is our land,</em>, &amp;c.]</span> like as you say, <span class="ar long">هٰذِهِ بَحْرَتُنَا</span>: <span class="auth">(Ṣ, TA:)</span> the pl. <span class="auth">(of the former, Ṣ, Mṣb)</span> is <span class="ar">بُلْدَانٌ</span> <span class="auth">(Ṣ, M, Mṣb)</span> and <span class="auth">(of the same, Ṣ, or of the latter, Mṣb)</span> <span class="ar">بِلَادٌ</span>: <span class="auth">(T, Ṣ, M, Mṣb:)</span> <span class="add">[which latter, regarded <a href="#balodapN">as pl. of <span class="ar">بَلْدَةٌ</span></a> in a more limited sense than <span class="ar">بَلَدٌ</span>, is often used as meaning <em>provinces collectively;</em> i. e. <em>a country:</em>]</span> <span class="ar">بُلْدَانٌ</span> is <em>syn. with</em> <span class="ar">كُوَرٌ</span> <span class="add">[which signifies <em>districts,</em> or <em>tracts of country; quarters,</em> or <em>regions;</em> and also, <em>cities, towns,</em> or <em>villages</em>]</span>. <span class="auth">(T.)</span> <span class="ar">البَلَدُ</span> and<span class="arrow"><span class="ar">البَلْدَةُ↓</span></span> are names applied to <em>Mekkeh;</em> <span class="auth">(M, Ḳ;)</span> in like manner as <span class="ar">النَّجْمُ</span> is a name applied to the Pleiades. <span class="auth">(M.)</span> <span class="add">[So too <span class="ar long">البَلَدُ الأَمِينُ</span> and <span class="ar long">البَلَدُ الحَرَامُ</span>, &amp;c.]</span> <span class="ar long">بَلَدٌ مَيِّتٌ</span> means <em>A tract of land without herbage,</em> or <em>pasture:</em> <span class="auth">(Mṣb:)</span> and <span class="ar">بَلَدٌ</span> alone, <em>a</em> <span class="add">[<em>desert, a waterless desert,</em> or <em>such as is termed</em>]</span> <span class="ar">مَفَازَةٍ</span>. <span class="auth">(TA voce <span class="ar">تا</span>; under which see an ex.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baladN_A2">
					<p><span class="ar">بَلَدٌ</span> also signifies <em>Land which has not been dug, and upon which fire has not been kindled.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baladN_A3">
					<p><em>A</em> <span class="add">[<em>house,</em> or <em>dwelling, such as is termed</em>]</span> <span class="ar">دار</span>: <span class="auth">(M, Ḳ:)</span> of the dial. of El-Yemen. <span class="auth">(M.)</span> Sb mentions the saying, <span class="ar long">هٰذِهِ الدَّارُ نِعْمَتِ البَلَدُ</span> <span class="add">[<em>This house, excellent,</em> or <em>most excel-lent, is the dwelling!</em>]</span>; in which <span class="ar">البلد</span> is made fem. because it is syn. with <span class="ar">الدار</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baladN_A4">
					<p><em>A burial-ground:</em> <span class="auth">(M, Ḳ:)</span> or, as some say, <span class="auth">(M, but in the Ḳ “and,”)</span> <em>a grave,</em> or <em>sepulchre:</em> <span class="auth">(M, Ḳ:)</span> pl. as above. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baladN_A5">
					<p><em>Dust,</em> or <em>earth;</em> and so<span class="arrow"><span class="ar">يَلْدَةٌ↓</span></span>. <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baladN_A6">
					<p>The <em>place in which an ostrich lays its egg, in sand.</em> <span class="auth">(Ṣ, M, L, Ḳ.)</span> And hence, <span class="ar long">بَيْضَةُ البَلَدِ</span> <em>The egg of the ostrich, which it abandons in the place where it lays it, in the sand,</em> or <em>in a desert:</em> <span class="auth">(M, L:)</span> also called <span class="arrow"><span class="ar">البَلَدِيَّةِ↓</span></span> and <span class="ar long">ذَاتُ البَلَدِ</span>. <span class="auth">(M.)</span> You say, <span class="ar long">فُلَانٌ بَيْضَةُ البَلَدِ</span> <span class="add">[‡ <em>Such a one is</em> like <em>the egg of the ostrich,</em>, &amp;c.]</span>, meaning <em>such a one is unequalled,</em> or <em>unparalleled:</em> said in dispraise and in praise: <span class="auth">(M,* L:)</span> allowed by AʼObeyd to be used in praise: and said by El-Bekree to be applied to him who is separated from his family and near relations. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=02_b/235_byD">See also art. <span class="ar">بيض</span></a>.]</span> You also say, <span class="ar long">هُوَ أَذَلُّ مِنْ بَيْضَةِ البَلَدِ</span> <span class="auth">(Ṣ, M, A)</span> ‡ <em>He is more object,</em> or <em>vile, than the egg of the ostrich, which it abandons</em> <span class="auth">(Ṣ, TA)</span> <em>in the desert, and to which it does not return.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=02_b/235_byD">See again art. <span class="ar">بيض</span></a>.]</span> Also <span class="ar long">هُوَ أَعَزَّ مِنْ بَيْضَةِ البَلَدِ</span> ‡ <span class="add">[<em>He is more highly esteemed than the egg of the ostrich, which it lays in the sand</em>]</span>; because the ostrich spreads its wings over it and sits upon it. <span class="auth">(A in art. <span class="ar">فرخ</span>.)</span> <span class="add">[<a href="index.php?data=02_b/235_byD">See more in art. <span class="ar">بيض</span></a>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baladN_A7">
					<p><em>A trace, mark,</em> or <em>vestige,</em> <span class="auth">(T, Ṣ, M, Ḳ, <span class="add">[in the Ḳ mentioned in two places, but in the latter of these omitted in the CK,]</span>)</span> of a house, or dwelling: <span class="auth">(TA:)</span> and <em>a mark remaining upon the body:</em> <span class="auth">(AʼObeyd, T:)</span> pl. <span class="ar">أَبْلَادٌ</span>. <span class="auth">(Ṣ, AʼObeyd, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="baladN_A8">
					<p>The <em>origin,</em> or <em>an element,</em> (<span class="ar">عُنْصُر</span>,) of a thing. <span class="auth">(Th, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="baladN_A9">
					<p><a href="#balodapN">See also the next paragraph</a>, in three places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="baladN_A10">
					<p><a href="#bulodapN">and see <span class="ar">بُلْدَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balodapN">
				<h3 class="entry"><span class="ar">بَلْدَةٌ</span></h3>
				<div class="sense" id="balodapN_A1">
					<p><span class="ar">بَلْدَةٌ</span>: <a href="#baladN">see <span class="ar">بَلَدٌ</span></a>, in three places. You say, <span class="ar long">إِنْ لَمْ تَفْعَلْ كَذَا فَهِىَ بَلْدَةٌ بَيْنِى وَبَيْنِكَ</span> ‡ <em>If thou do not thus, it will be</em> <span class="add">[a cause of]</span> <em>separation between me and thee;</em> <span class="auth">(M,* A, TA;)</span> i. e., I will alienate thee from me so that a country, or region, shall separate us, each from the other. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balodapN_A2">
					<p>Also <em>A desert,</em> or <em>waterless desert, in which one cannot find his way:</em> and <em>any extensive tract of land.</em> <span class="auth">(T, L.)</span> <span class="add">[Hence,]</span> <span class="ar long">لَقِيتُهُ بِبَلْدَةِ إِصْمَتِ</span> <em>I found him,</em> or <em>met him, in a desert,</em> or <em>desolate, place, in which there was no one beside.</em> <span class="auth">(M.)</span> <span class="add">[<a href="index.php?data=14_S/093_Smt">See also art. <span class="ar">صمت</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balodapN_A3">
					<p>And <span class="add">[hence, app.,]</span> <span class="ar">البَلْدَةُ</span> <em>One of the Mansions of the Moon,</em> <span class="auth">(M, Ḳ,)</span> <span class="add">[namely, <em>the Twenty-first Mansion,</em>]</span> <em>a patch of the sky,</em> <span class="auth">(Ḳ,)</span> <em>containing no stars,</em> <span class="auth">(M, Ḳ,)</span> or <em>containing only small stars,</em> <span class="auth">(T,* M,)</span> <em>between the</em> <span class="ar">نَعَائِم</span> <em>and</em> <span class="ar long">سَعْد الذَّابِح</span>: <span class="auth">(M, Ḳ:)</span> sometimes the moon declines from it, and takes as its mansion the <span class="ar">قِلَادَة</span>: it <span class="add">[app. <span class="ar">القلادة</span>, accord. to the Ḳ, but accord. to the TA <span class="ar">البلدة</span>,]</span> consists of six stars resembling a bow, <span class="auth">(Ḳ,)</span> in the sign of Sagittarius (<span class="ar">القَوْس</span>): <span class="auth">(T:)</span> or <span class="ar">البلدة</span> is <em>one of the Mansions of the Moon, consisting of six stars of Sagittarius</em> (<span class="ar">القوس</span>), <em>which the sun enters on the shortest day of the year:</em> <span class="auth">(Ṣ:)</span> <span class="add">[<a href="#manaAzilu">see <span class="ar long">مَنَازِلُ القَمَر</span></a>, <a href="index.php?data=25_n/110_nzl">in art. <span class="ar">نزل</span></a>: in the Ḳ it is also said that <span class="arrow"><span class="ar">البَلَدُ↓</span></span> is a Mansion of the Moon; but this appears to be a mistake, occasioned by the accidental omission of the word <span class="ar">البَلْدَةُ</span>; though <span class="ar">البَلَدُ</span> would seem to be an appropriate name for the mansion next after the <span class="ar">نعائم</span>:]</span> IF says that <span class="ar">البَلْدَةُ</span> is <em>a star,</em> or <em>an asterism,</em> (<span class="ar">نَجْمٌ</span>,) <em>said to be the</em> <span class="ar">بَلْدَة</span>, i. e. <em>breast, of the Lion;</em> not meaning the mansion thus called in the sign of Sagittarius: El-Ḥareeree finds fault with him for using this expression, <span class="add">[the <span class="ar">بلدة</span> of the Lion,]</span> but Ibn-Dhafr replies that it occurs in the language. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balodapN_A4">
					<p><span class="ar">بَلْدَةٌ</span> also signifies The <em>earth,</em> or <em>ground.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="balodapN_A5">
					<p>Also <span class="auth">(Ṣ, M, L, TA, <span class="add">[in the Ḳ<span class="arrow"><span class="ar">بَلَد↓</span></span>, by the accidental omission of the word <span class="ar">البَلْدَةُ</span>,]</span>)</span> the <em>pit between the two collar-bones, with the part around it:</em> or the <em>middle thereof,</em> i. e., <em>of that pit:</em> <span class="auth">(M, Ḳ:)</span> or the <em>third of the</em> <span class="ar">فَلَك</span> <span class="auth">(which are six in number)</span> <em>of that part of a horse's breast which is called the</em> <span class="ar">زَوُر</span>: or the <em>part called</em> <span class="ar long">رَحَى الزَّوْرِ</span>: <span class="auth">(M:)</span> or <span class="add">[so accord. to the M, but accord. to the Ḳ “and,”]</span> the <em>breast,</em> syn. <span class="ar">صَدْر</span>, <span class="auth">(Ṣ, M, A, Ḳ,)</span> of a camel, <span class="auth">(M, A,)</span> or of that which has a foot like the camel's, and of a solid-hoofed animal, <span class="auth">(M,)</span> and of a man: <span class="auth">(A:)</span> and the <em>part immediately beneath the two prominent portions of flesh of the breast</em> of a horse, <em>extending to the arms.</em> <span class="auth">(M, L.)</span> Dhu-rRummeh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أُنِيخَتْ فَأَلْقَتْ بَلْدَةً فَوْقَ بَلْدَةٍ</span> *</div> 
					</blockquote>
					<p><em>She</em> <span class="auth">(the camel)</span> <em>was made to lie down, and threw</em> her <em>breast upon</em> <span class="add">[<em>a tract of</em>]</span> <em>ground.</em> <span class="auth">(Ṣ, M.)</span> And you say, <span class="ar long">فُلَانٌ وَاسِعُ البَلْدَةِ</span> <em>Such a one is wide in the breast.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<span class="pb" id="Page_0248"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="balodapN_A6">
					<p>Also ‡ The <em>palm of the hand.</em> <span class="auth">(M, A, TA. <span class="add">[In the Ḳ, by the accidental omission of the word <span class="ar">البَلْدَةُ</span>, this meaning is assigned to <span class="arrow"><span class="ar">بَلَدٌ↓</span></span>.]</span>)</span> You say, <span class="ar long">ضَرَبَ بَلْدَتَهُ عَلَى بَلْدَتِهِ</span> ‡ <em>He smote the palm of his hand upon his breast.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="balodapN_B1">
					<p><a href="#bulodapN">See also <span class="ar">بُلْدَةٌ</span></a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلْدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="balodapN_C1">
					<p><a href="#balaAdapN">and see <span class="ar">بَلَادَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulodapN">
				<h3 class="entry"><span class="ar">بُلْدَةٌ</span></h3>
				<div class="sense" id="bulodapN_A1">
					<p><span class="ar">بُلْدَةٌ</span> <span class="auth">(Ṣ, M, L, Ḳ)</span> and<span class="arrow"><span class="ar">بَلْدَةٌ↓</span></span> <span class="auth">(Ṣ, M, L)</span> and<span class="arrow"><span class="ar">بَلَدٌ↓</span></span> <span class="add">[<a href="#bld_1">which is an inf. n. of <span class="ar">بَلِدَ</span></a>]</span> <span class="auth">(Ṣ, Ḳ)</span> <em>Clearness, from hair, of the space between the eyebrows:</em> <span class="auth">(Ṣ, L, Ḳ:)</span> <em>i. q.</em> <span class="ar">بُلْجَةٌ</span>: or <em>more than</em> <span class="ar">بُلْجَةٌ</span>: or the <em>having the eyebrows not joined:</em> <span class="auth">(M:)</span> or<span class="arrow">↓</span> the second signifies the <em>space between the eyebrows.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بُلْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulodapN_A2">
					<p>And the first, The <em>form, aspect, appearance,</em> or <em>lineaments,</em> of the face. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بُلْدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bulodapN_B1">
					<p><a href="#balaAdapN">See also <span class="ar">بَلَادَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaladiyBapu">
				<h3 class="entry"><span class="ar">البَلَدِيَّةُ</span></h3>
				<div class="sense" id="AlbaladiyBapu_A1">
					<p><span class="ar">البَلَدِيَّةُ</span>: <a href="#baladN">see <span class="ar">بَلَدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baliydN">
				<h3 class="entry"><span class="ar">بَلِيدٌ</span></h3>
				<div class="sense" id="baliydN_A1">
					<p><span class="ar">بَلِيدٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَبْلَدٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <em>Stupid, dull, wanting in intelligence;</em> <span class="auth">(Ṣ, Mṣb;)</span> <em>inert; wanting in vigour; not penetrating, sharp, vigorous,</em> or <em>effective, in the performing of affairs:</em> <span class="auth">(T, M, Ḳ:*)</span> <span class="add">[<em>soft, weak, feeble; wanting in endurance,</em> or <em>patience:</em>]</span> <em>contr. of</em> <span class="ar">جَلِيدٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baliydN_A2">
					<p>Also the former, A horse <em>that lags behind those that outstrip in running:</em> <span class="auth">(T, TA:)</span> and a camel <span class="auth">(TA)</span> <em>not to be rendered brisk, lively,</em> or <em>sprightly, by being put in motion.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَلِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baliydN_A3">
					<p><a href="#maboluwdN">See also <span class="ar">مَبْلُودٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balAdapN">
				<h3 class="entry"><span class="ar">بَلادَةٌ</span></h3>
				<div class="sense" id="balAdapN_A1">
					<p><span class="ar">بَلادَةٌ</span> <span class="add">[an inf. n. <span class="auth">(of <span class="ar">بَلُدَ</span>)</span> used as a subst.]</span> <span class="auth">(Ṣ, M, A)</span> and<span class="arrow"><span class="ar">بُلْدَةٌ↓</span></span> and<span class="arrow"><span class="ar">بَلْدَةٌ↓</span></span> <span class="auth">(M, TA)</span> <em>Stupidity, dulness, want of intelligence,</em> <span class="auth">(Ṣ, A,)</span> or <em>of penetration, sharpness, vigour,</em> or <em>effectiveness, in the performing of affairs.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAlidN">
				<h3 class="entry"><span class="ar">بَالِدٌ</span></h3>
				<div class="sense" id="baAlidN_A1">
					<p><span class="ar">بَالِدٌ</span> <em>Remaining, staying, abiding,</em> or <em>dwelling,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>in a</em> <span class="ar">بَلَد</span> <span class="add">[i. e. <em>country,</em> or <em>town,</em>, &amp;c.]</span>, <span class="auth">(Mṣb,)</span> or in a place. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">بَالِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAlidN_A2">
					<p><span class="ar long">تَالِدٌ بَالِدٌ</span> <em>Lasting; that does not cease,</em> or <em>fail,</em> or <em>pass away:</em> the former word signifies <em>old;</em> and the latter is <span class="add">[said to be]</span> an imitative sequent. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboladN">
				<h3 class="entry"><span class="ar">أَبْلَدٌ</span></h3>
				<div class="sense" id="OaboladN_A1">
					<p><span class="ar">أَبْلَدٌ</span> A man <em>having a space clear from hair between his eyebrows:</em> or <em>having eyebrows not joined: i. q.</em> <span class="ar">أَبْلَجُ</span>. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">أَبْلَدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaboladN_B1">
					<p><span class="add">[<em>More,</em> and <em>most, stupid, dull, wanting in intelligence,</em> or <em>in penetration, sharpness, vigour,</em> or <em>effectiveness, in the performing of affairs:</em> <a href="#baluda">see <span class="ar">بَلُدَ</span></a>.]</span> You say, <span class="ar long">أَبْلَدُ مِنْ ثَوْرٍ</span> <span class="add">[<em>More stupid,</em>, &amp;c., <em>than a bull</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">أَبْلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OaboladN_B2">
					<p><a href="#baliydN">See also <span class="ar">بَلِيدٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلد</span> - Entry: <span class="ar">أَبْلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OaboladN_B3">
					<p>A man <span class="auth">(Ṣ)</span> <em>of large,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>big, gross, rude,</em> or <em>coarse,</em> <span class="auth">(M,)</span> <em>make.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubolidN">
				<h3 class="entry"><span class="ar">مُبْلِدٌ</span></h3>
				<div class="sense" id="mubolidN_A1">
					<p><span class="ar">مُبْلِدٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">مُبْلَدٌ</span>, <span class="auth">(T,)</span> <em>Old;</em> applied to a watering-trough or tank. <span class="auth">(T, Ḳ.)</span> So in the words of a poet, describing a watering-trough or tank,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمُبْلَدٍ بَيْنَ مَوْمَاةٍ بِمَهْلَكَةٍ</span> *</div> 
					</blockquote>
					<p>formed by transposition from <span class="ar">مُلْبِدَ</span>, which <span class="add">[properly]</span> means <em>cleaving to the ground:</em> <span class="auth">(IAạr, T, TA:)</span> or it is <span class="ar">مُبْلَد</span>, <span class="auth">(TA,)</span> or <span class="ar">مُبْلِد</span>, <span class="auth">(T,)</span> which means <em>abandoned, and worn, and no longer used, so that it threatens to fall to ruin.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboluwdN">
				<h3 class="entry"><span class="ar">مَبْلُودٌ</span></h3>
				<div class="sense" id="maboluwdN_A1">
					<p><span class="ar">مَبْلُودٌ</span> <em>Confounded,</em> or <em>perplexed, and unable to see his right course:</em> <span class="add">[a pass. part. n., but]</span> it has no verb answering to it: <span class="auth">(M, TA:)</span> or <em>idiotic; deficient,</em> or <em>wanting, in intellect;</em> or <em>bereft thereof:</em> <span class="auth">(Esh-Sheybánee, M, Ḳ:)</span> or <em>unable to proceed in,</em> or <em>prosecute, his journey, his means having failed him, or his camel that bore him stopping with him from fatigue or breaking down or perishing, or an event befalling him so that he cannot move:</em> <span class="auth">(Aṣ, M:)</span> all of these significations refer to confusion or perplexity: <span class="auth">(M, L:)</span> or one <em>whose modesty,</em> or <em>shame,</em> or <em>whose intellect, has quitted him;</em> as also<span class="arrow"><span class="ar">بَلِيدٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0246.pdf" target="pdf">
							<span>Lanes Lexicon Page 246</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0247.pdf" target="pdf">
							<span>Lanes Lexicon Page 247</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0248.pdf" target="pdf">
							<span>Lanes Lexicon Page 248</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
