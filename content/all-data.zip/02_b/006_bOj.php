<article class="root" id="Root_bOj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/005_bAbwnj">بابونج</a></span>
				<span class="ar">بأج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/007_bAcnjAn">باذنجان</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baOojN">
				<h3 class="entry"><span class="ar">بَأْجٌ</span></h3>
				<div class="sense" id="baOojN_A1">
					<p><span class="ar">بَأْجٌ</span>, also pronounced <span class="ar">بَاجٌ</span>, without <span class="ar">ء</span>, <span class="auth">(IAạr, Ṣ, Mṣb, Ḳ,)</span> but the former alone is mentioned by Th in the Fṣ, and is the chaste word, <span class="auth">(TA,)</span> arabicized, from the Persian <span class="ar">بَاهَا</span>, <span class="auth">(Ṣ,)</span> <em>A sort,</em> or <em>species,</em> <span class="auth">(Ṣ, Ḳ,)</span> of food, or viands. <span class="auth">(Ṣ.)</span> Hence the saying, <span class="ar long">اِجْعَلِ البَأْجَات بَإْجاً وَاحِدًا</span> <span class="add">[<em>Make thou the sorts,</em> or <em>species,</em> of food, or viands, to be <em>one sort,</em> or <em>species</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> occurring in a trad., in which it is without <span class="ar">ء</span> in each case, accord. to IDrst: several different sorts of food being brought to ʼOmar, he asked respecting them, and it was said, <span class="add">[They are]</span> <span class="ar">سِكْبَاج</span> and <span class="ar">زِرْبَاج</span> and <span class="ar">إِسْفِيدْبَاج</span>; whereupon he ordered that the bowls should be brought, and their contents were emptied into one; he saying the words above. <span class="auth">(Marginal note in a copy of the Ṣ.)</span> IKh says that a man would bring various sorts <span class="add">[of food]</span>, and one would say, <span class="ar long">اِجْعَلْهَا بأْجاً وَاحدِا</span> <span class="add">[<em>Make thou them</em> to be <em>one sort</em>]</span>. <span class="auth">(TA.)</span> The pl. is <span class="add">[<span class="ar">بَأْجَاتٌ</span>, as shown above, as though the sing. were <span class="ar">بَأْجَةٌ</span>, and]</span> <span class="ar">أَبْوَاجٌ</span>. <span class="auth">(Mṣb, TA.)</span> <span class="ar long">لَأَجْعَلَنَّ النَّاسَ كُلَّهُمْ بَأْجًا وَاحِدًا</span> is <span class="add">[likewise]</span> a saying of ʼOmar, <span class="auth">(Mṣb, TA,)</span> meaning <span class="add">[<em>I will assuredly make the people, all of them, to be</em>]</span> <em>one body</em> or <em>assemblage;</em> <span class="ar">بَأْجٌ</span> signifying <em>a state of assembling,</em> or <em>collecting together:</em> <span class="auth">(Ḳz, TA:)</span> or <span class="add">[<em>of</em>]</span> <em>one uniform way</em> or <em>mode</em> or <em>manner,</em> <span class="auth">(Mṣb, TA,)</span> as El-Fihree says in the Expos. of the Fṣ, on the authority of ISd in the book entitled El-'Awees; <span class="auth">(TA;)</span> i. e., in respect of gifts, or allowances: <span class="auth">(Mṣb:)</span> accord. to IAạr, it is from <span class="ar">بَأْجٌ</span> or <span class="ar">بَاجٌ</span> signifying <em>a uniform line of road.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">النَّاسُ بَأْجٌ وَاحِدٌ</span> <em>The people are</em> <span class="add">[<em>as</em>]</span> <em>one thing.</em> <span class="auth">(TA.)</span> And <span class="ar long">هُمْ فِى أَمْرٍ بَأْجٍ</span> <em>They are</em> <span class="add">[<em>in one and the same,</em> or]</span> <em>in an equal,</em> or <em>a uniform, case.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">جَعَلَ الكَلَامَ بَأْجاً وَاخِدًا</span> <em>He made the speech,</em> or <em>language, to be</em> <span class="add">[<em>uniform,</em> or]</span> <em>of one mode,</em> or <em>manner.</em> <span class="auth">(TA.)</span> And <span class="ar long">اِجْعَلْ هٰذا الشَّىْءَ بَأْجًا وَاحِدًا</span> <em>Make thou this thing to be</em> <span class="add">[<em>uniform,</em> or]</span> <em>of one way,</em> or <em>mode,</em> or <em>manner.</em> <span class="auth">(ISk.)</span> And <span class="ar long">اِجْعَلِ الأَمْرَ بَأْجًا وَاحِدًا</span> <em>Make thou the affair,</em> or <em>case,</em> <span class="add">[<em>uniform,</em> or]</span> <em>one uniform thing.</em> <span class="auth">(Fr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
