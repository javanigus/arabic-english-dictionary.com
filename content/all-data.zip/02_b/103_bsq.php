<article class="root" id="Root_bsq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/102_bsT">بسط</a></span>
				<span class="ar">بسق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/104_bsl">بسل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسق</span></h3>
				<div class="sense" id="bsq_1_A1">
					<p><span class="ar long">بَسَقَ النَّخْلُ</span>, <span class="auth">(aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُقُ</span>}</span></add> Msb,)</span> inf. n. <span class="ar">بُسُوقٌ</span>, <em>The palm-trees were,</em> or <em>became, tall</em>, <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> <em>and full-grown:</em> <span class="auth">(JK:)</span> or <em>exceedingly tall</em>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsq_1_A2">
					<p><span class="ar long">بَسَقَ عَلَيْهِمْ</span>, <span class="auth">(inf. n. as above, TA,)</span> ‡ <em>He overcame them, excelled them,</em> or <em>was superior to them;</em> <span class="auth">(JK, Ṣ, Ḳ;)</span> namely, his companions: <span class="auth">(Ṣ:)</span> <em>he surpassed them in excellence.</em> <span class="auth">(TA.)</span> And <span class="ar">بَسَقَهُمْ</span> <em>He became exalted above them in fame, or renown.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsq_1_A3">
					<p><span class="ar long">بَسَقَ فِى عِلْمِهِ</span> <em>He was, or became, skilled in his science, knowing its abstrusities and niceties,</em> or <em>having learned the whole of it.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsq_1_B1">
					<p><span class="ar">بَسَقَ</span>, <span class="auth">(JK, Ṣ, &amp;c.,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُقُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَسْقٌ</span>, <span class="auth">(Ṣ, TA,)</span> or <span class="ar">بُسَاقٌ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[but see the latter below,]</span> <em>i. q.</em> <span class="ar">بَصَقَ</span> <span class="auth">(JK, Ṣ,* Mṣb, Ḳ)</span> and <span class="ar">بَزَقَ</span> <span class="auth">(TA)</span> <span class="add">[<em>He spat</em>]</span>: but some, as on the authority of Kh, disallow it, saying that it has no other signification than that of excessive tallness, as in the case of a palm-tree: <span class="auth">(Mṣb:)</span> or the second of these verbs is the most chaste; the first and last being of weak authority, or rare. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bsq_1_C1">
					<p><span class="ar long">بَسَقَتِ الشَّمْسُ</span> <em>i. q.</em> <span class="ar">بَزَقَت</span> <span class="add">[and <span class="ar">بَزَغَت</span>, i. e. <em>The sun rose</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsq_2">
				<h3 class="entry">2. ⇒ <span class="ar">بسّق</span></h3>
				<div class="sense" id="bsq_2_A1">
					<p><span class="ar long">لَا تُبَسِّقْ عَلَيْنَا</span>, <span class="auth">(JK, Ḳ,)</span> inf. n. <span class="ar">تَبْسِيقٌ</span>, <span class="auth">(Ḳ,)</span> ‡ <em>Be not thou proliæ, or tedious, to us;</em> syn. <span class="ar long">لَا تُطَوَّلْ</span>, <span class="auth">(JK, Ḳ, TA,)</span> or <span class="ar long">لَا تَتَطَوَّلْ</span>, <span class="auth">(TA,)</span> both of which signify the same. <span class="auth">(TḲ.)</span> <span class="add">[<span class="ar">بَسَّقَ</span> and↓<span class="ar">تبسّق</span> are syn.; or]</span> <span class="ar">تَبَسُّقٌ</span> signifies † The <em>being proliæ,</em> or <em>tedious,</em> (<span class="ar">تَطَوَّلٌ</span>,) <em>and heavy,</em> or <em>sluggish.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsq_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابسق</span></h3>
				<div class="sense" id="bsq_4_A1">
					<p><span class="ar">ابسقت</span> <em>She</em> <span class="auth">(a camel)</span> <em>excerned the first milk,</em> or <em>biestings, into her udder, before bringing forth:</em> <span class="auth">(Aṣ, Ṣ, Ḳ:)</span> or <em>she</em> <span class="auth">(a ewe, JK, or a camel, Yz, T)</span> <em>excerned the milk</em> <span class="auth">(Yz, JK, T)</span> <em>a month before bringing forth,</em> <span class="auth">(JK, T,)</span> <em>so that it oozed,</em> or <em>flowed;</em>; or, <em>as is sometimes the case, when she was not pregnant.</em> <span class="auth">(T.)</span> Also <em>She</em> <span class="auth">(a girl being a <span class="ar">بِكْر</span> <span class="add">[which means a virgin, and also one that has not yet brought forth, and one that has brought forth but once,]</span>)</span> <em>had milk in her breast:</em> so, says Az, I have heard. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsq_4_A2">
					<p><em>She</em> <span class="auth">(a ewe)</span> <em>had a long udder</em>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsq_4_A3">
					<p>And <em>She</em> <span class="auth">(a ewe)</span> <em>was, or became, pregnant.</em> <span class="auth">(Bḍ in l. 10.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبسّق</span></h3>
				<div class="sense" id="bsq_5_A1">
					<p><a href="#bsq_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basoqapN">
				<h3 class="entry"><span class="ar">بَسْقَةٌ</span></h3>
				<div class="sense" id="basoqapN_A1">
					<p><span class="ar">بَسْقَةٌ</span> <em>A</em> <span class="add">[<em>stony tract such as is termed</em>]</span> <span class="ar">حَرَّة</span>: <span class="add">[or <em>one that is somewhat elevated;</em> as also <span class="ar">بَصْقَةٌ</span>:]</span> pl. <span class="ar">بِسَاقٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busaAqN">
				<h3 class="entry"><span class="ar">بُسَاقٌ</span></h3>
				<div class="sense" id="busaAqN_A1">
					<p><span class="ar">بُسَاقٌ</span> <em>i. q.</em> <span class="ar">بُصَاقٌ</span> <span class="add">[<em>Spittle,</em> or <em>saliva, when it has gone forth from the mouth:</em> or <em>saliva that flows;</em> <a href="#buzaAqN">see <span class="ar">بُزَاقٌ</span></a>: <a href="#bsq_1">see also 1</a>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<span class="ar">بُسَاقَةٌ</span> is app. its n. un. And hence,]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: <span class="ar">بُسَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="busaAqN_A2">
					<p><span class="ar long">بُسَاقَةٌ القَمَرِ</span> <em>Stone of a clear white colour, that glistens; </em> as also with <span class="ar">ص</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basuwqN">
				<h3 class="entry"><span class="ar">بَسُوقٌ</span></h3>
				<div class="sense" id="basuwqN_A1">
					<p><span class="ar">بَسُوقٌ</span> and↓<span class="ar">مِبْسَاقٌ</span>, both applied to a ewe, <span class="auth">(JK, Ḳ,)</span> and to a she-camel, <span class="auth">(TA,)</span> <em>Having a long udder:</em> <span class="auth">(JK, Ḳ:)</span> or <em>i. q.</em>↓, applied to a ewe. <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAsiqN">
				<h3 class="entry"><span class="ar">بَاسِقٌ</span></h3>
				<div class="sense" id="baAsiqN_A1">
					<p><span class="ar">بَاسِقٌ</span> <span class="add">[act. part. n. of 1]</span>. <span class="ar long">نَخْلَةٌ بَاسِقَةٌ</span> <em>A tall palm-tree:</em> <span class="add">[or <em>an exceedingly tall palm-tree;</em> <a href="#bsq_1">see 1</a>:]</span> pl. <span class="ar">بَاسِقَاتٌ</span> and <span class="ar">بَوَاسِقُ</span>. <span class="auth">(Mṣb.)</span> The former of these pls. occurs in the Ḳur l. 10, meaning <em>tall</em>: <span class="auth">(Ṣ, Bḍ, TA:)</span> or <em>bearing fruit;</em> from <span class="ar">أَبْسَقَتْ</span> said of a ewe, as signifying “she was, or became, pregnant;” so that it is an instance of a part. n. of the measure <span class="ar">فَاعِلٌ</span> from a verb of the measure <span class="ar">أَفْعَلَ</span>: accord. to one reading, it is <span class="ar">بَاصِقَات</span>, because of the <span class="ar">ق</span>. <span class="auth">(Bḍ.)</span> The latter of the pls. also signifies The <em>first portions</em> of clouds: <span class="auth">(AḤn, TA:)</span> <span class="add">[app. the <em>portions that first appear above the horizon:</em>]</span> or <em>what are elongated of the heads,</em> or <em>summits,</em> (<span class="ar">فُرُوع</span>,) of a cloud: and hence, of <span class="add">[the plant called]</span> <span class="ar">أُقْحُوَان</span> <span class="add">[or chamomile]</span>. <span class="auth">(TA.)</span> And <span class="ar">بَاسِقَةٌ</span> signifies <em>A cloud of a clear white colour</em> <span class="add">[as being always very high in the sky]</span>. <span class="auth">(Ṣgh, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: <span class="ar">بَاسِقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAsiqN_A2">
					<p><span class="ar long">بَاسِقُ الأَخْلَاقِ</span> † <em>Endowed with elevated,</em> or <em>noble, natural dispositions</em> or <em>mental qualities.</em> <span class="auth">(Ḥam p. 369.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسق</span> - Entry: <span class="ar">بَاسِقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAsiqN_B1">
					<p><em>A sweet yellow fruit.</em> <span class="auth">(Ṣgh, Ḳ.)</span> <span class="add">[Golius appears to have found <span class="ar">تَمْرَةٌ</span> in the place of <span class="ar">ثَمَرَةٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubosiqN">
				<h3 class="entry"><span class="ar">مُبْسِقٌ</span></h3>
				<div class="sense" id="mubosiqN_A1">
					<p><span class="ar">مُبْسِقٌ</span> A she-camel <em>excerning the first milk,</em> or <em>biestings, into her udder before bringing forth:</em> <span class="auth">(Aṣ, Ṣ, Ḳ: <span class="add">[<a href="#bsq_4">see 4</a>:]</span> <a href="#basuwqN">and see also <span class="ar">بَسُوقٌ</span></a>:)</span> pl. <span class="ar">مَبَاسِيقُ</span>. <span class="auth">(Ṣ, Ḳ.)</span> And A girl that is a <span class="ar">بِكْر</span> <span class="add">[<a href="#bsq_4">see 4</a>]</span> <em>having milk flowing into her breast.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibosaAqN">
				<h3 class="entry"><span class="ar">مِبْسَاقٌ</span></h3>
				<div class="sense" id="mibosaAqN_A1">
					<p><span class="ar">مِبْسَاقٌ</span>: <a href="#basuwqN">see <span class="ar">بَسُوقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0205.pdf" target="pdf">
							<span>Lanes Lexicon Page 205</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
