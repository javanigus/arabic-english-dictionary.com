<article class="root" id="Root_brX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/071_brsm">برسم</a></span>
				<span class="ar">برش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/073_brS">برص</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brX_1">
				<h3 class="entry">1. ⇒ <span class="ar">برش</span></h3>
				<div class="sense" id="brX_1_A1">
					<p><span class="ar">بَرِشَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَشُ</span>}</span></add>, inf. n. <span class="ar">بَرَشٌ</span>, <em>i. q.</em> <span class="ar">بَرِصَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَشُ</span>}</span></add>, inf. n. <span class="ar">بَرَصٌ</span>: <span class="auth">(Mṣb:)</span> <span class="add">[or rather, used allusively for the latter verb: <a href="#OaboraXu">see <span class="ar">أَبْرَشُ</span></a>. <a href="#baraXN">See also <span class="ar">بَرَشٌ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brX_9">
				<h3 class="entry">9. ⇒ <span class="ar">ابرشّ</span></h3>
				<div class="sense" id="brX_9_A1">
					<p><span class="ar">ابرشّ</span>, inf. n. <span class="ar">إِبْرشَاشٌ</span>, <em>He</em> <span class="auth">(a horse)</span> <em>was,</em> or <em>became, marked with small specks, called</em> <span class="ar">بَرَش</span>, <em>differing from the rest of his colour.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraXN">
				<h3 class="entry"><span class="ar">بَرَشٌ</span></h3>
				<div class="sense" id="baraXN_A1">
					<p><span class="ar">بَرَشٌ</span>, in the hair of a horse, <em>Small specks, differing from the rest of the colour;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بُرْشَةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or both signify <em>a colour in which one speck is red and another black</em> or <em>dustcoloured</em> or <em>the like.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برش</span> - Entry: <span class="ar">بَرَشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baraXN_A2">
					<p>And hence, <span class="auth">(T-A,)</span> the former, <span class="auth">(A, TA,)</span> or<span class="arrow">↓</span> both <span class="auth">(Ḳ,)</span> <em>A whiteness that appears upon the nails.</em> <span class="auth">(Ibráheem El-Ḥarbee, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برش</span> - Entry: <span class="ar">بَرَشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baraXN_A3">
					<p>And the former, <em>White specks in the skin.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برش</span> - Entry: <span class="ar">بَرَشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baraXN_A4">
					<p><span class="add">[<a href="#brX_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroXapN">
				<h3 class="entry"><span class="ar">بُرْشَةٌ</span></h3>
				<div class="sense" id="buroXapN_A1">
					<p><span class="ar">بُرْشَةٌ</span>: <a href="#baraXN">see <span class="ar">بَرَشٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bariyXN">
				<h3 class="entry"><span class="ar">بَرِيشٌ</span></h3>
				<div class="sense" id="bariyXN_A1">
					<p><span class="ar">بَرِيشٌ</span>: <a href="#OaboraXu">see <span class="ar">أَبْرَشُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboraXu">
				<h3 class="entry"><span class="ar">أَبْرَشُ</span></h3>
				<div class="sense" id="OaboraXu_A1">
					<p><span class="ar">أَبْرَشُ</span>, applied to a horse, <span class="auth">(Ṣ, Ḳ,)</span> or to one of the sort termed <span class="ar">بِرْذَون</span>, <span class="auth">(Lḥ,)</span> <em>Marked with the small speaks termed</em> <span class="ar">بَرَش</span>; <span class="auth">(Lḥ, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَرِيشٌ↓</span></span>. <span class="auth">(Ḳ.)</span> Also, <span class="ar long">شَاةٌ بَرْشَآءُ</span> <em>A ewe,</em> or <em>she-goat, marked with specks of various colours.</em> <span class="auth">(TA.)</span> And <span class="ar long">حَيَّةٌ بَرْشَآءُ</span> <em>A serpent black speckled with white,</em> or <em>white speckled with black.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برش</span> - Entry: <span class="ar">أَبْرَشُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboraXu_A2">
					<p><span class="add">[Hence,]</span> <em>i. q.</em> <span class="ar">أَبْرَصُ</span>: fem. <span class="ar">بَرْشَآءُ</span>: pl. <span class="ar">بُرْشٌ</span>: <span class="auth">(Mṣb:)</span> <span class="add">[or rather, used allusively for <span class="ar">أَبْرَصُ</span>; for]</span> Jedheemeh <span class="auth">(Ṣ, A, Ḳ)</span> Ibn-Málik <span class="auth">(Ṣ, TA)</span> Ibn-Fahm, <span class="auth">(TA,)</span> the king <span class="add">[of El-Heereh]</span>, <span class="auth">(Ḳ,)</span> was surnamed <span class="ar">الأَبْرَشُ</span> in allusion to his being <span class="ar">أَبْرَص</span>; <span class="auth">(Ṣ, A, Ḳ;)</span> the Arabs fearing to apply to him this latter epithet: <span class="auth">(Ḳ:)</span> or he was thus called because he was marked with black or red specks caused by a burn. <span class="auth">(Kh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برش</span> - Entry: <span class="ar">أَبْرَشُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaboraXu_A3">
					<p><span class="ar long">مَكَانٌ أَبْرَشُ</span> <em>A place of various colours, abounding in plants</em> or <em>herbage:</em> <span class="auth">(Ḳ:)</span> and <span class="ar long">أَرْضٌ بَرْشَآءٌ</span>, and <span class="ar long">سَنَةٌ بَرْشَآءُ</span>, <em>land,</em> and <em>a year, in which is abundance of herbage</em> <span class="auth">(Ks, Ḳ)</span> <em>of various colours;</em> <span class="auth">(Ks;)</span> as also <span class="ar">رَبْشَآءُ</span> and <span class="ar">رَمْشَآءُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0188.pdf" target="pdf">
							<span>Lanes Lexicon Page 188</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
