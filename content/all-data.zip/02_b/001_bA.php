<article class="root" id="Root_bA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/000_b">ب</a></span>
				<span class="ar">با</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/002_bO">بأ</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="baA">
				<h3 class="entry"><span class="ar">بَا</span> / <span class="ar">بَآءٌ</span></h3>
				<div class="sense" id="baA_A1">
					<p><span class="ar">بَا</span> and <span class="ar">بَآءٌ</span>: <a href="index.php?data=02_b/000_b">see the letter <span class="ar">ب</span></a>, <a href="index.php?data=02_b/211_bwA">and arts. <span class="ar">بوأ</span></a> <a href="index.php?data=02_b/228_be">and <span class="ar">بى</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0144.pdf" target="pdf">
							<span>Lanes Lexicon Page 144</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
