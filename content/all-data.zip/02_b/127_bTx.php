<article class="root" id="Root_bTx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/126_bTH">بطح</a></span>
				<span class="ar">بطخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/128_bTr">بطر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTx_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطخ</span></h3>
				<div class="sense" id="bTx_4_A1">
					<p><span class="ar">أَبْطَخُوا</span> <em>They had abundance of</em> <span class="ar">بِطِّيخ</span> <span class="add">[or <em>melons,</em> or <em>water-melons</em>]</span>. <span class="auth">(Ṣ, A, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTx_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبطّخ</span></h3>
				<div class="sense" id="bTx_5_A1">
					<p><span class="ar">تبطّخ</span> <em>He ate</em> <span class="ar">بِطِّيخ</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTixapN">
				<h3 class="entry"><span class="ar">بَطِخَةٌ</span></h3>
				<div class="sense" id="baTixapN_A1">
					<p><span class="ar long">إِبِلٌ بَطِخَةٌ</span>, and <span class="ar long">رِجَالٌ بَطِخَةٌ</span>, ‡ <em>Large, big, bulky,</em> or <em>corpulent, camels,</em> and <em>men:</em> and<span class="arrow"><span class="ar long">رَجُلٌ بُطَاخِىٌّ↓</span></span> ‡ <em>a large, big, bulky,</em> or <em>corpulent, man.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buTaAxieBN">
				<h3 class="entry"><span class="ar">بُطَاخِىٌّ</span></h3>
				<div class="sense" id="buTaAxieBN_A1">
					<p><span class="ar">بُطَاخِىٌّ</span>: <a href="#baTixapN">see what immediately precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTBiyxN">
				<h3 class="entry"><span class="ar">بَطِّيخٌ</span> / <span class="ar">بَطِّيخَةٌ</span></h3>
				<div class="sense" id="baTBiyxN_A1">
					<p><span class="ar">بَطِّيخٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> vulgarly and incorrectly pronounced <span class="ar">بَطِّيخٌ</span>, <span class="auth">(ISk, Mṣb,)</span> and in the dial. of El-Ḥijáz called <span class="ar">طِبِّيخٌ</span>, <span class="auth">(Mṣb,)</span> <em>A certain well-known fruit;</em> <span class="auth">(Mṣb;)</span> <span class="add">[the <em>melon,</em> absolutely, as is shown by many passages in the lexicons, and expressly stated in law-books: and, particularly, the <em>water-melon; cucurbita citrullus:</em> or <em>a plant</em>]</span> <em>of the kind called</em> <span class="ar">يَقْطِين</span>, <em>that does not grow tall, but extends itself upon the surface of the ground:</em> <span class="auth">(Ḳ, TA:)</span> and also the <span class="ar">خِرْبِز</span> <span class="add">[or <span class="ar">خَرْبُز</span>, a Persian word, and applied to the <em>water-melon,</em> by the Turks termed by this name, and in their own language <span class="ar">قَارْپُوزْ</span>]</span>: <span class="auth">(CK: <span class="add">[but not found by me in my MṢ. copy of the Ḳ, nor in the L, nor in the TA:]</span>)</span> or <span class="ar long">البِطِّيخُ الهِنْدِىُّ</span> <span class="add">[the Indian <span class="ar">بطّيخ</span>]</span> is <em>what is called in Persian the</em> <span class="fa">خَرْبُز</span>: <span class="auth">(Mgh:)</span> <span class="add">[the term <span class="ar">بطّيخ</span> is applied to many varieties of the water-melon, distinguished by different epithets; as <span class="ar">الأَحْمَرُ</span> <em>the red,</em> <span class="ar">الأَصْفَرُ</span> <em>the yellow,</em> <span class="ar">الأَبْيَضُ</span> <em>the white,</em> <span class="ar">الأَجْرَبُ</span> <em>the mangy,</em> <span class="ar">النَّمْشُ</span> <em>the speckled,</em> <span class="ar">البُرُلُّىُّ</span> <em>that of El-Burullus,</em>, &amp;c.: it is a coll. gen. n.:]</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَطِّيخَةٌ</span>}</span></add>. <span class="auth">(Ṣ, Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboTaxapN">
				<span class="pb" id="Page_0217"></span>
				<h3 class="entry"><span class="ar">مَبْطَخَةٌ</span></h3>
				<div class="sense" id="maboTaxapN_A1">
					<p><span class="ar">مَبْطَخَةٌ</span> <span class="auth">(Ṣ, A, Mgh, &amp;c.)</span> and <span class="ar">مَبْطُخَةٌ</span> <span class="auth">(Ṣ, L, Ḳ)</span> <em>A place where</em> <span class="ar">بِطِّيخ</span> <em>grow:</em> <span class="auth">(Ṣ, A, Mgh, &amp;c.:)</span> pl. <span class="ar">مَبَاطِخُ</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0216.pdf" target="pdf">
							<span>Lanes Lexicon Page 216</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0217.pdf" target="pdf">
							<span>Lanes Lexicon Page 217</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
