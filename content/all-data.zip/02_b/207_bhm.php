<article class="root" id="Root_bhm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/206_bhl">بهل</a></span>
				<span class="ar">بهم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/208_bhw">بهو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhm_2">
				<h3 class="entry">2. ⇒ <span class="ar">بهّم</span></h3>
				<div class="sense" id="bhm_2_A1">
					<p><span class="ar long">بهّموا البَهْمِ</span>, inf. n. <span class="ar">تَبْهِيمٌ</span>, <em>They separated the</em> <span class="ar">بهم</span> <span class="add">[i. e. <em>lambs,</em> or <em>kids,</em> or <em>both,</em>]</span> <em>from their mothers,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and pastured them alone.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhm_2_B1">
					<p><span class="ar long">بهّموا بِالمَكَانِ</span>, inf. n. as above, <em>They stayed,</em> or <em>remained, in the place;</em> <span class="auth">(Ḳ, TA;)</span> <em>did not quit it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bhm_2_B2">
					<p>Also <span class="ar">بهّم</span>, said of a man, † <em>He continued looking at a thing without his being relieved by doing so.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bhm_2_B3">
					<p>† <em>He was silent, and confounded,</em> or <em>perplexed, when asked respecting a thing.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bhm_2_B4">
					<p>† <em>He did not fight,</em> or <em>engage in conflict.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhm_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابهم</span></h3>
				<div class="sense" id="bhm_4_A1">
					<p><span class="ar">ابهم</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">إِبْهَامٌ</span>, <span class="auth">(JK,)</span> † <em>It</em> <span class="auth">(a thing, or an affair,)</span> <em>was,</em> or <em>became, dubious, confused,</em> or <em>vague,</em> <span class="auth">(JK, Ḳ, TA,)</span> <em>so that one knew not the way,</em> or <em>manner, in which it should be engaged in, done, executed,</em> or <em>performed;</em> <span class="auth">(JK, TA;)</span> as also<span class="arrow"><span class="ar">استبهم↓</span></span>; <span class="auth">(JK, Ḳ, TA;)</span> for which grammarians often use <span class="arrow"><span class="ar">انبهم↓</span></span>; but this has not been heard in the <span class="add">[classical]</span> language of the Arabs: <span class="auth">(MF, TA:)</span> <span class="add">[said to be]</span> from <span class="ar">بَهِيمٌ</span> denoting a colour, whatever it be, except that which is termed <span class="ar">شُهْبَة</span>, in which is no colour differing therefrom. <span class="auth">(Ḥar p. 50.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhm_4_B1">
					<p><em>He closed,</em> or <em>locked,</em> a door; <span class="auth">(Ṣ, Mgh, TA;)</span> <span class="add">[or, <em>so that one could not find the way to open it;</em> (<a href="#mubohamN">see <span class="ar">مُبْهَمٌ</span></a>;)]</span> and <em>stopped</em> it <em>up.</em> <span class="auth">(TA.)</span> <span class="add">[And hence,]</span> one says of the thumb, <span class="ar long">تُبْهِمُ الكَفَّ</span>, meaning <em>It closes upon</em> <span class="add">[the palm of]</span> <em>the hand, as a cover.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bhm_4_B2">
					<p><span class="add">[Hence also,]</span> † <em>He made</em> a thing, or an affair, <em>to be dubious, confused,</em> or <em>vague,</em> <span class="auth">(JK, TA,*)</span> <em>so that there was no way,</em> or <em>manner, of knowing it,</em> <span class="auth">(TA,)</span> or <em>so that one knew not the way,</em> or <em>manner, in which it should be engaged in, done, executed,</em> or <em>performed:</em> <span class="auth">(JK:)</span> <span class="add">[in the former sense, or meaning † <em>he made</em> it <em>to be dubious, confused,</em> or <em>vague,</em>]</span> said of speech, or language, <span class="auth">(Ḳ in art. <span class="ar">غمض</span>, &amp;c.,)</span> and of information, or news, or a narration; <span class="auth">(Mṣb;)</span> <em>contr.</em> of <span class="ar">أَوْضَحَ</span>; <span class="auth">(TA in art. <span class="ar">غمض</span>;)</span> <em>i. q.</em> <span class="ar long">لمْ يُبَيِّنْ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bhm_4_B3">
					<p>† <em>He made,</em> or <em>held,</em> a thing <em>to be vague,</em> or <em>indefinite.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bhm_4_B4">
					<p>And, said of a prohibited thing, † <em>He made</em> it, or <em>held</em> it, <em>to be not allowable in any manner, nor for any cause:</em> <span class="auth">(Az, TA:)</span> or <em>to be prohibited unconditionally.</em> <span class="auth">(Mgh.)</span> <span class="add">[<a href="#mubohamN">See <span class="ar">مُبْهَمٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="bhm_4_B5">
					<p>† <em>He made</em> a man <em>to turn away,</em> or <em>withdraw,</em> or <em>retire,</em> <span class="auth">(JK, Ḳ,)</span> <span class="ar long">عَنْ كَذَا</span> <em>from such a thing,</em> <span class="auth">(JK,)</span> or <span class="ar long">عَنِ الأَمْرِ</span> <em>from the affair.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bhm_4_C1">
					<p><span class="ar long">ابهمت الأَرْضُ</span> <em>The land produced what is termed</em> <span class="ar">بُهْمَى</span>: <span class="auth">(JK, Ḳ:)</span> or <em>produced much thereof.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبهّم</span></h3>
				<div class="sense" id="bhm_5_A1">
					<p><a href="#bhm_10">see 10</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhm_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبهم</span></h3>
				<div class="sense" id="bhm_7_A1">
					<p><a href="#bhm_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhm_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبهم</span></h3>
				<div class="sense" id="bhm_10_A1">
					<p><a href="#bhm_4">see 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhm_10_A2">
					<p>You say, <span class="ar long">استبهم عَلَيْهِ الأَمْرُ</span> ‡ <em>The affair was as though it were closed against him, so that he knew not the way in which to engage in it,</em> or <em>execute it;</em> syn. <span class="ar long">أُرْتِجَ عَلَيْهِ</span>. <span class="auth">(TA.)</span> And <span class="ar long">استبهم عَلَيْهِ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">استبهم عليه الكَلَامُ</span>, <span class="auth">(Ṣ, TA,)</span> † <em>Speech was as though it were closed against him;</em> or <em>he was,</em> or <em>became, impeded in his speech, unable to speak,</em> or <em>tongue-tied;</em> <span class="auth">(Ṣ,* Ḳ, TA;)</span> syn. <span class="ar">اِسْتَغْلَقَ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar long">تبهّم↓ عليه كَلَامُهُ</span></span> <span class="add">[signifies the same]</span>; syn. <span class="ar">أُرْتِجَ</span>; <span class="auth">(JK, Ṣ;*)</span> on the authority of AZ. <span class="auth">(Ṣ.)</span> And <span class="ar long">استبهم الخَبَرُ</span> † <em>The information,</em> or <em>narration, was dubious, confused, vague,</em> or <em>difficult to be understood</em> or <em>expressed;</em> or <em>was not to be understood</em> or <em>expressed; as though it were closed</em> <span class="add">[<em>against the hearer</em> or <em>speaker</em>]</span>; syn. <span class="ar">اِسْتَغْلَقَ</span>, and <span class="ar">اِسْتَعْجَمَ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahomN">
				<h3 class="entry"><span class="ar">بَهْمٌ</span></h3>
				<div class="sense" id="bahomN_A1">
					<p><span class="ar">بَهْمٌ</span> is pl. of<span class="arrow"><span class="ar">بَهْمَةٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> as are also <span class="arrow"><span class="ar">بَهَمٌ↓</span></span> and <span class="ar">بِهَامٌ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[or rather <span class="ar">بَهْمٌ</span> is a coll. gen. n., and<span class="arrow"><span class="ar">بَهْمَةٌ↓</span></span> is its n. un., and<span class="arrow"><span class="ar">بَهَمٌ↓</span></span> is a quasi-pl. n., and]</span> <span class="ar">بِهَامٌ</span> <a href="#bahomN">is pl. of <span class="ar">بَهْمٌ</span></a>, <span class="auth">(Ṣ, Mṣb,)</span> and <span class="ar">بِهَامَاتِ</span> is a pl. pl. <span class="add">[i. e. <a href="#bihaAmN">pl. of <span class="ar">بِهَامٌ</span></a>]</span>: <span class="auth">(Ḳ:)</span> <span class="arrow"><span class="ar">بَهْمَةٌ↓</span></span> signifies <em>A lamb,</em> and is applied to the <em>male</em> and the <em>female;</em> <span class="auth">(Ṣ, Mṣb;)</span> or, accord. to a trad. in which it occurs, it is a name for the <em>female;</em> <span class="auth">(IAth, TA;)</span> but <span class="ar">بِهَامٌ</span>, which is applied to <em>lambs when they are alone,</em> as <span class="ar">سِخَالٌ</span> is to kids when they are alone, is also applied to <em>lambs and kids together:</em> <span class="auth">(Ṣ,* Mṣb:)</span> or, accord. to IF, <span class="ar">بَهْمٌ</span> signifies <em>young lambs</em> or <em>goats:</em> <span class="auth">(Mṣb:)</span> and accord. to AZ, <span class="auth">(Mṣb,)</span> or AʼObeyd, <span class="auth">(TA,)</span> <span class="arrow"><span class="ar">بَهْمَةٌ↓</span></span> is applied to <em>a lamb</em> or <em>goat,</em> whether <em>male</em> or <em>female, after the period when it is termed</em> <span class="ar">سَخْلَةٌ</span>, <em>which is when it is just brought forth;</em> <span class="auth">(Mṣb, TA;)</span> and its pl. is <span class="ar">ابهم</span>: <span class="auth">(Mṣb: <span class="add">[so in my copy of that work, as though meant for <span class="ar">أَبْهُمٌ</span>; but perhaps a mistranscription for <span class="ar">البَهْمُ</span>:]</span>)</span> or it is applied to <em>a lamb</em> or <em>goat when just brought forth,</em> i. e., <em>before it is termed</em> <span class="ar">سَخْلَةٌ</span>: <span class="auth">(Mgh: <span class="add">[and this is agreeable with its application in a trad. cited by IAth:]</span>)</span> or to the <em>young one, not,</em> as in the Ḳ, <em>young ones,</em> <span class="auth">(TA,)</span> <em>of the sheep,</em> and <em>of the goat,</em> and <em>of an animal of the bovine kind</em> <span class="auth">(Ḳ, TA)</span> both <em>wild</em> and <em>not wild,</em> alike to the <em>male</em> and the <em>female, while small;</em> or, as some say, <em>when it has attained to youthful vigour:</em> <span class="auth">(TA:)</span> Lebeed applies <span class="ar">بِهَامٌ</span> to the <em>young ones of</em> <span class="add">[<em>wild</em>]</span> <em>animals of the bovine kind:</em> <span class="auth">(Ṣ, TA:)</span> accord. to Th, <span class="ar">بَهْمٌ</span> signifies <em>young kids.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahomN_A2">
					<p><span class="ar long">سَعْدُ البِهَامِ</span> <em>One of the Mansions</em> <span class="auth">(Ḳ, TA)</span> <em>of the Moon:</em> <span class="auth">(TA:)</span> or <em>two stars which are not of the Mansions of the Moon.</em> <span class="auth">(Ṣ and L and Ḳ in art. <span class="ar">سعد</span>, q. v.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bahamN">
				<h3 class="entry"><span class="ar">بَهَمٌ</span></h3>
				<div class="sense" id="bahamN_A1">
					<p><span class="ar">بَهَمٌ</span>: <a href="#bahomN">see <span class="ar">بَهْمٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahimN">
				<h3 class="entry"><span class="ar">بَهِمٌ</span></h3>
				<div class="sense" id="bahimN_A1">
					<p><span class="add">[<span class="ar">بَهِمٌ</span> an epithet of which only the fem. form is mentioned. You say]</span> <span class="ar long">أَرْضٌ بَهِمَةٌ</span> <em>Land abounding with what is termed</em> <span class="ar">بُهْمَى</span>: <span class="auth">(AḤn, Ḳ:)</span> the word <span class="ar">بهمة</span> is a possessive epithet. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bahomapN">
				<h3 class="entry"><span class="ar">بَهْمَةٌ</span></h3>
				<div class="sense" id="bahomapN_A1">
					<p><span class="ar">بَهْمَةٌ</span>: <a href="#bahomN">see <span class="ar">بَهْمٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhomapN">
				<h3 class="entry"><span class="ar">بُهْمَةٌ</span></h3>
				<div class="sense" id="buhomapN_A1">
					<p><span class="ar">بُهْمَةٌ</span> <em>A rock,</em> or <em>great mass of stone</em> or <em>of hard stone,</em> <span class="auth">(Ḳ, TA,)</span> <em>that is solid, not hollow.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بُهْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buhomapN_A2">
					<p>And hence, accord. to some, <span class="auth">(TA,)</span> or because his condition is such that one knows not how to prevail with him, <span class="auth">(Ḥam pp. 334 and 610,)</span> <em>A courageous man,</em> <span class="auth">(Ḳ, and Ḥam ubi suprà,)</span> or <em>a horseman,</em> <span class="auth">(AO, Ṣ,)</span> <em>to whom one knows not the way whence to gain access,</em> or <em>whence to come,</em> <span class="auth">(AO, Ṣ, Ḳ,)</span> <em>by reason of his great might,</em> or <em>valour:</em> <span class="auth">(AO, Ṣ:)</span> or, as in the Nawádir, <span class="ar long">رَجُلٌ بُهْمَةٌ</span> signifies <em>a man who will not be turned from a thing that he desires to do:</em> <span class="auth">(TA:)</span> it is not applied as an epithet to a woman: <span class="auth">(IJ, TA:)</span> pl. <span class="ar">بُهَمٌ</span>. <span class="auth">(Ṣ, A.)</span> You say, <span class="ar long">هُوَ بُهْمَةٌ مِنَ البُهَمِ</span>, meaning † <em>He is a courageous man, of those to whom the approach is as though it were closed against his adversaries.</em> <span class="auth">(A, TA.)</span> Accord. to IJ, it is an inf. n. used as an epithet, though having no verb. <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> it applies to one and to a number of persons. <span class="auth">(Ḥam p. 494.)</span> <span class="add">[For]</span> it signifies also</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بُهْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buhomapN_A3">
					<p>† <em>An army:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>courageous men,</em> or <em>courageous men clad in armour;</em> because one knows not the way in which to fight with them: or, as some say, <em>a company of horsemen:</em> <span class="auth">(TA:)</span> pl. as above. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بُهْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="buhomapN_A4">
					<p>† <em>A difficult affair</em> or <em>case;</em> <span class="auth">(Ḳ, TA;)</span> <em>such that one cannot find the way to perform it,</em> or <em>manage it:</em> pl. as above. <span class="auth">(TA.)</span> You say, <span class="ar long">وَقَعَ فِى بُهْمَةٍ لَا يُتَّجَهُ لَهَا</span> † <span class="add">[<em>He fell into a difficult,</em> or <em>an embarrassing, case, which one knew not the way to manage</em>]</span>. <span class="auth">(TA.)</span> The pl. is also explained as meaning † <em>Dubious, confused,</em> or <em>vague, affairs</em> or <em>cases.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بُهْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="buhomapN_A5">
					<p>† <em>Blackness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بُهْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="buhomapN_A6">
					<p>And <span class="ar">البُهَمُ</span> † <em>The three nights in which the moon does not</em> <span class="add">[<em>visibly</em>]</span> <em>rise.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buhomae">
				<h3 class="entry"><span class="ar">بُهْمَى</span></h3>
				<div class="sense" id="buhomae_A1">
					<p><span class="ar">بُهْمَى</span>, a word both sing. and pl., <span class="auth">(Sb, Ṣ, Ḳ,)</span> its alif <span class="add">[written <span class="ar">ى</span>]</span> being a denotative of the fem. gender, wherefore it is without tenween; <span class="auth">(Sb, Ṣ;)</span> or <span class="add">[it is written <span class="ar">بُهْمًى</span>, with tenween, for it is a coll. gen. n., and]</span> its n. un. is <span class="ar">بُهْمَاةٌ</span>, <span class="auth">(Ṣ, Ḳ, and so in the JK,)</span> its alif, some say, being a letter of quasi-coordination; but Mbr says that this is not known, and that the alif in a word of the measure <span class="ar">فُعْلى</span> is nought but a denotative of the fem. gender; <span class="auth">(Ṣ;)</span> <span class="pb" id="Page_0269"></span>and the n. un. <span class="ar">بهماة</span> is anomalous; <span class="auth">(El-'Ashmoonee's Expos. of the Alfeeyeh of Ibn-Málik, § <span class="ar">التأنيث</span>;)</span> <span class="add">[<em>A species of barley-grass;</em> app. <em>hordeum murinum,</em> or <em>common wall-barley-grass;</em>]</span> <em>a certain plant,</em> <span class="auth">(Lth, JK, Ṣ, Ḳ,)</span> <em>well known;</em> <span class="auth">(Ḳ;)</span> <em>the sheep and goats,</em> <span class="auth">(Lth, TA,)</span> or <em>the camels,</em> <span class="auth">(JK,)</span> <em>are vehemently fond of it as long as it is green;</em> <span class="auth">(Lth, JK, TA;)</span> <em>but when it dries up, its prickles bristle out, and it repugns;</em> <span class="auth">(Lth, TA;)</span> <em>it is of the herbs</em> (<span class="ar">بُقُول</span>) <em>that are termed</em> <span class="ar">أَحْرَاز</span> <span class="add">[app. here meaning <em>slender and sweet</em>]</span> <em>when fresh and when dry, and comes forth at first undistinguishably as to species, from the earth, like as does corn; then it becomes like corn, and puts forth prickles like those</em> <span class="add">[<em>that compose the awn,</em> or <em>beard,</em>]</span> <em>of the ear of corn, which, when they enter the noses of the sheep or goats and the camels, cause pain to their noses, until men pull them out from their mouths and their noses; and when it becomes large, and dries up, it is a pasture that is fed upon until the rain of the next year falls upon it, when its seed that has fallen from its ears germinates beneath it.</em> <span class="auth">(AḤn, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahiymN">
				<h3 class="entry"><span class="ar">بَهِيمٌ</span></h3>
				<div class="sense" id="bahiymN_A1">
					<p><span class="ar">بَهِيمٌ</span> <em>Black:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">بُهُمٌ</span>. <span class="auth">(TA.)</span> And <span class="add">[app. used also as a subst., signifying]</span> <em>A black ewe</em> <span class="auth">(Ḳ, TA)</span> <em>in which is no whiteness:</em> pl. as above and <span class="ar">بُهْمٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bahiymN_A2">
					<p>Applied to a horse, to the male and the female, <span class="auth">(Ṣ,* Mgh,* Ḳ,)</span> <em>Of one, unmixed, colour; in which is no colour differing from the rest:</em> <span class="auth">(Ṣ, Mgh, Ḳ:)</span> pl. <span class="ar">بُهُمٌ</span>. <span class="auth">(Ṣ.)</span> <span class="ar long">لَا أَغَرُّ وَلَا بَهِيمٌ</span> <span class="add">[<em>Not having a star,</em> or <em>blaze, on the forehead</em> or <em>face, nor of one, unmixed, colour,</em> or <em>not white nor black,</em> <span class="auth">(some such proposition as “This is a horse” being understood before <span class="ar">لا</span>,)</span>]</span> is a prov. applied to a dubious, confused, or vague, affair or case. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bahiymN_A3">
					<p>A colour <em>of one kind,</em> <span class="auth">(JK,)</span> <em>in which is no colour differing from the rest,</em> <span class="auth">(JK, and Ḥar p. 50,)</span> <em>whatever colour it be, except that which is termed</em> <span class="ar">شُهْبَة</span>: <span class="auth">(Ḥar ubi suprà:)</span> or a colour <em>that is clear, pure,</em> or <em>unmixed, not resembling any other,</em> <span class="auth">(AA, Ḳ,* TA,)</span> <em>whether it be black or any other colour,</em> <span class="auth">(AA, TA,)</span> <em>except,</em> as Z says, <em>that which is termed</em> <span class="ar">شُهْبَة</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bahiymN_A4">
					<p>A night <em>in which is no light</em> <span class="auth">(JK, TA)</span> <em>until the dawn.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bahiymN_A5">
					<p>‡ A sound, or voice, <em>in which is no trilling,</em> or <em>quavering,</em> or <em>reiteration in the throat</em> or <em>fauces.</em> <span class="auth">(JK, Ḳ,* TA.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bahiymN_A6">
					<p><em>Perfect,</em> or <em>complete, in make;</em> as also<span class="arrow"><span class="ar">مُبْهَمٌ↓</span></span>: pl. <span class="ar">بُهْمٌ</span>: so in the phrase in a trad. <span class="auth">(respecting the day of resurrection, TA)</span>, <span class="ar long">يُحْشَرُ النَّاسُ بُهْمًا</span>, i. e. <em>Mankind shall be congregated perfect,</em> or <em>complete, in make, without mutilation,</em> or <em>defect:</em> <span class="auth">(JK:)</span> or the meaning here is, <em>sound,</em> or <em>healthy:</em> <span class="auth">(Ṣ:)</span> or <em>not having any of the diseases or noxious affections of the present state, as blindness, and elephantiasis, and leprosy, and blindness of one eye, and lameness, &amp;c.:</em> <span class="auth">(AʼObeyd, Ḳ,* TA:)</span> or <em>naked;</em> <span class="auth">(JK, Ḳ;)</span> <em>not having upon them anything to conceal them:</em> <span class="auth">(JK:)</span> or <em>not having with them anything</em> <span class="auth">(Ṣ, TA)</span> <em>of worldly goods</em> or <em>commodities.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bahiymN_A7">
					<p>† <em>Unknown.</em> <span class="auth">(El-Khaṭṭábee, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">بَهِيمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bahiymN_B1">
					<p><a href="#IibohaAmN">See also <span class="ar">إِبْهَامٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahiymapN">
				<h3 class="entry"><span class="ar">بَهِيمَةٌ</span></h3>
				<div class="sense" id="bahiymapN_A1">
					<p><span class="ar">بَهِيمَةٌ</span> <span class="add">[<em>A beast; a brute;</em>]</span> <em>any quadruped,</em> <span class="auth">(Akh, M, Mṣb, Ḳ,)</span> <em>even if in the water,</em> <span class="auth">(Akh, M, Ḳ,)</span> <span class="add">[i. e.,]</span> <em>of the land</em> and <em>of the sea;</em> <span class="auth">(Mṣb;)</span> and <span class="auth">(so in the Mṣb, but in the Ḳ “or”)</span> <em>any animal that does not discriminate:</em> <span class="auth">(Zj, Mṣb, Ḳ:)</span> pl. <span class="ar">بَهَائِمُ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahiymie">
				<h3 class="entry"><span class="add">[<span class="ar">بَهِيمِى</span>]</span></h3>
				<div class="sense" id="bahiymie_A1">
					<p><span class="add">[<span class="ar">بَهِيمِى</span> <em>Of,</em> or <em>relating to, beasts,</em> or <em>brutes.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahiymiyBapN">
				<h3 class="entry"><span class="add">[<span class="ar">بَهِيمِيَّةٌ</span>]</span></h3>
				<div class="sense" id="bahiymiyBapN_A1">
					<p><span class="add">[<span class="ar">بَهِيمِيَّةٌ</span> The <em>nature of beasts,</em> or <em>brutes.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabohamu">
				<h3 class="entry"><span class="ar">أَبْهَمُ</span></h3>
				<div class="sense" id="Oabohamu_A1">
					<p><span class="ar">أَبْهَمُ</span>: <a href="#mubohamN">see <span class="ar">مُبْهَمٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">أَبْهَمُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabohamu_A2">
					<p>Also <em>i. q.</em> <span class="ar">أَعْجَمُ</span> <span class="add">[app. as meaning <em>Destitute of the faculty of speech</em> or <em>articulation, like the beasts</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibohaAmN">
				<h3 class="entry"><span class="ar">إِبْهَامٌ</span></h3>
				<div class="sense" id="IibohaAmN_A1">
					<p><span class="ar">إِبْهَامٌ</span> The <em>thumb,</em> and the <em>great toe;</em> <span class="auth">(M, Ḳ;)</span> the <em>greatest</em> <span class="ar">إِصْبَع</span>, <span class="auth">(JK, T, Ṣ,)</span> <em>that is next to the forefinger, having two joints,</em> so called because it closes upon <span class="add">[the palm of]</span> the hand, as a cover; <span class="auth">(T, TA;)</span> the <em>greatest of the</em> <span class="ar">أَصَابِع</span> <em>in the hand</em> and <em>in the foot:</em> <span class="auth">(M, Ḳ:)</span> of the fem. gender, <span class="auth">(Ṣ, Mṣb,)</span> accord. to common repute; <span class="auth">(Mṣb;)</span> and sometimes masc.: <span class="auth">(Lḥ, M, Ḳ:)</span> and<span class="arrow"><span class="ar">بَهِيمٌ↓</span></span> signifies the same; mentioned by Az in the T, and by others; but Az adds that one should not say <span class="ar">بِهَامٌ</span>: <span class="auth">(TA:)</span> <a href="#AbhAm">the pl. of <span class="ar">ابهام</span></a> is <span class="ar">أَبَاهِيمُ</span> <span class="auth">(JK, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَبَاهِمُ</span>, <span class="auth">(M, Ḳ,)</span> which latter is used by poetic license for the former, <span class="auth">(M,)</span> and <span class="ar">إِبْهَامَاتٌ</span>. <span class="auth">(Mṣb.)</span> <span class="ar long">أَقْصَرُ مِنْ إِبْهَامِ الضَّبِّ</span> <span class="add">[<em>Shorter than the great toe of the</em> (<em>lizard called</em>) <span class="ar">ضبّ</span>]</span>, and <span class="ar long">من ابهام القَطَاةِ</span> <span class="add">[<em>than the back toe of the</em> (<em>bird called</em>) <span class="ar">قطاة</span>]</span>, and <span class="ar long">من ابهام الحُبَارَى</span> <span class="add">[<em>than the back toe of the</em> (<em>bird called</em>) <span class="ar">حبارى</span>]</span>, are proverbs of the Arabs. <span class="auth">(Ḥar p. 335.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubohamN">
				<h3 class="entry"><span class="ar">مُبْهَمٌ</span></h3>
				<div class="sense" id="mubohamN_A1">
					<p><span class="ar">مُبْهَمٌ</span>, applied to a door, <em>Closed,</em> or <em>locked,</em> <span class="auth">(JK, Ḳ,)</span> <em>so that one cannot find the way to open it:</em> <span class="auth">(JK, TA:)</span> and <em>stopped up:</em> <span class="auth">(TA:)</span> or <em>having a lock upon it, with which it is fastened.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubohamN_A2">
					<p>A wall <em>in which is no door.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mubohamN_A3">
					<p>A chest <em>having no lock</em> <span class="add">[<em>by means of which it may be opened</em>]</span>. <span class="auth">(IAmb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="mubohamN_A4">
					<p><em>I. q.</em> <span class="ar">مُصْمَتٌ</span> <span class="add">[as meaning <em>Solid; not hollow;</em> in the CK <span class="ar">أَصْمَتُ</span>, which signifies the same]</span>; as also<span class="arrow"><span class="ar">أَبْهَمُ↓</span></span>: <span class="auth">(Ḳ:)</span> <em>having no fissure in it:</em> and<span class="arrow">↓</span> the latter, applied to a heart is said to mean † <em>impenetrable by admonition.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="mubohamN_A5">
					<p>† A thing, or an affair, <em>made to be dubious, confused,</em> or <em>vague;</em> <span class="auth">(JK;)</span> <span class="add">[<em>such that there is no way,</em> or <em>manner, of knowing it;</em> <span class="auth">(see the verb;)</span>]</span> or <em>such that one knows not the way,</em> or <em>manner, in which it should be engaged in, done, executed,</em> or <em>performed:</em> <span class="auth">(JK, Ṣ, Mgh, TA:)</span> † speech, or language, <span class="add">[<em>that is dubious, confused,</em> or <em>vague,</em>]</span> <em>such that there is no way,</em> or <em>manner, of knowing it:</em> <span class="auth">(Mgh, TA:)</span> applied to a road, † <em>unapparent,</em> or <em>hardly apparent:</em> <span class="auth">(TA:)</span> and, applied to the ordinance respecting the making up for the days in which one has broken a fast, <span class="add">[and to many other cases,]</span> † <em>undefined;</em> in this instance meaning, as to whether the days may be interrupted, or whether they must be consecutive. <span class="auth">(Mgh.)</span> <span class="add">[Hence,]</span> <span class="ar">مُبْهَمَاتٌ</span> † <em>Difficult things,</em> or <em>affairs, such that one cannot find the way to perform them.</em> <span class="auth">(TA.)</span> And <span class="ar long">الأَسْمَآءُ المُبْهَمَةُ</span>, so termed by the grammarians, † <em>The nouns of indication,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>such as</em> <span class="ar">هٰذَا</span> <em>and</em> <span class="ar">هٰؤُلَآءِ</span> <em>and</em> <span class="ar">ذَاكَ</span> <em>and</em> <span class="ar">أُولَائِكَ</span>: <span class="auth">(Ṣ:)</span> accord. to Az, <span class="ar long">الحُرُوفُ المُبْهَمَةُ</span> signifies † <em>the particles which have no derivatives, and of which the roots are not known, as</em> <span class="ar">الَّذِى</span> <em>and</em> <span class="ar">مَا</span> <em>and</em> <span class="ar">مَنْ</span> <em>and</em> <span class="ar">عَنْ</span> <em>and the like.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="mubohamN_A6">
					<p>Applied to a vow, and to <span class="add">[certain ordinances respecting]</span> marriage and divorce and emancipation, † <em>From which there is no getting out,</em> or <em>extricating of oneself; as though they were closed doors with locks upon them:</em> <span class="auth">(Mgh:)</span> and, applied to prohibited things, † <em>not allowable in any manner,</em> <span class="auth">(T, Ḳ, TA,)</span> <em>nor for any cause;</em> <span class="auth">(T, TA;)</span> or <em>prohibited unconditionally;</em> <span class="auth">(Mgh;)</span> <em>as the prohibition of</em> <span class="add">[<em>the marriage with</em>]</span> <em>the mother, and the sister,</em> <span class="auth">(T, Mgh,* Ḳ, TA,)</span> <em>and the like:</em> <span class="auth">(T, TA:)</span> such a woman is said to be <span class="ar long">مُبْهَمَةٌ عَلَى الرَّجُلِ</span> † <span class="add">[<em>absolutely prohibited to the man; as though she were closed against him,</em> or <em>inaccessible to him</em>]</span>. <span class="auth">(Mṣb. <span class="add">[But in this last work it seems to be <span class="ar">مثبْهِمَةٌ</span>, which is not agreeable with common usage.]</span>)</span> In the copies of the Ḳ, <span class="ar">بُهْمٌ</span> and <span class="ar">بُهُمٌ</span> are given as pls. of this word: but it seems that there is an omission or a misplacement in the passage; for these are said to be pls. of <span class="ar">بَهِيمٌ</span>, as shown above. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="mubohamN_A7">
					<p>† <em>In a state of swooning</em> or <em>insensibility, speechless, and without discrimination;</em> in consequence of a blow <span class="add">[&amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهم</span> - Entry: <span class="ar">مُبْهَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="mubohamN_A8">
					<p><a href="#bahiymN">See also <span class="ar">بَهِيمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotabohimN">
				<h3 class="entry"><span class="ar">مُسْتَبْهِمٌ</span></h3>
				<div class="sense" id="musotabohimN_A1">
					<p><span class="ar long">مُسْتَبْهِمٌ عَنِ الكَلَامِ</span> † <em>Debarred from the faculty of speech.</em> <span class="auth">(Nifṭaweyh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0268.pdf" target="pdf">
							<span>Lanes Lexicon Page 268</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0269.pdf" target="pdf">
							<span>Lanes Lexicon Page 269</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
