<article class="root" id="Root_bTm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/133_bTl">بطل</a></span>
				<span class="ar">بطم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/135_bTn">بطن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="buTomN">
				<h3 class="entry"><span class="ar">بُطْمٌ</span></h3>
				<div class="sense" id="buTomN_A1">
					<p><span class="ar">بُطْمٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُطُمٌ</span>, <span class="auth">(Ḳ,)</span> the latter allowable accord. to IAạr, <span class="auth">(TA,)</span> The <span class="ar long">حَبَّة خَضْرَآء</span> <span class="add">[or <em>fruit of the terebinth-tree,</em> to which this latter appellation is given in the present day, i. e., <em>of the pistacia terebinthus of the botanists</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> so accord. to the people of El-ʼÁliyeh; and the like is said on the authority of Aṣ: <span class="auth">(TA:)</span> or the <em>tree thereof;</em> <span class="auth">(Ḳ;)</span> <span class="add">[which is called <span class="ar">بُطْم</span> in the present day;]</span> so accord. to AḤn; and he says, but no one has told me that it grows in the land of the Arabs; but they assert that <em>the</em> <span class="ar">ضِرْو</span> <span class="add">[meaning the <em>cancamum-tree,</em> also called <span class="ar">كَمْكَام</span>, but said by IAạr to be the <span class="ar long">حبّة خضراء</span>,]</span> <em>is nearly like it:</em> <span class="auth">(TA:)</span> <em>its fruit is heating, diuretic, strengthening to the venereal faculty, good for the cough, and for the</em> <span class="add">[<em>disease of the face called</em>]</span> <span class="ar">لَقْوَة</span>, <em>and for the kidney; and the overspreading of the hair with its dry and sifted leaves causes it to grow, and beautifies it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0219.pdf" target="pdf">
							<span>Lanes Lexicon Page 219</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
