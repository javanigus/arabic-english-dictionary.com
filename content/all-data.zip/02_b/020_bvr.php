<article class="root" id="Root_bvr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/019_bv">بث</a></span>
				<span class="ar">بثر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/021_bvq">بثق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bvr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بثر</span></h3>
				<div class="sense" id="bvr_1_A1">
					<p><span class="ar">بَثِرَ</span>, <span class="auth">(Ṣ, M, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْثَرُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بُثُورٌ</span>; <span class="auth">(M, Mṣb, Ḳ;)</span> and <span class="ar">بَثُرَ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُرُ</span>}</span></add>, <span class="auth">(Ṣ, M, Mṣb,)</span> inf. n. <span class="ar">بَثْرٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">بُثُورٌ</span>; <span class="auth">(M, Ḳ;)</span> and <span class="ar">بَثُرٌ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُرُ</span>}</span></add>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>It</em> <span class="auth">(a man's face, Ṣ, M, Ḳ, or the skin, M, A, Mṣb)</span> <em>broke out with pimples,</em> or <em>small pustules;</em> <span class="auth">(Ṣ, M, A, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">تبثّر↓</span></span>: <span class="auth">(M, A, and some copies of the Ḳ:)</span> or this last signifies <em>it</em> <span class="auth">(a man's skin)</span> <em>became blistered,</em> or <em>vesicated.</em> <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bvr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بثّر</span></h3>
				<div class="sense" id="bvr_2_A1">
					<p><span class="ar">بثّر</span> <em>It</em> <span class="auth">(tar)</span> <span class="add">[<em>made</em> a camel <em>to break out with small pustules;</em> or]</span> <em>excoriated</em> a camel, <em>and made</em> him <em>to bleed.</em> <span class="auth">(Ibn-ʼAbbád, TA in art. <span class="ar">حرش</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bvr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبثّر</span></h3>
				<div class="sense" id="bvr_5_A1">
					<p><a href="#bvr_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bavorN">
				<h3 class="entry"><span class="ar">بَثْرٌ</span></h3>
				<div class="sense" id="bavorN_A1">
					<p><span class="ar">بَثْرٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَثَرٌ↓</span></span>, <span class="auth">(M, Mṣb, Ḳ,)</span> coll. gen. ns., <span class="auth">(Mṣb,* MF,)</span> originally inf. ns., <span class="auth">(Mṣb,)</span> <em>Pimples,</em> or <em>small pustules;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> accord. to some, specially upon the face; <span class="auth">(M, TA;)</span> as also <span class="ar">بُثُورٌ</span>; <span class="auth">(Ṣ, Mṣb;)</span> which <a href="#bavorF">is the pl. of <span class="ar">بَثْرً</span></a>: <span class="auth">(Mṣb:)</span> ns. un. <span class="ar">بَثَرَاتٌ</span> <span class="auth">(Ṣ, M, Mṣb)</span> and <span class="ar">بَثَرَةٌ</span>: <span class="auth">(M, Mṣb:)</span> and pl. of this last <span class="ar">بَثَرَاتٌ</span>: <span class="auth">(Mṣb:)</span> or <span class="ar">بُثُورٌ</span>, <a href="#bavorN">pl. of <span class="ar">بَثْرٌ</span></a>, signifies <em>purulent pustules like the small-pox, upon the face and other parts of the person of a man.</em> <span class="auth">(T.)</span> You say, <span class="ar long">خَرَجَتْ بِهِ بَثْرَةٌ فَعَصَرَهَا</span> <span class="add">[<em>A pimple,</em> or <em>small pustule,</em> or <em>purulent pustule, came forth on him, and he squeezed it</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">بِجِلْدِهِ بَثْرٌ شَتَّى</span> <span class="add">[<em>In his skin are scattered,</em> or <em>sundry, pimples,</em>, &amp;c.]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bavarN">
				<h3 class="entry"><span class="ar">بَثَرٌ</span></h3>
				<div class="sense" id="bavarN_A1">
					<p><span class="ar">بَثَرٌ</span>: <a href="#bavorN">see <span class="ar">بَثْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0151.pdf" target="pdf">
							<span>Lanes Lexicon Page 151</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
