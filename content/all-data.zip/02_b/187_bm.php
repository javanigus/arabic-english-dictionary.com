<article class="root" id="Root_bm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/186_ble">بلى</a></span>
				<span class="ar">بم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/188_bn">بن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bamBN">
				<h3 class="entry"><span class="ar">بَمٌّ</span></h3>
				<div class="sense" id="bamBN_A1">
					<p><span class="ar">بَمٌّ</span> <span class="add">[The <em>bass</em> in music; used in this sense in the present day: or particularly the <em>bass notes</em> of the lute: in this sense F seems to have understood the saying of ISd that]</span> the <span class="ar">بَمّ</span> of the lute is well known: <span class="auth">(M, Ḳ: <span class="add">[in the CK, <span class="ar long">البَمَّ مِنَ العُوْدِ او الوَتَرِ الخ</span> is erroneously put for <span class="ar long">البَمُّ مِنَ العُودِ مٓ أَوِ الوَتَرُ الخ</span>:]</span>)</span> or <span class="auth">(so in the Ḳ)</span> it is the <em>thick</em> <span class="add">[or <em>bass</em>]</span> <em>chord of the lute:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="pb" id="Page_0258"></span>the word is foreign: <span class="auth">(M:)</span> <span class="add">[in Persian <span class="ar">بَمْ</span>:]</span> Az says that it is not Arabic. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bumBN">
				<h3 class="entry"><span class="ar">بُمٌّ</span></h3>
				<div class="sense" id="bumBN_A1">
					<p><span class="ar">بُمٌّ</span> <em>i. q.</em> <span class="ar">بُومٌ</span>, q. v. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0257.pdf" target="pdf">
							<span>Lanes Lexicon Page 257</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0258.pdf" target="pdf">
							<span>Lanes Lexicon Page 258</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
