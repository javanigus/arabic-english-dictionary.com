<article class="root" id="Root_bT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/123_bDE">بضع</a></span>
				<span class="ar">بط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/125_bTO">بطأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bT_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطّ</span></h3>
				<div class="sense" id="bT_1_A1">
					<p><span class="ar">بَطَّ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُطُ</span>}</span></add>, inf. n. <span class="ar">بَطٌّ</span>, <span class="auth">(Mgh, Mṣb,)</span> <em>He slit</em> a wound, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> or an ulcer, <span class="auth">(Ṣ,)</span> and a purse, <span class="auth">(Ḳ,)</span>, &amp;c. <span class="auth">(TA.)</span> <span class="add">[<a href="#bT_RQ1">See also R. Q. 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bT_2">
				<h3 class="entry">2. ⇒ <span class="ar">بطّط</span></h3>
				<div class="sense" id="bT_2_A1">
					<p><span class="ar">بِطّط</span>, inf. n. <span class="ar">تَبْطِيطٌ</span>, <em>He trafficked in the birds called</em> <span class="ar">بَطّ</span>, q. v. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bT_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطّ</span></h3>
				<div class="sense" id="bT_4_A1">
					<p><span class="ar">ابطّ</span>, <span class="auth">(IAạr, Ḳ,)</span> inf. n. <span class="ar">إِبْطَاطٌ</span>, <span class="auth">(IAạr,)</span> <em>He purchased</em> <span class="add">[or <em>became possessed of</em>]</span> <em>a</em> <span class="ar">بَطَّة</span> <span class="add">[q. v.]</span> <em>for oil,</em> or <em>of oil.</em> <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bT_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بطبط</span></h3>
				<div class="sense" id="bT_RQ1_A1">
					<p><span class="ar long">ضَرَبَهُ فَبَطْبَطَهُ</span> <em>He struck him and clave his skin,</em> or <em>his head.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bT_1">See 1</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بط</span> - Entry: R. Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bT_RQ1_B1">
					<p><a href="#baTobaTapN">See also <span class="ar">بَطْبَطَةٌ</span>, below</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTBN">
				<h3 class="entry"><span class="ar">بَطٌّ</span></h3>
				<div class="sense" id="baTBN_A1">
					<p><span class="ar">بَطٌّ</span> <em>A kind of water-fowl;</em> <span class="auth">(Ṣ, O, Mṣb;)</span> <span class="add">[the <em>duck,</em> or <em>ducks;</em> and the <em>goose,</em> or <em>geese;</em> but generally the former of these birds; agreeably with a statement in the Jm, that <span class="ar">بَطٌّ</span> is applied by the Arabs to the <em>small,</em> and <span class="ar">إِوَزٌّ</span> to the <em>large;</em>]</span> <em>i. q.</em> <span class="ar">إِوَزٌّ</span>, <span class="auth">(Ḳ, TA,)</span> both the <em>small thereof</em> and the <em>large:</em> <span class="auth">(TA:)</span> a Persian word (<span class="ar">عَجَمِىٌّ</span>), arabicized; <span class="add">[originally <span class="ar">بَتْ</span>, or <span class="ar">بَطْ</span>, or <span class="ar">بَطّ</span>;]</span> or, accord. to IJ, an imitation of its cries: n. un. <span class="ar">بَطَّةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> which is applied to the male and to the female, <span class="auth">(Ṣ, Mṣb,)</span> like <span class="ar">حَمَامَةٌ</span> and <span class="ar">دَجَاجَةٌ</span>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">بِطَاطٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTBapN">
				<h3 class="entry"><span class="ar">بَطَّةٌ</span></h3>
				<div class="sense" id="baTBapN_A1">
					<p><span class="ar">بَطَّةٌ</span> <a href="#baTBN">n. un. of <span class="ar">بَطٌّ</span>, q. v.</a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بط</span> - Entry: <span class="ar">بَطَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baTBapN_A2">
					<p>Also <em>A kind of bottle,</em> or <em>pot, of glass;</em> syn. <span class="ar">دَبَّةٌ</span>; <span class="auth">(Ḳ, TA; <span class="add">[in the CK, erroneously, <span class="ar">دُبَّة</span>;]</span>)</span> in the dial. of the people of Mekkeh; so called because made in the form of a living <span class="ar">بَطَّة</span>: <span class="auth">(Lth, TA:)</span> or <em>a vessel like the</em> <span class="add">[<em>flask,</em> or <em>bottle, called</em>]</span> <span class="ar">قَارُورَة</span>; <span class="auth">(Ḳ;)</span> <span class="add">[<em>a kind of leathern pot,</em> or <em>bottle, of which the body is nearly globular, with a short and wide neck;</em>]</span> <em>in which oil, &amp;c. are put:</em> pl. <span class="ar">بُطَطٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTBaATN">
				<h3 class="entry"><span class="ar">بَطَّاطٌ</span></h3>
				<div class="sense" id="baTBaATN_A1">
					<p><span class="ar">بَطَّاطٌ</span> <em>A maker of</em> <span class="ar">بُطَط</span>, <a href="#baTBapN">pl. of <span class="ar">بَطَّةٌ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTobaTapN">
				<h3 class="entry"><span class="ar">بَطْبَطَةٌ</span></h3>
				<div class="sense" id="baTobaTapN_A1">
					<p><span class="ar">بَطْبَطَةٌ</span> <span class="add">[app. an inf. n., of which the verb is <span class="arrow"><span class="ar">بَطْبَطَ↓</span></span>,]</span> The <em>crying,</em> or <em>cry, of the</em> <span class="ar">بَطّ</span>; <span class="auth">(Ḳ;)</span> after which it <span class="add">[the bird]</span> is named, accord. to IJ, as mentioned above: <span class="auth">(TA:)</span> or its <em>diving in water.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibaTBapN">
				<h3 class="entry"><span class="ar">مِبَطَّةٌ</span></h3>
				<div class="sense" id="mibaTBapN_A1">
					<p><span class="ar">مِبَطَّةٌ</span> The <span class="ar">مِبْضَع</span> <span class="add">[or <em>scarifying instrument</em>]</span> <span class="auth">(Ḳ, TA)</span> <em>with which a wound is slit.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0215.pdf" target="pdf">
							<span>Lanes Lexicon Page 215</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
