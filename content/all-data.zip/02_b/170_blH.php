<article class="root" id="Root_blH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/169_blj">بلج</a></span>
				<span class="ar">بلح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/171_bld">بلد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blH_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلح</span></h3>
				<div class="sense" id="blH_4_A1">
					<p><span class="ar">ابلح</span> <em>It</em> <span class="auth">(a palm-tree)</span> <em>bore,</em> or <em>had, dates in the state in which they are termed</em> <span class="ar">بَلَح</span>. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaH">
				<h3 class="entry"><span class="ar">بَلَح</span></h3>
				<div class="sense" id="balaH_A1">
					<p><span class="ar">بَلَح</span> <em>Dates,</em> or the <em>fruit of the palm-tree, while continuing green</em> <span class="auth">(Mṣb, TA)</span> <em>and small;</em> <span class="auth">(TA;)</span> a term like <span class="ar">حِصْرِمٌ</span> applied to grapes; <span class="auth">(Mṣb, TA;)</span> <em>called by the people of El-Basrah</em> <span class="ar">خَلَالٌ</span>: when they have begun to colour, i. e., to become red or yellow, they are termed <span class="ar">بُسْرٌ</span>: <span class="auth">(Mṣb:)</span> or <em>dates in the state between that in which they are called</em> <span class="ar">خلال</span> <em>and that in which they are called</em> <span class="ar">بسر</span>; <span class="auth">(Ṣ, Mgh, Ḳ;)</span> for dates in their incipient state are termed <span class="ar">طَلْعٌ</span>; then, <span class="ar">خلال</span>; then, <span class="ar">بلح</span>; then, <span class="ar">بسر</span>; then, <span class="ar">رُطَبٌ</span>; and then, <span class="ar">تَمْرٌ</span>: <span class="auth">(Ṣ, IAth:)</span> or <em>i. q.</em> <span class="ar">سُيَّابٌ</span>: <span class="auth">(Aṣ, and Ṣ and Ḳ in art. <span class="ar">سيب</span>:)</span> <span class="add">[by many of the Arabs in the present day, it is applied to <em>fresh ripe dates,</em> and to <em>dried dates:</em> it is a coll. gen. n.:]</span> n. un. with <span class="ar">ة</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0246.pdf" target="pdf">
							<span>Lanes Lexicon Page 246</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
