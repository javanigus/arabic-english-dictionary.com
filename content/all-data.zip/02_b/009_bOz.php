<article class="root" id="Root_bOz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/008_bOr">بأر</a></span>
				<span class="ar">بأز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/010_bOs">بأس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baOozN">
				<h3 class="entry"><span class="ar">بَأْزٌ</span></h3>
				<div class="sense" id="baOozN_A1">
					<p><span class="ar">بَأْزٌ</span> <em>i. q.</em> <span class="ar">بَازٍ</span> <span class="add">[<a href="#baAzK">which see</a> <a href="index.php?data=02_b/097_bzw">in art. <span class="ar">بزو</span></a>; <a href="#baAzN">and <span class="ar">بَازٌ</span></a>]</span>: pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْؤُزٌ</span>, and <span class="add">[of mult.]</span> <span class="ar">بُؤُوزٌ</span> and <span class="ar">بِئْزَانٌ</span>. <span class="auth">(Ḳ.)</span> <span class="pb" id="Page_0146"></span>IJ holds that the <span class="ar">أ</span> is substituted for <span class="ar">ا</span>, and that it remains in <span class="ar">ابؤز</span> and <span class="ar">بئزان</span> like as is the case in <span class="ar">أَعْيَادٌ</span> <span class="add">[in which the <span class="ar">ى</span> is substituted for <span class="ar">و</span> and remains in the pl. because it is substituted for <span class="ar">و</span> in the sing. <span class="ar">عِيدٌ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0146.pdf" target="pdf">
							<span>Lanes Lexicon Page 146</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
