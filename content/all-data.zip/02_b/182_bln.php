<article class="root" id="Root_bln">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/181_blqE">بلقع</a></span>
				<span class="ar">بلن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/183_blh">بله</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="balBaAnN.1">
				<h3 class="entry"><span class="ar">بَلَّانٌ</span></h3>
				<div class="sense" id="balBaAnN.1_A1">
					<p><span class="ar">بَلَّانٌ</span>: <a href="index.php?data=02_b/168_bl">see art. <span class="ar">بل</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0253.pdf" target="pdf">
							<span>Lanes Lexicon Page 253</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
