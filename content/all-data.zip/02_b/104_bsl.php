<article class="root" id="Root_bsl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/103_bsq">بسق</a></span>
				<span class="ar">بسل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/105_bsm">بسم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسل</span></h3>
				<div class="sense" id="bsl_1_A1">
					<p><span class="ar">بَسْلٌ</span> <span class="auth">(inf. n. of <span class="ar">بَسَلَ</span>, M)</span> is The act of <em>preventing, hindering, withholding, debarring, forbidding,</em> or <em>prohibiting;</em> syn. <span class="ar">مَنْعٌ</span>; the primary meaning; <span class="auth">(Bḍ in vi. 69;)</span> and <span class="ar">إِعْجَالٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">حَبْسٌ</span>; <span class="auth">(AA, Ḳ;)</span> <span class="add">[both syn. with <span class="ar">مَنْعٌ</span>;]</span> and<span class="arrow"><span class="ar">إِبْسَالٌ↓</span></span> <span class="add">[<a href="#bsl_4">inf. n. of 4, q. v.</a> infrà,]</span> signifies the same. <span class="auth">(Bḍ ubi suprà.)</span> You say, <span class="ar long">بَسَلَنِى عَنْ حَاجَتِى</span>, inf. n. as above, <em>He prevented me from accomplishing my want;</em> syn. <span class="ar">أَعْجَلَنِى</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsl_1_B1">
					<p><span class="ar">بَسَلَ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُلُ</span>}</span></add>, <span class="auth">(M,)</span> inf. n. <span class="ar">بُسُولٌ</span>, <em>He</em> <span class="auth">(a man, TA)</span> <em>frowned, contracted his face,</em> or <em>looked sternly</em> or <em>austerely</em> or <em>morosely;</em> or, doing <em>so, grinned,</em> or <em>displayed his teeth;</em> or <em>contracted the part between his eyes;</em> (<span class="ar">عَبَسَ</span>;) <em>by reason of courage,</em> or <em>of anger;</em> as also<span class="arrow"><span class="ar">تبسّل↓</span></span>: <span class="auth">(M, Ḳ:)</span> and <span class="add">[so in the M, but in the Ḳ “or”]</span> <span class="arrow"><span class="ar long">تبسّل↓ وَجْهُهُ</span></span>, <span class="auth">(M, and so in some copies of the Ḳ,)</span> or<span class="arrow"><span class="ar">تبسّل↓</span></span> <span class="add">[alone]</span>, <span class="auth">(so in other copies of the Ḳ, and in the TA,)</span> <em>His face,</em> or <em>he, was,</em> or <em>became, odious, and excessively foul</em> or <em>unseemly</em> or <em>hideous, in aspect:</em> <span class="auth">(M, Ḳ:)</span> and<span class="arrow"><span class="ar long">تبسّل↓ لِى</span></span> <em>He</em> <span class="auth">(a man)</span> <em>was displeasing,</em> or <em>odious, in aspect to me.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bsl_1_B2">
					<p>And <span class="add">[hence]</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بُسُولٌ</span>, <span class="auth">(TA,)</span> said of milk, <a href="#nabiyc">and of <span class="ar">نَبِيذ</span></a> <span class="add">[or must, &amp;c.]</span>, ‡ <em>It was,</em> or <em>became, strong:</em> <span class="auth">(Ḳ: <span class="add">[in the CK, <span class="ar">بَسَّلَ</span> is here erroneously put for <span class="ar">بَسَلَ</span>; and <span class="ar">وَبَسَّلَهُ</span>, which should next follow, is omitted:]</span>)</span> or, said of the former, <em>it was,</em> or <em>became, displeasing,</em> or <em>odious, in taste, and sour;</em> and, said of the latter, <em>it was,</em> or <em>became, strong, and sour.</em> <span class="auth">(M, TA.)</span> Also, said of vinegar, † <em>It, having been left long, became altered,</em> or <em>corrupted, in flavour.</em> <span class="auth">(Az in art. <span class="ar">حذق</span>, TA.)</span> And, said of flesh-meat, † <em>It stank,</em> or <em>became stinking.</em> <span class="auth">(AḤn, M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bsl_1_C1">
					<p><span class="ar">بِسُلَ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُلُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَسَالَةٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">بَسَالٌ</span>, <span class="add">[respecting which latter see what follows in the next sentence,]</span> <span class="auth">(M, Ḳ,)</span> <em>He was,</em> or <em>became, courageous,</em> or <em>strong-hearted, on the occasion of war,</em> or <em>fight:</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> from <span class="ar">بَسْلٌ</span> meaning “forbidden,” or “prohibited;” because he who has this quality defends himself from his antagonist, as though it were forbidden to him <span class="add">[the latter]</span> to do him a displeasing, or an evil, deed. <span class="auth">(Ḥam p. 13.)</span> El-Hoteíah says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَأَحْلَى مِنَ التَّمْرِ الجَنِىِّ وَفِيهِمُ</span> *</div> 
						<div class="star">* <span class="ar long">بَسَالَةُ نَفْسٍ إِنْ أُرِيدَ بَسَالُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And sweeter than fresh-gathered dates, and in them is courageousness of soul, if courageousness thereof be desired</em>]</span>: but <span class="ar">بسالها</span> may be here altered by curtailment from <span class="ar">بَسَالَنُهَا</span>. <span class="auth">(M.)</span> You say, <span class="ar long">مَا أَبْيَنَ بَسَالَتَهُ</span> <span class="add">[<em>How manifest is</em>]</span> <em>his courage!</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="bsl_1_C2">
					<p><a href="#bsl_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بسّل</span></h3>
				<div class="sense" id="bsl_2_A1">
					<p><span class="ar">بسّلهُ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَبْسِيلٌ</span>, <span class="auth">(Ḳ,)</span> <em>He made it</em> <span class="auth">(a thing)</span> <em>to be an object of dislike, disapprobation,</em> or <em>hatred;</em> syn. <span class="ar">كَرَّهَهُ</span>: <span class="auth">(M:)</span> or <em>he disliked it, disapproved of it,</em> or <em>hated it;</em> syn. <span class="ar">كَرِهَهُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsl_3">
				<h3 class="entry">3. ⇒ <span class="ar">باسل</span></h3>
				<div class="sense" id="bsl_3_A1">
					<p><span class="ar">مُبَاسَلَةٌ</span> <span class="add">[inf. n. of <span class="ar">باسل</span>]</span> The act of <em>assaulting,</em> or <em>assailing, in war.</em> <span class="auth">(Ṣ, PṢ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابسل</span></h3>
				<div class="sense" id="bsl_4_A1">
					<p><span class="ar">إِبْسَالٌ</span> <span class="add">[inf. n. of <span class="ar">ابسل</span>]</span> <em>i. q.</em> <span class="ar">بَسْلٌ</span> as explained in the first sentence of this art.; i. e., The act of <em>preventing, hindering, withholding, debarring,</em> <span class="auth">(Bḍ in vi. 69,)</span> <em>forbidding,</em> or <em>prohibiting.</em> <span class="auth">(Ṣ, Ḳ, and Bḍ ubi suprà.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsl_4_B1">
					<p><span class="ar">ابسلهُ</span> <span class="auth">(inf. n. as above, TA)</span> <em>He pledged, </em> or <em>gave in pledge, him,</em> or <em>it,</em> <span class="auth">(M, Mṣb, Ḳ,)</span> <span class="ar">لِكَذَا</span> <span class="add">[and <span class="ar">بِكَذَا</span>, as will be shown below, both meaning <em>for such a thing</em>]</span>: and <em>he gave in exchange,</em> or <em>as an equivalent, him,</em> or <em>it,</em> <span class="ar">لِكَذَا</span> <span class="add">[and app. <span class="ar">بِكَذَا</span> also, as above, <em>for such a thing</em>]</span>; syn. <span class="ar">عَرَّضَهُ</span>: <span class="auth">(M, Ḳ:)</span> and <em>he gave him up, delivered him, delivered him over,</em> or <em>consigned him, to destruction,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>to punishment.</em> <span class="auth">(Az, TA.)</span> 'Owf Ibn-El-Ahwas says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإِبْسَالِى بَنِىَّ بِغَيْرِجُرْمٍ</span> *</div> 
						<div class="star">* <span class="ar long">بَعَوْنَاهُ وَلَا بِدَمٍ مُرَاقِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And my giving in pledge,</em> or <em>as an equivalent,</em> or <em>giving up to destruction, my sons, not for a crime that we have committed, nor for blood that has been shed</em> by us]</span>: <span class="auth">(Ṣ, M, TA:)</span> for he had given his sons in pledge for others, seeking peace, or reconciliation. <span class="auth">(Ṣ, TA.)</span> <span class="ar long">أَنْ تُبْسَلَ بِمَا كَسَبَتْ</span>, in the Ḳur <span class="add">[vi. 69]</span>, means <em>Lest a soul should be given up,</em> or <em>delivered,</em>, &amp;c., <span class="auth">(AO, Ṣ, Bḍ, Jel, TA.)</span> <em>to destruction,</em> <span class="auth">(Bḍ, Jel, TA,)</span> or <em>to punishment,</em> <span class="auth">(Az, TA,)</span> <em>for that which it hath done,</em> <span class="auth">(Az, Bḍ, Jel, TA,)</span> of evil: <span class="auth">(Bḍ:)</span> or <em>be given in pledge.</em> <span class="auth">(Bḍ, TA.)</span> And <span class="ar long">أُولٰئِكَ الَّذِينَ أُبْسِلُوا بِمَا كَسَبُوا</span>, in the same <span class="add">[ubi suprà]</span>, means, in like manner, <em>Those who are given up,</em> or <em>delivered,</em>, &amp;c., (<em>to punishment,</em> Bḍ) <em>for their sins:</em> <span class="auth">(El-Ḥasan, Bḍ,* TA:)</span> or <em>who are given in pledge:</em> <span class="auth">(Mṣb, TA:)</span> or <em>are destroyed:</em> or, as Mujáhid says, <em>are disgraced,</em> or <em>put to shame, by the exposure of their sins:</em> or, as Ḳatádeh says, <em>are imprisoned.</em> <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0206"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bsl_4_B2">
					<p><span class="ar long">ابسلهُ لِعَمَلِهِ</span> and <span class="ar">بِعَمَلِهِ</span> <em>He left him to his work, not interfering with him therein.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bsl_4_B3">
					<p><span class="ar long">ابسل نَفْسَهُ لِلْمَوْتِ</span>, <span class="auth">(M, Ḳ,)</span> as also<span class="arrow"><span class="ar">استبسل↓</span></span> <span class="add">[alone]</span>, <span class="auth">(M, Ḳ, and Ḥam p. 291)</span>, and<span class="arrow"><span class="ar">تبسّل↓</span></span>, and<span class="arrow"><span class="ar">بسل↓</span></span>, <span class="add">[which last may be either <span class="ar">بَسَلَ</span> or <span class="ar">بَسُلَ</span>, or perhaps it is a mistranscription for <span class="ar">أَبْسَلَ</span>,]</span> <span class="auth">(Ḥam ibid.,)</span> <em>He disposed and subjected his mind,</em> or <em>himself, to death,</em> <span class="auth">(M, Ḳ, Ḥam,)</span> <em>and felt certain,</em> or <em>sure, of it:</em> <span class="auth">(Ḥam, TA:)</span> and in like manner, <span class="ar">لِلضَّرْبِ</span> <span class="add">[<em>to beating,</em> i. e., <em>to being beaten</em>]</span>: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">ابتسل↓ لِلْمَوْتِ</span></span> <em>He submitted himself to death:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">استبسل↓</span></span> <em>He threw himself into war,</em> or <em>battle,</em> or <em>fight, desiring to slay or be slain,</em> <span class="auth">(Ṣ Ḳ,)</span> <em>inevitably.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bsl_4_C1">
					<p><span class="ar long">مَا أَبْسَلَهُ</span> <em>How courageous,</em> or <em>stronghearted, is he, on the occasion of war,</em> or <em>fight!</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبسّل</span></h3>
				<div class="sense" id="bsl_5_A1">
					<p><span class="ar">تبسّل</span> <em>He affected courage,</em> or <em>strength of heart, on the occasion of war,</em> or <em>fight; emboldened himself;</em> or <em>became like a lion in boldness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsl_5_A2">
					<p><a href="#bsl_4">See 4</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bsl_5_B1">
					<p><a href="#bsl_1">See also 1</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتسل</span></h3>
				<div class="sense" id="bsl_8_A1">
					<p><span class="ar long">ابتسل لِلْمَوْتِ</span>: <a href="#bsl_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبسل</span></h3>
				<div class="sense" id="bsl_10_A1">
					<p><a href="#bsl_4">see 4</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basolN">
				<h3 class="entry"><span class="ar">بَسْلٌ</span></h3>
				<div class="sense" id="basolN_A1">
					<p><span class="ar">بَسْلٌ</span> <span class="add">[an inf. n. (<a href="#bsl_1">see 1</a>) used as an epithet;]</span> <em>Forbidden; prohibited; unlawful:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> and <em>allowed; permitted; lawful:</em> <span class="auth">(AA, IAạr, M, Ḳ:)</span> thus having two contr. significations: <span class="auth">(AA, Ḳ:)</span> used alike as sing. and pl. and masc. and fem. <span class="add">[because originally an inf. n.]</span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">هٰذَا بَسْلٌ عَلَيْكَ</span> <em>This is forbidden, prohibited,</em> or <em>unlawful, to thee.</em> <span class="auth">(Bḍ in vi. 69.)</span> And <span class="ar long">دَمِى لَكُمْ بَسْلٌ</span> <em>My blood is,</em> or <em>shall be, allowed, permitted,</em> or <em>lawful, to you.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَسْلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="basolN_B1">
					<p><a href="#baAsilN">See also <span class="ar">بَاسِلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="basilN">
				<h3 class="entry"><span class="ar">بَسِلٌ</span></h3>
				<div class="sense" id="basilN_A1">
					<p><span class="ar">بَسِلٌ</span>: <a href="#baAsilN">see <span class="ar">بَاسِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bisilBae">
				<h3 class="entry"><span class="ar">بِسِلَّى</span></h3>
				<div class="sense" id="bisilBae_A1">
					<p><span class="ar">بِسِلَّى</span> <span class="add">[more commonly written in the present day <span class="ar">بِسِلَّة</span>]</span> <em>A certain kind of grain like the lupine</em> (<span class="ar">تُرْمُس</span>), <em>or less than this;</em> <span class="add">[the <em>pea termed</em> by Linnæus <em>pisum arvense:</em>]</span> a word of the dial. of Egypt. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="basuwlN">
				<h3 class="entry"><span class="ar">بَسُولٌ</span></h3>
				<div class="sense" id="basuwlN_A1">
					<p><span class="ar">بَسُولٌ</span>: <a href="#baAsilN">see <span class="ar">بَاسِلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="basiylN">
				<h3 class="entry"><span class="ar">بَسِيلٌ</span></h3>
				<div class="sense" id="basiylN_A1">
					<p><span class="ar">بَسِيلٌ</span>: <a href="#baAsilN">see <span class="ar">بَاسِلٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basaAlapN">
				<h3 class="entry"><span class="ar">بَسَالَةٌ</span></h3>
				<div class="sense" id="basaAlapN_A1">
					<p><span class="ar">بَسَالَةٌ</span> <a href="#bsl_1">inf. n. of <span class="ar">بَسُلَ</span>, q. v.</a> <span class="auth">(Ṣ, M, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَسَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="basaAlapN_A2">
					<p>Also <span class="add">[<em>i. q.</em> <span class="ar">بُسُولٌ</span>, <a href="#bsl_1">inf. n. of <span class="ar">بَسَلَ</span>, q. v.</a>; meaning]</span> <em>A frowning, contracting the face,</em> or <em>looking sternly</em> or <em>austerely</em> or <em>morosely;</em> or <em>doing so with grinning,</em> or <em>displaying the teeth;</em> or <em>contracting the part between the eyes; by reason of courage,</em> or <em>of anger.</em> <span class="auth">(Ḥam p. 14.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَسَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="basaAlapN_A3">
					<p>And <em>dislike, disapprobation, displeasure,</em> or <em>hatred.</em> <span class="auth">(Ḥam ibid.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAsilN">
				<h3 class="entry"><span class="ar">بَاسِلٌ</span></h3>
				<div class="sense" id="baAsilN_A1">
					<p><span class="ar">بَاسِلٌ</span> <em>Courageous,</em> or <em>strong-hearted, on the occasion of war,</em> or <em>fight;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> because he who is so defends himself from his antagonist; <span class="auth">(Ḥam p. 13, and Bḍ in vi. 69;)</span> as also<span class="arrow"><span class="ar">بَسِيلٌ↓</span></span> <span class="auth">(Mṣb)</span> and<span class="arrow"><span class="ar">بَسُولٌ↓</span></span>: <span class="auth">(Ḥam ubi suprà:)</span> pl. of the first <span class="ar">بُسْلٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بُسَلَآءُ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَاسِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAsilN_A2">
					<p><em>Frowning, contracting the face,</em> or <em>looking sternly</em> or <em>austerely</em> or <em>morosely;</em> or <em>doing so with grinning,</em> or <em>displaying the teeth;</em> or <em>contracting the part between the eyes; by reason of courage,</em> or <em>of anger;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَسْلٌ↓</span></span>, <span class="auth">(M, TA,)</span> in the Ḳ <span class="arrow"><span class="ar">بَسِلٌ↓</span></span>, but this is incorrect, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بَسِيلٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> and <span class="ar long">بَاسِرٌ بَاسِلٌ</span> <em>frowning,</em>, &amp;c., <em>much,</em> or <em>vehemently;</em> applied to the face: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">بَسْلٌ↓</span></span> <span class="auth">(IAạr, Ḳ)</span> and<span class="arrow"><span class="ar">بَسِيلٌ↓</span></span> <span class="auth">(IAạr, Ṣ, Ḳ)</span> <em>displeasing,</em> or <em>odious,</em> <span class="auth">(IAạr, Ṣ, Ḳ,)</span> <em>in face,</em> <span class="auth">(IAạr, Ṣ,)</span> or <em>aspect.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَاسِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAsilN_A3">
					<p>The <em>lion;</em> <span class="auth">(M, Ḳ;)</span> because of his displeasing, or odious, aspect; <span class="auth">(M;)</span> or because his prey does not escape from him; <span class="auth">(Bḍ in vi. 69;)</span> as also<span class="arrow"><span class="ar">بَسُولٌ↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">مُتَبَسِّلٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَاسِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAsilN_A4">
					<p>Applied to a saying, <em>Hard,</em> or <em>severe, and displeasing,</em> or <em>odious.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَاسِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAsilN_A5">
					<p>Applied to milk, and to <span class="ar">نَبِيذ</span> <span class="add">[or must, &amp;c.]</span> ‡ <em>Strong:</em> <span class="auth">(Ḳ:)</span> or, applied to the former, <em>displeasing,</em> or <em>odious, in taste, and sour;</em> and applied to the latter, <em>strong and sour.</em> <span class="auth">(M, TA.)</span> And, applied to vinegar, † <em>Altered,</em> or <em>corrupted, in flavour, from having been left long;</em> as also<span class="arrow"><span class="ar">مُبَسَّلٌ↓</span></span> <span class="auth">(Az in art. <span class="ar">حذق</span>, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسل</span> - Entry: <span class="ar">بَاسِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAsilN_A6">
					<p>Applied to a day, † <em>Distressing, afflictive,</em> or <em>calamitous.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubasBalN">
				<h3 class="entry"><span class="ar">مُبَسَّلٌ</span></h3>
				<div class="sense" id="mubasBalN_A1">
					<p><span class="ar">مُبَسَّلٌ</span>: <a href="#baAsilN">see <span class="ar">بَاسِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutabisBilN">
				<h3 class="entry"><span class="ar">مُتَبِسِّلٌ</span></h3>
				<div class="sense" id="mutabisBilN_A1">
					<p><span class="ar">مُتَبِسِّلٌ</span>: <a href="#baAsilN">see <span class="ar">بَاسِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotabosilN">
				<h3 class="entry"><span class="ar">مُسْتَبْسِلٌ</span></h3>
				<div class="sense" id="musotabosilN_A1">
					<p><span class="ar">مُسْتَبْسِلٌ</span> <em>Disposing and subjecting one's mind,</em> or <em>oneself, to death,</em> or <em>to being beaten:</em> <span class="auth">(Ṣ: <span class="add">[see also its verb:]</span>)</span> or, as some say, <em>falling into a displeasing, an odious,</em> or <em>an evil, case, from which there is no escape.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0205.pdf" target="pdf">
							<span>Lanes Lexicon Page 205</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0206.pdf" target="pdf">
							<span>Lanes Lexicon Page 206</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
