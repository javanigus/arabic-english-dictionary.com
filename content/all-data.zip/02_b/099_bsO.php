<article class="root" id="Root_bsO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/098_bs">بس</a></span>
				<span class="ar">بسأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/100_bsc">بسذ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسأ</span></h3>
				<div class="sense" id="bsO_1_A1">
					<p><span class="ar long">بَسَأَ بِهِ</span>, and <span class="ar">بَسِئَ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْسَأُ</span>}</span></add>; <span class="auth">(M, Ḳ;)</span> inf. n. <span class="ar">بَسْءٌ</span> and <span class="ar">بُسُوْءٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بَسَآءٌ</span>, <span class="auth">(M, Ḳ,)</span> all of the former verb; <span class="auth">(M;)</span> and <span class="ar">بَسَأْ</span>, <span class="auth">(M, Ḳ,)</span> of the latter; <span class="auth">(M;)</span> <em>He was,</em> or <em>became, sociable, friendly,</em> or <em>familiar, with him;</em> <span class="auth">(namely, a man, Ṣ, TA;)</span> or <em>cheered,</em> or <em>gladdened, by his company</em> or <em>converse,</em> or <em>by his presence.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsO_1_A2">
					<p><span class="ar long">بَسَأَ بِالأَمْرِ</span>, inf. n. <span class="ar">بَسْءٌ</span> and <span class="ar">بُسُوْءٌ</span>, <em>He was,</em> or <em>became, accustomed,</em> or <em>habituated, to the affair,</em> or <em>case.</em> <span class="auth">(M,* Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsO_1_A3">
					<p><span class="add">[And hence,]</span> <span class="ar long">بَسَأَ بِهِ</span> <em>He despised,</em> or <em>made light of, him,</em> or <em>it.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابسأ</span></h3>
				<div class="sense" id="bsO_4_A1">
					<p><span class="ar">أَبْسَأْتُهُ</span> <em>I made him sociable, friendly,</em> or <em>familiar;</em> or <em>cheered him,</em> or <em>gladdened him, by my company</em> or <em>converse,</em> or <em>by my presence.</em> <span class="auth">(Ṣ, Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="basuwoCN">
				<span class="pb" id="Page_0202"></span>
				<h3 class="entry"><span class="ar">بَسُوْءٌ</span></h3>
				<div class="sense" id="basuwoCN_A1">
					<p><span class="ar">بَسُوْءٌ</span> A she-camel <em>that offers no opposition to her milker,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>being of a good disposition, and accustomed to him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bst">
				<h3 class="entry"><span class="ar">بست</span></h3>
				<div class="sense" id="bst_A1">
					<p><span class="ar">بست</span> accord. to some: <span class="ar">بستان</span> accord. to others.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busotaAnN">
				<h3 class="entry"><span class="ar">بُسْتَانٌ</span></h3>
				<div class="sense" id="busotaAnN_A1">
					<p><span class="ar">بُسْتَانٌ</span> <span class="add">[accord. to its etymology <span class="auth">(which will be explained below)</span> and to general modern usage, <em>A garden of sweet-scented flowers and trees:</em> but accord. to the Arabic Lexicons,]</span> <em>a</em> <span class="add">[<em>garden such as is termed</em>]</span> <span class="ar">جَنَّة</span>: <span class="auth">(Mgh, Mṣb:)</span> or <em>a</em> <span class="add">[<em>garden,</em> or <em>walled garden, such as is termed</em>]</span> <span class="ar">حَدِيقَة</span>, <span class="auth">(M, Ḳ, TA,)</span> <em>of palm-trees;</em> as in a poem of El-Aạshà: <span class="auth">(TA:)</span> said by Fr to be an Arabic word; <span class="auth">(Mṣb, TA;)</span> but this is denied by IDrd: <span class="auth">(TA:)</span> and said by some to be <span class="ar">رُومِىّ</span> <span class="add">[or Greek]</span>: <span class="auth">(Mṣb:)</span> <span class="add">[but correctly]</span> it is an arabicized word, from <span class="add">[the Persian]</span> <span class="ar">بُوسْتَانٌ</span> <span class="add">[bóstán]</span>; <span class="auth">(Ḳ, <span class="add">[in which the <span class="ar">ن</span> is regarded as a radical letter,]</span> Shifá el-Ghaleel, MF,)</span> meaning “taking odour, or fragrance,” or, as some say, “a place where odour, or fragrance, collects, or is collected:” <span class="auth">(Shifá el-Ghaleel, MF:)</span> its composition from <span class="ar">بو</span> and <span class="ar">ستان</span> requires the former meaning to be assigned to it: <span class="auth">(TA:)</span> <span class="add">[or rather it signifies “a place of odour, or fragrance:”]</span> afterwards applied to <em>trees:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بَسَاتِينُ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بَسَاتُونَ</span>, <span class="auth">(Ḳ,)</span> like <span class="ar">شَيَاطِينُ</span> and <span class="ar">شَيَاطُونَ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="busotanobaAnN">
				<h3 class="entry"><span class="ar">بُسْتَنْبَانٌ</span></h3>
				<div class="sense" id="busotanobaAnN_A1">
					<p><span class="ar">بُسْتَنْبَانٌ</span> <span class="add">[an arabicized word from the Persian <span class="ar">بُسْتَانْبَانْ</span>, <em>i. q.</em><span class="arrow"><span class="ar">بُسْتَانِىٌّ↓</span></span>, which is the more common; <em>A gardener,</em> or]</span> <em>a keeper of a</em> <span class="ar">بُسْتَان</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="busotaAnieBN">
				<h3 class="entry"><span class="ar">بُسْتَانِىٌّ</span></h3>
				<div class="sense" id="busotaAnieBN_A1">
					<p><span class="ar">بُسْتَانِىٌّ</span>: <a href="#busotanobaAnN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0201.pdf" target="pdf">
							<span>Lanes Lexicon Page 201</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0202.pdf" target="pdf">
							<span>Lanes Lexicon Page 202</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
