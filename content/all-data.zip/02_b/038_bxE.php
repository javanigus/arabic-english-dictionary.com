<article class="root" id="Root_bxE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/037_bxS">بخص</a></span>
				<span class="ar">بخع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/039_bxq">بخق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخع</span></h3>
				<div class="sense" id="bxE_1_A1">
					<p><span class="ar long">بَخَعَ الذَّبِيحَةَ</span>, <span class="auth">(Z, in the Fáïk,)</span> or <span class="ar">الشَّاةَ</span>, <span class="auth">(Z, in the A,)</span> or <span class="ar">بِالشَّاةِ</span>, <span class="auth">(O, Ḳ,)</span> <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَعُ</span>}</span></add>, inf. n. <span class="ar">بَخْعٌ</span>,]</span> <em>He slaughtered the beast for slaughter,</em> or <em>the sheep</em> or <em>goat, with much,</em> or <em>extraordinary, effectiveness,</em> or <em>energy,</em> <span class="auth">(Z, Ḳ,)</span> <em>so that he reached the back of the neck,</em> <span class="auth">(Z, in the A,)</span> or <em>so that he reached the</em> <span class="ar">بِخَاع</span>, <span class="auth">(Ḳ, TA, <span class="add">[in the CK <span class="ar">نُخَاع</span>,]</span>)</span> <em>cutting the bone of the neck.</em> <span class="auth">(TA.)</span> This is the primary signification; and hence the verb is used to denote the doing anything to a great extent, in a great degree, egregiously, or with much or extraordinary effectiveness or energy or the like. <span class="auth">(Z, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bxE_1_A2">
					<p><span class="add">[Hence you say,]</span> <span class="ar long">بَخَعَ نَفْسَهُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَعُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَخْعٌ</span> <span class="auth">(Ṣ, Mṣb)</span> and <span class="ar">بُخُوعٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He killed himself with grief,</em> <span class="auth">(Ṣ, Mṣb, Ḳ, TA,)</span> or <em>with wrath,</em> or <em>rage.</em> <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bxE_1_A3">
					<p>And <span class="ar long">بَالَغُوا فِى بَخْعِ أَنْفُسِهِمْ</span> ‡ <em>They exceeded the ordinary bounds in subduing and abasing themselves by obedience.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bxE_1_A4">
					<p>And <span class="ar long">بَخَعْتُ لَكَ نَفْسِى وَنُصْحِى</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَعُ</span>}</span></add>, inf. n. <span class="ar">بُخُوعٌ</span>, ‡ <em>I exerted for thee myself and my good advice,</em> or <em>counsel, laboriously, earnestly,</em> or <em>with energy:</em> <span class="auth">(TA:)</span> and <span class="ar long">بَخَعَ لَهُ نُصْحَهُ</span>, <span class="auth">(Ḳ, TA,)</span> inf. n. <span class="ar">بَخْعٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He acted sincerely towards him, and took extraordinary pains, in giving him good advice,</em> or <em>counsel.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bxE_1_A5">
					<p>And <span class="ar long">بَخَعَ لَهُ بِالحَقِّ</span>, <span class="auth">(Ṣ,* Ḳ,* TA,)</span> inf. n. <span class="ar">بُخُوعٌ</span>; and <span class="ar">بَخِعَ</span>, inf. n. <span class="ar">بُخُوعٌ</span> and <span class="ar">بَخَاعَةٌ</span>; ‡ <em>He confessed,</em> or <em>acknowledged, to him the right,</em> or <em>due, and humbled himself to him:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> or you say, <span class="ar long">بَخَعَنِى بِالحَقِّ</span>, inf. n. <span class="ar">بُخُوعٌ</span>, meaning † <em>he submitted himself to me, and gave the right,</em> or <em>due, freely:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">بَخَعْتُ لَهُ</span> † <em>I became submissive and obedient, and made confession,</em> or <em>acknowledgment, to him:</em> or, accord. to the A, <span class="ar">بَخَعَ</span> signifies ‡ <em>he made confession,</em> or <em>acknowledgment, with the utmost submissiveness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bxE_1_A6">
					<p>And <span class="ar long">بَخَعَ فُلَانًا خَبَرَهُ</span> ‡ <em>He related his information,</em> or <em>news, truly to such a one.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bxE_1_A7">
					<p>Also, <span class="ar long">بَخَعَ الرَّكِيَّةَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَعُ</span>}</span></add>, inf. n. <span class="ar">بَخْعٌ</span>, † <em>He dug the well until its water appeared.</em> <span class="auth">(Ks, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bxE_1_A8">
					<p>And hence the saying of ʼÁïsheh, speaking of ʼOmar, <span class="ar long">بَخَعَ الأَرْضَ فَقَآءَتْ أُكْلَهَا</span>, meaning † <em>He subdued and abased</em> the people of <em>the earth,</em> <span class="add">[<em>so that it disclosed</em>]</span> and he drew forth <em>the treasures that it contained,</em> and <em>the possessions of the kings.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَخَعَ الأَرْضَ بِالزِّرَاعَةِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَخْعٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He exhausted the strength of the land by sowing, tilling it continuously, and not giving it rest for a year.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbixaAEu">
				<span class="pb" id="Page_0160"></span>
				<h3 class="entry"><span class="ar">البِخَاعُ</span></h3>
				<div class="sense" id="AlbixaAEu_A1">
					<p><span class="ar">البِخَاعُ</span> <em>A certain vein,</em> or <em>nerve,</em> (<span class="ar">عِرْق</span>,) <em>in the</em> <span class="ar">صُلْب</span> <span class="add">[or <em>back-bone</em>]</span>, <span class="auth">(Z in the Fáïk and Ksh, and Ḳ,)</span> <em>lying within the</em> <span class="ar">قَفَا</span> <span class="add">[or <em>back of the neck</em>]</span>; <span class="auth">(Z in the Ksh, and TA;)</span> Bḍ says, <em>lying within the</em> <span class="ar">فَقَار</span> <span class="add">[or <em>vertebræ</em>]</span>; but it is said that this is a mistranscription, and that the right reading is the <span class="ar">قفا</span>, as in the Ksh; and it is said in the Ḳ to be <em>running into the bone</em> <span class="add">[or, as in the CK, <em>bones,</em>]</span> <em>of the neck;</em> but this is a mistake: <span class="auth">(TA:)</span> accord. to an assertion of Z, <span class="auth">(Ḳ,)</span> in his Fáïk and Ksh, <span class="auth">(TA,)</span> it is different from the <span class="ar">نُخَاع</span>, with <span class="ar">ن</span>, which is the white cord in the interior of the bone of the neck, extending to the back-bone: but IA th says, I have searched long in lexicons, and in books of medicine and anatomy, but have not found <span class="ar">البخاع</span>, with <span class="ar">ب</span>, mentioned in any of them. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAxiEN">
				<h3 class="entry"><span class="ar">بَاخِعٌ</span></h3>
				<div class="sense" id="baAxiEN_A1">
					<p><span class="ar long">فَلَعَلَّكَ بَاخِعٌ نَفْسَكَ</span>, in the Ḳur <span class="add">[xviii. 5]</span>, <span class="auth">(Ṣ,)</span> means ‡ <em>And may-be thou wilt hill thyself</em> <span class="auth">(Ṣ, Ḳ)</span> <em>with grief,</em> <span class="auth">(Ṣ,)</span> being beyond measure eager for their becoming Muslims. <span class="auth">(Ḳ, TA.)</span> These words imply an incitement to abstain from regret. <span class="auth">(B.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboxaEu">
				<h3 class="entry"><span class="ar">أَبْخَعُ</span></h3>
				<div class="sense" id="OaboxaEu_A1">
					<p><span class="ar">أَبْخَعُ</span> <span class="add">[<em>More,</em> and <em>most, effectual to kill,</em> and <em>destroy</em>]</span>. <span class="auth">(Ḳ voce <span class="ar">أَخْنَعُ</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخع</span> - Entry: <span class="ar">أَبْخَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboxaEu_A2">
					<p><span class="ar long">هُمْ أَبْخَعُ طَاعَةً</span> ‡ <em>They are more sincere and more energetic in obedience</em> than others; as though they exceeded the ordinary bounds in subduing and abasing themselves by obedience. <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0159.pdf" target="pdf">
							<span>Lanes Lexicon Page 159</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0160.pdf" target="pdf">
							<span>Lanes Lexicon Page 160</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
