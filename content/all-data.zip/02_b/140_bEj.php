<article class="root" id="Root_bEj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/139_bEvr">بعثر</a></span>
				<span class="ar">بعج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/141_bEd">بعد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEj_1">
				<h3 class="entry">1. ⇒ <span class="ar">بعج</span></h3>
				<div class="sense" id="bEj_1_A1">
					<p><span class="ar">بَعَجَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَجُ</span>}</span></add>, <span class="auth">(T, Ṣ, A, Ḳ,)</span> inf. n. <span class="ar">بَعْجٌ</span>, <span class="auth">(T, Ṣ,)</span> <em>He slit, ripped,</em> or <em>rent, it,</em> <span class="auth">(T, Ṣ, A, Ḳ,)</span> namely, a belly, with a knife, <span class="auth">(T, Ṣ, A, TA,)</span> <em>and moved about the knife in it,</em> <span class="auth">(T,)</span> <em>so that what was in it became displaced and apparent, hanging down;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بعّجهُ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEj_1_A2">
					<p><span class="ar long">بَعَجَتْ بَطْيَهَا لِزَوْجِهَا</span> † <span class="add">[<em>She brought forth many children to her husband; i. q.</em> <span class="ar">نَثَرَتْ</span>: <a href="#baEiyjN">see <span class="ar">بَعِيجٌ</span></a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEj_1_A3">
					<p><span class="ar long">بَعَجْتُ لَهُ بَطْنِى</span> ‡ <em>I disclosed,</em> or <em>revealed, to him my secret</em> <span class="add">[or <em>my whole mind</em>]</span>. <span class="auth">(A.)</span> Esh-Shemmákh uses the phrase <span class="ar long">بَعَجْتُ إِلَيْهِ البَطْنَ</span> <span class="add">[meaning the same]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEj_1_A4">
					<p><span class="ar long">بَعَجَ بَطْيَهُ لَكَ</span> signifies <span class="add">[also]</span> ‡ <em>He took extraordinary pains,</em> or <em>exceeded the usual bounds, in giving thee sincere, honest,</em> or <em>faithful, advice,</em> or <em>counsel.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bEj_1_A5">
					<p><span class="ar long">بَعَجَ أَرْضَهُ</span> ‡ <em>He clave,</em> or <em>furrowed,</em> or <em>trenched, his land.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bEj_1_A6">
					<p><span class="ar long">بَعَجَ الأَرْضَ آبَارًا</span> ‡ <em>He dug many wells in the ground.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bEj_1_A7">
					<p><span class="ar long">بَعَجَ الأَرْضَ وَبَجَعَهَا</span> ‡ <em>He clave the earth,</em> or <em>land, and subdued it:</em> said of ʼOmar, in a trad., alluding to his conquests. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bEj_1_A8">
					<p><span class="ar long">بَعَجَتْ لَهُ الدَّنْيَا مِعَاهَا</span> ‡ <em>The world disclosed to him what it contained, of treasures, and other possessions, and spoil:</em> also said of ʼOmar, in another trad. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bEj_1_A9">
					<p><span class="ar long">بَعَجَتْ هٰذِهِ الأَرْضَ عَذَاةٌ طَيِّبَةُ الأَرْضِ</span> † <em>A tract of good land intervened in the middle of this land</em> <span class="add">[<em>as though cleaving it</em>]</span>. <span class="auth">(L.)</span></p>
				</div>
				<span class="pb" id="Page_0224"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bEj_1_A10">
					<p><span class="ar long">بَعَجَهُ الحُبُّ</span> ‡ <em>Love threw him into mourning,</em> or <em>sorrow; brought grief to him:</em> <span class="auth">(Ḳ, TA:)</span> <span class="add">[or <em>occasioned him intense grief:</em> for]</span> you say, <span class="ar long">بَعَجَهُ حُبُّ فُلَانٍ</span> meaning ‡ <em>the love of such a one occasioned him intense grief, and he mourned for him:</em> Az says that <span class="ar long">لَعَجَهُ الحُبُّ</span> is more correct than <span class="ar">بَعَجَهُ</span>: but he afterwards mentions <span class="ar long">بَعَجَهُ الأَمْرُ</span> as meaning † <em>the affair caused him to mourn,</em> or <em>sorrow.</em> <span class="auth">(L, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEj_2">
				<h3 class="entry">2. ⇒ <span class="ar">بعّج</span></h3>
				<div class="sense" id="bEj_2_A1">
					<p><a href="#bEj_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEj_2_A2">
					<p><span class="ar long">بعّج المَطَرُ الأَرْضَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">فِى الأَرْضِ</span>, <span class="auth">(L, TA,)</span> inf. n. <span class="ar">تَبْعِيجٌ</span>, † <em>The rain dug up the stones of the earth by its vehemence.</em> <span class="auth">(Ṣ, L, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEj_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبعّج</span></h3>
				<div class="sense" id="bEj_5_A1">
					<p><span class="ar long">تبعّج السَّحّابُ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> and<span class="arrow"><span class="ar">انبعج↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="ar">بِالمَطَرِ</span>, <span class="auth">(TA,)</span> ‡ <em>The clouds clave asunder, with,</em> or <em>by reason of, rain,</em> <span class="auth">(Ṣ, A, Ḳ, TA,)</span> and <em>vehement rain.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEj_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبعج</span></h3>
				<div class="sense" id="bEj_7_A1">
					<p><span class="ar">انبعج</span> <em>It</em> <span class="add">[a belly]</span> <em>became slit, ripped,</em> or <em>rent.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEj_7_A2">
					<p><em>He had his belly slit,</em> or <em>ripped,</em> or <em>rent,</em> with a knife, <em>so that what was in it became displaced and apparent, hanging down.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEj_7_A3">
					<p><a href="#bEj_5">See also 5</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEj_7_A4">
					<p>† <em>It</em> <span class="auth">(anything, as, for instance, a valley,)</span> <em>became wide,</em> or <em>ample.</em> <span class="auth">(TA.)</span> <span class="ar long">اِنْبَعَجَتْ دُفْعَةٌ مِنَ المَطَرِ</span> ‡ <span class="add">[<em>A fall of rain burst forth</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">انبعج السَّيْلُ</span> ‡ <span class="add">[<em>The torrent burst forth</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEijN">
				<h3 class="entry"><span class="ar">بَعِجٌ</span></h3>
				<div class="sense" id="baEijN_A1">
					<p><span class="ar">بَعِجٌ</span>: <a href="#baEiyjN">see <span class="ar">بَعِيجٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: <span class="ar">بَعِجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEijN_A2">
					<p>Also † A man <em>who walks weakly, as though his belly were slit,</em> or <em>ripped,</em> or <em>rent.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEiyjN">
				<h3 class="entry"><span class="ar">بَعِيجٌ</span></h3>
				<div class="sense" id="baEiyjN_A1">
					<p><span class="ar">بَعِيجٌ</span> A belly <span class="auth">(Ṣ)</span> <em>slit, ripped,</em> or <em>rent,</em> <span class="auth">(Ṣ, Ḳ,)</span> with a knife, <span class="auth">(Ṣ,)</span> <em>so that what was in it is displaced and apparent, hanging down;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَعِجٌ↓</span></span>, thought to be after manner of a rel. n.; <span class="auth">(L, TA;)</span> and<span class="arrow"><span class="ar">مَبْعُوجٌ↓</span></span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: <span class="ar">بَعِيجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEiyjN_A2">
					<p>Hence, <span class="ar long">بَطْنِى لِلْكِرَامِ بَعِيجٌ</span>, an expression used by Aboo-Dhu-eyb, meaning ‡ <em>My sincere, honest,</em> or <em>faithful, advice,</em> or <em>counsel, is liberally,</em> or <em>freely, given to the generous.</em> <span class="auth">(TA. <span class="add">[In a reading given in the Ṣ, <span class="ar">بالكرام</span> is substituted for <span class="ar">للكرام</span>]</span>)</span> <span class="add">[Or it may mean ‡ <em>My secret is disclosed,</em> or <em>revealed, to the generous:</em> or <em>my whole mind.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: <span class="ar">بَعِيجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baEiyjN_A3">
					<p><span class="ar">بَعِيجٌ</span> is also applied to a man, and, without <span class="ar">ة</span>, to a woman, as signifying <em>Having the belly slit, ripped,</em> or <em>rent,</em> with a knife, <em>so that what was in it is displaced and apparent, hanging down:</em> pl., masc. and fem., <span class="ar">بَعْجَى</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: <span class="ar">بَعِيجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baEiyjN_A4">
					<p>And <span class="add">[hence,]</span> † A woman <em>who has brought forth many children</em> (<span class="ar long">بَعَجَتْ بَطْنَهَا</span>, and <span class="ar">نَثَرَتْ</span>, <span class="add">[<a href="#bEj_1">see 1</a>, <a href="index.php?data=25_n/041_nvr">and see art. <span class="ar">نثر</span></a>,]</span>) <em>to her husband.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAEijapN">
				<h3 class="entry"><span class="ar">بَاعِجَةٌ</span></h3>
				<div class="sense" id="baAEijapN_A1">
					<p><span class="ar">بَاعِجَةٌ</span> † The <em>wide part of a valley;</em> <span class="auth">(Ṣ, Ḳ;)</span> the <em>place where it becomes wide.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعج</span> - Entry: <span class="ar">بَاعِجَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAEijapN_A2">
					<p>Also † <em>Plain,</em> or <em>soft, land, that produces</em> <span class="add">[<em>the plant called</em>]</span> <span class="ar">نَصِىّ</span>: or the <em>extremity of a tract of sand,</em> and <em>of plain,</em> or <em>soft, land,</em> <span class="add">[<em>extending</em>]</span> <em>to what is termed</em> <span class="ar">قُفّ</span> <span class="add">[or <em>high,</em> or <em>high and rugged, ground</em>]</span>: and <span class="add">[the pl.]</span> <span class="ar">بَوَائِجُ</span> signifies <em>places, in sand, which are of little depth</em> <span class="add">[<em>of sand</em>]</span>, <em>and which, if</em> <span class="ar">نَصِىّ</span> <em>grow therein, are of least depth, and best.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboEuwjN">
				<h3 class="entry"><span class="ar">مَبْعُوجٌ</span></h3>
				<div class="sense" id="maboEuwjN_A1">
					<p><span class="ar">مَبْعُوجٌ</span>: <a href="#baEiyjN">see <span class="ar">بَعِيجٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0223.pdf" target="pdf">
							<span>Lanes Lexicon Page 223</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0224.pdf" target="pdf">
							<span>Lanes Lexicon Page 224</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
