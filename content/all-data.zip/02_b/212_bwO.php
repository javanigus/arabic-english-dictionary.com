<article class="root" id="Root_bwO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/211_bwA">بوا</a></span>
				<span class="ar">بوأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/213_bwb">بوب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوأ</span></h3>
				<div class="sense" id="bwO_1_A1">
					<p><span class="ar long">بَآءَ إِلَيْهِ</span>, <span class="auth">(M, Mgh,* Mṣb,* Ḳ,)</span> aor. <span class="ar">يَبُوْءُ</span>, <span class="auth">(M, Mgh, Mṣb,)</span> inf. n. <span class="ar">بَوْءٌ</span>, <span class="auth">(M, Mgh,)</span> <em>He returned, went back,</em> or <em>came back,</em> <span class="auth">(M, Mgh, Mṣb, Ḳ,)</span> <em>to it,</em> <span class="auth">(M, Ḳ,*)</span> namely, a thing: <span class="auth">(M:)</span> or <em>he withdrew</em> <span class="add">[from a person or persons, or a place,]</span> <em>to it,</em> or <em>him;</em> or, perhaps, <em>he made himself solely and peculiarly a companion,</em> or <em>an associate, to him,</em> or <em>it;</em> syn. <span class="ar">اِنْقَطَعَ</span> <span class="add">[q. v.]</span>: <span class="auth">(Ḳ:)</span> but in some copies of the Ḳ, the latter explanation is connected with the former by <span class="ar">وَ</span> <span class="add">[and]</span> instead of <span class="ar">أَو</span>. <span class="auth">(TA.)</span> <span class="ar long">وَبَاؤُوا بِغَضَبٍ مِنَ ٱللّٰهِ</span> <span class="add">[in the Ḳur ii. 58 and iii. 108]</span> means <em>And they returned with anger from God;</em> <span class="auth">(Akh, Ṣ, Bḍ in ii. 58, and Jel in the same and in iii. 108;)</span> i. e. the anger of God came upon them: <span class="auth">(Akh, Ṣ:)</span> or <em>they returned deserving anger from God:</em> <span class="auth">(Bḍ in iii. 108:)</span> or <em>they became deserving of anger from God:</em> from <span class="ar long">بَآءَ فُلَانٌ بِفُلَانٍ</span> <em>such a one was deserving of being,</em> or <em>fit to be, slain in retaliation for such a one,</em> <span class="auth">(Ksh and Bḍ in ii. 58,)</span> <em>because his equal:</em> <span class="auth">(Ksh ibid.:)</span> the primary signification of <span class="ar">بَوْءٌ</span> being <span class="add">[said to be]</span> that of <em>equalling,</em> or <em>being equal with.</em> <span class="auth">(Bḍ in ii. 58.)</span> <span class="add">[See a similar phrase, also from the Ḳur, below.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwO_1_A2">
					<p><span class="ar long">بُؤْتُ بِهِ إِلَيْهِ</span> <span class="add">[<em>I returned with it to him:</em> and hence,]</span> <em>I returned it, took it back,</em> or <em>brought it back, to him;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَبَأْتُهُ↓</span></span>, <span class="auth">(Th, M, Ḳ,)</span> and <span class="ar">بُؤْتُهُ</span>, <span class="auth">(Ks, M, Ḳ,)</span> but this last is rare. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwO_1_A3">
					<p><span class="ar long">بَآءَ بِإِثْمِهِ</span>, aor. and inf. n. as above, <span class="auth">(T, Ṣ,)</span> signifies, accord. to Akh, <em>He returned</em> <span class="add">[laden]</span> <em>with his sin:</em> <span class="auth">(Ṣ:)</span> or, accord. to Aṣ, <em>he acknowledged it,</em> or <em>confessed it:</em> <span class="auth">(T:)</span> or, accord. to others, <span class="auth">(TA,)</span> <span class="ar long">بَآءَ بِذَنْبِهِ</span>, <span class="auth">(T,* M, Mṣb, Ḳ,)</span> aor. as above, inf. n. <span class="ar">بَوْءٌ</span> and <span class="ar">بَوَآءٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>he bore,</em> or <em>took upon himself, the burden of his sin,</em> or <em>crime,</em> or <em>offence;</em> syn. <span class="ar">اِحْتَمَلَهُ</span>; <span class="auth">(Aboo-Is-ḥáḳ, T, M, Ḳ, TA;)</span> <em>and became</em> <span class="add">[<em>as though he were</em>]</span> <em>the abiding-place thereof:</em> <span class="auth">(TA:)</span> or <em>he became burdened,</em> or <em>laden, with it:</em> <span class="auth">(Mṣb:)</span> or <em>he became,</em> or <em>made himself, answerable, responsible,</em> or <em>accountable, for it, by an inseparable obligation;</em> syn. <span class="ar long">اِلْتَزَمَ بِهِ</span>; for the primary signification of <span class="ar">بَوَآءٌ</span> is <span class="add">[asserted to be]</span> <span class="ar">لُزُومٌ</span> <span class="add">[i. e. <em>adhesion,</em>, &amp;c.]</span>; and it is afterwards used in every case <span class="add">[so as to imply a meaning of this kind]</span> according to the exigency of that case; as is said in the Nh, and expressly stated by Z and Er-Rághib: <span class="auth">(TA:)</span> or <em>he acknowledged it,</em> or <em>confessed it.</em> <span class="auth">(M, Ḳ.)</span> <span class="ar long">إِنِّى أُرِيدُ أَنْ تَبُوْءَ بِإِثْمِى وَإِثْمِكَ</span>, in the Ḳur v. 35, means <em>Verily I desire that thou return</em> <span class="add">[laden]</span> <em>with the sin committed against me</em> in slaying me, <em>and thy sin</em> which thou hast committed previously: <span class="auth">(Jel:)</span> or <em>I desire that thou shouldst bear</em> (<span class="ar">تَحْمِلَ</span>) <em>my sin</em> if I were to extend my hand towards thee, <em>and thy sin</em> in extending thy hand towards me: or <em>the sin committed against me</em> in slaying me, <em>and thy sin</em> for which thine offering was not accepted: and each noun is in the place of a denotative of state; i. e., <span class="add">[it means]</span> <em>that thou return involved in the two sins; bearing them:</em> and perhaps the speaker may have meant, if that must inevitably take place, I desire that it may be thine act, not mine; so that the real meaning is, that it should not be his, not that it should be his brother's: or by the <span class="ar">إِثْمٌ</span> may be meant the <em>punishment</em> thereof; for the desire of the punishment of the disobedient is allowable: <span class="auth">(Bḍ:)</span> accord. to Th, the meaning is, if thou have determined upon slaying me, the sin will be in thee, not in me. <span class="auth">(M.)</span> <span class="pb" id="Page_0271"></span><span class="ar long">فَبَاؤُوا بِغَضَبٍ عَلَى غَضَبٍ</span> <span class="add">[in the Ḳur ii. 84]</span> is explained by Aboo-Is-ḥáḳ as meaning <em>So they bore the burden of anger upon anger;</em> syn. <span class="ar">اِحْتَمَلُوا</span>; this being said by him to be the proper signification of the verb: or, as some say, the meaning is, <span class="add">[<em>they bore the burden of</em>]</span> <em>sin for which they deserved the fire</em> <span class="add">[<em>of Hell</em>]</span> <em>following upon sin for which they deserved the same:</em> or <em>they returned</em> <span class="add">[laden <em>with anger upon anger</em>]</span>: <span class="auth">(T:)</span> or <em>they became deserving of anger upon anger.</em> <span class="auth">(Ksh.)</span> <span class="add">[See a similar phrase, also from the Ḳur, above.]</span> It is said in a form of prayer, <span class="ar long">أَبُوْءُ إِلَيْكَ بِنِعْمَتِكَ</span>, meaning <em>I acknowledge,</em> or <em>confess, to Thee thy favour</em> <span class="add">[towards me, as imposing an obligation upon me]</span>. <span class="auth">(Mgh.)</span> You say also, <span class="ar long">بَآءٌ بِحَقِّهِ</span>; <span class="auth">(Ṣ;)</span> and <span class="ar">بِدِّمِهِ</span>; <span class="auth">(M, Ḳ;)</span> <em>He acknowledged,</em> or <em>confessed,</em> <span class="add">[<em>himself to be answerable, responsible,</em> or <em>accountable, for</em>]</span> <em>his right, due,</em> or <em>just claim;</em> <span class="auth">(Ṣ;)</span> and so <span class="add">[<em>for</em>]</span> <em>his blood:</em> <span class="auth">(M, Ḳ:)</span> the verb expresses acknowledgment, or confession, always of something for which its agent is, as it were, indebted, or answerable; not the contrary. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwO_1_A4">
					<p><span class="ar long">بَآءَ بِكَفِّى</span>, in a poem of Sakhr-el-Gheí, means <em>It</em> <span class="add">[referring to a sword]</span> <em>became in my hand; my hand became to it a</em> <span class="ar">مَبَآءَة</span>, i. e. <span class="ar">مَأْوًى</span> <span class="add">[or <em>place of abode</em>]</span>; <em>it returned, and became in my hand:</em> or, accord. to Ibn-Ḥabeeb, <em>i. q.</em> <span class="ar">اِسْتَقَلَّ</span> <span class="add">[app. a mistranscription for <span class="ar">اِسْتَقَرَّ</span> <em>it rested,</em> or <em>remained;</em> the verb <span class="ar">بآء</span> in this phrase being from <span class="ar">بَوَآءٌ</span> signifying <span class="ar">لُزُومٌ</span>, explained above]</span>. <span class="auth">(Skr p. 16.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwO_1_B1">
					<p><span class="ar">بَآءٌ</span> also signifies <em>It</em> <span class="auth">(a thing, TA)</span> <em>suited, matched, tallied, corresponded,</em> or <em>agreed.</em> <span class="auth">(Ḳ.)</span> <span class="add">[Hence,]</span> <span class="ar long">بَآءَ فُلَانٌ بِفُلَانٍ</span> <span class="auth">(inf. n. <span class="ar">بَوَآءٌ</span>, TA)</span> <em>Such a one was the like,</em> or <em>equal, of such a one, to be slain</em> <span class="add">[<em>in retaliation</em>]</span> <em>for him:</em> <span class="auth">(T:)</span> or <em>became his like,</em> or <em>equal, so that he was slain</em> <span class="add">[<em>in retaliation</em>]</span> <em>for him:</em> <span class="auth">(Mgh:)</span> and <em>was slain for him,</em> <span class="auth">(AZ, T, Ṣ,)</span> <em>and his blood became a compensation for the blood of the other:</em> <span class="auth">(T:)</span> or <em>was deserving of being,</em> or <em>fit to be, slain in retaliation for him,</em> <span class="auth">(Ksh and Bḍ in ii. 58,)</span> <em>because his equal:</em> <span class="auth">(Ksh ibid.:)</span> or <em>was slain for him, and so became equal with him;</em> <span class="auth">(Ḳ,* TA;)</span> as also<span class="arrow"><span class="ar">أَبَآءَهُ↓</span></span>, and<span class="arrow"><span class="ar">بَاوَأَهُ↓</span></span>. <span class="auth">(M, Ḳ.)</span> One says, <span class="ar">بُؤْبِهِ</span>, i. e. <em>Be thou of such as are slain</em> <span class="add">[<em>in retaliation</em>]</span> <em>for him.</em> <span class="auth">(Ṣ.)</span> And it is said in a prov., <span class="ar long">بَآءَتْ عَرَارِ بِكَحْلٍ</span> <em>'Arári became slain for Kahl:</em> these were two cows, which smote each other with their horns, and both died: the proverb is applied to any two that become equal. <span class="auth">(Ṣ in this art.; and the same and Ḳ in art. <span class="ar">عر</span>. <span class="add">[See also Freytag's Arab. Prov. i. 151.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bwO_1_B2">
					<p><span class="ar long">بَآءَ دَمَهُ بِدَمِهِ</span>, <span class="auth">(T,* M, Ḳ,)</span> inf. n. <span class="ar">بَوْءٌ</span> and <span class="ar">بَوَآءٌ</span>, <span class="auth">(M,)</span> <em>He made his blood equal with</em> <span class="add">[or <em>an equivalent for</em>]</span> <em>his</em> <span class="add">[i. e. <em>another's</em>]</span> <em>blood</em> <span class="add">[<em>by shedding the former in retaliation</em>]</span>. <span class="auth">(M, Ḳ.)</span> And <span class="ar">بَآءَهُ</span>, <span class="add">[or <span class="ar long">بَآءَهُ بِهِ</span>,]</span> <span class="auth">(M,)</span> or<span class="arrow"><span class="ar long">أَبَآءَهُ↓ به</span></span>, <span class="auth">(T, Ṣ,)</span> and<span class="arrow"><span class="ar long">اِسْتِبَآءَهُ↓ به</span></span>, <span class="auth">(Ṣ,)</span> <em>He slew him</em> <span class="add">[<em>in retaliation</em>]</span> <em>for him;</em> <span class="auth">(T, Ṣ, M;)</span> i. e., the slayer for the slain. <span class="auth">(Ṣ.)</span> <span class="arrow"><span class="ar long">أَبَآءَ↓ فُلَانًا بِفُلَانٍ</span></span> <span class="add">[<em>He slew such a one in retaliation for such a one</em>]</span> is said when the Sultán has retaliated for a man upon another man: and<span class="arrow"><span class="ar">أَبَآءَهُ↓</span></span>, inf. n. <span class="ar">إِبَآءَةٌ</span>, signifies <em>he</em> <span class="auth">(the Sultán, or another,)</span> <em>slew him in retaliation.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bwO_1_C1">
					<p><span class="ar">بَآءَ</span> signifies also <em>He exalted himself,</em> or <em>was proud:</em> app. formed by transposition <span class="add">[of the second and third radical letters, the <span class="ar">ى</span> being changed into <span class="ar">ا</span>,]</span> from <span class="ar">بَأَى</span>. <span class="auth">(Fr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwO_2">
				<h3 class="entry">2. ⇒ <span class="ar">بوّأ</span></h3>
				<div class="sense" id="bwO_2_A1">
					<p><span class="ar long">بوّأهُ مَنْزِلًا</span> <em>He lodged him in an abode;</em> <span class="auth">(Fr, T, M, Ḳ;)</span> as also <span class="ar long">بوّاهُ فِى مَنْزِلٍ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar long">ابآءهُ↓ مَنْزِلًا</span></span>: <span class="auth">(T,* M, Ḳ:)</span> or, as also <span class="ar long">بوّأ لَهُ مَنْزِلًا</span>, <span class="auth">(the latter mentioned by Fr, T,)</span> <em>he prepared for him an abode,</em> <span class="auth">(Ṣ, Mgh,)</span> <em>and assigned,</em> or <em>gave, him a place therein:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">بَوَّأْتُهُ دارًا</span> and <span class="ar long">بوّاتُ لَهُ دارًا</span> <em>I lodged him in a house:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">بَوَّأْتُكَ بَيْتًا</span> <em>I took for thee a house:</em> and<span class="arrow"><span class="ar long">تَبَوَّآ↓ لِقَوْمِكُمَا بِمِصْرَ بُيُوتًا</span></span> <span class="add">[in the Ḳur x. 87]</span> means <em>take ye two, for your people, in Egypt, houses:</em> <span class="auth">(Akh, T:)</span> or<span class="arrow"><span class="ar">تَبَوُّؤٌ↓</span></span> <span class="add">[or <span class="ar long">تَبَوُّؤُ مَكَانٍ</span>]</span> signifies a man's <em>putting a mark upon a place, when it pleases him, that he may abide there:</em> <span class="auth">(El-'Itreefee, T:)</span> or<span class="arrow"><span class="ar">تبوّأهُ↓</span></span> <em>he put it</em> <span class="add">[a place]</span> <em>into a right,</em> or <em>proper, state;</em> and <em>prepared it:</em> <span class="auth">(Sh,* T:)</span> or<span class="arrow"><span class="ar long">تبوّأ↓ بَيْتًا</span></span> <em>he took a house as a place of abode,</em> or <em>as a dwelling:</em> <span class="auth">(Mṣb:)</span> or<span class="arrow"><span class="ar long">تبوّأ↓ مَنْزِلًا</span></span> <em>he looked for the best place that could be seen, and the most level,</em> or <em>even, and the best adapted by its firmness, for his passing the night there, and took it as a place of abode;</em> <span class="auth">(Fr, T;)</span> or <em>he took for himself a place of abode;</em> <span class="auth">(T, Mgh;)</span> or <em>he alighted and sojourned in a place of abode:</em> and<span class="arrow"><span class="ar">استبآءهُ↓</span></span> <em>he took it as a</em> <span class="ar">مَبَآءَة</span> <span class="add">[or <em>place of abode</em>]</span>: <span class="auth">(Ṣ:)</span> and <span class="ar long">بوّأ المَكَانَ</span> and<span class="arrow"><span class="ar long">ابآء↓ بِهِ</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">تبوّأ↓</span></span> <span class="add">[i. e. <span class="ar long">تبوّأ بِهِ</span>]</span> <span class="auth">(Sh, T, Ḳ)</span> <em>he alighted in the place, and stayed,</em> or <em>dwelt, in it:</em> <span class="auth">(Sh, T, Ḳ:)</span> or<span class="arrow"><span class="ar long">ابآء↓ به</span></span> <em>he stayed,</em> or <em>dwelt, in it,</em> i. e., a place: <span class="auth">(Akh, T:)</span> and<span class="arrow"><span class="ar long">تبوّأ↓ المَكَانَ</span></span> <em>he alighted and abode in the place:</em> <span class="auth">(M:)</span> <span class="add">[whence, in the Ḳur lix. 9,]</span><span class="arrow"><span class="ar long">وَٱلَّذِينَ تَبَوَّؤُوا↓ ٱلدَّارَوَ ٱلْإِيمَانَ</span></span> <span class="add">[<em>and they who have made their abode in the City</em> of the Prophet <em>and in the faith</em>]</span>; the faith being likened to a place of abode; or the meaning may be <span class="ar long">مَكَانَ الإِيمَانِ</span> <span class="add">[<em>the place of the faith</em>]</span>. <span class="auth">(M.)</span> <span class="ar long">بَوَّأَهُمْ مَنْزِلًا</span> <span class="auth">(AZ, M)</span> and<span class="arrow"><span class="ar long">أَبَآءَهُمْ↓ منزلًا</span></span> <span class="auth">(AZ, TA)</span> also signify <em>He alighted and abode with them by the face,</em> or <em>front, of a mountain, where it rose from its base,</em> <span class="auth">(AZ, M, TA,)</span> or <em>next to a river,</em> or <em>brook.</em> <span class="auth">(AZ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwO_2_B1">
					<p><span class="add">[Hence, (<a href="#baACapi">see <span class="ar">بَآءَةِ</span></a>,)]</span> <span class="ar">بوّأ</span> <span class="auth">(inf. n. <span class="ar">تَبْوِيْءٌ</span>, Ḳ)</span> † <em>Inivit</em> <span class="add">[feminam]</span>: and <em>he married</em> <span class="add">[a woman]</span>; <em>took</em> <span class="add">[her]</span> <em>in marriage:</em> syn. <span class="ar">نَكَحَ</span>: <span class="auth">(M, Ḳ:)</span> and also <span class="ar">تَزَّوَجَ</span>. <span class="auth">(TA. <span class="add">[There mentioned as a distinct signification.]</span>)</span> The verb is trans. in these two senses. <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bwO_2_C1">
					<p><span class="ar long">بوّأ الرُمْحَ نَحْوَهُ</span> <em>He directed the spear towards him;</em> <span class="auth">(T, Ṣ;)</span> and <span class="auth">(T)</span> <em>confronted him with it;</em> <span class="auth">(T, M, Ḳ;)</span> and <em>prepared it,</em> or <em>made it ready</em> <span class="add">[<em>to thrust it towards him</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bwO_3">
				<h3 class="entry">3. ⇒ <span class="ar">باوأ</span></h3>
				<div class="sense" id="bwO_3_A1">
					<p><span class="ar">بَاوَأهُ</span>: <a href="#baACa">see <span class="ar long">بَآءَ فُلَانٌ بِفُلَانٍ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابوأ</span></h3>
				<div class="sense" id="bwO_4_A1">
					<p><span class="ar">أَبَأْتُهُ</span>: <a href="#buWotu">see <span class="ar long">بُؤْتُ بِهِ إِلَيْهِ</span></a>, near the beginning of this art.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwO_4_A2">
					<p><span class="ar long">ابآء الإِبِلَ</span>, <span class="auth">(T, Ṣ, O, L, and so in some copies of the Ḳ, in other copies of which we find <span class="ar long">ابآء بِالْإِبِلِ</span>,)</span> inf. n. <span class="ar">إِبَآءَةٌ</span>, <span class="auth">(T,)</span> <em>He brought back the camels to the</em> <span class="ar">مَبَآءَة</span> <span class="auth">(T, Ṣ, O, L)</span> or <span class="ar">مَعْطِن</span>, <span class="auth">(Ḳ,)</span> both of which signify the <em>place where they are made to lie down, at the watering-place.</em> <span class="auth">(L.)</span> And <span class="ar long">ابآء الإِبِلَ</span>, <span class="auth">(T, M,)</span> inf. n. as above, <span class="auth">(T,)</span> <em>He made the camels to lie down</em> <span class="add">[<em>in the</em> <span class="ar">مَبَآءَة</span>]</span>, <em>one beside another.</em> <span class="auth">(T, M.)</span> And <span class="ar long">ابآء عَلَيْهِ مَالَهُ</span> <em>He drove back,</em> or <em>brought back, to their nightly resting-place, for him, his cattle,</em> <span class="auth">(Ṣ, M, TA,)</span> i. e., <em>his camels,</em> or <em>his sheep</em> or <em>goats.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="add">[hence,]</span> <span class="ar long">أَبَآءَ ٱللّٰهُ عَلَيْهِمْ نَعَمًا لَا يَسَعُهَا المُرَاحُ</span> <span class="add">[<em>God bestowed upon them cattle</em> <span class="auth">(i. e. <em>camels</em>, &amp;c.)</span> <em>which the nightly resting-place thereof would not contain</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwO_4_A3">
					<p><a href="#bwA2">See also 2</a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwO_4_A4">
					<p><span class="ar long">ابآء الأَدِيمَ</span> <em>He put the skin,</em> or <em>hide, into the tanning liquid.</em> <span class="auth">(Ḳ.)</span> In the O, the action is ascribed to a woman. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwO_4_B1">
					<p><span class="ar long">ابآء مِنْهُ</span> <em>He fled from him.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bwO_4_B2">
					<p><span class="ar long">فَلَاةٌ تُبِىْءُ فِى فَلَاْةٍ</span> <em>A desert that extends</em> <span class="auth">(lit. <em>goes away</em>)</span> <em>into a desert,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> <em>by reason of its amplitude.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bwO_4_C1">
					<p><span class="ar">أَبَأْتُهُ</span> <em>I made him to acknowledge,</em> or <em>confess.</em> <span class="auth">(M.)</span> <span class="add">[It seems to be indicated in the M that one says, <span class="ar long">أَبَأْتُهُ بِدَمِ فُلَانٍ</span>, meaning <em>I made him to acknowledge,</em> or <em>confess, himself to be answerable, responsible,</em> or <em>accountable, for the blood of such a one.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bwO_4_D1">
					<p><a href="#bwA1">See also 1</a>, <span class="auth">(towards the end of the paragraph,)</span> in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwO_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبوّأ</span></h3>
				<div class="sense" id="bwO_5_A1">
					<p><a href="#bwA2">see 2</a>, in eight places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwO_5_A2">
					<p><span class="ar long">الرَّجُلُ يَتَبَوَّأُ مِنْ أَهْلِهِ كَمَا يَتَبَوَّأُ مِنْ دَارِهِ</span> <em>The man possesses mastery,</em> or <em>authority, and power, over his wife, like as he possesses the same over his house;</em> syn. <span class="ar long">يَسْتَمْكِنُ مِنْهَا</span>. <span class="auth">(Ṣ, Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwO_5_A3">
					<p><a href="#bwA10">See also 10</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwO_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباوأ</span></h3>
				<div class="sense" id="bwO_6_A1">
					<p><span class="ar">تَبَاوَآ</span> <em>They two</em> <span class="auth">(namely, two slain men, M)</span> <em>became equal</em> <span class="add">[<em>by being slain, one in retaliation for the other</em>]</span>. <span class="auth">(M, Ḳ.)</span> It is said in a trad., <span class="ar long">أَمَرَهُمْ أَنْ يَتَبَاوَؤُوا</span>; incorrectly related as being <span class="ar">يَتَبآءَوْا</span>; <span class="auth">(Ṣ, Mgh;)</span> meaning <em>He</em> <span class="auth">(the Prophet)</span> <em>ordered them that they should be equal in retaliation,</em> in their fighting: <span class="auth">(Mgh:)</span> the occasion of the order was this: there was a conflict between two tribes of the Arabs, and one of the two tribes had superior power over the other, so they said, “We will not be content unless we slay, for the slave of our party, the free of their party; and for the woman, the man:” AʼObeyd holds the former reading to be the right. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwO_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبوأ</span></h3>
				<div class="sense" id="bwO_10_A1">
					<p><span class="ar">استبآءهُ</span>: <a href="#bwA2">see 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwO_10_A2">
					<p>In the following verse of Zuheyr Ibn-Abee-Sulmà,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَلَمْ أَرَ مَعْشَرًا أَسَرُوا هَدِيًّا</span> *</div> 
						<div class="star">* <span class="ar long">وَلَمْ أَرَجَارَ بَيْتٍ يُسْتَبَآءُ</span> *</div> 
					</blockquote>
					<p>ISk says that the <span class="ar">هَدِىّ</span> is <em>one who is entitled to respect,</em> or <em>honour,</em> or <em>protection;</em> and that <span class="ar">يستبآء</span> is syn. with <span class="arrow"><span class="ar">يُتَبَوَّأُ↓</span></span>, meaning <em>whose wife is taken as a wife</em> <span class="add">[by another man]</span>: but Aboo-ʼAmr EshSheybánee says that <span class="ar">يستبآء</span> is from <span class="ar">البَوَآءُ</span>, meaning “retaliation:” <span class="add">[and accord. to this interpretation, which is the more probable, the verse may be rendered, <em>And I have not seen a company of men who have made captive one entitled to respect,</em> or <em>honour,</em> or <em>protection, nor have I seen one who has begged the protection</em> of the people <em>of a house,</em> or <em>of a tent, slain in retaliation:</em>]</span> for, he says, he came to them desiring to beg their protection, and they took him, and slew him in retaliation for one of themselves. <span class="auth">(T.)</span> <a href="#bwA1">See 1</a>, near the end of the paragraph.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwO_10_A3">
					<p><span class="ar long">اِسْتَبَأْتُ الحَكَمَ</span>, and <span class="ar">بِالْحَكَم</span>, <em>I asked the judge to retaliate upon a slayer; to slay the slayer for the slain.</em> <span class="auth">(M.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baMCN">
				<span class="pb" id="Page_0272"></span>
				<h3 class="entry"><span class="ar">بَآءٌ</span></h3>
				<div class="sense" id="baMCN_A1">
					<p><span class="ar">بَآءٌ</span>: <a href="#baACapN">see <span class="ar">بَآءَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">بَآءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baMCN_B1">
					<p>A <em>libidinous</em> man. <span class="auth">(TA in <span class="ar long">باب الالف الليّنة</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">بَآءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="baMCN_C1">
					<p>The <em>name of the letter</em> <span class="ar">ب</span>, q. v.; as also <span class="ar">بَا</span>: pl. of the former <span class="ar">بَآءَاتٌ</span>; and of the latter <span class="ar">أَبْوَآءٌ</span>. <span class="auth">(TA ubi suprà.)</span> The dim. is <span class="ar">بُيَيَّةٌ</span>, meaning <em>A little</em> <span class="ar">ب</span>: and <em>a</em> <span class="ar">ب</span> <em>faintly pronounced:</em> <span class="add">[and app. <span class="ar">بُوَيَّةٌ</span> also, as the medial radical is generally held to be <span class="ar">و</span>:]</span> and in like manner is formed the dim. of every similar name of a letter. <span class="auth">(Lth, on the letter <span class="ar">حَآء</span>, in TA, <span class="ar long">باب الالف اللينّة</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baMCapN">
				<h3 class="entry"><span class="ar">بَآءَةٌ</span></h3>
				<div class="sense" id="baMCapN_A1">
					<p><span class="ar">بَآءَةٌ</span>: <a href="#mabaACapN">see <span class="ar">مَبَآءَةٌ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">بَآءَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baMCapN_B1">
					<p>Also, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بَآءٌ↓</span></span>, <span class="auth">(IAạr, T, Ṣ, M, Ḳ,)</span> and <span class="ar">بَاهَةٌ</span>, with the <span class="ar">ء</span> changed into <span class="ar">ه</span>, <span class="auth">(TA,)</span> and <span class="ar">بَاهٌ</span>, <span class="auth">(IAạr, T, Mṣb,)</span> with <span class="ar">ا</span> and <span class="ar">ه</span>, but IḲt asserts this last to be a mistranscription, <span class="auth">(Mṣb, TA,)</span> <span class="add">[though it is of very frequent occurrence,]</span> and IAmb says that <span class="ar">بَآءَةٌ</span> is sing., or n. un., of <span class="ar">بَآءٌ</span>, and <span class="ar">بَآءٌ</span> <span class="add">[or <span class="ar">بَآءَةٌ</span>]</span> has for pl. <span class="ar">بَآءَاتٌ</span>, <span class="auth">(TA,)</span> ‡ <em>Coïtus conjugalis:</em> and <em>marriage:</em> syn. <span class="ar">جِمَاعٌ</span> <span class="auth">(T, Mṣb)</span> and <span class="ar">نِكَاحٌ</span> <span class="auth">(Aṣ, Fr, T, Ṣ, M, Mgh, Ḳ)</span> and <span class="ar">تَزْوِيجٌ</span>: <span class="auth">(T:)</span> from <span class="ar">بَآءَةٌ</span> signifying <em>a place of abode;</em> <span class="add">[<a href="#mabaACapN">see <span class="ar">مَبَآءَةٌ</span></a>;]</span> <span class="auth">(T, Ṣ,* Mgh, Mṣb;)</span> because it is generally in a place of abode; <span class="auth">(Mgh, Mṣb;)</span> or because the man possesses mastery, or authority, and power, over his wife, like as he possesses the same over his house: <span class="auth">(Ṣ, Mgh, Mṣb: <a href="#bwA5">see 5</a>:)</span> <span class="ar">بَآءَةٌ</span> is applied <span class="add">[also]</span> to the <em>marriage-contract;</em> because he who takes a woman in marriage lodges her in a place of abode. <span class="auth">(T.)</span> <span class="add">[<a href="#baAhN">See also <span class="ar">بَاهٌ</span></a>, <a href="index.php?data=02_b/227_bwh">in art. <span class="ar">بوه</span></a>.]</span> It is said in a trad., <span class="ar long">مَنِ ٱسْتَطَاعَ مِنْكُمُ البَآءَ ةَ فَلْيَتَزَّوجْ</span> <em>He who is able, of you, to marry, let him marry:</em> <span class="auth">(T:)</span> or a prefixed noun is here suppressed; the meaning being, <em>he who finds</em> <span class="add">[or <em>is able to procure</em>]</span> <em>the provisions</em> (<span class="ar">مُؤَن</span>) <em>of marriage, let him marry.</em> <span class="auth">(Mṣb, TA.)</span> And one says, <span class="ar long">فُلَانٌ حَرِيصٌ عَلَى البَآءَةِ</span> <em>Such a one is vehemently desirous of marriage.</em> <span class="auth">(Aṣ, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biyoYapN">
				<h3 class="entry"><span class="ar">بِيْئَةٌ</span></h3>
				<div class="sense" id="biyoYapN_A1">
					<p><span class="ar">بِيْئَةٌ</span> a subst. from <span class="ar long">بَوَّأَهُ مَنْزِلًا</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#bwA2">See 2</a>; and]</span> <a href="#mabaACapN">see also <span class="ar">مَبَآءَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">بِيْئَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biyoYapN_A2">
					<p><em>A mode,</em> or <em>manner, of taking for oneself a place of abode:</em> <span class="auth">(M:)</span> and <span class="add">[hence,]</span> <em>a state,</em> or <em>condition.</em> <span class="auth">(AZ, T, Ṣ, M, Ḳ.)</span> You say, <span class="ar long">إِنَّهُ لَحَسَنُ البِيْئَةِ</span> <em>Verily he has a good mode,</em> or <em>manner, of taking for himself a place of abode:</em> <span class="auth">(M:)</span> or <em>verily he is of good state</em> or <em>condition.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">بَاتَ بِبِيْئَةِ</span> <em>He passed the night in an evil state</em> or <em>condition</em> <span class="auth">(AZ, T, Ṣ,* M.)</span> <span class="ar">بَوَآءٌ</span> <em>Equal; equivalent; like; alike; a match;</em> <span class="auth">(Akh, T, Ṣ, M, Mgh, Ḳ;)</span> and particularly, <em>if slain in retaliation for another.</em> <span class="auth">(M.)</span> It is applied to one, and to two, and to more: so that you say, <span class="ar long">فُلَانٌ بَوَآءٌ فُلَانٌ</span> <em>Such a one is the equal,</em>, &amp;c., <em>of such a one if slain in retaliation for him:</em> <span class="auth">(M:)</span> and <span class="ar long">هُوَ بَوَآءٌ</span> <em>He is an equal,</em>, &amp;c.; and so <span class="ar">هِىَ</span> <em>she:</em> and <span class="ar long">هُمْ بَوَآءٌ</span> <em>They are equals,</em>, &amp;c.; and so <span class="ar">هُنَّ</span> <em>they,</em> referring to females: <span class="auth">(Mgh:)</span> and <span class="ar long">هُمْ بَوَآءٌ فِى هٰذَا الأَمْرِ</span> <em>They are equals in this affair.</em> <span class="auth">(T.)</span> Hence, in a trad. of ʼAlee, respecting witnesses, <span class="ar long">إَذَ كَانُوا بَوَآءٌ</span> <em>When they are equals in number and rectitude.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">مَا فُلَانٌ لِفُلَانٍ بِبَوَآءٌ</span> <em>Such a one is not an equal,</em>, &amp;c., <em>to such a one.</em> <span class="auth">(T.)</span> And <span class="ar long">دَمُ فُلَانٍ بَوَآءٌ لِدَمِ فُلَانٍ</span> <em>The blood of such a one is an equivalent for the blood of such a one.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">الجِرَاحَاتُ بَوَآءٌ</span> <em>Wounds are to be retaliated equally:</em> a trad. <span class="auth">(T, Mgh.)</span> And <span class="ar long">القَوْمُ عَلَى بَوَآءِ</span> <em>The people,</em> or <em>company of men, are in a state of equality.</em> <span class="auth">(T.)</span> And <span class="ar long">قُسِمَ المَالُ بَيْنَهُمْ عَلَى بَوَآءٍ</span> <em>The property was divided among them equally.</em> <span class="auth">(T. <span class="add">[A similar ex. is given in the Mgh, and explained in the same manner; but there I find <span class="ar long">عَنْ بَوَآءٍ</span>; perhaps a mistranscription.]</span>)</span> And <span class="ar long">كَلَّمْنَاهُمْ فَأَجَابُوا عَنْ بَوَآءٍ وَاحِدٍ</span> <span class="add">[in a copy of the M <span class="ar long">عَلَى بوآء واحد</span>]</span> <em>We spoke to them, and they replied with one reply:</em> <span class="auth">(T, Ṣ, O, Ḳ:*)</span> i. e., their reply was not discordant: <span class="ar">عَنْ</span> being here used in the sense of <span class="ar">بِ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">بِيْئَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="biyoYapN_A3">
					<p>Also <em>Retaliation.</em> <span class="auth">(T.)</span> <span class="add">[<a href="#bwA1">See 1</a>, near the end of the paragraph: as well as in other places.]</span> It is related in a trad., that Jaạfar Es-Sádik, being asked the reason of the rage of the scorpion against the sons of Adam, said, <span class="ar long">تُرِيدُ البَوَآءَ</span> <span class="add">[<em>It desires retaliation</em>]</span>; i. e., it hurts like as it is hurt. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYieBN">
				<h3 class="entry"><span class="ar">بَائِىٌّ</span></h3>
				<div class="sense" id="baAYieBN_A1">
					<p><span class="ar">بَائِىٌّ</span> and<span class="arrow"><span class="ar">بَاوِيٌّ↓</span></span> rel. ns. of <span class="ar">بَآءٌ</span> and <span class="ar">بَا</span> the names of the letter <span class="ar">ب</span>; <span class="auth">(TA in <span class="ar long">باب الالف الليّنة</span>;)</span> and<span class="arrow"><span class="ar">بَيَوِىٌّ↓</span></span> is a rel. n. of the same. <span class="auth">(M in art. <span class="ar">ب</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAwieBN">
				<h3 class="entry"><span class="ar">بَاوِىٌّ</span></h3>
				<div class="sense" id="baAwieBN_A1">
					<p><span class="ar">بَاوِىٌّ</span> <a href="#baAyieBN">see <span class="ar">بَائِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayawieBN">
				<h3 class="entry"><span class="ar">بَيَوِىٌّ</span></h3>
				<div class="sense" id="bayawieBN_A1">
					<p><span class="ar">بَيَوِىٌّ</span> <a href="#baAyieBN">see <span class="ar">بَائِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabaMCapN">
				<h3 class="entry"><span class="ar">مَبَآءَةٌ</span></h3>
				<div class="sense" id="mabaMCapN_A1">
					<p><span class="ar">مَبَآءَةٌ</span> The <em>nightly resting-place</em> of camels; <span class="auth">(T;)</span> the <em>resting-place</em> of camels, <em>where they are made to lie down, at the watering-place;</em> <span class="auth">(T, Ṣ,* M,* L, Ḳ;*)</span> and of sheep or goats likewise; also termed <span class="arrow"><span class="ar">مُتَبَوَّأٌ↓</span></span>: <span class="auth">(L, TA:)</span> or the <em>place to which camels return;</em> <span class="auth">(Mgh;)</span> as also<span class="arrow"><span class="ar">بَآءَةٌ↓</span></span>: <span class="auth">(Mgh, Mṣb:)</span> this is the primary signification. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">مَبَآءَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mabaMCapN_A2">
					<p>Hence, <span class="auth">(Mgh,)</span> <em>A place of abode</em> <span class="auth">(T, Ṣ, M, Ḳ)</span> of a people, <em>in any situation;</em> <span class="auth">(T, Ṣ;)</span> as also<span class="arrow"><span class="ar">مُبَوَّأٌ↓</span></span> <span class="auth">(Bḍ and Jel in x. 93)</span> and<span class="arrow"><span class="ar">بِيْئَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">بَآءَةٌ↓</span></span>; <span class="auth">(Ṣ,* M, Mgh, Mṣb,* Ḳ;)</span> which last is hence applied in another sense, explained before, voce <span class="ar">بآءَةٌ</span>: <span class="auth">(Mgh, Mṣb:)</span> or <em>a place where people alight and abide next to a valley,</em> or <em>to the face,</em> or <em>front, of a mountain, where it rises from its base;</em> <span class="add">[<a href="#bawBaOahumo">see <span class="ar long">بَوَّأَهُمْ مَنْزِلًا</span></a>;]</span> as also<span class="arrow"><span class="ar">بَآءَةٌ↓</span></span>. <span class="auth">(T.)</span> <span class="add">[Hence,]</span> <span class="ar long">هُوَ رَحِيبٌ المَبَآءَةِ</span> † <em>He is largely bountiful.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">مَبَآءَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mabaMCapN_A3">
					<p>Also The <em>covert</em> of the wild bull. <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">مَبَآءَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="mabaMCapN_A4">
					<p><em>A nest</em> of bees <em>in a mountain:</em> <span class="auth">(M, Ḳ:)</span> or, accord. to the T, the <em>nightly resting-place</em> of bees; not there restricted by mention of the mountain. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">مَبَآءَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="mabaMCapN_A5">
					<p>The <em>part</em> of the womb <em>where the child has its abode;</em> <span class="auth">(M;)</span> the <em>part</em> thereof <em>which is the child's</em> <span class="arrow"><span class="ar">مُتَبَوَّأ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوأ</span> - Entry: <span class="ar">مَبَآءَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="mabaMCapN_A6">
					<p>A well has what are termed <span class="ar">مَبَآءَتَانِ</span>, which are The <em>place where the water returns to</em> <span class="add">[<em>supply the place of</em>]</span> <em>that which has</em> <span class="add">[<em>before</em>]</span> <em>collected in the well</em> <span class="add">[<em>and been drawn</em>]</span>, <span class="auth">(M,)</span> or the <em>place where the water collects in the well;</em> <span class="auth">(TA voce <span class="ar">مَآءَبَةٌ</span>;)</span> and the <em>place where stands the driver of the</em> <span class="ar">سَانِيَة</span> <span class="add">[q. v.]</span>. <span class="auth">(M.)</span> <span class="add">[<a href="#mavaAbapN">See also <span class="ar">مَثَابَةٌ</span></a>; and <span class="ar">مَثَابٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubiyoYapN">
				<h3 class="entry"><span class="ar">مُبِيْئَةٌ</span></h3>
				<div class="sense" id="mubiyoYapN_A1">
					<p><span class="ar long">حَاجَةٌ مُبِيْئَةٌ</span> <em>A want that is vehement,</em> or <em>pressing,</em> <span class="auth">(Ḳ, TA,)</span> <em>and necessary.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubawBaON">
				<h3 class="entry"><span class="ar">مُبَوَّأٌ</span></h3>
				<div class="sense" id="mubawBaON_A1">
					<p><span class="ar">مُبَوَّأٌ</span> <a href="#mabaACapN">see <span class="ar">مَبَآءَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutabawBaON">
				<h3 class="entry"><span class="ar">مُتَبَوَّأٌ</span></h3>
				<div class="sense" id="mutabawBaON_A1">
					<p><span class="ar">مُتَبَوَّأٌ</span> <a href="#mabaACapN">see <span class="ar">مَبَآءَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0270.pdf" target="pdf">
							<span>Lanes Lexicon Page 270</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0271.pdf" target="pdf">
							<span>Lanes Lexicon Page 271</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0272.pdf" target="pdf">
							<span>Lanes Lexicon Page 272</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
