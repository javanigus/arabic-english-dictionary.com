<article class="root" id="Root_bgw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/151_bgm">بغم</a></span>
				<span class="ar">بغو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/153_bge">بغى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغو</span> ⇒ <span class="ar">بغى</span></h3>
				<div class="sense" id="bgw_1_A1">
					<p><span class="ar long">بَغَا الشَّىْءَ</span>, inf. n. <span class="ar">بَغْوٌ</span>, <em>He looked at the thing</em> <span class="add">[<em>to see</em>]</span> <em>how it was;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">بَغَى</span>, <span class="auth">(Ḳ in art. <span class="ar">بغى</span>,)</span> inf. n. <span class="ar">بَغْىٌ</span>. <span class="auth">(TA in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0231.pdf" target="pdf">
							<span>Lanes Lexicon Page 231</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
