<article class="root" id="Root_bqr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/154_bq">بق</a></span>
				<span class="ar">بقر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/156_bqs">بقس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bqr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بقر</span></h3>
				<div class="sense" id="bqr_1_A1">
					<p><span class="ar">بَقَرَ</span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْقُرُ</span>}</span></add>, <span class="auth">(JK, Ṣ, A, Mgh, Mṣb,)</span> or <span class="ar">ـَ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[but this seems to be a mistake,]</span> inf. n. <span class="ar">بَقْرٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He slit; ripped; split; cut,</em> or <em>divided, lengthwise.</em> <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.)</span> <em>He slit,</em> or <em>ripped open,</em> an animal's belly. <span class="auth">(A, Mgh.)</span> One says, <span class="ar long">اُبْقُرْهَا عَنْ جَنِينِهَا</span> <em>Rip thou open her</em> <span class="add">[a camel's]</span> <em>belly so as to disclose her fœtus.</em> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#baqiyrN">See <span class="ar">بَقِيرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bqr_1_A2">
					<p><em>He opened,</em> or <em>laid open.</em> <span class="auth">(Ṣ, A, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bqr_1_A3">
					<p><em>He widened; made wide,</em> or <em>ample.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bqr_1_A4">
					<p><em>He opened, and widened,</em> or <em>made wide,</em> a house, or tent. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bqr_1_A5">
					<p><em>He opened and revealed</em> to a person a story. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bqr_1_A6">
					<p><span class="ar long">بَقَرَ الأَرْضَ</span> said of a <span class="ar">هُدْهُد</span> <span class="add">[or hoopoe]</span>, <em>It looked for the place of water and saw it:</em> <span class="auth">(Ḳ:)</span> <span class="add">[or <em>it clave the ground and discovered water:</em>]</span> occurring in a trad. respecting the <span class="ar">هدهد</span> of Solomon <span class="add">[mentioned in the Ḳur ch. xxvii.]</span> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bqr_1_A7">
					<p><span class="ar long">بَقَرَ فِى بَنِى فُلَانٍ</span> <em>He knew the state, condition, case,</em> or <em>affair, of the sons of such a one, and examined,</em> or <em>inspected, them.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bqr_1_A8">
					<p><span class="ar long">بَقَرَ عَنِ العُلُومِ</span> <em>He inquired,</em> and <em>searched to the utmost, after sciences.</em> <span class="auth">(A.)</span></p>
				</div>
				<span class="pb" id="Page_0234"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bqr_1_A9">
					<p><span class="ar long">بَقَرَ العِلْمَ</span>: <a href="#bqr_5">see 5</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bqr_1_B1">
					<p><span class="ar">بَقِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْقَرُ</span>}</span></add>, <em>He</em> <span class="auth">(a dog)</span> <em>became confounded,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and stupified,</em> <span class="auth">(TA,)</span> <em>with joy,</em> <span class="auth">(Ḳ,)</span> <em>at seeing</em> <span class="ar">بَقَر</span>, <span class="auth">(Ṣ, Ḳ,)</span> i. e., <span class="ar long">بَقَر الوَحْش</span> <span class="add">[<em>wild oxen,</em> or <em>wild bulls</em> or <em>cows</em>]</span>; <span class="auth">(TA;)</span> like as one says <span class="ar">غَزِلَ</span> meaning “he sported,” or “played,” “at seeing a gazelle,” or “a young gazelle;” as also<span class="arrow"><span class="ar">بَيْقَرَ↓</span></span>: or the former, <em>he feared, so that he was astonished, amazed,</em> or <em>stupified, at seeing many</em> <span class="ar">بَقَر</span>: <span class="auth">(TA voce <span class="ar">بَحِزَ</span>:)</span> and<span class="arrow">↓</span> the latter signifies also <span class="add">[simply]</span> <em>he became confounded,</em> or <em>perplexed:</em> <span class="auth">(IAạr, TA:)</span> and <em>he doubted respecting a thing.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bqr_1_B2">
					<p>Also, aor. as above, inf. n. <span class="ar">بَقَرٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بَقْرٌ</span>; <span class="auth">(Ḳ;)</span> but Az says, El-Mundhiree has informed me that AHeyth disallowed <span class="ar">بَقْرٌ</span>, saying that it is accord. to analogy <span class="ar">بَقَرٌ</span>, as the verb is intrans.; <span class="auth">(TA;)</span> <em>He</em> <span class="auth">(a man)</span> <em>became tired,</em> or <em>fatigued,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>so that he could hardly see;</em> <span class="auth">(Ḳ;)</span> and <em>he became weary,</em> or <em>jaded;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَيْقَرَ↓</span></span>. <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بقّر</span></h3>
				<div class="sense" id="bqr_2_A1">
					<p><span class="ar long">بقّر القَوْمُ مَا حَوْلَهُمْ</span> <em>The people dug the tract around them, and made wells.</em> <span class="auth">(Aṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبقّر</span></h3>
				<div class="sense" id="bqr_5_A1">
					<p><span class="ar">تبقّر</span> <em>It</em> <span class="auth">(a she-camel's belly)</span> <em>became ripped open;</em> as also<span class="arrow"><span class="ar">ابتقر↓</span></span> and<span class="arrow"><span class="ar">انبقر↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bqr_5_A2">
					<p><em>It became open.</em> <span class="auth">(Aṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bqr_5_A3">
					<p>And <em>i. q.</em> <span class="ar">توسّع</span>; <span class="auth">(Aṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَبَيْقَرَ↓</span></span>. <span class="auth">(Ḳ.)</span> So in the phrase <span class="ar long">تبقّر فِى العِلْمِ</span> <span class="add">[<em>He enlarged himself,</em> or <em>took a wide range, in science,</em> or <em>knowledge</em>]</span>; <span class="auth">(Ṣ, A, Mṣb;)</span> and<span class="arrow"><span class="ar long">بَقَرَ↓ العِلْمَ</span></span>, inf. n. <span class="ar">بَقْرٌ</span>, signifies the same. <span class="auth">(TA.)</span> And so in the phrase <span class="ar long">تبقّر فِى المَالِ</span>, <span class="auth">(Ṣ, A, Mṣb,)</span> and <span class="ar long">فى الأَهْلِ</span>, <span class="auth">(TA,)</span> i. e., <em>He enlarged himself,</em> or <em>he became,</em> or <em>made himself, large,</em> or <em>abundant, in wealth,</em> or <em>camels</em> or <em>the like,</em> and <em>in family;</em> as explained by Aṣ. <span class="auth">(AʼObeyd.)</span> You say also, <span class="ar long">تبقّر الكَلَامَ</span>, <span class="add">[meaning <span class="ar long">فِى الكَلَامِ</span>,]</span> i. e., <em>He was diffuse,</em> or <em>profuse, in speech;</em> syn. <span class="ar long">تَفَتَّقَ بِهِ</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqr_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبقر</span></h3>
				<div class="sense" id="bqr_7_A1">
					<p><a href="#bqr_5">see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتقر</span></h3>
				<div class="sense" id="bqr_8_A1">
					<p><a href="#bqr_5">see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqr_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar"></span></h3>
				<div class="sense" id="bqr_QQ1_A1">
					<p><a href="#bqr_1">see 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqr_QQ2">
				<h3 class="entry">Q. Q. 2. ⇒ <span class="ar"></span></h3>
				<div class="sense" id="bqr_QQ2_A1">
					<p><a href="#bqr_5">see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqarN">
				<h3 class="entry"><span class="ar">بَقَرٌ</span></h3>
				<div class="sense" id="baqarN_A1">
					<p><span class="ar">بَقَرٌ</span> a gen. n., <span class="auth">(Ṣ, Mṣb,)</span> a word of well-known meaning, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <span class="add">[The <em>bovine genus;</em> the <em>ox,</em> or <em>bull,</em> and <em>cow;</em> and <em>oxen,</em> or <em>bulls,</em> and <em>cows; neat; black cattle;</em>]</span> applied to the <em>domestic</em> and the <em>wild:</em> <span class="auth">(TA:)</span> <span class="add">[but the wild have also distinctive appellations, as will be seen below:]</span> n. un. <span class="ar">بَقَرَةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, <span class="add">[but in the Ḳ it is said that <span class="ar">بَقَرٌ</span> <a href="#baqarapN">is pl. of <span class="ar">بَقَرَةٌ</span></a>,]</span>)</span> which is applied to the <em>male</em> and the <em>female;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> the <span class="ar">ة</span> being added only to restrict it to unity: <span class="auth">(Ṣ, Mṣb:)</span> <a href="#baqarN">the pl. of <span class="ar">بَقَرٌ</span></a> is <span class="ar">أَبْقُرٌ</span> <span class="add">[a pl. of pauc.]</span>; <span class="auth">(M,)</span> and <span class="ar">أَبْقَارٌ</span>, meaning <em>herds of oxen,</em> or <em>bulls,</em> or <em>cows:</em> <span class="auth">(Mṣb and TA in art. <span class="ar">ابل</span>:)</span> and <a href="#baqarapN">the pl. of <span class="ar">بَقَرَةٌ</span></a> is <span class="ar">بَقَرَاتٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بُقُرٌ</span> and <span class="ar">بُقَّارٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بَوَاقِرُ</span> <span class="auth">(Aṣ, T, Ḳ)</span> and<span class="arrow"><span class="ar">أُبْقُورٌ↓</span></span>; <span class="auth">(Ḳ;)</span> <span class="add">[or rather this last is a quasi-pl. n.;]</span> and the following <span class="add">[also]</span> are quasi-pl. ns., namely, <span class="arrow"><span class="ar">بَيْقُورٌ↓</span></span>, <span class="auth">(Ḳ,)</span> which is syn. with <span class="ar">بَقَرٌ</span>, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">بَقِيرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> or this signifies <em>a collection,</em> or <em>herd, of</em> <span class="ar">بَقَر</span>, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">بَاقِرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> or this signifies <em>a collection,</em> or <em>herd, of</em> <span class="ar">بَقَر</span> <em>with their pastors,</em> <span class="auth">(Lth, Ṣ,)</span> and<span class="arrow"><span class="ar">بَاقُورٌ↓</span></span>, and<span class="arrow"><span class="ar">بَاقُورَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> or this last is syn. with <span class="ar">بَقَرَةٌ</span> in the dial. of the people of El-Yemen: <span class="auth">(Ṣ:)</span> or<span class="arrow"><span class="ar">بَاقُورٌ↓</span></span> and<span class="arrow"><span class="ar">يَبْقُورٌ↓</span></span> and<span class="arrow"><span class="ar">أُبْقُورٌ↓</span></span> are all syn. with <span class="ar">بَقَرٌ</span>; and so, accord. to Ḳṭr, is <span class="arrow"><span class="ar">بَاقُورَةٌ↓</span></span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqarN_A2">
					<p><span class="ar long">بَقَرُ الوَحْشِ</span> <span class="add">[and <span class="ar long">البَقَرُ الوَحْشِىُّ</span> signify <em>The wild ox,</em> or <em>bull,</em> and <em>cow;</em> and <em>wild oxen,</em> or <em>bulls,</em> and <em>cows,</em> collectively: n. un. <span class="ar long">بَقَرَةُ الوَحْشِ</span> and <span class="ar long">البَقَرَةُ الوَحْشِيَّةُ</span>; masc. and fem.: in Egypt, these appellations are applied to the <em>antilope defassa</em> of modern zoologists: so says Sir Gardner Wilkinson; and to this, I believe, they generally apply in the poems, &amp;c. of the early Arabs: it is <em>a species of bovine antelope:</em> in Barbary, it seems that the animal thus called is another species of bovine antelope, or perhaps a variety of the former; it is said to be what is termed by Pallas <em>antilope bubalis;</em> by others, <em>alcephalus bubalis,</em> or <em>acronotus bubalis;</em> and this is said to come occasionally to the Nile: but the Arabic appellations given above are employed with much laxity: thus we find <span class="ar long">بَقَرُ الوَحْشِ</span> explained as meaning]</span> <em>a kind of animal of which there are four different species: the first called</em> <span class="ar">مِهِا</span> <span class="add">[i. e. <span class="ar">مَهًا</span>, a coll. gen. n. of which the n. un. is <span class="ar">مَهَاةٌ</span>]</span>; <em>the second,</em> <span class="ar">ايل</span> <span class="add">[i. e. <span class="ar">إِيَّلٌ</span>]</span>; <em>the third</em> <span class="ar">يحمور</span> <span class="add">[i. e. <span class="ar">يَحْمُورٌ</span>]</span>, or <span class="ar">يامور</span> <span class="add">[i. e. <span class="ar">يَأْمُورٌ</span>]</span>; <em>the fourth,</em> <span class="ar">ثيثل</span> <span class="add">[or <span class="ar">ثَيْتَلٌ</span>]</span>, <em>and also</em> <span class="ar">وعل</span> <span class="add">[i. e. <span class="ar">وَعْلٌ</span>]</span>: <span class="auth">(Ed-Demeeree, cited by De Sacy, erroneously written by him “Domaïri,” in his Chrest. Ar. sec. ed. ii. 435 et seq.:)</span> or <em>what is called in Persian</em> <span class="fa">كوزن</span> <span class="add">[or <span class="fa">گَوَزْنْ</span> (<a href="#IiyBalN">see also <span class="ar">إِيَّلٌ</span></a> <a href="index.php?data=01_A/163_Awl">in art. <span class="ar">اول</span></a>)]</span>; <em>it has a great horn, with branches; an additional branch growing upon its horn every year; and its horn is solid, thus differing from the horns of other animals, for their horns are hollow: when it hears singing, and the sounds of musical instruments, it listens thereto, and then it takes no care to guard itself from the arrows, by reason of its intense delight therein: when it raises its ear, it hears sounds; and when it relaxes it, it hears not anything.</em> <span class="auth">(Ḳzw: also cited by De Sacy, ubi suprà.)</span> The Arabs regard <span class="ar">بَقَر</span> <span class="add">[meaning <span class="ar long">بقر الوحش</span>]</span> as ominous of evil, because of the sharpness of their horns. <span class="auth">(Ḥam p. 285.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baqarN_A3">
					<p><span class="ar long">مِلْءُ مَسْكِ البَقَرَةِ</span> <span class="add">[<em>The quantity that fills the hide of the bull,</em> or <em>cow,</em>]</span> means ‡ <em>a large quantity.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baqarN_A4">
					<p><span class="ar long">الظِّبَآءَ عَلَى البَقَرِ</span> <span class="add">[or <span class="ar">الظِّبَآءُ</span>]</span> and <span class="ar long">الكِرَابَ عَلَى البَقَرِ</span> <span class="add">[or <span class="ar">الكِرَابُ</span>, and <span class="ar">الكِلَابَ</span> or <span class="ar">الكِلَابُ</span>,]</span> are provs. of the Arabs. <span class="auth">(TA.)</span> <span class="add">[See arts. <span class="ar">ظبى</span> and <span class="ar">كرب</span> and <span class="ar">كلب</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baqarN_A5">
					<p><span class="ar long">عَيْنُ البَقَرِ</span> † <span class="add">[<em>The buphthalmum,</em> or <em>ox-eye;</em>]</span> <em>i. q.</em> <span class="ar">بَهَارٌ</span>, q. v. <span class="auth">(Ṣ in art. <span class="ar">بهر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baqarN_A6">
					<p><span class="ar long">عُيُونُ البَقَرِ</span> ‡ <em>A species of grape, black, large, round, and not very sweet.</em> <span class="auth">(Ḳ, TA.)</span> In Palestine, applied to ‡ <em>A species of</em> <span class="ar">إِجَّاص</span> <span class="add">[or <em>plum</em>]</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baqarN_A7">
					<p><span class="ar">بَقَرٌ</span> is also applied to ‡ <em>A family,</em> or <em>household; those who dwell with a man, and whose maintenance is incumbent on him.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">جَاءَ فُلَانٌ يَجُرُّ بَقَرَهُ</span> ‡ <em>Such a one came dragging along his family,</em> or <em>household.</em> <span class="auth">(A,* TA.)</span> And <span class="ar long">عَلَى فُلَانٍ بَقَرَةٌ مِنْ عِيَالٍ وَمَالٍ</span> ‡ <em>Upon such a one is dependent a troop,</em> or <em>large number, of his family, and of camels</em> or <em>the like;</em> <span class="auth">(A,* TA;)</span> and in like manner you say, <span class="ar long">كَرِشٌ مِنْ عِيَالٍ</span>. <span class="auth">(A.)</span> And <span class="ar long">فُلَانٌ فِى بَقَرٍ مِنَ النَّاسِ</span> ‡ <em>Such a one is among a large company of men.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqiyrN">
				<h3 class="entry"><span class="ar">بَقِيرٌ</span></h3>
				<div class="sense" id="baqiyrN_A1">
					<p><span class="ar">بَقِيرٌ</span> <em>Slit; ripped; split; cut,</em> or <em>divided, lengthwise;</em> as also<span class="arrow"><span class="ar">مَبْقُورٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqiyrN_A2">
					<p>A she-camel <em>having her belly ripped open so as to disclose her fœtus.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baqiyrN_A3">
					<p>A mare's colt or foal <em>that is born in a</em> <span class="add">[<em>membrane such as is called</em>]</span> <span class="ar">مَاسِكَةٌ</span> or <span class="ar">سَلًى</span>: <span class="auth">(Ḳ:)</span> so termed because this is ripped open over it. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baqiyrN_A4">
					<p>Also, and<span class="arrow"><span class="ar">بَقِيرَةٌ↓</span></span>, <em>A garment of the kind called</em> <span class="ar">بُرْد</span>, <em>which is slit</em> <span class="add">[<em>in the middle</em>]</span>, <em>and worn</em> <span class="auth">(Aṣ, Ḳ)</span> <em>by a woman, who throws it upon her neck,</em> <span class="add">[<em>putting her head through the slit,</em>]</span> <span class="auth">(Aṣ,)</span> <em>without sleeves,</em> <span class="auth">(Aṣ, Ḳ,)</span> <em>and without a</em> <span class="ar">جَيْبٍ</span> <span class="add">[or <em>an opening at the bosom</em>]</span>; <span class="auth">(Aṣ;)</span> <em>i. q.</em> <span class="ar">إِتْبٌ</span> <span class="add">[q. v.]</span>, which is <em>a kind of shirt without sleeves, worn by women.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقِيرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baqiyrN_B1">
					<p><a href="#baqarN">See also <span class="ar">بَقَرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqiyrapN">
				<h3 class="entry"><span class="ar">بَقِيرَةٌ</span></h3>
				<div class="sense" id="baqiyrapN_A1">
					<p><span class="ar">بَقِيرَةٌ</span>: <a href="#baqiyrN">see <span class="ar">بَقِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqBaArN">
				<h3 class="entry"><span class="ar">بَقَّارٌ</span></h3>
				<div class="sense" id="baqBaArN_A1">
					<p><span class="ar">بَقَّارٌ</span> <em>A grave-digger;</em> syn. <span class="ar">حَفَّارٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَّارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqBaArN_A2">
					<p><em>A worker in iron; a blacksmith.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">بَقَّارٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baqBaArN_B1">
					<p><em>An owner,</em> or <em>a possessor,</em> <span class="add">[or <em>an attendant,</em>]</span> <em> of</em> <span class="ar">بَقَر</span> <span class="add">[or <em>oxen,</em> or <em>bulls,</em> or <em>cows</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqBaAriyBapN">
				<h3 class="entry"><span class="ar">بَقَّارِيَّةٌ</span></h3>
				<div class="sense" id="baqBaAriyBapN_A1">
					<p><span class="ar long">عَصًا بَقَّارِيَّةٌ</span> <em>A strong staff</em> or <em>stick</em> <span class="add">[<em>such,</em> app., <em>as is used for driving oxen or bulls or cows</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaAqiru">
				<h3 class="entry"><span class="ar">البَاقِرُ</span></h3>
				<div class="sense" id="AlbaAqiru_A1">
					<p><span class="ar">البَاقِرُ</span> <em>The lion:</em> <span class="auth">(Ḳ:)</span> because, when he catches his prey, he rips open his belly. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">البَاقِرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlbaAqiru_A2">
					<p><span class="ar">بَاقِرٌ</span> and<span class="arrow"><span class="ar">بَاقرَةٌ↓</span></span>, <span class="add">[the latter an intensive epithet,]</span> A man <em>who inquires, and searches to the utmost, after sciences.</em> <span class="auth">(A.)</span> And <span class="ar long">بَاقِرُ عِلْمٍ</span> One <em>who enlarges himself,</em> or <em>takes a wide range, in science,</em> or <em>knowledge.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">البَاقِرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AlbaAqiru_A3">
					<p><span class="ar long">فِتْنَةٌ بَاقِرَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> occurring in a trad., <span class="auth">(TA,)</span> † <em>A sedition, discord, dissension,</em> or <em>the like, that severs society;</em> <span class="auth">(Ḳ;)</span> <em>that corrupts religion, and separates men:</em> or <em>that is wide-spreading and great:</em> <span class="auth">(TA:)</span> it is likened to the disease of the belly; meaning the yellow water or fluid: <span class="auth">(Ṣ:)</span> or to pain of the belly; because its exciting cause and its cure are unknown. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقر</span> - Entry: <span class="ar">البَاقِرُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AlbaAqiru_B1">
					<p><a href="#baqarN">See also <span class="ar">بَقَرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAqirapN">
				<h3 class="entry"><span class="ar">بَاقِرَةٌ</span></h3>
				<div class="sense" id="baAqirapN_A1">
					<p><span class="ar">بَاقِرَةٌ</span>: <a href="#baAqirN">see <span class="ar">بَاقِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoqarapN">
				<h3 class="entry"><span class="ar">بَيْقَرَةٌ</span></h3>
				<div class="sense" id="bayoqarapN_A1">
					<p><span class="ar">بَيْقَرَةٌ</span> <em>Abundance of wealth,</em> or <em>of camels</em> or <em>the like,</em> and <em>of commodities,</em> or <em>household goods</em> or <em>utensils and furniture.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAquwrN">
				<h3 class="entry"><span class="ar">بَاقُورٌ</span></h3>
				<div class="sense" id="baAquwrN_A1">
					<p><span class="ar">بَاقُورٌ</span>: <a href="#baqarN">see <span class="ar">بَقَرٌ</span></a>; in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayoquwrN">
				<h3 class="entry"><span class="ar">بَيْقُورٌ</span></h3>
				<div class="sense" id="bayoquwrN_A1">
					<p><span class="ar">بَيْقُورٌ</span>: <a href="#baqarN">see <span class="ar">بَقَرٌ</span></a>; in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAquwrapN">
				<h3 class="entry"><span class="ar">بَاقُورَةٌ</span></h3>
				<div class="sense" id="baAquwrapN_A1">
					<p><span class="ar">بَاقُورَةٌ</span>: <a href="#baqarN">see <span class="ar">بَقَرٌ</span></a>; in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuboquwrN">
				<h3 class="entry"><span class="ar">أُبْقُورٌ</span></h3>
				<div class="sense" id="OuboquwrN_A1">
					<p><span class="ar">أُبْقُورٌ</span>: <a href="#baqarN">see <span class="ar">بَقَرٌ</span></a>; each in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboquwrN">
				<h3 class="entry"><span class="ar">مَبْقُورٌ</span></h3>
				<div class="sense" id="maboquwrN_A1">
					<p><span class="ar">مَبْقُورٌ</span>: <a href="#baqiyrN">see <span class="ar">بَقِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0233.pdf" target="pdf">
							<span>Lanes Lexicon Page 233</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0234.pdf" target="pdf">
							<span>Lanes Lexicon Page 234</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
