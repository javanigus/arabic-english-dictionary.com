<article class="root" id="Root_bwE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/221_bwX">بوش</a></span>
				<span class="ar">بوع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/223_bwq">بوق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوع</span> ⇒ <span class="ar">باع</span></h3>
				<div class="sense" id="bwE_1_A1">
					<p><span class="ar">بَاعَ</span>, <span class="auth">(Ṣ, TA,)</span> aor. <span class="ar">يَبُوعُ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَوْعٌ</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>He extended his arms to their full reach;</em> expl. by <span class="ar long">بَسَطَ بَاعَهُ</span>; <span class="auth">(TA;)</span> and the inf. n. by <span class="ar long">مَدُّ البَاعِ</span>; with a thing; as also<span class="arrow"><span class="ar">تبوّع↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwE_1_A2">
					<p><em>He</em> <span class="auth">(a camel)</span> <em>stretched forth his fore legs to the full</em> (<span class="ar long">مَدَّ أَبْوَاعَهُ</span>); as also<span class="arrow"><span class="ar">تبوّع↓</span></span>; and in like manner a gazelle: <span class="auth">(TA:)</span> and <em>he</em> <span class="auth">(a horse)</span> <em>stepped far,</em> or <em>took long steps,</em> in his running; <span class="auth">(Ṣ, Ḳ;)</span> and in like manner one says <span class="add">[<span class="ar">بَاعَت</span>]</span> of a she-camel. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">مَرَّ يَبُوعُ</span>, and<span class="arrow"><span class="ar">يَتَبَوَّعُ↓</span></span>, <em>He went along stretching forth his fore-legs to the full extent of his step.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwE_1_A3">
					<p><span class="ar long">بَاعَ بِالمَالِ</span>, aor. <span class="ar">يَبُوعُ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَوْعٌ</span>, <span class="auth">(Lth, Ḳ,)</span> <em>He extended his arm,</em> or <em>hand,</em> <span class="add">[<em>liberally,</em> or <em>bountifully,</em>]</span> <em>with the property.</em> <span class="auth">(Lth, Ḳ, TA.)</span> You say also, <span class="ar long">بُعْ بُعْ</span>, meaning † <em>Stretch forth thine arms,</em> or <em>hands,</em> (<span class="ar long">بَا عَيْكَ</span>,) <em>in acts of obedience to God.</em> <span class="auth">(IAạr.)</span> And<span class="arrow"><span class="ar long">تَبَوَّعَ↓ لِلْمَسَاعِى</span></span> ‡ <em>He stretched forth his arms</em> (<span class="ar long">مَدَّ بَاعَهُ</span>) <span class="add">[<em>to attain means of honour and elevation</em>]</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">مَا يُدْرَكُ تَبَوُّعُهُ↓</span></span> † <em>The point to which he has reached is not to be attained:</em> <span class="auth">(Ḳ, TA:)</span> and, as Lḥ says, <span class="arrow"><span class="ar long">لَا تَبْلُغُونَ تَبَوُّعَهُ↓</span></span> † <em>Ye will not,</em> or <em>shall not, reach the point to which he has attained:</em> originally, his length of step. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwE_1_A4">
					<p><span class="arrow"><span class="ar long">إِذَا بَاعَ ٱنْبَاعَ↓</span></span> <em>When he accomplishes his want, he goes away.</em> <span class="auth">(Ḥar p. 592.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwE_1_B1">
					<p><span class="ar long">بَاعَ الحَبْلَ</span>, <span class="auth">(Mṣb, TA,)</span> first pers. <span class="ar">بُعْتُهُ</span>, <span class="auth">(Ṣ,)</span> aor. and inf. n. as above, <span class="auth">(Ṣ, Mṣb, TA,)</span> <em>He measured the rope by the</em> <span class="ar">باع</span> <span class="add">[or <em>fathom</em>]</span>; <span class="auth">(Mṣb;)</span> <em>he extended his</em> <span class="ar">باع</span> <span class="add">[or <em>arms stretched to the full reach</em>]</span> <em>with the rope;</em> <span class="auth">(Ṣ;)</span> or <em>he extended the rope with his</em> <span class="ar">باع</span>; or, which is nearly the same in meaning, <em>he extended his arms with the rope until it became a</em> <span class="ar">باع</span> <span class="add">[or <em>fathom in measure</em>]</span>; <span class="auth">(TA;)</span> like as you say, <span class="ar">شَبَرْتُهُ</span> from <span class="ar">الشِّبْرُ</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bwE_1_B2">
					<p><span class="add">[And hence,]</span> <span class="ar long">يَبُوعُ الأَرْضَ</span> <em>He traverses the ground with wide step and quick motion.</em> <span class="auth">(Ḥam p. 720.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bwE_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبوّع</span></h3>
				<div class="sense" id="bwE_5_A1">
					<p><a href="#bwE_1">see 1</a>, in six places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwE_5_A2">
					<p><a href="#bwE_7">and see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwE_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبوع</span> ⇒ <span class="ar">انباع</span></h3>
				<div class="sense" id="bwE_7_A1">
					<p><span class="ar">انباع</span> and<span class="arrow"><span class="ar">تبوّع↓</span></span>, said of a rope, signify the same <span class="add">[app. <em>It was measured by the</em> <span class="ar">باع</span>, or <em>fathom</em>]</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwE_7_A2">
					<p><span class="ar long">انباعت الحَيَّةُ</span> <em>The serpent extended itself, after gathering itself together and coiling itself, in order to spring.</em> <span class="auth">(Lḥ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwE_7_A3">
					<p>Also <span class="ar">انباع</span>, said of a man, <em>He leaped,</em> or <em>sprang, after being still:</em> or <em>he made an assault;</em> or <em>leaped,</em> or <em>sprang, and made a violent seizure.</em> <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">مُخْرَنْبِقٌ لِيَنْبَاعَ</span> <em>Silent in order to leap,</em> or <em>spring,</em> <span class="auth">(Ḳ, and Ṣ in art. <span class="ar">خربق</span>,)</span> <em>when he finds an opportunity;</em> <span class="auth">(Ṣ in that art.;)</span> <em>on account of a misfortune which he desires</em> <span class="add">[<em>to effect</em>]</span>; <span class="auth">(Ṣ, Ḳ, in that art.;)</span> or <em>in order to make an assault:</em> <span class="auth">(TA:)</span> or <em>looking,</em> or <em>waiting, for an opportunity to leap,</em> or <em>spring, upon his enemy,</em> or <em>the object of his want, when able to do so;</em> and in like manner, <span class="ar long">مُخْرَنْطِمٌ لِيَنْبَاعَ</span>: <span class="auth">(TA in art. <span class="ar">خربق</span>:)</span> a prov., <span class="auth">(Ḳ,)</span> applied to a man who is silent respecting a misfortune <span class="add">[which he desires to effect]</span>; <span class="auth">(TA;)</span> or applied to a man who is long silent until he thinks his object inadvertent, and who is possessed of cunning: <span class="auth">(Aṣ, TA in art. <span class="ar">خربق</span>:)</span> accord. to one relation, <span class="ar">لِيَنْبَاقَ</span>, i. e. to bring about, or effect, a <span class="ar">بَائِقَة</span>, meaning a calamity, or misfortune: <span class="auth">(Ḳ:)</span> or <span class="ar">لينباع</span> may be for <span class="ar">لَيْنَبَع</span>, from <span class="ar long">نَبَعَ المَآءُ</span>. <span class="auth">(Ḥar p. 62.)</span> <span class="add">[Hence also,]</span> <span class="ar long">انباع الشُّجَاعُ مِنَ الصَّفِّ</span> <em>The courageous man went,</em> or <em>came, out,</em> or <em>forth, from the rank.</em> <span class="auth">(AAF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwE_7_A4">
					<p><span class="ar long">انباع لِى فِى سِلْعَتِهِ</span> <em>He treated me in an easy manner in the sale of his commodity,</em> or <em>article of merchandise, and strained himself</em> (<span class="ar">اِمْتَدَّ</span>) <em>to give his consent to it.</em> <span class="auth">(Ḳ, TA.)</span> And hence,<span class="arrow"><span class="ar">اِنْبَيَاعٌ↓</span></span>, as used by Sakhrel-Ghei in describing the conduct of a man towards a beautiful woman, or, accord. to one relation, <span class="arrow"><span class="ar">اِبْتِيَاعٌ↓</span></span>, The <em>acting,</em> or <em>behaving,</em> towards another, <em>boldly, in a free and easy manner,</em> or <em>without shyness;</em> syn. <span class="ar">اِنْبِسَاطٌ</span>; as also <span class="ar">بَيْعٌ</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bwE_7_A5">
					<p><span class="ar">انباع</span> also signifies <em>He ran in a gentle manner, with a bending and a twisting of himself;</em> from <span class="ar">بَاعَ</span>, aor. <span class="ar">يَبُوعُ</span>. <span class="auth">(Aḥmad Ibn-ʼObeyd.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bwE_7_A6">
					<p><em>And he went away.</em> <span class="auth">(Ḥar p. 592: <a href="#bwE_1">see 1</a>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bwE_7_A7">
					<p>And <em>It</em> <span class="auth">(sweat)</span> <em>flowed:</em> <span class="auth">(Mṣb, Ḳ:)</span> or, as El-Fárábee says, <em>extended.</em> <span class="auth">(Mṣb.)</span> 'Antarah says, describing the sweat of a she-camel,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَنْبَاعُ مِنْ ذِفْرَى غَضُوبٍ جَسْرَةٍ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Flowing,</em> or <em>extending, from the part behind the ear of a she-camel quickly angered, spirited,</em> or <em>tall,</em> or <em>tall and bulky,</em> or <em>strong, and bold to endure travel</em>]</span>: <span class="pb" id="Page_0276"></span><span class="ar">ينباع</span> being originally <span class="ar">يَنْبَوِعُ</span>; or, as most of the lexicologists say, originally <span class="ar">يَنْبَعُ</span>, the <span class="ar">ا</span> being inserted after the fet-ḥah of the <span class="ar">ب</span> to render its sound full. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bwE_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتوع</span> ⇒ <span class="ar">ابتاع</span></h3>
				<div class="sense" id="bwE_8_A1">
					<p><span class="ar">اِبْتِيَاعٌ</span>: <a href="#bwE_7">see 7</a>, in the latter half of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAEN">
				<h3 class="entry"><span class="ar">بَاعٌ</span></h3>
				<div class="sense" id="baAEN_A1">
					<p><span class="ar">بَاعٌ</span> <em>A fathom;</em> the <em>space that is between</em> <span class="add">[<em>the extremities of</em>]</span> <em>the two hands when they are extended to the right and left;</em> <span class="auth">(Mṣb;)</span> the <em>measure of the extension of the two arms</em> <span class="auth">(Ṣ, Ḳ, TA)</span> <em>with what is between them of the body;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَوْعٌ↓</span></span> and<span class="arrow"><span class="ar">بُوعٌ↓</span></span>; <span class="auth">(Ḳ;)</span> the last of the dial. of Hudheyl: <span class="auth">(TA:)</span> said by AḤát to be of the masc. gender: <span class="auth">(Mṣb:)</span> pl. <span class="ar">أَبْوَاعٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بِيعَانٌ</span>. <span class="auth">(Ḥam p. 475.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: <span class="ar">بَاعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAEN_A2">
					<p><span class="add">[And hence,]</span> † The <em>body, including the limbs;</em> <span class="add">[because a fathom in height;]</span> as in the phrase <span class="ar long">رَجُلٌ طَوِيلُ البَاعِ</span> † <em>A man tall in the body;</em> which has also another meaning, to be seen below: but you do not say, <span class="ar long">قَصِيرُ البَاعِ</span> as meaning short in the body. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: <span class="ar">بَاعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAEN_A3">
					<p><span class="add">[Also The <em>arms;</em> and particularly <em>when extended to their full reach;</em> as also the pl.: and in like manner, the <em>fore legs</em> of a beast: see several examples in the first paragraph of this art.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: <span class="ar">بَاعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAEN_A4">
					<p><span class="add">[And hence, ‡ <em>Reach; power;</em> or <em>ability.</em>]</span> You say, <span class="ar long">هُوَ قَصِيرُ البَاعِ</span> ‡ <em>He is lacking in power,</em> or <em>ability:</em> a phrase which has also another meaning, to be seen below. <span class="auth">(TA.)</span> And <span class="ar long">قَصُرَ بَاعُهُ عَنْ ذٰلِكَ</span> ‡ <em>He was unable to attain,</em> or <em>to do,</em> or <em>effect, that:</em> in this case, <span class="arrow"><span class="ar">بوع↓</span></span> is not used. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: <span class="ar">بَاعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAEN_A5">
					<p>And ‡ <em>Reach, power,</em> or <em>ability, in the means,</em> or <em>causes, of attaining honour;</em> or <em>in generous,</em> or <em>honourable, qualities</em> or <em>actions:</em> <span class="auth">(TA:)</span> ‡ <em>eminence; nobility; honour; generosity:</em> <span class="auth">(Lth, Ṣ, Ḳ:)</span> in which senses, <span class="arrow"><span class="ar">بوع↓</span></span> is not used. <span class="auth">(Lth.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَهُ فِى المَجْدِ سَابِقَةٌ وَبَاعُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>He has precedence and eminence in glory, honour, dignity,</em> or <em>nobility</em>]</span>. <span class="auth">(Lth.)</span> And <span class="ar long">رَجُلٌ طَوِيلُ البَاعِ</span> ‡ <em>A man of large generosity.</em> <span class="auth">(TA.)</span> And <span class="ar long">قَصِيرُ البَاعِ</span> ‡ <em>Niggardly:</em> a phrase which has also another meaning, mentioned above. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawoEN">
				<h3 class="entry"><span class="ar">بَوْعٌ</span></h3>
				<div class="sense" id="bawoEN_A1">
					<p><span class="ar">بَوْعٌ</span> and <span class="ar">بُوعٌ</span>: <a href="#baAEN">see <span class="ar">بَاعٌ</span></a>, in four places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوع</span> - Entry: <span class="ar">بَوْعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bawoEN_B1">
					<p>The former also signifies <em>A place that is broken,</em> or <em>crushed,</em> (<span class="ar long">مَكَانٌ مُنْهَضِمُ</span>,) <em>in a small ravine</em> (<span class="ar">لِصْب</span>) <em>of a mountain.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAEapN">
				<h3 class="entry"><span class="ar">بَاعَةٌ</span></h3>
				<div class="sense" id="baAEapN_A1">
					<p><span class="ar">بَاعَةٌ</span> The <em>court</em> (<span class="ar">سَاحَة</span>) of a house: <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> <a href="#baAHapN">a dial. var. of <span class="ar">بَاحَةٌ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawBaAEN">
				<h3 class="entry"><span class="ar">بَوَّاعٌ</span></h3>
				<div class="sense" id="bawBaAEN_A1">
					<p><span class="ar">بَوَّاعٌ</span> † A <em>large-bodied</em> camel. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYiEN">
				<h3 class="entry"><span class="ar">بَائِعٌ</span></h3>
				<div class="sense" id="baAYiEN_A1">
					<p><span class="ar">بَائِعٌ</span> <em>A young gazelle that stretches forth its fore legs to the full</em> (<span class="ar">يَبُوعُ</span>) <em>in going along:</em> <span class="auth">(Ḳ, TA:)</span> an epithet in which the quality of a subst. is predominant: <span class="auth">(TA:)</span> pl. <span class="ar">بُوعٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بَوَائِعُ</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar">أَبْوَاعُ↓</span></span>, a determinate noun, is applied to <em>The ewe,</em> because she does so in going along: and she is called to be milked thereby; <span class="auth">(Ibn-ʼAbbád, Ḳ;)</span> by saying, <span class="ar long">أَبْوَاعُ أَبْوَاعُ</span>. <span class="auth">(Ibn-ʼAbbád.)</span> You say also <span class="ar long">نَاقَةٌ بَائِعَةُ</span> <em>A she-camel that steps far,</em> or <em>takes long steps:</em> pl. <span class="ar">بَوَائِعُ</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">فَرَسٌ بَيِّعٌ↓</span></span>, <span class="auth">(Ḳ,)</span> originally <span class="ar">بَيْوِعٌ</span>, <span class="auth">(TA,)</span> <em>A horse that steps far,</em> or <em>takes long steps.</em> <span class="auth">(Z, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayBiEN">
				<h3 class="entry"><span class="ar">بَيِّعٌ</span></h3>
				<div class="sense" id="bayBiEN_A1">
					<p><span class="ar">بَيِّعٌ</span>: <a href="#baAyiEN">see <span class="ar">بَائِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabowaAEu">
				<h3 class="entry"><span class="ar">أَبْوَاعُ</span></h3>
				<div class="sense" id="OabowaAEu_A1">
					<p><span class="ar">أَبْوَاعُ</span>: <a href="#baAyiEN">see <span class="ar">بَائِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="munobaAEN">
				<h3 class="entry"><span class="ar">مُنْبَاعٌ</span></h3>
				<div class="sense" id="munobaAEN_A1">
					<p><span class="ar">مُنْبَاعٌ</span> Anything <em>that flows;</em> or <em>extends:</em> <span class="auth">(Mṣb:)</span> anything <em>sweating,</em> or <em>exuding sweat.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0275.pdf" target="pdf">
							<span>Lanes Lexicon Page 275</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0276.pdf" target="pdf">
							<span>Lanes Lexicon Page 276</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
