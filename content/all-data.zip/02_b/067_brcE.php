<article class="root" id="Root_brcE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/066_brdE">بردع</a></span>
				<span class="ar">برذع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/068_brcn">برذن</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="barocaEN">
				<h3 class="entry"><span class="ar">بَرْذَعٌ</span></h3>
				<div class="sense" id="barocaEN_A1">
					<p><span class="ar">بَرْذَعٌ</span>: <a href="#barocaEapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barocaEapN">
				<h3 class="entry"><span class="ar">بَرْذَعَةٌ</span></h3>
				<div class="sense" id="barocaEapN_A1">
					<p><span class="ar">بَرْذَعَةٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بَرْدَعَةٌ</span> <span class="auth">(Mṣb, Ḳ)</span> <em>A</em> <span class="add">[<em>cloth of the kind called</em>]</span> <span class="ar">حِلْس</span> <em>which is put beneath the</em> <span class="add">[<em>saddle called</em>]</span> <span class="ar">رَحْل</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> <em>of the camel:</em> <span class="auth">(Mgh:)</span> pl. <span class="ar">بَرَاذِعُ</span> <span class="auth">(Mgh, Mṣb)</span> and <span class="ar">بَرَادِعُ</span> <span class="auth">(Mṣb.)</span> Ru-beh says, <span class="add">[using the sing. without the <span class="ar">ة</span> as a coll. gen. n.,]</span></p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">وَتَحْتَ أَحْنَآءِ الرِّحَالِ البَرْذَعُ↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And beneath the curved pieces of wood of the camels' saddles are the bardha'ahs</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برذع</span> - Entry: <span class="ar">بَرْذَعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barocaEapN_A2">
					<p>This is the primary signification: but in the conventional language of our time, it is applied to <em>An ass's saddle; the thing upon which one rides on an ass, like the</em> <span class="ar">سَرْج</span> <em>to the horse;</em> <span class="auth">(Mṣb;)</span> <span class="add">[i. e. <em>a pad,</em> or <em>stuffed saddle; generally stuffed with straw; and used for a mule as well as for an ass;</em>]</span> or an ass's <span class="ar">برذعة</span> is <em>a saddle like the</em> <span class="ar">رَحْل</span> <em>and</em> <span class="ar">قَتَب</span>. <span class="auth">(TA voce <span class="ar">إِكَافٌ</span>, q. v.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برذع</span> - Entry: <span class="ar">بَرْذَعَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barocaEapN_B1">
					<p><span class="ar">بَرْذَعَةٌ</span> also signifies <em>Land which is neither hard nor soft:</em> <span class="auth">(Ḳ:)</span> pl. as above. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraAciEieBN">
				<h3 class="entry"><span class="ar">بَرَاذِعِىٌّ</span></h3>
				<div class="sense" id="baraAciEieBN_A1">
					<p><span class="ar">بَرَاذِعِىٌّ</span> <em>A maker of</em> <span class="ar">بَرَاذِعُ</span>, <a href="#barocaEapN">pl. of <span class="ar">بَرْذَعَةٌ</span></a>: a rel. n. similar to <span class="ar">أَنْمَاطِىٌّ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0186.pdf" target="pdf">
							<span>Lanes Lexicon Page 186</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
