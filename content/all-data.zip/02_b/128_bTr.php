<article class="root" id="Root_bTr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/127_bTx">بطخ</a></span>
				<span class="ar">بطر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/129_bTrq">بطرق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطر</span></h3>
				<div class="sense" id="bTr_1_A1">
					<p><span class="ar">بَطِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْطَرُ</span>}</span></add>, inf. n. <span class="ar">بَطَرٌ</span>, <em>He exulted;</em> or <em>exulted greatly,</em> or <em>excessively; and behaved insolently and unthankfully,</em> or <em>ungratefully:</em> or <em>he exulted by reason of wealth, and behaved with pride and self-conceitedness, and boastfulness, and want of thankfulness:</em> or <em>he behaved with the utmost exultation,</em>, &amp;c.: or <em>he rejoiced, and rested his mind upon things agreeable with natural desire:</em> syn. of the inf. n. <span class="ar">أَشَرٌ</span>, <span class="auth">(Ṣ, A, L, Mṣb, TA,)</span> and <span class="ar">مَرَحٌ</span>; <span class="auth">(L, TA;)</span> the former of which signifies <span class="ar long">شِدَّةٌ المَرَحِ</span>, <span class="auth">(Ṣ, A,)</span> and <span class="ar long">مُجَاوَزَةُ الحَدِّ فِى مَرَحٍ</span>: <span class="auth">(A:)</span> <em>he was,</em> or <em>became, stupified, deprived of his reason, confounded,</em> or <em>amazed,</em> <span class="auth">(Ṣ, Ḳ, Er-Rághib,)</span> <em>bearing wealth ill,</em> or <em>in an evil manner, performing little of the duty imposed on him by it, and turning it to a wrong purpose:</em> <span class="auth">(Er-Rághib, TA,* TḲ:)</span> this is said to be the primary signification: <span class="auth">(TA:)</span> <em>he was,</em> or <em>became, stupified, or confounded, and knew not what to prefer nor what to postpone:</em> <span class="auth">(TA:)</span> <em>he was,</em> or <em>became, confounded, perplexed,</em> or <em>amazed, by reason of fright:</em> <span class="auth">(Aṣ, Ṣ voce <span class="ar">بَحِرَ</span>:)</span> <em>he behaved exorbitantly,</em> or <em>insolently, with wealth,</em> <span class="auth">(Ḳ, TA,)</span> or <em>on the occasion of having wealth:</em> and this, also, is said to be the primary signification: <span class="auth">(TA:)</span> <em>he had,</em> or <em>exercised, little of the quality of bearing wealth</em> <span class="add">[<em>in a becoming,</em> or <em>proper, manner</em>]</span>: <span class="auth">(Ḳ:)</span> <em>he behaved proudly:</em> <span class="auth">(TA:)</span> <em>he regarded a thing with hatred,</em> or <em>dislike, without its deserving to be so regarded: he was,</em> or <em>became, brisk, lively,</em> or <em>sprightly:</em> <span class="auth">(Ḳ:)</span> accord. to some, <em>he walked with an elegant and a proud and self-conceited gait, with an affected inclining of the body from side to side.</em> <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">لَا يَنْظُرُ ٱللّٰهُ يَوْمَ القِيَامَةِ مَنْ جَرَّ إِزَارَهُ بَطَرًا</span> <span class="add">[<em>God will not look, on the day of resurrection, upon him who drags along his wrapper of the lower part of the body in exultation and insolence,</em> or <em>pride:</em> meaning one who wears too long a wrapper of the lower part of the body]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTr_1_A2">
					<p><span class="ar long">بَطِرْتَ عَيْشَكَ</span> ‡ <span class="add">[<em>Thou exultedst,</em> or <em>exultedst greatly,</em> or <em>excessively, and behavedst insolently and unthankfully,</em> or <em>ungratefully,</em>, &amp;c., <em>in thy manner of life,</em>]</span> is a phrase similar to <span class="ar long">رَشِدْتَ أَمْرَكَ</span>; <span class="auth">(Ṣ, TA;)</span> and in like manner <span class="ar long">بَطِرَتْ مَعِيشَتَهَا</span>, in the Ḳur <span class="add">[xxviii. 58]</span>; in which the verb is not trans., but the subst. is put in the accus. case because of <span class="ar">فِى</span> understood before it. <span class="auth">(Aboo-Is-ḥáḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTr_1_A3">
					<p><span class="ar long">لَا أَبْطَرُ الغِنَى</span> † <em>I do not,</em> or <em>will not, domineer,</em> or <em>assume superiority, over others when I am rich.</em> <span class="auth">(Ḥam p. 517.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTr_1_A4">
					<p><span class="ar long">بَطِرَ النِّعْمَةَ</span> ‡ <em>He held wealth,</em> or <em>the favour,</em> or <em>benefit, in light estimation, and was unthankful,</em> or <em>ungrateful, for it.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bTr_1_A5">
					<p><span class="ar long">بَطِرَ هِدَايَةَ أَمْرِهِ</span> † <em>He refused the right direction as to the management of his affair, and was ignorant of it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bTr_1_A6">
					<p>It is said in a trad., that pride is <span class="ar long">بَطَرُ الحَقِّ</span>, which <em>means ‡ The considering as false,</em> or <em>vain, what God has pronounced to be the truth,</em> or <em>our duty;</em> namely, the confession of his unity, and the obligation of rendering Him religious service: or <em>the being confounded at considering truth,</em> or <em>duty, and not seeing it to be true,</em> or <em>incumbent:</em> <span class="auth">(TA:)</span> or <em>the disdaining the truth,</em> or <em>right, and not accepting it</em> or <em>not admitting it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTr_1_B1">
					<p><span class="ar">بَطَرَهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُرُ</span>}</span></add> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْطِرُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَطْرٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He cut it,</em> or <em>divided it, lengthwise; slit it; split it.</em> <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> Hence the appellation <span class="ar">بَيْطَارٌ</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطر</span></h3>
				<div class="sense" id="bTr_4_A1">
					<p><span class="ar">ابطرهُ</span> <em>It rendered him such as is termed</em> <span class="ar">بَطِر</span>; <em>it</em> <span class="auth">(wealth)</span> <em>caused him to exult,</em> or <em>to exult greatly,</em> or <em>excessively, and to behave insolently and unthankfully,</em> or <em>ungratefully:</em>, &amp;c.: <span class="add">[<a href="#baTira">see <span class="ar">بَطِرَ</span></a>:]</span> <span class="auth">(Ṣ, A:)</span> <em>it stupified him, deprived him of his reason, confounded him,</em> or <em>amazed him.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">مَا أَمْطَرَتْ حَتَّى أَبْطَرَتْ</span> <em>It</em> <span class="auth">(the sky)</span> <em>rained not until it caused</em> <span class="add">[men]</span> <em>to exult,</em> or <em>to exult greatly,</em>, &amp;c. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTr_4_A2">
					<p><span class="ar long">ابطر حِلْمَهُ</span> ‡ <em>It</em> <span class="auth">(the ignorance of a person)</span> <em>caused his</em> <span class="auth">(another's)</span> <em>clemency, moderation,</em> or <em>gravity, to become converted into inordinate exultation, and insolence,</em> or <em>the like, and levity.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTr_4_A3">
					<p><span class="ar long">ابطرهُ حِلْمَهُ</span> ‡ <em>It stupified, confounded,</em> or <em>amazed, him, so as to turn him from his clemency, moderation,</em> or <em>gravity.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTr_4_A4">
					<p><span class="ar long">ابطرهُ ذَرْعَهُ</span> ‡ <em>He imposed upon him more than he was able to do;</em> <span class="auth">(Ṣ;)</span> <em>what was above his power:</em> <span class="auth">(Ḳ:)</span> <span class="ar">ذرعه</span> is here a substitute for its antecedent to indicate an implication therein: <span class="auth">(A:)</span> you say this when a slow-paced camel has endeavoured in vain to keep pace with another camel; and when any man has imposed upon another a difficulty beyond his power: <span class="auth">(TA:)</span> or the meaning is, <em>he cut off his means of subsistence, and wasted his body:</em> <span class="auth">(IAạr, Ḳ:)</span> <span class="ar">ذرع</span> signifying the “body.” <span class="auth">(IAạr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTr_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">بَيْطَرَ</span></h3>
				<div class="sense" id="bTr_QQ1_A1">
					<p><span class="ar">بَيْطَرَ</span>, inf. n. <span class="ar">بَيْطَرَةٌ</span>, <em>He practised</em> <span class="add">[<em>farriery, the veterinary art,</em> or]</span> <em>the art of the</em> <span class="ar">بَيْطَار</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: Q. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTr_QQ1_A2">
					<p><span class="ar long">هُوَ يُبَيْطِرُ الدَّوَابَّ</span> <em>He treats beasts,</em> or <em>horses and the like, medically,</em> or <em>curatively.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biTorFA">
				<h3 class="entry"><span class="ar">بِطْرًا</span></h3>
				<div class="sense" id="biTorFA_A1">
					<p><span class="ar long">ذَهَبَ دَمُهُ بِطْرًا</span> ‡ <em>His blood went unrevenged,</em> <span class="auth">(Ks, Ṣ, A, Ḳ,)</span> <em>being held in light estimation.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTirN">
				<h3 class="entry"><span class="ar">بَطِرٌ</span></h3>
				<div class="sense" id="baTirN_A1">
					<p><span class="ar">بَطِرٌ</span> part. n. of <span class="ar">بَطِرَ</span>, <span class="auth">(Mṣb, TA,)</span> <em>Exulting,</em> or <em>exulting greatly,</em> or <em>excessively, and behaving insolently and unthankfully,</em> or <em>ungratefully:</em> or <em>exulting by reason of wealth, and behaving with pride and self-conceitedness, and boastfulness, and want of thankfulness:</em> or <em>behaving with the utmost exultation,</em>, &amp;c.: see its verb. <span class="auth">(A, Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTiyrN">
				<h3 class="entry"><span class="ar">بَطِيرٌ</span></h3>
				<div class="sense" id="baTiyrN_A1">
					<p><span class="ar">بَطِيرٌ</span> <em>Cut,</em> or <em>divided, lengthwise; slit; split;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">مَبْطُورٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: <span class="ar">بَطِيرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baTiyrN_B1">
					<p><a href="#baYoTaArN">See also <span class="ar">بَيْطَارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTiyrapN">
				<h3 class="entry"><span class="ar">َطِيرَةٌ</span></h3>
				<div class="sense" id="baTiyrapN_A1">
					<p><span class="ar long">اِمْرَأَةٌ بَطِيرَةٌ</span> <em>A woman who behaves with much</em> <span class="ar">بَطَر</span>, i. e. <em>exultation, and insolence and unthankfulness,</em> or <em>ingratitude,</em>, &amp;c.: <span class="add">[<a href="#baTira">see <span class="ar">بَطِرَ</span></a>.]</span> <span class="auth">(A.)</span> <span class="add">[<a href="#biToriyrN">See also what next follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biToriyrN">
				<h3 class="entry"><span class="ar">بِطْرِيرٌ</span> / <span class="ar">بِطْرِيرَةٌ</span></h3>
				<div class="sense" id="biToriyrN_A1">
					<p><span class="ar">بِطْرِيرٌ</span> <em>Clamorous; long-tongued:</em> and one <em>who perseveres in error:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بِطْرِيرَةٌ</span>}</span></add>: <span class="auth">(Ḳ:)</span> but it <span class="add">[the former]</span> is mostly used in relation to women, <span class="auth">(TA,)</span> and as signifying a woman <em>who exults,</em> or <em>exults greatly,</em> or <em>excessively, and behaves insolently and unthankfully,</em> or <em>ungratefully,</em> (<span class="ar">تَبْطَرُ</span>,) <em>and perseveres in error:</em> <span class="auth">(ADk:)</span> <span class="add">[it is said in the TA that some say <span class="ar">بِظْرِيرٌ</span>, and that this is the more approved; but Az says,]</span> Lth cites, from ADk, the phrase <span class="ar long">اِمْرَأَةٌ بِطْرِيرٌ</span> as meaning <em>a clamorous, long-tongued woman;</em> <span class="ar long">لِأَنَّهَا قَدْ بَطِرَتْ وأَشِرَتٌ</span> <span class="add">[because of her insolent behaviour]</span>: and says that, accord. to Aboo-Kheyreh, it is <span class="ar long">امراة بِظْرِيرٌ</span>; her tongue being likened to the <span class="ar">بَظْر</span>: but Lth adds, the saying of ADk is preferable in my opinion, and more correct. <span class="auth">(T in art. <span class="ar">بظر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayoTarN">
				<h3 class="entry"><span class="ar">بَيْطَرٌ</span></h3>
				<div class="sense" id="bayoTarN_A1">
					<p><span class="ar">بَيْطَرٌ</span>: <a href="#baYoTaArN">see <span class="ar">بَيْطَارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biyaTorN">
				<h3 class="entry"><span class="ar">بِيَطْرٌ</span></h3>
				<div class="sense" id="biyaTorN_A1">
					<p><span class="ar">بِيَطْرٌ</span>: <a href="#baYoTaArN">see <span class="ar">بَيْطَارٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: <span class="ar">بِيَطْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biyaTorN_A2">
					<p><span class="add">[Hence,]</span> <em>A tailor.</em> <span class="auth">(Sh, Ṣ,* Ḳ.)</span> A poet says, <span class="auth">(calling a tailor a <span class="ar">بيطر</span>, like as one calls a skilful man an <span class="ar">إِسْكَاف</span>, Sh, TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">شَقَّ البِيَطْرِ مِدْرَعَ الهُمَامِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Like as the tailor cuts lengthwise,</em> or <em>slits, the woollen tunic of the valiant chief</em>]</span>. <span class="auth">(Sh, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoTarapN">
				<h3 class="entry"><span class="ar">بَيْطَرَةٌ</span></h3>
				<div class="sense" id="bayoTarapN_A1">
					<p><span class="ar">بَيْطَرَةٌ</span> <span class="add">[<em>Farriery;</em> the <em>veterinary art;</em>]</span> the <em>art of the</em> <span class="ar">بَيْطَار</span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<a href="#bTr_QQ1">See Q. Q. 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoTaArN">
				<h3 class="entry"><span class="ar">بَيْطَارٌ</span></h3>
				<div class="sense" id="bayoTaArN_A1">
					<p><span class="ar">بَيْطَارٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بِيَطْرٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بَيْطَرٌ↓</span></span> and<span class="arrow"><span class="ar">بَطِيرٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">مُبَيْطِرٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> <span class="add">[<em>A farrier; one who practises the veterinary art;</em>]</span> <em>one who treats beasts,</em> or <em>horses and the like, medically,</em> or <em>curatively:</em> <span class="auth">(Ḳ:)</span> from <span class="ar">بَطَرَهُ</span>, explained above. <span class="auth">(Ṣ, Mṣb.*)</span> <span class="ar long">أَشْهَرُ مِنْ رَايَةِ البَيْطَارِ</span> <span class="add">[<em>More commonly known than the sign of the farrier,</em> app. meaning a sign which, I suppose, the itinerant farrier carried about with him,]</span> <span class="auth">(A, TA)</span> is one of the proverbs of the Arabs. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطر</span> - Entry: <span class="ar">بَيْطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoTaArN_A2">
					<p>You say, also, <span class="ar long">هُوَ بِهٰذَا عَالِمٌ بَيْطَارٌ</span> ‡ <span class="add">[<em>He is knowing and skilful in this:</em> <a href="#biyaTorN">see also <span class="ar">بِيَطْرٌ</span></a>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboTuwrN">
				<h3 class="entry"><span class="ar">مَبْطُورٌ</span></h3>
				<div class="sense" id="maboTuwrN_A1">
					<p><span class="ar">مَبْطُورٌ</span>: <a href="#baTiyrN">see <span class="ar">بَطِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubayoTirN">
				<h3 class="entry"><span class="ar">مُبَيْطِرٌ</span></h3>
				<div class="sense" id="mubayoTirN_A1">
					<p><span class="ar">مُبَيْطِرٌ</span>: <a href="#baYoTaArN">see <span class="ar">بَيْطَارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0217.pdf" target="pdf">
							<span>Lanes Lexicon Page 217</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
