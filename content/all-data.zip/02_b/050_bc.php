<article class="root" id="Root_bc">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/049_bde">بدى</a></span>
				<span class="ar">بذ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/051_bcO">بذأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bc_1">
				<h3 class="entry">1. ⇒ <span class="ar">بذّ</span></h3>
				<div class="sense" id="bc_1_A1">
					<p><span class="ar">بَذَّ</span>, <span class="auth">(M,)</span> sec. pers. <span class="ar">بَذِذْتَ</span>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> aor. <span class="ar">يَبَذُّ</span>, <span class="auth">(L, Ḳ,)</span> inf. n. <span class="ar">بَذَاذَةٌ</span> <span class="auth">(Ṣ, M, Mgh, Ḳ)</span> and <span class="ar">بُذُوذَةٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بَذَذٌ</span> <span class="auth">(M, Mgh, Ḳ)</span> and <span class="ar">بَذَاذٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">بِذَاذٌ</span>, with kesr, <span class="auth">(TA,)</span> <span class="add">[of all which, the third is the regular form,]</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, threadbare, and shabby,</em> or <em>mean, in the state of his apparel,</em> <span class="auth">(Ks, Ṣ, M, Mgh, L,)</span> and <em>in an evil condition;</em> <span class="auth">(M, L, Ḳ;)</span> <em>slovenly with respect to his person:</em> <span class="auth">(Ks, M, L:)</span> or <em>he neglected the constant adornment of himself:</em> or <em>he adorned himself one day, and another day left his hair in a shaggy</em> or <em>dishevelled,</em> or <em>matted and dusty, state:</em> <span class="auth">(T, L:)</span> or <em>he was humble in his apparel, not taking pleasure therein.</em> <span class="auth">(IAth, L.)</span> <span class="ar">بَذَاذَة</span> is said in a trad. to be a part of religion; <span class="auth">(Ks, T, M, Mgh, L;)</span> meaning, in this instance, The <em>being humble in dress, and wearing that which is not conducive to self-conceit and pride.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bc_1_B1">
					<p><span class="ar">بَذَّهُ</span>, aor. <span class="ar">يَبُذُّ</span>, <span class="auth">(T, Ṣ, M, L,)</span> inf. n. <span class="ar">بَذٌّ</span> <span class="auth">(Ṣ, M, L, Ḳ)</span> and<span class="arrow"><span class="ar">بَذِيذَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="add">[or this may be a simple subst.,]</span> <em>He overcame him;</em> <span class="auth">(T, Ṣ, M, L, Ḳ;)</span> <em>he surpassed him</em> in goodliness or beauty, or in any deed: <span class="auth">(T, L:)</span> <em>he outstripped him.</em> <span class="auth">(M, L.)</span> It is said in a trad., <span class="ar long">بَذَّ القَائِلِينَ</span> <em>He outstripped,</em> or <em>surpassed, and overcame, the speakers.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bc_3">
				<h3 class="entry">3. ⇒ <span class="ar">باذّ</span></h3>
				<div class="sense" id="bc_3_A1">
					<p><span class="ar">باذّهُ</span> <em>He hastened with him; made haste,</em> or <em>strove, to be,</em> or <em>get, before him:</em> <span class="auth">(Ḳ,* TA:)</span> <em>he vied with him in glory</em> or <em>excellence.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bc_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتذّ</span></h3>
				<div class="sense" id="bc_8_A1">
					<p><span class="ar long">ابتذّ حَقَّهُ</span> <em>He took his</em> <span class="auth">(i. e. his own)</span> <em>right,</em> or <em>due.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bc_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبذّ</span></h3>
				<div class="sense" id="bc_10_A1">
					<p><span class="ar long">استبذّ بِالأَمْرِ</span> <em>He was alone, with none to share,</em> or <em>participate, with him, in the affair;</em> <span class="auth">(Ḳ,* TA;)</span> <em>i. q.</em> <span class="ar">استبدّ</span> <span class="auth">(Ḳ)</span> <em>and</em> <span class="ar">استقلّ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacBN">
				<h3 class="entry"><span class="ar">بَذٌّ</span></h3>
				<div class="sense" id="bacBN_A1">
					<p><span class="ar">بَذٌّ</span> <span class="add">[perhaps from the Persian <span class="ar">بَدْ</span>]</span> A man <em>slovenly with respect to his person, and poor.</em> <span class="auth">(IAạr, T, L.)</span> And <span class="ar long">بَذُّ الهَيْئَةِ</span>, and<span class="arrow"><span class="ar long">بَاذُّ↓ الهَيْئَةِ</span></span>, A man <em>threadbare, and shabby,</em> or <em>mean, in the state of his apparel;</em> <span class="auth">(Ks, T,* Ṣ, Mgh, L;)</span> and <em>in an evil condition with respect to it;</em> <span class="auth">(L, Ḳ;)</span> <em>slovenly with respect to his person:</em> <span class="auth">(Ks, L:)</span> or one <em>who neglects the constant adornment of his person:</em> or <em>who adorns himself one day, and another day leaves his hair in a shaggy</em> or <em>dishevelled,</em> or <em>matted and dusty, state:</em> <span class="auth">(T, L:)</span> or <em>humble in his apparel, not taking pleasure therein.</em> <span class="auth">(IAth, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَذٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bacBN_A2">
					<p><span class="ar long">بَذُّ البَخْتِ</span> A man <em>having evil fortune.</em> <span class="auth">(Kr, M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَذٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bacBN_A3">
					<p><span class="ar long">هَيْئَةٌ بَذَّةٌ</span> <em>A threadbare, and shabby,</em> or <em>mean, state of apparel.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَذٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bacBN_A4">
					<p><span class="ar long">حَالٌ بَذَّةٌ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">حَالَةٌ بَذَّةٌ</span>, <span class="auth">(TA,)</span> <em>An evil state</em> or <em>condition.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَذٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bacBN_A5">
					<p><span class="ar long">تَمْرٌ بَذٌّ</span> <em>Dates that are separate, each one from another, not sticking together;</em> like <span class="ar">فَذٌّ</span>: <span class="auth">(IAạr, M:)</span> or <em>that are scattered.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَذٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bacBN_A6">
					<p><span class="ar long">فَذٌّ بَذٌّ</span> <em>Single; sole; that is alone,</em> or <em>apart from others:</em> <span class="auth">(IAạr, Ḳ:)</span> and so<span class="arrow"><span class="ar long">أَبَذُّ↓ أَحَذُّ</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacBapN">
				<h3 class="entry"><span class="ar">بَذَّةٌ</span></h3>
				<div class="sense" id="bacBapN_A1">
					<p><span class="ar long">فِى هَيْئَتِهِ بَذَّةٌ</span>, and <span class="ar">بَذَاذَةٌ</span>, <span class="add">[the latter an inf. n. <span class="auth">(of <span class="ar">بَذَّ</span>)</span> used as a simple subst.,]</span> <em>In his state of apparel is slovenliness, and threadbareness, and shabbiness,</em> or <em>meanness.</em> <span class="auth">(T.)</span> <span class="arrow"><span class="ar">بَذِيذَةٌ↓</span></span>, also, <span class="auth">(sometimes written<span class="arrow"><span class="ar">بَذْبَذَةٌ↓</span></span>, TA, and so in the TT but without vowel-signs,)</span> signifies <em>Slovenliness with respect to one's person;</em> or <em>neglect of cleanliness.</em> <span class="auth">(T, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baciycapN">
				<h3 class="entry"><span class="ar">بَذِيذَةٌ</span> / <span class="ar">بَذْبَذَةٌ</span></h3>
				<div class="sense" id="baciycapN_A1">
					<p><span class="ar">بَذِيذَةٌ</span>, or <span class="ar">بَذْبَذَةٌ</span>: <a href="#bacBapN">see <span class="ar">بَذَّةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَذِيذَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baciycapN_B1">
					<p>And for the former, <a href="#bc_1_B1">see also <span class="ar">بَذَّهُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAcBN">
				<h3 class="entry"><span class="ar">بَاذٌّ</span></h3>
				<div class="sense" id="baAcBN_A1">
					<p><span class="ar">بَاذٌّ</span>: <a href="#bacBN">see <span class="ar">بَذٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذ</span> - Entry: <span class="ar">بَاذٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAcBN_B1">
					<p>Also Any one <em>overcoming,</em> or <em>surpassing.</em> <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabacBN">
				<h3 class="entry"><span class="ar">أَبَذٌّ</span></h3>
				<div class="sense" id="OabacBN_A1">
					<p><span class="ar">أَبَذٌّ</span>: <a href="#bacBN">see <span class="ar">بَذٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0172.pdf" target="pdf">
							<span>Lanes Lexicon Page 172</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
