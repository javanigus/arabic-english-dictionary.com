<article class="root" id="Root_bqe">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/161_bqw">بقو</a></span>
				<span class="ar">بقى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/163_bkO">بكأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bqe_1">
				<h3 class="entry">1. ⇒ <span class="ar">بقى</span></h3>
				<div class="sense" id="bqe_1_A1">
					<p><span class="ar">بَقِيَ</span> aor. <span class="ar">يَبْقَى</span>, inf. n. <span class="ar">بَقَآءٌ</span> <span class="auth">(JK, Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بَاقِيَةٌ</span>; <span class="auth">(Mṣb; <span class="add">[but see this latter below;]</span>)</span> <span class="add">[and accord. to the CK, <span class="ar">بَقًى</span> and <span class="ar">بَقْىٌ</span>; but this is a mistake; <span class="ar long">وَبَقَى و بَقْيًا</span> being there erroneously put for <span class="ar long">بَقَى بَقْيًا</span>, explained by what here follows;]</span> and <span class="ar">بَقَى</span>, <span class="add">[by some written <span class="ar">بَقَا</span>,]</span> <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> aor. as above, <span class="auth">(JK,)</span> inf. n. <span class="ar">بَقْىٌ</span>, <span class="auth">(Ḳ,)</span> of the dial. of Belhárith Ibn-Kaab, <span class="auth">(TA,)</span> or of that of Teiyi, <span class="auth">(JK, Ṣ, TA,)</span> who in like manner say <span class="ar">بَقَتْ</span> instead of <span class="ar">بَقَيَتْ</span>, <span class="auth">(Ṣ, TA,)</span> and the like is done in other verbs of the same class, <span class="auth">(Ṣ, Mṣb,)</span> whether the kesreh and the <span class="ar">ى</span> be original, as in <span class="ar">بَقِىَ</span> and <span class="ar">نَسِىَ</span> and <span class="ar">فَنِىَ</span>, or accidental, as in the pass. verbs <span class="ar">هُدِىَ</span> and <span class="ar">بُنِىَ</span>; <span class="auth">(Mṣb;)</span> <span class="add">[<em>He,</em> or]</span> <em>it,</em> namely, a thing, <em>remained, continued, lasted, endured:</em> and <em>was,</em> or <em>became, permanent,</em> or <em>perpetual;</em> or <em>continued, lasted,</em> or <em>existed, incessantly, always, endlessly,</em> or <em>for ever:</em> syn. <span class="ar">دَامَ</span>, and <span class="ar">ثَبَتَ</span>; <span class="auth">(Mṣb;)</span> <em>contr. of</em> <span class="ar">فَنِىَ</span>: <span class="auth">(Ḳ:)</span> <span class="ar">بَقَآءٌ</span> signifies a thing's <em>remaining, continuing, lasting,</em> or <em>enduring, in its first state, to a period determined by the will of God, either with respect to its corporeal substance,</em> as in the case of a heavenly orb, <em>or with respect to its kind only,</em> as in the case of the human and other animal races; and the <em>continuing, lasting,</em> or <em>existing, for ever, either by self,</em> as in the instance of God alone, <em>or otherwise,</em> and thus <em>either with respect to the corporeal substance,</em> as in the case of an inhabitant of Paradise, <em>or with respect to kind only,</em> as in the case of the fruits of the inhabitants of Paradise. <span class="auth">(Er-Rághib, TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">دَارُ البَقَآءِ</span> <span class="add">[<em>The abode of everlasting existence;</em>]</span> <em>the world to come.</em> <span class="auth">(T in art. <span class="ar">دور</span>.)</span> The verb is said of a thing; and in like manner of a man, as in <span class="ar long">بَقِىَ زَمَانًا طَوِيلًا</span>, i. e. <em>He lived</em> <span class="add">[or <em>continued in life</em>]</span> <em>a long time.</em> <span class="auth">(Ṣ.)</span> <span class="add">[You say also, <span class="ar long">بَقِىَ عَلَى حَالِهِ</span> <em>He,</em> or <em>it, remained,</em> or <em>continued, in his,</em> or <em>its, state,</em> or <em>condition;</em> i. e., <em>as he,</em> or <em>it, was.</em> And <span class="ar long">بَقِىَ عَلَى الشِّدَّةِ</span> <em>He endured,</em> or <em>bore up against, difficulty, distress,</em> or <em>adversity.</em>]</span> And <span class="ar long">بَقِى مِنَ الشَّىْءِ بَقِيَّةٌ</span> <span class="add">[<em>A remain, remainder, remnant, relic,</em> or <em>residue, of the thing remained.</em>]</span> <span class="auth">(Ṣ.)</span> And <span class="ar long">بَقِىَ مِنْهُ كَذَا</span> <em>Such a thing remained, over and above,</em> and <em>behind, thereof;</em> as also<span class="arrow"><span class="ar">تبقّى↓</span></span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bqe_1_B1">
					<p><span class="ar">بَقَاهُ</span>, with <span class="ar">ى</span> and with <span class="ar">و</span> for the last radical, <span class="auth">(Ḳ,)</span> first pers. <span class="ar">بَقَيْتُهُ</span> <span class="auth">(Lḥ, Ṣ)</span> and <span class="ar">بَقَوْتُهُ</span>, <span class="auth">(Lḥ, TA,)</span> aor. of the former <span class="ar">ـِ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">بَقْىٌ</span>, <span class="add">[of the former verb,]</span> <span class="auth">(Ḳ,)</span> <em>He looked at him,</em> or <em>it:</em> <span class="auth">(Lḥ, Ṣ, Ḳ:)</span> or <span class="add">[so in the Ḳ, but in the Ṣ “and,”]</span> <em>he watched,</em> or <em>observed, him,</em> or <em>it:</em> <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar">بَقَيْتُهُ</span> <em>I looked, watched,</em> or <em>waited, for him,</em> or <em>it;</em> <span class="auth">(TA in art. <span class="ar">بقو</span>;)</span> as also <span class="ar">بَقَوْتُهُ</span>; <span class="auth">(Ḳ in that art.;)</span> but the former is the more approved. <span class="auth">(TA in that art.)</span> <span class="add">[<a href="index.php?data=02_b/161_bqw">See also art. <span class="ar">بقو</span></a>.]</span> You say also, <span class="ar long">فُلَانٌ يَبْقِى الشَّىْءَ بِبَصَرِهِ</span> <em>Such a one looks at the thing,</em> and <em>watches,</em> or <em>observes, it.</em> <span class="auth">(JK.)</span> And it is said in a trad., <span class="ar long">بَقَيْنَا رَسُولَ ٱللّٰهِ</span> <em>We looked, watched,</em> or <em>waited, for the Apostle of God.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqe_2">
				<h3 class="entry">2. ⇒ <span class="ar">بقّى</span></h3>
				<div class="sense" id="bqe_2_A1">
					<p><a href="#bqe_4">see 4</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqe_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابقى</span></h3>
				<div class="sense" id="bqe_4_A1">
					<p><span class="ar">ابقاهُ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بقّاهُ↓</span></span> and<span class="arrow"><span class="ar">تبقّاهُ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> all signify the same, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">استبقاهُ↓</span></span> likewise, <span class="auth">(Ḳ,)</span> <em>He made,</em> or <em>caused,</em> <span class="add">[and <em>he suffered,</em>]</span> <em>him,</em> or <em>it, to remain, continue, last; to be,</em> or <em>become, permanent,</em> or <em>perpetual; to continue, last,</em> or <em>exist, incessantly, always, endlessly,</em> or <em>for ever; he continued it; he perpetuated it.</em> <span class="auth">(Mṣb, Ḳ *)</span> You say, <span class="ar long">ابقاهُ ٱللّٰهُ</span> <span class="add">[<em>God preserved him,</em> or <em>prolonged his life;</em> or <em>may God preserve him,</em> or <em>prolong his life;</em> or]</span> <em>God made him,</em> or <em>caused him,</em> or <em>may God make him,</em> or <em>cause him, to continue in life.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">أَبْقَى أَصْلَ الشَّىْءِ وَجَعَلَ ثَمَرَهُ فِى سَبِيلِ ٱللّٰهِ</span> <em>He made the thing itself to remain unalienable, not to be inherited nor sold nor given away, and assigned the profit arising from it to be employed in the cause of God,</em> or <em>of religion.</em> <span class="auth">(TA in art. <span class="ar">حبس</span>.)</span> And <span class="ar long">أَبْقَيْتُ مَا بَيْنَنَا</span> <em>I was sparing of marring,</em> i. e., <em>forbore from marring much,</em> or <em>exceedingly, that</em> <span class="add">[<em>state of union</em> or <em>amity</em>]</span> <em>which subsisted between us.</em> <span class="auth">(Ḳ.)</span> And<span class="arrow"><span class="ar long">بَقِّ↓ نَعْلَيْكَ وَٱبْذُلْ قَدَمَيْكَ</span></span> <span class="add">[<em>Preserve thou,</em> or <em>spare thou, thy sandals, and use freely,</em> or <em>unsparingly, thy feet</em>]</span>: a prov. <span class="auth">(Meyd. See Freytag's Arab. Prov. i. 149.)</span> <span class="pb" id="Page_0238"></span>And<span class="arrow"><span class="ar long">تَبَقَّهْ↓ وَتَوَقَّهْ</span></span> <em>Preserve thou the soul</em> (<span class="arrow"><span class="ar long">اِسْتَبْقِ↓ النَّفْسَ</span></span>), <em>expose it not to destruction,</em> <span class="add">[meaning <em>preserve thyself,</em>]</span> <em>and guard against evils,</em> or <em>calamities:</em> a trad.: the <span class="ar">ه</span> in each verb is that of pausation. <span class="auth">(TA.)</span> <span class="add">[And <span class="ar long">ابقى مِنَ الشَّىْءِ بَقِيَّةً</span> <em>He left,</em> or <em>reserved, of the thing, a remain, remainder, remnant,</em>, &amp;c.:]</span> and<span class="arrow"><span class="ar long">استبقى↓ مِنَ الشَّىْءِ</span></span> <em>He left a portion of the thing;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">تبقّى↓</span></span>; whence the prov., used to incite to liberality, <span class="arrow"><span class="ar long">لَا يَنْفَعُكَ مِنْ زَادٍ تَبَقٍّ↓</span></span> <em>Leaving a portion of travel-ling-provision will not profit thee.</em> <span class="auth">(JK.)</span> <span class="add">[And <span class="ar long">ابقى الشَّىْءِ</span> and<span class="arrow"><span class="ar">استبقاهُ↓</span></span> <em>He reserved the thing</em> for a future time or use, &amp;c.]</span> And<span class="arrow"><span class="ar">استبقاهُ↓</span></span> as meaning <span class="add">[<em>He spared him; he let him live;</em>]</span> <em>he left him alive;</em> <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[as also <span class="ar">ابقاهُ</span>; for]</span> men say to their enemies when the latter have overcome, <span class="ar long">أَبْقُونَا وَلَا تَسْتَأْصِلُونَا</span> <span class="add">[<em>Spare ye us, and destroy us not entirely</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[or <span class="ar">ابقاهُ</span>, in a case of this kind,]</span> and <span class="ar long">ابقى عَلَيْهِ</span> and<span class="arrow"><span class="ar">استبقاهُ↓</span></span> signify <em>He pardoned him,</em> <span class="add">[<em>and forbore to slay him,</em>]</span> <em>when slaughter was his due:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">استبقاهُ↓</span></span> signifies also <em>He pardoned,</em> or <em>forgave, his fault, wrong action,</em> or <em>lapse into sin, and preserved his love,</em> or <em>affection.</em> <span class="auth">(JK, TA.*)</span> And <span class="add">[hence,]</span> <span class="ar long">أَبْقَيْتُ عَلَى فُلَانٍ</span> signifies also <em>I showed mercy to such a one</em> <span class="add">[<em>by sparing him,</em> or <em>letting him live,</em> or <em>by pardoning him,</em> or <em>otherwise</em>]</span>; <em>had mercy on him; pitied,</em> or <em>compassionated, him;</em> syn. <span class="ar long">أَرْعَيْتُ عَلَيْهِ</span> and <span class="ar">رَحِمْتُهُ</span>. <span class="auth">(Ṣ.)</span> One says, <span class="ar long">لَا أَبْقَى ٱللّٰهُ عَلَيْكَ إِنْ أَبْقَيْتَ عَلَىَّ</span> <span class="add">[<em>May God not show mercy to thee if thou show mercy to me:</em> a prov., said in derision to one who affects to show mercy when unable to take revenge]</span>. <span class="auth">(Ṣ, Meyd.)</span> And <span class="ar long">لَا تُبْقِ إِلَّا عَلَى نَفْسِكَ</span> <span class="add">[<em>Show not mercy save to thyself:</em> another prov., similar to the former]</span>. <span class="auth">(Meyd.)</span> And it is said, in a trad., of the fire <span class="add">[of Hell]</span>, <span class="ar long">لَا تُبْقِى عَلَى مَنْ تَضَرَّعَ إِلَيْهَا</span>, i. e. <em>It will not pity</em> <span class="add">[<em>him who abases himself to it:</em> or rather <em>it will not spare, &amp;c.:</em> and in like manner, <span class="ar long">لَا تُبْقِى وَلَا تَذَرُ</span>, in the Ḳur lxxiv. 28, is generally understood as meaning <em>It</em> <span class="auth">(namely, Hell,)</span> <em>will not spare, nor leave</em> unburned]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqe_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبقّى</span></h3>
				<div class="sense" id="bqe_5_A1">
					<p><a href="#bqe_1">see 1</a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bqe_5_B1">
					<p><a href="#bqe_4">and see also 4</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqe_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباقى</span></h3>
				<div class="sense" id="bqe_6_A1">
					<p><span class="ar">تَبَاقٍ</span> The <em>remaining together.</em> <span class="auth">(KL.)</span> <span class="add">[You say, app., <span class="ar">تَبَاقَوْا</span>, and <span class="ar">تَبَاقَيَا</span>, <em>They,</em> and <em>they two, remained together.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bqe_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبقى</span></h3>
				<div class="sense" id="bqe_10_A1">
					<p><a href="#bqe_4">see 4</a>, in seven places. <span class="add">[<a href="index.php?data=06_H/229_He">See also a usage of this verb in art. <span class="ar">حى</span></a>, <a href="#He_10">conj. 10</a>, second sentence.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqFe">
				<h3 class="entry"><span class="ar">بَقًى</span></h3>
				<div class="sense" id="baqFe_A1">
					<p><span class="ar long">لَقٍى بَقًى</span>: <a href="#baqaAqN">see <span class="ar">بَقَاقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqoyapN">
				<h3 class="entry"><span class="ar">بَقْيَةٌ</span></h3>
				<div class="sense" id="baqoyapN_A1">
					<p><span class="ar">بَقْيَةٌ</span>: <a href="#baqiyBapN">see <span class="ar">بَقِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqowae.1">
				<h3 class="entry"><span class="ar">بَقْوَى</span></h3>
				<div class="sense" id="baqowae.1_A1">
					<p><span class="ar">بَقْوَى</span>: <a href="#buqoyaA">see <span class="ar">بُقْيَا</span></a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buqwae">
				<h3 class="entry"><span class="ar">بُقوَى</span></h3>
				<div class="sense" id="buqwae_A1">
					<p><span class="ar">بُقوَى</span>: <a href="#buqoyaA">see <span class="ar">بُقْيَا</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqoyaA">
				<h3 class="entry"><span class="ar">بَقْيَا</span></h3>
				<div class="sense" id="baqoyaA_A1">
					<p><span class="ar">بَقْيَا</span>: <a href="#buqoyaA">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buqoyaA">
				<h3 class="entry"><span class="ar">بُقْيَا</span></h3>
				<div class="sense" id="buqoyaA_A1">
					<p><span class="ar">بُقْيَا</span> <span class="auth">(JK, Ṣ, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">بَقْيَا↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">بَقْوَى↓</span></span> <span class="auth">(JK, Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بُقْوَى↓</span></span> <span class="auth">(Th, Ḳ)</span> and<span class="arrow"><span class="ar">بَقِيَّةٌ↓</span></span> <span class="auth">(JK, Ḳ,)</span> the<span class="arrow">↓</span> third and<span class="arrow">↓</span> fourth with <span class="ar">ى</span> changed into <span class="ar">و</span>, like as <span class="ar">و</span> is changed into <span class="ar">ى</span> in <span class="ar">دُنْيَا</span> and <span class="ar">عُلْيَا</span> and <span class="ar">قُصْيَا</span>, <span class="auth">(ISd, TA,)</span> <span class="add">[substs. in the sense of <span class="ar">إِبْقَآءٌ</span>, <a href="#bqe_4">inf. n. of 4</a>, signifying The <em>making,</em> or <em>causing,</em> and <em>suffering, to remain, continue, last,</em>, &amp;c.; <em>preservation</em> of a person <em>in life,</em> and of a thing <em>in being;</em> and the <em>sparing, letting live,</em> or <em>leaving alive;</em>]</span> substs. from <span class="ar">أَبْقَاهُ</span>: <span class="auth">(Mṣb, Ḳ:)</span> or <span class="add">[the <em>showing mercy by sparing</em> or <em>letting live,</em> or <em>by pardoning,</em> or <em>otherwise; having mercy; pitying,</em> or <em>compassionating;</em>]</span> substs. from <span class="ar long">أَبْقَيْتُ عَلَى فُلَانٍ</span>. <span class="auth">(Ṣ.)</span> Thus one says of a pilgrim, that he put gum, or something glutinous, upon his head, and so caused his hair to become compacted, <span class="ar long">بُقْيَا عَلَيْهِ</span> <em>to preserve it in the state in which it was</em> <span class="auth">(expl. by <span class="ar long">إِبْقَآءً عليه</span>)</span>, lest it should become shaggy, or dishevelled, &amp;c. <span class="auth">(L in art. <span class="ar">لبد</span>.)</span> And one says, <span class="ar long">نَشَدْتُكَ ٱللّٰهَ وَالبُقْيَا</span> and<span class="arrow"><span class="ar">البَقْوَى↓</span></span> <span class="add">[<em>I conjure,</em> or <em>beg,</em> or <em>beseech, thee by God and by the preservation of</em> thy <em>life</em>]</span>. <span class="auth">(JK.)</span> And<span class="arrow"><span class="ar long">مَا لِى عَلَيْه رَعْوَى وَلَا بَقْوَى↓</span></span> <span class="add">[<em>I have no mercy nor pity</em> to bestow <em>upon him</em>]</span>. <span class="auth">(JK. <span class="add">[There expl. by the words <span class="ar long">أَىْ أَرْعَيْتُ عَلَيْهِ وَأَبْقَيْتُ</span>; but <span class="ar">أَىْ</span> is evidently a mistranscription for <span class="ar">مِنْ</span>, i. e. from.]</span>)</span> A poet <span class="auth">(El-La'een El-Minkaree, TA)</span> says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَمَا بُقْيَا عَلَىَّ تَرَكْتُمَانِى</span> *</div> 
						<div class="star">* <span class="ar long">وَلٰكِنْ خِفْتُمَا صَرَدَ النِّبَالِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And it was not to show mercy by sparing me that ye two left me; but ye feared the transpiercing of the arrows</em>]</span>. <span class="auth">(Ṣ.)</span> And another says, on his having refused to accept an offer of seven bloodwits,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أُذَكَّرُ بِالبُقْيَا عَلَى مَنْ أَصَابَنِى</span> *</div> 
						<div class="star">* <span class="ar long">وَبُقْيَاىَ أَنِّى جَاهِدٌ غَيْرُ مُؤْتَلِى</span> *</div> 
					</blockquote>
					<p>i. e. <em>Am I required</em> <span class="add">[or <em>exhorted</em> or <em>reminded</em>]</span> <em>to show mercy to him who slew my relation, when the mercy that I show</em> to him <em>is that I am labouring</em> to slay him, and <em>not falling short,</em> or <em>being remiss:</em> by <span class="ar">بقياى</span> is meant <span class="ar long">إِبْقَائِى عَلَيْهِ</span>; though <span class="ar">الإِبْقَآء</span> is not <span class="ar">الجَهْد</span>: the meaning is, that this is done by me in lieu of that: <span class="ar">البُقْيَا</span> is a subst. from <span class="ar">الإِبْقَآء</span>, syn. therewith; and the <span class="ar">و</span> prefixed to it is a denotative of state. <span class="auth">(Ḥam p. 119. <span class="add">[This verse is also cited in the TA, but with the substitution of<span class="arrow"><span class="ar">بِالبَقْوَى↓</span></span> and <span class="ar">وَبَقْوَاى</span> for the corresponding words above.]</span>)</span> <span class="arrow"><span class="ar">البَقِيَّةَ↓</span></span> is said by men to their enemies when the latter have overcome; meaning <span class="add">[We ask, or beg, <em>the being spared,</em> or <em>mercy,</em> or <em>quarter;</em> a verb, whereby it is governed, being understood: or]</span> <span class="ar long">أَبْقُونَا وَلَا تَسْتَأْصِلُونَا</span> <span class="add">[<em>spare ye us, and destroy us not entirely</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqiyBapN">
				<h3 class="entry"><span class="ar">بَقِيَّةٌ</span></h3>
				<div class="sense" id="baqiyBapN_A1">
					<p><span class="ar">بَقِيَّةٌ</span> <em>A remain, remainder, remaining portion, remnant, relic, residue,</em> or the <em>remains,</em> or <em>rest,</em> of a thing; <span class="auth">(KL, PṢ, &amp;c.;)</span> a subst. from <span class="ar">بَقِىَ</span> as signifying “it remained over and above,” and “it remained behind:” pl. <span class="ar">بَقَايَا</span> and <span class="ar">بَقِيَّاتٌ</span>: <span class="auth">(Mṣb:)</span> <span class="arrow"><span class="ar">بَاقِيَةٌ↓</span></span>, also, <span class="add">[pl. <span class="ar">بَوَاقٍ</span> and <span class="ar">بَاقِيَاتٌ</span>,]</span> has the same meaning as <span class="ar">بَقِيَّةٌ</span>; <span class="auth">(TA;)</span> <span class="add">[i. e., as explained above; and so has <span class="arrow"><span class="ar">بَاقٍ↓</span></span>, for <span class="ar long">شَىْءٍ بَاقٍ</span>, &amp;c.]</span> You say, <span class="ar long">بَقِىَ مِنَ الشَّىْءِ بَقِيَّةٌ</span> <span class="add">[explained before: <a href="#bqe_1">see 1</a>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[And <span class="ar long">هُمْ بَقِيَّةُ السَّيْفِ</span>, and <span class="ar long">بَقَايَا السَّيْفِ</span>, <em>They are those who have been spared by the sword</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَقِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqiyBapN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">فُلَانٌ مِنْ بَقِيَّةِ القَوْمِ</span> <em>Such a one is of the best of the people,</em> or <em>company of men:</em> because a man reserves the most excellent of the things that he produces. <span class="auth">(Bḍ in xi. 118.)</span> And <span class="ar long">فُلَانٌ مِنْ بَقِيَّةِ أَهْلِهِ</span> <em>Such a one is of the most excellent of his people,</em> or <em>family.</em> <span class="auth">(Ḥam p. 78.)</span> And <span class="ar long">فُلَانٌ بَقِيَّةُ القَوْمِ</span> <em>Such a one is the best of the people,</em> or <em>company of men:</em> pl. <span class="ar">بَقَايَا</span>. <span class="auth">(Kull p. 96.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَقِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baqiyBapN_A3">
					<p><span class="ar long">أُولُو بَقِيَّةٍ</span>, in the Ḳur xi. 118, hence means <em>Persons possessed of excellence:</em> <span class="add">[see a phrase mentioned voce <span class="ar">بَلَلٌ</span>:]</span> or <em>possessing a relic of judgment and intelligence:</em> <span class="auth">(Bḍ:)</span> or <em>persons of religion and excellence:</em> <span class="auth">(Jel:)</span> or <em>persons of understanding</em> <span class="auth">(Ḳ, TA)</span> <em>and discrimination:</em> <span class="auth">(TA:)</span> or <em>persons of obedience:</em> <span class="auth">(TA:)</span> or <em>having the quality of preserving themselves</em> <span class="auth">(Az, Bḍ, Ḳ,*)</span> <em>from punishment,</em> <span class="auth">(Bḍ,)</span> <em>by their holding the approved religion:</em> <span class="auth">(Az, TA:)</span> and this last explanation is confirmed by another reading, which is <span class="arrow"><span class="ar long">اولوا بَقْيَةٍ↓</span></span> <span class="add">[<em>possessing a quality of watching,</em> or <em>observing,</em> and hence, <em>of guarding,</em> or <em>preserving</em>]</span>; <span class="ar">بَقْيَة</span> being the inf. n. of un. of <span class="ar">بَقَاهُ</span>, aor. <span class="ar">يَبْقِيهِ</span>, signifying “he watched,” or “observed,”, &amp;c., “him,” or “it.” <span class="auth">(Bḍ.)</span> <a href="#buqayaA">See also <span class="ar">بُقَيَا</span></a>, in two places. <span class="ar">بَقِيَّةٌ</span> is also a subst. from <span class="ar long">أَبْقَيْتُ مَا بَيْنَنَا</span> <span class="add">[explained before: <a href="#bqe_4">see 4</a>: app. meaning <em>Forbearance from marring much,</em> or <em>exceedingly, the state of unity,</em> or <em>of amity, subsisting between two persons,</em> or <em>parties:</em> and such may be its meaning in the phrase above-mentioned (<span class="ar long">اولوا بقيّة</span>)]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَقِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baqiyBapN_A4">
					<p><span class="ar long">بَقِيَّةُ ٱللّٰهِ</span>, in the Ḳur xi. 87, <span class="add">[after the command, in the next preceding verse, to give full measure and weight,]</span> means <em>God's sustenance that remains for you</em> after your giving full measure <span class="add">[and weight]</span>: <span class="auth">(Jel:)</span> or <em>that which God has preserved for you, of what is lawful,</em> <span class="auth">(Fr, Bḍ,)</span> after <span class="add">[your]</span> keeping aloof from that which he has forbidden you: <span class="auth">(Bḍ:)</span> or <em>the good state,</em> or <em>condition, remaining for you:</em> <span class="auth">(Zj, Ḳ:)</span> or <em>the fear</em> (<span class="ar">مُرَاقَبَة</span>) <em>of God;</em> accord. to some: <span class="auth">(Fr, TA:)</span> or <em>the obedience of God, and</em> <span class="auth">(as Aboo-ʼAlee says, TA)</span> <em>the looking for his recompense:</em> <span class="auth">(Ḳ, TA:)</span> or <span class="ar">بَقِيَّةٌ</span> and<span class="arrow"><span class="ar">بَاقِيَةٌ↓</span></span> signify <em>any religious service whereby one seeks to obtain the recompense of God;</em> and such is the meaning of the former in this instance. <span class="auth">(Er-Rághib, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَقِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baqiyBapN_A5">
					<p><a href="#baAqiyapN">See also <span class="ar">بَاقِيَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqK">
				<h3 class="entry"><span class="ar">بَاقٍ</span></h3>
				<div class="sense" id="baAqK_A1">
					<p><span class="ar">بَاقٍ</span> part. n. of <span class="ar">بَقِىَ</span> <span class="add">[in all its senses; <em>Remaining, continuing, lasting,</em> or <em>enduring:</em> and <em>permanent,</em> or <em>perpetual;</em> or <em>continuing, lasting,</em> or <em>existing, incessantly, always, endlessly,</em> or <em>for ever:</em>, &amp;c.: <a href="#bqe_1">see 1</a>]</span>. <span class="auth">(Er-Rághib, TA.)</span> <span class="ar">البَاقِى</span>, a name of God, <span class="add">[as also, pleonastically, <span class="ar long">البَاقِى الأَبَدِىُّ</span>, means <em>The Everlasting,</em> or]</span> <em>He whose existence will have no end.</em> <span class="auth">(TA.)</span> <a href="#baqiyBapN">See also <span class="ar">بَقِيَّةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَاقٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAqK_A2">
					<p><span class="ar">البَاقِى</span> also signifies <em>The</em> <span class="ar">حَاصِل</span> <span class="add">[or <em>net produce,</em> or perhaps simply the <em>produce,</em>]</span> <em>of the</em> <span class="add">[<em>tax termed</em>]</span> <span class="ar">خَرَاج</span>, <em>and the like.</em> <span class="auth">(Lth, JK, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqiyapN">
				<h3 class="entry"><span class="ar">بَاقِيَةٌ</span></h3>
				<div class="sense" id="baAqiyapN_A1">
					<p><span class="ar">بَاقِيَةٌ</span>: <a href="#baqiyBapN">see <span class="ar">بَقِيَّةٌ</span></a>, first sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَاقِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAqiyapN_A2">
					<p><span class="ar long">البَاقِيَاتُ الصَّالِحَاتُ</span> <span class="add">[in the Ḳur xviii. 44, and xix. 79,]</span> means <em>Any righteous,</em> or <em>good, work,</em> <span class="auth">(Ḳ, TA,)</span> <em>of which the recompense remains:</em> <span class="auth">(TA:)</span> <span class="pb" id="Page_0239"></span>or <em>acts of obedience,</em> <span class="auth">(Bḍ and Jel in xix. 79,)</span> or <em>good works,</em> <span class="auth">(Bḍ in xviii. 44,)</span> <em>of which the fruit remains for ever:</em> <span class="auth">(Bḍ in both those places, and Jel * in the former:)</span> and, as included therein, <span class="add">[so Bḍ, but in the Ḳ “or,”]</span> <em>the five prayers;</em> <span class="auth">(Bḍ, Ḳ;)</span> and <em>the performance of the pilgrimage;</em> and <em>the keeping the fast of Ramadán;</em> <span class="auth">(Bḍ in xviii. 44;)</span> and <span class="add">[so Bḍ, but in the Ḳ “or,”]</span> <em>the saying,</em> <span class="ar long">سُبْحَانَ ٱللّٰهِ وَالحَمْدُلِلّٰهِ وَلَا إِلَّا ٱللّٰهُ وَٱللّٰهُ أَكْبَرُ</span>; <span class="auth">(Bḍ and Jel in xviii. 44, and Ḳ;)</span> to which some add, <span class="ar long">وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِٱللّٰهِ</span>: <span class="auth">(Jel ibid.:)</span> or, accord. to Er-Rághib, the correct meaning is <em>any religious service whereby one seeks to obtain the recompense of God:</em> <a href="#baqiyBapN">see also <span class="ar">بَقِيَّةٌ</span></a>, last explanation. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">بَاقِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAqiyapN_A3">
					<p><span class="ar">بَاقِيَةٌ</span> is sometimes put in the place of an inf. n.; <span class="auth">(Ṣ, Ḳ;)</span> or it is an inf. n.; <span class="auth">(Mṣb;)</span> <em>syn. with</em> <span class="ar">بَقَآءٌ</span>; <span class="auth">(Ṣ, Mṣb, TA;)</span> with which <span class="arrow"><span class="ar">بَقِيَّةٌ↓</span></span>, also, is syn. <span class="auth">(TA in art. <span class="ar">سرع</span>.)</span> So in the Ḳur <span class="add">[lxix. 8]</span>, <span class="ar long">فَهَلْ تَرَى لَهُمْ مِنْ بَاقِيَةٍ</span> <span class="add">[<em>And dost thou see them to have any continuance?</em>]</span>; <span class="auth">(Ṣ, TA;)</span> so says Fr: <span class="auth">(TA:)</span> or, as some say, the meaning is, <span class="ar">بَقِيَّةٍ</span> <span class="add">[i. e. <em>a remnant</em>]</span>: <span class="auth">(TA:)</span> or <span class="ar long">جَمَاعَةٍ بَاقِيَةٍ</span> <span class="add">[<em>a company remaining</em>]</span>: <span class="auth">(Er-Rághib, TA:)</span> or <span class="ar long">نَفْسٍ بَاقِيَةٍ</span> <span class="add">[<em>a soul,</em> or <em>person, remaining</em>]</span>: <span class="auth">(Bḍ, Jel:)</span> or the <span class="ar">ة</span> is an intensive affix; <span class="auth">(Jel;)</span> <span class="add">[or a restrictive to unity;]</span> i. e. <em>one remaining;</em> <span class="auth">(Jel, TA;)</span> and this is also allowable and good: one says, likewise, <span class="ar long">مَا بَقِيَتْ بَاقِيَةٌ وَلَا وَقَاهُمْ مِنَ ٱللّٰهِ وَاقِيَةٌ</span> <span class="add">[<em>One remaining remained not, nor did one preserver preserve them from God</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboqae">
				<h3 class="entry"><span class="ar">أَبْقَى</span></h3>
				<div class="sense" id="Oaboqae_A1">
					<p><span class="ar">أَبْقَى</span> <em>Longer continuing.</em> <span class="auth">(Bḍ and Jel in xx. 74, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">أَبْقَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oaboqae_A2">
					<p><span class="ar long">هُوَ أَبْقَى الرَّجُلَيْنِ</span> means <span class="ar long">أَكْثَرُ إِبْقَآءً عَلَى قَوْمِهِ</span> <span class="add">[<em>He is the more merciful,</em> or <em>pitiful,</em> or <em>compassionate, of the two men, towards his people</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboqiyapN">
				<h3 class="entry"><span class="ar">مُبْقِيَةٌ</span></h3>
				<div class="sense" id="muboqiyapN_A1">
					<p><span class="ar long">نَاقَةٌ مُبْقِيَةٌ</span> <em>A she-camel</em> <span class="add">[<em>that retains some milk;</em>]</span> <em>that does not exhaust her copious supply of milk.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">مُبْقِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muboqiyapN_A2">
					<p><span class="ar long">مُبْقِيَاتُ الخَيْلِ</span>, <span class="auth">(Ḳ,)</span> or rather <span class="ar long">المُبْقِيَاتُ مِنَ الخَيْلِ</span>, <span class="auth">(TA,)</span> <em>The horses whose running continues after the running of other horses has ceased:</em> <span class="auth">(M, Ḳ:)</span> or, <em>that reserve somewhat of their running.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقى</span> - Entry: <span class="ar">مُبْقِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="muboqiyapN_A3">
					<p>And <span class="ar">المُبْقِيَاتُ</span> <em>The places that retain some of the pools in which water has collected, and do not drink it up.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0237.pdf" target="pdf">
							<span>Lanes Lexicon Page 237</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0238.pdf" target="pdf">
							<span>Lanes Lexicon Page 238</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0239.pdf" target="pdf">
							<span>Lanes Lexicon Page 239</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
