<article class="root" id="Root_be">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/227_bwh">بوه</a></span>
				<span class="ar">بى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/229_byb">بيب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="be_2">
				<h3 class="entry">2. ⇒ <span class="ar">بىّى</span></h3>
				<div class="sense" id="be_2_A1">
					<p><span class="ar long">بَيَّيْتُ الشَّىْءَ</span>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">تَبْيِىٌّ</span>, <span class="auth">(Ḳ,)</span> <em>I made the thing apparent, manifest, evident, clear, plain,</em> or <em>perspicuous.</em> <span class="auth">(Aṣ, T, Ḳ*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="be_2_B1">
					<p>Also, <span class="auth">(Ḳ, as in the TA,)</span> or<span class="arrow"><span class="ar long">تَبَّيَيْتُ↓ الشَّىْءَ</span></span> <span class="auth">(M, and so in several copies of the Ḳ,)</span> <span class="add">[both confirmed by what follows,]</span> i. q. <span class="ar">تَعَمَّدْتُهُ</span> <span class="add">[meaning <em>I directed myself,</em> or <em>my course,</em> or <em>aim, to,</em> or <em>towards, the thing; made for it,</em> or <em>towards it; made it my object;</em>, &amp;c.]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بى</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="be_2_B2">
					<p>In the saying, <span class="ar long">حَيَّاكَ ٱللّٰهُ وَبَيَّاكَ</span>, the phrase <span class="ar long">حياك ٱللّٰه</span> means <em>May God make thee to have dominion:</em> <span class="auth">(Ṣ, M:)</span> or <em>may God prolong thy life:</em> <span class="auth">(M:)</span> and <span class="ar">بيّاك</span> means <span class="ar long">اِعْتَمَدَكَ بِالتَّحِيَّةِ</span> <span class="add">[<em>may He bring thee prolongation of life;</em> lit. <em>may He direct himself to thee,</em> or the like, <em>with</em> the gift of <em>prolongation of life</em>]</span>; <span class="auth">(Aṣ, Ṣ;)</span> or <span class="ar long">قَصَدَكَ بِالتَّحِيَّةِ</span> <span class="add">[which is the same]</span>: <span class="auth">(IAạr, T:)</span> or <span class="ar long">اِعْتَمَدَكَ بِالْمُلْكِ</span> <span class="add">[<em>may He bring thee dominion</em>]</span>; <span class="auth">(M;)</span> so too says IAạr: <span class="auth">(TA:)</span> or <em>may He make thy state,</em> or <em>condition, to be good:</em> <span class="auth">(TA:)</span> or <em>may He make thee to laugh:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> so some say, accord. to Aṣ: <span class="auth">(T:)</span> and it is related that these words were addressed to Adam, in consequence of his having remained a hundred years without laughing after his son had been slain: <span class="auth">(T, Ṣ:)</span> so says AʼObeyd, on the authority of Saʼeed Ibn-Jubeyr: <span class="auth">(T:)</span> or it means <em>may He bring thee near</em> <span class="add">[<em>unto Himself</em>]</span>: <span class="auth">(Aboo-Málik, Aṣ, T, M, Ḳ:)</span> or <em>may He bring thee:</em> <span class="auth">(IAạr, Ṣ, M:)</span> or <em>may He prepare for thee an abode;</em> i. q. <span class="ar">بَوَّأَكَ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">بَوَّأَكَ مَنْزِلًا</span>; the verb being here altered in order to assimilate it to the preceding verb, <span class="ar">حَيَّا</span>: <span class="auth">(El-Aḥmar, T, Ṣ:)</span> this explanation was approved by Aṣ: <span class="auth">(Ṣ:)</span> the meaning intended thereby is, <em>may He lodge thee in an abode in Paradise:</em> <span class="auth">(TA:)</span> or, as some say, the verb in this case is an imitative sequent to that preceding it: <span class="auth">(AʼObeyd, Ṣ Ḳ:*)</span> but this is naught: <span class="auth">(Ḳ:)</span> AʼObeyd says that in his opinion it is not an imitative sequent, because an imitative sequent is scarcely ever coupled with what precedes it by <span class="ar">و</span>. <span class="auth">(Ṣ.)</span> As an ex. of <span class="ar">بَيَّا</span> in the sense of <span class="ar">قَرَّبَ</span>, Aboo-Málik cites this verse:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَيَّا لَهُمْ إِذْ نَزَلُوا الطَّعَامَا</span> *</div> 
						<div class="star">* <span class="ar long">اَلْكِبْدَ وَالمَلْحَآءَ وَالسَّنَامَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>He brought near to them,</em> i. e., <em>placed before them, when they alighted, the food,</em> namely, <em>the liver, and the flesh of the back extending from the withers to the rump, and the hump</em>]</span>. <span class="auth">(T.)</span> And IAạr, explaining <span class="ar">بيّاك</span> as meaning <span class="ar long">قصدك بالتحيّة</span>, cites the following verse:</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">لَمَّا تَبَّيَيْنَا↓ أَبَا تَمِيمِ</span></span> *</div> 
						<div class="star">* <span class="ar long">أَعْطَى عَطَآءَ اللَّحِزِ اللَّئِيمِ</span> *</div> 
					</blockquote>
					<p><span class="auth">(T.)</span> Accord. to J, the meaning in this instances may be agreeable with the explanation of <span class="ar">بيّاك</span> by <span class="ar long">اعتمدك بالتحيّة</span> <span class="add">[so that the verse may be rendered <em>When we betook ourselves with salutation to the father of Temeem,</em> or, as the verse is cited in the Ṣ, <em>to the brother of Temeem</em> (<span class="ar long">أَخَا تميم</span>), <em>he gave the gift of the niggardly, the mean</em>]</span>: or it may mean <em>we brought:</em> and the verb admits of the same double rendering in other instances. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="be_2_C1">
					<p><span class="ar long">بَيَّيْتُ بَآءً حَسَنَةً</span> and <span class="ar">حَسَنًا</span> <span class="add">[<em>I made,</em> or <em>wrote, a beautiful</em> <span class="ar">ب</span>]</span>. <span class="auth">(TA in <span class="ar long">باب الالف الليّنة</span>.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="be_5">
				<span class="pb" id="Page_0279"></span>
				<h3 class="entry">5. ⇒ <span class="ar">تبىّى</span></h3>
				<div class="sense" id="be_5_A1">
					<p><span class="ar">تبيّا</span> <em>It was,</em> or <em>became, apparent, manifest, evident, clear, plain,</em> or <em>perspicuous, being near;</em> syn. <span class="ar long">تَبَيَّنَ مِنْ قُرْبٍ</span>. <span class="auth">(Aṣ, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بى</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="be_5_B1">
					<p><a href="#be_1">See also 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaeBN">
				<h3 class="entry"><span class="ar">البَىٌّ</span></h3>
				<div class="sense" id="AlbaeBN_A1">
					<p><span class="ar">البَىٌّ</span> <em>The low, ignoble, mean,</em> or <em>contemptible, man;</em> as also<span class="arrow"><span class="ar long">اِبْنُ بَيَّانَ↓</span></span>, <span class="auth">(IAạr, T, Ḳ)</span> and <span class="ar long">ابن هَيَّانَ</span>, <span class="auth">(IAạr, T,)</span> and <span class="ar long">ابن بَىّ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">هَىُّ بْنُ بَىّ</span>, and<span class="arrow"><span class="ar long">هَيَّانُ بْنُ بَيَّانَ↓</span></span>: <span class="auth">(Lth, T:)</span> or the last two signify <em>he whose stock and branch are unknown:</em> <span class="auth">(M:)</span> or the same two, <em>he who is unknown, and whose father also is unknown:</em> <span class="auth">(Ḳ in art. <span class="ar">هى</span>; and so the latter of them is explained in the Ṣ, both there and in the present art.:)</span> and one says, <span class="ar long">مَا أَدْرِى أَىُّ هَىِّ بْنِ بَىٍّ هُوَ</span>, meaning <em>I know not what man he is.</em>. <span class="auth">(Ṣ.)</span> Accord. to some, <span class="auth">(Lth, T,)</span> <span class="ar long">هَىُّ بْنُ بَىٍّ</span> was one of the sons of Adam, that went away in the earth when the rest of his children dispersed themselves, and no trace of him was afterwards perceived. <span class="auth">(Lth, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBaAna">
				<h3 class="entry"><span class="ar">بَيَّانَ</span></h3>
				<div class="sense" id="bayBaAna_A1">
					<p><span class="ar long">اِبْنُ بَيَّانَ</span>: <a href="#AlbaeBu">see <span class="ar">البَىُّ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayawieBN.1">
				<h3 class="entry"><span class="ar">بَيَوِىٌّ</span></h3>
				<div class="sense" id="bayawieBN.1_A1">
					<p><span class="ar">بَيَوِىٌّ</span> <a href="#OabN">rel. n. of <span class="ar">بَآءٌ</span></a> or <span class="ar">بَا</span>: whence <span class="ar long">قَصِيدَةٌ بَيَوِيَّةٌ</span> <span class="add">[as also <span class="ar">بَائِيَّةٌ</span> and <span class="ar">بَاوِيَّةٌ</span>]</span> <em>A</em> <span class="ar">قصيدة</span> <em>of which the</em> <span class="ar">رَوِىّ</span> is <span class="ar">ب</span>. <span class="auth">(M in art. <span class="ar">ب</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0278.pdf" target="pdf">
							<span>Lanes Lexicon Page 278</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0279.pdf" target="pdf">
							<span>Lanes Lexicon Page 279</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
