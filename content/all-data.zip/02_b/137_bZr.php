<article class="root" id="Root_bZr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/136_bTw">بطو</a></span>
				<span class="ar">بظر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/138_bEv">بعث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bZr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بظر</span></h3>
				<div class="sense" id="bZr_1_A1">
					<p><span class="ar">بَظِرَتْ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْظَرُ</span>}</span></add>, inf. n. <span class="ar">بَظَرٌ</span>,]</span> said of a woman, <span class="add">[<em>She had a</em> <span class="ar">بَظْر</span> <span class="auth">(q. v.)</span>, or <em>a long</em> <span class="ar">بَظْر</span>; or]</span> <em>she was uncircumcised.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#baZarN">But see <span class="ar">بَظَرٌ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بظر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bZr_1_A2">
					<p>And <span class="ar">بَظِر</span>, inf. n. <span class="ar">بَظَرٌ</span>, <em>He had what is termed a</em> <span class="ar">بُظَارَة</span> <span class="add">[q. v.]</span> <em>in his upper lip.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bZr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بظّر</span></h3>
				<div class="sense" id="bZr_2_A1">
					<p><span class="ar">بَظَّرَتْ</span>, inf. n. <span class="ar">تَبْظِيرٌ</span>, <em>She circumcised</em> a female. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بظر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bZr_2_A2">
					<p><span class="ar long">هُوَ يُمِصُّهُ وَيُبَظِّرُهُ</span> <span class="auth">(M, Ḳ)</span> <em>He says to him,</em> <span class="ar long">اُمْصُصْ بَظْرَ فُلَانَةَ</span>: <span class="auth">(Ḳ:)</span> a prov. of the Arabs. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baZorN">
				<h3 class="entry"><span class="ar">بَظْرٌ</span></h3>
				<div class="sense" id="baZorN_A1">
					<p><span class="ar">بَظْرٌ</span>, <span class="auth">(Lḥ, T, Ṣ, M, &amp;c.,)</span> also pronounced <span class="ar">بَضْرٌ</span>, <span class="auth">(T,)</span> and<span class="arrow"><span class="ar">بُظَارَةٌ↓</span></span> <span class="add">[which see below]</span> <span class="auth">(Lḥ, T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">بَظَارَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">بَيْظَرٌ↓</span></span> <span class="auth">(Lḥ, T, M, Ḳ)</span> and<span class="arrow"><span class="ar">بُنْظُرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A certain thing,</em> <span class="auth">(Ṣ, M, Mgh, Ḳ,)</span> or <em>piece of flesh,</em> <span class="auth">(A,)</span> <em>between the two sides of the vulva</em> (<span class="ar">الإِسْكَتَانِ</span>, Ṣ, M, Ḳ, or <span class="ar">الشُّفْرَانِ</span>, A, or <span class="ar long">شُفْرَا الفَرْجِ</span>, Mgh) <em>of a woman,</em> <span class="auth">(M, A, Mgh, Ḳ,)</span> <em>which is cut off in circumcision,</em> <span class="auth">(A,)</span> <em>not yet cut off;</em> <span class="auth">(Ṣ;)</span> <em>a piece of flesh between the two sides of the vulva</em> (<span class="ar">الشُّفْرَانِ</span>) <em>of a woman;</em> i. e. the <em>prepuce</em> (<span class="ar">قُلْقَة</span>) <em>that is cut off in circumcision;</em> <span class="auth">(Mṣb;)</span> <em>also called</em> <span class="ar">كَيْنٌ</span> <em>and</em> <span class="ar">رَفْرَفٌ</span> <em>and</em> <span class="ar">نَوْفٌ</span> <span class="auth">(Lḥ, T)</span> <em>and</em> <span class="ar">قُنْبٌ</span> <span class="add">[which last properly signifies the “prepuce,” or “sheath,” of a beast or horse or the like]</span>; <span class="auth">(A and Ḳ in art. <span class="ar">قنب</span>;)</span> <em>and likened to a cock's comb:</em> <span class="auth">(Mṣb in art. <span class="ar">عرف</span>:)</span> <span class="add">[the last of these explanations plainly shows that what is meant thereby is the <em>prepuce of the clitoris;</em> which, it seems, in the Arabian and Egyptian races, and others throughout Eastern Africa, and still more so in the Hottentot race, grows to an extraordinary size; and this may be the reason why the <span class="ar">بظر</span> is described by some travellers as a caruncle for which we have no name: or it may, perhaps, be <em>a distinct excrescence from the prepuce of the clitoris:</em> it has been described to me as <em>a caruncle a little in front of the meatus urinarius:</em> many of the Egyptians assert that it is the <em>clitoris itself</em> that is amputated, <span class="auth">(as Ludolph also does in his Comment. to his Ethiop. Hist. p. 273, finding fault with those who say otherwise;)</span> and they affirm that this is done for the purpose of lessening the libidinous passion: such, indeed, appears to be the case in some instances, but not generally; and it may have led to a misapplication of the term <span class="ar">بظر</span> in post-classical times: an analogous practice, one still more barbarous, is said to have obtained among an African race hence called the Colobi: <a href="#barobaru">see <span class="ar">بَرْبَرُ</span></a>: Abu-l-Kásim Ez-Zahráwee speaks of the amputation of the redundance of the <span class="ar">بظر</span> when preternaturally large, and also of an excrescence in the vulva: the former he describes in such a manner as plainly shows that he means thereby the <em>clitoris:</em> the latter, in terms apparently indicating a preternatural elongation of the lower part of the prepuce of the clitoris; as “an excrescence of flesh at, or in, the mouth of the vulva, such as fills it up, and sometimes protrudes externally, like a tail, wherefore the ancients term it the caudal disease <span class="ar long">المرض الذنبى</span>; and this,” he says, “should be amputated, like as the <span class="ar">بظر</span> is amputated” when preternaturally large: <span class="auth">(Albucasis de Chirurgia, pp. 314 and 316:)</span> in some of our medical books, the term “caudatio” is defined as “an elongation of the clitoris;” inconsistently with the foregoing description of “the caudal disease:”]</span> the pl. <span class="add">[of mult.]</span> of <span class="ar">بَظْرٌ</span> is <span class="ar">بُظُورٌ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">أَبْظُرٌ</span>. <span class="auth">(Mṣb.)</span> <span class="ar long">يَا ٱبْنَ مُقَطِّعَةِ البُظُورِ</span> <span class="add">[<em>O son of her who amputates</em> <span class="ar">بظور</span>!]</span> is an expression of contumely employed by the Arabs whether the mother of the person addressed be really a circumciser of females or not. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baZarN">
				<h3 class="entry"><span class="ar">بَظَرٌ</span></h3>
				<div class="sense" id="baZarN_A1">
					<p><span class="ar">بَظَرٌ</span> The <em>having a</em> <span class="ar">بَظْر</span>: <span class="auth">(T, Ṣ:)</span> or the <em>having a long</em> <span class="ar">بَظْر</span>: <span class="auth">(Ḳ:)</span> a subst., <span class="auth">(Ḳ,)</span> or an inf. n., <span class="auth">(T,)</span> having no verb, <span class="auth">(T, M,*)</span> because it denotes an inherent quality, not one that is accidental. <span class="auth">(T.)</span> <span class="add">[<a href="#baZirato">But see <span class="ar">بَظِرَتْ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buZorapN">
				<h3 class="entry"><span class="ar">بُظْرَةٌ</span> / <span class="ar">بَظَرَةٌ</span></h3>
				<div class="sense" id="buZorapN_A1">
					<p><span class="ar">بُظْرَةٌ</span>, or <span class="ar">بَظَرَةٌ</span>: <a href="#buZaArapN">see <span class="ar">بُظَارَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baZaArapN">
				<h3 class="entry"><span class="ar">بَظَارَةٌ</span></h3>
				<div class="sense" id="baZaArapN_A1">
					<p><span class="ar">بَظَارَةٌ</span>: <a href="#baZorN">see <span class="ar">بَظْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buZaArapN">
				<h3 class="entry"><span class="ar">بُظَارَةٌ</span></h3>
				<div class="sense" id="buZaArapN_A1">
					<p><span class="ar">بُظَارَةٌ</span> The <em>lower extremity,</em> <span class="auth">(M,)</span> or <em>a thing in the extremity,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>a protuberant,</em> or <em>prominent, thing in the lower part,</em> <span class="auth">(Lḥ, T, M,)</span> <em>of the vulva</em> <span class="auth">(Lḥ, T, Ṣ, M)</span> of a ewe or goat, <span class="auth">(Lḥ, T, Ṣ, M, Ḳ,)</span> or camel, <span class="auth">(Lḥ, T,)</span> and any animal. <span class="auth">(M.)</span> It is metaphorically used by Jereer in relation to a woman. <span class="auth">(M.)</span> <a href="#baZorN">See <span class="ar">بَظْرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بظر</span> - Entry: <span class="ar">بُظَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buZaArapN_A2">
					<p>Also, <span class="auth">(Lḥ, Ṣ, T, M, &amp;c.,)</span> and<span class="arrow"><span class="ar">بُظْرَةٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> or<span class="arrow"><span class="ar">بَظَرَةٌ↓</span></span>, <span class="auth">(IAạr, T,)</span> The <em>thing</em> <span class="auth">(M, Ḳ)</span> <em>protuberant,</em> <span class="auth">(M,)</span> or <em>a protuberant thing,</em> <span class="auth">(Ṣ, A, Mgh,)</span> <em>in the upper lip,</em> <span class="auth">(Ṣ, M, A, Mgh, Ḳ,)</span> <em>in the middle thereof,</em> <span class="auth">(M, A, Mgh, Ḳ,)</span> <em>when it is somewhat long,</em> <span class="auth">(Ṣ,)</span> or <em>somewhat large:</em> <span class="auth">(M:)</span> or <em>a pro- tuberance in the lip:</em> <span class="auth">(IAạr, T:)</span> when not long, it is called <span class="ar">حِثْرِمَةٌ</span>: <span class="auth">(Ṣ:)</span> it is not every one that has it: <span class="auth">(Mgh:)</span> dim. <span class="arrow"><span class="ar">بُظَيْرَةٌ↓</span></span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buZayorapN">
				<h3 class="entry"><span class="ar">بُظَيْرَةٌ</span></h3>
				<div class="sense" id="buZayorapN_A1">
					<p><span class="ar">بُظَيْرَةٌ</span>: <a href="#buZaArapN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biZoriyrN">
				<h3 class="entry"><span class="ar">بِظْرِيرٌ</span></h3>
				<div class="sense" id="biZoriyrN_A1">
					<p><span class="ar">بِظْرِيرٌ</span> † A <em>long-tongued,</em> <span class="auth">(M,)</span> <em>clamorous</em> woman: <span class="auth">(M, Ḳ: <span class="add">[in the CK, erroneously, with <span class="ar">ة</span>:]</span>)</span> but some say <span class="ar">بِطْرِيرٌ</span> <span class="add">[q. v.]</span>. <span class="auth">(M.)</span> <span class="add">[<a href="#OaboZaru">See <span class="ar">أَبْظَرُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bunoZurN">
				<h3 class="entry"><span class="ar">بُنْظُرٌ</span></h3>
				<div class="sense" id="bunoZurN_A1">
					<p><span class="ar">بُنْظُرٌ</span>: <a href="#baZorN">see <span class="ar">بَظْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoZarN">
				<h3 class="entry"><span class="ar">بَيْظَرٌ</span></h3>
				<div class="sense" id="bayoZarN_A1">
					<p><span class="ar">بَيْظَرٌ</span>: <a href="#baZorN">see <span class="ar">بَظْرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بظر</span> - Entry: <span class="ar">بَيْظَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayoZarN_A2">
					<p><span class="ar long">يَا بَيْظَرُ</span> is an expression of contumely addressed to a female slave. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboZaru">
				<h3 class="entry"><span class="ar">أَبْظَرُ</span></h3>
				<div class="sense" id="OaboZaru_A1">
					<p><span class="ar">أَبْظَرُ</span> A man <em>uncircumcised.</em> <span class="auth">(M, Ḳ.)</span> And the fem., <span class="ar">بَظْرَآءُ</span>, A woman, <span class="auth">(T, Ṣ, Mṣb,)</span> or a female slave, <span class="auth">(M, Ḳ,)</span> <em>having a</em> <span class="ar">بَظْر</span>; <span class="auth">(T, Ṣ, Mṣb;)</span> or <em>having a long</em> <span class="ar">بَظْر</span>: <span class="auth">(M, Ḳ:)</span> or a woman <em>uncircumcised:</em> <span class="auth">(Mgh:)</span> pl. <span class="ar">بُظْرٌ</span>. <span class="auth">(T.)</span> <span class="ar long">يَا ٱبْنَ البَظْرَآءِ</span> <em>O son of the uncircumcised woman!</em> is an expression of contumely. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بظر</span> - Entry: <span class="ar">أَبْظَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboZaru_A2">
					<p>A man <em>having what is termed a</em> <span class="ar">بُظَارَة</span> <em>in his upper lip;</em> <span class="auth">(Ṣ, A, Mgh;)</span> <span class="add">[i. e.]</span> <em>having a</em> <span class="ar">حِثْرِمَة</span> <em>somewhat long;</em> <span class="auth">(Ṣ in art. <span class="ar">حثرم</span>;)</span> <em>having a long</em> <span class="auth">(T, M)</span> <em>and projecting</em> <span class="auth">(M)</span> <em>upper lip, with a protuberance in the middle of it.</em> <span class="auth">(T, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بظر</span> - Entry: <span class="ar">أَبْظَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaboZaru_A3">
					<p>Accord. to some, † <em>Clamorous; long-tongued.</em> <span class="auth">(Mgh.)</span> <span class="add">[<a href="#biZoriyrN">See <span class="ar">بِظْرِيرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaZBirN">
				<h3 class="entry"><span class="ar">مُبَظِّرٌ</span></h3>
				<div class="sense" id="mubaZBirN_A1">
					<p><span class="ar">مُبَظِّرٌ</span> <em>A circumciser:</em> <span class="auth">(M, L:)</span> and <span class="ar">مُبَظِّرَةٌ</span> <em>a woman who circumcises females.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0222.pdf" target="pdf">
							<span>Lanes Lexicon Page 222</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
