<article class="root" id="Root_bcl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/054_bcq">بذق</a></span>
				<span class="ar">بذل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/056_bcw">بذو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bcl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بذل</span></h3>
				<div class="sense" id="bcl_1_A1">
					<p><span class="ar">بَذَلَهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُلُ</span>}</span></add> <span class="auth">(Ṣ, M,* Mṣb, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْذِلُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَذْلٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>He gave it, and was liberal,</em> or <em>bountiful, with it; he gave it liberally, bountifully, unsparingly,</em> or <em>freely;</em> <span class="auth">(Ṣ, Mṣb, Ḳ, TA;)</span> <em>he gave it willingly, of his own free will</em> or <em>good pleasure:</em> <span class="auth">(TA:)</span> and <em>he made it allowable,</em> or <em>lawful, to be taken</em> or <em>possessed</em> or <em>done, willingly,</em> or <em>of his own free will</em> or <em>good pleasure:</em> <span class="auth">(Mṣb:)</span> <span class="ar">بَذْلٌ</span> is the <em>contr. of</em> <span class="ar">مَنْعٌ</span>. <span class="auth">(M.)</span> <span class="add">[Hence,]</span> <span class="ar long">سَأَلْتُهُ فَأَعْطَانِى بَذْلَ يَمِينِهِ</span> <em>I asked him, and he gave me what he was able to give.</em> <span class="auth">(TA.)</span> <span class="add">[And <span class="ar long">بَذَلَ لَهُ نَفْسَهُ</span>. † <em>He gave up himself to,</em> or <em>spent himself for, him</em> or <em>it; he gave,</em> or <em>applied, himself,</em> or <em>his mind, unsparingly to it,</em> namely, an undertaking, &amp;c.: a phrase of frequent occurrence. And <span class="ar long">بَذَلَ جَهْدَهُ</span>, and <span class="ar">مَجْهُودَهُ</span>, † <em>He exerted,</em> or <em>put forth,</em> or <em>expended, unsparingly,</em> or <em>freely, his power,</em> or <em>ability,</em> or <em>his utmost power</em> or <em>ability</em> or <em>endeavour:</em> also of frequent occurrence.]</span> And <span class="ar long">فَرَسٌ لَهُ صَوْنٌ وَبَذْلٌ</span> ‡ <em>A horse that reserves a portion of his run, and is unsparing with a portion thereof; not putting forth the whole at once:</em> <span class="auth">(TA:)</span> or <em>that has a run which he reserves</em> <span class="add">[<em>for the time of need</em>]</span>, <em>and a run which he performs unsparingly:</em> <span class="auth">(A in art. <span class="ar">شهد</span>: <a href="#XaAhidN">see <span class="ar">شَاهِدٌ</span></a>:)</span> and<span class="arrow"><span class="ar long">فَرَسٌ ذُو صَوْنٍ وَٱبْتِذَالٍ↓</span></span> <em>a horse that has a running pace</em> (<span class="ar">حُضْرٌ</span>) <em>which he has reserved for the time of need, and a run</em> (<span class="ar">عَدْوٌ</span>) <em>less quick which he has performed freely,</em> or <em>without reservation</em> (<span class="ar long">قَدِ ٱبْتَذَلَهُ</span>). <span class="auth">(T.)</span> <span class="add">[In the Ḳ these phrases are given in a mutilated state, and with a mutilated explanation.]</span> And <span class="ar long">صَوْنُهُ خَيْرٌ مِنْ بَذْلِهِ</span> ‡ <em>His interior state,</em> or <em>disposition of mind, is better than his apparent state</em>, &amp;c. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcl_1_A2">
					<p><a href="#bcl_8">See also 8</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبذّل</span></h3>
				<div class="sense" id="bcl_5_A1">
					<p><span class="ar">تبذّل</span> <em>He neglected the preserving of himself</em> or <em>his honour</em> or <em>reputation</em> <span class="add">[from disgrace]</span>; <em>i. q.</em> <span class="ar long">تَرَكَ التَّصَاوُنَ</span> <span class="auth">(Ṣ)</span> or <span class="ar">التَّصَوُّنَ</span>; <span class="auth">(TA;)</span> <em>he was careless of himself</em> or <em>his honour</em> or <em>reputation; contr. of</em> <span class="ar">تَصَاوَنَ</span>; <span class="auth">(Mṣb in the present art,;)</span> as also<span class="arrow"><span class="ar">ابتذل↓</span></span>. <span class="auth">(Mṣb in art. <span class="ar">صون</span>.)</span> You say, <span class="ar long">كَرُمَ وَلَمْ يَتَبَذَّلْ</span> <span class="add">[<em>He was generous, and was not careless of his honour</em> or <em>reputation</em>]</span>. <span class="auth">(M and L in art. <span class="ar">وفر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcl_5_A2">
					<p><span class="ar long">تبذّل فِى عَمَلِ كَذَا</span>, and<span class="arrow"><span class="ar long">ابتذل↓ نَفْسَهُ فِيهِ</span></span> and <span class="ar">بِهِ</span>, <em>He employed his own self in the doing of such a thing.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتذل</span></h3>
				<div class="sense" id="bcl_8_A1">
					<p><span class="ar">اِبْتِذَالٌ</span> is the <em>contr. of</em> <span class="ar">صِيَانَةٌ</span>; <span class="auth">(M, Ḳ;)</span> <span class="add">[i. e.]</span> <span class="ar">ابتذلهُ</span> signifies <em>He held it in mean estimation;</em> namely, a garment or other thing; <span class="auth">(TA;)</span> <span class="add">[<em>he was careless of it; he used it,</em> or <em>employed it, on,</em> or <em>for, ordinary, mean,</em> or <em>vile, occasions,</em> or <em>purposes;</em>]</span> <em>he used it for service and work;</em> namely, a garment, &amp;c.; syn. <span class="ar">اِمْتَهَنَهُ</span>; <span class="auth">(Ṣ, Mṣb;)</span> <em>he wore it</em> <span class="auth">(a garment)</span> <em>in times of service and work;</em> as also<span class="arrow"><span class="ar">بَذَلَهُ↓</span></span>; <span class="auth">(Mṣb, TA;)</span> or, as IḲooṭ says, <span class="ar">بَذَلَهُ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُلُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْذِلُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَذْلَةٌ</span> and <span class="ar">بِذْلَةٌ</span>, signifies <em>he did not preserve it, lay it up, take care of it,</em> or <em>reserve it;</em> namely, a garment. <span class="auth">(Mṣb.)</span> <a href="#bcl_5">See also 5</a>, in two places. You say also, <span class="ar long">ابتذل عَدْوَهُ</span> † <span class="add">[<em>He</em> <span class="auth">(a horse)</span> <em>performed his run freely,</em> or <em>without reservation;</em> opposed to <span class="ar">صَانَهُ</span>]</span>. <span class="auth">(T.)</span> <a href="#bcl_1">See 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبذل</span></h3>
				<div class="sense" id="bcl_10_A1">
					<p><span class="ar">استبذلهُ</span> <em>He sought,</em> or <em>demanded, of him a liberal, free,</em> or <em>willing, gift.</em> <span class="auth">(TA.)</span> And <span class="ar long">اِسْتَبْذَلْتُ فُلَانًا شَيْئًا</span> <em>I asked of such a one that he would liberally, freely,</em> or <em>willingly, give me a thing.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacolN">
				<h3 class="entry"><span class="ar">بَذْلٌ</span></h3>
				<div class="sense" id="bacolN_A1">
					<p><span class="ar">بَذْلٌ</span> <em>A thing that is given liberally, freely,</em> or <em>willingly:</em> and inf. n. <span class="add">[or 1, q. v.]</span>, used as a proper subst.: pl. <span class="ar">بُذُولٌ</span>. <span class="auth">(Ḥar p. 206.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bacolapN">
				<h3 class="entry"><span class="ar">بَذْلَةٌ</span></h3>
				<div class="sense" id="bacolapN_A1">
					<p><span class="ar">بَذْلَةٌ</span>: <a href="#bicolapN">see what next follows</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bicolapN">
				<h3 class="entry"><span class="ar">بِذْلَةٌ</span></h3>
				<div class="sense" id="bicolapN_A1">
					<p><span class="ar">بِذْلَةٌ</span> <em>A garment that is worn</em> <span class="auth">(T, Ṣ, Mṣb)</span> <em>in service,</em> or <em>work;</em> <span class="auth">(Ṣ, Mṣb;)</span> <em>that is not preserved, laid up, taken care of,</em> or <em>reserved;</em> <span class="auth">(T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَذْلَةٌ↓</span></span> <span class="auth">(Mṣb)</span> and<span class="arrow"><span class="ar">مبْذَلٌ↓</span></span>, <span class="auth">(T,)</span> or<span class="arrow"><span class="ar">مِبْذَلَةٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> the pl. of which is <span class="ar">مَبَاذِلٌ</span>: <span class="auth">(Ṣ:)</span> and <em>an old and worn-out garment;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">مِبْذَلٌ↓</span></span> and<span class="arrow"><span class="ar">مِبْذَلَةٌ↓</span></span>; <span class="auth">(M, Ḳ;)</span> the last of which is mentioned on the authority of AZ, but is disapproved by ʼAlee Ibn-Hamzeh, who asserts it to be without <span class="ar">ة</span>: <span class="auth">(IB, TA:)</span> <span class="ar">بِذْلَةٌ</span> sometimes has <span class="ar">بِذَلٌ</span> as pl. <span class="auth">(TA.)</span> You say,<span class="arrow"><span class="ar long">جَآءَ نَا فُلَانٌ فِى مَبَاذِلِه↓</span></span>, i. e. <span class="ar long">فِى ثِيَابِ بِذْلَتِهِ</span> or<span class="arrow"><span class="ar">بَذْلَتِهِ↓</span></span> <span class="add">[<em>Such a one came to us in his garments that he wore in service,</em> or <em>work</em>]</span>. <span class="auth">(Ṣ, accord. to different copies. <span class="add">[I have shown that <span class="ar">بِذْلَةٌ</span> and <span class="ar">بَذْلَةٌ</span> are dial. vars., both as inf. ns. (<a href="#bcl_8">see 8</a>)</span> and as proper substs.]</span>) The word <span class="ar">بَدْلَةٌ</span>, with fet-ḥ, and with the unpointed <span class="ar">د</span>, applied by the vulgar to <span class="add">[a suit of]</span> new clothes, is a mistake for <span class="ar">بِذْلَةٌ</span>, and this is correctly a name for old and worn-out clothes. <span class="auth">(TA. <span class="add">[But this is doubtful; for <span class="ar">بَدْلَةٌ</span> commonly signifies, in modern Arabic, a change of clothes; and hence, a suit of clothes, whether new or old.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: <span class="ar">بِذْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bicolapN_A2">
					<p>IJ uses it metaphorically, in relation to poetry; saying, <span class="ar long">الرَّجَزُ إِنَّمَا يُسْتَعَانُ بِهِ فِى البِذْلَةِ وَعِنْدَ الاِعْتِمَالِ وَالحُدَآءِ وَالمِهْنَةِ</span> ‡ <span class="add">[<em>The</em> metre termed <em>rejez is only used as an aid in the ordinary,</em> or <em>meaner, business of life, and on the occasion of doing one's work, and singing to camels for the purpose of urging them on, and performing service of any kind:</em> but in this case it may be regarded as an inf. n.: <a href="#bcl_8">see 8</a>]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bacuwlN">
				<h3 class="entry"><span class="ar">بَذُولٌ</span></h3>
				<div class="sense" id="bacuwlN_A1">
					<p><span class="ar">بَذُولٌ</span>: <a href="#bacBaAlN">see <span class="ar">بَذَّالٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacaAlapN">
				<h3 class="entry"><span class="ar">بَذَالَةٌ</span></h3>
				<div class="sense" id="bacaAlapN_A1">
					<p><span class="ar">بَذَالَةٌ</span> <em>i. q.</em> <span class="ar">بَذْلٌ</span> <span class="add">[<a href="#bcl_1">inf. n. of 1</a>, The <em>act of giving liberally,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacBaAlN">
				<h3 class="entry"><span class="ar">بَذَّالٌ</span></h3>
				<div class="sense" id="bacBaAlN_A1">
					<p><span class="ar">بَذَّالٌ</span> A man <em>wont to give property liberally, freely,</em> or <em>willingly;</em> or <em>who so gives it much,</em> or <em>frequently;</em> as also<span class="arrow"><span class="ar">بَذُولٌ↓</span></span> <span class="auth">(T, TA)</span> <span class="add">[and app.<span class="arrow"><span class="ar">مِبْذَالٌ↓</span></span>, <span class="auth">(like <span class="ar">مِسْمَاحٌ</span>, &amp;c.,)</span> of which the pl. occurs in the following saying]</span>. <span class="arrow"><span class="ar long">هُمْ مَبَاذِيلُ↓ لِلْمَعْرُوفِ</span></span> <span class="add">[<em>They are very liberally disposed to the exercise of beneficence,</em> or <em>bounty</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAcilN">
				<h3 class="entry"><span class="ar">بَاذِلٌ</span></h3>
				<div class="sense" id="baAcilN_A1">
					<p><span class="ar">بَاذِلٌ</span> Any one <em>who gives</em> <span class="add">[<em>liberally,</em>]</span> <em>freely,</em> or <em>willingly.</em> <span class="auth">(M.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibocilN">
				<span class="pb" id="Page_0175"></span>
				<h3 class="entry"><span class="ar">مِبْذِلٌ</span></h3>
				<div class="sense" id="mibocilN_A1">
					<p><span class="ar">مِبْذِلٌ</span>: <a href="#bicolapN">see <span class="ar">بِذْلَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibocalapN">
				<h3 class="entry"><span class="ar">مِبْذَلَةٌ</span> / <span class="ar">مَبَاذِلُ</span></h3>
				<div class="sense" id="mibocalapN_A1">
					<p><span class="ar">مِبْذَلَةٌ</span>; and its pl. <span class="ar">مَبَاذِلُ</span>: <a href="#bicolapN">see <span class="ar">بِذْلَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibocaAlN">
				<h3 class="entry"><span class="ar">مِبْذَالٌ</span> / <span class="ar">مَبَاذِيلُ</span></h3>
				<div class="sense" id="mibocaAlN_A1">
					<p><span class="ar">مِبْذَالٌ</span>; pl. <span class="ar">مَبَاذِيلُ</span>: <a href="#bacBaAlN">see <span class="ar">بَذَّالٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotacalN">
				<h3 class="entry"><span class="ar">مُبْتَذَلٌ</span></h3>
				<div class="sense" id="mubotacalN_A1">
					<p><span class="ar">مُبْتَذَلٌ</span> <em>Held in mean estimation:</em> as in the saying, <span class="ar long">مَالُهُ مَصُونٌ وَعِرْضُهُ مُبْتَذَلٌ</span> <span class="add">[<em>His wealth is preserved,</em> or <em>taken care of, and his honour,</em> or <em>reputation, is held in mean estimation</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: <span class="ar">مُبْتَذَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubotacalN_A2">
					<p>† Language, and a proverb, <em>which one is wont to speak</em> or <em>mention,</em> or <em>which one is fond of speaking</em> or <em>mentioning.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: <span class="ar">مُبْتَذَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mubotacalN_A3">
					<p><span class="ar long">فُلَانٌ صَدْقُ المُبْتَذَلِ</span> <em>Such a one is strong,</em> or <em>sturdy, in the work in which he employs himself:</em> <span class="auth">(T:)</span> or <em>sharp, vigorous,</em> or <em>effective, in nature,</em> or <em>disposition; one who, when employed in a work, is found to be strong,</em> or <em>sturdy.</em> <span class="auth">(TA.)</span> And <span class="ar long">سَيْفٌ صَدْقُ المُبْتَذَلِ</span> ‡ <em>A sword sharp,</em> or <em>penetrating, in the part with which one strikes.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotacilN">
				<h3 class="entry"><span class="ar">مُبْتَذِلٌ</span></h3>
				<div class="sense" id="mubotacilN_A1">
					<p><span class="ar">مُبْتَذِلٌ</span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">مُتَبَذِّلٌ↓</span></span>, <span class="auth">(M, <span class="add">[so in a copy of that work, accord. to the TT, but this is probably a mistranscription,]</span>)</span> <em>Wearing a</em> <span class="ar">مِبْذَل</span>, i. e. <span class="add">[a <em>garment used in service</em> or <em>work,</em> or]</span> <em>an old and worn-out garment:</em> <span class="auth">(M, Ḳ:)</span> and the latter, <span class="add">[if not a mistranscription for the former,]</span> <em>neglecting the adorning of himself, by way of humility.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: <span class="ar">مُبْتَذِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubotacilN_A2">
					<p><a href="#mutabacBilN">See also what follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabacBilN">
				<h3 class="entry"><span class="ar">مُتَبَذِّلٌ</span></h3>
				<div class="sense" id="mutabacBilN_A1">
					<p><span class="ar">مُتَبَذِّلٌ</span> <span class="auth">(T, M, Ḳ)</span> and<span class="arrow"><span class="ar">مُبْتَذِلٌ↓</span></span> <span class="auth">(M, Ḳ)</span> A man <em>who employs his own self in doing a thing;</em> <span class="auth">(T;)</span> a man <em>who performs his own work.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذل</span> - Entry: <span class="ar">مُتَبَذِّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutabacBilN_A2">
					<p><a href="#mubotacilN">See also what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0174.pdf" target="pdf">
							<span>Lanes Lexicon Page 174</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0175.pdf" target="pdf">
							<span>Lanes Lexicon Page 175</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
