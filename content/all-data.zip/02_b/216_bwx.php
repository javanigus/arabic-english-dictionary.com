<article class="root" id="Root_bwx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/215_bwH">بوح</a></span>
				<span class="ar">بوخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/217_bwd">بود</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwx_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوخ</span> ⇒ <span class="ar">باخ</span></h3>
				<div class="sense" id="bwx_1_A1">
					<p><span class="ar long">بَاخَتِ النَّارُ</span>, <span class="auth">(Ṣ, A, L, Ḳ,)</span> aor. <span class="ar">تَبُوخُ</span>, inf. n. <span class="ar">بَوْخٌ</span> and <span class="ar">بُؤُوخٌ</span> and <span class="ar">بَوَخَانٌ</span>, <span class="auth">(L,)</span> <em>The fire abated;</em> or <em>became allayed:</em> <span class="auth">(Ṣ, L, Ḳ:*)</span> or <em>became extinguished,</em> or <em>quenched.</em> <span class="auth">(A.)</span> And <span class="ar long">باخ الحَرُّ</span> <em>The heat abated,</em> or <em>became allayed.</em> <span class="auth">(Ṣ, A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwx_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَاخَتِ الحُمَّى</span> † <em>The fever abated,</em> or <em>became allayed.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">باخ عَنْهُ الوِرْدُ</span> ‡ <em>His fever abated,</em> or <em>remitted.</em> <span class="auth">(A, TA.)</span> And <span class="ar long">باخ غَضَبُهُ</span> ‡ <em>His anger abated,</em> or <em>became assuaged.</em> <span class="auth">(Ṣ,* A, Ḳ.*)</span> And <span class="ar long">بَيْنَهُمْ حَرْبٌ مَا يَبُوخُ سَعِيرُهَا</span> † <em>Between them is war of which the fire does not become extinguished,</em> or <em>quenched.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwx_1_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar">باخ</span> likewise signifies ‡ <em>He became fatigued,</em> <span class="auth">(Ṣ, L, Ḳ,)</span> <em>and out of breath.</em> <span class="auth">(L)</span> You say, <span class="ar long">عَدَا حَتَّٓى بَاخَ</span> <span class="auth">(Ṣ, A, L)</span> ‡ <em>He ran until he became fatigued</em> <span class="auth">(Ṣ, L)</span> <em>and out of breath.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwx_1_A4">
					<p>† <em>He</em> <span class="auth">(a man)</span> <em>flagged;</em> or <em>became remiss,</em> or <em>languid.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوخ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bwx_1_A5">
					<p>Also, inf. n. <span class="ar">بُؤُوخٌ</span>, † <em>It</em> <span class="auth">(flesh-meat)</span> <em>became altered,</em> or <em>changed in odour or otherwise for the worse,</em> <span class="auth">(Ḳ, TA,)</span> <em>And corrupted,</em> or <em>tainted.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwx_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابوخ</span> ⇒ <span class="ar">اباخ</span></h3>
				<div class="sense" id="bwx_4_A1">
					<p><span class="ar">اباخ</span> <em>He extinguished,</em> or <em>quenched,</em> fire. <span class="auth">(A, Ḳ.)</span> And <em>He</em> <span class="auth">(God)</span> <em>abated,</em> or <em>allayed,</em> the heat. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوخ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwx_4_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">اباخ النّائِرَةَ بَيْنَهُمْ</span> ‡ <span class="add">[<em>He extinguished,</em> or <em>assuaged, the discord,</em> or <em>rancour,</em> or <em>enmity, that was between them</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوخ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwx_4_A3">
					<p>And <span class="ar long">أَبِخْ عَنْكَ مِنَ الظَّهِيرِةَ</span> † <em>Stay thou until the midday-heat shall have become allayed, and the air be cool.</em> <span class="auth">(IAạr, TA in art. <span class="ar">فيح</span> and in the present art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwxN">
				<h3 class="entry"><span class="ar">بُوخٌ</span></h3>
				<div class="sense" id="buwxN_A1">
					<p><span class="ar">بُوخٌ</span> <em>A state of confusion,</em> or <em>perplexedness.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">هُمْ فِى بُوخٍ مِنْ أَمْرِهِمْ</span> <em>They are in a state of confusion,</em> or <em>perplexedness, with respect to their affair,</em> or <em>case.</em> <span class="auth">(Ṣ, Ḳ.*)</span> And it is said in a prov., <span class="ar long">وَقَعُوا فِى دُوكَةٍ وَبَوخٍ</span>, meaning <em>They fell into evil,</em> or <em>mischief, and altercation.</em> <span class="auth">(Meyd, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0274.pdf" target="pdf">
							<span>Lanes Lexicon Page 274</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
