<article class="root" id="Root_bTn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/134_bTm">بطم</a></span>
				<span class="ar">بطن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/136_bTw">بطو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTn_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطن</span></h3>
				<div class="sense" id="bTn_1_A1">
					<p><span class="ar">بَطُنَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُنُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَطَانَةٌ</span>, <span class="auth">(TA,)</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, big,</em> or <em>large, in the belly,</em> <span class="auth">(Ḳ, TA,)</span> <em>in consequence of much eating.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTn_1_A2">
					<p>And <span class="ar">بَطِنَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْطَنُ</span>}</span></add>, inf. n. <span class="ar">بَطَنٌ</span>, <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, big,</em> or <em>large, in the belly, in consequence of satiety,</em> <span class="auth">(Ṣ, TA,)</span> <em>and disordered therein:</em> <span class="auth">(TA:)</span> <em>he was,</em> or <em>became, in a state of repletion,</em> or <em>much filled with food.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTn_1_A3">
					<p>And <span class="add">[hence,]</span> <span class="ar">بَطِنَ</span> signifies also ‡ <em>i. q.</em> <span class="ar">أَشِرَ</span> and <span class="ar">بَطِرَ</span> <span class="add">[<em>He exulted,</em> or <em>exulted greatly,</em> or <em>excessively, and behaved insolently and unthankfully,</em> or <em>ungratefully:</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTn_1_A4">
					<p><span class="ar">بُطِنَ</span> <em>He</em> <span class="auth">(a man, Ṣ, TA)</span> <em>had a complaint of,</em> or <em>a disease in,</em> or <em>a pain in, his belly.</em> <span class="auth">(Ṣ, Mṣb, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTn_1_B1">
					<p><span class="ar">بَطَنَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُنُ</span>}</span></add>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">بَطْنٌ</span>, <span class="auth">(TA,)</span> <em>He struck,</em> or <em>beat, his belly;</em> as also <span class="ar long">بَطَنَ لَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> accord. to some, or the <span class="ar">ل</span> is added <span class="add">[only]</span> in verse; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">بطّنهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْطِينٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bTn_1_B2">
					<p><em>It</em> <span class="auth">(a disease)</span> <em>entered into him:</em> <span class="add">[as though it penetrated into his belly: <a href="#bTn_10">see 10</a>:]</span> in this sense it has for its inf. n. <span class="ar">بُطُونٌ</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَطَنَتْ بِهِ الحُمَّى</span> <em>The fever produced an effect within him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bTn_1_B3">
					<p><em>He entered into it;</em> namely, a valley; <span class="auth">(Ṣ, TA;)</span> in which sense it has for its inf. n. <span class="ar">بَطْنٌ</span>; and<span class="arrow"><span class="ar">تبطّنهُ↓</span></span> signifies the same: or the latter, <em>he went about in it;</em> namely, the valley; as also<span class="arrow"><span class="ar">استبطنهُ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bTn_1_B4">
					<p>‡ <span class="add">[<em>He penetrated into it mentally;</em>]</span> <em>he knew it;</em> <span class="auth">(Mṣb, Ḳ, TA;)</span> namely, the news or story, or the state or case, of another: <span class="auth">(Ḳ, TA:)</span> ‡ <em>he knew the inward,</em> or <em>intrinsic, state</em> or <em>circumstances thereof;</em> <span class="auth">(Ṣ, Mṣb, TA;)</span> i. e., of a case, or an affair; <span class="auth">(Ṣ, TA;)</span> <span class="pb" id="Page_0220"></span>as also<span class="arrow"><span class="ar">استبطنهُ↓</span></span>: <span class="auth">(Ḳ, A, TA:)</span> and<span class="arrow"><span class="ar">تبطّنهُ↓</span></span> † <em>he entered into it so that he knew its inward,</em> or <em>intrinsic, state</em> or <em>circumstances.</em> <span class="auth">(Ḥam p. 688.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="bTn_1_B5">
					<p><span class="ar long">بَطَنَ بِفُلَانٍ</span>, accord. to the Ṣ and M, but in the Ḳ <span class="ar long">مِنْ فُلَانٍ</span>, <span class="auth">(TA,)</span> ‡ <em>He became one of his particular,</em> or <em>special, intimates, friends,</em> or <em>associates,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>entering into his affair</em> <span class="add">[or <em>affairs</em>]</span>: <span class="auth">(TA:)</span> or <span class="ar long">بَطَنَ بِهِ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُنُ</span>}</span></add>, inf. n. <span class="ar">بُطُونٌ</span> and <span class="ar">بَطَانَةٌ</span>, means † <em>he entered into his affair</em> <span class="add">[or <em>affairs</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B6</span>
				</div>
				<div class="sense" id="bTn_1_B6">
					<p>And <span class="ar">بَطَنَ</span>, <span class="auth">(Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُنُ</span>}</span></add>, said of a thing, <span class="auth">(Mṣb,)</span> <em>It was,</em> or <em>became, unapparent, hidden, concealed,</em> or <em>covert;</em> <span class="auth">(Ḳ, TA;)</span> <em>contr. of</em> <span class="ar">ظَهَرَ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B7</span>
				</div>
				<div class="sense" id="bTn_1_B7">
					<p><a href="#bTn_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_2">
				<h3 class="entry">2. ⇒ <span class="ar">بطّن</span></h3>
				<div class="sense" id="bTn_2_A1">
					<p><span class="ar">بطّنهُ</span>, inf. n. <span class="ar">تَبْطِينٌ</span>: <a href="#bTn_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTn_2_A2">
					<p><a href="#bTn_4">See also 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTn_2_A3">
					<p><em>He put a</em> <span class="ar">بِطَانَة</span>, i. e. a <em>lining, to it;</em> namely, a garment, or piece of cloth; <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابطنهُ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTn_2_A4">
					<p><span class="ar long">بطّن لِحَيَتَهُ</span>, inf. n. as above, <em>He took,</em> or <em>cut off, from that part of his beard which was beneath the chin and lower jaw.</em> <span class="auth">(Sh, Nh, TA.)</span> Accord. to the copies of the Ḳ, <span class="ar long">تَبْطِينُ اللِّحْيَةِ</span> signifies the <em>not</em> doing so: but this is wrong. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_3">
				<h3 class="entry">3. ⇒ <span class="ar">باطن</span></h3>
				<div class="sense" id="bTn_3_A1">
					<p><span class="ar long">بَاطَنْتُ صَاحِبِى</span> <em>i. q.</em> <span class="ar">شددته</span> <span class="add">[app. a mistranscription for <span class="ar">شَاوَرْتُهُ</span>, meaning † <em>I consulted with my companion in order to know what was in his mind</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطن</span></h3>
				<div class="sense" id="bTn_4_A1">
					<p><span class="ar long">ابطن البَعِيرَ</span>, <span class="auth">(IAạr, Ṣ, Ḳ,)</span> inf. n. <span class="ar">إِبْطَانٌ</span>, <span class="auth">(Ṣ,)</span> <em>He bound,</em> or <em>made fast, the camel's</em> <span class="ar">بِطَان</span> <span class="add">[or <em>belly-girth</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بطّنهُ↓</span></span>, accord. to the copies of the Ḳ; but this is a mistake for<span class="arrow"><span class="ar">بَطَنَهُ↓</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُنُ</span>}</span></add>, inf. n. <span class="ar">بَطْنٌ</span>; which last verb, however, though said by Az to be a dial. var., is disallowed by IAạr and by AHeyth. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTn_4_A2">
					<p><span class="ar long">أَبْطَنْتُ السِّيْفَ كَشْحِى</span> <span class="auth">(Ṣ, TA)</span> <em>I put the sword beneath my waist.</em> <span class="auth">(TA.)</span> And <span class="ar long">ابطن كَشْحَهُ سَيْفَهُ</span> † <em>He made his sword to be his</em> <span class="arrow"><span class="ar">بِطَانَة↓</span></span> <span class="add">[app. meaning his <em>secret companion</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[This seems to be from the phrase next following.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTn_4_A3">
					<p><span class="ar long">أَبْطَنْتُ الرَّجُلَ</span> † <em>I made the man to be one of my particular,</em> or <em>special, intimates, friends,</em> or <em>associates;</em> <span class="auth">(Ṣ, TA;*)</span> <em>took him as a</em> <span class="ar">بِطَانَة</span>. <span class="auth">(TA.)</span> One says also,<span class="arrow"><span class="ar long">اِسْتَبْطَنْتُ↓ فُلَانًا دُونَكَ</span></span> <span class="auth">(Ḥam p. 688; <span class="add">[there rendered by <span class="ar">خامصته</span>, app. a mistranscription for <span class="ar">خَصَصْتُهُ</span>; meaning † <em>I took,</em> or <em>chose, such a one particularly,</em> or <em>specially, for my companion, in preference to thee:</em> it is said in explanation of the phrase <span class="ar long">مُسْتَبْطِنًا سَيْفِى</span>, which seems to mean † <em>taking my sword as my special companion,</em> or <em>putting it beneath my waist;</em> so that<span class="arrow"><span class="ar long">استبطن↓ سَيْفَهُ</span></span> is similar to one, or both, of two phrases mentioned above in this paragraph.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTn_4_A4">
					<p><a href="#bTn_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبطّن</span></h3>
				<div class="sense" id="bTn_5_A1">
					<p><span class="ar">تبطّن</span> <em>He filled the</em> <span class="add">[meaning <em>his</em>]</span> <em>belly.</em> <span class="auth">(Ḥar p. 176.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTn_5_A2">
					<p><span class="ar long">تبطّن جَارِيَةً</span> <span class="auth">(Sh, Ṣ, TA)</span> <em>He made his</em> <span class="ar">بَطْن</span> <em>to be in contact with that of a girl, skin to skin:</em> <span class="auth">(Sh, TA:)</span> or <em>inivit puellam;</em> i. e. <span class="ar long">أَوْلَحَ ذَكَرَهُ فِيهَا</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTn_5_A3">
					<p><span class="ar long">تبطّن الكَلَأَ</span> <em>He was,</em> or <em>became, in the middle,</em> or <em>midst, of the herbage:</em> <span class="auth">(TA:)</span> or <em>he went round about in the herbage.</em> <span class="auth">(Ṣ.)</span> <a href="#bTn_1">See also 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباطن</span></h3>
				<div class="sense" id="bTn_6_A1">
					<p><span class="ar">تباطن</span> <em>It</em> <span class="auth">(a place)</span> <em>was far-extending; one part thereof being remote from another.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتطن</span></h3>
				<div class="sense" id="bTn_8_A1">
					<p><span class="ar long">اِبْتَطَنْتُ النَّاقَةَ عَشَرَةَ أَبْطُنٍ</span> <em>I assisted the she-camel in bringing forth,</em> or <em>delivered her of her young, ten times.</em> <span class="auth">(Ṣ, TA. <span class="add">[Golius and Freytag render the verb by “<span class="la">ventre enixa fuit:</span>” and the former renders the phrase above (incorrectly printed in his Lex.)</span> by “<span class="la">peperit camela decem vicibus.</span>”]</span>)</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTn_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبطن</span></h3>
				<div class="sense" id="bTn_10_A1">
					<p><span class="ar long">استبطن الفَرَسَ</span> <em>He sought to find what young was in the belly of the mare.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTn_10_A2">
					<p><span class="ar long">استبطن الفَحْلُ الشُّوَّلَ</span> <em>The stallion covered the she-camels raising their tails, so that they conceived,</em> or <em>received his seed into their wombs;</em> as though <span class="add">[meaning]</span> <em>he deposited his seed in their bellies.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTn_10_A3">
					<p><span class="ar">استبطنهُ</span> <em>He,</em> or <em>it, entered</em> <span class="add">[or <em>penetrated</em>]</span> <em>into his,</em> or <em>its, belly,</em> or <em>interior;</em> <span class="add">[or <em>was,</em> or <em>became,</em> or <em>lay, within it;</em>]</span> <em>like as the vein enters</em> <span class="add">[or <em>penetrates</em>]</span> <em>into</em> <span class="add">[or <em>lies within</em>]</span> (<span class="ar">يَسْتَبْطِنُ</span>) <em>the flesh.</em> <span class="auth">(A, TA.)</span> You say, <span class="ar long">اِسْتَبْطَنْتُ الشَّىْءَ</span> <span class="add">[<em>I entered,</em> or <em>penetrated, into the thing,</em> whether <em>actually</em> or <em>mentally</em>]</span>. <span class="auth">(Ṣ.)</span> <a href="#bTn_1">See 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTn_10_A4">
					<p><a href="#bTn_4">See also 4</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bTn_10_A5">
					<p><span class="ar">اِسْتِبْطَانٌ</span> also signifies The <em>having,</em> or <em>holding,</em> <span class="add">[a thing]</span> <em>concealed within.</em> <span class="auth">(PṢ.)</span> <span class="add">[This explanation seems to be given to show that, in the opinion of the author of the PṢ, <span class="ar long">اِسْتَبْطَنْتُ الشَّىْءَ</span> in the Ṣ means <em>I had,</em> or <em>held, the thing concealed within.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTonN">
				<h3 class="entry"><span class="ar">بَطْنٌ</span></h3>
				<div class="sense" id="baTonN_A1">
					<p><span class="ar">بَطْنٌ</span> The <em>belly,</em> or <em>abdomen;</em> i. e. the <em>part of the body which is separated from the</em> <span class="ar">جَوْف</span> <span class="add">[i. e. <em>chest,</em> or <em>thorax,</em>]</span> <em>by the</em> <span class="ar">حِجَاب</span> <span class="add">[i. e. <em>midriff,</em> or <em>diaphragm</em>]</span>; <em>containing the liver and the spleen and the stomach and the lower intestines, &amp;c.;</em> <span class="auth">(Zj in his “Khalk el-Insán;” <span class="add">[in which it is erroneously said to comprise also the lungs;]</span>)</span> <em>contr. of</em> <span class="ar">ظَهْرٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> of a man and of any animal: <span class="auth">(TA:)</span> of the masc. gender, <span class="auth">(Ṣ, Ḳ,)</span> and, accord. to AO, fem. also: <span class="auth">(AḤát, Ṣ:)</span> pl. <span class="ar">أَبْطُنٌ</span> and <span class="ar">بُطُونٌ</span> <span class="auth">(Az, Mṣb, Ḳ)</span> and <span class="ar">بُطْنَانٌ</span>; <span class="auth">(Ḳ;)</span> the first a pl. of pauc.; and the second <span class="add">[as also the third]</span> a pl. of mult., applied to more than ten. <span class="auth">(Az, TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">ذُو البَطْنِ</span> <span class="add">[<em>What is in the belly:</em> but generally meaning]</span> <em>excrement, ordure,</em> or <em>dung.</em> <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar long">أَلْقَى ذَا بَطْنِهِ</span> <em>He</em> <span class="auth">(a man)</span> <em>ejected his excrement,</em> or <em>ordure.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَلْقَتْ ذَا بَطْنِهَا</span> <em>She</em> <span class="auth">(a woman, TA)</span> <em>brought forth;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar long">وَضَعَتْ ذَاتَ بَطْنِهَا</span>: <span class="auth">(TA in art. <span class="ar">ذو</span>:)</span> and <em>she</em> <span class="auth">(a hen)</span> <em>laid an egg.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">نَثَرَتْ ذَا بَطْنِهَا</span>, <span class="auth">(T and Mgh in art. <span class="ar">نثر</span>,)</span> and <span class="add">[elliptically]</span> <span class="ar long">نَثَرَتْ بَطْنَهَا</span>, <span class="auth">(T and A and Mgh in that art.,)</span> <em>She</em> <span class="auth">(a woman)</span> <em>brought forth many children.</em> <span class="auth">(T in that art.)</span> And it is said in a prov., <span class="auth">(TA,)</span> <span class="ar long">الذِّئْبُ يُغْبَطُ بِذِى بَطْنِهِ</span> <span class="add">[<em>The wolf is envied for what is in his belly</em>]</span>: for one never thinks him to be hungry, but only thinks him to be in a state of repletion, because of his hostility to men and cattle, <span class="auth">(AʼObeyd, Ḳ,)</span> though he is sometimes distressed by hunger. <span class="auth">(AʼObeyd. <span class="add">[See various readings of this prov. in Freytag's Arab. Prov. i. 500 and 501.]</span>)</span> <span class="ar long">مَاتَتْ فِى بَطْنٍ</span>, a phrase occurring in a trad., means <em>She</em> <span class="auth">(a woman)</span> <em>died in childbirth.</em> <span class="auth">(TA.)</span> <a href="index.php?data=02_b/198_bne">See also <span class="ar long">فُلَانٌ ٱبْنُ بَطْنِهِ بَطَنٌ</span></a>. means † <em>Such a one is solicitous for his belly.</em> <span class="auth">(Er-Rághib, TA in art. <span class="ar">بنى</span>.)</span> <span class="add">[Many phrases in which the word <span class="ar">بَطْن</span> occurs will be found explained under other words of those phrases; as <span class="ar">ظَهْرٌ</span>, and <span class="ar">أَخَذَ</span>, and <span class="ar">عُصْفُورٌ</span>, &amp;c.]</span> <span class="ar long">بَطْنُ الحُوتِ</span>: <a href="#AlrBiXaACu">see <span class="ar">الرِّشَآءُ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baTonN_A2">
					<p>Also The <em>inside,</em> or <em>interior,</em> of anything; syn. <span class="ar">جَوْفٌ</span>: and so<span class="arrow"><span class="ar">بَاطِنٌ↓</span></span>; syn. <span class="ar">دَاخِلٌ</span>: <span class="auth">(Ḳ:)</span> pl. of the former as above. <span class="auth">(TA.)</span> Thus <span class="ar long">بَطْنُ وَادٍ</span> means <em>The interior of a water-course</em> or <em>riverbed</em> <span class="add">[or <em>valley;</em> i. e. <em>its bottom, in which flows, occasionally</em> or <em>constantly, its torrent</em> or <em>river</em>]</span>. <span class="auth">(MA.)</span> And <span class="ar long">بَطْنُ مَكَّةَ</span> means <em>The interior of Mekkeh.</em> <span class="auth">(Bḍ in xlviii. 24.)</span> <span class="add">[Hence,]</span> it is said of the Ḳur-án, <span class="ar long">لِكُلِّ آيَةٍ مِنْهَا ظَهْرٌ وَبَطْنٌ</span>, meaning † <em>To every verse thereof is an apparent sense and a sense requiring development.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#ZahorN">See <span class="ar">ظَهْرٌ</span></a>.]</span> <a href="#baATinN">See also <span class="ar">بَاطِنٌ</span></a>. <span class="add">[And its pl. <span class="ar">بُطْنَانٌ</span> is also used as a sing., meaning The <em>middle,</em> or <em>midst,</em> of a thing: and the <em>lower,</em> or <em>lowest, part,</em> or the <em>foundation.</em> Thus,]</span> <span class="ar long">بُطْنَانُ الجَنَّةِ</span> means <em>The middle,</em> or <em>midst, of Paradise:</em> <span class="auth">(Ṣ, TA:)</span> and <span class="ar long">بُطْنَانُ العَرْشِ</span>, <em>The lower,</em> or <em>lowest, part,</em> or <em>the foundation, of the</em> <span class="ar">عرش</span> <span class="add">[vulgarly held to be the <em>throne of God</em>]</span>. <span class="auth">(TA.)</span> You say also <span class="add">[<span class="ar long">بَطْنُ الكَفِّ</span> and]</span> <span class="arrow"><span class="ar long">بَاطِنُ↓ الكَفِّ</span></span> † <em>The palm of the hand</em> <span class="add">[opposed to <span class="ar">ظَهْرُهَا</span> and <span class="ar">ظَاهِرُهَا</span>]</span>: and <span class="add">[<span class="ar long">بَطْنُ القَدَمِ</span> and]</span> <span class="arrow"><span class="ar long">بَاطِنُ↓ القَدَمِ</span></span> † <em>The sole of the foot</em> <span class="add">[likewise opposed to <span class="ar">ظَهْرُهَا</span> and <span class="ar">ظَاهِرُهَا</span>]</span>: <span class="auth">(Zj in his “Khalk- el-Insán:”)</span> and <span class="ar long">بَطْنُ الحَافِرُ</span> <span class="auth">(Ṣ in art. <span class="ar">نسر</span>)</span> and<span class="arrow"><span class="ar long">بَاطِنُ↓ الحَافِرِ</span></span> <span class="auth">(M and Ḳ in that art.)</span> † <span class="add">[<em>The sole of the solid hoof;</em>]</span> <em>the part of the solid hoof in which is the</em> <span class="ar">نَسْر</span>, q. v. <span class="auth">(Ṣ and M and Ḳ in that art.)</span> <span class="ar long">بَطْنُ الرَّاحَةِ</span> is well known <span class="add">[as another name for <span class="ar long">بَطْنُ الكَفِّ</span>, explained above; for <span class="ar">الرَّاحَة</span> is often used as syn. with <span class="ar">الكَفّ</span>]</span>: and<span class="arrow"><span class="ar long">بَاطِنُ↓ الخُفِّ</span></span> is <span class="add">[said to be]</span> † <em>The part of the foot of a camel or the like that is next the leg:</em> and one says,<span class="arrow"><span class="ar long">بَاطِنُ↓ الإِبْطِ</span></span>, <span class="add">[meaning † <em>The armpit,</em> or <em>hollow of the inner side of the shoulder-joint,</em>]</span> but not <span class="ar long">بَطْنُ الإِبْطِ</span>: <span class="auth">(TA:)</span> <span class="add">[and<span class="arrow"><span class="ar long">بَاطِنُ↓ العُنُقِ</span></span> <em>the throat.</em>]</span> The <span class="ar">بَطْن</span> of a feather is ‡ The <em>long,</em> <span class="auth">(Ṣ,)</span> or <em>longer,</em> <span class="auth">(Ḳ,)</span> <span class="add">[or <em>wider,</em> i. e. <em>inner,</em>]</span> <em>lateral half:</em> pl. <span class="ar">بُطْنَانٌ</span>; <span class="auth">(Ṣ, Ḳ, TA;)</span> which is explained as signifying the <em>parts beneath the shaft:</em> opposed to <span class="ar">ظُهْرَانٌ</span>, <a href="#ZahorN">pl. of <span class="ar">ظَهْرٌ</span> <span class="add">[q. v.]</span></a>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baTonN_A3">
					<p>Also <em>A low,</em> or <em>depressed, tract,</em> or <em>portion,</em> of land, or ground; <span class="auth">(Ṣ, TA;)</span> and so<span class="arrow"><span class="ar">بَاطِنٌ↓</span></span>: <span class="auth">(TA:)</span> <span class="add">[or <em>a bottom,</em> or <em>low land;</em> or <em>a low, soft flat;</em> i. e.]</span> <em>soft, plain, fine, low land</em> or <em>ground;</em> opposed to <span class="ar">ظَهْرٌ</span> <span class="add">[q. v.]</span>: <span class="auth">(TA in art. <span class="ar">ظهر</span>:)</span> pl. of the former, <span class="auth">(Ṣ,)</span> or of the latter, <span class="auth">(Ḳ,)</span> <span class="ar">بُطْنَانٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> a pl. of mult., <span class="auth">(TA,)</span> and <span class="ar">أَبْطِنَةٌ</span>, <span class="auth">(Ḳ,)</span> a pl. of pauc., and anomalous <span class="add">[as pl. of either]</span>: <span class="auth">(TA:)</span> the former pl., in relation to land, is also used as a sing., like <span class="ar">بَطْنٌ</span>: <span class="auth">(AḤn, TA:)</span> and accord. to ISh, <span class="ar long">بُطْنَانُ الأَرْضِ</span> signifies <em>the low,</em> or <em>depressed, tract,</em> or <em>tracts, of land, of the plain,</em> or <em>soft, parts thereof, and of the rugged, and of the meadows, where water rests and stagnates:</em> and such tracts are also called <span class="ar">بَوَاطِنُ</span> and <span class="ar">بُطُونٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baTonN_A4">
					<p><span class="ar long">بَطْنُ السَّمَآءِ</span> and <span class="ar long">ظَهْرُ السَّمَآءِ</span> both signify † <em>The apparent, visible, part of the sky.</em> <span class="auth">(Fr, T voce <span class="ar">ظَهْرٌ</span> <span class="add">[q. v.]</span>.)</span></p>
				</div>
				<span class="pb" id="Page_0221"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baTonN_B1">
					<p>Also ‡ <em>A tribe below that which is termed</em> <span class="ar">قَبِيلَة</span>: <span class="auth">(Ṣ, Mṣb, Ḳ, TA:)</span> or <em>next below the</em> <span class="ar">عِمَارَة</span>: <span class="auth">(Ṣ and TA voce <span class="ar">شَعْبٌ</span>, &amp;c.:)</span> or <em>below the</em> <span class="ar">فَخِذ</span> <em>and above the</em> <span class="ar">عمارة</span>: <span class="auth">(Ḳ: <span class="add">[but for this I have found no other authority:]</span>)</span> of the masc. gender: <span class="auth">(TA:)</span> or <span class="add">[properly]</span> fem.: but if <span class="ar">حَيٌّ</span> <span class="add">[said by some to signify <em>a tribe,</em> absolutely,]</span> be meant thereby, it is masc.: <span class="auth">(Mṣb:)</span> or fem. if used in the sense of <span class="ar">قَبِيلَة</span>: <span class="auth">(TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْطُنٌ</span> and <span class="add">[of mult.]</span> <span class="ar">بُطُونٌ</span>. <span class="auth">(Mṣb, Ḳ.)</span> <span class="add">[<a href="#XaEobN">See <span class="ar">شَعْبٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTanN">
				<h3 class="entry"><span class="ar">بَطَنٌ</span></h3>
				<div class="sense" id="baTanN_A1">
					<p><span class="ar">بَطَنٌ</span> <em>Disease of the belly,</em> <span class="auth">(Ḳ, TA,)</span> <em>being a state of enlargement thereof arising from satiety;</em> and so<span class="arrow"><span class="ar">بَطْنٌ↓</span></span>; whence the phrase <span class="ar long">مَاتَ بِالبَطْنِ</span> <em>He died by the disease of the belly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTinN">
				<h3 class="entry"><span class="ar">بَطِنٌ</span></h3>
				<div class="sense" id="baTinN_A1">
					<p><span class="ar">بَطِنٌ</span> One <em>whose object of care,</em> or <em>anxiety, is his belly:</em> <span class="auth">(Ḳ:)</span> or <em>who has an inordinate desire,</em> or <em>appetite, for food;</em> <span class="auth">(Ṣ;)</span> <em>whom nothing causes care,</em> or <em>anxiety, but his belly;</em> <span class="auth">(Ṣ, TA;)</span> as also<span class="arrow"><span class="ar">مِبْطَانٌ↓</span></span>: <span class="auth">(TA:)</span> or the former, <span class="auth">(TA,)</span> or<span class="arrow">↓</span> the latter, <span class="auth">(Ṣ,)</span> <em>ever large,</em> or <em>big, in the belly in consequence of much eating:</em> <span class="auth">(Ṣ, TA:)</span> or<span class="arrow">↓</span> both signify <em>voracious; not ceasing from eating.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baTinN_A2">
					<p>And <span class="add">[hence,]</span> ‡ One <em>who exults,</em> or <em>exults greatly,</em> or <em>excessively, and behaves insolently and unthankfully,</em> or <em>ungratefully:</em> <span class="auth">(TA:)</span> or <em>who does so, being abundant in wealth.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biTonapN">
				<h3 class="entry"><span class="ar">بِطْنَةٌ</span></h3>
				<div class="sense" id="biTonapN_A1">
					<p><span class="ar">بِطْنَةٌ</span> <em>Repletion;</em> the <em>state of being much filled with food</em> <span class="auth">(Ṣ, Ḳ)</span> <em>and drink.</em> <span class="auth">(So in a copy of the Ṣ.)</span> It is said in a prov., <span class="ar long">البِطْنَةُ تُذْهِبُ الفِطْنَةَ</span> <span class="add">[<em>Repletion banishes intelligence</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بِطْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biTonapN_A2">
					<p>And <span class="add">[hence,]</span> ‡ <em>Exultation,</em> or <em>great or excessive exultation, and insolent and unthankful,</em> or <em>ungrateful, behaviour.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بِطْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="biTonapN_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar long">مَاتَ فُلَانٌ بِبِطْنَتِهِ</span> † <em>Such a one died with his wealth complete, not having expended,</em> or <em>dispensed, anything thereof:</em> or, accord. to AʼObeyd, this prov. relates to religion, and means † <em>he went forth from the present world in a state of integrity, without any infringement of his religion.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#tagaDogaDa">See also <span class="ar">تَغَضْغَضَ</span></a>, in two places.]</span> <span class="add">[Hence also,]</span> <span class="ar long">نَزَّتْ بِهِ البَطِنَةُ</span> † <em>Richness caused him to exult,</em> or <em>exult greatly,</em> or <em>excessively, and to behave insolently and unthankfully,</em> or <em>ungratefully.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaTinapu">
				<h3 class="entry"><span class="ar">البَطِنَةُ</span></h3>
				<div class="sense" id="AlbaTinapu_A1">
					<p><span class="ar">البَطِنَةُ</span> <em>i. q.</em> <span class="ar">الدُّبُرُ</span> <span class="add">[<em>The back, hinder part, posteriors,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">البَطِنَةُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlbaTinapu_A2">
					<p><span class="ar long">بَطِنَاتُ الوَادِى</span> <em>The roads,</em> or <em>beaten tracks, of the valley.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biTaAnN">
				<h3 class="entry"><span class="ar">بِطَانٌ</span></h3>
				<div class="sense" id="biTaAnN_A1">
					<p><span class="ar">بِطَانٌ</span> <span class="add">[The <em>belly-girth</em> of a camel: or]</span> the <em>girth of the</em> <span class="add">[<em>kind of saddle called</em>]</span> <span class="ar">قَتَب</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>which is put beneath the belly of the camel, and is like the</em> <span class="ar">تَصْدِير</span> <em>to the</em> <span class="ar">رَحْل</span>: <span class="auth">(Ṣ:)</span> or the <em>girth of the</em> <span class="add">[<em>saddle called</em>]</span> <span class="ar">رَحْل</span>: <span class="auth">(Mṣb:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْطِنَةٌ</span> and <span class="add">[of mult.]</span> <span class="ar">بُطْنٌ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[Hence,]</span> <span class="ar long">اِلْتَقَتْ حَلْقَتَا البِطَانِ</span> <span class="add">[<em>The two rings of the belly-girth met</em>]</span>: said of a case, or an affair, that has become severe, strait, or distressing. <span class="auth">(Ṣ.)</span> And <span class="ar long">رَجُلٌ عَرِيضُ البِطَانِ</span> ‡ <em>A man in ample and easy circumstances;</em> or <em>in an easy,</em> or <em>a pleasant, state</em> or <em>condition;</em> or <em>easy,</em> or <em>unstraitened, in mind.</em> <span class="auth">(Ḳ, TA. <span class="add">[<a href="index.php?data=18_E/069_ErD">See also art. <span class="ar">عرض</span></a>.]</span>)</span> And <span class="ar long">مَاتَ فُلَانٌ وَهُوَ عَرِيضُ البِطَانِ</span>, meaning, accord. to AʼObeyd, † <em>Such a one died broad in the fleshy parts</em> (<span class="ar">المَلَاحِم</span>); <em>nothing of him having gone.</em> <span class="auth">(TA. <span class="add">[But this seems to be said of a man's dying in a state of opulence: see Freytag's Arab. Prov. ii. 601.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTiynN">
				<h3 class="entry"><span class="ar">بَطِينٌ</span></h3>
				<div class="sense" id="baTiynN_A1">
					<p><span class="ar">بَطِينٌ</span>, applied to a man, <span class="auth">(Ḳ,)</span> <em>Big,</em> or <em>large, in the belly;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">مِبْطَانٌ↓</span></span>: the former occurs, in a description of ʼAlee, used as an epithet of praise: and signifies also <em>big,</em> or <em>large, in the belly in consequence of much eating:</em> and <em>having the belly full;</em> as also<span class="arrow">↓</span> the latter: pl. of the former <span class="ar">بِطَانٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baTiynN_A2">
					<p>Hence, ‡ <em>Full;</em> applied to a purse <span class="add">[&amp;c.]</span>. <span class="auth">(TA.)</span> You say <span class="ar long">رَجُلٌ بَطِينُ الكُرْزِ</span> † <span class="add">[lit. <em>A man having the pair of provision-bags full</em>]</span>; meaning † <em>a man who conceals his travel-ling-provision in a journey, and eats that of his companion.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baTiynN_A3">
					<p>† <em>Far; far-extending.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span> So in the phrase <span class="ar long">شَأْوٌ بَطِينٌ</span> † <span class="add">[<em>A farextending heat,</em> or <em>single run to a goal</em> or <em>limit</em>]</span>, <span class="auth">(Ṣ, TA,)</span> and <span class="ar long">شَوْطٌ بَطِينٌ</span> <span class="add">[signifying the same]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَطِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baTiynN_A4">
					<p>† <em>Wide, and low,</em> or <em>depressed;</em> applied to a tract of land or ground. <span class="auth">(Ḥam p. 506.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbuTayonu">
				<h3 class="entry"><span class="ar">البُطَيْنُ</span></h3>
				<div class="sense" id="AlbuTayonu_A1">
					<p><span class="ar">البُطَيْنُ</span> <em>One of the Mansions of the Moon;</em> <span class="auth">(Ṣ, Ḳ;)</span> namely, <em>the Second;</em> <span class="auth">(Ḳzw, &amp;c.;)</span> <em>three small stars</em> <span class="add">[e and p and n]</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>disposed in the form of an equilateral triangle,</em> <span class="auth">(Ṣ,)</span> <em>as though they were three stones whereon a cooking-pot is placed, and forming the belly of the Ram;</em> <span class="auth">(Ṣ, Ḳ;)</span> the appellation being made a diminutive because the Ram consists of many stars in the form of a ram; <span class="add">[so I here render <span class="ar">حَمَل</span> though it properly signifies a lamb;]</span> the <span class="ar">شَزَطَانِ</span> being its two horns; and the <span class="ar">بُطَيْن</span>, its belly; <span class="add">[or, accord. to our configuration of Aries, the rump;]</span> and the <span class="ar">ثُرَيَّا</span>, its rump, or tail; <span class="auth">(Ṣ;)</span> <em>three obscure stars, forming the points of a triangle, in the belly of the Ram, between the</em> <span class="ar">شَرَطَانِ</span> <em>and the</em> <span class="ar">ثُرَيَّا</span>; <span class="auth">(Ḳzw, Mir-át ez-Zemán, &amp;c.;)</span> <em>the three stars of which two are on the tail and one on the thigh of the Ram, forming an equilateral triangle.</em> <span class="auth">(Ḳzw in his description of Aries.)</span> <span class="add">[<a href="#manaAzilu">See <span class="ar long">مَنَازِلُ القَمَرِ</span></a>, <a href="index.php?data=25_n/110_nzl">in art. <span class="ar">نزل</span></a>.]</span> The Arabs assert that it has no <span class="ar">نَوْء</span> <span class="add">[here meaning effect upon the weather]</span>, except wind. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biTaAnapN">
				<h3 class="entry"><span class="ar">بِطَانَةٌ</span></h3>
				<div class="sense" id="biTaAnapN_A1">
					<p><span class="ar">بِطَانَةٌ</span> The <em>lining,</em> or <em>inner covering,</em> of a garment, or piece of cloth <span class="add">[&amp;c.]</span>; <em>contr. of</em> <span class="ar">ظِهَارَةٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَاطِنَةٌ↓</span></span>: <span class="auth">(JK in art. <span class="ar">ظهر</span>:)</span> pl. of the former <span class="ar">بَطَائنُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بِطَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biTaAnapN_A2">
					<p>† <em>A secret</em> <span class="auth">(Ḳ, TA)</span> <em>that a man conceals.</em> <span class="auth">(TA.)</span> One says, <span class="ar long">هُوَ ذُو بِطَانَةٍ بِفُلَانٍ</span>, i. e. † <em>He is one who possesses knowledge of the inward,</em> or <em>intrinsic, state</em> or <em>circumstances of the case,</em> or <em>affair, of such a one.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بِطَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="biTaAnapN_A3">
					<p>‡ <em>A particular,</em> or <em>special, intimate, friend,</em> or <em>associate;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> <em>one who is particularly distinguished by entering into, and becoming acquainted with, the inward,</em> or <em>intrinsic, state</em> or <em>circumstances of one's case</em> or <em>affair;</em> <span class="auth">(TA;)</span> <em>an intimate and familiar friend</em> or <em>associate;</em> <span class="auth">(Zj, TA;)</span> <em>a confidential friend, who is consulted respecting one's circumstances:</em> <span class="auth">(TA:)</span> it is from the same word in the sense first explained above, relating to a garment, or piece of cloth: <span class="auth">(Mgh, Er-Rághib:)</span> and is used in a pl. sense, as meaning <em>intimate and familiar friends</em> or <em>associates, to whom one is open,</em> or <em>unreserved, in conversation, and who know the inward state</em> or <em>circumstances</em> <span class="add">[<em>of one's case</em> or <em>affair</em>]</span>: <span class="auth">(Zj, TA:)</span> or one's <em>family;</em> and one's <em>particular,</em> or <em>special, intimates, friends,</em> or <em>associates.</em> <span class="auth">(Mgh.)</span> You say, <span class="ar long">هُوَ بِطَانَتِى</span> ‡ <span class="add">[<em>He is my particular,</em> or <em>special, intimate,</em>, &amp;c.]</span>: and <span class="ar long">هُمْ بِطَانَتِى</span> and <span class="ar long">أَهْلُ بِطَانَتِى</span> ‡ <span class="add">[<em>They are my particular,</em> or <em>special, intimates,</em>, &amp;c.]</span>. <span class="auth">(A, TA.)</span> <a href="#bTn_4">See also 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بِطَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="biTaAnapN_A4">
					<p>Coupled with <span class="ar">عَلَاوَة</span>, it signifies <em>What is put beneath</em> <span class="add">[<em>the things that compose the main load of a camel</em>]</span>, <em>such as a water-skin and the like.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بِطَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="biTaAnapN_A5">
					<p><a href="#baATinapN">See also <span class="ar">بَاطِنَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baATinN">
				<h3 class="entry"><span class="ar">بَاطِنٌ</span></h3>
				<div class="sense" id="baATinN_A1">
					<p><span class="ar">بَاطِنٌ</span> <em>Unapparent; hidden; concealed; covert:</em> <span class="auth">(Ḳ, TA:)</span> <span class="add">[and <em>inward; inner; interior; internal; intrinsic; esoteric:</em> in all these senses]</span> <em>contr. of</em> <span class="ar">ظَاهِرٌ</span>. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baATinN_A2">
					<p><span class="ar long">بَاطِنُ أَمْرٍ</span> <span class="add">[<em>The inward,</em> or <em>intrinsic, state</em> or <em>circumstances, of a case</em> or <em>an affair</em>]</span>; <span class="auth">(TA, &amp;c.;)</span> <span class="add">[and so<span class="arrow"><span class="ar long">بَطْنُ↓ أَمْرٍ</span></span>; whence the phrases,]</span> <span class="ar long">أَفْرَشَنِى ظَهْرَ أَمْرِهِ وَبَطْنَهُ</span> † <span class="add">[<em>He displayed,</em> or <em>laid open, to me the outward state</em> or <em>circumstances of his case</em> or <em>affair, and the inward state</em> or <em>circumstances thereof</em>]</span>; and <span class="ar long">هُوَ مُجَرِّبٌ بَطْنَ الأُمُورِ</span> † <span class="add">[<em>He is one who possesses experience of the inward,</em> or <em>intrinsic, state</em> or <em>circumstances of affairs</em>]</span>, as though he hit their bellies by his knowledge of their true, or real, states or circumstances. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baATinN_A3">
					<p><span class="ar">البَاطِنُ</span> <span class="add">[<em>The internal, inward,</em> or <em>intrinsic, state, condition, character,</em> or <em>circumstances,</em> of a man: and <em>the heart,</em> meaning <em>the secret thoughts; the recesses of the mind; the state of mind; the inward,</em> or <em>secret, disposition of the mind:</em> opposed to <span class="ar">الظَّاهِرُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baATinN_A4">
					<p><span class="add">[Also,]</span> an epithet applied to God, meaning <em>He who knows the inward,</em> or <em>intrinsic, states</em> or <em>circumstances of things:</em> <span class="auth">(Ṣ:)</span> <em>or He who knows the secret and hidden things:</em> or <em>He who is veiled from the eyes and imaginations of created beings.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baATinN_A5">
					<p><span class="add">[<span class="ar">بَاطِنًا</span> <em>Covertly; secretly.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baATinN_A6">
					<p><a href="#baATinapN">See also <span class="ar">بَاطِنَةٌ</span></a>, in eight places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baATinN_A7">
					<p><span class="ar">بِطَانَةٌ</span> also signifies <em>A water-course,</em> or <em>place in which water flows, in rugged ground:</em> pl. <span class="ar">بُطْنَانٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بُطْنٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baATinapN">
				<h3 class="entry"><span class="ar">بَاطِنَةٌ</span></h3>
				<div class="sense" id="baATinapN_A1">
					<p><span class="ar">بَاطِنَةٌ</span>: <a href="#biTaAnapN">see <span class="ar">بِطَانَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">بَاطِنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baATinapN_A2">
					<p>Also The <em>middle,</em> and the <em>retired part,</em> of a <span class="ar">كُورَة</span> <span class="add">[i. e. province, or district, or city]</span>: in the copies of the Ḳ erroneously written <span class="arrow"><span class="ar">بِطَانَة↓</span></span>, and explained as meaning the “middle of a <span class="ar">كورة</span>.” <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlOaboTanu">
				<h3 class="entry"><span class="ar">الأَبْطَنُ</span></h3>
				<div class="sense" id="AlOaboTanu_A1">
					<p><span class="ar">الأَبْطَنُ</span> <em>A certain vein in the interior of the arm of the horse; one of two veins which are called</em> <span class="ar">الأَبْطَنَانِ</span>: <span class="auth">(Ṣ:)</span> accord. to AO, these are <em>two veins that penetrate into the interior of the arm until they become hidden among the sinews of the shank.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaTBanN">
				<h3 class="entry"><span class="ar">مُبَطَّنٌ</span> / <span class="ar">مُبَطَّنَةٌ</span></h3>
				<div class="sense" id="mubaTBanN_A1">
					<p><span class="ar">مُبَطَّنٌ</span>, applied to a man, <em>Lank in the belly:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُبَطَّنَةٌ</span>}</span></add>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">مُبَطَّنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubaTBanN_A2">
					<p>Applied to a horse, <em>White in the back and belly.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطن</span> - Entry: <span class="ar">مُبَطَّنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mubaTBanN_A3">
					<p><em>Lined; having a</em> <span class="ar">بِطَانَة</span> <em>put to it.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miboTaAnN">
				<h3 class="entry"><span class="ar">مِبْطَانٌ</span></h3>
				<div class="sense" id="miboTaAnN_A1">
					<p><span class="ar">مِبْطَانٌ</span>: <a href="#baTiynN">see <span class="ar">بَطِينٌ</span></a>, in two places: <a href="#baTinN">and see <span class="ar">بَطِنٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboTuwnN">
				<h3 class="entry"><span class="ar">مَبْطُونٌ</span></h3>
				<div class="sense" id="maboTuwnN_A1">
					<p><span class="ar">مَبْطُونٌ</span> <em>Having a complaint of,</em> or <em>a disease in,</em> or <em>a pain in, his belly:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> one <em>who dies of disease of his belly, as dropsy and the like:</em> such is reckoned a martyr. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0219.pdf" target="pdf">
							<span>Lanes Lexicon Page 219</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0220.pdf" target="pdf">
							<span>Lanes Lexicon Page 220</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0221.pdf" target="pdf">
							<span>Lanes Lexicon Page 221</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
