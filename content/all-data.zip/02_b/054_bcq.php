<article class="root" id="Root_bcq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/053_bcr">بذر</a></span>
				<span class="ar">بذق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/055_bcl">بذل</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bacoqN">
				<h3 class="entry"><span class="ar">بَذْقٌ</span></h3>
				<div class="sense" id="bacoqN_A1">
					<p><span class="ar">بَذْقٌ</span>: <a href="#baYocaqN">see <span class="ar">بَيْذَقٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAcaqN">
				<h3 class="entry"><span class="ar">بَاذَقٌ</span></h3>
				<div class="sense" id="baAcaqN_A1">
					<p><span class="ar">بَاذَقٌ</span> <span class="auth">(Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">بَاذِقٌ↓</span></span> <span class="auth">(Ḳ)</span> <span class="add">[in my copy of the Mṣb erroneously written <span class="ar">باذيق</span>]</span> a Persian word, arabicized; originally <span class="ar">بَادَهْ</span>, which signifies <em>Wine:</em> <span class="auth">(AʼObeyd, TA:)</span> or <em>juice of grapes cooked in the least degree, so as to be strong</em> <span class="auth">(Mgh, Mṣb, Ḳ)</span> <em>and intoxicating;</em> an arabicized word; <span class="auth">(Mṣb;)</span> said to have been introduced by the Benoo-Umeiyeh, <span class="auth">(TA,)</span> and to have been unknown to the Prophet; <span class="auth">(Mgh;)</span> but there is a trad. of I’Ab which is understood to mean that the Prophet forbade what is thus called: <span class="auth">(Mgh, TA:)</span> some assert it to mean that it existed not in his time; <span class="auth">(TA;)</span> but this latter assertion is weak. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAciqN">
				<h3 class="entry"><span class="ar">بَاذِقٌ</span></h3>
				<div class="sense" id="baAciqN_A1">
					<p><span class="ar">بَاذِقٌ</span>: <a href="#baAcaqN">see above</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذق</span> - Entry: <span class="ar">بَاذِقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAciqN_B1">
					<p>It is also an imitative sequent to <span class="ar">حَاذِقٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayocaqN">
				<h3 class="entry"><span class="ar">بَيْذَقٌ</span></h3>
				<div class="sense" id="bayocaqN_A1">
					<p><span class="ar">بَيْذَقٌ</span> <span class="add">[meaning <em>A pawn</em>]</span> <em>in the game of chess</em> is from <span class="arrow"><span class="ar">بَيَاذَقَةٌ↓</span></span>; <span class="auth">(TA;)</span> which latter signifies <em>footmen, as opposed to horsemen,</em> <span class="auth">(AO, Ḳ, TA,)</span> and is an arabicized word, from the Persian, <span class="auth">(AO, TA,)</span> originally <span class="ar">پِيَادَهْ</span>: <span class="auth">(TA:)</span> <a href="#bycq">the pl. of <span class="ar">بيذق</span></a> is <span class="ar">بَيَاذِقُ</span>; for which a poet uses <span class="ar">بُذُوقٌ</span>, as though he suppressed the <span class="ar">ى</span> <span class="add">[in the sing.]</span>, making <span class="ar">بيذق</span> to become <span class="arrow"><span class="ar">بَذْقٌ↓</span></span>: <span class="auth">(Ibn-Buzurj, TA:)</span> or, accord. to El-Khárzenjee, <span class="auth">(JK, TA,)</span> <span class="arrow"><span class="ar">بَذْقٌ↓</span></span> signifies <em>a guide in a journey;</em> as also <span class="ar">بَيْذَقٌ</span>: <span class="auth">(JK, Ḳ, TA:)</span> or <span class="add">[in the CK “and”]</span> <em>small and light</em> or <em>active:</em> <span class="auth">(Ḳ, TA:)</span> or, as in the Tekmileh, <span class="auth">(TA,)</span> <em>short and light</em> or <em>active:</em> <span class="auth">(JK, TA:)</span> and its pl. is <span class="ar">بُذُوقْ</span>. <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayaAciqapN">
				<h3 class="entry"><span class="ar">بَيَاذِقَةٌ</span></h3>
				<div class="sense" id="bayaAciqapN_A1">
					<p><span class="ar">بَيَاذِقَةٌ</span>: <a href="#baYocaqN">see <span class="ar">بَيْذَقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0174.pdf" target="pdf">
							<span>Lanes Lexicon Page 174</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
