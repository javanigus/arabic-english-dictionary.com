<article class="root" id="Root_bge">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/152_bgw">بغو</a></span>
				<span class="ar">بغى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/154_bq">بق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bge_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغى</span></h3>
				<div class="sense" id="bge_1_A1">
					<p><span class="ar">بَغَى</span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْغِىُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بُغَآءٌ</span>, <span class="auth">(Ṣ, Mgh, Ḳ, &amp;c.,)</span> or this is a simple subst., and the inf. n. is <span class="ar">بَغْىٌ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[but, if this be correct, the former is generally used for the latter,]</span> and <span class="ar">بُغًى</span>, <span class="auth">(Lḥ, Ḳ,)</span> but the first is better known, and is the chaste form, and some say, <span class="ar">بِغًى</span>, <span class="auth">(TA,)</span> and <span class="ar">بُغْيَةٌ</span> and <span class="ar">بِغْيَةٌ</span>, <span class="auth">(Ḳ,)</span> accord. to Th, but others hold these two to be simple substs., and some mention also <span class="ar">بَغْيَةٌ</span>, with fet-ḥ, <span class="auth">(TA,)</span> and <span class="ar">بُغَايَةٌ</span>, <span class="auth">(Aṣ, Ṣ, TA,)</span> <em>He sought; sought for,</em> or <em>after; sought, desired,</em> or <em>endeavoured, to find, and take,</em> or <em>get;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, &amp;c.;)</span> a stray-beast, <span class="auth">(Aṣ, Ṣ, TA,)</span> or any other thing, <span class="auth">(Ṣ, Mgh,* Mṣb,* Ḳ,* TA,)</span> good or evil; <span class="auth">(Lḥ, TA;)</span> as also<span class="arrow"><span class="ar">ابتغى↓</span></span> and<span class="arrow"><span class="ar">تبغّى↓</span></span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">استبغى↓</span></span>: <span class="auth">(Ḳ:)</span> or<span class="arrow"><span class="ar">ابتغى↓</span></span> signifies <em>he sought,</em>, &amp;c., <em>diligently, studiously, sedulously,</em> or <em>earnestly:</em> <span class="auth">(Er-Rághib, TA:)</span> and <span class="ar">بَغَى</span> signifies also <em>he loved,</em> or <em>affected,</em> a thing: <span class="auth">(MF, TA:)</span> or, accord. to Er-Rághib, the inf. n. signifies the <em>seeking to exceed the just bounds in respect of that which one aims at,</em> or <em>endeavours after, whether one actually exceed or do not;</em> and sometimes it is considered <em>in relation to quantity;</em> and sometimes, <em>in relation to quality.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">بَغَاهُ بِشَرٍّ</span> <span class="add">[<em>He sought him with an evil purpose;</em> or <em>sought to do him evil</em>]</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">عقب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bge_1_A2">
					<p>And <span class="ar">بَغَاهُ</span> <em>He sought,</em>, &amp;c., a thing <em>for him;</em> like <span class="ar long">بَغَى لَهُ</span>. <span class="auth">(Lḥ, Mgh,* Ḳ.*)</span> You say, <span class="ar long">بَغَاهُ الشَّىْءَ</span> <em>He sought,</em>, &amp;c., <em>the thing for him;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar long">ابغاهُ↓ الشَّىْءَ</span></span>: <span class="auth">(Ḳ:)</span> thus you say, <span class="ar long">اِبْغِنِى كَذَا</span> or<span class="arrow"><span class="ar long">أَبْغِنِى↓ كذا</span></span> and <span class="ar long">اِبْغَ لِى كذا</span> <em>Seek thou for me such a thing;</em> <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar long">أَبْغِنِى↓ ضَالَّتِى</span></span> <em>Seek thou for me my stray-beast:</em> <span class="auth">(Mgh:)</span> or<span class="arrow"><span class="ar long">ابغاهُ↓ الشَّىْءَ</span></span> signifies <em>He aided,</em> or <em>assisted, him to seek the thing:</em> <span class="auth">(Ks, Ḳ:)</span> or<span class="arrow"><span class="ar long">أَبْغِنِى↓ كَذَا</span></span> signifies <em>Seek thou for me such a thing;</em> and also <em>Aid thou me to seek such a thing.</em> <span class="auth">(JK.)</span> It is said in the Ḳur <span class="add">[ix. 47]</span>, <span class="ar long">يَبْغُونَكُمُ الفِتْنَةَ</span> <em>They seek,</em> or <em>desire, for you discord,</em> or <em>dissension;</em> or <em>they seeking,</em>, &amp;c.: and in the same <span class="add">[iii. 94]</span>, <span class="ar long">تَبْغُونَهَا عِوَجًا</span> <em>Ye seek,</em> or <em>desire, for it,</em> namely, the way <span class="add">[of God]</span>, <em>crookedness;</em> or <em>ye seeking,</em>, &amp;c.: the first objective complement of the verb being in the accus. case because of the suppression of the preposition <span class="ar">ل</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bge_1_A3">
					<p><span class="add">[Hence, app.,]</span> <span class="ar long">بَغَانِى دَآءً</span> <em>It procured to me disease; it caused disease to befall me.</em> <span class="auth">(Ḥam p. 794.)</span> And <span class="ar long">إِنَّهُ لَذُو بُغَايَةٍ</span> <em>Verily he is one who makes much gain:</em> <span class="auth">(JK, Ḳ:)</span> but in the M, <span class="ar long">ذُو بُغَايَةٍ لِلْكَسْبِ</span>, meaning <em>a seeker of gain.</em> <span class="auth">(TA.)</span> And <span class="ar long">مَابُغِىَ لَهُ</span> <em>Good was not appointed to betide him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bge_1_A4">
					<p><span class="ar long">بَغَى عَلَى أَخِيهِ</span>, inf. n. <span class="ar">بَغْىٌ</span>, <em>He envied his brother; he wished that a blessing, or cause of happiness, or an excellence, might become transferred from his brother to himself:</em> so says Lḥ, who holds this to be the primary signification of the verb. <span class="auth">(TA.)</span> It is said in a prov., <span class="ar long">البَغْىُ عِقَالُ النَّصْرِ</span> <span class="add">[<em>Envy is the shackle of aid</em> from God against an enemy or a wrongdoer]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bge_1_A5">
					<p>Hence, <span class="auth">(Lḥ, TA,)</span> <span class="ar">بَغْىٌ</span> signifies The <em>acting wrongfully, injuriously,</em> or <em>tyrannically;</em> <span class="auth">(Lḥ, Ṣ, TA;)</span> because the envier so acts towards the envied; his endeavour being to cause, by guile, the blessing of God upon him to depart from him: <span class="auth">(Lḥ, TA:)</span> or the <em>seeking,</em> or <em>endeavouring, to act corruptly, wrongly,</em> or <em>unjustly:</em> <span class="auth">(Az, TA:)</span> or the <em>exceeding the due bounds,</em> or <em>just limits, in any way:</em> <span class="auth">(Ṣ:)</span> accord. to Er-Rághib, it is of two kinds: one of these is approved, and this is the <em>passing beyond the bounds of equity to exercise beneficence, and beyond the bounds of obligatory duties to do what is not obligatory:</em> the other is disapproved, and this is the <em>passing beyond the bounds of that which is true,</em> or <em>right, to do that which is false,</em> or <em>wrong,</em> or <em>to do acts of a doubtful nature:</em> but in most instances it is that which is disapprove. <span class="auth">(TA.)</span> You say, <span class="ar long">بَغَى عَلَيْهِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar long">بغى عَلَى النَّاسِ</span>, <span class="auth">(Az, Mṣb,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْغِىُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <em>He exalted himself against him,</em> or <em>above him; overpowered,</em> or <em>oppressed, him;</em> <span class="auth">(Fr, Ṣ, Ḳ;)</span> <em>acted wrongfully, injuriously,</em> or <em>tyrannically, towards him; and deviated from the right way:</em> <span class="auth">(Ḳ:)</span> and <em>he acted wrongfully, injuriously,</em> or <em>tyrannically, towards men,</em> or <em>the people,</em> <span class="auth">(Az, Mṣb,)</span> <em>and sought to annoy them,</em> or <em>hurt them.</em> <span class="auth">(Az, TA.)</span> Lḥ mentions, on the authority of Ks, the saying, <span class="ar long">مَا لِى وَلِلْبَغِ بَعْضِكُمْ عَلَى بَعْضٍ</span> <span class="add">[<em>What have I to do with wrongful conduct,</em> the wrongful conduct <em>of one of you towards another?</em>]</span>, for <span class="ar">وَلِلْبَغْىِ</span>; ISd thinks, because of the difficulty found in pronouncing the kesreh after the <span class="ar">ى</span>. <span class="auth">(TA.)</span> <span class="ar">بَغَى</span> also signifies <em>He occupied himself with corrupt, wrong,</em> or <em>unjust, conduct:</em> <span class="add">[accord. to Fei,]</span> from the same verb <span class="add">[in a sense to be mentioned below,]</span> said of a wound. <span class="auth">(Mṣb.)</span> Also, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْغِىُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(Az, TA,)</span> <em>He magnified himself;</em> or <em>behaved proudly, haughtily,</em> or <em>insolently:</em> <span class="auth">(Az, TA:)</span> because he who does so passes beyond the bounds of his proper station to a station that does not belong to him. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bge_1_A6">
					<p>And <span class="add">[hence,]</span> <span class="ar long">بَغَى فِى مِشيَتِهِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(TA,)</span> <em>He</em> <span class="add">[app. a horse, and perhaps a man also,]</span> <em>was proud,</em> or <em>self-conceited, and quick, in his gait:</em> <span class="auth">(Ḳ:)</span> or <span class="ar">بَغْىٌ</span> in a horse, <span class="auth">(Ṣ, TA,)</span> or in the running of a horse, <span class="auth">(JK, TA,)</span> is the <em>being proud,</em> or <em>self-conceited, with exceeding briskness</em> or <em>liveliness</em> or <em>sprightliness.</em> <span class="auth">(JK, Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bge_1_A7">
					<p>And <span class="ar long">بَغَتِ السَّمَآءُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(TA,)</span> <em>The sky rained vehemently:</em> <span class="auth">(AʼObeyd, Ṣ, Ḳ:)</span> or <em>exceeded, in rain, the limit of what was wanted.</em> <span class="auth">(Er-Rághib, TA.)</span> And <span class="ar long">بَغَى الوَادِى</span> <em>The valley flowed with water reaching to a place to which it had not reached before.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bge_1_A8">
					<p><span class="ar">بَغَتْ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> said of a woman, <span class="auth">(Th, IKh, Ṣ, Mṣb, and so in some copies of the Ḳ,)</span> or of a female slave, <span class="auth">(so in other copies of the Ḳ,)</span> but it is not restricted to the latter, <span class="auth">(TA,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْغِىُ</span>}</span></add>, <span class="auth">(JK, Mṣb,)</span> inf. n. <span class="ar">بِغَآءٌ</span>, <span class="auth">(IKh, JK, Ṣ, Mgh, Mṣb, TA,)</span> or <span class="ar">بَغْىٌ</span>, <span class="auth">(ISd, Ḳ,)</span> <span class="add">[but the former, only, is commonly known,]</span> <em>She committed fornication,</em> or <em>adultery; she prostituted herself;</em> <span class="auth">(JK, Ṣ, Mgh, Mṣb, Ḳ;)</span> because she who does so transgresses her proper bounds; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَاغَتْ↓</span></span>, <span class="auth">(IKh, Ṣ,* Mṣb, Ḳ,)</span> inf. n. <span class="ar">بِغَآءٌ</span> <span class="auth">(IKh, Ḳ)</span> and <span class="ar">مُبَاغَاةٌ</span>, <span class="auth">(Ḳ,)</span> said of a female slave: <span class="auth">(Mṣb:)</span> or <span class="ar">مباغاة</span> signifies the <em>committing fornication,</em> or <em>adultery, with another.</em> <span class="auth">(KL.)</span> It is said in the Ḳur <span class="add">[xxiv. 33]</span>, <span class="ar long">وَلَا تُكْرِهُو فَتَيَاتِكُمْ عَلَى البِغَآءِ</span> <span class="add">[<em>And compel not ye your young women to prostitute themselves</em>]</span>. <span class="auth">(Mgh.)</span> And you say,<span class="arrow"><span class="ar long">خَرَجَتِ المَرْأَةُ تُبَاغِى↓</span></span> <span class="add">[<em>The woman went forth</em> for <em>prostituting herself</em>]</span>. <span class="auth">(Ṣ.)</span> Accord. to the Jema et-Tefáreek, <span class="ar">بِغَآءٌ</span> signifies The <em>knowing of a woman's committing fornication</em> or <em>adultery,</em> or <em>prostituting herself, and approving,</em> or <em>being content:</em> but this, if correct, is an amplification in speech. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bge_1_A9">
					<p><span class="ar long">بَغَى الجُرْحُ</span>, <span class="auth">(JK, Ṣ, Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَىُ</span>}</span></add>, inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(JK,)</span> <em>The wound swelled,</em> <span class="auth">(Ṣ,)</span> <em>and became in a corrupt state,</em> <span class="auth">(JK, Ṣ, Mṣb,)</span> <em>and produced thick purulent matter.</em> <span class="auth">(JK.)</span> <span class="pb" id="Page_0232"></span>And <span class="ar long">بَرَأَ جُرْحُهُ عَلَى بَغْىٍ</span> <em>His wound healed having somewhat of corruption in it.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bge_1_A10">
					<p><span class="ar">بَغَى</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْغِىُ</span>}</span></add>, inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(TA,)</span> also signifies <em>He lied; said what was untrue.</em> <span class="auth">(Ḳ.)</span> <span class="ar long">مَا نَبْغِى</span>, in the Ḳur <span class="add">[xii. 65]</span>, is said to mean <em>We do not lie:</em> and <em>we do not act wrongfully:</em> or it may mean <em>what do we seek,</em> or <em>desire?</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="bge_1_A11">
					<p>Also, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَغْىٌ</span>, <span class="auth">(TA,)</span> <em>He looked at a</em> thing <span class="add">[<em>to see</em>]</span> <em>how it was;</em> <span class="auth">(Ḳ;)</span> and so <span class="ar">بَغَا</span>, inf. n. <span class="ar">بَغْوٌ</span>: mentioned by Kr. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="bge_1_A12">
					<p>And, <span class="auth">(Ḳ,)</span> with the same inf. n., <span class="auth">(TA,)</span> <em>He looked, watched,</em> or <em>waited, for</em> a person or thing. <span class="auth">(Kr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bge_3">
				<h3 class="entry">3. ⇒ <span class="ar">باغى</span></h3>
				<div class="sense" id="bge_3_A1">
					<p><a href="#bge_1">see 1</a>, latter part, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bge_3_B1">
					<p>Lh mentions the saying, addressed to a pretty woman, <span class="ar long">إِنَّكِ لَجَمِيلَةٌ وَلَا تُبَاغِى</span>, as meaning <em>Verily thou art pretty, and mayest thou not be smitten by the</em> <span class="add">[<em>evil</em>]</span> <em>eye:</em> <span class="auth">(TA in this art.:)</span> but accord. to some, the verb in this instance belongs to art. <span class="ar">بوغ</span> or art. <span class="ar">بيغ</span>. <span class="auth">(TA in art. <span class="ar">بوغ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bge_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابغى</span></h3>
				<div class="sense" id="bge_4_A1">
					<p><a href="#bge_1">see 1</a>, in five places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bge_4_A2">
					<p><span class="ar long">ابغاهُ الشَّىْءَ</span> also signifies <em>He made him,</em> or <em>caused him, to seek the thing; to seek for it,</em> or <em>after it; to seek,</em> or <em>desire,</em> or <em>endeavour, to find, and take,</em> or <em>get, it.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bge_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبغّى</span></h3>
				<div class="sense" id="bge_5_A1">
					<p><a href="#bge_1">see 1</a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bge_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباغى</span></h3>
				<div class="sense" id="bge_6_A1">
					<p><span class="ar">تَبَاغَوْا</span> <em>They acted wrong fully, injuriously,</em> or <em>tyrannically, one towards another; exalted themselves, one against,</em> or <em>above, another; overpowered,</em> or <em>oppressed, one another.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bge_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبغى</span></h3>
				<div class="sense" id="bge_7_A1">
					<p><span class="ar">انبغى</span> is said in the Ṣ <a href="#bge_1">to be quasi-pass. of <span class="ar">بَغَيْتُهُ</span></a>, <a href="#ksr_7">like as <span class="ar">اِنْكَسَرَ</span></a> <a href="#ksr_1">is of <span class="ar">كَسَرْتُهُ</span></a>; and Esh-Shiháb says of the aor. that <a href="#bge_1_A2">it is quasi-pass. of <span class="ar">بَغَاهُ</span></a>, aor. <span class="ar">يَبْغِيهِ</span>, <a href="#Tlb_1">in the sense of <span class="ar">طَلَبَهُ</span></a>: <span class="auth">(TA:)</span> <span class="add">[Fei says,]</span> it has been asserted that <a href="#bgy_7"><span class="ar">انبغى</span></a> <a href="#bgy_1">is quasi-pass. of <span class="ar">بَغَى</span></a>; but a verb of the measure <span class="ar">انفعل</span> is not used as a quasi-pass. unless it implies effort, and the consequence of an action, <a href="#ksr_1">as in the case of <span class="ar">كَسَرْتُهُ</span></a>, <a href="#ksr_7">of which the quasi-pass. is <span class="ar">اِنْكَسَرَ</span></a>; which <span class="ar">انبغى</span> does not: some, however, allow its being thus used: <span class="auth">(Mṣb:)</span> accord. to Zj, it is as though it were syn. with <span class="ar">اِنْطَلَبَ</span>, <a href="#Tlb_1">as quasi-pass. of <span class="ar">طَلَبَ</span></a>, and means <em>It was,</em> or <em>became, suitable, fit, meet,</em> or <em>proper;</em> <span class="auth">(Zj, TA;)</span> <span class="add">[or <em>right,</em> and <em>allowable;</em> and <em>good:</em> or <em>very requisite:</em> <span class="auth">(see explanations of exs. following:)</span> or <em>it behooved:</em> and]</span> <em>it was,</em> or <em>became, facilitated,</em> or <em>easy;</em> <span class="auth">(Er-Rághib, Ḳ;)</span> and <em>practicable,</em> or <em>manageable.</em> <span class="auth">(Er-Rághib, TA.)</span> Accord. to some, this verb is not used in the pret. tense, but only in the aor.: it is reckoned among verbs imperfectly inflected: <span class="auth">(Mṣb, TA:)</span> but the pret. is mentioned by AZ and Sb and Zj, and by El-Khattábee on the authority of Ks; and was often used by Esh-Sháfiʼee: it is, however, very rare. <span class="auth">(TA.)</span> You say, <span class="ar long">يَنْبَغِى لَكَ أَنْ تَفْعَلَ كَذَا</span> <span class="add">[<em>It is suitable to thee,</em> or <em>is fit, meet,</em> or <em>proper,</em>, &amp;c., <em>for thee,</em> or <em>it behooveth thee, that thou shouldst do such a thing</em>]</span>. <span class="auth">(Ṣ, TA.)</span> And, accord. to Zj, <span class="ar long">اِنْبَغَى لِفُلَانٍ أَنْ يَفْعَلَ</span>, as meaning <em>It was,</em> or <em>became, suitable to such a one,</em> or <em>fit, meet,</em> or <em>proper, for him, that he should do,</em> or <em>to do,</em> such a thing. <span class="auth">(TA.)</span> And <span class="ar long">مَا يَنْبَغِى لَكَ أَنْ تَفْعَلَ هٰذَا</span>, <span class="auth">(Lḥ, Ḳ,)</span> and<span class="arrow"><span class="ar long">ما يُبْتَغَى↓</span></span>, <span class="auth">(Ḳ, TA,)</span> with fet-ḥ to the <span class="ar">غ</span>, <span class="auth">(TA,)</span> and <span class="ar long">ما ٱنْبَغَى</span>, and<span class="arrow"><span class="ar long">ما ٱبْتُغِىَ↓</span></span>; <span class="auth">(Lḥ, Ḳ;)</span> of which four phrases, the first is given by Lḥ as explanatory of the third and fourth, and means, accord. to Esh-Shiháb, <em>It is not right, proper, fit,</em> or <em>meet, nor allowable, for thee that thou shouldst do this,</em> or <em>to do this;</em> and <em>it is not good for thee</em>, &amp;c.; but he adds that only the aor. has been heard from the Arabs in this sense. <span class="auth">(TA.)</span> And <span class="ar long">يَنْبَغِى أَنْ يَكُونَ كَذَا</span> <em>It is very requisite that it should be so,</em> or <em>that such a thing ought be;</em> <span class="add">[or <em>it ought to be so,</em> or <em>such a thing ought to be; it behooves that it should be so,</em> or <em>such a thing behooves;</em>]</span> <em>it is not well that such a thing should be neglected,</em> or <em>left undone.</em> <span class="auth">(Mṣb.)</span> And Ks is related to have heard, from the Arabs, the phrase, <span class="ar long">مَا يَنْبَغِى أَنْ يَكُونَ كَذَا</span>, meaning <em>It is not right that it should be so,</em> or <em>that such a thing should be:</em> or <em>it is not good</em>, &amp;c. <span class="auth">(Mṣb.)</span> It is said in the Ḳur <span class="add">[xxxvi. 69]</span>, <span class="ar long">وَمَا عَلَّمْنَاهُ الشِّعْرَ وَمَا يَنْبَغِى لَهُ</span>, i. e. <span class="add">[<em>And we have not taught him poetry,</em> or <em>versification</em>]</span>, <em>nor is it right, proper, fit,</em> or <em>meet, for him:</em> <span class="auth">(Bḍ:)</span> or <em>nor is it easy to him,</em> <span class="auth">(Bḍ, Jel, Er-Rághib,)</span> or <em>practicable to him.</em> <span class="auth">(Bḍ, Er-Rághib.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bge_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتغى</span></h3>
				<div class="sense" id="bge_8_A1">
					<p><a href="#bge_1">see 1</a>, first sentence, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bge_8_A2">
					<p><a href="#bge_7">and see also 7</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bge_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبغى</span></h3>
				<div class="sense" id="bge_10_A1">
					<p><a href="#bge_1">see 1</a>, first sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bge_10_A2">
					<p>You say also, <span class="ar long">استبغى القَوْمَ فَبَغَوْهُ</span> and <span class="ar long">بَغَوْا لَهُ</span> <span class="add">[<em>He asked the people,</em> or <em>company of men, to seek</em> a thing for him, <em>and they sought</em> it <em>for him</em>]</span>. <span class="auth">(Lḥ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagoeN">
				<h3 class="entry"><span class="ar">بَغْىٌ</span></h3>
				<div class="sense" id="bagoeN_A1">
					<p><span class="ar">بَغْىٌ</span> <span class="add">[originally an inf. n. (<a href="#bge_1">see 1</a>)]</span> <em>Much</em> of rain; or <em>much rain:</em> in <span class="add">[some of]</span> the copies of the Ḳ, <span class="ar">البطر</span> is erroneously put for <span class="ar">المطر</span>: <span class="auth">(TA:)</span> <span class="add">[and in some, <span class="ar">البَغِىُّ</span> for <span class="ar">البَغْىُ</span>: in a MṢ. copy, I find <span class="ar long">البَغِىُّ الكَثِيرُ مِنَ المَطَرِ</span>: and in the CK, <span class="ar long">البَغِىُّ الكَثِيْرُ من النَّظَرِ</span>:]</span> or <span class="ar long">بَغْىُ السَّمَآءِ</span> signifies <em>the main portion,</em> <span class="auth">(Aṣ, Ṣ,)</span> or <em>the vehemence, and the main portion,</em> <span class="auth">(Lḥ, JK, TA,)</span> <em>of the rain of the sky.</em> <span class="auth">(Aṣ, Lḥ, JK, Ṣ, TA.)</span> Hence the saying, <span class="ar long">دَفَعْنَا بَغْىَ السَّمَآءِ خَلْفَنَا</span> <span class="auth">(Aṣ, Ṣ, TA)</span> or <span class="ar">عَنَّا</span> <span class="auth">(Lḥ, TA)</span> <span class="add">[lit. <em>We drove away the main portion,</em> or <em>the vehemence, and the main portion, of the rain of the sky behind us</em> or <em>from us;</em> meaning <em>it was driven away behind us</em> or <em>from us,</em> or <em>it departed;</em> <a href="index.php?data=08_d/083_dfE">as is shown in art. <span class="ar">دفع</span></a>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bugoyapN">
				<h3 class="entry"><span class="ar">بُغْيَةٌ</span></h3>
				<div class="sense" id="bugoyapN_A1">
					<p><span class="ar">بُغْيَةٌ</span>: <a href="#bigoyapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bigoyapN">
				<h3 class="entry"><span class="ar">بِغْيَةٌ</span></h3>
				<div class="sense" id="bigoyapN_A1">
					<p><span class="ar">بِغْيَةٌ</span> and<span class="arrow"><span class="ar">بُغْيَةٌ↓</span></span> <span class="auth">(JK, Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَغِيَّةٌ↓</span></span> <span class="auth">(Ḳ)</span> <em>A thing sought;</em> <span class="auth">(JK, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَغَايَةٌ↓</span></span> <span class="add">[originally an inf. n. (<a href="#bge_1">see 1</a>)]</span>: <span class="auth">(JK:)</span> or <em>a thing wanted, needed,</em> or <em>required; an object of want</em> or <em>need; a want,</em> or <em>needful</em> or <em>requisite thing</em> or <em>affair:</em> <span class="auth">(Ṣ, Mṣb:)</span> as in the saying, <span class="ar long">لِى فِىبَنِى فُلَانٍ بَغْيَةٌ</span> and <span class="ar">بُغْيَةٌ</span> <span class="add">[<em>I have among the sons of such a one an object of want</em>]</span>: <span class="auth">(Ṣ:)</span> or the first signifies <em>a state that one seeks;</em> and the second, <em>a thing itself that one wants:</em> <span class="auth">(Aṣ, Ṣ, Mṣb:*)</span> and the first, <span class="auth">(JK,)</span> or third, <span class="auth">(Ḳ,)</span> signifies also <em>a stray beast that is sought:</em> <span class="auth">(JK, Ḳ:)</span> the pl. of the second is <span class="ar">بُغًى</span>. <span class="auth">(JK.)</span> <span class="ar long">اِرْتَدَّتْ عَلَى فُلَانٍ بِغْيَتُهُ</span> <span class="add">[<em>The thing that he sought was refused to such a one</em>]</span> is said of one who finds not what he seeks. <span class="auth">(TA.)</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baguwBN">
				<h3 class="entry"><span class="ar">بَغُوٌّ</span></h3>
				<div class="sense" id="baguwBN_A1">
					<p><span class="ar">بَغُوٌّ</span>: <a href="#bagieBN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagieBN">
				<h3 class="entry"><span class="ar">بَغِىٌّ</span></h3>
				<div class="sense" id="bagieBN_A1">
					<p><span class="ar">بَغِىٌّ</span>, accord. to some, of the measure <span class="ar">فَعِيلٌ</span>; accord. to others, of the measure <span class="ar">فَعُولٌ</span>, originally <span class="ar">بَغُوىٌ</span>; <span class="add">[if of the former, originally meaning “sought;” and if of the latter, originally meaning “seeking;”]</span> and therefore <span class="add">[in either case]</span> not admitting the affix <span class="ar">ة</span>: <span class="auth">(TA:)</span> <em>A fornicatress, an adulteress,</em> or <em>a prostitute;</em> <span class="auth">(JK, Ṣ, Mgh, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَغُوٌّ↓</span></span> <span class="add">[of the measure <span class="ar">فَعُولٌ</span>, and therefore anomalous, like <span class="ar">نَهُوٌّ</span>]</span>: <span class="auth">(M, Ḳ:)</span> <span class="ar">بَغِىٌّ</span> is not applied to a man, <span class="auth">(Lḥ, Mṣb,)</span> nor <span class="ar">بَغِيَّةٌ</span> to a woman: <span class="auth">(Lḥ, TA:)</span> pl. <span class="ar">بَغَايَا</span>. <span class="auth">(Ṣ, Mgh, Mṣb.)</span> <span class="add">[See an ex. voce <span class="ar">مَهْرٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَغِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bagieBN_A2">
					<p>Also <em>A female slave,</em> <span class="auth">(JK, Ṣ, Ḳ,)</span> <em>whether she be a fornicatress</em> or <em>an adulteress</em> or <em>a prostitute</em> or <em>not;</em> <span class="auth">(TA;)</span> not meant to imply revilement, though originally applied to female slaves because of their prostitution of themselves: <span class="auth">(Ṣ:)</span> or <em>a free woman who is a fornicatress</em> or <em>an adulteress</em> or <em>a prostitute:</em> so in the Ḳ: but correctly, or <em>a fornicatress</em> or <em>an adulteress</em> or <em>a prostitute, whether free</em> or <em>a slave:</em> <span class="auth">(TA:)</span> and <em>a female singer, though chaste;</em> because of fornication's being originally attributable to such a person: <span class="auth">(Mṣb:)</span> pl. as above. <span class="auth">(JK, Ṣ, TA.)</span> One says, <span class="ar long">قَامَتْ عَلَى رُؤُسِهِمُ البَغَايَا</span> <span class="add">[<em>The female slaves stood over their heads</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَغِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bagieBN_A3">
					<p><span class="ar">بَغَايَا</span> also signifies The <em>scouts,</em> or <em>companies of scouts, that precede an army:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> but the sing. of this is <span class="arrow"><span class="ar">بَغِيَّةٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bagiyBapN">
				<h3 class="entry"><span class="ar">بَغِيَّةٌ</span> / <span class="ar">بَغَايَا</span></h3>
				<div class="sense" id="bagiyBapN_A1">
					<p><span class="ar">بَغِيَّةٌ</span>: <a href="#bigoyapN">see <span class="ar">بِغْيَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَغِيَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bagiyBapN_B1">
					<p>Also, pl. <span class="ar">بَغَايَا</span>: <a href="#bagieBN">see <span class="ar">بَغِىٌّ</span></a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bugaAyapN">
				<h3 class="entry"><span class="ar">بُغَايَةٌ</span></h3>
				<div class="sense" id="bugaAyapN_A1">
					<p><span class="ar">بُغَايَةٌ</span>: <a href="#bigoyapN">see <span class="ar">بِغْيَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAgK">
				<h3 class="entry"><span class="ar">بَاغٍ</span></h3>
				<div class="sense" id="baAgK_A1">
					<p><span class="ar">بَاغٍ</span> <em>Seeking; seeking for,</em> or <em>after; seeking, desiring,</em> or <em>endeavouring, to find, and take,</em> or <em>get:</em> pl. <span class="ar">بُغَاةٌ</span> and <span class="ar">بُغْيَانٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بُغَّآءٌ</span>. <span class="auth">(TA: <span class="add">[there mentioned as a pl., but not said to be of <span class="ar">بَاغٍ</span>, nor explained.]</span>)</span> <span class="ar long">بَاغٍ وَهَادٍ</span>, lit. <em>A seeker</em> of <span class="add">[stray]</span> camels <em>and a guide</em> of the way, mentioned in a trad. respecting the Hijreh <span class="auth">(as said by A booBekr to a man who asked him “Who are ye?”)</span>, alludes to the seeking of religion and the guiding from error. <span class="auth">(TA.)</span> One says, <span class="ar long">فَرِّقُوا لِهٰذِهِ الإِبِلِ بُغْيَانًا يُضِبُّونَ لَهَا</span>, i. e. <span class="add">[<em>Disperse ye, for these camels, seekers</em>]</span> <em>to scatter themselves in search thereof.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَاغٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAgK_A2">
					<p><em>Acting wrongfully, injuriously,</em> or <em>tyrannically,</em> <span class="add">[&amp;c.,]</span> towards others: pl. <span class="ar">بُغَاةٌ</span>. <span class="auth">(Mṣb. <span class="add">[<a href="#bge_1">See 1</a>.]</span>)</span> <span class="ar long">غَيْرَ بَاغٍ</span>, in the Ḳur ii. 168, <span class="add">[&amp;c.,]</span> means <em>Not being a revolter from the Muslims,</em> <span class="auth">(Jel,)</span> or, <em>against the Imám:</em> <span class="auth">(TA:)</span> or it means <em>not desiring to eat for the sake of enjoyment:</em> or <em>not seeking to exceed the limit of his want:</em> <span class="auth">(Az, TA:)</span> or <em>not seeking what he should not seek.</em> <span class="auth">(Er-Rághib, TA.)</span> <span class="ar long">فِئَةٌ بَاغِيَهٌ</span> <em>A company of men revolting from the just Imám.</em> <span class="auth">(Ḳ.)</span> <span class="ar long">فِرْقَةٌ بَاغِيَةٌ</span> <em>A party occupying itself with corrupt, wrong,</em> or <em>unjust, conduct.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَاغٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAgK_A3">
					<p>A camel <em>that does not impregnate,</em> or <em>get with young.</em> <span class="auth">(Kr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَاغٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAgK_A4">
					<p>A horse <em>that is proud,</em> or <em>self-conceited, with exceeding briskness</em> or <em>liveliness</em> or <em>sprightliness:</em> <span class="auth">(JK, Ḥam p. 210:)</span> <span class="add">[but]</span> Kh disallows its being thus used. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغى</span> - Entry: <span class="ar">بَاغٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAgK_B1">
					<p><span class="add">[The pl.]</span> <span class="ar">بُغْيَانٌ</span> also signifies <em>What the sportsman,</em> or <em>hunter, seeks, of game,</em> or <em>objects of the chase.</em> <span class="auth">(JK.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabogFe">
				<span class="pb" id="Page_0233"></span>
				<h3 class="entry"><span class="ar">مَبْغًى</span></h3>
				<div class="sense" id="mabogFe_A1">
					<p><span class="ar">مَبْغًى</span> <span class="add">[<em>A place where a thing is sought:</em> and hence, <em>a way,</em> or <em>manner, in which a thing is,</em> or <em>should be, sought</em>]</span>: this is meant in the saying, <span class="arrow"><span class="ar long">بَغَيْتُ المَالَ مِنْ مَبْغَاتِهِ↓</span></span> <span class="add">[<em>I sought wealth by the way,</em> or <em>manner, whereby it should be sought</em>]</span>; like as <span class="ar">مَأْتًى</span> is meant in the saying, <span class="ar long">أَتَيْتُ الأَمْرَ مِنْ مَأْتَاتِهِ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabogaApN">
				<h3 class="entry"><span class="ar">مَبْغَاةٌ</span></h3>
				<div class="sense" id="mabogaApN_A1">
					<p><span class="ar">مَبْغَاةٌ</span>: <a href="#baAgK">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Almubotagie">
				<h3 class="entry"><span class="ar">المُبْتَغِى</span></h3>
				<div class="sense" id="Almubotagie_A1">
					<p><span class="ar">المُبْتَغِى</span>, <span class="auth">(Ḳ,)</span> or, as in the Tekmileh, <span class="ar">المُتَبَغِّى</span>, <span class="auth">(TA,)</span> <em>The lion:</em> <span class="auth">(Ḳ:)</span> because he is always seeking prey. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlmutabagBie">
				<h3 class="entry"><span class="ar">المُتَبَغِّى</span></h3>
				<div class="sense" id="AlmutabagBie_A1">
					<p><span class="ar">المُتَبَغِّى</span>: <a href="#Almubotagie">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0231.pdf" target="pdf">
							<span>Lanes Lexicon Page 231</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0232.pdf" target="pdf">
							<span>Lanes Lexicon Page 232</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0233.pdf" target="pdf">
							<span>Lanes Lexicon Page 233</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
