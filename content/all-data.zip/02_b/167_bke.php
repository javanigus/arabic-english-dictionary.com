<article class="root" id="Root_bke">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/166_bkm">بكم</a></span>
				<span class="ar">بكى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/168_bl">بل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bke_1">
				<h3 class="entry">1. ⇒ <span class="ar">بكى</span></h3>
				<div class="sense" id="bke_1_A1">
					<p><span class="ar">بَكَى</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْكِىُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بُكَآءٌ</span> and <span class="ar">بُكًا</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">مَبْكًى</span>, <span class="auth">(Ḥar p. 11,)</span> <em>He wept; i. e. he lamented,</em> or <em>grieved, shedding tears at the same time;</em> and <em>he lamented,</em> or <em>grieved,</em> alone; and <em>he shed tears</em> alone: <span class="auth">(Er-Rághib, TA:)</span> accord. to some, the preferable opinion is, that there is no difference between <span class="ar">بُكَآءُ</span> and <span class="ar">بُكًا</span>: <span class="auth">(TA:)</span> or the former means the <em>crying,</em> or <em>uttering of the voice</em> <span class="add">[<em>of lamentation</em>]</span>, <span class="auth">(Ṣ, IḲṭṭ, Mṣb, TA, &amp;c.,)</span> <em>that accompanies</em> <span class="ar">البُكَآء</span> <span class="add">[so in copies of the Ṣ and in the TA, but correctly <span class="ar">البُكَا</span>]</span>; <span class="auth">(Ṣ, IḲṭṭ, TA;)</span> and the latter (<span class="ar">بُكًا</span>), the <em>shedding of tears:</em> <span class="auth">(Ṣ, IḲṭṭ, Mṣb, TA, &amp;c.:)</span> or the former, i. e. with medd, means the <em>shedding of tears by reason of lamentation,</em> or <em>grief, and raising of the voice, or crying,</em> <span class="add">[<em>at the same time,</em>]</span> <em>when the voice is predominant,</em> being like <span class="ar">رُغَآءٌ</span>, and <span class="ar">ثُغَآءٌ</span> and other words of the same form applied to denote the uttering of a cry or of the voice; and the latter, <span class="add">[the <em>shedding of tears, &amp;c.</em>]</span> <em>when lamentation,</em> or <em>grief, is predominant:</em> <span class="auth">(Er-Rághib, TA:)</span> or by the former is meant the <em>crying,</em> or <em>uttering of the voice</em> <span class="add">[<em>of lamentation</em>]</span>; and by the latter, the <em>lamenting,</em> or <em>grieving.</em> <span class="auth">(Kh, TA.)</span> <span class="ar">تَبْكَآءٌ</span> and <span class="ar">تِبْكَآءٌ</span> <span class="add">[may be inf. ns. of <span class="ar">بَكَى</span> or of <span class="arrow"><span class="ar">بَكَّى↓</span></span>, and]</span> signify <em>the same as</em> <span class="ar">بُكَآءٌ</span>: or <em>much</em> <span class="ar">بُكَاء</span> <span class="add">[or <em>weeping,</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> MF asserts that <span class="ar">تِبْكَآءٌ</span> <span class="auth">(with kesr)</span> and the former of these explanations are unknown; but both the word and the explanation are mentioned by Lḥ, as used in a form of words uttered by Arab women of the desert to fascinate men: ISd, however, says that it should be <span class="ar">تَبْكَآء</span>, because it is an inf. n. of a class formed to denote muchness <span class="add">[of the attribute signified by the verb]</span>, like <span class="ar">تَهْذَارٌ</span> and <span class="ar">تَلْعَابٌ</span>, &amp;c.; and IAạr says that <span class="ar">تَبْكَاءٌ</span>, with fet-ḥ, has the latter of the two significations assigned to it above. <span class="auth">(TA.)</span> <span class="add">[See what is said of the measure <span class="ar">تِفْعَالٌ</span> voce <span class="ar">بَيَّنَ</span>.]</span> You say, <span class="ar long">بَكَى لَهُ</span> <span class="auth">(MF, TA)</span> and <span class="ar long">بَكَى عَلَيْهِ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, MF,)</span> meaning <span class="add">[<em>He wept</em>]</span> <em>for,</em> or <em>over, him,</em> or <em>it:</em> and only <span class="ar long">بَكَى بِهِ</span> <span class="add">[or thus and also <span class="ar">بَكَىمِنْهُ</span> as appears from what follows]</span> when meaning <span class="add">[<em>He wept</em>]</span> <em>because,</em> or <em>in consequence, of it:</em> <span class="auth">('Ináyeh, MF, TA:)</span> and <span class="ar">بَكَاهُ</span> and<span class="arrow"><span class="ar">بَكَّاهُ↓</span></span>, <span class="auth">(Aṣ, AZ, Ṣ, Mṣb, Ḳ,)</span> inf. n. of the former <span class="ar">بُكَآءٌ</span> <span class="auth">(Ḳ)</span> <span class="add">[and <span class="ar">بُكًا</span>]</span>, and of the latter <span class="ar">تَبْكِيَةٌ</span>, <span class="auth">(TA,)</span> signify <em>the same as</em> <span class="ar long">بَكَى عَلَيْهِ</span>; <span class="auth">(Aṣ, AZ, Ṣ, Mṣb,* Ḳ;)</span> the object being a man: <span class="auth">(Aṣ, Ṣ:)</span> and <span class="auth">(or as some say, TA)</span> <em>he wept for,</em> or <em>over, him,</em> i. e., one dead; or <em>did so, and enumerated his good qualities</em> or <em>actions;</em> syn. <span class="ar">رَثَاهُ</span>: <span class="auth">(Ḳ:)</span> or, as some say, <span class="ar">بَكَاهُ</span> means <span class="add">[<em>he wept because,</em> or <em>in consequence, of it,</em> i. e.,]</span> <em>on account of being pained:</em> and <span class="ar long">بَكَى عَلَيْهِ</span>, <span class="add">[<em>he wept for,</em> or <em>over, him,</em>]</span> <em>by reason of tenderness of heart,</em> or <em>compassion:</em> and <span class="add">[hence]</span> it is said that <span class="ar">بَكَيْتُهُ</span> is originally <span class="ar long">بَكَيْتُ مِنْهُ</span>: <span class="auth">(TA:)</span> <span class="add">[and<span class="arrow"><span class="ar">بَكَّاهُ↓</span></span> may have an intensive, or a frequentative, meaning; for it is said that]</span> <span class="ar">بَكِّى</span>, addressed to the eye, signifies <em>weep thou much,</em> and <em>repeatedly.</em> <span class="auth">(Ḥam p. 461.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bke_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَكَت السَّحَابَةُ</span> † <em>The cloud rained.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bke_1_A3">
					<p><span class="ar">بَكَى</span> also means <em>He sang:</em> <span class="add">[in the CK, <span class="ar long">وبَكَى عَنِّى</span> is erroneously put for <span class="ar long">وبَكَى غَنَّى</span>:]</span> thus it has two contr. significations: <span class="auth">(Ḳ, TA:)</span> accord. to MF, it has this meaning only in relation to the pigeon and the like; but it is also used in this sense when said of a man, as in a verse cited voce <span class="ar">جَنَازَةٌ</span>, q. v.: and he observes that the assertion of its having two contr significations requires consideration, seeing that it is also said to signify <span class="ar">رَثَى</span>; <span class="add">[for in the performance of <span class="ar">رِثَآء</span>, it is a common practice to sing;]</span> but <span class="ar">رِثَآء</span> is generally accompanied by lamentation, and <span class="ar">غِنَآء</span> by rejoicing. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bke_1_A4">
					<p><span class="ar long">بَاكَيْتُهُ فَبَكَيْتُهُ</span>: <a href="#bke_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bke_2">
				<h3 class="entry">2. ⇒ <span class="ar">بكّى</span></h3>
				<div class="sense" id="bke_2_A1">
					<p><a href="#bke_1">see 1</a>, in three places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bke_2_B1">
					<p><a href="#bke_4">and see also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bke_3">
				<h3 class="entry">3. ⇒ <span class="ar">باكى</span></h3>
				<div class="sense" id="bke_3_A1">
					<p><span class="ar long">بَاكَيْتُهُ فَبَكَيْتُهُ</span>, <span class="auth">(Ṣ, TA,)</span> aor. of the latter <span class="ar">أَبْكُوهُ</span>, <span class="auth">(TA,)</span> or <span class="ar">أَبْكِيهِ</span>, retaining its original form, accord. to a rule observed in the case of a verb having an infirm letter <span class="add">[for its second or third radical]</span> lest a verb with a radical <span class="ar">ى</span> should be confounded with one having a radical <span class="ar">و</span>, <span class="auth">(Ḥam p. 670,)</span> i. e. <span class="add">[<em>I vied with him,</em> or <em>strove to exceed him, in weeping, and I exceeded him therein,</em> or]</span> <em>I was a greater weeper</em> (<span class="ar">أَبْكَى</span>) <em>than he.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bke_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابكى</span></h3>
				<div class="sense" id="bke_4_A1">
					<p><span class="ar">ابكاهُ</span> <span class="add">[<em>He made him,</em> or <em>caused him, to weep;</em> or]</span> <em>he did to him what made him to weep;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">استبكاهُ↓</span></span>. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">بكّاهُ↓ عَلَيْهِ</span></span>, inf. n. <span class="ar">تَبْكِيَةٌ</span>, <em>He excited him to weep for him,</em> or <em>it;</em> <span class="auth">(Ḳ, TA;)</span> namely, a person dead, <span class="auth">(Ḳ,)</span> or a thing lost. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bke_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباكى</span></h3>
				<div class="sense" id="bke_6_A1">
					<p><span class="ar">تباكى</span> signifies <span class="ar long">تَكَلَّفَ البُكَآءَ</span> <span class="add">[i. e. <em>He affected weeping;</em> or <em>endeavoured,</em> or <em>constrained himself, to weep</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> Hence, in a trad., <span class="ar long">فَإِنْ لَمْ تَجِدُوا بُكَآءً فَتَبَاكَوْا</span> <span class="add">[<em>And if ye experience not weeping, endeavour to weep</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[or the words of the trad. are]</span> <span class="ar long">اُتْلُوا القُرْآنَ وَٱبْكُوا فَإِنْ لَمْ تَبْكُوا فَتَبَاكَوْا</span> <span class="add">[<em>Peruse ye the Ḳur-án, and weep;</em> or, <em>if ye weep not, endeavour to do so</em>]</span>. <span class="auth">(Bḍ in xix. 59.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bke_6_A2">
					<p>And <em>He feigned,</em> or <em>made a show of, weeping.</em> <span class="auth">(Ḥar p. 602.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bke_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبكى</span></h3>
				<div class="sense" id="bke_10_A1">
					<p><span class="ar">استبكاهُ</span>: <a href="#bke_4">see 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bke_10_A2">
					<p>Also <em>He desired,</em> or <em>required, of him weeping.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakieBN">
				<h3 class="entry"><span class="ar">بَكِىٌّ</span></h3>
				<div class="sense" id="bakieBN_A1">
					<p><span class="ar">بَكِىٌّ</span> One <em>who weeps much;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَكَّآءٌ↓</span></span>. <span class="auth">(Ḳ, but omitted in some copies and in the TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بكى</span> - Entry: <span class="ar">بَكِىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bakieBN_B1">
					<p><span class="ar long">رَجُلٌ عَيِيٌّ بَكِىٌّ</span>, <em>A man unable to speak.</em> <span class="auth">(Mbr, TA.)</span> <span class="add">[But perhaps this should be <span class="ar">بَكِىْءٌ</span>: <a href="../">see art. <span class="ar">بكأ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bakBaMCN">
				<h3 class="entry"><span class="ar">بَكَّآءٌ</span></h3>
				<div class="sense" id="bakBaMCN_A1">
					<p><span class="ar">بَكَّآءٌ</span>: <a href="#bakieBN">see <span class="ar">بَكِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAkK">
				<h3 class="entry"><span class="ar">بَاكٍ</span></h3>
				<div class="sense" id="baAkK_A1">
					<p><span class="ar">بَاكٍ</span> part. n. of <span class="ar">بَكَى</span> <span class="add">[i. e. <em>Weeping,</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> pl. <span class="ar">بُكِىٌّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> of the measure <span class="ar">فُعُولٌ</span>, with the <span class="ar">و</span> changed into <span class="ar">ى</span> <span class="add">[and the second ḍammeh consequently into a kesreh, wherefore it is also, sometimes, pronounced <span class="ar">بِكِىٌّ</span>]</span>, <span class="auth">(Ṣ,)</span> and <span class="ar">بُكَاةٌ</span>, <span class="auth">(Ḳ,)</span> which is agreeable with analogy and usage, though said by Es-Semeen to have not been heard. <span class="auth">(TA.)</span> <span class="add">[The pl. of the fem., i. e. of <span class="ar">بَاكِيَةٌ</span>, is <span class="ar">بَاكِيَاتٌ</span> and <span class="ar">بَوَاكٍ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabokae">
				<h3 class="entry"><span class="ar">أَبْكَى</span></h3>
				<div class="sense" id="Oabokae_A1">
					<p><span class="ar">أَبْكَى</span> <span class="add">[<em>A greater weeper,</em> or <em>one who weeps more,</em> than another: <a href="#bke_3">see 3</a>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0242.pdf" target="pdf">
							<span>Lanes Lexicon Page 242</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
