<article class="root" id="Root_bgv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/146_bgt">بغت</a></span>
				<span class="ar">بغث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/148_bgX">بغش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgv_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغث</span></h3>
				<div class="sense" id="bgv_1_A1">
					<p><span class="ar">بَغِثَ</span>, <span class="auth">(Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَثُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بُغْثَةٌ</span>, <span class="auth">(Mṣb,)</span> or this is a simple subst., and the inf. n. is <span class="ar">بَغَثٌ</span>, <span class="auth">(TA,)</span> <em>He</em> <span class="auth">(a bird)</span> <em>was,</em> or <em>became, of a colour resembling that of ashes:</em> <span class="auth">(Mṣb:)</span> or <em>he</em> <span class="auth">(a sheep or goat)</span> <em>was of the mixed colours of those to which the epithet</em> <span class="ar">بَغْثَآءُ</span> <em>is applied.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="#Oabogavu">See <span class="ar">أَبْغَثُ</span></a>, <a href="#bugovapN">and <span class="ar">بُغْثَةٌ</span></a>, <a href="#bagavN">and <span class="ar">بَغَثٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagavN">
				<h3 class="entry"><span class="ar">بَغَثٌ</span></h3>
				<div class="sense" id="bagavN_A1">
					<p><span class="ar">بَغَثٌ</span> <em>Dust-colour.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#bugovapN">But see <span class="ar">بُغْثَةٌ</span></a>. Accord. to the TA, <a href="#bgv_1">the former is the inf. n. of 1, q. v.</a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bugovapN">
				<h3 class="entry"><span class="ar">بُغْثَةٌ</span></h3>
				<div class="sense" id="bugovapN_A1">
					<p><span class="ar">بُغْثَةٌ</span> <em>Whiteness inclining to</em> <span class="ar">خُضْرَة</span> <span class="add">[which here app. means <em>a dark,</em> or <em>ashy, dust-colour</em>]</span>: <span class="auth">(T:)</span> <span class="add">[or, in a bird, <em>a colour resembling that of ashes:</em> (<a href="#bgv_1">see 1</a>:)]</span> or the <em>colour of sheep or goats to which the epithet</em> <span class="ar">بَغْثَآءُ</span> <em>is applied.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="#Oabogavu">See <span class="ar">أَبْغَثُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bagovaMCu">
				<h3 class="entry"><span class="ar">بَغْثَآءُ</span></h3>
				<div class="sense" id="bagovaMCu_A1">
					<p><span class="ar">بَغْثَآءُ</span>: <a href="#Oabogavu">see <span class="ar">أَبْغَثُ</span></a>, of which it is the fem.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagaAvN">
				<h3 class="entry"><span class="ar">بَغَاثٌ</span> / 
							<span class="ar">بُغَاثٌ</span> / 
							<span class="ar">بِغَاثٌ</span> / 
							<span class="ar">بَغَاثَةٌ</span></h3>
				<div class="sense" id="bagaAvN_A1">
					<p><span class="ar">بَغَاثٌ</span> <span class="auth">(T, Ṣ, A, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بُغَاثٌ</span> and <span class="ar">بِغَاثٌ</span>; <span class="auth">(A, Mgh, Ḳ;)</span> only the second of these three mentioned by Sb; <span class="auth">(TA;)</span> but the second and third asserted to be correct by Yoo; <span class="auth">(AZ, TA;)</span> and the last heard by Az; <span class="auth">(TA;)</span> or neither of these two is allowable; <span class="auth">(Mṣb;)</span> <em>A bird that does not prey, and such as one does not desire to make an object of prey because it is not eaten:</em> <span class="auth">(T, Mṣb:)</span> or <em>small birds that do not prey, such as sparrows and the like;</em> <span class="add">[a coll. gen. n.;]</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَغَاثَةٌ</span>}</span></add>: <span class="auth">(Mgh:)</span> or <span class="add">[accord. to Lth,]</span> <em>a certain dust-coloured bird,</em> <span class="auth">(T, A, Ḳ,)</span> <em>of the birds of the water, ash-coloured, and long-necked;</em> as also<span class="arrow"><span class="ar">أَبْغَثُ↓</span></span>; pl. <span class="add">[of the latter]</span> <span class="ar">بُغْثٌ</span> and <span class="ar">أَبَاغِثُ</span>: <span class="auth">(T:)</span> <span class="add">[but this appears to be wrong; for AM says, in the T,]</span> Lth makes the <span class="ar">بغاث</span> and the <span class="ar">ابغث</span> to be one, asserting them to be of aquatic birds; but in my opinion, the former is different from the latter: as to the latter, it is <em>a well-known kind of aquatic bird,</em> so called because it is <em>of the colour termed</em> <span class="ar">بُغْثَة</span>, i. e. <em>white inclining to</em> <span class="ar">خُضْرَة</span> <span class="add">[explained above, voce <span class="ar">بُغْثَةٌ</span>]</span>: but as to the <span class="ar">بغاث</span>, it is <em>any bird that is not one of prey:</em> and the word is said to be a coll. gen. n., signifying the <em>class of birds that are objects of prey:</em> <span class="auth">(TA:)</span> ISk says that the <span class="ar">بَغَاث</span> is <em>a bird of a colour inclining to that of dust,</em> <span class="auth">(Ṣ, Mṣb,*)</span> <em>a little less than the</em> <span class="ar">رَخَمَة</span> <span class="add">[or <em>vultur percnopterus</em>]</span>, <span class="auth">(Ṣ,)</span> or <em>less than the</em> <span class="ar">رخمة</span>, <span class="auth">(Mṣb,)</span> <em>slow in flight:</em> <span class="auth">(Ṣ, Mṣb:)</span> but IB says that this is a mistake in two points of view; first, because <span class="ar">بغاث</span> is a <span class="add">[coll.]</span> gen. n., of which the n. un. is with <span class="ar">ة</span>, like <a href="#HamaAmN">as is that of <span class="ar">حَمَامٌ</span></a>; and secondly, because it applies to the <em>class of birds that do not prey;</em> but the <span class="arrow"><span class="ar">أَبْغَث↓</span></span> is <em>a bird of the colour of dust,</em> and this may be <em>a bird of prey,</em> and it may be <em>not a bird of prey:</em> <span class="auth">(TA:)</span> AZ says that <span class="ar">بغاث</span> signifies the <span class="add">[<em>species of vulture called</em>]</span> <span class="ar">رَخَم</span>; and the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَغَاثَةٌ</span>}</span></add> others, the <em>young ones of the</em> <span class="ar">رخم</span> and <em>birds of the crowkind:</em> or <span class="add">[<em>birds</em>]</span> <em>like the</em> <span class="add">[<em>hawks called</em>]</span> <span class="ar">سَوَادِق</span> <span class="add">[<a href="#saWodaqN">pl. of <span class="ar">سَوْدَقٌ</span></a>]</span>, <em>not predaceous:</em> in the T, it is said to be <span class="add">[<em>a kind of bird</em>]</span> <em>like the</em> <span class="add">[<em>hawk called</em>]</span> <span class="ar">بَاشَق</span>, <em>that does not prey upon any other bird:</em> <span class="auth">(TA:)</span> or <span class="ar">بِغَاثٌ</span> and <span class="ar">بُغَاثٌ</span> <span class="auth">(ISd, Ḳ)</span> and <span class="ar">بَغَاثٌ</span> <span class="auth">(Ḳ)</span> signify the <em>worst</em> <span class="add">[or <em>most ignoble</em>]</span> <em>of birds,</em> <span class="auth">(ISd, Ḳ, <span class="add">[the latter giving this as a second and distinct signification,]</span>)</span> and <em>such as do not prey:</em> <span class="auth">(ISd, TA:)</span> Fr says, <span class="ar long">بَغَاثُ الطَّيْرِ</span> signifies <em>the worst of birds,</em> and <em>such as do not prey;</em> and <span class="ar">بُغَاثٌ</span> and <span class="ar">بِغَاثٌ</span> are dial. vars.: <span class="auth">(Ṣ:)</span> the pl. is <span class="ar">بِغْثَانٌ</span>, <span class="auth">(Sb, T, Ṣ, Mṣb, Ḳ,)</span> accord. to those who make <span class="ar">بغاث</span> a sing., <span class="auth">(Yoo, Ṣ, Mṣb, TA,)</span> or accord. to those who make the sing. to be with <span class="ar">ة</span>; <span class="auth">(T, TA;)</span> or those who apply <span class="ar">بَغَاثَةٌ</span> <span class="add">[as a n. un.]</span> to the male and the female make <span class="ar">بَغَاثٌ</span> to be pl. <span class="add">[or rather a coll. gen. n.]</span>; <span class="auth">(Yoo, Ṣ, Mṣb;)</span> as is done in the case of <span class="ar">نَعَامَةٌ</span> and <span class="ar">نَعَامٌ</span>: <span class="auth">(Yoo, Ṣ:)</span> ISd says that <span class="ar">بَغَاثَةٌ</span>, with fet-ḥ, is the n. un., applied alike to the male and the female: <span class="auth">(TA:)</span> <span class="add">[and Fei says,]</span> it is not allowable to pronounce this with damm or with kesr to the first letter: <span class="auth">(Mṣb:)</span> but Yoo asserts both of these forms to be used: <span class="auth">(AZ, TA:)</span> and <span class="ar">بغاثة</span> is said to signify <em>a weak bird.</em> <span class="auth">(TA.)</span> It is said in a prov., <span class="ar long">إِنَّ البَغَاثَ بِأَرْضِنَا يَسْتَنْسِرُ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ *)</span> <em>Verily the</em> <span class="ar">بغاث</span> <em>in our land becomes</em> <span class="add">[<em>like</em>]</span> <em>a vulture,</em> or <em>become</em> <span class="add">[<em>like</em>]</span> <em>vultures:</em> <span class="auth">(Mṣb:)</span> applied to the low person who becomes of high rank: <span class="auth">(A:)</span> meaning ‡ <em>the weak in our land becomes strong:</em> <span class="auth">(Mṣb:)</span> or <em>he who makes himself our neighbour becomes mighty, strong,</em> or <em>of high rank, by our means,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>acquiring the might,</em> or <em>strength, of the vulture, after having been low,</em> or <em>mean, in condition.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagiyvN">
				<h3 class="entry"><span class="ar">بَغِيثٌ</span></h3>
				<div class="sense" id="bagiyvN_A1">
					<p><span class="ar">بَغِيثٌ</span> <em>Wheat</em> (<span class="ar">حِنْطَةٌ</span> and <span class="ar">طَعَامٌ</span> <span class="add">[both of which signify the same, though the latter, q. v., has a a larger application,]</span>) <em>adulterated by being mixed with barley;</em> <span class="auth">(Th, Ḳ;)</span> as also <span class="ar">غَلِيثٌ</span> and <span class="ar">لَغِيثٌ</span>. <span class="auth">(Th, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bugayovaMCu">
				<h3 class="entry"><span class="ar">بُغَيْثَآءُ</span></h3>
				<div class="sense" id="bugayovaMCu_A1">
					<p><span class="ar">بُغَيْثَآءُ</span> <span class="add">[<a href="#bagovaACu">dim. of <span class="ar">بَغْثَآءُ</span></a> <a href="#Oabogavu">fem. of <span class="ar">أَبْغَثُ</span>, q. v.</a>,]</span> The <em>place of the</em> <span class="ar">حَقِيبَة</span> <span class="add">[q. v.]</span> in a camel. <span class="auth">(Ḳ.)</span> <span class="add">[So called because of its colour, produced by chafing.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabogavu">
				<h3 class="entry"><span class="ar">أَبْغَثُ</span></h3>
				<div class="sense" id="Oabogavu_A1">
					<p><span class="ar">أَبْغَثُ</span> <em>Of a white colour inclining to</em> <span class="ar">خُضْرَة</span> <span class="add">[which here app. means <em>a dark,</em> or <em>ashy, dustcolour</em>]</span>: <span class="auth">(T:)</span> <span class="add">[or <em>of a colour resembling that of ashes:</em> (<a href="#bgv_1">see 1</a>:)]</span> or <em>dust-coloured:</em> <span class="auth">(A:)</span> or <em>of a colour near to that of dust:</em> <span class="auth">(Ṣ:)</span> an epithet, like <span class="ar">أَحْمَرُ</span>: <span class="add">[fem. <span class="ar">بَغْثَآءُ</span>: and]</span> pl. <span class="ar">بُغْثٌ</span>: and sometimes, when used as a subst., it has for pl. <span class="ar">أَبَاغِثُ</span>. <span class="auth">(IB, TA.)</span> You say <span class="ar long">طَائِرٌ أَبْغَثُ</span> <em>A bird of the colour above described:</em> <span class="auth">(T, Ṣ:)</span> whether it be a bird of prey or not: <a href="#bagaAvN">see <span class="ar">بَغَاثٌ</span></a> in two places: <span class="auth">(IB, TA:)</span> and <span class="ar long">صَقْرٌ أَبْغَثُ</span> <span class="add">[<em>a hawk of that colour.</em>]</span>; <span class="auth">(ISh, A;)</span> as well as <span class="ar">أَحْوَى</span> and <span class="ar">أَبْيَضُ</span>; i. e., that wherewith men take game. <span class="auth">(ISh, TA.)</span> <span class="ar">بَغْثَآءُ</span> applied to sheep or goats, <span class="auth">(Ṣ, Ḳ,)</span> or, as in some lexicons, to sheep, <span class="auth">(TA,)</span> is like <span class="ar">رَقْطَآءُ</span>; <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[<em>Black speckled with white;</em> or <em>the reverse;</em>]</span> or <em>in which are blackness and whiteness, with predominance of the latter colour:</em> <span class="auth">(TA:)</span> or <span class="ar long">شَاةٌ بَغْثَآءُ</span> and <span class="ar long">غَنَمٌ بُغْثٌ</span> signify <em>a sheep</em> or <em>goat,</em> and <em>sheep</em> or <em>goats, in which are blackness and whiteness.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغث</span> - Entry: <span class="ar">أَبْغَثُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabogavu_A2">
					<p>Also, <span class="add">[as a subst.,]</span> <em>A certain bird,</em> <span class="auth">(Ḳ, TA,)</span> <em>dustcoloured,</em> in truth <em>different from the</em> <span class="ar">بَغَاث</span>, as shown above: see the latter word: <span class="auth">(TA:)</span> pl. <span class="ar">بُغْثٌ</span> and <span class="ar">أَبَاغِثُ</span>. <span class="auth">(T, TA.)</span> You say, <span class="ar long">هُوَ مِنْ أَبَاغِثِ الطَّيْرِ</span> <span class="add">[<em>He is of the birds thus called</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغث</span> - Entry: <span class="ar">أَبْغَثُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabogavu_A3">
					<p>And <span class="ar">الأَبْغَثُ</span> signifies <em>The lion;</em> <span class="auth">(TṢ, Ḳ;)</span> because he is of the colour termed <span class="ar">بُغْثَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغث</span> - Entry: <span class="ar">أَبْغَثُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oabogavu_A4">
					<p>And <span class="ar">البَغْثَآءُ</span> ‡ <em>The medley,</em> or <em>mixed</em> or <em>promiscuous multitude</em> or <em>collection, of men</em> or <em>people;</em> or <em>of the lowest</em> or <em>basest</em> or <em>meanest sort,</em> or <em>refuse,</em> or <em>riffraff, thereof;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> <em>the commonalty,</em> or <em>vulgar,</em> and <em>collective body, of the people.</em> <span class="auth">(Ṣ.)</span> One says, <span class="ar long">خَرَجَ فَلَانٌ فِى البَغْثَآءِ</span> and <span class="ar">الغَثْرَآءِ</span> ‡ <em>Such a one went forth among the medley,</em>, &amp;c., <em>of the people.</em> <span class="auth">(A.)</span> And <span class="ar long">دَخَلْنَا فِى البَغْثَآءِ</span> ‡ <em>We entered among the commonalty,</em> or <em>vulgar,</em> and <em>the collective body, of the people.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0229.pdf" target="pdf">
							<span>Lanes Lexicon Page 229</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
