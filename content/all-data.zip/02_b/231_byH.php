<article class="root" id="Root_byH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/230_byt">بيت</a></span>
				<span class="ar">بيح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/232_byd">بيد</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">بيح</span></h4>
			<hr>
			<section class="entry xref" id="bayoHaAnN">
				<h3 class="entry"><span class="ar">بَيْحَانٌ</span> / <span class="ar">بَيَّحَانٌ</span></h3>
				<div class="sense" id="bayoHaAnN_A1">
					<p><span class="ar">بَيْحَانٌ</span> and <span class="ar">بَيَّحَانٌ</span>: <a href="#baWuwHN">see <span class="ar">بَؤُوحٌ</span></a>, <a href="index.php?data=02_b/215_bwH">in art. <span class="ar">بوح</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0281.pdf" target="pdf">
							<span>Lanes Lexicon Page 281</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
