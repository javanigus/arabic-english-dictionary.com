<article class="root" id="Root_bOr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/007_bAcnjAn">باذنجان</a></span>
				<span class="ar">بأر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/009_bOz">بأز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bOr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بأر</span></h3>
				<div class="sense" id="bOr_1_A1">
					<p><span class="ar">بَأَرَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْأَرُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> <em>He sunk,</em> or <em>dug,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> a well; <span class="auth">(Ṣ, M;)</span> as also<span class="arrow"><span class="ar">ابتأر↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bOr_1_A2">
					<p>Also, aor. as above, inf. n. <span class="ar">بَأْرٌ</span>, <em>He dug a</em> <span class="add">[<em>hollow such as is termed</em>]</span> <span class="ar">بُؤْرَة</span>, <span class="auth">(AZ, Ṣ, M,)</span> <em>in which to cook.</em> <span class="auth">(AZ, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bOr_1_A3">
					<p>Also, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. as above, <span class="auth">(M, Ḳ,)</span> and so the inf. n.; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar">ابتأر↓</span></span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> <em>He hid,</em> or <em>concealed,</em> a thing: <span class="auth">(T, M, Ḳ:)</span> and <em>he stored</em> it, or <em>laid</em> it <em>up, for a time of need.</em> <span class="auth">(T, Ṣ, Ḳ.)</span> Hence a hollow dug in the ground is termed <span class="ar">بُؤْرَةٌ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bOr_1_A4">
					<p>You say also,<span class="arrow"><span class="ar long">ابتأر↓ خَيْرًا</span></span>, <span class="auth">(T, M, Ḳ,)</span> and <span class="ar">بَأَرَهُ</span>, <span class="auth">(M, Ḳ,)</span> <em>He did good beforehand:</em> <span class="auth">(T, M, Ḳ:)</span> or, accord. to some, <em>he, as it were, did good beforehand for himself, having laid it up,</em> or <em>concealed it, for himself:</em> <span class="auth">(T, TA:)</span> so says El-Umawee: or <em>he laid up for himself in store concealed good:</em> <span class="auth">(TA:)</span> or <em>he did good concealedly:</em> <span class="auth">(M, Ḳ:)</span> and <span class="ar">ائتبر</span> signifies the same. <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bOr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابأر</span></h3>
				<div class="sense" id="bOr_4_A1">
					<p><span class="ar long">ابأر فُلَانًا</span> <em>He made,</em> or <em>he assigned,</em> or <em>appointed,</em> (<span class="ar">جَعَلَ</span>,) <em>for such a one, a well.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bOr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتأر</span></h3>
				<div class="sense" id="bOr_8_A1">
					<p><a href="#bAr_1">see 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biYorN">
				<h3 class="entry"><span class="ar">بِئْرٌ</span></h3>
				<div class="sense" id="biYorN_A1">
					<p><span class="ar">بِئْرٌ</span> <span class="auth">(T, Ṣ, M, &amp;c.)</span> and <span class="ar">بِيرٌ</span>, <span class="auth">(Mṣb,)</span> of the fem. gender, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بِئْرَةٌ↓</span></span>, <span class="auth">(M,)</span> <em>A well:</em> <span class="auth">(M, TA:)</span> pl. <span class="auth">(of pauc., Ṣ, Mṣb)</span> <span class="ar">أَبْؤُرٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="auth">(by transposition, Fr, Mṣb)</span> <span class="ar">آبُرٌ</span> <span class="auth">(Fr, Mṣb, Ḳ)</span> and <span class="ar">أَبْآرٌ</span> and <span class="auth">(by transposition, Yaạḳoob, T, Ṣ, M)</span> <span class="ar">آبَارٌ</span> and <span class="auth">(of mult., Ṣ, Mṣb)</span> <span class="ar">بِئَارٌ</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> and pl. of pauc. <span class="add">[of <span class="ar">بِيرٌ</span>]</span> <span class="ar">أَبْيَارٌ</span>. <span class="auth">(Mṣb.)</span> The dim. is<span class="arrow"><span class="ar">بُؤَيْرَةٌ↓</span></span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buWorapN">
				<h3 class="entry"><span class="ar">بُؤْرَةٌ</span></h3>
				<div class="sense" id="buWorapN_A1">
					<p><span class="ar">بُؤْرَةٌ</span> <em>A hollow,</em> or <em>hole, dug in the ground,</em> <span class="auth">(AZ, Ṣ, M, Ḳ,)</span> <em>in which to cook;</em> also called <span class="ar">إِرَةٌ</span>: <span class="auth">(AZ, Ṣ:)</span> or <span class="auth">(M)</span> <em>a place in which fire is lighted.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#bAr_1">See 1</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأر</span> - Entry: <span class="ar">بُؤْرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buWorapN_B1">
					<p><a href="#bayiyrapN">See also <span class="ar">بَئِيرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biYorpN">
				<h3 class="entry"><span class="ar">بِئْرةٌ</span></h3>
				<div class="sense" id="biYorpN_A1">
					<p><span class="ar">بِئْرةٌ</span>: <a href="#bYorN">see <span class="ar">بئْرٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأر</span> - Entry: <span class="ar">بِئْرةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="biYorpN_B1">
					<p><a href="#bayiyrapN">and see <span class="ar">بَئِيرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buWayorapN">
				<h3 class="entry"><span class="ar">بُؤَيْرَةٌ</span></h3>
				<div class="sense" id="buWayorapN_A1">
					<p><span class="ar">بُؤَيْرَةٌ</span>: <a href="#biYorN">see <span class="ar">بِئْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baYiyrapN">
				<h3 class="entry"><span class="ar">بَئِيرَةٌ</span></h3>
				<div class="sense" id="baYiyrapN_A1">
					<p><span class="ar">بَئِيرَةٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">بِئْرَةٌ↓</span></span> and<span class="arrow"><span class="ar">بُؤْرَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <em>A thing stored,</em> or <em>laid up, for a time of need.</em> <span class="auth">(T, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baOBLrN">
				<h3 class="entry"><span class="ar">بَأّٓرٌ</span></h3>
				<div class="sense" id="baOBLrN_A1">
					<p><span class="ar">بَأّٓرٌ</span>, <span class="auth">(T, TA, and so in some copies of the Ḳ,)</span> or <span class="ar">أَبَّارٌ</span>, <span class="auth">(as in other copies of the Ḳ and so in the CK,)</span> the latter formed by transposition, and the former <span class="add">[said to have been]</span> not heard, <span class="auth">(M,)</span> <em>A well-sinker,</em> or <em>well-digger.</em> <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
