<article class="root" id="Root_bxS">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/036_bxs">بخس</a></span>
				<span class="ar">بخص</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/038_bxE">بخع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxS_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخص</span></h3>
				<div class="sense" id="bxS_1_A1">
					<p><span class="ar long">بَخَصَ عَيْنَهُ</span>, <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَصُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> inf. n. <span class="ar">بَخْصٌ</span>, <span class="auth">(Ṣ, Mgh,)</span> <em>He put out his eye;</em> syn. <span class="ar">فَقَأَهَا</span>, <span class="auth">(Mgh,)</span> and <span class="ar">عَوَّرَهَا</span>: <span class="auth">(A, Mgh:)</span> or <em>he pulled out his eye</em> <span class="add">[<em>altogether, i. e.,</em>]</span> <em>with its bulb:</em> <span class="auth">(Ṣ, Ḳ: <span class="add">[in the former, <span class="ar long">مَعض شَحْمَتِهَا</span>: in the latter, not so well, <span class="ar">بِشَحْمِهَا</span>:]</span>)</span> or <em>he put his finger into his eye:</em> <span class="auth">(Mṣb:)</span> Yaạḳoob says that you should not say <span class="ar">بَخَسَ</span>; <span class="auth">(Ṣ;)</span> and so says ISk: <span class="auth">(TA in art. <span class="ar">بخس</span>:)</span> but accord. to Aṣ, as related by Aboo-Turáb, you say <span class="ar long">بَخَصَ عَيْنَهُ</span> and <span class="ar">بَخَزَهَا</span> and <span class="ar">بَخَسَهَا</span>, all as meaning <em>he put out his eye;</em> syn. <span class="ar">فَقَأَهَا</span>: <span class="auth">(TA:)</span> and IAạr says that <span class="ar">بَخَسَهَا</span> and <span class="ar">بَخَصَهَا</span> signify alike: <span class="auth">(Mṣb:)</span> the former of these two is a dial. var. of the latter; <span class="auth">(TA in art. <span class="ar">بخس</span>;)</span> and signifies <em>he put it out</em> (<span class="ar">فَقَأَهَا</span>) <em>with his finger</em> or <em>some other thing:</em> <span class="auth">(Lth, Aṣ, and Ḳ in art. <span class="ar">بخس</span>:)</span> but <span class="ar">بَخَصَ</span> is the better word. <span class="auth">(Lḥ, IAạr, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0159.pdf" target="pdf">
							<span>Lanes Lexicon Page 159</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
