<article class="root" id="Root_bre">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/088_brw">برو</a></span>
				<span class="ar">برى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/090_bz">بز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bre_1">
				<h3 class="entry">1. ⇒ <span class="ar">برى</span></h3>
				<div class="sense" id="bre_1_A1">
					<p><span class="ar">بَرَى</span>, <span class="auth">(T, M, Ḳ,)</span> first pers. <span class="ar">بَرَيْتُ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْرِىُ</span>}</span></add>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">بَرْىٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> <em>He formed,</em> or <em>fashioned, by cutting; shaped out;</em> or <em>pared;</em> <span class="auth">(Aṣ, T, M, Ḳ;)</span> a reed for writing, <span class="auth">(Lth, Aṣ, ISk, T, Ṣ, M, Mṣb,)</span> and a stick, or piece of wood, <span class="auth">(Lth, T, M,)</span> and an arrow, <span class="auth">(M, Ḳ,)</span>, &amp;c.; <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar">ابترى↓</span></span>: <span class="auth">(M, Ḳ:)</span> and <span class="ar">بَرَوْتُ</span>, <span class="auth">(Mṣb,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُىُ</span>}</span></add>, <span class="auth">(Lth, T,)</span> is a dial. var., <span class="auth">(Mṣb,)</span> used by some, who say, <span class="ar long">هُمَ يَقْلُو البُرَّ</span> <span class="add">[instead of <span class="ar">يَقْلِى</span>]</span>. <span class="auth">(Lth, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bre_1_A2">
					<p>And hence, <span class="auth">(Aṣ, T,)</span> aor. and inf. n. as above, <span class="auth">(Aṣ, T, M, Ḳ,)</span> † <em>He</em> <span class="auth">(a man)</span> <em>fatigued,</em> or <em>jaded, and made to lose flesh,</em> <span class="auth">(Aṣ,* T,* Ṣ,)</span> a she-camel, <span class="auth">(Aṣ, T,)</span> or a camel: <span class="auth">(Ṣ:)</span> or <em>it</em> <span class="auth">(journeying)</span> <em>rendered</em> him <em>lean,</em> or <em>emaciated:</em> <span class="auth">(M, Ḳ:)</span> and in like manner one says of a year of dearth or drought. <span class="auth">(TA.)</span> And <span class="ar long">بَرَيْتُ سَنَامَهَا بِسَيْرِى عَلَيْهَا</span> † <span class="add">[<em>I wasted her hump by my journeying upon her</em>]</span>: occurring in a poem of El-Aạshà. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bre_1_B1">
					<p><a href="#bre_3">See also 3</a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bre_1_B2">
					<p><a href="#bre_5">and see 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bre_3">
				<h3 class="entry">3. ⇒ <span class="ar">بارى</span></h3>
				<div class="sense" id="bre_3_A1">
					<p><span class="ar">باراهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">مُبَارَاةٌ</span>, <span class="auth">(T, TA,)</span> <em>He vied, competed,</em> or <em>contended for superiority, with him; emulated,</em> or <em>rivalled, him;</em> or <em>imitated him; i. q.</em> <span class="ar">عَارَضَهُ</span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> i. e., <span class="auth">(TA,)</span> <em>he did the like of what he</em> <span class="auth">(the latter)</span> <em>did,</em> <span class="auth">(ISk, T, Ṣ, Mṣb, TA, and EM p. 64,)</span> <em>striving to overcome him</em> or <em>surpass him;</em> <span class="auth">(EM ubi suprà;)</span> as also<span class="arrow"><span class="ar long">بَرَى↓ لَهُ</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْرِىُ</span>}</span></add>, inf. n. <span class="ar">بَرْىٌ</span>; and<span class="arrow"><span class="ar long">انبرى↓ له</span></span>: <span class="auth">(Aṣ, T:)</span> and <em>he vied,</em> or <em>competed, with him,</em> or <em>contended with him for superiority, in glory,</em> or <em>excellence,</em> or <em>in beauty,</em> or <em>goodliness; he emulated,</em> or <em>rivalled, him therein;</em> syn. <span class="ar">بَاهَاهُ</span>: <span class="auth">(TA in art. <span class="ar">بهج</span>:)</span> and <em>he vied, competed,</em> or <em>contended, with him in running; and strove with him to outstrip him, to be before him, to get before him,</em> or <em>to precede him.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">فُلَانٌ يُبَارِى الرِّيحَ سَخَآءً</span> <span class="add">[<em>Such a one vies with the wind in bounty</em>]</span>: <span class="auth">(T, Ṣ:)</span> <span class="add">[for]</span> the bountiful man whose gifts are common is likened by the Arabs to the wind because it blows upon all in common, not only upon particular persons. <span class="auth">(Ḥam p. 445.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bre_3_B1">
					<p><span class="ar long">بارى ٱمْرَأَتَهُ</span> <em>He compounded,</em> or <em>made a compromise, with his wife for their mutual separation;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">بَارَأَهَا</span> <span class="add">[which is the original]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bre_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرى</span></h3>
				<div class="sense" id="bre_4_A1">
					<p><span class="ar">ابرى</span>: <a href="index.php?data=02_b/088_brw">see art. <span class="ar">برو</span></a></p> 
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bre_4_B1">
					<p>Also <em>He found,</em> or <em>met with, sugar-canes.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bre_4_C1">
					<p><a href="#AaboraOa">See also <span class="ar">أَبْرَأَ</span></a>, <a href="../">in art. <span class="ar">برأ</span></a>, last signification.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bre_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّى</span></h3>
				<div class="sense" id="bre_5_A1">
					<p><span class="ar">التَّبَرِّى</span> signifies <em>The coming before</em> or <em>forward, presenting oneself, advancing, confronting, encountering, meeting,</em> or <em>opposing;</em> <span class="auth">(KL;)</span> and so<span class="arrow"><span class="ar">الاِنْبِرَآءُ↓</span></span>. <span class="auth">(KL, PṢ.)</span> You say, <span class="ar long">تبرّى لَهُ</span> <em>He presented, addressed, applied,</em> or <em>betook, himself to him,</em> i. e., one man to another man; <em>advanced, came forward,</em> or <em>went forward, to him;</em> or <em>opposed himself to him;</em> syn. <span class="ar">تَعَرَّضَ</span>; as also <span class="ar">تبرّاهُ</span>; and<span class="arrow"><span class="ar long">بَرَى↓ لَهُ</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْرِىُ</span>}</span></add>: <span class="auth">(T:)</span> and<span class="arrow"><span class="ar long">انبرى↓ له</span></span> signifies <span class="ar long">اِعْتَرَضَ لَهُ</span>, <span class="auth">(Ṣ, Ḳ, and Ḥar p. 558,)</span> meaning <span class="add">[as above; or]</span> <em>he betook himself, and advanced,</em> or <em>went forward, to it,</em> namely, an action; <span class="auth">(Ḥar ubi suprà;)</span> and <em>it presented itself to it,</em> as a thought to the heart, or mind, syn. <span class="ar">تعرّض</span>: <span class="auth">(Ḥam p. 541:)</span> <span class="arrow"><span class="ar long">بَرَى↓ لَهُ</span></span>, inf. n. <span class="ar">بَرْىٌ</span>, is <em>syn. with</em> <span class="ar long">عَرَضَ لَهُ</span> <span class="add">[meaning as above, for it is syn. with <span class="ar">تَعَرَّضَ</span> and <span class="ar">اِعْتَرَضَ</span>; or <em>it happened to him, befell him,</em> or <em>occurred to him</em>]</span>: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar">انبرى↓</span></span> is also <em>syn. with</em> <span class="ar">عَرَضَ</span> <span class="add">[meaning <em>it happened, befell,</em> or <em>occurred</em>]</span>. <span class="auth">(Ḥar p. 56.)</span> You say also, <span class="ar long">تبرّى لِمَعْرُوفِهِ</span>, i. e. <span class="ar long">تَعَرَّضَ لَهُ</span> <span class="auth">(ISk, Ṣ, Ḳ)</span> or <span class="ar long">اِعْتَرَضَ لَهُ</span> <span class="auth">(M)</span> <span class="add">[both of which explanations mean <em>He presented, addressed, applied,</em> or <em>betook, himself,</em> or <em>he advanced, came forward, went forward,</em> or <em>attempted, to obtain his favour,</em> or <em>bounty;</em> or <em>he sought it,</em> or <em>demanded it</em>]</span>; as also <span class="ar long">تبرّى مَعْرُوفَهُ</span>. <span class="auth">(M, TA.)</span> And <span class="ar long">تَبَرَّيْتُ وُدَّهُمْ</span> <span class="add">[<em>I addressed, applied,</em> or <em>betook, myself to obtain their love,</em> or <em>affection</em>]</span>. <span class="auth">(Ṣ, M.)</span> And<span class="arrow"><span class="ar long">انبرى↓ لِطَىِّ بِسَاطِهِ</span></span>, <em>i. q.</em> <span class="ar">اِعْتَرَضَ</span>, meaning, in this instance, <em>He hastened to cut short his speech.</em> <span class="auth">(Ḥar p. 280.)</span> And<span class="arrow"><span class="ar long">انبرى↓ يُنْشِدُ شِعْرًا</span></span>, i. e. <span class="ar long">تَعَرَّضَ لِإِنْشَآئِهِ</span> <span class="add">[or <span class="ar">لِإِنْشَادِهِ</span>, meaning <em>He addressed himself to reciting poetry,</em> or <em>verses</em>]</span>. <span class="auth">(Ḥar p. 34.)</span> And<span class="arrow"><span class="ar long">انبرى↓ مِنَ الجَمَاعَةِ</span></span>, <em>i. q.</em> <span class="ar">اِعْتَرَضَ</span> <span class="add">[<em>He presented himself,</em> or <em>advanced,</em> or <em>came forward, from the company</em>]</span>. <span class="auth">(Ḥar p. 647.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bre_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبارى</span></h3>
				<div class="sense" id="bre_6_A1">
					<p><span class="ar">تَبَارَيَا</span> <em>They vied, competed,</em> or <em>contended for superiority, each with the other; emulated,</em> or <em>rivalled, each other; imitated each other;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> <em>they did each like as the other did.</em> <span class="auth">(T, Ṣ, TA.)</span> <span class="add">[See the part. n., below.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bre_7">
				<span class="pb" id="Page_0198"></span>
				<h3 class="entry">7. ⇒ <span class="ar">انبرى</span></h3>
				<div class="sense" id="bre_7_A1">
					<p><span class="ar">انبرى</span>, <span class="auth">(Ḳ, TA,)</span> or<span class="arrow"><span class="ar">ابترى↓</span></span>, <span class="auth">(so in a copy of the M,)</span> <em>It was,</em> or <em>became, formed,</em> or <em>fashioned, by cutting; shaped out;</em> or <em>pared:</em> <span class="auth">(M, Ḳ:)</span> said of a reed for writing, and of a stick, or piece of wood, <span class="auth">(M,)</span> and of an arrow, <span class="auth">(M, Ḳ,)</span>, &amp;c. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 7.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bre_7_B1">
					<p><a href="#bre_3">See also 3</a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bre_7_B2">
					<p><a href="#bre_5">and see 5</a>, in six places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bre_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابترى</span></h3>
				<div class="sense" id="bre_8_A1">
					<p><a href="#bre_1">see 1</a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bre_8_B1">
					<p><a href="#bre_7">and see also 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="barFe">
				<h3 class="entry"><span class="ar">بَرًى</span> / <span class="ar">بَرًا</span></h3>
				<div class="sense" id="barFe_A1">
					<p><span class="ar">بَرًى</span>, or <span class="ar">بَرًا</span>: <a href="index.php?data=02_b/088_brw">see art. <span class="ar">برو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baraApN">
				<h3 class="entry"><span class="ar">بَرَاةٌ</span></h3>
				<div class="sense" id="baraApN_A1">
					<p><span class="ar">بَرَاةٌ</span>: <a href="#miboraApN">see <span class="ar">مِبْرَاةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: <span class="ar">بَرَاةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baraApN_B1">
					<p><a href="#baraACapN">See also <span class="ar">بَرَآءَةٌ</span></a>, <a href="../">in art. <span class="ar">برأ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baraMCN.1">
				<h3 class="entry"><span class="ar">بَرَآءٌ</span></h3>
				<div class="sense" id="baraMCN.1_A1">
					<p><span class="ar">بَرَآءٌ</span>: <a href="#miboraApN">see <span class="ar">مِبْرَاةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buraMCN">
				<h3 class="entry"><span class="ar">بُرَآءٌ</span></h3>
				<div class="sense" id="buraMCN_A1">
					<p><span class="ar">بُرَآءٌ</span>: <a href="#buraAyapN">see <span class="ar">بُرَايَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barieBN">
				<h3 class="entry"><span class="ar">بَرِىٌّ</span></h3>
				<div class="sense" id="barieBN_A1">
					<p><span class="ar">بَرِىٌّ</span>, applied to an arrow, <em>i. q.</em><span class="arrow"><span class="ar">مَبْرِىٌّ↓</span></span> <span class="add">[i. e. <em>Formed,</em> or <em>fashioned, by cutting; shaped out;</em> or <em>pared</em>]</span>; <span class="auth">(T, M, Ḳ;)</span> or <span class="auth">(M, Ḳ)</span> <em>completely;</em> <span class="auth">(T, M, Ḳ;)</span> <em>but not feathered, nor headed:</em> for an arrow when first cut is termed <span class="ar">قِطْعٌ</span>; then it is formed, or fashioned, by cutting, or shaped out, or pared, and is termed <span class="ar">بَرِىٌّ</span>; and when straightened, and fit to be feathered and headed, it is a <span class="ar">قِدْح</span>; and when feathered and headed, it becomes a <span class="ar">سَهْم</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برى</span> - Entry: <span class="ar">بَرِىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barieBN_B1">
					<p>It is also sometimes used for <span class="ar">بَرِىْءٌ</span>. <span class="auth">(Ḳz, TA in art. <span class="ar">برأ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlbariyBapN.1">
				<h3 class="entry"><span class="ar">البَرِيَّةٌ</span></h3>
				<div class="sense" id="AlbariyBapN.1_A1">
					<p><span class="ar">البَرِيَّةٌ</span>: <a href="index.php?data=02_b/088_brw">see art. <span class="ar">برو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buraAyapN">
				<h3 class="entry"><span class="ar">بُرَايَةٌ</span></h3>
				<div class="sense" id="buraAyapN_A1">
					<p><span class="ar">بُرَايَةٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">بُرَآءٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> in which latter the <span class="ar">ء</span> is originally <span class="ar">ى</span>, <span class="auth">(IJ, M,)</span> <em>Cuttings, chips, parings,</em> or <em>the like;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>what falls from a thing that is formed,</em> or <em>fashioned, by cutting.</em> <span class="auth">(T, Ṣ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: <span class="ar">بُرَايَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buraAyapN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">مَطَرٌ ذُو بُرَايَةٍ</span> † <em>Rain that pares and peels the ground.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: <span class="ar">بُرَايَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buraAyapN_A3">
					<p>And <span class="ar long">هُوَ مِنْ بُرَايَتِهِمْ</span> † <em>He is of the refuse,</em> or <em>lowest</em> or <em>meanest sort, of them.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: <span class="ar">بُرَايَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="buraAyapN_A4">
					<p>But <span class="ar long">ذُو بُرَايَةٍ</span>, applied to a camel, means † <em>En-during travel:</em> <span class="auth">(T, Ṣ, M:)</span> or <em>having fat and flesh:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">ذَاتُ بُرَايَةٍ</span>, applied to a she-camel, has the latter meaning: or the former: <span class="auth">(M, Ḳ:)</span> or <em>strong when fatigued and emaciated by travel:</em> <span class="auth">(TA:)</span> or, as some say, <span class="ar">براية</span> in both cases means the <em>remains of fatness and compactness,</em> or <em>of fat, and of strength.</em> <span class="auth">(M, TA.)</span> <span class="ar long">حَتُّ البُرَايَةِ</span> is said to mean † <em>Fleet,</em> or <em>swift, when emaciated by travel;</em> for the subst. <span class="ar">براية</span> is said to be here put for the inf. n. <span class="ar">بَرْى</span>. <span class="auth">(L in art. <span class="ar">حت</span>, q. v.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biraAyapN">
				<h3 class="entry"><span class="ar">بِرَايَةٌ</span></h3>
				<div class="sense" id="biraAyapN_A1">
					<p><span class="ar">بِرَايَةٌ</span> <a href="#bre_1">a quasi-inf. n. of 1</a> in the first of the senses assigned to it above: as when it is said that a reed for writing is not called a <span class="ar">قَلَم</span> except after the <span class="ar">براية</span> <span class="add">[i. e. the <em>shaping,</em> or <em>paring</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBaMCN">
				<h3 class="entry"><span class="ar">بَرَّآءٌ</span></h3>
				<div class="sense" id="barBaMCN_A1">
					<p><span class="ar">بَرَّآءٌ</span> <em>A maker of arrows, who forms,</em> or <em>fashions, them by cutting; who shapes them out,</em> or <em>pares them:</em> or <em>who does so completely:</em> <span class="auth">(Ḳ:)</span> and <em>a maker of spindles, who forms,</em> or <em>fashions, them by cutting:</em> and <em>a cutter,</em> or <em>parer, of aloes-wood, that is used for fumigation:</em> <span class="auth">(TA:)</span> <span class="add">[and in like manner,<span class="arrow"><span class="ar long">بَارِى↓ قِسِىٍ</span></span> <em>a fashioner,</em> or <em>shaper, of bows:</em> whence the saying,]</span> <span class="ar long">أَعْطِ القَوْسَ بَارِيَهَا</span> <span class="add">[<em>Give thou the bow to its fashioner</em>]</span>; meaning † <em>commit thou thine affair to him who will execute it well:</em> a prov. <span class="auth">(Ḥar p. 68. <span class="add">[See also Freytag's Arab. Prov. ii. 98.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="barBaMCapN">
				<h3 class="entry"><span class="ar">بَرَّآءَةٌ</span></h3>
				<div class="sense" id="barBaMCapN_A1">
					<p><span class="ar">بَرَّآءَةٌ</span>: <a href="#miboraApN">see <span class="ar">مِبْرَاةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baArie">
				<h3 class="entry"><span class="ar">بَارِى</span></h3>
				<div class="sense" id="baArie_A1">
					<p><span class="ar long">بَارِى قِسِىّ</span>: <a href="#barBaACN">see <span class="ar">بَرَّآءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baArieBN">
				<h3 class="entry"><span class="ar">بَارِىٌّ</span></h3>
				<div class="sense" id="baArieBN_A1">
					<p><span class="ar">بَارِىٌّ</span> and <span class="ar">بَارِيَّةٌ</span> and <span class="ar">بَارِيَآءُ</span>: <a href="index.php?data=02_b/218_bwr">see in art. <span class="ar">بور</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maborae">
				<h3 class="entry"><span class="ar">مَبْرَى</span></h3>
				<div class="sense" id="maborae_A1">
					<p><span class="ar long">مَبْرَى القَلَمِ</span> <span class="add">[<em>The place where the paring is commenced of the reed for writing</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">جلف</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboraApN">
				<h3 class="entry"><span class="ar">مِبْرَاةٌ</span></h3>
				<div class="sense" id="miboraApN_A1">
					<p><span class="ar">مِبْرَاةٌ</span> The <em>iron implement,</em> <span class="auth">(Ṣ,)</span> or <em>knife,</em> <span class="auth">(AḤn, M, Ḳ,)</span> <em>with which one forms, fashions, shapes out,</em> or <em>pares,</em> <span class="auth">(AḤn, Ṣ, M, Ḳ,)</span> <em>a bow;</em> <span class="auth">(AḤn, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَرَّآءَةٌ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> with teshdeed and medd, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">بَرَآءٌ↓</span></span>, <span class="auth">(so in a copy of the M,)</span> or<span class="arrow"><span class="ar">بَرَاةٌ↓</span></span>. <span class="auth">(CK, and so in a MṢ. copy of the Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maborieBN">
				<h3 class="entry"><span class="ar">مَبْرِىٌّ</span></h3>
				<div class="sense" id="maborieBN_A1">
					<p><span class="ar">مَبْرِىٌّ</span>: <a href="#barieBN">see <span class="ar">بَرِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabaAri">
				<h3 class="entry"><span class="ar">مُتَبَارِ</span></h3>
				<div class="sense" id="mutabaAri_A1">
					<p><span class="ar">مُتَبَارِ</span> part. n. of 6. It is said in a trad., <span class="ar long">المُتَبَارِيَانِ لَا يُجَابَانِ وَلَا يُؤْكَلُ طَعَامُهُمَا</span> <span class="add">[<em>The two</em> persons <em>who vie with each other</em> in the expensiveness of their entertainments <em>shall not have their invitations accepted, nor shall their food be eaten</em>]</span>. <span class="auth">(El-Jámiʼ eṣ-Ṣagheer of Es-Suyootee.)</span> The <span class="ar">متباريان</span> whose food is forbidden, in a trad., to be eaten, are They <em>who vie with each other in order that each may render the other unable to equal him in respect of the repast prepared by him for his guests:</em> and the doing of this is disliked because of the rivalry and ostentation that are involved in it. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برى</span> - Entry: <span class="ar">مُتَبَارِ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutabaAri_A2">
					<p><span class="ar">المُتَبَارِيَانِ</span> is also an appellation of <em>The night and the day.</em> <span class="auth">(Ḥar p. 377.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0197.pdf" target="pdf">
							<span>Lanes Lexicon Page 197</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0198.pdf" target="pdf">
							<span>Lanes Lexicon Page 198</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
