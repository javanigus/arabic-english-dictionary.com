<article class="root" id="Root_bED">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/142_bEr">بعر</a></span>
				<span class="ar">بعض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/144_bEq">بعق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bED_1">
				<h3 class="entry">1. ⇒ <span class="ar">بعض</span></h3>
				<div class="sense" id="bED_1_A1">
					<p><span class="ar long">بَعَضَهُ البَعُوضُ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَضُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَعْضٌ</span>, <em>The</em> <span class="ar">بَعُوض</span> <span class="add">[or <em>gnats,</em> or <em>musquitoes,</em>]</span> <em>bit him; and annoyed,</em> or <em>molested, him.</em> <span class="auth">(TA.)</span> And <span class="ar">بُعِضُوا</span> <em>They were bitten by the</em> <span class="ar">بَعُوض</span>: <span class="auth">(A:)</span> or <em>were annoyed,</em> or <em>molested, thereby.</em> <span class="auth">(Ḳ.)</span> <span class="ar">بَعَضَهُ</span> is not used in relation to anything but <span class="ar">بَعُوض</span>. <span class="auth">(TA.)</span> A poet says, praising a man who passed the night within a <span class="ar">كِلَّة</span> <span class="add">[or thin curtain used for protection from gnats, or musquitoes]</span>, which is also called <span class="ar long">أَبُو دِثَارٍ</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَنِعْمَ البَيْتُ بَيْتُ أَبِى دِثَارٍ</span> *</div> 
						<div class="star">* <span class="ar long">إِذَا مَا خَافَ بَعْضُ القَوْمِ بَعْضَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Excellent indeed is the tent, the tent of Aboo-Dithár, when some of the people fear biting, and annoyance,</em> or <em>molestation, from gnats,</em> or <em>musquitoes</em>]</span>: by <span class="ar">بعضا</span> meaning <span class="ar">عَضًّا</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bED_2">
				<h3 class="entry">2. ⇒ <span class="ar">بعّض</span></h3>
				<div class="sense" id="bED_2_A1">
					<p><span class="ar">بعضهُ</span>, inf. n. <span class="ar">تَبْعِيضٌ</span>, <em>He divided it into parts,</em> or <em>portions,</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> <em>distinct,</em> or <em>separate, one from another.</em> <span class="auth">(Mṣb)</span> You say, <span class="ar long">أَخَذُوا مَالَهُ فَبَعَّضُوهُ</span> <em>They took his property and divided it into parts,</em> or <em>portions.</em> <span class="auth">(A, TA.)</span> And <span class="ar long">عَضَّى الشَّاةَ وَبَعَّضَهَا</span> <span class="add">[<em>He limbed,</em> or <em>dismembered, the sheep,</em> or <em>goat, and divided it into parts,</em> or <em>portions</em>]</span>. <span class="auth">(A, TA.)</span> <span class="add">[Hence,]</span> <span class="ar">مِنْ</span> in certain cases, and <span class="ar">بِ</span> in the like cases, as in the saying <span class="ar long">شَرِبْتُ بِمَآءِ كَذَا</span> <span class="add">[“I drank of,” i. e. “some of, such water”]</span>, are said to be <span class="ar">لِلتَّبْعِيضِ</span> <span class="add">[<em>For the purpose of dividing into parts,</em> or <em>portions</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bED_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابعض</span></h3>
				<div class="sense" id="bED_4_A1">
					<p><span class="ar">ابعضوا</span> <em>They had</em> <span class="ar">بَعُوض</span> <span class="add">[or <em>gnats,</em> or <em>musquitoes</em>]</span>, <span class="auth">(Ḳ,)</span> or <em>abundance thereof,</em> <span class="auth">(A,)</span> <em>in their land.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bED_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبعّض</span></h3>
				<div class="sense" id="bED_5_A1">
					<p><span class="ar">تبعّض</span> <em>It was,</em> or <em>became, divided into parts,</em> or <em>portions.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEoDN">
				<h3 class="entry"><span class="ar">بَعْضٌ</span></h3>
				<div class="sense" id="baEoDN_A1">
					<p><span class="ar">بَعْضٌ</span> <em>Some,</em> or <em>somewhat</em> or <em>some one,</em> <span class="auth">(lit. <em>a thing,</em>)</span> of things, or of a thing: Th says that it signifies thus accord. to all the grammarians; <span class="auth">(Mṣb, TA;)</span> except Hishám, as will be seen hereafter: <span class="auth">(TA:)</span> or <em>a part,</em> or <em>portion,</em> <span class="auth">(A, Mṣb, Ḳ,)</span> of a thing, <span class="auth">(Mṣb,)</span> or of anything; <span class="auth">(A, Ḳ;)</span> whether little or much: <span class="auth">(TA:)</span> accord. to both these explanations, it may denote the greater part; as eight of ten: <span class="auth">(Mṣb:)</span> <span class="add">[thus it signifies <em>some one</em> or <em>more;</em> and it relates to persons and to other things:]</span> pl. <span class="ar">أَبْعَاضٌ</span>; <span class="auth">(Ṣ, IJ, Ḳ;)</span> but ISd doubts whether IJ had an authority for this. <span class="auth">(TA.)</span> You say, <span class="ar long">بَعْضُ الشَّرِّ أَهْوَنُ مِنْ بَعْضٍ</span> <span class="add">[<em>Some kinds of evil are easier to be borne than some</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">جَارِيَةٌ حُسَّانَةٌ يُشْبِهُ بَعْضُهَا بَعْضًا</span> <span class="add">[<em>A very beautiful girl, parts of whom resemble other parts</em>]</span>. <span class="auth">(A.)</span> <span class="add">[And <span class="ar long">ضَرَبَ بَعْضُهُمْ بَعْضًا</span> <em>Some of them beat some;</em> i. e. <em>they beat one another.</em>]</span> And <span class="ar long">لَبِثْنَا يَوْمًا أَوْ بَعْضَ يَوْمٍ</span> <span class="add">[<em>We have tarried a day or part of a day</em>]</span>. <span class="auth">(Ḳur xviii. 18.)</span> And one says to a man of a company of men, “Who did this?” and he answers, <span class="ar">أَحَدُنَا</span> or <span class="ar">بَعْضُنَا</span> <span class="add">[<em>Some one of us</em>]</span>; meaning himself. <span class="auth">(A.)</span> The article <span class="ar">ال</span> should not be prefixed to it, <span class="auth">(Ḳ,* TA,)</span> because it is originally a prefixed n., and as such determinate either literally or virtually, so that it does not admit another cause of being determinate; <span class="auth">(TA;)</span> contr. to what is said by IDrst <span class="auth">(Ḳ, TA)</span> and Ez-Zejjájee; for they said <span class="ar">البَعْضُ</span> and <span class="ar">الكُلُّ</span>; which, properly, as ISd says, is not allowable; and it is said in the O that IDrst, in this matter, was at variance with all the people of his age: <span class="auth">(TA:)</span> AḤát says that the Arabs did not say <span class="ar">الكُلُّ</span> nor <span class="ar">البَعْضُ</span>, but that people used these expressions, even Sb and Akh in their two books, by reason of their little knowledge in this way: <span class="auth">(Ḳ,* TA:)</span> a remark, says MF, which is extr., and needs no comment: <span class="auth">(TA:)</span> <span class="add">[for who surpassed Sb and Akh in knowledge respecting matters of this kind?]</span> AḤát also relates his having told Aṣ that he had seen in the book of <span class="add">[that celebrated and chaste author]</span> Ibn-El-Mukaffa', <span class="ar long">العِلْمُ الكَثِيرٌ وَلٰكِنَّ أَخْذَ البَعْضِ خَيْرٌ مِنْ تَرْكِ الكُلِّ</span> <span class="add">[<em>Science is large; but the acquiring of part is better than the neglecting of the whole</em>]</span>; and that Aṣ disapproved of it most strongly, saying that the article <span class="ar">ال</span> is not prefixed to <span class="ar">بَعْضٌ</span> and <span class="ar">كُلٌّ</span> because they are determinate without it: <span class="auth">(TA:)</span> Az, however, says that the grammarians allow its being prefixed to these two words, <span class="auth">(Mṣb, TA,)</span> though Aṣ disallows it, <span class="auth">(TA,)</span> because they are meant to be understood as prefixed ns.; <span class="auth">(Mṣb;)</span> or because the article is meant to be a substitute for the noun to which they should be prefixed; or, in the case of <span class="ar">بَعْضٌ</span>, because this word is equivalent to <span class="ar">جُزْءٌ</span>, which receives the article <span class="ar">ال</span>. <span class="auth">(MF.)</span> It is related of AO, that he assigned also to <span class="ar">بَعْضٌ</span> the contr. meaning of <em>All;</em> or the <em>whole:</em> adducing as a proof thereof the words of the Ḳur <span class="add">[xl. 29]</span>, <span class="ar long">يُصِبْكُمْ بَعْضُ ٱلَّذِى يَعِدُكُمْ</span> as meaning <em>All of that with which he threateneth you will befall you:</em> and the saying of Lebeed.</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَوْ يَعْتَلِقْ بَعْضَ النُّفُوسِ حِمَامُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[as meaning <em>Or their death shall cling to all living creatures:</em> or, accord. to another relation, <span class="ar long">او يَرْتَبِطْ</span>, which means the same as <span class="ar long">او يعتلق</span>]</span>: thus also AHeyth explains the above-cited verse of the Ḳur; and thus Hishám explains the saying of Lebeed, erroneously asserting that <span class="ar">بعض</span> is here a pl.: <span class="auth">(TA:)</span> but with respect to the former instance, the Prophet had threatened them with two things, the punishment of the present world and that of the world to come; so he says, “This punishment will befall you in the present world;” which is part (<span class="ar">بعض</span>) of the two threats; without denying the punishment of the world to come: or, as Aboo-Is-ḥáḳ says, he mentions the part to indicate the necessary consequence of the whole: and as to the saying of Lebeed, by <span class="ar long">بعض النفوس</span> he means himself. <span class="auth">(TA <span class="add">[app. from ISd]</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEiDapN">
				<h3 class="entry"><span class="ar">بَعِضَةٌ</span></h3>
				<div class="sense" id="baEiDapN_A1">
					<p><span class="ar long">أَرْضٌ بَعِضَةٌ</span> <em>A land abounding with</em> <span class="ar">بَعُوض</span> <span class="add">[or <em>gnats,</em> or <em>musquitoes</em>]</span>; <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">مَبْعَضَةٌ↓</span></span>, like as you say <span class="ar">مَبَقَّةٌ</span>. <span class="auth">(TA.)</span> And <span class="ar long">لَيْلَةٌ بَعِضَةٌ</span> <em>A night in which are many</em> <span class="ar">بَعُوض</span>; as also<span class="arrow"><span class="ar">مَبْعُوضَةٌ↓</span></span> <span class="auth">(A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEuwDN">
				<h3 class="entry"><span class="ar">بَعُوضٌ</span> / <span class="ar">بَعُوضَةٌ</span></h3>
				<div class="sense" id="baEuwDN_A1">
					<p><span class="ar">بَعُوضٌ</span> <span class="add">[<em>Gnats,</em> or <em>musquitoes;</em>]</span> <em>i. q.</em> <span class="ar">بَقَّ</span> <span class="add">[which signifies both gnats, or musquitoes, <span class="auth">(called in Egypt <span class="ar">نَامُوس</span>,)</span> and also bugs]</span>: n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَعُوضَةٌ</span>}</span></add>: <span class="auth">(Ṣ:)</span> <a href="#baEuwDapN">or pl. of <span class="ar">بَعُوضَةٌ</span></a>, <span class="auth">(Ḳ,)</span> which signifies <em>i. q.</em> <span class="ar">بَقَّةٌ</span>. <span class="auth">(A, Ḳ.)</span> A poet speaks of the humming of the <span class="ar">بعوض</span> of the water. <span class="auth">(TA.)</span> The author of the Ḳ says, in the B, that the word is taken from <span class="ar">بَعْضٌ</span>, because of the smallness of the body of the <span class="ar">بعوضة</span> in comparison with other living things. <span class="auth">(TA.)</span> You say, <span class="ar long">كَلَّفَنِى مُخَّ البَعُوضِ</span> ‡ <em>He imposed upon me a difficult thing:</em> <span class="auth">(A:)</span> or <em>an impossible thing.</em> <span class="auth">(TṢ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboEaDapN">
				<h3 class="entry"><span class="ar">مَبْعَضَةٌ</span></h3>
				<div class="sense" id="maboEaDapN_A1">
					<p><span class="ar">مَبْعَضَةٌ</span>: <a href="#baEiDapN">see <span class="ar">بَعِضَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboEuwDapN">
				<h3 class="entry"><span class="ar">مَبْعُوضَةٌ</span></h3>
				<div class="sense" id="maboEuwDapN_A1">
					<p><span class="ar long">لَيْلَةٌ مَبْعُوضَةٌ</span>: <a href="#baEiDapN">see <span class="ar">بَعِضَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0227.pdf" target="pdf">
							<span>Lanes Lexicon Page 227</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
