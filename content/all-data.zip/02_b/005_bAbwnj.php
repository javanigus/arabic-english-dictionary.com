<article class="root" id="Root_bAbwnj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/004_bAbl">بابل</a></span>
				<span class="ar">بابونج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/006_bOj">بأج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baAbuwnajN">
				<h3 class="entry"><span class="ar">بَابُونَجٌ</span></h3>
				<div class="sense" id="baAbuwnajN_A1">
					<p><span class="ar">بَابُونَجٌ</span> <span class="add">[from the Persian <span class="ar">بَابُونَهْ</span> <em>Chamomile;</em> or <em>chamomile-flowers:</em> both called by these names in the present day]</span>: <em>a certain herb, of several different colours; yellow-flowered,</em> and <em>whiteflowered,</em> and <em>purple-flowered:</em> <span class="auth">(Avicenna <span class="add">[Ibn-Seenà]</span> i. 139:)</span> <em>i. q.</em> <span class="ar">أُقْحُوَانٌ</span>: <span class="auth">(Ṣ, Mṣb, Ḳ, all in art <span class="ar">قحو</span>:)</span> i. e. the <span class="ar">اقحوان</span> is the <span class="ar">بابونج</span> with the Persians: <span class="auth">(Mṣb in that art.:)</span> or the <em>flower of the</em> <span class="ar">اقحوان</span>: <span class="auth">(Ṣ in art. <span class="ar">قرص</span>:)</span> or <em>of the yellow</em> <span class="ar">اقحوان</span>, <span class="auth">(TA in art. <span class="ar">قرص</span>,)</span> <em>when it has become dry:</em> <span class="auth">(Ṣ, TA, both in art. <span class="ar">قرص</span>:)</span> <em>a well-known flower, of great utility,</em> <span class="auth">(Ḳ, TA,)</span> or <em>of which the oil is of great utility:</em> <span class="auth">(CK:)</span> <em>commonly known in El-Yemen by the name of</em> <span class="ar">مونس</span> <span class="add">[app. <span class="ar">مُؤْنِسٌ</span>, because of its pleasant odour, or its medical properties]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
