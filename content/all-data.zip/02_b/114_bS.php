<article class="root" id="Root_bS">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/113_bXnyn">بشنين</a></span>
				<span class="ar">بص</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/115_bSr">بصر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bS_1">
				<h3 class="entry">1. ⇒ <span class="ar">بصّ</span></h3>
				<div class="sense" id="bS_1_A1">
					<p><span class="ar">بَصَّ</span>, aor. <span class="ar">يَبِصُّ</span>, inf. n. <span class="ar">بَصِيصٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and <span class="ar">بَصٌّ</span>, <span class="auth">(TA,)</span> <em>It</em> <span class="auth">(a thing, Ṣ, as, for instance, a grain of a pomegranate, TA)</span> <em>shone,</em> or <em>glistened.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بص</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bS_1_A2">
					<p><span class="ar long">هُوَ يَبُصُّ لِى</span>, <span class="add">[<em>He looks at me</em>]</span> is an expression used by the vulgar <span class="add">[in the present day]</span>, and is from <span class="ar">البَصَّاصَةُ</span> signifying “the eye.” <span class="auth">(TA.)</span> <span class="add">[By rule it should be <span class="ar">يَبِصُّ</span>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bS_2">
				<span class="pb" id="Page_0210"></span>
				<h3 class="entry">2. ⇒ <span class="ar">بصّص</span></h3>
				<div class="sense" id="bS_2_A1">
					<p><span class="ar long">بصّص بِسَيْفِهِ</span> <em>He made a sign with his sword, waving it,</em> or <em>moving it about</em> <span class="add">[<em>so that it shone,</em> or <em>glistened</em>]</span> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bS_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بصبص</span></h3>
				<div class="sense" id="bS_RQ1_A1">
					<p><span class="ar">بَصْبَصَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">بَصْبَصَ بِذَنَبِهِ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">بَصْبَصَةٌ</span>, <span class="auth">(TA,)</span> <em>He</em> <span class="auth">(a dog, Ṣ, M, Ḳ, and a beast of prey, and a gazelle, and a camel when urged on by the driver's singing, TA)</span> <em>wagged,</em> or <em>moved about, his tail;</em> <span class="auth">(Ṣ, Ḳ;)</span> which a dog does by reason of cupidity, or fear; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">تَبَصْبَصَ↓</span></span>: <span class="auth">(Ṣ:)</span> or <em>he</em> <span class="auth">(a dog)</span> <em>struck with his tail.</em> <span class="auth">(ISd.)</span> The inf. n. <span class="ar">بَصْبَصَةٌ</span> has a pl., namely, <span class="ar">بَصَابِصُ</span>; as in the following ex.:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حَتَّى إِذَا أَبْصَرْنَهُ وَعَلِمْنَهُ</span> *</div> 
						<div class="star">* <span class="ar long">حَيَّيْنَهُ بِبَصَابِصِ الأَذْنَابِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Until, when they see him and know him, they greet him with waggings of the tails</em>]</span>. <span class="auth">(TA.)</span> It is said in a prov., respecting the flight and submissiveness of the coward,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَصْبَصْنَ إِذْ حُدِيْنَ بِالأَذْنَابِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They wagged the tails when they were urged on by the driver's singing</em>]</span>. <span class="auth">(Aṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بص</span> - Entry: R. Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bS_RQ1_B1">
					<p><span class="ar long">بَصْبَصَتِ الإِبِلُ قَرَبَهَا</span> <em>The camels performed quickly their nightjourney to water.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#baSobaASN">See <span class="ar">بَصْبَاصٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bS_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تبصبص</span></h3>
				<div class="sense" id="bS_RQ2_A1">
					<p><span class="ar">تَبَصْبَصَ</span>: <a href="#bS_RQ1">see R. Q. 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSBN">
				<h3 class="entry"><span class="add">[<span class="ar">بَصٌّ</span> / <span class="ar">بَصَّةٌ</span>]</span></h3>
				<div class="sense" id="baSBN_A1">
					<p><span class="add">[<span class="ar">بَصٌّ</span>, and <span class="ar long">بَصُّ نَارٍ</span>, <em>Live coals;</em> because they shine, or glisten: n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَصَّةٌ</span>}</span></add>: so in the present day; but probably only post-classical: or, accord. to the TA, in art. <span class="ar">بصو</span>, the word <span class="ar">بَصَّةٌ</span> is used by the vulgar, for <span class="ar">بَصْوَةٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSBaASN">
				<h3 class="entry"><span class="ar">بَصَّاصٌ</span></h3>
				<div class="sense" id="baSBaASN_A1">
					<p><span class="ar">بَصَّاصٌ</span> <span class="add">[<em>Shining,</em> or <em>glistening:</em> or rather, <em>shining,</em> or <em>glistening, much</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بص</span> - Entry: <span class="ar">بَصَّاصٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baSBaASN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">البَصَّاصَةُ</span> <em>The eye:</em> <span class="auth">(Ṣ A, Ḳ:)</span> an epithet in which the quality of a subst. predominates: <span class="auth">(TA:)</span> said to be so called <span class="auth">(TA)</span> because it shines, or glistens. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بص</span> - Entry: <span class="ar">بَصَّاصٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baSBaASN_A3">
					<p><span class="add">[And hence <span class="ar">بَصَّاصٌ</span> is applied in the present day to <em>An officer employed as an inspector by a police-magistrate.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buSBaAnN">
				<h3 class="entry"><span class="ar">بُصَّانٌ</span></h3>
				<div class="sense" id="buSBaAnN_A1">
					<p><span class="ar">بُصَّانٌ</span> a name of <span class="add">[<em>The month afterwards called</em>]</span> <span class="ar long">رَبِيعٌ الآخِرُ</span>: the former was its name in the Time of Ignorance: thus it is written accord. to the Jm: <span class="add">[or it was called, or was also called, <span class="ar">وَبْصَانُ</span>, and <span class="ar">وُبْصَانِ</span>: (<a href="index.php?data=27_w/015_wbS">see art. <span class="ar">وبص</span></a>:) or <span class="ar">وَبُصَانٌ</span>, and <span class="ar">وَبِصَانٌ</span>: (<a href="index.php?data=02_b/121_bSn">see art. <span class="ar">بصن</span></a>:)]</span> the author of the Ḳ mentions it in art.<span class="ar">بصن</span>; <span class="add">[where it is said to be also written <span class="ar">بُصَانٌ</span>, i. e., without teshdeed;]</span> but this is its proper place, for it is from <span class="ar">البَصِيصُ</span> <span class="add">[<a href="#bS_1">inf. n. of <span class="ar">بَصَّ</span></a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSobaASN">
				<h3 class="entry"><span class="ar">بَصْبَاصٌ</span></h3>
				<div class="sense" id="baSobaASN_A1">
					<p><span class="ar long">قَرَبٌ بَصْبَاصٌ</span>, <span class="auth">(T, Ḳ,)</span> or <span class="ar long">خِمْسٌ بَصْبَاصٌ</span>, <span class="auth">(Ṣ,)</span> <em>A laborious,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> <em>fatiguing,</em> <span class="auth">(T,)</span> <em>nightjourney to water,</em> <span class="auth">(T, Ḳ,)</span> or <em>journey in which the second and third and fourth days are without water; in which is no flagging:</em> <span class="auth">(Ṣ:)</span> <span class="add">[as also <span class="ar">صَبْصَابٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بص</span> - Entry: <span class="ar">بَصْبَاصٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baSobaASN_A2">
					<p><span class="ar long">يَوْمٌ بَصْبَاصٌ</span> <em>A vehemently-hot day.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0209.pdf" target="pdf">
							<span>Lanes Lexicon Page 209</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0210.pdf" target="pdf">
							<span>Lanes Lexicon Page 210</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
