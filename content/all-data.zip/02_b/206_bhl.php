<article class="root" id="Root_bhl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/205_bhq">بهق</a></span>
				<span class="ar">بهل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/207_bhm">بهم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهل</span></h3>
				<div class="sense" id="bhl_1_A1">
					<p><span class="ar long">بَهَلَ النَّاقَةَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَلُ</span>}</span></add>, inf. n. <span class="ar">بَهْلٌ</span>,]</span> <em>He left the she-camel without a</em> <span class="ar">صِرَار</span> <span class="add">[<em>bound upon her udder to prevent her being sucked</em>]</span>; <span class="auth">(Bḍ in iii. 54;)</span> as also<span class="arrow"><span class="ar">ابلها↓</span></span>: <span class="auth">(Ṣ:)</span> or <em>he left her to be milked;</em> or <em>allowed her being milked:</em> <span class="auth">(Z, TA:)</span> and<span class="arrow">↓</span> the latter, <em>he loosed her</em> <span class="ar">صِرَار</span>, <em>and left her young one at liberty to such her;</em> <span class="auth">(Ḳ;)</span> and <em>he left her to herself</em> <span class="auth">(Ḳ, TA)</span> <em>to be milked by any one who pleased.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhl_1_A2">
					<p>And <span class="ar">بَهَلَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> <span class="add">[inf. n. <span class="ar">بَهْلٌ</span>,]</span> <em>He left him</em> <span class="auth">(Ṣ, Ḳ)</span> <em>to his own will,</em> or <em>wish,</em> <span class="auth">(Ṣ,)</span> or <em>to his own opinion,</em> or <em>judgment;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">ابهلهُ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> or the former is said in relation to the free man; and<span class="arrow">↓</span> the latter, in relation to the slave; <span class="auth">(Zj, Ḳ;)</span> and signifies also <span class="add">[simply]</span> <em>he left him to himself.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bhl_1_A3">
					<p>Hence, <span class="auth">(TA,)</span> <span class="ar">بَهْلٌ</span> signifies <span class="add">[also]</span> The <em>act of cursing.</em> <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> You say, <span class="ar">بَهَلَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَلُ</span>}</span></add>, inf. n. <span class="ar">بَهْلٌ</span>, <em>He cursed him.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">بَهَلَ ٱللّٰهُ فُلَانًا</span> <em>May God curse such a one!</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bhl_1_B1">
					<p><span class="ar">بَهِلَتْ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَلُ</span>}</span></add>, inf. n. <span class="ar">بَهَلٌ</span>, <em>She</em> <span class="auth">(a camel)</span> <em>had her</em> <span class="ar">صِرَار</span> <em>loosed, and her young one left to suck her.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhl_3">
				<h3 class="entry">3. ⇒ <span class="ar">باهل</span></h3>
				<div class="sense" id="bhl_3_A1">
					<p><span class="ar">مُبَاهَلَةٌ</span> The <em>act of cursing each other:</em> <span class="auth">(Ṣ, Mgh, Mṣb:)</span> inf. n. of <span class="ar">باهلهُ</span> <em>He cursed him, being cursed by him:</em> <span class="auth">(Mṣb:)</span> <span class="add">[or rather]</span> <span class="ar">بَاهَلْتُهُ</span> signifies <em>I joined with him in imprecating the curse of God upon whichever of us did wrong.</em> <span class="auth">(JK.)</span> Hence the saying of Ibn-Mesʼood, <span class="ar long">مَنْ شَآءَ بَاهَلْتُهُ أَنَّ سُورَةَ القُصْرَى نَزَلَتْ بَعْدَ البَقَرَةِ</span> <span class="add">[<em>Whosoever will, I will contend with him by imprecating the curse of God upon whichever of us is wrong, that the shorter chapter of “Women” came down</em> from heaven <em>after</em> the chapter of “<em>The Cow”</em>]</span>: or, accord. to one recital, he said <span class="ar long">لَا عَنْتُهُ</span>: for when they differed respecting a thing, they used to come together, and say,<span class="arrow"><span class="ar long">بَهْلَةُ↓ ٱللّٰهِ عَلَى الظَّالِمِ مِنَّا</span></span> <span class="add">[<em>The curse of God be upon such of us as is the wrongdoer!</em>]</span>. <span class="auth">(Mgh.)</span> <span class="ar long">باهل بَعْضُهُمْ بَعْضًا</span> and<span class="arrow"><span class="ar">تبّهلوا↓</span></span> and<span class="arrow"><span class="ar">تباهلوا↓</span></span> all signify <em>They cursed one another:</em> <span class="auth">(Ḳ:)</span> <span class="add">[or]</span> <em>they joined in imprecating a curse upon such of them as was the wrongdoer:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">ابتهلوا↓</span></span> signifies the like: whence, <span class="ar long">ثُمَّ نَبْتَهِلْ</span>, in the Ḳur <span class="add">[iii. 54]</span>, <span class="auth">(Bḍ, TA,)</span> as some explain it, <span class="auth">(TA,)</span> meaning<span class="arrow"><span class="ar long">ثُمَّ نَتَبَاهَلْ↓</span></span>, i. e., <em>Then let us imprecate a curse upon such of us as is the liar.</em> <span class="auth">(Bḍ. <span class="add">[<a href="#bhl_8">But see also 8 below</a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابهل</span></h3>
				<div class="sense" id="bhl_4_A1">
					<p><a href="#bhl_1">see 1</a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhl_4_A2">
					<p><span class="add">[The inf. n.]</span> <span class="ar">إِبْهَالٌ</span> also signifies The <em>sending forth,</em> or <em>letting flow, the water upon what has been sown,</em> <span class="auth">(JK, Ḳ, TA,)</span> <em>after having finished the sowing.</em> <span class="auth">(JK, TA. <span class="add">[In the CK, <span class="ar">نَذَرْتَهُ</span> is erroneously put for <span class="ar">بَذَرْتَهُ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبهّل</span></h3>
				<div class="sense" id="bhl_5_A1">
					<p><a href="#bhl_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhl_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباهل</span></h3>
				<div class="sense" id="bhl_6_A1">
					<p><a href="#bhl_3">see 3</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتهل</span></h3>
				<div class="sense" id="bhl_8_A1">
					<p><a href="#bhl_3">see 3</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhl_8_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">ابتهل</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> or <span class="ar long">ابتهل فِى الدَّعَآءِ</span>, <span class="auth">(JK,)</span> ‡ <em>He humbled,</em> or <em>abased, himself;</em> or <em>addressed himself with earnest,</em> or <em>energetic, supplication;</em> syn. <span class="ar">تَضَرَّعَ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <span class="ar long">إِلَى ٱللّٰهِ</span> <em>to God:</em> <span class="auth">(Mṣb:)</span> <em>he strove,</em> or <em>was earnest,</em> or <em>energetic, in prayer,</em> or <em>supplication;</em> <span class="auth">(JK, Ḳ;)</span> <em>and was sincere,</em> or <em>without hypocrisy, therein;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>with a striving,</em> or <em>an earnestness,</em> or <em>energy, like that of the</em> <span class="ar">مُبْتَهِلُونَ</span> <span class="add">[properly so called, i. e., <em>persons who join in imprecating a curse upon such of them as is the wrongdoer</em>]</span>. <span class="auth">(TA.)</span> It is said that <span class="ar long">ثُمَّ نَبْتَهِلْ</span>, in the Ḳur <span class="add">[iii. 54, of which one explanation has been given above, (<a href="#bhl_3">see 3</a>,)]</span> means ‡ <em>Then let us be sincere,</em> or <em>without hypocrisy, in prayer,</em> or <em>supplication;</em> <span class="auth">(Ṣ, TA;)</span> <em>and let us strive,</em> or <em>be earnest,</em> or <em>energetic:</em> <span class="auth">(TA:)</span> or <em>let us humble,</em> or <em>abase, ourselves;, &amp;c.;</em> syn. <span class="ar">نَتَضَرَّعْ</span>. <span class="auth">(Jel.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bhl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبهل</span></h3>
				<div class="sense" id="bhl_10_A1">
					<p><span class="ar">استبلها</span> <em>He milked her</em> <span class="auth">(namely, a camel,)</span> <em>without a</em> <span class="ar">صِرَار</span>. <span class="auth">(Ḳ. <span class="add">[<a href="#bhl_1">See 1</a>, first sentence.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhl_10_A2">
					<p><em>He</em> <span class="auth">(a young camel)</span> <em>pulled off her</em> <span class="ar">أَصِرَّة</span> <span class="add">[<a href="#SiraAr">pl. of <span class="ar">صِرَار</span></a>]</span> <em>to suck her,</em> namely, his mother. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bhl_10_A3">
					<p><span class="ar long">استبهل الرَّعيَّةَ</span> <em>He</em> <span class="auth">(the ruler)</span> <em>left the people,</em> or <em>subject, to themselves,</em> <span class="auth">(Lḥ, Ḳ,)</span> <em>to do what they would; not restraining them.</em> <span class="auth">(Lḥ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bhl_10_A4">
					<p><span class="ar long">اِسْتَبْهَلَتْهَا السَّوَاحِلُ</span> <span class="auth">(Ṣ)</span> and <span class="ar long">استبلتهم البَادِيَةُ</span> <span class="auth">(Ḳ)</span> † <em>The shores, and the desert, left them at liberty in their abodes therein, no Sultán reaching them, so that they did what they pleased.</em> <span class="auth">(Ṣ,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baholapN">
				<h3 class="entry"><span class="ar">بَهْلَةٌ</span></h3>
				<div class="sense" id="baholapN_A1">
					<p><span class="ar">بَهْلَةٌ</span> <span class="auth">(Ṣ, Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">بُهْلَةٌ↓</span></span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>A curse:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> from <span class="ar long">بَهَلَ النَّاقَةَ</span> in the sense first explained above. <span class="auth">(Bḍ in iii. 54.)</span> You say, <span class="ar long">عَلَيْهِ بَهْلَةُ ٱللّٰهِ</span> and<span class="arrow"><span class="ar">بُهْلَتُهُ↓</span></span> <em>The curse of God be on him!</em> <span class="auth">(Ṣ.)</span> For another ex., <a href="#bhl_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buholapN">
				<h3 class="entry"><span class="ar">بُهْلَةٌ</span></h3>
				<div class="sense" id="buholapN_A1">
					<p><span class="ar">بُهْلَةٌ</span>: <a href="#baholapN">see what next precedes</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baholalapN">
				<h3 class="entry"><span class="ar">بَهْلَلَةٌ</span></h3>
				<div class="sense" id="baholalapN_A1">
					<p><span class="ar">بَهْلَلَةٌ</span> The <em>quality of shrinking from foul things, and of generosity,</em> or <em>nobleness.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buholuwlN">
				<h3 class="entry"><span class="ar">بُهْلُولٌ</span></h3>
				<div class="sense" id="buholuwlN_A1">
					<p><span class="ar">بُهْلُولٌ</span> One <em>that shrinks from foul things, and is generous,</em> or <em>noble;</em> applied to a man <span class="auth">(Ibn-ʼAbbád, JK)</span> and to a woman: <span class="auth">(JK:)</span> pl. <span class="ar">بَهَالِيلُ</span>. <span class="auth">(Ibn-ʼAbbád, JK.)</span> <em>A lord, chief,</em> or <em>prince, combining all good qualities.</em> <span class="auth">(Seer, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بُهْلُولٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buholuwlN_A2">
					<p><em>A great,</em> or <em>frequent, laugher.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAhilN">
				<h3 class="entry"><span class="ar">بَاهِلٌ</span></h3>
				<div class="sense" id="baAhilN_A1">
					<p><span class="ar">بَاهِلٌ</span> A she-camel <em>having no</em> <span class="ar">صِرَار</span> <em>upon her,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>so that any one who will may milk her:</em> <span class="auth">(TA:)</span> or one <em>having no nose-rein upon her,</em> <span class="auth">(Ḳ, TA,)</span> <em>so that she pastures where she will:</em> <span class="auth">(TA:)</span> or also one <em>having no</em> <span class="ar">عِرَان</span> <span class="add">[which is a <em>piece of wood inserted in the partition between the nostrils</em>]</span>: <span class="auth">(Ṣ:)</span> and <span class="auth">(so in the Ṣ, but in the Ḳ “or”)</span> one <em>having no mark,</em> or <em>brand, upon her:</em> <span class="auth">(JK, Ṣ, Ḳ:)</span> pl. <span class="ar">بُهَّلٌ</span> <span class="auth">(JK, Ṣ, Ḳ)</span> and <span class="ar">بُهُلٌ</span>: <span class="auth">(JK, Ḳ, TA: <span class="add">[the latter in the CK like <span class="ar">بُرْدٌ</span>:]</span>)</span> and<span class="arrow"><span class="ar">مُبْهَلَةٌ↓</span></span> signifies <em>left in the state of her that is termed</em> <span class="ar">بَاهِل</span>, <span class="auth">(Ṣ,)</span> or <em>having her</em> <span class="ar">صِرَار</span> <em>loosed, and her young one left at liberty to suck her:</em> <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar">مَبَاهِلُ↓</span></span> is applied in the same sense <span class="add">[as its pl.]</span>. <span class="auth">(Ṣ, Ḳ. <span class="add">[In the CK the latter is written <span class="ar">مُبَاهِلٌ</span>, as a sing.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بَاهِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAhilN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">أَتَيْتُكَ بَاهِلًا غَيْرَ ذَاتِ صِرَارٍ</span>, said by an Arab woman to her husband; <span class="auth">(Ṣ;)</span> by the wife of Dureyd Ibn-Eṣ-Ṣimmeh, to him, on his desiring to divorce her; meaning † <em>I made my property lawful to thee.</em> <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0268"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بَاهِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAhilN_A3">
					<p><span class="ar">بَاهِلُونَ</span> † <em>People at liberty in their place of abode, no Sultán reaching them, so that they do what they please.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بَاهِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAhilN_A4">
					<p>And the sing., ‡ <em>Going to and fro without work.</em> <span class="auth">(Ibn-ʼAbbád, Z, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بَاهِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAhilN_A5">
					<p>‡ A pastor <em>without a staff:</em> <span class="auth">(JK, Ḳ:)</span> or, <em>walking without a staff.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بَاهِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAhilN_A6">
					<p>† A man <em>without a weapon.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهل</span> - Entry: <span class="ar">بَاهِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baAhilN_A7">
					<p>And <span class="ar">بَاهِلَةٌ</span> † A woman <em>having no husband;</em> <span class="auth">(JK;)</span> syn. <span class="ar">أَيِّمٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabohalN">
				<h3 class="entry"><span class="ar">أَبْهَلٌ</span></h3>
				<div class="sense" id="OabohalN_A1">
					<p><span class="ar">أَبْهَلٌ</span> The <em>produce,</em> or <em>fruit, of a certain tree, which is the</em> <span class="ar">عَرْعَر</span> <span class="add">[a name applied to the <em>cypress</em> and to the <em>juniper-tree</em>]</span>: <span class="auth">(Ṣ:)</span> so says Ibn-Seenà <span class="add">[Avicenna]</span> in the Kánoon; and he adds that <em>it is of two species, small and great, both brought from the country of the</em> <span class="ar">رُوم</span>: <em>one species of the tree thereof has leaves like those of the</em> <span class="ar">سَرْو</span> <span class="add">[<em>or common, evergreen, cypress</em>]</span>, <em>has many thorns, and grows, or spreads, wide,</em> (<span class="ar">يَسْتَعْرِضُ</span>,) <em>not growing tall: the leaves of the other are like those of the</em> <span class="ar">طَرْفَآء</span> <span class="add">[or <em>tamarisk</em>]</span>, <em>the taste thereof is like</em> <span class="add">[<em>that of</em>]</span> <em>the</em> <span class="ar">سَرْو</span>, <em>and it is drier, and less hot:</em> <span class="auth">(TA:)</span> or it is the <em>produce of a kind of great tree, the leaves of which are like</em> <span class="add">[<em>those of</em>]</span> the <span class="ar">طرفاء</span>, and the fruit of which is like the <span class="ar">نَبِق</span> <span class="add">[or <em>fruit of the lote-tree called</em> <span class="ar">سِدْر</span>]</span>; and it is not <span class="add">[<em>the fruit of</em>]</span> <em>the</em> <span class="ar">عرعر</span>, <em>as J imagined it to be: the smoke thereof expels quickly the young in the womb: used as a liniment, with vinegar, it cures what is termed</em> <span class="ar long">دَآء الثَّعْلَب</span> <span class="add">[<em>alopecia</em>]</span>: <em>and with honey, it cleanses foul ulcers.</em> <span class="auth">(Ḳ.)</span> <span class="add">[In the present day, it is applied to the <em>juniper-tree;</em> as is also <span class="ar">عَرْعَر</span>; and particularly to the species thereof called the <em>savin.</em> <a href="#qaTiraAnN">See <span class="ar">قَطِرَانٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubohalapN">
				<h3 class="entry"><span class="ar">مُبْهَلَةٌ</span> / <span class="ar">مَبَاهِلُ</span></h3>
				<div class="sense" id="mubohalapN_A1">
					<p><span class="ar">مُبْهَلَةٌ</span> and <span class="ar">مَبَاهِلُ</span> <span class="add">[its pl.]</span>: <a href="#baAhilN">see <span class="ar">بَاهِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0267.pdf" target="pdf">
							<span>Lanes Lexicon Page 267</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0268.pdf" target="pdf">
							<span>Lanes Lexicon Page 268</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
