<article class="root" id="Root_bqX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/156_bqs">بقس</a></span>
				<span class="ar">بقش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/158_bqE">بقع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baqoXN">
				<h3 class="entry"><span class="ar">بَقْشٌ</span></h3>
				<div class="sense" id="baqoXN_A1">
					<p><span class="ar">بَقْشٌ</span> <em>A certain kind of tree, called in Persian</em> <span class="fa long">خُوشْ سَاىْ</span>, <span class="auth">(Ṣgh, Ḳ,)</span> which means “good in shade;” <span class="add">[and also is applied to the <em>box-tree;</em>]</span> as has been said before, voce <span class="ar">بَقْسٌ</span>, which may be the same: IDrd says that <span class="ar">بَقْشٌ</span> is a post-classical word. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0235.pdf" target="pdf">
							<span>Lanes Lexicon Page 235</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
