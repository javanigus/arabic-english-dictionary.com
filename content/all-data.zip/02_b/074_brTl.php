<article class="root" id="Root_brTl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/073_brS">برص</a></span>
				<span class="ar">برطل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/075_brE">برع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brTl_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برطل</span></h3>
				<div class="sense" id="brTl_Q1_A1">
					<p><span class="ar">بَرْطَلَ</span>, <span class="auth">(inf. n. <span class="ar">بَرْطَلَةٌ</span>, TḲ,)</span> <em>He placed a long stone</em> (<span class="ar">بِرْطِيلٌ</span>) <em>in the fore part</em> (<span class="ar">إِزَآء</span>, q. v.,) <em>of his watering-trough.</em> <span class="auth">(Lth, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برطل</span> - Entry: Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brTl_Q1_B1">
					<p><span class="add">[<em>He gave</em> him <em>a</em> <span class="ar">بِرْطِيل</span>, or <em>bribe;</em>]</span> <em>he bribed</em> him. <span class="auth">(Ḳ.)</span> And <span class="ar">بُرْطِلَ</span> <em>He was bribed.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brTl_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبرطل</span></h3>
				<div class="sense" id="brTl_Q2_A1">
					<p><span class="ar">تَبَرْطَلَ</span> <em>He received a</em> <span class="add">[<span class="ar">بِرْطِيل</span>, or]</span> <em>bribe.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biroTiylN">
				<h3 class="entry"><span class="ar">بِرْطِيلٌ</span></h3>
				<div class="sense" id="biroTiylN_A1">
					<p><span class="ar">بِرْطِيلٌ</span> <em>A long stone:</em> pl. <span class="ar">بَرَاطِيلٌ</span>: <span class="auth">(Ṣ:)</span> or <em>a broad stone:</em> <span class="auth">(TA in art. <span class="ar">برم</span>:)</span> or <em>a stone</em> <span class="auth">(Seer, A, Ḳ)</span> <em>of an oblong form</em> <span class="auth">(A, TA)</span> <em>a cubit in length,</em> <span class="auth">(Seer, TA,)</span> or <em>an iron, long, broad, and hard by nature,</em> <span class="auth">(Ḳ,)</span> <em>not such as is made long, or sharpened</em> or <em>made sharp-pointed, by men,</em> <span class="auth">(TA,)</span> <em>with which the millstone is pecked</em> (<span class="ar">تُنْقَرُ</span> <span class="add">[i. e., <em>wrought into shape, and roughened in its surface, by pecking</em>]</span>): so says Lth: <span class="auth">(TA:)</span> to this is sometimes likened the muzzle, or fore part of the nose and mouth, of a she-camel of high breed: <span class="auth">(Lth, TA:)</span> <span class="add">[and hence,]</span> it signifies also † the <em>muzzle,</em> or <em>fore part of the nose and mouth, of an old bear:</em> <span class="auth">(TA:)</span> some say that the dual signifies <em>two elongated stones, of the hardest kind, slender, and sharp-pointed, with which the millstone is pecked</em> (<span class="ar">تُنْقَرُ</span> <span class="add">[explained above]</span>). <span class="auth">(TA.)</span> Also, <span class="auth">(Ḳ,)</span> accord. to Sh, <span class="auth">(TA,)</span> <em>A pickaxe,</em> or <em>stonecutter's pick;</em> syn. <span class="ar">مِعْوَلٌ</span>: <span class="auth">(Sh, Mṣb, Ḳ:)</span> pl. as above: accord. to IAạr, <em>what is called in Persian</em> <span class="fa">اسكنه</span> <span class="add">[app. a mistranscription, or a dial. var., of <span class="ar">إِسْكَنك</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برطل</span> - Entry: <span class="ar">بِرْطِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="biroTiylN_B1">
					<p><em>A bribe;</em> syn. <span class="ar">رِشْوَةٌ</span>: <span class="auth">(Mṣb, Ḳ:)</span> app. mentioned in the Ḳ as an Arabic word; and if so, the pronunciation with fet-ḥ to the <span class="ar">ب</span> is a vulgarism, since there is no such measure as <span class="ar">فَعْلِيلٌ</span>: Abu-l-ʼAlà El-Ma'arree says that it is not known in this sense in the <span class="add">[classical]</span> language of the Arabs; and it seems as though it were taken from the same word signifying “an oblong stone;” as though the bribe were likened to a stone that is thrown: <span class="auth">(TA:)</span> or it seems as though it were taken from the same word signifying a <span class="ar">مِعْوَل</span>; because therewith a thing is got out; <span class="auth">(Mṣb;)</span> and so El-Munáwee asserts it to be: <span class="auth">(TA:)</span> pl. as above. <span class="auth">(Mṣb, Ḳ.)</span> Hence the phrase, <span class="ar long">أَلْقَمَهُ البِرْطِيلَ</span> <span class="add">[<em>He tipt him the bribe; conveyed it to him in like manner as one puts a morsel into another's mouth;</em> somewhat like our phrase <em>he greased his fist</em>]</span>. <span class="auth">(TA.)</span> And the saying, <span class="ar long">البَرَاطِيلُ تَنْصُرُ الأَبَاطِيلِ</span> <span class="add">[<em>Bribes render victorious false allegations</em>]</span>: <span class="auth">(Mṣb, TA:)</span> a prov. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaroTilu">
				<h3 class="entry"><span class="ar">مُبَرْطِلُ</span></h3>
				<div class="sense" id="mubaroTilu_A1">
					<p><span class="ar long">مُبَرْطِلُ الرَّأْسِ</span> A man <em>having a long head.</em> <span class="auth">(A in art. <span class="ar">كوز</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0189.pdf" target="pdf">
							<span>Lanes Lexicon Page 189</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
