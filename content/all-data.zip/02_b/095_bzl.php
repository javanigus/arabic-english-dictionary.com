<article class="root" id="Root_bzl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/094_bzq">بزق</a></span>
				<span class="ar">بزل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/096_bzm">بزم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bzl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزل</span></h3>
				<div class="sense" id="bzl_1_A1">
					<p><span class="ar">بَزَلَهُ</span>, <span class="auth">(Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُلُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَزْلٌ</span>, <span class="auth">(Mṣb, TA,)</span> <em>He clave it, split it,</em> or <em>slit it;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">بزّلهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْزِيلٌ</span>. <span class="auth">(TA. <span class="add">[But the latter verb probably has an intensive or a frequentative sense, or applies to many objects.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzl_1_A2">
					<p><em>He broached it,</em> or <em>pierced it, and drew forth what was in it.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bzl_1_A3">
					<p><em>He broached,</em> or <em>pierced, the vessel containing it,</em> <span class="auth">(IDrd, Ḳ, TA,)</span> <em>and drew it forth;</em> <span class="auth">(IDrd, TA;)</span> namely wine, &amp;c.; <span class="auth">(IDrd, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">ابتزلهُ↓</span></span> and<span class="arrow"><span class="ar">تبزّلهُ↓</span></span>. <span class="auth">(Ḳ,* TA.)</span> You say,<span class="arrow"><span class="ar long">اِبْتَزَلْتُ↓ الشَّرَابَ لِنَفْسِى</span></span> <span class="add">[<em>I broached its vessel, and drew forth the wine,</em> or <em>beverage, for myself</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bzl_1_A4">
					<p><em>He removed it,</em> or <em>took it off,</em> namely, the clay <span class="add">[that closed the mouth,]</span> from the head of the <span class="ar">دَنّ</span> <span class="add">[or wine-jar]</span>. <span class="auth">(Ḥar p. 140.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bzl_1_A5">
					<p><em>He cleared it,</em> or <em>clarified it;</em> namely, wine, or beverage; <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">ابتزلهُ↓</span></span>: but Az says, I know not <span class="ar">البَزْلُ</span> as signifying “the act of clearing, or clarifying.” <span class="auth">(TA. <span class="add">[<span class="ar long">بَزَلْتُ الشَّرَابَ</span> is mentioned, but not explained, in the Ṣ. The meaning there intended may be either the third or the last given above.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bzl_1_A6">
					<p>‡ <em>He decided it,</em> <span class="auth">(Ḳ, TA,)</span> <em>and settled it firmly;</em> <span class="auth">(TA;)</span> namely, a case, or an affair; or an opinion: <span class="auth">(Ḳ, TA:)</span> and † <em>he decided it;</em> namely, the judicial sentence. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bzl_1_A7">
					<p>† <em>He originated it,</em> or <em>devised it;</em> namely, his opinion. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bzl_1_A8">
					<p><span class="ar long">مَا عِنْدَهُ بُلْغَةٌ تَبْزُلُ حَاجَةً</span> † <em>He has not a sufficiency,</em> or <em>a sufficiency of the means of subsistence, that will satisfy a want.</em> <span class="auth">(Z, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzl_1_B1">
					<p><span class="ar">بَزَلَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُلُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">بُزُولٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بَزْلٌ</span>, <span class="auth">(Ḳ, TA, <span class="add">[in the CK <span class="ar">بُزْل</span>,]</span>)</span> <em>It</em> <span class="auth">(the <span class="ar">ناب</span> <span class="add">[or tush]</span> of a camel)</span> <em>clave the flesh, and came forth:</em> <span class="auth">(Ḳ,* TA:)</span> or <em>his</em> <span class="auth">(a camel's)</span> <span class="ar">ناب</span> <span class="add">[or <em>tush</em>]</span> <em>clave the flesh, and came forth;</em> <span class="auth">(Ṣ, Mṣb;)</span> <span class="add">[or <em>he became such as is termed</em> <span class="ar">بَازِل</span>; generally]</span> <em>by his entering the ninth year.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bzl_1_B2">
					<p><span class="add">[And hence, as being likened to a camel that has attained his full strength,]</span> inf. n. <span class="ar">بزالة</span> <span class="add">[written without any indication of the syll. signs, but most probably <span class="ar">بَزَالَةٌ</span>, though the verb seems to be <span class="ar">بَزَلَ</span>, not <span class="ar">بَزُلَ</span>,]</span> † <em>It</em> <span class="auth">(an opinion, or a judgment,)</span> <em>was,</em> or <em>became, right.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بزّل</span></h3>
				<div class="sense" id="bzl_2_A1">
					<p><a href="#bzl_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبزّل</span></h3>
				<div class="sense" id="bzl_5_A1">
					<p><span class="ar">تبزّل</span> and<span class="arrow"><span class="ar">انبزل↓</span></span>, <span class="auth">(Ḳ, TA,)</span> or<span class="arrow"><span class="ar">ابتزل↓</span></span>, <span class="auth">(so the latter is written in the CK,)</span> <em>It clave, split,</em> or <em>slit;</em> intrans.: <span class="auth">(Ḳ:)</span> or the former signifies <em>it clave, split,</em> or <em>slit, much, in several places,</em> or <em>often;</em> syn. <span class="ar">تَشَقَّقَ</span>: and<span class="arrow">↓</span> the second, said of a <span class="ar">طَلْع</span>, <span class="add">[app. here meaning a spathe, rather than a spadix, of a palm-tree,]</span> <em>it clave, split,</em> or <em>burst.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzl_5_A2">
					<p>Also, the first, said of the body, <em>It burst forth,</em> or <em>flowed, with blood:</em> and in like manner one says of a water-skin <span class="ar">تبزّل</span> and <span class="ar long">تبزّل بِالمَآءِ</span> <span class="add">[<em>it burst forth,</em> or <em>flowed, with water,</em> or <em>the water</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzl_5_B1">
					<p><a href="#bzl_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzl_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبزل</span></h3>
				<div class="sense" id="bzl_7_A1">
					<p><a href="#bzl_5">see 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتزل</span></h3>
				<div class="sense" id="bzl_8_A1">
					<p><a href="#bzl_1">see 1</a>, in three places</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzl_8_B1">
					<p><a href="#bzl_5">and see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبزل</span></h3>
				<div class="sense" id="bzl_10_A1">
					<p><span class="ar">استبزلهُ</span> <em>He opened it;</em> namely, a <span class="ar">دَنّ</span> <span class="add">[or wine-jar]</span>. <span class="auth">(Ḥar p. 140.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bazolK">
				<h3 class="entry"><span class="ar">بَزْلٍ</span></h3>
				<div class="sense" id="bazolK_A1">
					<p><span class="ar long">أَمْرٌ ذُو بَزْلٍ</span> <em>A distressing, an afflictive,</em> or <em>a calamitous, affair</em> or <em>event</em> or <em>case.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buzolN">
				<h3 class="entry"><span class="ar">بُزْلٌ</span></h3>
				<div class="sense" id="buzolN_A1">
					<p><span class="ar long">سِقَآءٌ فِيهِ بُزْلٌ</span> <em>A water-skin that bursts forth,</em> or <em>flows, with the water:</em> pl. <span class="ar">بُزُولٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bazolaMCu">
				<h3 class="entry"><span class="ar">بَزْلَآءُ</span></h3>
				<div class="sense" id="bazolaMCu_A1">
					<p><span class="ar">بَزْلَآءُ</span> ‡ <em>A great calamity</em> or <em>misfortune</em> or <em>disaster.</em> <span class="auth">(IDrd, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَزْلَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bazolaMCu_A2">
					<p>† <em>Difficulties, distresses,</em> or <em>afflictions.</em> <span class="auth">(IDrd, Ḳ.)</span> You say, <span class="ar long">هُوَ نَهَّاضٌ بِبَزْلَآءِ</span> † <em>He is one who manages great affairs;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> <em>who has ability and strength to overcome difficulties.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَزْلَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bazolaMCu_A3">
					<p>† <em>Good judgment</em> or <em>opinion</em> or <em>counsel.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَزْلَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bazolaMCu_A4">
					<p><span class="ar long">مَا لِفُلَانٍ بَزْلَآءُ يَعِيشُ بِهَا</span> † <em>Such a one has not determination, resolution,</em> or <em>decision, of judgment, whereby to live.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَزْلَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bazolaMCu_A5">
					<p><span class="ar long">هُوَ ذُو بَزْلَآءَ</span> † <em>He has a firm,</em> or <em>well-established, way,</em> or <em>manner, of acting,</em> or <em>conducting himself.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَزْلَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bazolaMCu_A6">
					<p><span class="ar long">خُطَّةٌ بَزْلَآءُ</span> ‡ <em>A great event that distinguishes that which is true and that which is false.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buzaAlN">
				<h3 class="entry"><span class="ar">بُزَالٌ</span></h3>
				<div class="sense" id="buzaAlN_A1">
					<p><span class="ar">بُزَالٌ</span> The <em>place that is broached,</em> or <em>pierced, in a vessel containing wine</em>, &amp;c.; <span class="auth">(Ḳ;)</span> the <em>place whence issues the thing</em> <span class="add">[or <em>liquid</em>]</span> <em>whereof the containing vessel is broached,</em> or <em>pierced.</em> <span class="auth">(IDrd.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bizaAlN">
				<h3 class="entry"><span class="ar">بِزَالٌ</span></h3>
				<div class="sense" id="bizaAlN_A1">
					<p><span class="ar">بِزَالٌ</span> <em>An iron instrument with which the</em> <span class="ar">مِبْزَل</span> <span class="add">[or <span class="ar">مَبْزَل</span>?]</span> <em>of a wine-jar is opened.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bazuwlN">
				<h3 class="entry"><span class="ar">بَزُولٌ</span></h3>
				<div class="sense" id="bazuwlN_A1">
					<p><span class="ar">بَزُولٌ</span>: <a href="#baAzilN">see <span class="ar">بَازِلٌ</span></a> in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baziylN">
				<h3 class="entry"><span class="ar">بَزِيلٌ</span></h3>
				<div class="sense" id="baziylN_A1">
					<p><span class="ar">بَزِيلٌ</span>, applied to wine or beverage, <em>i. q.</em><span class="arrow"><span class="ar">مُبْتَزَلٌ↓</span></span> <span class="add">[which may mean either That <em>whereof the containing vessel has been broached and which has been drawn forth,</em> or that <em>which is cleared</em> or <em>clarified;</em> but more probably the former]</span>. <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAzilN">
				<h3 class="entry"><span class="ar">بَازِلٌ</span></h3>
				<div class="sense" id="baAzilN_A1">
					<p><span class="ar">بَازِلٌ</span>, applied to a camel, the male and the female, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>That has cut its</em> <span class="ar">ناب</span> <span class="add">[or <em>tush</em>]</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>by its entering the ninth year;</em> <span class="auth">(Mṣb;)</span> or <em>in its ninth year;</em> <span class="auth">(Ṣ, Mgh, Ḳ;)</span> for then it cuts that tooth; <span class="auth">(Ṣ, Ḳ;)</span> or, as is sometimes the case, <em>in the eighth year;</em> <span class="auth">(Ṣ;)</span> and after this there is no age named: <span class="auth">(IAạr, Ḳ:)</span> or a she-camel <em>that has completed her ninth year, and attained her full strength:</em> <span class="auth">(Ḥam p. 506:)</span> and<span class="arrow"><span class="ar">بَزُولٌ↓</span></span> signifies the same, applied to the male and the female: <span class="auth">(IDrd, Ḳ:)</span> or, accord. to AZ, a she-camel is not termed <span class="ar">بَازِلٌ</span>; but the epithet<span class="arrow"><span class="ar">بَزُولٌ↓</span></span> is applied to her <em>that has completed a year after cutting the tooth above mentioned, until she is termed</em> <span class="ar">ناب</span>: <span class="auth">(MF, TA:)</span> the pl. <span class="auth">(of <span class="ar">بازل</span>, Ṣ, Mṣb)</span> is <span class="ar">بَوَازِلُ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بُزَّلٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُزْلٌ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بُزُلٌ</span>, like <span class="ar">كُتُبٌ</span>. <span class="auth">(Ḳ.)</span> <span class="ar long">بَازِلُ عَامٍ</span> and <span class="ar long">بَازِلُ عَامَيْنِ</span> signify <em>That has passed a year,</em> and <em>two years, after cutting the tooth above mentioned.</em> <span class="auth">(MF, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَازِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAzilN_A2">
					<p>Also The <em>tooth that has come forth at the time above mentioned:</em> <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">بَوَازِلُ</span>. <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَازِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAzilN_A3">
					<p>And ‡ A man <em>perfect in his experience and his intellect:</em> <span class="auth">(Ḳ, TA:)</span> or <em>rendered firm,</em> or <em>sound, in judgment by age and experience:</em> so says IDrd: likened to the camel thus termed: <span class="auth">(TA:)</span> or <em>old:</em> opposed to <span class="ar">جَذَعٌ</span>, q. v. <span class="auth">(IAạr in art. <span class="ar">جذع</span> of the TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَازِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAzilN_A4">
					<p>And ‡ A case, or an affair, and an opinion, <em>firmly settled</em> or <em>established.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَازِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAzilN_A5">
					<p><span class="ar long">خَطْبٌ بَازِلٌ</span> † <em>A difficult, a distressing,</em> or <em>an afflicting, thing, affair,</em> or <em>business.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">بُلَىَ بِأَشْهَبَ بَازِلٍ</span> † <em>He was afflicted with a difficult and distressing thing</em> or <em>event.</em> <span class="auth">(TA. <span class="add">[<a href="index.php?data=13_X/164_Xhb">See also art. <span class="ar">شهب</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَازِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAzilN_A6">
					<p><span class="ar long">شَجَّةٌ بَازِلَةٌ</span> <em>A wound in the head from which the blood flows:</em> <span class="auth">(Ṣ:)</span> or <em>such as is termed</em> <span class="ar">حَارِصَةٌ</span>, <span class="auth">(Ḳ,)</span> i. e. <span class="ar">مُتَلَاحِمَةٌ</span>, <span class="auth">(TA,)</span> <span class="add">[but see these two words, <a href="#XajBapN">and see <span class="ar">شَجَّةٌ</span></a>,]</span> <em>that cleaves the skin, but does not penetrate beyond it:</em> <span class="auth">(Ḳ:)</span> the mulet for which is said to be three camels. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">بَازِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baAzilN_A7">
					<p><span class="ar long">مَا بَقِيتَ لَهُمْ بَازِلَةٌ</span> is like the saying <span class="ar long">مَا بَقِيتَ لَهُمْ ثَاغِيَةٌ وَلَا رَاغِيَةٌ</span>, i. e. ‡ <span class="add">[<em>There remained not to them</em>]</span> <em>one</em> <span class="add">[<em>sheep</em> or <em>goat,</em> or <em>camel</em>]</span>. <span class="auth">(Ṣ, TA.)</span> You say also, <span class="ar long">مَا عِنْدَهُ بَازِلَةٌ</span>, i. e. † <em>There is not in his possession anything of property,</em> or <em>of camels</em>, &amp;c.: <span class="auth">(Yaạḳoob, Ṣ, Ḳ:)</span> or, <em>a sufficiency,</em> or <em>a sufficiency of the means of subsistence, that will satisfy a want.</em> <span class="auth">(Z, TA.)</span> And <span class="ar long">لَا تَرَكَ ٱللّٰهُ عِنْدَهُ بَازِلَةً</span> † <span class="add">[<em>May God not leave in his possession</em>]</span> <em>anything.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">لَمْ يُعْطِهِمْ بَازِلَةً</span> † <span class="add">[<em>He did not give them</em>]</span> <em>anything.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabozalN">
				<h3 class="entry"><span class="add">[<span class="ar">مَبْزَلٌ</span>]</span></h3>
				<div class="sense" id="mabozalN_A1">
					<p><span class="add">[<span class="ar">مَبْزَلٌ</span> app. The <em>mouth</em> of a wine-jar: <a href="#bizaAlN">see <span class="ar">بِزَالٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibozalN">
				<h3 class="entry"><span class="ar">مِبْزَلٌ</span></h3>
				<div class="sense" id="mibozalN_A1">
					<p><span class="ar">مِبْزَلٌ</span> <em>A strainer,</em> or <em>thing with which wine,</em> or <em>beverage, is cleared,</em> or <em>clarified;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">مِبْزَلَةٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزل</span> - Entry: <span class="ar">مِبْزَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mibozalN_A2">
					<p><em>An instrument for broaching, piercing,</em> or <em>perforating.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibozalapN">
				<h3 class="entry"><span class="ar">مِبْزَلَةٌ</span></h3>
				<div class="sense" id="mibozalapN_A1">
					<p><span class="ar">مِبْزَلَةٌ</span>: <a href="#mibozalN">see <span class="ar">مِبْزَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubotazalN">
				<h3 class="entry"><span class="ar">مُبْتَزَلٌ</span></h3>
				<div class="sense" id="mubotazalN_A1">
					<p><span class="ar">مُبْتَزَلٌ</span>: <a href="#baziylN">see <span class="ar">بَزِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0200.pdf" target="pdf">
							<span>Lanes Lexicon Page 200</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
