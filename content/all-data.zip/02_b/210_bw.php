<article class="root" id="Root_bw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/209_bhe">بهى</a></span>
				<span class="ar">بو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/211_bwA">بوا</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bawBN">
				<h3 class="entry"><span class="ar">بَوٌّ</span></h3>
				<div class="sense" id="bawBN_A1">
					<p><span class="ar">بَوٌّ</span> <em>A skin of a young unweaned camel stuffed</em> <span class="auth">(Lth, T, Ṣ, M, Ḳ)</span> <em>with straw</em> <span class="auth">(Lth, T, M, Ḳ)</span> <em>or with</em> <span class="ar">ثُمَام</span> <span class="add">[i. e. <em>panic grass</em>]</span> <span class="auth">(M, Ḳ)</span> <em>or with dry herbage,</em> <span class="auth">(M,)</span> <em>to which a she-camel is made to incline</em> <span class="auth">(Lth, T, Ṣ)</span> <em>when her young one has died:</em> <span class="auth">(Ṣ:)</span> <em>it is brought near to the mother of the young camel</em> <span class="add">[<em>that has died</em>]</span>, <em>in order that she may incline to it, and yield her milk</em> <span class="auth">(M, Ḳ)</span> <em>over it.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بو</span> - Entry: <span class="ar">بَوٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bawBN_A2">
					<p>Also <em>A she-camel's young one.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بو</span> - Entry: <span class="ar">بَوٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bawBN_A3">
					<p>And † <em>Stupid; foolish; having little sense,</em> or <em>intellect;</em> as also<span class="arrow"><span class="ar">بَوِّىٌّ↓</span></span>; <span class="auth">(IAạr, T, Ḳ;)</span> applied to a man: <span class="auth">(IAạr, T:)</span> fem. <span class="ar">بَوَّةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بو</span> - Entry: <span class="ar">بَوٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bawBN_A4">
					<p>And <span class="ar">البَوُّ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">بَوُّ الأَثَافِى</span>, <span class="auth">(Lth, T, Ṣ, M,)</span> ‡ <em>Ashes:</em> <span class="auth">(Lth, T, Ṣ, M, Ḳ:)</span> so called <span class="add">[as being lifeless,]</span> by way of comparison <span class="add">[to the stuffed skin of a young camel]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bawBieBN">
				<h3 class="entry"><span class="ar">بَوِّىٌّ</span></h3>
				<div class="sense" id="bawBieBN_A1">
					<p><span class="ar">بَوِّىٌّ</span>: <a href="#bawBN_A3">see above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bawobaApN">
				<h3 class="entry"><span class="ar">بَوْبَاةٌ</span></h3>
				<div class="sense" id="bawobaApN_A1">
					<p><span class="ar">بَوْبَاةٌ</span>, mentioned in this art. in the Ṣ, and also, as well as in art. <span class="ar">بوب</span>, in the Ḳ: <a href="index.php?data=02_b/213_bwb">see the latter art</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0270.pdf" target="pdf">
							<span>Lanes Lexicon Page 270</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
