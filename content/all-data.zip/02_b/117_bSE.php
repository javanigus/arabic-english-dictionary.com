<article class="root" id="Root_bSE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/116_bST">بصط</a></span>
				<span class="ar">بصع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/118_bSq">بصق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bSE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بصع</span></h3>
				<div class="sense" id="bSE_1_A1">
					<p><span class="ar">بَصَعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْصَعُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَصْعٌ</span>, <span class="auth">(Ṣ,)</span> <em>He collected:</em> <span class="auth">(Ḳ:)</span> <span class="add">[J says,]</span> I have heard from certain of the grammarians that <span class="ar">البَصْعُ</span> is syn. with <span class="ar">الجَمْعُ</span>, but I know not what is the truth of the matter. <span class="auth">(Ṣ.)</span> Hence what here follows. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboSaEu">
				<h3 class="entry"><span class="ar">أَبْصَعُ</span></h3>
				<div class="sense" id="OaboSaEu_A1">
					<p><span class="ar">أَبْصَعُ</span> is a word used as a corroborative, and is pronounced by some with the pointed <span class="ar">ض</span>, but this is not of high authority: you say, <span class="ar long">أَخَذْتُ حَقِّى أَجْمَعَ أَبْصَعَ</span> <span class="add">[<em>I took my right,</em> or <em>due, altogether</em>]</span>: and <span class="add">[the pl. is <span class="ar">أَبْصَعُونَ</span>:]</span> you say, <span class="ar long">جَآءَ القَوْمُ أَجْمَعُونَ أَبْصَعُونَ</span> <span class="add">[<em>The people,</em> or <em>company of men, came all together</em>]</span>: and the fem. is <span class="ar">بَصْعَآءُ</span>: you say, <span class="ar long">جَمْعَآءَ بَصْعَآءَ</span>: and <span class="add">[<a href="#baSoEaACu">the pl. of <span class="ar">بَصْعَآءُ</span></a> is <span class="ar">بُصَعُ</span>: you say,]</span> <span class="ar long">رَأَيْتُ النِّسْوَةَ جُمَعَ بُصَعَ</span> <span class="add">[<em>I saw the women all together</em>]</span>: it is a corroborative occurring in a particular order, never before <span class="ar">اجمع</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#OabotaEu">See <span class="ar">أَبْتَعُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0212.pdf" target="pdf">
							<span>Lanes Lexicon Page 212</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
