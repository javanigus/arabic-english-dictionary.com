<article class="root" id="Root_bxtr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/033_bxt">بخت</a></span>
				<span class="ar">بختر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/035_bxr">بخر</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bxtr_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بختر</span></h3>
				<div class="sense" id="bxtr_Q1_A1">
					<p><span class="ar">بَخْتَرَ</span>: <a href="#bxtr_Q2">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxtr_Q2">
				<h3 class="entry">Q. 2. ⇒ <span class="ar">تبختر</span></h3>
				<div class="sense" id="bxtr_Q2_A1">
					<p><span class="ar">تَبَخْتَرَ</span>, <span class="auth">(L,)</span> inf. n. <span class="ar">تَبَخْتُرٌ</span>; <span class="auth">(JK, Ṣ, L, Ḳ;)</span> and<span class="arrow"><span class="ar">بَخْتَرَ↓</span></span>, <span class="auth">(L,)</span> inf. n. <span class="ar">بَخْتَرَةٌ</span>; <span class="auth">(L, Ḳ;)</span> <em>He walked in a certain manner;</em> <span class="auth">(Ṣ;)</span> <em>with an elegant gait;</em> <span class="auth">(JK, Ḳ;)</span> <em>with an elegant and a proud and self-conceited gait,</em> <span class="auth">(L, TA, TḲ,)</span> <em>with an affected inclining of the body from side to side;</em> <span class="auth">(TḲ;)</span> or <em>with a twisting of the back,</em> <span class="auth">(Fr, in TA, voce <span class="ar">تَمَطَّطَ</span>, and Bḍ in lxxv. 33,)</span> <em>and with extended steps.</em> <span class="auth">(Bḍ ibid.)</span> You say also, <span class="ar long">فُلَانٌ يَتَبَخْتَرُ فِى مِشْيَتِهِ</span> and <span class="ar">يَتَبَخْتَى</span> <span class="add">[<em>Such a one carries himself in an elegant and a proud and self-conceited manner, with an affected inclining of his body from side to side, in his gait;</em> or <em>with a twisting of his back, and with extended steps</em>]</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxotarieBN">
				<h3 class="entry"><span class="ar">بَخْتَرِىٌّ</span> / <span class="ar">بَخْتَرِيَّةٌ</span></h3>
				<div class="sense" id="baxotarieBN_A1">
					<p><span class="ar">بَخْتَرِىٌّ</span> and<span class="arrow"><span class="ar">بِخْتِيرٌ↓</span></span> <em>Elegant,</em> or <em>beautiful, in gait and in body;</em> <span class="auth">(L, Ḳ: in <span class="add">[some of]</span> the copies of the Ḳ, instead of <span class="ar">وَالجِسْمِ</span>, is erroneously put <span class="ar">وَالجَسِيمُ</span>: TA:)</span> applied to a man: <span class="auth">(L:)</span> or <span class="auth">(so accord. to the L and TA, but in the Ḳ “and”)</span> <em>proud and self-conceited:</em> <span class="auth">(L, Ḳ:)</span> or <em>who walks in the manner termed</em> <span class="ar">تَبَخْتُرٌ</span> <span class="add">[<a href="#bxtr_Q2">see Q. 2</a>.]</span>: <span class="auth">(JK, L:)</span> the former epithet is also applied to a camel: <span class="auth">(L:)</span> the fem. of the former is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَخْتَرِيَّةٌ</span>}</span></add>. <span class="auth">(JK, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buxoturieBN">
				<h3 class="entry"><span class="ar">بُخْتُرِىٌّ</span></h3>
				<div class="sense" id="buxoturieBN_A1">
					<p><span class="ar">بُخْتُرِىٌّ</span> a subst. signifying The <em>gait denoted by</em> <span class="ar">التَّبَخْتُرُ</span> <span class="add">[<a href="#bxtr_Q2">inf. n. of Q. 2</a>]</span>: <span class="auth">(JK:)</span> <span class="add">[and so<span class="arrow"><span class="ar">بَخْتَرِيَّةٌ↓</span></span>: whence the phrase]</span> <span class="ar long">فُلَانٌ يَمْشِى البَخْتَرِيَّةٌ</span> <em>Such a one walks in the manner termed</em> <span class="ar">تَبَخْتُرٌ</span>. <span class="auth">(Ṣ, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxotariyBapN">
				<h3 class="entry"><span class="ar">بَخْتَرِيَّةٌ</span></h3>
				<div class="sense" id="baxotariyBapN_A1">
					<p><span class="ar">بَخْتَرِيَّةٌ</span>: <a href="#buxoturieBN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bixotiyrN">
				<h3 class="entry"><span class="ar">بِخْتِيرٌ</span></h3>
				<div class="sense" id="bixotiyrN_A1">
					<p><span class="ar">بِخْتِيرٌ</span>: <a href="#baxotarieBN">see <span class="ar">بَخْتَرِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0158.pdf" target="pdf">
							<span>Lanes Lexicon Page 158</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
