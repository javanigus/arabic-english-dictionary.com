<article class="root" id="Root_brsm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/070_brzx">برزخ</a></span>
				<span class="ar">برسم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/072_brX">برش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brsm_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برسم</span></h3>
				<div class="sense" id="brsm_Q1_A1">
					<p><span class="ar">بُرْسِمَ</span> <em>He</em> <span class="auth">(a man)</span> <em>was affected with the disease termed</em> <span class="ar">بِرْسَام</span>; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> as also <span class="ar">بُلْسِمَ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="birosaAmN">
				<h3 class="entry"><span class="ar">بِرْسَامٌ</span></h3>
				<div class="sense" id="birosaAmN_A1">
					<p><span class="ar">بِرْسَامٌ</span>, <span class="auth">(in the T with fet-ḥ, <span class="add">[<span class="ar">بَرْسَامٌ</span>,]</span> Mgh,)</span> <em>A certain malady,</em> or <em>disease,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>well known,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>attended by delirium:</em> <span class="auth">(Ḳ:)</span> <span class="add">[in the present day, this term is applied to the <em>pleurisy,</em> as also <span class="ar long">ذَاتُ الجَنْبِ</span>; and so it is explained by Golius and Freytag; or, as the latter adds, accord. to Avicenna, <em>pleurodyne:</em> but]</span> in some of the books of medicine, it is said to be <em>a tumour,</em> <span class="auth">(Mṣb,)</span> or <em>a hot tumour,</em> <span class="auth">(TA,)</span> <em>that is incident to the septum which is between the liver and the bowels,</em> <span class="add">[app. meaning <em>the upper parts of the greater and lesser omentum,</em>]</span> <em>and then reaches to the brain:</em> <span class="auth">(Mṣb, TA:)</span> also pronounced <span class="ar">بِلْسَامٌ</span>: <span class="auth">(ISk, Mṣb:)</span> <em>i. q.</em> <span class="ar">مُومٌ</span>: <span class="auth">(M, TA:)</span> it is an arabicized word; <span class="auth">(IDrd, Mgh, Mṣb;)</span> or seems to be so; composed of <span class="ar">بَرْ</span> and <span class="ar">سَامْ</span>; the former of these, in Persian, signifying the “breast,” or “chest;” and the latter, “death” <span class="add">[and “fire” and “a swelling;” of which three meanings, the second and third are agreeable with the two explanations of <span class="ar">برسام</span> given above]</span>: so says Az. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="birosiymN">
				<h3 class="entry"><span class="ar">بِرْسِيمٌ</span></h3>
				<div class="sense" id="birosiymN_A1">
					<p><span class="ar">بِرْسِيمٌ</span>, with kesr, <span class="auth">(Ḳ,)</span> vulgarly pronounced with fet-ḥ to the <span class="ar">ب</span>, <span class="add">[<span class="ar">بَرْسِيم</span>,]</span> <span class="auth">(TA,)</span> <span class="add">[<em>Alexandrian trefoil</em> or <em>clover; trifolium Alexandrinum;</em> described by Forskål in his Flora Aegypt. Arab. p. 139; <em>the most common and the best kind of succulent food for cattle grown in Egypt: it is sown when the waters of the inundation are leaving the fields; and yields three crops; the second of which is termed</em> <span class="ar">رِبَّةٌ</span>; <em>and so is the third; but this is generally left for seed: when dry, it is termed</em> <span class="ar">دَرِيسٌ</span>: if his words have not been perverted by copyists, F explains it as]</span> the <em>grain of the</em> <span class="ar">قُرْط</span>, (<span class="ar long">حَبُّ القُرْط</span>) <span class="add">[but I think it probable that this is a mistranscription, for <span class="ar long">خَيْرُ القُرْطِ</span>, i. e., <em>the best of the</em> (<em>species of trefoil,</em> or <em>clover, called</em>) <span class="ar">قُرْط</span>,]</span> <em>resembling the</em> <span class="ar">رُطْبَة</span> <span class="add">[or <span class="ar">رَطْبَة</span>]</span>, <em>or superior to this latter in size,</em> or <em>quality</em> (<span class="ar long">أَجَلُّ مِنْهَا</span>): <span class="auth">(Ḳ:)</span> the <span class="ar">قُرْط</span> resembles the <span class="ar">رُطْبَة</span>, <span class="add">[written in the TA without the vowel signs,]</span> but is superior to this latter in size, or quality (<span class="ar long">اجلّ منها</span>), and larger in the leaves, and is what is called in Persian <span class="fa">شَبْذَر</span> <span class="add">[or <span class="fa">شَبْدَر</span>]</span>: <span class="auth">(AḤn, TA:)</span><em>it is one of the best kinds of herbage for horses and the like, which fatten upon it.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboriysamN">
				<span class="pb" id="Page_0188"></span>
				<h3 class="entry"><span class="ar">إِبْرِيسَمٌ</span></h3>
				<div class="sense" id="IiboriysamN_A1">
					<p><span class="ar">إِبْرِيسَمٌ</span>, <span class="auth">(M, <span class="add">[and thus written in copies of the Ḳ,]</span>)</span> with kesr to the <span class="ar">ر</span> <span class="add">[as well as the <span class="ar">ء</span>]</span>, accord. to IAạr, <span class="auth">(M,)</span> <span class="add">[and]</span> with fet-ḥ to the <span class="ar">س</span>; <span class="auth">(Ḳ;)</span> or <span class="ar">إِبْرَيْسَمٌ</span>; <span class="auth">(M;)</span> and <span class="add">[app. <span class="ar">إِبْرِيسُمٌ</span>,]</span> with damm to the <span class="ar">س</span>; <span class="auth">(Ḳ;)</span> or it has three dial. forms; accord. to ISk, it is <span class="ar">ابريسِم</span> <span class="add">[app. <span class="ar">إِبْرِيسِمٌ</span>]</span>; others say that it is <span class="ar">ابريسَم</span> <span class="add">[app. <span class="ar">أَبْرَيْسَمٌ</span>]</span>, with fet-ḥ; IAạr says that it is <span class="ar">إِبْرِيسَمٌ</span>, with kesr to the <span class="ar">ء</span> and the <span class="ar">ر</span> and with fet-ḥ to the <span class="ar">س</span>, and he says that there is not in the language an instance of <span class="ar">إِفْعِيلِلٌ</span>, with kesr, but there are instances of <span class="ar">إِفْعِيلَلٌ</span>, as <span class="ar">إِهْلِيلَجٌ</span> <span class="add">[q. v.]</span> and <span class="ar">إِبْرِيسَمٌ</span>; <span class="auth">(Ṣ; <span class="add">[but I find that in two copies of that work, and in the L, this passage is mutilated; for it runs thus; “ISk says that it is <span class="ar">إِبْرِيسَمٌ</span>, with kesr to the <span class="ar">ء</span> and <span class="ar">ر</span>, and with fet-ḥ to the <span class="ar">س</span>,”, &amp;c.;]</span>)</span> or one of its dial. forms is <span class="ar">إِبْرِيسِمٌ</span>, with kesr to the <span class="ar">ء</span> and the <span class="ar">ر</span> and the <span class="ar">س</span>; but ISk disallows this, <span class="add">[or, probably, as appears from what has been said above, we should read here, “accord. to ISk, but others disallow this,”]</span> saying that there is not in the language an instance of <span class="ar">افعليل</span> with kesr to the <span class="add">[former]</span> <span class="ar">ل</span>, but with fet-ḥ, as <span class="ar">إِهْلِيلَجٌ</span> and <span class="ar">إطْرِيفَلٌ</span>; and the second form is <span class="ar">أَبْرَيْسَمٌ</span>, with fet-ḥ to those three letters; and the third is <span class="ar">إِبْرَيْسَمٌ</span>, with kesr to the <span class="ar">ء</span>, and fet-ḥ to the <span class="ar">ر</span> and the <span class="ar">س</span>; <span class="auth">(Mṣb;)</span> and IB <span class="add">[appears to indicate the second and third of these forms, for he]</span> says that some pronounce <span class="ar">ابريسم</span> with fet-ḥ to the <span class="ar">ء</span> and the <span class="ar">ر</span>, and some pronounce it with kesr to the <span class="ar">ء</span>, and with fet-ḥ to the <span class="ar">س</span>; <span class="auth">(TA;)</span> <em>Silk;</em> syn. <span class="ar">حَرِيرٌ</span>: <span class="auth">(M, Ḳ:)</span> or, accord. to some, specially, <em>raw silk:</em> <span class="auth">(TA:)</span> <span class="add">[it is said that]</span> <span class="ar">حرير</span> is the same as <span class="ar">ابريسم</span>: <span class="auth">(Mṣb in art. <span class="ar">حر</span>:)</span> or dressed silk; syn. <span class="ar long">ابريسم مَطْبُوخ</span>: <span class="auth">(Mgh and Mṣb in that art.:)</span> or stuff wholly composed of silk: or of which the woof is silk: <span class="auth">(Mgh in that art., from the Jema et-Tefáreek:)</span> <span class="add">[and it is also said that]</span> <span class="ar">قَزَّ</span> is the same as <span class="ar">ابريسم</span>: <span class="auth">(Ḳ in art. <span class="ar">قز</span>:)</span> or a kind thereof: <span class="auth">(Ṣ in that art.:)</span> or that whereof <span class="ar">ابريسم</span> is made: <span class="auth">(Lth, Az, Mṣb, TA, all in that art.:)</span> <span class="add">[medicinal properties are ascribed to it: it is said that]</span> <em>it is exhilarating, warming to the body, moderate in temperament, and strengthening to the sight when used as a collyrium:</em> <span class="auth">(Ḳ:)</span> the word is arabicized, <span class="auth">(Ṣ, Mṣb, Ḳ, <span class="add">[but in the last it is said, after the explanation of the meaning, “or it is arabicized,”]</span>)</span> from <span class="add">[the Persian]</span> <span class="ar">ابريشم</span> <span class="add">[i. e. <span class="ar">أَبْرِيشَمْ</span>]</span>: <span class="auth">(TA:)</span> and is perfectly decl., even if used as a proper name, in the manner of a surname, because it was arabicized in its indeterminate state, not like <span class="ar">إِسْحَاقُ</span>, &amp;c., which were arabicized in their determinate state, and are not used by the Arabs indeterminately. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiborisamieBN">
				<h3 class="entry"><span class="ar">إِبْرِسَمِىٌّ</span></h3>
				<div class="sense" id="IiborisamieBN_A1">
					<p><span class="ar">إِبْرِسَمِىٌّ</span> or <span class="ar">إِبْرَيْسَمِىٌّ</span> <span class="add">[&amp;c.]</span> <em>A manufacturer</em> <span class="add">[or <em>seller</em>]</span> <em>of</em> <span class="ar">ابريسم</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubarosamN">
				<h3 class="entry"><span class="ar">مُبَرْسَمٌ</span></h3>
				<div class="sense" id="mubarosamN_A1">
					<p><span class="ar">مُبَرْسَمٌ</span> A man <em>affected with the disease termed</em> <span class="ar">بِرْسَام</span>; <span class="auth">(Mgh, Mṣb, Ḳ;)</span> as also <span class="ar">مُبَلْسَمٌ</span>. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0187.pdf" target="pdf">
							<span>Lanes Lexicon Page 187</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0188.pdf" target="pdf">
							<span>Lanes Lexicon Page 188</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
