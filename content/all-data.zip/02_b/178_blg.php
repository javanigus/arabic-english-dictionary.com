<article class="root" id="Root_blg">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/177_blEm">بلعم</a></span>
				<span class="ar">بلغ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/179_blgm">بلغم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blg_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلغ</span></h3>
				<div class="sense" id="blg_1_A1">
					<p><span class="add">[<span class="ar">بُلُوغٌ</span> inf. n. of <span class="ar">بَلَغَ</span>]</span> and <span class="ar">إِبْلَاغٌ</span> <span class="add">[<a href="#blg_4">inf. n. of<span class="arrow"><span class="ar">ابلغ↓</span></span></a>, but it seems that <span class="ar">ابلاغ</span> is here a mistranscription for <span class="ar">بَلَاغٌ</span>, which is, like <span class="ar">بُلُوغٌ</span>, an inf. n. of <span class="ar">بَلَغَ</span>, and this observation will be found to be confirmed by a statement immediately following this sentence,]</span> signify The <em>reaching, attaining, arriving at,</em> or <em>coming to, the utmost point of that to which,</em> or <em>towards which, one tends</em> or <em>repairs</em> or <em>betakes himself, to which one directs his course,</em> or <em>which one seeks, pursues, endeavours to reach, desires, intends,</em> or <em>purposes; whether it be a place, or a time, or any affair or state or event that is meditated or intended or determined or appointed:</em> and sometimes, the <em>being at the point thereof:</em> so says Abu-1-Kásim in the Mufradát. <span class="auth">(TA: <span class="add">[in which it is said, in the supplement to the present art., that <span class="ar">بَلَاغٌ</span> signifies The <em>reaching, attaining, arriving at,</em> or <em>coming to, a thing.</em>]</span>)</span> You say, <span class="ar long">بَلَغَ المَكَانَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">المَنْزِلَ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُغُ</span>}</span></add>,]</span> inf. n. <span class="ar">بُلُوغٌ</span> <span class="auth">(Ṣ, Ḳ)</span> <span class="add">[and <span class="ar">بَلَاغٌ</span>, as shown above]</span>, <em>He reached, attained, arrived at,</em> or <em>came to,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>the place,</em> <span class="auth">(Ṣ, Ḳ,)</span> and <em>the place of abode:</em> <span class="auth">(Mṣb:)</span> and <span class="auth">(so in the Ṣ, but in the Ḳ “or,”)</span> <em>he was, or became, at the point of reaching it, attaining it,</em>, &amp;c. <span class="auth">(Ṣ, Ḳ.)</span> <span class="ar long">فَبَلَغْنَ أَجَلَهُنَ</span>, in the Ḳur <span class="add">[ii. 232]</span>, means <em>And they have fully attained,</em> or <em>ended, their term.</em> <span class="auth">(Mṣb.)</span> But <span class="ar long">فَإِذَا بَلَغْنَ أَجَلَهُنَّ</span>, in the same <span class="add">[lxv. 2]</span>, means <em>And when they are near to attaining,</em> or <em>ending, their term:</em> <span class="auth">(Ṣ, TA:)</span> or <em>are at the point of accomplishing their term.</em> <span class="auth">(Mṣb, TA.)</span> It has the first of the meanings explained above in the phrase, <span class="ar long">بَلَغَ أَشُدَّهُ</span> <span class="add">[Ḳur xii. 22, &amp;c., <em>He attained his manly vigour,</em> or <em>full maturity,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span> And in <span class="ar long">بَلَغَأَرْبَعِينَ سَنَةً</span> <span class="add">[Ḳur xlvii. 14, <em>He attained </em>the age of <em>forty years</em>]</span>. <span class="auth">(TA.)</span> And in <span class="ar long">بَلَغَ مَعَهُ السَّعْىَ</span> <span class="add">[Ḳur xxxvii. 100, <em>He attained to working with him</em>]</span>. <span class="auth">(TA.)</span> In the Ḳur <span class="add">[iii. 35]</span>, occurs the phrase, <span class="ar long">وَقَدْ بَلَغَنِىَ الكِبَرُ</span> <span class="add">[<em>When old age hath come to me,</em> or <em>overtaken me</em>]</span>: and in another place <span class="add">[xix. 9]</span>, <span class="ar long">وَقَدْ بَلَغْتُ مِنَ الكِبَرِ عُتِيًّا</span> <span class="add">[<em>And I have reached the extreme degree of old age:</em> so explained in the Expos. of the Jel]</span>: phrases like <span class="ar long">أَدْرَكَنِىَ الجَهْدُ</span> and <span class="ar">أَدْرَكْتُهُ</span>. <span class="auth">(Er-Rághib, TA.)</span> You say also,<span class="arrow"><span class="ar long">لَزِمَهُ ذٰلِكَ بَالِغًا↓ مَا بَلَغَ</span></span> with the accus. case as a denotative of state; meaning <span class="add">[<em>That clave to him,</em> or <em>adhered to him,</em>, &amp;c.,]</span> <em>rising to its highest degree</em> or <em>point;</em> from <span class="ar long">بَلَغَ المَنْزِلَ</span>, explained above. <span class="auth">(Mṣb.)</span> <span class="add">[But<span class="arrow"><span class="ar long">بَالِغًا↓ مَا بَلَغَ</span></span> more frequently means <em>Whatever point, degree, amount, sum, quantity, number,</em> or <em>the like, it may reach, attain, arrive at, come to,</em> or <em>amount to.</em>]</span> And<span class="arrow"><span class="ar long">بَلَغَ فُلَانٌ مَبْلَغَهُ↓</span></span> and<span class="arrow"><span class="ar">مَبْلَغَتُهُ↓</span></span> <span class="add">[<em>Such a one reached,</em> or <em>attained, his utmost point</em> or <em>scope</em> or <em>degree</em>]</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">بَلَغَ فِى العِلْمِ المَبَالِغَ↓</span></span> <span class="add">[<em>He attained, in knowledge,</em> or <em>science, the utmost degrees of proficiency</em>]</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">بَلَغَ فِى الجَوْدَةِ مَبْلَغًا↓</span></span> <span class="add">[<em>It reached a consummate degree in goodness</em>]</span>. <span class="auth">(Ṣ, Ḳ,* TA.)</span> And<span class="arrow"><span class="ar long">بَلَغَ مِنَ الجَوْدَةِ مَبْلَغًا↓</span></span> <span class="add">[<em>He attained a consummate degree of goodliness</em>]</span>: said of a boy that has attained to puberty. <span class="auth">(O, TA.)</span> And <span class="ar long">بَلَغَ غَايَتَهُ فِى الطَّلَبِ</span> <span class="add">[<em>He did his utmost,</em> or <em>used his utmost power</em> or <em>ability, in seeking to attain an object</em>]</span>. <span class="auth">(Mṣb in art. <span class="ar">جهد</span>.)</span> And <span class="ar long">بَلَغَ أَقْصَى مَجْهُودِ بَعِيرِهِ فِى السَّيْرِ</span> <span class="add">[<em>He exerted the utmost endeavour,</em> or <em>effort,</em> or <em>power,</em> or <em>strength, of his camel, in journeying</em>]</span>. <span class="auth">(Ṣ in art. <span class="ar">نكث</span>.)</span> And <span class="ar long">بَلَغَ جَهْدَ دَابَّتِهِ</span> <em>i. q.</em> <span class="ar">جَهَدَهَا</span> <span class="add">[<em>He jaded, harassed, distressed, fatigued,</em> or <em>wearied, his beast</em>]</span>: <span class="auth">(Ḳ in art. <span class="ar">جهد</span>:)</span> and in like manner, <span class="ar long">بَلَغَ مَشَقَّتَهُ</span> and <span class="ar long">بَلَغَ مِنْهُ المَشَقَّةَ</span> <em>i. q.</em> <span class="ar">جَهَدَهُ</span> <span class="add">[and <span class="ar long">شَقَّ عَلَيْهِ</span>, i. e. <em>He,</em> or <em>it, jaded him, harassed him,</em>, &amp;c.; <em>ditressed him, afflicted him, oppressed him, overpowered him:</em> thus in each of these instances, as in many similar cases, the verb with the inf. n. that follows is equivalent to the verb of that inf. n.]</span>. <span class="auth">(Mṣb in art. <span class="ar">جهد</span>.)</span> <span class="add">[And, elliptically, <span class="ar long">بَلَغَ مِنْهُ</span> <em>i. q.</em> <span class="ar long">بَلَغَ مِنْهُ المشَقَّةَ</span>, explained above: and often meaning <em>It took,</em> or <em>had, an effect upon him; it affected him:</em> frequently said of wine and the like: and of a saying; as in the Ksh and Bḍ in iv. 66, where <span class="ar long">يَبْلُغُ مِنْهُمْ</span> is followed by <span class="ar long">وَيُؤَثِرُ فِيهِ</span> as an explicative: <a href="#baliygN">see also <span class="ar">بَلِيغٌ</span></a>.]</span> <span class="pb" id="Page_0251"></span>And <span class="ar long">بَلَغْتَ مِنَّا البُلَغِينَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">البِلَغِينَ</span>, and <span class="ar long">كُلَّ مَبْلَغٍ</span>: <span class="auth">(Ḳ:)</span> <a href="#Albulagiyna">see <span class="ar">البُلَغِينَ</span> below</a>. And <span class="ar long">بَلَغْتُ مِنَ الأَمْرِ المَشَقَّةَ</span> <span class="add">[<em>I experienced distress from the affair,</em> or <em>event</em>]</span>. <span class="auth">(TA in art. <span class="ar">مض</span>.)</span> <span class="add">[See also an ex. voce <span class="ar">إِبِدٌ</span>. <span class="ar">بَلَغَنِى</span> also signifies <em>It has come to my knowledge,</em> or <em>been related to me,</em> or <em>been told me;</em> or <em>it came to my knowledge,</em>, &amp;c.: and in this case it is generally followed by <span class="ar">أَنَّ</span>, or by <span class="ar">أَنْ</span> as a contraction of <span class="ar">أَنَّ</span>: for exs., see these two particles. And in like manner, <span class="ar long">بَلَغَنِى عَنْهُ</span> <em>Information has come to me,</em> or <em>information came to me, from him,</em> or <em>concerning him,</em> that such a thing has happened, or had happened.]</span> And <span class="ar">بَلَغَ</span> said of a letter or writing, inf. n. <span class="ar">بَلَاغٌ</span> and <span class="ar">بُلُوغٌ</span>, <em>It reached, arrived,</em> or <em>came.</em> <span class="auth">(Mṣb.)</span> And said of a plant, or of herbage, <em>It attained its full growth:</em> <span class="auth">(TA:)</span> and of a tree, such as a palm-tree, &amp;c., <em>its fruit became ripe:</em> <span class="auth">(AḤn, TA:)</span> and of fruit, <em>it became ripe.</em> <span class="auth">(Mṣb.)</span> Also, said of a boy, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُغُ</span>}</span></add>, inf. n. <span class="ar">بُلُوغٌ</span>, or, as IḲooṭ says, <span class="ar">بَلَاغٌ</span>, <span class="auth">(Mṣb,)</span> <em>He attained to puberty, virility, ripeness,</em> or <em>maturity;</em> syn. <span class="ar">أَدْرَكَ</span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">اِحْتَلَمَ</span>; <span class="auth">(M, Mṣb;)</span> and <em>attained a consummate degree of goodliness</em> (<span class="ar long">بَلَغَ مِنَ الجَوْدَةِ مَبْلَغًا</span>): <span class="auth">(O, TA:)</span> as though he attained the time of the writing of his marriage-contract, and of his having duties or obligations imposed upon him: <span class="auth">(TA:)</span> and in like manner one says of a girl, <span class="ar">بَلَغَ</span>, <span class="auth">(T, TA,)</span> or <span class="ar">بَلَغَتْ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blg_1_A2">
					<p><span class="ar long">بَلَغَ ٱللّٰهُ بِهِ</span> <span class="add">[<em>God caused him to reach, attain, arrive at,</em> or <em>come to, his appointed end,</em> or <em>term of life;</em> <span class="ar">أَجَلَهُ</span>, or the like, being understood]</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">بَلَغَ ٱللّٰهُ بِكَ أَكْلَأَ العُمُرِ</span>, i. e. <span class="add">[<em>May God cause thee to reach,</em> or <em>attain,</em>]</span> <em>the extreme,</em> or <em>most distant, period of life!</em> <span class="auth">(Ṣ and TA in art. <span class="ar">كلأ</span>.)</span> And <span class="ar long">فَعَلْتُ بِهِ مَا بَلَغَ بِهِ الأَذَى وَالمَكْرُوهْ</span> <span class="add">[<em>I did with him that which caused him to come to what was annoying,</em> or <em>hurtful, and evil</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَلَغَ بِهِ البِلَغِينَ</span>: see the last word of this phrase below.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blg_1_A3">
					<p><span class="ar">بُلِغَ</span>, like <span class="ar">عُنِىَ</span>, <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, jaded, harasssed, distressed, fatigued,</em> or <em>wearied.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blg_1_B1">
					<p><span class="ar">بَلُغَ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُغُ</span>}</span></add>,]</span> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَلَاغَةٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He was,</em> or <em>became</em> <span class="ar">بَلِيغ</span>, i. e. <span class="ar">فَصِيح</span> <span class="add">[more properly signifying <em>chaste,</em> or <em>perspicuous, in speech,</em> but here meaning <em>eloquent</em>]</span>; <span class="auth">(Ṣ,* Mṣb, Ḳ;)</span> and <em>sharp,</em> or <em>penetrating,</em> or <em>effective, in tongue;</em> <span class="auth">(Mṣb;)</span> <em>attaining, by his speech,</em> or <em>diction, the utmost scope of his mind and desire.</em> <span class="auth">(Ḳ,* TA.)</span> The difference between <span class="ar">بَلَاغَةٌ</span> and <span class="ar">فَصَاحَةٌ</span> is this: that the latter is an attribute of a single word and of speech and of the speaker; but the former is an attribute only of speech and the speaker: <span class="auth">(Kull:)</span> <span class="ar">بلاغة</span> in the speaker is <em>A faculty whereby one is enabled to compose language suitable to the exigency of the case,</em> i. e., <em>to the occasion of speaking</em> <span class="add">[<em>or writing</em>]</span>, <em>with chasteness,</em> or <em>perspicuity,</em> or <em>eloquence, thereof:</em> in language, it is <em>suitableness to the exigency of the case,</em> i. e., <em>to the occasion of speaking</em> <span class="add">[or <em>writing</em>]</span>, <em>with chasteness</em> or <em>perspicuity,</em> or <em>eloquence, thereof.</em> <span class="auth">(KT.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blg_2">
				<h3 class="entry">2. ⇒ <span class="ar">بلّغ</span></h3>
				<div class="sense" id="blg_2_A1">
					<p><span class="ar">تَبْلِيغٌ</span> and<span class="arrow"><span class="ar">إِبْلَاغٌ↓</span></span> <span class="add">[inf. ns. of <span class="ar">بلّغ</span> and <span class="ar">ابلغ</span>]</span> signify The <em>causing to reach, attain, arrive,</em> or <em>come; bringing, conveying,</em> or <em>delivering:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> the former is the more common. <span class="auth">(Er-Rághib, TA.)</span> <span class="add">[You say, <span class="ar long">بلّغهُ المَكَانَ</span> <em>He caused him,</em> or <em>it, to reach, attain, arrive at,</em> or <em>come to, the place.</em> And <span class="ar long">بلّغهُ مَقْصُودَهُ</span> <em>He caused him to attain his object of aim</em> or <em>endeavour</em>, &amp;c.]</span> And <span class="ar long">بَلَّغْتُ الرِّسَالَةَ</span> <span class="add">[<em>I brought, conveyed,</em> or <em>delivered, the message</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">بلّغهُ السَّلَامَ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">الخَبَرَ</span>, <span class="auth">(TA,)</span> as also<span class="arrow"><span class="ar">ابلغهُ↓</span></span>, <span class="auth">(Mṣb, TA,)</span> <em>He brought, conveyed, delivered,</em> or <em>communicated, to him the salutation,</em> <span class="auth">(Mṣb,)</span> and <em>he brought,</em>, &amp;c., or <em>told, to him the news,</em> or <em>information.</em> <span class="auth">(TA.)</span> <span class="add">[And <span class="ar long">بَلَّغَنِى عَنْ فُلَانٍ</span> <em>He told me from such a one,</em> or <em>on the part of such a one,</em> some piece of information, or that some event had happened, &amp;c.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blg_2_B1">
					<p><span class="ar long">بلّغ الفَارِسُ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> inf. n. <span class="ar">تَبْلِيغٌ</span>, <span class="auth">(Ḳ,)</span> <em>The horseman stretched forth,</em> or <em>extended, his hand,</em> or <em>arm, with the rein of his horse,</em> <span class="add">[or <em>gave the rein to his horse,</em>]</span> <em>in order that he might increase in his running.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="blg_2_C1">
					<p><span class="ar long">بلّغ الشَّيْبُ فِى رَأْسِهِ</span> <em>Hoariness began to appear on his head;</em> accord. to IAạr; as also <span class="ar">بلّع</span>, with the unpointed <span class="ar">ع</span>: the Basrees assert that the former is a mistranscription; but it is related as heard from Th, by Aboo-Bekr Eṣ-Ṣoolee. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blg_3">
				<h3 class="entry">3. ⇒ <span class="ar">بالغ</span></h3>
				<div class="sense" id="blg_3_A1">
					<p><span class="ar">بالغ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> inf. n. <span class="ar">مُبَالَغَةٌ</span> <span class="auth">(JK, Ḳ, &amp;c.)</span> and <span class="ar">بِلَاغٌ</span>, <span class="auth">(Ḳ.)</span> <em>He exceeded the usual,</em> or <em>ordinary,</em> or <em>the just,</em> or <em>proper, bounds,</em> or <em>degree,</em> in a thing; <em>acted egregiously,</em> or <em>immoderately,</em> or <em>extravagantly,</em> therein: <span class="auth">(KL:)</span> <em>he strove,</em> or <em>laboured; exerted himself,</em> or <em>his power</em> or <em>efforts</em> or <em>endeavours</em> or <em>ability; employed himself vigorously, strenuously, laboriously, sedulously, earnestly, with energy</em> or <em>effectiveness; took pains,</em> or <em>extraordinary pains:</em> <span class="auth">(Ḳ, TA:)</span> <em>he did not fall short of doing what was requisite,</em> or <em>what he ought; did not flag,</em> or <em>was not remiss:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> <em>he exerted unsparingly his power</em> or <em>ability,</em> or <em>effort</em> or <em>endeavour,</em> or <em>the utmost thereof:</em> <span class="auth">(Mṣb:)</span> <em>he accomplished,</em> or <em>did,</em> or <em>attained, the utmost of his power</em> or <em>ability,</em> or <em>effort</em> or <em>endeavour; he did his utmost:</em> <span class="auth">(JK:)</span> <span class="ar long">فِى أَمْرٍ</span> <span class="add">[<em>in an affair</em>]</span>: <span class="auth">(Ṣ, Ḳ, TA:)</span> or <span class="ar long">فِى كَذَا</span>, meaning <em>in the pursuit of such a thing.</em> <span class="auth">(Mṣb.)</span><span class="add">[<span class="ar long">بالغ فِى كَذَا</span> may be rendered as above, or <em>He did such a thing much, exceedingly, egregiously, extraordinarily, immoderately, extravagantly, excessively, vehemently, energetically, superlatively, excellently, consummately, thoroughly.</em> Hence <span class="ar">مُبَالَغَةٌ</span> in explanations of words; meaning <em>Intensiveness; muchness; extraordinariness; excessiveness; vehemence; energy; emphasis; hyperbole;</em>, &amp;c.; and sometimes, <em>frequentative signification.</em> Thus, <span class="ar long">إِسْمُ مُبَالَغَةٍ</span> means <em>A noun of intensiveness;</em> or <em>an intensive epithet:</em> as <span class="ar">شَكُورٌ</span> “very thankful,” or “very grateful;” and <span class="ar">حَمَّادٌ</span> “a great praiser,” or “a frequent praiser.”]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blg_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلغ</span></h3>
				<div class="sense" id="blg_4_A1">
					<p><span class="ar">ابلغ</span>, inf. n. <span class="ar">إِبْلَاغٌ</span>: <a href="#blg_2">see 2</a>, in two places. <span class="add">[Hence,]</span> <span class="ar long">ابلغ الأَمْرَ جَهْدَهُ</span> <span class="add">[<em>He brought his utmost power</em> or <em>ability,</em> or <em>effort</em> or <em>endeavour, to the performance,</em> or <em>accomplishment, of the affair</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">أَبْلَغْتُ إِلَيْهِ</span> i. e. <span class="ar long">فَعَلْتُ بِهِ مَا بَلَغَ بِهِ الأَذَى وَالمَكْرُوهَ</span> <span class="add">[<em>I did with him that which caused him to come to what was annoying,</em> or <em>hurtful, and evil</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blg_4_B1">
					<p><a href="#blg_1">See also 1</a>, first sentence; where it is said that <span class="ar">إِبْلَاغٌ</span> is syn. with <span class="ar">بُلُوغٌ</span>; but this is app. a mistake.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="blg_4_C1">
					<p><span class="add">[<span class="ar long">مَا أَبْلَغَهُ</span>, and <span class="ar long">أَبْلِغْ بِهِ</span>, <em>How eloquent is he!</em>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blg_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّغ</span></h3>
				<div class="sense" id="blg_5_A1">
					<p><span class="ar long">تبلّغ المَنْزِلَ</span> <em>He constrained himself to reach,</em> or <em>attain, the place of abode, until,</em> or <em>so that, he did reach</em> <span class="add">[<em>it</em>]</span>, or <em>attain</em> <span class="add">[<em>it</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="blg_5_A2">
					<p><span class="ar long">تبلّغ بِهِ</span> <em>He was satisfied,</em> or <em>content, with it,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>and attained his desire</em> <span class="add">[<em>thereby</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="blg_5_A3">
					<p><span class="ar long">تَبَلَّغَتْ بِهِ العِلَّةُ</span> <em>The disease,</em> or <em>malady, distressed him; afflicted him; became vehement,</em> or <em>severe, in him.</em> <span class="auth">(Ṣ, Z, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blg_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبالغ</span></h3>
				<div class="sense" id="blg_6_A1">
					<p><span class="ar long">تبالغ الدِّبَاغُ فِى الجِلْدِ</span> <em>The tan attained its utmost effect in the skin.</em> <span class="auth">(AḤn.)</span> And <span class="ar long">تبالغ فِيهِ الهَّمُ</span>, and <span class="ar">المَرَضَ</span>, <em>Anxiety,</em> or <em>disquietude of mind,</em> or <em>grief, attained its utmost degree in him,</em> and so <em>disease,</em> or <em>the disease.</em> <span class="auth">(TA.)</span> <span class="add">[This verb seems properly to signify <em>It reached,</em> or <em>attained, by degrees.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: 6.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blg_6_B1">
					<p><span class="ar long">تبالغ فِى كَلَامِهِ</span> <em>He affected eloquence</em> (<span class="ar">بَلَاغَة</span>) <em>in his speech, not being of those characterized thereby:</em> <span class="add">[whence]</span> one says, <span class="ar long">مَا هُوَ بِبَلِيغٍ وَلٰكِنْ يَتَبَالِغُ</span> <span class="add">[<em>He is not eloquent, but he affects eloquence</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balogN">
				<h3 class="entry"><span class="ar">بَلْغٌ</span></h3>
				<div class="sense" id="balogN_A1">
					<p><span class="ar">بَلْغٌ</span>: <a href="#bilogN">see what next follows</a>, in three places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلْغٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="balogN_B1">
					<p><a href="#baAligN">and see <span class="ar">بَالِغٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلْغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="balogN_B2">
					<p><a href="#baliygN">and <span class="ar">بَلِيغٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilogN">
				<h3 class="entry"><span class="ar">بِلْغٌ</span></h3>
				<div class="sense" id="bilogN_A1">
					<p><span class="ar long">ٱللّٰهُمَ سِمْعٌ لَا بِلْغٌ</span>, and<span class="arrow"><span class="ar long">سَمْعٌ لَا بَلْغٌ↓</span></span>, <span class="auth">(Ks, Fr, Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar long">سَمْعًا لَا بَلْغًا↓</span></span>, <span class="auth">(Ks, Ṣ, Ḳ,)</span> and <span class="ar long">سِمْعًا لَا بِلْغًا</span>, <span class="auth">(Ḳ,)</span> <em>O God, may we hear of it</em> <span class="auth">(or <em>may it be heard of,</em> IB)</span> <em>but may it not be fulfilled;</em> <span class="auth">(Fr, Ṣ, Ḳ;)</span> or, <em>may it not reach us,</em> or <em>come to us:</em> said on hearing of a displeasing, or hateful, or an evil, event: <span class="auth">(L:)</span> or on hearing tidings not pleasing to one: <span class="auth">(Ks, Ṣ, Ḳ:)</span> or on the coming of tidings not held to be true. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=12_s/197_smE">See also art. <span class="ar">سمع</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بِلْغٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bilogN_B1">
					<p><span class="ar long">أَحْمَقُ بِلْغٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَلْغٌ↓</span></span>, and<span class="arrow"><span class="ar">بَلْغَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>Stupid,</em> or <em>foolish, but, notwithstanding his stupidity,</em> or <em>foolishness, attaining his desire:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>stupid,</em> or <em>foolish, in the utmost degree:</em> <span class="auth">(Ḳ, TA:)</span> fem. <span class="ar long">حَمْقَآءُ بِلْغَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بِلْغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bilogN_B2">
					<p><span class="ar long">رَجُلٌ بِلْغٌ مِلْغٌ</span> <span class="auth">(Ṣ,* Ḳ)</span> <em>A man who is bad, evil,</em> or <em>wicked,</em> <span class="auth">(Fr, Ḳ,)</span> <em>in the utmost degree.</em> <span class="auth">(Fr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بِلْغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bilogN_B3">
					<p><a href="#baliygN">See also <span class="ar">بَلِيغٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bilagN">
				<h3 class="entry"><span class="ar">بِلَغٌ</span></h3>
				<div class="sense" id="bilagN_A1">
					<p><span class="ar">بِلَغٌ</span>: <a href="#baliygN">see <span class="ar">بَلِيغٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balogapN">
				<h3 class="entry"><span class="ar">بَلْغَةٌ</span></h3>
				<div class="sense" id="balogapN_A1">
					<p><span class="ar">بَلْغَةٌ</span>: <a href="#bilogN">see <span class="ar">بِلْغٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulogapN">
				<h3 class="entry"><span class="ar">بُلْغَةٌ</span></h3>
				<div class="sense" id="bulogapN_A1">
					<p><span class="ar">بُلْغَةٌ</span> <em>A sufficiency of the means of subsistence,</em> <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> <em>such that nothing remains over and above it:</em> <span class="auth">(T, Mṣb:)</span> and simply <em>a sufficiency; enough;</em> <span class="auth">(JK, Mṣb, TA;)</span> as also<span class="arrow"><span class="ar">بَلَاغٌ↓</span></span>, <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> meaning <em>a thing that suffices,</em> or <em>contents, and enables one to attain what he seeks;</em> <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">تَبَلُّغٌ↓</span></span>. <span class="auth">(JK, Mṣb, TA.)</span> You say, <span class="ar long">فِى هٰذَا بُلْغَةٌ</span>, and<span class="arrow"><span class="ar">بَلَاغٌ↓</span></span>, and<span class="arrow"><span class="ar">تَبَلُّغٌ↓</span></span>, <em>In this is a sufficiency,</em> or <em>enough.</em> <span class="auth">(Mṣb, TA.)</span> <span class="pb" id="Page_0252"></span>And it is said in the Ḳur <span class="add">[xxi. 106]</span>,<span class="arrow"><span class="ar long">إِنَّ فِى هٰذَا لَبَلَاغًا↓ لِقَوْمٍ عَابِدِينَ</span></span> <em>Verily in this is a sufficiency</em> <span class="add">[<em>for a people serving</em> God]</span>: <span class="auth">(Bḍ, TA:)</span> or <em>a means of attaining the object sought after,</em> or <em>desired.</em> <span class="auth">(Bḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilagonN">
				<h3 class="entry"><span class="ar">بِلَغْنٌ</span></h3>
				<div class="sense" id="bilagonN_A1">
					<p><span class="ar">بِلَغْنٌ</span>: <a href="#balaAgapN">see <span class="ar">بَلَاغَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بِلَغْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bilagonN_B1">
					<p>Also <em>A calumniator,</em> or <em>slanderer:</em> <span class="auth">(Kr, TA:)</span> or <em>one who conveys people's discourse to others.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Albulagiyna">
				<h3 class="entry"><span class="ar">البُلَغِينَ</span></h3>
				<div class="sense" id="Albulagiyna_A1">
					<p><span class="ar">البُلَغِينَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">البِلَغِينَ</span>, <span class="auth">(JK,)</span> or both, <span class="auth">(Ḳ,)</span> <em>Calamity, misfortune,</em> or <em>disaster:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>distress,</em> or <em>affliction.</em> <span class="auth">(JK.)</span> Hence the saying of ʼÁïsheh to ʼAlee, <span class="auth">(Ṣ, Ḳ,)</span> when she was taken prisoner <span class="add">[by him]</span>, <span class="auth">(Ṣ,)</span> <span class="ar long">بَلَغْتَ مِنَّا البُلَغِينَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">البِلَغِينَ</span>, <span class="auth">(Ḳ,)</span> i. e., <span class="ar">الدَّاهِيَةَ</span>; meaning<span class="arrow"><span class="ar long">بَلَغْتَ مِنَّا كُلَّ مَبْلَغٍ↓</span></span> <span class="add">[<em>Thou hast distressed us,</em> or <em>afflicted us, in the utmost degree</em>]</span>: <span class="auth">(Ḳ:)</span> it is said to mean that the war harassed her, and distressed her in the utmost degree. <span class="auth">(TA.)</span> It is like <span class="ar">البُرَحِينَ</span> <span class="add">[and <span class="ar">البِرَحِينَ</span>]</span> and <span class="ar">الأَطْوَرِينَ</span>; all meaning <em>calamities, misfortunes,</em> or <em>disasters:</em> <span class="auth">(AʼObeyd, TA:)</span> and is as though they said <span class="ar long">خَطْبٌ بِلَغٌ</span> <span class="add">[and <span class="ar">بُلَغٌ</span>]</span>, meaning <span class="ar">بَلِيغٌ</span>, and then formed the pl. thus because they considered calamities <span class="add">[as personified, i. e.,]</span> as rational beings having purpose, or design. <span class="auth">(IAth, TA.)</span> It is invariably thus, terminating with <span class="ar">ى</span> and <span class="ar">ن</span>: or one may say in the nom. case <span class="ar">البُلَغُونَ</span>, and in the accus. and gen. <span class="ar">البُلَغِينَ</span>. <span class="auth">(O, Ḳ.*)</span> You say also, <span class="ar long">بَلَغَ بِهِ البِلَغِينَ</span> <span class="add">[lit. <em>He caused him to come,</em> i. e. <em>he brought him, to calamity, misfortune,</em> or <em>disaster,</em> or <em>to distress,</em> or <em>affliction</em>]</span>; meaning <em>he went to the utmost point in reviling him, and annoying him,</em> or <em>molesting him.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaAgN">
				<h3 class="entry"><span class="ar">بَلَاغٌ</span></h3>
				<div class="sense" id="balaAgN_A1">
					<p><span class="ar">بَلَاغٌ</span> is a subst. from <span class="ar">تَبْلِيغٌ</span> and <span class="ar">إِبْلَاغٌ</span>, meaning The <em>bringing, conveyance, delivery,</em> or <em>communication,</em> <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> of a message <span class="add">[&amp;c.]</span>. <span class="auth">(Jel in iii. 19, &amp;c.)</span> <span class="add">[It often occurs in the Ḳur as meaning The <em>communication,</em> or <em>announcement,</em> of what is revealed.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلَاغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balaAgN_A2">
					<p>In a trad., in which it is said, <span class="ar long">كُلُّ رَافِعَةٍ رَفَعَتْ إِلَيْنَا مِنَ البَلَاغِ</span>, <span class="add">[in the CK <span class="ar long">رُفِعَتْ علينا</span>,]</span> it means <em>What is communicated,</em> or <em>announced,</em> (<span class="ar long">مَا بَلَغَ</span>,) <em>of the Ḳur-án and of the</em> <span class="add">[<em>statutes,</em> or <em>ordinances,</em>, &amp;c., <em>termed</em>]</span> <span class="ar">سُنَن</span>: or the meaning is, <span class="ar long">مِنْ ذَوِى البَلَاغِ</span>, i. e., <span class="ar">التَّبْلِيغِ</span>, <span class="add">[<em>of those who have the office of communicating,</em> or <em>announcing,</em>]</span> the simple subst. being put in the place of the inf. n.: <span class="auth">(Ḳ, TA:)</span> but some relate it differently, saying <span class="arrow"><span class="ar long">مِنَ البُلَّاغِ↓</span></span> <span class="add">[<em>of the communicators,</em> or <em>announcers,</em>]</span> like <span class="ar">حُدَّاث</span> in the sense of <span class="ar">مُحَدِّثُون</span>: <span class="auth">(TA:)</span> and some say, <span class="arrow"><span class="ar long">مِنَ البِلَاغِ↓</span></span>, meaning <span class="ar long">مِنَ المُبَالِغِينَ فِى التَّبْلِيغِ</span>, i. e. <em>of those who do their utmost in communicating,</em> or <em>announcing.</em> <span class="auth">(Hr, Ḳ.)</span> <span class="add">[<a href="#rfE_1">See this trad. cited and explained more fully in the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=10_r/161_rfE">of art. <span class="ar">رفع</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلَاغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balaAgN_A3">
					<p><span class="ar long">هٰذَا بَلَاغٌ لِلنَّاسِ</span>, in the Ḳur <span class="add">[xiv. last verse]</span>, means <em>This</em> Ḳur-án contains <em>a sufficient exposition,</em> or <em>demonstration, for men.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلَاغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balaAgN_A4">
					<p><a href="#bulogapN">See also <span class="ar">بُلْغَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bilaAgN">
				<h3 class="entry"><span class="ar">بِلَاغٌ</span></h3>
				<div class="sense" id="bilaAgN_A1">
					<p><span class="ar">بِلَاغٌ</span>: <a href="#balaAgN">see <span class="ar">بَلَاغٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baliygN">
				<h3 class="entry"><span class="ar">بَلِيغٌ</span></h3>
				<div class="sense" id="baliygN_A1">
					<p><span class="ar">بَلِيغٌ</span> <em>i. q.</em> <span class="ar">فَصِيحٌ</span> <span class="add">[properly signifying <em>Chaste in speech,</em> but here meaning <em>eloquent</em>]</span>; <span class="auth">(Ṣ,* Mṣb, Ḳ;)</span> <em>sharp,</em> or <em>penetrating,</em> or <em>effective, in tongue;</em> <span class="auth">(Mṣb;)</span> one <em>who attains, by his speech,</em> or <em>diction, the utmost scope of his mind and desire;</em> <span class="auth">(Ḳ,* TA;)</span> <span class="add">[<em>possessing the faculty of</em> <span class="ar">بَلَاغَة</span>; (<a href="#baluga">see <span class="ar">بَلُغَ</span></a>;)]</span> as also<span class="arrow"><span class="ar">بَلْغٌ↓</span></span>, and<span class="arrow"><span class="ar">بِلْغٌ↓</span></span>, and<span class="arrow"><span class="ar">بِلَغٌ↓</span></span>, and<span class="arrow"><span class="ar">بَلضاغَى↓</span></span>, like <span class="ar">سَكَارَى</span>, <span class="add">[in the CK like <span class="ar">سُكَارَى</span>,]</span> and<span class="arrow"><span class="ar">بُلَاغَي↓</span></span>, like <span class="ar">حُبَارَى</span>: <span class="auth">(Ḳ:)</span> or<span class="arrow"><span class="ar">بَلْغٌ↓</span></span> signifies a man <em>who does not commit mistakes often in his speech:</em> <span class="auth">(JK:)</span> <a href="#baliygN">the pl. of <span class="ar">بَلِيغٌ</span></a> is <span class="ar">بُلَغَآءُ</span>. <span class="auth">(TA.)</span> Applied to a saying, <span class="add">[&amp;c.,]</span> it also signifies <em>Effectual,</em> or <em>producing an effect.</em> <span class="auth">(Ksh and Bḍ and Jel in iv. 66.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلِيغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baliygN_A2">
					<p><span class="add">[Also <em>Surpassing</em> in any quality: and <em>superlative.</em>]</span> It is also applied to a calamity or the like <span class="add">[as meaning <em>Great, severe, distressing,</em> or <em>afflictive</em>]</span>. <span class="auth">(IAth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaAgapN">
				<h3 class="entry"><span class="ar">بَلَاغَةٌ</span></h3>
				<div class="sense" id="balaAgapN_A1">
					<p><span class="ar">بَلَاغَةٌ</span> <em>i. q.</em> <span class="ar">فَصَاحَةٌ</span>, <span class="add">[as meaning <em>Eloquence;</em> (<a href="#baluga">see <span class="ar">بَلُغَ</span></a>, of which it is the inf. n.;)]</span> <span class="auth">(Ṣ, Mṣb,*)</span> as also<span class="arrow"><span class="ar">بِلَغْنٌ↓</span></span>. <span class="auth">(Seer, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَلَاغَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balaAgapN_A2">
					<p>And <span class="add">[the pl.]</span> <span class="ar">بَلَاغَاتٌ</span> <em>Slanders,</em> or <em>calumnies.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balaAgae">
				<h3 class="entry"><span class="ar">بَلَاغَى</span> / <span class="ar">بُلَاغَى</span></h3>
				<div class="sense" id="balaAgae_A1">
					<p><span class="ar">بَلَاغَى</span> and <span class="ar">بُلَاغَى</span>: <a href="#baliygN">see <span class="ar">بَلِيغٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulBaAgN">
				<h3 class="entry"><span class="ar">بُلَّاغٌ</span></h3>
				<div class="sense" id="bulBaAgN_A1">
					<p><span class="ar">بُلَّاغٌ</span>: <a href="#balaAgN">see <span class="ar">بَلَاغٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAligN">
				<h3 class="entry"><span class="ar">بَالِغٌ</span></h3>
				<div class="sense" id="baAligN_A1">
					<p><span class="ar">بَالِغٌ</span> <em>Reaching, attaining, arriving at,</em> or <em>coming to,</em> a place <span class="add">[or time, or an affair or a state or an event that is meditated or intended or determined or appointed; <em>reaching,</em>, &amp;c., <em>to the utmost point</em> or <em>degree:</em> and sometimes, <em>being at the point of reaching</em>, &amp;c.: <a href="#blg_1">see 1</a>, first sentence]</span>. <span class="auth">(TA.)</span> You say also,<span class="arrow"><span class="ar long">جَيْشٌ بَلْغٌ↓</span></span>, meaning <span class="ar">بَالِغٌ</span> <span class="add">[<em>An army reaching,</em> or <em>arriving at, its appointed place</em>]</span>. <span class="auth">(Ḳ, TA.)</span> And<span class="arrow"><span class="ar long">أَمْرُ ٱللّٰهِ بَلْغٌ↓</span></span>, i. e. <span class="ar">بَالِغٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> meaning <span class="add">[<em>The decree of God</em>]</span> <em>reacheth,</em> or <em>attaineth, its intended object:</em> <span class="auth">(Ḳ:)</span> from the saying in the Ḳur <span class="add">[lxv. 3]</span>, <span class="ar long">إِنَّ ٱللّٰهَ بَالِغٌ أَمْرَهُ</span> <span class="auth">(Ṣ)</span> <em>Verily God attaineth his purpose.</em> <span class="auth">(Bḍ, Jel.)</span> And <span class="ar long">بَالِغٌ فِى الحُمْقِ</span> <em>Reaching the utmost point,</em> or <em>degree, in stupidity,</em> or <em>foolishness.</em> <span class="auth">(TA.)</span> And <span class="ar long">لَزِمَهُ ذٰلِكَ بَالِغًا مَا بَلَغَ</span>: <a href="#blg_1">see 1</a>: and see the sentence there next following it. <span class="auth">(Mṣb.)</span> <span class="ar long">أَيْمَانٌ بَالِغَةٌ</span>, in the Ḳur lxviii. 39, means <em>Firm covenants:</em> <span class="auth">(Jel:)</span> or <em>covenants confirmed by oaths in the utmost degree:</em> <span class="auth">(Bḍ:)</span> or <em>rendered obligatory for ever; sworn to, that they shall be constantly observed:</em> or <em>that have reached their utmost point:</em> <span class="auth">(Th, TA:)</span> or <span class="ar long">يَمِينٌ بَالِغَةٌ</span> means <span class="add">[<em>an oath,</em> or <em>a covenant,</em>]</span> <em>confirmed.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَالِغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAligN_A2">
					<p><em>Attaining,</em> or <em>having attained, to puberty, virility, ripeness,</em> or <em>maturity;</em> applied to a boy: <span class="auth">(T, IḲooṭ, IḲṭṭ, Mṣb:)</span> and in like manner, without <span class="ar">ة</span>, applied to a girl; <span class="auth">(T, IAmb, Mṣb, Ḳ;)</span> thus applied, with the mention of the noun qualified by it, by Esh-Sháfiʼee <span class="auth">(T, Mṣb)</span> and other chaste persons, of the Arabs; <span class="auth">(T, TA;)</span> or <span class="ar">بَالِغَةٌ</span>; <span class="auth">(IḲooṭ, Mṣb;)</span> or the latter is also thus applied, with the mention of the noun which it qualifies, <span class="auth">(T, Mṣb, Ḳ,)</span> not being wrong because it is the original form; <span class="auth">(T, TA;)</span> and seems to be necessarily used when the noun which it qualifies is not mentioned, to prevent ambiguity. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">بَالِغٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAligN_A3">
					<p><em>A good, a goodly,</em> or an <em>excellent,</em> thing. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabolagu">
				<h3 class="entry"><span class="ar">أَبْلَغُ</span></h3>
				<div class="sense" id="Oabolagu_A1">
					<p><span class="ar">أَبْلَغُ</span> <span class="add">[<em>More,</em> and <em>most, effectual or efficacious:</em> <a href="#baliygN">see <span class="ar">بَلِيغٌ</span></a>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">أَبْلَغُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabolagu_A2">
					<p><span class="ar long">ثَنَآءٌ أَبْلَغُ</span> <em>i. q.</em><span class="arrow"><span class="ar long">مُبَالَغٌ↓ فِيهِ</span></span> <span class="add">[<em>Praise,</em> or <em>eulogy,</em> or <em>commendation, in which the usual,</em> or <em>ordinary,</em> or <em>the just,</em> or <em>proper, bounds are exceeded; such as is egregious,</em> or <em>immoderate,</em> or <em>extravagant;</em>, &amp;c.: <a href="#blg_3">see 3</a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taboligapN">
				<h3 class="entry"><span class="ar">تَبْلِغَةٌ</span></h3>
				<div class="sense" id="taboligapN_A1">
					<p><span class="ar">تَبْلِغَةٌ</span> <em>A rope,</em> or <em>cord, with which the main well-rope</em> (<span class="ar">الرِّشَآء</span>) <em>is joined to</em> <span class="add">[<em>that which is called</em>]</span> <em>the</em> <span class="ar">كَرَب</span>: <span class="auth">(Ḳ:)</span> or <em>a rope,</em> or <em>cord, that is joined to the</em> <span class="ar">رِشَآء</span> <em>so that it may reach the water:</em> <span class="auth">(Z, TA:)</span> pl. <span class="ar">تَبَالِغُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغ</span> - Entry: <span class="ar">تَبْلِغَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taboligapN_A2">
					<p>Also <em>A thong that is wound upon the curved extremity of a bow, where the bow-string ends, three times, or four, in order that the bow-string may become firm,</em> or <em>fast.</em> <span class="auth">(AḤn, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabalBugN">
				<h3 class="entry"><span class="ar">تَبَلُّغٌ</span></h3>
				<div class="sense" id="tabalBugN_A1">
					<p><span class="ar">تَبَلُّغٌ</span> <span class="add">[an inf. n. <span class="auth">(of 5, q. v.,)</span> used as a subst.]</span>: <a href="#bulogapN">see <span class="ar">بُلْغَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabolagN">
				<h3 class="entry"><span class="ar">مَبْلَغٌ</span></h3>
				<div class="sense" id="mabolagN_A1">
					<p><span class="ar">مَبْلَغٌ</span> <span class="add">[The <em>place,</em> and the <em>time, which a person,</em> or <em>thing, reaches, attains, arrives at,</em> or <em>comes to:</em> the <em>utmost point to which,</em> or <em>towards which, one tends,</em> or <em>repairs,</em> or <em>betakes himself; to which one directs his course;</em> or <em>which one seeks, pursues, endeavours to reach, desires, intends,</em> or <em>purposes; whether it be a place, or a time, or any affair or state or event that is meditated or intended or determined or appointed:</em> (<a href="#blg_1">see 1</a>, first sentence:)]</span> the <em>utmost point,</em> or <em>scope,</em> or <em>degree,</em> of knowledge <span class="add">[and of any attainment]</span>: <span class="auth">(Bḍ and Jel in liii. 31:)</span> <span class="add">[the <em>utmost degree of proficiency: a consummate degree</em> of goodness and of any other quality: the <em>age of puberty, virility, ripeness,</em> or <em>maturity:</em> the <em>sum, amount,</em> or <em>product, resulting from addition</em> or <em>multiplication: a sum of money:</em> and particularly <em>a considerable sum thereof:</em> and]</span> <em>cash,</em> or <em>ready money, consisting of dirhems</em> and <em>of deenárs:</em> in this sense, post-classical: pl. <span class="ar">مَبَالِغُ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">بَلَغَ فُلَانٌ مَبْلَغَهُ</span> and <span class="ar">مَبْلَغَتَهُ</span>: and <span class="ar long">بَلَغَ فِى العِلْمِ المَبَالِغَ</span>: and <span class="ar long">بَلَغَ فِى الجَوْدَةِ مَبْلَغًا</span>, and <span class="ar long">مِنَ الجَوْدَةِ</span>: <a href="#blg_1">for explanations of all which, see 1</a>. And <span class="ar long">بَلَغْتَ مِنَّا كُلَّ مَبْلَغٍ</span>: <a href="#Albulagiyna">see <span class="ar">البُلَغِينَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabolagatahu">
				<h3 class="entry"><span class="ar">مَبْلَغَتَهُ</span></h3>
				<div class="sense" id="mabolagatahu_A1">
					<p><span class="ar long">بَلَغَ فُلَانٌ مَبْلَغَتَهُ</span>: <a href="#blg_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubalBigN">
				<h3 class="entry"><span class="add">[<span class="ar">مُبَلِّغٌ</span>]</span></h3>
				<div class="sense" id="mubalBigN_A1">
					<p><span class="add">[<span class="ar">مُبَلِّغٌ</span> <em>One whose office it is, with other persons each of whom is thus called, to chant certain words, as the</em> <span class="ar">إِقَامَة</span> <em>&amp;c., in a mosque.</em> <span class="auth">(See my “Modern Egyptians, “ch. iii.)</span>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboluwgN">
				<h3 class="entry"><span class="ar">مَبْلُوغٌ</span></h3>
				<div class="sense" id="maboluwgN_A1">
					<p><span class="ar long">هُوَ مَبْلُوغٌ بِهِ</span> <span class="add">[<em>He is caused to reach, attain, arrive at,</em> or <em>come to, his appointed end,</em> or <em>term of life,</em> (<span class="ar">أَجَلَهُ</span>, or the like, being understood,)]</span> is said of the object of the phrase <span class="ar long">بَلَغَ ٱللّٰهُ بِهِ</span> <span class="add">[which see, and the phrase next following it]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubaAlagN">
				<h3 class="entry"><span class="ar">مُبَالَغٌ</span></h3>
				<div class="sense" id="mubaAlagN_A1">
					<p><span class="ar long">ثَنَآءٌ مُبَالَغٌ فِيهِ</span>: <a href="#Oabolagu">see <span class="ar">أَبْلَغُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0250.pdf" target="pdf">
							<span>Lanes Lexicon Page 250</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0251.pdf" target="pdf">
							<span>Lanes Lexicon Page 251</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0252.pdf" target="pdf">
							<span>Lanes Lexicon Page 252</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
