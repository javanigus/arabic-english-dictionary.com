<article class="root" id="Root_bxq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/038_bxE">بخع</a></span>
				<span class="ar">بخق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/040_bxl">بخل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخق</span></h3>
				<div class="sense" id="bxq_1_A1">
					<p><span class="ar">بَخِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَقُ</span>}</span></add>; and <span class="ar">بَخَقَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْخُقُ</span>}</span></add>; <em>He had that affection of an eye which is termed</em> <span class="ar">بَخَقُ</span>, explained below. <span class="auth">(Ḳ.)</span> <span class="add">[And,]</span> accord. to ISd, <span class="ar long">بَخَقَتْ عَيْنُهُ</span>, and <span class="ar">بَخِقَتْ</span>, <em>His eye went away;</em> or <em>perished:</em> and <em>i. q.</em> <span class="ar">عَارَتْ</span> <span class="add">[<em>his eye became blind;</em> or <em>became wanting;</em> or <em>sank in its socket</em>]</span>: the more approved form is <span class="add">[<span class="ar">بَخَقَتْ</span>,]</span> with fet-ḥ <span class="add">[to the medial radical]</span>: and it is also explained as meaning <span class="ar">فُقِئَتْ</span> <span class="add">[<em>it was put out;</em> or <em>was blinded;</em>, &amp;c.]</span>: <span class="auth">(TA:)</span> or, accord. to the Mj, <span class="ar long">بَخِقَتِ العَيْنُ</span> signifies <em>the flesh</em> <span class="add">[app. meaning <em>the bulb,</em> which is also termed the <span class="ar">شَحْمَة</span>,]</span> <em>of the eye disappeared:</em> and the epithet applied to the eye in this case is <span class="arrow"><span class="ar">بَخْقَآءُ↓</span></span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بخق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bxq_1_B1">
					<p><span class="ar long">بَخَقَ عَيْنَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَقُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَخْقٌ</span>, <span class="auth">(Ṣ,)</span> <em>i. q.</em> <span class="ar">عَوَّرَهَا</span> <span class="add">[<em>He put out his eye;</em> or <em>made it to sink in its socket</em>]</span>; <span class="auth">(Lth, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَبْخَقَهَا↓</span></span>: <span class="auth">(TA:)</span> or the former, <span class="auth">(Mgh,)</span> and<span class="arrow">↓</span> the latter, <span class="auth">(AA, Ḳ, TA,)</span> <em>i. q.</em> <span class="ar">فَقَأَهَا</span> <span class="add">[<em>he put it out;</em> or <em>blinded it;</em>, &amp;c.]</span>. <span class="auth">(AA, Mgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bxq_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابخق</span></h3>
				<div class="sense" id="bxq_4_A1">
					<p><a href="#bxq_1">see 1</a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بخق</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bxq_4_B1">
					<p><a href="#bxq_7">and see also 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxq_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبخق</span></h3>
				<div class="sense" id="bxq_7_A1">
					<p><span class="ar long">اِنْبَخَقَتِ العَيْنُ</span>, so in the Moḥeeṭ; accord. to the Ḳ, <span class="arrow"><span class="ar">أَبْخَقَت↓</span></span>, but this is wrong; <em>i. q.</em> <span class="ar">نَدَرَت</span> <span class="add">[<em>The eye fell out from its place;</em> or <em>became displaced</em>]</span>; as in the Ḳ. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxaqN">
				<h3 class="entry"><span class="ar">بَخَقٌ</span></h3>
				<div class="sense" id="baxaqN_A1">
					<p><span class="ar">بَخَقٌ</span> <span class="add">[<a href="#bxq_1">app. inf. n. of <span class="ar">بَخِقَ</span></a>: and, as a simple subst.,]</span> The <em>worst,</em> or <em>most unseemly, kind of</em> <span class="ar">عَوَر</span> <span class="add">[or <em>blindness of one eye,</em> or <em>loss thereof,</em>, &amp;c.]</span>, <em>and that in which there is most</em> <span class="add">[<em>of the foul matter termed</em>]</span> <span class="ar">غَمَص</span>: <span class="add">[in the CK, for <span class="ar long">أَكْثَرُهُ غَمَصًا</span>, is erroneously put <span class="ar long">اَكْثَرُهُ غَمْضًا</span>; and so I find in the JK:]</span> or the <em>state in which the edge of one's eyelid</em> (<span class="ar long">شُفْرُ عَيْنِهِ</span> <span class="add">[in the CK <span class="ar long">شُفْرُ عَيْنَيْهِ</span>]</span>) <em>will not meet the black,</em> or <em>part surrounded by the white:</em> <span class="auth">(Lth, Ḳ:)</span> or <em>blindness of one eye</em> (<span class="ar">عَوَرٌ</span>) <em>by the disappearance, in the head, of the black,</em> or <em>part surrounded by the white:</em> <span class="auth">(Ṣ:)</span> or the <em>disappearance of that part of the eye, in the head, after blindness of the eye:</em> <span class="auth">(Sh, TA:)</span> or the <em>having the sight gone, but the eye remaining open, blind,</em> or <em>white and blind, but still whole.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxiyqN">
				<h3 class="entry"><span class="ar">بَخِيقٌ</span> / <span class="ar">بَخِيقَةٌ</span></h3>
				<div class="sense" id="baxiyqN_A1">
					<p><span class="ar">بَخِيقٌ</span>, and with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَخِيقَةٌ</span>}</span></add>: <a href="#Oaboxaqu">see <span class="ar">أَبْخَقُ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAxiqN">
				<h3 class="entry"><span class="ar">بَاخِقٌ</span> / 
							<span class="ar">بَاخِقُ</span> / 
							<span class="ar">بَاخِقَةٌ</span></h3>
				<div class="sense" id="baAxiqN_A1">
					<p><span class="ar long">بَاخِقُ العَيْنُ</span> and <span class="ar long">عَيْنٌ بَاخِقَةٌ</span>: <a href="#Oaboxaqu">see <span class="ar">أَبْخَقُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboxaqu">
				<h3 class="entry"><span class="ar">أَبْخَقُ</span></h3>
				<div class="sense" id="Oaboxaqu_A1">
					<p><span class="ar long">رَجُلٌ أَبْخَقُ</span>, and<span class="arrow"><span class="ar">بَخِيقٌ↓</span></span> and<span class="arrow"><span class="ar long">بَاخِقُ↓ العَيْنِ</span></span> and<span class="arrow"><span class="ar long">مَبْخُوقُ↓ العَيْنِ</span></span> all signify the same; <span class="auth">(Ḳ;)</span> i. e. <em>A man blind of one eye; or wanting one eye;</em> or <em>having one of his eyes sunk in its socket;</em> or <em>having one of his eyes dried up;</em> syn. <span class="ar">أَعْوَرُ</span>: <span class="auth">(TA:)</span> <span class="add">[or <em>having that affection of an eye which is termed</em> <span class="ar">بَخَقٌ</span>:]</span> and in like manner <span class="ar">بَخْقَآءُ</span> applied to a sheep or goat for sacrifice on the occasion of the pilgrimage signifies <span class="ar">عَوْرَآءُ</span> <span class="add">[<em>blind of one eye;</em>, &amp;c.]</span>; <span class="auth">(Mgh, TA;)</span> or, as some say, <em>having an eye of which the black,</em> or <em>part surrounded by the white, has disappeared in the head.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">عَيْنٌ بَخْقَآءُ</span> and<span class="arrow"><span class="ar">بَاخِقَةٌ↓</span></span> and<span class="arrow"><span class="ar">بَخِيقٌ↓</span></span> and<span class="arrow"><span class="ar">بَخِيقَةٌ↓</span></span> <em>i. q.</em> <span class="ar">عَوْرَآءُ</span> <span class="add">[<em>An eye that is blind;</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> <a href="#bxq_1">see also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboxuwqu">
				<h3 class="entry"><span class="ar">مَبْخُوقُ</span></h3>
				<div class="sense" id="maboxuwqu_A1">
					<p><span class="ar long">مَبْخُوقُ العَيْنِ</span>: <a href="#Oaboxaqu">see <span class="ar">أَبْخَقُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0160.pdf" target="pdf">
							<span>Lanes Lexicon Page 160</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
