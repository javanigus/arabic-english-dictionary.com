<article class="root" id="Root_bqm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/159_bql">بقل</a></span>
				<span class="ar">بقم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/161_bqw">بقو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baqBamN">
				<h3 class="entry"><span class="ar">بَقَّمٌ</span></h3>
				<div class="sense" id="baqBamN_A1">
					<p><span class="ar">بَقَّمٌ</span> <span class="add">[<em>Brazil-wood;</em> the <em>wood of the Braziltree, a species of Cæsalpinia;</em>]</span> <em>a well-known dye;</em> <span class="auth">(Ṣ, Mṣb;)</span> <em>i. q.</em> <span class="ar">عَنْدَمٌ</span>; <span class="auth">(Ṣ;)</span> <span class="add">[or rather the <em>wood from which a well-known dye is prepared;</em>]</span> the <em>wood of a certain great tree, the leaves of which are like those of the almond, and having a red stem, the decoction of which is used as a dye: it consolidates wounds, stops a flow of blood from any member, and dries up ulcers; and its root,</em> or <em>lowest part, is an instantaneous poison:</em> <span class="auth">(Ḳ:)</span> the word is said by some to be Arabic; <span class="auth">(Mṣb;)</span> others say that it is arabicized; <span class="auth">(Ṣ, Mṣb, TA;)</span> <span class="add">[perhaps from the Persian <span class="ar">بَقَمْ</span>, or <span class="ar">بَكَمْ</span>;]</span> and that the only other words of the same measure in the Arabic language are proper names, and four in number, <span class="auth">(Ṣ TA,)</span> or seven: <span class="auth">(TA:)</span> if used as a proper name, it is imperfectly decl., because determinate and of the measure of a verb. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0237.pdf" target="pdf">
							<span>Lanes Lexicon Page 237</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
