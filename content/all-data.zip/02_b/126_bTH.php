<article class="root" id="Root_bTH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/125_bTO">بطأ</a></span>
				<span class="ar">بطح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/127_bTx">بطخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTH_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطح</span></h3>
				<div class="sense" id="bTH_1_A1">
					<p><span class="ar">بَطَحَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْطَحُ</span>}</span></add>, <span class="auth">(Mṣb, TA,)</span> inf. n. <span class="ar">بَطْحٌ</span>, <span class="auth">(Mgh, TA,)</span> <em>He spread it; spread it out,</em> or <em>forth; expanded it; extended it.</em> <span class="auth">(Mgh,* Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTH_1_A2">
					<p>Also, <span class="auth">(Ṣ, A, Ḳ,)</span> or <span class="ar long">بَطَحَهُ عَلَى وَجْهِهِ</span>, <span class="auth">(Mgh, Mṣb,)</span> aor. as above, <span class="auth">(Ḳ,)</span> and so the inf. n., <span class="auth">(TA,)</span> <em>He threw him down upon his face.</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTH_1_A3">
					<p><a href="#bTH_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTH_2">
				<h3 class="entry">2. ⇒ <span class="ar">بطّح</span></h3>
				<div class="sense" id="bTH_2_A1">
					<p><span class="ar long">بطّح المَسْجِدَ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَبْطِيحٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">ابطحهُ↓</span></span>; <span class="auth">(TA;)</span> <em>He strewed pebbles in the mosque, and made it plain,</em> or <em>level</em> <span class="add">[<em>in its ground,</em> or <em>floor</em>]</span>: <span class="auth">(Ḳ, TA:)</span> and <span class="ar">بَطْحُهُ</span>, <span class="add">[inf. n. of <span class="arrow"><span class="ar">بَطَحَهُ↓</span></span>,]</span> occurring in a trad., also signifies the <em>making it plain,</em> or <em>level.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bTH_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطح</span></h3>
				<div class="sense" id="bTH_4_A1">
					<p><a href="#bTH_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTH_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبطّح</span></h3>
				<div class="sense" id="bTH_5_A1">
					<p><span class="ar">تبطّح</span>: <a href="#bTH_7">see 7</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTH_5_A2">
					<p>Also <em>It</em> <span class="auth">(a torrent)</span> <em>flowed widely:</em> <span class="auth">(ISd, A:)</span> or <em>spread widely in the</em> <span class="ar">بَطْحَآء</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTH_5_A3">
					<p>Also, <span class="add">[and<span class="arrow"><span class="ar">انبطح↓</span></span>,]</span> <em>It</em> <span class="auth">(a place, &amp;c.)</span> <em>spread; spread out,</em> or <em>forth; became expanded</em> or <em>extended.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bTH_5_B1">
					<p>And <em>i. q.</em> <span class="ar">اِنْتَصَبَ</span> <span class="add">[<em>It became set up</em> or <em>upright, erected,</em>, &amp;c.: thus the verb bears two contr. significations]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bTH_5_C1">
					<p>Also <em>He</em> <span class="auth">(a man)</span> <em>took the</em> <span class="ar">أَبْطَح</span> <em>as a place of abode.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTH_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبطح</span></h3>
				<div class="sense" id="bTH_7_A1">
					<p><span class="ar">انبطح</span> <em>It</em> <span class="auth">(water)</span> <em>went to the right and left</em> in a place. <span class="auth">(AA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTH_7_A2">
					<p><a href="#bTH_5">See also 5</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTH_7_A3">
					<p><em>He became thrown down upon his face:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> or <em>he lay,</em> or <em>lay as though thrown down</em> or <em>extended,</em> upon his face: <span class="auth">(Mgh, Mṣb:)</span> or <em>he stretched himself;</em> or <em>lay, and stretched himself; upon his face, extended upon the ground;</em> as also<span class="arrow"><span class="ar">تبطّح↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTH_7_A4">
					<p><em>It</em> <span class="auth">(a valley)</span> <em>became wide;</em> <span class="auth">(Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">استبح↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bTH_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبطح</span></h3>
				<div class="sense" id="bTH_10_A1">
					<p><a href="#bTH_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baTiHN">
				<h3 class="entry"><span class="ar">بَطِحٌ</span></h3>
				<div class="sense" id="baTiHN_A1">
					<p><span class="ar">بَطِحٌ</span>: <a href="#OaboTaHu">see <span class="ar">أَبْطَحُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baToHapN">
				<h3 class="entry"><span class="ar">بَطْحَةٌ</span></h3>
				<div class="sense" id="baToHapN_A1">
					<p><span class="ar">بَطْحَةٌ</span> The <em>stature</em> of a man <span class="add">[app. in a lying posture]</span>: as in the phrase <span class="ar long">هُوَ بَطْحَةٌ رَجُلٍ</span> <span class="add">[<em>It is</em> of <em>the stature of a man</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: <span class="ar">بَطْحَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baToHapN_A2">
					<p><span class="ar long">بَيْنَهُمَا بَطْحَةٌ بَعِيدَةٌ</span> <em>Between them two is a far-extending distance</em> or <em>space</em> or <em>interval.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطح</span> - Entry: <span class="ar">بَطْحَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baToHapN_A3">
					<p><a href="#OaboTaHu">See also <span class="ar">أَبْطَحُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baToHaMCu">
				<h3 class="entry"><span class="ar">بَطْحَآءُ</span></h3>
				<div class="sense" id="baToHaMCu_A1">
					<p><span class="ar">بَطْحَآءُ</span>: <a href="#OaboTaHu">see <span class="ar">أَبْطَحُ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biTaAHN">
				<h3 class="entry"><span class="ar long">بِطَاحٌ بُطَّحٌ</span></h3>
				<div class="sense" id="biTaAHN_A1">
					<p><span class="ar long">بِطَاحٌ بُطَّحٌ</span> <span class="add">[<em>Many wide water-courses in which are fine,</em> or <em>minute,</em> or <em>broken, pebbles:</em> the former word <a href="#OaboTaHu">is pl. of <span class="ar">أَبْطَحُ</span></a> <a href="#baToHaACu">or of <span class="ar">بَطْحَآءُ</span></a>]</span>: a phrase like <span class="ar long">أَعْوَامٌ عُوَّمٌ</span>. <span class="auth">(Aṣ, AʼObeyd, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baTiyHapN">
				<h3 class="entry"><span class="ar">بَطِيحَةٌ</span></h3>
				<div class="sense" id="baTiyHapN_A1">
					<p><span class="ar">بَطِيحَةٌ</span>: <a href="#OaboTaHu">see <span class="ar">أَبْطَحُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baATiHN">
				<h3 class="entry"><span class="ar">بَاطِحٌ</span></h3>
				<div class="sense" id="baATiHN_A1">
					<p><span class="ar">بَاطِحٌ</span> applied to a man, <em>i. q.</em><span class="arrow"><span class="ar">مُنْبَطِحٌ↓</span></span> <span class="add">[part. n. of 7, q. v.]</span>. <span class="auth">(Ḥam p. 244.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboTaHu">
				<h3 class="entry"><span class="ar">أَبْطَحُ</span></h3>
				<div class="sense" id="OaboTaHu_A1">
					<p><span class="ar">أَبْطَحُ</span>, originally an epithet <span class="add">[and therefore imperfectly decl.]</span>, <span class="auth">(M, TA,)</span> that is, an epithet converted into a subst., and not used as an epithet, <span class="auth">(Ḥam p. 21,)</span> <em>A wide water-course,</em> or <em>channel of a torrent, in which are fine,</em> or <em>minute,</em> or <em>broken, pebbles;</em> <span class="auth">(Ṣ, A, Ḳ, and Ḥam ubi suprà;)</span> so called because the water goes in it to the right and left; <span class="add">[i. e. spreads widely; <a href="#bTH_7">see 7</a>;]</span> <span class="auth">(AA;)</span> as also<span class="arrow"><span class="ar">بَطْحَآءُ↓</span></span>, <span class="auth">(Ṣ, A, Ḳ, Ḥam,)</span> fem. of the former, and, like it, an epithet converted into a subst.; <span class="auth">(Ḥam ubi suprà;)</span> and<span class="arrow"><span class="ar">بَطِيحَةٌ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَطِحٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or <em>a water-course,</em> or <em>channel of a torrent, in which are sand and pebbles;</em> as also<span class="arrow"><span class="ar">بَطْحَآءُ↓</span></span>: <span class="auth">(Mgh:)</span> or a <em>wide place</em> <span class="add">[app. <em>in a water-course</em>]</span>; as also<span class="arrow"><span class="ar">بطحة↓</span></span> <span class="add">[app. <span class="ar">بَطْحَةٌ</span>, which is explained by Freytag, but without his stating on what authority, as signifying <em>a depressed place through which water flows, abounding with pebbles;</em> as is also <span class="ar">بِطْحَةٌ</span>; and in like manner Golius explains the former, but mentions the latter <a href="#bTyHp">as a pl. of <span class="ar">بطيحة</span></a>]</span>: <span class="auth">(Mṣb:)</span> or, accord. to AḤn, the <em>bottom of a water-course,</em> or <em>channel of a torrent, producing no plants</em> or <em>herbage:</em> <span class="auth">(TA:)</span> or<span class="arrow"><span class="ar">بَطْحَآءُ↓</span></span> signifies <em>soft earth</em> of a valley, <em>such as has been drawn along by the torrents:</em> <span class="auth">(ISd, TA:)</span> or the <em>soft pebbles in the bottom of the water-course,</em> or <em>channel of a torrent,</em> of a valley; as also <span class="ar">أَبْطَحُ</span>: <span class="auth">(IAth, TA:)</span> or the <em>soft earth, such as has been drawn along by the torrents, in the bottom of a</em> <span class="ar">تَلْعَة</span> <span class="add">[meaning <em>a water-course</em>, &amp;c.]</span> and <em>of a valley;</em> and the <span class="ar">أَبْطَح</span> and<span class="arrow"><span class="ar">بَطْحَآء↓</span></span> of a valley are its <em>earth and soft pebbles:</em> <span class="auth">(En-Naḍr, TA:)</span> and accord. to AA, <span class="arrow"><span class="ar">بَطِحٌ↓</span></span> signifies <em>sand in a</em> <span class="ar">بَطْحَآء</span>: <span class="auth">(TA:)</span> the pl. is <span class="ar">أَبَاطِحُ</span> and <span class="ar">بِطَاحٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and <span class="ar">بَطَائِحُ</span>; <span class="auth">(Ḳ;)</span> the first of these, and the second also, contr. to analogy, being pls. of <span class="ar">ابطح</span>; <span class="auth">(Ṣ;)</span> or both are pls. of <span class="ar">بطحآء</span>, contr. to analogy; <span class="auth">(Ḥam p. 251;)</span> or the first <a href="#AbTH">is pl. of <span class="ar">ابطح</span></a>, formed after the manner of the pl. of a subst. of this measure, though the sing. is originally an epithet; <span class="auth">(M, TA;)</span> and the second, as is asserted by more than one, is correctly <a href="#bTHAC">pl. of <span class="ar">بطحآء</span></a>, as is also <span class="ar">بَطْحَاوَاتٌ</span>; <span class="auth">(TA;)</span> and the third <a href="#bTyHp">is pl. of <span class="ar">بطيحة</span></a>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="munobaTiHN">
				<h3 class="entry"><span class="ar">مُنْبَطِحٌ</span></h3>
				<div class="sense" id="munobaTiHN_A1">
					<p><span class="ar">مُنْبَطِحٌ</span> <span class="add">[part. n. of 7, q. v.: often applied to anything <em>Spread out, expanded,</em> or <em>flat</em>]</span>: <a href="#baATiHN">see <span class="ar">بَاطِحٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0216.pdf" target="pdf">
							<span>Lanes Lexicon Page 216</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
