<article class="root" id="Root_bhO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/198_bne">بنى</a></span>
				<span class="ar">بهأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/200_bht">بهت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bhO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بهأ</span></h3>
				<div class="sense" id="bhO_1_A1">
					<p><span class="ar long">بَهَأ بِهِ</span>, and <span class="ar">بَهِئَ</span>, <span class="auth">(AZ, Ṣ, Mgh, Ḳ,)</span> <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْهَأُ</span>}</span></add>]</span> and <span class="ar">بَهُؤَ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْهُأُ</span>}</span></add>]</span> inf. n. <span class="ar">بَهْءٌ</span> and <span class="ar">بُهُوْءٌ</span> <span class="auth">(AZ, Ṣ, Ḳ)</span> and <span class="ar">بَهَآءٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar long">ابتهأ↓ به</span></span>; <span class="auth">(Aboo-Saʼeed, TA;)</span> <em>He was,</em> or <em>became, sociable, friendly,</em> or <em>familiar, with him,</em> or <em>it;</em> <span class="auth">(AZ, Ṣ, Mgh, Ḳ;)</span> namely, a man, <span class="auth">(AZ, Ṣ,)</span> or a thing; <span class="auth">(Mgh;)</span> <em>and loved,</em> or <em>liked, his,</em> or <em>its, nearness:</em> <span class="auth">(Aboo-Saʼeed, TA:)</span> and <em>he became familiar with it so as to have little,</em> or <em>no, reverence for it,</em> or <em>awe of it.</em> <span class="auth">(Mgh, TA.)</span> <span class="ar long">بَهَوْا بِهِ</span> occurs in a trad., as they relate it, for <span class="ar long">بَهَؤُوا به</span>: <span class="auth">(AʼObeyd, TA:)</span> and<span class="arrow"><span class="ar">يَبْتَهِى↓</span></span>, in a verse of El-Aạshà, for <span class="ar">يَبْتَهِئُ</span>. <span class="auth">(Aṣ, O, TṢ, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بهأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bhO_1_A2">
					<p><span class="ar long">مَا بَهَأْتُ لَهُ</span> <em>I did not understand it;</em> or <em>I did not know it;</em> <span class="auth">(ISk, Ṣ, Ḳ;)</span> as also <span class="ar long">مَا بَأَهْتُ لَهُ</span>. <span class="auth">(ISk, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bhO_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتهأ</span></h3>
				<div class="sense" id="bhO_8_A1">
					<p><a href="#bhA1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bahaMCN">
				<h3 class="entry"><span class="ar">بَهَآءٌ</span></h3>
				<div class="sense" id="bahaMCN_A1">
					<p><span class="ar long">نَاقَةٌ بَهَآءٌ</span> <em>A she-camel familiar with,</em> or <em>accustomed to, her milker;</em> <span class="auth">(Aṣ, Ṣ;)</span> <em>that offers no opposition to him.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بهأ</span> - Entry: <span class="ar">بَهَآءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bahaMCN_B1">
					<p><span class="ar">بَهَآءٌ</span> as syn. with <span class="ar">حُسْنٌ</span> <a href="index.php?data=02_b/208_bhw">belongs to art. <span class="ar">بهو</span></a>. <span class="auth">(Ṣ, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0263.pdf" target="pdf">
							<span>Lanes Lexicon Page 263</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
