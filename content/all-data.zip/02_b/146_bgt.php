<article class="root" id="Root_bgt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/145_bEl">بعل</a></span>
				<span class="ar">بغت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/147_bgv">بغث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgt_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغت</span></h3>
				<div class="sense" id="bgt_1_A1">
					<p><span class="ar">بَغَتَهُ</span>, <span class="auth">(Ṣ, A, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَتُ</span>}</span></add>, <span class="auth">(A, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَغْتٌ</span> and <span class="ar">بَغْتَةٌ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ)</span> and <span class="ar">بَغَتٌ</span> <span class="auth">(MF)</span> and <span class="ar">بَغَتَةٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بَغَتَّةٌ</span>, with teshdeed to the <span class="ar">ت</span>, of the same measure as <span class="ar">جَرَبَّةٌ</span>, <span class="pb" id="Page_0229"></span>accord. to AA's reading of the Ḳur in a passage which will be found below, without a parallel among inf. ns., <span class="auth">(Z,)</span> <span class="add">[and said by some to have an intensive signification,]</span> <em>He,</em> or <em>it, came upon him,</em> or <em>happened to him, suddenly, unexpectedly, without his being aware of it,</em> or <em>without any previous cause; surprised him; took him by surprise,</em> or <em>unawares;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">باغتهُ↓</span></span>, <span class="auth">(A, Mṣb,)</span> inf. n. <span class="ar">مُبَاغَتَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بِغَاتٌ</span>. <span class="auth">(TA.)</span> It is said in the Ḳur vi. 31, accord. to the reading mentioned above, <span class="ar long">إِذَا جَآءَتْهُمُ ٱلسَّاعَةُ بَغَتَّةً</span> <span class="add">[<em>When the hour</em> of the resurrection <em>shall come upon them suddenly, unexpectedly,</em>, &amp;c.]</span>. <span class="auth">(Z.)</span> And you say, <span class="ar long">جَآءَهُ بَغْتَةً</span> <em>He,</em> or <em>it, came to him suddenly,</em>, &amp;c. <span class="auth">(A, Mṣb.)</span> And <span class="ar long">لَقِيَهُ بَغْتَةً</span> <em>He met,</em> or <em>found, him,</em> or <em>it, suddenly,</em>, &amp;c. <span class="auth">(Ṣ.)</span> And <span class="ar long">لَسْتُ آمَنُ بَغَتَاتِ العَدُوِّ</span> <em>I am not secure from,</em> or <em>free from fear of, the enemy's comings</em> <span class="add">[<em>upon me</em>]</span> <em>unawares.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bgt_3">
				<h3 class="entry">3. ⇒ <span class="ar">باغت</span></h3>
				<div class="sense" id="bgt_3_A1">
					<p><a href="#bgt_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaAguwtu">
				<h3 class="entry"><span class="ar">البَاغُوتُ</span></h3>
				<div class="sense" id="AlbaAguwtu_A1">
					<p><span class="ar">البَاغُوتُ</span> <em>The festival,</em> <span class="auth">(A,)</span> or <em>a certain festival,</em> <span class="auth">(IAth, Ḳ,)</span> <em>of the Christians;</em> <span class="auth">(A, IAth, Ḳ;)</span> <span class="add">[namely, <em>Easter;</em>]</span> thus called accord. to some; but accord. to others, <span class="ar">الباعوث</span> <span class="add">[q. v.]</span>, with the unpointed <span class="ar">ع</span> and the three-pointed <span class="ar">ث</span>. <span class="auth">(IAth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboguwtN">
				<h3 class="entry"><span class="ar">مَبْغُوتٌ</span></h3>
				<div class="sense" id="maboguwtN_A1">
					<p><span class="ar">مَبْغُوتٌ</span> <em>i. q.</em> <span class="ar">مَبْهُوتٌ</span> <span class="add">[<em>Confounded,</em> or <em>perplexed, and unable to see his right course</em>]</span>: so in the saying, <span class="ar long">لَا رَأْىَ لِمَبْغُوتٍ</span> <span class="add">[<em>There is no judgment to one who is confounded,</em>, &amp;c.]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0228.pdf" target="pdf">
							<span>Lanes Lexicon Page 228</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0229.pdf" target="pdf">
							<span>Lanes Lexicon Page 229</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
