<article class="root" id="Root_bwl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/223_bwq">بوق</a></span>
				<span class="ar">بول</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/225_bwm">بوم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بول</span> ⇒ <span class="ar">بال</span></h3>
				<div class="sense" id="bwl_1_A1">
					<p><span class="ar">بَالَ</span>, <span class="auth">(T, Ṣ, &amp;c.,)</span> aor. <span class="ar">يَبُولُ</span>, <span class="auth">(Ṣ, M, Mṣb,)</span> inf. n. <span class="ar">بَوْلٌ</span> <span class="auth">(M, Mṣb)</span> and <span class="ar">مَبَالٌ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[<em>He urined, discharged his urine, made water,</em> or <em>staled;</em>]</span> said of a man, <span class="auth">(M, Mṣb,)</span> and of a beast, <span class="auth">(Mṣb,)</span>, &amp;c. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwl_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَالَ بَوْلًا شَرِيفًا فَاخِرًا</span> ‡ <em>He</em> <span class="auth">(a man)</span> <em>begat offspring resembling him</em> <span class="auth">(El-Mufaddal, T, TA)</span> <em>in form and natural dispositions.</em> <span class="auth">(El-Mufaddal, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwl_1_A3">
					<p>A poet, using the verb metaphorically, says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَالَ سُهَيْلٌ فِى الفَضِيخِ فَفَسَدْ</span> *</div> 
					</blockquote>
					<p>‡ <span class="add">[<em>Canopus made water in the beverage prepared from unripe dates, and it became spoiled,</em> or <em>marred</em>]</span>: <span class="auth">(M:)</span> <span class="pb" id="Page_0277"></span>meaning, that when Canopus rises <span class="add">[aurorally, which it does, in central Arabia, early in August, the making of that beverage is stopped, for]</span> the season of unripe dates has passed, and they have become ripe. <span class="auth">(L in art. <span class="ar">فضخ</span>.)</span> <span class="ar long">بَالَ سُهَيْلٌ</span> is also a prov., said when winter has come. <span class="auth">(MF in art. <span class="ar">خرت</span>.)</span> <span class="add">[<a href="#suhaYolN">See <span class="ar">سُهَيْلٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwl_1_A4">
					<p><span class="ar">بَوْلٌ</span> also signifies † The <em>having vent, so as to flow forth:</em> <span class="auth">(Ḳ:)</span> whence <span class="ar">بَوَّالٌ</span> as an epithet applied to a wine-skin: see this word below. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bwl_1_A5">
					<p>And <span class="ar">بَالَ</span> † <em>It melted,</em> or <em>dissolved:</em> <span class="auth">(Ḳ:)</span> said of fat. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بوّل</span></h3>
				<div class="sense" id="bwl_2_A1">
					<p><span class="ar long">بوّل أَصْلَ الشَّجَرَةِ</span> <span class="auth">(Ḳ in art. <span class="ar">قزح</span>)</span> <span class="add">[<em>He made water upon the root,</em> or <em>stem, of the tree:</em> or]</span> <em>he put urine at the root of the tree to render its fruit abundant.</em> <span class="auth">(TḲ in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwl_3">
				<h3 class="entry">3. ⇒ <span class="ar">باول</span></h3>
				<div class="sense" id="bwl_3_A1">
					<p><span class="ar long">لَا أُبَاوِلُهُ</span>, from <span class="ar">البَالُ</span>, <em>I will not,</em> or <em>I do not, cause him,</em> or <em>it, to move,</em> or <em>occur to, my mind.</em> <span class="auth">(Z, TA <a href="index.php?data=02_b/184_blw">in art. <span class="ar">بلو</span></a>. <a href="#OubaAliyhi">See <span class="ar long">لَا أُبَالِيهِ</span></a> in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابول</span> ⇒ <span class="ar">ابال</span></h3>
				<div class="sense" id="bwl_4_A1">
					<p><span class="ar long">ابال الخَيْلِ</span>, and<span class="arrow"><span class="ar">استبالها↓</span></span>, <span class="add">[<em>He,</em> or <em>it, made,</em> or <em>caused, the horses to stale:</em> or]</span> <em>he stopped the horses for the purpose of</em> <span class="add">[<em>their</em>]</span> <em>staling.</em> <span class="auth">(TA.)</span> One says, <span class="auth">(in threatening, PṢ,)</span> <span class="ar long">لَنُبِيلَنَّ الخَيْلَ فِى عرَصَاتِكُمْ</span> <span class="add">[<em>We will assuredly make the horses to stale in your courts</em>]</span>. <span class="auth">(Ṣ.)</span> And it is said in a prov.,<span class="arrow"><span class="ar long">بَالَ حِمَارٌ فَٱسْتَبَالَ↓ أَحْمِرَةٌ</span></span> <em>An ass staled, and caused some</em> (<em>other</em>) <em>asses to stale:</em> applied to a case in which people help one another to do what is disagreeable. <span class="auth">(Meyd.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبول</span> ⇒ <span class="ar">استبال</span></h3>
				<div class="sense" id="bwl_10_A1">
					<p><span class="ar">استبال</span> <em>He desired,</em> or <em>required, to make water.</em> <span class="auth">(KL.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwl_10_A2">
					<p><a href="#bwl_4">See also 4</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwl_10_A3">
					<p>El-Farezdaḳ says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإِنَّ الَّذِى يَسْعَى لِيُفْسِدَ زَوْجَتِى</span> *</div> 
						<div class="star">* <span class="ar long">كَسَاعٍ إِلَى أُسْدِ الشَّرَى يَسْتَبِيلُهَا</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>And verily he who strives to corrupt my wife is like one betaking himself to the lions of Esh-Sharà</em> <span class="auth">(a certain road abounding with those animals)</span>]</span> <em>to receive their urine in his hand.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAlN">
				<h3 class="entry"><span class="ar">بَالٌ</span></h3>
				<div class="sense" id="baAlN_A1">
					<p><span class="ar">بَالٌ</span> <em>A state, condition,</em> or <em>case;</em> syn. <span class="ar">حَالٌ</span> <span class="auth">(T, Ṣ, Mṣb, Ḳ)</span> and <span class="ar">شَأْنٌ</span>: <span class="auth">(T:)</span> or <em>a state, condition,</em> or <em>case, for which one cares;</em> wherefore one says, <span class="ar long">مَا بَالَيْتُ بِكَذَا</span>, inf. n. <span class="ar">بَالَةٌ</span>, meaning “I cared not for such a thing:” <span class="auth">(TA:)</span> or <em>a thing</em> <span class="add">[or <em>things</em>]</span> <em>for which one cares:</em> <span class="auth">(Ḥar p. 94:)</span> and <span class="ar">البَالُ</span> signifies also <span class="ar long">بَالُ النَّفْسِ</span>, i. e. <em>care,</em> or <em>concern;</em> and hence is <span class="add">[said to be]</span> derived <span class="ar">بَالَيْتُ</span>, having for its inf. n. <span class="ar">بَالَةٌ</span>. <span class="auth">(T.)</span> One says, <span class="ar long">مَا بَالُكَ</span> <em>What is thy state,</em> or <em>condition,</em> or <em>case?</em> <span class="auth">(Ṣ.)</span> <span class="add">[See the Ḳur xii. 50 and xx. 53: and see an ex. in a verse cited in this Lex. voce <span class="ar">إِيهِ</span>.]</span> When it was said to a man, in former times, “How hast thou entered upon the morning?” he used to reply, <span class="ar long">بِخَيْرٍ أَصْلَحَ ٱللّٰهُ بَالَكُمْ</span> <span class="add">[<em>With good fortune: may God make good your state,</em> or <em>condition</em>]</span>. <span class="auth">(Ḥam p. 77.)</span> <span class="ar long">وَيُصْلِحُ بَالَهُمْ</span>, in the Ḳur <span class="add">[xlvii. 6]</span>, means <em>And He will make good their state,</em> or <em>condition, in the present world:</em> <span class="auth">(I’Ab, T:)</span> or <em>their means of subsistence in the present world, together with their recompense in the world to come.</em> <span class="auth">(M.)</span> One says also, <span class="ar long">هُوَ رَخِىُّ البَالِ</span> <em>He is in ample and easy circumstances</em> <span class="auth">(T, Mṣb)</span> <em>of life;</em> <span class="auth">(T;)</span> <em>he is not straitened in circumstances, nor troubled:</em> <span class="auth">(T:)</span> or <em>he is in an easy,</em> or <em>a pleasant, state</em> or <em>condition:</em> <span class="auth">(TA in art. <span class="ar">رخو</span>:)</span> or <em>he is easy,</em> or <em>unstraitened, in mind:</em> <span class="auth">(Ṣ:)</span> <span class="add">[for]</span> <span class="ar">البَالُ</span>, <span class="auth">(T, M, Ḳ,)</span> or <span class="ar long">رَخَآءُ البَالِ</span>, <span class="auth">(TA,)</span> signifies <em>ampleness and easiness of life:</em> <span class="auth">(T, M, Ḳ, TA:)</span> or <span class="ar">البال</span> signifies <em>an easy,</em> or <em>unstraitened, state of the mind.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">هُوَ كَاسِفُ البَالِ</span> <em>He is in an evil state</em> or <em>condition:</em> <span class="auth">(TA:)</span> or <em>he is straitened in his hope,</em> or <em>expectation:</em> for <span class="ar">البال</span> is said to signify <em>hope,</em> or <em>expectation:</em> <span class="auth">(T:)</span> so says El-Hawaázinee. <span class="auth">(TA.)</span> And <span class="ar long">لَيْسَ هٰذَا مِنْ بَالِى</span> <em>This is not of the things for which I care.</em> <span class="auth">(Ṣ.)</span> And it is said in a trad., <span class="ar long">كُلُّ أَمْرٍ ذِى بَالٍ لَمْ يُبْدَأْ فِيهِ بِحَمْدِ ٱللّٰهِ فَهُوَ أَبْتَرُ</span>, i. e., <em>Every honourable affair, for which one cares, and by which one is rendered solicitous,</em> <span class="add">[<em>in which a beginning is not made by praising God, is cut off from good,</em> or <em>prosperity:</em>]</span> or <em>every affair of importance,</em> or <em>moment.</em> <span class="auth">(TA in two places in this art.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAlN_A2">
					<p>Also The <em>heart,</em> or <em>mind;</em> syn. <span class="ar">قَلْبٌ</span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">خَلَدٌ</span>, <span class="auth">(Ḥam pp. 76 and 77,)</span> and <span class="ar">نَفْسٌ</span>, <span class="auth">(AZ, T,)</span> and <span class="ar">خَاطِرٌ</span>. <span class="auth">(M, Ḳ, Kull p. 179.)</span> You say, <span class="ar long">خَطَرَ بِبَالِى</span>, <span class="auth">(Mṣb, Kull ubi suprà,)</span> and <span class="ar long">عَلَى بَالِى</span>, <span class="auth">(Kull ibid.,)</span> i. e., <span class="add">[<em>It</em> <span class="auth">(an affair, or a thing, Kull)</span> <em>occurred to,</em> or <em>bestirred itself in,</em> or <em>moved,</em>]</span> <em>my heart,</em> or <em>mind.</em> <span class="auth">(Mṣb, Kull.)</span> And <span class="ar long">لَمْ يَخْطُرْ بِبَالِى ذٰلِكَ الأَمْرُ</span>, i. e., <span class="add">[<em>That affair did not occur to,</em> or]</span> <em>did not move me,</em> or <em>distress me.</em> <span class="auth">(T.)</span> And <span class="ar long">مَا يَخْطُرُ فُلَانٌ بِبَالِى</span>, i. e. <span class="add">[<em>Such a one does not occur to,</em> or <em>move,</em>]</span> <em>my heart,</em> or <em>mind.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAlN_A3">
					<p><span class="add">[And hence, <em>Mind,</em> or <em>attention.</em> You say, <span class="ar long">أَعْطِنِى بَالَكَ</span> <em>Give me thy mind,</em> or <em>attention.</em> And]</span> <span class="ar long">لَا أُلْقِى إِلَيْهِ بَالًا</span> <span class="add">[<em>I will not,</em> or <em>I do not, give,</em> or <em>pay, any attention to him,</em> or <em>it</em>]</span>. <span class="auth">(Z, TA in art. <span class="ar">بلو</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAlN_B1">
					<p><span class="add">[The <em>whale;</em>]</span> <em>a great fish,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>of the fish of the</em> <span class="ar">بَحْر</span> <span class="add">[here meaning <em>sea</em>]</span>; <span class="auth">(Ṣ;)</span> <em>a certain bulky fish, called</em> <span class="ar long">جَمَلُ البَحْرُ</span>; <span class="auth">(M;)</span> it is <em>a fish fifty cubits long:</em> <span class="auth">(MF:)</span> <span class="add">[Ḳzw describes it as being <em>from four hundred to five hundred cubits in length,</em> and says that <em>it sometimes shows the extremity of its fin, like a great sail, and its head also, and blows forth water rising into the air higher than an arrow can be shot:</em> these and other exaggerated particulars he mentions in his account of the Sea of the Zenj: and in a later place he says, that <em>it eats ambergris, and dies in consequence; and a great quantity of oil is procured from its brain, and used for lamps:</em>]</span> the word <span class="add">[in this sense]</span> is not Arabic: <span class="auth">(Ṣ:)</span> in the O it is said to be arabicized, from <span class="add">[the Persian]</span> <span class="ar">وَالْ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="baAlN_C1">
					<p>The <em>spade</em> (<span class="ar">مَرّ</span> <span class="add">[in the CK erroneously written <span class="ar">مُرّ</span>]</span>) <em>with which one works in land of seed-produce.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="baAlN_D1">
					<p><a href="#baAlapN">See also <span class="ar">بَالَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawolN">
				<h3 class="entry"><span class="ar">بَوْلٌ</span></h3>
				<div class="sense" id="bawolN_A1">
					<p><span class="ar">بَوْلٌ</span>, originally an inf. n., <span class="auth">(Mṣb,)</span> <span class="add">[<em>Urine; stale:</em>]</span> pl. <span class="ar">أَبْوَالٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bawolN_A2">
					<p><span class="ar long">أَبْوَالُ البِغَالِ</span> <em>The seminal fluid of mules.</em> <span class="auth">(Aṣ, TA.)</span> And hence, as being likened thereto, because it is fruitless, <span class="auth">(Aṣ, TA,)</span> † <em>The</em> <span class="ar">سَرَاب</span> <span class="add">[or <em>mirage:</em> in the CK <span class="ar">الشَّرابُ</span>]</span>. <span class="auth">(Aṣ, Ḳ, TA.)</span> It is also applied to the road of El-Yemen, which is not travelled but by mules: <a href="index.php?data=02_b/150_bgl">see also art. <span class="ar">بغل</span></a>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bawolN_A3">
					<p><span class="ar long">بَوْلُ العَجُوزِ</span> † <em>Cow's milk.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bawolN_A4">
					<p><span class="ar">بَوْلٌ</span> signifies also ‡ <em>Offspring.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bawolN_A5">
					<p>And ‡ <em>A large number.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bawolN_A6">
					<p><a href="#Oabowalu">See also <span class="ar">أَبْوَلُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAlapN">
				<h3 class="entry"><span class="ar">بَالَةٌ</span></h3>
				<div class="sense" id="baAlapN_A1">
					<p><span class="ar">بَالَةٌ</span> <em>A</em> <span class="add">[<em>flask,</em> or <em>bottle, such as is called</em>]</span> <span class="ar">قَارُورَة</span>: <span class="auth">(M, Ḳ:)</span> pl. <span class="add">[or rather coll. gen. n.]</span> <span class="arrow"><span class="ar">بَالٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAlapN_A2">
					<p><em>A</em> <span class="add">[<em>bag such as is called</em>]</span> <span class="ar">جِرَاب</span>, <span class="auth">(T,M, Ḳ,)</span> <em>small</em> and <em>large, in which mush is put:</em> <span class="auth">(T:)</span> or <span class="auth">(M <span class="add">[in the Ḳ “and”]</span>)</span> the <em>receptacle of perfume:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> a Persian word, <span class="auth">(Ṣ, M,)</span> arabicized; <span class="auth">(Ṣ;)</span> in Persian <span class="ar">بِيْلَه</span>, <span class="auth">(T, Ṣ, M,)</span> or <span class="ar">بَالَه</span>: <span class="auth">(M:)</span> pl. <span class="add">[or coll. gen. n.]</span> <span class="arrow"><span class="ar">بَالٌ↓</span></span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAlapN_A3">
					<p>It is said to signify also <em>An odour; a smell;</em> <span class="auth">(T;)</span> on the authority of Aboo-Saʼeed Ed-Dareer; <span class="auth">(TA;)</span> from <span class="ar">بَلَوْتُهُ</span> meaning “I smelled it, and tried, proved, or tested, it;” originally <span class="ar">بَلْوَةٌ</span>; the <span class="ar">و</span> being transposed, and changed into <span class="ar">ا</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAlapN_A4">
					<p>And <em>A staff with a pointed iron at the end, used by the hunters of El-Basrah, who throw it at the game:</em> pl. <span class="add">[or coll. gen. n.]</span> <span class="arrow"><span class="ar">بَالٌ↓</span></span>. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAlapN_A5">
					<p>And hence it is applied by the vulgar to <em>A small elongated sword.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَالَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAlapN_B1">
					<p><a href="#blw_3">It is also an inf. n. of <span class="ar">بَالَى</span></a>, <a href="index.php?data=02_b/184_blw">which see in its proper art</a>. <span class="auth">(TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawolapN">
				<h3 class="entry"><span class="ar">بَوْلَةٌ</span></h3>
				<div class="sense" id="bawolapN_A1">
					<p><span class="ar">بَوْلَةٌ</span> The <em>origin</em> (<span class="ar">مَنْبِت</span> <span class="add">[so in copies of the Ḳ accord. to the TA)]</span> or <em>daughter</em> (<span class="ar">بِنْت</span> <span class="add">[so in some copies of the Ḳ]</span>) of a man; <span class="auth">(Ḳ;)</span> on the authority of El-Mufaddal. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biylapN">
				<h3 class="entry"><span class="ar">بِيلَةٌ</span></h3>
				<div class="sense" id="biylapN_A1">
					<p><span class="ar">بِيلَةٌ</span> a subst. from <span class="ar">بَالَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <span class="add">[meaning <em>A discharging of urine, making water, or staling: or a mode, or manner, thereof;</em> as appears probable from its form, and from J's adding that it is]</span> like <span class="ar">جِلْسَةٌ</span> and <span class="ar">رِكْبَةٌ</span>; <span class="auth">(Ṣ;)</span> <span class="add">[and also from the following phrase:]</span> <span class="ar long">إِنَّهُ لَحَسَنُ البِيلَةِ</span> <span class="add">[<em>Verily he is one who has a good mode of discharging his urine</em>]</span>; from <span class="ar">البَوْلُ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwalapN">
				<h3 class="entry"><span class="ar">بُوَلَةٌ</span></h3>
				<div class="sense" id="buwalapN_A1">
					<p><span class="ar">بُوَلَةٌ</span> That discharges much urine; syn. <span class="ar long">كَثِيرُ البَوْلِ</span>; <span class="auth">(M, Ḳ;)</span> applied to a man; <span class="auth">(M;)</span> and so<span class="arrow"><span class="ar">بَوَّالٌ↓</span></span> applied to a camel. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawaAlN">
				<h3 class="entry"><span class="ar">بَوَالٌ</span></h3>
				<div class="sense" id="bawaAlN_A1">
					<p><span class="ar">بَوَالٌ</span> <em>A disease occasioning much,</em> or <em>frequent,</em> <span class="ar">بَوْل</span> <span class="add">[or <em>discharging of urine</em>]</span>: <span class="auth">(M, Ḳ:)</span> <em>a disease that attacks sheep,</em> or <em>goats, such that they discharge urine until they die.</em> <span class="auth">(Ḥam p. 77.)</span> You say, <span class="ar long">أَخَذَهُ بُوَالٌ</span> <em>He was taken with much,</em> or <em>frequent,</em> <span class="ar">بَوْل</span> <span class="add">[or <em>discharging of urine</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawBaAlN">
				<h3 class="entry"><span class="ar">بَوَّالٌ</span></h3>
				<div class="sense" id="bawBaAlN_A1">
					<p><span class="ar">بَوَّالٌ</span>: <a href="#buwalapN">see <span class="ar">بُوَلَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوَّالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bawBaAlN_A2">
					<p><span class="add">[Hence,]</span> † A wine-skin <em>from which the wine runs out.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بول</span> - Entry: <span class="ar">بَوَّالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bawBaAlN_A3">
					<p>And <span class="ar long">شَحْمَةٌ بَوَّالَةٌ</span> † <em>A piece of fat that quickly melts</em> or <em>dissolves.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabowalu">
				<h3 class="entry"><span class="ar">أَبْوَلُ</span></h3>
				<div class="sense" id="Oabowalu_A1">
					<p><span class="ar long">أَبْوَلُ مِنْ كَلْبٍ</span> <em>More frequent in making water than a dog:</em> or it may mean <em>more abundant in offspring.</em> <span class="auth">(Meyd. <span class="add">[Freytag adds, in his Arab. Prov. i. 199, on the authority of Sharaf-ed-Deen, that <span class="arrow"><span class="ar">بول↓</span></span> (i. e. <span class="ar">بَوْلٌ</span>)</span> may signify <em>urine</em> or <em>coitus or offspring.</em>]</span>)</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabaAlN">
				<h3 class="entry"><span class="ar">مَبَالٌ</span></h3>
				<div class="sense" id="mabaAlN_A1">
					<p><span class="ar">مَبَالٌ</span> <span class="add">[The <em>place of urine, or of the urinary discharge;</em> meaning]</span> the <span class="ar">فَرْج</span> <span class="add">[or <em>pudendum</em> of a man and of a woman]</span>: whence the phrase, <span class="ar long">مَبَالٌ فِى مَبَالٍ</span>, occurring in a trad. <span class="auth">(TA,)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabowalapN">
				<span class="pb" id="Page_0278"></span>
				<h3 class="entry"><span class="ar">مَبْوَلَةٌ</span></h3>
				<div class="sense" id="mabowalapN_A1">
					<p><span class="ar">مَبْوَلَةٌ</span> <span class="add">[<em>A diuretic; a provocative of urine</em>]</span>. You say, <span class="ar long">كَثْرَةُ الشَّرَابِ مَبْوَلَةٌ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> i. e., <em>Much beverage occasions a discharging of urine.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibowalapN">
				<h3 class="entry"><span class="ar">مِبْوَلَةٌ</span></h3>
				<div class="sense" id="mibowalapN_A1">
					<p><span class="ar">مِبْوَلَةٌ</span> <span class="add">[<em>A urinal;</em>]</span> <em>a vessel</em> (<span class="ar">كُوز</span>) <em>in which one makes water.</em> <span class="auth">(Ṣ, Ḳ,*)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0276.pdf" target="pdf">
							<span>Lanes Lexicon Page 276</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0277.pdf" target="pdf">
							<span>Lanes Lexicon Page 277</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0278.pdf" target="pdf">
							<span>Lanes Lexicon Page 278</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
