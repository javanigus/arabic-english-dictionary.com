<article class="root" id="Root_brO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/057_br">بر</a></span>
				<span class="ar">برأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/059_brbx">بربخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brO_1">
				<h3 class="entry">1. ⇒ <span class="ar">برأ</span></h3>
				<div class="sense" id="brO_1_A1">
					<p><span class="ar">بَرِئَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>, inf. n. generally <span class="ar">بُرْءٌ</span> or <span class="ar">بَرَآءَةٌ</span>,]</span> <em>He was,</em> or <em>became, clear,</em> or <em>free,</em> of, or from, a thing; in the manners which will be explained below: <span class="auth">(Bḍ ii. 51:)</span> <em>he was,</em> or <em>became, in a state of freedom</em> or <em>immunity, secure,</em> or <em>safe.</em> <span class="auth">(T.)</span> <span class="add">[Hence,]</span> <span class="ar long">بَرِئَ مِنَ المَرَضِ</span>, and <span class="ar">بَرَأَ</span>, <span class="auth">(T, Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add> and <span class="ar">بَرُؤَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُأُ</span>}</span></add>; <span class="auth">(Mṣb;)</span> inf. n. <span class="ar">بُرْءٌ</span>: <span class="auth">(T, Mṣb:)</span> or <span class="ar long">بَرِئَ من المرض</span>, inf. n. <span class="ar">بُرْءٌ</span>, with damm; and the people of El-Ḥijáz say <span class="ar">بَرَأَ</span>, inf. n. <span class="ar">بَرْءٌ</span>, with fet-ḥ: <span class="auth">(Ṣ:)</span> accord. to Aṣ, <span class="ar long">بَرِىَ من المرض</span> is of the dial. of Temeem; and <span class="ar">بَرَأَ</span> of the dial. of the people of El-Ḥijáz: or, accord. to AZ, the people of El-Ḥijáz say <span class="ar">بَرَأَ</span>; and the rest of the Arabs say <span class="ar">بَرِئَ</span>: <span class="auth">(T:)</span> or <span class="ar">بَرَأَ</span> <span class="add">[alone]</span>, said of a sick man, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُأُ</span>}</span></add> and <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>; and <span class="ar">بَرِئَ</span>; and <span class="ar">بَرُؤَ</span>; inf. n. <span class="ar">بَرْءٌ</span> <span class="add">[probably a mistranscription for <span class="ar">بُرْءٌ</span>]</span> and <span class="ar">بُرُؤٌ</span>: or, accord. to Lḥ, the people of El-Ḥijáz say <span class="ar">بَرَأَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُأُ</span>}</span></add>, inf. n. <span class="ar">بُرْءٌ</span> and <span class="ar">بُرُؤٌ</span> <span class="add">[i. e. <span class="ar">بُرُوْءٌ</span>]</span>; and the people of El-ʼÁliyeh, <span class="add">[<span class="ar">بَرَأَ</span>,]</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>, inf. n. <span class="ar">بُرْءٌ</span> and <span class="ar">بُرُؤُ</span>; and Temeem, <span class="ar">بَرِئَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>,]</span> inf. n. <span class="ar">بُرْءٌ</span> and <span class="ar">بُرُؤٌ</span>: <span class="auth">(M:)</span> or <span class="ar">بَرَأَ</span>, <span class="auth">(Ḳ,)</span> said by IḲṭṭ to be the most chaste form, <span class="auth">(TA,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> agreeably with analogy, <span class="auth">(TA,)</span> and <span class="ar">ـُ</span>, <span class="auth">(Ḳ,)</span> said by Zj to be the only instance of a verb of the measure <span class="ar">فَعَلَ</span> with <span class="ar">ء</span> for its last radical letter having its aor. of the measure <span class="ar">يَفْعُلُ</span>, <span class="add">[though others mention also <span class="ar">قَرَأَ</span>, aor. <span class="ar">يَقْرُؤُ</span>, and <span class="ar">هَنَأَ</span>, aor. <span class="ar">يَهْنُؤُ</span>,]</span> and asserted to be a bad form, <span class="auth">(TA,)</span> inf. n. <span class="ar">بُرْءٌ</span> and <span class="ar">بُرُوْءٌ</span>; and <span class="ar">بَرُؤَ</span>, <span class="auth">(Ḳ,)</span> not a chaste form, <span class="auth">(TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُأُ</span>}</span></add>; and <span class="ar">بَرِئَ</span>, <span class="auth">(Ḳ,)</span> a chaste form, <span class="auth">(TA,)</span> <span class="add">[and the most common of all,]</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>, inf. n. <span class="ar">بَرْءٌ</span> and <span class="ar">بُرُؤٌ</span>, <span class="auth">(Ḳ, TA,)</span> or <span class="ar">بُرْءٌ</span>, <span class="auth">(CK,)</span> and <span class="ar">بُرُوْءٌ</span>; <span class="auth">(Ḳ, TA;)</span> <em>He became free from the disease, sickness,</em> or <em>malady:</em> <span class="auth">(T:)</span> or <span class="add">[<em>he recovered from it:</em>]</span> <em>he became convalescent;</em> or <em>sound,</em> or <em>healthy, at the close of disease, but was yet weak; or he recovered, but not completely, his health and strength;</em> syn. <span class="ar">نِقَهَ</span>; <span class="auth">(M, Ḳ;)</span> i. e., <em>he acquired that slight degree of soundness,</em> or <em>health, which comes at the close of disease, but with disease remaining in him.</em> <span class="auth">(TA.)</span> <span class="add">[And <span class="ar long">بَرِئَ الجُرْجُ</span>, or <span class="ar">بَرَأَ</span>, <em>The wound healed;</em> or <em>became in a healing state:</em> of frequent occurrence.]</span> And <span class="ar long">بَرِئَ مِنَ الأَمْرِ</span>, <span class="add">[the only form of the verb used in this case, and in the other cases in which it is mentioned below,]</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُأُ</span>}</span></add>, the latter extr., <span class="auth">(M, Ḳ,)</span> or rather it is very strange, for IḲooṭ says that <span class="ar">نَعِمَ</span>, aor. <span class="ar">يَنْعُمُ</span>, and <span class="ar">فَضِلَ</span>, aor. <span class="ar">يَفْضُلُ</span>, are the only instances of this kind, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَرَآءَةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">بَرَآءٌ</span> <span class="auth">(Lḥ, M, Ḳ)</span> and <span class="ar">بُرُؤٌ</span>, <span class="auth">(M,)</span> or <span class="ar">بُرْءٌ</span>, <span class="auth">(Ḳ, TA,)</span> or <span class="ar">بُرُوْءٌ</span>; <span class="auth">(CK;)</span> and<span class="arrow"><span class="ar">تبرّأ↓</span></span>; <span class="auth">(Ṣ,* M, Ḳ, Mgh;*)</span> <span class="add">[<em>He was,</em> or <em>became, free from the thing,</em> or <em>affair;</em> or <em>clear,</em> or <em>quit, thereof; clear of having</em> or <em>taking,</em> or <em>of having had</em> or <em>taken, any part therein; guiltless of it:</em> and also, <em>irresponsible for it;</em> as in an ex. q. v. voce <span class="ar">عِضَاضٌ</span>:]</span> said in relation to <span class="add">[a fault or the like, and]</span> a debt, and a claim, and religion <span class="add">[&amp;c.]</span>. <span class="auth">(Lḥ, M.)</span> You say, <span class="ar long">بَرِئَ مِنَ العَيْبِ</span>, <span class="auth">(Mgh, Mṣb,)</span> or <span class="ar">العُيُوبِ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">بَرَآءَةٌ</span>, <span class="auth">(Mgh,)</span> <em>He was,</em> or <em>became, free</em> <span class="auth">(Mṣb)</span> <span class="add">[<em>from the fault, defect, imperfection, blemish,</em> or <em>vice</em>]</span>, <span class="auth">(Mgh, Mṣb,)</span> <span class="add">[or <em>faults,</em>, &amp;c.]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">بَرِئَ مِنَ الدَّيْنِ</span>, <span class="auth">(T, Mgh, Mṣb,)</span> or <span class="ar">الدُّيُونِ</span>, <span class="auth">(Ṣ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>, <span class="auth">(T, Mṣb,)</span> inf. n. <span class="ar">بَرَآءَةٌ</span>, <span class="auth">(T, Mgh, Mṣb,)</span> <em>He was,</em> or <em>became, clear,</em> or <em>quit, of the debt;</em> <span class="auth">(or <em>debts;</em> Ṣ;)</span> <em>irresponsible for it</em> <span class="add">[or <em>them</em>]</span>: or <em>in a state of immunity with respect to it</em> <span class="add">[or <em>them</em>]</span>; i. e., <em>exempt from the demand thereof.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">بَرئَ إِلَيْكَ مِنْ حَقِّكَ</span>, inf. n. <span class="ar">بَرَآءَةٌ</span> and <span class="ar">بَرَآءٌ</span> <span class="auth">(Lḥ, M)</span> and <span class="ar">بُرُؤٌ</span>, <span class="add">[<em>He was,</em> or <em>became, clear,</em> or <em>quit, to thee, of thy claim,</em> or <em>due,</em> or <em>right;</em> or <em>exempt from the demand thereof;</em>]</span> as also<span class="arrow"><span class="ar">تبرّأ↓</span></span>. <span class="auth">(M.)</span> And <span class="ar long">بَرِئْتُ إِلَيْكَ مِنْ فُلَانٍ</span>, inf. n. <span class="ar">بَرَآءةٌ</span>, <span class="add">[<em>I was,</em> or <em>became,</em> or <em>have become, clear, to thee, of having</em> or <em>taking,</em> or <em>of having had</em> or <em>taken, any part with such a one;</em> or, <em>irresponsible to thee for such a one:</em>]</span> <span class="auth">(AZ, T, Ṣ:* <span class="add">[in one copy of the Ṣ, I find the phrase <span class="ar long">بَرِئْتُ مِنْكَ</span>, commencing the art.; but not in other copies:]</span>)</span> this is the only form of the verb used in this case, and in relation to debt <span class="add">[and the like]</span>. <span class="auth">(AZ, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brO_1_A2">
					<p><em>He removed himself,</em> or <em>kept, far,</em> or <em>aloof,</em> <span class="add">[from unclean things, or things occasioning blame; followed by <span class="ar">مِنْ</span>, with which it may be rendered <em>he shunned,</em> or <em>avoided;</em>]</span> syn. <span class="ar">تَنَزَّهُ</span> and <span class="ar">تَبَاعَدَ</span>. <span class="auth">(T.)</span> <span class="add">[You say, <span class="ar long">بَرِئَ مِنَ الأَقْذَارِ</span> <em>He removed himself,</em> or <em>kept, far,</em> or <em>aloof, from unclean things.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brO_1_A3">
					<p><em>He manifested an excuse,</em> <span class="add">[or <em>asserted himself to be clear</em> or <em>quit</em> or <em>irresponsible,</em> like<span class="arrow"><span class="ar">تبرّأ↓</span></span>,]</span> <em>and gave warning;</em> syn. <span class="ar">أَعْذَرَ</span> and <span class="ar">أَنْذَرَ</span>. <span class="auth">(T.)</span> Hence, in the Ḳur <span class="add">[ix. 1]</span>, <span class="ar long">بَرَآءَةٌ مِنَ ٱللّٰهِ وَرَسُولِهِ</span> <em>A manifestation of excuse, and a warning, from God and his apostle.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brO_1_B1">
					<p><span class="ar long">بَرَأَ ٱللّٰهُ الخَلْقَ</span>, <span class="auth">(Fr, T, Ṣ, M, Ḳ,)</span> or <span class="ar">الخَلِيَقَةَ</span>, <span class="auth">(Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَأُ</span>}</span></add>, <span class="auth">(T, M, &amp;c.,)</span> inf. n. <span class="ar">بَرْءٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">بُرُوْءٌ</span>, <span class="auth">(AZ, Lḥ, M, Ḳ,)</span> <em>God created mankind,</em> or <em>the beings,</em> or <em>things, that are created,</em> syn. <span class="ar">خَلَقَ</span>, <span class="auth">(Fr, T, M, Mṣb, Ḳ,)</span> <em>after no similitude,</em> or <em>model,</em> <span class="auth">(TA,)</span> <span class="add">[<em>but,</em> properly, though not always meaning so, <em>out of pre-existing matter;</em> for]</span> Bḍ says <span class="add">[in ii. 51]</span> that the primary meaning of the root <span class="ar">برء</span> is to denote a thing's becoming clear, or free, of, or from, another thing; either by being released <span class="add">[therefrom]</span>, as in <span class="ar long">بَرِئَ المَرِيضُ مِنْ مَرَضِهِ</span> and <span class="ar long">المَدْيُونُ مِنْ دَينِهِ</span> <span class="add">[both sufficiently explained above]</span>; or by production <span class="add">[therefrom]</span>, as in <span class="ar long">بَرَأَ ٱللّٰهُ آدَمَ مِنَ الطِّينِ</span> <span class="add">[<em>God produced,</em> or <em>created, Adam, from,</em> or <em>out of, clay</em>]</span>. <span class="auth">(TA.)</span> This verb relates to substances <span class="add">[as in the exs. given above]</span> and to accidents; and hence, <span class="add">[in the Ḳur lvii. 22,]</span> <span class="ar long">مِنْ قبْلِ أَنْ نَبْرَأَهَا</span> <span class="add">[<em>Before our creating it,</em> if <span class="ar">ها</span> refer to <span class="ar">مُصِيبَة</span>, preceding it; but, as Bḍ says, it may refer to this, or to <span class="ar">الأَرْض</span>, or to <span class="ar">أَنْفُس</span>]</span>: <span class="auth">(M:)</span> but <span class="ar">البَرْءُ</span> has a more particular application than <span class="ar">الخَلْقُ</span>; the former being particularly applied to the creation of animate beings, with few exceptions: you say, <span class="ar long">بَرَأَ ٱللّٰهُ النَّسَمَةَ وَخَلَقَ السَّمٰوَاتِ وَالأَرْضَ</span> <span class="add">[<em>God created,</em> or <em>produced, man,</em> or <em>the soul, and He created the heavens and the earth</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[To this verb, or perhaps to <span class="ar">بَرَى</span>, or to both, <span class="he">בָרָא</span> is the Hebrew equivalent, properly <span class="auth">(though not necessarily always)</span> signifying “he created out of pre-existing matter,” or “he fashioned.”]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brO_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّأ</span></h3>
				<div class="sense" id="brO_2_A1">
					<p><span class="ar">برّأهُ</span>, inf. n. <span class="ar">تَبْرئَةٌ</span>: <a href="#brA4">see 4</a>, in four places. <span class="add">[Hence,]</span> <span class="ar long">لَا التَّبْرِئَةِ</span> <em>The</em> <span class="ar">لا</span> <em>that denies in a general manner, absolutely,</em> or <em>to the uttermost;</em> i. e. <em>the</em> <span class="ar">لا</span> <em>that is a universal negative.</em> <span class="auth">(Mughnee, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brO_2_A2">
					<p>Also <em>He verified his being free</em> <span class="add">[from a thing]</span>, <em>clear,</em> or <em>quit,</em> <span class="add">[of it,]</span> <em>guiltless</em> <span class="add">[of it]</span>, or <em>irresponsible</em> <span class="add">[for it]</span>. <span class="auth">(Mgh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brO_3">
				<h3 class="entry">3. ⇒ <span class="ar">بارأ</span></h3>
				<div class="sense" id="brO_3_A1">
					<p><span class="ar">بارأهُ</span>, <span class="auth">(T, Ṣ, M, Mgh, Ḳ,)</span> inf. n. <span class="ar">مُبَارَأَةٌ</span> <span class="auth">(T, M, Mgh)</span> and <span class="ar">بِرَآءٌ</span>, <span class="auth">(M,)</span> <em>He made him</em> <span class="auth">(his copartner)</span> <em>free, clear, quit,</em> or <em>irresponsible, the latter doing to him the same:</em> <span class="auth">(Mgh:)</span> <em>he compounded,</em> or <em>made a compromise, with him</em> <span class="auth">(his hired man, T, M)</span> <em>for their mutual separation:</em> <span class="auth">(M:)</span> <em>he separated himself from him</em> <span class="auth">(his copartner, Ṣ, O)</span>, <em>the latter doing the same.</em> <span class="auth">(Ṣ, O, Ḳ.)</span> And <span class="ar long">بَارَأْتُ الرَّجُلَ</span> <em>I became free, clear, quit,</em> or <em>irresponsible, to the man, he becoming so to me.</em> <span class="auth">(M.)</span> And <span class="ar long">بارأ المَرْأَةَ</span>, <span class="auth">(T, M, Ḳ,)</span> or <span class="ar">ٱمْرَأَتَهُ</span>, <span class="auth">(Ṣ,)</span> inf. n. as above, <span class="auth">(M,)</span> <em>He compounded,</em> or <em>made a compromise, with the woman</em> <span class="auth">(or <em>his wife,</em> Ṣ)</span> <em>for their mutual separation;</em> <span class="auth">(M, Ḳ;)</span> i. e. <em>he divorced her for a compensation</em> <span class="add">[<em>which she was to make him,</em> such as her giving up a portion of her dowry remaining due to her, <em>in order that they might be clear, each of the other</em>]</span>: it occurs also <span class="add">[without <span class="ar">ء</span>]</span> <a href="index.php?data=02_b/089_bre">in art. <span class="ar">برى</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرأ</span></h3>
				<div class="sense" id="brO_4_A1">
					<p><span class="ar">ابرأهُ</span> <em>He</em> <span class="auth">(God, Ṣ, M, Ḳ)</span> <span class="add">[<em>recovered him,</em> or]</span> <em>restored him to convalescence,</em> <span class="auth">(M, Ḳ,)</span> <span class="ar long">مِنَ المَرَضِ</span> <span class="add">[<em>from the disease, sickness,</em> or <em>malady</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brO_4_A2">
					<p><span class="ar long">أَبْرَأَكَ مِنَ الأَمْرِ</span> and<span class="arrow"><span class="ar">بَرَّأَكَ↓</span></span> <span class="auth">(M, Ḳ *)</span> <em>He</em> <span class="auth">(i. e. God, TA)</span> <em>made thee, pronounced thee,</em> or <em>held thee,</em> or <em>hath made thee,</em>, &amp;c., or <em>may He make thee,</em>, &amp;c., <em>to be free from the thing</em> or <em>affair,</em> or <em>clear</em> or <em>quit thereof,</em> or <em>guiltless thereof,</em> or <em>irresponsible for it;</em> <span class="auth">(TA;)</span> <span class="add">[or <em>He acquitted thee,</em> or <em>hath acquitted thee,</em> or <em>may He acquit thee, thereof;</em> or <em>He showed thee,</em> or <em>hath showed thee,</em> or <em>may He show thee, to be free from it,</em>, &amp;c.: <a href="#brA2">see also 2, above</a>:]</span> said in relation to <span class="add">[a fault or the like, and]</span> a debt, and a claim, and religion <span class="add">[&amp;c.]</span>. <span class="auth">(M.)</span> You say,<span class="arrow"><span class="ar long">بَرَّأْتُهُ↓ مِنَ العَيْبِ</span></span> <em>I made him, pronounced him,</em> or <em>held him, to be free from the fault, defect, imperfection, blemish,</em> or <em>vice.</em> <span class="auth">(Mṣb.)</span> It is said in the Ḳur <span class="add">[xxxiii. 69]</span>,<span class="arrow"><span class="ar long">فَبَرَّأْهُ↓ ٱللّٰهُ مِمَا قَالُوا</span></span> <span class="auth">(M)</span> <em>But God showed him to be clear of that which they said.</em> <span class="auth">(Bḍ.)</span> You say also, <span class="ar long">أَبْرَأْتُهُ مِنَ الدَّيْنِ</span> <em>I made him, pronounced him,</em> or <em>held him, to be clear,</em> or <em>quit, of the debt; irresponsible for it;</em> or <em>in a state of immunity with respect to it;</em> i. e., <em>exempt from the demand thereof:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">أَبْرَأْتُهُ مِمَّا لِى عَلَيْهِ</span>; and<span class="arrow"><span class="ar">بَرَّأْتُهُ↓</span></span>, inf. n. <span class="ar">تَبْرِئَةٌ</span>; <span class="add">[<em>I acquitted him of that which he owed me:</em>]</span> <span class="auth">(Ṣ:)</span> and <span class="ar">أَبْرَأْتُهُ</span> <span class="add">[alone]</span> <em>I made him, pronounced him,</em> or <em>held him, to be clear,</em> or <em>quit, of a claim that I had upon him,</em> or <em>a due</em> or <em>right that he owed me.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<span class="pb" id="Page_0179"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brO_4_B1">
					<p><span class="ar">ابرأ</span> <span class="add">[in the T <span class="auth">(as on the authority of Aboo-ʼAmr Esh-Sheybánee)</span> <span class="ar">أَبْرَى</span>]</span> <em>He entered upon</em> <span class="add">[<em>the night,</em> or <em>day, called</em>]</span> <span class="ar">البَرَآء</span>, q. v. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brO_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّأ</span></h3>
				<div class="sense" id="brO_5_A1">
					<p><a href="#brA1">see 1</a>, in three places. <span class="ar long">تبرّأ مِنْهُ</span> also signifies <em>He asserted himself to be free from it;</em> or <em>clear,</em> or <em>quit, of it;</em> namely, a fault, or the like. <span class="auth">(Mgh.)</span> <span class="add">[And <em>He declared himself to be clear of him; to be not connected,</em> or <em>implicated, with him; he renounced him:</em> see Ḳur ii. 161 and 162, &amp;c.:]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brO_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبارأ</span></h3>
				<div class="sense" id="brO_6_A1">
					<p><span class="ar">تَبَارَأْنَا</span> <em>We separated ourselves, each from the other.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#brA3">See 3</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brO_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبرأ</span></h3>
				<div class="sense" id="brO_10_A1">
					<p><span class="ar">استبرأ</span>, <span class="auth">(T,)</span> or <span class="ar long">استبرأ مِنَ البَوْلِ</span>, <span class="auth">(Mṣb,)</span> <em>He took extraordinary pains,</em> or <em>the utmost pains, in cleansing the orifice of his penis from the remains of urine, by shaking it and pulling it and the like, until he knew that nothing remained in it:</em> <span class="auth">(T:)</span> or <em>he purified,</em> or <em>cleansed, himself from urine;</em> syn. <span class="ar long">تَنَزَّهُ عَنْهُ</span>: <span class="auth">(Mṣb:)</span> or <span class="ar">استبرأ</span>, <span class="auth">(M,)</span> or <span class="ar long">استبرأ الذَّكَرَ</span>, <span class="auth">(Ḳ, TA,)</span> signifies <em>he took extraordinary pains,</em> or <em>the utmost pains, in cleansing the penis from urine;</em> or <em>he cleansed it entirely from urine;</em> <span class="auth">(M,* Ḳ,* TA;)</span> and so <span class="ar long">استبرأ الفَرْجَ</span>: and in like manner, <span class="ar long">استبرأتِ الفَرْجَ</span> said of a woman: <span class="auth">(El-Munáwee, TA:)</span> but the lawyers make a distinction between <span class="ar">اسْتِبْرَآءٌ</span> and <span class="ar">اِسْتِنْقَآءٌ</span> <span class="add">[which are made syn. in the M and Ḳ]</span>: see the latter word. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brO_10_A2">
					<p>And <span class="ar long">استبرأ الجَارِيَةَ</span>, <span class="auth">(T, Ṣ, Mgh,)</span> or <span class="ar">المَرْأَةَ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> <em>He abstained from sexual intercourse</em> <span class="auth">(T, M, Ḳ)</span> <em>with the girl</em> whom he had purchased or whom he had taken captive, <span class="auth">(T,)</span> or <em>with the woman,</em> <span class="auth">(M, Ḳ,)</span> <em>until she had menstruated</em> <span class="auth">(T, M, Ḳ)</span> <em>at his abode, once, and then become purified:</em> <span class="auth">(T:)</span> the meaning is, <span class="auth">(T,)</span> <em>he sought to find her free from pregnancy.</em> <span class="auth">(T, Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brO_10_A3">
					<p>Hence, <span class="auth">(Mgh,)</span> <span class="ar long">استبرأ الشَّيْءِ</span>, <span class="auth">(Z, Mgh, Mṣb,)</span> or <span class="ar">الأَمْرَ</span>, <span class="auth">(TA,)</span> <em>He searched, searched out,</em> or <em>sought to find</em> or <em>discover, the uttermost of the thing,</em> or <em>affair,</em> <span class="auth">(Z, Mgh, Mṣb, TA,)</span> <em>in order that he might know it,</em> <span class="auth">(Mgh,)</span> <em>to put an end to his doubt.</em> <span class="auth">(Z, Mgh, Mṣb, TA.)</span> You say, <span class="ar long">اِسْتَبْرَأْتُ مَا عِنْدَكَ</span> <span class="add">[<em>I searched,</em> or <em>sought to find</em> or <em>discover,</em> or <em>I have searched,</em>, &amp;c., <em>the uttermost of what thou hast,</em> of knowledge, &amp;c.]</span>. <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">استبرأ أرْضَ كَذَا فَمَا وَجَدَ ضَالَّتَهُ</span> <span class="add">[<em>He searched the uttermost of such a land and found not his stray beast</em>]</span>. <span class="auth">(TA.)</span> It is said in the Expos. of the Jámiʼ eṣ-Ṣagheer that <span class="ar">اِسْتِبْرَآءٌ</span> is an expression denoting The <em>seeking,</em> or <em>seeking leisurely and repeatedly, to obtain knowledge</em> of a thing, <em>until one knows</em> it; <em>considering</em> it <em>with the endeavour to obtain a clear knowledge</em> of it; <em>taking, in doing so, the course prescribed by prudence, precaution, or good judgment.</em> <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buruOapN">
				<h3 class="entry"><span class="ar">بُرُأَةٌ</span></h3>
				<div class="sense" id="buruOapN_A1">
					<p><span class="ar">بُرُأَةٌ</span> <em>A hunter's lurking-place</em> or <em>covert:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> pl. <span class="ar">بُرَأٌ</span>. <span class="auth">(T, Ṣ, M.)</span> El-Aạshà says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بِهَا بُرَأٌ مِثْلُ الفَسِيلِ المُكَمَّمِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>At it</em> <span class="auth">(a source of water mentioned in the context)</span> <em>were hunters' lurking-places, like young palmtrees covered over:</em> for tender young palm-trees are often covered over with a kind of coarse matting]</span>. <span class="auth">(T, Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraMCN">
				<h3 class="entry"><span class="ar">بَرَآءٌ</span></h3>
				<div class="sense" id="baraMCN_A1">
					<p><span class="ar">بَرَآءٌ</span>: <a href="#barieoCN">see <span class="ar">بَرِىْءٌ</span></a>, in six places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: <span class="ar">بَرَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baraMCN_A2">
					<p><span class="ar">البَرَآءٌ</span> <em>The first night of the</em> <span class="add">[<em>lunar</em>]</span> <em>month;</em> <span class="auth">(El-Mázinee, T, Ṣ, Ḳ;)</span> called thus, <span class="auth">(Ṣ,)</span> or <span class="ar long">لَيْلَةُ البَرَآءِ</span>, <span class="auth">(M,)</span> because the moon has then become clear of the sun: <span class="auth">(Ṣ, M:)</span> or <em>the first day of the month:</em> <span class="auth">(AA, T, Ḳ:)</span> or <em>the last night thereof:</em> <span class="auth">(Aṣ, T, Ḳ:)</span> or <em>the last day thereof;</em> <span class="auth">(IAạr, T, Ḳ;)</span> <em>a fortunate day; every event happening therein being regarded as a means of obtaining a blessing;</em> <span class="auth">(IAạr, T;)</span> but most hold that the last day of the month is termed <span class="ar">النَّحِيرَةٌ</span>; <span class="auth">(TA;)</span> as also <span class="ar long">اِبْنُ البَرَآءِ</span>: <span class="auth">(Ḳ:)</span> or this is <em>the first day of the month:</em> <span class="auth">(IAạr, T, TA:)</span> pl. <span class="ar">أَبْرِئَةٌ</span>. <span class="auth">(Th, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buraMCu">
				<h3 class="entry"><span class="ar">بُرَآءُ</span></h3>
				<div class="sense" id="buraMCu_A1">
					<p><span class="ar">بُرَآءُ</span>: <a href="#barieoCN">see <span class="ar">بَرِىْءٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barieoCN">
				<h3 class="entry"><span class="ar">بَرِىْءٌ</span></h3>
				<div class="sense" id="barieoCN_A1">
					<p><span class="ar">بَرِىْءٌ</span> <em>Free,</em> <span class="auth">(Mṣb,)</span> <span class="ar">مِنْهُ</span> <em>from it;</em> namely a fault, defect, imperfection, blemish, or vice; <span class="auth">(Mgh, Mṣb;)</span> and, also followed by <span class="ar">مِنْهُ</span>, <em>clear,</em> or <em>quit, of it; irresponsible for it;</em> or <em>in a state of immunity with respect to it;</em> i. e. <em>exempt from the demand thereof;</em> namely a debt, <span class="auth">(Mṣb,)</span> or a claim, or due, or right; <span class="auth">(Mgh;)</span> as also<span class="arrow"><span class="ar">بَارِىٌ↓</span></span> and<span class="arrow"><span class="ar">بَرَآءٌ↓</span></span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَنَا بَرِىْءٌ مِنْهُ</span> <span class="add">[<em>I am free from it,</em>, &amp;c.]</span>; <span class="auth">(T,* Ṣ, M, Ḳ;*)</span> and<span class="arrow"><span class="ar">بَرَآءٌ↓</span></span>, used alike as sing. and dual and pl. <span class="auth">(Fr, T, Ṣ, M, Ḳ)</span> and masc. and fem., <span class="auth">(Fr, T, M, Ḳ,)</span> because it is originally an inf. n.; <span class="auth">(Fr, T, Ṣ;)</span> and<span class="arrow"><span class="ar">بُرَآءٌ↓</span></span>: <span class="auth">(Ṣ, M:)</span> <a href="#barieoCN">the pl. of <span class="ar">بَرِىْءٌ</span></a> is <span class="ar">بَرِيؤُونَ</span> <span class="auth">(T, Ṣ, Ḳ)</span> and <span class="ar">بُرَأءُ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">بُرَآءٌ</span>, <span class="auth">(T, M, Ḳ,)</span> of the measure <span class="ar">فُعَالٌ</span>, <span class="auth">(T,)</span> like <span class="ar">رُخَالٌ</span>, <span class="auth">(M, Ḳ,)</span> of an extr. measure, disapproved by Suh, who says, in the R, that it is a contraction of <span class="ar">بُرَأءُ</span>, and has tenween because it resembles <span class="add">[words originally of the measure]</span> <span class="ar">فُعَالٌ</span>, and that the rel. n. formed from it is <span class="arrow"><span class="ar">بُرَاوِىٌّ↓</span></span>, <span class="auth">(TA,)</span> but it is mentioned by AAF <a href="#barieoCN">as a pl. of <span class="ar">بَرِىْءٌ</span></a>, and as being like <span class="ar">رُخَالٌ</span>, and Fr mentions <span class="ar">بُرَآءُ</span> as a pl. of the same, imperfectly decl., with one of the two hemzehs suppressed, <span class="auth">(M,)</span> and <span class="ar">بِرَآءٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">أَبْرَآءٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أَبْرِئَآءُ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> the last two anomalous: <span class="auth">(TA:)</span> <a href="#bariYoCN">the fem. of <span class="ar">بَرِيْءٌ</span></a> is <span class="ar">بَرِيْئَةٌ</span>; pl. <span class="ar">بَرِيْآتٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">بَرِيَّاتٌ</span> <span class="auth">(Lḥ, M, Ḳ)</span> and <span class="ar">بَرَايَا</span>. <span class="auth">(T, Ṣ, M, Ḳ.)</span> You say, <span class="ar long">أَنَا بَرِىْءٌ مِنْهُ</span> and <span class="ar long">خَلِىٌّ مِنْهُ</span> <span class="add">[<em>I am free from it;</em> or, more commonly, <em>I am clear,</em> or <em>quit, of it,</em> or <em>him</em>]</span>; and<span class="arrow"><span class="ar long">أنَا بَرَآءٌ↓ مِنْهُ</span></span> and <span class="ar long">خَلَآءٌ مِنْهُ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar long">أَنَا البَرَآءُ↓ مِنْهُ</span></span>: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar long">نَحْنُ مِنْكَ البَرَآءُ↓</span></span> and <span class="ar">الخَلَآءُ</span> <span class="add">[<em>We are clear,</em> or <em>quit, of you</em>]</span>; <span class="auth">(Fr, T;)</span> i. e., <span class="ar long">ذَوُو البَرَآءِ</span>: so says Aboo-Is-ḥáḳ; and Aṣ says the like of what Fr says. <span class="auth">(T.)</span> It is said in the Ḳur <span class="add">[xliii. 25]</span>,<span class="arrow"><span class="ar long">إِنَّنِى بَرَآءٌ↓ مِمَّا تَعْبُدُونَ</span></span> <span class="add">[<em>Verily I am clear of that which ye worship</em>]</span>; <span class="auth">(T, M;)</span> or <span class="ar">بَرِىْءٌ</span>, or<span class="arrow"><span class="ar">بُرَآءٌ↓</span></span>; accord. to different readers. <span class="auth">(Bḍ.)</span> <span class="ar">بَرِىْءٌ</span> occurs in several places in the Ḳur. <span class="auth">(M.)</span> Accord. to IAạr, it signifies <em>Clear of evil qualities</em> or <em>dispositions; shunning what is vain and false; remote from actions that occasion suspicion; pure in heart from associating any with God:</em> and it signifies <em>sound in body and intellect.</em> <span class="auth">(T.)</span> <a href="#baAriyN">See also <span class="ar">بَارِئٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraMCapN">
				<h3 class="entry"><span class="ar">بَرَآءَةٌ</span></h3>
				<div class="sense" id="baraMCapN_A1">
					<p><span class="ar">بَرَآءَةٌ</span> <em>A writing of</em> <span class="add">[i. e. <em>conferring</em>]</span> <em>immunity</em> or <em>exemption:</em> from <span class="ar long">بَرِئَ مِنَ الدَّيْنِ</span> and <span class="ar">العَيْب</span>, of which it is the inf. n.: pl. <span class="ar">بَرَاآتٌ</span>, with medd: <span class="ar">بَرَاوَاتٌ</span> is <span class="add">[<a href="#baraApN">pl. of <span class="ar">بَرَاةٌ</span></a>, and both of these are]</span> vulgar. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buraAwieBN">
				<h3 class="entry"><span class="ar">بُرَاوِىٌّ</span></h3>
				<div class="sense" id="buraAwieBN_A1">
					<p><span class="ar">بُرَاوِىٌّ</span>: <a href="#barieoCN">see <span class="ar">بَرِىْءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbariyBapu">
				<h3 class="entry"><span class="ar">البَرِيَّةُ</span></h3>
				<div class="sense" id="AlbariyBapu_A1">
					<p><span class="ar">البَرِيَّةُ</span> <em>The creation;</em> as meaning <em>the beings,</em> or <em>things, that are created;</em> or, particularly, <em>mankind;</em> syn. <span class="ar">الخَلْقُ</span>: <span class="auth">(T, Ṣ, M:)</span> pronounced without <span class="ar">ء</span>; <span class="auth">(T, Ṣ;)</span> originally with <span class="ar">ء</span>, like <span class="ar">نَبِىٌّ</span> and <span class="ar">ذُرِّيَةٌ</span>; <span class="auth">(M;)</span> and the people of Mekkeh differ from the other Arabs in pronouncing these three words with <span class="ar">ء</span>: <span class="auth">(Yoo, T, M:)</span> Lḥ says that the Arabs agree in omitting the <span class="ar">ء</span> in these three instances; and he does not except the people of Mekkeh: <span class="auth">(M:)</span> it is of the measure <span class="ar">فَعِيلَةٌ</span> in the sense of <span class="ar">مَفْعُولَةٌ</span>, <span class="auth">(Mṣb,)</span> from <span class="ar long">بَرَأَ ٱللّٰهُ الخَلْقَ</span>, meaning <span class="ar">خَلَقَهُمْ</span>: <span class="auth">(Fr, T:)</span> or, if derived from <span class="ar">البَرَى</span> <span class="add">[“earth” or “dust”]</span>, it is originally without <span class="ar">ء</span>: <span class="auth">(Fr, T, Ṣ:)</span> pl. <span class="ar">بَرَايَا</span> and <span class="ar">بَرِيَّاتٌ</span>. <span class="auth">(Ṣ in art. <span class="ar">برو</span> and <span class="ar">برى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAriYN">
				<h3 class="entry"><span class="ar">بَارِئٌ</span></h3>
				<div class="sense" id="baAriYN_A1">
					<p><span class="ar">بَارِئٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">بَارِئٌ مِنْ مَرَضِهِ</span>, <span class="auth">(Lḥ, Ṣ, M,)</span> <span class="add">[<em>Recovering from his disease, sickness,</em> or <em>malady:</em> or]</span> <em>convalescent;</em> or <em>becoming sound,</em> or <em>healthy, at the close of his disease, but being yet weak;</em> or <em>recovering, but not completely, his health and strength:</em> <span class="add">[<a href="#brA1">see 1</a>:]</span> <span class="auth">(M, Ḳ:)</span> as also<span class="arrow"><span class="ar">بَرِئْءٌ↓</span></span>: <span class="auth">(Lḥ, M, Ḳ:)</span> but whether the latter be properly used in this sense is disputed; while the former is said to be the act. part. n. of 1 in all its senses: <span class="auth">(TA:)</span> pl. <span class="ar">بِرَآءٌ</span>, <span class="auth">(M, Ḳ,)</span> like as <span class="ar">صِحَاحٌ</span> <a href="#SaHiyHN">is pl. of <span class="ar">صَحِيحٌ</span></a>, accord. to Lḥ, so that he holds it to be <a href="#barieoCN">pl. of <span class="ar">بَرِىْءٌ</span></a>; or it may be <a href="#baAriyN">pl. of <span class="ar">بَارِئٌ</span></a>, like as <span class="ar">جِيَاعٌ</span> <a href="#jaAyiEN">is pl. of <span class="ar">جَائِعٌ</span></a>, and <span class="ar">صِحَابٌ</span> of <span class="ar">صَاحِبٌ</span>. <span class="auth">(M.)</span> <span class="arrow"><span class="ar">بَرِىْءٌ↓</span></span> is sometimes written and pronounced <span class="ar">بَرِىٌّ</span> <span class="add">[in all its senses]</span>. <span class="auth">(Ḳz.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: <span class="ar">بَارِئٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAriYN_A2">
					<p><a href="#bariYoCN">See also <span class="ar">بَرِيْءٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برأ</span> - Entry: <span class="ar">بَارِئٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAriYN_B1">
					<p><span class="ar">البَارِئُ</span>, applied to God, <em>The Creator;</em> <span class="auth">(T, Ṣ, Mṣb;)</span> <em>He who hath created the things that are created, not after any similitude,</em> or <em>model;</em> <span class="auth">(Nh;)</span> or <em>He who hath created those things free from any incongruity,</em> or <em>faultiness,</em> <span class="auth">(Mgh, and Bḍ in ii. 51,)</span> <em>and distinguished, one from another, by various forms and outward appearances:</em> <span class="auth">(Bḍ:)</span> or <em>the Former,</em> or <em>Fashioner;</em> syn. <span class="ar">المُصَوِّرُ</span> <span class="add">[q. v.]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0178.pdf" target="pdf">
							<span>Lanes Lexicon Page 178</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0179.pdf" target="pdf">
							<span>Lanes Lexicon Page 179</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
