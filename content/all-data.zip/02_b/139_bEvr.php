<article class="root" id="Root_bEvr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/138_bEv">بعث</a></span>
				<span class="ar">بعثر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/140_bEj">بعج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEvr_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بعثر</span></h3>
				<div class="sense" id="bEvr_Q1_A1">
					<p><span class="ar">بَعْثَرَ</span>, <span class="add">[inf. n. <span class="ar">بَعْثَرَةٌ</span>,]</span> <em>He took, drew,</em> or <em>pulled,</em> a thing <em>out,</em> or <em>forth, and uncovered</em> it, <em>laid</em> it <em>open,</em> or <em>exposed</em> it; <span class="auth">(Ṣ, Ḳ;)</span> as also <span class="ar">بَحْثَرَ</span>: <span class="auth">(Ṣ:)</span> <em>he raised</em> what was in a thing, <span class="auth">(Ṣ, Ḳ,)</span> <em>and caused</em> it <em>to come forth.</em> <span class="auth">(Ṣ.)</span> Hence, in the Ḳur <span class="add">[c. 9]</span>, <span class="ar long">إِذَا بُعْثِرَ مَا فِى ٱلْقُبُورِ</span> <em>When that which is in the graves is raised, and caused to come forth:</em> <span class="auth">(AO, Ṣ:)</span> <span class="add">[<a href="#baHovara">see also <span class="ar">بَحْثَرَ</span></a>:]</span> or the meaning is, <em>when the dust,</em> or <em>earth, in the graves is turned over, and the dead in them are raised:</em> <span class="auth">(Zj:)</span> or <em>when what is in the graves,</em> of gold and silver, <em>comes forth;</em> after which the dead are to come forth. <span class="auth">(Fr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعثر</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEvr_Q1_A2">
					<p>Also <em>He examined; he searched.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعثر</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEvr_Q1_A3">
					<p><em>He searched for,</em> or <em>after,</em> or <em>into,</em> news, or tidings. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعثر</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEvr_Q1_A4">
					<p><em>He scattered,</em> or <em>dispersed,</em> a thing, <em>and turned</em> it <em>over, one part upon another:</em> <span class="auth">(Ḳ:)</span> <em>he scattered,</em> or <em>dispersed,</em> his household goods, or his commodities, <span class="auth">(Fr, Ṣ,)</span> <em>and turned</em> them <em>over, one upon another;</em> <span class="auth">(Fr, Zj, Ṣ;)</span> as also <span class="ar">بَحْثَرَ</span>, <span class="auth">(Fr, Ṣ,)</span> and <span class="ar">بَغْثَرَ</span>. <span class="auth">(Yaạḳoob.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعثر</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bEvr_Q1_A5">
					<p><em>He demolished</em> a watering-trough or tank, <em>and turned</em> it <em>upside-down.</em> <span class="auth">(AO, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0223.pdf" target="pdf">
							<span>Lanes Lexicon Page 223</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
