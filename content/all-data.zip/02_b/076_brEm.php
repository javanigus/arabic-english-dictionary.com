<article class="root" id="Root_brEm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/075_brE">برع</a></span>
				<span class="ar">برعم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/077_brgv">برغث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brEm_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برعم</span></h3>
				<div class="sense" id="brEm_Q1_A1">
					<p><span class="ar long">بَرْعَمَتِ الشَّجَرَةُ</span> <em>The tree put forth its</em> <span class="ar">بَرَاعِيم</span> <span class="add">[<a href="#buroEuwmN">pl. of <span class="ar">بُرْعُومٌ</span></a>]</span>, <span class="auth">(Ṣ,)</span> or <em>its</em> <span class="ar">بُرْعُمَة</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroEumN">
				<h3 class="entry"><span class="ar">بُرْعُمٌ</span></h3>
				<div class="sense" id="buroEumN_A1">
					<p><span class="ar">بُرْعُمٌ</span>: <a href="#buroEumapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroEumapN">
				<h3 class="entry"><span class="ar">بُرْعُمَةٌ</span></h3>
				<div class="sense" id="buroEumapN_A1">
					<p><span class="ar">بُرْعُمَةٌ</span>: <a href="#buroEuwmN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroEuwmN">
				<h3 class="entry"><span class="ar">بُرْعُومٌ</span></h3>
				<div class="sense" id="buroEuwmN_A1">
					<p><span class="ar">بُرْعُومٌ</span> and<span class="arrow"><span class="ar">بُرْعُمٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بُرْعُومَةٌ↓</span></span> and<span class="arrow"><span class="ar">بُرْعُمَةٌ↓</span></span> <span class="auth">(Ḳ)</span> The <em>calyx of the fruit,</em> or <em>produce, of a tree:</em> <span class="auth">(Ḳ:)</span> and <em>blossoms,</em> or <em>white blossoms,</em> syn. <span class="ar">نَوْرٌ</span>, <span class="auth">(Ḳ TA,)</span> <em>before they open:</em> <span class="auth">(TA:)</span> or <em>flowers,</em> <span class="auth">(Ṣ, and Mṣb in explanation of the first word in art. <span class="ar">زهر</span>,)</span> or the <em>flower of a tree,</em> <span class="auth">(Ḳ,)</span> <em>before the opening thereof:</em> <span class="auth">(Ṣ, Mṣb ubi suprà, Ḳ:)</span> pl. <span class="ar">بَرَاعِيمُ</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برعم</span> - Entry: <span class="ar">بُرْعُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buroEuwmN_A2">
					<p><span class="ar">بَرَاعِيمُ</span> also signifies The <em>heads,</em> or <em>tops;</em> or <em>round, high, slender tops;</em> or <em>peaks;</em> (<span class="ar">شَمَارِيخ</span>;) of mountains: <span class="auth">(AZ, Ḳ:)</span> sing. <span class="arrow"><span class="ar">بُرْعُومَةٌ↓</span></span>. <span class="auth">(AZ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroEuwmapN">
				<h3 class="entry"><span class="ar">بُرْعُومَةٌ</span></h3>
				<div class="sense" id="buroEuwmapN_A1">
					<p><span class="ar">بُرْعُومَةٌ</span>: <a href="#buroEuwmN">see <span class="ar">بُرْعُومٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0189.pdf" target="pdf">
							<span>Lanes Lexicon Page 189</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
