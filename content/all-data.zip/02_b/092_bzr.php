<article class="root" id="Root_bzr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/091_bzx">بزخ</a></span>
				<span class="ar">بزر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/093_bzg">بزغ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bzr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزر</span></h3>
				<div class="sense" id="bzr_1_A1">
					<p><span class="ar long">بَزَرَ القِدْرَ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُرُ</span>}</span></add> or <span class="ar">ـِ</span>, accord. to the rule of the Ḳ,]</span> inf. n. <span class="ar">بَزْرٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">بزّرها↓</span></span>, <span class="auth">(A,)</span> inf. n. <span class="ar">تَبْزِيرٌ</span>; <span class="auth">(TA;)</span> <em>He threw,</em> or <em>put,</em> <span class="ar">أَبْزَار</span>, <span class="auth">(A,)</span> or <span class="ar">إِبْزَار</span>, <span class="auth">(Mṣb,)</span> or <span class="ar">أَبَازِير</span>, <span class="auth">(A, Ḳ,)</span> <span class="add">[i. e. <em>seeds for seasoning the food,</em>]</span> <em>into the cooking-pot.</em> <span class="auth">(A, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzr_1_A2">
					<p><span class="add">[Hence,]</span><span class="arrow"><span class="ar long">بزّر↓ كَلَامَهُ</span></span> ‡ <em>He seasoned</em> (<span class="ar">تَوْبَلَ</span> <span class="add">[meaning <em>he embel-lished</em>]</span>) <em>his speech,</em> or <em>language.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bzr_1_A3">
					<p><span class="ar">بَزَرَ</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">بَزْرٌ</span>, <span class="auth">(Ḳ,)</span> also signifies <em>He sowed</em> <span class="auth">(Ḳ, TḲ)</span> seeds; <span class="auth">(TḲ;)</span> <em>i. q.</em> <span class="ar">بَذَرَ</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bzr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بزّر</span></h3>
				<div class="sense" id="bzr_2_A1">
					<p><a href="#bzr_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bazorN">
				<h3 class="entry"><span class="ar">بَزْرٌ</span></h3>
				<div class="sense" id="bazorN_A1">
					<p><span class="ar">بَزْرٌ</span>: <a href="#bizorN">see what next follows</a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bizorN">
				<h3 class="entry"><span class="ar">بِزْرٌ</span></h3>
				<div class="sense" id="bizorN_A1">
					<p><span class="ar">بِزْرٌ</span> and<span class="arrow"><span class="ar">بَزْرٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> the former the more chaste, <span class="auth">(T, Ṣ, Mṣb,)</span> or the only form used by persons of chaste speech, <span class="auth">(ISk, T, Mṣb,)</span> The <em>seed of herbs</em> or <em>leguminous plants,</em> <span class="auth">(Ṣ, A, Mgh, Mṣb,)</span> <em>and of other plants:</em> <span class="auth">(Ṣ, A, Mṣb:)</span> or <em>small seed</em> or <em>grain, such as that of herbs</em> or <em>leguminous plants and the like:</em> <span class="auth">(TA:)</span> or <em>any seed,</em> or <em>grain, that is sown</em> <span class="auth">(Kh, Mṣb, Ḳ)</span> <em>for vegetation;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">بَذْرٌ</span> <span class="add">[q. v.]</span>: <span class="auth">(Kh, Mṣb:)</span> pl. <span class="ar">بُزُورٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: <span class="ar">بِزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bizorN_A2">
					<p>And <em>Seeds that are used in cooking, for seasoning food;</em> syn. <span class="ar">تَابَلٌ</span>: pl. <span class="arrow"><span class="ar">أَبْزَارٌ↓</span></span> and <span class="ar">أَبَازِيرٌ</span>; <span class="auth">(Ḳ;)</span> the latter of which <a href="#OabozaArN">is pl. of <span class="ar">أَبْزَارٌ</span></a>; <span class="auth">(TA;)</span> or of this word and of <span class="arrow"><span class="ar">إِبْزَارٌ↓</span></span>; both of which are sings.; arabicized <span class="add">[from the Persian <span class="ar">أَفْزَارْ</span>]</span>; the former of them anomalous, being of a pl. form: <span class="auth">(Mṣb:)</span> <span class="ar">أَبْزَارٌ</span> and <span class="ar">أَبَازِيرُ</span> are <em>syn. with</em> <span class="ar">تَوَابِلُ</span>: <span class="auth">(Ṣ:)</span> or <span class="ar">ابزار</span> and <span class="ar">توابل</span> both signify <em>that with which food is seasoned;</em> but the former of these is applied to <em>what is moist</em> and <em>what is dry;</em> and the latter, to what is dry only: this distinction, however, appears to be conventional <span class="add">[and modern]</span>; for the <span class="add">[classical]</span> language of the Arabs does not indicate it. <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: <span class="ar">بِزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bizorN_A3">
					<p>Hence,<span class="arrow"><span class="ar">أَبَازِيرُ↓</span></span> also signifies ‡ <em>Additions</em> <span class="add">[or <em>embellishments</em>]</span> <em>in speech.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: <span class="ar">بِزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bizorN_A4">
					<p><span class="ar">بِزْرٌ</span> and<span class="arrow"><span class="ar">بَزْرٌ↓</span></span> signify also <em>Oil of</em> <span class="ar">بَزْر</span> <span class="add">[i. e. of <em>seeds</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="ar long">بِزْرُ الكَتَّانِ</span> <span class="add">[commonly meaning <em>Linseed</em>]</span> signifies <em>linseed-oil</em> in the dial. of the people of Baghdád. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: <span class="ar">بِزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bizorN_A5">
					<p>Also <span class="arrow"><span class="ar">بَزْرٌ↓</span></span>, <span class="auth">(Mgh,)</span> or <span class="ar long">بَزْرُ القَزِّ</span>, <span class="auth">(Mṣb,)</span> ‡ <em>The eggs of the silk-worm.</em> <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزر</span> - Entry: <span class="ar">بِزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bizorN_A6">
					<p>And<span class="arrow">↓</span> the former of these, † <em>Offspring.</em> <span class="auth">(Ḳ, TA.)</span> One says,<span class="arrow"><span class="ar long">مَا أَكْثَرَ بَزْرَهُ↓</span></span> † <em>How numerous is his offspring!</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bazoraMCu">
				<h3 class="entry"><span class="ar">بَزْرَآءُ</span></h3>
				<div class="sense" id="bazoraMCu_A1">
					<p><span class="ar">بَزْرَآءُ</span>: <a href="#mabozuwrN">see <span class="ar">مَبْزُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bazorieBN">
				<h3 class="entry"><span class="ar">بَزْرِىٌّ</span></h3>
				<div class="sense" id="bazorieBN_A1">
					<p><span class="ar">بَزْرِىٌّ</span> <em>One who expresses the oil of</em> <span class="ar">بِزْر</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bazBaArN">
				<h3 class="entry"><span class="ar">بَزَّارٌ</span></h3>
				<div class="sense" id="bazBaArN_A1">
					<p><span class="ar">بَزَّارٌ</span> <em>One who sells</em> <span class="ar long">بِزْر الكَتَّان</span>, i. e., <em>linseed-oil,</em> in the dial. of the people of Baghdád. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAzuwrN">
				<h3 class="entry"><span class="ar">بَازُورٌ</span></h3>
				<div class="sense" id="baAzuwrN_A1">
					<p><span class="ar">بَازُورٌ</span> ‡ A man <em>who induces in one,</em> or <em>throws one into, doubt</em> or <em>suspicion;</em> from the phrase <span class="ar long">بَزَّرَ كَلَامَهُ</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabozaArN">
				<h3 class="entry"><span class="ar">أَبْزَارٌ</span></h3>
				<div class="sense" id="OabozaArN_A1">
					<p><span class="ar">أَبْزَارٌ</span> and <span class="ar">إِبْزَارٌ</span>: pl. <span class="ar">أَبَازِيرُ</span>: <a href="#bizorN">see <span class="ar">بِزْرٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabozaArieBN">
				<h3 class="entry"><span class="ar">أَبْزَارِىٌّ</span></h3>
				<div class="sense" id="OabozaArieBN_A1">
					<p><span class="ar">أَبْزَارِىٌّ</span> <span class="add">[<em>One who sells</em> <span class="ar">أَبْزَار</span> or <span class="ar">إِبْزَار</span>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubazBarN">
				<h3 class="entry"><span class="ar">مُبَزَّرٌ</span></h3>
				<div class="sense" id="mubazBarN_A1">
					<p><span class="ar">مُبَزَّرٌ</span> <em>Seasoned with</em> <span class="ar">أَبَازِير</span>, i. e. <span class="ar">تَوَابِل</span>. <span class="auth">(Mgh.)</span> <span class="add">[<a href="#bizorN">See <span class="ar">بِزْرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabozuwrN">
				<h3 class="entry"><span class="ar">مَبْزُورٌ</span></h3>
				<div class="sense" id="mabozuwrN_A1">
					<p><span class="ar">مَبْزُورٌ</span> † <em>Having many children;</em> applied to a man: and so<span class="arrow"><span class="ar">بَزْرَآءُ↓</span></span> applied to a woman. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0199.pdf" target="pdf">
							<span>Lanes Lexicon Page 199</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
