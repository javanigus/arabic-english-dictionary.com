<article class="root" id="Root_brnk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/084_brns">برنس</a></span>
				<span class="ar">برنك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/086_brh">بره</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="baronakaMCu.1">
				<h3 class="entry"><span class="ar">بَرْنَكَآءُ</span> / 
							<span class="ar">بَرْنَكَانٌ</span> / 
							<span class="ar">بَرْنَكَانِىٌّ</span></h3>
				<div class="sense" id="baronakaMCu.1_A1">
					<p><span class="ar">بَرْنَكَآءُ</span> and <span class="ar">بَرْنَكَانٌ</span> and <span class="ar">بَرْنَكَانِىٌّ</span>: <a href="#barBakaAnN">see <span class="ar">بَرَّكَانٌ</span></a>, <a href="index.php?data=02_b/081_brk">in art. <span class="ar">برك</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0196.pdf" target="pdf">
							<span>Lanes Lexicon Page 196</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
