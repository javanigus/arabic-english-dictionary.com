<article class="root" id="Root_bnw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/196_bnm">بنم</a></span>
				<span class="ar">بنو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/198_bne">بنى</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bnw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بنو</span> ⇒ <span class="ar">بنى</span></h3>
				<div class="sense" id="bnw_1_A1">
					<p><span class="ar">بَنَا</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْنُوُ</span>}</span></add>: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AibonN.1">
				<h3 class="entry"><span class="ar">اِبْنٌ</span></h3>
				<div class="sense" id="AibonN.1_A1">
					<p><span class="ar">اِبْنٌ</span>, held by some to be originally <span class="ar">بَنَوٌ</span>: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bunuwBapN">
				<h3 class="entry"><span class="ar">بُنُوَّةٌ</span></h3>
				<div class="sense" id="bunuwBapN_A1">
					<p><span class="ar">بُنُوَّةٌ</span>: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="banawiyBN">
				<h3 class="entry"><span class="ar">بَنَوِيٌّ</span></h3>
				<div class="sense" id="banawiyBN_A1">
					<p><span class="ar">بَنَوِيٌّ</span>: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0260.pdf" target="pdf">
							<span>Lanes Lexicon Page 260</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
