<article class="root" id="Root_bXq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/110_bXE">بشع</a></span>
				<span class="ar">بشق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/112_bXm">بشم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bXq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بشق</span></h3>
				<div class="sense" id="bXq_1_A1">
					<p><span class="ar">بَشِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْشَقُ</span>}</span></add>; and <span class="ar">بَشَقَ</span>, aor <span class="ar">ـِ</span>; <em>He struck, smote,</em> or <em>beat,</em> another with a staff or stick. <span class="auth">(Nawádir el-Aaráb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bXq_1_B1">
					<p><em>He looked sharply, or intently:</em> <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> inf. n. <span class="ar">بَشْقٌ</span>. <span class="auth">(JK.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bXq_1_C1">
					<p>Also the former verb, <em>He hastened,</em> or <em>was quick;</em> as also <span class="ar">بَشَكَ</span>. <span class="auth">(IDrd, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bXq_1_D1">
					<p>And the former, <span class="add">[but the aor. is not mentioned,]</span> <em>He cut</em> a garment, or piece of cloth, <em>in a light,</em> or <em>prompt, manner;</em> as also <span class="ar">بَشَكَ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بشق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="bXq_1_E1">
					<p>And <span class="ar">بَشَقَ</span>, inf. n. <span class="ar">بَشْقٌ</span>, <em>He took,</em> or <em>seized.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baXoqN">
				<h3 class="entry"><span class="ar">بَشْقٌ</span></h3>
				<div class="sense" id="baXoqN_A1">
					<p><span class="ar long">نَظَرٌ بَشْقٌ</span> <em>A sharp,</em> or <em>an intent, look.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAXaqN">
				<h3 class="entry"><span class="ar">بَاشَقٌ</span></h3>
				<div class="sense" id="baAXaqN_A1">
					<p><span class="ar">بَاشَقٌ</span> <span class="auth">(JK, Mṣb, Ḳ)</span> and <span class="ar">بَاشِقٌ</span>, <span class="auth">(Mṣb, Es-Suyootee, TA,)</span> the latter being allowable accord. to some for the sake of conformity to the usual Arabic measure, as in <span class="ar">خاتم</span> and <span class="ar">دانق</span> and <span class="ar">طابع</span> and the like; <span class="auth">(Mṣb;)</span> perhaps derived from <span class="ar">بَشْقٌ</span> meaning the “looking sharply,” or “intently;” <span class="auth">(JK;)</span> or from <span class="ar">بَشَقَ</span> meaning “he took,” or “seized;” <span class="auth">(Mṣb;)</span> or it is arabicized, <span class="auth">(Mṣb, Ḳ,)</span> from <span class="add">[the Persian]</span> <span class="ar">بَاشَهْ</span>; <span class="auth">(Ḳ;)</span> <em>A certain bird;</em> <span class="auth">(Ḳ;)</span> <span class="add">[the <em>musket,</em> or <em>sparrow-hawk; falco nisus;</em>]</span> <em>a bird of beautiful form, the smallest of birds of prey, that preys upon sparrows and other birds of their size:</em> <span class="auth">(Ḳzw:)</span> <em>it is of the birds called</em> <span class="ar">صُقُور</span>, <span class="add">[<a href="#SaqorN">pl. of <span class="ar">صَقْرٌ</span></a>,]</span> as are also the <span class="ar">بَازِى</span> and the <span class="ar">شَاهِين</span> and the <span class="ar">زُرَّق</span> and the <span class="ar">يُؤْيُؤ</span>: <span class="auth">(AḤát in “the Book of Birds,” TA:)</span> pl. <span class="ar">بَوَاشِقُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0209.pdf" target="pdf">
							<span>Lanes Lexicon Page 209</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
