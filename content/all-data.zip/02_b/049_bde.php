<article class="root" id="Root_bde">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/048_bdw">بدو</a></span>
				<span class="ar">بدى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/050_bc">بذ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bde_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدى</span></h3>
				<div class="sense" id="bde_1_A1">
					<p><span class="ar long">بَدِيتُ بِالشَّىْءِ</span> and <span class="ar long">بَدَيْتُ بِهِ</span><em>i. q.</em> <span class="add">[<span class="ar">بَدَأْتُ</span> and]</span> <span class="ar">اِبْتَدَأْتُ</span> <span class="add">[<em>I began with the thing;</em> or <em>made it to have precedence,</em> or <em>to be first</em>]</span>; <span class="auth">(M, Ḳ;)</span> of the dial. of the Ansár: <span class="auth">(M:)</span> the people of El-Medeeneh say, <span class="ar">بَدَيْنَا</span>, or <span class="ar">بَدِينَا</span>, <span class="add">[accord. to different copies of the Ṣ,]</span> in the sense of <span class="ar">بَدَأْنَا</span>: <span class="auth">(Ṣ:)</span> <span class="add">[the right reading seems to be <span class="ar">بَدَيْنَا</span>; for]</span> IKh says, none says <span class="ar">بَدَيْتُ</span> in the sense of <span class="ar">بَدَأْتُ</span>, except the Ansár: all others say, <span class="ar">بَدِيتُ</span> and <span class="ar">بَدَأْتُ</span>; when the hemzeh is suppressed, the <span class="ar">د</span> is pronounced with kesr, and therefore the hemzeh is changed into <span class="ar">ى</span>. <span class="auth">(IB, TA.)</span> <span class="add">[See a verse of Ibn-Rawáhah cited voce <span class="ar">بَدْءٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bidaAyapN">
				<h3 class="entry"><span class="ar">بِدَايَةٌ</span></h3>
				<div class="sense" id="bidaAyapN_A1">
					<p><span class="ar">بِدَايَةٌ</span>, said by Mṭr to be a vulgar word, and by IB to be erroneous, but by IḲṭṭ to be of the dial. of the Ansár: <a href="../">see art. <span class="ar">بدأ</span></a> <span class="add">[voce <span class="ar">بَدْءٌ</span>, second sentence, in two places]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0172.pdf" target="pdf">
							<span>Lanes Lexicon Page 172</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
