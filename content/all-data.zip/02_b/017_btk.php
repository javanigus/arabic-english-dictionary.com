<article class="root" id="Root_btk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/016_btE">بتع</a></span>
				<span class="ar">بتك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/018_btl">بتل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="btk_1">
				<h3 class="entry">1. ⇒ <span class="ar">بتك</span></h3>
				<div class="sense" id="btk_1_A1">
					<p><span class="ar">بَتَكَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِكُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْتُكُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَتْكٌ</span>, <span class="auth">(Ṣ,)</span> <em>He cut it;</em> or <em>severed it,</em> or <em>cut it off,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>entirely,</em> or <em>from its root;</em> <span class="auth">(TA;)</span> and in like manner,<span class="arrow"><span class="ar">بتّكهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْتِيكٌ</span>; <span class="auth">(TA;)</span> but <span class="ar">بتَك</span> is with teshdeed to denote muchness, or frequency, of the action, or its application to many objects. <span class="auth">(Ṣ, TA.)</span> <span class="ar long">آذَانَ الأَنْعَامِ</span>, in the Ḳur <span class="add">[iv. 118]</span>, accord. to Abu-l-ʼAbbás, <span class="auth">(TA,)</span> means <em>And they shall assuredly cut,</em> or <em>cut off, the ears of the cattle:</em> <span class="auth">(Ṣ,* TA:)</span> or, as Az thinks, <em>slit the ears of the cattle,</em> as they did in the time of ignorance. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btk_1_A2">
					<p>Also <em>He plucked it out; he laid hold upon it and pulled it towards him so that it became severed from its root and plucked out;</em> <span class="auth">(Lth, Ṣ,* TA;)</span> namely, a hair, or feather, or the like. <span class="auth">(Lth, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="btk_2">
				<h3 class="entry">2. ⇒ <span class="ar">بتّك</span></h3>
				<div class="sense" id="btk_2_A1">
					<p><a href="#btk_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="btk_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبتّك</span></h3>
				<div class="sense" id="btk_5_A1">
					<p><a href="#btk_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="btk_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبتك</span></h3>
				<div class="sense" id="btk_7_A1">
					<p><span class="ar">انبتك</span> <em>It became cut;</em> or <em>became severed, or cut off,</em> <span class="auth">(Ṣ,* Ḳ,)</span> <em>entirely,</em> or <em>from its root;</em> <span class="auth">(TA;)</span> and in like manner,<span class="arrow"><span class="ar">تبتّك↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتك</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btk_7_A2">
					<p>Also <em>It became plucked out.</em> <span class="auth">(Lth, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bitokapN">
				<h3 class="entry"><span class="ar">بِتْكَةٌ</span></h3>
				<div class="sense" id="bitokapN_A1">
					<p><span class="ar">بِتْكَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بَتْكَةٌ</span> <span class="auth">(Ḳ)</span> <em>A piece,</em> or <em>portion,</em> of a thing, <em>cut off,</em> or <em>severed:</em> pl. <span class="ar">بِتَكٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> Hence the saying of the poet, <span class="auth">(Ṣ,)</span> namely, Zuheyr, <span class="auth">(TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حَتَّى إِذَا مَا هَوَتع كَفُّ الغُلَامِ لَهَا</span> *</div> 
						<div class="star">* <span class="ar long">طَارَتْ وَفِى كَفِّهِ مِنْ رِيشِهَا بِتَكُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Until, when the hand of the boy descends to her, she flies, while portions of her feathers, plucked out, are in his hand</em>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتك</span> - Entry: <span class="ar">بِتْكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bitokapN_A2">
					<p>And <span class="add">[hence,]</span> <em>i. q.</em> <span class="ar long">جُهْمَةٌ مِنَ اللَّيْلِ</span> <span class="add">[i. e. <em>A portion at the commencement of the latter parts of the night,</em> accord. to the Ṣ and Ḳ in art. <span class="ar">جهم</span>; or <em>a remaining portion of darkness in the latter part of the night,</em> accord. to the Ḳ in that art.]</span>: <span class="auth">(Ṣ, Ḳ:)</span> as though it were a division <span class="add">[or portion cut off]</span> of the night. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="batuwkN">
				<h3 class="entry"><span class="ar">بَتُوكٌ</span></h3>
				<div class="sense" id="batuwkN_A1">
					<p><span class="ar">بَتُوكٌ</span>: <a href="#baAtikN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAtikN">
				<h3 class="entry"><span class="ar">بَاتِكٌ</span></h3>
				<div class="sense" id="baAtikN_A1">
					<p><span class="ar">بَاتِكٌ</span> <span class="auth">(applied to a sword, Ṣ)</span> <em>Sharp,</em> or <em>cutting;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَتُوكٌ↓</span></span>: <span class="auth">(Ḳ:)</span> <span class="add">[but the latter is an intensive epithet, signifying <em>very sharp;</em> or <em>cutting much,</em> or <em>keenly</em>]</span>: the pl. <span class="add">[of the former]</span> is <span class="ar">بَوَاتِكُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0150.pdf" target="pdf">
							<span>Lanes Lexicon Page 150</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
