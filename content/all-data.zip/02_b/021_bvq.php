<article class="root" id="Root_bvq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/020_bvr">بثر</a></span>
				<span class="ar">بثق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/022_bjH">بجح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bvq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بثق</span></h3>
				<div class="sense" id="bvq_1_A1">
					<p><span class="ar long">بَثَقَ المَآءَ</span>, <span class="auth">(Mgh, Mṣb,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْثِقُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُقُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَثْقٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> <em>He made an opening for the water by breaking through the bank,</em> or <em>the dam that confined it.</em> <span class="auth">(Mgh, Mṣb.*)</span> And <span class="ar long">بَثَقَ النَّهْرَ</span>, inf. n. <span class="ar">بَثْقٌ</span> <span class="auth">(Lth, Ḳ)</span> and <span class="ar">بِثْقٌ</span>, <span class="auth">(Ḳ, TA,)</span> in some of the copies of the Ṣ <span class="add">[and in the CK]</span> <span class="ar">بَثَقٌ</span>, but this is wrong, though Ru-beh has used it by poetic license, <span class="auth">(TA,)</span> and <span class="ar">تَبْثَاقٌ</span>, <span class="auth">(Ḳ,)</span> <em>He broke</em> <span class="add">[<em>through</em>]</span> <em>the bank of the river,</em> or <em>rivulet, in order that the water might pour out,</em> or <em>flow forth;</em> <span class="auth">(Lth, Ḳ, TA;)</span> <span class="pb" id="Page_0152"></span>as also<span class="arrow"><span class="ar">بثُق↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْثِيقٌ</span>; the latter not commonly mentioned. <span class="auth">(TA.)</span> And <span class="ar long">بَثَقَ السَّيْلُ مَوْضِعَ كَذَا</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُقُ</span>}</span></add>, inf. n. <span class="ar">بَثْقٌ</span> and <span class="ar">بِثْقٌ</span>, on the authority of Yaạḳoob, <em>The torrent broke through, and clave, such a place.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bvq_1_B1">
					<p><a href="#bvq_7">See also 7</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bvq_1_B2">
					<p><span class="ar long">بَثَقَت العَيْنُ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُقُ</span>}</span></add>, inf. n. <span class="ar">بَثْقٌ</span> and <span class="ar">تَبْثَاقٌ</span>, <span class="auth">(TA,)</span> <em>The eye shed tears quickly.</em> <span class="auth">(AA, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bvq_1_B3">
					<p><span class="ar long">بَثَقَتِ الرَّكِيَّةُ</span>, <span class="auth">(AZ, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْثُقُ</span>}</span></add>, <span class="auth">(AZ, TA,)</span> inf. n. <span class="ar">بُثُوقٌ</span> <em>The well became full, and abundant in water.</em> <span class="auth">(AZ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bvq_1_C1">
					<p><span class="ar">بَثِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْثَقُ</span>}</span></add>, <span class="add">[inf. n., by rule, <span class="ar">بَثَقٌ</span>,]</span> <em>It</em> <span class="auth">(seed-produce)</span> <em>became affected with the disease termed</em> <span class="ar">بَثْقٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bvq_2">
				<h3 class="entry">2. ⇒ <span class="ar">بثّق</span></h3>
				<div class="sense" id="bvq_2_A1">
					<p><a href="#bvq_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bvq_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبثق</span></h3>
				<div class="sense" id="bvq_7_A1">
					<p><span class="ar">انبثق</span> <em>It</em> <span class="auth">(water)</span> <em>had vent;</em> or <em>it poured out,</em> or <em>flowed forth:</em> <span class="auth">(Ṣ, Mṣb,* Ḳ:)</span> or <em>it ran,</em> or <em>flowed, of itself, without the breaking through of a dam or the like.</em> <span class="auth">(Mgh.)</span> <span class="add">[For <span class="ar">اِنْفَجَرَ</span>, in the Ṣ, Golius appears to have found <span class="ar">اِنْفَرَجَ</span>, which is a mistake.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bvq_7_A2">
					<p><span class="add">[The Christians, as Golius has observed, use this verb to denote the procession of the Holy Spirit.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bvq_7_A3">
					<p><span class="ar long">انبثق السَّيْلُ عَلَيْهِمْ</span> ‡ <em>The torrent came upon them without their expecting it,</em> or <em>thinking it.</em> <span class="auth">(Ḳ,* TA.)</span> And<span class="arrow"><span class="ar long">بَثَقَ↓ المَآءُ عَلَيْهِمْ</span></span> † <em>The water came upon them.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bvq_7_A4">
					<p><span class="ar long">انبثق عَلَيْهِمْ بِالكِلَامِ</span> ‡ <em>He came upon them with speech without their expecting it.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bvq_7_A5">
					<p><span class="ar long">انبثقت الأَرْضُ</span> ‡ <em>The land became abundant in herbage,</em> or <em>fruitful.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bavoqN">
				<h3 class="entry"><span class="ar">بَثْقٌ</span></h3>
				<div class="sense" id="bavoqN_A1">
					<p><span class="ar">بَثْقٌ</span> and<span class="arrow"><span class="ar">بِثْقٌ↓</span></span> <em>An opening made for water by breaking through the bank,</em> or <em>the dam that confined it:</em> <span class="auth">(Mgh, Mṣb:*)</span> or the <em>place where the bank of a river,</em> or <em>rivulet, is broken</em> <span class="add">[<em>through</em>]</span> <em>in order that the water may pour out,</em> or <em>flow forth: a place where water has vent,</em> or <em>pours out,</em> or <em>flows forth:</em> <span class="auth">(Ḳ:)</span> or the latter signifies <em>a place furrowed,</em> or <em>hollowed out, by water:</em> <span class="auth">(JK:)</span> pl. <span class="ar">بُثُوقٌ</span>. <span class="auth">(JK, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: <span class="ar">بَثْقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bavoqN_B1">
					<p>Also the former, <em>A disease that affects seed-produce, occasioned by rain.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bivoqN">
				<h3 class="entry"><span class="ar">بِثْقٌ</span></h3>
				<div class="sense" id="bivoqN_A1">
					<p><span class="ar">بِثْقٌ</span>: <a href="#bavoqN">see <span class="ar">بَثْقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAviqN">
				<h3 class="entry"><span class="ar">بَاثِقٌ</span></h3>
				<div class="sense" id="baAviqN_A1">
					<p><span class="ar">بَاثِقٌ</span> <span class="add">[act. part. n. of 1]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: <span class="ar">بَاثِقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAviqN_A2">
					<p><span class="ar long">رَكِيَّةٌ بَاثِقَةٌ</span> <em>A well full, and abundant in water.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">مِيَاهٌ بُثَّقٌ</span> <span class="add">[<a href="#baAviqN">pl. of <span class="ar">بَاثِقٌ</span></a>]</span>, like <span class="ar">رُكَّعٌ</span> <span class="add">[<a href="#raAkiEN">pl. of <span class="ar">رَاكِعٌ</span></a>, app. <em>Waters flowing forth abundantly</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بثق</span> - Entry: <span class="ar">بَاثِقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAviqN_A3">
					<p><span class="add">[Hence,]</span> <span class="ar long">هُوَ بَاثِقُ الكَرَمِ</span> † <em>He is abundant in generosity.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0151.pdf" target="pdf">
							<span>Lanes Lexicon Page 151</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0152.pdf" target="pdf">
							<span>Lanes Lexicon Page 152</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
