<article class="root" id="Root_bkt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/163_bkO">بكأ</a></span>
				<span class="ar">بكت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/165_bkr">بكر</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bkt_1">
				<h3 class="entry">1. ⇒ <span class="ar">بكت</span></h3>
				<div class="sense" id="bkt_1_A1">
					<p><a href="#bkt_2">see 2</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bkt_2">
				<h3 class="entry">2. ⇒ <span class="ar">بكّت</span></h3>
				<div class="sense" id="bkt_2_A1">
					<p><span class="ar">بكّتهُ</span>, inf. n. <span class="ar">تَبْكِيتٌ</span>, <em>He reprehended, reproved, blamed, chid,</em> or <em>reproached, him, for an affair,</em> or <em>for a crime</em> or <em>the like;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> accord. to some, <em>with justice;</em> <span class="auth">(TA;)</span> or <em>he did so severely;</em> <span class="auth">(Ṣ,* TA;)</span> <em>and threatened him;</em> <span class="auth">(TA;)</span> <em>and declared his deed to be evil;</em> <span class="auth">(Mṣb;)</span> <em>as when one says,</em> “<em>O wicked man! wast thou not ashamed? didst thou not fear God?</em>” <span class="auth">(TA:)</span> and sometimes this is done <em>by using an enunciative phrase, such as the saying of Abraham,</em> <span class="add">[mentioned in the Ḳur xxi. 64,]</span> “<em>Nay, the chief of them, this, did it;</em>” for thus he said to reprove their worship of idols; <span class="auth">(Mṣb;)</span> and it may be <em>by means of the hand,</em> and <em>a staff</em> or <em>stick,</em> and <em>the like.</em> <span class="auth">(Hr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkt_2_A2">
					<p><em>He accused him, to his face,</em> (<span class="ar">اِسْتَقْبَلَهُ</span>, q. v.,) <em>of that which he disliked,</em> or <em>hated;</em> <span class="auth">(Aṣ, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَكَتَهُ↓</span></span>, <span class="auth">(Aṣ, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْكُتُ</span>}</span></add>, inf. n. <span class="ar">بَكْتٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bkt_2_A3">
					<p><em>He overcame him,</em> <span class="ar">بِالحُجَّةِ</span> <span class="add">[<em>with the argument, allegation,</em> or <em>plea</em>]</span>; <span class="auth">(Ṣ, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَكَتَهُ↓</span></span>; <span class="auth">(A, TA;)</span> and both, <em>he obliged him to be silent by reason of his inability to reply.</em> <span class="auth">(A,* TA.)</span> You say, <span class="ar long">بكّتهُ حَتَّى أَسْكَتَهُ</span>, and<span class="arrow"><span class="ar">بَكَتَهُ↓</span></span>, <em>He overcame him</em> <span class="add">[by an argument, &amp;c.,]</span> <em>so that he silenced him.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bkt_2_A4">
					<p>Also, <span class="auth">(Lth, TA,)</span> and<span class="arrow"><span class="ar">بَكَتَهُ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> aor. and inf. n. as above, <span class="auth">(TA,)</span> <em>He beat, struck,</em> or <em>smote, him</em> <span class="auth">(Ḳ, TA)</span> with a staff or stick, and a sword, <span class="auth">(Lth, Ḳ, TA,)</span> and the like. <span class="auth">(Lth, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubakBitN">
				<h3 class="entry"><span class="ar">مُبَكِّتٌ</span></h3>
				<div class="sense" id="mubakBitN_A1">
					<p><span class="ar">مُبَكِّتٌ</span> A woman <em>who usually brings forth a male child after a female.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[Such a woman is app. thus called because supposed to reproach her husband for his having been displeased with her on her bringing forth a female.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0239.pdf" target="pdf">
							<span>Lanes Lexicon Page 239</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
