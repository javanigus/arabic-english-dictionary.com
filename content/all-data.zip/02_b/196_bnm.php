<article class="root" id="Root_bnm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/195_bnq">بنق</a></span>
				<span class="ar">بنم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/197_bnw">بنو</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="AibonumN">
				<h3 class="entry"><span class="ar">اِبْنُمٌ</span> / 
							<span class="ar">اِبْنَمٌ</span> / 
							<span class="ar">ٱبْنُمٌ</span> / 
							<span class="ar">ٱبْنَمٌ</span> / 
							<span class="ar">ٱبْنِيمَا</span></h3>
				<div class="sense" id="AibonumN_A1">
					<p><span class="ar">اِبْنُمٌ</span> or <span class="ar">اِبْنَمٌ</span>, and <span class="ar">ٱبْنُمٌ</span> or <span class="ar">ٱبْنَمٌ</span>; and <span class="ar">ٱبْنِيمَا</span> for <span class="ar">ٱبْنِمَا</span>: <a href="#IibonN">see <span class="ar">اِبْنٌ</span></a>, <a href="index.php?data=02_b/198_bne">in art. <span class="ar">بنى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0260.pdf" target="pdf">
							<span>Lanes Lexicon Page 260</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
