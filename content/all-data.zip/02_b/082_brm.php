<article class="root" id="Root_brm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/081_brk">برك</a></span>
				<span class="ar">برم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/083_brn">برن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brm_1">
				<h3 class="entry">1. ⇒ <span class="ar">برم</span></h3>
				<div class="sense" id="brm_1_A1">
					<p><span class="ar">بَرَمَهُ</span>: <a href="#brm_4">see 4</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brm_1_B1">
					<p><span class="ar">بَرِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَمُ</span>}</span></add>; and<span class="arrow"><span class="ar">تبرّم↓</span></span>; <em>He was,</em> or <em>became, affected with disgust, loathing,</em> or <em>aversion;</em> <span class="auth">(M,* Ḳ;)</span> <em>he was vexed, grieved, disquieted by grief,</em> or <em>distressed in mind.</em> <span class="auth">(M.)</span> You say, <span class="ar long">بَرِمَ بِهِ</span>, inf. n. <span class="ar">بَرَمٌ</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar long">تبرّم↓ بِهِ</span></span>; <span class="auth">(T, Ṣ, Mṣb, Ḳ;)</span> <em>He was,</em> or <em>became, disgusted by it,</em> or <em>by reason of it; he loathed it;</em> <span class="auth">(T,*, M,* Mṣb,* Ḳ;)</span> <em>he was vexed, grieved, disquieted by grief,</em> or <em>distressed in mind, by it,</em> or <em>by reason of it.</em> <span class="auth">(T, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brm_1_B2">
					<p><span class="ar long">بَرِمَ بِحُجَّتِهِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَمُ</span>}</span></add>, ‡ <span class="add">[<em>He was unable to adduce, as he had intended, his argument, allegation,</em> or <em>evidence,</em>]</span> is said when one has intended to adduce an argument, allegation, or evidence, and it did not present itself to him. <span class="auth">(A, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brm_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرم</span></h3>
				<div class="sense" id="brm_4_A1">
					<p><span class="ar">ابرمهُ</span>, <span class="auth">(inf. n. <span class="ar">إِبْرَامٌ</span>, T,)</span> <em>He made it</em> <span class="auth">(a rope, AḤn, M, Ḳ, or a thread, or string, T)</span> <em>of two strands,</em> or <em>distinct yarns</em> or <em>twists, and then twisted it;</em> <span class="auth">(AḤn, T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَرَمَهُ↓</span></span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُمُ</span>}</span></add>, inf. n. <span class="ar">بَرْمٌ</span>]</span>: <span class="auth">(T:)</span> or <em>he twisted it well;</em> namely, a rope. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brm_4_A2">
					<p>And hence, <span class="auth">(T, TA,)</span> ‡ <em>He made it</em> <span class="auth">(a thing, Ṣ, or an affair, T, M, Ḳ, or a compact, Mṣb)</span> <em>firm, strong, solid,</em> or <em>sound; he established it, settled it,</em> or <em>arranged it, firmly, strongly, solidly, soundly,</em> or <em>thoroughly;</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">بَرَمَهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُمُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَرْمٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brm_4_A3">
					<p>† <em>He thought,</em> or <em>meditated, upon it;</em> <span class="auth">(namely, a thing;)</span> or <em>did so looking to its end, issue,</em> or <em>result;</em> or <em>he did it, performed it,</em> or <em>executed it, with thought,</em> or <em>consideration.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brm_4_B1">
					<p><em>He affected him with disgust, loathing,</em> or <em>aversion;</em> <span class="auth">(T,* Ṣ, M,* Mṣb,* Ḳ;)</span> <em>caused him to be vexed, grieved, disquieted by grief,</em> or <em>distressed in mind.</em> <span class="auth">(T, Ṣ, M, Mṣb.)</span> You say, <span class="ar long">لَا تُبْرِمْنِى بِكَثْرَةِ فُضُولِكَ</span> <span class="add">[<em>Disgust me not,</em> or <em>vex me not, by the abundance of thy meddling,</em> or <em>impertinent, speech.</em>]</span>. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brm_4_C1">
					<p><span class="ar">ابرم</span> <em>It</em> <span class="auth">(a vine)</span> <em>put forth grapes in the state in which they are termed</em> <span class="ar">بَرَمَ</span>, q. v. <span class="auth">(Th, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّم</span></h3>
				<div class="sense" id="brm_5_A1">
					<p><a href="#brm_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brm_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبرم</span></h3>
				<div class="sense" id="brm_7_A1">
					<p><span class="ar">انبرم</span> <span class="add">[<em>It</em> <span class="auth">(a rope, or a thread, or string,)</span> <em>was made of two strands,</em> or <em>distinct twists, and then twisted:</em> or <em>was twisted well:</em> <a href="#brm_4">see 4, of which it is quasi-pass.</a>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brm_7_A2">
					<p><span class="add">[And hence,]</span> ‡ <em>It</em> <span class="auth">(<span class="add">[a thg, or an affair, or]</span> compact, Mṣb)</span> <em>was,</em> or <em>became, firm, strong, solid,</em> or <em>sound; it was,</em> or <em>became, established, settled,</em> or <em>arranged, firmly, strongly, solidly, soundly,</em> or <em>thoroughly.</em> <span class="auth">(Mṣb, KL.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barama">
				<h3 class="entry"><span class="ar">بَرَمَ</span> / <span class="ar">بَرَمَةٌ</span></h3>
				<div class="sense" id="barama_A1">
					<p><span class="ar">بَرَمَ</span> The <em>fruit of the</em> <span class="add">[<em>trees called</em>]</span> <span class="ar">عِضَاه</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرَمَةٌ</span>}</span></add>: <span class="auth">(Ṣ, M:)</span> <em>in its first stage it is termed</em> <span class="ar">فَتْلَةٌ</span>; <em>then,</em> <span class="ar">بَلَّةٌ</span>; <em>then,</em> <span class="ar">بَرَمَةٌ</span>: AḤn has erred in saying that the <span class="ar">فتلة</span> is above the <span class="ar">برمة</span> <span class="add">[in degree]</span>: <span class="auth">(M:)</span> <em>that of every kind of</em> <span class="ar">عضاه</span> <em>is yellow, except that of the</em> <span class="ar">عُرْفُط</span>, <em>which is white,</em> <span class="auth">(Ṣ, M,)</span> <em>as though its filaments,</em> or <em>fringe-like appertenances, were cotton, and it is like the button of a shirt, or somewhat larger:</em> <span class="auth">(M:)</span> <em>that of the</em> <span class="ar">سَلَم</span> <em>is the sweetest in odour,</em> <span class="auth">(Ṣ, M,)</span> <em>and this is yellow, and is eaten, being sweet,</em> or <em>pleasant:</em> <span class="auth">(M:)</span> accord. to AA, the <em>fruit of the</em> <span class="ar">طَلْح</span> <span class="add">[or <em>acacia gummifera,</em> which is of the trees called <span class="ar">عضاه</span>]</span>: n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرَمَةٌ</span>}</span></add>: <span class="auth">(T:)</span> sometimes, also, <span class="ar">بَرَمَةٌ</span> is applied to <em>a fruit of the</em> <span class="ar">أَرَاك</span> <span class="auth">(M,* Ḳ,* TA)</span> <em>before it has become ripe and black;</em> for when ripe, it is called <span class="ar">مَرْدٌ</span>; and when black, <span class="ar">كَبَاثٌ</span>: <span class="auth">(TA:)</span> and the pl. is <span class="ar">بِرَامٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">بُرَمٌ</span>, <span class="auth">(M,)</span> or <span class="ar">بَرَمٌ</span>. <span class="auth">(Ḳ: <span class="add">[but the last is a coll. gen. n.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرَمَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barama_A2">
					<p>Also <em>Grapes when they are above,</em> <span class="auth">(M,)</span> or <em>when they are like,</em> <span class="auth">(Ḳ,)</span> <em>the heads of young ants.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرَمَ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barama_B1">
					<p>‡ <em>One who does not take part with others in the game called</em> <span class="ar">المَيْسِر</span> <span class="add">[q. v.]</span>, <span class="auth">(Aṣ, T, Ṣ, M, Ḳ,)</span> <em>nor contribute with them anything,</em> <span class="auth">(TA,)</span> <em>by reason of his avarice,</em> <span class="auth">(Ḥar p. 382,)</span> <em>though he eats with them of the flesh-meat thereof;</em> <span class="auth">(Aṣ, TA;)</span> <em>but sometimes he shuffles,</em> or <em>deals forth,</em> (<span class="ar">يُفِيضُ</span>,) <em>the gaming-arrows for the players:</em> <span class="auth">(Ṣ in art. <span class="ar">جمد</span>:)</span> likened to the <span class="ar">بَرَمَ</span> of the <span class="ar">أَرَاك</span>, because he is of no use: <span class="auth">(Ḥar ubi suprà:)</span> and<span class="arrow"><span class="ar">بَرَمَةٌ↓</span></span> occurs in the same sense; <span class="add">[the man so termed being likened to a <span class="ar">بَرَمَة</span> of the <span class="ar">اراك</span>; or]</span> the <span class="ar">ة</span> being added to give intensiveness to the meaning: <span class="auth">(M:)</span> the pl. is <span class="ar">أَبْرَامٌ</span>. <span class="auth">(T, Ṣ, M, Ḳ.)</span> And hence, ‡ <em>Avaricious,</em> or <em>niggardly; mean,</em> or <em>sordid:</em> <span class="auth">(Ḥar ubi suprà:)</span> or <em>heavy,</em> or <em>sluggish;</em> <span class="auth">(Ḳ, TA;)</span> <em>destitute of good.</em> <span class="auth">(TA.)</span> It is said in a prov., <span class="ar long">أَبْرَمًا قَرُونًا</span> ‡ <span class="add">[<em>Art thou</em> (<span class="ar">تَكُونُ</span> being understood after) <em>one taking no part with others in the game of</em> <span class="ar">الميسر</span>, as is implied in the Ṣ, or <em>art thou</em>]</span> <em>heavy,</em> or <em>sluggish,</em> <span class="auth">(Ḳ, TA,)</span> <em>destitute of good,</em> <span class="auth">(TA,)</span> yet <em>eating two dates at once each time?</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barimN">
				<h3 class="entry"><span class="ar">بَرِمٌ</span></h3>
				<div class="sense" id="barimN_A1">
					<p><span class="ar">بَرِمٌ</span> part. n. of <span class="ar">بَرِمَ</span> <span class="add">[and therefore meaning <em>Affected with disgust, loathing,</em> or <em>aversion;</em> or <em>vexed, grieved, disquieted by grief,</em> or <em>distressed in mind</em>]</span>. <span class="auth">(M, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buromapN">
				<h3 class="entry"><span class="ar">بُرْمَةٌ</span></h3>
				<div class="sense" id="buromapN_A1">
					<p><span class="ar">بُرْمَةٌ</span> <em>A cooking-pot</em> <span class="auth">(T, M, &amp;c.)</span> <em>of stone,</em> <span class="auth">(T, Mgh, Mṣb,)</span> or <em>of stones:</em> <span class="add">[<a href="#muborimN">see <span class="ar">مُبْرِمٌ</span></a>:]</span> <span class="auth">(M, Ḳ:)</span> or <span class="add">[simply]</span> <em>a cooking-pot,</em> <span class="auth">(Ṣ, TA,)</span> as some say, <em>in a general sense,</em> so that it may be <em>of copper,</em> and <em>of iron, &amp;c.:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بِرَامٌ</span> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">بُرَمٌ</span> <span class="auth">(T, M, &amp;c.)</span> and <span class="add">[coll. gen. n.]</span> <span class="ar">بُرْمٌ</span>. <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بُرْمَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buromapN_B1">
					<p>Also <em>A certain thing which women wear upon their arms, like the bracelet.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baramapN">
				<h3 class="entry"><span class="ar">بَرَمَةٌ</span></h3>
				<div class="sense" id="baramapN_A1">
					<p><span class="ar">بَرَمَةٌ</span> <span class="add">[originally <a href="#baramN">n. un. of <span class="ar">بَرَمٌ</span></a>]</span>: <a href="#baramN">see <span class="ar">بَرَمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariymN">
				<h3 class="entry"><span class="ar">بَرِيمٌ</span></h3>
				<div class="sense" id="bariymN_A1">
					<p><span class="ar">بَرِيمٌ</span> <em>A rope composed of two twists twisted together into one;</em> as also<span class="arrow"><span class="ar">مُبْرَمٌ↓</span></span>: <span class="auth">(Ṣ:)</span> or <em>a thread,</em> or <em>string, twisted of two distinct yarns</em> or <em>twists:</em> <span class="auth">(T:)</span> or <em>a thread,</em> or <em>string, twisted of white and black yarns:</em> <span class="auth">(Ḥam p. 704:)</span> or <em>a twisted rope in which are two colours,</em> <span class="auth">(AʼObeyd, Ṣ,)</span> or <em>two threads,</em> or <em>strings, of different colours,</em> <span class="auth">(IAạr, T, M, Ḳ,)</span> <em>red and yellow,</em> <span class="auth">(M,)</span> or <em>red and white,</em> <span class="auth">(Ḳ,)</span> <em>sometimes</em> <span class="auth">(AʼObeyd, Ṣ)</span> <em>bound by a woman upon her waist, and upon her upper arm:</em> <span class="auth">(AʼObeyd, Ṣ, Ḳ:)</span> <em>a rope of two colours, adorned with jewels, so bound by a woman:</em> <span class="auth">(M, Ḳ:)</span> or <em>a thread,</em> or <em>string,</em> <span class="auth">(Lth, AʼObeyd, T,)</span> <em>with beads strung upon it,</em> <span class="auth">(Lth, T,)</span> or <em>of different colours,</em> <span class="auth">(AʼObeyd, T,)</span> <em>which a woman binds upon her waist:</em> <span class="auth">(Lth, AʼObeyd, T: <span class="add">[<a href="#HaWoTN">see also <span class="ar">حَوْطٌ</span></a>]</span>:)</span> or <em>a string of cowries, which is bound upon the waist of a female slave.</em> <span class="auth">(Aboo-Sahl El-Harawee in art. <span class="ar">بزم</span> of the TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bariymN_A2">
					<p><em>Anything in which are two colours</em> <span class="auth">(T, M, Ḳ)</span> <em>mixed together:</em> <span class="auth">(M, Ḳ:)</span> and <em>any two things mixed together and combined.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bariymN_A3">
					<p><em>An amulet</em> <span class="auth">(M, Ḳ, TA)</span> <em>that is hung upon a boy;</em> because of the colours therein. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bariymN_A4">
					<p><em>A garment,</em> or <em>piece of cloth, in which are silk</em> (<span class="ar">قَزّ</span>) <em>and flax.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bariymN_A5">
					<p>Also, <span class="auth">(Ḳ,)</span> or the dual thereof, <span class="auth">(AO, T, Ṣ,)</span> which latter is the right, <span class="auth">(TA,)</span> The <em>liver and hump</em> <span class="add">[<em>of a camel</em>]</span>, <span class="auth">(AO, T, Ṣ, Ḳ,)</span> <em>cut lengthwise, and tied round with a string</em> or <em>thread, or some other thing,</em> <span class="auth">(Ṣ, Ḳ,)</span> in some copies of the Ṣ, <em>or with a gut;</em> <span class="auth">(TA;)</span> said to be thus called because of the whiteness of the hump and the blackness of the liver. <span class="auth">(Ṣ, Ḳ.)</span> So in the phrase, <span class="ar long">اِشْوِ لَنَا مِنْ بَرِيَمَيْهَا</span> <span class="add">[<em>Roast thou for us some of her liver and hump, cut lengthwise,</em>, &amp;c.]</span>. <span class="auth">(AO, T, Ṣ: <span class="add">[in copies of the Ḳ, <span class="ar">بَرِيمِهَا</span>: and in the CK, <span class="ar">بَرِيمَتِهَا</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bariymN_A6">
					<p>Also, the sing., <em>Water mixed with other</em> <span class="add">[<em>water</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bariymN_A7">
					<p><em>Tears mixed with</em> <span class="add">[<em>the collyrium termed</em>]</span> <span class="ar">إِثْمِد</span>; <span class="auth">(M, Ḳ;)</span> because having two colours. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bariymN_A8">
					<p><em>A mixed company</em> of people. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bariymN_A9">
					<p><em>An army;</em> <span class="auth">(Ṣ, Ḳ;)</span> because comprising a mixed multitude of men; <span class="auth">(Ḳ;)</span> or because of the colours of the banners of the tribes therein: <span class="auth">(Ṣ, Ḳ, TA:)</span> or <em>an army in which is a mixed multitude of men:</em> <span class="auth">(M:)</span> or <em>an army having two colours:</em> <span class="auth">(T:)</span> and the dual, <em>two armies, Arabs and foreigners.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bariymN_A10">
					<p><em>A number of sheep and goats together.</em> <span class="auth">(IAạr, T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="bariymN_A11">
					<p>The <em>light of the sun with the remains of the blackness of night:</em> <span class="auth">(IAạr, T:)</span> or the <em>dawn;</em> <span class="auth">(M, Ḳ;)</span> because of its combining the blackness of night and the whiteness of day: or, as some say, <span class="ar long">بَرِيمٌ الصُّبْحِ</span> means <em>the tint</em> (<span class="ar">خَيْط</span> <span class="add">[q. v.]</span>) <em>of the dawn that is mixed with two colours.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="bariymN_A12">
					<p>† <em>Inducing suspicion,</em> or <em>evil opinion;</em> <span class="add">[as though of two colours;]</span> <span class="auth">(IAạr, T;)</span> <em>suspected.</em> <span class="auth">(IAạr, T, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBiymapN">
				<h3 class="entry"><span class="ar">بَرِّيمَةٌ</span></h3>
				<div class="sense" id="barBiymapN_A1">
					<p><span class="ar">بَرِّيمَةٌ</span>, with fet-ḥ, and with teshdeed to the <span class="ar">ر</span> which is meksoorah, <em>A</em> <span class="ar">دَائِرَة</span> <span class="add">[or <em>feather,</em> or <em>portion of the hair naturally curled or frizzled, in a spiral manner, or otherwise,</em>]</span> <em>upon a horse, whereby one judges of its goodness or badness:</em> pl. <span class="ar">بَرَارِيمُ</span>. <span class="auth">(TA: <span class="add">[and used in this sense in the present day.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">بَرِّيمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barBiymapN_A2">
					<p><a href="#baYoramN">See also <span class="ar">بَيْرَمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayoramN">
				<h3 class="entry"><span class="ar">بَيْرَمٌ</span></h3>
				<div class="sense" id="bayoramN_A1">
					<p><span class="ar">بَيْرَمٌ</span> The <span class="add">[<em>implement called</em>]</span> <span class="ar">عَتَلَة</span>: or particularly the <span class="ar">عتلة</span> <em>of the carpenter:</em> <span class="auth">(M, Ḳ:)</span> <span class="add">[i. e.,]</span> <em>an auger, a wimble,</em> or <em>a gimlet;</em> <span class="add">[called in the present day <span class="arrow"><span class="ar">بَرِّيمَة↓</span></span>; accord. to Mirḳát el-Loghah, cited by Golius, who writes the latter word without teshdeed, the former signifies <em>such an implement</em> <span class="auth">(“terebra”)</span> <em>of a large size;</em>]</span> <em>that with which the carpenter perforates:</em> and also said to signify <em>that with which the saddler perforates leather:</em> <span class="auth">(KL:)</span> also <em>a well-known kind of</em> <span class="add">[<em>implement such as is called in Persian</em>]</span> <span class="ar">تِيشَهْ</span> <span class="add">[i. e., <em>a hatchet,</em> or <em>the like</em>]</span>: <span class="auth">(PṢ:)</span> AO said, the <span class="ar">بَيْرَمْ</span> is the <span class="ar">عَتَلَة</span> of the carpenter: or he said, the <span class="ar">عتلة</span> is the <span class="ar">بيرم</span> of the carpenter: <span class="auth">(T:)</span> this word, <span class="auth">(M,)</span> the <span class="ar">بيرم</span> of the carpenter, <span class="auth">(Ṣ,)</span> is Persian, <span class="auth">(Ṣ, M,)</span> arabicized. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboramN">
				<h3 class="entry"><span class="ar">مُبْرَمٌ</span></h3>
				<div class="sense" id="muboramN_A1">
					<p><span class="ar">مُبْرَمٌ</span>: <a href="#bariymN">see <span class="ar">بَرِيمٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">مُبْرَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muboramN_A2">
					<p>Also A garment, or piece of cloth, <em>of which the thread is twisted of two yarns,</em> or <em>distinct twists.</em> <span class="auth">(Ṣ, Ḳ.)</span> And hence, <span class="auth">(Ṣ,)</span> <em>A certain kind of garments,</em> or <em>cloths.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0196"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">مُبْرَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="muboramN_A3">
					<p><span class="add">[† A thing, or an affair, or a compact, <em>made firm, strong, solid,</em> or <em>sound; established, settled,</em> or <em>arranged, firmly, strongly, solidly, soundly,</em> or <em>thoroughly.</em> See its verb, 4.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">مُبْرَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="muboramN_A4">
					<p><span class="add">[And hence, <span class="ar long">قَضَآءٌ مُبْرَمٌ</span> † <em>Ratified destiny; such as is rendered inevitable.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboramN.1">
				<h3 class="entry"><span class="ar">مُبْرَمٌ</span></h3>
				<div class="sense" id="muboramN.1_A1">
					<p><span class="ar">مُبْرَمٌ</span> <span class="add">[act. part. n. of 4.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">مُبْرَمٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muboramN.1_B1">
					<p><span class="add">[And also]</span> <em>A gatherer of</em> <span class="ar">بَرَم</span> <span class="add">[q. v.]</span>: <span class="auth">(M:)</span> or, <em>of the</em> <span class="ar">بَرَم</span> <em>of the</em> <span class="ar">عِضَاه</span>: <span class="auth">(Ḳ:)</span> or, specially, <em>a gatherer of the</em> <span class="ar">بَرَم</span> <em>of the</em> <span class="ar">أَرَاك</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">مُبْرَمٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="muboramN.1_C1">
					<p><em>A maker of</em> <span class="ar">بِرَام</span> <span class="add">[or <em>stone cookingpots</em>]</span>: <span class="auth">(Ḳ:)</span> or <em>one who wrenches out the stones of which they are made from the mountain,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>and fashions them, and hews them out.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برم</span> - Entry: <span class="ar">مُبْرَمٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="muboramN.1_D1">
					<p>And hence, <span class="auth">(M,)</span> † A <em>heavy,</em> or <em>sluggish,</em> man; as though <span class="add">[in the CK <span class="ar">لاَنَّهُ</span> is erroneously put for <span class="ar">كَأَنَّهُ</span>]</span> he cut off for himself something from the persons sitting with him: <span class="auth">(M, Ḳ:*)</span> or, as some say, <span class="add">[so in the M; but in the Ḳ, “and”]</span> <em>bad,</em> or <em>corrupt, in discourse;</em> <span class="auth">(M, Ḳ;)</span> <em>who discourses to others of that in which is no profit nor meaning;</em> <span class="auth">(TA;)</span> from the same word as signifying “a gatherer of the fruit of the <span class="ar">اراك</span>,” <span class="auth">(M, TA,)</span> which has no taste nor sweetness nor sourness nor virtue, or efficacy: <span class="auth">(AO, TA:)</span> or one <em>who is a burden upon his companion, without profit and without good; like the</em> <span class="ar">بَرَم</span> <em>who takes no part with others in the game of</em> <span class="ar">المَيْسِر</span>, <em>though he eats of the flesh-meat thereof.</em> <span class="auth">(Aṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboramN">
				<h3 class="entry"><span class="ar">مِبْرَمٌ</span></h3>
				<div class="sense" id="miboramN_A1">
					<p><span class="ar">مِبْرَمٌ</span> <a href="#mabaArimu">sing. of <span class="ar">مَبَارِمُ</span></a>, <span class="auth">(TA,)</span> which signifies The <em>spindles with which the twisting termed</em> <span class="ar">إِبْرَام</span> <em>is performed.</em> <span class="auth">(M, Ḳ, TA.)</span> <span class="add">[<a href="#brm_4">See 4</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0195.pdf" target="pdf">
							<span>Lanes Lexicon Page 195</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0196.pdf" target="pdf">
							<span>Lanes Lexicon Page 196</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
