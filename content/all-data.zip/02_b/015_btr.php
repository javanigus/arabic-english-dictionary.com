<article class="root" id="Root_btr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/014_bt">بت</a></span>
				<span class="ar">بتر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/016_btE">بتع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="btr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بتر</span></h3>
				<div class="sense" id="btr_1_A1">
					<p><span class="ar">بَتَرَ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor <span class="ar">ـُ</span>, <span class="auth">(M, Mgh, Mṣb,)</span> inf. n. <span class="ar">بَتْرٌ</span>; <span class="auth">(T, Ṣ, M, &amp;c.;)</span> and<span class="arrow"><span class="ar">ابتر↓</span></span>; <span class="auth">(T;)</span> <em>He cut,</em> or <em>cut off,</em> a thing <em>before it was complete:</em> <span class="auth">(Ṣ, A, L, Mṣb:)</span> or <em>he cut,</em> or <em>cut off,</em> <span class="auth">(M, Mgh, Ḳ,)</span> <em>in any manner:</em> <span class="auth">(M:)</span> or <em>he cut off</em> <span class="auth">(a tail or the like, T)</span> <em>entirely,</em> or <em>utterly.</em> <span class="auth">(Aboo-Is-ḥáḳ, T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btr_1_A2">
					<p><span class="ar">بَتَرَهُ</span>, <span class="auth">(Ḳ,)</span> aor. and inf. n. as above; <span class="auth">(TA;)</span> or<span class="arrow"><span class="ar">ابترهُ↓</span></span>; <span class="auth">(M, L;)</span> <em>He cut off his tail:</em> <span class="auth">(Ḳ:)</span> or <em>he cut,</em> or <em>amputated, his tail in any place.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="btr_1_A3">
					<p><span class="ar long">بَتَرَ رَحِمَهُ</span>, <span class="auth">(M,)</span> aor. as above, <span class="auth">(M, Ḳ,)</span> and so the inf. n., <span class="auth">(M,)</span> † <em>He cut,</em> or <em>severed, the ties,</em> or <em>bonds, of his relationship; he disunited himself from his relations.</em> <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="btr_1_B1">
					<p><span class="ar">بَتِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْتَرُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَتَرٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He</em> <span class="auth">(any beast, M)</span> <em>had his tail cut off:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or <span class="add">[<em>had either the whole</em> or <em>a part of his tail cut off;</em>]</span> <em>had his tail cut,</em> or <em>amputated, in any place.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="btr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابتر</span></h3>
				<div class="sense" id="btr_4_A1">
					<p><a href="#btr_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btr_4_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">ابترهُ</span> said of God, <em>He made him to be.</em> or <em>become,</em> <span class="ar">أَبْتَر</span>, <span class="auth">(Ṣ, Ḳ,)</span> i. e., <em>without offspring,</em> or <em>progeny.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="btr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبتّر</span></h3>
				<div class="sense" id="btr_5_A1">
					<p><a href="#btr_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="btr_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبتر</span></h3>
				<div class="sense" id="btr_7_A1">
					<p><span class="ar">انبتر</span> <em>It</em> <span class="auth">(a tail or the like, T)</span> <em>became cut,</em> or <em>cut off,</em> <span class="auth">(T, Ṣ, M, Ḳ, TA,)</span> <em>in any place,</em> <span class="auth">(M,)</span> or <em>entirely;</em> <span class="auth">(T, M;)</span> and<span class="arrow"><span class="ar">تبتّر↓</span></span> signifies the same. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="butaArN">
				<h3 class="entry"><span class="ar">بُتَارٌ</span></h3>
				<div class="sense" id="butaArN_A1">
					<p><span class="ar">بُتَارٌ</span>: <a href="#baAtirN">see <span class="ar">بَاتِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="batuwrN">
				<h3 class="entry"><span class="ar">بَتُورٌ</span></h3>
				<div class="sense" id="batuwrN_A1">
					<p><span class="ar">بَتُورٌ</span>: <a href="#baAtirN">see <span class="ar">بَاتِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="butayoraMCu">
				<h3 class="entry"><span class="ar">بُتَيْرَآءُ</span></h3>
				<div class="sense" id="butayoraMCu_A1">
					<p><span class="ar">بُتَيْرَآءُ</span>: <a href="#Oabotaru">see <span class="ar">أَبْتَرُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="batBaArN">
				<h3 class="entry"><span class="ar">بَتَّارٌ</span></h3>
				<div class="sense" id="batBaArN_A1">
					<p><span class="ar">بَتَّارٌ</span>: <a href="#baAtirN">see <span class="ar">بَاتِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAtirN">
				<h3 class="entry"><span class="ar">بَاتِرٌ</span></h3>
				<div class="sense" id="baAtirN_A1">
					<p><span class="ar">بَاتِرٌ</span> A <em>cutting,</em> or <em>sharp,</em> sword; <span class="auth">(T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَتَّارٌ↓</span></span> <span class="auth">(T, M, Ḳ)</span> and<span class="arrow"><span class="ar">بَتُورٌ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">بَتَارٌ↓</span></span>. <span class="auth">(Ḳ.)</span> <span class="add">[But all of these except the first are app. intensive epithets, signifying <em>very sharp.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">بَاتِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAtirN_A2">
					<p><a href="#OubaAtirN">See also <span class="ar">أُبَاتِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabotaru">
				<h3 class="entry"><span class="ar">أَبْتَرُ</span></h3>
				<div class="sense" id="Oabotaru_A1">
					<p><span class="ar">أَبْتَرُ</span> A tail <em>cut off entirely.</em> <span class="auth">(T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabotaru_A2">
					<p>Any beast <span class="auth">(M)</span> <em>having the tail cut off:</em> <span class="auth">(T, Ṣ, A, Mṣb, Ḳ:)</span> or <span class="add">[<em>having</em> either <em>the whole</em> or <em>a part of the tail cut off;</em>]</span> <em>having the tail cut,</em> or <em>amputated, in any place:</em> <span class="auth">(M:)</span> fem. <span class="ar">بَتْرَآءُ</span>; with which <span class="arrow"><span class="ar">مَبْتُورَةٌ↓</span></span> is syn.: <span class="auth">(Mgh, Mṣb:)</span> pl. <span class="ar">بُتْرٌ</span>. <span class="auth">(A, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabotaru_A3">
					<p>† <em>A certain malignant,</em> or <em>noxious, serpent:</em> <span class="auth">(Ḳ:)</span> or <em>a short-tailed serpent:</em> <span class="auth">(Mgh; and Ed-Durr en-Netheer, an abridgment of the Nh of IAth, by El-Jelál:)</span> or <em>a certain species of blue serpent, having its tail</em> <span class="add">[<em>as it were</em>]</span> <em>cut off, which none in a state of pregnancy sees without casting her burden:</em> <span class="auth">(ISh:)</span> or the <em>kind of serpent called</em> <span class="ar">شَيْطَان</span>, <em>having a short tail: no one sees it without fleeing from it, and no one in a state of pregnancy beholds it without casting her young:</em> it is thus called only because of the shortness of its tail, as thought its tail were cut off. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oabotaru_A4">
					<p>† A leathern water-bag, and a bucket, <em>having no loop.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oabotaru_A5">
					<p>† <em>Defective, deficient, incomplete,</em> or <em>imperfect.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Oabotaru_A6">
					<p>† <em>In want,</em> or <em>poor.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Oabotaru_A7">
					<p>† <em>Suffering loss;</em> syn. <span class="ar">خَاسِرٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Oabotaru_A8">
					<p>† One <em>from whom all good,</em> or <em>prosperity, is cut off.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Oabotaru_A9">
					<p>† <em>Having no offspring,</em> or <em>progeny;</em> <span class="auth">(Aboo-Is-ḥáḳ, T, Ṣ, M, IAth, Ḳ;)</span> as also<span class="arrow"><span class="ar">أُبَاتِرٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">مُنْبَتِرٌ↓</span></span>. <span class="auth">(IAth.)</span> <span class="add">[The dim., <span class="arrow"><span class="ar">أُبَيْتِرُ↓</span></span>, occurs in a trad., in this sense, or in some other sense implying contempt.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Oabotaru_A10">
					<p>† Anything <em>cut off,</em> <span class="auth">(Ḳ,)</span> or anything <em>of which the effect is cut off,</em> <span class="auth">(Ṣ,)</span> <em>from good,</em> or <em>prosperity.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[See an ex. in a trad. cited voce <span class="ar">بَالٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Oabotaru_A11">
					<p><span class="ar long">خُطْبَةٌ بَتْرَآءُ</span> † <em>A</em> <span class="ar">خطبة</span> <span class="add">[q. v.]</span> <em>in which the speaker does not praise God nor bless the Prophet:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> particularly applied to a certain <span class="ar">خطبة</span> of Ziyád. <span class="auth">(Ṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="Oabotaru_A12">
					<p><span class="ar long">رَكْعَةٌ بَتْرَآءُ</span>, <span class="auth">(TA,)</span> and <span class="add">[its dim.]</span> <span class="arrow"><span class="ar">بُتَيْرَآءُ↓</span></span>, <span class="auth">(Ṣ, TA,)</span> † <em>A single</em> <span class="ar">ركعة</span> <span class="add">[q. v.]</span> <em>performed instead of the complete performance of the prayer called</em> <span class="ar">الوِتْر</span>: or a <span class="ar">ركعة</span> <em>cut short,</em> or <em>cut off, after the completion of one</em> <span class="ar">ركعة</span>, <em>when both were to have been performed.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أَبْتَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="Oabotaru_A13">
					<p><span class="ar">الأَبْتَرَانِ</span> † <em>The ass</em> (<span class="ar">العَيْرُ</span>) <em>and the slave:</em> <span class="auth">(ISK, Ṣ, A, Ḳ:)</span> so called because of the little good that is in them: <span class="auth">(ISk, Ṣ:)</span> each is called <span class="ar">الأَبْتَرُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubaAtirN">
				<h3 class="entry"><span class="ar">أُبَاتِرٌ</span></h3>
				<div class="sense" id="OubaAtirN_A1">
					<p><span class="ar">أُبَاتِرٌ</span> † <em>Short;</em> <span class="auth">(M, Ḳ;)</span> as though cut off from completion. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أُبَاتِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OubaAtirN_A2">
					<p><a href="#Oabotaru">See also <span class="ar">أَبْتَرُ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتر</span> - Entry: <span class="ar">أُبَاتِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OubaAtirN_A3">
					<p>Also † A man <em>who cuts,</em> or <em>severs, the ties,</em> or <em>bonds, of his relationship; who disunites himself from his relations;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَاتِرٌ↓</span></span>; <span class="auth">(A:)</span> or <em>quick to cut,</em> or <em>sever, the ties,</em> or <em>bonds, between him and his friend.</em> <span class="auth">(IAạr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oubayotiru">
				<h3 class="entry"><span class="ar">أُبَيْتِرُ</span></h3>
				<div class="sense" id="Oubayotiru_A1">
					<p><span class="ar">أُبَيْتِرُ</span>: <a href="#Oabotaru">see <span class="ar">أَبْتَرُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabotuwrapN">
				<h3 class="entry"><span class="ar">مَبْتُورَةٌ</span></h3>
				<div class="sense" id="mabotuwrapN_A1">
					<p><span class="ar">مَبْتُورَةٌ</span>: <a href="#Oabotaru">see <span class="ar">أَبْتَرُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="munobatirN">
				<h3 class="entry"><span class="ar">مُنْبَتِرٌ</span></h3>
				<div class="sense" id="munobatirN_A1">
					<p><span class="ar">مُنْبَتِرٌ</span>: <a href="#Oabotaru">see <span class="ar">أَبْتَرُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0149.pdf" target="pdf">
							<span>Lanes Lexicon Page 149</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
