<article class="root" id="Root_bSn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/120_bSm">بصم</a></span>
				<span class="ar">بصن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/122_bD">بض</a></span>
			</h2>
			<hr>
			<section class="entry main" id="buSaAnN">
				<h3 class="entry"><span class="ar">بُصَانٌ</span></h3>
				<div class="sense" id="buSaAnN_A1">
					<p><span class="ar">بُصَانٌ</span>, <span class="auth">(M, Ḳ,)</span> so accord. to Ḳṭr, <span class="auth">(M,)</span> and <span class="ar">بُصَّانٌ</span>, <span class="auth">(Ḳ,)</span> thus in some of the copies of the Jm of IDrd, <span class="auth">(TA,)</span> a name of <em>The month</em> <span class="ar long">رَبِيعٌ الأخِرُ</span>, <span class="auth">(M, Ḳ,)</span> in the Time of Ignorance: <span class="auth">(M:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْصِنَةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">بِصْنَانٌ</span>; <span class="auth">(M, TA;)</span> the latter erroneously written in the copies of the Ḳ <span class="ar">بُصَانَاتٌ</span>: <span class="auth">(TA:)</span> so says Ḳṭr; but other lexicologists hold that it is <span class="ar">وَبُصَانٌ</span>, like <span class="ar">سَبُعَان</span>, and <span class="ar">وَبِصَانٌ</span>, like <span class="ar">شَقِرَان</span>; and this is the correct opinion: Aboo-Is-ḥáḳ says that it was so named because of the <span class="ar">وَبِيص</span>, i. e. gleaming, of the weapons therein: <span class="auth">(M:)</span> but it is said in art. <span class="ar">وبص</span> of the Ḳ to be <span class="ar">وَبْصَان</span> and <span class="ar">وُبْصَان</span>: and Ṣgh holds <span class="ar">بُصَّانٌ</span> to be correct because <span class="ar">بَصَّ</span> and <span class="ar">وَبَصَ</span> signify the same. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0213.pdf" target="pdf">
							<span>Lanes Lexicon Page 213</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
