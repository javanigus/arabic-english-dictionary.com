<article class="root" id="Root_bsn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/106_bsml">بسمل</a></span>
				<span class="ar">بسن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/108_bX">بش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsn_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابسن</span></h3>
				<div class="sense" id="bsn_4_A1">
					<p><span class="ar">ابسن</span>, said of a man, <em>He was,</em> or <em>became good,</em> or <em>beautiful, in respect of his</em> <span class="ar">سَجِيَّة</span> <span class="add">[i. e. <em>natural disposition</em>]</span>, accord. to the copies of the Ḳ, but correctly, as explained by IAạr, <em>his</em> <span class="ar">سَحْنَة</span> <span class="add">[i. e. <em>aspect,</em> or <em>colour,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basanN">
				<h3 class="entry"><span class="ar">بَسَنٌ</span></h3>
				<div class="sense" id="basanN_A1">
					<p><span class="ar">بَسَنٌ</span> an imitative sequent to <span class="ar">حَسَنٌ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> <span class="add">[or it may signify <em>Beautiful in aspect</em>, &amp;c., from the verb above; or the verb may be from this word:]</span> or, in the opinion of Aboo-ʼAlee El-Ḳálee, originally <span class="ar">بَسٌّ</span> inf. n., used in the sense of the pass. part. n., of <span class="ar long">بَسَّ السَّوِيقَ</span>, meaning “he moistened, or stirred about, the <span class="ar">سويق</span> with clarified butter, or with olive-oil, to complete, or perfect, its goodness;” one of the two <span class="ar">س</span> s being suppressed, and <span class="ar">ن</span> being added; so that it means <em>complete,</em> or <em>perfect.</em> <span class="auth">(MF. <span class="add">[But this derivation seems to be extremely far-fetched.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0206.pdf" target="pdf">
							<span>Lanes Lexicon Page 206</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
