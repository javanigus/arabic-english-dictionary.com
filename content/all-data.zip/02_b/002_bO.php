<article class="root" id="Root_bO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/001_bA">با</a></span>
				<span class="ar">بأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/003_bOb">بأب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bO_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بأبأ</span></h3>
				<div class="sense" id="bO_RQ1_A1">
					<p><span class="ar">بَأْبَأَهُ</span>, <span class="auth">(Lth, T, Ṣ, M, Ḳ,)</span> and <span class="ar long">بأبأ بِهِ</span>, <span class="auth">(Fr, M, Ḳ,)</span> inf. n. <span class="ar">بَأْبَآَةُ</span> <span class="auth">(Lth, T, M)</span> and <span class="ar">بَئْبَآءٌ</span>; <span class="auth">(Fr, M;)</span> <span class="add">[as also <span class="ar">بأَبِى</span>; <a href="#biOabie">see art. <span class="ar long">بِأَبِى أَنْتَ</span></a>;]</span> <em>He said to him,</em> <span class="ar">بِأَبِى</span>, <span class="auth">(Fr, M,)</span> or <span class="ar">بأَبَا</span>, <span class="auth">(M,)</span> or <span class="ar long">بِأَبِى أَنْتَ</span>, <span class="auth">(Lth, T, Ḳ,)</span> <span class="add">[all meaning <em>With my father mayest thou be ransomed!</em> or]</span> meaning <span class="ar long">أَفْدِيكَ بِأَبِى</span> <span class="add">[<em>I will ransom thee with my father</em>]</span>; <span class="auth">(Lth, T;)</span> or <em>he said to him,</em> <span class="ar long">بِأَبِى أَنْتَ وَأُمِّى</span> <span class="add">[<em>With my father mayest thou be ransomed, and</em> with <em>my mother!</em> or <em>I will ransom thee</em>, &amp;c.; <a href="index.php?data=01_A/011_Abw">see art. <span class="ar">ابو</span></a>]</span>; <span class="auth">(Ṣ;)</span> the current phrase of the Arabs being that which includes both parents: <span class="auth">(TA:)</span> i. e., a man said so to another man, <span class="auth">(Lth, T, M,)</span> or to a child; <span class="auth">(Fr, Ṣ, M;)</span> and in like manner to his horse, for having saved him from some accident: <span class="auth">(IAạr, T:)</span> the verb is derived from <span class="ar">بِأَبِى</span>. <span class="auth">(Lth, T, M.)</span> Hence <span class="ar">البِأَبْ</span>, <a href="#OabN">in an ex. cited voce <span class="ar">أَبٌ</span></a>, <a href="index.php?data=01_A/011_Abw">in art. <span class="ar">ابو</span>, q. v.</a>; <span class="auth">(M;)</span> or <span class="ar">البِئَبْ</span>; <span class="auth">(TA in art. <span class="ar">ابو</span>;)</span> or <span class="ar">البِيَبْ</span>. <span class="auth">(Ṣ in that art.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bO_RQ1_A2">
					<p>And <span class="add">[hence,]</span> <span class="ar">بَأبَؤُوهُ</span> <em>They made a show of treating him with graciousness, courtesy,</em> or <em>blandishment;</em> as also<span class="arrow"><span class="ar long">تَبَأْبَؤُوا↓ عَلَيْهِ</span></span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bO_RQ1_A3">
					<p><span class="add">[Hence also,]</span> <span class="arrow"><span class="ar">بَأْبَآءٌ↓</span></span>, with medd, <span class="add">[used as an inf. n.,]</span> A woman's <em>dandling,</em> or <em>dancing,</em> of her child. <span class="auth">(AA, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bO_RQ1_B1">
					<p><span class="ar">بَأْبَأَ</span> also signifies <em>He</em> <span class="auth">(a child)</span> <em>said</em> <span class="arrow"><span class="ar">بَأْبَأْ↓</span></span> <span class="auth">(M, Ḳ)</span> <span class="add">[in some copies of the Ḳ written <span class="ar">بَابَا</span>, both meaning <em>Papa,</em> or <em>Father,</em>]</span> to his father. <span class="auth">(M.)</span> <span class="add">[Accord. to the TA, the verb is trans. in this sense, as in the senses before explained; but I think that <span class="ar">بَأْبَأَهُ</span> has been there erroneously put for <span class="ar">بَأْبَأَ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bO_RQ1_B2">
					<p>And <em>He</em> <span class="auth">(a stallion <span class="add">[meaning a stallion-camel]</span>)</span> <em>reiterated the sound of the letter</em> <span class="ar">ب</span> <span class="add">[or <em>b</em>]</span> <em>in his braying.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bO_RQ1_B3">
					<p><span class="add">[And hence, perhaps,]</span> <span class="arrow"><span class="ar">بَأْبَأٌ↓</span></span> <span class="add">[or, more probably, <span class="arrow"><span class="ar">بَأْبَآءٌ↓</span></span>, with medd, agreeably with analogy, used as an inf. n.,]</span> The <em>chiding of the cat,</em> or <em>act of chiding the cat;</em> <span class="auth">(AA, T, Ṣgh;)</span> also termed <span class="ar">غَسٌّ</span>. <span class="auth">(AA, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bO_RQ1_C1">
					<p>Also <em>He hastened, made haste,</em> or <em>sped:</em> and<span class="arrow"><span class="ar">تَبَأْبَأْنَا↓</span></span> <em>we hastened,</em>, &amp;c.: <span class="auth">(marginal note in a copy of the Ṣ:)</span> or<span class="arrow"><span class="ar">تَبَأْبَأَ↓</span></span> signifies <em>he ran.</em> <span class="auth">(El-Umawee, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bO_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تبأبأ</span></h3>
				<div class="sense" id="bO_RQ2_A1">
					<p><a href="#bA_RQ1">see above, in three places</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baOobOo">
				<h3 class="entry"><span class="ar">بَأْبأْ</span> / <span class="ar">بَأْبَأٌ</span></h3>
				<div class="sense" id="baOobOo_A1">
					<p><span class="ar">بَأْبأْ</span> and <span class="ar">بَأْبَأٌ</span>: <a href="#bA_RQ1">see R. Q. 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buWobuWN">
				<h3 class="entry"><span class="ar">بُؤْبُؤٌ</span> / <span class="ar">بُؤْبُؤَةٌ</span></h3>
				<div class="sense" id="buWobuWN_A1">
					<p><span class="ar">بُؤْبُؤٌ</span> The <em>source, origin, race, root,</em> or <em>stock,</em> syn. <span class="ar">أَصْلٌ</span>, <span class="auth">(AA, Sh, T, Ṣ, M, Ḳ,)</span> of a man, <span class="auth">(Sh, T,)</span> <em>whether noble</em> or <em>base.</em> <span class="auth">(AA, T.)</span> You say, <span class="ar long">هُوَ كَرِيمُ البُؤْبُؤِ</span> <em>He is of generous,</em> or <em>noble, origin;</em> lit., <em>generous,</em> or <em>noble, of origin.</em> <span class="auth">(TḲ.)</span> And <span class="ar long">فُلَانٌ فِىبُؤْبُؤِ الكَرَمِ</span> <em>Such a one is of</em> <span class="add">[a race]</span> <em>the source</em> (<span class="ar">أَصْل</span>) <em>of generosity,</em> or <em>nobleness.</em> <span class="auth">(Ṣ. <span class="add">[In the PṢ, <span class="ar">من</span> is here put in the place of <span class="ar">فى</span>: but <span class="ar">فى</span> is often used in phrases of the same kind and meaning as that above, in the sense of <span class="ar">مِنْ</span>.]</span>)</span> IKh cites from Jereer,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فِى يُؤْبُؤِ المَجْدِ وَبُحْبُوحِ الكَرَمْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Of</em> a race <em>the source of glory, and the very heart of generosity,</em> or <em>nobleness</em>]</span>: but Aboo-ʼAlee El-Ḳálee quotes the words thus;</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فِى ضِئْضِئِ المَجْدِ وَبُؤْبُوْءِ الكَرَمْ</span> *</div> 
					</blockquote>
					<p><span class="add">[which may be rendered, <em>of</em> a race <em>the source of glory, and the very root of generosity</em>]</span>; whence it appears that <span class="ar">بُؤْبُوءٌ</span> <a href="#buWobuwN">is a dial. var. of <span class="ar">بُؤْبُؤٌ</span></a> in the sense here given. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بُؤْبُؤٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buWobuWN_A2">
					<p>The <em>middle</em> of a thing; <span class="auth">(Ḳ;)</span> <span class="add">[and app. the <em>heart,</em> or <em>very heart,</em> thereof; the <em>middle as being</em> the <em>best part</em> of a thing;]</span> like <span class="ar">بُحْبُوحٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0145"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بُؤْبُؤٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buWobuWN_A3">
					<p><span class="add">[Hence, perhaps,]</span>The <em>pupil,</em> or <em>apple,</em> or the <em>image that is seen reflected in the black,</em> (<span class="ar">عَيْر</span> AA, T, or <span class="ar">إِنْسَان</span> Ḳ,) of the eye. <span class="auth">(AA, T, Ḳ.)</span> Whence the saying, <span class="ar long">هُوَ أَعَزُّ عَلَىِّ مِنْ بُؤْبُؤِ عَيْنِى</span> <span class="add">[<em>He is dearer to me than the apple of my eye;</em> a saying common in the present day, with the substitution of <span class="ar">إِنْسَان</span> for <span class="ar">بُؤْبُؤ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بُؤْبُؤٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="buWobuWN_A4">
					<p><em>A generous,</em> or <em>noble,</em> <span class="auth">(ISk, T,)</span> or <em>a clever, an ingenious,</em> or <em>an accomplished,</em> or <em>a well-bred,</em> or <em>an elegant,</em> <span class="auth">(M, Ḳ,)</span> <em>and a light, an active,</em> or <em>a sprightly,</em> <span class="auth">(M,)</span> <em>lord, master, chief,</em> or <em>personage:</em> <span class="auth">(ISk, T, M, Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُؤْبُؤَةٌ</span>}</span></add>. <span class="auth">(IKh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بُؤْبُؤٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="buWobuWN_A5">
					<p>Also, <span class="auth">(AA, T, Ṣ,* <span class="add">[but I find it only in one of three copies of the Ṣ,]</span>)</span> or<span class="arrow"><span class="ar">بُؤْبُؤْءٌ↓</span></span>, and<span class="arrow"><span class="ar">بَأْبَآءٌ↓</span></span>, <span class="auth">(Ḳ,)</span> the last from the M, <span class="auth">(TA, <span class="add">[but it is not in the M as transcribed in the TT,]</span>)</span> A <em>learned</em> man <span class="auth">(AA, T, Ṣ, Ḳ)</span> <em>who teaches;</em> <span class="auth">(AA, T;)</span> but the teaching of others is not a condition required in the application of the epithet; <span class="auth">(TA;)</span> like <span class="ar">سَرْسُورٌ</span>. <span class="auth">(Ṣ <span class="add">[in which this last word is evidently given as a syn.: but in the Ḳ it is given to show the form, only, of <span class="ar">بُؤْبُوْءٌ</span>]</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بُؤْبُؤٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="buWobuWN_A6">
					<p>Also The <em>body of a locust,</em> <span class="auth">(Ḳ,)</span> <em>without the head and legs.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بُؤْبُؤٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="buWobuWN_A7">
					<p>And, accord. to the Ḳ, The <em>head,</em> or <em>uppermost part, of a vessel in which</em> <span class="add">[<em>the collyrium called</em>]</span> <span class="ar">كُحْل</span> <em>is kept:</em> but it will appear, <a href="../">in art. <span class="ar">يأ</span></a>, that this is <span class="add">[perhaps]</span> a mistranscription for <span class="ar">يُؤْيُؤٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baOobaMCN">
				<h3 class="entry"><span class="ar">بَأْبَآءٌ</span></h3>
				<div class="sense" id="baOobaMCN_A1">
					<p><span class="ar">بَأْبَآءٌ</span>: <a href="#bA_RQ1">see R. Q. 1</a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بأ</span> - Entry: <span class="ar">بَأْبَآءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baOobaMCN_B1">
					<p><a href="#buWobuwN">and see <span class="ar">بُؤْبُؤٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buWobuwCN">
				<h3 class="entry"><span class="ar">بُؤْبُوءٌ</span></h3>
				<div class="sense" id="buWobuwCN_A1">
					<p><span class="ar">بُؤْبُوءٌ</span>: <a href="#buWobuwN">see <span class="ar">بُؤْبُؤٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0144.pdf" target="pdf">
							<span>Lanes Lexicon Page 144</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
