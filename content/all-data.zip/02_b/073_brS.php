<article class="root" id="Root_brS">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/072_brX">برش</a></span>
				<span class="ar">برص</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/074_brTl">برطل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brS_1">
				<h3 class="entry">1. ⇒ <span class="ar">برص</span></h3>
				<div class="sense" id="brS_1_A1">
					<p><span class="ar">بَرِصَ</span>, <span class="auth">(Ṣ, <span class="add">[so in two copies, in one mentioned by Freytag <span class="ar">بُرِصَ</span>, which is a mistake,]</span> M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَصُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَرَصٌ</span>, <span class="auth">(M, Mṣb,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>was,</em> or <em>became, affected with</em> <span class="ar">بَرَص</span> <span class="add">[or <em>leprosy</em> (<a href="#baraSN">see <span class="ar">بَرَصٌ</span> below</a>)]</span>. <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span> <span class="add">[<a href="#bariXa">See also <span class="ar">بَرِشَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brS_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّص</span></h3>
				<div class="sense" id="brS_2_A1">
					<p><span class="ar long">برّص رَأْسَهُ</span>, <span class="auth">(A,)</span> inf. n. <span class="ar">تَبْرِيصٌ</span>, <span class="auth">(Ḳ,)</span> ‡ <em>He shaved his head.</em> <span class="auth">(Ibn-ʼAbbád, A, Ṣgh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brS_2_A2">
					<p><span class="ar long">برّص المَطَرُ الأَرْضَ</span>, <span class="auth">(TḲ,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> † <em>The rain fell upon the land before it was ploughed,</em> or <em>tilled.</em> <span class="auth">(Ibn'-ʼAbbád, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brS_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرص</span></h3>
				<div class="sense" id="brS_4_A1">
					<p><span class="ar">ابرص</span> <em>He begot a child that was</em> <span class="ar">أَبْرَص</span> <span class="add">[or <em>leprous</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برص</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brS_4_B1">
					<p><span class="ar long">ابرصهُ ٱللّٰهُ</span> <em>God rendered him,</em> or <em>caused him to be</em> or <em>become,</em> <span class="ar">أَبْرَص</span> <span class="add">[or <em>leprous</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brS_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّص</span></h3>
				<div class="sense" id="brS_5_A1">
					<p><span class="ar long">تبرّص الأَرْضَ</span> ‡ <em>He</em> <span class="auth">(a camel, A, TA)</span> <em>found no pasture in the land without depasturing it;</em> <span class="auth">(Ṣgh, Ḳ;)</span> <em>left no pasture in the land.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroSN">
				<h3 class="entry"><span class="ar">بَرْصٌ</span></h3>
				<div class="sense" id="baroSN_A1">
					<p><span class="ar">بَرْصٌ</span>, with fet-ḥ, <em>A certain small reptile</em> (<span class="ar">دُوَيْبَّةٌ</span>) <em>that is in the well.</em> <span class="auth">(Ibn-ʼAbbád, Ṣgh, Ḳ. <span class="add">[In the CK, <span class="ar long">فى البَعِيرِ</span> is put by mistake for <span class="ar long">فِى البِئْرِ</span>.]</span>)</span> <span class="add">[Perhaps it is the same as is called <span class="ar">بُرْص</span>, <span class="auth">(see this word below,)</span> which may be a vulgar pronunciation; and if so, this may be the reason why the author of the Ḳ has added, contr. to his usual rule, “with fet-ḥ.”]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroSN">
				<h3 class="entry"><span class="ar">بُرْصٌ</span></h3>
				<div class="sense" id="buroSN_A1">
					<p><span class="ar">بُرْصٌ</span> <em>i. q.</em> <span class="ar">وَزَغَةٌ</span> <span class="add">[<em>A lizard of the species called gecko, of a leprous hue,</em> as its name <span class="ar">برص</span> indicates; so applied in the present day]</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar long">أَبُو بَرِيصٍ↓</span></span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar long">أَبُو بُرَيْصٍ↓</span></span>, <span class="auth">(TA,)</span> is <em>a surname of the same.</em> <span class="auth">(M, TA.)</span> <span class="add">[<a href="#baroSN">See also <span class="ar">بَرْصٌ</span></a>; <a href="#OaboraSa">and see <span class="ar long">سَامُّ أَبْرَصَ</span></a>, voce <span class="ar">أَبْرَصُ</span>; and <span class="ar">بَرِيصَةً</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraSN">
				<h3 class="entry"><span class="ar">بَرَصٌ</span></h3>
				<div class="sense" id="baraSN_A1">
					<p><span class="ar">بَرَصٌ</span> <span class="add">[<em>Leprosy;</em> particularly the <em>malignant species thereof termed “leuce;”</em>]</span> <em>a certain disease,</em> <span class="auth">(Ṣ, TA,)</span> <em>well known,</em> <span class="auth">(TA,)</span> <em>which is a whiteness;</em> <span class="auth">(Ṣ;)</span> <em>a whiteness incident in the skin;</em> <span class="auth">(M;)</span> <em>a whiteness which appears upon the exterior of the body, by reason of a corrupt state of constitution.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بَرَصٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baraSN_A2">
					<p>‡ <em>What has become white, in a beast, in consequence of his being bitten.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroSapN">
				<h3 class="entry"><span class="ar">بُرْصَةٌ</span></h3>
				<div class="sense" id="buroSapN_A1">
					<p><span class="ar">بُرْصَةٌ</span> † <em>i. q.</em> <span class="ar">بَلُّوقَةٌ</span>; <span class="auth">(ISh;)</span> pl. <span class="ar">بِرَاصٌ</span>, <span class="auth">(ISh, Ḳ,)</span> which signifies <em>White places,</em> <span class="auth">(ISh,)</span> or <em>portions distinct from the rest,</em> <span class="auth">(Ḳ,)</span> <em>in sand, which give growth to nothing.</em> <span class="auth">(ISh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بُرْصَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buroSapN_A2">
					<p>The pl. also signifies † The <em>alighting-places of the jinn,</em> or <em>genii:</em> <span class="auth">(Ḳ:)</span> <span class="add">[reminding us of our fairy-rings:]</span> in which sense, also, it <a href="#buroSapN">is pl. of <span class="ar">بُرْصَةٌ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بُرْصَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buroSapN_A3">
					<p>Also, the sing., † <em>An aperture in clouds,</em> or <em>mist, through which the face of the sky is seen.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biraSapN">
				<h3 class="entry"><span class="ar">بِرَصَةٌ</span></h3>
				<div class="sense" id="biraSapN_A1">
					<p><span class="ar">بِرَصَةٌ</span>: <a href="#OaboraSa">see <span class="ar long">سَامُّ أَبْرَصَ</span></a>, <a href="#OaboraSu">voce <span class="ar">أَبْرَصُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariySN">
				<h3 class="entry"><span class="ar">بَرِيصٌ</span></h3>
				<div class="sense" id="bariySN_A1">
					<p><span class="ar">بَرِيصٌ</span> <em>A shining,</em> or <em>glistening;</em> syn. <span class="ar">بَصِيصٌ</span> <span class="auth">(A, Ḳ)</span> and <span class="ar">بَرِيقٌ</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بَرِيصٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bariySN_B1">
					<p>Also <em>A certain plant, resembling the</em> <span class="ar">سُعْد</span> <span class="add">[or <em>cyperus</em>]</span>, <span class="auth">(AA, Ḳ,)</span> <em>growing in channels of running water.</em> <span class="auth">(AA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بَرِيصٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bariySN_C1">
					<p><span class="ar long">أَبُو بَرِيصٍ</span>: <a href="#buroSN">see <span class="ar">بُرْصٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buraySN">
				<h3 class="entry"><span class="ar">بُرَيصٌ</span></h3>
				<div class="sense" id="buraySN_A1">
					<p><span class="ar">بُرَيصٌ</span> <a href="#OaboraSu">dim. of <span class="ar">أَبْرَصُ</span>, q. v.</a></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بُرَيصٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buraySN_B1">
					<p><span class="ar long">أَبُو بُرَيْصٌ</span>: <a href="#buroSN">see <span class="ar">بُرْصٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">بُرَيصٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="buraySN_C1">
					<p><span class="ar long">أَبُو بُرَيص</span> is also the name of <em>A certain bird, otherwise called</em> <span class="ar">بلعة</span>, <span class="add">[so written in the TA, without any syll. signs,]</span> accord. to IKh, and mentioned in the Ḳ in art. <span class="ar">بلص</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariySapN">
				<h3 class="entry"><span class="ar">بَرِيصَةٌ</span></h3>
				<div class="sense" id="bariySapN_A1">
					<p><span class="ar">بَرِيصَةٌ</span> <em>A certain small reptile</em> (<span class="ar long">دَابَّةٌ صَغِيرَةٌ</span>), <em>smaller than the</em> <span class="ar">وَزَغَة</span>; <em>when it bites a thing, the latter is not cured.</em> <span class="auth">(M, TA.)</span> <span class="add">[<a href="#buroSN">See also <span class="ar">بُرْصٌ</span></a>; <a href="#OaboraSu">and see <span class="ar long">سَامُّ أَبْرَصَ</span>, voce <span class="ar">أَبْرَصُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboraSu">
				<h3 class="entry"><span class="ar">أَبْرَصُ</span></h3>
				<div class="sense" id="OaboraSu_A1">
					<p><span class="ar">أَبْرَصُ</span> <span class="add">[<em>Leprous;</em>]</span> <em>having the disease called</em> <span class="ar">بَرَصٌ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> fem. <span class="ar">بَرْصَآءُ</span>: <span class="auth">(M, Mṣb:)</span> pl. <span class="ar">بُرْصٌ</span> <span class="auth">(Mṣb, TA)</span> and <span class="ar">بُرْصَانٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">أَبْرَصُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboraSu_A2">
					<p><span class="ar long">سَامُّ أَبْرَصَ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> the former word being decl., prefixed to the latter as governing it in the gen. case; <span class="auth">(Ṣ, Mṣb;)</span> and <span class="ar long">سَامُّ أَبْرَصَ</span>, as one word, the former being indecl. with fet-ḥ for its termination, and the latter being imperfectly decl., <span class="auth">(Ṣ, Mṣb;)</span> in this and in the former instance; <span class="auth">(Mṣb;)</span> and <span class="ar long">سَمُّ أَبْرَصَ</span>; <span class="auth">(as in some copies of the Ḳ in art. <span class="ar">سم</span>;)</span> <em>i. q.</em> <span class="ar">الوَزَغَةُ</span> <span class="add">[<em>The species of lizard described above, voce</em> <span class="ar">بُرْصٌ</span>]</span>: <span class="auth">(M, and so in the JK and Ḳ in art. <span class="ar">وزغ</span>:)</span> <span class="pb" id="Page_0189"></span>or <em>such as are large, of the</em> <span class="ar">وَزَغ</span> <span class="add">[whereof <span class="ar">وَزَغَةٌ</span> is the n. un.]</span>: <span class="auth">(A, Mṣb:)</span> or <span class="add">[<em>one</em>]</span> <em>of the large</em> <span class="add">[<em>sorts</em>]</span> <em>of the</em> <span class="ar">وَزَغ</span>: <span class="auth">(Ṣ, Ḳ:)</span> determinate, as a generic appellation: <span class="auth">(Ṣ, TA:)</span> Aṣ says, I know not why it is so called: <span class="auth">(TA:)</span> <span class="add">[the reason seems to be its leprous hue: <a href="#buroSN">see <span class="ar">بُرْصٌ</span></a>:]</span> its blood and its urine have a wonderful effect when put into the orifice of the penis of a child suffering from difficulty in voiding his urine, <span class="auth">(Ḳ, TA,)</span> relieving him immediately; <span class="auth">(TA;)</span> and its head, pounded, when put upon a member, causes to come forth a thing that has entered into it and become concealed therein, such as a thorn and the like: <span class="auth">(Ḳ:)</span> the dual is <span class="ar long">سَامَّا أَبْرَصَ</span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> and the pl. is <span class="ar long">سَوَامُّ أَبْرَصَ</span>, <span class="auth">(Ṣ, M, A, Mṣb, Ḳ,)</span> <span class="ar">ابرص</span> having no dual form nor pl.; <span class="auth">(M;)</span> or, <span class="auth">(Ḳ,)</span> or sometimes, <span class="auth">(Mṣb,)</span> or if you will you may say, <span class="auth">(Ṣ,)</span> <span class="ar">السَّوَامُّ</span>, without mentioning <span class="ar">ابرص</span>; and<span class="arrow"><span class="ar">البِرَصَةُ↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and <span class="ar">الأَبَارِصُ</span>; <span class="auth">(Ṣ, M, A, Mṣb, Ḳ;)</span> without mentioning <span class="ar">سَامّ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> the last of these pls. being as though formed from a rel. n., <span class="add">[namely, <span class="ar">أَبْرَصِىٌّ</span>,]</span> although without <span class="add">[the termination]</span> <span class="ar">ة</span>, like as they said <span class="ar">المَهَالِبُ</span> <span class="add">[for <span class="ar">المَهَالِبَةُ</span>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">أَبْرَصُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaboraSu_A3">
					<p><span class="ar">الأَبْرَصُ</span> <em>The moon.</em> <span class="auth">(A, Ṣgh, Ḳ.)</span> <span class="add">[So called because of its mottled hue.]</span> You say, <span class="ar long">بِتُّ لَا مُؤْنِسِى إِلَّا الأَبْرَصُ</span> <span class="add">[<em>I passed the night, none but the moon cheering me by its presence</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">أَبْرَصُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaboraSu_A4">
					<p><span class="ar long">حَيَّةٌ بَرْصَآءُ</span> <em>A serpent having in it,</em> <span class="auth">(Ḳ,)</span> i. e., <em>in its skin,</em> <span class="auth">(M, TA,)</span> <em>white places, distinct from the general colour.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برص</span> - Entry: <span class="ar">أَبْرَصُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaboraSu_A5">
					<p><span class="ar long">أَرْضٌ بَرْصَآءُ</span> ‡ <em>Land bare of herbage;</em> <span class="auth">(A;)</span> <em>of which the herbage has been depastured</em> <span class="auth">(Ḳ, TA)</span> <em>in some places, so that it has become bare thereof.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0188.pdf" target="pdf">
							<span>Lanes Lexicon Page 188</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0189.pdf" target="pdf">
							<span>Lanes Lexicon Page 189</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
