<article class="root" id="Root_bSr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/114_bS">بص</a></span>
				<span class="ar">بصر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/116_bST">بصط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bSr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بصر</span></h3>
				<div class="sense" id="bSr_1_A1">
					<p><span class="ar">بَصُرَ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْصُرُ</span>}</span></add>,]</span> <span class="auth">(Sb, M, Ḳ,)</span> and <span class="ar">بَصِرَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْصَرُ</span>}</span></add>,]</span> <span class="auth">(Lḥ, Ḳ,)</span> inf. n. <span class="ar">بَصَرٌ</span> and <span class="ar">بَصَارَةٌ</span> and <span class="ar">بِصَارَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <span class="add">[<em>He saw;</em> i. e.]</span> <em>he became seeing;</em> syn.<span class="ar long">صَارَ مُبْصِرًا</span>; <span class="auth">(Sb, M, Ḳ;)</span> with <span class="ar">بِ</span> prefixed to the noun following. <span class="auth">(Ḳ.)</span> <a href="#bSr_4">But see 4</a>, in four places. <span class="ar">بَصُرَ</span> is seldom used to signify the sense of sight unless to this meaning is conjoined that of mental perception. <span class="auth">(B.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bSr_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">بَصُرَ</span>, <span class="add">[and <span class="ar">بَصِرَ</span>.]</span>, inf. n. <span class="ar">بَصَارَةٌ</span> <span class="add">[and <span class="ar">بَصَرٌ</span>]</span>, <em>He was,</em> or <em>became, endowed with mental perception;</em> or <em>belief,</em> or <em>firm belief;</em> or <em>knowledge, understanding, intelligence,</em> or <em>skill.</em> <span class="auth">(Ṣ,* M, TA.)</span> And <span class="ar">بَصُرَبِهِ</span>, <span class="auth">(Ṣ Mṣb, B,)</span> and <span class="ar">بَصِرَبِهِ</span>, and sometimes <span class="ar">بَصُرَهُ</span> and <span class="ar">بَصِرَهُ</span>, but more chastely with <span class="ar">بِ</span>, inf. n. <span class="add">[<span class="ar">بَصَارَةٌ</span> and]</span> <span class="ar">بَصَرٌ</span>; <span class="auth">(Mṣb;)</span> and * <span class="ar">ابصرهُ</span>; <span class="auth">(B;)</span> <em>He perceived it mentally;</em> <span class="auth">(B;)</span> <em>he knew it</em> <span class="add">[or <em>understood it</em>]</span>. <span class="auth">(Ṣ, Mṣb.)</span> <span class="ar long">بَصُرْتُ بِمَا لَمْ يَبْصُرُوا بِهِ</span>, in the Ḳur <span class="add">[xx. 96]</span>, means <em>I knew that which they knew not.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bSr_1_B1">
					<p><span class="ar long">بَصَرَ الأَدِيمَيْنِ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْصُرُ</span>}</span></add>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">بَصْرٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>He put the two hides together, and sewed them, like as the two edges of a garment,</em> or <em>piece of cloth, are sewed, one being put upon the other; which</em> <span class="add">[<em>mode of sewing</em>]</span> <em>is contrary to,</em> or <em>different from, that in which a garment,</em> or <em>piece of cloth, is sewed before it is sewed the second time:</em> <span class="auth">(Ṣ:)</span> or <em>he put together the two edges of the two hides, when they were being sewed,</em> <span class="auth">(M, Ḳ,)</span> <em>like as a garment,</em> or <em>piece of cloth, is sewed.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بصّر</span></h3>
				<div class="sense" id="bSr_2_A1">
					<p><span class="ar">بصّر</span> <em>He</em> <span class="auth">(a whelp)</span> <em>opened his eyes.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bSr_2_B1">
					<p><span class="ar">بصّرهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَبْصِيرٌ</span>; <span class="auth">(TA;)</span> or * <span class="ar">ابصرهُ</span>; <span class="auth">(accord. to some copies of the Ḳ; <span class="add">[<a href="#muboSirN">see <span class="ar">مُبْصِرٌ</span></a>, as confirmatory of the latter; but both seem to be correct;]</span>)</span> <em>It</em> <span class="add">[or <em>he</em>]</span> <em>made him</em> <span class="add">[or <em>caused him</em>]</span> <em>to see,</em> or <em>to have sight:</em> or <em>to have mental perception,</em> or <em>knowledge,</em> or <em>skill:</em> syn. <span class="ar long">جَعَلَهُ بَصِيرًا</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bSr_2_B2">
					<p>And the former, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ, Ḳ,)</span> <em>He made him to know.</em> <span class="auth">(Ṣ, Ḳ)</span> You say, <span class="ar long">بَصَّرْتُهُ بِهِ</span>, <span class="auth">(A, Mṣb,)</span> inf. n. as above, <span class="auth">(Mṣb,)</span> <em>I made him to know it; acquainted him with it.</em> <span class="auth">(A, Mṣb.)</span> And <span class="ar long">بصّرهُ الأَمْرَ</span>, inf. n. as above and <span class="ar">تَبْصِرَةٌ</span>, <em>He made him to understand the affair,</em> or <em>case.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bSr_2_B3">
					<p>Also <em>He rendered it apparent,</em> or <em>plainly apparent, conspicuous, manifest,</em> or <em>evident.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bSr_2_C1">
					<p><span class="ar long">بُصِّرَتْ بِدِمَامٍ</span>, said of the feathers of an arrow, <em>They were besmeared</em> <span class="ar">بِالبَصِيرَةِ</span>, i. e. <em>with blood:</em> <span class="auth">(Ṣ:)</span> or <em>were strengthened and fastened with glue.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bSr_2_D1">
					<p>Also <span class="ar">بصّر</span>, inf. n. <span class="ar">تَبْصِيرٌ</span>; <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">ابصر↓</span></span>; <span class="auth">(Ḳ;)</span> <em>He went,</em> <span class="auth">(Ṣ,)</span> or <em>came,</em> <span class="auth">(M, Ḳ,)</span> <em>to the city of El-Basrah</em> (<span class="ar">البَصْرَة</span>). <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باصر</span></h3>
				<div class="sense" id="bSr_3_A1">
					<p><span class="ar">باصرهُ</span> <em>He looked with at a thing, trying which of them two would see it before the other.</em> <span class="auth">(M.)</span> And <span class="ar">بَاصَرَا</span> <em>They two looked, trying which of them would see first.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bSr_3_A2">
					<p><em>He elevated himself,</em> or <em>rose up,</em> or <em>stood up, so as to be higher than the surrounding objects,</em> (<span class="ar">أَشْرَفَ</span>,) <em>looking at him,</em> or <em>towards him, from afar.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bSr_3_A3">
					<p><a href="#bSr_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابصر</span></h3>
				<div class="sense" id="bSr_4_A1">
					<p><span class="ar">ابصرهُ</span>, <span class="auth">(Lḥ Ṣ M, A, &amp;c.,)</span> inf. n. <span class="ar">إِبْصَارٌ</span>, <span class="auth">(Mṣb,)</span> <em>He saw him,</em> or <em>it,</em> <span class="auth">(Lḥ, Ṣ, A, Mgh, Mṣb,)</span> <span class="ar long">بِرُؤْيَةِ العَيْنِ</span> <em>by the sight of the eye;</em> <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar long">بَصُرَ↓ بِهِ</span></span>: <span class="auth">(A:)</span> or <em>he looked</em> <span class="auth">(M, Ḳ)</span> <em>at,</em> or <em>towards, him,</em> or <em>it,</em> <span class="auth">(M,)</span> <em>trying whether he could see him,</em> or <em>it;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar long">بَصُرَ↓ بِهِ</span></span>, inf. n.<span class="ar">بَصَرٌ</span> and <span class="ar">بَصَارَةٌ</span> and <span class="ar">بِصَارَةٌ</span>; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar long">بَصِرَ↓ به</span></span>; <span class="auth">(Lḥ, M;)</span> and<span class="arrow"><span class="ar">تبّصرهُ↓</span></span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar">باصرهُ↓</span></span>: <span class="auth">(M:)</span> or, accord. to Sb, <span class="arrow"><span class="ar">بَصُرَ↓</span></span> <span class="add">[is used when no object of sight is mentioned, and]</span> signifies <em>he</em> <span class="add">[<em>saw,</em> or]</span> <em>became seeing:</em> and <span class="ar">ابصرهُ</span> is said when one mentions that upon which his eye has fallen. <span class="auth">(M.)</span> You say also, <span class="ar long">أَبْصِرَ إِلَىَّ</span> <em>Look thou at me:</em> or <em>turn thy face towards me.</em> <span class="auth">(Ibn-Buzurj, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bSr_4_A2">
					<p><a href="#bSr_1">See also 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bSr_4_B1">
					<p><a href="#bSr_2">And see 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bSr_4_C1">
					<p><span class="ar long">أَبْصِرْ بِهِ وَأَسْمِعْ</span>, in the Ḳur <span class="add">[xviii. 25]</span>, means <span class="ar long">مَا أَبْصَرَهُ وَمَا أَسْمَعَهُ</span> <span class="auth">(Jel)</span> ‡ <em>How clear is his sight! and how clear his hearing!</em> the pronoun relating to God; <span class="auth">(Bḍ, Jel;)</span> and thus used, the phrase is tropical; i. e., nothing escapes his sight and hearing. <span class="auth">(Jel.)</span> And <span class="ar long">أَسْمِعْ بِهِمْ وَأَبْصِرْ</span>, in the same <span class="add">[xix. 39]</span>, means <span class="ar long">مَا أَسْمَعَهُمْ وَمَا أَبْصَرَهُمْ</span> <span class="auth">(Ṣ in art. <span class="ar">سمع</span>, and Jel)</span> <em>How clearly shall they hear! </em> and <em>how clearly shall they see!</em> <span class="auth">(Ṣ, Bḍ, Jel:)</span> or the meaning is, <em>do thou make them to hear, and make them to see,</em> the threats of that day which is afterwards mentioned, and what shall befall them therein. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bSr_4_D1">
					<p><span class="ar">أَبْصَرَ</span> also signifies <em>He relinquished infidelity, and adopted the true belief.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="bSr_4_E1">
					<p><a href="#bSr_10">See also 10</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="bSr_4_F1">
					<p><em>He hung upon the door of his dwelling a</em> <span class="ar">بَصِيرَة</span>, i. e. <em>an oblong piece of cotton</em> or <em>other cloth.</em> <span class="auth">(TA.)</span></p>
				</div>
						<span type="dis">＝</span>
				<div class="sense" id="bSr_4_g1">
					<p><a href="#bSr_2">See also 2</a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبصّر</span></h3>
				<div class="sense" id="bSr_5_A1">
					<p><span class="ar">تبصّرهُ</span> <em>He looked at it;</em> namely, a thing: or <em>looked long at it:</em> or <em>glanced lightly at it:</em> like <span class="ar">رَمَقَهُ</span>: <span class="auth">(TA:)</span> or <em>he sought,</em> or <em>endeavoured, to see it:</em> <span class="auth">(Mgh:)</span> <em>or i. q. </em> <span class="ar">أَبْصَرَهُ</span>, in a sense explained above; <a href="#bSr_4">see 4</a>. <span class="auth">(M.)</span> You say also, <span class="ar long">تَبَصَّرْ لِى فُلَانًا</span> <span class="add">[<em>Consider thou,</em> or <em>examine thou, for me, such a one, that thou mayest obtain a clear knowledge of him</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">تبصّر فِى شَىْءٍ</span> <em>He considered a thing, endeavouring to obtain a clear knowledge of it; he looked into it, considered it, examined it,</em> or <em>studied it, repeatedly, until he knew it: he sought,</em> or <em>sought leisurely,</em> or <em>repeatedly, after the knowledge of it, until he knew it.</em> <span class="auth">(Ṣ,* Ḳ,* TA.)</span> And <span class="ar long">تبصّر فِى رَأْيِهِ</span> signifies the same as<span class="arrow"><span class="ar long">استبصر↓ فِيهِ</span></span>, i. e. <em>He sought,</em> or <em>endeavoured, to see,</em> or <em>discover, what would happen to him, of good and evil.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSr_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباصر</span></h3>
				<div class="sense" id="bSr_6_A1">
					<p><span class="ar">تباصروا</span> <em>They saw one another.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bSr_6_A2">
					<p><span class="add">[<span class="ar">تباصر</span> also signifies <em>He feigned himself seeing,</em> either <em>ocularly</em> or <em>mentally; contr. of</em> <span class="ar">تَعَامَى</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bSr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبصر</span></h3>
				<div class="sense" id="bSr_10_A1">
					<p><span class="ar">استبصر</span> <span class="add">[<em>He sought,</em> or <em>endeavoured, to see,</em> or <em>to perceive mentally</em>]</span>. You say, <span class="ar long">استبصر فِى رَأْيِهِ</span>: <a href="#bSr_5">see 5</a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bSr_10_A2">
					<p><em>He had,</em> or <em>was endowed with,</em> <span class="add">[<em>mental perception,</em> or]</span> <em>knowledge,</em> <span class="auth">(Mṣb,)</span> <span class="add">[or <em>understanding, intelligence,</em> or <em>skill:</em> as in the phrase,]</span> <span class="ar long">استبصر فِى شَىْءٍ</span> <span class="add">[<em>He had a mental perception,</em> or <em>knowledge,</em>, &amp;c., <em>of,</em> or <em>in relation to, a thing</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#musotaboSirN">See <span class="ar">مُسْتَبْصِرٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bSr_10_B1">
					<p><em>It</em> <span class="auth">(a road, TA)</span> <em>was,</em> or <em>became, plain, clear, manifest,</em> or <em>conspicuous;</em> <span class="auth">(Ḳ,* TA;)</span> as also<span class="arrow"><span class="ar">ابصر↓</span></span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baSorN">
				<h3 class="entry"><span class="ar">بَصْرٌ</span></h3>
				<div class="sense" id="baSorN_A1">
					<p><span class="ar">بَصْرٌ</span>: <a href="#baSorapN">see <span class="ar">بَصْرَةٌ</span></a>, in four places: <a href="#buSorapN">and see <span class="ar">بُصْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buSorN">
				<h3 class="entry"><span class="ar">بُصْرٌ</span></h3>
				<div class="sense" id="buSorN_A1">
					<p><span class="ar">بُصْرٌ</span> The <em>thickness</em> of anything; <span class="auth">(M;)</span> as of the heaven, <span class="auth">(TA,)</span> or of each heaven <span class="add">[of the seven heavens]</span>, <span class="auth">(Ṣ, A, TA,)</span> and of the earth, <span class="add">[or of each of the seven earths,]</span> and of the skin of a man, <span class="auth">(TA,)</span> and of a garment, or piece of cloth. <span class="auth">(A.)</span> <span class="pb" id="Page_0211"></span>You say <span class="ar long">ثَوْبٌ جَيِّدُ البُصْرِ</span> <em>A thick garment</em> or <em>piece of cloth.</em> <span class="auth">(M.)</span> <span class="ar">صُبْرٌ</span>, formed by transposition, signifies the same. <span class="auth">(Ṣ in art. <span class="ar">صبر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بُصْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buSorN_A2">
					<p><em>A side:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> the <em>edge</em> of anything: <span class="auth">(Ṣ, Ḳ:)</span> formed by transposition from <span class="ar">صُبْرٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بُصْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buSorN_B1">
					<p><em>Cotton:</em> <span class="auth">(Ḳ:)</span> whence <span class="ar">بَصِيرَةٌ</span> signifying “an oblong piece of cotton cloth.” <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بُصْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="buSorN_C1">
					<p><a href="#baSorapN">See also <span class="ar">بَصْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biSorN">
				<h3 class="entry"><span class="ar">بِصْرٌ</span></h3>
				<div class="sense" id="biSorN_A1">
					<p><span class="ar">بِصْرٌ</span>: <a href="#baSorapN">see <span class="ar">بَصْرَةٌ</span></a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSarN">
				<h3 class="entry"><span class="ar">بَصَرٌ</span></h3>
				<div class="sense" id="baSarN_A1">
					<p><span class="ar">بَصَرٌ</span> The <em>sense of sight,</em> <span class="auth">(Lth, Ṣ,)</span> or <em>of the eye:</em> <span class="auth">(M, Ḳ:)</span> or the <em>light whereby the organ</em> <span class="add">[<em>of sight</em>]</span> (<span class="ar">الجَارِحَة</span>) <em>perceives the things seen</em> (<span class="ar">المُبْصَرَات</span>): <span class="auth">(Mṣb:)</span> pl. <span class="ar">أَبْصَارٌ</span>. <span class="auth">(M, Mṣb, Ḳ.)</span> <span class="add">[Hence,]</span> <span class="ar long">صَلَاةُ البَصَرِ</span> <em>The prayer of sunset:</em> or, as some say, <em>of daybreak:</em> because performed when the darkness becomes mixed with the light: <span class="auth">(TA:)</span> or because performed when the stars are seen: also called <span class="ar long">صَلَاةُ الشَّاهِدِ</span>: <span class="auth">(TA in art. <span class="ar">شهد</span>:)</span> or because performed at a time when the eyes see corporeal forms, after the intervention of darkness, or before it. <span class="auth">(JM.)</span> And <span class="ar long">لَقِيَهُ بَصَرًا</span> <em>He met him when eyes saw one another:</em> or <em>at the beginning of darkness, when there remained enough light for objects to be distinguished thereby:</em> <span class="add">[accord. to some,]</span> the noun is used <span class="add">[in the sense which it here bears]</span> only as an adv. n. <span class="add">[of time]</span>. <span class="auth">(M.)</span> And <span class="ar long">رَأَيْتُهُ بَيْنَ سَمْعِ الأَرْضِ وَبَصَرِهَا</span> ‡ <em>I saw him in a vacant tract of land,</em> or <em>of the earth, where nothing but it heard or saw me.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#samoEN">See also <span class="ar">سَمْعٌ</span></a>, in two places.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baSarN_A2">
					<p><a href="#baSiyrapN">See also <span class="ar">بَصِيرَةٌ</span></a>, first sentence, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baSarN_A3">
					<p>Also The <em>eye;</em> <span class="add">[and so<span class="arrow"><span class="ar">بَاصِرَةٌ↓</span></span>;]</span> syn. <span class="ar">عَيْنٌ</span>; but of the masc. gender: <span class="auth">(TA:)</span> pl. as above: <span class="auth">(Ḳur ii. 6, &amp;c.:)</span> but the sing. is also used in a pl. sense <span class="add">[like <span class="ar">سَمْعٌ</span>]</span>. <span class="auth">(TA in art. <span class="ar">سمع</span>.)</span> See two exs. voce <span class="ar">بَصِيرةٌ</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSorapN">
				<h3 class="entry"><span class="ar">بَصْرَةٌ</span></h3>
				<div class="sense" id="baSorapN_A1">
					<p><span class="ar">بَصْرَةٌ</span> <em>Soft stones;</em> <span class="auth">(AA, M, Mṣb;)</span> <em>i. q.</em> <span class="ar">كَذَّانُ</span>; <span class="auth">(AA, M;)</span> as also<span class="arrow"><span class="ar">بِصْرٌ↓</span></span> <span class="auth">(M, Mṣb)</span> and<span class="arrow"><span class="ar">بَصْرٌ↓</span></span>; or, accord. to Zj, this last is not allowable: <span class="auth">(Mṣb:)</span> or <em>soft stones in which is whiteness:</em> <span class="auth">(Ḳ:)</span> or <em>in which is some whiteness:</em> <span class="auth">(TA:)</span> or <em>soft stones inclining to white;</em> as also<span class="arrow"><span class="ar">بِصْرٌ↓</span></span>, with kesr if without <span class="ar">ة</span>: <span class="auth">(Ṣ:)</span> <span class="add">[i. e. <em>whitish soft stones:</em>]</span> or <em>soft white stone;</em> as also<span class="arrow"><span class="ar">بِصْرٌ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">بَصْرٌ↓</span></span>: <span class="auth">(TA:)</span> or <em>glistening stones;</em> as also<span class="arrow"><span class="ar">بِصْرٌ↓</span></span>: <span class="auth">(Fr:)</span> pl. <span class="ar">بِصَارٌ</span>: <span class="auth">(M:)</span> and <em>rugged ground:</em> <span class="auth">(Ḳ:)</span> or <em>stones of rugged ground;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بِصْرٌ↓</span></span> and<span class="arrow"><span class="ar">بَصْرٌ↓</span></span> and<span class="arrow"><span class="ar">بُصْرٌ↓</span></span>: <span class="auth">(Ḳz, TA:)</span> or these three words, without <span class="ar">ة</span>, signify <em>thick,</em> or <em>rough,</em> or <em>rugged, stone:</em> <span class="auth">(Ḳ:)</span> or the same three, <em>hard,</em> or <em>strong, and thick,</em> or <em>rough,</em> or <em>rugged, stone:</em> <span class="auth">(Lḥ, M:)</span> and <span class="ar">بَصْرَةٌ</span> signifies, also, <em>land that is as though it were a mountain of gypsum:</em> <span class="auth">(ISh, L:)</span> or <em>land of which the stones are gypsum;</em> <span class="auth">(M, TA;)</span> as also<span class="arrow"><span class="ar">بَصَرَةٌ↓</span></span> and<span class="arrow"><span class="ar">بَصِرَةٌ↓</span></span>; <span class="auth">(so in a copy of the M, but accord. to the TA <span class="arrow"><span class="ar">بُصْرَةٌ↓</span></span> and<span class="arrow"><span class="ar">بِصْرَةٌ↓</span></span>;)</span> but the last is app. an epithet: <span class="auth">(M: <span class="add">[<a href="#baSirapN">see <span class="ar">بَصِرَةٌ</span>, below</a>; and <span class="ar">بُصْرَةٌ</span>:]</span>)</span> also <em>tough clay in which is gypsum;</em> <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بَصِرَةٌ↓</span></span> signifies <em>tough clay:</em> <span class="auth">(M, TA:)</span> or <span class="ar">بَصْرَةٌ</span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">بَصْرٌ↓</span></span>, <span class="auth">(TA,)</span> <em>tough and good clay, containing pebbles.</em> <span class="auth">(Lḥ, M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buSorapN">
				<h3 class="entry"><span class="ar">بُصْرَةٌ</span></h3>
				<div class="sense" id="buSorapN_A1">
					<p><span class="ar">بُصْرَةٌ</span> <span class="add">[in the TA, as on the authority of ISd, <span class="arrow"><span class="ar">بَصْرَةٌ↓</span></span>,]</span> <em>Good red land.</em> <span class="auth">(M, Ḳ.)</span> <a href="#baSorapN">See also <span class="ar">بَصْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biSorapN">
				<h3 class="entry"><span class="ar">بِصْرَةٌ</span></h3>
				<div class="sense" id="biSorapN_A1">
					<p><span class="ar">بِصْرَةٌ</span>: <a href="#baSorapN">see <span class="ar">بَصْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baSarapN">
				<h3 class="entry"><span class="ar">بَصَرَةٌ</span></h3>
				<div class="sense" id="baSarapN_A1">
					<p><span class="ar">بَصَرَةٌ</span>: <a href="#baSorapN">see <span class="ar">بَصْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSirapN">
				<h3 class="entry"><span class="ar">بَصِرَةٌ</span></h3>
				<div class="sense" id="baSirapN_A1">
					<p><span class="ar long">أَرْضٌ بَصِرَةٌ</span> <em>Land in which are stones that cut the hoofs of beasts.</em> <span class="auth">(TA.)</span> <a href="#baSorapN">See also <span class="ar">بَصْرَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSiyrN">
				<h3 class="entry"><span class="ar">بَصِيرٌ</span></h3>
				<div class="sense" id="baSiyrN_A1">
					<p><span class="ar">بَصِيرٌ</span> <em>Seeing; i. q.</em> <span class="arrow"><span class="ar">مُبْصِرٌ↓</span></span>; <span class="auth">(M, Ḳ;)</span> <em>contr. of</em> <span class="ar">ضَرِيرٌ</span>: <span class="auth">(Ṣ:)</span> of the measure <span class="ar">فَعِيلٌ</span> in the sense of the measure <span class="ar">مُفْعِلٌ</span>, <span class="auth">(M,)</span> or of the measure <span class="ar">فَاعِلٌ</span> <span class="add">[i. e.<span class="arrow"><span class="ar">بَاصِرٌ↓</span></span>]</span>: <span class="auth">(TA:)</span> pl. <span class="ar">بُصَرَآءُ</span>. <span class="auth">(M, Ḳ.)</span> One says, <span class="ar long">إِنَّهُ لَبَصِيرٌ بِالعَيْنَيْنِ</span> <em>Verily he is one who sees with the two eyes.</em> <span class="auth">(Lḥ, M.)</span> <span class="add">[Hence,]</span> <span class="ar">البَصِيرُ</span>, as a name of God, <em>The All-seeing; He who sees all things, both what are apparent thereof and what are occult, without any organ</em> <span class="add">[<em>of vision</em>]</span>. <span class="auth">(TA.)</span> And <em>The dog;</em> <span class="auth">(M;)</span> as also <span class="ar long">أَبُو بَصِيرٍ</span>: <span class="auth">(Mṣb:)</span> because it is one of the most sharp-sighted of animals. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baSiyrN_A2">
					<p><em>Endowed with mental perception;</em> <span class="auth">(B;)</span> <em>knowing; skilful; possessing understanding, intelligence,</em> or <em>skill:</em> <span class="auth">(Ṣ, M, A, Mṣb, Ḳ:)</span> pl. as above. <span class="auth">(A.)</span> One says, <span class="ar long">أَنَا بَصِيرٌ بِهِ</span> <em>I am knowing in it,</em> or <em>respecting it.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">إِنَّهُ لَبَصِيرٌ بِالأَشْيَآءِ</span> <em>Verily he is knowing,</em> or <em>skilful, in things.</em> <span class="auth">(Lḥ, M.)</span> And <span class="ar long">رَجُلٌ بَصِيرٌ بِالعِلْمِ</span> <em>A man knowing,</em> or <em>skilful, in science.</em> <span class="auth">(M.)</span> And <span class="ar long">هُوَ مِنَ البُصَرَآءِ بِالِتّجَارَةِ</span> <em>He is of those who are knowing,</em> or <em>skilful, in commerce.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baSiyrN_A3">
					<p>It is also an epithet applied to A <em>blind</em> man; <span class="auth">(AʼObeyd, M, B;)</span> and so <span class="ar long">أَبُو بَصِيرٍ</span>: <span class="auth">(TA in art. <span class="ar">عور</span>:)</span> so applied as meaning <em>endowed with mental perception;</em> <span class="auth">(B;)</span> or as meaning <em>a believer;</em> <span class="auth">(AʼObeyd, M;)</span> or as an epithet of good omen: <span class="auth">(M:)</span> and <span class="ar long">أَبُو بَصِيرٍ</span> is used as meaning <span class="ar">الأَعْشَى</span> <span class="add">[<em>the weaksighted,</em>, &amp;c.,]</span> for this last reason. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baSiyrN_B1">
					<p><a href="#baSiyrapN">See also <span class="ar">بَصِيرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baSiyrapN">
				<h3 class="entry"><span class="ar">بَصِيرَةٌ</span></h3>
				<div class="sense" id="baSiyrapN_A1">
					<p><span class="ar">بَصِيرَةٌ</span> <em>Mental perception;</em> the <em>perceptive faculty of the mind;</em> as also<span class="arrow"><span class="ar">بَصَرٌ↓</span></span>: <span class="auth">(B:)</span> <em>knowledge;</em> <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">بَصَرٌ↓</span></span> <span class="auth">(Ṣ, Mṣb)</span> and <span class="ar">اِسْتِبْصَارٌ</span>: <span class="auth">(Mṣb:)</span> <em>understanding; intelligence; skill:</em> <span class="auth">(M, Ḳ:)</span> <span class="ar">البَصِيرَةُ</span> signifies <span class="ar long">الاِ سْتِبْصَارُ فِى الشَّىْءِ</span> <span class="add">[which implies all the meanings above: <a href="#bSr_10">see 10</a>]</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar long">بَصَرُ↓ القَلْبِ</span></span> <span class="add">[in like manner]</span> signifies <em>mental perception</em> or <em>vision</em> or <em>view; idea,</em> or <em>opinion, occurring to the mind:</em> <span class="auth">(M, Ḳ:)</span> <a href="#baSiyrapN">the pl. of <span class="ar">بَصِيرَةٌ</span></a> is <span class="ar">بَصَائرُ</span>; <span class="auth">(M, B;)</span> and the pl. of<span class="arrow"><span class="ar">بَصَرٌ↓</span></span>, as syn. therewith, <span class="ar">أَبْصَارٌ</span>. <span class="auth">(B.)</span> <span class="add">[Sometimes it is opposed to <span class="ar">بَصَرٌ</span>, as in the first and second of the following exs.]</span> <span class="arrow"><span class="ar long">عَمَى الأَبْصَارِ↓ أَهُونُ مِنْ عِمَى البَصَائِرِ</span></span> <span class="add">[<em>Blindness of the eyes is a lighter thing than blindness of the perceptive faculties of the mind</em>]</span>. <span class="auth">(A.)</span> When Mo'áwiyeh said to Ibn-ʼAbbás,<span class="arrow"><span class="ar long">يَا بَنِى هَاشِمٍ تُصَابُونَ فِى أَبْصَارِكُمْ↓</span></span> <span class="add">[<em>O sons of Háshim, ye are afflicted in your eyes</em>]</span>, the latter replied, <span class="ar long">وَأَنْتُمْ يَا بَنِى أُمَيَّةَ تُصَابُونَ فِى بَصَائِرِكُمْ</span> <span class="add">[<em>And ye, O sons of Umeiyeh, are afflicted in your perceptive faculties of the mind</em>]</span>. <span class="auth">(M.)</span> And the Arabs say, <span class="ar long">أَعْمَى ٱللّٰهُ بَصَائِرَةُ</span> <em>May God blind his faculties of understanding!</em> And one says, <span class="ar long">لَهُ فِرَاسَةٌ ذَاتُ بَصِيرَةٍ</span>, and <span class="ar">بَصَائِرَ</span>, ‡ <em>He possesses true intuitive perception.</em> <span class="auth">(A.)</span> And <span class="ar long">رَأَيْتُ عَلَيْكَ ذَاتَ البَصَائِرِ</span> ‡ <span class="add">[<em>I saw</em> impressed <em>upon thee the signs of perceptive faculties of the mind</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baSiyrapN_A2">
					<p>Also <em>Belief,</em> or <em>firm belief, of the heart,</em> or <em>mind.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">عَلَى بَصِيرَةٍ</span> <em>According to,</em> or <em>agreeably with, knowledge and assurance:</em> <span class="auth">(TA:)</span> and <em>purposely; intentionally.</em> <span class="auth">(M, TA.)</span> And <span class="ar long">عَلَى غَيْرِ بَصِيرَةٍ</span> <em>Without certainty.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baSiyrapN_A3">
					<p><em>Constancy,</em> or <em>firmness, in religion.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baSiyrapN_A4">
					<p><em>An evidence, a testimony, a proof, an argument,</em> or <em>the like;</em> as also<span class="arrow"><span class="ar">مَبْصَرَةٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">مَبْصَرٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baSiyrapN_A5">
					<p><span class="add">[And hence,]</span> <em>Blood,</em> <span class="auth">(M,)</span> or <em>somewhat thereof,</em> <span class="auth">(Aṣ, Ṣ, Ḳ,)</span> <em>by which one is directed to an animal that has been shot,</em> or <em>to the knowledge thereof:</em> <span class="auth">(Aṣ, AA, Ṣ, M, Ḳ:)</span> or <em>blood upon the ground;</em> <span class="auth">(AZ, Ṣ;)</span> <em>what sticks upon the ground, not upon the body:</em> <span class="auth">(M:)</span> what adheres to the body is termed <span class="ar">جَدِيَّةٌ</span>: <span class="auth">(AZ, Ṣ:)</span> or <em>a portion of blood of the size of a dirhem:</em> <span class="auth">(TA:)</span> or <em>what is of a round form, like a shield:</em> or <em>what is of an oblong form:</em> or <em>what is of the size of the</em> <span class="ar">فِرْسِن</span> <span class="add">[or <em>foot</em>]</span> <em>of the camel:</em> in all these explanations, blood being meant: or <em>blood not flowing:</em> or <em>what flows thereof at one single time:</em> <span class="auth">(M:)</span> or <em>a portion of blood that glistens:</em> <span class="auth">(B:)</span> and <span class="auth">(as some say, M)</span> the <em>blood of a virgin:</em> <span class="auth">(M, Ḳ:)</span> and <em>blood-revenge:</em> and <em>a fine for homicide:</em> <span class="auth">(TA:)</span> pl. <span class="ar">بَصَائِرُ</span>, as above: <span class="auth">(Ṣ, M:)</span> and<span class="arrow"><span class="ar">بَصِيرٌ↓</span></span>, which occurs in a verse cited by AḤn, may also be <a href="#baSiyrapN">a pl. of <span class="ar">بَصِيرَةٌ</span></a>, applied to blood, <span class="add">[or rather a coll. gen. n., of which <span class="ar">بصيرة</span> is the n. un.,]</span> like as <span class="ar">شَعِيرٌ</span> is of <span class="ar">شَعِيرَةٌ</span>; or it may be for <span class="ar">بصيرة</span>, the <span class="ar">ة</span> being elided by poetic license; or it may be <a href="#bSyrp">a dial. var. of <span class="ar">بصيرة</span></a>, like as one says <span class="ar">بَيَاضٌ</span> and <span class="ar">بَيَاضَةٌ</span>. <span class="auth">(M.)</span> El-As'ar El-Joafee says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">رَاحوا بَصَائِرُهُمْ عَلَى أَكْتَافِهِمْ</span> *</div> 
						<div class="star">* <span class="ar long">وَبَصِيرَتِى يَعْدُو بِهَا عَتَدٌ وَأَى</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They went with their blood upon their shoulderblades; but my blood, a ready and swift and strong horse runs with it</em>]</span>; meaning, they neglected the blood of their father, and left it behind them; i. e., they did not take revenge for it; but I have sought my blood-revenge: <span class="auth">(Ṣ, M:*)</span> but see another explanation in what follows. <span class="auth">(Ṣ. <span class="add">[See also Ḥam p. 59.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baSiyrapN_A6">
					<p>‡ <em>A witness:</em> <span class="auth">(Lḥ, Ṣ,* M, Mgh, Ḳ:)</span> <em>an observer and a witness.</em> <span class="auth">(A.)</span> <span class="ar long">بَلِ الإِنْسَانُ عَلَى نَفْسِهِ بَصِيرَةٌ</span>, in the Ḳur <span class="add">[lxxv. 14]</span>, means ‡ <em>Nay, the man</em> shall be <em>witness against himself:</em> <span class="auth">(Ṣ, Mgh:)</span> or it means that his arms, or hands, and his legs, or feet, and his tongue, shall be witnesses against him on the day of resurrection: <span class="auth">(M:)</span> Akh says that it is like the saying to a man, <span class="ar long">أَنْتَ حُجَّةٌ عَلَى نَفْسِكَ</span>: <span class="auth">(Ṣ:)</span> the <span class="ar">ة</span> is added because the members are meant thereby; <span class="auth">(B;)</span> or to give intensiveness to the signification, <span class="auth">(Mgh, B,)</span> as in <span class="ar">عَلَّامَةٌ</span> and <span class="ar">رَاوِيَةٌ</span>; <span class="auth">(B;)</span> or because the meaning is <span class="ar long">عَيْنٌ بَصِيرَةٌ</span>. <span class="auth">(Mgh.)</span> You say also, <span class="ar long">اِجْعَلْنِى بَصِيرَةً عَلَيْهِمْ</span> ‡ <em>Make thou me an observer of them and a witness against them.</em> <span class="auth">(Lḥ,* M,* A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baSiyrapN_A7">
					<p><em>An example by which one is admonished:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">بَصَائِرُ</span>; which is said to be used agreeably with this interpretation in the Ḳur xxviii. 43. <span class="auth">(TA.)</span> <span class="pb" id="Page_0212"></span>You say, <span class="ar long">أَمَا لَكَ بَصِيرَةٌ فِيهِ</span> ‡ <em>Hast thou not an example whereby thou shouldst be admonished in him?</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baSiyrapN_B1">
					<p><em>A shield:</em> <span class="auth">(AO, Ṣ, M, Ḳ:)</span> or <em>a glistening shield:</em> or <em>an oblong shield:</em> <span class="auth">(TA:)</span> and <em>a coat of mail:</em> <span class="auth">(AO, Ṣ, M, Ḳ:)</span> and <em>any defensive armour:</em> <span class="auth">(M, TA:)</span> and <span class="ar long">بَصَائِرُ السِّلَاحِ</span> <em>any arms that are worn:</em> and <span class="ar">بِصَارٌ</span>, as well as <span class="ar">بَصَائِرُ</span>, is a pl. thereof. <span class="auth">(TA.)</span> Accord. to AO, the verse of El-Joafee cited above commences thus:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حَمَلُوا بَصَائِرَهُمْ عَلَى أَكْتَافِهِمْ</span> *</div> 
					</blockquote>
					<p>and the meaning is, <span class="add">[<em>They bore</em>]</span> <em>their shields</em> <span class="add">[<em>upon their shoulder-blades</em>]</span>; or <em>their coats of mail.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="baSiyrapN_C1">
					<p><em>An oblong piece of cloth</em> <span class="auth">(Ḳ, TA)</span> <em>of cotton or other material.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#buSorN">See <span class="ar">بُصْرٌ</span></a>.]</span> Such is hung upon the door of a dwelling. <span class="auth">(TA.)</span> And you say, <span class="ar long">رَأَيْتُ عَلَيْهِ بَصِيرَةً</span>, i. e. <span class="ar long">شُقَّةً مُلَفَّقَةً</span> <span class="add">[app. meaning <em>I saw upon him a garment composed of two oblong pieces of cloth joined and sewed together</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَصِيرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="baSiyrapN_C2">
					<p><em>What is between the two oblong pieces of cloth</em> <span class="add">[i. e. <em>between any two of such pieces</em>]</span> <em>of a</em> <span class="ar">بَيْت</span> <span class="add">[or <em>tent</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> and <em>what is between the two pieces of a</em> <span class="ar">مَزَادَة</span> and <em>the like; what is sewed, thereof, in the manner termed</em> <span class="ar">بَصْرٌ</span> <span class="add">[<a href="#bSr_1">inf. n. of <span class="ar">بَصَرَ</span></a>: <a href="#bSr_1">see 1</a>, last sentence]</span>: <span class="auth">(B:)</span> pl. <span class="ar">بَصَائِرُ</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar">بَاصِرٌ↓</span></span> signifies <span class="add">[in like manner]</span> <em>what is joined and sewed together</em> (<span class="ar">مُلَفَّق</span>) <em>between two oblong pieces of cloth</em> or <em>two pieces of rag.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baASirN">
				<h3 class="entry"><span class="ar">بَاصِرٌ</span></h3>
				<div class="sense" id="baASirN_A1">
					<p><span class="ar">بَاصِرٌ</span>: <a href="#baSiyrN">see <span class="ar">بَصِيرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَاصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baASirN_A2">
					<p><span class="ar long">لَمْحٌ بَاصِرٌ</span> ‡ <em>An intent,</em> or <em>a hard, glance:</em> <span class="auth">(M, Ḳ:)</span> or <em>a very intent</em> or <em>hard glance.</em> <span class="auth">(Ṣ.)</span> You say, <span class="ar long">أَرَيْتُهُ لَمْحًا بَاصِرًا</span> ‡ <em>I showed him a very intent</em> or <em>hard glance:</em> <span class="auth">(Ṣ, M:*)</span> <span class="ar">باصرا</span> being here used for the augmented epithet <span class="add">[<span class="ar">مُبْصِرًا</span>]</span>; <span class="auth">(M;)</span> or it is a possessive epithet, <span class="auth">(Yaạḳoob, M,)</span> like <span class="ar">لَابِنٌ</span> and <span class="ar">تَامِرٌ</span>, meaning <span class="ar long">ذُو بَصَرٍ</span>, from <span class="ar">أَبْصَرْتُ</span>, like <span class="ar long">مَوْتٌ مَائِتٌ</span> from <span class="ar">أَمَتُّ</span>; and it means <em>I showed him a severe thing.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">لَقِىَ مِنْهُ لَمْحًا بَاصِرًا</span> ‡ <em>He experienced from him a manifest,</em> or <em>an evident, thing.</em> <span class="auth">(M. <span class="add">[<a href="index.php?data=23_l/145_lmH">See also art. <span class="ar">لمح</span></a>.]</span>)</span> And <span class="ar long">رَأَى فُلَانٌ لَمْحًا بَاصِرًا</span> ‡ <em>Such a one beheld a terrible thing.</em> <span class="auth">(Lth, TA.)</span> And <span class="ar long">أَرَانِى الزَّمَانُ لَمْحًا بَاصِرًا</span> ‡ <em>Fortune showed me a terrifying thing.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَاصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baASirN_A3">
					<p>It is said in a prov., <span class="ar long">خَيْرُ الغَدَآءِ بَوَاكِرُهُ وَخَيْرُ العَشَآءِ بَوَاصِرُهُ</span>, <span class="add">[the word <span class="ar">بَوَاصِرُ</span> being pl. of<span class="arrow"><span class="ar">بَاصِرَةٌ↓</span></span>,]</span> meaning <span class="add">[<em>The best kinds of morning-meal are those thereof that are early; and the best kinds of evening-meal are those thereof</em>]</span> <em>in which the food is seen,</em> before the invasion of night. <span class="auth">(Meyd. See Freytag's Arab. Prov. i. 442.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَاصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baASirN_A4">
					<p><span class="ar">بَاصِرَةٌ</span> <span class="add">[as an epithet in which the quality of a subst. predominates]</span>: <a href="#baSarN">see <span class="ar">بَصَرٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">بَاصِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baASirN_B1">
					<p><a href="#baSayrapN">See also <span class="ar">بَصَيرَةٌ</span></a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baASirapN">
				<h3 class="entry"><span class="ar">بَاصِرَةٌ</span></h3>
				<div class="sense" id="baASirapN_A1">
					<p><span class="ar">بَاصِرَةٌ</span>: <a href="#baSarN">see <span class="ar">بَصَرٌ</span></a>: <a href="#baASirN">and see <span class="ar">بَاصِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baASuwrN">
				<h3 class="entry"><span class="ar">بَاصُورٌ</span></h3>
				<div class="sense" id="baASuwrN_A1">
					<p><span class="ar">بَاصُورٌ</span>: <a href="#baAsuwrN">see <span class="ar">بَاسُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binoSirN">
				<h3 class="entry"><span class="ar">بِنْصِرٌ</span></h3>
				<div class="sense" id="binoSirN_A1">
					<p><span class="ar">بِنْصِرٌ</span>: <a href="index.php?data=02_b/193_bnSr">see art. <span class="ar">بنصر</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboSaru">
				<h3 class="entry"><span class="ar">أَبْصَرُ</span></h3>
				<div class="sense" id="OaboSaru_A1">
					<p><span class="ar">أَبْصَرُ</span> <span class="add">[<em>More,</em> and <em>most, sharp-sighted</em> or <em>clearsighted:</em> see an ex. voce <span class="ar">حَيَّةٌ</span>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboSarN">
				<h3 class="entry"><span class="ar">مَبْصَرٌ</span></h3>
				<div class="sense" id="maboSarN_A1">
					<p><span class="ar">مَبْصَرٌ</span>: <a href="#baSayrpN">see <span class="ar">بَصَيرةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muboSarN">
				<h3 class="entry"><span class="ar">مُبْصَرٌ</span> / <span class="ar">مُبْصَرَةٌ</span></h3>
				<div class="sense" id="muboSarN_A1">
					<p><span class="ar">مُبْصَرٌ</span> and its fem. <span class="ar">مُبْصَرَةٌ</span>: <a href="#muboSirN">see the next paragraph</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboSirN">
				<h3 class="entry"><span class="ar">مُبْصِرٌ</span></h3>
				<div class="sense" id="muboSirN_A1">
					<p><span class="ar">مُبْصِرٌ</span>: <a href="#baSiyrN">see <span class="ar">بَصِيرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">مُبْصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muboSirN_A2">
					<p><span class="add">[Hence,]</span> ‡ <em>A watcher,</em> or <em>guard,</em> set in a garden. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">مُبْصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="muboSirN_A3">
					<p>And <span class="ar">المُبْصِرُ</span> † <em>The lion,</em> which sees his prey from afar, and pursues it. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">مُبْصِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muboSirN_B1">
					<p><span class="add">[<em>Making,</em> or <em>causing, to see,</em> or <em>to have sight:</em> and hence, <em>giving light; shining; illumining:</em> and <em>conspicuous; manifest; evident; apparent:</em> also <em>making,</em> or <em>causing, to have mental perception,</em> or <em>knowledge,</em> or <em>skill.</em>]</span> <span class="ar long">وَالنَّهَارَ مُبْصِرًا</span>, in the Ḳur <span class="add">[x. 68, &amp;c. <span class="auth">(in the CK<span class="arrow"><span class="ar long">والنّهارُ مُبْصَرًا↓</span></span>)</span>]</span>, means, <em>And the day</em> <span class="add">[<em>causing to see;</em> or]</span> <em>in which one sees;</em> <span class="auth">(Ḳ;)</span> <em>giving light; shining;</em> or <em>illumining.</em> <span class="auth">(TA.)</span> And <span class="ar long">فَلَمَّا جَآءَتْهُمْ آيَاتُنَا مُبْصِرَةً</span>, also in the Ḳur <span class="add">[xxvii. 13]</span>, † <em>And when our signs came to them, making them to have sight,</em> or <em>to have mental perception,</em> or <em>knowledge,</em> or <em>skill;</em> expl. by <span class="ar long">تَجْعَلُهُمْ بُصَرَآءَ</span>: <span class="auth">(Akh, Ṣ, Ḳ:)</span> or <em>giving light; shining;</em> or <em>illumining:</em> <span class="auth">(Ṣ:)</span> or <em>being conspicuous, manifest,</em> or <em>evident:</em> or we may read <span class="arrow"><span class="ar">مُبْصَرَةً↓</span></span>, meaning <em>having become manifest,</em> or <em>evident.</em> <span class="auth">(Zj, M.)</span> And <span class="ar long">آتَيْنَا ثَمُودَ النَّاقَةَ مُبْصِرَةً</span>, also in the Ḳur <span class="add">[xvii. 61]</span>, † <em>And we gave to Thamood the she-camel, by means of which they had sight,</em> or <em>mental perception,</em> or <em>knowledge,</em> or <em>skill:</em> <span class="auth">(Akh:)</span> or <em>a sign giving light, shining,</em> or <em>illumining;</em> <span class="auth">(Fr, T;)</span> and this is the right explanation: <span class="auth">(T:)</span> or <em>a manifest,</em> or <em>an evident, sign:</em> <span class="auth">(Zj, L, Ḳ:)</span> and some read<span class="arrow"><span class="ar">مُبْصَرَةً↓</span></span>, meaning <em>having become manifest, so as to be seen.</em> <span class="auth">(Zj, L.)</span> And <span class="ar long">جَعَلْنَا آيَةَ النَّهَارِ مُبْصِرَةً</span>, also in the Ḳur <span class="add">[xvii. 13]</span>, ‡ <em>We have made the sign of the day manifest,</em> or <em>apparent.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">مُبْصِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="muboSirN_C1">
					<p>One <em>who hangs upon his door a</em> <span class="ar">بَصِيرَة</span>, i. e. <em>an oblong piece of cloth</em> <span class="auth">(Ḳ, TA)</span> <em>of cotton or other material.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboSarapN">
				<h3 class="entry"><span class="ar">مَبْصَرَةٌ</span></h3>
				<div class="sense" id="maboSarapN_A1">
					<p><span class="ar">مَبْصَرَةٌ</span>: <a href="#baSiyrapN">see <span class="ar">بَصِيرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaboSirN">
				<h3 class="entry"><span class="ar">مُسْتَبْصِرٌ</span></h3>
				<div class="sense" id="musotaboSirN_A1">
					<p><span class="ar">مُسْتَبْصِرٌ</span> One <em>who seeks,</em> or <em>endeavours, to see a thing plainly</em> or <em>clearly</em> <span class="add">[either <em>with the eyes</em> or <em>with the mind</em>]</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصر</span> - Entry: <span class="ar">مُسْتَبْصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="musotaboSirN_A2">
					<p><span class="ar long">وَكَانُوا مُسْتَبْصِرِينَ</span>, in the Ḳur <span class="add">[xxix. 37]</span>, means, <em>And they were endowed with perceptive faculties of the mind,</em> or <em>of knowledge,</em> or <em>of skill:</em> <span class="auth">(Jel:)</span> or <em>they clearly perceived,</em> when they did what they did, that the result thereof would be their punishment. <span class="auth">(M.)</span> And you say, <span class="ar long">هُوَ مُسْتَبْصِرٌ فِى دِينِهِ وَعَمَلِهِ</span> <em>He is endowed with mental perception,</em> or <em>knowledge,</em> or <em>understanding, intelligence,</em> or <em>skill, in his religion and his actions.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0210.pdf" target="pdf">
							<span>Lanes Lexicon Page 210</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0211.pdf" target="pdf">
							<span>Lanes Lexicon Page 211</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0212.pdf" target="pdf">
							<span>Lanes Lexicon Page 212</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
