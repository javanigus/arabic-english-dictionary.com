<article class="root" id="Root_bkm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/165_bkr">بكر</a></span>
				<span class="ar">بكم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/167_bke">بكى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bkm_1">
				<h3 class="entry">1. ⇒ <span class="ar">بكم</span></h3>
				<div class="sense" id="bkm_1_A1">
					<p><span class="ar">بَكِمَ</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْكَمُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَكَمٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He was</em> <span class="ar">أَخْرَسٌ</span> <span class="add">[meaning <em>dumb,</em> either <em>by natural conformation</em> or <em>from inability to find words to express what he would say</em>]</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;*)</span> <span class="ar">بَكَمٌ</span> being <em>syn. with</em> <span class="ar">خَرَسٌ</span>, as is also <span class="ar">بَكَامَةٌ</span> <span class="add">[accord. to rule an inf. n. of <span class="ar">بَكُمَ</span>, which may also have the same signification as <span class="ar">بَكِمَ</span>, as well as another to be explained below]</span>: <span class="auth">(Ḳ:)</span> or <em>he had not understanding to reply,</em> <span class="auth">(T, Mṣb, TA,)</span> <em>nor ability to frame speech well,</em> <span class="auth">(T, TA,)</span> <em>though possessing the faculty of speech:</em> <span class="add">[<a href="#Oabokamu">see <span class="ar">أَبْكَمُ</span></a>:]</span> <span class="auth">(T, Mṣb, TA:)</span> or <em>he was dumb, and moreover unable to find words to express what he would say, and weak in understanding, silly,</em> or <em>stupid:</em> <span class="auth">(Ḳ:)</span> or <em>he was dumb and deaf and blind by birth.</em> <span class="auth">(Th, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bkm_1_A2">
					<p><span class="ar">بَكُمَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْكُمُ</span>}</span></add>, <span class="auth">(inf. n. <span class="ar">بَكَامَةٌ</span>, TḲ,)</span> <em>He refrained,</em> <span class="auth">(Lth, Ḳ)</span> or, as some say, <em>broke off,</em> or <em>ceased,</em> <span class="auth">(TA,)</span> <em>from speaking, intentionally,</em> <span class="auth">(Lth, Ḳ, TA,)</span> or <em>from ignorance.</em> <span class="auth">(Lth, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بكم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bkm_1_A3">
					<p>‡ <em>He cut himself off,</em> or <em>desisted, from marriage,</em> or <em>sexual intercourse,</em> either <em>from ignorance</em> or <em>intentionally.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bkm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبكّم</span></h3>
				<div class="sense" id="bkm_5_A1">
					<p><span class="ar long">تبكّم عَلَيْهِ الكَلَامُ</span> <em>His speech was,</em> or <em>became, impeded; he was unable to speak freely.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bakiymN">
				<h3 class="entry"><span class="ar">بَكِيمٌ</span></h3>
				<div class="sense" id="bakiymN_A1">
					<p><span class="ar">بَكِيمٌ</span>: <a href="#OabokamN">see what follows</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabokamN">
				<h3 class="entry"><span class="ar">أَبْكَمٌ</span></h3>
				<div class="sense" id="OabokamN_A1">
					<p><span class="ar">أَبْكَمٌ</span> <span class="auth">(T, Ṣ, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">بَكِيمٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> <em>i. q.</em> <span class="ar">أَخْرَسُ</span> <span class="add">[meaning <em>Dumb,</em> either <em>by natural conformation</em> or <em>from inability to find words to express what he would say</em>]</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or <em>not having understanding to reply,</em> <span class="auth">(IAạr, T, Mṣb, TA,)</span> <em>nor ability to frame speech well,</em> <span class="auth">(T, TA,)</span> <em>though possessing the faculty of speech;</em> whereas <span class="ar">اخرس</span> signifies speechless, or destitute of the faculty of speech, by natural conformation, <span class="auth">(T, Mṣb, TA,)</span> like the beast that lacks the faculty of articulation; <span class="auth">(T, TA;)</span> <em>unable to find words to express what he would say; unable to reply:</em> <span class="auth">(AZ, TA:)</span> or <em>dumb by natural conformation:</em> <span class="auth">(IAth, TA:)</span> fem. <span class="ar">بَكْمَآءُ</span>: <span class="auth">(TA:)</span> pl. <span class="ar">بُكْمٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بُكْمَانٌ</span>, <span class="auth">(Ḳ,)</span> both pls. of <span class="ar">أَبْكَمُ</span>, like as <span class="ar">صُمٌّ</span> and <span class="ar">صُمَّانٌ</span> are pls. of <span class="ar">أَصَمُّ</span>; and the pl. of<span class="arrow"><span class="ar">بَكِيمٌ↓</span></span> is <span class="ar">أَبْكَامٌ</span>. <span class="auth">(TA.)</span> In the Ḳur ii. 166, <span class="ar">بُكْمٌ</span> means persons <em>in the condition of him who has been born dumb:</em> or, as some say, <em>deprived of their intellects:</em> <span class="auth">(Zj, TA:)</span> or <em>ignorant and ignoble;</em> because not profiting much by the faculty of speech, so that they are as though they had been deprived of it. <span class="auth">(IAth, TA.)</span> <span class="pb" id="Page_0242"></span>The phrase <span class="ar long">فِتْنَةٌ صَمَّآءُ بَكْمَآءُ عَمْيَآءُ</span>, occurring in a trad., <span class="add">[lit.]</span> meaning <span class="add">[<em>A sedition,</em> or the like,]</span> <em>deaf, dumb, blind,</em> applies to a <span class="ar">فتنة</span> that does not withdraw, or become removed: or, as some say, to one which, by reason of the confusion attending it, and the perishing of the sound and the sick therein, is likened to the deaf and dumb and blind who does not pursue the right course to a thing, but goes at random like the weak-sighted she-camel. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0241.pdf" target="pdf">
							<span>Lanes Lexicon Page 241</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0242.pdf" target="pdf">
							<span>Lanes Lexicon Page 242</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
