<article class="root" id="Root_bHt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/027_bH">بح</a></span>
				<span class="ar">بحت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/029_bHv">بحث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bHt_1">
				<h3 class="entry">1. ⇒ <span class="ar">بحت</span></h3>
				<div class="sense" id="bHt_1_A1">
					<p><span class="ar">بَحُتَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْحُتُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بُحُوتَةٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">بَحْتٌ</span>, <span class="auth">(Mṣb,)</span> <em>It</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became, unmixed, free from admixture,</em> or <em>pure:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[and]</span> <em>he was unmixed,</em> or <em>pure, in race, lineage,</em> or <em>parentage.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHt_3">
				<h3 class="entry">3. ⇒ <span class="ar">باحت</span></h3>
				<div class="sense" id="bHt_3_A1">
					<p><span class="ar long">باحت المَآءَ</span>, <span class="auth">(A,)</span> inf. n. <span class="ar">مُبَاحَتَةٌ</span>, <span class="auth">(TA,)</span> <em>He drank water,</em> or <em>the water, not upon</em> <span class="ar">ثُفْل</span> <span class="add">[i. e. <em>without having eaten anything such as flesh-meat</em> or <em>bread</em> or <em>dates</em> or <em>grain</em>]</span>: <span class="auth">(A:)</span> or <em>he drank water,</em> or <em>the water, not mixed with honey</em> or <em>any other thing.</em> <span class="auth">(TA.)</span> And <span class="ar long">باحت الشَّرَابَ</span> <em>He drank the wine,</em> or <em>beverage, pure, without any mixture.</em> <span class="auth">(A.)</span> And <span class="ar long">باحت الرِّمْثَ</span> <span class="add">[<em>He</em> <span class="auth">(a camel)</span> <em>ate of the shrub called</em> <span class="ar">رمث</span> <em>without any other pasture</em>]</span>. <span class="auth">(T in art. <span class="ar">طلح</span>.)</span> And <span class="ar long">باحت دَابَّتَهُ بِالضَّرِيعِ</span> <em>He fed his beast with</em> <span class="ar">ضريع</span>, <span class="auth">(i. e. <em>dry herbage,</em> TA,)</span> <em>and the like, unmixed</em> <span class="add">[<em>with other pasture</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحت</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHt_3_A2">
					<p><span class="ar long">باحتهُ الوُدَّ</span> <em>He regarded him,</em> or <em>acted towards him, with reciprocal purity,</em> or <em>sincerity, of love,</em> or <em>affection:</em> <span class="auth">(Ṣ, A, Ḳ:)</span> or <em>he was pure,</em> or <em>sincere, to him in love,</em> or <em>affection.</em> <span class="auth">(M.)</span> And <span class="ar long">باحت القِتَالَ</span> <em>He fought with earnestness and energy, unmixed with lenity.</em> <span class="auth">(A,* TA.)</span> And <span class="ar long">باحت فُلَانًا</span> <span class="auth">(inf. n. as above, TA)</span> <em>He acted openly,</em> or <em>undisguisedly, with,</em> or <em>towards, such a one.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHotN">
				<h3 class="entry"><span class="ar">بَحْتٌ</span> / <span class="ar">بَحْتَةٌ</span></h3>
				<div class="sense" id="baHotN_A1">
					<p><span class="ar">بَحْتٌ</span> <em>Unmixed, free from admixture,</em> or <em>pure;</em> <span class="auth">(Ṣ, A, Mgh, Ḳ;)</span> applied to anything: <span class="auth">(A, Ḳ:)</span> anything <em>that is eaten alone, without seasoning</em> or <em>condiment</em> or <em>any savoury food:</em> and in like manner, seasoning, or condiment, or any savoury food, <em>without bread:</em> <span class="auth">(Aḥmad Ibn-Yaḥyà:)</span> <em>unmixed,</em> or <em>pure, in race, lineage,</em> or <em>parentage;</em> <span class="auth">(Ṣ, A, Mṣb;)</span> applied <span class="add">[for instance]</span> to an Arab, <span class="auth">(Ṣ, A,)</span> and to an Arab of the desert: <span class="auth">(TA:)</span> originally an inf. n.; <span class="auth">(Mṣb;)</span> <span class="add">[and therefore]</span> the same as masc. and fem. and dual and pl.: but if you will, you may use <span class="ar">بَحْتَةٌ</span> as a fem. epithet, applied <span class="add">[for instance]</span> to an Arab woman; and may use the dual and pl. forms: <span class="auth">(Ṣ:)</span> or the fem. is <span class="add">[properly]</span> with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَحْتَةٌ</span>}</span></add>; or, as some say, the word has no dual nor pl. nor dim. form. <span class="auth">(Ḳ.)</span> You say <span class="ar long">شَرَابٌ بَحْتٌ</span> <em>Unmixed wine</em> or <em>beverage:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">خَمْرٌ بَحْتٌ</span> and <span class="ar">بَحْتَةٌ</span> and <span class="ar long">خُمُورٌ بَحْتَةٌ</span> <span class="add">[<em>unmixed wine</em> and <em>wines</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">خُبْزٌ بَحْتٌ</span> <em>Bread without anything else</em> <span class="add">[<em>to season it</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَكَلَ الخُبْزَ بَحْتًا</span>, and <span class="ar long">اللَّحْمَ بَحْتًا</span>, <em>He ate the bread without any seasoning</em> or <em>condiment</em> or <em>savoury food,</em> and <em>the flesh-meat without bread.</em> <span class="auth">(TA.)</span> And <span class="ar long">قَدَّمَ إِلَيْهِ قَفَارًا بَحْتًا</span> <em>He presented to him food without any seasoning</em> or <em>condiment.</em> <span class="auth">(A.)</span> And <span class="ar long">ادَّهَنَ بِدُهْنٍ بَحْتٌ</span> <em>He anointed himself with ointment unmixed with any perfume.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">مِسْكٌ بَحْنٌ</span> <span class="auth">(A, Mṣb)</span> <span class="add">[<em>Unmixed,</em> or <em>unadulterated, and</em> therefore]</span> <em>strong</em> <span class="add">[<em>-scented,</em>]</span> <em>musk.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">بَرْدٌ بَحْتٌ لَحْتٌ</span> <em>Vehement,</em> or <em>intense, cold;</em> <span class="auth">(TA;)</span> <span class="add">[<em>as though unmixed with any degree of warmth;</em>]</span> syn. <span class="ar">صَادِقٌ</span>: <span class="auth">(Ḳ in art. <span class="ar">لحت</span>:)</span> the last word is an imitative sequent. <span class="auth">(TA in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0155.pdf" target="pdf">
							<span>Lanes Lexicon Page 155</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
