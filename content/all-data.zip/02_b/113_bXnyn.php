<article class="root" id="Root_bXnyn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/112_bXm">بشم</a></span>
				<span class="ar">بشنين</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/114_bS">بص</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baXoniynN">
				<h3 class="entry"><span class="ar">بَشْنِينٌ</span></h3>
				<div class="sense" id="baXoniynN_A1">
					<p><span class="ar">بَشْنِينٌ</span>, with fet-ḥ, and then sukoon, and then kesr, <em>I. q.</em> <span class="ar">نيلوفر</span> <span class="add">[i. e. <span class="ar">نِيلُوفَرٌ</span> and <span class="ar">نَيْلُوفَرٌ</span> or <span class="ar">نَيْلَوْفَرٌ</span>, the <em>nymphæa lotus,</em> or <em>white lotus:</em> and the <em>nymphæa cærulea,</em> or <em>blue lotus:</em> <a href="index.php?data=25_n/312_nylwfr">see art. <span class="ar">نيلوفر</span></a>]</span>: a word of the dial. of Egypt. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0209.pdf" target="pdf">
							<span>Lanes Lexicon Page 209</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
