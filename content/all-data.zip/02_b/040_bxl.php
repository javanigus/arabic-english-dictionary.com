<article class="root" id="Root_bxl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/039_bxq">بخق</a></span>
				<span class="ar">بخل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/041_bd">بد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخل</span></h3>
				<div class="sense" id="bxl_1_A1">
					<p><span class="ar">بَخِلَ</span>, <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَلُ</span>}</span></add>, inf. n. <span class="ar">بَخَلٌ</span>; <span class="auth">(JK, Mṣb, Ḳ;)</span> and <span class="ar">بَخُلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْخُلُ</span>}</span></add>, inf. n. <span class="ar">بُخْلٌ</span>; <span class="auth">(Mṣb, Ḳ;)</span> <em>He was,</em> or <em>became, niggardly, tenacious, stingy, penurious,</em> or <em>avaricious:</em> <a href="#buxolN">see <span class="ar">بُخْلٌ</span>, below</a>. <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar long">بَخِلَ بِكَذَا</span>, <span class="auth">(Ṣ, TA,)</span> and <span class="ar long">بَخُلَ بِهِ</span>, <em>He was,</em> or <em>became, niggardly,</em>, &amp;c., <em>of such a thing.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَخِلَ عَنْهُ</span> <span class="add">[<em>He withheld, with niggardliness, from him</em>]</span>: and <span class="ar long">بَخِلَ عَلَيْهِ</span> <span class="add">[<em>he was niggardly to him</em>]</span>. <span class="auth">(Bḍ and Jel in xlvii. last verse.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بخّل</span></h3>
				<div class="sense" id="bxl_2_A1">
					<p><span class="ar">بخّلهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَبْخِيلٌ</span>, <span class="auth">(Ḳ,)</span> <em>He attributed,</em> or <em>imputed, to him</em> <span class="ar">بُخْل</span> <span class="add">[or <em>niggardliness,</em>, &amp;c.]</span>: <span class="auth">(Ṣ:)</span> or <em>he accused him thereof:</em> <span class="auth">(Ḳ:)</span> or <em>he called him</em> <span class="ar">بَخِيل</span> <span class="add">[or <em>niggardly,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابخل</span></h3>
				<div class="sense" id="bxl_4_A1">
					<p><span class="ar">ابخلهُ</span> <em>He found him to be</em> <span class="ar">بَخِيل</span> <span class="add">[or <em>niggardly,</em>, &amp;c.]</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxolN">
				<h3 class="entry"><span class="ar">بَخْلٌ</span></h3>
				<div class="sense" id="baxolN_A1">
					<p><span class="ar">بَخْلٌ</span>: <a href="#buxolN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buxolN">
				<h3 class="entry"><span class="ar">بُخْلٌ</span></h3>
				<div class="sense" id="buxolN_A1">
					<p><span class="ar">بُخْلٌ</span> and<span class="arrow"><span class="ar">بَخَلٌ↓</span></span>, <span class="add">[both of which are properly inf. ns.,]</span> <span class="auth">(JK, Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَخْلٌ↓</span></span>, <span class="auth">(Ks, Ṣ, Mṣb, Ḳ,)</span> which is a simple subst., <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar">بُخُلٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">بَخِلٌ↓</span></span> and<span class="arrow"><span class="ar">بِخْلٌ↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">بُخُولٌ↓</span></span>, <span class="auth">(Ḳ,)</span> of all which, the first is that which commonly obtains, <span class="auth">(TA,)</span> are syn., <span class="auth">(JK, Ṣ,)</span> signifying <em>Niggardliness, tenaciousness, stinginess, penuriousness,</em> or <em>avarice;</em> <a href="#karamN">contr. of <span class="ar">كَرَمٌ</span></a> <span class="auth">(Ḳ, TA)</span> and <span class="ar">جُودٌ</span>; and its definition is the <em>withholding of acquired articles of property from that wherefrom it is not lawful to withhold them:</em> <span class="auth">(TA:)</span> or the <em>debarring the asker,</em> or <em>beggar, from what one has that is superabundant:</em> <span class="auth">(Mṣb:)</span> and in the law, the <em>refusal of what is incumbent,</em> or <em>obligatory.</em> <span class="auth">(Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bixolN">
				<h3 class="entry"><span class="ar">بِخْلٌ</span></h3>
				<div class="sense" id="bixolN_A1">
					<p><span class="ar">بِخْلٌ</span>: <a href="#buxolN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxalN">
				<h3 class="entry"><span class="ar">بَخَلٌ</span></h3>
				<div class="sense" id="baxalN_A1">
					<p><span class="ar">بَخَلٌ</span>: <a href="#buxolN">see <span class="ar">بُخْلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخل</span> - Entry: <span class="ar">بَخَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baxalN_A2">
					<p><a href="#baxiylN">and see also <span class="ar">بَخِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxilN">
				<h3 class="entry"><span class="ar">بَخِلٌ</span></h3>
				<div class="sense" id="baxilN_A1">
					<p><span class="ar">بَخِلٌ</span>: <a href="#buxolN">see <span class="ar">بُخْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buxulN">
				<h3 class="entry"><span class="ar">بُخُلٌ</span></h3>
				<div class="sense" id="buxulN_A1">
					<p><span class="ar">بُخُلٌ</span>: <a href="#buxolN">see <span class="ar">بُخْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxolapN">
				<h3 class="entry"><span class="ar">بَخْلَةٌ</span></h3>
				<div class="sense" id="baxolapN_A1">
					<p><span class="ar">بَخْلَةٌ</span> <em>A single act,</em> or <em>instance, of</em> <span class="ar">بُخْل</span> <span class="add">[or <em>niggardliness</em>, &amp;c.]</span>. <span class="auth">(JK, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxaAlN">
				<h3 class="entry"><span class="ar">بَخَالٌ</span></h3>
				<div class="sense" id="baxaAlN_A1">
					<p><span class="ar">بَخَالٌ</span>: <a href="#baxiylN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxiylN">
				<h3 class="entry"><span class="ar">بَخِيلٌ</span></h3>
				<div class="sense" id="baxiylN_A1">
					<p><span class="ar">بَخِيلٌ</span> <span class="auth">(JK, Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَاخِلٌ↓</span></span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>Niggardly, tenacious, stingy, penurious,</em> or <em>avaricious;</em> <span class="auth">(Ḳ;)</span> i. e. <span class="ar long">ذُو بُخْلٍ</span>; <span class="auth">(Mṣb;)</span> epithets from 1: <span class="auth">(Ṣ, Mṣb:*)</span> or one <em>from whom niggardliness is experienced much</em> or <em>often:</em> <span class="auth">(TA: <span class="add">[appin explanation of the former:]</span>)</span> and so<span class="arrow"><span class="ar">بَخَلٌ↓</span></span>, in inf. n. used as an epithet <span class="add">[and therefore implying more than the possession of the simple attribute of niggardliness, &amp;c., being a kind of personification]</span>; <span class="auth">(Abu-l-ʼOmeythil El-Aạrábee, Ḳ;)</span> and<span class="arrow"><span class="ar">بَخَّالٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بَخَالٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">مُبَخَّلٌ↓</span></span> <span class="auth">(JK, Ḳ)</span> i. e. <span class="ar long">شَدِيدُ البُخْلِ</span> <span class="add">[<em>very,</em> or <em>vehemently, niggardly</em>, &amp;c.]</span>: <span class="auth">(Ṣ, TA:)</span> pl. of the first, <span class="ar">بُخَلَآءُ</span>; <span class="auth">(Mṣb, Ḳ;)</span> and of the second, <span class="ar">بُخَّلٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بُخَّالٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buxuwlN">
				<h3 class="entry"><span class="ar">بُخُولٌ</span></h3>
				<div class="sense" id="buxuwlN_A1">
					<p><span class="ar">بُخُولٌ</span>: <a href="#buxolN">see <span class="ar">بُخْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxBaAlN">
				<h3 class="entry"><span class="ar">بَخَّالٌ</span></h3>
				<div class="sense" id="baxBaAlN_A1">
					<p><span class="ar">بَخَّالٌ</span>: <a href="#baxiylN">see <span class="ar">بَخِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAxilN">
				<h3 class="entry"><span class="ar">بَاخِلٌ</span></h3>
				<div class="sense" id="baAxilN_A1">
					<p><span class="ar">بَاخِلٌ</span>: <a href="#baxiylN">see <span class="ar">بَخِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboxalapN">
				<h3 class="entry"><span class="ar">مَبْخَلَةٌ</span></h3>
				<div class="sense" id="maboxalapN_A1">
					<p><span class="ar">مَبْخَلَةٌ</span> <em>A cause of,</em> or <em>a thing that incites to,</em> <span class="ar">بُخْل</span> <span class="add">[or <em>niggardliness</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> a word of the same class as <span class="ar">مَجْبَنَةٌ</span> and <span class="ar">مَهْلَكَةٌ</span> and <span class="ar">مَعْطَشَةٌ</span> and <span class="ar">مَفَازَةٌ</span>, &amp;c. <span class="auth">(TA.)</span> So explained as occurring in the trad., <span class="auth">(TA,)</span> <span class="ar long">الوَلَدُ مَبْخَلَةٌ مَجْبَنَةٌ</span> <span class="add">[<em>Children are a cause of niggardliness</em> and <em>a cause of cowardice</em>]</span>; <span class="auth">(Ṣ, TA;)</span> because on account of them one loves property, and continuance of life. <span class="auth">(Ṣ in art. <span class="ar">جبن</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubaxBalN">
				<h3 class="entry"><span class="ar">مُبَخَّلٌ</span></h3>
				<div class="sense" id="mubaxBalN_A1">
					<p><span class="ar">مُبَخَّلٌ</span>: <a href="#baxiylN">see <span class="ar">بَخِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0160.pdf" target="pdf">
							<span>Lanes Lexicon Page 160</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
