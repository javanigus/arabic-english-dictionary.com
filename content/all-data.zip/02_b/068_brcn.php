<article class="root" id="Root_brcn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/067_brcE">برذع</a></span>
				<span class="ar">برذن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/069_brz">برز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brcn_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برذن</span></h3>
				<div class="sense" id="brcn_Q1_A1">
					<p><span class="ar">بَرْذَنَ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بَرْذَنَةٌ</span>, <span class="auth">(T,)</span> <em>He</em> <span class="auth">(a horse)</span> <em>went in the manner of the</em> <span class="ar">بِرْذَوْن</span>, q. v. <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برذن</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brcn_Q1_A2">
					<p><em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, heavy,</em> or <em>sluggish:</em> whence IDrd thinks <span class="ar">بِرْذَوْنٌ</span> to be derived: <span class="auth">(M, Mṣb:*)</span> but this opinion is of no account. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برذن</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brcn_Q1_A3">
					<p><em>He was unable to reply,</em> <span class="auth">(T, Ḳ,)</span> when asked respecting a thing. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برذن</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brcn_Q1_A4">
					<p><em>He subdued, overpowered,</em> or <em>overcame:</em> <span class="auth">(Ḳ: <span class="add">[expl. by <span class="ar">قَهَرَ</span> and <span class="ar">غَلَبَ</span>; but I think that the right reading may be <span class="ar">قُهِرَ</span> and <span class="ar">غُلِبَ</span>, meaning <em>he was,</em> or <em>became, subdued,</em>, &amp;c.:]</span>)</span> said of a man. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="birocawonN">
				<h3 class="entry"><span class="ar">بِرْذَوْنٌ</span> / <span class="ar">بِرْذَوْنَةٌ</span></h3>
				<div class="sense" id="birocawonN_A1">
					<p><span class="ar">بِرْذَوْنٌ</span> <span class="add">[<em>A horse of mean breed,</em> or <em>of coarse make; a jade:</em> but commonly applied to <em>a hack,</em> or <em>hackney; a horse for ordinary use,</em> and <em>for journeying</em>:]</span> <em>a</em> <span class="ar">دَابَّة</span>, <span class="auth">(Ṣ, Ḳ,)</span> not in an absolute sense, but <em>of a particular sort,</em> namely, <span class="auth">(MF,)</span> <em>a horse that is not of Arabian breed:</em> <span class="auth">(T, MF:)</span> or <em>a heavy,</em> or <em>sluggish,</em> <span class="ar">دابّة</span>: <span class="auth">(so in a copy of the Ṣ:)</span> or <em>a coarse horse:</em> <span class="auth">(Towsheeh, TA:)</span> or <em>a horse of coarse make, hardy so as to endure travel upon the mountain-roads and rugged ground, not of Arabian breed, mostly brought from Er-Room</em> <span class="add">[meaning <em>Asia Minor</em> or <em>Greece</em>]</span>: <span class="auth">(TA, from the Expos. of the 'Irákeeyeh of Es-Sakháwee:)</span> or <em>a horse of large and coarse make, with thick limbs;</em> whereas those of Arabian breed are light of flesh, lank in the belly, and more slender in the limbs: <span class="auth">(El-Bájee, TA:)</span> or <em>a Turkish horse; opposed to Arabian:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>a pacinghorse;</em> syn. <span class="ar">رَهَوَانٌ</span>: <span class="auth">(TA voce <span class="ar">هِمْلَاجٌ</span>:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بِرْذَوْنَةٌ</span>}</span></add>; <span class="auth">(Ks, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> sometimes; but without <span class="ar">ة</span> it is applied to the female as well as the male: <span class="auth">(IAmb, Mṣb:)</span> pl. <span class="ar">بَرَاذِينٌ</span> <span class="auth">(T, Ṣ, Mgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubarocinN">
				<h3 class="entry"><span class="ar">مُبَرْذِنٌ</span></h3>
				<div class="sense" id="mubarocinN_A1">
					<p><span class="ar">مُبَرْذِنٌ</span> <em>An owner of a</em> <span class="ar">بِرْذَوْن</span>: <span class="auth">(Ḳ:)</span> or <em>a rider thereon.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0186.pdf" target="pdf">
							<span>Lanes Lexicon Page 186</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
