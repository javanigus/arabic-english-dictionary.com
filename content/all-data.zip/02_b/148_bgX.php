<article class="root" id="Root_bgX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/147_bgv">بغث</a></span>
				<span class="ar">بغش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/149_bgD">بغض</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgX_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغش</span></h3>
				<div class="sense" id="bgX_1_A1">
					<p><span class="ar long">بَغَشَتِ السَّمَآءُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَشُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">بَغْشٌ</span>, <span class="auth">(Ṣ,)</span> <em>The sky rained a rain such as is termed</em> <span class="ar">بَغْشَةٌ</span>, q. v. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bgX_1_A2">
					<p><span class="ar long">بُغِشَتُ الأَرْضُ</span> <em>The land was watered by a rain such as is termed</em> <span class="ar">بَغْشَةٌ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَغْشٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bagoXN">
				<h3 class="entry"><span class="ar">بَغْشٌ</span></h3>
				<div class="sense" id="bagoXN_A1">
					<p><span class="ar">بَغْشٌ</span>: <a href="#bagoXapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagoXapN">
				<h3 class="entry"><span class="ar">بَغْشَةٌ</span></h3>
				<div class="sense" id="bagoXapN_A1">
					<p><span class="ar">بَغْشَةٌ</span> <em>A weak shower of rain;</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>above what is called</em> <span class="ar">طَشَّة</span>: <span class="auth">(Ṣ:)</span> or <em>weak rain, small in its drops;</em> as also<span class="arrow"><span class="ar">بَغْشٌ↓</span></span> <span class="add">[originally an inf. n.]</span>: or both signify <em>a cloud that pours forth its rain in one shower:</em> Aṣ says that the lightest and weakest of rain is that called <span class="ar">طَلّ</span>; then, the <span class="ar">رَذَاذ</span>; then, the <span class="ar">بَغْش</span>: the dim. of the last is <span class="ar">بُغَيْشٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAgiXN">
				<h3 class="entry"><span class="ar">بَاغِشٌ</span></h3>
				<div class="sense" id="baAgiXN_A1">
					<p><span class="ar long">مَطَرٌ بَاغِشٌ</span> <em>Weak rain.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboguwXapN">
				<h3 class="entry"><span class="ar">مَبْغُوشَةٌ</span></h3>
				<div class="sense" id="maboguwXapN_A1">
					<p><span class="ar long">أَرْضٌ مَبْغُوشَةٌ</span> <em>Land watered by a rain such as is termed</em> <span class="ar">بَغْشَةٌ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَغْشٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0229.pdf" target="pdf">
							<span>Lanes Lexicon Page 229</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
