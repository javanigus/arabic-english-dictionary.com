<article class="root" id="Root_bjs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/024_bjr">بجر</a></span>
				<span class="ar">بجس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/026_bjl">بجل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bjs_1">
				<h3 class="entry">1. ⇒ <span class="ar">بجس</span></h3>
				<div class="sense" id="bjs_1_A1">
					<p><span class="ar long">بَجَسَ المَآءَ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْجُسُ</span>}</span></add> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْجِسُ</span>}</span></add>, <span class="auth">(A, Ḳ,)</span> inf. n. <span class="ar">بَجْسٌ</span>, <span class="auth">(Mṣb, TA,)</span> <em>He opened a way, passage, vent,</em> or <em>channel, for the water to flow forth; gave vent to it; made it to flow;</em> syn. <span class="ar">فَجَرَهُ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">فَتَحَهُ</span>, <span class="auth">(Mṣb,)</span> or <span class="ar">شَقَّهُ</span>: <span class="auth">(A, Ḳ:)</span> <span class="add">[all of which, in this case, signify the same:]</span> and in like manner one says of a wound; <span class="auth">(A, Ḳ;)</span> but in this case, the phrase is tropical: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">بجّس↓ الَمآءِ</span></span>, inf. n. <span class="ar">تَبْجِيسٌ</span>, <em>He</em> <span class="auth">(namely, God, TA)</span> <em>made the water to flow forth,</em> or <em>to flow forth copiously,</em> syn. <span class="ar">فَجَّرَهُ</span>, <span class="auth">(Ḳ, TA,)</span> from the cloud or clouds, and from the spring. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بجس</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bjs_1_B1">
					<p><a href="#bjs_7">See also 7</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bjs_2">
				<h3 class="entry">2. ⇒ <span class="ar">بجّس</span></h3>
				<div class="sense" id="bjs_2_A1">
					<p><a href="#bjs_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bjs_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبجّس</span></h3>
				<div class="sense" id="bjs_5_A1">
					<p><a href="#bjs_7">see 7</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bjs_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبجس</span></h3>
				<div class="sense" id="bjs_7_A1">
					<p><span class="ar">انبجس</span> <em>It</em> <span class="auth">(water)</span> <em>had a way, passage, vent,</em> or <em>channel, opened for it to flow forth; it had vent; it poured forth;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> <span class="add">[<em>it burst forth;</em>]</span> from a cloud or clouds, and from a spring; <span class="auth">(A;)</span> and from a rock; <span class="auth">(Ḳur vii. 160;)</span> as also<span class="arrow"><span class="ar">بَجَسَ↓</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْجُسُ</span>}</span></add>; <span class="auth">(Ṣ, TA;)</span> and<span class="arrow"><span class="ar">تبجّس↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> syn. of the first, <span class="auth">(Ṣ, A, Ḳ,* TA,)</span> and last, <span class="auth">(Ṣ,)</span> <span class="ar">اِنْفَجَرَ</span>: <span class="auth">(Ṣ, A, TA:)</span> or of the last, <span class="ar">تَفَجَّرَ</span> <span class="add">[properly signifying <em>it poured forth copiously</em>]</span>: <span class="auth">(A, TA:)</span> <span class="ar">اِنْبِجَاسٌ</span> signifies particularly the <em>welling forth</em> <span class="add">[of water]</span> <em>from a spring:</em> or it has a general application: <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar">بَجْسٌ↓</span></span> signifies <em>cracking</em> in a water-skin, or stone, or earth, <em>so that water issues</em> from it. <span class="auth">(TA.)</span> You say, <span class="ar long">السَّحَابُ يَنْبَجِسُ بِالمَطَرِ</span> <span class="add">[<em>The clouds pour with rain</em>]</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">أَتَانَا بِثَرِيدٍ يَتَبَجَّسُ↓</span></span>, <span class="auth">(A,)</span> or<span class="arrow"><span class="ar long">يَتَبَجَّسُ↓ أُدْمًا</span></span>, <span class="auth">(TA,)</span> <span class="add">[<em>He brought us crumbled bread moistened with broth, which streamed with seasoning,</em>]</span> meaning, by reason of the abundance of grease <span class="add">[in it]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajosN">
				<h3 class="entry"><span class="ar">بَجْسٌ</span></h3>
				<div class="sense" id="bajosN_A1">
					<p><span class="ar long">مَآءٌ بَجْسٌ</span> <em>Water having a way, passage, vent,</em> or <em>channel, opened for it to flow forth; having a vent;</em> or <em>pouring forth:</em> <span class="auth">(Ḳ:)</span> and in like manner, <span class="ar long">سَحَابٌ بَجْسٌ</span> <span class="add">[<em>clouds pouring forth rain</em>]</span>; <span class="auth">(TA;)</span> and <span class="add">[so]</span> <span class="ar long">سَحَائِبُ بُجَّسٌ</span> <span class="add">[pl. of <span class="arrow"><span class="ar">بَاجِسٌ↓</span></span> and <span class="ar">بَاجِسَةٌ</span>]</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar long">مَآءٌ بَجِيسٌ↓</span></span> <em>flowing water:</em> <span class="auth">(Kr, TA:)</span> and<span class="arrow"><span class="ar long">عَيْنٌ بَجِيسٌ↓</span></span> <em>a copious spring.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bajysN">
				<h3 class="entry"><span class="ar">بَجيسٌ</span></h3>
				<div class="sense" id="bajysN_A1">
					<p><span class="ar">بَجيسٌ</span>: <a href="#bajosN">see <span class="ar">بَجْسٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAjisN">
				<h3 class="entry"><span class="ar">بَاجِسٌ</span> / <span class="ar">بُجَّسٌ</span></h3>
				<div class="sense" id="baAjisN_A1">
					<p><span class="ar">بَاجِسٌ</span>; pl. <span class="ar">بُجَّسٌ</span>: <a href="#bajosN">see <span class="ar">بَجْسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0153.pdf" target="pdf">
							<span>Lanes Lexicon Page 153</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
