<article class="root" id="Root_bz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/089_bre">برى</a></span>
				<span class="ar">بز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/091_bzx">بزخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bz_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزّ</span></h3>
				<div class="sense" id="bz_1_A1">
					<p><span class="ar">بَزَّهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُزُ</span>}</span></add>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">بَزٌّ</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>He took it away;</em> or <em>seized it,</em> or <em>carried it away, by force;</em> <span class="auth">(Ṣ, TA;)</span> as also<span class="arrow"><span class="ar">ابتزّهُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَزْبَزَهُ↓</span></span>: <span class="auth">(Ḳ:)</span> <em>he took it away unjustly, injuriously, and forcibly;</em> as also<span class="arrow"><span class="ar">ابتزّهُ↓</span></span>: <span class="auth">(Ḳ,* TA:)</span> <em>he gained the mastery over it:</em> <span class="auth">(Ḳ,* TA:)</span> <em>he pulled it up</em> or <em>out</em> or <em>off; removed it from its place; displaced it;</em> <span class="auth">(Ḳ,* TA;)</span> as also<span class="arrow"><span class="ar">ابتزّهُ↓</span></span>, and<span class="arrow"><span class="ar">بَزْبَزَهُ↓</span></span>. <span class="auth">(TA.)</span> It is said in a prov., <span class="ar long">مَنْ عَزَّ بَزَّ</span> <em>He who overcomes takes the spoil.</em> <span class="auth">(Ṣ, A.)</span> And you say, <span class="ar long">بَزَّهُ ثَوْبَهُ</span>, and<span class="arrow"><span class="ar">ابتزّهُ↓</span></span>, <em>He took away from him,</em> or <em>seized</em> or <em>carried away from him by force, his garment.</em> <span class="auth">(A.)</span> It is said in a trad.,<span class="arrow"><span class="ar long">فَيَبْتَزُّ↓ ثِيَابِى وَمَتَاعِى</span></span> <em>And he strips me,</em> or <em>despoils me, of my clothes and my goods; takes them from me by superior force.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">بَزَّهُ ثِيَابَهُ</span> <em>He pulled off from him his clothes.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">ابتزّ↓ الرَّجُلُ جَارِيَتَهُ مشنْ ثِيَابِهَا</span></span> <em>The man stripped his slave-girl of her clothes.</em> <span class="auth">(Mgh,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بز</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bz_1_A2">
					<p>Also <span class="ar">بَزَّثَوْبَهُ</span>, aor. as above, <em>He pulled his garment towards him,</em> or <em>to him:</em> so in a verse of Khálid Ibn-Zuheyr El-Hudhalee <span class="add">[<a href="index.php?data=10_r/244_ryb">cited in art. <span class="ar">ريب</span></a>, but with this difference, that <span class="ar">يَجُرُّ</span> is there put in the place of <span class="ar">يَبُزُّ</span>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بز</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bz_1_A3">
					<p><span class="add">[<span class="ar">بَزَّهُ</span> is also explained in the TA by <span class="ar">حَبَسَهُ</span>; but without any ex.; and I think it probable that <span class="ar">حَبَسَهُ</span> is a mistake for <span class="ar">جَذَبَهُ</span>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bz_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتزّ</span></h3>
				<div class="sense" id="bz_8_A1">
					<p><a href="#bz_1">see 1</a>, in six places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بز</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bz_8_B1">
					<p><span class="ar long">ابتزّت مِنْ ثِيَابِهَا</span> <em>She stripped herself of her clothes.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bz_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بزبز</span></h3>
				<div class="sense" id="bz_RQ1_A1">
					<p><span class="ar">بَزْبَزَهُ</span>: <a href="#bz_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بز</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bz_RQ1_A2">
					<p><span class="ar">بَزْبَزَةٌ</span> <span class="add">[the inf. n.]</span> also signifies The <em>being quick and active in wrongful, unjust, injurious,</em> or <em>tyrannical, conduct:</em> and the rel. n. is <span class="arrow"><span class="ar">بَزْبَزِىٌّ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bazBN">
				<h3 class="entry"><span class="ar">بَزٌّ</span></h3>
				<div class="sense" id="bazBN_A1">
					<p><span class="ar">بَزٌّ</span> <a href="#bz_1">inf. n. of 1</a>. <span class="auth">(Ṣ, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بز</span> - Entry: <span class="ar">بَزٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bazBN_A2">
					<p><span class="add">[Hence, app.,]</span> <span class="ar long">جِىْءَ بِهِ عَزَّا بَزًّا</span> <em>He was brought without any means of avoiding it;</em> <span class="auth">(A, TA;)</span> <em>willingly</em> or <em>against his will:</em> <span class="auth">(TA in art. <span class="ar">عز</span>:)</span> <span class="add">[as though originally signifying <em>by being overcome and despoiled.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بز</span> - Entry: <span class="ar">بَزٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bazBN_B1">
					<p><em>Cloths,</em> or <em>stuffs,</em> or <em>garments;</em> syn. <span class="ar">ثِيَاب</span>: <span class="auth">(IAmb, Mgh, Ḳ:)</span> <span class="add">[<a href="#bizBapN">see also <span class="ar">بِزَّةٌ</span></a>:]</span> or <em>a kind thereof:</em> <span class="auth">(Lth, Mgh, Mṣb:)</span> or <em>such as are the goods of the</em> <span class="ar">بَزَّاز</span>, <span class="auth">(Ṣ, A,)</span> or <em>of the merchant:</em> <span class="auth">(Mṣb:)</span> or the <em>furniture of a house or tent, consisting of cloths</em> or <em>stuffs</em> (<span class="ar">ثِيَاب</span>, IDrd, Mgh, Mṣb, Ḳ) <em>and the like:</em> <span class="auth">(Ḳ:)</span> in the dial. of the people of El-Koofeh, <em>cloths,</em> or <em>stuffs,</em> or <em>garments,</em> (<span class="ar">ثياب</span>,) <em>of linen</em> and <em>of cotton; not of wool nor of</em> <span class="ar">خَزّ</span>: <span class="auth">(Mgh:)</span> pl. <span class="ar">بُزُوزٌ</span>; <span class="auth">(A;)</span> meaning, in conjunction with <span class="ar">خُزُوزٌ</span>, <span class="auth">(i. e., <span class="ar long">خُزُوزٌ وَبُزُوزٌ</span>,)</span> <em>good cloths</em> or <em>stuffs</em> or <em>garments.</em> <span class="auth">(A.)</span> <span class="add">[Golius explains it as “Chald. <span class="he">בוּץ</span>, <em>Byssus,</em> seu potius <em>pannus lineus, bombacinus,</em> etiam <em>sericus:</em>” as on the authority of the Ṣ and Ḳ <span class="auth">(though he omits the explanations in both those lexicons)</span> and Meyd and Ibn-Maạroof <span class="auth">(who explains it only by the Persian word <span class="ar">جَامَهْ</span>, meaning <em>cotton</em> or <em>linen cloth,</em> or <em>a garment,</em>)</span> and the Mirḳát el-Loghah. He seems to have judged from its resemblance in sound to the Chaldee and Latin words with which he identifies it. The things which it signifies, however, may perhaps be so called because they are usual spoils: and hence also, perhaps, the application here next following.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بز</span> - Entry: <span class="ar">بَزٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bazBN_C1">
					<p><em>Weapons,</em> or <em>arms;</em> or <em>a weapon;</em> syn. <span class="ar">سِلَاحٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بِزَّةٌ↓</span></span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بَزَزٌ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بِزِّيزَى↓</span></span>: <span class="auth">(TA:)</span> the first of these four words including in its application <em>coats of mail and the</em> <span class="ar">مِغْفَر</span> <em>and the sword:</em> <span class="auth">(TA:)</span> or it signifies <em>a sword:</em> <span class="auth">(IDrd, A, TA:)</span> and<span class="arrow"><span class="ar">بَزَزٌ↓</span></span>, accord. to AA, <em>complete arms.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">تَقَلَّدَ بَزَّا حَسَنًا</span> <em>He hung upon himself a goodly sword, putting its suspensory belt or cord upon his neck.</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">غَزَا فِى بِزَّةٍ↓ كَامِلَةٍ</span></span> <em>He went to war in complete arms.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bizBapN">
				<h3 class="entry"><span class="ar">بِزَّةٌ</span></h3>
				<div class="sense" id="bizBapN_A1">
					<p><span class="ar">بِزَّةٌ</span> <em>Constraint,</em> or <em>force:</em> as in the saying, <span class="ar long">لَنْ يَأْخُذَهُ أَبَدًا بِزَّةً مِنِّى</span> <em>He will never take it by constraint,</em> or <em>force, from me.</em> <span class="auth">(Ks, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بز</span> - Entry: <span class="ar">بِزَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bizBapN_B1">
					<p><em>Outward appearance; state with regard to apparel and the like;</em> syn. <span class="ar">هَيْئَةٌ</span>, <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ, TA,)</span> and <span class="ar">شَارَةٌ</span>: <span class="auth">(TA:)</span> <em>garb; mode, manner,</em> or <em>fashion, of dress:</em> <span class="auth">(TA:)</span> <em>apparel.</em> <span class="auth">(A, Mgh.)</span> You say, <span class="ar long">رَجُلٌ حَسَنُ البِزَّةِ</span> <em>A man of goodly outward appearance,</em> or <em>state of apparel and the like:</em> <span class="auth">(Mgh, Mṣb:)</span> or as some say, <em>clothes and arms.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">إِنَّهُ لَذُو بِزَّةٍ حَسَنَةٍ</span> <em>Verily he has a goodly outward appearance and dress.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بز</span> - Entry: <span class="ar">بِزَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bizBapN_C1">
					<p><a href="#bazBN">See also <span class="ar">بَزٌّ</span></a>, latter part, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bazazN">
				<h3 class="entry"><span class="ar">بَزَزٌ</span></h3>
				<div class="sense" id="bazazN_A1">
					<p><span class="ar">بَزَزٌ</span>: <a href="#bazBN">see <span class="ar">بَزٌّ</span></a>, latter part, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bizaAzapN">
				<h3 class="entry"><span class="ar">بِزَازَةٌ</span></h3>
				<div class="sense" id="bizaAzapN_A1">
					<p><span class="ar">بِزَازَةٌ</span> The <em>trade of the</em> <span class="ar">بَزَّاز</span>. <span class="auth">(Mgh, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bizaAzapN.1">
				<h3 class="entry"><span class="ar">بِزَازَةٌ</span></h3>
				<div class="sense" id="bizaAzapN.1_A1">
					<p><span class="ar">بِزَازَةٌ</span> The <em>seller of the cloths or stuffs or the like called</em> <span class="ar">بَزّ</span>. <span class="auth">(Ṣ,* A,* Mgh,* Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bizBiyzae">
				<span class="pb" id="Page_0199"></span>
				<h3 class="entry"><span class="ar">بِزِّيزَى</span></h3>
				<div class="sense" id="bizBiyzae_A1">
					<p><span class="ar">بِزِّيزَى</span> a subst. from <span class="ar">بَزَّ</span> in the first of the senses explained above; The <em>act of taking away;</em> or <em>spoliation;</em> or the <em>act of seizing,</em> or <em>carrying away, by force:</em> <span class="auth">(Ṣ, TA:)</span> the <em>act of taking,</em> or <em>obtaining, by superior power or force.</em> <span class="auth">(Ḳ,* TA.)</span> It is said in a trad., <span class="ar long">ثُمَّ يَكُونُ بِزِّيزَى وَأَخْذَ أَمْوَالٍ بِغَيْرِ حَقٍّ</span> <em>Then it shall be by spoliation, and the taking of possessions without right:</em> or, as some relate this trad., <span class="arrow"><span class="ar">بَزْبَزِيًّا↓</span></span>; but accord. to Az, this is naught. <span class="auth">(TA.)</span> You say also, <span class="ar long">رَجَعَتِ الخلَافَةُ بِزِّيزَى</span> <span class="add">[<em>The office of Khaleefeh became reduced to be a thing taken by superior power</em> or <em>force</em>]</span>; <em>was not taken by desert.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بز</span> - Entry: <span class="ar">بِزِّيزَى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bizBiyzae_B1">
					<p><a href="#bazBN">See also <span class="ar">بَزٌّ</span></a>, latter part.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bazobazieBN">
				<h3 class="entry"><span class="ar">بَزْبَزِىٌّ</span></h3>
				<div class="sense" id="bazobazieBN_A1">
					<p><span class="ar">بَزْبَزِىٌّ</span>: <a href="#bz_RQ1">see R. Q. 1</a>, <a href="#bizBiyzae">and <span class="ar">بِزِّيزَى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0198.pdf" target="pdf">
							<span>Lanes Lexicon Page 198</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0199.pdf" target="pdf">
							<span>Lanes Lexicon Page 199</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
