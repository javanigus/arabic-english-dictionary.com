<article class="root" id="Root_bndq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/191_bndr">بندر</a></span>
				<span class="ar">بندق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/193_bnSr">بنصر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bndq_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">بندق</span></h3>
				<div class="sense" id="bndq_Q1_A1">
					<p><span class="ar">بَنْدَقَ</span> <em>He made</em> a thing <em>into</em> <span class="ar">بَنَادِق</span> <span class="add">[meaning <em>bullets,</em> or <em>little balls</em>]</span>, <span class="auth">(Mgh, Ḳ,)</span> or <em>like</em> <span class="ar">بنادق</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بندق</span> - Entry: Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bndq_Q1_B1">
					<p><span class="add">[In post-classical Arabic, <em>He shot a bullet,</em> or <em>bullets,</em> from a cross-bow or other weapon.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بندق</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bndq_Q1_B2">
					<p><span class="ar long">بندق إِلَيْهِ</span> † <em>He looked sharply,</em> or <em>intently, at him,</em> or <em>it.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunoduqN">
				<h3 class="entry"><span class="ar">بُنْدُقٌ</span> / <span class="ar">بُنْدُقَةٌ</span></h3>
				<div class="sense" id="bunoduqN_A1">
					<p><span class="ar">بُنْدُقٌ</span> <span class="add">[The <em>hazel-nut;</em> or <em>hazel-nuts;</em> so in the present day;]</span> <em>a certain thing that is eaten;</em> <span class="auth">(Mṣb;)</span> <em>i. q.</em> <span class="ar">جِلَّوْز</span>: <span class="auth">(IDrd, Ḳ:)</span> or, as some say, <em>like</em> <span class="ar">جلّوز</span>; <em>brought from an island; the best whereof is the fresh, heavy, white, and sweet in taste; the old being bad: it is beneficial as a remedy for palpitation, parched with anise-seed; and for poisons, and wasting of the kidneys, and burning of the urine; and with pepper, it excites the venereal faculty; with sugar, it removes cough; and the shell thereof, burnt, and applied as a collyrium, sharpens the sight:</em> <span class="auth">(TA:)</span> <em>they assert that the suspending it upon the upper arm preserves from scorpions,</em> <span class="auth">(Ḳ,)</span> i. e., <em>from their stinging:</em> <span class="auth">(TA:)</span> <em>the moistening of the top of the head of a child with the powder of it when burnt, together with oil, removes the blueness of its eyes and the redness of its hair: and the Indian kind thereof is an antidote very beneficial to the eyes:</em> <span class="auth">(Ḳ, TA:)</span> but in some copies of the Ḳ, <span class="add">[and so in the CK,]</span> instead of <span class="ar">لِلْعَيْنَيْنِ</span>, we here find <span class="ar">لِلْعِنِّينِ</span> <span class="add">[<em>for the impotent in respect of the venereal faculty</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[it is said in the Mṣb that most hold the <span class="ar">ن</span> to be augmentative: but this is not the case; for]</span> the word is Persian <span class="add">[arabicized, from <span class="ar">فُنْدُقْ</span>]</span>: <span class="auth">(Ḳ:)</span> <span class="add">[it is a coll. gen. n.:]</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُنْدُقَةٌ</span>}</span></add>: pl. <span class="ar">بَنَادِقُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بندق</span> - Entry: <span class="ar">بُنْدُقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bunoduqN_A2">
					<p><span class="add">[Hence, <em>Bullets,</em> i. e.]</span> <em>certain things that one shoots,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>made of clay:</em> <span class="auth">(Mṣb:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُنْدُقَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> the latter signifies <em>a piece of clay, made round, which one shoots,</em> or <em>casts;</em> or <em>i. q.</em> <span class="ar">جُلَاهِقٌ</span>: <span class="auth">(Mgh:)</span> it is said in the Shifá el-Ghaleel to be an arabicized word: <span class="auth">(TA:)</span> pl. as above. <span class="auth">(Ṣ, Mṣb.)</span> <span class="add">[See a prov. voce <span class="ar">حِدَأَةٌ</span>. Hence <span class="ar long">قَوْسُ البُنْدُقِ</span> <em>The crossbow.</em> In modern Arabic, <span class="ar">بُنْدُق</span> is also applied to <em>Balls of any kind of the size of hazel-nuts:</em> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بُنْدُقَةٌ</span>}</span></add>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunoduqieBN">
				<h3 class="entry"><span class="ar">بُنْدُقِىٌّ</span></h3>
				<div class="sense" id="bunoduqieBN_A1">
					<p><span class="ar">بُنْدُقِىٌّ</span> <em>A garment,</em> or <em>piece of cloth, of fine, delicate,</em> or <em>thin, linen.</em> <span class="auth">(Ṣgh, Ḳ.)</span> <span class="add">[SM says,]</span> It is most probably, in my opinion, so called in relation to the l<a href="#AlbunoduqiyBap">and of <span class="ar">البُنْدُقِيَّة</span></a> <span class="add">[or Venice]</span>. <span class="auth">(TA.)</span> <span class="add">[In modern Arabic, <em>A Venetian sequin:</em> pl. <span class="ar">بَنَادِقَةٌ</span>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunodaqaAnieBN">
				<h3 class="entry"><span class="ar">بُنْدَقَانِىٌّ</span></h3>
				<div class="sense" id="bunodaqaAnieBN_A1">
					<p><span class="ar">بُنْدَقَانِىٌّ</span> <span class="add">[app. a post-classical word,]</span> <em>A maker of cross-bows</em> (<span class="ar long">قِسِىّ البُنْدُق</span>). <span class="auth">(El-Makreezee's Khitat, art. <span class="ar long">خطّ البندقانيّين</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
