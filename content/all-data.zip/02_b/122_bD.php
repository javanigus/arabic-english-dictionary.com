<article class="root" id="Root_bD">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/121_bSn">بصن</a></span>
				<span class="ar">بض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/123_bDE">بضع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bD_1">
				<h3 class="entry">1. ⇒ <span class="ar">بضّ</span></h3>
				<div class="sense" id="bD_1_A1">
					<p><span class="ar">بَضَضْتَ</span>, and <span class="ar">بَضِضْتَ</span>, <span class="auth">(Ṣ, TA,)</span> and <span class="ar">بَضُضْتَ</span> also, <span class="auth">(accord. to one copy of the Ṣ,)</span> <span class="add">[third pers., accord. to rule, <span class="ar">بَضَّ</span>, <span class="auth">(accord. to Golius and Freytag <span class="ar">بَضَضَ</span> or <span class="ar">بَضِضَ</span>, but these are irregular forms, and not admissible without authority,)</span> aor., accord. to rule, of the first <span class="ar">يَبِضُّ</span>, and of the second <span class="ar">يَبَضُّ</span>, and of the third <span class="ar">يَبُضُّ</span>,]</span> inf. n. <span class="ar">بَضَاضَةٌ</span> and <span class="ar">بُضَوضَةٌ</span>, <span class="auth">(Ṣ, TA,)</span> <em>Thou</em> <span class="auth">(O man)</span> <em>wast,</em> or <em>becamest, such as is termed</em> <span class="ar">بَضٌّ</span>; i. e. <em>thin-shinned and plump;</em>, &amp;c.: <span class="auth">(Ṣ:)</span> or <em>very white</em> or <em>fair, with fatness:</em> or <em>delicate and clear in complexion, and such that the least thing made a mark,</em> or <em>an impression, upon thee.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bD_1_B1">
					<p><span class="ar long">بَضَّ المَآءُ</span>, aor. <span class="ar">يَبِضُّ</span>, inf. n. <span class="ar">بَضِيضٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بُضُوضٌ</span> and <span class="ar">بَضٌّ</span>, <span class="auth">(Ḳ,)</span> <em>The water flowed by little and little:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>exuded</em> upon a rock or the ground. <span class="auth">(TA.)</span> And <span class="ar long">بَضَّتِ الرَّكِيَّةُ</span>, and <span class="ar long">بَضَّتْ بِمَائِهَا</span>, <em>The well had,</em> or <em>yielded, little water;</em> or <em>its water became little.</em> <span class="auth">(TA.)</span> It is said in a trad. respecting Tabook, <span class="ar long">وَالعَيْنُ تَبِضُّ بِشَىْءٍ مِنَ المَآءِ</span> <span class="add">[<em>The source,</em> or <em>spring, yielding scantily somewhat of water</em>]</span>. <span class="auth">(TA.)</span> And you say, <span class="ar long">بَضَّتِ العَيْنُ</span>, aor. as above, inf. n. <span class="ar">بَضٌّ</span> and <span class="ar">بَضِيضٌ</span>, <em>The eye shed tears.</em> <span class="auth">(TA.)</span> And, of a man when you characterise him as patient under affliction, <span class="ar long">مَا تَبِضُّ عَيْنُهُ</span> <span class="add">[<em>His eye does not shed tears</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَضَّتِ الحَلَمَةُ</span> <em>The nipple streamed with milk.</em> <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">مَا تَبِضُّ بِبَلَالٍ</span> <em>Having no milk dropping from it,</em> or <em>her.</em> <span class="auth">(TA.)</span> And in another trad., <span class="ar long">سَقَطَ مِنَ الفَرَسِ فَإِذَا هُوَ جَالِسٌ وَعُرْضُ وَجْهِهِ يَبِضُّ مَآءً أَصْفَرَ</span> <span class="add">[<em>He fell from the horse, and lo, he was sitting, with the side of his face exuding yellow water</em>]</span>. <span class="auth">(TA.)</span> One should not say, <span class="ar long">بَضَّ السِّقَآءُ</span>, nor <span class="ar">القِرْبَةُ</span>: but some say so, urging the authority of Ru-beh. <span class="auth">(Ṣ.)</span> And you say of a stone, and the like, <span class="ar">بَضَّ</span>, aor. as above, meaning <em>Water flowed from it like sweat; water oozed from it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bD_1_B2">
					<p>Hence the saying, <span class="ar long">مَا يَبِضُّ حَجَرُهُ</span> † <em>No good is obtained from him;</em> <span class="auth">(TA;)</span> <em>i. q.</em> <span class="ar long">مَا تَنْدَى صَفَاتُهُ</span>: <span class="auth">(Ṣ:)</span> a prov. applied to the niggardly. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[Hence also,]</span> <span class="ar long">بَضَّ لَهُ</span>, <span class="add">[aor., accord. to the TA, <span class="ar">يَبُضُّ</span>, but this is evidently a mistake,]</span> † <em>He gave him a little;</em> as also<span class="arrow"><span class="ar long">ابضّ↓ له</span></span>, <span class="auth">(Sh, Ḳ,)</span> inf. n. <span class="ar">إِبْضَاضٌ</span>: <span class="auth">(TA:)</span> and <span class="ar long">بَضَّ لَهُ بِشَىْءٍ</span> † <em>He did him a small benefit;</em> as also <span class="ar">نَضَّ</span>. <span class="auth">(Aṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bD_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابضّ</span></h3>
				<div class="sense" id="bD_4_A1">
					<p><span class="ar long">ابضّ لَهُ</span>: <a href="#bD_1">see 1</a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bD_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبضّض</span></h3>
				<div class="sense" id="bD_5_A1">
					<p><span class="ar">تَبَضَّضْتُهُ</span> <em>I took everything belonging to him.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بض</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bD_5_A2">
					<p><span class="ar long">تَبَضَّضْتُ حَقِّى مِنْهُ</span> <em>I took the whole of my right,</em> or <em>due, from him by little and little:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[as also <span class="ar long">تَنَضَّضْتُهُ مِنْهُ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bD_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبضّ</span></h3>
				<div class="sense" id="bD_10_A1">
					<p><span class="ar long">خُذْ مَا ٱسْتَبَضَّ</span> <em>Take thou what is easily attainable; what offers itself without difficulty.</em> <span class="auth">(AA, TA in art. <span class="ar">ندب</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDBN">
				<h3 class="entry"><span class="ar">بَضٌّ</span> / <span class="ar">بَضَّةٌ</span></h3>
				<div class="sense" id="baDBN_A1">
					<p><span class="ar">بَضٌّ</span> A man <em>thin-skinned,</em> or <em>fine-skinned, and plump:</em> <span class="auth">(Ṣ:)</span> or a man <em>having a thin,</em> or <em>fine, and plump, skin, upon which the least thing makes a mark,</em> or <em>an impression:</em> <span class="auth">(Mgh:)</span> or a man <span class="auth">(Aṣ)</span> <em>soft,</em> or <em>tender, in body;</em> not particularly implying whiteness: <span class="auth">(Aṣ, Ṣ:)</span> or <em>soft,</em> or <em>tender, in body, thin-skinned,</em> or <em>fine-skinned, and plump:</em> <span class="auth">(Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَضَّةٌ</span>}</span></add>; <span class="auth">(Ṣ, Ḳ, &amp;c.;)</span> signifying a girl, <span class="auth">(Ṣ,)</span> or a woman, <em>thin-skinned,</em> or <em>fine-skinned, and soft,</em> or <em>tender,</em> or <em>delicate,</em> <span class="auth">(TA,)</span> <em>if tawny</em> or <em>white:</em> <span class="auth">(Ṣ, TA:)</span> or <em>soft,</em> or <em>tender, in body;</em> not particularly implying whiteness: <span class="auth">(Aṣ, Ṣ:)</span> or <em>fleshy and white:</em> <span class="auth">(AA:)</span> or <em>thin-skinned,</em> or <em>fine-skinned, in whom the blood appears</em> <span class="add">[<em>through the skin</em>]</span>: <span class="auth">(Lḥ:)</span> or <em>soft,</em> or <em>tender,</em> or <em>delicate, compact in flesh, and very white</em> or <em>fair in complexion:</em> <span class="auth">(Lth:)</span> and<span class="arrow"><span class="ar">بَضِيضَةٌ↓</span></span> and<span class="arrow"><span class="ar">بَاضَّةٌ↓</span></span> and<span class="arrow"><span class="ar">بَضْبَاضَةٌ↓</span></span>, applied to a girl, signify the same as <span class="ar">بَضَّةٌ</span>; <span class="auth">(Ḳ, TA;)</span> <em>compact in flesh, plump,</em> or <em>soft and thin-skinned and plump, with a very white</em> or <em>fair complexion:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">بَضَاضٌ↓</span></span> also is syn. with <span class="ar">بَضَّةٌ</span>, applied to a woman. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDaDN">
				<h3 class="entry"><span class="ar">بَضَضٌ</span></h3>
				<div class="sense" id="baDaDN_A1">
					<p><span class="ar">بَضَضٌ</span> <em>Little water.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baDaADN">
				<h3 class="entry"><span class="ar">بَضَاضٌ</span></h3>
				<div class="sense" id="baDaADN_A1">
					<p><span class="ar">بَضَاضٌ</span>: <a href="#baDBN">see <span class="ar">بَضٌّ</span></a>, at the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDuwDN">
				<h3 class="entry"><span class="ar">بَضُوضٌ</span></h3>
				<div class="sense" id="baDuwDN_A1">
					<p><span class="ar long">بِئْرٌ بَضُوضٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">رَكِيَّةٌ بَضُوضٌ</span>, <span class="auth">(Ṣ,)</span> <em>A well having little water:</em> <span class="auth">(Ṣ:)</span> or <em>of which the water comes forth by little and little:</em> <span class="auth">(Ḳ:)</span> pl., in some copies of the Ḳ, <span class="ar">بِضَاضٌ</span>: in others, <span class="ar">بَضَائِضُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buDaADapN">
				<h3 class="entry"><span class="ar">بُضَاضَةٌ</span></h3>
				<div class="sense" id="buDaADapN_A1">
					<p><span class="ar long">مَا فِى السِّقَآءَ بُضَاضَةٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">بُضَاضَةٌ مِنْ مَاءٍ</span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بَضِيضَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>There is not in the skin</em> <span class="add">[even so much as]</span> <em>a small quantity of water:</em> <span class="auth">(Ḳ, TA:)</span> from Aboo-Saʼeed. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baDiyDapN">
				<h3 class="entry"><span class="ar">بَضِيضَةٌ</span></h3>
				<div class="sense" id="baDiyDapN_A1">
					<p><span class="ar">بَضِيضَةٌ</span>: <a href="#baDBN">see <span class="ar">بَضٌّ</span></a>, near the end of the paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بض</span> - Entry: <span class="ar">بَضِيضَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baDiyDapN_B1">
					<p><em>Rain little in quantity.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بض</span> - Entry: <span class="ar">بَضِيضَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baDiyDapN_B2">
					<p><a href="#buDaADapN">See also <span class="ar">بُضَاضَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بض</span> - Entry: <span class="ar">بَضِيضَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="baDiyDapN_C1">
					<p><em>A thing which the hand possesses.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">أَخْرَجْتُ لَهُ بَضِيضَتِى</span> <em>I produced to him what my hand possessed.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baDobaADapN">
				<h3 class="entry"><span class="ar">بَضْبَاضَةٌ</span></h3>
				<div class="sense" id="baDobaADapN_A1">
					<p><span class="ar">بَضْبَاضَةٌ</span>: <a href="#baDBN">see <span class="ar">بَضٌّ</span></a>, near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baADBapN">
				<h3 class="entry"><span class="ar">بَاضَّةٌ</span></h3>
				<div class="sense" id="baADBapN_A1">
					<p><span class="ar">بَاضَّةٌ</span>: <a href="#baDBN">see <span class="ar">بَضٌّ</span></a>, near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baADuwDN">
				<h3 class="entry"><span class="ar">بَاضُوضٌ</span></h3>
				<div class="sense" id="baADuwDN_A1">
					<p><span class="ar long">مَا فِى البِئْرِ بَاضُوضٌ</span> <em>There is not any moisture in the well.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabaDBu">
				<h3 class="entry"><span class="ar">أَبَضُّ</span></h3>
				<div class="sense" id="OabaDBu_A1">
					<p><span class="ar long">هُوَ أَبَضُّ النَّاسِ</span> <em>He is the most delicate,</em> or <em>fine, in complexion, of men, and the most beautiful of them in external skin.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0213.pdf" target="pdf">
							<span>Lanes Lexicon Page 213</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
