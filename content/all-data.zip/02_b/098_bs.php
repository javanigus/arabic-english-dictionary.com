<article class="root" id="Root_bs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/097_bzw">بزو</a></span>
				<span class="ar">بس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/099_bsO">بسأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bs_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسّ</span></h3>
				<div class="sense" id="bs_1_A1">
					<p><span class="ar">بَسٌّ</span> signifies The <em>act of breaking:</em> or <em>breaking in pieces:</em> syn. <span class="ar">حَطْمٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bs_1_A2">
					<p><span class="add">[And The <em>act of mixing:</em> <a href="#basiysapN">see <span class="ar">بَسِيسَةٌ</span></a>. This, or the former, is probably the primary signification.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bs_1_A3">
					<p><span class="add">[And hence, app.,]</span> <span class="ar">بَسَّهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْسُسُ</span>}</span></add>, inf. n. <span class="ar">بَسٌّ</span>, <span class="auth">(M, Mṣb,)</span> <em>He broke it, crumbled it,</em> or <em>bruised</em> or <em>brayed it;</em> said of wheat, &amp;c.; <em>thus making it what is termed</em> <span class="ar">بَسِيسَة</span>: <span class="auth">(Mṣb:)</span> or <em>he mixed it,</em> namely, <span class="ar">سَويق</span> <span class="add">[or meal of parched barley or wheat]</span>, and flour, &amp;c., <em>with clarified butter,</em> or <em>with olive-oil; thus making it what is termed</em> <span class="ar">بسِيسَة</span>: <span class="auth">(M:)</span> or <em>he moistened it,</em> namely, <span class="ar">سَوِيق</span>, and flour, <em>with a little water;</em> <span class="auth">(ISk, Mṣb;)</span> <em>but making it more moist than one does in the action termed</em> <span class="ar">لَتٌّ</span>: <span class="auth">(Yaạḳoob, cited in the Ṣ; and ISk, in the Mṣb:)</span> or <span class="ar">بَسٌّ</span> signifies the <em>making,</em> or <em>preparing,</em> <span class="ar">بسِيسَة</span>, <em>by stirring about,</em> or <em>moistening,</em> <span class="ar">سَوِيق</span>, or <em>flour,</em> or <em>ground</em> <span class="ar">أَقِط</span>, <em>with clarified butter,</em> or <em>with olive-oil;</em> <span class="auth">(Ṣ, Ḳ;)</span> after which it is eaten, without being cooked. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bs_1_A4">
					<p><span class="add">[And hence the saying in the Ḳur lvi. 5,]</span> <span class="ar long">وَبُسَّتِ الجِبَالُ بَسًّا</span> <em>And the mountains shall be crumbled with a</em> vehement <em>crumbling,</em> <span class="auth">(Lḥ, M, A, Ḳ,)</span> <em>like flour, and</em> <span class="ar">سَوِيق</span>, <span class="auth">(A,)</span> <em>and become earth:</em> <span class="auth">(Fr, Ḳ:)</span> or <em>become dust cleaving to the earth:</em> <span class="auth">(AO, M, TA:)</span> or <em>be levelled:</em> <span class="auth">(M, TA:)</span> or <em>mixed with the dust:</em> <span class="auth">(Zj, M, TA:)</span> or <em>reduced to powder and scattered in the wind.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basiysapN">
				<h3 class="entry"><span class="ar">بَسِيسَةٌ</span></h3>
				<div class="sense" id="basiysapN_A1">
					<p><span class="ar">بَسِيسَةٌ</span> <em>Wheat, &amp;c., broken,</em> or <em>crumbled,</em> or <em>bruised:</em> <span class="auth">(Mṣb:)</span> or <span class="ar">سَوِيق</span> <span class="add">[or <em>meal of parched barley or wheat</em>]</span>, and <em>flour, &amp;c., mixed with clarified butter,</em> or <em>with olive-oil:</em> <span class="auth">(M:)</span> or <em>what is stirred about with olive-oil,</em> or <em>with clarified butter, and not wetted</em> <span class="add">[<em>with water</em>]</span>: <span class="auth">(Lḥ, M:)</span> or <span class="ar">سويق</span>, or <em>flour,</em> or <em>ground</em> <span class="ar">أَقِط</span>, <em>stirred about,</em> or <em>moistened, with clarified butter,</em> or <em>with oliveoil;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>after which it is eaten, without being cooked:</em> <span class="auth">(Ṣ:)</span> or <span class="ar">سويق</span>, and <em>flour, moistened with a little water,</em> <span class="auth">(ISk, Mṣb,)</span> <em>but more moist than such as is prepared in the manner termed</em> <span class="ar">لَتٌّ</span>; <span class="auth">(Yaạḳoob, cited in the Ṣ; and ISk, in the Mṣb;)</span> <em>and used as travelling-provision:</em> <span class="auth">(TA:)</span> and <em>bread dried and pounded, and</em> <span class="add">[<em>mixed with water so that it is</em>]</span> <em>drunk like as</em> <span class="ar">سويق</span> <em>is drunk:</em> <span class="auth">(M, Ḳ:*)</span> IDrd thinks it to be <em>what is termed</em> <span class="ar">فَتُوث</span>: also <em>barley mixed with date-stones, for camels:</em> <span class="auth">(M, TA:)</span> or, accord. to Aṣ, <em>anything that one mixes with another thing: such as</em> <span class="ar">سويق</span> <em>with</em> <span class="ar">اقط</span>, <em>which one then moistens with fresh butter:</em> and <em>such as barley with date-stones, which one then moistens, for camels:</em> <span class="auth">(Mṣb,* TA:)</span> pl. <span class="ar">بُسُسٌ</span>, <span class="auth">(IAạr, TA,)</span> which is explained in the Ḳ as signifying <em>messes of</em> <span class="ar">سويق</span> <em>moistened,</em> or <em>stirred about with water, &amp;c.</em> (<span class="ar long">أَسْوِقَةٌ مَلْتُوتَةٌ</span>). <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0201.pdf" target="pdf">
							<span>Lanes Lexicon Page 201</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
