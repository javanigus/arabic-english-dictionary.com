<article class="root" id="Root_bdh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/046_bdn">بدن</a></span>
				<span class="ar">بده</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/048_bdw">بدو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bdh_1">
				<h3 class="entry">1. ⇒ <span class="ar">بده</span></h3>
				<div class="sense" id="bdh_1_A1">
					<p><span class="ar">بَدَهَهُ</span>, <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْدَهُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَدْءٌ</span>, <span class="auth">(JK, Ṣ, Mṣb,)</span> <em>He,</em> or <em>it, came upon him,</em> or <em>happened to him, suddenly, unexpectedly,</em> or <em>without his being aware of it; surprised him,</em> or <em>took him unawares;</em> <span class="auth">(JK, Ṣ Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بادههُ↓</span></span>, inf. n. <span class="ar">مُبَادَهَةٌ</span>: <span class="auth">(JK, Mṣb:)</span> the former verb has this signification said of an affair, or event. <span class="auth">(Ṣ, Ḳ.)</span> And <span class="ar long">بَدَهَهُ بِأَمْرٍ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. as above, <span class="auth">(Ḳ,)</span> and so the inf. n., <span class="auth">(JK, TA,)</span> signifies <span class="ar long">اِسْتَقْبَلَهُ بِهِ</span>, <span class="auth">(JK, T, Ṣ, Ḳ,)</span> i. e. <em>He met him,</em> or <em>encountered him, with a thing,</em> or <em>an affair,</em> or <em>an action,</em> <span class="auth">(TḲ,)</span> <em>suddenly, unexpectedly,</em> or <em>without his being aware of it:</em> <span class="auth">(T, TA:)</span> or <em>he began with him by it,</em> or <em>with it;</em> syn. <span class="ar long">بَدَأَهُ بِهِ</span>; <span class="auth">(Ḳ;)</span> the <span class="ar">ه</span> being a substitute for the <span class="ar">ا</span> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">بادههُ↓ بِهِ</span></span>, <span class="auth">(Ṣ,* Ḳ,)</span> inf. n. <span class="ar">مُبَادَهَةٌ</span> and <span class="ar">بِدَاهٌ</span>, <span class="auth">(Ḳ,)</span> <em>he came upon him suddenly, unexpectedly,</em> or <em>without his being aware of it; surprised him,</em> or <em>took him unawares;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>with it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdh_1_A2">
					<p><a href="#bdh_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdh_2">
				<h3 class="entry">2. ⇒ <span class="ar">بدّه</span></h3>
				<div class="sense" id="bdh_2_A1">
					<p><span class="ar">بدّه</span>, inf. n. <span class="ar">تَبْدِيهٌ</span>, <em>He answered,</em> or <em>replied, quickly:</em> <span class="auth">(IAạr, TA:)</span> and<span class="arrow"><span class="ar">بَدَهَ↓</span></span> <em>he answered,</em> or <em>replied,</em> or <em>he spoke, extempore; without premeditation.</em> <span class="auth">(Ḥar p. 64.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bdh_3">
				<h3 class="entry">3. ⇒ <span class="ar">باده</span></h3>
				<div class="sense" id="bdh_3_A1">
					<p><a href="#bdh_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdh_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباده</span></h3>
				<div class="sense" id="bdh_6_A1">
					<p><span class="ar long">هُمَ يَتَبَادَهَانِ بِا لشِّعْرِ</span> <span class="auth">(Ṣ, TA)</span> <em>They two dispute,</em> or <em>contend together</em> <span class="add">[<em>extemporaneously,</em> or <em>extemporizing, with verses</em> or <em>poetry</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdh_6_A2">
					<p><a href="#bdh_8">See also 8</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdh_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتده</span></h3>
				<div class="sense" id="bdh_8_A1">
					<p><span class="ar long">ابتده الخُطْبَةَ</span> <span class="auth">(Ḳ, TA)</span> <em>He extemporized the discourse,</em> or <em>sermon,</em> or <em>oration; spoke it,</em> or <em>composed it, extemporaneously, impromptu, without premeditation.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">هُمْ يَتَبَادَهُونَ↓ الخُطَبَ</span></span> <span class="auth">(Ḳ, TA)</span> <em>They extemporize discourses,</em>, &amp;c.: here the measure <span class="ar">تَفَاعُلٌ</span> has not its proper quality <span class="add">[of denoting participation in the manner of contention, though it has in a phrase mentioned before]</span>. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badohN">
				<span class="pb" id="Page_0170"></span>
				<h3 class="entry"><span class="ar">بَدْهٌ</span> / <span class="ar">بُدْهٌ</span></h3>
				<div class="sense" id="badohN_A1">
					<p><span class="ar">بَدْهٌ</span> and <span class="ar">بُدْهٌ</span>: <a href="#budaAhapN">see <span class="ar">بُدَاهَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badiypK">
				<h3 class="entry"><span class="ar">بَدِيةٍ</span> / <span class="ar">بَدِيهًا</span></h3>
				<div class="sense" id="badiypK_A1">
					<p><span class="ar long">عَلَى بَدِيةٍ</span>, and <span class="ar">بَدِيهًا</span>: <a href="#badiyhapN">see <span class="ar">بَدِيهَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badaAhapN">
				<h3 class="entry"><span class="ar">بَدَاهَةٌ</span></h3>
				<div class="sense" id="badaAhapN_A1">
					<p><span class="ar">بَدَاهَةٌ</span>: <a href="#budaAhapN">see <span class="ar">بُدَاهَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="budaAhapN">
				<h3 class="entry"><span class="ar">بُدَاهَةٌ</span></h3>
				<div class="sense" id="budaAhapN_A1">
					<p><span class="ar">بُدَاهَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بَدَاهَةٌ↓</span></span> <span class="auth">(Ṣgh, Ḳ)</span> and<span class="arrow"><span class="ar">بَدِيهَةٌ↓</span></span> <span class="auth">(JK, Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">بَدْهٌ↓</span></span> and<span class="arrow"><span class="ar">بُدْهٌ↓</span></span> <span class="auth">(Ḳ)</span> substs. from <span class="ar long">بَدَهَهُ بِأَمْرٍ</span>, <span class="auth">(JK, Ṣ,)</span> meaning The <em>first</em> of anything; and <em>an occurrence</em> thereof <em>by which one is taken unawares:</em> <span class="auth">(Ḳ:)</span> or the <em>first occurrence</em> of a thing, <em>that happens to one unexpectedly.</em> <span class="auth">(M, in explanation of the first word, in art. <span class="ar">بدأ</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: <span class="ar">بُدَاهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="budaAhapN_A2">
					<p>Also the first <span class="auth">(Ṣ, TA)</span> and<span class="arrow">↓</span> second <span class="auth">(JK)</span> and<span class="arrow">↓</span> third <span class="auth">(TA)</span> The <em>first part of the running</em> of a horse; <span class="auth">(JK, Ṣ, TA;)</span> opposed to <span class="ar">عُلَالَةٌ</span>, signifying <span class="add">[the “remaining part of the running,” or “an afterrunning,” or]</span> “a running after a running.” <span class="auth">(TA.)</span> You say,<span class="arrow"><span class="ar long">هُوَ ذُو بَدِيهَةٍ↓ وَعُلَالَةٍ</span></span>, and <span class="ar">بُدَاهَةٍ</span>, <span class="add">[<em>He has a first running and an after-running,</em> differing, the one from the other]</span>. <span class="auth">(Az, TA.)</span> And <span class="ar long">لَحِقَهُ فِى بُدَاهَةِ جَرْيِهِ</span> <span class="add">[<em>He overtook him in the first part of his running</em>]</span>. <span class="auth">(Z, TA.)</span> ISd thinks that in all these cases the <span class="ar">ه</span> is a substitute for <span class="ar">ء</span>. <span class="auth">(TA.)</span> <span class="add">[Hence,]</span><span class="arrow"><span class="ar long">غَمْرُ البَدِيْهَةِ↓</span></span> <span class="add">[properly <em>Fleet in the first part of his running;</em> meaning]</span> ‡ a man <em>who takes by surprise with large bounty.</em> <span class="auth">(TA, in art. <span class="ar">غمر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: <span class="ar">بُدَاهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="budaAhapN_A3">
					<p><a href="#badiyhapN">See also the next paragraph</a>. in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badiyhapN">
				<h3 class="entry"><span class="ar">بَدِيهَةٌ</span></h3>
				<div class="sense" id="badiyhapN_A1">
					<p><span class="ar">بَدِيهَةٌ</span>: <a href="#budaAhapN">see <span class="ar">بُدَاهَةٌ</span></a>, in four places. You say, <span class="ar long">لَكَ البَدِيهَةُ</span>, <span class="auth">(Ḳ,)</span> in which ISd thinks the <span class="ar">ه</span> to be a substitute for <span class="ar">ء</span>, <span class="auth">(TA,)</span> <em>It is for thee to begin;</em> <span class="auth">(Ḳ;)</span> and so<span class="arrow"><span class="ar long">لك البُدَاهَةُ↓</span></span>, with <span class="ar">ه</span> substituted for <span class="ar">ء</span>. <span class="auth">(M, Mbr, TA art. <span class="ar">بدأ</span>.)</span> And <span class="ar long">أَجَابَ عَلَى البَديهَةِ</span> <span class="auth">(Ḳ)</span> <em>He answered,</em> or <em>replied, on the first of his being taken unawares.</em> <span class="auth">(TA.)</span> <span class="add">[<span class="arrow"><span class="ar long">عَلَى بَدِيهٍ↓</span></span> is mentioned by Freytag, but on what authority he does not say, as meaning <em>Unpreparedly, suddenly,</em> or <em>unexpectedly;</em> and so<span class="arrow"><span class="ar">بَدِيهًا↓</span></span> by Golius, as on the authority of J, but I do not find it in the Ṣ in the present article.]</span> And <span class="ar long">رَآهُ بَدِيهَةً</span>, signifies <em>He saw him suddenly,</em> or <em>unexpectedly.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَدِيهَةُ الرَّأْىِ</span>, <em>Suddenly formed, unpremeditated, judgment</em> or <em>opinion.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: <span class="ar">بَدِيهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badiyhapN_A2">
					<p><span class="ar">بَدِيهَةٌ</span> and<span class="arrow"><span class="ar">بُدَاهَةٌ↓</span></span> both signify The <em>coming, of speech, without premeditation:</em> and the <em>coming suddenly, unexpectedly,</em> or <em>unawares.</em> <span class="auth">(KL.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: <span class="ar">بَدِيهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badiyhapN_A3">
					<p>And<span class="arrow">↓</span> the latter, <span class="add">[and more commonly the former,]</span> <em>An intuitive knowledge, notion,</em> or <em>idea; such as that one is the half of two;</em> being, <em>with respect to knowledge, like</em> <span class="ar">بَدِيعٌ</span> <em>with respect to intellect:</em> <span class="auth">(Kull:)</span> <span class="add">[or]</span> the former signifies the <em>faculty of judging rightly at the first of an unexpected occurrence:</em> <span class="add">[<em>intuition,</em> or <em>intuitive perception:</em>]</span> accord. to ʼAlee-Ibn-Dháfir El-Haddád, it signifies primarily <span class="ar long">اِرْتِجَالٌ فِى الكَلَامِ</span> <span class="add">[i. e. the <em>faculty of extemporizing:</em> or <em>speaking,</em> or <em>composing, extemporaneously, impromptu, without premeditation</em>]</span>: and predominantly, the <em>poetizing,</em> or <em>versifying, impromptu, without premeditation</em> or <em>consideration: except that</em> <span class="ar">ارتجال</span> <em>is quicker than</em> <span class="ar">بديهة</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">هُوَ ذُو بَدِيهَةٍ</span> <span class="auth">(Ḳ)</span> <em>He has a faculty of judging rightly at the first of an unexpected occurrence.</em> <span class="auth">(TA.)</span> And <span class="ar long">فُلَانٌ ذُو بَدِيهَةٍ حَسَنَةٍ</span> <em>Such a one has a good faculty of extemporizing;</em> or <em>of uttering,</em> or <em>relating, things by means of the promptness of his intelligence.</em> <span class="auth">(TA, in art. <a href="../"><span class="ar">بدأ</span></a>: <a href="#badiYoyapN">see <span class="ar">بَدِيْئَةٌ</span></a>.)</span> And <span class="ar long">هٰذَا مَعْلُومٌ فِى بَدَائِهِ العُقُولِ</span> <span class="add">[<em>This is known among the intuitive notions of intellects;</em> i. e., <em>intuitively</em>]</span>. <span class="auth">(Ḳ,* TA.)</span> <span class="ar">بَدَائِهُ</span> seems to be <a href="#badiyhapN">pl. of <span class="ar">بَدِيهَةٌ</span></a>, as in the phrase, <span class="auth">(TA,)</span> <span class="ar long">لَهُ بَدَائِهُ</span>, i. e. <span class="ar">بَدَائِعُ</span> <span class="add">[<em>He has new</em>, or <em>admirable, things that he utters</em>]</span>, <span class="auth">(Ḳ, TA,)</span> in speech, or language, and poetry, and in answering, or replying: but here it is not improbable that the <span class="ar">ه</span> may be a substitute for the <span class="ar">ع</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badiyhieBN">
				<h3 class="entry"><span class="ar">بَدِيهِىٌّ</span></h3>
				<div class="sense" id="badiyhieBN_A1">
					<p><span class="ar">بَدِيهِىٌّ</span> <span class="add">[<em>Intuitive</em> knowledge;]</span> <em>such that its origination does not rest upon speculation, and acquisition by study, whether it do,</em> or <em>do not, require some other thing, as conjecture or experience</em>, &amp;c.; <span class="auth">(KT, Kull;)</span> <em>so that it is</em> <span class="add">[<em>sometimes</em>]</span> <em>syn. with</em> <span class="ar">ضَرُورِىٌّ</span> <span class="add">[and opposed to <span class="ar">نَظَرِىٌّ</span>]</span>: and sometimes it means <em>such as does not require anything whatever after the intellect has directed itself; so that it is more particular than</em> <span class="ar">ضَرُورِىٌّ</span>: <span class="auth">(KT:)</span> <em>as the conception of heat and cold, and the assent of the mind to the position that negation and affirmation cannot be co-existent, nor be simultaneously non-existent, in the same instance.</em> <span class="auth">(KT, Kull.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بده</span> - Entry: <span class="ar">بَدِيهِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badiyhieBN_A2">
					<p><span class="add">[And hence,]</span> <em>A mere simpleton</em> or <em>fool:</em> but this is post-classical. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibodahN">
				<h3 class="entry"><span class="ar">مِبْدَهٌ</span></h3>
				<div class="sense" id="mibodahN_A1">
					<p><span class="ar long">رَجُلٌ مِبْدَهٌ</span> <span class="auth">(Ṣ)</span> <em>A man possessing in a large degree the faculty of extemporizing,</em> or <em>of judging rightly at the first of an unexpected occurrence; firm,</em> or <em>steady, in speech</em> or <em>discourse,</em> or <em>whose tongue makes no slip in contentions, when he is taken unawares.</em> <span class="auth">(Ḥar p. 64.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0169.pdf" target="pdf">
							<span>Lanes Lexicon Page 169</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0170.pdf" target="pdf">
							<span>Lanes Lexicon Page 170</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
