<article class="root" id="Root_bl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/167_bke">بكى</a></span>
				<span class="ar">بل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/169_blj">بلج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلّ</span></h3>
				<div class="sense" id="bl_1_A1">
					<p><span class="ar">بَلَّهُ</span> <span class="auth">(Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُلُ</span>}</span></add>, <span class="auth">(Ṣ, M,)</span> inf. n. <span class="ar">بَلٌّ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">بِلَّةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>He moistened it</em> <span class="auth">(Ṣ, M, Ḳ)</span> with water <span class="auth">(M, Mṣb, Ḳ)</span>, &amp;c.; <span class="auth">(M;)</span> and in like manner,<span class="arrow"><span class="ar">بلّلهُ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> but signifying <em>he moistened it much.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bl_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَلَّتِ الإِبِلُ أَغْمَارَهَا</span> <span class="add">[<em>The camels damped their thirst;</em>]</span> i. e., <em>drank a little.</em> <span class="auth">(TA in art. <span class="ar">غمر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bl_1_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar long">بَلَّ رَحِمَهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span>) aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْلُلُ</span>}</span></add>, <span class="auth">(T, M,)</span> inf. n. <span class="ar">بَلٌّ</span> <span class="auth">(with fet-ḥ, TA <span class="add">[in the CK it has kesr]</span>)</span> and <span class="ar">بِلَالٌ</span>, <span class="auth">(M, Ḳ,)</span> ‡ <em>He made close</em> <span class="add">[or <em>he refreshed</em>]</span> <em>his ties of relationship by behaving with goodness and affection and gentleness to his kindred;</em> syn. <span class="ar">وَصَلَهَا</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar">نَدَّاهَا</span>: <span class="auth">(T:)</span> for, as some things are conjoined and commixed by moisture, and become disunited by dryness, <span class="ar">بَلٌّ</span> is metaphorically used to denote conjunction, as above, and <span class="ar">يُبْسٌ</span> to denote the contrary. <span class="auth">(TA.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَالرِّحْمَ فٱبْلُلْهَا بِخَيْرِ البُلَّانْ</span> *</div> 
						<div class="star">* <span class="ar long">فَإِنَهَاٱشْتُقَّتْ مِنِ ٱسْمِ الرَّحْمٰنْ</span> *</div> 
					</blockquote>
					<p><span class="add">[‡ <em>And the ties of relationship, make thou them close, &amp;c. by the best mode,</em> or <em>modes, of doing so; for the name thereof is derived from the name of the Compassionate</em>]</span>: here↓<span class="ar">البُلَّان</span> may be a noun in the sing. number, like <span class="ar">غُفْرَانٌ</span>, or it may be <a href="#balalN">pl. of <span class="ar">بَلَلٌ</span></a>, which may be either a subst. or an. inf. n., for some inf. ns. have pls., as <span class="ar">شُغْلٌ</span> and <span class="ar">عَقْلٌ</span> and <span class="ar">مَرَضٌ</span>. <span class="auth">(M.)</span> And it is said in a trad., <span class="ar long">بُلُّوا أَرْحَامَكُمْ وَلَوْ بِالسَّلَامِ</span> ‡ <em>Make ye close</em> <span class="add">[or <em>refresh ye</em>]</span> <em>your ties of relationship, &amp;c., though but, </em> or <em>if only, by salutation;</em> syn. <span class="ar">صِلُوهَا</span>, <span class="auth">(M,)</span> or <span class="ar long">نَدُّوهَا بِالصِّلَةِ</span>. <span class="auth">(Ṣ.)</span> And hence the saying in another trad., <span class="ar long">إِذَ ٱسْتَشَنَّ مَا بَيْنَكَ وَبَيْنَ ٱللّٰهِ فَٱبْلُلْهُ بِالإِحْسَانِ إِلَى عِبَادَهِ</span> ‡ <span class="add">[<em>When the tie between thee and God wears out, repair thou it,</em> or <em>refresh thou it, by beneficence to his servants</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#bilaAlN">See also <span class="ar">بِلَالٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bl_1_A4">
					<p><span class="ar long">بَلَّكَ ٱللّٰهُ بِٱبْنٍ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">ٱبْنًا</span>, <span class="auth">(M, Ḳ,)</span> † <em>May God give thee a son.</em> <span class="auth">(Ṣ, M, Ḳ, TA.)</span> Hence, perhaps, the phrase, <span class="ar long">بُلَّتْ يَدَاكَ بِهِ</span> as meaning † <em>Thou was given it.</em> <span class="auth">(Ḥar p. 479.)</span> You say also, <span class="ar">بَلَلْتُهُ</span>, meaning † <em>I gave to him.</em> <span class="auth">(T.)</span> And<span class="arrow"><span class="ar long">لَا تَبْلُكَ عِنْدِى بَالَّةٌ↓</span></span>, and<span class="arrow"><span class="ar">بَلَالٌ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ, <span class="add">[but in the Ḳ <span class="ar">عِنْدَنَا</span>, and “or” for “and,” and in the CK <span class="ar long">لا تَبَلُّكَ</span>,]</span>)</span> ‡ <em>No bounty,</em> <span class="auth">(Ṣ,)</span> <em>no good,</em> or <em>no benefit, shall betide thee from me,</em> <span class="auth">(T, Ṣ, Ḳ, TA,)</span> <em>nor will I profit thee, nor believe thee.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bl_1_A5">
					<p><span class="ar">بَلُّوا</span> <em>They sowed</em> land. <span class="auth">(ISh, T, Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0243"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bl_1_B1">
					<p><span class="add">[<span class="ar">بَلَّ</span> as an intrans. verb perhaps primarily signifies <em>It was,</em> or <em>became, moist;</em> and has for its sec. pers. <span class="ar">بَلِلْتَ</span> or <span class="ar">بَلَلْتَ</span>, and for its aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَلُ</span>}</span></add> or <span class="ar">ـِ</span>, and for its inf. n. <span class="ar">بَلَلٌ</span>, and probably <span class="ar">بِلَّةٌ</span>, &amp;c. mentioned with that noun below.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bl_1_B2">
					<p><span class="add">[And hence,]</span> <span class="ar long">بَلَّتِ الرِّيحُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِلُ</span>}</span></add>, inf. n. <span class="ar">بُلُولٌ</span>, <em>The wind was cold and moist.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#baliylN">See <span class="ar">بَلِيلٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bl_1_B3">
					<p><span class="add">[And hence, probably, as though originally said of one who had had a fever,]</span> <span class="ar long">بَلَّ مِنْ مَرَضِهِ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِلُ</span>}</span></add>, inf. n. <span class="ar">بَلٌّ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بَلَلٌ</span> and <span class="ar">بُلُولٌ</span>; <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">ابلّ↓</span></span>, and<span class="arrow"><span class="ar">استبلّ↓</span></span>; <span class="auth">(Ṣ, M, Ḳ;)</span> <em>He recovered from his disease:</em> <span class="auth">(Ṣ, M:)</span> and<span class="arrow"><span class="ar">ابتلّ↓</span></span> and<span class="arrow"><span class="ar">تبلّل↓</span></span> <em>he became in a good condition after leanness,</em> or <em>meagerness:</em> <span class="auth">(M,Z:)</span> or all have this latter signification: and the second (<span class="ar">ابلّ</span>) has the former also. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bl_1_B4">
					<p>And <span class="ar">بَلَّ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِلُ</span>}</span></add>, <span class="auth">(M,)</span> inf. n. <span class="ar">بُلُولٌ</span>; and<span class="arrow"><span class="ar">ابلّ↓</span></span>; <em>He</em> <span class="auth">(a man, TA)</span> <em>escaped,</em> or <em>became safe</em> or <em>secure,</em> <span class="auth">(M, Ḳ,)</span> <em>from difficulty, distress,</em> or <em>straitness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="bl_1_B5">
					<p><span class="ar long">بَلَّ فِى الأَرْض</span>, <span class="auth">(Mṣb, Ḳ,* TA,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِلُ</span>}</span></add>, inf. n. <span class="ar">بَلٌّ</span>; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">ابلّ↓</span></span>; <span class="auth">(M, Ḳ;)</span> <em>He</em> <span class="auth">(a man, M)</span> <em>went away in,</em> or <em>into, the land,</em> or <em>country.</em> <span class="auth">(M, Mṣb, Ḳ.)</span> And <span class="ar long">بَلَّتْ نَاقَتُهُ</span> <em>His she-camel went away.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَلَّتْ مَطِيَّتُهُ عَلَى وَجْهِهَا</span>, <span class="auth">(Fr, T, TA,)</span> and<span class="arrow"><span class="ar long">ابلّت↓ على وجها</span></span>, <span class="auth">(Ḳ,)</span> <em>His camel,</em> or <em>riding-camel, ran away,</em> or <em>went away, at random, to pasture, straying;</em> syn. <span class="ar long">هَمَتْ ضَالَّةً</span>. <span class="auth">(Fr, T, Ḳ, TA. <span class="add">[In the CK, <span class="ar">همت</span>, which, as is said in the TA, is without teshdeed, is written <span class="ar">هَمَّتْ</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bl_1_C1">
					<p><span class="ar long">بَلِلْتُ مِنْهُ</span>, <span class="auth">(Aṣ, T, Ṣ, &amp;c.,)</span> inf. n. <span class="ar">بَلَلٌ</span>, <span class="auth">(M,)</span> <em>I got him; got possession of him;</em> <span class="auth">(Aṣ, T, Ṣ, M, Ḳ;)</span> <em>got him in my hand.</em> <span class="auth">(Ṣ.)</span> One says, <span class="ar long">لَئِنْ بَلَّتْ بِكَ يَدِى لَا تُفَارِقُنِى أَوْ تُؤَدِّىَ حَقِّى</span> <span class="add">[<em>Assuredly if my hand get hold of thee, thou shalt not quit me unless thou give up,</em> or <em>pay, my right,</em> or <em>due</em>]</span>. <span class="auth">(Ṣ.)</span> And hence the prov., <span class="ar long">مَا بَلَلْتُ مِنْ فُلَانٍ بِأَفْوَقَ نَاصِلٍ</span> <span class="add">[<em>I did not get, in such a one,</em> a man like <em>an arrow with a broken notch</em> and <em>without a head</em>]</span>; meaning I got a perfect man; one sufficient. <span class="auth">(Sh, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="bl_1_C2">
					<p>Also, <span class="auth">(T,)</span> or <span class="ar">بَلِلْتُهُ</span>, <span class="auth">(M, Ḳ,)</span> <em>I kept,</em> or <em>clave, to him,</em> <span class="auth">(T, M, Ḳ,)</span> namely, a man, <span class="auth">(T, Ḳ,)</span> <em>and constantly associated with him.</em> <span class="auth">(T.)</span> And <span class="ar long">بَلَّ بِالشَّيْءِ</span>, inf. n. <span class="ar">بَلٌّ</span>, <em>He became devoted,</em> or <em>attached, to the thing, and kept to it constantly.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="bl_1_C3">
					<p>And <span class="ar long">بَلِلْتُ مِنْهُ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَلُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَلَلٌ</span> and <span class="ar">بَلَالَةٌ</span> and <span class="ar">بُلُولٌ</span>, <em>I was tried by him</em> (<span class="ar long">مُنِيتُ بِهِ</span> <span class="add">[app. meaning <span class="ar">بِحُبِّهِ</span> <em>by love of him</em>]</span>), <em>and loved him</em> (<span class="ar">عَلِقْتُهُ</span> <span class="add">[in the CK <span class="ar">عَلَقْتُهُ</span>]</span>); as also <span class="ar long">بَلَلْتُ به</span>, <span class="auth">(AA, M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْلِلُ</span>}</span></add>, inf. n. <span class="ar">بُلُولٌ</span> <span class="auth">(AA, TA.)</span> And <span class="ar long">بَلِلْتُ بِهِ</span> <em>I was tried by him, as though by fire,</em> (<span class="ar long">صَلِيتُ به</span>, <span class="add">[in the CK <span class="ar">صَلَيْتُ</span>,]</span>) <em>and suffered distress,</em> or <em>misery,</em> or <em>fatigue</em> (<span class="ar">شَقِيتُ</span>, for which <span class="ar">شُفِيتُ</span> is erroneously put in the copies of the Ḳ: TA). <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C4</span>
				</div>
				<div class="sense" id="bl_1_C4">
					<p><span class="ar long">مَا بَلَلْتُ بِهِ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَلُ</span>}</span></add>, inf. n. <span class="ar">بَلَلٌ</span>, <span class="auth">(TA,)</span> <em>I did not light on,</em> or <em>meet with,</em> or <em>find, nor know, him,</em> or <em>it; expl. by</em> <span class="ar long">مَا أَصَبْتُهُ وَلَا عَلِمْتُهُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bl_1_D1">
					<p><span class="ar">بَلَّ</span>, <span class="auth">(Th, M, Ḳ,)</span> inf. n. <span class="ar">بَلَلٌ</span>, <span class="auth">(Th, Ṣ, M, Ḳ,)</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, such as is termed</em> <span class="ar">أَبَلّ</span> <span class="add">[which epithet see below]</span>. <span class="auth">(Th, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بلّل</span></h3>
				<div class="sense" id="bl_2_A1">
					<p><a href="#bl_1">see 1</a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلّ</span></h3>
				<div class="sense" id="bl_4_A1">
					<p><span class="ar">ابلّ</span> <em>It</em> <span class="auth">(wood, or a branch or twig,)</span> <em>had the sap,</em> (<span class="ar">المَآء</span>, Ḳ,) or <em>the produce of the rain,</em> <span class="auth">(O,)</span> <em>flowing in it.</em> <span class="auth">(O, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bl_4_A2">
					<p><a href="#balBa">See also <span class="ar">بَلَّ</span></a>, in four places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bl_4_B1">
					<p><em>He</em> <span class="auth">(a man)</span> <em>resisted,</em> or <em>withstood, and overcame.</em> <span class="auth">(Aṣ, T, Ṣ. <span class="add">[<a href="#Oabala">See also <span class="ar">أَبَلَ</span></a>.]</span>)</span> And <span class="ar long">ابلّ عَلَيْهِ</span> <em>He overcame him.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[See an ex. in a verse of Sá'ideh, cited voce <span class="ar">خَسْفٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bl_4_B2">
					<p><em>He wearied by badness,</em> or <em>wickedness:</em> <span class="auth">(M, Ḳ:)</span> or <em>he wearied another in aiding him to accomplish his desire.</em> <span class="auth">(TA. <span class="add">[<a href="#mubilBN">See <span class="ar">مُبِلٌّ</span></a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bl_4_C1">
					<p><span class="ar">أَبْلَلْتُهُ</span> <em>I made him to go away.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّل</span></h3>
				<div class="sense" id="bl_5_A1">
					<p><a href="#bl_8">see 8</a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bl_5_A2">
					<p><a href="#balBa">and see also <span class="ar">بَلَّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتلّ</span></h3>
				<div class="sense" id="bl_8_A1">
					<p><span class="ar">ابتلّ</span> <em>It became moist</em> or <em>moistened </em> <span class="auth">(Ṣ, M, Mṣb,* Ḳ)</span> with water <span class="auth">(M, Mṣb, Ḳ)</span>, &amp;c.; <span class="auth">(M;)</span> and in like manner, <span class="add">[but signifying <em>it became much moistened,</em> <a href="#bl_2">being quasi-pass. of <span class="ar">بلّلهُ</span></a>,]</span> <a href="#bl_5"><span class="arrow"><span class="ar">تبلّل↓</span></span></a>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bl_8_A2">
					<p><a href="#balBa">See also <span class="ar">بَلَّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبلّ</span></h3>
				<div class="sense" id="bl_10_A1">
					<p><a href="#balBa">see <span class="ar">بَلَّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bl_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بلبل</span></h3>
				<div class="sense" id="bl_RQ1_A1">
					<p><span class="ar">بَلْبَلَ</span>, inf. n. <span class="ar">بَلْبَلَةٌ</span> and <span class="ar">بِلْبَالٌ</span>, <span class="auth">(M, Ḳ,)</span> the latter with kesr, <span class="auth">(TA,)</span> <span class="add">[but written in the CK with fet-ḥ,]</span> <em>He put</em> people <em>in motion;</em> and <em>roused,</em> or <em>excited,</em> them. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bl_RQ1_A2">
					<p>Also, <span class="auth">(T,)</span> inf. n. <span class="ar">بَلْبَلَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>He scattered, dispersed,</em> or <em>put asunder,</em> his goods, commodities, or householdutensils and furniture. <span class="auth">(IAạr, T, Ḳ.* <span class="add">[In the CK, <span class="ar">والمَتاعُ</span> is erroneously put for <span class="ar">وَالمَتَاعِ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bl_RQ1_A3">
					<p>And <em>He divided,</em> or <em>disunited,</em> opinions. <span class="auth">(Fr, T, Ḳ; but only the inf. n. of the verb in this sense is mentioned.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bl_RQ1_A4">
					<p>And <em>He</em> <span class="auth">(God)</span> <span class="add">[<em>mixed</em> or <em>confounded</em> or]</span> <em>made discordant</em> the tongues, or languages, of a people. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bl_RQ1_A5">
					<p><span class="add">[<a href="#balobalapN">See also <span class="ar">بَلْبَلَةٌ</span> below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bl_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تبلبل</span></h3>
				<div class="sense" id="bl_RQ2_A1">
					<p><span class="ar">تَبَلْبَلَ</span> <em>He</em> <span class="auth">(a man)</span> <em>was moved by grief</em> <span class="add">[or <em>anxiety:</em> <a href="#balobalapN">see <span class="ar">بَلْبَلَةٌ</span>, below</a>]</span>. <span class="auth">(Ḥar p. 94.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: R. Q. 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bl_RQ2_A2">
					<p><span class="ar long">تَبَلْبَلَتِ الأَلْسُنُ</span> <em>The tongues,</em> or <em>languages, became mixed,</em> or <em>confounded.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: R. Q. 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bl_RQ2_B1">
					<p><span class="ar long">تَبَلْبَلَتِ الإِبِلُ الكَلَأَ</span> <em>The camels went on seeking the herbage,</em> or <em>pasture, and left not of it aught.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balo">
				<h3 class="entry"><span class="ar">بَلْ</span></h3>
				<div class="sense" id="balo_A1">
					<p><span class="ar">بَلْ</span> is a particle of digression: <span class="auth">(Mughnee, Ḳ:)</span> or, accord. to Mbr, it denotes emendation, wherever it occurs, in the case of a negation or an affirmation: <span class="auth">(T, TA:)</span> or it is a word of emendation, and denoting digression from that which precedes; as also <span class="ar">بَنْ</span>, in which the <span class="ar">ن</span> is a substitute for the <span class="ar">ل</span>, because <span class="ar">بل</span> is of frequent occurrence, and <span class="ar">بن</span> is rare; or, as IJ says, the latter may be an independent dial. var. <span class="auth">(M.)</span> When it is followed by a proposition, the meaning of the digression is either the cancelling of what precedes, as in <span class="ar long">وَقَالُوا ٱتَّخَذَ ٱلرَّحْمٰنُ وَلَدًا سُبْحَانَهُ بَلْ عِبَادٌ مُكْرَمُونَ</span> <span class="add">[<em>And they said, “The Compassionate hath gotten offspring:” extolled be his freedom from that which is derogatory from his glory! nay,</em> or <em>nay rather,</em> or <em>nay but,</em> they are <em>honoured servants</em> <span class="auth">(Ḳur xxi. 26)</span>]</span>, or transition from one object of discourse to another, as in <span class="ar long">قَدْ أَفْلَحَ مَنْ تَزَكَّى وَذَكَرَ ٱسْمَ رَبِّهِ فَصَلَّى بَلْ تُؤْثِرُونَ ٱلْحَيَاةَ ٱلدُّنْيَا</span> <span class="add">[<em>He hath attained felicity who hath purified himself, and celebrated the name of his Lord, and prayed: but ye prefer the present life</em> <span class="auth">(Ḳur lxxxvii. 14-16)</span>]</span>: <span class="auth">(Mughnee, Ḳ:*)</span> and in all such cases it is an inceptive particle; not a conjunctive. <span class="auth">(Mughnee.)</span> When it is followed by a single word, it is a conjunction, <span class="auth">(Ṣ,* Mṣb,* Mughnee, Ḳ,)</span> and requires that word to be in the same case as the word before it: <span class="auth">(Ṣ:)</span> and if preceded by a command or an affirmation, <span class="auth">(Mughnee, Ḳ,)</span> as in <span class="ar long">اِضْرَبْ زَيْدًا بَلْ عَمْرًا</span> <span class="add">[<em>Beat thou Zeyd: no, ʼAmr</em>]</span>, <span class="auth">(Mṣb, Mughnee, Ḳ,)</span> and <span class="ar long">قَامَ زَيْدٌ بَلْ عَمْرٌو</span> <span class="add">[<em>Zeyd stood: no, ʼAmr</em>]</span>, <span class="auth">(M, Mughnee, Ḳ,)</span> or <span class="ar long">جَآءَنِى أَخُوكَ بَلْ أَبُوكَ</span> <span class="add">[<em>Thy brother came to me: no, thy father</em>]</span>, <span class="auth">(Ṣ,)</span> it makes what precedes it to be as though nothing were said respecting it, <span class="auth">(Ṣ,* Mṣb,* Mughnee, Ḳ,)</span> making the command or affirmation to relate to what follows it: <span class="auth">(Ṣ,* Mṣb,* Mughnee:)</span> <span class="add">[and similar to these cases is the case in which it is preceded by an interrogation: <a href="#Oamo">see <span class="ar">أَمْ</span></a> as syn. with this particle:]</span> but when it is preceded by a negation or a prohibition, it is used to confirm the meaning of what precedes it and to assign the contrary of that meaning to what follows it, <span class="auth">(Mughnee, Ḳ,)</span> as in <span class="ar long">مَا قَامَ زَيْدٌ عَمْرٌو</span> <span class="add">[<em>Zeyd stood not, but ʼAmr stood</em>]</span>, <span class="auth">(Mughnee,)</span> or <span class="ar long">مَا رَأَيْتُ زَيْدًا بَلْ عَمْرًا</span>, <span class="add">[<em>I saw not Zeyd, but I saw ʼAmr</em>]</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">لَا يَقُمْ زَيْدٌ بَلْ عَمْرٌو</span> <span class="add">[<em>Let not Zeyd stand, but</em> let ʼAmr stand]</span>. <span class="auth">(Mughnee.)</span> Mbr and ʼAbd-El-Wárith allow its being used to transfer the meaning of the negation and the prohibition to what follows it; so that, accord. to them, one may say, <span class="ar long">مَازَيْدٌ قَائِمًا بَلْ قَاعِدًا</span> <span class="add">[as meaning <em>Zeyd is not standing: no,</em> is not <em>sitting</em>]</span>, and <span class="ar long">بَلْ قَاعِدٌ</span> <span class="add">[<em>but is sitting</em>]</span>; the meaning being different <span class="add">[in the two cases]</span>. <span class="auth">(Mughnee, Ḳ.*)</span> The Koofees disallow its being used as a conjunction after anything but a negation <span class="add">[so in the Mughnee, but in the Ḳ a prohibition,]</span> or the like thereof; so that one should not say, <span class="ar long">ضَرَبْتُ زَيْدًا بَلْ إِيَّاكَ</span> <span class="add">[<em>I beat Zeyd: no, thee</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span> Sometimes <span class="ar">لَا</span> is added before it, to corroborate the meaning of digression, after an affirmation, as in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَجْهُكَ البَدْرُ لَا بَلِ الشَّمْسُ لَوْ لَمْ</span> *</div> 
						<div class="star">* <span class="ar long">يُقْضَ لِلشَّمْسِ كَسْفَةٌ وَأُفُولُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Thy face is the full moon: no, but it would be the sun, were it not that eclipse and setting are appointed to happen to the sun</em>]</span>: and to corroborate what precedes it, after a negation, as in</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمَا هَجَرْتُكَ لَا بَلْ زَادَنِى شَغَفًا</span> *</div> 
						<div class="star">* <span class="ar long">هَجْرٌ وَبَعْدٌ تَرَاخَى لَا إِلَى أَجَلِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And I did not abandon thee,</em> or <em>have not abandoned thee: no, but abandonment and distance, protracted, not to an appointed period, increased,</em> or <em>have increased, my heart-felt love</em>]</span>. <span class="auth">(Mughnee, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balo_A2">
					<p>Sometimes it is used to denote the passing from one subject to another without cancelling <span class="add">[what precedes it]</span>, and is <em>syn. with</em> <span class="ar">وَ</span>, as in the saying in the Ḳur <span class="add">[lxxxv. 20 and 21]</span>, <span class="ar long">وَٱللّٰهُ مِنْ وَرَائِهِمْ مُحِيطٌ بَلْ هُوَ قُرْآنٌ مَجِيدٌ</span> <span class="add">[<em>And God from behind them is encompassing: and it is a glorious Ḳur-án:</em> or here it may mean <span class="ar">إِنَّ</span>, as in an ex. below]</span>: and to this meaning it is made to accord in the saying, <span class="ar long">لَهُ عَلَىَّ دِينَارٌ بَلْ دِرْهَمٌ</span> <span class="add">[<em>I owe him a deenár and a dirhem</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<span class="pb" id="Page_0244"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balo_A3">
					<p>In the following saying in the Ḳur <span class="add">[xxxviii. 1]</span>, <span class="ar long">وَٱلْقُرْآنِ ذِى ٱلذِّكْرِبَلِ ٱلَّذِينَ كَفَرُوا فِى عِزَّةٍ وَشِقَاقٍ</span>, it is said to signify <span class="ar">إِنَّ</span>; <span class="add">[so that the meaning is, <em>By the Ḳur-án possessed of eminence, verily they who have disbelieved are in a state of pride and opposition;</em>]</span> therefore the oath applies to it. <span class="auth">(Akh, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balo_A4">
					<p>Sometimes the Arabs use it in breaking off a saying and commencing another; and thus a man commences with it a citation, or recitation, of verse; in which case, it does not form any part of the first verse, but is a sign of the breaking off, or ending, of what precedes. <span class="auth">(Akh, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="balo_A5">
					<p>Sometimes it is put in the place of <span class="ar">رُبَّ</span>, <span class="auth">(Ṣ, Mughnee,)</span> as in the saying of the rájiz,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَلْ مَهْمَهٍ قَطَعْتُ بَعْدَ مَهْمَهٍ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Many a far-extending desert have I traversed, after a far-extending desert</em>]</span>. <span class="auth">(Ṣ: <span class="add">[and a similar ex. is given in the Mughnee.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="balo_A6">
					<p>What is deficient in this word <span class="add">[supposing it to be originally of three letters]</span> is unknown; and so in the cases of <span class="ar">هَلْ</span> and <span class="ar">قَدْ</span>: it may be a final <span class="ar">و</span> or <span class="ar">ى</span> or they may be originally <span class="ar">بَلّ</span> and <span class="ar">هَلّ</span> and <span class="ar">قَدّ</span>. <span class="auth">(Akh, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balBN">
				<h3 class="entry"><span class="ar">بَلٌّ</span></h3>
				<div class="sense" id="balBN_A1">
					<p><span class="add">[<span class="ar">بَلٌّ</span> <em>Moist,</em> or <em>containing moisture:</em> or rather <em>moistened;</em> being, app., an inf. n. used in the sense of a pass. part. n.; like <span class="ar">خَلْقٌ</span> in the sense of <span class="ar">مَخْلُوقٌ</span>. Hence,]</span> <span class="ar long">رِيحٌ بَلَّةٌ</span> and↓<span class="ar">بَلِيلٌ</span> and↓<span class="ar">بَلِيلَةٌ</span> <em>A wind in which is moisture:</em> <span class="auth">(Ṣ:)</span> or the last, <em>a wind mixed with feeble rain:</em> <span class="auth">(T:)</span> and the second, <em>a wind cold with moisture;</em> <span class="auth">(M, Ḳ;)</span> or the same, <em>a wind cold with rain;</em> <span class="auth">(A, TA;)</span> the <em>north wind,</em> as though it sprinkled water by reason of its coldness: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">بَلَلٌ↓</span></span> also signifies <em>a cold north wind:</em> <span class="auth">(Ibn-ʼAbbád, TA:)</span> <span class="ar">بَلِيلٌ</span> is used alike as sing. and pl.: <span class="auth">(Ḳ:)</span> it has no pl. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="balBN_B1">
					<p><span class="ar long">بَلٌّ بِشَىْءٍ</span> A man <span class="auth">(M)</span> <em>devoted,</em> or <em>attached, to a thing, and keeping to it constantly.</em> <span class="auth">(M, Ḳ. <span class="add">[In the CK and in my MṢ. copy of the Ḳ, <span class="ar">اللَّهْجُ</span> is erroneously put for <span class="ar">اللَّهِجُ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="balBN_B2">
					<p>And <span class="ar">بَلٌّ</span>, alone, <em>Much given to the deferring of payment to his creditors, by repeated promises;</em> <span class="auth">(T;)</span> <em>withholding, by swearing, what he possesses of things that are the rightful property of others.</em> <span class="auth">(IAạr, T, Ḳ.)</span> <a href="#OabalBN">See also <span class="ar">أَبَلٌّ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilBN">
				<h3 class="entry"><span class="ar">بِلٌّ</span></h3>
				<div class="sense" id="bilBN_A1">
					<p><span class="ar">بِلٌّ</span> <em>Allowable,</em> or <em>lawful; i. e., to be taken,</em> or <em>let alone,</em> or <em>done,</em> or <em>made use of,</em> or <em>possessed:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> so in the dial. of Himyer: <span class="auth">(T, Ṣ. M:)</span> or <em>a remedy;</em> <span class="auth">(AʼObeyd, T, Ṣ, M, Ḳ;)</span> from the phrase <span class="ar long">بَلَّ مِنْ مَرَضِهِ</span> <span class="add">[q. v.]</span>: <span class="auth">(A' Obeyd, T, Ṣ, M:)</span> or it is an imitative sequent to <span class="ar">حِلٌّ</span>, <span class="auth">(M, Ḳ,)</span> as some say: <span class="auth">(M:)</span> so Aṣ thought until he heard that it was said to be of the dial. of Himyer in the first of the senses explained above: <span class="auth">(Ṣ, M:)</span> AʼObeyd and ISk say that it may not be so because it is conjoined with <span class="ar">حِلٌّ</span> by <span class="ar">وَ</span>: <span class="auth">(T:)</span> and AʼObeyd says, We have seldom found an imitative sequent conjoined by <span class="ar">و</span>. <span class="auth">(TA.)</span> Hence the phrase, <span class="ar long">هُوَ لَكَ حِلٌّ وَبِلٌّ</span> <em>It is to thee lawful and allowable:</em> or <em>lawful and a remedy.</em> <span class="auth">(M, Ḳ.*)</span> And hence the saying of El-ʼAbbás the son of ʼAbd-El-Muttalib, respecting <span class="add">[the well of]</span> Zemzem, <span class="ar long">هِىَ لِشَارِبٍ حِلٌّ وَبِلٌّ</span> <em>It is to a drinker lawful, &amp;c.</em> <span class="auth">(T, Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balBapN">
				<h3 class="entry"><span class="ar">بَلَّةٌ</span></h3>
				<div class="sense" id="balBapN_A1">
					<p><span class="ar">بَلَّةٌ</span> <span class="add">[<em>A single act of moistening.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balBapN_A2">
					<p><span class="add">[And hence,]</span> The <em>least sprinkling</em> (<span class="ar long">أَدْنَى بَلَلٍ</span> lit. the <em>least moisture</em>) <em>of good.</em> <span class="auth">(TA in art. <span class="ar">هل</span>.)</span> You say, <span class="ar long">جَآءَنَا فُلَانٌ فَلَمْ يَأْتِنَا بِهَلَّةٍ وَلَا بَلَّةٍ</span> <span class="add">[<em>Such a one came to us and did not bring us anything to rejoice us nor the least sprinkling of good</em>]</span>: <span class="ar">هلّة</span>, accord. to ISK, being from <span class="ar">الفَرَحُ</span> and <span class="ar">الاِسْتِهْلَالُ</span>, and <span class="ar">بلّة</span> from <span class="ar">البَلْلُ</span> and <span class="ar">الخَيْرُ</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">مَا أَصَابَ هَلَّةً وَلَا بَلَّةً</span> <em>He did not obtain,</em> or <em>has not obtained, anything.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balBapN_A3">
					<p><em>Wealth,</em> or <em>competence:</em> <span class="auth">(Fr, TA:)</span> or <em>wealth,</em> or <em>competence, after poverty;</em> <span class="auth">(Fr, T, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">بُلَّى↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balBapN_A4">
					<p><em>Remains of herbage</em> or <em>pasture;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">بُلَّةٌ↓</span></span>. <span class="auth">(Fr, T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="balBapN_A5">
					<p>The <em>freshness</em> of youth; as also<span class="arrow"><span class="ar">بُلَّةٌ↓</span></span>; <span class="auth">(M, Ḳ;*)</span> but the former word is the more approved. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="balBapN_A6">
					<p>See also an ex. voce <span class="ar">بَلَلٌ</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulBapN">
				<h3 class="entry"><span class="ar">بُلَّةٌ</span></h3>
				<div class="sense" id="bulBapN_A1">
					<p><span class="ar">بُلَّةٌ</span>: <a href="#balalN">see <span class="ar">بَلَلٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulBapN_A2">
					<p><a href="#balBapN">and see also <span class="ar">بَلَّةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bulBapN_A3">
					<p>Also <em>A state of moisture.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bulBapN_A4">
					<p>The <em>moisture of fresh pasture.</em> <span class="auth">(Ṣ, M, Ḳ.)</span> The <em>rájiz</em> <span class="auth">(Iháb Ibn-<em>ʼOmeyr,</em> TA)</span> says, describing <span class="add">[wild]</span> asses,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حَتَّى إِذَا أَهْرَأْنَ بِالأَصَائِلِ</span> *</div> 
						<div class="star">* <span class="ar long">وَفَارَقَتْهَا بُلَّةُ الأَوَابِلِ</span> *</div> 
					</blockquote>
					<p>meaning that they went in the cool of the evening to the water after that the herbage had dried up: <span class="ar">الاوابل</span> means the wild animals that are satisfied with green pasture, so as to be in no need of water. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilBapN">
				<h3 class="entry"><span class="ar">بِلَّةٌ</span></h3>
				<div class="sense" id="bilBapN_A1">
					<p><span class="ar">بِلَّةٌ</span>: <a href="#balalN">see <span class="ar">بَلَلٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bilBapN_A2">
					<p>Also <em>Good, good fortune, prosperity,</em> or <em>wealth:</em> and <em>sustenance,</em> or <em>means of subsistence.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bilBapN_A3">
					<p><em>Health; soundness;</em> or <em>freedom from disease.</em> <span class="auth">(T, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bilBapN_A4">
					<p><em>A repast prepared on the occasion of a wedding,</em> or <em>on any occasion.</em> <span class="auth">(Fr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bilBapN_A5">
					<p>‡ The tongue's <em>fluency, and chasteness of speech:</em> <span class="auth">(Ḳ, TA:)</span> or its <em>readiness of diction</em> or <em>expression, and facility;</em> <span class="auth">(M;)</span> <em>and</em> <span class="add">[so in the M, but in the Ḳ “or,”]</span> <em>its falling upon the</em> <span class="add">[<em>right</em>]</span> <em>places of utterance of the letters,</em> <span class="auth">(T, M, A, Ḳ,)</span> <em>and its regular and uniform continuance of speech,</em> <span class="auth">(T, M, Ḳ,)</span> <em>and its facility.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">مَا أَحْسَنٌ بِلَّةَ لِسَانِهِ</span> ‡ <span class="add">[<em>How good is the fluency, &amp;c., of his tongue!</em>]</span>. <span class="auth">(T, M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balalN">
				<h3 class="entry"><span class="ar">بَلَلٌ</span></h3>
				<div class="sense" id="balalN_A1">
					<p><span class="ar">بَلَلٌ</span> <em>Moisture;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بِلَّةٌ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">بِلَالٌ↓</span></span> and<span class="arrow"><span class="ar">بُلَالَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <span class="add">[and several other dial. vars. occurring in phrases in this paragraph]</span>: or<span class="arrow"><span class="ar">بِلَّةٌ↓</span></span> signifies <em>an inferior,</em> or <em>inconsiderable, degree of moisture;</em> <span class="auth">(Lth, T, Ḳ; <span class="add">[an ambiguity in the Ḳ in this place has occasioned several mistakes in Freytag's Lex. voce <span class="ar">بَلَلٌ</span>;]</span>)</span> and<span class="arrow"><span class="ar">بِلَالٌ↓</span></span> is an anomalous pl. of this word; <span class="auth">(M, TA;)</span> and is pl. also of<span class="arrow"><span class="ar">بُلَّةٌ↓</span></span>: <span class="auth">(Ṣ, TA:)</span> and <span class="ar">بُلَّانٌ</span>, occurring in a verse cited above (<a href="#bl_1">see 1</a>) may be <a href="#balalN">pl. of <span class="ar">بَلَلٌ</span></a>. <span class="auth">(M.)</span> <span class="add">[Using syns. of <span class="ar">بَلَلٌ</span> in the sense explained above,]</span> you say,<span class="arrow"><span class="ar long">طَوَيْتُ السِّقَآءَ عَلَى بُلُلَتِهِ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بُلَلَتِهِ↓</span></span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">بَلَلَتِهِ↓</span></span>, <span class="auth">(T, M,)</span> <em>I folded the skin while it was moist,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> before it should break in pieces, <span class="auth">(T,)</span> or lest it should break in pieces. <span class="auth">(M.)</span> And <span class="add">[hence,]</span><span class="arrow"><span class="ar long">طَوَيْتُ فُلَانًا عَلَى بُلُلَتِهِ↓</span></span>, <span class="auth">(T,*S, M,*K,*)</span> and<span class="arrow"><span class="ar">بُلَلَتِهِ↓</span></span>, <span class="auth">(T, Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَلَلَتِهِ↓</span></span>, and<span class="arrow"><span class="ar">بُلَالَتِهِ↓</span></span>, and<span class="arrow"><span class="ar">بَلَالَتِهِ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بُلَّتِهِ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَلَّتِهِ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بُلَاتِهِ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">بَلَاتِهِ↓</span></span>, <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">بُلُولَتِهِ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> which is of the dial. of Temeem, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بُلُولِهِ↓</span></span>, <span class="auth">(Ḳ,)</span> ‡ <em>I bore with, suffered,</em> or <em>tolerated, such a one,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>notwithstanding his vice,</em> or <em>fault,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> <em>and evil conduct:</em> <span class="auth">(Ṣ:)</span> or <span class="add">[so in the M and Ḳ, but in the Ṣ “and,”]</span> <em>I treated him with gentleness,</em> or <em>blandishment,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>while some love,</em> or <em>affection, remained in him;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> and this is the true meaning; <span class="auth">(M;)</span> and in like manner,<span class="arrow"><span class="ar long">عَلَى بِلَالٌ↓ نَفْسِهِ</span></span>. <span class="auth">(Ṣ, TA.)</span> And<span class="arrow"><span class="ar long">طَوَاهُ عَلَى بِلَالِهِ↓</span></span>, and<span class="arrow"><span class="ar">بُلُولِهِ↓</span></span>, ‡ <em>He feigned himself heedless of,</em> or <em>inattentive to, his vice,</em> or <em>fault;</em> like as one folds a skin upon its fault <span class="add">[to conceal that fault]</span>. <span class="auth">(T.)</span> And<span class="arrow"><span class="ar long">اِنْصَرَفَ القَوْمَ بِبَلَلَتِهِمْ↓</span></span>, and<span class="arrow"><span class="ar">بِبُلُلَتِهِمْ↓</span></span>, and<span class="arrow"><span class="ar">بِبُلُولَتِهِمْ↓</span></span>, † <em>The people,</em> or <em>company of men, turned away,</em> or <em>back, having some good,</em> or <em>somewhat good, remaining, in them,</em> or <em>among them;</em> expl. by <span class="ar long">وَفِيهِمْ بَقِيَّةٌ</span> <span class="add">[in which the last word generally implies something good; as, for instance, in the Ḳur xi. 118]</span>: <span class="auth">(M, Ḳ:)</span> or, <em>in a good state,</em> or <em>condition:</em> <span class="auth">(Ḳ:)</span> or this latter is meant when one says, <span class="ar">بِبُلُلَتِهِمْ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balalN_A2">
					<p><em>Abundance of herbage;</em> or <em>of the goods, conveniences,</em> or <em>comforts, of life.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="balalN_A3">
					<p><a href="#balBN">See also <span class="ar">بَلٌّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="balalN_A4">
					<p><span class="ar long">مَا أَحْسَنَ بَلَلَهُ</span> <em>How good is his adornment of himself!</em> or <em>his manner of undertaking a task,</em> or <em>taking upon himself a responsibility!</em> <span class="auth">(Ḳ: expl. in some copies by <span class="ar">تَجَمُّلَهُ</span>; and so in the TA: in others by <span class="ar">تَحَمُّلَهُ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulalN">
				<h3 class="entry"><span class="ar">بُلَلٌ</span></h3>
				<div class="sense" id="bulalN_A1">
					<p><span class="ar">بُلَلٌ</span>, like <span class="ar">صُرَدٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">بُلُلٌ</span>, <span class="auth">(so in a copy of the T, accord. to the TT,)</span> <em>Seed; grain for sowing.</em> <span class="auth">(ISh, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balalapN">
				<h3 class="entry"><span class="ar">بَلَلَةٌ</span></h3>
				<div class="sense" id="balalapN_A1">
					<p><span class="ar">بَلَلَةٌ</span> and its pl.: <a href="#balalN">see four exs. voce <span class="ar">بَلَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulalapN">
				<h3 class="entry"><span class="ar">بُلَلَةٌ</span></h3>
				<div class="sense" id="bulalapN_A1">
					<p><span class="ar">بُلَلَةٌ</span> and its pl.: see three exs. voce <span class="ar">بَلَلٌ</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulalapN_A2">
					<p>The sing. also signifies <em>Garb, guise, aspect</em> or <em>appearance, external state</em> or <em>condition.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> You say, <span class="ar long">إِنَّهُ لَحَسَنُ البُلَلَةِ</span> <em>Verily he is goodly,</em> or <em>beautiful, in garb, &amp;c.</em> <span class="auth">(Ibn-ʼAbbád, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bulalapN_A3">
					<p>You say also, <span class="ar long">كَيْفَ بُلَلَتُكَ</span>, and<span class="arrow"><span class="ar">بُلُولَتُكَ↓</span></span>, meaning <em>How is thy state,</em> or <em>condition?</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bululapN">
				<h3 class="entry"><span class="ar">بُلُلَةٌ</span></h3>
				<div class="sense" id="bululapN_A1">
					<p><span class="ar">بُلُلَةٌ</span>: <a href="#balalN">see three exs. voce <span class="ar">بَلَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balaAli">
				<h3 class="entry"><span class="ar">بَلَالِ</span></h3>
				<div class="sense" id="balaAli_A1">
					<p><span class="ar">بَلَالِ</span> a subst. signifying <em>The making close the ties of relationship by behaving with goodness and affection and gentleness to one's kindred:</em> <span class="auth">(Ḳ:)</span> changed in form from <span class="ar">بَالَةٌ</span>; q. v. <span class="auth">(TA.)</span> <span class="add">[<a href="#bilaAlN">See also <span class="ar">بِلَالٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balaAlN">
				<h3 class="entry"><span class="ar">بَلَالٌ</span></h3>
				<div class="sense" id="balaAlN_A1">
					<p><span class="ar">بَلَالٌ</span>: <a href="#bilaAlN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulaAlN">
				<h3 class="entry"><span class="ar">بُلَالٌ</span></h3>
				<div class="sense" id="bulaAlN_A1">
					<p><span class="ar">بُلَالٌ</span>: <a href="#bilaAlN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bilaAlN">
				<h3 class="entry"><span class="ar">بِلَالٌ</span></h3>
				<div class="sense" id="bilaAlN_A1">
					<p><span class="ar">بِلَالٌ</span>: <a href="#balalN">see <span class="ar">بَلَلٌ</span></a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bilaAlN_A2">
					<p>Also <em>Water;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> and so<span class="arrow"><span class="ar">بُلَالٌ↓</span></span> and<span class="arrow"><span class="ar">بَلَالٌ↓</span></span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">مَا فِى سِقَائِهِ بِلَالٌ</span> <em>There is not in his skin any water:</em> <span class="auth">(T, Ṣ:)</span> or <em>anything whatever:</em> <span class="auth">(so in a copy of the Ṣ:)</span> and in like manner one says of a well. <span class="auth">(T.)</span> <span class="pb" id="Page_0245"></span>And<span class="arrow"><span class="ar long">مَا فِى البِئْرِ بَالُولٌ↓</span></span> <em>There is not any water in the well.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bilaAlN_A3">
					<p>And <em>Anything with which one moistens the fauces, of water or of milk:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> such is said to be its meaning. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بِلَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bilaAlN_A4">
					<p>And hence the saying, <span class="ar long">اِنْضَحُوا الرَّحِمَ بِبَلَالِهَا</span>, i. e. <span class="ar long">صِلُوهَا بِصِلَتِهَا</span> <span class="add">[<em>Make ye close the ties of relationship by behaving with that goodness and affection and gentleness to kindred which those ties require:</em> <a href="#balBa">see <span class="ar long">بَلَّ رَحِمَهُ</span></a>; <a href="#balaAli">and see also <span class="ar">بَلَالِ</span></a>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buluwlN">
				<h3 class="entry"><span class="ar">بُلُولٌ</span></h3>
				<div class="sense" id="buluwlN_A1">
					<p><span class="ar">بُلُولٌ</span>: <a href="#balalN">see two exs. voce <span class="ar">بَلَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baliylN">
				<h3 class="entry"><span class="ar">بَلِيلٌ</span></h3>
				<div class="sense" id="baliylN_A1">
					<p><span class="ar">بَلِيلٌ</span>: <a href="#balBN">see <span class="ar">بَلٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balaAlapN">
				<h3 class="entry"><span class="ar">بَلَالَةٌ</span></h3>
				<div class="sense" id="balaAlapN_A1">
					<p><span class="ar">بَلَالَةٌ</span>: <a href="#balalN">see an ex. voce <span class="ar">بَلَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulaAlapN">
				<h3 class="entry"><span class="ar">بُلَالَةٌ</span></h3>
				<div class="sense" id="bulaAlapN_A1">
					<p><span class="ar">بُلَالَةٌ</span>: <a href="#balalN">see <span class="ar">بَلَلٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulaAlapN_A2">
					<p>Also The <em>quantity with which a thing is moistened.</em> <span class="auth">(Ḥar p. 107.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bulaAlapN_A3">
					<p>And <em>A remain,</em> or <em>remainder;</em> <span class="auth">(T, and Ḥar ubi suprá;)</span> as also <span class="ar">عُلُالَةٌ</span>. <span class="auth">(Ḥar ubi suprá.)</span> You say, <span class="ar long">مَا فِيهِ بُلَالَةٌ وَلَا عُلَالَةٌ</span> <em>There is not in it anything remaining.</em> <span class="auth">(T, and Ḥar ubi suprá.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buluwlapN">
				<h3 class="entry"><span class="ar">بُلُولَةٌ</span></h3>
				<div class="sense" id="buluwlapN_A1">
					<p><span class="ar">بُلُولَةٌ</span>: <a href="#balalN">see two exs. voce <span class="ar">بَلَلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلُولَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buluwlapN_A2">
					<p><a href="#bulalapN">and see an ex. voce <span class="ar">بُلَلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baliylapN">
				<h3 class="entry"><span class="ar">بَلِيلَةٌ</span></h3>
				<div class="sense" id="baliylapN_A1">
					<p><span class="ar">بَلِيلَةٌ</span>: <a href="#balBN">see <span class="ar">بَلٌّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baliylapN_A2">
					<p>Also <em>Wheat boiled in water,</em> <span class="add">[in the present day, <em>with clarified butter, and honey,</em>]</span> <em>and eaten.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلِيلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baliylapN_B1">
					<p>And <em>i. q.</em> <span class="ar">صِحَّةٌ</span> <span class="add">[<em>Health,</em> or <em>soundness, &amp;c.</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulBae">
				<h3 class="entry"><span class="ar">بُلَّى</span></h3>
				<div class="sense" id="bulBae_A1">
					<p><span class="ar">بُلَّى</span>: <a href="#balBapN">see <span class="ar">بَلَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balBaAnN">
				<h3 class="entry"><span class="ar">بَلَّانٌ</span></h3>
				<div class="sense" id="balBaAnN_A1">
					<p><span class="ar">بَلَّانٌ</span> <em>A hot bath:</em> <span class="auth">(Ḳ:)</span> the <span class="ar">ا</span> and <span class="ar">ن</span> are augmentative: for the hot bath is thus called because he who enters it is moistened by its water or by his sweat: <span class="auth">(TA:)</span> pl. <span class="ar">بَلَّانَاتٌ</span>, <span class="auth">(Ḳ,)</span> occurring in a trad., and said by IAth to be originally <span class="ar">بَلَّالَاتٌ</span>. <span class="auth">(TA in art. <span class="ar">بلن</span>; in which, as well as in the present art., it is mentioned in the Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلَّانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balBaAnN_A2">
					<p>It is now applied to <em>A man who serves</em> <span class="add">[<em>the bathers, by washing them, &amp;c.,</em>]</span> <em> in the hot bath:</em> <span class="add">[fem. with <span class="ar">ة</span>:]</span> but this is a vulgar application of the word. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulBaAnN">
				<h3 class="entry"><span class="ar">بُلَّانٌ</span></h3>
				<div class="sense" id="bulBaAnN_A1">
					<p><span class="ar">بُلَّانٌ</span>: <a href="#bl_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulobulN">
				<h3 class="entry"><span class="ar">بُلْبُلٌ</span></h3>
				<div class="sense" id="bulobulN_A1">
					<p><span class="ar">بُلْبُلٌ</span> <span class="add">[The <em>nightingale:</em> and <em>a certain melodious bird resembling the nightingale:</em> both, in the present day, vulgarly called <span class="ar">بِلْبِل</span>:]</span> the <span class="ar">عَنْدَلِيب</span> <span class="add">[q. v.]</span>: and the <span class="ar">كُعَيْت</span> <span class="add">[q. v.]</span>: <span class="auth">(T:)</span> <em>a certain bird,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>well known,</em> <span class="auth">(Ḳ,)</span> <em>of beautiful voice, that frequents the Haram</em> <span class="add">[or <em>Sacred Territory of Mekkeh</em>]</span>, <em>and is called by the people of El-Ḥijáz the</em> <span class="ar">نُغَر</span> <span class="add">[q. v.]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلْبُلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulobulN_A2">
					<p>A man <em>light,</em> or <em>active:</em> <span class="auth">(Ṣ:)</span> or <em>clever, well-mannered,</em> or <em>elegant, and light,</em> or <em>active:</em> <span class="auth">(T:)</span> or a man <span class="auth">(M)</span> <em>light,</em> or <em>active, in journeying, and very helpful;</em> <span class="auth">(M, Ḳ;)</span> and so<span class="arrow"><span class="ar">بُلَابِلٌ↓</span></span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">بُلْبُلِىُّ↓</span></span>: <span class="auth">(Ḳ:)</span> or, accord. to Th, a boy <em>light,</em> or <em>active, in journeying:</em> <span class="auth">(M:)</span> and a man <em>light,</em> or <em>active in that which he sets about;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بُلَابِلٌ↓</span></span>; <span class="auth">(Ḳ;)</span> or this last signifies a man <em>active in intellect, to whom nothing is unapparent:</em> <span class="auth">(T:)</span> pl. of the first, <span class="auth">(Ṣ,)</span> and of the last, <span class="auth">(Ḳ,)</span> <span class="ar">بَلَابِلُ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلْبُلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bulobulN_B1">
					<p><em>A certain fish, of the size of the hand.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلْبُلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bulobulN_C1">
					<p>The spout (<span class="ar">قَنَاة</span>) of a mug (<span class="ar">كُوز</span>), <em>that pours forth the water.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balobalapN">
				<h3 class="entry"><span class="ar">بَلْبَلَةٌ</span></h3>
				<div class="sense" id="balobalapN_A1">
					<p><span class="ar">بَلْبَلَةٌ</span> <a href="#bl_RQ1">inf. n. of <span class="ar">بَلْبَلَ</span> <span class="add">[q. v.]</span></a>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْبَلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="balobalapN_B1">
					<p><em>A state of confusion,</em> or <em>mixture, of tongues,</em> or <em>languages.</em> <span class="auth">(M, Ḳ.*)</span> In the copies of the Ḳ, <span class="ar">الأَسِنَّة</span> is here erroneously put for <span class="ar">الأَلْسِنَة</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="balobalapN_B2">
					<p>Also, and<span class="arrow"><span class="ar">بَلْبَالٌ↓</span></span>, The <em>vain,</em> or <em>unprofitable,</em> or <em>evil, suggestion of anxieties in the bosom:</em> <span class="auth">(T:)</span> or <em>anxiety, and vain,</em> or <em>unprofitable,</em> or <em>evil, suggestion of the mind:</em> <span class="auth">(Ṣ:)</span> or <em>intense anxiety, and vain,</em> or <em>unprofitable,</em> or <em>evil, suggestions</em> or <em>thoughts;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بُلَابِلٌ↓</span></span>, <span class="auth">(so in the M, accord. to the TT,)</span> or<span class="arrow"><span class="ar">بَلَابِلُ↓</span></span>: <span class="auth">(so in copies of the Ḳ:)</span> this last <span class="add">[however]</span> is pl. of<span class="arrow"><span class="ar">بَلْبَالٌ↓</span></span>; <span class="auth">(T;)</span> which also signifies <em>vehement distress in the bosom;</em> <span class="auth">(M, Ḳ;)</span> and so does<span class="arrow"><span class="ar">بَلْبَالَةٌ↓</span></span>: <span class="auth">(IJ, M:)</span> or<span class="arrow"><span class="ar">بَلْبَالٌ↓</span></span> signifies <em>anxiety</em> and <em>grief:</em> and, as also <span class="ar">بَلْبَلَةٌ</span>, <em>a motion,</em> or <em>commotion, in the heart, arising from grief</em> or <em>love.</em> <span class="auth">(Ḥar p. 94.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulobulapN">
				<h3 class="entry"><span class="ar">بُلْبُلَةٌ</span></h3>
				<div class="sense" id="bulobulapN_A1">
					<p><span class="ar">بُلْبُلَةٌ</span> <em>A mug</em> (<span class="ar">كُوز</span>) <em>having a spout</em> (<span class="ar">بُلْبُل</span>) <em>by the side of its head,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>from which the water pours forth:</em> <span class="auth">(TA:)</span> or <em>a ewer, as long as it contains wine.</em> <span class="auth">(Kull p. 102.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulobuliyBN">
				<h3 class="entry"><span class="ar">بُلْبُلِيٌّ</span></h3>
				<div class="sense" id="bulobuliyBN_A1">
					<p><span class="ar">بُلْبُلِيٌّ</span>: <a href="#bulobulN">see <span class="ar">بُلْبُلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balobaAlN">
				<h3 class="entry"><span class="ar">بَلْبَالٌ</span></h3>
				<div class="sense" id="balobaAlN_A1">
					<p><span class="ar">بَلْبَالٌ</span>: <a href="#balobalapN">see <span class="ar">بَلْبَلَةٌ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَلْبَالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="balobaAlN_B1">
					<p>Also <em>A putting</em> people <em>in motion;</em> and <em>rousing,</em> or <em>exciting,</em> them: a subst. from R. Q. 1. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balobaAlapN">
				<h3 class="entry"><span class="ar">بَلْبَالَةٌ</span></h3>
				<div class="sense" id="balobaAlapN_A1">
					<p><span class="ar">بَلْبَالَةٌ</span>: <a href="#balobalapN">see <span class="ar">بَلْبَلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balaAbilN">
				<h3 class="entry"><span class="ar">بَلَابِلٌ</span></h3>
				<div class="sense" id="balaAbilN_A1">
					<p><span class="ar">بَلَابِلٌ</span>: <a href="#balobalapN">see <span class="ar">بَلْبَلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulaAbilN">
				<h3 class="entry"><span class="ar">بُلَابِلٌ</span></h3>
				<div class="sense" id="bulaAbilN_A1">
					<p><span class="ar">بُلَابِلٌ</span>: <a href="#bulobilN">see <span class="ar">بُلْبِلٌ</span></a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بُلَابِلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bulaAbilN_B1">
					<p><a href="#balobalapN">and see <span class="ar">بَلْبَلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAlBapN">
				<h3 class="entry"><span class="ar">بَالَّةٌ</span></h3>
				<div class="sense" id="baAlBapN_A1">
					<p><span class="ar">بَالَّةٌ</span> <span class="add">[properly <em>A thing that moistens.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">بَالَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAlBapN_A2">
					<p><span class="add">[And hence,]</span> ‡ <em>Bounty,</em> or <em>liberality;</em> or <em>a gift;</em> as also<span class="arrow"><span class="ar">بَلالِ↓</span></span>: <span class="auth">(T, Ṣ, TA:)</span> and both these words, <em>good,</em> or <em>benefit:</em> <span class="auth">(T, Ṣ, M, TA:)</span> so in a phrase mentioned above; <a href="#bl_1">see 1</a>: <span class="auth">(T, Ṣ, Ḳ:)</span> the latter word is changed in form the former. <span class="auth">(T.)</span> <span class="add">[<a href="#balaAli">See also <span class="ar">بَلَالِ</span> above</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAluwlN">
				<h3 class="entry"><span class="ar">بَالُولٌ</span></h3>
				<div class="sense" id="baAluwlN_A1">
					<p><span class="ar">بَالُولٌ</span>: <a href="#bilaAlN">see <span class="ar">بِلَالٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabalBN">
				<h3 class="entry"><span class="ar">أَبَلٌّ</span></h3>
				<div class="sense" id="OabalBN_A1">
					<p><span class="add">[<span class="ar">أَبَلٌّ</span> <em>More,</em> and <em>most, moist:</em> fem. <span class="ar">بَلَّآءُ</span>: and pl. <span class="ar">بُلٌّ</span>. Hence,]</span> <span class="ar long">الجَنُوبُ أَبَلُّ الرِّيَاحِ</span> <em>The south is the most moist of the winds.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">أَبَلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabalBN_A2">
					<p><span class="add">[Hence, also,]</span> <span class="ar long">مَا شَىْءٌ أَبَلَّ لِلْجِسْمِ مشنَ اللَّهْوِ</span> <em>Nothing is more healthful and suitable to the body than sport.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">أَبَلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OabalBN_A3">
					<p>And <span class="ar long">صَفَاةٌ بَلَّآءٌ</span> <em>A smooth stone</em> or <em>rock.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بل</span> - Entry: <span class="ar">أَبَلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OabalBN_A4">
					<p>And <span class="ar">أَبَلُّ</span>, applied to a man, <span class="auth">(T, Ṣ, &amp;c.,)</span> <em>Violent,</em> or <em>vehement, in contention, altercation,</em> or <em>dispute;</em> <span class="auth">(T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَلٌّ↓</span></span>: <span class="auth">(Ḳ:)</span> or <span class="auth">(M)</span> one <em>who has no sense of shame:</em> <span class="auth">(M, Ḳ:)</span> or <span class="auth">(TA)</span> one <em>who resists,</em> or <em>withstands,</em> <span class="auth">(Ḳ, TA,)</span> <em>and overcomes:</em> <span class="auth">(TA:)</span> or <span class="auth">(M)</span> <em>very mean,</em> <span class="auth">(M, Ḳ,)</span> <em>from whom that which he possesses cannot be obtained,</em> <span class="auth">(Ks, T, Ṣ, M, Ḳ,)</span> <em>by reason of his meanness;</em> <span class="auth">(Ks, T, Ṣ;)</span> and so <span class="ar">بَلَّآءُ</span> applied to a woman: <span class="auth">(Ks, Ṣ:)</span> or <em>mean,</em> <span class="auth">(TA,)</span> <em>much given to the deferring of payment to his creditors,</em> <span class="auth">(IAạr, M, Ḳ,)</span> <em>much given to swearing</em> <span class="auth">(T, Ṣ, Ḳ)</span> <em>and to wronging,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>withholding the rightful property of others;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَلٌّ↓</span></span> <span class="add">[q. v.]</span>: <span class="auth">(IAạr, M, <span class="add">[but referring only to what is given above on the authority of the former,]</span> K, <span class="add">[referring to the same and to what follows except the addition in the TA,]</span> and TA:)</span> or, <span class="auth">(Ṣ, M,)</span> accord. to AO, <span class="auth">(Ṣ,)</span> <em>i. q.</em> <span class="ar">فَاجِرُ</span> <span class="add">[i. e. <em>vicious, immoral, unrighteous,</em>, &amp;c.]</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> fem. <span class="ar">بَلَّآءُ</span>: <span class="auth">(M, Ḳ:)</span> and pl. <span class="ar">بُلُّ</span>: <span class="auth">(Ḳ:)</span> or it signifies one <em>who pursues his course at random, not caring for what he meets.</em> <span class="auth">(Ḥam p. 383.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubilBN">
				<h3 class="entry"><span class="ar">مُبِلٌّ</span></h3>
				<div class="sense" id="mubilBN_A1">
					<p><span class="ar">مُبِلٌّ</span> One <em>whose aiding thee to accomplish thy desire wearies thee.</em> <span class="auth">(AʼObeyd, T, Ḳ, TA. <span class="add">[In the CK, for <span class="ar long">مَنْ يَعْيِيكَ أَنْ يُتَابِعَكَ عَلَى مَا تُرِيدُ</span>, we find <span class="ar long">مَنْ يُعِينُكَ اَى يُتَابِعُكَ على ما تُرِيدُ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibalBN">
				<h3 class="entry"><span class="ar">مِبَلٌّ</span></h3>
				<div class="sense" id="mibalBN_A1">
					<p><span class="ar long">خَصْمٌ مِبَلٌّ</span> <em>A constant, firm,</em> or <em>steady, adversary in a contention, dispute,</em> or <em>litigation.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0242.pdf" target="pdf">
							<span>Lanes Lexicon Page 242</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0243.pdf" target="pdf">
							<span>Lanes Lexicon Page 243</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0244.pdf" target="pdf">
							<span>Lanes Lexicon Page 244</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0245.pdf" target="pdf">
							<span>Lanes Lexicon Page 245</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
