<article class="root" id="Root_bAbl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/003_bOb">بأب</a></span>
				<span class="ar">بابل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/005_bAbwnj">بابونج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baAbilieBN">
				<h3 class="entry"><span class="ar">بَابِلِىٌّ</span></h3>
				<div class="sense" id="baAbilieBN_A1">
					<p><span class="ar">بَابِلِىٌّ</span> <em>Of,</em> or <em>belonging to,</em> or <em>relating to,</em> <span class="ar">بَابِل</span> <span class="add">[i. e. <em>Babel</em>]</span>, <em>a place</em> <span class="add">[<em>well known</em>]</span> <em>in El-'Irák:</em> it is an epithet applied to enchantment, <span class="add">[which is said to have been there taught by two fallen angels, Hároot and Mároot, <span class="auth">(see the Ḳur ii. 96,)</span>]</span> and to wine. <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بابل</span> - Entry: <span class="ar">بَابِلِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAbilieBN_A2">
					<p>And hence, <span class="auth">(TA,)</span> <em>Poison:</em> <span class="add">[and, accord to the CK, <em>wine;</em>]</span> as also<span class="arrow"><span class="ar">بَابِلِيَّةٌ↓</span></span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بابل</span> - Entry: <span class="ar">بَابِلِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAbilieBN_A3">
					<p>In the original language of the place above mentioned, <span class="ar">البَابِلِىُّ</span> is a name of <span class="ar">المُشْتَرِى</span> <span class="add">[<em>The planet Jupiter</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAbilyBapN">
				<h3 class="entry"><span class="ar">بَابِليَّةٌ</span></h3>
				<div class="sense" id="baAbilyBapN_A1">
					<p><span class="ar">بَابِليَّةٌ</span>: <a href="#baAbilieBN">see above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
