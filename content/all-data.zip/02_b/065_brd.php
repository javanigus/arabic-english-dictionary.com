<article class="root" id="Root_brd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/064_brH">برح</a></span>
				<span class="ar">برد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/066_brdE">بردع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brd_1">
				<h3 class="entry">1. ⇒ <span class="ar">برد</span></h3>
				<div class="sense" id="brd_1_A1">
					<p><span class="ar">بَرُدَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُدُ</span>}</span></add>, inf. n. <span class="ar">بُرُودَةٌ</span>; <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ;)</span> and <span class="ar">بَرَدَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُدُ</span>}</span></add>, <span class="auth">(M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَرْدٌ</span>; <span class="auth">(M, Mṣb;)</span> <em>It</em> <span class="auth">(a thing, Ṣ, Mṣb, and the latter said of water, Mṣb)</span> <em>was,</em> or <em>became, cold, chill,</em> or <em>cool;</em> <span class="add">[<a href="#barodN">see <span class="ar">بَرْدٌ</span> below</a>;]</span> <span class="auth">(Ṣ, M;)</span> <em>its heat became allayed.</em> <span class="auth">(Mṣb.)</span> The latter verb is also used transitively, as will be shown below. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brd_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَرُدَ مَضْجَعَهُ</span> <span class="add">[lit. <em>His bed,</em> or <em>place of sleep, became cold;</em> meaning]</span> ‡ <em>he went on a journey.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brd_1_A3">
					<p><span class="ar">بَرَدَ</span> also signifies ‡ <em>He died;</em> <span class="auth">(Aṣ, T, Ṣ, A, Ḳ;)</span> because death is the non-existence of the heat of the soul; <span class="auth">(L;)</span> or it is allusive to the extinction of the natural heat; or to the cessation of motion. <span class="auth">(MF.)</span> For</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brd_1_A4">
					<p><span class="ar">بَرَدَ</span>, <span class="auth">(MF,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُدُ</span>}</span></add>, <span class="auth">(Mgh,)</span> inf. n. <span class="ar">بَرْدٌ</span>, <span class="auth">(MF,)</span> likewise signifies † <em>It was,</em> or <em>became, still, quiet,</em> or <em>motionless;</em> <span class="auth">(Mgh, MF;)</span> for instance, a slaughtered sheep or goat <span class="add">[&amp;c.]</span>. <span class="auth">(Mgh.)</span> And † <em>It</em> <span class="auth">(beverage of the kind called <span class="ar">نَبِيذ</span>)</span> <em>became still, and without briskness.</em> <span class="auth">(TA, from a trad.)</span> You say, <span class="ar long">رُعِبَ فَبَرَدَ مَكَانَهُ</span> <span class="add">[† <em>He became frightened, and remained motionless in his place;</em> <span class="ar">مَكَانَهُ</span> meaning <span class="ar long">فِى مَكَانَهُ</span>: and hence,]</span> ‡ <em>he became amazed,</em> or <em>stupified.</em> <span class="auth">(A.)</span> And <span class="ar long">بَرَدَتْ عَيْنُهُ</span> † <em>The pain in his eye became allayed,</em> or <em>stilled.</em> <span class="auth">(L.)</span> And <span class="ar long">بَرَدَ أَمْرُنَا</span> † <em>Our affair,</em> or <em>case, became easy.</em> <span class="auth">(TA, from a trad. <span class="add">[<a href="#baAridN">See also <span class="ar">بَارِدٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="brd_1_A5">
					<p>Also, inf. n. <span class="ar">بَرْد</span>, <span class="add">[which see below,]</span> † <em>He slept.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="brd_1_A6">
					<p>And hence, ‡ <em>It remained,</em> or <em>became permanent,</em> or <em>fixed,</em> or <em>settled.</em> <span class="auth">(T.)</span> So in the saying, <span class="ar long">لَمْ يَبْرُدْ بِيَدِى مِنْهُ شَيْءٌ</span> ‡ <em>There did not remain,</em> or <em>become permanent</em> or <em>fixed</em> or <em>settled, in my hand, thereof, anything.</em> <span class="auth">(T, L.*)</span> You say also, <span class="ar long">بَرَدَ أَسِيرًا فِى أَيْدِيْهِمْ</span> ‡ <em>He remained safely a captive in their hands.</em> <span class="auth">(A.)</span> And <span class="ar long">بَرَدَ فِى أَيْدِيهمْ سَلْمًا</span> ‡ <em>He became a permanent captive, remaining in their hands, not to be ransomed nor liberated nor demanded.</em> <span class="auth">(L.)</span> And <span class="ar long">بَرَدَ المَوْتِ عَلَىمُصْطَلَاهُ</span> ‡ <em>Death fixed,</em> or <em>settled,</em> <span class="add">[<em>upon his face and extremities,</em> or]</span> <em>upon his limbs,</em> or <em>upon his arms and legs and face and every prominent part,</em> which become cold at the time of death, and which are warmed at the fire. <span class="auth">(AHeyth, L.)</span> And <span class="ar long">بَرَدَ المَوْتِ عَلَيْهِ</span> <span class="add">[‡ <em>Death became impressed upon him;</em>]</span> <em>the marks,</em> or <em>signs, of death became apparent upon him.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="brd_1_A7">
					<p><span class="add">[And hence, app.,]</span> ‡ <em>It</em> <span class="auth">(a right, or due,)</span> <em>became incumbent,</em> or <em>obligatory,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>and established.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">بَرَدَ لِى حَقِّى عَلَى فُلَانٍ</span> ‡ <em>My right,</em> or <em>due, became incumbent,</em> or <em>obligatory, on such a one, and established against him.</em> <span class="auth">(M,* A,* TA.)</span> And <span class="ar long">مَا بَرَدَ لَكَ عَلَى فُلَانٍ</span> ‡ <em>What hath become incumbent,</em> or <em>obligatory, to thee, on such a one, and established against him?</em> or <em>what hath become owed,</em> or <em>due, to thee, by,</em> or <em>from, such a one?</em> as also <span class="ar long">مَا ذَابَ لَكَ عَلَيْهِ</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">بَرَدَ لِى عَلَيْهِ كَذَا مِنَ المَالِ</span> ‡ <em>Such an amount of the property,</em> or <em>of property, became incumbent,</em> or <em>obligatory, to me, on him, and established against him;</em> or <em>became owed,</em> or <em>due, to me, by,</em> or <em>from, him.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="brd_1_A8">
					<p>Also, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُدُ</span>}</span></add>, inf. n. <span class="ar">بَرْدٌ</span>, <span class="auth">(TA, <span class="add">[but see the next sentence,]</span>)</span> † <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, weak;</em> and so <span class="ar">بُرِدَ</span>, a verb like <span class="ar">عُنِىَ</span>. <span class="auth">(Ḳ.)</span> And, inf. n. <span class="ar">بُرَادٌ</span> and <span class="ar">بُرُودٌ</span>, <span class="auth">(M, Ḳ,)</span> † <em>He was,</em> or <em>became, languid,</em> <span class="auth">(Ḳ,)</span> or <em>weak and languid, from leanness</em> or <em>disease:</em> <span class="auth">(M:)</span> or <em>weak in the legs, from hunger</em> or <em>fatigue.</em> <span class="auth">(Ibn-Buzurj, T.)</span> And <span class="ar long">بَرَدَ مُخُّهُ</span>, <span class="auth">(A, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُدُ</span>}</span></add>, inf. n. <span class="ar">بَرْدٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He was,</em> or <em>became, lean,</em> or <em>emaciated;</em> <span class="auth">(A, Ḳ;)</span> and so <span class="ar long">بَرَدَتْ عِظَامُهُ</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="brd_1_A9">
					<p>† <em>It</em> <span class="auth">(a sword <span class="add">[or the like]</span>)</span> <em>was,</em> or <em>became, blunt.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brd_1_B1">
					<p><span class="ar">بَرَدَهُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُدُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَرْدٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">برّدهُ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَبْرِيدٌ</span>; <span class="auth">(Ṣ;)</span> <em>He made it,</em> or <em>rendered it,</em> <span class="auth">(for ex., water, M, Mṣb, Ḳ,)</span> <em>cold, chill,</em> or <em>cool:</em> <span class="auth">(Ṣ, &amp;c.:)</span> but the latter has an intensive signification <span class="add">[<em>he made it,</em> or <em>rendered it, very cold,</em> or <em>very cool</em>]</span>: <span class="auth">(Mṣb:)</span> or both signify, <span class="auth">(Ḳ,)</span> or the former signifies, <span class="auth">(M, TA,)</span> <em>he mixed it with snow:</em> <span class="auth">(M, Ḳ:)</span> one does not say<span class="arrow"><span class="ar">ابردهُ↓</span></span>, except in a bad dialect. <span class="auth">(Ṣ.)</span> <span class="ar">بَرِّدِيهِ</span>, being used by a poet for <span class="ar long">بَلْ رِدِيهِ</span>, has been erroneously supposed to mean “Make thou it hot.” <span class="auth">(M.)</span> You say, <span class="ar long">بَرَدَنَا اللَّيْلُ</span>, <span class="auth">(aor. and inf. n. as above, M,)</span> and <span class="ar long">بَرَدَ عَلَيْنَا</span>, <em>The night affected us with its cold.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">سَقَيْتُهُ شَرْبَةً بَرَدَتْ فُؤَادَهُ</span>, <span class="auth">(Ṣ, M,*)</span> aor. and inf. n. as above, <span class="auth">(Ṣ,)</span> <em>I gave him to drink a draught that cooled his heart:</em> <span class="auth">(Ṣ, M:)</span> <span class="pb" id="Page_0184"></span>or <span class="ar long">بَرَدْتُ بِهَا فُؤَادَهُ</span> <span class="add">[<em>with which I cooled his heart</em>]</span>. <span class="auth">(So in the T.)</span> And<span class="arrow"><span class="ar long">بَرِّدْ↓ فُؤَادَكَ بِشَرْبَةٍ</span></span> <em>Cool thy heart by a draught.</em> <span class="auth">(A.)</span> And <span class="ar long">اِسْقِنِى سَوِيقًا أَبْرُدْ بِهِ كَبِدِى</span> <span class="add">[<em>Give thou me to drink</em> <span class="ar">سويق</span> <em>with which I may cool my liver</em>]</span>. <span class="auth">(T.)</span> And <span class="ar long">بَرَدَ عَيْنُهُ بِالْكُحْلِ</span>, <span class="auth">(AʼObeyd, T, M,)</span> or <span class="ar">بِالْبَرُودِ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. and inf. n. as above, <span class="auth">(M,)</span> <span class="add">[<em>He cooled his eye with the collyrium,</em> or]</span> <em>he applied the cooling collyrium to his eye,</em> <span class="auth">(T,* Ṣ, M,* Mṣb, Ḳ,*)</span> <em>and allayed its pain.</em> <span class="auth">(M.)</span> The following words, cited by IAạr,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَرَدُوا غَوَارِبَ أَيْنُقٍ حُدْبِ</span> *</div> 
					</blockquote>
					<p><span class="add">[lit. <em>They cooled the fore parts of the humps,</em> or <em>the backs, of humped she-camels</em>]</span>, mean ‡ <em>they put off from them their saddles, that their backs might become cool.</em> <span class="auth">(M.)</span> You say also,<span class="arrow"><span class="ar long">بَرِّدْ↓ ظَهْرَ فَرَسِكَ سَاعَةً</span></span> ‡ <em>Relieve thy horse from riding</em> <span class="add">[lit. <em>cool his back</em>]</span> <em>awhile.</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">لَا تُبَرِّدْ↓ عَنْ فُلَانٍ</span></span> ‡ <em>Do not thou alleviate the punishment</em> <span class="add">[<em>in the world to come</em>]</span> <em>due to the offence of such a one by thy reviling him,</em> or <em>cursing him,</em> when he has acted injuriously to thee. <span class="auth">(T, Ṣ,* M,* A,* L.)</span> And <span class="ar long">بَرَدَ الخُبْزَ</span>, <span class="auth">(T, L, Ḳ,)</span> <span class="ar">بِالْمَآءِ</span>, <span class="auth">(T,)</span> <em>He poured</em> <span class="add">[<em>cold</em>]</span> <em>water upon the bread,</em> <span class="auth">(T, L, Ḳ,)</span> and <em>moistened it</em> <span class="add">[<em>therewith:</em> <a href="#baruwdN">see <span class="ar">بَرُودٌ</span></a>]</span>. <span class="auth">(T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brd_1_B2">
					<p><span class="ar">بُرِدَ</span> <span class="auth">(a verb like <span class="ar">عُنِىَ</span>, Ḳ)</span> <em>It</em> <span class="auth">(a company of men)</span> <em>was hailed upon.</em> <span class="auth">(Ṣ, M, Ḳ.)</span> And <span class="ar">بُرِدَتِ</span>. <span class="ar">الأَرُضُ</span> <em>The land,</em> or <em>ground, was hailed upon.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brd_1_C1">
					<p><span class="ar">بَرَدَ</span>, <span class="auth">(Ṣ, M, &amp;c.,)</span> aor <span class="ar">ـُ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَرْدٌ</span>, <span class="auth">(Mgh, TA,)</span> also signifies <em>He filed</em> <span class="auth">(M, Mgh, Ḳ)</span> iron, <span class="auth">(Ṣ, M, &amp;c.,)</span> and the like, <span class="auth">(M,)</span> with a <span class="ar">مِبْرَد</span>.<span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="brd_1_D1">
					<p><span class="ar">بَرَدَهُ</span> and<span class="arrow"><span class="ar">ابردهُ↓</span></span> <em>He sent him as a</em> <span class="ar">بَرِيد</span> <span class="add">[or <em>messenger on a postmule</em> or <em>post-horse</em>]</span>. <span class="auth">(Ḳ.)</span> And <span class="ar long">بَرَدَ بَريدًا</span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">ابردهُ↓</span></span>, <span class="auth">(A,)</span> <em>He sent a</em> <span class="ar">بريد</span>. <span class="auth">(M, A.)</span> And<span class="arrow"><span class="ar long">ابرد↓ إِلْيَهِ</span></span>, <span class="auth">(Ṣ,)</span> or<span class="arrow"><span class="ar long">ابرد↓ اليه بَرِيدًا</span></span>, <span class="auth">(T, TA.)</span> <em>He sent to him a</em> <span class="ar">بريد</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brd_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّد</span></h3>
				<div class="sense" id="brd_2_A1">
					<p><a href="#brd_1_B1">see <span class="ar">بَرَدَهُ</span></a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brd_2_A2">
					<p><span class="ar long">برّدهُ عَلَيْهِ</span> ‡ <em>He made it incumbent,</em> or <em>obligatory, on him.</em> <span class="auth">(M, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brd_2_A3">
					<p>And <span class="ar">برّدهُ</span>, <span class="auth">(Ḳ, TA, but omitted in the CK,)</span> inf. n. <span class="ar">تَبْرِيدٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">ابردهُ↓</span></span>; <span class="auth">(M, Ḳ;)</span> ‡ <em>It</em> <span class="auth">(a thing, M)</span> <em>made him,</em> or <em>rendered him, weak; weakened him;</em> <span class="auth">(Ḳ;)</span> or <em>made him,</em> or <em>rendered him, weak and languid.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brd_2_B1">
					<p><span class="add">[<span class="ar">برّد</span> also signifies, as is indicated in the TA voce <span class="ar">حُبَاحِبٌ</span>, <em>It</em> <span class="auth">(a locust)</span> <em>spread forth its wings;</em> which are termed its <span class="ar">بُرْدَانِ</span>: <a href="#burodN">see <span class="ar">بُرْدٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brd_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرد</span></h3>
				<div class="sense" id="brd_4_A1">
					<p><span class="ar">ابرد</span> <em>He entered upon a cold,</em> or <em>cool, time:</em> <span class="auth">(Mgh, Mṣb:)</span> <em>he entered upon the last part of the day:</em> <span class="auth">(M, Ḳ:)</span> <em>he entered upon the time when the sun had declined:</em> <span class="auth">(Moḥammad Ibn-Kaab, T:)</span> and <em>he entered upon the cool season, at the end of the summer.</em> <span class="auth">(Lth, T.)</span> <span class="add">[Hence,]</span> <span class="ar long">أَبْرِدُوا بِالطَّعَامِ</span> <em>Delay ye to eat food until it is cool:</em> occurring in a trad. <span class="auth">(El-Munáwee.)</span> And <span class="ar long">أَبْرِدُوا بِالظُّهْرِ</span> <span class="auth">(T, A, Mgh, Mṣb)</span> <em>Defer ye the noon-prayers until the cooler time of the day, when the vehemence of the heat shall have become allayed.</em> <span class="auth">(Mgh, Mṣb.)</span> And <span class="ar long">أَبْرِدْ عَنْكَ مِنَ الظَّهِيرِةَ</span> <em>Stay thou until the mid-day heat shall have become assuaged, and the air be cool.</em> <span class="auth">(M, and L in art. <span class="ar">فيح</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brd_4_A2">
					<p><span class="ar">ابردلَهُ</span> <em>He gave him to drink what was cold,</em> or <em>cool.</em> <span class="auth">(M, Ḳ.)</span> You say also, <span class="ar long">سَقَيْتُهُ فَأَبْرَدْتُ لَهُ</span>, meaning <em>I gave him to drink what was cold,</em> or <em>cool.</em> <span class="auth">(AʼObeyd, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brd_4_A3">
					<p><span class="ar">ابردهُ</span> <em>He brought it cold,</em> or <em>cool.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="brd_4_A4">
					<p><a href="#brd_1_B1">See <span class="ar">بَرَدَهُ</span></a>, first sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="brd_4_A5">
					<p><a href="#brd_2">And see 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brd_4_B1">
					<p><a href="#brd_1">See also 1</a>, in four places; last three sentences.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّد</span></h3>
				<div class="sense" id="brd_5_A1">
					<p><span class="ar long">تبرّد فِيهِ</span> <em>He descended into it,</em> <span class="auth">(i. e., into water, TA,)</span> <em>and washed himself in it, to refresh himself by its coolness.</em> <span class="auth">(M, Ḳ.)</span> <a href="#brd_8">See also 8</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brd_5_A2">
					<p><span class="ar">تبرّد</span> also signifies † <em>He became weakened.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brd_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابترد</span></h3>
				<div class="sense" id="brd_8_A1">
					<p><span class="ar">ابترد</span> <em>He washed himself with cold water:</em> <span class="auth">(Ṣ:)</span> and likewise, <span class="auth">(Ṣ,)</span> or <span class="ar">ابتردالمَآءَ</span>, <span class="auth">(Ḳ,)</span> <em>he drank water to cool his liver:</em> <span class="auth">(Ṣ, Ḳ:)</span> or the latter signifies <em>he poured the water cold upon himself,</em> <span class="auth">(M, Ḳ,)</span> meaning, <em>upon his head:</em> <span class="auth">(M:)</span> and<span class="arrow"><span class="ar long">تبرّد↓ بِالْمَاءِ</span></span>, <span class="auth">(T, A,)</span> and <span class="ar">ابترد</span>, <span class="auth">(A,)</span> <em>he washed himself with water,</em> or <em>with the water.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brd_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبرد</span></h3>
				<div class="sense" id="brd_10_A1">
					<p><span class="ar long">استبرد عَلَيْهِ لِسَانَهُ</span> ‡ <em>He let loose his tongue and used it like a file against him.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barodN">
				<h3 class="entry"><span class="ar">بَرْدٌ</span></h3>
				<div class="sense" id="barodN_A1">
					<p><span class="ar">بَرْدٌ</span> and<span class="arrow"><span class="ar">بُرُودَةٌ↓</span></span> <span class="add">[originally inf. ns.]</span> <em>Cold; coldness; chill; chilness; cool,</em> as a subst.; <em>coolness;</em> the former, <em>contr. of</em> <span class="ar">حَرٌّ</span>; <span class="auth">(Ṣ, M, A, Mṣb;)</span> and the latter, <em>of</em> <span class="ar">حَرَارَةٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barodN_A2">
					<p>And <span class="add">[hence]</span> the former, ‡ <em>Pleasantness; enjoyment; ease; comfort:</em> as in the saying, <span class="ar long">نَسْأَلُكَ الجَنَّةَ وَبَرْدَهَا</span> ‡ <em>We ask of Thee Paradise and its pleasantness,</em>, &amp;c. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="barodN_A3">
					<p>Also † <em>Sleep:</em> <span class="auth">(T, Ṣ, M, A, Ḳ:)</span> <span class="add">[an inf. n. used as a subst.:]</span> so in the Ḳur lxxviii. 24: <span class="auth">(Ṣ, M, Ḳ:)</span> for sleep cools a man: <span class="auth">(TA:)</span> or, accord. to I’Ab, it there means the <em>coldness,</em> or <em>coolness,</em> of beverage. <span class="auth">(T.)</span> You say, <span class="ar long">مَنَعَ البَرَدُ البَرْدَ</span> † <em>The hail prevented sleep.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="barodN_A4">
					<p>And † <em>Saliva:</em> <span class="auth">(Th, T, M, Ḳ:)</span> so, accord. to Th, in the saying of El-'Arjee,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإِنْ شِئْتِ لَمْ أَطْعَمُ نُقَاخًا وَلَا بَرْدَا</span> *</div> 
					</blockquote>
					<p><em>And if thou desire, I will not taste sweet water, nor saliva</em> <span class="add">[from any lips but thine]</span>. <span class="auth">(T, M,* TA. <span class="add">[But this is cited in the Ṣ as an ex. of <span class="ar">بَرْد</span> signifying <em>sleep.</em>]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="barodN_A5">
					<p><a href="#baAridN">See also <span class="ar">بَارِدٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="barodN_A6">
					<p><span class="add">[Hence,]</span> <span class="ar">البَرْدَانِ</span>: <a href="#AlOaboradaAni">see <span class="ar">الأَبْرَدَانِ</span></a>, voce <span class="ar">أَبْرَدُ</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burodN">
				<h3 class="entry"><span class="ar">بُرْدٌ</span></h3>
				<div class="sense" id="burodN_A1">
					<p><span class="ar">بُرْدٌ</span> <em>A kind of garment;</em> <span class="auth">(Ṣ;)</span> <em>a kind of striped garment:</em> <span class="auth">(M, Ḳ:)</span> accord. to some, <em>of the description termed</em> <span class="ar">وَشْىٌ</span> <span class="add">[or <em>variegated</em>]</span>: <span class="auth">(M:)</span> or particular kinds thereof are distinguished by such terms as <span class="ar long">بُرْدُ عَصْبٍ</span> and <span class="ar long">بُرْدُ وَشْىٍ</span>: <span class="auth">(Mṣb:)</span> also, <span class="auth">(as a coll. gen. n., TA,)</span> <em>garments of the kind called</em> <span class="ar">أَكْسِيَةٌ</span>, <span class="add">[<a href="#kisaACN">pl. of <span class="ar">كِسَآءٌ</span></a>,]</span> <em>which are wrapped round the body;</em> <span class="auth">(Ḳ;)</span> <em>one of which is called</em> <span class="arrow"><span class="ar">بُرْدَةٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> or, as Lth says, the <span class="ar">بُرْد</span> is <span class="add">[<em>a</em>]</span> <em>well-known</em> <span class="add">[<em>garment</em>]</span>, <em>of the kind called</em> <span class="ar long">بُرُودُ العَصْبِ</span> <em>and</em> <span class="ar long">بُرُودُ الوَشْىِ</span>; <span class="auth">(T;)</span> but the <span class="arrow"><span class="ar">بُرْدَةٌ↓</span></span> is <em>a garment of the kind called</em> <span class="ar">كِسَآءٌ</span>, <em>four-sided, black, and somewhat small, worn by the Arabs of the desert:</em> <span class="auth">(T, Ṣ, Mgh,* Mṣb,* TA:)</span> or this latter <span class="auth">(the <span class="ar">بردة</span>)</span> is <em>a striped garment of the kind called</em> <span class="ar">شَمْلَةٌ</span>: <span class="auth">(T:)</span> or it is <em>an oblong piece of woollen cloth, fringed:</em> <span class="auth">(M:)</span> Sh says, I saw an Arab of the desert wearing <em>a piece of woollen cloth resembling a napkin, wrapped round the body like an apron;</em> and on my saying to him, What dost thou call it? he answered, <span class="ar">بُرْدَة</span>: <span class="auth">(T:)</span> <span class="add">[the modern <span class="ar">بردة</span>, in every case in which I have seen it, I have observed to be <em>an oblong piece of thick woollen cloth, generally brown or of a dark or ashy dust-colour, and either plain, or having stripes so narrow and near together as to appear, at a little distance, of one colour; used both to envelop the person by day and as a night-covering:</em> the <span class="ar">بردة</span> of Moḥammad is described as about seven feet and a half in length, and four and a half in width, and in colour either <span class="ar">أَخْضَر</span> or <span class="ar">أَحْمَر</span>, i. e. of a dark or ashy dust-colour or brown; for such are the significations of these two epithets when applied to a garment of this kind, and in some other cases:]</span> <a href="#burodN">the pl. of <span class="ar">بُرْدٌ</span></a> is <span class="ar">أَبْرُدٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أَبْرَادٌ</span> <span class="add">[both pls. of pauc.]</span> and <span class="ar">بُرُودٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بُرَدٌ</span>, <span class="auth">(IAạr, T,)</span> or this last <a href="#burodapN">is pl. of <span class="ar">بُرْدَةٌ</span></a>, <span class="auth">(Ṣ, M,)</span> and <span class="ar">بِرَادٌ</span>, like as <span class="ar">قِرَاطٌ</span> <a href="#quroTN">is pl. of <span class="ar">قُرْطٌ</span></a>, or this, also, <a href="#burodapN">is pl. of <span class="ar">بُرْدَةٌ</span></a>, like as <span class="ar">بِرَامٌ</span> <a href="#buromapN">is pl. of <span class="ar">بُرْمَةٌ</span></a>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="burodN_A2">
					<p><span class="ar">ذُوبُرْدٍ</span>, as opposed to <span class="ar long">ذُو كِسَآءِ</span>, means † <em>A rich man.</em> <span class="auth">(Ṣ in art. <span class="ar">عج</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="burodN_A3">
					<p><span class="ar long">وَقَعَ بَيْنُهُمَا قَدُّ بُرُودٍ يُمْنَةٍ</span>, <span class="auth">(so in copies of the Ḳ, in the TA <span class="ar">يُمَنَةٍ</span>,)</span> or <span class="ar long">بُرُودٍ ثَمِينَةٍ</span>, <span class="auth">(so in a copy of the A,)</span> ‡ <span class="add">[<em>There happened between them two the rending of</em> <span class="ar">بُرُود</span> <em>of the fabric of El-Yemen,</em> accord. to the reading in the Ḳ, or <em>of costly</em> <span class="ar">بُرُود</span>, accord. to the reading in the A,]</span> means <em>they arrived at a great,</em> or <em>severe, state of affairs;</em> <span class="auth">(Ḳ;)</span> or is said of two men who have contended together in vehement altercation so that they have rent each other's garments; <span class="auth">(A;)</span> <span class="add">[accord. to the reading in the Ḳ,]</span> because <span class="ar">يُمَنٌ</span>, <span class="add">[in the CK <span class="ar">يُمْن</span>,]</span> which are <span class="ar">بُرُود</span> of El-Yemen, are not rent save on account of some great, or severe, thing, or affair. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="burodN_A4">
					<p><span class="arrow"><span class="ar long">هُمَا فِى بُرْدَةِ↓ أَخْمَاسٍ</span></span> means † <em>They two do one deed;</em> or <em>act alike;</em> <span class="auth">(IAạr, M, Ḳ;)</span> <em>and resemble each other, as though they were in one</em> <span class="ar">بُرْدَة</span>: <span class="auth">(IAạr, M:)</span> or <em>they two have become near together, and in a state of agreement.</em> <span class="auth">(Ḳ in art. <span class="ar">خمس</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="burodN_A5">
					<p>And<span class="arrow"><span class="ar long">سَلَبَ الصَّهْبَآءَ بُرْدَتَهَا↓</span></span>‡ <em>He,</em> or <em>it, deprived the wine of its colour.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="burodN_A6">
					<p>And <span class="ar long">بُرْدَا الجَرَادِ</span>, <span class="auth">(T,)</span> or <span class="ar">الجُنْدَبِ</span>, <span class="auth">(Ṣ,)</span> † <em>The two wings</em> <span class="add">[<em>of the locust,</em> or <em>of the species called</em> <span class="ar">جندب</span>]</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="burodN_A7">
					<p>And↓<span class="ar long">بُرْدَةُ الضَّأْنِ</span>† <em>A certain sort of milk.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baradN">
				<h3 class="entry"><span class="ar">بَرَدٌ</span> / <span class="ar">بَرَدَةٌ</span></h3>
				<div class="sense" id="baradN_A1">
					<p><span class="ar">بَرَدٌ</span> <em>Hail; what descends from the clouds, resembing pebbles;</em> <span class="auth">(M, Mṣb;)</span> <em>frozen rain;</em> <span class="auth">(Lth, T;)</span> <em>what is called</em> <span class="ar long">حَبُّ الغَمَامِ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ)</span> <em>and</em> <span class="ar long">حَبُّ المُزْنِ</span> <span class="auth">(Mṣb)</span> <span class="add">[i. e. <em>the grains,</em> or <em>berries, of the clouds:</em> a coll. gen. n., of which the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرَدَةٌ</span>}</span></add>, signifying <em>a hailstone</em>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baridN">
				<h3 class="entry"><span class="ar">بَرِدٌ</span></h3>
				<div class="sense" id="baridN_A1">
					<p><span class="ar">بَرِدٌ</span> <em>Possessing coldness</em> or <em>coolness:</em> an epithet applied to the <span class="add">[plant called]</span> <span class="ar">صِلِّيَان</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baridN_A2">
					<p><span class="ar long">سَحَابٌ بَرِدٌ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">أَبْرَدُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>Clouds containing hail</em> <span class="auth">(T, Ṣ, M, Ḳ *)</span> <em>and cold.</em> <span class="auth">(T.)</span> You say also <span class="ar long">سَحَابَةٌ بَرِدَةٌ</span> <em>A cloud containing hail</em> <span class="auth">(T, Ṣ, M, A *)</span> <em>and cold;</em> <span class="auth">(T;)</span> but not <span class="ar long">سحابة بَرْدَآءُ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barodapN">
				<h3 class="entry"><span class="ar">بَرْدَةٌ</span></h3>
				<div class="sense" id="barodapN_A1">
					<p><span class="ar">بَرْدَةٌ</span>: <a href="#baAridN">see <span class="ar">بَارِدٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barodapN_B1">
					<p><a href="#baradapN">and see also <span class="ar">بَرَدَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="barodapN_C1">
					<p><span class="ar long">هِىَ لَكَ بَرْدَةَ نَفْسَهَا</span> <em>She is purely thine;</em> <span class="auth">(Fr, AʼObeyd, T, Ṣ, M;)</span> syn. <span class="ar">خَالِصَةً</span>: <span class="auth">(M:)</span> AʼObeyd explains it by <span class="ar">خَالِصًا</span>, <span class="auth">(T, Ṣ, M,)</span> not in the fem. form, <span class="auth">(TA,)</span> on the authority of Fr. <span class="auth">(T.)</span></p>
				</div>
				<span class="pb" id="Page_0185"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="barodapN_C2">
					<p><span class="ar long">هُوَ لِى بَرْدَةَ يَمِينِى</span>, <span class="auth">(AʼObeyd, M,)</span>or <span class="ar long">هُوَ لِبَرْدَةِ يَمِينِى</span>, <span class="auth">(Ṣ,)</span> <em>He,</em> or <em>it, is known to me.</em> <span class="auth">(AʼObeyd, Ṣ, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="barodapN_D1">
					<p><span class="ar">بَرْدَةُ</span> a proper name applied to <em>The ewe.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="burodapN">
				<h3 class="entry"><span class="ar">بُرْدَةٌ</span></h3>
				<div class="sense" id="burodapN_A1">
					<p><span class="ar">بُرْدَةٌ</span>: <a href="#burodN">see <span class="ar">بُرْدٌ</span></a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baradapN">
				<h3 class="entry"><span class="ar">بَرَدَةٌ</span></h3>
				<div class="sense" id="baradapN_A1">
					<p><span class="ar">بَرَدَةٌ</span> <span class="auth">(T, Ṣ, M, A, &amp;c.)</span> and<span class="arrow"><span class="ar">بَرْدَةٌ↓</span></span> <span class="auth">(T, M, Ḳ)</span> <em>Indigestion; a malady arising from unwholesome food:</em> <span class="auth">(Ṣ, M, A, L, Mṣb, Ḳ:)</span> or <em>heaviness of food to the stomach:</em> <span class="auth">(IAạr, T, L:)</span> so termed because it makes the stomach cold. <span class="auth">(T, L, Mṣb.)</span> It is said in a trad., <span class="ar long">أَصْلُ كُلِّ دَآءٍ البَرَدَةُ</span> <span class="add">[<em>The origin of every disease is indigestion</em>]</span>. <span class="auth">(T, Ṣ, M,* A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرَدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baradapN_B1">
					<p>Also, the former, The <em>middle</em> of the eye. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buradaMCu">
				<h3 class="entry"><span class="ar">بُرَدَآءُ</span></h3>
				<div class="sense" id="buradaMCu_A1">
					<p><span class="ar">بُرَدَآءُ</span> <em>An ague;</em> i. e. <em>a fever attended by a cold fit,</em> <span class="auth">(Ḳ,)</span> or <em>by shivering.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barodiyBN">
				<h3 class="entry"><span class="ar">بَرْدِيٌّ</span></h3>
				<div class="sense" id="barodiyBN_A1">
					<p><span class="ar">بَرْدِيٌّ</span> <em>A well-known kind of plant,</em> <span class="auth">(Ṣ, M,* Ḳ,)</span> <em>of which the kind of paper termed</em> <span class="ar">قِرْطَاس</span> <em>is made;</em> <span class="auth">(TA in art. <span class="ar">قرطس</span>, q. v.;)</span> <span class="add">[namely, <em>papyrus;</em> and]</span> <em>of which mats are made;</em> <span class="auth">(Mṣb;)</span> <span class="add">[app. meaning <em>rushes</em> in general: but the former is generally meant by it in the present day, and is probably the proper signification: anciently, mats, as well as ropes and sails, &amp;c., were made of the rind of the papyrus; and even small boats were constructed of its stalks bound together; and of such, probably, was the ark in which the infant Moses was exposed: it is a coll. gen. n.:]</span> n. un. <span class="ar">بَرْدِيَّةٌ</span>. <span class="auth">(M, TA.)</span> Hence, <span class="ar long">قَطْنُ البَرْدِىّ</span> <em>The cotton of the papyrus, which, resembling wool, is gathered from the stalk, and, mixed with lime, composes a very tenacious kind of cement.</em> <span class="auth">(Golius, from Ibn-Maạroof.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرْدِيٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barodiyBN_A2">
					<p><span class="add">[Also, a rel. n. from the same, meaning <em>Of,</em> or <em>belonging to,</em> or <em>resembling, the plant so called.</em> Hence the saying,]</span> <span class="ar long">لَهَا سَاقٌ بَرْدِيَّةٌ</span> <span class="add">[<em>She has a shank like a papyrus-stalk</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burodieBN">
				<h3 class="entry"><span class="ar">بُرْدِىٌّ</span></h3>
				<div class="sense" id="burodieBN_A1">
					<p><span class="ar">بُرْدِىٌّ</span> <em>One of the most excellent sorts of dates:</em> <span class="auth">(Ṣ, Mṣb:)</span> <em>an excellent sort of dates,</em> <span class="auth">(AḤn, M, Ḳ,)</span> <em>resembling the</em> <span class="ar">بَرْنِىّ</span>: <span class="auth">(AḤn, M:)</span> or <em>a sort of dates of El-Ḥijáz.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barodaAnN">
				<h3 class="entry"><span class="add">[<span class="ar">بَرْدَانٌ</span> / <span class="ar">بَرْدَانَةٌ</span>]</span></h3>
				<div class="sense" id="barodaAnN_A1">
					<p><span class="add">[<span class="ar">بَرْدَانٌ</span> <em>Feeling cold</em> or <em>chilly</em> or <em>cool:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرْدَانَةٌ</span>}</span></add>: perhaps post-classical; for I have not found it mentioned in any of the lexicons.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buraAdN">
				<h3 class="entry"><span class="ar">بُرَادٌ</span></h3>
				<div class="sense" id="buraAdN_A1">
					<p><span class="ar">بُرَادٌ</span>: <a href="#baAridN">see <span class="ar">بَارِدٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بُرَادٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buraAdN_B1">
					<p>Also <em>Weakness of the legs, from hunger or fatigue.</em> <span class="auth">(Ibn-Buzurj, T.)</span> <span class="add">[<a href="#brd_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baruwdN">
				<h3 class="entry"><span class="ar">بَرُودٌ</span></h3>
				<div class="sense" id="baruwdN_A1">
					<p><span class="ar">بَرُودٌ</span>: <a href="#baAridN">see <span class="ar">بَارِدٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baruwdN_A2">
					<p>Beverage <em>that cools the heat of thirst.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baruwdN_A3">
					<p>Also, <span class="auth">(T, L, Ḳ,)</span> and<span class="arrow"><span class="ar">مَبْرُودٌ↓</span></span>, <span class="auth">(T, M, A, L, Ḳ,)</span> Bread <em>upon which water is poured;</em> <span class="auth">(T, L, Ḳ;)</span> <em>which is moistened with cold water:</em> <span class="auth">(A:)</span> eaten by women to make them fat. <span class="auth">(M, A, L.)</span> The subst. applied to such bread is <span class="arrow"><span class="ar">بَرِيدٌ↓</span></span> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baruwdN_A4">
					<p><span class="ar">بَرُودٌ</span> <span class="add">[as an epithet in which the quality of a subst. predominates]</span> also signifies <em>Cold water which one pours upon his head.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baruwdN_A5">
					<p><em>Anything with which a thing is rendered cold,</em> or <em>cooled.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baruwdN_A6">
					<p><em>A collyrium which cools the eye;</em> <span class="auth">(Lth, T, M, Mṣb;)</span> also termed <span class="ar long">بَرُودُ العَيْنِ</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baruwdN_A7">
					<p><span class="ar long">بَرُودُ الظِّلِّ</span> † <em>Pleasant in social intercourse:</em> applied alike to the male and the female. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="baruwdN_A8">
					<p><span class="ar long">ثَوْبٌ بَرُودٌ</span> <em>A garment without nap:</em> <span class="auth">(Ḳ:)</span> and <em>a garment that is not warm nor soft.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariydN">
				<h3 class="entry"><span class="ar">بَرِيدٌ</span></h3>
				<div class="sense" id="bariydN_A1">
					<p><span class="ar">بَرِيدٌ</span>: <a href="#baruwdN">see <span class="ar">بَرُودٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرِيدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bariydN_B1">
					<p>Also <em>A mule appointed</em> <span class="add">[<em>for the conveyance of messengers</em>]</span> <em>in a</em> <span class="ar">رِبَاط</span> <span class="add">[or <em>public building for the accommodation of travellers and their beasts,</em> or <em>in a</em> <span class="ar">سِكَّة</span>, which is a <em>house</em> or <em>the like specially appropriated to messengers and the beasts that carry them:</em> thus it signifies <em>a postmule:</em> afterwards, it was applied also to <em>a posthorse,</em> and <em>any beast appointed for the conveyance of messengers</em>]</span>: <span class="auth">(Mgh:)</span> <span class="add">[this is what is meant by the words in the Ṣ and Ḳ, <span class="ar long">البَرِيدُ المُرَتَّبُ</span>:]</span> it is a word of Persian origin, <span class="auth">(Z in the Fáïk,)</span> arabicized, from <span class="ar long">بُرِيدَهْ دُمْ</span>, <span class="auth">(Z in the Fáïk, and Mgh,)</span> i. e. “docked,” or “having the tail cut off;” for the post-mules (<span class="ar long">بِغَالُ البَرِيدِ</span>) had their tails cut off in order that they might be known: <span class="auth">(Z in the Fáïk:)</span> <span class="add">[or perhaps it is from the Hebrew <span class="he">פֶּרֶד</span> “a mule:”]</span> or it is applied to the <em>beast appointed for the conveyance of messengers</em> (<span class="ar long">دَابَّةُ البَرِيدِ</span>) because he traverses the space called <span class="ar">بَرِيد</span> <span class="add">[defined below: but the reason before given for this appellation is more probable: it is like the Lat. “veredus”]</span>: <span class="auth">(T, Mṣb:)</span> pl. <span class="ar">بُرُدٌ</span> <span class="auth">(Z, Mgh, Mṣb)</span> and <span class="ar">بُرْدٌ</span>, which is a contraction of the former, like as <span class="ar">رُسْلٌ</span> is of <span class="ar">رُسُلٌ</span>. <span class="auth">(Z.)</span> You say, <span class="ar long">حُمِلَ فُلَانٌ عَلَى البَرِيِد</span> <span class="add">[<em>Such a one was borne on the postmule</em> or <em>post-horse</em>]</span>. <span class="auth">(Ṣ.)</span> Imra-el-Ḳeys speaks of a <span class="ar">بريد</span> of the horses of Barbar. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bariydN_B2">
					<p>Having been originally used in the sense first explained above, it was afterwards applied to <em>A messenger borne on a post-mule</em> <span class="add">[or <em>post-horse</em>]</span>: <span class="auth">(Z in the Fáïk, and Mgh:)</span> or <em>messengers on beasts of the post:</em> <span class="auth">(M, Ḳ:)</span> or <em>a messenger that journeys with haste:</em> <span class="auth">(A:)</span> or <span class="add">[simply]</span> <em>a messenger:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> pl. as above. <span class="auth">(M,* Z.)</span> Hence the saying, <span class="ar long">الحُمَّى بَرِيدُ المَوْتِ</span> <em>Fever is the messenger of death:</em> <span class="auth">(T, Mṣb:)</span> because it gives warning thereof. <span class="auth">(T.)</span> Hence also <span class="ar">البَرِيدُ</span> applied to <em>The animal called</em> <span class="ar">الفُرَانِقُ</span>, <span class="auth">(said to be <em>the jackal,</em> but some say otherwise, TA,)</span> because he gives warning before <span class="add">[the approach of]</span> the lion. <span class="auth">(T, Ṣ, Ḳ.)</span> And <span class="ar long">صَاحِبُ البَرِيِد</span> <span class="add">[<em>The master of the messengers that journey on post-mules</em> or <em>post-horses</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[And <span class="ar long">خَيْلٌ البَرِيِد</span>, occurring in many histories, &amp;c., <em>The post-horses, that carry messengers and others.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bariydN_B3">
					<p>Also, having been applied to a messenger on a post-mule <span class="add">[or post-horse]</span>, it then became applied to The <em>space,</em> or <em>distance, traversed by the messenger thus called;</em> <span class="auth">(Mgh, Mṣb;*)</span> the <em>space,</em> or <em>distance, between each</em> <span class="ar">سِكَّة</span> <em>and the</em> <span class="ar">سِكَّة</span> <em>next to it;</em> the <span class="ar">سكّة</span> being a structure of either of the kinds called <span class="ar">بَيْت</span> and <span class="ar">قُبَّة</span>, or a <span class="ar">رِبَاط</span> <span class="add">[explained above]</span>, in which the appointed messengers lodge; <span class="auth">(Z in the Fáïk;)</span> the <em>space,</em> or <em>distance, between two stations,</em> or <em>places of alighting;</em> or <em>two parasangs,</em> or <em>leagues;</em> <span class="auth">(M, Ḳ;)</span> <span class="add">[<em>six miles;</em>]</span> each parasang, or league, being three miles, and each mile being four thousand cubits: <span class="auth">(TA:)</span> or <em>twelve miles;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> i. e. <em>four parasangs,</em> or <em>leagues:</em> <span class="auth">(Mgh, TA:)</span> <span class="add">[for]</span> the space, or distance, between each station termed <span class="ar">سِكَّة</span> and the next to it is either two parasangs or four: <span class="auth">(Z in the Fáïk:)</span> the distance of <em>twelve miles</em> is <span class="add">[also]</span> termed <span class="ar long">سِكَّةُ البَرِيِد</span>: <span class="auth">(T:)</span> the pl. is as above. <span class="auth">(T, Z.)</span> A journey of four <span class="ar">بُرُد</span>, or forty-eight miles, renders it allowable to shorten prayers; which miles are of the Háshimee measure, such as are measured on the road to Mekkeh. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَرِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bariydN_B4">
					<p>Also The <em>course,</em> or <em>pace,</em> of a camel <em>along the space thus called:</em> so in the following verse of Muzarrid, in praise of 'Arábeh El-Owsee:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَدَتْكَ عَرَابَ اليَوْمَ أُمِّى وَخَالَتِى</span> *</div> 
						<div class="star">* <span class="ar long">وَنَاقَتِىَ النَّاجِى إِلَيْكَ بَرِيدُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>May my mother, and my maternal aunt, and my she-camel that is swift in her course to thee from one station to another, be ransoms for thee, O 'Arábeh,</em> <span class="auth">(the name being contracted,)</span> <em>this day!</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buraAdapN">
				<h3 class="entry"><span class="ar">بُرَادَةٌ</span></h3>
				<div class="sense" id="buraAdapN_A1">
					<p><span class="ar">بُرَادَةٌ</span> <em>Filings;</em> <span class="auth">(M, Mgh, Ḳ;)</span> <em>what falls from iron</em> <span class="add">[&amp;c.]</span> <em>when filed.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buruwdapN">
				<h3 class="entry"><span class="ar">بُرُودَةٌ</span></h3>
				<div class="sense" id="buruwdapN_A1">
					<p><span class="ar">بُرُودَةٌ</span>: <a href="#barodN">see <span class="ar">بَرْدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBaAdapN">
				<h3 class="entry"><span class="ar">بَرَّادَةٌ</span></h3>
				<div class="sense" id="barBaAdapN_A1">
					<p><span class="ar">بَرَّادَةٌ</span> <em>A vessel which cools water:</em> <span class="auth">(M, Ḳ:)</span> or <em>a</em> <span class="ar">كَوَّازَة</span> <span class="add">[app. meaning either a <em>stand,</em> or a <em>shelf, upon which mugs</em> (<span class="ar">كِيزَان</span>, <a href="#kuwz">pl. of <span class="ar">كُوز</span></a>,) <em>are placed;</em> erroneously in the Ḳ, <span class="ar">كُوَّارَةٌ</span>, and <span class="ar">كُوَارَةٌ</span>, as I find it in different copies;]</span> <em>upon which water is cooled:</em> <span class="auth">(Lth, T, Ḳ:*)</span> but <span class="add">[Az says,]</span> I know not whether it be a classical or a post-classical word. <span class="auth">(T.)</span> Hence the saying, <span class="ar long">بَاتَتْ كِيزَانُهُمْ عَلَى البَرَّادَةِ</span> <em>Their mugs passed the night upon the</em> <span class="ar">برّادة</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAridN">
				<h3 class="entry"><span class="ar">بَارِدٌ</span></h3>
				<div class="sense" id="baAridN_A1">
					<p><span class="ar">بَارِدٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> <em>Cold; chill; cool;</em> <span class="auth">(Ṣ, Mṣb;)</span> applied to water <span class="add">[&amp;c.]</span>; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَرْدٌ↓</span></span>, <span class="add">[originally an inf. n., like <span class="ar">عَدْلٌ</span>, used as an epithet,]</span> <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَرُودٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">بُرَادٌ↓</span></span>; <span class="auth">(M, Ḳ;)</span> but the last two are intensive forms <span class="add">[signifying <em>very cold</em> or <em>chill</em> or <em>cool</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَارِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAridN_A2">
					<p>‡ Anything <em>loved, beloved, liked,</em> or <em>approved.</em> <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">عَيْشٌ بَاردٌ</span> ‡ <em>An easy and a pleasant life,</em> or <em>state of life.</em> <span class="auth">(ISk,* T,* M, A, L, Ḳ.)</span> And <span class="ar long">لَيْلَةٌ بَارِدَةٌ العَيْشِ</span>, and<span class="arrow"><span class="ar long">بَرْدَةُ↓ العَيْشِ</span></span>, <span class="add">[the latter written in the TT <span class="ar long">بَرَدَةُ العيش</span>,]</span> ‡ <em>A night of easy and pleasant life.</em> <span class="auth">(M, L.)</span> And <span class="ar long">غَنيمَةٌ بَارِدَةٌ</span>: see the latter word.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَارِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAridN_A3">
					<p><span class="ar long">سَمُومٌ بَارِدٌ</span> ‡ <em>A hot wind that is constant, continual, permanent, settled,</em> or <em>incessant.</em> <span class="auth">(Ṣ, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَارِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAridN_A4">
					<p><span class="ar long">لِى عَلَيْهِ أَلْفٌ بَارِدٌ</span> ‡ <em>A thousand</em> <span class="add">[pieces of money, &amp;c.]</span> <em>are incumbent,</em> or <em>obligatory, on him, to me, and established against him;</em> or <em>are owed,</em> or <em>due, to me, by,</em> or <em>from, him.</em> <span class="auth">(Ṣ, M.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَارِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAridN_A5">
					<p><span class="ar long">جَآءَ فُلَانٌ بَارِدًا مُخُّهُ</span>, and <span class="ar long">بَارِدَ العِظَامَ</span>, ‡ <em>Such a one came in a lean,</em> or <em>an emaciated, state:</em> in the contr. case, one says, <span class="ar long">حَارَّا مُخُّهُ</span>, and <span class="ar long">حَارَّ العِظَامِ</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَارِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAridN_A6">
					<p><span class="add">[<span class="ar">بَارِدٌ</span> also signifies † <em>Blunt;</em> applied to a sword and the like: <a href="#brd_1">see 1</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">بَارِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baAridN_A7">
					<p><span class="add">[And, contr., † <em>Sharp:</em> for you say,]</span> <span class="ar long">مُرْهَفَاتٌ بَوَارِدُ</span> <span class="add">[<a href="#baAridapN">pl. of <span class="ar">بَارِدَةٌ</span></a>, meaning]</span> † <em>Sharp,</em> or <em>cutting, swords:</em> <span class="auth">(TA:)</span> or <em>slaying swords.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAridapN">
				<h3 class="entry"><span class="ar">بَارِدَةٌ</span></h3>
				<div class="sense" id="baAridapN_A1">
					<p><span class="ar">بَارِدَةٌ</span> † <em>Spoil acquired without fatigue;</em> <span class="auth">(IAạr, T;)</span> also termed <span class="ar long">غَنِيمَةٌ بَارِدَةٌ</span>; and to this is likened, by the Prophet, fasting in winter. <span class="auth">(T.)</span> Also † <em>Gain made by merchandise at the time of one's buying it.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboradu">
				<h3 class="entry"><span class="ar">أَبْرَدُ</span></h3>
				<div class="sense" id="Oaboradu_A1">
					<p><span class="ar">أَبْرَدُ</span> <span class="add">[<em>More,</em> and <em>most, cold,</em> or <em>chill,</em> or <em>cool</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">أَبْرَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oaboradu_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">الأَبْرَدَانِ</span> and<span class="arrow"><span class="ar">البَرْدَانِ↓</span></span> <em>The morning, between daybreak and sunrise, and the evening, between sunset and nightfall;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> <span class="pb" id="Page_0186"></span>also called <span class="ar">العَصْرَانِ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">الصَّرْعَانِ</span> and <span class="ar">الرِّدْفَانِ</span>: <span class="auth">(T:)</span> or <span class="auth">(as in the Ṣ, but in the M and Ḳ “and”)</span> <em>the morning-shade and evening-shade:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> so called because of their coldness, or coolness. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">أَبْرَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oaboradu_A3">
					<p><a href="#baridN">See also <span class="ar">بَرِدٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">أَبْرَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oaboradu_A4">
					<p><span class="ar long">ثَوْرٌ أَبْرَدُ</span> <em>A bull upon which are spots,</em> or <em>patches, of white and black:</em> <span class="auth">(Ṣ, M:)</span> of the dial. of El-Yemen. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">أَبْرَدُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oaboradu_A5">
					<p>And <span class="ar">الأَبْرَدُ</span> <em>The leopard:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">الأَبْرَدَةُ</span>}</span></add>: <span class="auth">(T, Ḳ: <span class="add">[but in the TT, the fem. is written like the masc.:]</span>)</span> pl. <span class="ar">الأَبَارِدُ</span>. <span class="auth">(T, Ḳ.)</span> The female is also called <span class="ar">الخَيْثَمَةُ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iiboradapu">
				<h3 class="entry"><span class="ar">إِبْرَدَةُ</span></h3>
				<div class="sense" id="Iiboradapu_A1">
					<p><span class="ar">إِبْرَدَةُ</span>, <span class="auth">(Ṣ, M, &amp;c.,)</span> with kesr <span class="auth">(Ṣ, Mgh, Ḳ)</span> to the <span class="ar">ء</span> and the <span class="ar">ر</span> <span class="auth">(Mgh, TA,)</span> <span class="add">[in the CK <span class="ar">اِبْرَدَة</span>,]</span> <em>Cold in the belly,</em> or <em>inside;</em> <span class="auth">(M, Ḳ;)</span> <em>a well-known malady, arising from the prevalence of cold and humidity, and preventing one, by languor, from performing the act of coition:</em> <span class="auth">(Ṣ, Mgh:)</span> and <em>a dripping of the urine, which prevents a man's taking pleasure in women.</em> <span class="auth">(T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">إِبْرَدَةُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Iiboradapu_A2">
					<p>Also <em>Coldness</em> of the damp earth, and of rain. <span class="auth">(M, L.)</span> An Arab says, <span class="ar long">إِنَّهَا لَبَارِدَةٌ اليَوْمَ</span> <span class="add">[<em>Verily it</em> <span class="auth">(the morning, <span class="ar">الغَدَاةُ</span>, L)</span> <em>is cold to-day</em>]</span>; and another says to him, <span class="ar long">لَيْسَتْ بِبَارِدَةٍ إِنَّمَا هِىَ إِبْرِدَةُ الثَّرَى</span> <span class="add">[<em>It is not cold: it is only the coldness of the damp earth</em>]</span>. <span class="auth">(Ṣ, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboradN">
				<h3 class="entry"><span class="ar">مُبْرَدٌ</span></h3>
				<div class="sense" id="muboradN_A1">
					<p><span class="ar">مُبْرَدٌ</span> <span class="add">[pass. part. n. of 4]</span>. You say, <span class="ar long">أَرْضٌ مُبْرَدَةٌ</span>: <a href="#maboruwdN">see <span class="ar">مَبْرُودٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muboridN">
				<h3 class="entry"><span class="ar">مُبْرِدٌ</span></h3>
				<div class="sense" id="muboridN_A1">
					<p><span class="ar">مُبْرِدٌ</span> <span class="add">[act. part. n. of 4]</span>. You say, <span class="ar long">جِئْنَاكَ مُبْرِدِينَ</span> <em>We came to thee when the heat had become allayed.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">مُبْرِدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muboridN_B1">
					<p>Also One <em>sending,</em> or <em>who sends, a</em> <span class="ar">بَرِيد</span> <span class="add">[or <span class="ar">بُرُد</span>, i. e., <em>a messenger on a post-mule</em> or <em>posthorse,</em> or <em>messengers on post-mules</em> or <em>post-horses</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboradN">
				<h3 class="entry"><span class="ar">مِبْرَدٌ</span></h3>
				<div class="sense" id="miboradN_A1">
					<p><span class="ar">مِبْرَدٌ</span> <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> <em>A file;</em> <span class="auth">(M;)</span> syn. <span class="ar">سُوهَانٌ</span>; <span class="auth">(M, Ḳ;)</span> which is a Persian word: <span class="auth">(M:)</span> pl. <span class="ar">مَبَارِدُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">مِبْرَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="miboradN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">جَعَلَ لِسَانِهِ عَلَيْهِ مُبْرِدًا</span> ‡ <span class="add">[<em>He made his tongue like a file upon him;</em> i. e.]</span> <em>he annoyed him,</em> or <em>hurt him, with his tongue, and vituperated him.</em> <span class="auth">(A.)</span> <span class="add">[See a saying of Moosà Ibn-Jábir voce <span class="ar">جِنٌّ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboradapN">
				<h3 class="entry"><span class="ar">مَبْرَدَةٌ</span></h3>
				<div class="sense" id="maboradapN_A1">
					<p><span class="ar">مَبْرَدَةٌ</span> <span class="add">[<em>A cause of coldness</em> or <em>coolness</em>]</span>. You say, <span class="ar long">هٰذَا الشَّىْءُ مَبْرَدَةٌ لِلْبَدَنِ</span> <span class="add">[<em>This thing is a cause of coldness,</em> or <em>coolness, to the body</em>]</span>: and Aṣ relates that he said to an Arab of the desert, “What induceth thee to take a sleep in the morning while the sun is yet low?” and he answered, <span class="ar long">إِنَّهَا مَبْرَدَةٌ فِى الصَّيْفِ مَسْخَنَةٌ فِى الشِّتَآءِ</span> <span class="add">[<em>Verily it is a cause of coolness in the summer,</em> and <em>a cause of warmth in the winter</em>]</span>. <span class="auth">(Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubarBadN">
				<h3 class="entry"><span class="ar">مُبَرَّدٌ</span></h3>
				<div class="sense" id="mubarBadN_A1">
					<p><span class="ar">مُبَرَّدٌ</span>: <a href="#maboruwdN">see what follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboruwdN">
				<h3 class="entry"><span class="ar">مَبْرُودٌ</span></h3>
				<div class="sense" id="maboruwdN_A1">
					<p><span class="ar">مَبْرُودٌ</span> <em>Made,</em> or <em>rendered, cold</em> or <em>chill</em> or <em>cool:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> <span class="add">[and<span class="arrow"><span class="ar">مُبَرَّدٌ↓</span></span> signifies the same in an intensive manner:]</span> applied to water <span class="add">[&amp;c.: or signifying <em>mixed with snow:</em> <a href="#brd_1_B1">see <span class="ar">بَرَدَهُ</span></a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">مَبْرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maboruwdN_A2">
					<p><span class="ar long">شَجَرَةٌ مَبْرُودَةٌ</span> <em>A tree deprived of its leaves by the cold.</em> <span class="auth">(AḤn, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">مَبْرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maboruwdN_A3">
					<p><span class="ar long">أَرْضٌ مَبْرُودَةٌ</span> <span class="auth">(M, A, Ḳ)</span> and<span class="arrow"><span class="ar">مُبْرَدَةٌ↓</span></span> <span class="auth">(Ḳ)</span> <em>Land,</em> or <em>ground, hailed upon:</em> <span class="auth">(M, Ḳ:)</span> or <em>snowed upon.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برد</span> - Entry: <span class="ar">مَبْرُودٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="maboruwdN_A4">
					<p><a href="#baruwdN">See also <span class="ar">بَرُودٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0183.pdf" target="pdf">
							<span>Lanes Lexicon Page 183</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0184.pdf" target="pdf">
							<span>Lanes Lexicon Page 184</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0185.pdf" target="pdf">
							<span>Lanes Lexicon Page 185</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0186.pdf" target="pdf">
							<span>Lanes Lexicon Page 186</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
