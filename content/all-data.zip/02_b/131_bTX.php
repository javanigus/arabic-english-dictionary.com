<article class="root" id="Root_bTX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/130_bTrk">بطرك</a></span>
				<span class="ar">بطش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/132_bTq">بطق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bTX_1">
				<h3 class="entry">1. ⇒ <span class="ar">بطش</span></h3>
				<div class="sense" id="bTX_1_A1">
					<p><span class="ar long">بَطَشَ بِهِ</span>, <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْطِشُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْطُشُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> the former of which is that adopted by the seven readers <span class="auth">(Mṣb, TA)</span> in chap. xliv. verse 15 of the Ḳur, <span class="auth">(TA,)</span> inf. n. <span class="ar">بَطْشٌ</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> <em>He seized him violently; laid violent hands upon him:</em> <span class="auth">(Ṣ, Mṣb:)</span> <em>assaulted him:</em> <span class="auth">(Ṣ:)</span> or <em>he seized him with violence and assault:</em> <span class="auth">(A, Ḳ:)</span> or <em>he seized him vehemently, in anger:</em> <span class="auth">(Mgh:)</span> and <em>he laid hold upon him</em> <span class="auth">(Mgh, TA)</span> <em>vehemently,</em> <span class="auth">(TA,)</span> <em>in making an assault:</em> <span class="auth">(Mgh, TA:)</span> and<span class="arrow"><span class="ar">أَبْطَشَهُ↓</span></span> signifies the same as <span class="ar long">بَطَشَ بِهِ</span>, <span class="auth">(Ḳ,)</span> but is rare, occurring in the words <span class="add">[of the Ḳur xliv. 15]</span>, <span class="ar long">يَوْمَ نُبْطِشُ البَطْشَةَ الكُبْرَى</span>, accord. to the reading of El-Ḥasan and Ibn-Rejà, <span class="add">[meaning <em>On the day when we make the greatest assault:</em>]</span> or, accord. to AḤát, <span class="add">[and Bḍ says the like,]</span> the meaning is, <span class="add">[<em>on the day when</em>]</span> <em>we give power over them to such as shall assault them</em> <span class="add">[<em>with the great assault;</em> or <em>make to assault with the great assault</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTX_1_A2">
					<p>Also <em>He took it,</em> namely, anything, or <em>took hold of it,</em> <span class="auth">(Lth, Ḳ,* TA,)</span> or <em>clung to it,</em> <span class="auth">(TA,)</span> <em>strongly.</em> <span class="auth">(Lth, Ḳ, TA.)</span> In the saying of El-Hulwánee, <span class="ar long">وَمَا لَا يَقَعُ عَلَيْهِ العَيْنُ وَلَا يَبْطِشُهُ الكَفُّ</span>, <span class="add">[meaning <em>And that upon which the eye falls not, and of which the hand does not take hold,</em>]</span> the prep. <span class="add">[<span class="ar">بِ</span>]</span> is understood; or the verb is thus used as implying the meaning of <span class="ar">الأَخْذُ</span> and <span class="ar">التَّنَاوُلُ</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bTX_1_A3">
					<p><span class="ar long">بَطَشَتْ بِهِمْ أَهْوَالُ الدُّنْيَا</span> ‡ <span class="add">[<em>The terrors of the world assaulted them</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bTX_1_A4">
					<p><span class="ar long">بَطَشَتِ اليَدُ</span> <em>The hand worked, wrought,</em> or <em>laboured.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bTX_1_A5">
					<p><span class="ar long">فُلَانٌ يَبْطِشُ فِى العِلْمِ بِبَاعٍ بَسِيطٍ</span> ‡ <span class="add">[<em>Such a one labours in science with extensive ability</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bTX_1_A6">
					<p><span class="ar long">بَطَشَ مِنَ الحُمَّى</span> ‡ <em>He recovered from the fever, being still weak.</em> <span class="auth">(Aboo-Málik, A,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTX_3">
				<h3 class="entry">3. ⇒ <span class="ar">باطش</span></h3>
				<div class="sense" id="bTX_3_A1">
					<p><span class="ar">باطشهُ</span>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">مُبَاطَشَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">بِطَاشٌ</span>, <span class="auth">(TA,)</span> <em>He laboured, strove, struggled, contended,</em> or <em>conflicted, with him, to prevail,</em> or <em>overcome;</em> syn. of the inf. n. <span class="ar">مُعَالَجَةٌ</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bTX_3_A2">
					<p><span class="ar">بَاطَشَا</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">مُبَاطَشَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>Each of them two stretched forth his hand towards the other to seize him violently</em> <span class="auth">(Ḳ, TA)</span> <em>and to assault him quickly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bTX_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابطش</span></h3>
				<div class="sense" id="bTX_4_A1">
					<p><a href="#bTX_1">see 1</a>, where two meanings are assigned to it.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bTX_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبطّش</span></h3>
				<div class="sense" id="bTX_5_A1">
					<p><span class="ar long">الرِّكَابُ تَبَطَّشُ بِأَحْمَالِهَا</span>, <span class="add">[for <span class="ar">تَبَطَّشُ</span>,]</span> ‡ <em>The travelling-camels walk with slow steps</em> (<span class="ar">تَزَحَّفُ</span> <span class="add">[for <span class="ar">تَتَزَحَّفُ</span>]</span>) <em>with their burdens, hardly moving.</em> <span class="auth">(Ibn-ʼAbbád, Z, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baToXN">
				<h3 class="entry"><span class="ar">بَطْشٌ</span></h3>
				<div class="sense" id="baToXN_A1">
					<p><span class="ar">بَطْشٌ</span> <a href="#bTX_1">inf. n. of 1 <span class="add">[q. v.]</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: <span class="ar">بَطْشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baToXN_A2">
					<p>Also <em>Might,</em> or <em>strength, in war</em> or <em>fight:</em> or <em>courage; valour,</em> or <em>valiantness; prowess:</em> syn. <span class="ar">بَأْسٌ</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">رَجُلٌ شَدِيدُ البَطْشِ</span> <span class="add">[<em>A man of great might,</em>, &amp;c.]</span>. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطش</span> - Entry: <span class="ar">بَطْشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baToXN_A3">
					<p>And <em>Anger.</em> <span class="auth">(Ḥar p. 258.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baToXapN">
				<h3 class="entry"><span class="ar">بَطْشَةٌ</span></h3>
				<div class="sense" id="baToXapN_A1">
					<p><span class="ar">بَطْشَةٌ</span> <em>An assault; a violent seizure.</em> <span class="auth">(Ṣ.)</span> <span class="ar long">البَطْشَةُ الكُبْرَى</span> <span class="add">[<em>The greatest assault</em>]</span>, in the Ḳur xliv. 15, is applied to the day of resurrection, or to the battle of Bedr. <span class="auth">(Bḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baTiyXN">
				<h3 class="entry"><span class="ar">بَطِيشٌ</span></h3>
				<div class="sense" id="baTiyXN_A1">
					<p><span class="ar">بَطِيشٌ</span> <em>i. q.</em> <span class="ar long">شَدِيدُ البَطْشِ</span>; <span class="auth">(Ḳ;)</span> <span class="add">[<a href="#baToXN">see <span class="ar">بَطْشٌ</span></a>;]</span> applied to a man; as also<span class="arrow"><span class="ar">بَطَّاشٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baTBaAXN">
				<h3 class="entry"><span class="ar">بَطَّاشٌ</span></h3>
				<div class="sense" id="baTBaAXN_A1">
					<p><span class="ar">بَطَّاشٌ</span>: <a href="#baTiyXN">see <span class="ar">بَطِيشٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboTiXN">
				<h3 class="entry"><span class="ar">مَبْطِشٌ</span></h3>
				<div class="sense" id="maboTiXN_A1">
					<p><span class="add">[<span class="ar">مَبْطِشٌ</span>, or <span class="ar">مَبْطَشٌ</span>, <em>A place of assault,</em> or <em>the like;</em> <a href="#mabaATiXu">sing. of <span class="ar">مَبَاطِشُ</span></a>, of which the following is an ex.]</span> <span class="ar long">سَلَكُوا أَرْضًا بَعِيدَةَ المَسَالِكِ قَرِيبَةَ المَهَالِكِ وَوُقِذُوا بِمَبَاطِشِهَا وَمَا أُنْقِذُوا مِنْ مَعَاطِشِهَا</span> ‡ <span class="add">[<em>They traversed a land whereof the roads were farextending, whereof the places of destruction were near, and they were prostrated,</em> or <em>left sick, in its places of assault, and were not saved from its places of thirst</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0218.pdf" target="pdf">
							<span>Lanes Lexicon Page 218</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
