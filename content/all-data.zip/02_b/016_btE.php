<article class="root" id="Root_btE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/015_btr">بتر</a></span>
				<span class="ar">بتع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/017_btk">بتك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="btE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بتع</span></h3>
				<div class="sense" id="btE_1_A1">
					<p><span class="ar">بَتِعَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْتَعُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَتَعٌ</span>, <span class="auth">(ISh, Ṣ, Ḳ,)</span> <em>He</em> <span class="auth">(a horse, Ḳ)</span> <em>was,</em> or <em>became, long in the neck, and at the same time strong in its base:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>thick and fleshy in the neck:</em> or <em>strong in the neck.</em> <span class="auth">(ISh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="btE_1_A2">
					<p><em>It,</em> <span class="auth">(the body,)</span> and <em>he,</em> <span class="auth">(a man,)</span> <em>was,</em> or <em>became, strong in the joints.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="btE_1_B1">
					<p><span class="ar">بَتَعَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْتِعُ</span>}</span></add>, <em>He prepared,</em> and <em>made,</em> the beverage called <span class="ar">نَبِيذ</span>. <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> <span class="add">[<a href="#bitoEN">See <span class="ar">بِتْعٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batoEN">
				<h3 class="entry"><span class="ar">بَتْعٌ</span></h3>
				<div class="sense" id="batoEN_A1">
					<p><span class="ar">بَتْعٌ</span>, with fet-ḥ, <span class="add">[perhaps a mistake for <span class="ar">بَتَعٌ</span>, (<a href="#btE_1">see 1</a>,)]</span> <em>Strength.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bitoEN">
				<h3 class="entry"><span class="ar">بِتْعٌ</span></h3>
				<div class="sense" id="bitoEN_A1">
					<p><span class="ar">بِتْعٌ</span> <span class="auth">(Ṣ, Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">بِتْعٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> <span class="add">[<em>Hydromel,</em> or]</span> <span class="ar">نَبِيذ</span> <em>of honey,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>that has become strong;</em> <span class="auth">(Ḳ;)</span> <span class="ar">نبيذ</span> <em>made of honey, as though it were wine in strength, the drinking of which is disapproved;</em> <span class="auth">(El-ʼEyn;)</span> <em>an intoxicating beverage made of honey, in El-Y emen:</em> <span class="auth">(Mgh:)</span> or <em>wine made of fresh dates:</em> <span class="auth">(Ibn-El-Beytár, cited by Golius:)</span> or the <em>pure juice of grapes;</em> <span class="auth">(Ibn-ʼAbbád, Ḳ;)</span> said by some to be so called by reason of the strength therein, from <span class="ar">بَتَعٌ</span>, <span class="add">[<a href="#btE_1">inf. n. of <span class="ar">بَتِعَ</span></a>,]</span> meaning “strength of the neck:” <span class="auth">(TA:)</span> or the former signifies <em>wine:</em> <span class="auth">(Ḳ:)</span> or <em>wine made of honey:</em> <span class="auth">(AḤn:)</span> a word of the dial. of El-Yemen: <span class="auth">(TA:)</span> the wine of El-Medeeneh is from unripe dates, and from ripe dates; that of the Persians, from grapes; that of the people of El-Yemen is <span class="ar">بِتْع</span>, and is from honey; and that of the Abyssinians is <span class="ar">سُكُرْكَة</span>. <span class="auth">(Aboo-Moosà El-Ash'aree.)</span> <span class="add">[<a href="#mizorN">See <span class="ar">مِزْرٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتع</span> - Entry: <span class="ar">بِتْعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bitoEN_B1">
					<p><a href="#batEN">See also <span class="ar">بَتعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batiEN">
				<h3 class="entry"><span class="ar">بَتِعٌ</span> / <span class="ar">بَتِعَةٌ</span></h3>
				<div class="sense" id="batiEN_A1">
					<p><span class="ar">بَتِعٌ</span> A horse <em>long in the neck, and at the same time strong in its base:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَتِعَةٌ</span>}</span></add>: <span class="auth">(Aṣ, Ṣ, Ḳ:)</span> or <em>long in the neck.</em> <span class="auth">(IAạr.)</span> You say also <span class="ar long">عُنُقٌ بَتِعٌ</span> <span class="auth">(ISh, TA)</span> and <span class="ar">بَتِعَةٌ</span> <span class="auth">(TA)</span> <em>A strong neck:</em> or <em>an excessively long neck:</em> <span class="auth">(TA:)</span> or <em>a thick and fleshy neck:</em> <span class="auth">(ISh:)</span> and<span class="arrow"><span class="ar">أَبْتَعُ↓</span></span> <span class="add">[in like manner]</span> signifies <em>full,</em> applied to a <span class="ar">رُسْغ</span>, <span class="add">[app. here meaning a pastern]</span>, <span class="auth">(Ḳ,)</span> accord. to Lth, who cites, from Ru-beh, the phrase <span class="ar long">رُسْغًا أَبْتَعَ</span>: but IB thinks that the right reading is <span class="ar long">جِيدًا أَبْتَعَ</span> <span class="add">[<em>a full neck</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتع</span> - Entry: <span class="ar">بَتِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="batiEN_A2">
					<p>Also A <em>tall</em> man: <span class="auth">(L, TA:)</span> in this sense, accord. to the Ḳ, <span class="arrow"><span class="ar">بِتْعٌ↓</span></span>, which is a mistake: <span class="auth">(TA:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَتِعَةٌ</span>}</span></add>. <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بتع</span> - Entry: <span class="ar">بَتِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="batiEN_A3">
					<p>And <em>Strong in the joints,</em> applied to a body, <span class="auth">(Lth, Ḳ,)</span> and to a man; as also<span class="arrow"><span class="ar">أَبْتَعُ↓</span></span>: <span class="auth">(Ḳ:)</span> fem. of the former with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَتِعَةٌ</span>}</span></add>: <span class="auth">(TA:)</span> and of<span class="arrow">↓ the latter</span>, <span class="ar">بَتْعَآءُ</span>: and pl. of the latter, <span class="ar">بُتْعٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="butaEu">
				<h3 class="entry"><span class="ar">بُتَعُ</span></h3>
				<div class="sense" id="butaEu_A1">
					<p><span class="ar">بُتَعُ</span> <a href="#batoEaACu">pl. of <span class="ar">بَتْعَآءُ</span></a>, <a href="#OabotaEu">fem. of <span class="ar">أَبْتَعُ</span>, q. v.</a></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bitaEN">
				<h3 class="entry"><span class="ar">بِتَعٌ</span></h3>
				<div class="sense" id="bitaEN_A1">
					<p><span class="ar">بِتَعٌ</span>: <a href="#bitoEN">see <span class="ar">بِتْعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="batBaAEN">
				<h3 class="entry"><span class="ar">بَتَّاعٌ</span></h3>
				<div class="sense" id="batBaAEN_A1">
					<p><em>A vintner,</em> in the dial. of El-Yemen. <span class="auth">(TA.)</span> <span class="add">[<a href="#bitEN">See <span class="ar">بِتعٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAtiEN">
				<h3 class="entry"><span class="ar">بَاتِعٌ</span></h3>
				<div class="sense" id="baAtiEN_A1">
					<p><span class="ar">بَاتِعٌ</span>: <em>Strong.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabotaEu">
				<h3 class="entry"><span class="ar">أَبْتَعُ</span></h3>
				<div class="sense" id="OabotaEu_A1">
					<p><span class="ar">أَبْتَعُ</span>: <a href="#batiEN">see <span class="ar">بَتِعٌ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بتع</span> - Entry: <span class="ar">أَبْتَعُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabotaEu_B1">
					<p>It is also a word used as a corroborative: you say, <span class="ar long">جَاؤُوا أَجْمَعُونَ أَكْتَعُونَ أَبْتَعُونَ</span> <span class="add">[<em>They came, all of them,</em> or <em>all together</em>]</span>: <span class="auth">(Ṣ:)</span> and <span class="ar long">جَآءَ القَوْمُ أَكْتَعُونَ أَبْتَعُونَ أَبْصَعُونَ</span> <span class="add">[<em>the people,</em> or <em>company of men, came, all of them,</em> or <em>all together</em>]</span>: <span class="auth">(AHeyth:)</span> and <span class="ar long">جَاؤُوا كُلُّهُمْ أَجْمَعُونَ أَكْتَعُونَ أَبْتَعُونَ</span> <span class="add">[<em>they came, all of them, all together</em>]</span>: these words which follow <span class="ar">اجمعون</span> being imitative sequents to it, not occurring save after it <span class="add">[in the order above]</span>: <span class="auth">(O, Ḳ:)</span> or one may begin with whichsoever of them he will, after it. <span class="auth">(Ibn-Keysán, Ḳ.)</span> And <span class="add">[the fem. is <span class="ar">بَتْعَآءُ</span>:]</span> you say <span class="ar long">القَبِيلَةُ كُلُّهَا جَمْعَآءُ كَتْعَآءُ بَصْعَآءُ بَتْعَآءُ</span> <span class="add">[<em>The tribe, all of it, all together:</em> in the CK, erroneously, <span class="ar">كُثْعآءُ</span> <span class="auth">(with damm and <span class="ar">ث</span>)</span> and <span class="ar">بُصْعاءُ</span> and <span class="ar">بُتْعاءُ</span>]</span>. <span class="auth">(Ḳ.)</span> And <span class="add">[<a href="#batoEaACu">the pl. of <span class="ar">بَتْعَآءُ</span></a> is <span class="arrow"><span class="ar">بُتَعُ↓</span></span>, originally <span class="ar">بَتْعَاوَاتٌ</span>:]</span> <span class="pb" id="Page_0150"></span>you say <span class="ar long">النِّسَآءُ كُلُّهُنَّ جُمَعُ كُتَعُ بُصَعُ بُتَعُ</span> <span class="add">[<em>The women, all of them, all together:</em> in the CK, erroneously, <span class="ar long">جُمَعٌ كُتَعٌ بُصَعٌ بُتَعٌ</span>, though it is well known that each of these is determinate, and imperfectly declinable]</span>. <span class="auth">(Ḳ.)</span> It is only necessary that he who mentions all these words should mention first <span class="ar">كُلّ</span>, and follow it with the word formed from <span class="ar long">ج م ع</span>, then add the rest in whatsoever order he will; but the more approved way is to put the word formed from <span class="ar long">ك ت ع</span> before the rest. <span class="auth">(TA.)</span> Fr mentions the phrases <span class="ar long">أَعْجَبنِى القَصْرُ أَجْمَعَ</span> <span class="add">[The palace pleased me, all of it, or altogether]</span>, and <span class="ar long">الدَّارُ جَمْعَآءَ</span> <span class="add">[the house, all of it, or altogether]</span>, with the accus. case, as denotative of state; but does not allow <span class="ar">أَجْمَعُونَ</span> nor <span class="ar">جُمَعُ</span> to be used otherwise than as corroboratives: IDrst, however, allows <span class="ar">أَجْمَعِينَ</span> to be used as a denotative of state; and this is correct; and accord. to both these ways is related the trad., <span class="ar long">فَصَلُّوا جُلُوسًا أَجْمَعِينَ</span> and <span class="ar">أَجْمَعُونَ</span> <span class="add">[And pray ye sitting, all of you, or all together]</span>; though some make <span class="ar">اجمعين</span> <span class="add">[here]</span> to be a corroborative of a pronoun understood in the accus. case, as though the speaker said, <span class="ar long">أَعْنِيكُمْ أَجْمَعِينَ</span> <span class="add">[I mean you, all of you, or all together]</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#OajomEu">But see <span class="ar">أَجْمعُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0149.pdf" target="pdf">
							<span>Lanes Lexicon Page 149</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0150.pdf" target="pdf">
							<span>Lanes Lexicon Page 150</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
