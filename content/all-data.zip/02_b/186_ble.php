<article class="root" id="Root_ble">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/185_blwr">بلور</a></span>
				<span class="ar">بلى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/187_bm">بم</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="ble_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلى</span></h3>
				<div class="sense" id="ble_1_A1">
					<p><span class="ar">بَلِىَ</span>: <a href="index.php?data=02_b/184_blw">see art. <span class="ar">بلو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="ble_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلى</span></h3>
				<div class="sense" id="ble_4_A1">
					<p><span class="ar long">ابلى الثَّوْبَ</span>: <a href="index.php?data=02_b/184_blw">see art. <span class="ar">بلو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biloeN">
				<h3 class="entry"><span class="ar">بِلْىٌ</span></h3>
				<div class="sense" id="biloeN_A1">
					<p><span class="ar">بِلْىٌ</span> and <span class="ar long">بِلْىُ سَفَرٍ</span>:, &amp;c.: <a href="index.php?data=02_b/184_blw">see art. <span class="ar">بلو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balae.1">
				<h3 class="entry"><span class="ar">بَلَى</span></h3>
				<div class="sense" id="balae.1_A1">
					<p><span class="ar">بَلَى</span> is a particle; <span class="auth">(Ṣ, Mṣb, Mughnee;)</span> <em>contr. of</em> <span class="ar">لَا</span>: <span class="auth">(Ṣ:)</span> not a noun: <span class="auth">(Sb, Ṣ:)</span> it is a replicative; <span class="auth">(Ṣ, Mughnee;)</span> an affirmative of what is said <span class="add">[in that to which it is a reply]</span>; <span class="auth">(Ṣ, Mṣb;)</span> <span class="add">[with very few exceptions]</span> relating only to a negation, which it annuls: <span class="auth">(Mṣb, Mughnee:)</span> the final letter is a radical: or, accord. to some, the word is originally <span class="ar">بَلْ</span>, <span class="add">[after which an affirmation is to be understood,]</span> and the final letter is augmentative: and some of these say that this letter is a denotative of the fem. gender, because it is <span class="add">[often]</span> pronounced with imáleh. <span class="auth">(Mughnee.)</span> It is a reply to an interrogation in which is a negative, <span class="auth">(T, M, Mṣb, Mughnee, Ḳ,)</span> and affirms what is said to thee <span class="add">[in that interrogation]</span>; <span class="auth">(M, Ḳ;)</span> whether it be an interrogation in the proper sense, <span class="auth">(Mughnee,)</span> as when you say to another, <span class="ar long">أَلَمْ تَفْعَلْ كَذَا</span> <span class="add">[<em>Didst thou not such a thing?</em>]</span>, and he replies, <span class="ar">بَلَى</span> <span class="add">[meaning <em>Yes,</em> or <em>yea,</em> or <em>ay,</em> I did]</span>, <span class="auth">(T,)</span> or as when one says, <span class="ar long">أَلَيْسَ زَيْدٌ بِقَائِمٍ</span> <span class="add">[<em>Is not Zeyd standing?</em>]</span>, and you reply, <span class="ar">بَلَى</span> <span class="add">[<em>Yes,</em> he is]</span>; or be meant to convey reproof, <span class="auth">(Mughnee,)</span> as in the Ḳur <span class="add">[lxxv. 3 and 4]</span>, <span class="ar long">أَيَحْسَبُ الإِنْسَانُ أَنْ لَنْ نَجْمَعَ عِظَامَهُ بَلَى</span> <span class="add">[<em>Doth man think that we will not collect his bones? Yes</em>]</span>, <span class="auth">(Mṣb, Mughnee,)</span> i. e., we will collect them; <span class="auth">(Mṣb;)</span> or be meant to make a person confess, or acknowledge, a thing, <span class="auth">(Mughnee,)</span> as in the Ḳur <span class="add">[vii. 171]</span>, <span class="ar long">أَلَسْتُ بِرَبِّكُمْ قَالُوا بَلَى</span> <span class="add">[<em>Am I not your Lord? They said, Yea</em>]</span>. <span class="auth">(M, Mughnee.)</span> It is also a reply to a simple negation, <span class="auth">(Mṣb, Mughnee,)</span> as when I say, <span class="ar long">مَا قَامَ زَيْدٌ</span> <span class="add">[<em>Zeyd did not stand,</em> or <em>has not stood</em>]</span>, and you reply, <span class="ar">بَلَى</span> as an affirmative <span class="add">[meaning <em>Yes,</em> he did, or he has]</span>. <span class="auth">(Mṣb.)</span> It occurs in the Ḳur <span class="add">[xxxix. 60]</span>, where it is said, <span class="ar long">بَلَى قَدْ جَآءَتْكَ آيَاتِى</span> <span class="add">[<em>Yea, my signs have come to thee</em>]</span>, preceded by that which is not literally a negation, but which has the force of a negation; for the preceding saying, <span class="ar long">لَوْ أَنَّ ٱللّٰهَ هَدَانِى</span> <span class="add">[<em>If God had directed me aright,</em> or <em>would that God</em>, &amp;c.]</span>, is like the saying, <span class="ar long">مَا هُدِيتُ</span> <span class="add">[<em>I was not directed aright</em>]</span>. <span class="auth">(M.)</span> It also occurs in the books of traditions, in some instances, as a reply to an interrogation without a negative; but these instances are rare, and not to be followed in rendering revelation. <span class="auth">(Mughnee.)</span> Az says that when a man says to another, <span class="ar long">أَلَا تَقُومُ</span> <span class="add">[<em>Wilt thou not stand?</em>]</span>, and the latter replies, <span class="ar">بَلَى</span>, he means <span class="ar long">بَلْ أَقُومُ</span> <span class="add">[<em>Nay, I will stand</em>]</span>, adding the alif <span class="add">[written <span class="ar">ى</span>]</span> to make the pause good; for if he said, <span class="ar">بَلْ</span>, the other would expect something more to be said after it. <span class="auth">(TA.)</span> It is said that the pronunciation termed imáleh is allowable in the case of <span class="ar">بَلَى</span>; and if so, its final radical letter is <span class="ar">ى</span>: and some of the grammarians say that this pronunciation of <span class="ar">بلى</span> is because, by reason of its completeness and independence of meaning, so that it requires nothing after it, it resembles independent nouns, in the cases of which this pronunciation is allowable. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biloyapN.1">
				<h3 class="entry"><span class="ar">بِلْيَةٌ</span></h3>
				<div class="sense" id="biloyapN.1_A1">
					<p><span class="ar">بِلْيَةٌ</span> and <span class="ar">بَلِىٌّ</span> and <span class="ar">بَلِيَّةٌ</span>: <a href="index.php?data=02_b/184_blw">see art. <span class="ar">بلو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0257.pdf" target="pdf">
							<span>Lanes Lexicon Page 257</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
