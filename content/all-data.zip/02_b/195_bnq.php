<article class="root" id="Root_bnq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/194_bnfsj">بنفسج</a></span>
				<span class="ar">بنق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/196_bnm">بنم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bnq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بنق</span></h3>
				<div class="sense" id="bnq_1_A1">
					<p><span class="ar">بَنَقَ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْنُقُ</span>}</span></add>, inf. n. <span class="ar">بَنْقٌ</span>, <span class="auth">(TḲ,)</span> <em>He joined</em> <span class="add">[a thing to another thing, like as the <span class="ar">بَنِيقَة</span> of a shirt is joined: see the pass. part. n., below]</span>; syn. <span class="ar">وَصَلَ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bnq_2">
				<h3 class="entry">2. ⇒ <span class="ar">بنّق</span></h3>
				<div class="sense" id="bnq_2_A1">
					<p><span class="ar long">بنّق القَمِيصَ</span>, inf. n. <span class="ar">تَبْنِيقٌ</span>, <em>He put a</em> <span class="ar">بَنِيقَة</span> <em>to the shirt.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0260"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنق</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bnq_2_A2">
					<p><span class="ar long">بنّق الجَعْبَةَ</span> ‡ <em>He made the upper part of the quiver wide</em> <span class="add">[<em>by adding to it the like of a</em> <span class="ar">بَنِيقَة</span> <span class="auth">(see the pass. part. n., below,)</span>]</span>, <em>and the lower part narrow:</em> <span class="auth">(Ḳ, TA:)</span> or <em>he widened its upper part, the lower part being</em> <span class="add">[or <em>remaining</em>]</span> <em>narrow.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binaqN">
				<h3 class="entry"><span class="ar">بِنَقٌ</span></h3>
				<div class="sense" id="binaqN_A1">
					<p><span class="ar">بِنَقٌ</span>: <a href="#binayqapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binaqapN">
				<h3 class="entry"><span class="ar">بِنَقَةٌ</span></h3>
				<div class="sense" id="binaqapN_A1">
					<p><span class="ar">بِنَقَةٌ</span>: <a href="#binayqapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binayqN">
				<h3 class="entry"><span class="ar">بِنَيقٌ</span></h3>
				<div class="sense" id="binayqN_A1">
					<p><span class="ar">بِنَيقٌ</span>: <a href="#binayqapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="binayqapN">
				<h3 class="entry"><span class="ar">بِنَيقَةٌ</span></h3>
				<div class="sense" id="binayqapN_A1">
					<p><span class="ar">بِنَيقَةٌ</span> The <span class="ar">لِبْنَة</span>, <span class="auth">(AZ, Abu-l-Hajjáj El-Aạlam, JK, Ṣ, Ḳ,)</span> or <span class="ar">دِخْرِصَة</span>, <span class="auth">(Abu-l-ʼAbbás El-Ahwal, TA,)</span> <span class="add">[both of which signify the <em>gore,</em>]</span> of a shirt, <span class="auth">(AZ, Ṣ, Ḳ,)</span> or of a garment; <span class="auth">(JK;)</span> or the <span class="ar">دخرصة</span> is longer than the <span class="ar">لبنة</span>: <span class="auth">(Seer, TA:)</span> and <em>any piece that is added in a garment or a leathern bucket to widen it:</em> <span class="auth">(Abu-l-Hajjáj El-Aalam, TA:)</span> or, accord. to IDrd, the <span class="ar">دخاريص</span> of a shirt: <span class="auth">(TA: <span class="add">[but this is app. a mistranscription for its sing. <span class="ar">دِخْرِيص</span>, q. v., <a href="#dixoriSap">a dial. var. of <span class="ar">دِخْرِصَة</span></a>:]</span>)</span> or the <span class="ar">جُرُبَّان</span> <span class="add">[or <em>opening at the neck and bosom</em>]</span> of a shirt: <span class="auth">(Ḳ:)</span> <span class="ar">جربّان</span> is prefixed to <span class="ar">البنيقة</span> in a verse of Jereer, governing the latter in the gen. case, to show that both these words have the same meaning: <span class="auth">(TA:)</span> <span class="arrow"><span class="ar">بِنَقَةٌ↓</span></span>, also, signifies the same as <span class="ar">بنيقة</span>; <span class="auth">(JK, Ḳ; <span class="add">[in the latter of which it is mentioned in such a manner as perhaps to denote that it has only the last of the significations above; but I think that this restriction is not meant;]</span>)</span> and its pl. <span class="add">[or rather the coll. gen. n.]</span> is <span class="arrow"><span class="ar">بِنَقٌ↓</span></span>: <span class="auth">(Ibn-ʼAbbád, TA:)</span> Th mentions <span class="ar">بَنَائِقٌ</span> and <span class="ar">بِنَقٌ</span>, and says that the latter is a pl. pl.; <span class="add">[i. e., pl. of the former;]</span> but this is unintelligible: <span class="auth">(TA:)</span> <span class="ar">بَنَائِقٌ</span> <a href="#baniyqapN">is pl. of <span class="ar">بَنِيقَةٌ</span></a>, <span class="auth">(JK, Ṣ, &amp;c.,)</span> and syn. with <span class="ar">دَخَارِيصٌ</span>. <span class="auth">(JK.)</span> AZ cites, from Mejnoon,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">كَمَا ضَمَّ أَزْرَارَ القَمِيصِ البَنَائِقٌ</span> *</div> 
					</blockquote>
					<p><span class="auth">(Ṣ, IB,)</span> which is an inverted phrase; the meaning being,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">كَمَا ضَمَّ أَزْرَارُ القَمِيصِ البَنَائِقَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Like as the buttons of the shirt draw together the gores:</em> if the last word mean <em>the gores</em>]</span>: or, if the <span class="ar">بنيقة</span> of the shirt be really its <span class="ar">جربّان</span>, the meaning is intelligible <span class="add">[without inversion]</span>; for its <span class="ar">جربّان</span> is the <em>part around the neck, upon which are sewed the buttons;</em> and when one desires to draw it together, he puts its buttons into the loops, and so draws together the bosom <span class="add">[of the shirt, with its buttons,]</span> to the uppermost part of the chest. <span class="auth">(IB, TA.)</span> Aboo-ʼAmr Esh-Sheybánee explains <span class="ar">البنائق</span>, here, as meaning the <em>loops into which the buttons are inserted;</em> and accord. to this explanation the meaning is plain, not requiring the supposition of inversion nor of deviation from the usual way: but the first explanation is that which is generally given. <span class="auth">(TA.)</span> In the saying,</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">قَدْ أَغْتَدِى وَالدَّهْرُ ذُو بَنِيقِ↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[in the last word of which, <span class="ar">ة</span> is elided; lit., <em>Sometimes I go forth early in the morning, when the time has a</em> <span class="ar">بَنِيقَة</span>;]</span> Lth says that the whiteness of the dawn is likened to the whiteness of the <span class="ar">بنيقة</span>; citing another verse, in which a shirt is described as having white <span class="ar">بنائق</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubnBaqapN">
				<h3 class="entry"><span class="ar">مُبنَّقَةٌ</span></h3>
				<div class="sense" id="mubnBaqapN_A1">
					<p><span class="ar long">جَعْبَةٌ مُبنَّقَةٌ</span> ‡ <em>A quiver that is widened:</em> <span class="auth">(Ibn-ʼAbbád, TA:)</span> or <em>in the upper part of which is added what resembles a</em> <span class="ar">بَنِيقَة</span>, <em>to enlarge it.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنق</span> - Entry: <span class="ar">مُبنَّقَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubnBaqapN_A2">
					<p><span class="ar long">طَرِيقٌ مُبَنَّقٌ</span> ‡ <em>A wide road.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabonuwqapN">
				<h3 class="entry"><span class="ar">مَبْنُوقَةٌ</span></h3>
				<div class="sense" id="mabonuwqapN_A1">
					<p><span class="ar long">أَرْضٌ مَبْنُوقَةٌ</span> † <em>Land joined</em> (<span class="ar">مَوْصُولَة</span>) <em>to other land, like as the</em> <span class="ar">بَنِيقَة</span> <em>of a shirt is joined.</em> <span class="auth">(ISd, TA.)</span> And <span class="ar long">مَفَازَةٌ مَبْنُوقَةٌ</span>, <span class="auth">(JK,)</span> or <span class="ar long">مَبْنُوقَةٌ بِأُخْرَى</span>, <span class="auth">(TA,)</span> ‡ <span class="add">[<em>A desert,</em> or <em>a desert in which is no water,</em>, &amp;c.,]</span> <em>joined to another.</em> <span class="auth">(JK, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0260.pdf" target="pdf">
							<span>Lanes Lexicon Page 260</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
