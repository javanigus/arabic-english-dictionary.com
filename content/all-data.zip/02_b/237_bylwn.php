<article class="root" id="Root_bylwn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/236_byE">بيع</a></span>
				<span class="ar">بيلون</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/238_byn">بين</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bayoluwnN">
				<h3 class="entry"><span class="ar">بَيْلُونٌ</span></h3>
				<div class="sense" id="bayoluwnN_A1">
					<p><span class="ar">بَيْلُونٌ</span> <span class="add">[<em>Fullers' earth, which is used for scouring cloths, and is sometimes used in the bath, instead of soap;</em>]</span> the <em>yellow</em> <span class="add">[or rather <em>yellowish,</em> or <em>yellowish gray,</em> and sometimes <em>white,</em> or <em>whitish,</em>]</span> <em>earth known by the name of</em> <span class="ar">طَفْل</span>. <span class="auth">(TA, from Esh-Shiháb El-'Ajamee.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0285.pdf" target="pdf">
							<span>Lanes Lexicon Page 285</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
