<article class="root" id="Root_brbT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/059_brbx">بربخ</a></span>
				<span class="ar">بربط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/061_brvn">برثن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="barobaTN">
				<h3 class="entry"><span class="ar">بَرْبَطٌ</span></h3>
				<div class="sense" id="barobaTN_A1">
					<p><span class="ar">بَرْبَطٌ</span> <span class="add">[The <em>Persian lute;</em>]</span> <em>a certain musical instrument</em> <span class="auth">(Lth, Mṣb)</span> <em>of the</em> <span class="ar">عَجَمَ</span> <span class="add">[or <em>Persians</em>]</span>; <span class="auth">(Mṣb;)</span> <em>i. q.</em> <span class="ar">عُوِدٌ</span>: <span class="auth">(Lth, Ḳ:)</span> an arabicized word, <span class="auth">(Ḳ,)</span> from <span class="ar">بَرِبَتْ</span>, <span class="auth">(IAth,)</span> or <span class="ar">بَرِبَطْ</span>; meaning “the breast of the duck, or goose;” because of its resemblance thereto; <span class="auth">(Ḳ;)</span> <span class="pb" id="Page_0180"></span>for <span class="ar">بَرْ</span> in Persian, signifies the “breast;” <span class="auth">(TA;)</span> <span class="add">[and <span class="ar">بَتْ</span> and <span class="ar">بَطْ</span> or <span class="ar">بَطّْ</span>, like the Arabic <span class="ar">بَطٌّ</span>, “a duck,” or “goose;”]</span> or because the player upon it places it against his breast: <span class="auth">(IAth:)</span> or it is said to be arabicized because it is the name of a musical instrument of the <span class="ar">عجم</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0179.pdf" target="pdf">
							<span>Lanes Lexicon Page 179</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0180.pdf" target="pdf">
							<span>Lanes Lexicon Page 180</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
