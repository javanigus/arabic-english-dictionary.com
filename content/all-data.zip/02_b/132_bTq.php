<article class="root" id="Root_bTq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/131_bTX">بطش</a></span>
				<span class="ar">بطق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/133_bTl">بطل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="biTaAqapN">
				<h3 class="entry"><span class="ar">بِطَاقَةٌ</span></h3>
				<div class="sense" id="biTaAqapN_A1">
					<p><span class="ar">بِطَاقَةٌ</span> <em>A piece of paper:</em> <span class="auth">(IAạr, M, Ṣgh, TA:)</span> in the Ḳ, <span class="ar">الحَدَقَةُ</span> is erroneously put for <span class="ar">الوَرَقَةُ</span>: <span class="auth">(TA:)</span> <em>a ticket that is attached to a garment,</em> or <em>piece of cloth,</em> <span class="auth">(T, Ṣ, M, L, Ḳ,)</span> <em>bearing the mark,</em> or <em>inscription, of its price;</em> <span class="auth">(T, Ṣ, L, Ḳ;)</span> or <em>a ticket marked,</em> or <em>inscribed, with the weight,</em> and <em>the number, of a thing:</em> <span class="auth">(TA:)</span> of the dial. of Egypt <span class="auth">(T, Ṣ, L)</span> and the neighbouring parts: <span class="auth">(T, L:)</span> so called, <span class="auth">(Ḳ,)</span> or said <span class="auth">(by Sh, TA)</span> to be so called, <span class="auth">(Ṣ,)</span> because it is tied by a twist, or thread, (<span class="ar">بِطَاقَةً</span>,) of the unwoven end of the cloth: <span class="auth">(Ṣ, Ḳ:)</span> but this is a mistake: <span class="auth">(ISd, TA:)</span> <span class="add">[in Greek, <span class="gr">πιττάκιον</span>, as observed by Freytag; and hence probably derived:]</span> accord. to some, it is <span class="add">[<span class="ar">نِطَاقَةً</span>,]</span> with <span class="ar">ن</span>, because it tells (<span class="ar">تَنْطِقُ</span>) what is marked, or inscribed, thereon; but this is strange. <span class="auth">(TA.)</span> It is said in a trad., that a man will be brought on the day of resurrection, and ninety-nine scrolls, or records, inscribed with his sins will be produced; and there will be produced for him a <span class="ar">بطاقة</span> bearing the testimony that there is no deity but God, and it will outweigh the others. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0218.pdf" target="pdf">
							<span>Lanes Lexicon Page 218</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
