<article class="root" id="Root_bnSr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/192_bndq">بندق</a></span>
				<span class="ar">بنصر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/194_bnfsj">بنفسج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="binoSirN.1">
				<h3 class="entry"><span class="ar">بِنْصِرٌ</span></h3>
				<div class="sense" id="binoSirN.1_A1">
					<p><span class="ar">بِنْصِرٌ</span> The <em>finger that is next to the little finger;</em> <span class="auth">(Ṣ in art. <span class="ar">بصر</span>;)</span> <span class="add">[<em>the third finger;</em>]</span> <em>that which is between the little and middle fingers:</em> <span class="auth">(Mṣb in art. <span class="ar">بصر</span>, and Ḳ:)</span> of the fem. gender: <span class="auth">(Ḳ:)</span> pl. <span class="ar">بَنَاصِرُ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَنَاصِرَةٌ</span>. <span class="auth">(Mṣb.)</span> Accord. to the author of the Ḳ, the <span class="ar">ن</span> is a radical letter, and therefore the mention of this word in art. <span class="ar">بصر</span> is wrong. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
