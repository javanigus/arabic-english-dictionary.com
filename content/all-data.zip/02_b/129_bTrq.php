<article class="root" id="Root_bTrq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/128_bTr">بطر</a></span>
				<span class="ar">بطرق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/130_bTrk">بطرك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="biToriyqN">
				<h3 class="entry"><span class="ar">بِطْرِيقٌ</span></h3>
				<div class="sense" id="biToriyqN_A1">
					<p><span class="ar">بِطْرِيقٌ</span> <em>A</em> <span class="ar">قَائِد</span> <span class="add">[or <em>leader of an army</em>]</span>, in the language of the <span class="ar">رُوم</span> <span class="add">[or Greeks of the Lower Empire]</span>; <span class="auth">(JK;)</span> <em>one who is to the</em> <span class="ar">روم</span> <em>like the</em> <span class="ar">قائد</span> <em>to the Arabs;</em> <span class="auth">(Mgh, Mṣb;)</span> <span class="add">[i. e.]</span> <em>a leader of an army</em> (<span class="ar">قائد</span>) <em>of the</em> <span class="ar">روم</span>; <span class="auth">(Ṣ, Ḳ;)</span> accord. to Kudámeh, <span class="auth">(Mgh,)</span> <em>one who is over ten thousand men:</em> <span class="auth">(Mgh, Ḳ:)</span> next to him is the <span class="ar">طَرْخَان</span> <span class="add">[in the CK <span class="ar">تَرْخان</span>]</span>, over five thousand: then, the <span class="ar">قَوْمَس</span>, over two hundred: <span class="auth">(Ḳ:)</span> but in art. <span class="ar">طرخ</span> in the Ḳ, it is said that <span class="ar">طرخان</span> signifies “a headman, or chief, of high, or noble, rank,” in the language of Khurásán; and in art. <span class="ar">قمس</span>, that <span class="ar">قومس</span> signifies “a commander,” or the like, syn. <span class="ar">أَمِيرٌ</span>; and. <span class="ar">قَمَامِسَةٌ</span>, i. q. <span class="ar">بَطَارِقَةٌ</span>, <span class="auth">(TA,)</span> which <a href="#bTryq">is pl. of <span class="ar">بطريق</span></a>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> as also <span class="ar">بَطَارِيقُ</span>, for which <span class="ar">بَطَارِقُ</span> is used in a verse of Aboo-Dhu-eyb: <span class="auth">(TA:)</span> it is an arabicized word; <span class="auth">(Ṣ, TA;)</span> <span class="add">[app. from the Latin “patricius;”]</span> or, as some say, of the language of the <span class="ar">روم</span> and of Syria: or Arabic, agreeing with the foreign word, and of the dial. of the people of El-Ḥijáz: accord. to El-Jawáleeḳee and others, in the language of the <span class="ar">روم</span> it is <span class="ar">بترك</span>: some say that it signifies <em>skilled in war and its affairs,</em> in the language of the <span class="ar">روم</span>; and he who is so has rank, or office, and is sometimes made foremost, among them: <span class="auth">(TA:)</span> <span class="pb" id="Page_0218"></span>and <span class="auth">(some say, TA)</span> a <em>proud and self-conceited</em> man; <span class="auth">(JK, Ḳ;)</span> so says Ibn-ʼAbbád: <span class="auth">(TA:)</span> and <em>fat;</em> applied to a bird <span class="auth">(JK, Ḳ)</span>, &amp;c.: <span class="auth">(JK:)</span> pl. <span class="ar">بَطَارِقَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بطرق</span> - Entry: <span class="ar">بِطْرِيقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="biToriyqN_A2">
					<p><span class="add">[<a href="#baTorakN">See also <span class="ar">بَطْرَكٌ</span></a>, <a href="#jaAvaliyqN">and <span class="ar">جَاثَلِيقٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0217.pdf" target="pdf">
							<span>Lanes Lexicon Page 217</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0218.pdf" target="pdf">
							<span>Lanes Lexicon Page 218</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
