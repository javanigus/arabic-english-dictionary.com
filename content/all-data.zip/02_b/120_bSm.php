<article class="root" id="Root_bSm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/119_bSl">بصل</a></span>
				<span class="ar">بصم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/121_bSn">بصن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="buSomN">
				<h3 class="entry"><span class="ar">بُصْمٌ</span></h3>
				<div class="sense" id="buSomN_A1">
					<p><span class="ar">بُصْمٌ</span> The <em>space that is between the extremity of the little finger and that of the third finger</em> <span class="add">[<em>when they are extended apart</em>]</span>: <span class="auth">(Ṣ, M,* Ḳ:)</span> mentioned on the authority of AO, <span class="auth">(Ṣ,)</span> or on that of Aboo-Málik alone. <span class="auth">(M.)</span> The <span class="ar">عَتَب</span> is the space between the third finger and the middle finger; the <span class="ar">رَتَب</span>, that between the middle finger and the first finger; <span class="add">[but see these two words;]</span> the <span class="ar">فِتْر</span>, that between the first finger and the thumb; the <span class="ar">شِبْر</span>, that between the thumb and the little finger; and the <span class="ar">فَوْت</span>, that between every two fingers, in length. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بصم</span> - Entry: <span class="ar">بُصْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buSomN_A2">
					<p><span class="ar long">ذُو بُصْمٍ</span> <em>Thick,</em> or <em>coarse;</em> applied to a man, <span class="auth">(M, Ḳ,)</span> or a garment, or piece of cloth: <span class="auth">(Ḳ:)</span> or you say <span class="ar long">ثَوْبٌ لَهُ بُصْمٌ</span>, meaning <em>a garment,</em> or <em>piece of cloth, that is dense,</em> or <em>compact; close in texture.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0213.pdf" target="pdf">
							<span>Lanes Lexicon Page 213</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
