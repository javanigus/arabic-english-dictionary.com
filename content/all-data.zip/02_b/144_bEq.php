<article class="root" id="Root_bEq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/143_bED">بعض</a></span>
				<span class="ar">بعق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/145_bEl">بعل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEq_1">
				<span class="pb" id="Page_0228"></span>
				<h3 class="entry">1. ⇒ <span class="ar">بعق</span></h3>
				<div class="sense" id="bEq_1_A1">
					<p><span class="ar">بَعَقَ</span>, <span class="auth">(TA,)</span> <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَقُ</span>}</span></add>,]</span> inf. n. <span class="ar">بُعَاقٌ</span>, <span class="auth">(Lth, Ḳ, TA,)</span> said of a man, and a camel, &amp;c., <span class="auth">(TA,)</span> <em>He uttered a vehement sound,</em> or <em>cry.</em> <span class="auth">(Lth,* Ḳ,* TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEq_1_B1">
					<p>Also, inf. n. as above, said of a vehement rain, descending in large drops, <em>It clave,</em> or <em>furrowed,</em> the ground, <em>and made it to flow.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bEq_1_B2">
					<p>And, inf. n. <span class="ar">بَعْقٌ</span>, <em>He stabbed,</em> or <em>stuck,</em> a camel <em>in the</em> <span class="ar">نَحْر</span>, or <em>throat,</em> or <em>uppermost part of the breast,</em> <span class="auth">(Ḳ, TA,)</span> <em>making the blood to flow;</em> <span class="auth">(TA;)</span> and <span class="auth">(TA)</span> so <span class="arrow"><span class="ar">بعّق↓</span></span>. <span class="auth">(AʼObeyd, Ṣ, L, TA, all of which, except the last, mention only the latter verb in this sense.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bEq_1_B3">
					<p>Also, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَعْقٌ</span>, <span class="auth">(TA,)</span> <em>He dug</em> a well. <span class="auth">(Z, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bEq_1_B4">
					<p><span class="ar">بَعْقٌ</span> also signifies The act of <em>slitting, ripping,</em> or <em>rending;</em> like <span class="ar">بَعْجٌ</span>: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">تَبْعِيقٌ↓</span></span> the same; <span class="auth">(Ṣ;)</span> or the <em>doing so much.</em> <span class="auth">(Ḳ.)</span> You say,<span class="arrow"><span class="ar long">بَعَّقْتُ↓ زِقَّ الخَمْرِ</span></span>, inf. n. <span class="ar">تَبْعِيقٌ</span>, <em>I slit,</em> or <em>ripped,</em> or <em>rent, the wine-skin.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="bEq_1_B5">
					<p><span class="ar long">بَعَقَةُ عَنْ كَذَا</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَعْقٌ</span>, <span class="auth">(TA,)</span> <em>He removed it, took it off,</em> or <em>stripped it off, from over,</em> or <em>before, such a thing, which it covered,</em> or <em>concealed.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEq_2">
				<h3 class="entry">2. ⇒ <span class="ar">بعّق</span></h3>
				<div class="sense" id="bEq_2_A1">
					<p><a href="#bEq_1">see 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبعّق</span></h3>
				<div class="sense" id="bEq_5_A1">
					<p><a href="#bEq_7">see 7</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEq_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبعق</span></h3>
				<div class="sense" id="bEq_7_A1">
					<p><span class="ar">انبعق</span> <em>It came upon one suddenly, unexpectedly, without his knowledge.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEq_7_A2">
					<p><span class="ar long">انبعق المُزْنُ</span> ‡ <span class="add">[<em>The clouds,</em> or <em>white clouds,</em> or <em>clouds containing water,</em>]</span> <em>clave asunder, with,</em> or <em>by reason of, rain,</em> or <em>violent rain;</em> syn. <span class="ar long">اِنْبَعَجَ بِالمَطَرِ</span>; <span class="auth">(Ṣ, Ḳ, TA;)</span> or <em>opened vehemently with rain;</em> <span class="auth">(Z, TA;)</span> and<span class="arrow"><span class="ar">تبعّق↓</span></span> signifies the same. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEq_7_A3">
					<p><span class="ar long">انبعق فُلَانٌ بِالجُودِ وَالكَرَمِ</span> ‡ <span class="add">[<em>Such a one was profuse in bounty and generosity</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bEq_7_A4">
					<p><span class="ar long">انبعق فِى الكَلَامِ</span> <span class="auth">(Ṣ, Ḳ)</span> † <em>He was profuse in speech;</em> <span class="auth">(Ḳ,* TA;)</span> as also<span class="arrow"><span class="ar">تبعّق↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">ابتعق↓</span></span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEq_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتعق</span></h3>
				<div class="sense" id="bEq_8_A1">
					<p><a href="#bEq_7">see 7</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baEaAqN">
				<h3 class="entry"><span class="ar">بَعَاقٌ</span></h3>
				<div class="sense" id="baEaAqN_A1">
					<p><span class="ar">بَعَاقٌ</span>: <a href="#buEaAqN">see what next follows</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buEaAqN">
				<h3 class="entry"><span class="ar">بُعَاقٌ</span></h3>
				<div class="sense" id="buEaAqN_A1">
					<p><span class="ar">بُعَاقٌ</span> † Clouds (<span class="ar">سَحَابٌ</span>) <em>pouring forth</em> <span class="add">[<em>rain</em>]</span> <em>with vehemence.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: <span class="ar">بُعَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buEaAqN_A2">
					<p>Also, and<span class="arrow"><span class="ar">بَعَاقٌ↓</span></span> and<span class="arrow"><span class="ar">بِعَاقٌ↓</span></span> and<span class="arrow"><span class="ar">بَاعِقٌ↓</span></span>, ‡ Rain <em>coming suddenly,</em> or <em>unexpectedly, with vehemence, in large drops.</em> <span class="auth">(Ḳ, TA.)</span> <span class="ar long">جَمُّ البُعَاقِ</span>, in a trad. respecting prayer for rain, means † <em>Copious, abundant, extensive rain.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعق</span> - Entry: <span class="ar">بُعَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buEaAqN_A3">
					<p>And<span class="arrow">↓</span> all these four words, † A torrent <em>vehemently driving;</em> <span class="auth">(Ḳ, TA;)</span> <em>that carries away everything.</em> <span class="auth">(AḤn, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biEaAqN">
				<h3 class="entry"><span class="ar">بِعَاقٌ</span></h3>
				<div class="sense" id="biEaAqN_A1">
					<p><span class="ar">بِعَاقٌ</span>: <a href="#buEaAqN">see <span class="ar">بُعَاقٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAEiqN">
				<h3 class="entry"><span class="ar">بَاعِقٌ</span></h3>
				<div class="sense" id="baAEiqN_A1">
					<p><span class="ar">بَاعِقٌ</span>: <a href="#buEaAqN">see <span class="ar">بُعَاقٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboEuwqapN">
				<h3 class="entry"><span class="ar">مَبْعُوقَةٌ</span></h3>
				<div class="sense" id="maboEuwqapN_A1">
					<p><span class="ar long">أَرْضٌ مَبْعُوقَةٌ</span> <em>Land upon which what is termed</em> <span class="ar">بُعَاق</span> <span class="add">[i. e. either the rain or torrent so termed]</span> <em>has fallen,</em> or <em>descended.</em> <span class="auth">(Nawádir el-Aaráb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0228.pdf" target="pdf">
							<span>Lanes Lexicon Page 228</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
