<article class="root" id="Root_blEm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/176_blE">بلع</a></span>
				<span class="ar">بلعم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/178_blg">بلغ</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="baloEama">
				<h3 class="entry"><span class="ar">بَلْعَمَ</span></h3>
				<div class="sense" id="baloEama_A1">
					<p><span class="ar">بَلْعَمَ</span>: <a href="#blE">see <span class="ar">بلع</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balEEamN">
				<h3 class="entry"><span class="ar">بَلععَمٌ</span></h3>
				<div class="sense" id="balEEamN_A1">
					<p><span class="ar">بَلععَمٌ</span>: <a href="#blE">see <span class="ar">بلع</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buloEumN.1">
				<h3 class="entry"><span class="ar">بُلْعُمٌ</span></h3>
				<div class="sense" id="buloEumN.1_A1">
					<p><span class="ar">بُلْعُمٌ</span>: <a href="#blE">see <span class="ar">بلع</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buloEuwmN.1">
				<h3 class="entry"><span class="ar">بُلْعُومٌ</span></h3>
				<div class="sense" id="buloEuwmN.1_A1">
					<p><span class="ar">بُلْعُومٌ</span>: <a href="#blE">see <span class="ar">بلع</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0250.pdf" target="pdf">
							<span>Lanes Lexicon Page 250</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
