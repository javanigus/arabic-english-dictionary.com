<article class="root" id="Root_bsm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/104_bsl">بسل</a></span>
				<span class="ar">بسم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/106_bsml">بسمل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bsm_1">
				<h3 class="entry">1. ⇒ <span class="ar">بسم</span></h3>
				<div class="sense" id="bsm_1_A1">
					<p><span class="ar">بَسَمَ</span>: <a href="#bsm_5">see 5</a>, with which it is syn.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsm_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">مَا بَسَمْتُ فِى الشَّىْءِ</span> ‡ <em>I did not taste the thing.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bsm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبسّم</span></h3>
				<div class="sense" id="bsm_5_A1">
					<p><span class="ar">تبسّم</span>; and<span class="arrow"><span class="ar">ابتسم↓</span></span>; and<span class="arrow"><span class="ar">بَسَمَ↓</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْسِمُ</span>}</span></add>, inf. n. <span class="ar">بَسْمٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">مَبْسَمٌ</span>; <span class="auth">(Ḳ,* TA;)</span> <span class="add">[<em>He smiled;</em>]</span> these verbs signify less than <span class="ar">ضَحِكَ</span> <span class="add">[so that they are properly explained by the Latin <em>subrisit</em>]</span>: <span class="auth">(Ṣ, Mṣb:)</span> or <em>he opened his lips like him who displays to another his teeth:</em> <span class="auth">(Lth, TA:)</span> or <em>he laughed in the least degree and in the most beautiful manner:</em> <span class="auth">(M, Ḳ:)</span> or <em>he laughed a little without any sound:</em> <span class="auth">(Mṣb:)</span> or <span class="ar">تَبَسُّمٌ</span> is the <em>beginning of</em> <span class="ar">ضَحِكٌ</span> <span class="add">[or <em>laughter</em>]</span>: <span class="auth">(Towsheeh, and Neseem er-Riyád, in TA art. <span class="ar">ضحك</span>, q. v.:)</span> accord. to Zj, it is the utmost degree of laughing of the prophets. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسم</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bsm_5_A2">
					<p><span class="add">[Hence,]</span><span class="arrow"><span class="ar long">ابتسم↓ السَّحَابُ عَنِ البَرْقِ</span></span> <span class="auth">(M,)</span> or <span class="ar long">تبسّم عَنْهُ</span> <span class="auth">(TA,)</span> <em>i. q.</em> <span class="ar long">اِنْكَلَّ عنه</span> <span class="add">[i. e. ‡ <em>The clouds displayed a faint flashing of lightning</em>]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بسم</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bsm_5_A3">
					<p>And <span class="ar long">تبسّم الطَّلْعُ</span> ‡ <em>The extremities of the</em> <span class="ar">طلع</span> <span class="add">[i. e. the <em>spadix,</em> or the <em>spathe, of the palm-tree,</em>]</span> <em>burst asunder.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bsm_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتسم</span></h3>
				<div class="sense" id="bsm_8_A1">
					<p><a href="#bsm_5">see 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="basBaAmN">
				<h3 class="entry"><span class="ar">بَسَّامٌ</span></h3>
				<div class="sense" id="basBaAmN_A1">
					<p><span class="ar">بَسَّامٌ</span> <span class="auth">(Ṣ M, Ḳ)</span> and<span class="arrow"><span class="ar">مِبْسَامٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> epithets from <span class="ar">بَسَمَ</span>, <span class="auth">(M, Ḳ,)</span> applied to a man, <span class="auth">(Ṣ, M,)</span> meaning <span class="ar long">كَثِيرُ التَّبَسُّمِ</span> <span class="add">[<em>That smiles much</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAsimN">
				<h3 class="entry"><span class="ar">بَاسِمٌ</span></h3>
				<div class="sense" id="baAsimN_A1">
					<p><span class="ar">بَاسِمٌ</span> part. n. of <span class="ar">بَسَمَ</span> <span class="add">[meaning <em>Smiling</em>]</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabosimN">
				<h3 class="entry"><span class="ar">مَبْسِمٌ</span></h3>
				<div class="sense" id="mabosimN_A1">
					<p><em>i. q.</em> <span class="ar">ثَغْرٌ</span> <span class="auth">(Ṣ, Ḳ,)</span> meaning The <em>front teeth:</em> <span class="auth">(TḲ:)</span> <span class="add">[and sometimes, perhaps, the <em>mouth:</em>]</span> so called as being the place of <span class="ar">التَّبَسُّم</span> <span class="add">[or smiling: pl. <span class="ar">مَبَاسِمُ</span>]</span>. <span class="auth">(TA.)</span> One says, <span class="add">[of women or girls,]</span> <span class="ar long">هُنَّ غُرُّ المَبَاسِمِ</span> <span class="add">[<em>They are white in the front teeth</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibosaAmN">
				<h3 class="entry"><span class="ar">مِبْسَامٌ</span></h3>
				<div class="sense" id="mibosaAmN_A1">
					<p><span class="ar">مِبْسَامٌ</span>: <a href="#basBaAmN">see <span class="ar">بَسَّامٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0206.pdf" target="pdf">
							<span>Lanes Lexicon Page 206</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
