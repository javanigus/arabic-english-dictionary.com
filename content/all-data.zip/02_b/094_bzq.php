<article class="root" id="Root_bzq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/093_bzg">بزغ</a></span>
				<span class="ar">بزق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/095_bzl">بزل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bzq_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزق</span></h3>
				<div class="sense" id="bzq_1_A1">
					<p><span class="ar">بَزَقَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُقُ</span>}</span></add>, <span class="auth">(Mṣb, TA,)</span> inf. n. <span class="ar">بَزْقٌ</span>, <span class="auth">(Ṣ, TA,)</span> or <span class="ar">بُزَاقٌ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[but see the latter below,]</span> <em>i. q.</em> <span class="ar">بَصَقَ</span> <span class="auth">(Ṣ,* Mṣb)</span> or <span class="ar">بَسَقَ</span> <span class="auth">(Ḳ)</span> <span class="add">[<em>He spat:</em> <a href="#bzq_5">see also 5</a>]</span>: but it is of weak authority, or rare; the most chaste being <span class="ar">بصق</span>. <span class="auth">(TA in art. <span class="ar">بسق</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzq_1_B1">
					<p><span class="ar long">بَزَقَ الأَرْضَ</span> <em>He sowed the land:</em> <span class="auth">(Az, Ḳ:)</span> of the dial. of El-Yemen. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bzq_1_C1">
					<p><span class="ar long">بَزَقَتِ الشَّمْسُ</span> <em>i. q.</em> <span class="ar">بَزَغَت</span>; <span class="auth">(Az, Ḳ;)</span> so in a trad., meaning <em>The sun rose:</em> the latter is that which is <span class="add">[commonly]</span> known; but the former may be a dial. var.; though the right reading seems to be <span class="ar">بَزَقَت</span>. <span class="auth">(Az, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzq_4">
				<span class="pb" id="Page_0200"></span>
				<h3 class="entry">4. ⇒ <span class="ar">ابزق</span></h3>
				<div class="sense" id="bzq_4_A1">
					<p><span class="ar">ابزقت</span> <em>She</em> <span class="auth">(namely, a ewe, JK, or a camel, Ḳ)</span> <em>excerned the milk</em> <span class="add">[or <em>biestings into her udder before bringing forth</em>]</span>; <span class="auth">(Yz, JK, Ḳ, TA;)</span> <em>i. q.</em> <span class="ar">ابسقت</span> <span class="add">[q. v.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبزّق</span></h3>
				<div class="sense" id="bzq_5_A1">
					<p><span class="ar">تبزّق</span> <em>He ejected his spittle,</em> as the faster is commanded to do. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buzaAqN">
				<h3 class="entry"><span class="ar">بُزَاقٌ</span></h3>
				<div class="sense" id="buzaAqN_A1">
					<p><span class="ar">بُزَاقٌ</span> is well known; <span class="auth">(Ḳ;)</span> <em>i. q.</em> <span class="ar">بُصَاقٌ</span> <span class="add">[<em>Spittle,</em> or <em>saliva, when it has gone forth from the mouth</em>]</span>: <span class="auth">(Ṣ:)</span> or <em>saliva that flows.</em> <span class="auth">(TA in art. <span class="ar">رضب</span>.)</span> <span class="add">[<a href="#bzq_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibozaqapN">
				<h3 class="entry"><span class="ar">مِبْزَقَةٌ</span></h3>
				<div class="sense" id="mibozaqapN_A1">
					<p><span class="ar">مِبْزَقَةٌ</span> <em>A spittoon,</em> or <em>vessel in which to spit;</em> syn. <span class="ar">مِتْفَلَةٌ</span>. <span class="auth">(TA in art. <span class="ar">تفل</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0199.pdf" target="pdf">
							<span>Lanes Lexicon Page 199</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0200.pdf" target="pdf">
							<span>Lanes Lexicon Page 200</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
