<article class="root" id="Root_bqw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/160_bqm">بقم</a></span>
				<span class="ar">بقو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/162_bqe">بقى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bqw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بقو</span> ⇒ <span class="ar">بقى</span></h3>
				<div class="sense" id="bqw_1_A1">
					<p><span class="ar long">بَقَاهُ بِعَيْنِهِ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْقُوُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَقَاوَةٌ</span> <span class="add">[and <span class="ar">بَقْوَةٌ</span>, as will be seen from what follows, like <span class="ar">رَحْمَةٌ</span>]</span>, <em>He looked,</em> <span class="auth">(Lḥ, JK, ISd, Ḳ,)</span> or <em>looked long,</em> or <em>glanced lightly,</em> <span class="auth">(JK,)</span> <em>at him,</em> or <em>it;</em> <span class="auth">(Lḥ, JK, ISd, Ḳ;)</span> and so with <span class="ar">ى</span> for the last radical: <span class="auth">(JK:)</span> and <span class="ar">بَقَاهُ</span> <span class="add">[alone]</span>, with <span class="ar">و</span> and with <span class="ar">ى</span> for the last radical, <span class="auth">(Ḳ in art. <span class="ar">بقى</span>,)</span> first pers. <span class="ar">بَقَوْتُهُ</span> and <span class="ar">بَقَيْتُهُ</span>, <span class="auth">(Lḥ, TA,)</span> <em>he looked at him,</em> or <em>it:</em> <span class="auth">(Lḥ, Ḳ:)</span> or <em>he watched,</em> or <em>observed, him,</em> or <em>it:</em> <span class="auth">(Ḳ in art. <span class="ar">بقى</span>:)</span> and <span class="ar">بقوته</span> <em>I looked, watched,</em> or <em>waited, for him,</em> or <em>it:</em> <span class="auth">(Ḳ:)</span> <a href="#bqe_1_B1">a dial. var. of <span class="ar">بَقَيْتُهُ</span></a>, which is the more approved. <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">اُبْقُهُ بَقْوَتَكَ مَالَكَ</span> and <span class="ar long">بَقَاوَتَكَ مَالَكَ</span> <em>Guard thou,</em> or <em>preserve thou, him,</em> or <em>it, as thou guardest,</em> or <em>preservest, thy property.</em> <span class="auth">(M, Tekmileh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baqowae">
				<h3 class="entry"><span class="ar">بَقْوَى</span> / <span class="ar">بُقْوَى</span></h3>
				<div class="sense" id="baqowae_A1">
					<p><span class="ar">بَقْوَى</span> and <span class="ar">بُقْوَى</span>: <a href="index.php?data=02_b/162_bqe">see art. <span class="ar">بقى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0237.pdf" target="pdf">
							<span>Lanes Lexicon Page 237</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
