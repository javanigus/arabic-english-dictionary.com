<article class="root" id="Root_bwA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/210_bw">بو</a></span>
				<span class="ar">بوا</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/212_bwO">بوأ</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="bawBaA">
				<h3 class="entry"><span class="ar">بَوَّا</span> / 
							<span class="ar">بَوَّى</span>
							<span class="ar">بَوَّآءُ</span></h3>
				<div class="sense" id="bawBaA_A1">
					<p><span class="ar long">جُوْزُ بَوَّا</span>, also written <span class="ar long">جَوْزُ بَوَّى</span>: <a href="index.php?data=05_j/180_jwz">see art. <span class="ar">جوز</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوا</span> - Entry: <span class="ar">بَوَّا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bawBaA_B1">
					<p><span class="ar long">خَيْرُ بَوَّآءُ</span>: <a href="index.php?data=07_x/181_xyr">see art. <span class="ar">خير</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0270.pdf" target="pdf">
							<span>Lanes Lexicon Page 270</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
