<article class="root" id="Root_brbx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/058_brO">برأ</a></span>
				<span class="ar">بربخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/060_brbT">بربط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="barobaxN">
				<h3 class="entry"><span class="ar">بَرْبَخٌ</span></h3>
				<div class="sense" id="barobaxN_A1">
					<p><span class="ar">بَرْبَخٌ</span> The <em>passage,</em> or <em>conduit, of water, called</em> <span class="ar">إِرْدَبَّة</span> <em>and</em> <span class="ar">بَالُوعَة</span> <span class="add">[q. v.]</span>, <em>made of baked clay:</em> <span class="auth">(Ḳ:)</span> or <span class="ar">بَرَابِخُ</span> <span class="add">[the pl.]</span> signifies the <em>baked-clay conduits of privies, which convey</em> <span class="add">[<em>the water</em>, &amp;c.]</span> <em>from the house-top to the ground.</em> <span class="auth">(Ṣ, but omitted in some copies.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بربخ</span> - Entry: <span class="ar">بَرْبَخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barobaxN_A2">
					<p><span class="ar long">برْبَخُ البَوْلِ</span> <em>The canal of the urine</em> <span class="add">[<em>from the kidney to the bladder;</em> i. e. <em>the ureter</em>]</span>: <span class="auth">(L, KL, TA:)</span> of the dial. of Egypt. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0179.pdf" target="pdf">
							<span>Lanes Lexicon Page 179</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
