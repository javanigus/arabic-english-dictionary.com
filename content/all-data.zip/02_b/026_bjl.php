<article class="root" id="Root_bjl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/025_bjs">بجس</a></span>
				<span class="ar">بجل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/027_bH">بح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bjl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بجل</span></h3>
				<div class="sense" id="bjl_1_A1">
					<p><span class="ar">بَجُلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْجُلُ</span>}</span></add>, inf. n. <span class="ar">بَجَالَةٌ</span> and <span class="ar">بُجُولٌ</span>, <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, such as is termed</em> <span class="ar">بَجَال</span> <em>and</em> <span class="ar">بَجِيل</span> <span class="add">[i. e. <em>magnified, honoured,</em>, &amp;c.]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0154"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bjl_1_B1">
					<p><span class="ar">بَجَلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْجَلُ</span>}</span></add>; and <span class="ar">بَجَلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْجُلُ</span>}</span></add>, inf. n. <span class="ar">بَجْلٌ</span> and <span class="ar">بُجُولٌ</span>; <em>He was,</em> or <em>became, in a good state</em> or <em>condition; having abundance of herbage,</em> or <em>of the goods</em> or <em>conveniences</em> or <em>comforts of life.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bjl_1_B2">
					<p>And <em>He was,</em> or <em>became, joyful, glad,</em> or <em>happy.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bjl_1_C1">
					<p><span class="add">[<span class="ar">بَجَلَهُ</span> <em>He bled him</em> <span class="auth">(namely, a horse, or a camel,)</span> <em>by opening the vein called</em> <span class="ar">الأَبْجَل</span>: so accord. to analogy; like <span class="ar">وَدَجَهُ</span>, meaning “he bled him by opening the vein called <span class="ar">الوَدَج</span>,”, &amp;c.]</span> <span class="ar long">لَمْ يُبْجَلْ</span> means <em>He had not been bled in the</em> <span class="ar">أَبْجَل</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bjl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بجّل</span></h3>
				<div class="sense" id="bjl_2_A1">
					<p><span class="ar">بجّلهُ</span>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَبْجِيلٌ</span>, <em>He magnified, honoured, revered, venerated,</em> or <em>respected, him:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or <em>he said to him</em> <span class="ar">بَجَلٌ</span>, meaning <em>Sufficient for thee</em> (<span class="ar">جَسْبُكَ</span>) <em>is the place</em> <span class="add">[or <em>condition</em> or <em>rank</em>]</span> <em>which thou hast attained.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bjl_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابجل</span></h3>
				<div class="sense" id="bjl_4_A1">
					<p><span class="ar">ابجلهُ</span> <em>It sufficed,</em> or <em>contented, him.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bjl_4_A2">
					<p><em>It rejoiced him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bujolN">
				<h3 class="entry"><span class="ar">بُجْلٌ</span></h3>
				<div class="sense" id="bujolN_A1">
					<p><span class="ar">بُجْلٌ</span>: <a href="#bajalN">see <span class="ar">بَجَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajalo">
				<h3 class="entry"><span class="ar">بَجَلْ</span></h3>
				<div class="sense" id="bajalo_A1">
					<p><span class="ar">بَجَلْ</span> is a noun <span class="auth">(Mughnee)</span> <em>syn. with</em> <span class="ar">حَسْبُ</span>: <span class="auth">(Ṣ, Mughnee, Ḳ:*)</span> and is also a verbal noun <em>syn. with</em> <span class="ar">يَكْفِى</span>. <span class="auth">(Mughnee, Ḳ.*)</span> You say <span class="ar">بَجَلِى</span> <span class="auth">(Ṣ, Mughnee, Ḳ)</span> and <span class="ar">بَجْلِى</span>, <span class="auth">(Ṣ, Ḳ,)</span> meaning <span class="ar">حَسْبِى</span> <span class="add">[<em>My sufficiency,</em> or <em>a thing sufficing me,</em> i. e. <em>sufficient for me,</em> is such a thing]</span>: <span class="auth">(Ṣ, Mughnee, Ḳ:)</span> <span class="add">[it is said in the Ḥam, p. 145, as on the authority of Akh, that they do not say <span class="ar">بَجْلى</span>; but this is a mistranscription for <span class="ar">بَجَلْنِى</span>, as will be seen from what follows:]</span> and, using it as a verbal noun, <span class="auth">(Mughnee, Ḳ,)</span> but this is rare, <span class="auth">(Mughnee,)</span> you say <span class="ar">بَجَلْنِى</span>, meaning <span class="ar">يَكْفِينِى</span> <span class="add">[<em>It suffices me,</em> or <em>will suffice me</em>]</span>; <span class="auth">(Mughnee, Ḳ;)</span> and <span class="ar">بَجَلْكَ</span>, meaning <span class="ar">يَكْفِيكَ</span> <span class="add">[<em>It suffices thee,</em> or <em>will suffice thee</em>]</span>: <span class="auth">(Ḳ:)</span> or, accord. to Akh, they say <span class="ar">بَجَلْكَ</span>, like as they say, <span class="ar">قَطْكَ</span>; but not <span class="ar">بَجَلْنِى</span>, like <span class="ar">قَطْنِى</span>: <span class="auth">(Ṣ:)</span> or the <span class="ar">ن</span> in <span class="ar">بَجَلْنِى</span> is absolutely necessary accord. to him who says that <span class="ar">بَجَلٌ</span> is a verbal noun; and accord. to him who says that this word is syn. with <span class="ar">حَسْبُ</span>, the <span class="ar">ن</span> is allowable. <span class="auth">(MF.)</span> <span class="add">[See, under the words <span class="ar">قَدْ</span> and <span class="ar">قَطْ</span>, what is said respecting <span class="ar">قَدْنِى</span> and <span class="ar">قَطْنِى</span>.]</span> In the saying of Jábir Ibn-Ra-lán Es-Simbisee,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَمَّا رَأَتْ مَعْشَرًا قَلَّتْ حَمُولَتُهُمْ</span> *</div> 
						<div class="star">* <span class="ar long">قَالَتْ سُعَادُ أَهٰذَا مَالُكُمْ بَجَلَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When she saw a company whose beasts of burden were few, So'ád said, Is this your property, sufficing</em> you?]</span> meaning, when she saw the fewness of our camels: the last word occupies the place of a denotative of state, and is made to end thus by poetic license: Abu-l-ʼAlà says that this word may be put in the accus. case as meaning <em>not exceeding what I see;</em> or it may be for <span class="ar">بَجَلِى</span>, after the manner of some of the Arabs who are related, by Akh and others, to have said <span class="ar">غُلَامَا</span> for <span class="ar">غُلَامِى</span>. <span class="auth">(Ḥam pp. 299 and 300.)</span> <span class="add">[<a href="#bjl_2">See also 2</a>: <a href="#bajalN">and see <span class="ar">بَجَلٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَجَلْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bajalo_B1">
					<p>It is also a particle, <span class="auth">(Mughnee,)</span> meaning <span class="ar">نَعَمْ</span> <span class="add">[<em>Yes; yea;</em> or <em>even so</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajalN">
				<h3 class="entry"><span class="ar">بَجَلٌ</span></h3>
				<div class="sense" id="bajalN_A1">
					<p><span class="ar">بَجَلٌ</span> <em>Calumny, slander,</em> or <em>false accusation:</em> or this is with damm; <span class="auth">(Ḳ;)</span> i. e.<span class="arrow"><span class="ar">بُجْلٌ↓</span></span>; <span class="auth">(T, TA;)</span> meaning <em>a great calumny</em>, &amp;c.; <span class="auth">(Ḳ,* TA;)</span> and Az thinks that this may be <a href="#bujorN">a dial. var. of <span class="ar">بُجْرٌ</span></a>, with which it is syn.; because <span class="ar">ل</span> and <span class="ar">ر</span> are interchanged in many instances. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَجَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bajalN_A2">
					<p>A <em>wonderful</em> thing; syn. <span class="ar">عَجَبٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَجَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bajalN_A3">
					<p><span class="ar long">ذُو البَحَلِ</span> denotes dispraise; meaning <em>Content with mean things; not desirous of the means of acquiring eminence:</em> <span class="auth">(Ḳ:)</span> or <em>content that another should manage affairs in his stead, and that he should be a burden upon others, saying, Sufficient for me</em> (<span class="ar">حَسْبِى</span> <span class="add">[or <span class="ar">بَجَلِى</span>]</span>) <em>is that</em> <span class="add">[<em>state</em> or <em>condition</em>]</span> <em>wherein I am:</em> <span class="auth">(O, TA:)</span> from a saying of Luk- mán Ibn-'Ád; <span class="auth">(O, Ḳ;)</span> as is also <span class="ar long">ذُو البَجْلَةِ</span>, which denotes praise. <span class="auth">(O, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajolapN">
				<h3 class="entry"><span class="ar">بَجْلَةٌ</span></h3>
				<div class="sense" id="bajolapN_A1">
					<p><span class="ar">بَجْلَةٌ</span> <em>A goodly,</em> or <em>beautiful, from</em> or <em>appearance, figure, person, mien,</em> or <em>external state</em> or <em>condition:</em> <span class="auth">(Sh, Ḳ:)</span> <em>a pleasing aspect; goodliness,</em> or <em>beauty; grounds of pretension to respect;</em> and <em>excellence;</em> or <em>sharpness,</em> or <em>quickness, of intellect.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">إِنَّهُ لَذُو بَجْلَةٍ</span> <span class="add">[<em>Verily he has a goodly,</em> or <em>beautiful, form</em>, &amp;c.]</span>. <span class="auth">(Sh, TA.)</span> <span class="add">[See the end of the next preceding paragraph.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَجْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bajolapN_A2">
					<p><em>A small tree:</em> pl. <span class="ar">بَجَلَاتٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajaAlN">
				<h3 class="entry"><span class="ar">بَجَالٌ</span></h3>
				<div class="sense" id="bajaAlN_A1">
					<p><span class="ar">بَجَالٌ</span> and<span class="arrow"><span class="ar">بَجِيلٌ↓</span></span>, applied to a man, <em>i. q.</em><span class="arrow"><span class="ar">مُبَجَّلٌ↓</span></span> <span class="add">[<em>Magnified, honoured, revered, venerated,</em> or <em>respected</em>]</span>: <span class="auth">(Sh, Ḳ:)</span> or <em>bulky,</em> or <em>corpulent;</em> <span class="auth">(Aṣ, Ṣ;)</span> applied to a man; <span class="auth">(Aṣ, TA;)</span> or to an old man: <span class="auth">(Ṣ:)</span> or the former signifies <em>an old,</em> or <em>aged, lord</em> or <em>chief:</em> <span class="auth">(AA, Ṣ:)</span> or <em>a bulky,</em> or <em>corpulent, old man:</em> or, as some say, one <em>beyond the middle age, in whom one sees goodliness of form</em> or <em>appearance, and advancement in years:</em> <span class="auth">(Mgh:)</span> or both signify <em>an old man, who is a great lord</em> or <em>chief, endowed with goodliness, and with excel-lence,</em> or <em>sharpness of intellect:</em> <span class="auth">(Ḳ:)</span> not applied to a woman; <span class="auth">(TA;)</span> i. e., a woman is not termed <span class="ar">بَجَالَةٌ</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajiylN">
				<h3 class="entry"><span class="ar">بَجِيلٌ</span></h3>
				<div class="sense" id="bajiylN_A1">
					<p><span class="ar">بَجِيلٌ</span>: <a href="#bajaAlN">see <span class="ar">بَجَالٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَجِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bajiylN_A2">
					<p>Also <em>Gross, big, thick, coarse,</em> or <em>rough;</em> applied to anything. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَجِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bajiylN_A3">
					<p><span class="ar long">أَمْرٌ بَجِيلٌ</span> <em>An affair, an event,</em> or <em>a case, deemed strange,</em> or <em>evil, and great,</em> or <em>formidable.</em> <span class="auth">(TA.)</span> <span class="ar long">خَيْرٌ بَجِيلٌ</span> <em>Ample, abundant, good</em> or <em>wealth</em> or <em>prosperity.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAjilN">
				<h3 class="entry"><span class="ar">بَاجِلٌ</span></h3>
				<div class="sense" id="baAjilN_A1">
					<p><span class="ar">بَاجِلٌ</span> <em>Being in a good state</em> or <em>condition; having abundance of herbage,</em> or <em>of the goods</em> or <em>conveniences</em> or <em>comforts of life;</em> <span class="auth">(Ḳ;)</span> applied to a man and to a camel: <span class="auth">(TA:)</span> or, as Yaạḳoob says, on the authority of Abu-l-Ghamr El-'Okeylee, <em>having much fat;</em> applied to a man and a she-camel and a he-camel. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجل</span> - Entry: <span class="ar">بَاجِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAjilN_A2">
					<p>Also <em>Joyful, glad,</em> or <em>happy.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabojalu">
				<h3 class="entry"><span class="ar">أَبْجَلُ</span></h3>
				<div class="sense" id="Oabojalu_A1">
					<p><span class="ar">أَبْجَلُ</span> <em>A certain vein,</em> <span class="auth">(Ṣ,)</span> <em>a thick vein,</em> <span class="auth">(Ḳ, Ḥam p. 417,)</span> <em>of the horse and of the camel,</em> <span class="auth">(Ṣ, TA,)</span> <em>in the thigh and the shank,</em> <span class="auth">(Ḥam ubi suprà,)</span> or <em>in the kind leg</em> or <em>the fore leg,</em> <span class="auth">(TA,)</span> <em>corresponding to the</em> <span class="ar">أَكْمَل</span> <span class="auth">(Ṣ, Ḳ)</span> <em>of man:</em> <span class="auth">(Ṣ:)</span> pl. <span class="ar">أَبَاجِلُ</span>. <span class="auth">(Ḥam ubi suprà, TA.)</span> You say, <span class="ar long">فَصَدَ أَبْجَلَهُ</span> <span class="add">[<em>He opened his</em> <span class="ar">ابجل</span>]</span>; i. e., the horse's or the camel's. <span class="auth">(TA.)</span> And one says of a swift horse, <span class="ar long">هُوَ وَاهِى الأَبَاجِلِ</span> <span class="add">[<em>He is lax in the</em> <span class="ar">اباجل</span>]</span>. <span class="auth">(Ḥam ubi suprà.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubBjBalN">
				<h3 class="entry"><span class="ar">مُبّجَّلٌ</span></h3>
				<div class="sense" id="mubBjBalN_A1">
					<p><span class="ar">مُبّجَّلٌ</span>: <a href="#bajaAlN">see <span class="ar">بَجَالٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0153.pdf" target="pdf">
							<span>Lanes Lexicon Page 153</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0154.pdf" target="pdf">
							<span>Lanes Lexicon Page 154</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
