<article class="root" id="Root_bws">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/219_bwz">بوز</a></span>
				<span class="ar">بوس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/221_bwX">بوش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bws_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوس</span> ⇒ <span class="ar">باس</span></h3>
				<div class="sense" id="bws_1_A1">
					<p><span class="ar">بَاسَهُ</span>, aor. <span class="ar">يَبُوسُهُ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">بَوْسٌ</span>, a Persian word, arabicized, <span class="auth">(Ṣ, A, Ḳ,)</span> <em>He kissed him.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> You say also, <span class="ar long">بَاسَ لَهُ الأَرْضَ</span> <em>He kissed the ground to him.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabuwsN">
				<h3 class="entry"><span class="ar">مَبُوسٌ</span></h3>
				<div class="sense" id="mabuwsN_A1">
					<p><span class="ar">مَبُوسٌ</span> <em>Kissed:</em> you say, <span class="ar long">اليَوْمَ بِسَاطُكَ مَبُوسٌ وَغَدًا أَنْتَ مَحْبُوسٌ</span> <span class="add">[<em>To-day thy carpet is kissed, and to-morrow thou art imprisoned</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0275.pdf" target="pdf">
							<span>Lanes Lexicon Page 275</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
