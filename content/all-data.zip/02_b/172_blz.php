<article class="root" id="Root_blz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/171_bld">بلد</a></span>
				<span class="ar">بلز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/173_bls">بلس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="QloIiboliyzi">
				<h3 class="entry"><span class="ar">ٱلْإِبْلِيزِ</span></h3>
				<div class="sense" id="QloIiboliyzi_A1">
					<p><span class="ar long">طِينُ ٱلْإِبْلِيزِ</span> <em>The mud of Egypt;</em> <span class="auth">(Ḳ;)</span> <em>what the Nile leaves behind it after retiring from the surface of the ground:</em> <span class="auth">(TA:)</span> a foreign word <span class="add">[arabicized, perhaps from the Greek <span class="gr">πηλὸς</span>, as suggested by De Sacy; who also remarks that it might be derived from the Greek <span class="gr">ἰλὺς</span> with the Egyptian masc. art. <span class="gr">πι</span>, were it not that <span class="gr">ἰλὺς</span> is fem.: <span class="auth">(see his “Abd-allatif,” p. 8:)</span> if we might suppose <span class="ar">ابليز</span> to be an old mistranscription for <span class="ar">ايليز</span>, we might with good reason derive it from <span class="gr">ἰλὺς</span>, which, as pronounced by the modern Greeks, very nearly resembles <span class="ar">إِيلِيز</span> in sound]</span>: <span class="auth">(Ḳ:)</span> <span class="add">[some of]</span> the vulgar pronounce it with <span class="ar">س</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلز</span> - Entry: <span class="ar">ٱلْإِبْلِيزِ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="QloIiboliyzi_A2">
					<p><span class="add">[Also applied to <em>Clay; plastic clay;</em> or <em>potters' earth.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0248.pdf" target="pdf">
							<span>Lanes Lexicon Page 248</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
