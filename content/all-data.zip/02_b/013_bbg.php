<article class="root" id="Root_bbg">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/012_bbr">ببر</a></span>
				<span class="ar">ببغ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/014_bt">بت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="babogaMCu">
				<h3 class="entry"><span class="ar">بَبْغَآءُ</span></h3>
				<div class="sense" id="babogaMCu_A1">
					<p><span class="ar">بَبْغَآءُ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بَبَّغَآءُ</span> <span class="auth">(Ḳ, Ḳzw)</span> <span class="add">[in modern vulgar Arabic <span class="ar">بَبَغَان</span>, The <em>parrot;</em>]</span> <em>a certain well-known bird;</em> <span class="auth">(Mṣb;)</span> <em>a certain green bird,</em> <span class="auth">(Ṣgh, Ḳ, TA,)</span> <em>well known;</em> <span class="auth">(TA;)</span> the <em>bird called in Persian</em> <span class="fa">طُوطِي</span>, <em>beautiful in colour and form, mostly green, but in some instances red, and yellow, and white; having a thick bill and tongue: it hears the speech of men and repeats it, without knowing its meaning; and utters letters rightly:</em> when they desire to teach it, they put a mirror in its cage, so that it sees therein its own form, and they speak to it from behind the mirror, and when it hears, it repeats, desiring to do as its like; and thus it learns quickly: one of the wonders relating to it is <span class="add">[said to be this]</span>, that it never drinks water; for if it drank, it would die: <span class="auth">(Ḳzw:)</span> the affix renders fem. the word, but not the thing named thereby, like the <span class="ar">ة</span> in <span class="ar">حَمَامَةٌ</span> and <span class="ar">نَعَامَةٌ</span>; for the word applies to the male and the female, so that one says, <span class="ar long">بَبْغَآءُ ذَكَرٌ</span> <span class="add">[<em>a male parrot</em>]</span> and <span class="ar long">بَبْغَآءُ أُنْثَى</span> <span class="add">[<em>a female parrot</em>]</span>: and the pl. is <span class="ar">بَبْغَاوَاتٌ</span> <span class="add">[or <span class="ar">بَبَّغَاوَاتٌ</span>]</span>, like as <span class="ar">صَحْرَاوَتٌ</span> <a href="#SaHoraACu">is pl. of <span class="ar">صَحْرَآءُ</span></a>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0147.pdf" target="pdf">
							<span>Lanes Lexicon Page 147</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
