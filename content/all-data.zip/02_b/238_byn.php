<article class="root" id="Root_byn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/237_bylwn">بيلون</a></span>
				<span class="ar">بين</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/239_byh">بيه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="byn_1">
				<h3 class="entry">1. ⇒ <span class="ar">بين</span> ⇒ <span class="ar">بان</span></h3>
				<div class="sense" id="byn_1_A1">
					<p><span class="ar">بَانَ</span>, <span class="auth">(M, Mgh, Mṣb, Ḳ,)</span> <span class="add">[aor. <span class="ar">يَبِينُ</span>,]</span> inf. n. <span class="ar">بَيْنُونَةٌ</span> and <span class="ar">بُيُونٌ</span> <span class="auth">(M, Mgh, Ḳ)</span> and <span class="ar">بَيْنٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>It</em> (<em>a thing</em>) <em>became separated, severed, disunited,</em> or <em>cut off,</em> <span class="auth">(M, Mgh, Mṣb, Ḳ,)</span> <span class="ar long">عَنِ الشَّىْءِ</span> <em>from the thing.</em> <span class="auth">(Mgh.)</span> And <span class="ar">بَانَتْ</span>, <span class="auth">(M, Ḳ,)</span> or <span class="ar long">بَانَتْ بِالطَّلَاقِ</span>, <span class="auth">(Mṣb,)</span> <em>She</em> <span class="auth">(a wife)</span> <em>became separated by divorce,</em> <span class="auth">(M, Mṣb, Ḳ,)</span> <span class="ar long">عَنِ الرَّجُلِ</span> <em>from the man.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar">بَانَتٌ</span> said of a girl, <span class="add">[<em>She became separated from her parents by marriage;</em>]</span> <em>she married:</em> <span class="auth">(ISh, T:)</span> as though she became at a distance from the house of her father. <span class="auth">(ISh, TA.)</span> And <span class="ar">بَانَ</span>, <span class="auth">(M,)</span> or <span class="ar long">بَانَ بِمَالٍ</span>, aor. <span class="ar">يَبِينُ</span>, <span class="auth">(T,)</span> inf. n. <span class="ar">بُيُونٌ</span> <span class="auth">(T, M)</span> and <span class="ar">بَيْنٌ</span>, <span class="auth">(M,)</span> <em>He became separated from his father,</em> or <em>mother,</em> or <em>both, by property</em> <span class="add">[<em>which he received from him,</em> or <em>her,</em> or <em>them,</em>]</span> <span class="auth">(AZ, T, M,)</span> <em>to be his alone:</em> <span class="auth">(AZ, T:)</span> <span class="pb" id="Page_0286"></span>and El-Fárisee states, on the authority of AZ, that one says also, <span class="ar long">بَانَ عَنْهُ</span> and <span class="ar">بَانَهُ</span> <span class="add">[the former app. meaning <em>he became separated thus from him,</em> i. e., from his father; and the latter being syn. with <span class="ar">أَبَانَهُ</span>, q. v.]</span>. <span class="auth">(M.)</span> And <span class="ar long">بَانَ الخَلِيطُ</span>, inf. n. <span class="ar">بَيْنٌ</span> and <span class="ar">بَيْنُونَةٌ</span>, <span class="add">[<em>The partner,</em> or <em>copartner,</em> or <em>sharer,</em>, &amp;c., <em>became separated from the person,</em> or <em>persons, with whom he had been associated.</em>]</span> <span class="auth">(T.)</span> And <span class="ar long">بَانَتْ يَدُ النَّاقَةِ عَنْ جَنْبِهَا</span>, inf. n. <span class="ar">بُيُونٌ</span>, <span class="add">[<em>The fore leg of the she-camel became withdrawn,</em> or <em>apart, from her side.</em>]</span> <span class="auth">(T.)</span> And <span class="ar">بَانَ</span>, <span class="auth">(Ṣ, M, Mṣb,)</span> and <span class="ar">بَانُوا</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">يَبِينُ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">بَيْنٌ</span> and <span class="ar">بَيْنُونَةٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>He separated himself,</em> or <em>it separated itself;</em> <span class="auth">(Ṣ; <span class="add">[in one copy of which it is said of a thing;]</span>)</span> and <em>they separated themselves:</em> <span class="auth">(Ḳ:)</span> or <em>it</em> <span class="auth">(a tribe, M, Mṣb)</span> <em>went, journeyed, went away,</em> or <em>departed;</em> and <em>went, removed, retired,</em> or <em>withdrew itself, to a distance,</em> or <em>far away,</em> or <em>far off.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byn_1_A2">
					<p><span class="ar">بَانَ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">يَبِينُ</span>, <span class="auth">(T, Mṣb,)</span> inf. n. <span class="ar">بَيَانٌ</span>; <span class="auth">(T, Ṣ, Mgh, Ḳ;)</span> and<span class="arrow"><span class="ar">ابان↓</span></span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">إِبَانَةٌ</span>; <span class="auth">(T, Mṣb;)</span> and<span class="arrow"><span class="ar">بيّن↓</span></span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">تَبْيِينٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">تبيّن↓</span></span>; and<span class="arrow"><span class="ar">استبان↓</span></span>; <span class="auth">(T, Ṣ, M, &amp;c.,)</span> all signify the same; <span class="auth">(T, M, Mṣb;)</span> i. e. <em>It</em> <span class="auth">(a thing, T, Ṣ, M, Mgh, or an affair, or a case, Mṣb)</span> <em>was,</em> or <em>became,</em> <span class="add">[<em>distinct, as though separate from others;</em> and thus,]</span> <em>apparent, manifest, evident, clear, plain,</em> or <em>perspicuous:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> and <em>it was,</em> or <em>became, known.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">بَانَ الحَقُّ</span> <span class="add">[<em>The truth became apparent,</em>, &amp;c.; or <em>known</em>]</span>; as also<span class="arrow"><span class="ar">ابان↓</span></span>. <span class="auth">(T.)</span> And</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">قَدْ بَيَّنَ↓ الصُّبْحُ لِذِى عَيْنَيْنِ</span></span> *</div> 
					</blockquote>
					<p><em>The dawn has become apparent to him who has two eyes:</em> a prov.: <span class="auth">(Ṣ, M:)</span> applied to a thing that becomes altogether apparent, or manifest. <span class="auth">(Ḥar p. 542.)</span> And it is said in the Ḳur <span class="add">[ii. 257]</span>,<span class="arrow"><span class="ar long">قَدْ تَبَيَّنَ↓ الرُّشْدُ مِنَ الغَىِّ</span></span> <span class="add">[<em>The right belief hath become distinguished from error</em>]</span>. <span class="auth">(TA.)</span> And the lawyers, correctly, use the phrase,<span class="arrow"><span class="ar long">كَصَوْتٍ لَا يَسْتَبِينُ↓ مِنْهُ حُرُوفٌ</span></span> <span class="add">[<em>Like a sound whereof letters are not distinguishable</em>]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="byn_1_A3">
					<p><span class="add">[It seems to be indicated in the TA that <span class="ar">بَانَ</span>, aor. <span class="ar">يَبِينُ</span>, inf. n. <span class="ar">بَيْنٌ</span> and <span class="ar">بَيْنُونَةٌ</span>, also signifies <em>It was,</em> or <em>became, united,</em> or <em>connected;</em> thus having two contr. meanings; but I have not found the verb used in this sense, though <span class="ar">بَيْنٌ</span> signifies both disunion and union.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byn_1_B1">
					<p><span class="ar">بَانَهُ</span>, aor. <span class="ar">يَبِينُ</span>, inf. n. <span class="ar">بَيْنٌ</span>: <a href="#bwn_1">see <span class="ar">بَانَهُ</span></a>, aor. <span class="ar">يَبُونُ</span>, inf. n. <span class="ar">بَوْنٌ</span>, <a href="index.php?data=02_b/226_bwn">in art. <span class="ar">بون</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="byn_1_C1">
					<p><a href="#byn_2">See also 2</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byn_2">
				<h3 class="entry">2. ⇒ <span class="ar">بيّن</span></h3>
				<div class="sense" id="byn_2_A1">
					<p><span class="ar">بيّن</span>, intrans., inf. n. <span class="ar">تَبْيِينٌ</span>: <a href="#byn_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byn_2_A2">
					<p>You say also, <span class="ar long">بيّن الشَّجَرُ</span> <em>The trees,</em> <span class="auth">(Ḳ,)</span> <em>or the leaves of the trees,</em> <span class="auth">(TA,)</span> <em>appeared, when beginning to grow forth.</em> <span class="auth">(Ḳ, TA.)</span> And <span class="ar long">بيّن القَرْنُ</span> ‡ <em>The horn came forth.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byn_2_B1">
					<p><span class="ar long">بيّن بِنْتَهُ</span>: <a href="#byn_4">see 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="byn_2_B2">
					<p><span class="ar">بيّنهُ</span>, <span class="auth">(T, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَبْيِينٌ</span> <span class="auth">(T, Ṣ)</span> and<span class="arrow"><span class="ar">تِبْيَانٌ↓</span></span> <span class="auth">(T, Ṣ,* Ḳ *)</span> and <span class="ar">تَبْيَانٌ</span>; <span class="auth">(Ḳ;)</span> the second of which three is an anomalous inf. n., <span class="auth">(T, Ṣ, Ḳ,)</span> for by rule it should be of the measure <span class="ar">تَفْعَالٌ</span>; <span class="auth">(T, Ṣ;)</span> but <span class="ar">تَبْيَانٌ</span> is not known except accord. to the opinion of those who allow the authority of analogy, which opinion is outweighed by the contrary; <span class="auth">(TA;)</span> and <span class="ar">تِبْيَانٌ</span> is the only inf. n. of its measure except <span class="ar">تِلْقَآءٌ</span>, <span class="auth">(T, Ṣ,)</span> accord. to the generality of the leading authorities; but some add <span class="ar">تِمْثَالٌ</span>, as inf. n. of <span class="ar">مَثَّلَ</span>; and El-Ḥareeree adds to these two, in the Durrah, <span class="ar">تِنْضَالٌ</span>, as inf. n. of <span class="ar">نَاضَلَهُ</span>; and Esh-Shiháb adds, in the Expos. of the Durrah, <span class="ar">تِشْرَابٌ</span>, as inf. n. of <span class="ar long">شَرِبَ الخَمْرَ</span>; asserting <span class="ar">تَشْرَابٌ</span> also to have been heard, agreeably with analogy; <span class="add">[and to these may be added <span class="ar">تَبْكَآءٌ</span> and <span class="ar">تِمْشَآءٌ</span>, and perhaps some other instances of the same kind;]</span> but some disallow <span class="ar">تِفْعَالٌ</span> altogether as the measure of an inf. n., saying that the words transmitted as instances thereof are simple substs. used as inf. ns., like <span class="ar">طَعَامٌ</span> in the place of <span class="ar">إِطْعَامٌ</span>; <span class="auth">(MF, TA;)</span> and Sb says that <span class="ar">تِبْيَانٌ</span> is not an inf. n.; for, where it so, it would be <span class="ar">تَبْيَانٌ</span>; but it is, from <span class="ar">بَيَّنْتُ</span>, like <span class="ar">غَارَةٌ</span> from <span class="ar">أَغَرْتُ</span>; <span class="auth">(M, TA;)</span> <span class="add">[<em>He made it distinct, as though separate from others;</em> and thus,]</span> <em>he made it</em> <span class="auth">(namely, a thing, T, Ṣ, Mgh, or an affair, or a case, Mṣb)</span> <em>apparent, manifest, evident, clear, plain,</em> or <em>perspicuous;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابانهُ↓</span></span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِبَانَةٌ</span>; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">تبيّنهُ↓</span></span>; <span class="auth">(Ṣ,* Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">استبانهُ↓</span></span>: <span class="auth">(Mgh, Mṣb, Ḳ:)</span> <span class="add">[<span class="ar">بيّنهُ</span> is the most common in this sense: and often signifies <em>he explained it:</em> and <em>he proved it:</em>]</span> and<span class="arrow">↓</span> all these verbs signify also <em>he made it known; he notified it:</em> <span class="auth">(Ḳ:)</span> or<span class="arrow"><span class="ar">اِسْتَبَنْتُهُ↓</span></span> signifies, <span class="auth">(Ṣ,)</span> or signifies also, <span class="auth">(Mgh,)</span> <em>I knew it,</em> or <em>became acquainted with it,</em> <span class="add">[or <em>distinguished it,</em>]</span> <span class="auth">(Ṣ, Mgh,)</span> <em>clearly,</em> or <em>plainly;</em> <span class="auth">(Mgh;)</span> and so<span class="arrow"><span class="ar">تَبَيَّنْتُهُ↓</span></span>; <span class="auth">(Ṣ,* Mgh;)</span> <span class="add">[and <span class="ar">بَيَّنْتُهُ</span>, as appears from an ex. in what follows, from a verse of En-Nábighah:]</span> <span class="arrow"><span class="ar">بِنْتُهُ↓</span></span> and<span class="arrow"><span class="ar">أَبَنْتُهُ↓</span></span> and<span class="arrow"><span class="ar">اِسْتَبَنْتُهُ↓</span></span> and <span class="ar">بَيَّنْتُهُ</span> all signify the same as <span class="arrow"><span class="ar">تَبَيَّنْتُهُ↓</span></span> <span class="add">[app. in all the senses of this verb]</span>: <span class="auth">(M:)</span> or, of all these verbs, <span class="arrow"><span class="ar">بَانَ↓</span></span> is only intrans.: <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">اِسْتَبَنْتُهُ↓</span></span> signifies <em>I looked at it,</em> or <em>into it,</em> <span class="auth">(namely, a thing,)</span> <em>considered it, examined it,</em> or <em>studied it, repeatedly, in order that it might become apparent, manifest, evident, clear,</em> or <em>plain, to me:</em> <span class="auth">(T, TA:)</span> and<span class="arrow"><span class="ar">تبيّنهُ↓</span></span> <em>he looked at it,</em> or <em>into it,</em> <span class="auth">(namely, an affair, or a case,)</span> <em>considered it, examined it,</em> or <em>studied it, repeatedly,</em> or <em>deliberately, in order to know its real state by the external signs thereof.</em> <span class="auth">(T.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمَا خِفْتُ حَتَّى بَيَّنَ الشِّرْبُ وَالأَذَى</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">بقَانِئَةٍ أَنِّى مِنَ الحَىِّ أَبْيَنُ↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And I feared not until the drinking,</em> or <em>the time of drinking, and molestation, made manifest,</em> or <em>plainly showed, by a deep-red</em> (<em>sun</em>), <em>that I was separated from the tribe:</em> <a href="#qaAniyN">see <span class="ar">قَانِئٌ</span></a>]</span>. <span class="auth">(M.)</span> And it is said in the Ḳur <span class="add">[xvi. 91]</span>, <span class="ar long">وَأَنْزَلْنَا عَلَيْكَ الكِتَابَ تِبْيَانًا لِكُلِّ شَىْءٍ</span> <span class="add">[<em>And we have sent down to thee the Scripture to make manifest everything</em>]</span>; meaning, we make manifest to thee in the Scripture everything that thou and thy people require <span class="add">[to know]</span> respecting matters of religion. <span class="auth">(T.)</span> <a href="#bayaAnN">See also <span class="ar">بَيَانٌ</span></a>, in the latter half of the paragraph. En-Nábighah says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِلَّا الأَوَارِىَّ مَّا أُبَيِّنُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Except the places of the confinement of the beasts: with difficulty did I distinguish them</em>]</span>; meaning<span class="arrow"><span class="ar">أَتَبَيَّنُهَا↓</span></span>. <span class="auth">(Ṣ.)</span> You say also,<span class="arrow"><span class="ar long">تَبَيَّنَ↓ مَا يَأْتِيهِ</span></span>, meaning <em>He sought,</em> or <em>endeavoured, to see,</em> or <em>discover, what would happen to him,</em> of good and evil. <span class="auth">(M in art. <span class="ar">بصر</span>.)</span> <span class="add">[<a href="#byn_5">See also 5, below</a>.]</span> <span class="arrow"><span class="ar long">وَلِتَسْتَبِينَ سَبِيلَ المُجْرِمِينَ</span></span>, in the Ḳur <span class="add">[vi. 55]</span>, means <em>And that thou mayest</em> the more <em>consider,</em> or <em>examine, repeatedly, in order that it may become manifest to thee, the way of the sinners,</em> O Moḥammad: <span class="auth">(T:)</span> or <em>that thou mayest seek,</em> or <em>endeavour, to see plainly,</em> or <em>clearly,</em>, &amp;c.; syn. <span class="ar long">وَلِتَسْتَوْضِحَ سَبِيلَهُمْ</span>: <span class="auth">(Bḍ:)</span> but most read, <span class="ar long">وَلِيَسْتَبِينَ سيبلُ المجرمين</span>; the verb in this case being intrans. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byn_3">
				<h3 class="entry">3. ⇒ <span class="ar">باين</span></h3>
				<div class="sense" id="byn_3_A1">
					<p><span class="ar">باينهُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُبَايَنَةٌ</span>, <span class="auth">(Ṣ,)</span> <em>He separated himself from him;</em> or <em>left, forsook,</em> or <em>abandoned, him:</em> <span class="auth">(Ṣ, TA:)</span> or <em>he forsook,</em> or <em>abandoned, him, being forsaken,</em> or <em>abandoned, by him;</em> or <em>cut him off from friendly or loving communion or intercourse, being so cut off by him;</em> or <em>cut him,</em> or <em>ceased to speak to him, being in like manner cut by him.</em> <span class="auth">(Ḳ.)</span> <span class="add">[And <em>It became separated from it.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byn_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابين</span> ⇒ <span class="ar">ابان</span></h3>
				<div class="sense" id="byn_4_A1">
					<p><span class="ar">ابان</span>, intrans., inf. n. <span class="ar">إِبَانَةٌ</span>: <a href="#byn_1">see 1</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byn_4_B1">
					<p><span class="ar">ابانهُ</span>, <span class="auth">(inf. n. as above, TA,)</span> <em>He separated it, severed it, disunited it,</em> or <em>cut it off.</em> <span class="auth">(M, Mṣb, Ḳ, TA.)</span> You say, <span class="ar long">ضَرَبَهُ فَأَبَانَ رَأْسَهُ</span> <span class="auth">(Ṣ, Ḳ)</span> <em>He smote him and severed his head,</em> <span class="ar long">مِنْ جَسَدِهِ</span> <em>from his body.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">ابان المَرْأَةَ</span> <em>He</em> <span class="auth">(the husband)</span> <em>separated the woman,</em> or <em>wife,</em> by divorce. <span class="auth">(Mṣb.)</span> And <span class="ar long">ابان بِنْتَهُ</span>, and<span class="arrow"><span class="ar">بيّنها↓</span></span>, <span class="auth">(T, Ḳ,)</span> inf. n. of the former as above, and of the latter <span class="ar">تَبْيِينٌ</span>, <span class="auth">(TA,)</span> <em>He married,</em> or <em>gave in marriage, his daughter,</em> <span class="auth">(T, Ḳ,)</span> <em>and she went to her husband:</em> <span class="auth">(T:)</span> from <span class="ar">بَيْنٌ</span> signifying “distance:” as though he removed her to a distance from the house, or tent, of her mother. <span class="auth">(TA.)</span> And <span class="ar long">ابان ٱبْنَهُ بِمَالٍ</span>, <span class="auth">(M,)</span> or <span class="ar long">ابانهُ أَبَوَاهُ</span>, <span class="auth">(T,)</span> <em>He separated from himself his son,</em> <span class="auth">(M,)</span> or <em>his two parents separated him from themselves,</em> <span class="auth">(T,)</span> <em>by</em> <span class="add">[<em>giving him</em>]</span> <em>property,</em> <span class="auth">(T, M,)</span> <em>to be his alone:</em> <span class="auth">(T:)</span> mentioned on the authority of AZ. <span class="auth">(T, M.)</span> And <span class="ar long">ابان الدَّلْوَ عَنْ طِىِّ البِئْرِ</span> <em>He drew away the bucket from the casing of the well, lest the latter should lacerate the former.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="byn_4_B2">
					<p><a href="#byn_2">See also 2</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="byn_4_B3">
					<p><span class="add">[Hence, <span class="ar">ابان</span> signifies also <em>He spoke,</em> or <em>wrote, perspicuously, clearly, plainly,</em> or <em>distinctly, as to meaning;</em> or, <em>with eloquence:</em> from <span class="ar">بَيَانٌ</span>, q. v.]</span> And <span class="ar long">ابان عَلَيْهِ</span> <em>He spoke perspicuously, clearly, plainly,</em> or <em>distinctly, and gave his testimony,</em> or <em>evidence,</em> or <em>gave decisive information, against him,</em> or <em>respecting it.</em> <span class="auth">(TA.)</span> <span class="add">[The verb thus used is for <span class="ar long">ابان كَلَامَهُ</span>, and <span class="ar">شَهَادَتَهُ</span>.]</span> One says of a drunken man, <span class="ar long">مَا يُبِينُ كَلَامًا</span> <em>He does not speak plainly,</em> or <em>distinctly;</em> lit., <em>does not make speech plain,</em> or <em>distinct.</em> <span class="auth">(Ks, T in art. <span class="ar">بت</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="byn_4_B4">
					<p><span class="add">[<span class="ar long">مَا أَبْيَنَهُ</span> <em>How distinct, apparent, manifest, evident, clear,</em> or <em>plain, is it!</em> See an ex. voce <span class="ar">بَسُلَ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="byn_4_B5">
					<p><span class="add">[And <em>How perspicuous,</em> or <em>chaste,</em> or <em>eloquent, is he in speech,</em> or <em>writing! how good is his</em> <span class="ar">بَيَان</span>!]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبيّن</span></h3>
				<div class="sense" id="byn_5_A1">
					<p><span class="ar">تبيّن</span>, intrans.: <a href="#byn_1">see 1</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byn_5_B1">
					<p>As a trans. verb: <a href="#byn_2">see 2</a>, in seven places.</p>
				</div>
				<span class="pb" id="Page_0287"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="byn_5_B2">
					<p><span class="add">[Hence,<span class="ar">الأَمْرَ</span> being understood,]</span> <em>He sought,</em> or <em>sought leisurely</em> or <em>repeatedly, to obtain knowledge</em> <span class="add">[<em>of the thing</em>]</span>, <em>until he knew</em> <span class="add">[<em>it</em>]</span>; <em>he examined, scrutinized,</em> or <em>investigated:</em> <span class="auth">(Bḍ in xlix. 6:)</span> <em>he sought,</em> or <em>endeavoured, to make the affair,</em> or <em>case, manifest, and to settle it,</em> or <em>establish it, and was not hasty therein:</em> <span class="auth">(Idem in iv. 96:)</span> or <em>he acted,</em> or <em>proceeded, deliberately,</em> or <em>leisurely, in the affair,</em> or <em>case; not hastily:</em> <span class="auth">(Ks, TA:)</span> or it has a signification like this: in the Ḳur ch. iv. v. 96 and ch. xlix. v. 6, some read <span class="ar">فَتَبَيَّنُوا</span>, and others <span class="ar">فَتَثَبَّتُوا</span>; and the meanings are nearly the same: <span class="ar">التَّبَيُّنُ</span> was said by Moḥammad to be from God, and <span class="ar">العَجَلَةٌ</span> <span class="add">[i. e. “haste”]</span> from the devil. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byn_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباين</span></h3>
				<div class="sense" id="byn_6_A1">
					<p><span class="ar">تباينا</span> <em>They two</em> <span class="auth">(namely, two men, and two copartners,)</span> <em>became separated, each from the other:</em> <span class="auth">(M, TA:)</span> or <em>they forsook,</em> or <em>abandoned, each other;</em> or <em>cut each other off from friendly or loving communion or intercourse;</em> or <em>cut,</em> or <em>ceased to speak to, each other.</em> <span class="auth">(Ḳ.)</span> And <span class="ar">تباينوا</span> <em>They, having been together, became separated:</em> <span class="auth">(Mṣb:)</span> or <em>they forsook,</em> or <em>abandoned, one another;</em> or <em>cut one another off from friendly or loving communion or intercourse;</em> or <em>cut,</em> or <em>ceased to speak to, one another.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byn_6_A2">
					<p><span class="add">[Hence, <em>They two were dissimilar:</em> and <em>they two</em> <span class="auth">(namely, words,)</span> <em>were disparate;</em> whether contraries or not: and <em>they two</em> <span class="auth">(namely, numbers,)</span> <em>were incommensurable.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="byn_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبين</span> ⇒ <span class="ar">استبان</span></h3>
				<div class="sense" id="byn_10_A1">
					<p><span class="ar">استبان</span>, intrans.: <a href="#byn_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byn_10_B1">
					<p>As a trans. verb: <a href="#byn_2">see 2</a>, in six places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAnN.1">
				<h3 class="entry"><span class="ar">بَانٌ</span> / <span class="ar">بَانَةٌ</span></h3>
				<div class="sense" id="baAnN.1_A1">
					<p><span class="ar">بَانٌ</span> a coll. gen. n.: n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَانَةٌ</span>}</span></add>: <a href="index.php?data=02_b/226_bwn">see art. <span class="ar">بون</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayonN">
				<h3 class="entry"><span class="ar">بَيْنٌ</span></h3>
				<div class="sense" id="bayonN_A1">
					<p><span class="ar">بَيْنٌ</span> has two contr. significations; <span class="auth">(T, Ṣ, Mṣb;)</span> one of which is <em>Separation,</em> or <em>disunion</em> <span class="add">[of companions or friends or lovers]</span>. <span class="auth">(T, Ṣ, M, Mṣb, Ḳ.)</span> Hence, <span class="ar long">ذَاتُ البَيْنِ</span> as meaning <em>Enmity,</em> and <em>vehement hatred:</em> and the saying <span class="ar long">لِإِصْلَاحِ ذَاتِ البَيْنِ</span>, i. e. <em>For the reforming,</em> or <em>amending, of the bad,</em> or <em>corrupt, state subsisting between the people,</em> or <em>company of men;</em> meaning <em>for the allaying of the discord, enmity, rancour,</em> or <em>vehement hatred:</em> <span class="auth">(Mṣb:)</span> <span class="add">[but this has also the contr. meaning, as will be seen below: and it is explained as having a vague import; for it is said that]</span> <span class="ar long">فِى إِصْلَاحِ ذَاتِ البَيْنِ</span> means <em>In the reforming,</em> or <em>amending, of the circumstances subsisting between the persons to whom it relates, by frequent attention thereto.</em> <span class="auth">(Mgh.)</span> <span class="add">[Hence also,]</span> <span class="ar long">غُرَابُ البَيْنِ</span> <span class="add">[<em>The raven of separation</em> or <em>disunion;</em> i. e., whose appearance, or croak, is ominous of separation: said by some to be]</span> <em>the</em> <span class="ar">غراب</span> <em>termed</em> <span class="ar">أَبْقَعُ</span> <span class="add">[i. e. <em>in which is blackness and whiteness;</em> or <em>having whiteness in the breast</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> so described by the poet 'Antarah: <span class="auth">(Ṣ:)</span> or <em>that which is red in the beak and legs;</em> but the black is called <span class="ar">الحَاتِمُ</span>, because it makes <span class="add">[or shows]</span> separation to be absolutely unavoidable, <span class="auth">(Abu-1-Ghowth, Ṣ, Ḳ,)</span> according to the assertion of the Arabs, i. e., by its croak: <span class="auth">(Mṣb in art. <span class="ar">حتم</span>:)</span> <span class="add">[or it is <em>any species of the corvus:</em>]</span> Hamzeh says, in his Proverbs, that this name attaches to the <span class="ar">غراب</span> because, when the people of an abode go away to seek after herbage, it alights in the place of their tents, searching the sweepings: <span class="auth">(Ḥar p. 308:)</span> but accord. to the Kádee of Granada, Aboo-ʼAbd-Allah Esh-Shereef, this appellation, so often occurring in poetry, properly signifies <em>camels that transport people from one district,</em> or <em>country, to another;</em> and he cites the following verses:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">غَلِطَ الَّذِينَ رَأَيْتُهُمْ بِجَهَالَةٍ</span> *</div> 
						<div class="star">* <span class="ar long">يَلْحَوْنَ كُلُّهُمُ غُرَابًا يَنْعَقُ</span> *</div> 
						<div class="star">* <span class="ar long">مَا الذَّنْبُ إِلَّا لِلْأَبَاعِرِ إِنَّهَا</span> *</div> 
						<div class="star">* <span class="ar long">مِمَّا يُشَتِّتُ جَمْعَهُمْ وَيُقَرِّقُ</span> *</div> 
						<div class="star">* <span class="ar long">إِنَّ الغُرَابَ بِيُمْنِهِ تُدْنُو النَّوَى</span> *</div> 
						<div class="star">* <span class="ar long">وَتُشَتِّتُ الشَّمْلَ الجَمِيعَ الأَيْنُقُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Those have erred whom I have seen, with ignorance, all of them blaming a raven croaking: the fault is not imputable save to the camels; for they are of the things that scatter and disperse their congregation: verily the place that is the object of a journey is brought near by the raven's lucky omen; but the she-camels discompose the united state</em>]</span>: and Ibn-ʼAbd-Rabbih says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">زَعَقَ الغُرَابُ فَقُلْتُ أَكْذَبُ طَائِرٍ</span> *</div> 
						<div class="star">* <span class="ar long">إِن لَّمْ يُصَدِّقْهُ رُغَآءُ بَعِيرِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>The raven cried; and I said, A most lying bird, if the grumbling cry of a camel on the occasion of his being laden do not verify it</em>]</span>. <span class="auth">(TA in art. <span class="ar">غرب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayonN_A2">
					<p>Also <em>Distance,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>by the space,</em> or <em>interval, between two things.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">بَيْنَ البَلَدَيْنِ بَيْنٌ</span> <em>Between the two countries,</em> or <em>towns,</em>, &amp;c., <em>is a distance, of space,</em> or <em>interval:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">بَيْنَهُمَا بَيْنٌ</span> <em>Between them two is a distance,</em> with <span class="ar">ى</span> when corporeal distance is meant: <span class="auth">(Idem in art. <span class="ar">بون</span>:)</span> or <span class="ar long">إِنَّ بَيْنَهُمَا لَبَيْنٌ</span> <span class="add">[<em>Verily between them two is a distance</em>]</span>, not otherwise, in the case of <span class="add">[literal]</span> distance. <span class="auth">(Ṣ.)</span> And you say also, <span class="ar long">بَيْنَهُمَا بَيْنٌ بَعِيدٌ</span> <span class="auth">(T in art. <span class="ar">بون</span>, Ṣ, M *)</span> and <span class="ar long">بَوْنٌ بَعِيدٌ</span> <span class="auth">(T in art. <span class="ar">بون</span>, Ṣ, M,* Mṣb * in art. <span class="ar">بون</span>)</span> <em>Between them two</em> <span class="add">[meaning two men]</span> <em>is a</em> <span class="add">[<em>wide</em>]</span> <em>distance;</em> <span class="auth">(M;)</span> i. e. <em>between their two degrees of rank</em> or <em>dignity,</em> or <em>between the estimations in which they are commonly held:</em> <span class="auth">(Mṣb in art. <span class="ar">بون</span>:)</span> in this case, the latter is the more chaste. <span class="auth">(Ṣ.)</span> You also say, <span class="add">[using <span class="ar">بين</span> to denote <em>An interval of time,</em>]</span> <span class="ar long">لَقِيتُهُ بُعَيْدَاتِ بَيْنٍ</span> <span class="add">[<em>I met him after,</em> or <em>a little after, an interval,</em> or <em>intervals,</em>]</span> when you have met him after a while, and then withheld yourself from him, and then come to him. <span class="auth">(Ṣ, M, Ḳ. <span class="add">[<a href="#baEodu">See also <span class="ar">بَعْدُ</span></a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bayonN_B1">
					<p>Also <em>Union</em> <span class="add">[of companions or friends or lovers]</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> the contr. of the first of the significations mentioned above in this paragraph. <span class="auth">(T, Ṣ, Mṣb.)</span> <span class="add">[Hence <span class="ar long">ذَاتُ البَيْنِ</span> as meaning <em>The state of union</em> or <em>concord</em> or <em>friendship</em> or <em>love subsisting between a people</em> or <em>between two parties;</em> this being likewise the contr. of a signification assigned to the same expression above: whence the phrase, <span class="ar long">إِفْسَادُ ذَاتِ البَيْنِ</span> <span class="auth">(occurring in the Ṣ and Ḳ in art. <span class="ar">ابر</span>, and often elsewhere,)</span> <em>The marring,</em> or <em>disturbance, of the state of union</em> or <em>concord</em>, &amp;c.: and]</span> hence the saying, <span class="ar long">سَعَى فُلَانٌ لِإِصْلَاحِ ذَاتِ البَيْنِ مِنْ عَشِيرَتِهِ</span> <span class="add">[<em>Such a one laboured for the improving of the state of union</em> or <em>concord</em>, &amp;c. <em>of his kinsfolk;</em> but in this instance, the meaning given in the second sentence of this paragraph seems to be more appropriate]</span>. <span class="auth">(Ḥam p. 569.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bayonN_B2">
					<p><span class="ar long">ذَاتُ بَيْنِهِمْ</span> may also be used as meaning <em>The vacant space</em> (<span class="ar">سَاحَة</span>) <em>that is between their houses,</em> or <em>tents.</em> <span class="auth">(Ḥam p. 195.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bayonN_C1">
					<p><span class="ar">بَيْن</span> is also an adverbial noun, <span class="add">[as such written <span class="ar">بَيْنَ</span>,]</span> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> capable of being used as a noun absolutely: <span class="auth">(M, Ḳ:)</span> it relates only to that which has space, as a country; or to that which has some number, either two or more, as two men, and a company of men; and denotes <span class="add">[intervention in]</span> the interval between two things, or the middle, or midst, of two things, <span class="auth">(Er-Rághib, TA,)</span> or the middle of a collective number: <span class="auth">(Ṣ:)</span> <span class="add">[thus it signifies <em>Between,</em> and <em>amidst,</em> and <em>among:</em>]</span> its meaning is <span class="add">[therefore]</span> vague, not apparent unless it is prefixed to two or more <span class="add">[words, or to a word signifying two or more]</span>, or to what supplies the place of such a complement: <span class="auth">(Mṣb:)</span> it must necessarily be prefixed, and may not be otherwise than in the manners just explained: <span class="auth">(Mgh:)</span> <span class="add">[i. e.]</span> it may not be prefixed to any noun but such as denotes more than one, or to a noun that has another conjoined to it by <span class="ar">و</span>, <span class="auth">(M,)</span> not by any other conjunction, <span class="auth">(M, Mṣb,)</span> acc0ord. to the usage commonly obtaining. <span class="auth">(Mṣb.)</span> You say <span class="ar long">بَيْنَ الرَّجُلَيْنِ</span> <span class="add">[<em>Between the two men</em>]</span>: <span class="auth">(Er-Rághib, TA:)</span> and <span class="ar long">المَالُ بَيْنَ القَوْمِ</span> <span class="add">[<em>The property is between the company of men</em>]</span>: <span class="auth">(M, Mṣb, Er-Rághib:*)</span> and <span class="ar long">المَالُ بَيْنَ زَيْدٍ وَعَمْرٍو</span> <span class="add">[<em>The property is between Zeyd and ʼAmr</em>]</span>: and <span class="ar long">هُوَ بَيْنِى وَبَيْنَهُ</span> <span class="add">[<em>He,</em> or <em>it, is between me and him</em>]</span>: <span class="auth">(M:)</span> and <span class="ar long">جَلَسْتُ بَيْنَ القَوْمِ</span> <em>I sat in the middle of</em> <span class="add">[or <em>amidst</em> or <em>among</em>]</span> <em>the company of men:</em> <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar long">بَيْنَكُمَا البَعِيرَ فَخُذَاهُ</span>, with <span class="ar">البعير</span> in the accus. case, <span class="add">[See <em>between you two the camel, therefore take him</em>]</span>, a saying heard by Ks: <span class="auth">(L in art. <span class="ar">عند</span>:)</span> and <span class="ar long">فَسَدَ مَا بَيْنَهُمْ</span> <span class="add">[<em>The state subsisting among them became bad,</em> or <em>marred,</em> or <em>disturbed</em>]</span>: <span class="auth">(Ṣ and Ḳ in art. <span class="ar">ميط</span>:)</span> and <span class="ar long">بَيْنَ الأَيَّامِ</span> <span class="auth">(M and Ḳ in art. <span class="ar">ندر</span>)</span> and <span class="ar long">فِيمَا بَيْنَ الأَيَّامِ</span> <span class="auth">(Ṣ and Mṣb in that art.)</span> <span class="add">[<em>In,</em> or <em>during, the space of</em> (<em>several</em>) <em>days</em>]</span>: and <span class="ar long">عَوَانٌ بَيْنَ ذٰلِكَ</span>, in the Ḳur <span class="add">[ii. 63]</span>, is an ex. of its being prefixed to a single word supplying the place of more than one; <span class="auth">(Mgh, Mṣb;)</span> the meaning being, <em>Of middle age, between that</em> which has been mentioned; namely, the <span class="ar">فَارِض</span> and the <span class="ar">بِكْر</span>. <span class="auth">(Bḍ.)</span> Some allow that two words to the former of which <span class="ar">بَيْنَ</span> is prefixed may be connected by <span class="ar">فَ</span>, citing as an evidence the phrase used by Imra-el-Ḳeys, <span class="ar long">بَيْنَ الدَّخُولِ فَحَوْمَلِ</span> <span class="add">[as though meaning <em>Between Ed-Dakhool and Howmal</em>]</span>: but to this it has been replied that <span class="ar">الدخول</span> is a name applying to several places; so that the phrase <span class="add">[means <em>amidst Ed-Dakhool</em>, &amp;c., and]</span> is similar to the saying, <span class="ar long">المَالُ بَيْنَ القَوْمِ</span> <span class="add">[mentioned above, or <span class="ar long">جَلَسْتُ بَيْنَ القَوْمِ</span>, also mentioned above]</span>. <span class="auth">(Mṣb.)</span> <span class="add">[You say also, <span class="ar long">بَيْنَ أَظْهُرِهِمْ</span>, and <span class="ar long">بَيْنَ ظَهْرَيْهِمْ</span>, &amp;c., meaning <em>In the midst of them.</em> (<a href="index.php?data=17_Z/022_Zhr">See art. <span class="ar">ظهر</span></a>.) And <span class="ar long">بَيْنَ يَدَيْهِ</span>, and <span class="ar long">بَيْنَ يَدَيْهِمْ</span>, meaning <em>Before him,</em> and <em>before them.</em> <span class="ar">بَيْن</span> is also often used absolutely as a noun: thus it is in the Ḳur lxxxvi. 7, <span class="ar long">يَخْرُجُ مِنْ بَيْنِ الصُّلْبِ وَالتَّرَائِبِ</span> <em>Coming forth from between,</em> or <em>amidst, the spine and the breast-bones:</em> and in xxxvi. 8 of the same, <span class="ar long">وَجَعَلْنَا مِنْ بَيْنِ أَيْديهِمْ سَدًّا</span> <em>And we have placed before them</em> <span class="auth">(lit. <em>between their hands</em>)</span> <em>a barrier.</em>]</span> <span class="pb" id="Page_0288"></span>It is said in the Ḳur <span class="add">[vi. 94]</span>, <span class="ar long">لَقَدْ تَقَطَّعَ بَيْنُكُمْ</span>, as some read; or <span class="ar">بَيْنَكُمْ</span>, as others: <span class="auth">(T, Ṣ, M:)</span> the former means <em>Verily your union hath become dissevered:</em> <span class="auth">(AA, T, Ṣ, M:)</span> the latter, <em>that which was between you;</em> (<span class="ar long">مَا بَيْنَكُمْ</span>, Ibn-Mesʼood, T, Ṣ, or <span class="ar long">ٱلَّذِى كَانَ بَيْنَكُمْ</span>, IAạr, T;) or <em>the state wherein ye were, in respect of partnership among you:</em> <span class="auth">(Zj, T:)</span> or <em>the state of circumstances,</em> or <em>the bond,</em> or <em>the love,</em> or <em>affection,</em> <span class="add">[<em>formerly subsisting</em>]</span> <em>among you,</em> or <em>between you;</em> or, accord. to Akh, <span class="ar">بَيْنَكُمْ</span>, though in the accus. case as to the letter, is in the nom. case as to the place, by reason of the verb, and the adverbial termination is retained only because the word is commonly used as an adv. n.: <span class="auth">(M:)</span> AḤát disapproved of the latter reading; but wrongly, because what is suppressed accord. to this reading is implied by what precedes in the same verse. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="bayonN_C2">
					<p><span class="add">[It is often used as a partitive, or distributive; as also <span class="ar long">مَا بَيْنَ</span>: for ex.,]</span> you say, <span class="ar long">هُمْ بَيْنَ حَاذِفٍ وَقَاذِفٍ</span>, <span class="auth">(Ṣ and TA in art. <span class="ar">قذف</span>,)</span> or <span class="ar long">هُمْ مَا بَيْنَ حَاذفٍ وقاذفٍ</span>, <span class="auth">(TA in art. <span class="ar">حذف</span>,)</span> i. e. <span class="add">[<em>They are partly,</em> or <em>in part,</em>]</span> <em>beating with the staff,</em> or <em>stick, and</em> <span class="add">[<em>partly,</em> or <em>in part,</em>]</span> <em>pelting with stones;</em> <span class="add">[or <em>some beating</em>, &amp;c., <em>and the others pelting</em>, &amp;c.]</span> <span class="auth">(Ṣ and TA, both in art. <span class="ar">قذف</span>, and the latter in art. <span class="ar">حذف</span>.)</span> <span class="add">[See also an ex. in a verse cited voce <span class="ar">خَيْطَةٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="bayonN_C3">
					<p><span class="ar long">هٰذَا بَيْنَ بَيْنَ</span> means <em>This</em> <span class="auth">(namely, a thing, Ṣ, or a commodity, Mṣb)</span> <em>is between good and bad:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or <em>of a middling,</em> or <em>middle, sort:</em> <span class="auth">(M:)</span> these two words being two nouns made one, and indecl., with fet-ḥ for their terminations, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> like <span class="ar long">خَمْسَةَ عَشَرَ</span>. <span class="auth">(Mṣb.)</span> <span class="ar long">الهَمْزَةُ المُخَفَّفَةُ</span> <span class="add">[i. e. the hemzeh uttered lightly]</span> is called <span class="ar long">هَمْزَةٌ بَيْنَ بَيْنَ</span>, <span class="auth">(Ṣ, M, Ḳ,*)</span> i. e. <em>A hemzeh that is between the hemzeh and the soft letter whence is its vowel;</em> <span class="auth">(Ṣ, M;)</span> or <span class="ar long">هَمْزَةُ بَيْنِ بَيْنٍ</span>, the first <span class="ar">بين</span> with kesreh but without tenween, and the second with tenween, <span class="auth">(Sharh Shudhoor edh-Dhahab,)</span> <span class="add">[i. e. <em>the hemzeh</em>, &amp;c.:]</span> if it is with fet-ḥ, it is between the hemzeh and the alif, as in <span class="ar">سَاَلَ</span>, <span class="auth">(Ṣ, M,)</span> for <span class="ar">سَأَلَ</span>; <span class="auth">(M;)</span> if with kesr, it is between the hemzeh and the yé, as in <span class="ar">سَيِمَ</span>, <span class="auth">(Ṣ, M,)</span> for <span class="ar">سَئِمَ</span>; <span class="auth">(M;)</span> and if with damm, it is between the hemzeh and the wáw, as in <span class="ar">لَوُمَ</span>, <span class="auth">(Ṣ, M,)</span> for <span class="ar">لَؤُمَ</span>: <span class="auth">(M:)</span> it is never at the beginning of a word, because of its nearness, by reason of feebleness, to the letter that is quiescent, <span class="auth">(Ṣ, M,)</span> though, notwithstanding this, it is really movent: <span class="auth">(Ṣ:)</span> it is thus called because it is weak, <span class="auth">(Sb, Ṣ, M,)</span> not having the power of the hemzeh uttered with its proper sound, nor the clearness of the letter whence is its vowel. <span class="auth">(M.)</span> ʼObeyd Ibn-El-Abras says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَحْمِى حَقِيقَتَنَا وَبَعْضُ</span> *</div> 
						<div class="star">* <span class="ar long">القَوْمِ يَسْقُطُ بَيْنَ بَيْنَا</span> *</div> 
					</blockquote>
					<p>i. e. <span class="add">[<em>Thou defendest what we ought to defend,</em> or <em>our banner,</em> or <em>standard, while some of the people,</em> or <em>company of men,</em>]</span> <em>fall, one after another, in a state of weakness, not regarded as of any account:</em> <span class="auth">(Ṣ:)</span> or it is as though he said, <em>between these and these;</em> like a man who enters between two parties in some affair, and falls, or slips, or commits a mistake, and is not honourably mentioned in relation to it: so says Seer: <span class="auth">(IB, TA:)</span> or <em>between entering into fight and holding back from it;</em> as when one says, Such a one puts forward a foot, and puts back another. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C4</span>
				</div>
				<div class="sense" id="bayonN_C4">
					<p><span class="arrow"><span class="ar">بَيْنَا↓</span></span> and<span class="arrow"><span class="ar">بَيْنَمَا↓</span></span> are of the number of inceptive <span class="ar">حُرُوف</span>: <span class="auth">(M, Ḳ:)</span> this is clear if by <span class="ar">حروف</span> is meant “words:” that they have become particles, no one says: they are still adv. ns.: <span class="auth">(MF, TA:)</span> the former is <span class="ar">بَيْنَ</span> with its <span class="add">[final]</span> fet-ḥah rendered full in sound; and hence the <span class="ar">ا</span>; <span class="auth">(Mughnee in the section next after <a href="#wA">that of <span class="ar">وا</span></a>, and Ḳ;)</span> <span class="add">[i. e.,]</span> it is of the measure <span class="ar">فَعْلَى</span> <span class="add">[or <span class="ar">فَعْلَا</span>]</span> from <span class="ar">البَيْن</span>, the <span class="add">[final]</span> fet-ḥah being rendered full in sound, and so becoming <span class="ar">ا</span>; and the latter is <span class="ar">بَيْنَ</span> with <span class="ar">مَا</span> <span class="add">[restrictive of its government]</span> added to it; and both have the same meaning <span class="add">[of <em>While,</em> or <em>whilst</em>]</span>: <span class="auth">(Ṣ:)</span> or the <span class="ar">ا</span> in the former is the restrictive <span class="ar">ا</span>; or, as some say, it is a portion of the restrictive <span class="ar">ما</span> <span class="add">[in the latter]</span>: <span class="auth">(Mughnee ubi suprà:)</span> and these do not exclude <span class="ar">بَيْنَ</span> from the category of nouns, but only cut it off from being prefixed to another noun: <span class="auth">(MF, TA:)</span> they are substitutes for that to which <span class="ar">بَيْنَ</span> would otherwise be prefixed: <span class="auth">(Mgh:)</span> some say that these two words are adv. ns. of time, denoting a thing's happening suddenly, or unexpectedly; and they are prefixed to a proposition consisting of a verb and an agent, or an inchoative and enunciative; so that they require a complement to complete the meaning. <span class="auth">(TA.)</span> One says, <span class="ar long">بَيْنَا نَحْنُ كَذٰلِكَ إِذْ حَدَثَ كَذَا</span> <span class="add">[<em>While we were in such a state as that, lo,</em> or <em>there,</em> or <em>then, such a thing happened,</em> or <em>came to pass</em>]</span>: <span class="auth">(M, Mgh,* Ḳ:*)</span> and <span class="ar long">بَيْنَمَا نَحْنُ كَذَا</span> <span class="add">[<em>While we were thus</em>]</span>: <span class="auth">(Mgh:)</span> and</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَيْنَا نَحْنُ نَرْقُبُهُ أَتَانَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>While we were looking,</em> or <em>waiting, for him, he came to us</em>]</span>; <span class="auth">(Ṣ, M;)</span> a saying of a poet, cited by Sb; <span class="auth">(M;)</span> the phrase being elliptical; <span class="auth">(Ṣ, M;)</span> meaning <span class="ar long">بَيْنَ أَوْقَاتِ نَحْنُ نَرْقُبُهُ</span>, <span class="auth">(M,)</span> i. e., <span class="ar long">بَيْنَ أَوْقَاتِ رِقْبَتِنَا إِيَّاهُ</span> <span class="add">[<em>between the times of our looking,</em> or <em>waiting, for him</em>]</span>. <span class="auth">(Ṣ, M.)</span> As used to put nouns following <span class="ar">بَيْنَا</span> in the gen. case when <span class="ar">بَيْنَ</span> might properly supply its place; as in the saying <span class="auth">(of Aboo-Dhu-eyb, which he thus recited, with kesr, Ṣ)</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَيْنَا تَعَنُّقِهِ الكُمَاةَ وَرَوْغِهِ</span> *</div> 
						<div class="star">* <span class="ar long">يَوْمًا أُتِيحَ لَهُ جَرِىْءٌ سَلْفَعُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Amid his embracing the courageous armed men, and his guileful eluding, one day a bold, daring man was appointed for him,</em> to slay him]</span>: <span class="auth">(Ṣ, Ḳ:)</span> in <span class="add">[some copies of]</span> the Ḳ, <span class="ar">تَعَنُّفِهِ</span>; but in the Deewán <span class="add">[of the Hudhalees]</span>, <span class="ar">تعنّقه</span>: <span class="add">[in the Mughnee, ubi suprà, <span class="ar">تَعَانُقِهِ</span>:]</span> the meaning is <span class="ar long">بَيْنَ تَعَانُقِهِ</span>; the <span class="ar">ا</span> being added to give fulness to the sound of the <span class="add">[final]</span> vowel: <span class="auth">(TA:)</span> Aṣ used to say that the <span class="ar">ا</span> is here redundant: <span class="auth">(Skr, TA:)</span> others put the nouns following both <span class="ar">بَيْنَا</span> and <span class="ar">بَيْنَمَا</span> in the nom. case, as the inchoative and enunciative. <span class="auth">(Skr, Ṣ, Ḳ.)</span> Mbr says that when the noun following <span class="ar">بينا</span> is a real subst., it is put in the nom. case as an inchoative; but when it is an inf. n., or a noun of the inf. kind, it is put in the gen., and <span class="ar">بينا</span> in this instance has the meaning of <span class="ar">بَيْنَ</span>: and Aḥmad Ibn-Yaḥyà says the like, but some persons of chaste speech treat the latter kind of noun like the former: after <span class="ar">بينما</span>, however, each kind of noun must be in the nom. case. <span class="auth">(AA, T.)</span> <span class="add">[<a href="index.php?data=01_A/044_Ac">See an ex. in a verse cited towards the end of art. <span class="ar">اذ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayonaA">
				<h3 class="entry"><span class="ar">بَيْنَا</span></h3>
				<div class="sense" id="bayonaA_A1">
					<p><span class="ar">بَيْنَا</span> <a href="#baYonN">see <span class="ar">بَيْنٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bayonamaA">
				<h3 class="entry"><span class="ar">بَيْنَمَا</span></h3>
				<div class="sense" id="bayonamaA_A1">
					<p><span class="ar">بَيْنَمَا</span> <a href="#baYonN">see <span class="ar">بَيْنٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="biynN">
				<h3 class="entry"><span class="ar">بِينٌ</span></h3>
				<div class="sense" id="biynN_A1">
					<p><span class="ar">بِينٌ</span> <em>A separation,</em> or <em>division,</em> <span class="auth">(T, M, Ḳ,)</span> <em>between two things,</em> <span class="auth">(T,)</span> or <em>between two lands;</em> <span class="auth">(M, Ḳ;)</span> <em>as when there is a rugged place, with sands near it, and between the two is a tract neither rugged nor plain:</em> <span class="auth">(T:)</span> <em>an elevation in rugged ground:</em> <span class="auth">(M, Ḳ:)</span> the <em>extent to which the eye reaches,</em> <span class="auth">(T, M, Ḳ,)</span> of a road, <span class="auth">(T,)</span> or of land: <span class="auth">(M:)</span> <em>a piece of land extending as far as the eye reaches:</em> <span class="auth">(T, Ṣ:)</span> and <em>a region, tract,</em> or <em>quarter:</em> <span class="auth">(AA, T, M, Ḳ:)</span> pl. <span class="ar">بُيُونٌ</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayaAnN">
				<h3 class="entry"><span class="ar">بَيَانٌ</span></h3>
				<div class="sense" id="bayaAnN_A1">
					<p><span class="ar">بَيَانٌ</span> <a href="#byn_1">is originally the inf. n. of <span class="ar">بَانَ</span></a> as syn. with <span class="ar">تَبَيَّنَ</span>, and so signifies The <em>being</em> <span class="add">[<em>distinct</em> or]</span> <em>apparent</em>, &amp;c.; <span class="auth">(Kull;)</span> or it is a subst. in this sense: <span class="auth">(Mṣb:)</span> or a subst. from <span class="ar">بَيَّنَ</span>, <span class="add">[and so signifies the <em>making distinct</em> or <em>apparent</em>, &amp;c.,]</span> being like <span class="ar">سَلَامٌ</span> and <span class="ar">كَلَامٌ</span> from <span class="ar">سَلَّمَ</span> and <span class="ar">كَلَّمَ</span>. <span class="auth">(Kull.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayaAnN_A2">
					<p>Hence, conventionally, <span class="auth">(Kull,)</span> The <em>means by which one makes</em> a thing <span class="add">[<em>distinct,</em>]</span> <em>apparent, manifest, evident, clear, plain,</em> or <em>perspicuous:</em> <span class="auth">(Ṣ, Er-Rághib, TA, Kull:)</span> this is of two kinds: one is <span class="add">[<em>a circumstantial indication</em> or <em>evidence;</em> or]</span> <em>a thing indicating,</em> or <em>giving evidence of, a circumstance,</em> or <em>state, that is a result,</em> or <em>an effect, of a quality</em> or <em>an attribute:</em> the other is <em>a verbal indication</em> or <em>evidence, either spoken or written:</em> <span class="add">[<a href="#bayBinapN">see also <span class="ar">بَيِّنَةٌ</span></a>:]</span> it is also applied to <em>language that discovers and shows the meaning that is intended:</em> and <em>an explanation of confused and vague language:</em> <span class="auth">(Er-Rághib, TA:)</span> or the <em>eduction</em> of a thing <em>from a state of dubiousness to a state of clearness:</em> or <em>making the meaning apparent to the mind so that it becomes distinct from other meanings and from what might be confounded with it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayaAnN_A3">
					<p>Also <em>Perspicuity, clearness, distinctness, chasteness,</em> or <em>eloquence, of speech</em> or <em>language:</em> <span class="auth">(T, Ṣ:)</span> or simply <em>perspicuity thereof:</em> <span class="auth">(Ḥar p. 2:)</span> or <em>perspicuity of speech with quickness,</em> or <em>sharpness, of intellect:</em> <span class="auth">(M, Ḳ:)</span> or <em>perspicuous,</em> or <em>chaste,</em> or <em>eloquent, speech, declaring,</em> or <em>telling plainly, what is in the mind:</em> <span class="auth">(Ksh, TA:)</span> or the <em>showing of the intent,</em> or <em>meaning, with the most eloquent expression:</em> it is an effect of understanding, and of sharpness, or quickness, of mind, with perspicuity, or chasteness, or eloquence, of speech: <span class="auth">(Nh, TA:)</span> or <em>a faculty,</em> or <em>principles,</em> <span class="add">[<em>or a science,</em>]</span> <em>whereby one knows how to express</em> <span class="add">[<em>with perspicuity of diction</em>]</span> <em>one meaning in various forms:</em> <span class="auth">(Kull:)</span> <span class="add">[some of the Arabs restrict the science of <span class="ar">البيان</span> to <em>what concerns comparisons and tropes and metonymies;</em> which last the Arabian rhetoricians distinguish from tropes: and some make it to include <em>rhetoric</em> altogether:]</span> Esh-Shereeshee says, in his Expos. of the Maká- mát <span class="add">[of El-Ḥareeree]</span> that the difference between <span class="ar">بَيَانٌ</span> and<span class="arrow"><span class="ar">تِبْيَانٌ↓</span></span> is this: that the former denotes <em>perspicuity of meaning;</em> and the latter, the <em>making the meaning to be understood;</em> <span class="pb" id="Page_0289"></span>and the former is to another person, and the latter to oneself; but sometimes the latter is used in the sense of the former: <span class="auth">(TA:)</span> or the former is the act of the tongue, and the latter is the act of the mind: <span class="auth">(Ḥar p. 2:)</span> or the former concerns the verbal expression, and the latter concerns the meaning. <span class="auth">(Kull.)</span> It is said in a trad., <span class="ar long">إِنَّ مِنَ البَيَانِ سِحْرًا</span> <span class="auth">(Ṣ)</span> or <span class="ar">لَسِحْرًا</span> <span class="auth">(TA)</span> <span class="add">[<em>Verily there is a kind of eloquence that is enchantment:</em> <a href="index.php?data=12_s/047_sHr">see this explained in art. <span class="ar">سحر</span></a>]</span>. The saying in the Ḳur <span class="add">[lv. 2 and 3]</span>, <span class="ar long">خَلَقَ ٱلْإِنْسَانَ عَلَّمَهُ ٱلْبَيَانَ</span> means <em>He hath created the Prophet: He hath taught him the Ḳur-án wherein is the manifestation of everything</em> <span class="add">[<em>needful to be known</em>]</span>: or <em>He hath created Adam,</em> or <em>man</em> as meaning all mankind: <em>He hath</em> <span class="add">[<em>taught him speech, and so</em>]</span> <em>made him to discriminate, and thus to be distinguished from all</em> <span class="add">[<em>other</em>]</span> <em>animals:</em><span class="auth">(Zj, T:)</span> or <em>He hath taught him that whereby he is distinguished from other animals,</em> namely, <em>the declaration of what is in the mind, and the making others to understand what he has perceived,</em> for the reception of inspiration, and the becoming acquainted with the truth, and the learning of the law. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bayaAnN_A4">
					<p>It is also applied to <em>Verbosity, and the going deep,</em> or <em>being extravagant, in speech, and affecting to be perspicuous,</em> or <em>chaste, therein,</em> or <em>eloquent, and pretending to excel others therein;</em> or some <span class="ar">بيان</span> is thus termed; and is blamed in a trad., as a kind of hypocrisy; as though it were a sort of self-conceit and pride. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayuwnN">
				<h3 class="entry"><span class="ar">بَيُونٌ</span></h3>
				<div class="sense" id="bayuwnN_A1">
					<p><span class="ar long">بِئْرٌ بَيُونٌ</span> <em>A well of which the rope does not strike against the sides, because its interior is straight:</em> or <em>that is wide in the upper part, and narrow in the lower:</em> or <em>in which the drawer of water makes the rope to be aloof from its sides, because of its crookedness:</em> <span class="auth">(T:)</span> or <em>deep and wide;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>because the ropes are wide apart from its sides;</em> <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">بَائِنَةٌ↓</span></span>: <span class="auth">(Ṣ, TA:)</span> or <em>that is wide between the two</em> <span class="add">[<em>opposite</em>]</span> <em>sides:</em> <span class="auth">(M:)</span> pl. <span class="add">[regularly of the latter epithet]</span> <span class="ar">بَوَائِنُ</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBinN">
				<h3 class="entry"><span class="ar">بَيِّنٌ</span></h3>
				<div class="sense" id="bayBinN_A1">
					<p><span class="ar">بَيِّنٌ</span> <span class="add">[<em>Distinct, as though separate from others;</em> and thus,]</span> <em>apparent, manifest, evident, clear, plain,</em> or <em>perspicuous;</em> <span class="auth">(T, Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَائِنٌ↓</span></span> <span class="auth">(T)</span> and<span class="arrow"><span class="ar">مُبِينٌ↓</span></span>: <span class="auth">(T, Ṣ:)</span> pl. <span class="add">[of mult.]</span> <span class="ar">أَبْيِنَآءُ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="add">[of pauc.]</span> <span class="ar">بَيِنَةٌ</span>. <span class="auth">(Ḳ.)</span> Hence,<span class="arrow"><span class="ar long">الكِتَابُ المُبِينٌ↓</span></span> <span class="add">[as applied to the Ḳur, q. v. in xii. 1, &amp;c.,]</span> <em>The clear, plain,</em> or <em>perspicuous, book</em> or <em>writing</em> or <em>scripture:</em> or, as some say, this means <em>the book</em>, &amp;c. <em>that makes manifest all that is required</em> <span class="add">[<em>to be known</em>]</span>: <span class="auth">(T:)</span> or, <em>of which the goodness and the blessing are made manifest:</em> or, <em>that makes manifest the truth as distinguished from falsity, and what is lawful as distinguished from what is unlawful, and that the prophetic office of Moḥammad is true, and so are the narratives relating to the prophets:</em> <span class="auth">(Zj, T:)</span> or, <em>that makes manifest the right paths as distinguished from the wrong.</em> <span class="auth">(M, TA.)</span> And <span class="ar long">كَلَامٌ بَيِّنٌ</span> <em>Perspicuous, clear, distinct, chaste,</em> or <em>eloquent, language.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيِّنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayBinN_A2">
					<p>A man, or thing, <em>bearing evidence</em> of a quality, &amp;c. that he, or it, possesses. <span class="auth">(Ṣ and Ḳ and other Lexicons passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَيِّنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayBinN_A3">
					<p>A man <span class="auth">(M)</span> <em>perspicuous,</em> or <em>clear,</em> or <em>distinct, in speech</em> or <em>language;</em> or <em>chaste therein;</em> or <em>eloquent;</em> <span class="auth">(ISh, T, M, Ḳ;)</span> <em>fluent, elegant, and elevated, in speech, and having little hesitation therein:</em> <span class="auth">(ISh, T:)</span> pl. <span class="ar">أَبْيِنَآءُ</span> <span class="auth">(T, M, Ḳ)</span> and <span class="ar">بُيَنَآءُ</span> and <span class="add">[of pauc.]</span> <span class="ar">أَبْيَانٌ</span>: <span class="auth">(Lḥ, M, Ḳ:)</span> the second of these pls. is anomalous: the last is formed by likening <span class="ar">فَعِيلٌ</span> to <span class="ar">فَاعِلٌ</span>: <span class="add">[for <span class="ar">بَيِّنٌ</span> is a contraction of <span class="ar">بَيِينٌ</span>:]</span> but the pl. most agreeable with analogy is <span class="ar">بَيِّنُونَ</span>: so says Sb. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBinapN">
				<h3 class="entry"><span class="ar">بَيِّنَةٌ</span></h3>
				<div class="sense" id="bayBinapN_A1">
					<p><span class="ar">بَيِّنَةٌ</span> <em>An evidence, an indication, a demonstration, a proof, a voucher,</em> or <em>an argument,</em> <span class="auth">(Mgh, TA,)</span> <em>such as is manifest,</em> or. <em>clear, whether intellectual or perceived by sense;</em> <span class="auth">(TA;)</span> <span class="add">[originally <span class="ar">بَيِينَةٌ</span>,]</span> of the measure <span class="ar">فَعِيلَةٌ</span>, from <span class="ar">بَيْنُونَةٌ</span>, <span class="add">[<a href="#byn_1">see 1</a>, first sentence,]</span> and <span class="ar">بَيَانٌ</span> <span class="add">[q. v.]</span>: <span class="auth">(Mgh:)</span> and the <em>testimony of a witness:</em> pl. <span class="ar">بَيِّنَاتٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYinN">
				<h3 class="entry"><span class="ar">بَائِنٌ</span></h3>
				<div class="sense" id="baAYinN_A1">
					<p><span class="ar">بَائِنٌ</span> <em>In a state of separation</em> or <em>disunion;</em> or <em>separated, severed, disunited,</em> or <em>cut off;</em> <span class="auth">(M,* Mṣb;)</span> as also<span class="arrow"><span class="ar">أَبْيَنُ↓</span></span>, occurring in a verse cited above, voce <span class="ar">بَيِّنَ</span>. <span class="add">[Hence,]</span> <span class="ar long">اِمْرَأَةٌ بَائِنٌ</span> <em>A woman separated from her husband by divorce;</em> <span class="auth">(M, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">مُبَانَةٌ↓</span></span>: the former without <span class="ar">ة</span>: <span class="auth">(Mṣb:)</span> like <span class="ar">طَالِقٌ</span> and <span class="ar">حَائِضٌ</span>: you say <span class="add">[to a wife]</span> <span class="ar long">أَنْتِ بَائِنٌ</span> <span class="add">[<em>Thou art separated</em> from me <em>by divorce.</em>]</span> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAYinN_A2">
					<p><span class="ar long">طَلَاقٌ بَائِنٌ</span> is a tropical phrase; and so is <span class="ar long">طَلْقَةٌ بَائِنَةٌ</span>; <span class="auth">(Mgh;)</span> <span class="add">[signifying the same as]</span> <span class="ar long">تَطْلِيقَةٌ بَائِنَةٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> ‡ <em>A divorce that is</em> <span class="add">[<em>as it were</em>]</span> <em>cut off; i. q.</em> <span class="arrow"><span class="ar">مُبَانَةٌ↓</span></span> <span class="add">[in the second and third of these phrases, and<span class="arrow"><span class="ar">مُبَانٌ↓</span></span> in the first]</span>: <span class="auth">(ISk, Mṣb:)</span> <span class="ar">بائنة</span> being here used in the sense of a pass. part. n.: <span class="auth">(Ṣ, Ṣgh, Mṣb:)</span> or it <span class="add">[is a possessive epithet, and thus]</span> means <em>having separation:</em> this kind of divorce is <em>one in the case of which the man cannot take back the woman unless by a new contract;</em> <span class="auth">(TA;)</span> <em>nor without her consent.</em> <span class="auth">(MF in art. <span class="ar">بت</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAYinN_A3">
					<p><span class="ar long">قَوْسٌ بَائِنَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">بَائِنٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>A bow that is widely separate from its string:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> <em>contr. of</em> <span class="ar">بَانِيَةٌ</span>; <span class="auth">(Ṣ, M;)</span> this signifying one that is so near to its string as almost to stick to it: <span class="auth">(Ṣ:)</span> each of these denotes what is a fault. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAYinN_A4">
					<p><span class="ar long">بِئْرٌ بَائِنَةٌ</span>: <a href="#bayuwnN">see <span class="ar">بَيُونٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAYinN_A5">
					<p><span class="ar long">نَخْلَةٌ بَائِنَةٌ</span> <em>A palm-tree of which the racemes have come forth from the spathes, and of which the fruit-stalks have grown long.</em> <span class="auth">(AḤn, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAYinN_A6">
					<p><span class="ar">البَائِنُ</span> also signifies <em>He who comes to the milch beast</em> <span class="add">[meaning <em>the she-camel, when she is to be milked,</em>]</span> <em>from her left side;</em> <span class="auth">(Ṣ, Ḳ;)</span> and <span class="ar">المُعَلِّى</span>, he who comes to her from her right side: <span class="auth">(Ṣ:)</span> or the former, <em>he who stands on the right of the she-camel when she is milked, and holds the milking-vessel, and raises it to the milker, who stands on her left, and is called</em> <span class="ar">المُسْتَعْلِى</span>: <span class="auth">(T:)</span> two persons are engaged in milking the she-camel; one of them holds the milking-vessel on the right side, and the other milks on the left side; and the milker is called <span class="ar">المُسْتَعْلِى</span> and <span class="ar">المُعَلِّى</span>; and the holder, <span class="ar">البائن</span>: <span class="auth">(M:)</span> pl. <span class="ar">بُيَّنٌ</span>. <span class="auth">(T.)</span> It is said in a prov., <span class="ar long">اِسْتُ البَائِنِ أَعْرَفُ</span>, or, as some say, <span class="ar">أَعْلَمُ</span>; meaning † <em>He who has superintended an affair, and exercised himself diligently in the management thereof, is better acquainted with it than he who has not done this.</em> <span class="auth">(T. <span class="add">[See Freytag's Arab. Prov. i. 606.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baAYinN_A7">
					<p><span class="ar long">طَوِيلٌ بَائِنٌ</span> <em>Excessively tall, far above the stature of tall men.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">بَائِنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAYinN_B1">
					<p><a href="#bayBinN">See also <span class="ar">بَيِّنٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaAYinapa">
				<h3 class="entry"><span class="ar">البَائِنَةَ</span></h3>
				<div class="sense" id="AlbaAYinapa_A1">
					<p><span class="ar long">طَلَبَ إِلَى أَبَوَيْهِ البَائِنَةَ</span> <em>He asked,</em> or <em>begged, of his two parents, the separation of himself from them, by</em> <span class="add">[<em>their giving him</em>]</span> <em>property,</em> <span class="auth">(AZ, T, M,)</span> <em>to be his alone.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboyanu">
				<h3 class="entry"><span class="ar">أَبْيَنُ</span></h3>
				<div class="sense" id="Oaboyanu_A1">
					<p><span class="ar">أَبْيَنُ</span>: <a href="#baAyinN">see <span class="ar">بَائِنٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">أَبْيَنُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oaboyanu_B1">
					<p><span class="ar long">فُلَانٌ أَبْيَنُ مِنْ فُلَانٍ</span> <em>Such a one is more perspicuous, clear, distinct, chaste,</em> or <em>eloquent, in speech</em> or <em>language, than such a one.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiboyaAnN">
				<h3 class="entry"><span class="ar">تِبْيَانٌ</span></h3>
				<div class="sense" id="tiboyaAnN_A1">
					<p><span class="ar">تِبْيَانٌ</span> an anomalous inf. n. <span class="auth">(T, Ṣ, Ḳ)</span> of 2, q. v.: <span class="auth">(T:)</span> or a subst. used as an inf. n.; <span class="auth">(MF, TA;)</span> i. e., a subst. from 2. <span class="auth">(Sb, M, TA.)</span> <a href="#bayaAnN">See <span class="ar">بَيَانٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubaAnN">
				<h3 class="entry"><span class="ar">مُبَانٌ</span> / <span class="ar">مُبَانَةٌ</span></h3>
				<div class="sense" id="mubaAnN_A1">
					<p><span class="ar">مُبَانٌ</span>; and its fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُبَانَةٌ</span>}</span></add>: <a href="#baAyinN">see <span class="ar">بَائِنٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubiynN">
				<h3 class="entry"><span class="ar">مُبِينٌ</span></h3>
				<div class="sense" id="mubiynN_A1">
					<p><span class="ar">مُبِينٌ</span> <em>Separating, severing, disuniting,</em> or <em>cutting off;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also <span class="ar">مُبْيِنٌ</span>, like <span class="ar">مُحْسِنٌ</span>: <span class="auth">(Ḳ:)</span> but <span class="add">[the right reading in the Ḳ may be <span class="ar long">وَمُبِينٌ كَمُحْسِنٍ</span>, meaning “and <span class="ar">مُبِينٌ</span> is like <span class="ar">مُحْسِنٌ</span>:“ if not,]</span> <span class="ar">مُبْيِنٌ</span> is a mistake. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بين</span> - Entry: <span class="ar">مُبِينٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="mubiynN_B1">
					<p><a href="#bayBinN">See also <span class="ar">بَيِّنٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabaAyinu">
				<h3 class="entry"><span class="ar">مَبَايِنُ</span></h3>
				<div class="sense" id="mabaAyinu_A1">
					<p><span class="ar long">مَبَايِنُ الحَقِّ</span> <span class="add">[in which the former word is app. <a href="#mubiynapN">pl. of <span class="ar">مُبِينَةٌ</span></a>]</span> signifies <em>The things that make the truth to be apparent, manifest, evident, clear,</em> or <em>plain;</em> or <em>the means of making it so;</em> syn. <span class="ar">مَوَاضِحُهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0285.pdf" target="pdf">
							<span>Lanes Lexicon Page 285</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0286.pdf" target="pdf">
							<span>Lanes Lexicon Page 286</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0287.pdf" target="pdf">
							<span>Lanes Lexicon Page 287</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0288.pdf" target="pdf">
							<span>Lanes Lexicon Page 288</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0289.pdf" target="pdf">
							<span>Lanes Lexicon Page 289</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
