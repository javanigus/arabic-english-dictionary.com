<article class="root" id="Root_byb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/228_be">بى</a></span>
				<span class="ar">بيب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/230_byt">بيت</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Albiyabo">
				<h3 class="entry"><span class="ar">البِيَبْ</span></h3>
				<div class="sense" id="Albiyabo_A1">
					<p><span class="ar">البِيَبْ</span> <a href="#OabN">see <span class="ar">أَبٌ</span></a>, <a href="index.php?data=01_A/011_Abw">in art. <span class="ar">ابو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0279.pdf" target="pdf">
							<span>Lanes Lexicon Page 279</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
