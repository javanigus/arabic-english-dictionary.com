<article class="root" id="Root_br">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/056_bcw">بذو</a></span>
				<span class="ar">بر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/058_brO">برأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="br_1">
				<h3 class="entry">1. ⇒ <span class="ar">برّ</span></h3>
				<div class="sense" id="br_1_A1">
					<p><span class="ar">بَرَّ</span>, <span class="add">[first pers. <span class="ar">بَرِرْتُ</span>,]</span> aor. <span class="ar">يَبَرُّ</span>, <span class="auth">(T, M, Mṣb,)</span> inf. n. <span class="ar">بِرٌّ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> <em>He was pious</em> <span class="add">[<em>towards his father</em> or <em>parents,</em> and ‡ <em>towards God;</em> <span class="auth">(see the explanations of the verb as used transitively;)</span> and <em>was kind,</em> or <em>good and affectionate and gentle in behaviour, towards his kindred;</em> and <em>kind,</em> or <em>good, in his dealings with strangers</em>]</span>: <span class="auth">(Mṣb:)</span> <em>he was good, just, righteous, virtuous,</em> or <em>honest:</em> <span class="auth">(T, Mṣb:)</span> <span class="add">[or <em>he was amply, largely,</em> or <em>extensively, good</em> or <em>beneficent:</em>]</span> and <em>he was true,</em> or <em>veracious.</em> <span class="auth">(M, Mṣb, Ḳ.)</span> <span class="add">[Authorities differ as to the primary signification of this verb, and as to the subordinate meanings: <a href="#birBN">see <span class="ar">بِرٌّ</span> below</a>.]</span> You say also, <span class="ar long">بَرَّ فِى قَوْلِهِ</span>, <span class="auth">(Mṣb, TA,)</span> and <span class="ar long">فِى يَمِينِهِ</span>, <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> first pers. <span class="ar">بَرِرْتُ</span> <span class="auth">(T, A, Mgh, Ḳ)</span> and <span class="ar">بَرَرْتُ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">يَبَرُّ</span> <span class="auth">(M, Mṣb)</span> and <span class="ar">يَبِرٌّ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">بِرٌّ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">بَرٌّ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">بُرُورٌ</span>, <span class="auth">(Mṣb,)</span> <em>He was true,</em> or <em>veracious,</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, TA,)</span> <em>in his saying,</em> <span class="auth">(Mṣb, TA,)</span> and <em>in his oath.</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="br_1_A2">
					<p><span class="ar long">بَرَّ عَمَلَهُ</span>, and <span class="ar">بُرَّ</span>, inf. n. <span class="ar">بِرٌّ</span> and <span class="ar">بُرُورٌ</span>; and<span class="arrow"><span class="ar">أَبَرَّ↓</span></span>; <span class="add">[<em>His deed,</em> or <em>work, was,</em> or <em>proved, good;</em> or <em>was well,</em> or <em>sinlessly, performed;</em>]</span> all signify the same. <span class="auth">(M.)</span> And <span class="ar long">بُرَّ العَمَلُ</span>, i. e. <span class="ar">الحَجُّ</span>, a form of benediction, said to a person come from pilgrimage, <em>May the deed,</em> or <em>work,</em> i. e. the pilgrimage, <em>have been sinlessly performed.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَرَّ حَجُّهُ</span>, <span class="auth">(T, Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">يَبَرُّ</span>, <span class="auth">(T,)</span> inf. n. <span class="ar">بِرٌّ</span> <span class="auth">(Ṣ, Mṣb,)</span> or <span class="ar">بُرُورٌ</span>; <span class="auth">(T;)</span> and <span class="ar long">بُرَّ حَجُّهُ</span>, <span class="auth">(Fr, T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">يُبَرُّ</span>, inf. n. <span class="ar">بِرٌّ</span>; <span class="auth">(T;)</span> <em>His pilgrimage was sinlessly performed:</em> <span class="auth">(Sh, T:)</span> or <em>was characterized by the giving of food, and by sweetness of speech;</em> as explained by Moḥammad himself: <em>was accepted: was rewarded.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="br_1_A3">
					<p><span class="ar">بَرَّ</span>, <span class="auth">(A, Mṣb, Ḳ,)</span> aor. <span class="ar">يَبَرُّ</span> <span class="auth">(T, M, Ḳ)</span> and <span class="ar">يَبِرُّ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بِرٌّ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">بَرٌّ</span> and <span class="ar">بُرُورٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>It</em> <span class="auth">(a saying, Mṣb, and an oath, T, A, M, Mṣb, Ḳ)</span> <em>was,</em> or <em>proved, true.</em> <span class="auth">(M, A,* Mṣb,* Ḳ,* TA.)</span> <span class="add">[<a href="#OaliyBapN">See an ex. voce <span class="ar">أَلِيَّةٌ</span></a>, <a href="index.php?data=01_A/126_Alw">in art. <span class="ar">الو</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="br_1_A4">
					<p><span class="ar long">بَرَّتْ بِى سِلْعَتُهُ</span>, inf. n. <span class="ar">بِرٌّ</span>, ‡ <em>His commodity,</em> or <em>article of merchandise, was easy of sale to me,</em> <span class="auth">(Aboo-Saʼeed, T, A,*)</span> <em>and procured me gain:</em> <span class="auth">(A:)</span> originally meaning <em>it recompensed me,</em> by its high price, for my care of it. <span class="auth">(T.)</span> <span class="add">[<a href="#br_1_B1">See also <span class="ar">بَرَّهُ</span>, below</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="br_1_B1">
					<p><span class="ar long">بَرَّ وَالِدَهُ</span>, <span class="auth">(M,)</span> <span class="add">[and app. <span class="ar">بِوَالِدِهِ</span>, (<a href="#barBN">see <span class="ar">بَرٌّ</span></a>,)]</span> first pers. <span class="ar">بَرِرْتُ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">بَرَرْتُ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">يَبَرُّ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">يَبِرُّ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">بِرٌّ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">مَبَرَّةٌ</span> <span class="auth">(Ṣ, Ḳ, Mṣb *)</span> and <span class="ar">بُرُورٌ</span>, <span class="auth">(Mṣb,)</span> <em>He treated,</em> or <em>behaved towards, his father with filial piety, duty,</em> or <em>obedience;</em> <span class="auth">(TA;)</span> or <em>with ample obedience;</em> <span class="auth">(B;)</span> the inf. ns. signifying the <em>contr. of</em> <span class="ar">عُقُوقٌ</span>: <span class="auth">(Ṣ, M, A, Ḳ:)</span> <em>he treated,</em> or <em>behaved towards, his father with good obedience, and with gentleness,</em> or <em>courtesy, striving to do the things that were pleasing to him, and to avoid what were displeasing to him.</em> <span class="auth">(Mṣb.)</span> And <span class="add">[hence, app., for accord. to the A it is tropical.]</span> <span class="ar long">بَرَّ خَالِقَهُ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">رَبَّهُ</span>, <span class="auth">(A,)</span> aor. <span class="ar">يَبَرُّ</span>, <span class="auth">(Ṣ, A,)</span> inf. n. <span class="ar">بِرٌّ</span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> and<span class="arrow"><span class="ar">تبرّرهُ↓</span></span>; <span class="auth">(Ṣ, Ḳ;*)</span> ‡ <em>He obeyed his Creator,</em> or <em>his Lord;</em> <span class="auth">(Ṣ, M,* A, Ḳ;*)</span> <span class="add">[<em>was pious towards Him;</em>]</span> <em>served Him; rendered religious service to Him:</em> <span class="auth">(TA:)</span> or <em>rendered Him ample obedience:</em> the obedience here meant is of two kinds; namely, that of belief and that of works; and both these kinds are meant by <span class="ar">البِرّ</span> in the Ḳur ii. 172. <span class="auth">(B.)</span> <span class="add">[And app. <span class="ar long">بَرَّتْ وَلَدَهَا</span>, or <span class="ar">بِوَلَدِهَا</span>, <em>She behaved with maternal affection towards her child,</em> or <em>offspring.</em> (<a href="#barBN">See <span class="ar">بَرٌّ</span></a>.)]</span> And <span class="ar">بَرَّهُ</span>, <span class="auth">(M,)</span> and <span class="ar long">بَرَّ رَحِمَهُ</span>, <span class="auth">(T,)</span> first pers. <span class="ar">بَرِرْتُ</span>, <span class="auth">(T, M,)</span> inf. n. <span class="ar">بِرٌّ</span>, <span class="auth">(T, M, Ḳ,)</span> <em>He behaved towards him,</em> and <em>towards his kindred,</em> or <em>relations, with kindness,</em> or <em>goodness and affection and gentleness, and regard for his,</em> or <em>their, circumstances;</em> syn. <span class="ar">وَصَلَهُ</span> <span class="add">[and <span class="ar">وَصَلَهُمْ</span>]</span>: <span class="auth">(T, M, Ḳ:)</span> such is said to be the signification of the verb as use in the Ḳur lx. 8. <span class="auth">(M, B, TA. <span class="add">[<a href="#br_3">See also 3</a>.]</span>)</span> And <span class="ar long">اَللّٰهُ يَبَرُّ عِبَادَهُ</span> † <em>God is merciful to his servants:</em> <span class="auth">(M, TA:)</span> or <span class="ar">بَرَّهُ</span>, inf. n. <span class="ar">بِرٌّ</span>, said of God, means <em>He recompensed him,</em> or <em>rewarded him, for his obedience.</em> <span class="auth">(B, TA.)</span> <span class="add">[<span class="ar long">بَرَّهُ بِكَذَا</span> <span class="auth">(occurring in the Ṣ and Ḳ in explanation of <span class="ar long">أَلْطَفَهُ بِكَذَا</span>)</span> may be rendered <em>He showed kindness,</em>, &amp;c., <em>to him by such a thing,</em> or <em>such an action,</em>, &amp;c.: and also <em>he presented him with such a thing;</em> like <span class="ar long">وَصَلَهُ بِكَذَا</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="br_1_B2">
					<p><span class="ar long">بَرَّ ٱللّٰهُ حَجَّهُ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> aor. <span class="ar">يَبَرُّ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بِرٌّ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بُرُورٌ</span>, <span class="auth">(Mṣb,)</span> <em>God accepted his pilgrimage;</em> <span class="auth">(Ṣ, Mṣb;)</span> as also<span class="arrow"><span class="ar">ابرّهُ↓</span></span>: <span class="auth">(T, Ṣ, M, Mṣb:)</span> the latter alone is allowed by Fr: <span class="auth">(M, TA:)</span> <span class="add">[though <span class="ar long">بُرَّ حَجُّهُ</span> and <span class="ar">عَمَلُهُ</span>, mentioned above, are well known; as is the pass. part. n. <span class="ar">مَبْرُورٌ</span>, which see below:]</span> and one says, <span class="add">[in like manner,]</span><span class="arrow"><span class="ar long">ابرّ↓ ٱللّٰهُ عَمَلُهُ</span></span> <span class="add">[<em>God accepted his deed,</em> or <em>work, as good; approved it</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="br_1_B3">
					<p><a href="#br_4">See also 4</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="br_1_C1">
					<p><span class="ar">بَرَّ</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">بِرٌّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He drove</em> sheep or goats: <span class="auth">(IAạr, Ṣ, Ḳ:)</span> or <em>he called</em> them. <span class="auth">(Yoo.)</span> <span class="add">[<a href="#birBN">See also <span class="ar">بِرٌّ</span> below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="br_3">
				<h3 class="entry">3. ⇒ <span class="ar">بارّ</span></h3>
				<div class="sense" id="br_3_A1">
					<p><span class="ar">بارّهُ</span>, inf. n. <span class="ar">مُبَارَّةٌ</span>, <em>He behaved towards him with kindness,</em> or <em>goodness and affection and gentleness, and regard for his circumstances;</em> or <em>he did so, experiencing from him the same behaviour;</em> syn. of the inf. n. <span class="ar">مُلَاطَفَةٌ</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">لطف</span>: but only the inf. n. is there mentioned. <span class="add">[<a href="#br_1">See also 1</a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="br_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرّ</span></h3>
				<div class="sense" id="br_4_A1">
					<p><span class="ar long">ابرّ عَمَلُهُ</span>: <a href="#br_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="br_4_B1">
					<p><span class="ar long">ابرّ حَجَّهُ</span>, and <span class="ar">عَمَلَهُ</span>: <a href="#br_1">see 1</a>, near the end of the paragraph.</p>
				</div>
				<span class="pb" id="Page_0176"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="br_4_B2">
					<p><span class="ar long">ابرّ القَوْلَ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">اليَمِينَ</span>, <span class="auth">(T, M, A, Mgh, Mṣb, Ḳ,)</span> <em>He executed,</em> or <em>performed, the saying,</em> and <em>the oath, truly.</em> <span class="auth">(M, A, Mgh, Mṣb, Ḳ.)</span> Accord. to El-Aḥmar, one also says,<span class="arrow"><span class="ar long">بَرِرْتُ↓ قَسَمِى</span></span>; but none other asserts this. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="br_4_B3">
					<p><span class="ar long">ابرٱللّٰهُ قَسَمَهُ</span>, <span class="auth">(T, TA,)</span> inf. n. <span class="ar">إِبْرَارٌ</span>; and<span class="arrow"><span class="ar">بَرَّهُ↓</span></span>, inf. n. <span class="ar">بِرٌّ</span>; <em>God verified his oath.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="br_4_B4">
					<p><span class="ar long">ابرّ فُلَانٌ قَسَمَ فُلَانٍ</span> <em>Such a one assented,</em> or <em>consented, to the conjurement of such a one:</em> <span class="ar">أَحْنَثُهُ</span> signifies “he assented not,” or “consented not, thereto.” <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="br_4_C1">
					<p><span class="ar long">ابرّ عَلَيْهِمْ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. as above, <span class="auth">(T, TA,)</span> <em>He overcame them:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> <em>he subdued them,</em> or <em>overcame them, by good or other actions;</em> <span class="auth">(TA;)</span> <em>by actions or sayings;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَرَّهُمْ↓</span></span>, aor. <span class="ar">يَبُرُّ</span>: <span class="auth">(T, Ḳ, TA:)</span> <em>he was refractory,</em> or <em>stubborn, and overcame them.</em> <span class="auth">(TA, from a trad.)</span> You say, <span class="ar long">ابرّ عَلَى خَصْمِهِ</span> <span class="add">[<em>He overcame his adversary</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">ابرّ عَلَيْهِمْ شَرًّا</span> <span class="add">[<em>He overcame them in evil</em>]</span>: and hence <span class="ar">ابرّ</span> is used in the sense of <span class="ar">فَجَرَ</span> <span class="add">[<em>he transgressed,</em>, &amp;c.]</span>; as in the saying of a poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَلَسْتُ أُبَالِى مَنْ أَبَرَّ وَمَنْ فَجَرْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Then I care not who acts wickedly and who transgresses</em>]</span>. <span class="auth">(IAạr, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="br_4_D1">
					<p><span class="ar">ابرّ</span> <span class="add">[from <span class="ar">بَرٌّ</span>]</span> <em>He rode,</em> or <em>journeyed, upon the land.</em> <span class="auth">(ISk, Ṣ, A, Ḳ.)</span> Opposed to <span class="ar">أَبْحَرَ</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="br_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّر</span></h3>
				<div class="sense" id="br_5_A1">
					<p><span class="ar">تبرّر</span> <span class="add">[<em>He affected,</em> or <em>endeavoured to characterize himself by,</em> <span class="ar">بِرّ</span>, i. e. <em>filial piety,</em>, &amp;c.]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="br_5_A2">
					<p><span class="ar long">قَدْ تَبَرَّرْتَ فِى أَمْرِنَا</span> <em>Thou hast abstained from crime,</em> or <em>sin,</em> or <em>the like, in our affair,</em> or <em>business,</em> or <em>case.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="br_5_B1">
					<p><span class="ar long">تبرّر خَالِقَهُ</span>: <a href="#br_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="br_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبارّ</span></h3>
				<div class="sense" id="br_6_A1">
					<p><span class="ar">تبارّوا</span> <em>They practised mutual</em> <span class="ar">بِرّ</span> <span class="add">[meaning <em>kindness,</em> or <em>goodness and affection and gentleness, and regard for each other's circumstances</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="br_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">بربر</span></h3>
				<div class="sense" id="br_RQ1_A1">
					<p><span class="ar">بَرْبَرَ</span>, inf. n. <span class="ar">بَرْبَرَةٌ</span>, <em>He talked much, and raised a clamour,</em> or <em>confused noise,</em> <span class="auth">(M, Ḳ,)</span> <em>with his tongue:</em> <span class="auth">(M:)</span> <em>he cried,</em> or <em>cried out,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and talked in anger,</em> <span class="auth">(Ṣ,)</span> or <em>talked confusedly, with anger and aversion.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَرْبَرَ فِى كَلَامِهِ</span> <em>He was profuse and unprofitable in his talk.</em> <span class="auth">(Fr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="br_RQ1_A2">
					<p>Also, inf. n. as above, <em>He</em> <span class="auth">(a goat)</span> <em>uttered a cry</em> or <em>cries,</em> <span class="add">[or <em>rattled,</em>]</span> <span class="auth">(M, Ḳ,)</span> <em>being excited by desire of the female.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBN">
				<h3 class="entry"><span class="ar">بَرٌّ</span> / 
							<span class="ar">بَرِرٌ</span> /
							<span class="ar">بَرَّةٌ</span></h3>
				<div class="sense" id="barBN_A1">
					<p><span class="ar">بَرٌّ</span> <span class="add">[originally <span class="ar">بَرِرٌ</span>]</span> <span class="auth">(M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَارٌّ↓</span></span> <span class="auth">(Mṣb)</span> <em>Pious</em> <span class="add">[<em>towards his father</em> or <em>parents,</em> and ‡ <em>towards God;</em> ‡ <em>obedient to God, serving God,</em> or <em>rendering religious service to God;</em> (<a href="#br_1">see 1</a>;) and <em>kind,</em> or <em>good and affectionate and gentle in behaviour, towards his kindred;</em> and <em>good in his dealings with strangers</em>]</span>; <em>good, just, righteous, virtuous,</em> or <em>honest:</em> <span class="auth">(Mṣb:)</span> <em>true,</em> or <em>veracious:</em> <span class="auth">(M, Mṣb, Ḳ:)</span> and both signify also <em>abounding in</em> <span class="ar">بِرّ</span> <span class="add">[or <em>filial piety,</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> the former is <span class="add">[said to be]</span> a stronger epithet than the latter, like as <span class="ar">عَدْلٌ</span> is stronger than <span class="ar">عَادِلٌ</span>: <span class="auth">(B:)</span> <span class="add">[but its pl. shows that it is not, like <span class="ar">عَدْلٌ</span>, originally an inf. n.: it is a regular contraction of <span class="ar">بَرِرٌ</span>, like as <span class="ar">بَارٌّ</span> is of <span class="ar">بَارِرٌ</span>:]</span> the fem. of each is with <span class="ar">ة</span>: <span class="auth">(Lḥ, M:)</span> the pl. <span class="auth">(of the former, Ṣ, M, Mṣb, or of the latter, B)</span> is <span class="ar">أَبْرَاٌ</span>; and <span class="auth">(of the latter, Ṣ, M, Mṣb, or of the former, B)</span> <span class="ar">بَرَرَةٌ</span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> the former pl. is often specially applied to saints, those who abstain from worldly pleasures, and devotees; and the latter, to the recording angels. <span class="auth">(B.)</span> You say, <span class="ar long">أَنَا بَرٌّ بِوَالِدِى</span>, and<span class="arrow"><span class="ar">بَارٌّ↓</span></span>, <em>I am characterized by filial piety, dutifulness,</em> or <em>obedience, to my father:</em> <span class="auth">(Ṣ, M, A:*)</span> the latter is mentioned on the authority of Kr; but some disallow it. <span class="auth">(M, TA.)</span> And <span class="ar long">الأُمُّ بَرَّةٌ بِوَلَدِهَا</span> <span class="add">[<em>The mother is maternally affectionate to her child,</em> or <em>offspring</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">رَجُلٌ بَرٌّ بِذِى قَرَابَتِهِ</span>, and<span class="arrow"><span class="ar">بَارٌّ↓</span></span>, <em>A man who behaves towards his kindred with kindness,</em> or <em>goodness and affection and gentleness, and regard for their circumstances.</em> <span class="auth">(T.)</span> And <span class="ar long">رَجُلٌ بَرٌّ سَرٌّ</span> <em>A man who treats with goodness and affection and gentleness, and rejoices,</em> or <em>gladdens, his brethren:</em> pl. <span class="ar long">بَرُّونَ سَرُّونَ</span>. <span class="auth">(Ṣ,* Ḳ,* TA, in art. <span class="ar">سر</span>.)</span> And <span class="ar long">بَرٌّ فِى قَوْلٍ</span>, and <span class="ar long">فِى يَمِينٍ</span>, and<span class="arrow"><span class="ar">بَارٌّ↓</span></span>, <em>True,</em> or <em>veracious, in a saying,</em> and <em>in an oath.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">يَمِينٌ بَرَّةٌ</span> and<span class="arrow"><span class="ar">بَارَّةٌ↓</span></span> <span class="add">[<em>A true oath;</em> or <em>an oath that proves true</em>]</span>. <span class="auth">(Ḥam p. 811.)</span> <span class="ar">البَرُّ</span> is also a name of God; <span class="auth">(M, Ḳ;)</span> meaning † <em>The Merciful,</em> or <em>Compassionate:</em> <span class="auth">(M:)</span> or <em>the Very Benign to his servants;</em> <span class="auth">(IAth;)</span> <em>the Ample in goodness</em> or <em>beneficence:</em> <span class="auth">(B:)</span> <span class="ar">البَارُّ</span> is not so used. <span class="auth">(IAth.)</span> It is said in a trad., <span class="ar long">تَمَسَّحُوا بِالأَرْضِ فَإِنَّهَا بَرَّةٌ بِكُمْ</span> † <em>Wipe yourselves with the dust,</em> or <em>earth,</em> <span class="add">[in performing the ceremony termed <span class="ar">التَّيَمُّمُ</span>,]</span> <em>for it is benignant towards you,</em> like as the mother is to her children; meaning, ye are created from it, and in it are your means of subsistence, and to it ye return after death: <span class="auth">(IAth:)</span> or the meaning is, that your tents, or houses, are upon it, and ye are buried in it. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="barBN_B1">
					<p><span class="ar">بَرٌّ</span> <em>Land;</em> opposed to <span class="ar">بَحْرٌ</span> <span class="add">[as meaning “sea” and the like]</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> from <span class="ar">بِرٌّ</span> signifying “ampleness,” “largeness,” or “extensiveness;” <span class="auth">(Esh-Shiháb <span class="add">[El-Khafájee]</span>, MF;)</span> or the former word is the original of the latter. <span class="auth">(B, TA. <span class="add">[See the latter word.]</span>)</span> <span class="add">[Hence, <span class="ar long">بَرًّا وَبَحْرًا</span> <em>By land and by sea.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="barBN_B2">
					<p><em>A desert,</em> or <em>deserts; a waste,</em> or <em>wastes.</em> <span class="auth">(T, TA. <span class="add">[<a href="#bar~iyBapN">See also <span class="ar">بَرِّيَّةٌ</span></a>, voce <span class="ar">بَرِّيٌّ</span>.]</span>)</span> So, accord. to Mujáhid <span class="add">[and the Jel]</span> in words of the Ḳur <span class="add">[vi. 59]</span>, <span class="ar long">وَيَعْلَمُ مَا فِى البَرِّ وَالبَحْرِ</span> <em>And He knoweth what is in the desert,</em> or <em>deserts, and the towns,</em> or <em>villages, in which is water,</em> <span class="auth">(T, TA,)</span> or <em>which are upon the rivers.</em> <span class="auth">(Jel.)</span> <span class="add">[So too in the phrase <span class="ar long">نَبَاتُ البَرِّ</span> <em>The plants,</em> or <em>herbage, of the desert</em> or <em>waste; the wild plants</em> or <em>herbage.</em> And <span class="ar long">عَسَلُ البَرِّ</span> <em>Honey of the desert; wild honey.</em> And <span class="ar long">حَيَوَانُ البَرِّ</span> <em>The animal,</em> or <em>animals, of the desert; the wild animal</em> or <em>animals.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="barBN_B3">
					<p><em>A wide tract of land.</em> <span class="auth">(Bḍ in ii. 41.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="barBN_B4">
					<p><span class="add">[The <em>open country;</em> opposed to <span class="ar">بَحْرٌ</span> as meaning the “cities,” or “towns,” “upon the rivers:” see the latter word.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="barBN_B5">
					<p><em>Elevated ground, open to view.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B6</span>
				</div>
				<div class="sense" id="barBN_B6">
					<p>The <em>tract, or part, out of doors,</em> or <em>where one is exposed to view; contr. of</em> <span class="ar">كِنٌّ</span>: used by the Arabs indeterminately; <span class="add">[without the article <span class="ar">ال</span>;]</span> as in the phrase, <span class="ar long">جَلَسْتُ بَرًّا</span> <span class="auth">(Lth, T)</span> meaning <em>I sat outside the house;</em> <span class="auth">(A;)</span> and <span class="ar long">خَرَجْتُ بَرًّا</span> <span class="auth">(Lth, T)</span> meaning <em>I went forth outside the</em> <span class="add">[<em>house</em> or]</span> <em>town,</em> <span class="auth">(A,)</span> or <em>into the desert:</em> <span class="auth">(TA:)</span> but <span class="add">[Az says,]</span> these are post-classical phrases, which I have not heard from the chaste-speaking Arabs of the desert. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B7</span>
				</div>
				<div class="sense" id="barBN_B7">
					<p>You say also, <span class="ar long">أَرِيدُ جَوًّا وَيُرِيدُ بَرًّا</span> <em>I desire concealment,</em> or <em>secrecy, and he desires publicity.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burBN">
				<h3 class="entry"><span class="ar">بُرٌّ</span></h3>
				<div class="sense" id="burBN_A1">
					<p><span class="ar">بُرٌّ</span> <em>Wheat;</em> and the <em>grain of wheat;</em> syn. <span class="ar">قَمْحٌ</span>, <span class="auth">(Ṣ,* Mṣb,)</span> or <span class="ar">حِنْطَةٌ</span>; <span class="auth">(M, Ḳ;)</span> but it is a more chaste word than <span class="ar">قَمْحٌ</span> and <span class="ar">حِنْطَةٌ</span>: <span class="auth">(M:)</span> <a href="#burBapN">pl. of <span class="ar">بُرَّةٌ</span></a>; <span class="auth">(Ṣ, M;)</span> or <span class="add">[rather]</span> <span class="ar">بُرَّةٌ</span> is the n. un. <span class="add">[signifying <em>a grain of wheat,</em> like <span class="ar">قَمْحَةٌ</span>]</span>: <span class="auth">(IDrd, Mṣb:)</span> <a href="#burBN">the pl. of <span class="ar">بُرٌّ</span></a> is <span class="ar">أَبْرَارٌ</span>; <span class="auth">(Ḳ;)</span> or this pl. is allowable on the ground of analogy, accord. to Mbr, but is disallowed by Sb. <span class="auth">(Ṣ.)</span> It is said in a prov., <span class="auth">(TA,)</span> <span class="ar long">هُوَ أَقْصَرُ مِنْ برَّةٍ</span> <span class="add">[<em>He,</em> or <em>it, is shorter than a grain of wheat</em>]</span>. <span class="auth">(A, TA.)</span> And you say, <span class="ar long">أَطْعمَنَا ٱبْنَ بُرَّةٍ</span> <em>He fed us with bread.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="birBN">
				<h3 class="entry"><span class="ar">بِرٌّ</span></h3>
				<div class="sense" id="birBN_A1">
					<p><span class="ar">بِرٌّ</span> <a href="#br_1">inf. n. of 1</a>: <span class="auth">(T, Ṣ, M, &amp;c.:)</span> it is said by some to signify primarily <em>Ampleness, largeness,</em> or <em>extensiveness;</em> whence <span class="ar">بَرٌّ</span> as opposed to <span class="ar">بَحْرٌ</span>: then,</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بِرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="birBN_A2">
					<p><em>Benevolent and solicitous regard</em> or <em>treatment</em> or <em>conduct</em> <span class="add">[<em>to parents and others;</em> i. e. <em>piety to parents;</em> and ‡ <em>towards God</em>]</span>: and <em>goodness,</em> or <em>beneficence:</em> and <em>kindness,</em> or <em>good and affectionate and gentle behaviour, and regard for the circumstances of another:</em> <span class="auth">(Esh-Shiháb <span class="add">[El-Khafájee]</span>, MF:)</span> or <span class="ar">بَرٌّ</span>, as opposed to <span class="ar">بَحْرٌ</span>, <span class="add">[or as signifying “a wide tract of land,” <span class="auth">(Bḍ in ii. 41,)</span>]</span> is the original of <span class="ar">بِرٌّ</span>, <span class="auth">(Bḍ in ii. 41, B, TA,)</span> which signifies <em>ample, large,</em> or <em>extensive, goodness</em> or <em>beneficence,</em> <span class="auth">(Z, in the Ksh, ii. 41, <span class="add">[but he regards it as the original of <span class="ar">بَرٌّ</span>,]</span> and Bḍ on the same passage, and B, Ḳ, TA,)</span> <em>to men;</em> <span class="auth">(TA;)</span> or comprehending <em>every kind of goodness:</em> <span class="auth">(Ksh and Bḍ ubi suprà:)</span> and hence it is said to be in three things: <em>in the service of God: in paying regard to relations; acting well to them:</em> and <em>in dealing with strangers:</em> <span class="auth">(Bḍ ubi suprà:)</span> or <em>every deed that is approved:</em> <span class="auth">(Ksh and Bḍ in ii. 172:)</span> and <span class="add">[particularly]</span> <em>obedience to God:</em> <span class="auth">(T, Ṣ, M, &amp;c.: <span class="add">[<a href="#barBapu">see also <span class="ar">بَرَّةُ</span></a>:]</span>)</span> <span class="add">[and <em>every incumbent duty:</em> and hence,]</span> the <em>pilgrimage to Mekkeh:</em> <span class="auth">(Ḳ:)</span> and <em>fidelity to an engagement:</em> <span class="auth">(TA:)</span> also <em>a gratuitous gift,</em> or <em>favour;</em> and <em>a bounty,</em> or <em>benefit;</em> syn. <span class="ar">فَضْلٌ</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">إِحْسَانٌ</span>; as also<span class="arrow"><span class="ar">مَبَرَّةٌ↓</span></span> <span class="add">[an inf. n., but when used as a simple subst. its pl. is <span class="ar">مَبَارٌ</span> and <span class="ar">مَبَرَّاتٌ</span>]</span>. <span class="auth">(Ḥar p. 94.)</span> In the Ḳur <span class="add">[ii. 172]</span>, where it is said, <span class="ar long">لُكِنَّ البِرَّ مَنْ آمَنَ بِٱللّٰهِ</span>, by <span class="ar">البرّ</span> is meant <span class="ar long">ذَا البِرِّ</span> <span class="add">[i. e. <em>But the pious,</em> or <em>obedient</em> to God, <em>is he who believeth in God</em>]</span>; <span class="auth">(T, M, Ksh, Bḍ, Jel;)</span> and some read <span class="ar">البَارَّ</span>: <span class="auth">(Ksh, Bḍ, Jel:)</span> or the meaning is, <span class="ar long">لكنّ البِرَّ بِرُّ من آمن باللّٰه</span> i. e. <em>but the obedience</em> of which it behooveth one to be mindful <em>is the obedience of him who believeth in God:</em> <span class="auth">(Sb, T, IJ, M, Ksh, Bḍ:)</span> and this explanation is preferable to the former. <span class="auth">(Bḍ.)</span> <span class="pb" id="Page_0177"></span>It is said in a prov., <span class="auth">(T, Ṣ,)</span> <span class="ar long">لَا يَعْرِفُ هِرًّا مِنْ بِرٍ</span>, <span class="auth">(Ṣ, A, Ḳ, but in the T and M <span class="ar">مَا</span> is put in the place of <span class="ar">لا</span>,)</span> meaning <em>He knows not him who dislikes him,</em> or <em>hates him, from him who behaves towards him with kindness,</em> or <em>goodness and affection and gentleness, and regard for his circumstances:</em> <span class="auth">(Ṣ, M, A, Ḳ,* TA:)</span> or <em>undutiful conduct to a parent from gentleness,</em> or <em>courtesy:</em> <span class="auth">(El-Fezáree, T, Ḳ:)</span> or <em>altercation,</em> <span class="auth">(T,)</span> or <em>dislike,</em> or <em>hatred,</em> <span class="auth">(Ḳ,)</span> <em>from honourable treatment:</em> <span class="auth">(T, Ḳ:)</span> or <em>the calling of sheep,</em> or <em>goats, from the driving of them:</em> <span class="auth">(IAạr, Ṣ, Ḳ:)</span> or <em>the driving of sheep,</em> or <em>goats, from the calling of them:</em> <span class="auth">(Yoo, T:)</span> or <em>the calling of them to water from the calling of them to fodder;</em> <span class="auth">(Ḳ;)</span> which last rendering is agreeable with an explanation of <span class="ar">بِرٌّ</span> by IAạr <span class="add">[mentioned in the T]</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">بِرْبِرٌ↓</span></span>, also, has the signification here assigned to <span class="ar">بِرٌّ</span>: <span class="auth">(Ḳ,* TA:)</span> or <span class="ar">الهَرْهَرَة</span> <em>from</em> <span class="ar">البَرْبَرَة</span>; <span class="auth">(AʼObeyd, T, Ḳ;)</span> i. e. <em>the crying of sheep from the crying of goats:</em> <span class="auth">(AʼObeyd, T:)</span> or <em>the cat from the rat,</em> or <em>mouse:</em> <span class="auth">(IAạr, T, M, Ḳ:)</span> and <span class="ar">بِرٌّ</span> also signifies the <span class="add">[<em>species of rat called</em>]</span> <span class="ar">جُرَذ</span>: <span class="auth">(Aboo-Tálib, T, Ḳ:)</span> or <em>a small animal resembling the rat</em> or <em>mouse:</em> <span class="auth">(M:)</span> and the <em>young of the fox.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بِرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="birBN_A3">
					<p>Also <em>Good,</em> as a subst., not an adj.; syn. <span class="ar">خَيْرٌ</span>; <span class="auth">(Sh, T, Mgh, Mṣb, Ḳ;)</span> which comprises all that has been said in explanation of <span class="ar">بِرٌّ</span> <span class="auth">(Sh, T, Mgh)</span> as used in the saying of Moḥammad, <span class="ar long">عَليْكُمْ بِالصِّدْقِ فَإِنَّهُ يَهْدِى إِلَى البِرِّ</span> <span class="add">[<em>Keep ye to truth; for it guides to good,</em> or <em>to a good,</em> or <em>right, state</em>]</span>: some render it in this instance by <span class="ar">الخَيْر</span>; and some, by <span class="ar">الصَّلَاح</span>. <span class="auth">(Sh, T.)</span> It signifies also The <em>good of the present life, consisting in spiritual and worldly blessings, and of that which is to come, consisting in everlasting enjoyment in Paradise:</em> so in the Ḳur iii. 86: <span class="auth">(T:)</span> or <span class="add">[simply]</span> <em>Paradise.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بِرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="birBN_A4">
					<p>Also The <em>heart;</em> or the <em>mind.</em> <span class="auth">(Ḳ.)</span> So in the saying, <span class="ar long">هُوَ مُطْمَئِنُّ البِرِّ</span> <span class="add">[<em>He is quiet,</em> or <em>at rest, in heart,</em> or <em>mind</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBapu">
				<h3 class="entry"><span class="ar">بَرَّةُ</span></h3>
				<div class="sense" id="barBapu_A1">
					<p><span class="ar">بَرَّةُ</span> a subst. in the sense of <span class="ar">البِرُّ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> meaning <em>Obedience</em> <span class="add">[&amp;c.]</span>; <span class="auth">(Ḳ;)</span> determinate, <span class="auth">(Ṣ, Ḳ,)</span> being a proper name; for which reason, combined with its being of the fem. gender, it is imperfectly decl. <span class="auth">(M.)</span> <span class="add">[It is opposed to <span class="ar">فَجَارِ</span>. <a href="#Hml_1">See a verse of En-Nábighah in the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=06_H/181_Hml">of art. <span class="ar">حمل</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariyrN">
				<h3 class="entry"><span class="ar">بَرِيرٌ</span> / <span class="ar">بَرِيرَةٌ</span></h3>
				<div class="sense" id="bariyrN_A1">
					<p><span class="add">[<span class="ar">بَرِيرٌ</span> a coll. gen. n.]</span> The <em>fruit of the</em> <span class="ar">أَرَاك</span> <span class="add">[q. v.]</span>, <span class="auth">(Ṣ, M,)</span> <em>in a general sense:</em> <span class="auth">(M:)</span> or the <em>first thereof;</em> <span class="auth">(Ḳ;)</span> <span class="add">[i. e.]</span> the <em>first that appears,</em> or <em>when it first appears, and is sweet:</em> <span class="auth">(M:)</span> or <em>when it has become hard:</em> <span class="auth">(Mṣb:)</span> or <em>when it is larger in its berries</em> (<span class="ar">حَبّ</span>) <em>than such as is termed</em> <span class="ar">كَبَاث</span>, <em>and smaller in its clusters; having a round, small, hard stone, a little larger than the</em> <span class="ar">حِمَّص</span>; <em>its cluster filling the hand:</em> <span class="auth">(AḤn, M:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرِيرَةٌ</span>}</span></add>. <span class="auth">(AḤn, Ṣ, M, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burBae">
				<h3 class="entry"><span class="ar">بُرَّى</span></h3>
				<div class="sense" id="burBae_A1">
					<p><span class="ar">بُرَّى</span> <em>A good, sweet,</em> or <em>pleasant, word</em> or <em>expression</em> or <em>saying:</em> <span class="auth">(Ḳ:)</span> from <span class="ar">بِرٌّ</span> signifying “benevolent and solicitous regard or treatment or conduct.” <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBieBN">
				<h3 class="entry"><span class="ar">بَرِّىٌّ</span></h3>
				<div class="sense" id="barBieBN_A1">
					<p><span class="add">[<span class="ar">بَرِّىٌّ</span> <em>Of,</em> or <em>belonging to,</em> or <em>relating to, the land</em> as opposed to the sea or a great river.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرِّىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barBieBN_A2">
					<p><span class="add">[And <em>Of,</em> or <em>belonging to,</em> or <em>relating to, the desert</em> or <em>waste; growing,</em> or <em>living,</em> or <em>produced, in the desert</em> or <em>waste; wild,</em> or <em>in an uncultivated state.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرِّىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="barBieBN_A3">
					<p><span class="add">[And hence,]</span> <span class="ar long">أَرْضٌ بَرِّيَّةٌ</span> <em>Uncultivated land; without seed-produce, and unfruitful; without green herbs</em> or <em>leguminous plants and without waters; contr. of</em> <span class="ar">رِيفِيَّةٌ</span>. <span class="auth">(IAạr, M, Ḳ.*)</span> And, simply, <span class="arrow"><span class="ar">بَرَّيَّةٌ↓</span></span>, <span class="auth">(Ṣ, M, A, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بَرِّيتٌ↓</span></span>, <span class="auth">(AʼObeyd, IAạr, Sh, Ṣ, Ḳ,)</span> the latter a variation of the former, the <span class="ar">ى</span> being made quiescent, and the <span class="ar">ة</span> therefore being changed into <span class="ar">ت</span>, as in <span class="ar">عِفْرِيتٌ</span>, originally <span class="ar">عِفْرِيَةٌ</span>, <span class="auth">(Ṣ,)</span> a rel. n. from <span class="ar">بَرٌّ</span>, <span class="auth">(Sh, T, Mṣb,)</span> <em>A desert; a waste; a spacious tract of ground without herbage;</em> syn. <span class="ar">صَحْرَآءُ</span>: <span class="auth">(Ṣ, M, A, Mṣb, Ḳ:)</span> <span class="add">[<a href="#barBN">see also <span class="ar">بَرٌّ</span></a>:]</span> or <em>a tract nearer to the desert</em> (<span class="ar">البَرّ</span>) <em>than it is to water:</em> <span class="auth">(Sh, T:)</span> <span class="add">[but some write the latter word <span class="arrow"><span class="ar">بِرِّيتٌ↓</span></span>; and it is said that]</span> <span class="ar">بِرِّيتُ</span>, <span class="auth">(T and Ḳ in art. <span class="ar">برت</span>,)</span> of the same measure as <span class="ar">سِكِّيتٌ</span>, <span class="auth">(Ḳ in that art.,)</span> signifies <em>flat, even,</em> or <em>level, land:</em> <span class="auth">(T, Ḳ:)</span> or <em>a barren, flat, even,</em> or <em>level, land:</em> a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بِرِّيتُ أَرْضٍ بَعْدَهَا بِرِّيتُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>A barren, flat land, after which is a</em> second <em>barren, flat land</em>]</span>: <span class="auth">(T:)</span> ISd says that <span class="ar">بِرِّيتٌ</span>, in a poem of Ru-beh, <span class="add">[from which the ex. given above is probably taken,]</span> is of the measure <span class="ar">فِعْلِيتٌ</span> from <span class="ar">البَرُّ</span>; and that art. <span class="ar">برت</span> is not the place in which it should be mentioned: <span class="auth">(TA:)</span> Lth says, <span class="ar">البَرِّيتُ</span> is a noun derived from <span class="ar">البَرِّيَّةُ</span>; the <span class="ar">ى</span> becoming quiescent, and the <span class="ar">ة</span> becoming an inseparable <span class="ar">ت</span>, as though it were a radical letter, as in the case of <span class="ar">عِفْرِيَةٌ</span>, which thus becomes <span class="ar">عِفْرِيتٌ</span>: <span class="auth">(T, TA:)</span> <a href="#br~yBp">the pl. of <span class="ar">برّيّة</span></a> is <span class="ar">بَرَارِىُّ</span>; <a href="#brByt">and that of <span class="ar">برّيت</span></a> is <span class="ar">بَرَارِيتُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="barBiyBapN">
				<h3 class="entry"><span class="ar">بَرِّيَّةٌ</span> / 
							<span class="ar">بَرِّيتٌ</span> / 
							<span class="ar">بِرِّيتٌ</span></h3>
				<div class="sense" id="barBiyBapN_A1">
					<p><span class="ar">بَرِّيَّةٌ</span> and <span class="ar">بَرِّيتٌ</span> and <span class="ar">بِرِّيتٌ</span>: <a href="#bar~ieBN">see <span class="ar">بَرِّىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBaArN">
				<h3 class="entry"><span class="ar">بَرَّارٌ</span></h3>
				<div class="sense" id="barBaArN_A1">
					<p><span class="ar">بَرَّارٌ</span> as signifying <em>A possessor of</em> <span class="ar">بُرّ</span>, i. e. <em>wheat,</em> though agreeable with prevailing analogy, is not allowable, not being sanctioned by usage. <span class="auth">(Sb, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barBaAnieBN">
				<h3 class="entry"><span class="ar">بَرَّانِىٌّ</span></h3>
				<div class="sense" id="barBaAnieBN_A1">
					<p><span class="ar">بَرَّانِىٌّ</span> <em>External;</em> or <em>outward: apparent; public.</em> <span class="auth">(T.)</span> Hence the saying of Selmán, <span class="auth">(T,)</span> <span class="ar long">مَنْ أَصْلَحَ جَوَّانِيَّهُ أَصْلَحَ ٱللّٰهُ بَرَّانِيَّهُ</span> <span class="auth">(T, A, Ḳ)</span> <em>Whoso maketh his inner man</em> (<span class="ar">سَرِيرَتَهُ</span>) <em>to be good, God will make his outward man</em> (<span class="ar">عَلَانِيَتَهُ</span>) <em>to be good.</em> <span class="auth">(T.)</span> <span class="ar">بَرَّانِىٌّ</span> is a rel. n., irregularly formed, <span class="auth">(Ḳ,)</span> from <span class="ar">بَرٌّ</span> signifying “elevated ground, open to view;” and <span class="ar">جَوَّانِىٌّ</span>, from <span class="ar">جَوٌّ</span> signifying “any low, or depressed, part of the ground.” <span class="auth">(T.)</span> You say, <span class="ar long">افْتَتَحَ البَابَ البَرَّانِىَّ</span> <em>He opened the outer door.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barobaru">
				<h3 class="entry"><span class="ar">بَرْبَرُ</span></h3>
				<div class="sense" id="barobaru_A1">
					<p><span class="ar">بَرْبَرُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">البَرْبَرُ</span>, <span class="auth">(Mgh, Mṣb,)</span> <span class="add">[a coll. gen. proper name, of which the n. un., or rel. n., is <span class="arrow"><span class="ar">بَرْبَرِىٌّ↓</span></span>,]</span> a foreign word, <span class="auth">(Ṣ,)</span> <span class="add">[probably of African origin, the primary form of which is the source of <span class="gr">Βάρβαρος</span>, &amp;c.,]</span> arabicized; <span class="auth">(Mṣb;)</span> or, as some say, from <span class="ar">بَرْبَرَةٌ</span> in speech; <span class="auth">(TA; <span class="add">[<a href="#br_RQ1">see R. Q. 1</a>;]</span>)</span> and <span class="ar">البَرَابِرَةُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <a href="#barobaru">the pl. of <span class="ar">بَرْبَرُ</span></a>, <span class="auth">(Ḳ,)</span> <a href="#Albarobaru">or of <span class="ar">البَرْبَرُ</span></a>, <span class="auth">(Mṣb,)</span> <span class="add">[<a href="#barobarieBN">or of <span class="ar">بَرْبَرِىٌّ</span></a>, agreeably with what follows and with analogy,]</span> the <span class="ar">ة</span> being added because the sing. is a foreign word, or <span class="add">[so in the M and TA, but in the Ṣ “and,”]</span> a rel. n., <span class="auth">(Ṣ, M,)</span> but it may be elided; <span class="add">[so that one may say <span class="ar">البَرَابِرُ</span>;]</span> <span class="auth">(Ṣ;)</span> <em>A certain people,</em> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> <em>of the inhabitants of El-Maghrib</em> <span class="add">[or <em>Northern Africa west of Egypt</em>]</span>, <span class="auth">(Mgh,* Mṣb, Ḳ,*)</span> <em>like the Arabs of the desert in hardness, and coarseness,</em> or <em>rudeness,</em> <span class="auth">(Mgh,* Mṣb,)</span> <em>and in slightness of religion, and littleness of knowledge:</em> <span class="auth">(Mgh:)</span> and <em>another people,</em> <span class="add">[<em>the Colobi</em> mentioned by Diodorus Siculus and Strabo,]</span> <em>between the Abyssinians and the Zinj, who amputate</em> <span class="add">[<em>the glans of</em>]</span> <em>the penis, and make it a dowry for a wife.</em> <span class="auth">(Ḳ.)</span> <span class="add">[There are various opinions of the origins of these races. The appellation of <span class="ar">البَرَابِرَةُ</span>, sing. <span class="arrow"><span class="ar">بَرْبَرِىٌّ↓</span></span>, is also applied by late historians, and in the present day, to <em>The races inhabiting the portion of the valley of the Nile which we commonly call Nubia.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buroburN">
				<h3 class="entry"><span class="ar">بُرْبُرٌ</span></h3>
				<div class="sense" id="buroburN_A1">
					<p><span class="ar">بُرْبُرٌ</span>: <a href="#barobaArN">see <span class="ar">بَرْبَارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="birobirN">
				<h3 class="entry"><span class="ar">بِرْبِرٌ</span></h3>
				<div class="sense" id="birobirN_A1">
					<p><span class="ar">بِرْبِرٌ</span>: <a href="#birBN">see <span class="ar">بِرٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="barobarieBN">
				<h3 class="entry"><span class="ar">بَرْبَرِىٌّ</span></h3>
				<div class="sense" id="barobarieBN_A1">
					<p><span class="ar">بَرْبَرِىٌّ</span>: <a href="#barobaArN">see <span class="ar">بَرْبَارٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرْبَرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barobarieBN_A2">
					<p><a href="#barobaru">and see also <span class="ar">بَرْبَرُ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barobaArN">
				<h3 class="entry"><span class="ar">بَرْبَارٌ</span></h3>
				<div class="sense" id="barobaArN_A1">
					<p><span class="ar">بَرْبَارٌ</span> One <em>who talks much, and raises a clamour,</em> or <em>confused noise,</em> <span class="auth">(M, Ḳ,)</span> <em>with his tongue:</em> <span class="auth">(M:)</span> <em>who cries,</em> or <em>cries out,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and talks in anger,</em> <span class="auth">(Ṣ,)</span> or <em>talks confusedly, with anger and aversion:</em> <span class="auth">(TA:)</span> <em>who vociferates much;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بُرْبُرٌ↓</span></span>: <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar">بَرْبَرِىٌّ↓</span></span> signifies one <em>who talks much and unprofitably.</em> <span class="auth">(Fr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرْبَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="barobaArN_A2">
					<p><span class="ar">البَرْبَارُ</span> <em>The lion;</em> as also<span class="arrow"><span class="ar">المُبَرْبِرُ↓</span></span>: <span class="auth">(Ḳ:)</span> because of the confused noise that he makes, and his aversion and anger. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">بَرْبَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="barobaArN_A3">
					<p><span class="ar long">دَلْوٌ بَرْبَارٌ</span> <em>A bucket that makes a noise</em> <span class="auth">(M, Ḳ)</span> <em>in the water.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burobuwrN">
				<h3 class="entry"><span class="ar">بُرْبُورٌ</span></h3>
				<div class="sense" id="burobuwrN_A1">
					<p><span class="ar">بُرْبُورٌ</span> <em>What is termed</em> <span class="ar">جَشِيش</span> <span class="add">[i. e. <em>coarselyground flour,</em>, &amp;c.]</span>, <span class="auth">(M, CK, <span class="add">[in MṢ. copies of the Ḳ, and of the Ṣ also, <span class="ar">حَشِيش</span>, which is evidently a mistranscription,]</span>)</span> <em>of wheat.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baArBN">
				<h3 class="entry"><span class="ar">بَارٌّ</span> / <span class="ar">بَارَّةٌ</span></h3>
				<div class="sense" id="baArBN_A1">
					<p><span class="ar">بَارٌّ</span> and its fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَارَّةٌ</span>}</span></add>: <a href="#barBN">see <span class="ar">بَرٌّ</span></a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabarBN">
				<h3 class="entry"><span class="ar">أَبَرٌّ</span></h3>
				<div class="sense" id="OabarBN_A1">
					<p><span class="ar">أَبَرٌّ</span> <span class="add">[accord. to analogy signifies <em>More,</em> and <em>most, pious</em>, &amp;c.: <a href="#barBN">see <span class="ar">بَرٌّ</span></a>. But the only meaning that I find assigned to it in any of the lexicons is that here following.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">أَبَرٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabarBN_B1">
					<p><em>More,</em> and <em>most, distant in the desert,</em> <span class="auth">(T, Ḳ,)</span> <em>as to habitation.</em> <span class="auth">(T.)</span> So in the saying, <span class="ar long">أَفْصَحُ العَرَبِ أَبَرُّهُمْ</span> <em>The most chaste in speech of the Arabs are the most distant of them in the desert, as to habitation.</em> <span class="auth">(T, Ḳ.* <span class="add">[In the latter, instead of <span class="ar">افصح</span>, we find <span class="ar">أَصْلَحُ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubirBN">
				<h3 class="entry"><span class="ar">مُبِرٌّ</span></h3>
				<div class="sense" id="mubirBN_A1">
					<p><span class="ar">مُبِرٌّ</span> One <em>who overcomes.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#br_4">See 4</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">مُبِرٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubirBN_A2">
					<p><span class="ar long">إِنَّهُ لَمُبِرٌّ بِذٰلِكَ</span> means <em>Verily he is a prudent,</em> or <em>sound, manager of that;</em> syn. <span class="ar long">ضَابِطٌ لَهُ</span>. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabarBapN">
				<h3 class="entry"><span class="ar">مَبَرَّةٌ</span></h3>
				<div class="sense" id="mabarBapN_A1">
					<p><span class="ar">مَبَرَّةٌ</span>: <a href="#birBN">see <span class="ar">بِرٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboruwrN">
				<h3 class="entry"><span class="ar">مَبْرُورٌ</span></h3>
				<div class="sense" id="maboruwrN_A1">
					<p><span class="ar">مَبْرُورٌ</span>, applied to a pilgrimage, <em>Sinlessly performed:</em> <span class="auth">(Sh, T, Mgh:)</span> or <em>characterized by the giving of food and by sweetness of speech;</em> as explained by Moḥammad himself: <em>accepted: rewarded.</em> <span class="auth">(TA.)</span> <span class="ar long">مَبْرُورٌ مَأْجُورٌ</span> <span class="add">[Thou art <em>accepted,</em> or <em>approved, and rewarded</em>]</span> and <span class="ar long">مَبْرُورًا مَأْجُورًا</span> <span class="add">[Go thou <em>accepted,</em> or <em>approved, and rewarded</em>]</span> are forms of benediction: <span class="pb" id="Page_0178"></span>the former, of the dial. of Temeem; <span class="ar">أَنْتَ</span> being understood: the latter, of the dial. of the people of El-Ḥijáz; <span class="ar">اِذْهَبْ</span> being understood. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بر</span> - Entry: <span class="ar">مَبْرُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maboruwrN_A2">
					<p>Applied to a sale, <em>Truly and honestly executed.</em> <span class="auth">(Sh, T, Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Almubarobiru">
				<h3 class="entry"><span class="ar">المُبَرْبِرُ</span></h3>
				<div class="sense" id="Almubarobiru_A1">
					<p><span class="ar">المُبَرْبِرُ</span>: <a href="#barobaArN">see <span class="ar">بَرْبَارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0175.pdf" target="pdf">
							<span>Lanes Lexicon Page 175</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0176.pdf" target="pdf">
							<span>Lanes Lexicon Page 176</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0177.pdf" target="pdf">
							<span>Lanes Lexicon Page 177</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0178.pdf" target="pdf">
							<span>Lanes Lexicon Page 178</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
