<article class="root" id="Root_brhn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/086_brh">بره</a></span>
				<span class="ar">برهن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/088_brw">برو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brhn_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">برهن</span></h3>
				<div class="sense" id="brhn_Q1_A1">
					<p>Q., or, as some say, Q. Q., 1. <span class="ar">بَرْهَنَ</span> <em>He adduced,</em> <span class="auth">(T, Z, Mṣb,)</span> or <em>established,</em> <span class="auth">(Ṣ, Ḳ, and Ḥam p. 7,)</span> <em>the</em> <span class="ar">بُرْهَان</span>, <span class="auth">(T, Z, Mṣb, Ḳ,)</span> i. e. the <em>evidence</em> or <em>proof</em> <span class="add">[&amp;c.]</span>; <span class="auth">(T, Ṣ, Mṣb, &amp;c.;)</span> or <em>he adduced his evidence</em> or <em>proof</em> <span class="add">[&amp;c.]</span>; <span class="auth">(T, Mṣb;)</span> <span class="ar">عَلَيْهِ</span> <span class="add">[<em>against him,</em> or <em>it,</em> or <span class="auth">(as in <span class="ar long">اِسْتَدَلَّ عَلَيْهِ</span>)</span> <em>of it</em>]</span>, <span class="auth">(Ṣ, Ḳ, and Ḥam p. 7,)</span> and <span class="ar">لَهُ</span> <span class="add">[<em>to him,</em> or <em>for him</em>]</span>: <span class="auth">(Ḥam ubi suprà:)</span> but this verb is said by Az and Z, on the authority of IAạr, to be post-classical; the correct word, they say, being <span class="ar">أَبْرَهَ</span>: <span class="auth">(Mṣb:)</span> this they assert on the ground of the opinion that <span class="ar">بُرْهَانٌ</span> <span class="add">[q. v.]</span> is of the measure <span class="ar">فُعْلَانٌ</span>; but J holds the <span class="ar">ن</span> to be a radical. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="burohaAnN.1">
				<h3 class="entry"><span class="ar">بُرْهَانٌ</span></h3>
				<div class="sense" id="burohaAnN.1_A1">
					<p><span class="ar">بُرْهَانٌ</span> <em>An evidence,</em> or a <em>proof:</em> <span class="auth">(T, Ṣ, Mṣb, Ḳ, and Ḥam p. 7:)</span> and a <em>demonstration;</em> i. e. the <em>manifestation of an evidence</em> or <em>proof:</em> <span class="auth">(Mṣb:)</span> or <em>a decisive and manifest evidence</em> or <em>proof:</em> <span class="auth">(TA:)</span> or the <em>firmest, strongest,</em> or <em>most valid, evidence</em> or <em>proof;</em> which is <em>such as ever necessarily implies truth,</em> or <em>veracity, as its consequence,</em> or <em>concomitant;</em> for evidences, or proofs, are of five sorts; whereof this is one; another is that which ever necessarily implies falsity, or falsehood, as its consequence, or concomitant; another, that which is nearer to truth, or veracity; another, that which is nearer to falsity, or falsehood; and another, that which is intermediate between these two: <span class="auth">(Er-Rághib, TA:)</span> <span class="add">[pl. <span class="ar">بَرَاهِينُ</span>:]</span> some say that the <span class="ar">ن</span> in this word is augmentative; <span class="auth">(Mṣb, and Ḥam p. 7;)</span> that it is of the measure <span class="ar">فُعْلَانٌ</span>, from <span class="ar">البره</span> <span class="add">[app. <span class="ar">البَرْهُ</span>]</span> signifying the “act of cutting:” <span class="auth">(Ḥam ubi suprà:)</span> others, that it is radical: Az mentions both of these opinions: <span class="pb" id="Page_0197"></span>J confines himself to the latter opinion: Z, to the former, saying, on the authority of IAạr, that the word is derived from <span class="ar">بَرَهْرَهَةٌ</span>, meaning “white,” <span class="add">[or “fair in complexion,”]</span> applied to a girl: <span class="auth">(Mṣb:)</span> Abu-l-Fet-ḥ <span class="add">[i. e. IJ]</span> says that he holds it to be of the measure <span class="ar">فُعْلَالٌ</span>, like <span class="ar">قُرْطَاسٌ</span> and <span class="ar">قُرْنَاسٌ</span>, the <span class="ar">ن</span> not being augmentative, as is shown by the verb above mentioned: <span class="auth">(Ḥam ubi suprà:)</span> but <span class="add">[it has been stated above that]</span> this verb is said, on the authority of IAạr, to be post-classical. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0196.pdf" target="pdf">
							<span>Lanes Lexicon Page 196</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0197.pdf" target="pdf">
							<span>Lanes Lexicon Page 197</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
