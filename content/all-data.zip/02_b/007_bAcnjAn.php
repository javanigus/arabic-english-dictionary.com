<article class="root" id="Root_bAcnjAn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/006_bOj">بأج</a></span>
				<span class="ar">باذنجان</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/008_bOr">بأر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="baAcanojaAnN">
				<h3 class="entry"><span class="ar">بَاذَنْجَانٌ</span></h3>
				<div class="sense" id="baAcanojaAnN_A1">
					<p><span class="ar">بَاذَنْجَانٌ</span>, <span class="add">[or <span class="ar">بَاذِنْجَانٌ</span>, commonly pronounced in the present day <span class="ar">بَادنْجَان</span> and <span class="ar">بَيْدِنْجَان</span> and <span class="ar">بِيدِنْجَان</span>, from the Persian <span class="ar">بَادِنْكَانْ</span>,]</span> a word of well-known meaning, often mentioned by the author of the Ḳ, <span class="add">[in explaining the words <span class="ar">أَنَبٌ</span> and <span class="ar">حَدَقٌ</span> and <span class="ar">مَغْدٌ</span> and <span class="ar">وَغْدٌ</span>,]</span> but not in its proper place in the lexicon. <span class="auth">(TA.)</span> <span class="add">[It signifies The <em>solanum melongena, mad-apple,</em> or <em>egg-plant;</em> both the <em>black,</em> distinguished by the epithet <span class="ar">أَسْوَدُ</span>, and the <em>white,</em> distinguished by the epithet <span class="ar">أَبْيَضُ</span>. And the <em>solanum lycopersicum,</em> or <em>solanum Aethiopicum;</em> also called <em>love-apple,</em> and so by the Arabs, <span class="ar long">تُفَّاحٌ الحُبِّ</span>; and <em>golden apple,</em> <span class="ar long">تُفَّاحٌ ذَهَبِىٌّ</span>; and <em>tomato;</em> and distinguished from the former species by the epithet <span class="ar">أَحْمَرُ</span>, and by the appellation <span class="ar long">باذنجان قُوطَة</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">باذنجان</span> - Entry: <span class="ar">بَاذَنْجَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAcanojaAnN_A2">
					<p><span class="add">[<span class="ar long">بَاذَنْجَانٌ تِرْيَاقِىٌّ</span> <em>Xanthium.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0145.pdf" target="pdf">
							<span>Lanes Lexicon Page 145</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
