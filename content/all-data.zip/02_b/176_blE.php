<article class="root" id="Root_blE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/175_blT">بلط</a></span>
				<span class="ar">بلع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/177_blEm">بلعم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="blE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بلع</span></h3>
				<div class="sense" id="blE_1_A1">
					<p><span class="ar">بَلِعَهُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَعُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَلْعٌ</span>, <span class="auth">(TA, <span class="add">[and the same is indicated in the Ḳ,]</span>)</span> or <span class="ar">بَلَعٌ</span> when the object is food, but <span class="ar">بَلْعٌ</span> when it is water or spittle; <span class="auth">(Mṣb;)</span> and <span class="ar">بَلَعَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْلَعُ</span>}</span></add>, inf. n. <span class="ar">بَلْعٌ</span>; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">ابتلعهُ↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">تبلّعهُ↓</span></span>; <span class="auth">(IAạr;)</span> and<span class="arrow"><span class="ar">بَلْعَمَهُ↓</span></span>, inf. n. <span class="ar">بَلْعَمَةٌ</span>; <span class="auth">(Ṣ * and TA in art. <span class="ar">بلعم</span>;)</span> <em>He swallowed it.</em> <span class="auth">(IAạr, TA.)</span> It is said in a proverb,<span class="arrow"><span class="ar long">لَا يَصْلُحُ رَفِيقًا مِنْ لمْ يَبْتَلِعْ↓ رِيقًا</span></span> <span class="add">[<em>He is not suitable,</em> or <em>fit, for being a companion who does not swallow his spittle;</em> meaning, † <em>who does not restrain his anger</em>]</span>. <span class="auth">(TA.)</span> You say also,<span class="arrow"><span class="ar long">بَلْعَمَ↓ اللُّقْمَةَ</span></span> meaning <em>He ate the morsel.</em> <span class="auth">(TA in art. <span class="ar">بلعم</span>.)</span> And <span class="ar long">بَلَعَ الطَّعَامَ</span> and<span class="arrow"><span class="ar">ابتلعهُ↓</span></span> also signify <span class="add">[<em>He swallowed the food without chewing it;</em>]</span> <em>he did not chew the food.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blE_2">
				<h3 class="entry">2. ⇒ <span class="ar">بلّع</span></h3>
				<div class="sense" id="blE_2_A1">
					<p><span class="ar long">بلّع الشَّيْبُ فِيهِ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">فِى رَأْسِهِ</span>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">تَبْلِيعٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>Hoariness began to appear</em> <span class="auth">(Ṣ, Ḳ)</span> <em>upon him,</em> <span class="auth">(Ḳ,)</span> or <em>upon his head:</em> <span class="auth">(Ṣ:)</span> or <em>rose:</em> <span class="auth">(A, TA:)</span> or <em>spread much.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#balBaga">See also <span class="ar">بَلَّغَ</span></a>.]</span> Hassán says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَدْ بَلَّعَتْ بِى ذُرْأَةٌ فَأَلْحَفَتْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Hoariness,</em> or <em>grayness,</em> or <em>the like, had begun to appear,</em>, &amp;c., <em>upon me, and marred me</em>]</span>; making the verb trans. by <span class="ar">بِ</span> because it has the meaning of <span class="ar long">قَدْ آلَمَتْ</span> <span class="add">[<em>it had given pain,</em> and this verb is thus made trans.]</span>; or substituting <span class="ar">بِى</span> for <span class="ar">فِىَّ</span> on account of the measure, which would not be right if he said <span class="ar">فِىَّ</span>. <span class="auth">(TA.)</span> You say also,<span class="arrow"><span class="ar long">تبلّع↓ فِيهِ الشَّيْبُ</span></span> <em>Hoariness appeared upon him.</em> <span class="auth">(IAạr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blE_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابلع</span></h3>
				<div class="sense" id="blE_4_A1">
					<p><span class="ar long">ابلعهُ الشَّىْءَ</span> <span class="auth">(Ṣ, Ḳ,* TA)</span> <em>He made him to swallow the thing:</em> <span class="auth">(Ṣ, TA:)</span> or <em>he enabled him to swallow the thing.</em> <span class="auth">(Ḳ,* TA.)</span> You say, <span class="ar long">أَبْلِعْنِى رِيقِى</span> <span class="add">[<em>Suffer thou me to swallow my spittle;</em>]</span> <em>give thou me time to swallow my spittle.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blE_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبلّع</span></h3>
				<div class="sense" id="blE_5_A1">
					<p><a href="#blE_1">see 1</a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="blE_5_B1">
					<p><a href="#blE_2">and 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="blE_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتلع</span></h3>
				<div class="sense" id="blE_8_A1">
					<p><a href="#blE_1">see 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="blE_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">بَلْعَمَ</span></h3>
				<div class="sense" id="blE_QQ1_A1">
					<p><span class="ar">بَلْعَمَ</span>: <a href="#blE_1">see 1</a>, in two places. <span class="add">[The <span class="ar">م</span> in this word is generally held to be augmentative: <a href="#baloEamN">see <span class="ar">بَلْعَمٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bulaEN">
				<h3 class="entry"><span class="ar">بُلَعٌ</span></h3>
				<div class="sense" id="bulaEN_A1">
					<p><span class="ar">بُلَعٌ</span>, applied to a man, <em>Voracious; a great eater;</em> as also<span class="arrow"><span class="ar">بُلَعَةٌ↓</span></span> and<span class="arrow"><span class="ar">مِبْلَعٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">بَوْلَعٌ↓</span></span>: <span class="auth">(IAạr, Ḳ:)</span> <span class="add">[<span class="arrow"><span class="ar">بَلَّاعْ↓</span></span> signifies the same:]</span> and<span class="arrow"><span class="ar">هِبْلَعٌ↓</span></span>, <span class="auth">(Ṣ and Ḳ in art. <span class="ar">هبلع</span>,)</span> in which the <span class="ar">ه</span> is said by some to be augmentative, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">هَبَلَّعٌ↓</span></span> <span class="auth">(Lth, Ḳ)</span> and<span class="arrow"><span class="ar">هِبْلَاعٌ↓</span></span>, <span class="auth">(IDrd, Ḳ,)</span> also signify the same; <span class="auth">(Ṣ in art. <span class="ar">هبلع</span>;)</span> or <em>voracious,</em> or <em>a great eater, who takes large mouthfuls, and is wide in the</em> <span class="ar">حُنْجُور</span> <span class="add">[app. here meaning the <em>fauces</em>]</span>: <span class="auth">(Lth, and Ḳ in art. <span class="ar">مبلع</span>:)</span> and<span class="arrow"><span class="ar">بُلَعَةٌ↓</span></span>, applied to a woman, one <em>who swallows everything.</em> <span class="auth">(Fr.)</span> <span class="arrow"><span class="ar long">يَا بَلَّاعَ↓ الأَيْرِ</span></span> <span class="add">[app. meaning <span class="ar long">يَا مَأْبُونُ</span>]</span> is an expression of vituperation used by the people of Syria. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بُلَعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bulaEN_A2">
					<p><span class="ar long">سَعْدُ بُلَعَ</span>, <span class="auth">(Lth, Ṣ, Ḳ,)</span> determinate, <span class="auth">(Lth, Ḳ,)</span> <span class="add">[the latter word imperfectly decl.,]</span> <em>One of the Mansions of the Moon;</em> <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[namely, <em>the Twenty-third;</em>]</span> which rose <span class="add">[aurorally]</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="pb" id="Page_0250"></span>as they assert, <span class="auth">(Ṣ,)</span> when God said, <span class="ar long">يَا أَرْضُ ٱبْلضعِى مَآءَكِ</span> <span class="add">[Ḳur xi. 46]</span>; <span class="auth">(Ṣ, Ḳ;)</span> <em>consisting of two stars near together;</em> <span class="auth">(Ṣ;)</span> or <em>two stars, straight</em> (<span class="ar">مُسْتَوِيَانِ</span>) <em>in course,</em> <span class="auth">(IḲt, Ḳ,)</span> or <em>near together and oblique;</em> <span class="auth">(TA;)</span> <em>one of them dim, and the other bright, and called</em> <span class="arrow"><span class="ar">بَالِعٌ↓</span></span>, as though it swallowed the former, <span class="auth">(IḲt, Ḳ, TA,)</span> namely, the dim one, and took its light: <span class="auth">(TA:)</span> it rises <span class="add">[aurorally]</span> in the last night but one <span class="add">[lit. one night remaining]</span> of <span class="ar long">كَانُون الآخِر</span> <span class="add">[Jan., O. Ṣ.]</span>, and sets <span class="add">[aurorally]</span> when one night has passed of <span class="ar">آب</span> <span class="add">[Aug., O. Ṣ.]</span>. <span class="auth">(IḲt, Ḳ.)</span> <span class="add">[Accord. to my calculation, it thus rose in Arabia about the commencement of the era of the Flight, on the 29th of Jan., O. Ṣ., and set aurorally on the 30th of July. <a href="#manaAzili">See <span class="ar long">مَنَازِلِ القَمَرِ</span></a>, <a href="index.php?data=25_n/110_nzl">in art. <span class="ar">نزل</span></a>: <a href="#saEodN">and see also <span class="ar">سَعْدٌ</span></a>.]</span> The rhyming-proser of the Arabs says, <span class="ar long">إِذَا طَلَعَ سَعْدُ بُلَعْ اِقْتَحَمَ الرُّبَعْ وَلَحِقَ الهُبَعْ وَصِيَدَ المُرَعْ وَصَارَ فِى الأَرْضِ لُمَعْ</span> <span class="add">[<em>When Saad-Bula' rises</em> aurorally,]</span> <em>the</em> <span class="ar">رُبَع</span> <span class="add">[or <em>young camel brought forth in the season called</em> <span class="ar">رَبِيع</span>, which is the beginning of the breeding-time,]</span> <em>becomes strong in his walk, and quick, but not strong to labour, and the</em> <span class="ar">هُبَع</span> <span class="add">[or <em>young camel brought forth in the end of the breeding-time</em>]</span> <em>acquires some strength, and attains to him, and the</em> <span class="ar">مُرَع</span>, a kind of bird, <em>is then,</em> it seems, <em>caught,</em> or <em>snared,</em> <span class="add">[<em>and parts differing in colour from the rest become apparent in the earth.</em>]</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بُلَعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bulaEN_B1">
					<p>Also The <em>hole,</em> or <em>perforation,</em> of the <span class="ar">بَكْرَة</span> <span class="add">[or sheave of a pulley]</span>: n. un. with <span class="ar">ة</span>: <span class="auth">(Ḳ:)</span> or the <em>hole,</em> or <em>perforation, in the</em> <span class="ar">قَامَة</span> <em>of the</em> <span class="ar">بَكْرَة</span> <span class="add">[which here means <em>the pulley,</em> or <em>sheave with its apparatus</em>]</span>: <span class="auth">(Ṣ:)</span> or<span class="arrow"><span class="ar">بُلَعَةُ↓</span></span> has this latter signification; and <span class="ar">بُلَعٌ</span> is its pl.; <span class="add">[or is a coll. gen. n.;]</span> so explained by Az; and this is the correct explanation. <span class="auth">(Marginal note in a copy of the Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buloEapN">
				<h3 class="entry"><span class="ar">بُلْعَةٌ</span></h3>
				<div class="sense" id="buloEapN_A1">
					<p><span class="ar">بُلْعَةٌ</span> <em>A gulp,</em> or <em>as much as one swallows at once,</em> of beverage; like <span class="ar">جُرْعَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulaEapN">
				<h3 class="entry"><span class="ar">بُلَعَةٌ</span></h3>
				<div class="sense" id="bulaEapN_A1">
					<p><span class="ar">بُلَعَةٌ</span>, as an epithet: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بُلَعَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bulaEapN_B1">
					<p>and as a subst.: <a href="#bulaEN">see the same</a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baloEamN">
				<h3 class="entry"><span class="ar">بَلْعَمٌ</span></h3>
				<div class="sense" id="baloEamN_A1">
					<p><span class="ar">بَلْعَمٌ</span>, applied to a man, <span class="auth">(Ṣ,)</span> <em>That eats much, and swallows food vehemently.</em> <span class="auth">(Ṣ, Ḳ *)</span> The <span class="ar">م</span> is augmentative, <span class="auth">(Ṣ,)</span> accord. to most authorities. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buloEumN">
				<h3 class="entry"><span class="ar">بُلْعُمٌ</span></h3>
				<div class="sense" id="buloEumN_A1">
					<p><span class="ar">بُلْعُمٌ</span>: <a href="#buloEuwmN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buloEuwmN">
				<h3 class="entry"><span class="ar">بُلْعُومٌ</span></h3>
				<div class="sense" id="buloEuwmN_A1">
					<p><span class="ar">بُلْعُومٌ</span> and<span class="arrow"><span class="ar">بُلْعُمٌ↓</span></span>; <span class="auth">(Mṣb, and Ṣ and Ḳ in art. <span class="ar">بلعم</span>;)</span> the latter a contraction of the former; the <span class="ar">م</span> augmentative; <span class="auth">(Mṣb;)</span> The <em>place of passage of the food in the</em> <span class="ar">حَلْق</span>; <span class="auth">(Ṣ, Mṣb, Ḳ, TA;)</span> the <em>gullet,</em> or <em>œsophagus;</em> <span class="auth">(Ṣ, Mṣb;)</span> as also<span class="arrow"><span class="ar">مَبْلَعٌ↓</span></span>: <span class="auth">(TA:)</span> or this last, <em>i. q.</em> <span class="ar">حَلْقٌ</span> <span class="add">[which is properly the <em>fauces;</em> but by a synecdoche, the <em>throat,</em> or <em>gullet</em>]</span>. <span class="auth">(Ḳ.)</span> <span class="add">[See an ex. voce <span class="ar">سُرْمٌ</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بُلْعُومٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="buloEuwmN_B1">
					<p>Also, the first, <em>A torrent, in ground such as is termed</em> <span class="ar">قُفّ</span>, <em>entering into the earth.</em> <span class="auth">(AḤn, and Ḳ in art. <span class="ar">بلعم</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بُلْعُومٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="buloEuwmN_C1">
					<p>And The <em>whiteness that is upon the lip of the ass,</em> <span class="auth">(Ḳ in art. <span class="ar">بلعم</span>,)</span> <em>at the extremity of the mouth-</em> <span class="auth">(TA in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baluwEN">
				<h3 class="entry"><span class="ar">بَلُوعٌ</span></h3>
				<div class="sense" id="baluwEN_A1">
					<p><span class="ar">بَلُوعٌ</span> a subst- signifying <em>A medicine which is swallowed.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بَلُوعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baluwEN_A2">
					<p><em>Beverage:</em> or <em>wine:</em> syn. <span class="ar">شَرَابٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بلع</span> - Entry: <span class="ar">بَلُوعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baluwEN_B1">
					<p><span class="ar long">قِدْرٌ بَلُوعٌ</span> ‡ <em>A wide cooking-pot,</em> <span class="auth">(A, Ḳ, TA,)</span> <em>that swallows what is thrown into it.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balBaAEN">
				<h3 class="entry"><span class="ar">بَلَّاعٌ</span></h3>
				<div class="sense" id="balBaAEN_A1">
					<p><span class="ar">بَلَّاعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balBaAEapN">
				<h3 class="entry"><span class="ar">بَلَّاعَةٌ</span></h3>
				<div class="sense" id="balBaAEapN_A1">
					<p><span class="ar">بَلَّاعَةٌ</span>: <a href="#baAluwEapN">see <span class="ar">بَالُوعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="balBuwEapN">
				<h3 class="entry"><span class="ar">بَلُّوعَةٌ</span></h3>
				<div class="sense" id="balBuwEapN_A1">
					<p><span class="ar">بَلُّوعَةٌ</span>: <a href="#baAluwEapN">see <span class="ar">بَالُوعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bulBayoEapN">
				<h3 class="entry"><span class="ar">بُلَّيْعَةٌ</span></h3>
				<div class="sense" id="bulBayoEapN_A1">
					<p><span class="ar">بُلَّيْعَةٌ</span>: <a href="#baAluwEapN">see <span class="ar">بَالُوعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAliEN">
				<h3 class="entry"><span class="ar">بَالِعٌ</span></h3>
				<div class="sense" id="baAliEN_A1">
					<p><span class="ar">بَالِعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bawolaEN">
				<h3 class="entry"><span class="ar">بَوْلَعٌ</span></h3>
				<div class="sense" id="bawolaEN_A1">
					<p><span class="ar">بَوْلَعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAluwEapN">
				<h3 class="entry"><span class="ar">بَالُوعَةٌ</span></h3>
				<div class="sense" id="baAluwEapN_A1">
					<p><span class="ar">بَالُوعَةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> of the dial. of El-Basrah, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بَلُّوعَةٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بَلَّاعَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بُلَّيْعَةٌ↓</span></span>, <span class="auth">(TA,)</span> <em>A hole,</em> or <em>perforation, in the midst of a house;</em> <span class="auth">(Ṣ;)</span> <em>a sink-hole; a hole,</em> or <em>perforation, into which water descends:</em> <span class="auth">(Mṣb:)</span> or <em>a well that is dug</em> <span class="auth">(Ḳ, TA)</span> <em>in the midst of a house,</em> <span class="auth">(TA,)</span> <em>narrow at the head, into which run the rain-water and the like:</em> <span class="auth">(Ḳ, TA:)</span> pl. <span class="add">[of the first]</span> <span class="ar">بَوَالِيعُ</span> <span class="auth">(Ṣgh, Ḳ)</span> and <span class="add">[of the others]</span> <span class="ar">بَلَالِيعُ</span>. <span class="auth">(Ṣ, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabolaEN">
				<h3 class="entry"><span class="ar">مَبْلَعٌ</span></h3>
				<div class="sense" id="mabolaEN_A1">
					<p><span class="ar">مَبْلَعٌ</span>: <a href="#buloEuwmN">see <span class="ar">بُلْعُومٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mibolaEN">
				<h3 class="entry"><span class="ar">مِبْلَعٌ</span></h3>
				<div class="sense" id="mibolaEN_A1">
					<p><span class="ar">مِبْلَعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubolaEapN">
				<h3 class="entry"><span class="ar">مُبْلَعَةٌ</span></h3>
				<div class="sense" id="mubolaEapN_A1">
					<p><span class="ar">مُبْلَعَةٌ</span> A well (<span class="ar">رَكِيَّةٌ</span>) <em>cased with stones,</em> or <em>with baked bricks, from the bottom to the brink:</em> <span class="auth">(O, TṢ, Ḳ:)</span> from Ibn-ʼAbbád. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="hibolaEN">
				<h3 class="entry"><span class="ar">هِبْلَعٌ</span></h3>
				<div class="sense" id="hibolaEN_A1">
					<p><span class="ar">هِبْلَعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="habalBaEN">
				<h3 class="entry"><span class="ar">هَبَلَّعٌ</span></h3>
				<div class="sense" id="habalBaEN_A1">
					<p><span class="ar">هَبَلَّعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="hibolaAEN">
				<h3 class="entry"><span class="ar">هِبْلَاعٌ</span></h3>
				<div class="sense" id="hibolaAEN_A1">
					<p><span class="ar">هِبْلَاعٌ</span>: <a href="#bulaEN">see <span class="ar">بُلَعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0249.pdf" target="pdf">
							<span>Lanes Lexicon Page 249</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0250.pdf" target="pdf">
							<span>Lanes Lexicon Page 250</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
