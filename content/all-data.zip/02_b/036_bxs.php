<article class="root" id="Root_bxs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/035_bxr">بخر</a></span>
				<span class="ar">بخس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/037_bxS">بخص</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxs_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخس</span></h3>
				<div class="sense" id="bxs_1_A1">
					<p><span class="ar">بَخَسَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَسُ</span>}</span></add>, inf. n. <span class="ar">بَخْسٌ</span>, <em>He diminished it; lessened it; made it deficient,</em> or <em>defective:</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ:)</span> or <em>he made it faulty.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">بَخَسَ الكَيَّالُ</span> <span class="add">[for <span class="ar long">بَخَسَ الكَيَّالُ الكَيْلَ</span> <em>The measurer made defective measure</em>]</span>. <span class="auth">(A.)</span> And of a just sale, <span class="ar long">لَا بَخْسَ فِيهِ وَلَا شَطَطَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">وَلَا شُطُوطَ</span>, <span class="auth">(T, TA,)</span> <span class="add">[<em>There is no deficiency in it nor excess.</em>]</span> And it is said in the Ḳur <span class="add">[lxxii. 13]</span>, <span class="ar long">فَلَا يَخَافُ بَخْسًا وَلَا رَهَقًا</span> <em>He shall not fear diminution</em> of the reward of his actions, <em>nor wrong,</em> or <em>injustice.</em> <span class="auth">(TA.)</span> And in this sense, <span class="add">[as also in the next,]</span> the verb is doubly trans. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">بَخَسَهُ حَقَّهُ</span> <em>He diminished to him his right,</em> or <em>due; deprived him,</em> or <em>defrauded him, of a part of it.</em> <span class="auth">(Ṣ, A.)</span> And it is said in the Ḳur <span class="add">[vii. 83 and xi. 86 and xxvi. 183]</span>, <span class="ar long">وَلَا تَبْخَسُوا النَّاسَ أَشْيَآءَهُمْ</span> <span class="add">[<em>And ye shall not diminish unto men their things</em>]</span>: <span class="auth">(Mṣb:)</span> or the verb in this instance has the signification next following. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bxs_1_A2">
					<p><em>He wronged him; acted wrongfully,</em> or <em>unjustly, towards him.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بخس</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bxs_1_B1">
					<p><span class="ar long">بَخَسَ عَيْنَهُ</span>: <a href="#baxaSa">see <span class="ar">بَخَصَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxs_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباخس</span></h3>
				<div class="sense" id="bxs_6_A1">
					<p><span class="ar">تباخسوا</span> <em>They defrauded one another in a sale.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxosN">
				<h3 class="entry"><span class="ar">بَخْسٌ</span></h3>
				<div class="sense" id="baxosN_A1">
					<p><span class="ar">بَخْسٌ</span> <em>Deficient; defective.</em> <span class="auth">(Ṣ.)</span> It is said in the Ḳur <span class="add">[xii. 20]</span>, <span class="ar long">وَشَرَوْهُ بِثَمَنٍ بَخْسٍ</span> <em>And they sold him for a deficient,</em> or <em>defective, price:</em> <span class="auth">(Ṣ,* Mṣb,* TA:)</span> or <em>for a price less than was incumbent:</em> or <em>for an insufficient price:</em> or <em>for an unjust price;</em> accord. to Zj; because the sale of a man that has been found is unlawful. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بخس</span> - Entry: <span class="ar">بَخْسٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baxosN_B1">
					<p><em>Land that produces herbage without being</em> <span class="add">[<em>artificially</em>]</span> <em>watered:</em> <span class="auth">(JK, Ṣ, Ḳ:)</span> or <em>land which is watered by the rain;</em> because it has deficient watering: <span class="auth">(Mgh:)</span> pl. <span class="ar">بُخُوسٌ</span>. <span class="auth">(JK, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخس</span> - Entry: <span class="ar">بَخْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baxosN_B2">
					<p>Also, <span class="auth">(TA, as from Ibn-Málik,)</span> or<span class="arrow"><span class="ar">بَخْسِىٌّ↓</span></span>, <span class="add">[which is more probably the correct form,]</span> a rel. n. from <span class="ar">بَخْسٌ</span> in the sense immediately preceding, explained in the T as signifying, <span class="auth">(Mgh,)</span> Seed-produce <em>that is not irrigated with water from a spring or well or the like, but only by the rain.</em> <span class="auth">(Mgh, and TA from Ibn-Málik.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baxosieBN">
				<h3 class="entry"><span class="ar">بَخْسِىٌّ</span></h3>
				<div class="sense" id="baxosieBN_A1">
					<p><span class="ar">بَخْسِىٌّ</span>: <a href="#baxosN">see <span class="ar">بَخْسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAxisN">
				<h3 class="entry"><span class="ar">بَاخِسٌ</span></h3>
				<div class="sense" id="baAxisN_A1">
					<p><span class="ar">بَاخِسٌ</span> Any one <em>who acts wrongfully,</em> or <em>unjustly.</em> <span class="auth">(TA.)</span> It is said in a prov., <span class="ar long">تَحْسِبُهَا حَمْقَآءَ وَهِىَ بَاخِسٌ</span>; <span class="auth">(Ṣ, A, Ḳ;)</span> so runs the prov.; but accord. to Th, <span class="auth">(Ṣ,)</span> you may also say <span class="ar">بَاخِسَةٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> i. e., <span class="add">[<em>Thou thinkest her stupid,</em>]</span> <em>but she is wrongful,</em> or <em>unjust:</em> applied to him who feigns himself to be of weak understanding when he is crafty and cunning. <span class="auth">(Ḳ, TA.)</span> The origin of the prov. was this: a man of the Benu-l-'Ambar, of Temeem, mixed his property with that of a woman, coveting the possession of it, and thinking that she was stupid, and that she did not take care of her property nor know it: then he made a division with her, after he had mixed; but she was not content with the division until she took her property: she complained of him to those in authority, so that he released himself from her by giving her what she desired of the property: and the man was reproved for his conduct; it being said to him, “Thou cheatest a woman: is not this wrongful conduct (<span class="ar">بَخْس</span>)?” whereupon he replied in the words above, which became a proverb. <span class="auth">(Th, Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0159.pdf" target="pdf">
							<span>Lanes Lexicon Page 159</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
