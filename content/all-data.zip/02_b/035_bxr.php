<article class="root" id="Root_bxr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/034_bxtr">بختر</a></span>
				<span class="ar">بخر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/036_bxs">بخس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخر</span></h3>
				<div class="sense" id="bxr_1_A1">
					<p><span class="ar long">بَخَرَتِ القِدْرُ</span>, <span class="auth">(Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْخُرُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> or <span class="ar">ـَ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَخْرٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">بُخَارٌ</span>, <span class="auth">(TA,)</span> <em>The cooking-pot sent up fume, vapour, steam,</em> or <em>an exhalation.</em> <span class="auth">(Mṣb, Ḳ.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بخر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bxr_1_B1">
					<p><span class="ar">بَخِرَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْخَرُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَخَرٌ</span>, <span class="auth">(TA,)</span> <em>He had a stinking mouth</em> <span class="add">[or <em>breath; he exhaled a stinking,</em> or <em>fetid, odour from his mouth</em>]</span>. <span class="auth">(Ṣ, L, Ḳ.)</span> You say, <span class="ar long">بَخِرَتٌ عَلَيْنَا</span> <em>She exhaled a stinking,</em> or <em>fetid, odour upon us from her mouth.</em> <span class="auth">(A. <span class="add">[But in my copy of that work, and in the TA, it is erroneously written <span class="ar">بَخَرَتْ</span>.]</span>)</span> And <span class="ar long">بَخِرَ الفَمُ</span>, aor. and inf. n. as above, <em>The mouth stank; exhaled a stinking,</em> or <em>fetid, odour.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#baxarN">See <span class="ar">بَخَرٌ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بخّر</span></h3>
				<div class="sense" id="bxr_2_A1">
					<p><span class="ar">بخّرت</span> <em>She perfumed</em> <span class="add">[or rather <em>fumigated</em> her own or another's person or clothes, &amp;c. with <span class="ar">بَخُور</span>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابخر</span></h3>
				<div class="sense" id="bxr_4_A1">
					<p><span class="ar">ابخرهُ</span> <em>It</em> <span class="auth">(a thing)</span> <em>caused him to have a stinking mouth</em> <span class="add">[or <em>breath</em>]</span>. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبخّر</span></h3>
				<div class="sense" id="bxr_5_A1">
					<p><span class="ar">تبخّر</span> <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> <em>He fumigated himself</em> with perfume or the like; <span class="auth">(TA;)</span> with <span class="ar">بَخُور</span>. <span class="auth">(Ṣ, A, Ḳ.)</span> <span class="pb" id="Page_0159"></span>One says, <span class="ar long">فُلَانٌ يَتَبَخَّرُ وَيَبَخْتَرُ</span> <span class="add">[<em>Such a one fumigates himself</em> with perfume, <em>and walks with an elegant and a proud and self-conceited gait, with an affected inclining of his body from side to side</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxarN">
				<h3 class="entry"><span class="ar">بَخَرٌ</span></h3>
				<div class="sense" id="baxarN_A1">
					<p><span class="ar">بَخَرٌ</span> <em>Stench,</em> or <em>fetor, of the mouth</em> <span class="add">[or <em>breath</em>]</span> <span class="auth">(Ṣ, A, Ḳ)</span> <em>&amp;c.:</em> <span class="auth">(AḤn, Ḳ:)</span> and <em>any odour that rises and diffuses itself,</em> <span class="auth">(Ḳ, TA,)</span> <em>whether stinking or not;</em> as also<span class="arrow"><span class="ar">بُخَارٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buxaArN">
				<h3 class="entry"><span class="ar">بُخَارٌ</span></h3>
				<div class="sense" id="buxaArN_A1">
					<p><span class="ar">بُخَارٌ</span> <span class="add">[<em>Fume, vapour, steam,</em> or <em>exhalation;</em>]</span> <em>what rises from water, like smoke;</em> <span class="auth">(Ṣ;)</span> <em>any fume</em> <span class="auth">(Ḳ, TA)</span> <em>that rises and diffuses itself</em> <span class="auth">(TA)</span> <em>from what is hot,</em> <span class="auth">(Ḳ, TA,)</span> or <em>from hot water;</em> <span class="auth">(TA;)</span> <em>anything that rises and diffuses itself from hot water</em> or <em>from damp earth:</em> pl. <span class="ar">أَبْخِرَةٌ</span> and <span class="ar">بُخَارَاتٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخر</span> - Entry: <span class="ar">بُخَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buxaArN_A2">
					<p>Also The <em>stench</em> of a noiseless emission of wind from the anus. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخر</span> - Entry: <span class="ar">بُخَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buxaArN_A3">
					<p><a href="#baxarN">See also <span class="ar">بَخَرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxuwrN">
				<h3 class="entry"><span class="ar">بَخُورٌ</span></h3>
				<div class="sense" id="baxuwrN_A1">
					<p><span class="ar">بَخُورٌ</span> <em>Incense,</em> or <em>a substance for fumigation;</em> syn. <span class="ar">دُخْنَةٌ</span>; <span class="auth">(Mṣb;)</span> <em>that with which one fumigates himself:</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ:)</span> <em>aloes-wood used for that purpose.</em> <span class="auth">(TA in art. <span class="ar">قتر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخر</span> - Entry: <span class="ar">بَخُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baxuwrN_A2">
					<p><span class="ar long">بَخُورُ مَرْيَمَ</span> <span class="add">[<em>Arthanita,</em> or <em>sow-bread; the common cyclamen;</em> also called <span class="ar">الوَلْفُ</span>; the latter name, accord. to Golius, on the authority of Zeyn El-'Attár, given to it by the Syrians;]</span> <em>a certain plant,</em> <span class="auth">(Ḳ,)</span> <em>originally called</em> <span class="ar">عَرْطَنِيثَا</span>; <em>hot; dry;</em> <span class="auth">(TA;)</span> <em>having the property of clearing the complexion,</em> or <em>skin; aperient; diuretic;</em> <span class="auth">(Ḳ;)</span> <em>laxative;</em> <span class="auth">(TA;)</span> <em>and very useful:</em> <span class="auth">(Ḳ:)</span> it is a laxative when used in the form of a suppository, or applied as a liniment below the navel. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaboxaru">
				<h3 class="entry"><span class="ar">أَبْخَرُ</span></h3>
				<div class="sense" id="Oaboxaru_A1">
					<p><span class="ar">أَبْخَرُ</span> <em>Having a stinking mouth</em> <span class="add">[or <em>breath</em>]</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> fem. <span class="ar">بَخْرَآءُ</span>: and pl. <span class="ar">بُخْرٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboxarapN">
				<h3 class="entry"><span class="ar">مَبْخَرَةٌ</span></h3>
				<div class="sense" id="maboxarapN_A1">
					<p><span class="ar">مَبْخَرَةٌ</span> <em>A thing that occasions one's knowing,</em> or <em>inferring,</em> or <em>suspecting, stench,</em> or <em>fetor, of the mouth</em> <span class="add">[or <em>breath; a cause of stench,</em> or <em>fetor, of the mouth</em> or <em>breath</em>]</span>: such is said to be the sleeping between daybreak and sunrise, or in the first part of the day. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboxarapN">
				<h3 class="entry"><span class="ar">مِبْخَرَةٌ</span></h3>
				<div class="sense" id="miboxarapN_A1">
					<p><span class="ar">مِبْخَرَةٌ</span> <em>A vessel for fumigation; a censer;</em> syn. <span class="ar">مِجْمَرَةٌ</span> <span class="add">[q. v.: pl. <span class="ar">مَبَاخِرُ</span>]</span>. <span class="auth">(Mṣb in art. <span class="ar">جمر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaxBarN">
				<h3 class="entry"><span class="ar">مُبَخَّرٌ</span></h3>
				<div class="sense" id="mubaxBarN_A1">
					<p><span class="ar">مُبَخَّرٌ</span> A garment <em>perfumed</em> <span class="add">[or rather <em>fumigated</em> with perfume]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboxuwrN">
				<h3 class="entry"><span class="ar">مَبْخُورٌ</span></h3>
				<div class="sense" id="maboxuwrN_A1">
					<p><span class="ar">مَبْخُورٌ</span><span class="add">[<em>Affected by the fumes of wine</em>, &amp;c.; or]</span> <em>affected with pain and headache occasioned by wine,</em> or <em>with the remains of intoxication.</em> <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0158.pdf" target="pdf">
							<span>Lanes Lexicon Page 158</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0159.pdf" target="pdf">
							<span>Lanes Lexicon Page 159</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
