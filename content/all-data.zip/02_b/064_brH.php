<article class="root" id="Root_brH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/063_brjm">برجم</a></span>
				<span class="ar">برح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/065_brd">برد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brH_1">
				<h3 class="entry">1. ⇒ <span class="ar">برح</span></h3>
				<div class="sense" id="brH_1_A1">
					<p><span class="ar">بَرِحَ</span> is <em>syn. with</em> <span class="ar">زَالَ</span> <span class="add">[in two senses; i. e. as an attributive verb, and also as a non-attributive verb; as will be shown by what follows]</span>. <span class="auth">(Ṣ, A, Mgh.)</span> <span class="add">[Using it as an attributive verb,]</span> you say, <span class="ar long">لَا أَبْرَحُ حَتَّى تَقْضِىَ حَاجَتِى</span> <em>I will not go away,</em> or <em>depart,</em> or <em>withdraw,</em> (<span class="ar long">لَا أَزُولٌ</span>, and <span class="ar long">لَا أَتَنَحَّىِ</span>,) <em>until thou accomplish my want:</em> from <span class="ar long">بَرِحَ المَكَانُ</span>, inf. n. <span class="ar">بَرَاحٌ</span>, <em>he went away,</em> or <em>departed, from the place;</em> syn. <span class="ar long">زَالَ مِنْهُ</span>: and to be distinguished from the phrase in the Ḳur <span class="add">[xviii. 59, similar as to words,]</span> mentioned below. <span class="auth">(Mgh.)</span> You say, <span class="ar long">بَرِحَ مَكَانَهُ</span>, <span class="auth">(Ṣ, A, L, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَحُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَرَاحٌ</span> <span class="auth">(Ṣ, L, Ḳ)</span> and <span class="ar">بُرُوحٌ</span> <span class="auth">(L, TA, and Ḥam p. 250)</span> and <span class="ar">بَرَحٌ</span>, <span class="auth">(L,)</span> or <span class="ar">بَرْحٌ</span>, <span class="auth">(as in a copy of the TA,)</span> <em>He went away,</em> or <em>departed, from his place;</em> <span class="auth">(Ṣ, L, Ḳ, and Ḥam ubi suprà;)</span> and <em>he became in the</em> <span class="ar">بَرَاح</span> <span class="add">[or <em>wide, uncultivated,</em> or <em>uninhabited, tract</em>]</span>. <span class="auth">(Ṣ, L, Ḳ.)</span> And <span class="ar long">مَا بَرِحَ مَكَانَهُ</span> <em>He did not quit his place.</em> <span class="auth">(Mṣb.)</span> And <span class="ar">بَرِحَ</span> <span class="add">[alone]</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَحُ</span>}</span></add>, inf. n. <span class="ar">بَرَاحٌ</span>, <em>It</em> <span class="auth">(a thing)</span> <em>went away,</em> or <em>departed,</em> (<span class="ar">زَالَ</span>,) <em>from its place;</em> <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">تبرّح↓</span></span>. <span class="auth">(L.)</span> In the phrase <span class="ar long">لَا بَرَاحَ</span> <span class="add">[<em>There is,</em> or <em>shall be, no quitting of place,</em> or <em>going away,</em> or <em>departing</em>]</span>, the noun is in the accus. case, as in <span class="ar long">لَا رَيْبَ</span>: but it is allowable to put it in the nom. case, so that <span class="ar">لا</span> is used in the manner of <span class="ar">لَيْسَ</span>; <span class="auth">(Ṣ, Ḳ;)</span> as in the following saying of Saạd Ibn-Málik, <span class="add">[in the TA, in one place, Ibn-Náshib,]</span> in a poem of which the rhyme is with refa, <span class="auth">(Ṣ, IAth,)</span> alluding to El-Hárith Ibn-ʼAbbád, who had withdrawn himself from the war of Teghlib and Bekr the sons of Wáïl: <span class="auth">(IAth, TA:)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَنْ فَرَّعَنْ نِيرَانِهَا</span> *</div> 
						<div class="star">* <span class="ar long">فَأَنَا ٱبْنُ قَيْسٍ لَا بَرَاحُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Whoso fleeth from its fires,</em> <span class="auth">(i. e. <span class="ar long">نِيرَانِ الحَرْبِ</span> <em>the fires of the war,</em>)</span> let him do so: <em>but</em> as for me, <em>I am the son of Keys:</em> to me <em>there is not,</em> or <em>shall not be, any quitting of place</em>]</span>. <span class="auth">(Ṣ, IAth. <span class="add">[See also Ḥam p. 250, where, for <span class="ar long">مَن فَرَّ</span>, we find <span class="ar long">مَنْ صَدَّ</span> <em>whoso turneth away.</em>]</span>)</span> <span class="add">[Hence,]</span> <span class="ar long">بَرِحَتِ الرِّيحُ بِالتُّرَابِ</span> <em>The wind carried up, raised,</em> or <em>swept up and scattered,</em> <span class="add">[lit. <em>went away with,</em>]</span> <em>the dust.</em> <span class="auth">(Mṣb.)</span> <span class="add">[Hence also, accord. to some,]</span> <span class="ar long">بَرِحَ الخَفَآءُ</span>, <span class="auth">(T, Ṣ, Ḳ, &amp;c.,)</span> and <span class="ar">بَرَحَ</span>, <span class="auth">(Ibn-El-Lihyánee, Z, and TA, <span class="add">[thus written in a copy of the A,]</span>)</span> ‡ <em>The state of concealment departed,</em> or <em>ceased:</em> or ‡ <em>what was in a state of concealment became apparent;</em> from <span class="ar">بَرَاحٌ</span> meaning “what is open and apparent” of land: or ‡ <em>what I was concealing became apparent:</em> <span class="auth">(T, TA:)</span> or ‡ <em>the affair,</em> or <em>case, became manifest,</em> <span class="auth">(Ṣ, A, Ḳ,)</span> and <em>its concealment ceased,</em> <span class="auth">(A,)</span> <span class="add">[or]</span> <em>as though the secret departed, and ceased:</em> <span class="auth">(Ṣ:)</span> or, as some say, † <em>the secret became apparent:</em> <span class="auth">(TA in art. <span class="ar">خفى</span>:)</span> or, lit., <em>the low ground became high and apparent;</em> meaning † <em>what was concealed became revealed:</em> <span class="auth">(Ḥar pp. 133-4:)</span> the first who said it was Shikk the Diviner. <span class="auth">(IDrd, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brH_1_A2">
					<p><span class="add">[Using it as a non-attributive verb,]</span> you say, <span class="ar long">لَا أَبْرَحُ أَفْعَلُ ذٰلِكَ</span> <em>I will not cease,</em> or <em>I will continue,</em> (<span class="ar long">لَا أَزَالُ</span>,) <em>to do that:</em> <span class="auth">(Ṣ, A:*)</span> and <span class="ar long">مَا بَرِحَ يَفْعَلُ كَذَا</span> <span class="add">[<em>he ceased not to do thus;</em> or]</span> <em>he persevered in,</em> or <em>kept to, doing thus:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">مَا بَرِحَ زَيْدٌ قَائِمًا</span> <span class="add">[<em>Zeyd ceased not to be,</em> or <em>he kept,</em> or <em>continued, standing</em>]</span>: in this case, the verb is of the category of <span class="ar">كَانَ</span>; <span class="auth">(Mgh;)</span> relates to time; and requires a predicate: and its inf. n. is <span class="ar">بَرَاحٌ</span>. <span class="auth">(Ḥam p. 250.)</span> Hence the saying in the Ḳur <span class="add">[xviii. 59]</span>, <span class="ar long">لَا أَبْرَاحُ حَتَّى أَبْلُغَ مَجْمَعَ البَحْرَيْنِ</span>, but the predicate is suppressed: it may be <span class="ar long">مَا نَحْنُ فِيهِ كَذٰلِكَ</span> <span class="add">[i. e. <em>I will not cease in that wherein we are thus engaged until I reach the place of meeting of the two seas</em>]</span>: <span class="auth">(Mgh:)</span> or it means <span class="ar long">لَا أَزَالُ أَسِيرُ</span> <span class="add">[<em>I will not cease journeying</em>]</span>: <span class="auth">(Bḍ, Jel:)</span> or <span class="ar long">لا ابرح</span> here may mean <em>I will not depart</em> (<span class="ar long">لَا أَزُولُ</span>) <em>from that upon which I am intent,</em> namely journeying and seeking; and <em>I will not relinquish it;</em> so that it does not require the predicate. <span class="auth">(Bḍ. <span class="add">[He gives a third explanation, paraphrastic and strained, which I omit.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brH_1_B1">
					<p><span class="ar">بَرَحَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَحُ</span>}</span></add> <span class="auth">(L, TA, <span class="add">[but it is implied in the Ḳ that it is <span class="ar">ـُ</span>, which is contr. to rule,]</span>)</span> inf. n. <span class="ar">بُرُوحٌ</span>, <em>It</em> <span class="auth">(a gazelle, Ṣ, Ḳ, and a bird, and any wild animal, that is hunted or shot, TA)</span> <em>turned its left side towards the spectator, passing by</em> <span class="auth">(Ṣ, Ḳ *)</span> <em>from the direction of his right hand towards that of his left hand:</em> <span class="auth">(Ṣ:)</span> or <em>passed by from the direction of the spectator's left hand towards that of his right hand:</em> <span class="auth">(Aboo-ʼAmr Esh-Sheybánee, IF, L, Mṣb, in art. <span class="ar">سنح</span>:)</span> <span class="add">[the former appears to be accord. to the usage of the Hijázees; and the latter, accord. to that of the Nejdees, in general: <a href="#baAriHN">see <span class="ar">بَارِحٌ</span></a>:]</span> <a href="#sanaHa">contr. of <span class="ar">سَنَحَ</span></a>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brH_1_C1">
					<p><span class="ar">بَرَحَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُحُ</span>}</span></add>, <span class="add">[contr. to rule,]</span> <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَرْحٌ</span>, <span class="auth">(TA,)</span> <em>He was angry.</em> <span class="auth">(Ḳ.)</span> When a man has been angry with his companion, one says, <span class="ar long">مَا أَشَدَّ مَا بَرَحَ عَلَيْهِ</span> <span class="add">[<em>How violently angry was he with him!</em>]</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brH_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّح</span></h3>
				<div class="sense" id="brH_2_A1">
					<p><span class="ar long">بَرَّحَتْ بِيَ الحُمَّى</span> <em>The fever affected me with its severity, violence,</em> or <em>sharpness, termed</em> <span class="ar">بُرَحَآءُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brH_2_A2">
					<p>Hence, <span class="auth">(TA,)</span> from <span class="ar">بُرَحَآءُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="ar long">برّح بِهِ</span>, inf. n. <span class="ar">تَبْرِيحٌ</span>, <em>It</em> <span class="auth">(an affair, an event, or a case,)</span> <em>affected him severely; afflicted, distressed,</em> or <em>harassed, him:</em> <span class="auth">(Ṣ, Ḳ:)</span> said also of anxiety; or disquietude, or trouble, of mind: <span class="auth">(A:)</span> and of a beating, meaning <em>it hurt him severely,</em> or <em>greatly.</em> <span class="auth">(Mṣb.)</span> Also said of a man, meaning <em>He importuned him,</em> or <em>pressed him, with annoyance,</em> or <em>molestation:</em> <span class="auth">(A, TA:)</span> <em>he annoyed him,</em> or <em>molested him, by importuning</em> or <em>pressing;</em> as also<span class="arrow"><span class="ar">ابرح↓</span></span>: <span class="auth">(TA:)</span> <em>he annoyed him,</em> or <em>molested him, by distressing importunity</em> or <em>pressing:</em> <span class="auth">(T, TA:)</span> and <em>he punished, tormented,</em> or <em>tortured, him.</em> <span class="auth">(TA.)</span> <span class="ar">تَبْرِيحٌ</span> signifies The act of <em>annoying, molesting,</em> or <em>hurting:</em> <span class="auth">(Mgh:)</span> and in a trad., <span class="auth">(in which it is forbidden, TA,)</span> the <em>killing,</em> or <em>putting to death, in an evil</em> <span class="add">[or <em>a cruel</em>]</span> <em>manner; such as throwing live fish, and lice, into the fire.</em> <span class="auth">(Mgh, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brH_2_B1">
					<p><span class="ar long">بَرَّحَ ٱللّٰهُ عَنْكَ</span> <em>May God remove from thee</em> <span class="ar">البَرْح</span> <span class="add">[i. e. <em>difficulty, distress, affliction, &amp;c.,</em> or <em>the difficulty,</em>, &amp;c.]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brH_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرح</span></h3>
				<div class="sense" id="brH_4_A1">
					<p><span class="ar">ابرحهُ</span> <em>He made him,</em> or <em>caused him, to go away from, depart from,</em> or <em>quit, his place.</em> <span class="auth">(A,* L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brH_4_B1">
					<p><em>He,</em> or <em>it, pleased,</em> or <em>rejoiced, him; excited his admiration and approval; induced in him wonder,</em> or <em>admiration, and pleasure,</em> or <em>joy.</em> <span class="auth">(Ṣ, Ḳ.)</span> One says also, <span class="ar long">مَا أَبْرَحَ هٰذَا الأَمْرَ</span> <em>How greatly does this affair,</em> or <em>event, please,</em> or <em>rejoice! how greatly does it excite admiration and approval!</em> or <em>how greatly does it induce wonder,</em> or <em>admiration, and pleasure,</em> or <em>joy!</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brH_4_B2">
					<p><em>He treated him with honour,</em> or <em>honoured him,</em> and <em>magnified him:</em> <span class="auth">(Ṣ, Ḳ:)</span> or, as some say, <em>he found him to be generous,</em> or <em>noble.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="brH_4_B3">
					<p><em>He judged him,</em> or <em>it,</em> i. e. a man, <span class="auth">(A, TA,)</span> and a horse, <span class="auth">(A,)</span> or anything, <span class="auth">(TA,)</span> <em>to be excellent,</em> or <em>to excel,</em> <span class="auth">(A, TA,)</span> <em>and wondered at,</em> or <em>admired, him,</em> or <em>it.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brH_4_C1">
					<p><span class="ar">ابرح</span> also signifies <em>He exceeded the usual bounds, degree,</em> or <em>mode.</em> <span class="auth">(Aṣ, Ṣ,* TA.)</span> You say, <span class="ar long">أَبْرَحْتَ كَرَمًا</span>, and <span class="ar">لُؤْمًا</span>, <span class="auth">(A, TA,)</span> <em>Thou hast done a thing exceeding the usual bounds</em> <span class="add">[<em>in generosity,</em> or <em>nobleness,</em> and <em>in meanness,</em> or <em>ignobleness</em>]</span>; or <em>extravagant;</em> or <em>excessive.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="brH_4_C2">
					<p><a href="#brH_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brH_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّح</span></h3>
				<div class="sense" id="brH_5_A1">
					<p><a href="#brH_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroHN">
				<h3 class="entry"><span class="ar">بَرْحٌ</span></h3>
				<div class="sense" id="baroHN_A1">
					<p><span class="ar">بَرْحٌ</span> <em>Difficulty, distress, affliction,</em> or <em>adversity; evil,</em> or <em>mischief;</em> <span class="auth">(Ḳ, TA;)</span> <em>annoyance, molestation,</em> or <em>hurt; severe punishment; trouble, inconvenience,</em> or <em>fatigue;</em> <span class="auth">(TA;)</span> <em>a difficult, a distressing, an afflictive,</em> or <em>adverse, and a wonderful, thing</em> or <em>event:</em> <span class="auth">(Ḥam p. 135:)</span> and <em>annoyance,</em> or <em>molestation, by distressing importunity</em> or <em>pressing;</em> a subst. from 2: <span class="auth">(T, TA:)</span> and <span class="ar long">بِنْتُ بَرْحٍ</span>, <span class="add">[and app. <span class="ar long">اِبْنُ بَرْحٍ</span> also,]</span> <em>a calamity, misfortune,</em> or <em>disaster;</em> or <em>a great,</em> or <em>terrible, thing, affair,</em> or <em>case;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar long">بِنْتُ بَارِحٍ↓</span></span>, and<span class="arrow"><span class="ar long">اِبْنُ بَرِيحٍ↓</span></span>; <span class="auth">(Ḳ;)</span> pl. <span class="ar long">بَنَاتُ بَرْحٍ</span> and <span class="ar long">بَنُو بَرْحٍ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#taboriyHN">See also <span class="ar">تَبْرِيحٌ</span></a>.]</span> You say,<span class="arrow"><span class="ar long">لَقِيتُ مِنْهُ بَرْحًا بَارِحًا↓</span></span> <em>I experienced from him,</em> or <em>it,</em> <span class="add">[<em>great</em>]</span> <em>difficulty, distress, affliction,</em> or <em>adversity;</em> <span class="add">[<em>great</em>]</span> <em>annoyance, molestation,</em> or <em>hurt;</em> <span class="auth">(Ṣ, A,* Ḳ;*)</span> a phrase having an intensive signification, <span class="auth">(Ḳ, TA,)</span> like <span class="ar long">لَيْلٌ أَلْيَلُ</span> <span class="add">[and <span class="ar long">لَيْلٌ لَائِلٌ</span>]</span>; and so<span class="arrow"><span class="ar long">بَرْحًا مُبَرِّحًا↓</span></span>. <span class="auth">(TA.)</span> When used as an imprecation, the more approved way is to put the two words in the accus. case: but sometimes they are put in the nom. case; as in the saying of a poet, <span class="arrow"><span class="ar long">بَرْحٌ لَعيْنَكَ بَارِحٌ↓</span></span> <span class="add">[<em>May great difficulty,</em>, &amp;c., <em>befall thy two eyes!</em>]</span>. <span class="auth">(TA.)</span> You say also, <span class="ar long">لَقِيتُ مِنْهُ بَنَاتِ بَرْحٍ</span>, <span class="auth">(Ṣ, A,)</span> and <span class="ar long">بَنِى بَرْحٍ</span>, <span class="auth">(Ṣ,)</span> <em>I experienced from him,</em> or <em>it, difficulties, distresses, afflictions,</em> or <em>adverse events;</em> and <em>calamities, misfortunes,</em> or <em>disasters:</em> <span class="auth">(Ṣ:)</span> and, in the same sense, <span class="arrow"><span class="ar long">لقيت منه البِرَحِينَ↓</span></span>, and<span class="arrow"><span class="ar">البُرَحِينَ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">البَرَحِينَ↓</span></span>; <span class="auth">(Ḳ;)</span> or, accord. to some copies of the Ḳ, <span class="arrow"><span class="ar">البِرْحَينِ↓</span></span>, and<span class="arrow"><span class="ar">البُرْحَيْنِ↓</span></span>, and<span class="arrow"><span class="ar">البَرْحَيْنِ↓</span></span>, as duals; but the former reading is the more correct: <span class="auth">(TA:)</span> <span class="add">[MF disapproves of the form <span class="ar">بَرَحِينَ</span>, and it is not mentioned in the L; but the dual form <span class="ar">بَرْحَيْنِ</span> is there mentioned:]</span> <span class="pb" id="Page_0182"></span>it seems as though <a href="#bariHiyna">the sing. of <span class="ar">بَرِحِينَ</span></a> <span class="add">[or <span class="ar">بُرَحِينَ</span>]</span> were <span class="ar">بِرَحَةٌ</span> <span class="add">[or <span class="ar">بُرَحَةٌ</span>]</span>, and that the pl. is formed by the termination <span class="ar">ون</span> to compensate for the rejection of the <span class="ar">ة</span>, as is virtually the case in <span class="ar">أَرَضُونَ</span>; <span class="add">[or because the signification is regarded as that of a personification;]</span> and that the pl. only is used. <span class="auth">(L.)</span> It is said in a prov., <span class="ar long">بِنْتُ بَرْحٍ شَرَكٌ عَلَى رَأْسِكَ</span> <span class="add">[<em>Calamity is,</em> or <em>be, a snare upon thy head</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bariHN">
				<h3 class="entry"><span class="ar">بَرِحٌ</span></h3>
				<div class="sense" id="bariHN_A1">
					<p><span class="ar">بَرِحٌ</span>: <a href="#mubarBiHN">see <span class="ar">مُبَرِّحٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baroHapa">
				<h3 class="entry"><span class="ar">بَرْحَةَ</span> / <span class="ar">بَرْحَةً</span></h3>
				<div class="sense" id="baroHapa_A1">
					<p><span class="ar long">صَرْحَةَ بَرْحَةَ</span>, or <span class="ar long">صَرْحَةً بَرْحَةً</span>, &amp;c.: <a href="index.php?data=14_S/041_SrH">see art. <span class="ar">صرح</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buroHapN">
				<h3 class="entry"><span class="ar">بُرْحَةٌ</span></h3>
				<div class="sense" id="buroHapN_A1">
					<p><span class="ar">بُرْحَةٌ</span> The <em>best</em> of anything: <span class="auth">(TA:)</span> and <span class="add">[particularly]</span> <em>one of the best of she-camels:</em> <span class="auth">(Ṣ, Ḳ:)</span> or, <em>of he-camels:</em> <span class="auth">(T:)</span> pl. <span class="ar">بُرَحٌ</span>. <span class="auth">(T, Ṣ, Ḳ.)</span> You say, <span class="ar long">هٰذِهِ بُرْحَةٌ مِنَ البُرَحِ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> or <span class="ar long">هُوَ بُرْحَةٌ مِنَ البُرَحِ</span>, <span class="auth">(T,)</span> <em>This is a she-camel,</em> <span class="auth">(Ṣ, Ḳ,*)</span> or <em>he is a camel,</em> <span class="auth">(T,)</span> <em>of the best of camels.</em> <span class="auth">(T, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baroHae">
				<h3 class="entry"><span class="ar">بَرْحَى</span></h3>
				<div class="sense" id="baroHae_A1">
					<p><span class="ar">بَرْحَى</span> a word that is said when one misses the mark in shooting or casting; like as <span class="ar">مَرْحَى</span> is said when one hits the mark. <span class="auth">(Ṣ, ISd, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buraHaMCu">
				<h3 class="entry"><span class="ar">بُرَحَآءُ</span></h3>
				<div class="sense" id="buraHaMCu_A1">
					<p><span class="ar">بُرَحَآءُ</span> <em>Severity, violence,</em> or <em>sharpness,</em> <span class="auth">(Aṣ, A, TA,)</span> or <em>vehement molestation,</em> <span class="auth">(Ṣ, Ḳ,)</span> of a fever <span class="auth">(Aṣ, A, Ṣ, Ḳ)</span>, &amp;c.: <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[<em>a paroxysm;</em> used in this sense by modern physicians:]</span> and <em>vehement distress of mind arising from the oppression caused by inspiration or revelation;</em> such as is said to have affected the Prophet; <span class="add">[but most probably <em>a paroxysm of that species of catalepsy which physicians term ecstasy;</em>]</span> occurring in a trad. <span class="auth">(TA.)</span> You say of one suffering from fever, when it is intense, <span class="ar long">أَصَابَتْهُ البُرَحَآءُ</span> <span class="add">[<em>The paroxysm,</em> or <em>severe fit, has befallen him</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlbiraHiyna">
				<h3 class="entry"><span class="ar">البِرَحِينَ</span> / <span class="ar">البُرَحِينَ</span></h3>
				<div class="sense" id="AlbiraHiyna_A1">
					<p><span class="ar">البِرَحِينَ</span> and <span class="ar">البُرَحِينَ</span>, &amp;c.: <a href="#baroHN">see <span class="ar">بَرْحٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraAHN">
				<h3 class="entry"><span class="ar">بَرَاحٌ</span></h3>
				<div class="sense" id="baraAHN_A1">
					<p><span class="ar">بَرَاحٌ</span> <a href="#brH_1">inf. n. of <span class="ar">بَرِحَ</span>, q. v.</a>; whence the phrase <span class="ar long">لَا بَرَاحَ</span>, explained above. <span class="auth">(Ṣ, L, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرَاحٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baraAHN_B1">
					<p><em>A wide,</em> or <em>spacious, tract of land,</em> <span class="auth">(Ṣ, A, Ḳ,)</span> <em>kaving in it no seed-produce nor trees:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>land having in it no building nor habitation:</em> <span class="auth">(Ḥam p. 237:)</span> and applied as an epithet to land, signifying <em>wide,</em> or <em>spacious, open,</em> or <em>conspicuous, and having in it no herbage nor habitation:</em> and <em>what is open, uncovered, and wholly apparent,</em> of land: <span class="auth">(TA:)</span> or <em>a place having no trees nor other things to cover</em> or <em>conceal it;</em> as though such things had departed; <span class="auth">(Mgh;)</span> <em>a place free from trees, &amp;c.:</em> <span class="auth">(Mṣb:)</span> or <em>an elevated and open tract of land.</em> <span class="auth">(Ḥar p. 134.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرَاحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="baraAHN_B2">
					<p><span class="ar long">حَبِيلُ بَرَاحٍ</span> is an appellation given to ‡ <em>A lion:</em> and † <em>a courageous man:</em> as though each of them were bound with ropes, <span class="auth">(Ḳ, TA,)</span> and did not quit his place. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرَاحٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="baraAHN_C1">
					<p>An affair, a thing, or a case, that is <em>plain, evident,</em> or <em>manifest;</em> <span class="auth">(Ḳ, TA;)</span> or <em>open,</em> or <em>public.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">جَآءَنَا بِالأَمْرِ بَرَاحًا</span> <span class="add">[<em>He told us,</em> or <em>did to us, the thing</em>]</span> <em>plainly</em> <span class="add">[or <em>openly</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">جَآءَ بِالكُفْرِ بَرَاحًا وَبِالشَّرِّ صُرَاحًا</span> <span class="add">[<em>He uttered,</em> or <em>committed an act of, infidelity plainly,</em> or <em>openly, and evil,</em> or <em>mischief, unmixedly</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرَاحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="baraAHN_C2">
					<p>Counsel, or an opinion, that is <em>disapproved,</em> or <em>deemed evil.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرَاحٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="baraAHN_D1">
					<p><span class="ar">بَرَاحِ</span>, <span class="auth">(El-Mufaddal, Ṣ, A, &amp;c.,)</span> and <span class="ar">بَرَاحُ</span>, with damm and without tenween, <span class="auth">(AZ, El-Mufaddal,)</span> a name of <em>The sun:</em> <span class="auth">(Ṣ, A, &amp;c.:)</span> determinate <span class="add">[and the former indecl.]</span>: the sun is so called because of the spreading of its light, and its conspicuousness; or, being applied to the sun when it sets, <span class="ar">براح</span> means <span class="ar">بَارِحَةٌ</span>; like as <span class="ar">كَسَابِ</span>, a name applied to a hunting-bitch, means <span class="ar">كَاسِبَةٌ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">دَلَكَتْ بَرَاحِ</span> <em>The sun set</em> <span class="add">[or <em>declined from the meridian</em>]</span>. <span class="auth">(A, TA.)</span> For this phrase, occurring at the end of a verse cited by Ḳṭr, Fr reads <span class="ar">دَلَكَتْ بِرَاحِ</span>; <span class="ar">راح</span> being pl. <span class="add">[or rather a quasi-pl. n.]</span> of <span class="ar">رَاحَةٌ</span>, meaning the “hand” <span class="add">[or “palm of the hand”]</span>: <span class="auth">(Ṣ, TA:)</span> accord. to which reading, the poet means <em>The sun had set,</em> or <em>had declined from the meridian, while they put their hands,</em> or <em>the palms of their hands, over their eyes,</em> looking to see if it had set, or had declined from the meridian: or he who says, <span class="ar long">دَلَكَتِ الشَّمْسُ بِرَاحِ</span> means <em>the sun had almost set:</em> the two readings <span class="ar">بَراح</span> and <span class="ar">بِراح</span> are mentioned by AʼObeyd and Az and Hr and Z and others: AZ says, <span class="ar long">دلكت بِرَاحٍ</span>, with tenween, and <span class="ar">بَرَاحٌ</span>, without tenween. <span class="auth">(TA.)</span> <span class="add">[<a href="#raAHapN">See also <span class="ar">رَاحَةٌ</span></a>, <a href="index.php?data=10_r/229_rwH">in art. <span class="ar">روح</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baruwHN">
				<h3 class="entry"><span class="ar">بَرُوحٌ</span></h3>
				<div class="sense" id="baruwHN_A1">
					<p><span class="ar">بَرُوحٌ</span>: <a href="#baAriHN">see <span class="ar">بَارِحٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bariyHN">
				<h3 class="entry"><span class="ar">بَرِيحٌ</span></h3>
				<div class="sense" id="bariyHN_A1">
					<p><span class="ar">بَرِيحٌ</span>: <a href="#baAriHN">see <span class="ar">بَارِحٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرِيحٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bariyHN_B1">
					<p>Also The <em>croaking</em> of the <span class="ar">غُرَاب</span> <span class="add">[or <em>crow,</em> of whatever species, as raven, carrion-crow, &amp;c.]</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرِيحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bariyHN_B2">
					<p><span class="add">[Hence,]</span> <span class="ar long">اِبْنُ بَرِيحٍ</span>: so in the Ḳ: in the Ṣ, <span class="ar long">أُمُّ بَرِيحٍ</span>; but IB and Aboo-Zekereeyà say that only the former is right: <span class="auth">(TA:)</span> <span class="add">[in one copy of the Ṣ, however, I find both of these:]</span> <em>The</em> <span class="ar">غُرَاب</span> <span class="add">[or <em>crow, as a generic term,</em> applying to <em>the raven, carrion-crow, &amp;c.</em>]</span>: <span class="auth">(Ṣ, Ḳ, &amp;c.:)</span> so called because of its cry: a determinate appellation: for the pl., the expression used is <span class="ar long">بَنَاتُ بَرِيحٍ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرِيحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bariyHN_B3">
					<p><a href="#baroHN">See also <span class="ar">بَرْحٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَرِيحٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bariyHN_C1">
					<p><span class="ar long">قَوْلٌ بَرِيحٌ</span> <em>A saying by which one pronounces a person to have said,</em> or <em>done, right.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAriHN">
				<h3 class="entry"><span class="ar">بَارِحٌ</span></h3>
				<div class="sense" id="baAriHN_A1">
					<p><span class="ar">بَارِحٌ</span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> as also<span class="arrow"><span class="ar">بَرُوحٌ↓</span></span> and<span class="arrow"><span class="ar">بَرِيحٌ↓</span></span>, <span class="auth">(Ḳ,)</span> applied to a gazelle, <span class="auth">(Ṣ,)</span> or what is hunted or shot, <span class="auth">(Ḳ, TA,)</span> of gazelles and birds and wild animals <span class="add">[in general]</span>, <span class="auth">(TA,)</span> <em>Turning his left side towards the spectator,</em> <span class="auth">(Ṣ,)</span> <em>passing from the direction of the right hand of the latter towards the direction of his left hand:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>turning his right side towards the spectator, passing from the direction of the latter's left hand towards that of his right:</em> <span class="auth">(Aboo-ʼAmr Esh-Sheybánee, IF, A,* L, Mṣb,* in art. <span class="ar">سنح</span>:)</span> <a href="#saAniHN">contr. of <span class="ar">سَانِحٌ</span></a>: <span class="auth">(Ṣ,* TA:)</span> pl. <span class="ar">بَوَارِحُ</span>. <span class="auth">(L in art. <span class="ar">سنح</span>.)</span> The Arabs <span class="add">[who apply the epithet in the latter sense]</span> regard the <span class="ar">بارح</span> as an evil omen, and the <span class="ar">سانح</span> as a good omen; because one cannot shoot at the former without turning himself: <span class="auth">(Ṣ:)</span> but some of them hold the reverse: <span class="auth">(Aboo-ʼAmr Esh-Sheybánee and L in art. <span class="ar">سنح</span>:)</span> the people of Nejd hold the <span class="ar">سانح</span> to be a good omen; but sometimes a Nejdee adopts the opinion of the Hijázee <span class="add">[which is the contrary]</span>. <span class="auth">(IB in that art.)</span> The first of these epithets is also applied to a bird as meaning <em>Inauspicious; ill-omened.</em> <span class="auth">(A.)</span> It is said in a prov., <span class="ar long">مَنْ لِى بِا لسَّانِحِ بَعْدَ البَارِحِ</span> <span class="auth">(TA)</span> i. e. <span class="add">[<em>Who will be responsible to me</em>]</span> <em>for a fortunate,</em> or <em>lucky, event, after an unfortunate,</em> or <em>unlucky?</em> <span class="auth">(Ḳ in art. <span class="ar">سنح</span>:)</span> applied in the case of a man's doing evil, and its being said, “He will at a future time do good to thee:” originally said by a man on the occasion of gazelles' passing before him in the manner of such as are termed <span class="ar">بَارِحَة</span>, and its being said to him, “They will present themselves to thee in the manner of such as are termed <span class="ar">سَانحَة</span>.” <span class="auth">(TA.)</span> And in another prov. it is said, <span class="ar long">إِنَّمَا هُوَ كَبَارِحِ الأَرْوَى</span> <span class="add">[<em>It,</em> or <em>he, is only like the mountain-goat passing in the manner of such as is termed</em> <span class="ar">بارح</span>]</span>: for it dwells on the tops of the mountains, and men scarcely ever see it passing with the right or left side towards them save once in the course of ages: <span class="auth">(Ṣ, Ḳ:)</span> applied in the case of an extraordinary occurrence: <span class="auth">(Ḳ:)</span> <span class="add">[or in the case of a benefit conferred by a man who very rarely confers benefits on others: <span class="auth">(Freytag's Arab. Prov. i. 35:)</span>]</span> or when a man has delayed, or been tardy in, visiting <span class="add">[but has come at last]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَارِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAriHN_A2">
					<p>Hence, <span class="ar long">فِتْلَةٌ بَارِحَةٌ</span> <em>i. q.</em> <span class="ar">شَزْرَةٌ</span> <span class="add">[i. e. ‡ <em>A manner of twisting contrary to that which is usual:</em> <a href="#Xazara">see <span class="ar">شَزَرَ</span></a>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَارِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAriHN_A3">
					<p>And <span class="ar long">هٰذِهِ فَعْلةٌ بَارِحَةٌ</span> ‡ <em>This is an action that has not happened rightly.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَارِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAriHN_A4">
					<p><span class="add">[Hence,]</span> <span class="ar long">بِنْتُ بَارِحٌ</span>: and <span class="add">[perhaps]</span> <span class="ar long">لَقِيتُ مِنْهُ بَرْحًا بَارِحًا</span>: and <span class="ar long">بَرْحٌ لِعَيْنَكَ بَارِحٌ</span>: <a href="#baroHN">see <span class="ar">بَرْحٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَارِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAriHN_A5">
					<p><span class="add">[And hence, perhaps, because of its evil effect; or because it comes, accord. to some, from the left, i. e. northerly direction, or, accord. to others, from the right, i. e. southerly direction; or]</span> from <span class="ar">بَرْحٌ</span> as signifying “a difficult, a distressing, an afflictive, or adverse, and a wonderful, thing, or event;” <span class="auth">(Ḥam p. 135;)</span> <span class="ar">بَارِحٌ</span> signifies also <em>A hot wind:</em> <span class="auth">(Ṣ:)</span> or <em>a hot wind in the</em> <span class="ar">صَيْفٌ</span> <span class="add">[i. e. <em>summer</em> or <em>spring</em>]</span>: <span class="auth">(Ḳ:)</span> or <em>a hot wind coming from the direction of El-Yemen:</em> <span class="auth">(Ḥam p. 135:)</span> or <em>a wind that carries up, raises,</em> or <em>sweeps up and scatters, the dust:</em> <span class="auth">(Mṣb:)</span> pl. <span class="ar">بَوارِحُ</span>: <span class="auth">(Ṣ, Ḳ, &amp;c.:)</span> or the <span class="ar">بوارح</span> are <em>hot north,</em> or <em>northerly, winds in the</em> <span class="ar">صَيْف</span>: <span class="auth">(AZ, Az, Ṣ:)</span> this Az found to be the sense in which the term was used by the Arabs in his time: <span class="auth">(TA:)</span> or <em>violent winds that carry with them the dust by reason of their violence:</em> <span class="auth">(TA:)</span> or this name <span class="auth">(the pl.)</span> was given by the Arabs to <em>all winds in the time of the stars of the</em> <span class="ar">قَيْظ</span> <span class="add">[or <em>summer</em>]</span>: <em>they mostly blow in the time of the stars of Libra;</em> <span class="add">[app. meaning when Libra is on, or near, the meridian at nightfall, agreeably with a statement in modern Arabic almanacs, that the periods of the beginning and end of the winds thus called are the 30th of May and the 9th of July;]</span> <em>and these winds are what are termed the</em> <span class="ar">سَمَائِم</span> <span class="add">[<a href="#samuwmN">pl. of <span class="ar">سَمُومٌ</span></a>]</span>. <span class="auth">(Ibn-Kunáseh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برح</span> - Entry: <span class="ar">بَارِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAriHN_A6">
					<p><span class="ar">البَوَارِحُ</span> is also said by some to signify <span class="ar">الأَنْوَآءُ</span> <span class="add">[<a href="#naWoCN">pl. of <span class="ar">نَوْءٌ</span>, q. v.</a>]</span>; as mentioned by AḤn; but he repels their assertion. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaAriHapu">
				<h3 class="entry"><span class="ar">البَارِحَةُ</span></h3>
				<div class="sense" id="AlbaAriHapu_A1">
					<p><span class="ar">البَارِحَةُ</span> <em>The next,</em> or <em>nearest, past,</em> or <em>preceding, night; yesternight:</em> <span class="auth">(Ṣ, A, Mgh,* Mṣb,* Ḳ:)</span> from <span class="ar">بَرِحَ</span> signifying <span class="ar">زَالَ</span> <span class="add">[“he, or it, went away”, &amp;c.]</span>. <span class="auth">(Ṣ, A.)</span> <span class="pb" id="Page_0183"></span><span class="add">[In modern Arabic, <em>Yesterday;</em> as also <span class="ar">البَارِح</span>.]</span> It has no dim. formed from it. <span class="auth">(Sb, in Ṣ, in art. <span class="ar">أمس</span>; and TA.)</span> You say, <span class="ar long">لَقِيتُهُ البَارِحَة</span> <span class="add">[<em>I met,</em> or <em>met with, him,</em> or <em>it, last night,</em> or <em>yesternight</em>]</span>: and <span class="ar long">لَقِيتُهُ البَارِحَةَ الأُولَى</span> <span class="add">[<em>I met,</em> or <em>met with, him,</em> or <em>it, the night before last;</em> this being the sense in which the phrase is now used by the learned: but the vulgar expression is <span class="ar long">أَوَّل البَارِحَة</span>, generally pronounced <span class="ar long">أَوَّل اَمْبَارِحَهْ</span> or <span class="ar long">أَوَّل اَمْبَارِحْ</span>, agreeably with a peculiarity of the dial. of the people of El-Yemen, or of Teiyi and Himyer, by the substitution of <span class="ar">اَمْ</span> for <span class="ar">اَلْ</span>: <a href="index.php?data=01_A/128_Am">see art. <span class="ar">ام</span></a>]</span>. <span class="auth">(Ṣ)</span> From daybreak to the time when the sun declines from the meridian, one says, <span class="ar long">رَأَيْتُ اللَّيْلَةَ فِى مَنَامِى</span> <span class="add">[I saw to-night in my sleep <span class="auth">(such a thing)</span>]</span>; but when the sun has declined, one says, <span class="ar long">رَأَيْتُ البَارِحَةَ</span> <span class="add">[<em>I saw last night,</em> or <em>yesternight</em>]</span>: <span class="auth">(AZ, Th: <span class="add">[and the like is said in the Mgh and Mṣb:]</span>)</span> or one says, <span class="ar long">كَانَ كَذَا وَكَذَا اللَّيْلَةَ</span> <span class="add">[<em>Such and such things happened to-night</em>]</span> until the sun is somewhat high and the day has become bright; but after this, one says, <span class="ar long">كَانَ البَارِحَةَ</span> <span class="add">[<em>It happened last night,</em> or <em>yesternight</em>]</span>. <span class="auth">(Yoo, Seer.)</span> The Arabs say,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَا أَشْبَهَ اللَّيْلَةَ بِا لبَارِحَةِ</span> *</div> 
					</blockquote>
					<p><em>How like is this night wherein we are to the former night that has departed!</em> <span class="auth">(TA:)</span> <span class="add">[or, <em>this night to yesternight!</em>]</span>: originally occurring in a poem of Tarafeh: used as meaning “how like is the child to the father!” and applied to <span class="add">[any]</span> two things resembling each other. <span class="auth">(Ḥar p. 667.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboraHu">
				<h3 class="entry"><span class="ar">أَبْرَحُ</span></h3>
				<div class="sense" id="OaboraHu_A1">
					<p><span class="ar">أَبْرَحُ</span> is formed <span class="add">[from <span class="ar">بَرَحَ</span> for <span class="ar">بَرَّحَ</span>]</span> by the rejection of the added letter: <span class="add">[for a word of this kind is regularly formed only from an unaugmented triliteral-radical verb:]</span> or it is like <span class="ar">أَحْنَكُ</span>, having no proper verb. <span class="auth">(L.)</span> You say, <span class="ar long">هٰذَا أَبْرَحُ عَلَىَّ مِنْ ذَاكَ</span> <span class="auth">(A,* L, Mṣb *)</span> <em>This is more difficult, distressing,</em> or <em>afflicting, to me than that.</em> <span class="auth">(L, Mṣb.*)</span> And <span class="ar long">هٰذَآ الأَمْرُ أَبْرَحُ مِنْ هٰذَا</span> <em>This affair, event,</em> or <em>case, is more difficult,</em> or <em>distressing, than this.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">قَتَلُوهُمْ أَبْرَحَ قَتْلٍ</span> <span class="add">[<em>They slew them with a most severe slaughter</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taboriyHN">
				<h3 class="entry"><span class="ar">تَبْرِيحٌ</span></h3>
				<div class="sense" id="taboriyHN_A1">
					<p><span class="ar">تَبْرِيحٌ</span> <span class="add">[<a href="#brH_2">inf. n. of 2</a>, used as a simple subst.,]</span> is said by some to be <a href="#tabaAriyHu">sing. of <span class="ar">تَبَارِيحُ</span></a>, and has been used as such by post-classical authors, but is not of established authority: accord. to others, the latter has no sing.: <span class="auth">(MF:)</span> the pl. signifies <em>Difficulties, distresses, afflictions,</em> or <em>adversities:</em> <span class="add">[<a href="#baroHN">see also <span class="ar">بَرْحٌ</span></a>:]</span> or the <em>difficulties,</em> or <em>obligations, incurred by troublesome,</em> or <em>inconvenient, means of obtaining subsistence:</em> <span class="auth">(TA:)</span> and <span class="ar long">تَبَارِيحُ الشَّوْقِ</span> <em>the burning,</em> or <em>fierce burning,</em> <span class="add">[or <em>the burnings,</em>, &amp;c.,]</span> <em>of the yearning,</em> or <em>longing, of the soul,</em> or <em>of longing desire.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubarBaHN">
				<h3 class="entry"><span class="ar">مُبَرَّحٌ</span></h3>
				<div class="sense" id="mubarBaHN_A1">
					<p><span class="ar long">أنَا مُبَرَّحٌ بِى</span> <em>I am importuned,</em> or <em>pressed, with annoyance,</em> or <em>molestation.</em> <span class="auth">(A, TA.)</span> <span class="add">[<a href="#brH_2">See the verb <span class="new">{2}</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubarBiHN">
				<h3 class="entry"><span class="ar">مُبَرِّحٌ</span></h3>
				<div class="sense" id="mubarBiHN_A1">
					<p><span class="ar">مُبَرِّحٌ</span> and<span class="arrow"><span class="ar">بَرِحٌ↓</span></span>, applied to an affair, an event, or a case, signify the same; <span class="auth">(Ḳ, TA;)</span> i. e. <em>Severe, afflicting, distressing,</em> or <em>harassing:</em> <span class="auth">(TA:)</span> and the former, to a beating, <span class="auth">(Ṣ, A, Mgh, TA,)</span> meaning <em>the same;</em> <span class="auth">(TA;)</span> or <em>hurting</em> <span class="auth">(Ṣ, Mgh)</span> <em>severely:</em> <span class="auth">(Ṣ:)</span> and to a man, meaning <em>annoying,</em> or <em>molesting, by importuning,</em> or <em>pressing.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#brH_2">See 2</a>.]</span> <span class="ar long">لَقِيتُ مِنْهُ بَرْحًا مُبَرِّحًا</span>: <a href="#baroHN">see <span class="ar">بَرْحٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="yaboruwHN">
				<h3 class="entry"><span class="ar">يَبْرُوحٌ</span></h3>
				<div class="sense" id="yaboruwHN_A1">
					<p><span class="ar">يَبْرُوحٌ</span>, <span class="auth">(Ḳ,)</span> thus correctly written, with the <span class="ar">ى</span> before the <span class="ar">ب</span>; <span class="add">[not <span class="ar">بيروح</span>, as in the CK; in Chald. <span class="he">יַבְרוּחַ</span>, the word corresponding to the sing. of the Hebr. <span class="he">דּוּדָאִים</span> in Gen. xxx. 14 and 16, accord. to the paraphrase of Onkelos;]</span> or <span class="ar long">يَبْرُوحٌ صَنَمِىٌّ</span> <span class="add">[the <em>idol-like</em> <span class="ar">يبروح</span>]</span>; <span class="auth">(TA;)</span> The <em>root,</em> or <em>lower part, of the wild</em> <span class="ar">لُفَّاح</span> <span class="add">[or <em>mandrake,</em> not to be confounded with another plant to which the name of <span class="ar">لُفَّاح</span>, q. v., is also applied]</span>, <span class="auth">(Ḳ,)</span> <em>which is known by the names of</em> <span class="ar">فَاوَانِيَا</span> <em>and</em> <span class="ar long">عُودُ الصَّلِيبِ</span> <span class="add">[names now given to the peony]</span>, and called by MF <span class="ar long">تُفَّاحُ البَرِّ</span>, <span class="add">[or <em>the wild apple,</em> but perhaps this is a mistranscription for <span class="ar long">لُفَّاحُ البَرِّ</span>,]</span> said by him to be an appellation used by the vulgar; <span class="auth">(TA;)</span> <em>resembling the form of a man;</em> <span class="auth">(Ḳ;)</span> <em>and of two sorts, male and female; called by the people of Greece</em> <span class="ar long">عَبْدُ السَّلَامِ</span>: <span class="auth">(TA:)</span> <em>it torpifies,</em> <span class="auth">(Ḳ,)</span> <em>and strengthens the two appetites</em> <span class="add">[namely that of the stomach and that of the generative organ]</span>: <span class="auth">(TA:)</span> <em>if ivory is cooked with it for six hours, it renders it soft; and if a part affected by</em> <span class="add">[<em>the disease termed</em>]</span> <span class="ar">بَرَش</span> <em>is rubbed with its leaves for a week,</em> <span class="auth">(Ḳ,)</span> <em>without interruption,</em> <span class="auth">(TA,)</span> <em>it removes it without causing ulcers,</em> or <em>sores:</em> <span class="auth">(Ḳ:)</span> the root of the wild <span class="ar">لُفَّاح</span> is the <span class="ar">يَبْروح</span>: <em>it has the form of a human being; the male like the male, and the female like the female; and they pretend that he who pulls it up dies; wherefore, when they desire to do so, they tie a dog or some other animal to it.</em> <span class="auth">(Ḳzw, voce <span class="ar">لُفَّاح</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0181.pdf" target="pdf">
							<span>Lanes Lexicon Page 181</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0182.pdf" target="pdf">
							<span>Lanes Lexicon Page 182</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0183.pdf" target="pdf">
							<span>Lanes Lexicon Page 183</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
