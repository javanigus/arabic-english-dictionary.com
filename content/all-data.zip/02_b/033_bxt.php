<article class="root" id="Root_bxt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/032_bx">بخ</a></span>
				<span class="ar">بخت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/034_bxtr">بختر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bxt_1">
				<h3 class="entry">1. ⇒ <span class="ar">بخت</span></h3>
				<div class="sense" id="bxt_1_A1">
					<p><span class="ar">بَخَتَهُ</span> <em>He beat, struck,</em> or <em>smote, him;</em> <span class="auth">(JK, Ḳ;)</span> namely, a man. <span class="auth">(JK.)</span> <span class="add">[<a href="#bkt_1">See also <span class="ar">بَكَتَهُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bxt_2">
				<h3 class="entry">2. ⇒ <span class="ar">بخّت</span></h3>
				<div class="sense" id="bxt_2_A1">
					<p><span class="ar">تَبْخِيتٌ</span> <span class="add">[inf. n. of <span class="ar">بَخَّتَهُ</span>]</span> The <em>overcoming</em> another <em>with an argument</em> or <em>the like;</em> or <em>reducing</em> him <em>to silence, through inability to reply; i. q.</em> <span class="ar">تَبْكِيتٌ</span>: and the <em>addressing</em> an adversary in a dispute or litigation <em>with speech so as to put a stop to his plea,</em> or <em>allegation:</em> from the author of the Tekmileh. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بخت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bxt_2_A2">
					<p>Also, as a term of the theologians, The <em>believing at first view, without consideration of a thing:</em> so in <span class="ar long">صَلَّى عَلَى التَّبْخِيتِ</span> <span class="add">[<em>he prayed according to the belief which he formed at first view, without consideration</em>]</span>; said of a person when the kibleh is doubtful, and he cannot work out a solution of the difficulty. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bxt_QQ2">
				<h3 class="entry">Q. Q. 2. ⇒ <span class="ar">تَبَخْتَى</span></h3>
				<div class="sense" id="bxt_QQ2_A1">
					<p><span class="ar">تَبَخْتَى</span>: <a href="#tabaxotara">see <span class="ar">تَبَخْتَرَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxotN">
				<h3 class="entry"><span class="ar">بَخْتٌ</span></h3>
				<div class="sense" id="baxotN_A1">
					<p><span class="ar">بَخْتٌ</span> <em>Fortune;</em> or particularly <em>good fortune;</em> syn. <span class="ar">جَدٌّ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> and <span class="ar">حَظٌّ</span>: <span class="auth">(Mṣb, TA:)</span> a foreign, or Persian, word, <span class="auth">(Mṣb,)</span> arabicized: <span class="auth">(Ṣ, Ḳ:)</span> or post-classical: accord. to the 'Ináyeh, not a chaste Arabic word: but in the Shifá el-Ghaleel said to have been used by the Arabs in ancient times; and the like is said in the L: Az says, “I know not if it be Arabic or not.” <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buxotu">
				<h3 class="entry"><span class="ar">بُخْتُ</span></h3>
				<div class="sense" id="buxotu_A1">
					<p><span class="ar">بُخْتُ</span> <span class="add">[a coll. gen. n.]</span> <em>A species of camels;</em> <span class="auth">(Ṣ,* Mṣb;)</span> the <em>Khurásánee</em> <span class="add">[or <em>Bactrian</em>]</span> <em>camels;</em> <span class="auth">(Ḳ;)</span> <em>begot between an Arabian she-camel and a</em> <span class="ar">فَالِج</span> <span class="add">[which is a <em>large two-humped camel brought from Es-Sind for the purpose of covering</em>]</span>; <span class="auth">(TA;)</span> <em>long-necked;</em> <span class="auth">(Nh;)</span> <span class="add">[<em>large and strong,</em> accord. to Ibn-Maạroof; <em>and two-humped,</em> accord. to Leo Africanus: the Mauritanian Arabs call thus all camels promiscuously; but accord. to the more common use of the word are to be understood <em>hairy camels, fit for winter-work; generally of Turhumán or Bactrian breed;</em> distinct from the Arabian, which are accustomed to bear bardens in winter and summer: <span class="auth">(Golius:)</span>]</span> they are also called <span class="arrow"><span class="ar">بُخْتِيَّةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> n. un. <span class="arrow"><span class="ar">بُخْتِىٌّ↓</span></span>; <span class="auth">(Ṣ, Mṣb;)</span> fem. <span class="arrow"><span class="ar">بُخْتِيَّةٌ↓</span></span>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">بَخَاتِىُّ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> imperfectly decl., <span class="auth">(Ṣ,)</span> and <span class="ar">بَخَاتَى</span> <span class="auth">(Ḳ, TA <span class="add">[in the CK <span class="ar">بَخَاتِى</span>]</span>)</span> and <span class="ar">بَخَاتٍ</span>, <span class="auth">(Ḳ,)</span> and you may say <span class="add">[with the article]</span> <span class="ar">البَخَاتِى</span>, without tenween: <span class="auth">(Ṣ, Mṣb:)</span> it is a foreign, or Persian, word, <span class="auth">(TA,)</span> arabicized: but some say, it is Arabic: <span class="auth">(Ṣ, TA:)</span> some hesitate as to its being Arabic because <span class="ar">بَخْتٌ</span>, meaning <span class="ar">خَظٌّ</span>, is not. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buxotieBN">
				<h3 class="entry"><span class="ar">بُخْتِىٌّ</span> / <span class="ar">بُخْتِيَّةٌ</span></h3>
				<div class="sense" id="buxotieBN_A1">
					<p><span class="ar">بُخْتِىٌّ</span> and <span class="ar">بُخْتِيَّةٌ</span>: <a href="#buxotN">see <span class="ar">بُخْتٌ</span></a>; for the latter, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxiytN">
				<h3 class="entry"><span class="ar">بَخِيتٌ</span></h3>
				<div class="sense" id="baxiytN_A1">
					<p><span class="ar">بَخِيتٌ</span>, not thought by IDrd to be a chaste word, <span class="auth">(TA,)</span> <em>Fortunate; possessed of good fortune;</em> <span class="auth">(A, Ḳ, TA;)</span> as also↓<span class="ar">مَبْخُوتٌ</span>. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baxBaAtN">
				<h3 class="entry"><span class="ar">بَخَّاتٌ</span></h3>
				<div class="sense" id="baxBaAtN_A1">
					<p><span class="ar">بَخَّاتٌ</span> One <em>who acquires, as his permanent property, camels such as are termed</em> <span class="ar">بُخْت</span>: <span class="auth">(Ḳ:)</span> and one <em>who makes use of such camels.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboxuwtN">
				<h3 class="entry"><span class="ar">مَبْخُوتٌ</span></h3>
				<div class="sense" id="maboxuwtN_A1">
					<p><span class="ar">مَبْخُوتٌ</span>: <a href="#baxiytN">see <span class="ar">بَخِيتٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0158.pdf" target="pdf">
							<span>Lanes Lexicon Page 158</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
