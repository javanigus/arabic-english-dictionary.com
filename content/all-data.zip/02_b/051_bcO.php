<article class="root" id="Root_bcO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/050_bc">بذ</a></span>
				<span class="ar">بذأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/052_bcx">بذخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bcO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بذأ</span></h3>
				<div class="sense" id="bcO_1_A1">
					<p><span class="ar">بَذُؤَ</span>, <span class="auth">(T, M, Ḳ,)</span> with and without <span class="ar">ء</span>, <span class="auth">(Mgh,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْذُأُ</span>}</span></add>, <span class="auth">(T,)</span> inf. n. <span class="ar">بَذَآءٌ</span> and <span class="ar">بَذَآءَةٌ</span>, <span class="auth">(M, Ḳ,)</span> the former written in one copy of the Ḳ <span class="ar">بَذَأٌ</span>, and the latter in some copies written <span class="ar">بَذْأَةٌ</span>; <span class="auth">(TA;)</span> and <span class="ar">بَذَأَ</span>, and <span class="ar">بَذِئَ</span>, <span class="auth">(Ḳ,)</span> aor. of both <span class="ar">ـَ</span>; <span class="auth">(TA;)</span> and some say <span class="ar">بَذِىَ</span>, aor. <span class="ar">يَبْذَى</span>, inf. n. <span class="ar">بَذَآءٌ</span>; <span class="auth">(T;)</span> or, accord. to the Mṣb, only <span class="ar">بَذَأَ</span> is with <span class="ar">ء</span>, and the others are properly written <span class="ar">بَذِىَ</span> and <span class="ar">بَذُوَ</span>; <span class="auth">(TA;)</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, foul, unseemly,</em> or <em>obscene,</em> <span class="auth">(T, M, Ḳ, TA,)</span> <em>in tongue;</em> <span class="auth">(TA;)</span> <em>evil in speech.</em> <span class="auth">(T.)</span> And <span class="ar long">بَذَأَ عَلَى القَوْمِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَأُ</span>}</span></add>, inf. n. <span class="ar">بَذْءٌ</span> and <span class="ar">بَذَآءٌ</span>, <em>He behaved in a lightwitted, weak, stupid,</em> or <em>foolish, manner,</em> or <em>ignorantly, towards the people,</em> or <em>company of men;</em> and <em>uttered foul, unseemly,</em> or <em>obscene, language against them;</em> and <em>so though with truth.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcO_1_A2">
					<p><span class="ar">بَذَأَ</span> also signifies <em>He was,</em> or <em>became, evil in disposition.</em> <span class="auth">(Fr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bcO_1_A3">
					<p>And, said of a place, <em>It became devoid of pasture, barren,</em> or <em>unfruitful.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بذأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bcO_1_B1">
					<p><span class="ar long">بَاذَأَهُ فَبَذَأَهُ</span>: <a href="#bcA3">see 3</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bcO_1_B2">
					<p><span class="ar">بَذَأَهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْذَأُ</span>}</span></add>, <span class="auth">(T,)</span> inf. n. <span class="ar">بَذْءٌ</span>, <span class="auth">(T, Ṣ,)</span> also signifies <em>He dispraised it; discommended it;</em> <span class="auth">(T, M, Ḳ;)</span> namely, a thing: <span class="auth">(M:)</span> and <em>be despised him:</em> <span class="auth">(T, Ḳ:)</span> and <em>he saw in him</em> <span class="auth">(a man, Ṣ)</span> <em>a state,</em> or <em>condition, that he disliked,</em> or <em>hated:</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>he did not approve him;</em> and <em>was not pleased with his aspect.</em> <span class="auth">(TA.)</span> And <span class="ar long">بَذَأَتْهُ عَيْنِى</span>, <span class="auth">(T, Ṣ, M, Mṣb,*)</span> aor. as above, <span class="auth">(M,)</span> and so the inf. n., <span class="auth">(Ṣ, M,)</span> <em>My eye did not approve him,</em> or <em>it;</em> <span class="auth">(T, Ṣ;)</span> <em>I was not pleased with his,</em> or <em>its, aspect;</em> <span class="auth">(Ṣ;)</span> and <em>I saw in him,</em> or <em>it, a state,</em> or <em>condition, that I disliked.</em> or <em>hated:</em> <span class="auth">(T:)</span> or <em>my eye despised,</em> or <em>regarded as of light estimation, him,</em> or <em>it:</em> <span class="auth">(M, Mṣb:)</span> accord. to AZ, this is said when a thing has been praised, or greatly praised, to thee, and in thy presence, and then thou dost not see it to be as it has been described: but when thou seest it to be as it has been described, thou sayest, <span class="ar long">مَا تَبْذَؤُهُ العَيْنِ</span>. <span class="auth">(T.)</span> One says also, <span class="ar long">بَذَأَ الأَرْضَ</span> <em>He dispraised,</em> or <em>discommended, the pasture of the land.</em> <span class="auth">(Ṣ, M, Ḳ.)</span> And in like manner, <span class="ar long">بَذَأَ المَوْضِعَ</span> <span class="auth">(Ṣ)</span> <em>He did not praise the place.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcO_3">
				<h3 class="entry">3. ⇒ <span class="ar">باذأ</span></h3>
				<div class="sense" id="bcO_3_A1">
					<p><span class="ar">باذأهُ</span>, <span class="auth">(T,)</span> inf. n. <span class="ar">مُبَاذَأَةٌ</span>, <span class="auth">(T, Ḳ,)</span> in some copies of the Ḳ without <span class="ar">ء</span>, <span class="auth">(TA,)</span> and <span class="ar">بِذَآءٌ</span>, <span class="auth">(T, Ḳ,)</span> <span class="add">[<em>He vied with him,</em> or <em>strove to surpass him, in foul, unseemly,</em> or <em>obscene, speech</em> or <em>language:</em> and <em>he held such discourse with him:</em> these significations being indicated by the following exs., and by the saying that]</span> the inf. ns. are <em>syn. with</em> <span class="ar">مُفَاحَشَةٌ</span>. <span class="auth">(T, Ḳ.)</span> You say,<span class="arrow"><span class="ar long">بَاذَأَهُ فَبَذَأَهُ↓</span></span> <span class="add">[<em>He vied with him,</em> or <em>strove to surpass him, in foul, unseemly,</em> or <em>obscene, speech</em> or <em>language, and he surpassed him therein:</em> in this case, the aor. of the latter verb is <span class="ar">ـُ</span>, notwithstanding the final faucial letter]</span>. <span class="auth">(TA.)</span> And Esh-Shaabee says, <span class="ar long">إِذَ عَظُمَتِ الحَلْقَةُ فَإِنَّمَا هُوَ بِذَآءٌ وَنِجَآءٌ</span> <span class="add">[i. e. <em>When the ring of people becomes large, it is only</em> an occasion of <em>holding foul, unseemly,</em> or <em>obscene, and secret, discourse</em>]</span>: it is said that <span class="ar">بذآء</span> here signifies <span class="ar">مفاحشة</span>: <span class="auth">(T:)</span> the meaning is, that there is much <span class="ar">بذاء</span> and <span class="ar">نجاء</span>, i. e. <span class="ar">مُنَاجَاة</span>, therein. <span class="auth">(TA in art. <span class="ar">نجو</span>. <span class="add">[But there, in the place of <span class="ar long">فَإِنَّمَا هُوَ</span>, I find <span class="ar">فَهِىَ</span>; and in the TA in the present art., <span class="ar long">فَإِنَّمَا بِهِ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذأ</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bcO_3_A2">
					<p>Also <em>He contended with him in an altercation.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bcO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابذأ</span></h3>
				<div class="sense" id="bcO_4_A1">
					<p><span class="ar">ابذأ</span> <em>He uttered foul, unseemly,</em> or <em>obscene, speech</em> or <em>language.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bacieoCN">
				<span class="pb" id="Page_0173"></span>
				<h3 class="entry"><span class="ar">بَذِىْءٌ</span></h3>
				<div class="sense" id="bacieoCN_A1">
					<p><span class="ar">بَذِىْءٌ</span> A man <em>foul, unseemly,</em> or <em>obscene,</em> <span class="auth">(T, M, Ḳ, TA,)</span> <em>in tongue;</em> <span class="auth">(TA;)</span> <em>evil in speech.</em> <span class="auth">(T.)</span> <span class="add">[<a href="index.php?data=02_b/056_bcw">See also art. <span class="ar">بذو</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بذأ</span> - Entry: <span class="ar">بَذِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bacieoCN_A2">
					<p>A place <em>in which is no pasture:</em> <span class="auth">(Ḳ:)</span> and <span class="ar long">أَرْضٌ بَذِيْئَةٌ</span> <em>a land in which is no pasture.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0172.pdf" target="pdf">
							<span>Lanes Lexicon Page 172</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0173.pdf" target="pdf">
							<span>Lanes Lexicon Page 173</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
