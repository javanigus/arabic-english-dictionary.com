<article class="root" id="Root_bnfsj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/193_bnSr">بنصر</a></span>
				<span class="ar">بنفسج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/195_bnq">بنق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="banafosajN">
				<h3 class="entry"><span class="ar">بَنَفْسَجٌ</span></h3>
				<div class="sense" id="banafosajN_A1">
					<p><span class="ar">بَنَفْسَجٌ</span>, of the measure <span class="ar">قَعَلَّلٌ</span>, like <span class="ar">سَفَرْجَلٌ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[an arabicized word, from the Persian <span class="ar">بَنَفْشَ</span>; The <em>violet; viola odorata</em> of Linn: and accord. to Forskål <span class="auth">(Flora AEgypt. Arab. p. ciii.)</span> applied in El-Yemen to the “<em>iris:</em>” and <span class="auth">(p. cxx.)</span> “<em>tagetes dubia?</em>”]</span> what is thus called is well known: <em>the smelling it in its fresh state is beneficial to those who are heated by wrath</em> (<span class="ar">المَحْرُورِين</span>), <em>and the continual smelling of it induces good sleep: the conserve made of it is beneficial for the pleurisy</em> (<span class="ar long">ذَاتُ الجَنْبِ</span>), <em>and for inflammation of the lungs</em> (<span class="ar long">ذَاتُ الرِّئَةِ</span>), <em>and for cough, and for headache.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0259.pdf" target="pdf">
							<span>Lanes Lexicon Page 259</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
