<article class="root" id="Root_bjH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/021_bvq">بثق</a></span>
				<span class="ar">بجح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/023_bjd">بجد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bjH_1">
				<h3 class="entry">1. ⇒ <span class="ar">بجح</span></h3>
				<div class="sense" id="bjH_1_A1">
					<p><span class="ar">يَجِحَ</span>, <span class="add">[aor. and inf. n. as below,]</span> <em>He rejoiced;</em> or <em>was joyful, glad,</em> or <em>happy;</em> <span class="auth">(Ṣ, A;)</span> as also<span class="arrow"><span class="ar">تبجّح↓</span></span>: <span class="auth">(Ṣ, Mgh, Ḳ:)</span> and<span class="arrow">↓</span> the latter signifies also <em>he magnified himself;</em> and <em>gloried,</em> or <em>boasted:</em> <span class="auth">(Mgh:)</span> or, accord. to Lḥ, this verb signifies <em>he gloried,</em> or <em>boasted;</em> and <em>vied with others,</em> or <em>contended with them for superiority, in beauty,</em> or <em>goodliness, in respect of something;</em> as also <span class="ar">تمجِح</span>: or, as some say, <em>he magnified himself:</em> and <span class="ar">بَجِعَ</span> is said to signify <em>he was,</em> or <em>became, great in his own estimation.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">بَجِعَ بِهِ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْجَحُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَجَحٌ</span>; <span class="auth">(Ṣ, Ḳ, TA;)</span> and <span class="ar">بَجَحَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْجَحُ</span>}</span></add>; <span class="auth">(Mṣb, Ḳ;)</span> but the latter is of weak authority; <span class="auth">(Ṣ, Ḳ;)</span> <em>He rejoiced in it,</em> or <em>at it;</em> <span class="auth">(Ṣ, Ḳ;)</span> namely, a thing; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">تبجّح↓</span></span> and<span class="arrow"><span class="ar">ابتجح↓</span></span>: <span class="auth">(TA:)</span> or <em>he gloried in it,</em> or <em>boasted of it;</em> and so<span class="arrow"><span class="ar">تبجّح↓</span></span>. <span class="auth">(Mṣb.)</span> And<span class="arrow"><span class="ar long">فُلَانٌ يَتَبَجَّحُ↓ عَلَيْنَا</span></span>, and <span class="ar long">يَتَمَجَّحُ علينا</span>, <em>Such a one talks foolishly,</em> or <em>irrationally,</em> <span class="add">[<em>to us, assuming superiority over us,</em>]</span> <em>by reason of self-conceitedness:</em> and so one says in speaking of a person in jest. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بجح</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bjH_1_B1">
					<p><a href="#bjH_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bjH_2">
				<h3 class="entry">2. ⇒ <span class="ar">بجّح</span></h3>
				<div class="sense" id="bjH_2_A1">
					<p><span class="ar">بجّحُه</span> <em>It</em> <span class="auth">(a thing, or an affair, TA)</span> <em>rejoiced him; made him joyful, glad,</em> or <em>happy;</em> <span class="auth">(A, TA;)</span> as also<span class="arrow"><span class="ar">ابجحّحُ↓</span></span>. <span class="auth">(TA.)</span> And <span class="ar">بَجَّحْتُهُ</span>, <span class="auth">(inf. n. <span class="ar">تَبْجِيعٌ</span>, Ṣ, Ḳ,)</span> <em>I rejoiced him; made him joyful,</em>, &amp;c.: <span class="auth">(Ṣ, Mgh, Ḳ:)</span> or, as some say, <em>magnified him:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">بَجَحْتُهُ↓</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْجِحُ</span>}</span></add>, <em>I magnified it;</em> namely, a thing. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bjH_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابجح</span></h3>
				<div class="sense" id="bjH_4_A1">
					<p><a href="#bjH_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bjH_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبجّح</span></h3>
				<div class="sense" id="bjH_5_A1">
					<p><a href="#bjH_1">see 1</a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bjH_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباجح</span></h3>
				<div class="sense" id="bjH_6_A1">
					<p><span class="ar long">النِّسَآءُ يَتَبَاجَحْنَ</span> <em>Women,</em> or <em>the women, vie,</em> or <em>contend for superiority, one with another, in beauty,</em> or <em>goodliness,</em> and <em>in glorying,</em> or <em>boasting.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bjH_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتجح</span></h3>
				<div class="sense" id="bjH_8_A1">
					<p><a href="#bjH_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajiHN">
				<h3 class="entry"><span class="ar">بَجِحٌ</span></h3>
				<div class="sense" id="bajiHN_A1">
					<p><span class="ar">بَجِحٌ</span> <em>Rejoicing, glad,</em> or <em>happy;</em> as in the phrase, <span class="ar long">إَنَا بَجَعٌ بِمَكَانِ كَذَا</span> <span class="add">[<em>I am rejoicing in such a place</em>]</span>; and so<span class="arrow"><span class="ar long">مُتَبَجِّحٌ↓ بِهِ</span></span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajBaAHN">
				<h3 class="entry"><span class="ar">بَجَّاحٌ</span></h3>
				<div class="sense" id="bajBaAHN_A1">
					<p><em>Joyful;</em> <span class="add">[an intensive epithet]</span> applied to a man. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAjiHN">
				<h3 class="entry"><span class="ar">بَاجِحٌ</span></h3>
				<div class="sense" id="baAjiHN_A1">
					<p><span class="ar">بَاجِحٌ</span> <em>Great in estimation;</em> applied to a man: pl. <span class="ar">بُجَّعٌ</span> and <span class="ar">بُجْحٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabaAjiHu">
				<h3 class="entry"><span class="ar">مَبَاجِحُ</span></h3>
				<div class="sense" id="mabaAjiHu_A1">
					<p><span class="ar">مَبَاجِحُ</span> <span class="add">[a pl. of which the sing. is app. <span class="ar">مَبْجَحَةٌ</span>, meaning, accord. to analogy, <em>A cause of joy</em> or <em>gladness</em> or <em>happiness</em>]</span>. You say, <span class="ar long">لَقِيتُ مِنْهُ المَنَاجِحَ والمَبَاجِحَ</span> <span class="add">[app. <em>I experienced from it,</em> or <em>him, the causes of success, and the causes of joy</em>, &amp;c.]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutabajBiHN">
				<h3 class="entry"><span class="ar">مُتَبَجِّحٌ</span></h3>
				<div class="sense" id="mutabajBiHN_A1">
					<p><span class="ar">مُتَبَجِّحٌ</span>: <a href="#bajiEN">see <span class="ar">بَجِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0152.pdf" target="pdf">
							<span>Lanes Lexicon Page 152</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
