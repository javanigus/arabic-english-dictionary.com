<article class="root" id="Root_bwH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/214_bwj">بوج</a></span>
				<span class="ar">بوح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/216_bwx">بوخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwH_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوح</span> ⇒ <span class="ar">باح</span></h3>
				<div class="sense" id="bwH_1_A1">
					<p><span class="ar">بَاحَ</span>, <span class="auth">(A, Mṣb, Ḳ,)</span> aor. <span class="ar">يَبُوحُ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بَوْحٌ</span>, <span class="auth">(A, Mṣb,)</span> <em>It</em> <span class="auth">(a secret, A, or a thing, Mṣb)</span> <em>became apparent,</em> or <em>manifest.</em> <span class="auth">(A, Mṣb, Ḳ.)</span> You say, <span class="ar long">بَاحَ مَا كَتَبْتُ</span> <span class="add">[<em>What I concealed became apparent</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">أَعُوذُ بِٱللّٰهِ مشنْ بَوْحِ السِّرِّ وَكَشْفِ السِّتْرِ</span> <span class="add">[<em>I seek protection by God from the appearing of the secret, and the removing of the veil,</em> or <em>covering</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bwH_1_B1">
					<p><span class="ar long">بَاحَ بِهِ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> <span class="add">[aor. as above,]</span> inf. n. <span class="ar">بَوْحٌ</span> and <span class="ar">بُؤُوحٌ</span> and <span class="ar">بُؤُوحَةٌ</span>, <span class="auth">(Ḳ, TA,)</span> <em>He revealed,</em> or <em>disclosed, it;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> namely, a secret, <span class="auth">(Ṣ, A, Ḳ,)</span> or a thing; <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">اباحهُ↓</span></span>. <span class="auth">(A, Mṣb, Ḳ.)</span> It <span class="auth">(the former)</span> is said to be from <span class="arrow"><span class="ar">الإِبَاحَهُ↓</span></span> <span class="add">[the inf. n. of the latter]</span> signifying <em>The showing</em> a thing <em>to the beholder in order that he who will may take it.</em> <span class="auth">(TA.)</span> You say,<span class="arrow"><span class="ar long">أَبَاحَهُ↓ سِرًّا فَبَاحَ بِهِ</span></span> <em>He revealed to him a secret, and he</em> <span class="auth">(the latter)</span> <span class="add">[<em>revealed it,</em> i. e.,]</span> <em>did not conceal it.</em> <span class="auth">(TA.)</span> And <span class="ar long">بُحْ بِٱسْمِكَ وَلَا تَكْنِ عَنْهُ</span> <span class="add">[<em>Reveal thou thy name, and make not a mere allusion to it</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwH_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابوح</span> ⇒ <span class="ar">اباح</span></h3>
				<div class="sense" id="bwH_4_A1">
					<p><span class="ar">اباح</span>, inf. n. <span class="ar">إِبَاحَةٌ</span>: <a href="#bwH_1">see 1</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwH_4_A2">
					<p><span class="ar">إِبَاحَةٌ</span> and<span class="arrow"><span class="ar">اِسْتِبَاحَةٌ↓</span></span> are used as syn.: but it is said that the former signifies The <em>making</em> a thing <em>allowable,</em> or <em>free,</em> to him who desires it, or seeks it: and the latter, the <em>taking</em> a thing <em>as allowed, allowable, free,</em> or <em>lawful.</em> <span class="auth">(MF.)</span> You say, <span class="ar long">اباح الشَّىْءَ</span> <em>He made the thing allowable,</em> or <em>free.</em> <span class="auth">(L.)</span> And <span class="ar long">اباح مَالَهُ</span> <em>He gave permission either to take or let alone his property; made it allowable,</em> or <em>free, either way one might choose to take.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أَبَحْتُكَ الشَّىْءَ</span> <em>I made,</em> or <em>have made, the thing allowable, free,</em> or <em>lawful, to thee,</em> <span class="auth">(Ṣ, L, Ḳ, TA,)</span> <em>to take it,</em> <span class="add">[<em>or let it alone,</em>]</span> <em>or do it,</em> <span class="add">[<em>or make use of it,</em>]</span> <em>or possess it;</em> but not by the law of the religion, for to do this belongs to God and his apostle; except in the language of this law. <span class="auth">(MF, TA.)</span> <span class="add">[Hence it is said that]</span> <span class="ar">إِبَاحَةٌ</span> bears a signification similar to <a href="#nuhobae">that of <span class="ar">نُهْبَى</span></a> <span class="add">[i. e. <em>Spoliation; a taking of spoil;</em> or the <em>taking</em> a thing <em>as spoil;</em> a signification more properly belonging to the inf. n. of 10, q. v.]</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwH_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبوح</span> ⇒ <span class="ar">استباح</span></h3>
				<div class="sense" id="bwH_10_A1">
					<p><span class="ar">استباحهُ</span> <em>He deemed it,</em> or <em>esteemed it, to be allowed, allowable, free,</em> or <em>lawful;</em> namely, the property of another: <span class="auth">(A:)</span> or <em>he took it as allowed, allowable,</em>, &amp;c. <span class="auth">(A,* MF.)</span> <a href="#bwH_4">See 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwH_10_A2">
					<p><em>He took it as spoil,</em> or <em>plunder.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwH_10_A3">
					<p><em>He made an attack upon it;</em> namely, the property of another. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bwH_10_A4">
					<p><em>He took him captive, making him as a lawful possession to him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bwH_10_A5">
					<p>And <span class="ar">اِسْتَبَاحَهُمْ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">اِسْتَبَاحُوهُمْ</span>, <span class="auth">(Ṣ,)</span> <em>He,</em> or <em>they, extirpated,</em> or <em>exterminated, them.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buwHN">
				<h3 class="entry"><span class="ar">بُوحٌ</span></h3>
				<div class="sense" id="buwHN_A1">
					<p><span class="ar">بُوحٌ</span> has the following various significations assigned to it in explanations of the saying, <span class="ar long">اِبْنُكَ ٱبْنُ بُوحِكَ يَشْرَبُ مِنْ صَبُوحِكَ</span>: <span class="auth">(Ṣ, TA:)</span> The <em>penis:</em> <span class="auth">(Ṣ, Ḳ, Ḥar p. 336:)</span> the <span class="ar">فَرْج</span> <span class="add">[or <em>pudendum,</em> app. meaning, of a woman]</span>: <span class="auth">(Ḳ, Ḥar p. 328 on the authority of AO:)</span> the <span class="ar">نَفْس</span> <span class="add">[meaning one's <em>self</em>]</span>: <span class="auth">(IAạr, T, Ṣ, Meyd, L:)</span> <em>coitus;</em> syn. <span class="ar">وَطْءٌ</span> <span class="auth">(Ṣ)</span> or <span class="ar">جِمَاعٌ</span>: <span class="auth">(Ḳ:)</span> and accord. to the last but one of these renderings, <span class="add">[and virtually accord. to the others also,]</span> the saying means <em>Thy son is the son of thyself,</em> <span class="add">[<em>who drinks of thy morningdraught</em>]</span>; <span class="auth">(T, TA;)</span> <em>he whom thou hast begotten,</em> not he whom thou hast adopted: <span class="auth">(IAạr, and Mṭr in Ḥar p. 328:)</span> or <span class="ar">بوح</span>, here, <a href="#baAHapN">is pl. of <span class="ar">بَاحَةٌ</span></a>; <span class="auth">(A, TA, Ḥar p. 336;)</span> and the meaning is, <em>he who has been born within the courts of thy house;</em> <span class="auth">(A;)</span> or, <em>in the court of thy house,</em> <span class="auth">(TA, Ḥar,)</span> not in the house of another: <span class="auth">(TA:)</span> or <span class="ar">بوح</span> is here a subst. from <span class="ar long">بَاحَ الشَّىْءِ</span>; and the meaning is, <em>thy son is he whom thou hast openly acknowledged</em> (<span class="ar long">بُحْتَ بِهِ</span>), and whom his mother hath also, agreeably with thee: <span class="auth">(Ḥar p. 328:)</span> <span class="add">[accord. to some,]</span> it signifies also <em>i. q.</em> <span class="ar">أَصْلٌ</span> <span class="add">[i. e. <em>origin;</em> or <em>race,</em> or <em>stock,</em> which it may mean in the saying above: or <em>original,</em> or <em>primary, state,</em> or <em>condition</em>]</span>; <span class="auth">(Ḳ, Ḥar p. 328;)</span> <span class="add">[for]</span> one says, <span class="ar long">رَجَعَ إِلَى بُوحِهِ</span> <span class="add">[<em>He returned,</em> or <em>reverted, to his original,</em> or <em>primary, state,</em> or <em>condition</em>]</span>. <span class="auth">(Ḥar p. 328.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAHapN">
				<h3 class="entry"><span class="ar">بَاحَةٌ</span></h3>
				<div class="sense" id="baAHapN_A1">
					<p><span class="ar">بَاحَةٌ</span> The <em>court;</em> or <em>a spacious vacant part,</em> or <em>portion, in which is no building;</em> syn. <span class="ar">سَاحَةٌ</span>, <span class="auth">(Ṣ A, Ḳ,)</span> and <span class="ar">عَرْصَةٌ</span>; <span class="auth">(A, TA;)</span> of a house or dwelling: <span class="auth">(Ṣ, TA:)</span> pl. <span class="ar">بُوحٌ</span> <span class="add">[q. v.]</span>. <span class="auth">(A, TA.)</span> Hence <span class="add">[is said to be derived]</span> <span class="ar long">بُحْبُوحَةُ الدَّارِ</span> <span class="add">[<a href="index.php?data=02_b/027_bH">mentioned in art. <span class="ar">بح</span></a>]</span>. <span class="auth">(TA.)</span> One says also, <span class="ar long">نَحْنُ فِى بَاحَةِ الدَّارِ</span>, meaning <em>We are in the middle,</em> or <em>midst,</em> or <em>best part, of the abode,</em> or <em>district,</em> or <em>country;</em> i. e. <span class="ar">أَوْسَطِهَا</span>. <span class="auth">(TA.)</span> And hence, accord. to Fr, <span class="ar">تَبَحْبَحَ</span> <span class="add">[<a href="index.php?data=02_b/027_bH">explained in art. <span class="ar">بح</span></a>]</span>. <span class="auth">(Az, TA.)</span> It is said in a trad., <span class="ar long">لَيْسَ لِلنِّسَآءِ مِنْ بَاحَةِ الطَّرِيقِ شَىْءٌ</span>, meaning <span class="add">[<em>Women have no right</em>]</span> <em>in the middle of the road.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: <span class="ar">بَاحَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAHapN_A2">
					<p>Also The <em>main part</em> or <em>body of water:</em> <span class="auth">(Ḳ:)</span> applied by most of the lexicologists to the <em>sea.</em> <span class="auth">(TA.)</span> <span class="add">[In the present day applied to <em>A deep part of the sea, distant from land;</em> the <em>deep;</em> the <em>main,</em> or <em>main sea.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوح</span> - Entry: <span class="ar">بَاحَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAHapN_A3">
					<p>And <em>Many palm-trees.</em> <span class="auth">(Aboo-Sárim El-Bahdalee, IAạr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawaAHFA">
				<h3 class="entry"><span class="ar">بَوَاحًا</span></h3>
				<div class="sense" id="bawaAHFA_A1">
					<p><span class="ar long">أَمَرَهُ بِمَعْصِيَةٍ بَوَاحًا</span> <em>He ordered him to disobey,</em> or <em>rebel, openly.</em> <span class="auth">(Ḳ.)</span> The last word occurs in this sense in two trads.; but in one of them, accord. to one recital, it is <span class="ar">بَرَاحًا</span>. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baWuwHN">
				<span class="pb" id="Page_0274"></span>
				<h3 class="entry"><span class="ar">بَؤُوحٌ</span></h3>
				<div class="sense" id="baWuwHN_A1">
					<p><span class="ar long">هُوَ بَؤُوحٌ بِمَا فِى صَدْرِهِ</span> <em>He is one who reveals,</em> or <em>discloses, what is in his bosom;</em> as also <span class="ar">بَيْحَانٌ</span> and <span class="ar">بَيَّحَانٌ</span>; <span class="auth">(Ḳ;)</span> the <span class="ar">ى</span> being originally <span class="ar">و</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaAHN">
				<h3 class="entry"><span class="ar">مُبَاحٌ</span></h3>
				<div class="sense" id="mubaAHN_A1">
					<p><span class="ar">مُبَاحٌ</span> <em>Allowed</em> or <em>allowable</em> <span class="add">[<em>to be taken, or let alone, or done, or made use of, or possessed;</em> <a href="#bwH_4">see 4</a>]</span>; <em>made allowable, free,</em> or <em>lawful; contr. of</em> <span class="ar">مَحْظُورٌ</span>. <span class="auth">(Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmubiyHu">
				<h3 class="entry"><span class="ar">المُبِيحُ</span></h3>
				<div class="sense" id="AlmubiyHu_A1">
					<p><span class="ar">المُبِيحُ</span> <em>The lion.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0273.pdf" target="pdf">
							<span>Lanes Lexicon Page 273</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0274.pdf" target="pdf">
							<span>Lanes Lexicon Page 274</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
