<article class="root" id="Root_bgl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/149_bgD">بغض</a></span>
				<span class="ar">بغل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/151_bgm">بغم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgl_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغل</span></h3>
				<div class="sense" id="bgl_1_A1">
					<p><span class="ar">بَغُلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْغُلُ</span>}</span></add>, inf. n. <span class="ar">بُغُولَةٌ</span>, said of a man, <em>i. q.</em> <span class="ar">تَبَلَّدَ</span> <span class="add">[i. e. † <em>He affected stupidity, dulness,</em> or <em>want of intelligence;</em> or <em>he became submissive, and humble;</em>, &amp;c.]</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#bgl_2">See also 2</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bgl_1_B1">
					<p><span class="ar">بَغَلَهُمْ</span>: <a href="#bgl_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgl_2">
				<h3 class="entry">2. ⇒ <span class="ar">بغّل</span></h3>
				<div class="sense" id="bgl_2_A1">
					<p><span class="ar">تَبْغِيلٌ</span>, the inf. n., signifies † The <em>being big, thick,</em> or <em>rude, and hard, strong,</em> or <em>sturdy, in body;</em> or said of the body: and hence, accord. to some, is derived <span class="arrow"><span class="ar">بَغْلٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bgl_2_A2">
					<p><span class="ar">بغّل</span>, inf. n. as above, ‡ <em>He was impotent and weak,</em> or <em>languid, and fatigued,</em> <span class="auth">(JK, Ḳ, TA,)</span> <em>in going,</em> or <em>pace.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bgl_2_A3">
					<p><span class="ar long">بغّلت الإِبِلُ</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ, Ḳ,)</span> ‡ <em>The camels went a pace between that termed</em> <span class="ar">هَمْجَلَة</span> <em>and that termed</em> <span class="ar">عَنَق</span>: <span class="auth">(Ṣ,* Ḳ, TA:)</span> and hence <span class="arrow"><span class="ar">بَغْلٌ↓</span></span> is derived accord. to IDrd: <span class="auth">(TA:)</span> or <em>they went in a certain manner, with wide step:</em> <span class="auth">(JK:)</span> <span class="add">[<a href="#bgl_5">see also 5</a>:]</span> or the inf. n. signifies the <em>going in a gentle manner:</em> and one says, <span class="ar long">أَعْيَا فَبَغَّلَ</span>, i. e. <span class="add">[<em>he was fatigued, so</em>]</span> <em>he went an easy, but a quick, pace;</em> syn. <span class="ar">هَمْلَجَ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bgl_2_B1">
					<p><span class="ar">بَغَّلَهُمْ</span>, <span class="auth">(inf. n. as above, TA,)</span> ‡ <em>He made their children to be base-born,</em> or <em>ignoble,</em> <span class="auth">(Ḳ, TA,)</span> by marrying among them; <span class="auth">(IDrd, TA;)</span> as also<span class="arrow"><span class="ar">بَغَلَهُمْ↓</span></span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَلُ</span>}</span></add>: <span class="auth">(Ḳ:)</span> from <span class="ar">بَغْلٌ</span>; because the <span class="ar">بغل</span> <span class="add">[or mule]</span> is unable to equal the heat, or course, of the horse. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبغّل</span></h3>
				<div class="sense" id="bgl_5_A1">
					<p><span class="ar">تبغّل</span> <em>He</em> <span class="auth">(a camel)</span> <em>became like the</em> <span class="ar">بَغْل</span> <span class="add">[or <em>mule</em>]</span> <em>in the width of his step.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bgl_2">See also 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagolN">
				<h3 class="entry"><span class="ar">بَغْلٌ</span></h3>
				<div class="sense" id="bagolN_A1">
					<p><span class="ar">بَغْلٌ</span> The <em>mule;</em> i. e. the <em>animal generated between the he-ass and the mare</em> <span class="add">[or sometimes <em>between the horse and the she-ass</em>]</span>; <span class="auth">(TA;)</span> also called <span class="arrow"><span class="ar">بَغَّالٌ↓</span></span>; so in a verse of Jereer: <span class="auth">(Ṣ, Ṣgh:)</span> pl. <span class="ar">أَبْغَلٌ</span> <span class="add">[a pl. of pauc.]</span> <span class="auth">(JK)</span> and <span class="ar">أَبْغَالٌ</span>, <span class="add">[also]</span> a pl. of pauc., <span class="auth">(Mṣb,)</span> and <span class="ar">بِغَالٌ</span>, <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> a pl. of mult.; <span class="auth">(Mṣb;)</span> and quasi-pl. n. <span class="arrow"><span class="ar">مَبْغُولَآءُ↓</span></span>, <span class="auth">(Ḳ,)</span> meaning <em>a number of mules</em> (<span class="ar">بِغَال</span>) <em>together:</em> <span class="auth">(JK,* Ṣ:)</span> the female is termed <span class="ar">بَغْلَةٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> pl. <span class="ar">بَغَلَاتٌ</span> and <span class="ar">بِغَالٌ</span>. <span class="auth">(Mṣb.)</span> <a href="#bgl_2">See 2</a>, in two places. You say <span class="ar long">طَرِيقٌ فِيهِ أَبْوَالُ البِغَالِ</span> <span class="add">[<em>A road in which is the urine of mules</em>]</span>; meaning † <em>a difficult road.</em> <span class="auth">(TA.)</span> And <span class="ar long">فُلَانَةُ أَعْقَرُ مِنْ بَغْلَةٍ</span> <span class="add">[<em>Such a woman is more barren than a she-mule</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">البَغْلُ نَغْلٌ وَهُوَ لَهُ أَهْلٌ</span> <span class="add">[<em>The mule is a bastard, and he is a relation to him</em>]</span>; meaning † <em>he is a bastard.</em> <span class="auth">(TA.)</span> And as the mule suggests the idea of evil disposition, or perverseness, and roughness, you say, in describing him who is low, or ignoble, <span class="ar long">هُوَ بَغْلٌ نَغْلٌ</span> † <span class="add">[<em>he is a mule, a bastard</em>]</span>. <span class="auth">(Er-Rághib, TA.)</span> The people of Egypt say, <span class="ar long">اِشْتَرَى فُلَانٌ بَغْلَةً حَسْنَآءَ</span>, meaning ‡ <span class="add">[<em>Such a one bought a beautiful</em>]</span> <em>female slave:</em> and <span class="ar long">فِى بَيْتِ بَنِى فُلَانٍ بِغَالٌ</span> <span class="add">[‡ <em>In the house of the sons of such a one are slaves,</em> or <em>female slaves</em>]</span>: and <span class="ar long">اِشْتَرَيْتُ مِنْ بِغَالِ اليَمَنْ وَلٰكِنْ بِغَالِى الثَّمَنْ</span> <span class="add">[‡ <em>I bought of the slaves,</em> or <em>female slaves, of El-Yemen, but for a high price</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagBaAlN">
				<h3 class="entry"><span class="ar">بَغَّالٌ</span></h3>
				<div class="sense" id="bagBaAlN_A1">
					<p><span class="ar">بَغَّالٌ</span> <span class="add">[n. un. of <span class="arrow"><span class="ar">بَغَّالَةٌ↓</span></span>, which is a coll. gen. n., like <span class="ar">حَمَّارَةٌ</span> and <span class="ar">جَمَّالَةٌ</span>, but explained by Freytag as meaning “he who possesses many mules;”]</span> <em>An owner,</em> or <em>attendant,</em> <span class="auth">(Sb, Ṣ,)</span> <em>of mules,</em> <span class="auth">(Sb, TA,)</span> or <em>of the mule.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغل</span> - Entry: <span class="ar">بَغَّالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bagBaAlN_B1">
					<p><a href="#bagolN">See also <span class="ar">بَغْلٌ</span></a>, with which it is syn.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bagBaAlapN">
				<h3 class="entry"><span class="ar">بَغَّالَةٌ</span></h3>
				<div class="sense" id="bagBaAlapN_A1">
					<p><span class="ar">بَغَّالَةٌ</span>: <a href="#bagBaAlN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabogalu">
				<h3 class="entry"><span class="ar">أَبْغَلُ</span></h3>
				<div class="sense" id="Oabogalu_A1">
					<p><span class="ar long">هُوَ مِنَ الثَّوْرِ أَبْغَلُ وَمِنَ الحِمَارِ أَثْقَلُ</span> † <span class="add">[<em>He is more mulish than the bull, and more heavy,</em> or <em>sluggish, than the ass</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboguwlaMCu">
				<h3 class="entry"><span class="ar">مَبْغُولَآءُ</span></h3>
				<div class="sense" id="maboguwlaMCu_A1">
					<p><span class="ar">مَبْغُولَآءُ</span>: <a href="#bagolN">see <span class="ar">بَغْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0230.pdf" target="pdf">
							<span>Lanes Lexicon Page 230</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
