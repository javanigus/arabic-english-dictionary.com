<article class="root" id="Root_bzw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/096_bzm">بزم</a></span>
				<span class="ar">بزو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/098_bs">بس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bzw_1">
				<h3 class="entry">1. ⇒ <span class="ar">بزو</span> ⇒ <span class="ar">بزى</span></h3>
				<div class="sense" id="bzw_1_A1">
					<p><span class="ar">بَزَا</span>, aor. <span class="ar">يَبْزُو</span>, <em>i. q.</em> <span class="ar">تَطَاوَلَ</span> <span class="add">[app. as meaning <em>He stretched out his neck, looking at a thing far off</em>]</span>; <span class="pb" id="Page_0201"></span>and <span class="ar">تَأَنَّسَ</span> <span class="add">[here meaning the same, or <em>he looked, raising his head;</em> said of a hawk, or falcon]</span>: <span class="auth">(Az, ISd, Ḳ:)</span> and hence IJ says that <span class="arrow"><span class="ar">بَازٌ↓</span></span> is <span class="add">[originally]</span> of the measure <span class="ar">فَلْعٌ</span> from this verb: <span class="auth">(TA: <span class="add">[and it is said in the Ḳ that <span class="ar">بَازٍ</span> seems to be hence derived:]</span>)</span> for <span class="add">[or <span class="ar">تطاول</span> may here be used in another sense; for, accord. to Fei,]</span> <span class="ar">بَزَا</span>, aor. as above, signifies <em>he overcame,</em> or <em>subdued;</em> and hence is derived <span class="arrow"><span class="ar">بَازٍ↓</span></span>. <span class="auth">(Mṣb.)</span> You say also, <span class="ar long">بَزَا عَلَيْهِ</span>, aor. as above, meaning <span class="ar">تطاول</span> <span class="add">[i. e., thus followed by <span class="ar">عليه</span>, <em>He held up his head with an assumption of superiority over him; behaved haughtily towards him; exalted himself above him;</em> or <em>overpowered, subdued,</em> or <em>oppressed, him</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">بُزِىَ بِالقَوْمِ</span> <em>The people,</em> or <em>company of men, were overcome,</em> or <em>subdued.</em> <span class="auth">(TA.)</span> And <span class="ar">بَزَاهُ</span>, aor. as above, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَزْوٌ</span>, <span class="auth">(TA,)</span> <em>He overcame,</em> or <em>subdued, him;</em> and <em>laid violent hands upon him,</em> or <em>assaulted him;</em> as also<span class="arrow"><span class="ar long">ابزى↓ بِهِ</span></span>: <span class="auth">(Ḳ:)</span> or this last signifies <em>he overcame him,</em> and <em>subdued him:</em> <span class="auth">(Ṣ:)</span> and <span class="ar">بَزَاهُ</span>, <em>he wronged him;</em> or <em>treated him wrongfully,</em> or <em>injuriously:</em> and<span class="arrow"><span class="ar">ابزاهُ↓</span></span> may signify the same; or this may mean <em>he induced him to become</em> <span class="ar">أَبْزَى</span>, q. v.: <span class="auth">(Ḥam p. 502:)</span> and accord. to Aboo-Riyásh, <span class="arrow"><span class="ar">ابزى↓</span></span> signifies <em>he pressed heavily upon his adversary,</em> or <em>imposed on him that which he was unable to do,</em> or <em>to bear, in order to treat him wrongfully,</em> or <em>injuriously.</em> <span class="auth">(Ḥam pp. 104 and 105.)</span> <span class="add">[It is said that]</span> <span class="ar">بَزَوَانٌ</span> <span class="add">[an inf. n. of which the verb, if it have one, is <span class="ar">بَزَا</span>,]</span> signifies the act of <em>Leaping;</em> syn. <span class="ar">وَثْبٌ</span>. <span class="auth">(Ṣ: <span class="add">[but I think it not improbable that this may have been taken from a mistranscription of <span class="ar">نَزَوَانٌ</span>, an inf. n. of <span class="ar">نَزَا</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzw_1_B1">
					<p><span class="ar">بَزِىَ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْزَوُ</span>}</span></add>; <span class="auth">(Ḥam p. 502;)</span> and <span class="ar">بَزَا</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْزُوُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> inf. n. <span class="ar">بَزًا</span> <span class="auth">(Ṣ,* Ḳ,* TA)</span> and <span class="ar">بَزْوٌ</span>, <span class="auth">(TA,)</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>had what is termed</em> <span class="ar">بَزًا</span>; <span class="auth">(Ḳ;)</span> i. e., <em>prominence of the breast and depression of the back:</em> <span class="auth">(Ṣ, Ḳ, and Ḥam ubi suprà:)</span> or <em>depression of the back and prominence of the belly:</em> or, as some say, <em>prominence of the breast and depression of the lower part of the belly:</em> <span class="auth">(Ḥam ubi suprà:)</span> or <em>depression of the breast and prominence of the lower part of the belly:</em> <span class="auth">(Ḥam p. 105:)</span> or <em>a bending in the back next the posteriors:</em> <span class="auth">(Ḳ, TA:)</span> or <em>a projecting of the middle of the back over the posteriors:</em> or <em>a backward bulging of the posteriors:</em> <span class="auth">(Ḳ:)</span> or <em>he was as though his posteriors projected over the hinder part of the thighs:</em> or <em>he had the breast bulging forward and the posteriors backward, so that he appeared unable to straighten his back.</em> <span class="auth">(T, TA.)</span> <span class="add">[<a href="#bzw_4">See also 4</a>.]</span> The epithet is <span class="ar">أَبْزَى</span>: fem. <span class="ar">بَزْوَآءُ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzw_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابزو</span> ⇒ <span class="ar">ابزى</span></h3>
				<div class="sense" id="bzw_4_A1">
					<p><span class="ar">ابزى</span>: <a href="#bzw_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بزو</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bzw_4_B1">
					<p>Also, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">إِبْزَآءٌ</span>, <span class="auth">(AʼObeyd, Ṣ,)</span> <em>He</em> <span class="auth">(a man, AʼObeyd, Ṣ)</span> <em>elevated his posteriors;</em> <span class="auth">(AʼObeyd, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">تبازى↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> or the latter signifies <em>he acted in such a manner in his walk as to cause it to be imagined that he was</em> <span class="ar">أَبْزَى</span>; <span class="auth">(Ḥam p. 105;)</span> or <em>he moved his posteriors in walking, like as does a woman;</em> or <em>he bent,</em> or <em>bowed, himself to others.</em> <span class="auth">(TA.)</span> Accord. to IAạr, <span class="ar">البزاء</span> <span class="add">[probably a mistranscription for <span class="ar">الإِبْزَآءُ</span>]</span> signifies <span class="ar">الصلف</span> <span class="add">[i. e. <span class="ar">الصَّلَفُ</span>, app. meaning <em>An extravagant affecting of elegance of carriage,</em> such as is common with women]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bzw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبازو</span> ⇒ <span class="ar">تبازى</span></h3>
				<div class="sense" id="bzw_6_A1">
					<p><span class="ar">تبازى</span>: <a href="#bzw_4">see 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزو</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bzw_6_A2">
					<p>Also <em>He stepped wide.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بزو</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bzw_6_A3">
					<p>And <em>He made a vain,</em> or <em>false, boast of abundance,</em> or <em>riches;</em> or <em>a boast of more than he possessed;</em> or <em>invested himself with that which did not belong to him.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bazowN">
				<h3 class="entry"><span class="ar">بَزْوٌ</span></h3>
				<div class="sense" id="bazowN_A1">
					<p><span class="ar">بَزْوٌ</span> The <em>equal, equivalent,</em> or <em>like,</em> of a thing. <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">أَخَذْتُ مِنْهُ بَزْوَ كَذَا</span> <span class="add">[<em>I took from him,</em> or <em>of it, the equal, equivalent,</em> or <em>like, of such a thing</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAzK">
				<h3 class="entry"><span class="ar">بَازٍ</span></h3>
				<div class="sense" id="baAzK_A1">
					<p><span class="ar">بَازٍ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بَازٌ</span> <span class="add">[<a href="index.php?data=02_b/219_bwz">mentioned in art. <span class="ar">بوز</span></a>]</span> <span class="auth">(Mṣb, TA, and so in some copies of the Ḳ in this art.)</span> and <span class="ar">بَازٌ</span> <span class="add">[<a href="../">mentioned in art. <span class="ar">بأز</span></a>]</span> and<span class="arrow"><span class="ar">بَازِىٌّ↓</span></span> <span class="auth">(TA)</span> <span class="add">[<em>A name given to several varieties of the hawk,</em> or <em>falcon;</em>]</span> <em>a species of</em> <span class="ar">صَقْر</span>, <span class="auth">(Ḳ,)</span> <em>that preys,</em> or <em>hunts or catches game;</em> <span class="auth">(Ṣ;)</span> <em>the proudest and fiercest of birds of prey, found in the country of the Turks: it is said that this name is only given to the female, and that the male is of another kind, a kite, or a white falcon</em> (<span class="ar">شَاهِين</span>), <em>and hence the varieties of form, &amp;c. in different individuals of the species: that of which the prevailing colour is white is the best, and the fullest in body, and the boldest, and the easiest to train: this variety</em> <span class="auth">(the <span class="ar">أَشْهَب</span>)</span> <em>is found only in the country of the Turks, and Armenia, and the country of the Khazar:</em> <span class="auth">(Ḳzw:)</span> <span class="add">[<a href="#baAXaqN">see also <span class="ar">بَاشَقٌ</span></a>:]</span> respecting the derivation, <a href="#bzw_1">see 1</a>, in two places: the pl. <span class="auth">(of <span class="ar">بَازٍ</span>, Ṣ, ISd, Mṣb)</span> is <span class="ar">بُزَاةٌ</span> <span class="auth">(Ṣ, ISd, Mṣb, Ḳ)</span> and <span class="ar">بَوَازٍ</span>; <span class="auth">(ISd, Ḳ;)</span> and <span class="auth">(of <span class="ar">بَازٌ</span>, Mṣb)</span> <span class="ar">بِيزَانٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">أَبْوَازٌ</span>, <span class="auth">(Mṣb,)</span> the former a pl. of mult., and the latter a pl. of pauc., <span class="auth">(TA,)</span> or the former is originally <span class="ar">بُزْيَانٌ</span> <span class="add">[and therefore <a href="#baAzK">a pl. of <span class="ar">بَازٍ</span></a>]</span>; <span class="auth">(IḲṭṭ, TA in art. <span class="ar">ميد</span>;)</span> and <span class="auth">(of <span class="ar">بَأْزٌ</span>, Ḳ in art. <span class="ar">بأز</span>,)</span> <span class="ar">أَبْؤُزٌ</span> <span class="add">[a pl. of pauc.]</span> and <span class="ar">بُؤُوزٌ</span> <span class="auth">(Ḳ in this art. and in art. <span class="ar">بأز</span>)</span> and <span class="ar">بِئْزَانٌ</span>. <span class="auth">(Ḳ in the latter art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAzieBN">
				<h3 class="entry"><span class="ar">بَازِىٌّ</span></h3>
				<div class="sense" id="baAzieBN_A1">
					<p><span class="ar">بَازِىٌّ</span>: <a href="#baAzK">see <span class="ar">بَازٍ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oabozae">
				<h3 class="entry"><span class="ar">أَبْزَى</span></h3>
				<div class="sense" id="Oabozae_A1">
					<p><span class="ar">أَبْزَى</span>, applied to a man, <span class="auth">(Ṣ, Mgh,)</span> <em>Having what is termed</em> <span class="ar">بَزًا</span>; <span class="auth">(Ṣ, Ḳ;)</span> i. e., <em>prominence of the breast and depression of the back,</em> <span class="auth">(Ṣ, Mgh, Ḳ, and Ḥam p. 105,)</span> or <em>of the part between the shoulder-blades:</em> <span class="auth">(Ḥam ubi suprà:)</span>, &amp;c.: <span class="add">[<a href="#bzw_1">see 1</a>, latter part:]</span> fem. <span class="ar">بَزْوَآءُ</span>: <span class="auth">(Ṣ, Ḳ:)</span> the masc. is sometimes coupled with <span class="ar">أَبْزَخُ</span>; and the fem., with <span class="ar">بَزْخَآءُ</span>, applied to an old woman who, when she walks, is as though she were bowing down her head and body: and the fem. is said by some to signify <em>sticking out her posteriors to be seen of men.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubozK">
				<h3 class="entry"><span class="ar">مُبْزٍ</span></h3>
				<div class="sense" id="mubozK_A1">
					<p><span class="ar long">هُوَ مُبْزٍ بِهٰذَا الأَمْرِ</span> <em>He is strong,</em> or <em>able, to perform this affair; a prudent,</em> or <em>sound, manager thereof.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0200.pdf" target="pdf">
							<span>Lanes Lexicon Page 200</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0201.pdf" target="pdf">
							<span>Lanes Lexicon Page 201</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
