<article class="root" id="Root_blgm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/178_blg">بلغ</a></span>
				<span class="ar">بلغم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/180_blq">بلق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="balogamN">
				<h3 class="entry"><span class="ar">بَلْغَمٌ</span></h3>
				<div class="sense" id="balogamN_A1">
					<p><span class="ar">بَلْغَمٌ</span> <span class="add">[<em>Phlegm;</em>]</span> <em>one of the four</em> <span class="add">[<em>natural constituents termed</em>]</span> <span class="ar">طَبَائِع</span>; <span class="auth">(Ṣ;)</span> <span class="add">[i. e.]</span> <em>one of the humours</em> (<span class="ar">أَخْلَاط</span>) <em>of the body.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بلغم</span> - Entry: <span class="ar">بَلْغَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="balogamN_A2">
					<p>And hence, ‡ <em>A heavy,</em> or <em>sluggish, person, who is a great talker,</em> or <em>babbler.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="balogamieBN">
				<h3 class="entry"><span class="add">[<span class="ar">بَلْغَمِىٌّ</span>]</span></h3>
				<div class="sense" id="balogamieBN_A1">
					<p><span class="add">[<span class="ar">بَلْغَمِىٌّ</span> <em>Of,</em> or <em>relating to, phlegm; phlegmatic.</em>]</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0252.pdf" target="pdf">
							<span>Lanes Lexicon Page 252</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
