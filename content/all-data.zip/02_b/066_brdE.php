<article class="root" id="Root_brdE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/065_brd">برد</a></span>
				<span class="ar">بردع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/067_brcE">برذع</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="barodaEapN">
				<h3 class="entry"><span class="ar">بَرْدَعَةٌ</span></h3>
				<div class="sense" id="barodaEapN_A1">
					<p><span class="ar">بَرْدَعَةٌ</span>: <a href="#barocaEapN">see <span class="ar">بَرْذَعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0186.pdf" target="pdf">
							<span>Lanes Lexicon Page 186</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
