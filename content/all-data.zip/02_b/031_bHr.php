<article class="root" id="Root_bHr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/030_bHvr">بحثر</a></span>
				<span class="ar">بحر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/032_bx">بخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bHr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بحر</span></h3>
				<div class="sense" id="bHr_1_A1">
					<p><span class="ar">بَحَرَ</span>, <span class="auth">(TA,)</span> <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْحَرُ</span>}</span></add>,]</span> inf. n. <span class="ar">بَحْرٌ</span>, <span class="auth">(Ḳ,)</span> <em>He slit; cut,</em> or <em>divided, lengthwise; split;</em> or <em>clave;</em> <span class="auth">(Ḳ, TA;)</span> <em>and enlarged,</em> or <em>made wide.</em> <span class="auth">(TA.)</span> Hence the term <span class="ar">بَحْرٌ</span> <span class="add">[as meaning “a sea” or “great river”]</span> is said to be derived, because what is so called is cleft, or trenched, in the earth, and the trench is made the bed of its water. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHr_1_A2">
					<p><span class="ar">بَحَرَهَا</span>, <span class="auth">(M,)</span> or <span class="ar long">بَحَرَ أُذُنَهَا</span>, <span class="auth">(Ṣ, A, Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْحَرُ</span>}</span></add>, <span class="auth">(M, Mṣb,)</span> inf. n. <span class="ar">بَحْرٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>He slit her</em> <span class="auth">(a camel's, Ṣ, M, A, Mṣb, and a sheep's or goat's, M)</span> <em>ear,</em> <span class="auth">(Ṣ, M, A, Mṣb, Ḳ,)</span> <em>in halves,</em> or <em>in halves lengthwise,</em> <span class="auth">(M, TA,)</span> <em>widely;</em> <span class="auth">(B;)</span> and in like manner, <span class="ar">بَحَرَهُ</span> <em>he slit his</em> <span class="auth">(a camel's)</span> <em>ear widely:</em> <span class="auth">(B:)</span> and<span class="arrow"><span class="ar long">بحّر↓ آذَانَ الأَنْعَامِ</span></span>, inf. n. <span class="ar">تَبْحِيرٌ</span>, <em>He slit</em> <span class="add">[&amp;c.]</span> <em>the ears of the cattle.</em> <span class="auth">(Az, TA in art. <span class="ar">بتك</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bHr_1_B1">
					<p><span class="add">[<span class="ar">بَحُرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْحُرُ</span>}</span></add>, inf. n. <span class="ar">بَحَارَةٌ</span>, <em>It was,</em> or <em>became, wide,</em> or <em>spacious.</em> The inf. n. is mentioned in the A: <a href="#baHorN">see <span class="ar">بَحْرٌ</span></a>: <a href="#bHr_10">and see also 10</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bHr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بحّر</span></h3>
				<div class="sense" id="bHr_2_A1">
					<p><a href="#bHr_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابحر</span></h3>
				<div class="sense" id="bHr_4_A1">
					<p><span class="ar">ابحر</span> <em>He embarked</em> <span class="add">[or <em>voyaged</em>]</span> <em>upon the sea</em> or <em>a great river.</em> <span class="auth">(Yaạḳoob, Ṣ, M, Ḳ.)</span> <span class="add">[Opposed to <span class="ar">أَبَرَّ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHr_4_A2">
					<p>‡ <em>It</em> <span class="auth">(water, Ḳ, sweet water Ṣ, A)</span> <em>was,</em> or <em>became, salt.</em> <span class="auth">(Ṣ, A,* Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bHr_4_A3">
					<p><span class="ar long">أَبْحَرَتِ الأَرْضُ</span> <em>The land abounded with places where water stagnated.</em> <span class="auth">(T, Ḳ.* <span class="add">[In the latter, <span class="ar">مَنَافِعُهَا</span> is put by mistake for <span class="ar">مَنَاقِعُهَا</span>. <a href="#baHorapN">See <span class="ar">بَحْرَةٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bHr_4_B1">
					<p>† <em>He found</em> water <em>to be salt; not easy,</em> or <em>pleasant, to be drunk.</em> <span class="auth">(Ḳ, TA. <span class="add">[In some copies of the Ḳ, for <span class="ar long">لَمْ يَسُغْ</span>, we find <span class="ar long">لَمْ يَمْتَنِعْ</span>, which is evidently a mistake.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bHr_4_C1">
					<p><em>He met,</em> or <em>met with,</em> a man <em>unintentionally:</em> <span class="auth">(M, Ḳ:)</span> from the phrase, <span class="ar long">لَقِيتُهُ صَحْرَةَ بَحْرَةَ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبحّر</span></h3>
				<div class="sense" id="bHr_5_A1">
					<p><span class="ar">تبحّر</span>: <a href="#bHr_10">see 10</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHr_5_A2">
					<p>Also † <em>He</em> <span class="auth">(a pastor)</span> <em>took a wide range</em> in abundant pasturage. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bHr_5_A3">
					<p><span class="ar long">تبحّر فِى المَالِ</span> ‡ <em>He enlarged himself,</em> or <em>he became,</em> or <em>made himself, ample,</em> or <em>abundant, in wealth,</em> or <em>camels,</em> or <em>the like;</em> <span class="auth">(Ḳ,* TA;)</span> as also<span class="arrow"><span class="ar long">استبحر↓ فيه</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bHr_5_A4">
					<p><span class="ar long">تبحّر فِى العِلْمِ</span> ‡ <em>He went deep into science,</em> or <em>knowledge, and enlarged himself,</em> or <em>took a wide range, therein,</em> <span class="auth">(Ṣ, A, Ḳ,)</span> <em>wide as the sea;</em> <span class="auth">(TA;)</span> and in like manner one says with respect to other things: <span class="auth">(Ṣ:)</span> and so<span class="arrow"><span class="ar long">استبحر↓ فيه</span></span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبحر</span></h3>
				<div class="sense" id="bHr_10_A1">
					<p><span class="ar">استبحر</span> ‡ <em>It</em> <span class="auth">(a place)</span> <em>became wide,</em> or <em>spacious, like the sea:</em> <span class="auth">(A:)</span> <em>it spread wide; became expanded;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">تبحّر↓</span></span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#baHura">See also <span class="ar">بَحُرَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHr_10_A2">
					<p>‡ <em>He</em> <span class="auth">(a poet, A, Ḳ, and a <span class="ar">خَطِيب</span>, <span class="add">[i. e. a speaker, an orator, or the like,]</span> A)</span> <em>expatiated in speech; was,</em> or <em>became, diffuse therein.</em> <span class="auth">(M, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bHr_10_A3">
					<p><a href="#bHr_5">See also 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHorN">
				<h3 class="entry"><span class="ar">بَحْرٌ</span></h3>
				<div class="sense" id="baHorN_A1">
					<p><span class="ar">بَحْرٌ</span> <span class="add">[<em>A sea:</em> and <em>a great river:</em>]</span> <em>a spacious place comprising a large quantity of water;</em> <span class="auth">(B;)</span> <em>a large quantity of water,</em> <span class="auth">(Ḳ, TA,)</span> <em>whether salt or sweet;</em> <span class="auth">(TA;)</span> <a href="#barBN">contr. of <span class="ar">بَرٌّ</span></a>; <span class="auth">(Ṣ, A;)</span> so called because of its depth <span class="auth">(Ṣ, TA)</span> and large extent; <span class="auth">(Ṣ, Mṣb, TA;)</span> from <span class="ar">البَحَارَةُ</span>; <span class="auth">(A;)</span> or because its bed is trenched in the earth; <a href="#bHr_1">see 1</a>: <span class="auth">(TA:)</span> or <em>a large quantity of salt water,</em> only; <span class="auth">(Ḳ;)</span> and so called because of its saltness: <span class="auth">(El-Umawee, TA: <span class="add">[but accord. to the A, this word as an epithet meaning “salt” is tropical:]</span>)</span> or rather this is its general meaning: <span class="auth">(TA:)</span> for it signifies also <em>any great river;</em> <span class="auth">(Ṣ, M, TA;)</span> <em>any river of which the water does not cease to flow;</em> <span class="auth">(Zj, T, TA;)</span> <em>such as the Euphrates,</em> for instance; <span class="auth">(Ṣ;)</span> or <em>such as the Tigris, and the Nile, and other similar great rivers of sweet water; of which the great salt</em> <span class="ar">بَحْر</span> <em>is the place of confluence;</em> so called because trenched in the earth: <span class="auth">(T, TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَبْحُرٌ</span> and <span class="add">[of mult.]</span> <span class="ar">بِحَارٌ</span> and <span class="ar">بُحُورٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> The dim. is↓<span class="ar">أُبَيْحِرٌ</span>, <span class="auth">(Ḳ,)</span> which is anomalous; and↓<span class="ar">بُحَيْرٌ</span>, which is the regular form: accord. to the Ḳ, the latter is not used; but this is untrue; for it is sometimes used, though rare. <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baHorN_A2">
					<p>Hence its application in the saying of the Arabs, <span class="ar long">يَا هَادِىَ اللَّيْلِ جُرْتَ إِنَّمَا هُوَ البَحْرُ أَوِ الفَجْرُ</span>, which Th explains by saying that the meaning is, ‡ <span class="add">[<em>O guide of the night, thou hast deviated from the right way:</em>]</span> <em>it is only destruction or</em> thou wilt see <em>the daybreak:</em> the night is here likened to the sea <span class="add">[and with the night is associated the idea of destruction]</span>: but accord. to one recital, it is <span class="ar">البَجْرُ</span>, instead of <span class="ar">البَحْرُ</span>. <span class="auth">(TA. <span class="add">[<a href="index.php?data=02_b/024_bjr">See art. <span class="ar">بجر</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baHorN_A3">
					<p>Also ‡ <em>Salt;</em> as an epithet, applied to water. <span class="auth">(Ṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baHorN_A4">
					<p>‡ <em>A fleet,</em> or <em>swift, and excellent, horse;</em> <span class="auth">(Aṣ, Ḳ;)</span> <em>that runs much;</em> <span class="auth">(Aṣ, TA;)</span> <em>that takes a wide range in his running;</em> <span class="auth">(Ṣ, A, Mṣb, B;)</span> <em>that runs like the sea,</em> or <em>a great river;</em> or <em>like the sea,</em> or <em>a great river, when it rolls wave over wave.</em> <span class="auth">(Nifṭaweyh;, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baHorN_A5">
					<p>‡ <em>A generous man;</em> <span class="auth">(Ḳ, TA;)</span> <em>one who takes a wide range in his beneficence, bounty,</em> or <em>kindness; who abounds therein.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">لَقِيتُ بِزَيْدٍ بَحْرًا</span> ‡ <span class="add">[<em>I found, in the place of Zeyd, a man of abundant generosity</em> or <em>beneficence</em>]</span>: <span class="ar">ب</span> here denoting substitution. <span class="auth">(The Lubáb cited in the TA voce <span class="ar">بِ</span>.)</span> And <span class="ar long">لَقِيتُ مِنْهُ بَحْرًا</span> ‡ <span class="add">[<em>I found him to be a man of exceeding generosity</em>]</span>; a phrase expressing an intensive degree of generosity: and <span class="ar long">رَأَيْتُ مِنْهُ بَحْرًا</span> <span class="add">[signifies the same]</span>. <span class="auth">(Mughnee in art. <span class="ar">بِ</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baHorN_A6">
					<p>‡ <em>A man of extensive knowledge</em> or <em>science; one who takes a wide range in his knowledge</em> or <em>science.</em> <span class="auth">(B.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baHorN_A7">
					<p>‡ <em>Any person,</em> or <em>thing, that takes a wide range in a thing.</em> <span class="auth">(B.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="baHorN_A8">
					<p>† <em>Land of seed-produce and fruitfulness;</em> or <em>a tract,</em> or <em>region, in which are green herbs</em> or <em>leguminous plants, and waters;</em> or the <em>part of a country near to water;</em> syn. <span class="ar">رِيفٌ</span>: <span class="auth">(Aboo-ʼAlee, Ḳ:)</span> and the dim. <span class="arrow"><span class="ar">بُحَيْرٌ↓</span></span> is used in the same sense; or, by poetic licence, for<span class="arrow"><span class="ar">بُحَيْرَةٌ↓</span></span>. <span class="auth">(TA.)</span> So in the Ḳur <span class="add">[xxx. 40]</span>, <span class="ar long">ظَهَرَ الفَسَادُ فِى البَرِّ وَالبَحْرِ</span> † <span class="add">[<em>Corruption hath appeared in the desert,</em> or <em>deserts, and in the land of seed-produce and fruitfulness;</em>, &amp;c.]</span>: <span class="auth">(Aboo-ʼAlee, TA:)</span> <span class="pb" id="Page_0157"></span>or the meaning here is, <span class="add">[<em>in the desert,</em> or <em>deserts, and in the towns,</em> or <em>villages, in which is water:</em> (<a href="#barBN">see <span class="ar">بَرٌّ</span></a>:) or <em>in the open country and</em>]</span> <em>in the cities</em> <span class="add">[or <em>towns</em>]</span> <em>upon the rivers;</em> by sterility in the former, and scarcity in the latter: <span class="auth">(Zj, TA, and T in art. <span class="ar">بر</span>:)</span> or <em>in the land and the sea;</em> i. e., the land has become sterile, or unfruitful, and the supply of the sea has become cut off. <span class="auth">(Az, TA.)</span> <a href="#baHorapN">See also <span class="ar">بَحْرَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="baHorN_A9">
					<p>Also, <span class="ar">البَحْرُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">بَحْرُ الرَّحِمِ</span>, <span class="auth">(A, Mgh,)</span> † <em>The bottom</em> (<span class="ar">عُمْق</span>, Ṣ, A, Mgh, Ḳ, or <span class="ar">قَعْر</span>, IAth, TA) <em>of the womb; fundus uteri:</em> <span class="auth">(Ṣ, A, Mgh, Ḳ:)</span> whence blood of a pure red colour, <span class="auth">(Ṣ,)</span> or intensely red, <span class="auth">(Mgh,)</span> is termed <span class="ar">بَحْرَانِىٌّ</span> <span class="auth">(Ṣ, Mgh)</span> and <span class="ar">بَاحِرٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHorapN">
				<h3 class="entry"><span class="ar">بَحْرَةٌ</span></h3>
				<div class="sense" id="baHorapN_A1">
					<p><span class="ar">بَحْرَةٌ</span> <em>A wide tract of land:</em> so accord. to Aboo-Naṣr: but in one place he says, <em>a small valley in rugged land:</em> pl. <span class="ar">بِحَارٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baHorapN_A2">
					<p><em>A land, country,</em> or <em>territory, belonging to,</em> or <em>inhabited by, a people;</em> syn. <span class="ar">بَلْدَةٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> One says, <span class="ar long">هٰذِهِ بَحْرَتُنَا</span> <em>This is our land,</em>, &amp;c.; syn. <span class="ar">أَرْضُنَا</span>. <span class="auth">(Ṣ.)</span> It occurs also in the dim. form <span class="add">[<span class="arrow"><span class="ar">بُحَيْرَةٌ↓</span></span>]</span>, as in the Towsheeh of El-Jelál. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baHorapN_A3">
					<p><em>Any town,</em> or <em>village, that has a running river and wholesome water:</em> <span class="auth">(Ḳ:)</span> and <span class="add">[absolutely]</span> <em>any town,</em> or <em>village:</em> of such the Arabs say, <span class="ar long">هٰذِهِ بَحْرَتُنَا</span> <em>This is our town,</em> or <em>village:</em> and the pl. <span class="ar">بِحَارٌ</span> they apply to <em>cities,</em> as well as <em>towns,</em> or <em>villages.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baHorapN_A4">
					<p><em>Low,</em> or <em>depressed, land:</em> <span class="auth">(IAạr, Ḳ:)</span> occurring also in the dim. form <span class="add">[<span class="arrow"><span class="ar">بُحَيْرَةٌ↓</span></span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baHorapN_A5">
					<p><em>A meadow;</em> or <em>a garden;</em> syn. <span class="ar">رَوْضَةٌ</span>: <span class="auth">(T, TA:)</span> or <em>one that is large,</em> <span class="auth">(Ḳ,)</span> <em>and wide.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baHorapN_A6">
					<p><em>A place where water stagnates.</em> <span class="auth">(Sh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baHorapN_A7">
					<p>The pl. is<span class="arrow"><span class="ar">بَحْرٌ↓</span></span>, <span class="auth">(as in some copies of the Ḳ, <span class="add">[or this is a coll. gen. n. of which <span class="ar">بَحْرَةٌ</span> is the n. un.,]</span>)</span> or <span class="ar">بِحَرٌ</span>, <span class="auth">(as in other copies of the Ḳ and in the TA,)</span> or <span class="ar">بُحْرٌ</span>, <span class="auth">(as in the CK,)</span> and <span class="ar">بِحَارٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baHorapN_B1">
					<p><span class="ar long">لَقِيتُهُ صَحْرَةَ بَحْرَةَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar long">صُحْرَةَ بُحْرَةَ↓</span></span>, as in the Expositions of the Tesheel, &amp;c., <span class="auth">(MF,)</span> and <span class="ar long">صَحْرَةً بَحْرَةً</span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar long">صُحْرَةً بُحْرَةً↓</span></span>, <span class="auth">(MF,)</span> <em>I met him out, with nothing intervening between me and him;</em> <span class="auth">(Ṣ, L;)</span> <em>both of us being exposed to open view;</em> <span class="auth">(TA;)</span> <em>without anything concealing,</em> or <em>intervening.</em> <span class="auth">(Ḳ, TA.)</span> <span class="ar long">صحرةَ بحرةَ</span>, without tenween, is a compound denotative of state; not, as some say, consisting of two inf. ns.: and sometimes <span class="ar">نَحْرَةً</span> is added; in which case each of the three words is with tenween, decl.; and they do not form a compound. <span class="auth">(MF. <span class="add">[<a href="#SaHorap">But see <span class="ar">صَحْرَة</span></a>.)</span>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buHorapN">
				<h3 class="entry"><span class="ar">بُحْرَةٌ</span> / 
							<span class="ar">بُحْرَةَ</span> / 
							<span class="ar">بُحْرَةً</span></h3>
				<div class="sense" id="buHorapN_A1">
					<p><span class="ar long">صُحْرَةَ بُحْرَةَ</span> and <span class="ar long">صُحْرَةً بُحْرَةً</span>: <a href="#baHorapN">see <span class="ar">بَحْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHorieBN">
				<h3 class="entry"><span class="ar">بَحْرِىٌّ</span></h3>
				<div class="sense" id="baHorieBN_A1">
					<p><span class="ar">بَحْرِىٌّ</span> <em>Of,</em> or <em>relating to,</em> or <em>belonging to, the sea,</em> or <em>a great river;</em> <a href="#baHorN">rel. n. of <span class="ar">بَحْرٌ</span></a>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baHorieBN_A2">
					<p><em>A seaman; a sailor;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَحَّارٌ↓</span></span>: <span class="auth">(Ḳ:)</span> and <span class="add">[<span class="arrow"><span class="ar">بَحْرِيَّةٌ↓</span></span> and]</span> <span class="arrow"><span class="ar">بَحَّارَةٌ↓</span></span> <em>seamen; sailors.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baHorieBN_A3">
					<p><span class="add">[In the dial. of Egypt, <em>North; northern;</em> because the Mediterranean Sea lies on the north of that country: like as, in Hebrew, <span class="he">יָם</span> signifies “west;” because that sea lies on the west of Palestine.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baHoriyBapN">
				<h3 class="entry"><span class="ar">بَحْرِيَّةٌ</span></h3>
				<div class="sense" id="baHoriyBapN_A1">
					<p><span class="ar">بَحْرِيَّةٌ</span>: <a href="#baHorieBN">see <span class="ar">بَحْرِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buHoraAnN">
				<h3 class="entry"><span class="ar">بُحْرَانٌ</span></h3>
				<div class="sense" id="buHoraAnN_A1">
					<p><span class="ar">بُحْرَانٌ</span>, a post-classical word, <span class="auth">(Ṣ, Ḳ,)</span> used by the physicians, signifying The <em>crisis of a disease;</em> the <em>sudden change which happens to a sick person,</em> <span class="auth">(Ṣ, TA,)</span> and the <em>commencement of convalescence,</em> <span class="auth">(TA,)</span> <em>in acute diseases;</em> <span class="auth">(Ṣ, TA;)</span> <em>at a time fixed by some motion in the heavenly bodies, mostly by a motion of the moon;</em> being <em>a change to health or to the contrary:</em> a word <span class="add">[said to be]</span> of Greek origin. <span class="auth">(The Nuzheh of the sheykh Dáwood El-Antákee, cited in the TA.)</span> <span class="add">[Pl. <span class="ar">بَحَارِينُ</span>.]</span> They say, <span class="ar long">هٰذَا يَوْمُ بُحْرَانٍ</span> and<span class="arrow"><span class="ar long">يَوْمٌ بَاحُورِىٌّ↓</span></span> <span class="add">[<em>This is the day of a crisis of a disease</em>]</span>: <span class="ar">باحورىّ</span> being anomalous: <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[perhaps from <span class="ar">البَاحُورُ</span> signifying “the moon,” because the crisis of a disease is thought to be mostly fixed by a motion of the moon: or]</span> <a href="#baAHuwrN">as though it were a rel. n. of <span class="ar">بَاحُورٌ</span></a> and <span class="ar">بَاحُورَآءُ</span> meaning the “vehemence of heat in <span class="add">[the month of]</span> <span class="ar">تَمُّوز</span>.” <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHoraAnieBN">
				<h3 class="entry"><span class="ar">بَحْرَانِىٌّ</span></h3>
				<div class="sense" id="baHoraAnieBN_A1">
					<p><span class="ar long">دَمٌ بَحْرَانِىٌّ</span> † <em>Blood of the menses;</em> accord. to El-Ḳutabee: or † <em>intensely red blood:</em> <span class="auth">(Mgh:)</span> or † <em>intensely red, and thick, and abundant, menstrual blood:</em> <span class="auth">(IAth:)</span> or ‡ <em>black blood:</em> <span class="auth">(A:)</span> or, as also<span class="arrow"><span class="ar long">دَمٌ بَاحِرٌ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> † <em>blood of the womb:</em> <span class="auth">(Ḳ:)</span> or † <em>blood of a pure red colour:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or † <em>such blood from the belly</em>: <span class="auth">(M:)</span> or † <em>pure blood of an intensely red colour:</em> <span class="auth">(Mṣb:)</span> both from <span class="ar">البَحْرُ</span> signifying “the bottom of the womb:”: <span class="auth">(Ṣ:)</span> the former is a rel. n. therefrom, <span class="auth">(A, IAth, Mṣb,)</span> in which the <span class="ar">ا</span> and <span class="ar">ن</span> are added to give intensiveness to the signification, <span class="auth">(IAth,)</span> <a href="#AlbaHoru">or to distinguish it from the rel. n. of <span class="ar">البَحْرُ</span></a> <span class="add">[in its most common sense]</span>: <span class="auth">(Mṣb:)</span> <a href="#AlbaHoru">or it is a rel. n. of <span class="ar">البَحْرُ</span></a> <span class="add">[in its most common sense]</span>, because of its abundance. <span class="auth">(IAth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَحْرَانِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baHoraAnieBN_A2">
					<p><span class="ar long">أَحْمَرُ بَحْرَانِىٌّ</span>, and<span class="arrow"><span class="ar">بَاحِرٌ↓</span></span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بَاحِرِىٌّ↓</span></span>, <span class="auth">(IAạr, TA,)</span> † <em>Intense red.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buHayorN">
				<h3 class="entry"><span class="ar">بُحَيْرٌ</span></h3>
				<div class="sense" id="buHayorN_A1">
					<p><span class="ar">بُحَيْرٌ</span> <a href="#baHorN">dim. of <span class="ar">بَحْرٌ</span></a>, <a href="#baHorN">which see</a>, in two places</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHiyrapN">
				<h3 class="entry"><span class="ar">بَحِيرَةٌ</span></h3>
				<div class="sense" id="baHiyrapN_A1">
					<p><span class="ar">بَحِيرَةٌ</span> A she-camel <em>having her ear slit:</em> <span class="auth">(Ṣ,* A, Mṣb, Ḳ *:)</span> <span class="add">[and, as a subst., or an epithet in which the quality of a subst. is predominant,]</span> <em>a she-camel of which the mother was a</em> <span class="ar">سَائِبَة</span>; <span class="auth">(Fr, Ṣ, Mgh, Mṣb, Ḳ;)</span> i. e., <em>of which the mother had brought forth ten females consecutively before her, and of which the ear was slit;</em> <span class="auth">(Mgh;)</span> or <em>of which the mother had brought forth five, of which five the last, if a male, was slaughtered and eaten, but if a female, her ear was slit and she was left with her mother;</em> <span class="auth">(Mgh,* Mṣb;)</span> <em>the predicament of which was the same as that of her mother;</em> <span class="auth">(Fr, Ṣ, Ḳ;)</span> i. e., <em>what was unlawful with respect to her mother was unlawful with respect to herself:</em> <span class="auth">(TA:)</span> or <em>a she-camel,</em> or <em>ewe,</em> or <em>she-goat, that had brought forth five young ones, and of which the fifth, if a male, was slaughtered, and its flesh was eaten by the men and women; but if a female, her ear was slit, and it was unlawful to the Arabs to eat her flesh and to drink her milk and to ride her; but when she died, her flesh was lawful to the women:</em> <span class="auth">(Ḳ:)</span> so says Az, on the authority of Ibn-ʼArafeh: <span class="auth">(TA: <span class="add">[but it appears from the explanation in the Mṣb, quoted above, that it was the slit-eared young she-camel here mentioned, not the mother, that was thus termed:]</span>)</span> or <em>a she-camel,</em> or <em>ewe</em>, or <em>she-goat, which, having brought forth ten young ones, had her ear slit,</em> <span class="auth">(Ḳ,)</span> <em>and no use was made of her milk nor of her back,</em> <span class="auth">(TA,)</span> <em>and she was left at liberty to pasture,</em> <span class="auth">(Ḳ,)</span> <em>and to go to water,</em> <span class="auth">(TA,)</span> <em>and her flesh, when she died, was made unlawful to the women of the Arabs, but was eaten by the men:</em> <span class="auth">(Ḳ:)</span> or <em>one that was left at liberty, without a pastor:</em> <span class="auth">(Ḳ:)</span> or, as some say, <em>syn. with</em> <span class="ar">سَائِبَةٌ</span>; i. e., say they, <em>a she-camel which, having brought forth seven young ones, had her ear slit, and was not ridden, nor used for carrying:</em> <span class="auth">(Mṣb:)</span> or <em>a she-camel that had brought forth five young ones, the last of which was a male, in which case her ear was slit, and she was exempted from being ridden and from carrying and from being slaughtered, and not prevented from taking of any water to which she came, nor from any pasturage, nor even ridden by a weary man who, having become unable to proceed in his journey, his means having failed him, or his camel that bore him stopping with him from fatigue or breaking down or perishing, might chance to find her:</em> <span class="auth">(Aboo-Ishák the Grammarian, TA: <span class="add">[and the like, but less fully, is said in the Mgh:]</span>)</span> or, applied specially to a ewe, or she-goat, <em>one that, having brought forth five young ones, had her ear slit:</em> <span class="auth">(L, Ḳ, TA: <span class="add">[in the CK, for <span class="ar">بُحِرَت</span> is put <span class="ar">نُحِرَت</span>:]</span>)</span> it also signifies a she-camel <span class="auth">(L)</span> <em>abounding in milk:</em> <span class="auth">(L, Ḳ:)</span> the pl. is <span class="ar">بَحَائِرُ</span> and <span class="ar">بُحُرٌ</span>; <span class="auth">(L, Ḳ;)</span> the latter a strange form of pl. of a fem. sing. such as <span class="ar">بحيرة</span>; and said to be the only instance of the kind except <span class="ar">صُرُمٌ</span> <a href="#SariymapN">pl. of <span class="ar">صَرِيمَةٌ</span></a>, meaning “having her ear cut off.” <span class="auth">(TA.)</span> It is said in a trad., that the person who instituted the practices relative to the <span class="ar">بحيرة</span> and the <span class="ar">حَامِى</span>, and the first who altered the religion of Ishmael, was ʼAmr the son of Loheí the son of Kama'ah the son of Jundab; and these practices are forbidden in the Ḳur v. 102. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buHayorapN">
				<h3 class="entry"><span class="ar">بُحَيْرَةٌ</span></h3>
				<div class="sense" id="buHayorapN_A1">
					<p><span class="ar">بُحَيْرَةٌ</span> <em>A small sea; a lake:</em> as though they imagined the word <span class="ar">بَحْرَةٌ</span> <span class="add">[as syn. with <span class="ar">بَحْرٌ</span>]</span>: otherwise there is no reason for the <span class="ar">ة</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بُحَيْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buHayorapN_A2">
					<p><a href="#baHorN">See also <span class="ar">بَحْرٌ</span></a>: <a href="#baHorapN">and see <span class="ar">بَحْرَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baHBaArN">
				<h3 class="entry"><span class="ar">بَحَّارٌ</span></h3>
				<div class="sense" id="baHBaArN_A1">
					<p><span class="ar">بَحَّارٌ</span>: <a href="#baHorieBN">see <span class="ar">بَحْرِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baHBaArapN">
				<h3 class="entry"><span class="ar">بَحَّارَةٌ</span></h3>
				<div class="sense" id="baHBaArapN_A1">
					<p><span class="ar">بَحَّارَةٌ</span>: <a href="#baHorieBN">see <span class="ar">بَحْرِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAHirN">
				<h3 class="entry"><span class="ar">بَاحِرٌ</span></h3>
				<div class="sense" id="baAHirN_A1">
					<p><span class="ar">بَاحِرٌ</span>: <a href="#baHoraAnieBN">see <span class="ar">بَحْرَانِىٌّ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAHirieBN">
				<h3 class="entry"><span class="ar">بَاحِرِىٌّ</span></h3>
				<div class="sense" id="baAHirieBN_A1">
					<p><span class="ar">بَاحِرِىٌّ</span>: <a href="#baHoraAnieBN">see <span class="ar">بَحْرَانِىٌّ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAHuwrN">
				<h3 class="entry"><span class="ar">بَاحُورٌ</span></h3>
				<div class="sense" id="baAHuwrN_A1">
					<p><span class="ar">بَاحُورٌ</span> and↓<span class="ar">بَاحُورَآءُ</span> The <em>vehemence of heat in</em> <span class="add">[<em>the Syrian month of</em>]</span> <span class="ar">تَمُّوز</span> or <span class="ar">تَمُوز</span> <span class="add">[corresponding to <em>July, O. Ṣ.</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[pl. of the former <span class="ar">بَوَاحِيرُ</span>:]</span> both are <span class="add">[said to be]</span> post-classical words: <span class="auth">(Ṣ:)</span> but they are <span class="add">[classical words,]</span> arabicized; for they occur in verses of the kind called <span class="ar">رَجَز</span> of some of the <span class="add">[early]</span> Arabs. <span class="auth">(MF.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحر</span> - Entry: <span class="ar">بَاحُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baAHuwrN_B1">
					<p><span class="ar">البَاحُورُ</span> <em>The moon.</em> <span class="auth">(Aboo-ʼAlee, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAHuwraMCu">
				<h3 class="entry"><span class="ar">بَاحُورَآءُ</span></h3>
				<div class="sense" id="baAHuwraMCu_A1">
					<p><span class="ar">بَاحُورَآءُ</span>: <a href="#baAHuwrN">see <span class="ar">بَاحُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAHuwrieBN">
				<h3 class="entry"><span class="ar">بَاحُورِىٌّ</span></h3>
				<div class="sense" id="baAHuwrieBN_A1">
					<p><span class="ar">بَاحُورِىٌّ</span>: <a href="#buHoraAnN">see <span class="ar">بُحْرَانٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OubayoHirN">
				<h3 class="entry"><span class="ar">أُبَيْحِرٌ</span></h3>
				<div class="sense" id="OubayoHirN_A1">
					<p><span class="ar">أُبَيْحِرٌ</span>: <a href="#baHorN">dim. of <span class="ar">بَحْرٌ</span>, q. v.</a> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0156.pdf" target="pdf">
							<span>Lanes Lexicon Page 156</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0157.pdf" target="pdf">
							<span>Lanes Lexicon Page 157</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
