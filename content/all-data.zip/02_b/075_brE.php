<article class="root" id="Root_brE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/074_brTl">برطل</a></span>
				<span class="ar">برع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/076_brEm">برعم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brE_1">
				<h3 class="entry">1. ⇒ <span class="ar">برع</span></h3>
				<div class="sense" id="brE_1_A1">
					<p><span class="ar long">بَرَعَ الجَبَلَ</span> <em>He ascended,</em> or <em>ascended upon, the mountain.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brE_1_A2">
					<p>And <span class="ar long">بَرَعَ صَاحِبَهُ</span> <em>He was,</em> or <em>became, superior to his companion; he excelled him;</em> <span class="auth">(IAạr;)</span> <em>he overcame him.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brE_1_B1">
					<p><span class="ar">بَرَعَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَعُ</span>}</span></add>; <span class="auth">(Mṣb, MṢ, PṢ, <span class="add">[accord. to the TA, which is followed in the TḲ, <span class="ar">ـُ</span>, which is evidently a mistake,]</span>)</span> and <span class="ar">بَرُعَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُعُ</span>}</span></add>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and <span class="ar">بَرِعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْرَعُ</span>}</span></add>; <span class="auth">(Ṣgh, Ḳ;)</span> inf. n. <span class="ar">بُرُوعٌ</span>, <span class="auth">(M, Ḳ,)</span> which is of <span class="ar">بَرَعَ</span>, <span class="auth">(TA,)</span> and <span class="ar">بَرَاعَةٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> which is of <span class="ar">بَرُعَ</span> <span class="add">[and is the more common]</span>; <span class="auth">(Mṣb, TA;)</span> <em>He excelled in knowledge,</em> or <em>courage,</em> or <em>other qualities:</em> <span class="auth">(Mṣb:)</span> or <em>he excelled his companions in knowledge, &amp;c.:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>he was,</em> or <em>became, accomplished, perfect,</em> or <em>complete, in every excellence,</em> and <em>in goodliness.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brE_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّع</span></h3>
				<div class="sense" id="brE_5_A1">
					<p><span class="ar long">تبرّع بِالعَطَآءِ</span> <em>He gave what was not incumbent,</em> or <em>obligatory, on him; he gave supererogatorily:</em> <span class="auth">(Ḳ:)</span> or <em>he gave gratuitously, unasked,</em> or <em>unbidden:</em> <span class="auth">(TA:)</span> <em>as though he affected</em> <span class="ar">بَرَاعَة</span> <span class="add">[or <em>excellence</em>]</span> <em>therein, and generosity.</em> <span class="auth">(Z, TA.)</span> And <span class="ar long">تبرّع بِالأَمْرِ</span> <em>He did,</em> or <em>performed, the thing,</em> or <em>affair, disinterestedly; not seeking,</em> or <em>desiring, a compensation.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">تبرّع بِالجِهَادِ</span> <span class="add">[<em>He engaged unbidden,</em> or <em>disinterestedly, in war against unbelievers</em>]</span>. <span class="auth">(Mṣb in art. <span class="ar">طوع</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bariyEapN">
				<h3 class="entry"><span class="ar">بَرِيعَةٌ</span></h3>
				<div class="sense" id="bariyEapN_A1">
					<p><span class="ar">بَرِيعَةٌ</span>: <a href="#baAriEN">see <span class="ar">بَارِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAriEN">
				<h3 class="entry"><span class="ar">بَارِعٌ</span> / <span class="ar">بَارِعَةٌ</span></h3>
				<div class="sense" id="baAriEN_A1">
					<p><span class="ar">بَارِعٌ</span> Anything <em>overtopping.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برع</span> - Entry: <span class="ar">بَارِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAriEN_A2">
					<p><em>Excelling in knowledge,</em> or <em>courage,</em> or <em>other qualities:</em> <span class="auth">(Mṣb:)</span> or <em>excelling his companions in knowledge, &amp;c.:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>accomplished, perfect,</em> or <em>complete, in every excellence,</em> and <em>in goodliness:</em> <span class="auth">(Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَارِعَةٌ</span>}</span></add>. <span class="auth">(Ḳ.)</span> And<span class="arrow"><span class="ar">بَرِيعَةٌ↓</span></span>, applied to a woman, <span class="auth">(IAạr,)</span> <em>Excelling in goodliness,</em> or <em>beauty,</em> and <em>in intelligence.</em> <span class="auth">(IAạr, Ḳ.)</span> And <span class="ar">بَارِعَةٌ</span>, applied to a girl, <em>Goodly,</em> or <em>beautiful.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برع</span> - Entry: <span class="ar">بَارِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAriEN_A3">
					<p><span class="ar long">أَمْرٌ بَارِعٌ</span> <em>A case, a state,</em> or <em>condition,</em> or <em>an affair, exalted,</em> or <em>of high estimation;</em> <span class="auth">(TA;)</span> <em>goodly,</em> or <em>comely.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برع</span> - Entry: <span class="ar">بَارِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAriEN_A4">
					<p><span class="ar long">سَعْدٌ البَارعِ</span> <em>A certain</em> <span class="ar">نَجْم</span> <span class="add">[or <em>asterism</em>]</span>. <span class="auth">(TA, <span class="add">[in which it is here said to be “of the Mansions,” i. e., of the Mansions of the Moon; but it seems that <span class="ar">لَيْسَ</span>, or the like, has been omitted by a copyist; for it is said in art. <span class="ar">سعد</span>, (q. v.,)</span> on several authorities, to be not of the Mansions of the Moon.]</span>)</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboraEu">
				<h3 class="entry"><span class="ar">أَبْرَعُ</span></h3>
				<div class="sense" id="OaboraEu_A1">
					<p><span class="ar">أَبْرَعُ</span> <em>This is larger, bigger,</em> or <em>more bulky, than he,</em> or <em>it.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabarBiEFA">
				<h3 class="entry"><span class="ar">مُتَبَرِّعًا</span></h3>
				<div class="sense" id="mutabarBiEFA_A1">
					<p><span class="ar long">فَعَلَهُ مُتَبَرِّعًا</span> <em>He did it without its being incumbent,</em> or <em>obligatory, on him; supererogatorily:</em> or <em>gratuitously, unasked,</em> or <em>unbidden:</em> or <em>disinterestedly; not seeking,</em> or <em>desiring, a compensation:</em> syn. <span class="ar">مُتَطَوِّعًا</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0189.pdf" target="pdf">
							<span>Lanes Lexicon Page 189</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
