<article class="root" id="Root_bgD">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/148_bgX">بغش</a></span>
				<span class="ar">بغض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/150_bgl">بغل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bgD_1">
				<h3 class="entry">1. ⇒ <span class="ar">بغض</span></h3>
				<div class="sense" id="bgD_1_A1">
					<p><span class="ar">بَغُضَ</span>; <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> and <span class="ar">بَغَضَ</span>; aor. <span class="add">[of both]</span> <span class="ar">ـُ</span>; <span class="pb" id="Page_0230"></span>and <span class="ar">بَغِضَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْغَضُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> inf. n. <span class="ar">بَفَاضَةٌ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> inf. n. of the first; <span class="auth">(TA;)</span> <em>He,</em> or <em>it,</em> <span class="auth">(a man, Ṣ, or a thing, Mṣb,)</span> <em>was,</em> or <em>became, hateful, odious,</em> or <em>an object of hatred.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bgD_1_A2">
					<p><span class="ar long">بَغُضَ جَدُّهُ</span> ‡ <em>His fortune,</em> or <em>good fortune, fell;</em> syn. <span class="ar">عَثَرَ</span>. <span class="auth">(A.)</span> And <span class="ar long">بَغُضَ جَدُّكَ</span>, <span class="auth">(L, Ḳ, TA,)</span> or <span class="ar">بَغَضَ</span>, <span class="auth">(as in one copy of the Ḳ,)</span> or <span class="ar">بَغِضَ</span>, <span class="auth">(as in the CK,)</span> ‡ <em>May thy fortune,</em> or <em>good fortune, fall:</em> syn. <span class="ar">تَعَسَ</span>, <span class="auth">(Ḳ, TA,)</span> and <span class="ar">عَثَرَ</span>: <span class="auth">(TA:)</span> a phrase ascribed by IB to the people of El-Yemen. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bgD_1_B1">
					<p><a href="#bgD_4">See also 4</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgD_2">
				<h3 class="entry">2. ⇒ <span class="ar">بغّض</span></h3>
				<div class="sense" id="bgD_2_A1">
					<p><span class="ar long">بغّضهُ ٱللّٰهُ إِلَى النَّاسِ</span>, <span class="auth">(Ṣ, TA,)</span> or <span class="ar">لِلنَّاسِ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[but this I think doubtful, from what is said in explanation of the verb of wonder, (<a href="#bgD_4">see 4</a>,)]</span> inf. n. <span class="ar">تَبْغِيضٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>God rendered him hateful, odious,</em> or <em>an object of hatred, to men;</em> <span class="auth">(Ṣ, Mṣb;*)</span> <span class="ar">تَبْغِيضٌ</span> being the <em>contr. of</em> <span class="ar">تَحْبِيبٌ</span>: <span class="auth">(Ḳ:)</span> or <em>very hateful</em> or <em>odious.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">حُبِّبَ إِلَىَّ زَيْدٌ وَبُغِّضَ إِلَىَّ عَمْرٌو</span> <span class="add">[<em>Zeyd was rendered an object of love to me, and ʼAmr was rendered an object of hatred,</em> or <em>of much hatred, to me</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgD_3">
				<h3 class="entry">3. ⇒ <span class="ar">باغض</span></h3>
				<div class="sense" id="bgD_3_A1">
					<p><span class="ar">بَاغَضْتُهُ</span>, inf. n. <span class="ar">مُبَاغَضَةٌ</span>, <em>I rendered him</em> <span class="add">[<em>hatred,</em> or]</span> <em>vehement hatred, reciprocally.</em> <span class="auth">(A,* TA.)</span> You say also, <span class="ar long">بَيْنَهُمَا مُبَاغَضَةٌ</span> <span class="add">[<em>Between them two is reciprocal hatred,</em> or <em>vehement hatred</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgD_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابغض</span></h3>
				<div class="sense" id="bgD_4_A1">
					<p><span class="ar">ابغضهُ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِبْغَاضٌ</span>, <span class="auth">(Mṣb,)</span> <em>He hated him.</em> <span class="auth">(Ṣ, A,* Mṣb,* Ḳ.)</span> It is said that <span class="arrow"><span class="ar">بَغَضَهُ↓</span></span> is not allowable: <span class="auth">(Mṣb:)</span> or <span class="ar">يَبْغُضُنِى</span> is a bad form; <span class="auth">(AḤát, Ḳ;)</span> used by the lower class; and sanctioned by Th only; for he explains <span class="ar">قَالِينَ</span>, as occurring in the Ḳur <span class="add">[xxvi. 168]</span>, by <span class="ar">بَاغِضِينَ</span>, which shows that he held <span class="ar">بَغَضَ</span> to be a dial. var.; for otherwise he would have said <span class="ar">مُبْغِضِينَ</span>: <span class="auth">(AḤát:)</span> but the epithet <span class="ar">بَغُوضٌ</span> affords a strong evidence in favour of the opinion of Th here mentioned; for <span class="ar">فَعُولٌ</span> is mostly from <span class="ar">فَاعِلٌ</span>, not from <span class="ar">مُفْعِلٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغض</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bgD_4_B1">
					<p><span class="ar long">مَا أَبْغَضَهُ إِلَىَّ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">لِى</span>, <span class="auth">(Ḳ,)</span> is <span class="add">[said to be]</span> anomalous; <span class="auth">(Ṣ, Ḳ;)</span> because the verb of wonder is not regularly formed from a verb of the measure <span class="ar">أَفْعَلَ</span>; but this is not anomalous; for it is from <span class="ar long">بَغَضَ فُلَانٌ إِلَىَّ</span> <span class="add">[“such a one was, or became, hateful, or odious, to me:” <span class="ar long">ما ابغضه الىّ</span> signifying <em>How hateful,</em> or <em>odious, is he to me!</em> but <span class="ar long">ما ابغضه لِى</span>, <em>How he hates me!</em> for]</span> the lexicologists and grammarians relate that <span class="ar long">مَا أَبْغَضَنِى لَهُ</span> is said when thou hatest him; and <span class="ar long">ما ابغضنى إِلَيْهِ</span>, when he hates thee: <span class="auth">(IB:)</span> ISd says, on the authority of Sb, that <span class="ar long">ما ابغضنى له</span> means that thou art an object of hatred (<span class="ar">مُبْغَضٌ</span> <span class="add">[so in the TA, but this is evidently a mistake for <span class="ar">مُبْغِضٌ</span>, a hater,]</span>) to him; and <span class="ar long">ما ابغضه الىّ</span>, that he is an object of hatred with thee, or in thine estimation. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغض</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bgD_4_C1">
					<p><span class="ar long">أَنْعَمَ ٱللّٰهُ بِكَ عَيْنًا وَأَبْغَضَ بِعَدُوِّكَ عَيْنًا</span>, <span class="auth">(so in the A, and the latter verb thus in the JK and in the L,)</span> or the former verb is <span class="ar">نَعِمَ</span>, <span class="auth">(L, Ḳ,)</span> and the latter <span class="arrow"><span class="ar">بَغَضَ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> like <span class="ar">نَصَرَ</span>, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">بَغِضَ↓</span></span>, <span class="auth">(CK,)</span> is a form of imprecation <span class="auth">(TA)</span> ‡ <span class="add">[app. meaning <em>May God make thine eye to be refreshed by the sight of him whom thou lovest, and make the eye of thine enemy to be pained by the sight of him whom he hateth:</em> or <em>may God make an eye to be refreshed by the sight of thee, and make an eye to be affected with hatred by the sight of thine enemy</em>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgD_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبغّض</span></h3>
				<div class="sense" id="bgD_5_A1">
					<p><span class="ar">تبغّض</span> <em>He manifested,</em> or <em>showed, hatred;</em> or <em>he became,</em> or <em>made himself, an object of hatred; contr. of</em> <span class="ar">تَحَبَّبَ</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">تَحَبَّبَ لِى فُلَانٌ وَتَبَغَّضَ لِى أَخُوهُ</span> <span class="add">[<em>Such a one manifested love to me,</em> or <em>made himself an object of love to me, and his brother manifested hatred to me,</em> or <em>made himself an object of hatred to me</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bgD_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباغض</span></h3>
				<div class="sense" id="bgD_6_A1">
					<p><span class="ar long">تباغض القَوْمُ</span> <em>The company of men hated one another:</em> <span class="auth">(Mṣb:)</span> <span class="ar">تَبَاغُضٌ</span> is the <em>contr. of</em> <span class="ar">تَحَابُبٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">مَا رَأَيْتُ أَشَدَّ تَبَاغُضًا مِنْهُمَا</span> <span class="add">[<em>I have not seen any more vehement in mutual hatred than they two</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bugoDN">
				<h3 class="entry"><span class="ar">بُغْضٌ</span></h3>
				<div class="sense" id="bugoDN_A1">
					<p><span class="ar">بُغْضٌ</span> <em>Hatred; contr. of</em> <span class="ar">حُبُّ</span>: <span class="auth">(Ṣ, A, Ḳ:)</span> a subst. from <span class="ar">أَبْغَضَهُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bigoDapN">
				<h3 class="entry"><span class="ar">بِغْضَةٌ</span></h3>
				<div class="sense" id="bigoDapN_A1">
					<p><span class="ar">بِغْضَةٌ</span> <em>Vehement hatred;</em> as also<span class="arrow"><span class="ar">بَغْضَآءُ↓</span></span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بَغَاضَةٌ↓</span></span> <span class="add">[<a href="#bgD_1">but see 1</a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بغض</span> - Entry: <span class="ar">بِغْضَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bigoDapN_B1">
					<p><a href="#bagiyDN">See also <span class="ar">بَغِيضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bagoDaMCu">
				<h3 class="entry"><span class="ar">بَغْضَآءُ</span></h3>
				<div class="sense" id="bagoDaMCu_A1">
					<p><span class="ar">بَغْضَآءُ</span>: <a href="#bigoDapN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baguwDN">
				<h3 class="entry"><span class="ar">بَغُوضٌ</span></h3>
				<div class="sense" id="baguwDN_A1">
					<p><span class="ar">بَغُوضٌ</span>: <a href="#bagiyDN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bagiyDN">
				<h3 class="entry"><span class="ar">بَغِيضٌ</span></h3>
				<div class="sense" id="bagiyDN_A1">
					<p><span class="ar">بَغِيضٌ</span> <em>Hateful; odious; and object of hatred:</em> <span class="auth">(Ṣ, A, Mṣb,* Ḳ:)</span> <em>hated;</em> as also<span class="arrow"><span class="ar">بَغُوضٌ↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">مُبْغَضٌ↓</span></span>: <span class="auth">(Mṣb,* TA:)</span> pl. of the first, <span class="ar">بُغَضَآءُ</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بغض</span> - Entry: <span class="ar">بَغِيضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bagiyDN_A2">
					<p>Some say that it has also the contr. signification of <em>Hating; i. q.</em> <span class="arrow"><span class="ar">مُبْغِضٌ↓</span></span>: <span class="auth">(TA:)</span> and Skr explains <span class="arrow"><span class="ar">بِغْضَةٌ↓</span></span> as signifying people <em>hating</em> thee. <span class="auth">(L, TA.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bagaADapN">
				<h3 class="entry"><span class="ar">بَغَاضَةٌ</span></h3>
				<div class="sense" id="bagaADapN_A1">
					<p><span class="ar">بَغَاضَةٌ</span>: <a href="#bigoDapN">see <span class="ar">بِغْضَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubogaDN">
				<h3 class="entry"><span class="ar">مُبْغَضٌ</span></h3>
				<div class="sense" id="mubogaDN_A1">
					<p><span class="ar">مُبْغَضٌ</span>: <a href="#bagiyDN">see <span class="ar">بَغِيضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubogiDN">
				<h3 class="entry"><span class="ar">مُبْغِضٌ</span></h3>
				<div class="sense" id="mubogiDN_A1">
					<p><span class="ar">مُبْغِضٌ</span>: <a href="#bagiyDN">see <span class="ar">بَغِيضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabogaDapN">
				<h3 class="entry"><span class="ar">مَبْغَضَةٌ</span></h3>
				<div class="sense" id="mabogaDapN_A1">
					<p><span class="ar">مَبْغَضَةٌ</span> <span class="add">[<em>A cause of hatred:</em> a word of the same class as <span class="ar">مَبْخَلَةٌ</span> and <span class="ar">مَجْبَنَةٌ</span>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0229.pdf" target="pdf">
							<span>Lanes Lexicon Page 229</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0230.pdf" target="pdf">
							<span>Lanes Lexicon Page 230</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
