<article class="root" id="Root_bdO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/041_bd">بد</a></span>
				<span class="ar">بدأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/043_bdr">بدر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bdO_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدأ</span></h3>
				<div class="sense" id="bdO_1_A1">
					<p><span class="ar long">بَدَأَ بِهِ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْدَأُ</span>}</span></add>, <span class="auth">(Mgh, Ḳ,)</span> inf. n. <span class="ar">بَدْءٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb,)</span> i. q.<span class="arrow"><span class="ar long">ابتدأ↓ به</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <span class="add">[<em>He began with it;</em>]</span> <em>he made it to have precedence,</em> or <em>to be first; gave precedence to it;</em> syn. <span class="ar">قَدَّمَهُ</span>: <span class="auth">(Mgh, Mṣb:)</span> in the dial. of the Ansár, <span class="ar long">بَدِئَ به</span> is used in this sense of <span class="ar">قدّمه</span>; <span class="auth">(M;)</span> or <span class="ar long">بَدِىَ به</span> <span class="add">[without <span class="ar">ء</span>]</span>; <span class="auth">(IḲṭṭ, TA; <span class="add">[<a href="#badpCN">see <span class="ar">بَدةءٌ</span></a>;]</span>)</span> <span class="add">[and <span class="ar long">بَدَى به</span>; <a href="index.php?data=02_b/049_bde">see art. <span class="ar">بدى</span></a>;]</span> and<span class="arrow"><span class="ar long">ابدأ↓ به</span></span> signifies the same. <span class="auth">(Mṣb.)</span> <span class="add">[So in the Ḳur xii. 76, <span class="ar long">فَبَدَأَ بِأَوْعِيَتِهِمْ قَبْلَ وِعَآءِ أَخِيهِ</span> <em>And he began with their bags, before the bags of his brother.</em> And <span class="ar">بَدَأَهُ</span> is sometimes used in the sense of <span class="ar long">بَدَأَ بِهِ</span>; whence, in the Ḳur ix. 13, <span class="ar long">وَهُمْ بَدَؤُوكُمْ أَوَّلَ مَرَّةٍ</span> <em>And they,</em> it was, <em>began with you the first time;</em> i. e., as Bḍ says, by acting with hostility, and fighting.]</span> You say also, <span class="ar long">بَدَّا ثُمَّ عَادَ</span> <em>He began,</em> or <em>did a first time,</em> or <em>the first time: then repeated,</em> or <em>did a second time.</em> <span class="auth">(Az, TA in art. <span class="ar">عود</span>.)</span> And <span class="ar long">بَدَأَ فِىِ الأَمْرِ</span> <span class="add">[<em>He began,</em> or <em>made a beginning, in the affair.</em>]</span> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdO_1_A2">
					<p><span class="ar">بَدَأَ</span> also signifies <em>It</em> <span class="auth">(a thing)</span> <em>began; began to be; originated;</em> or <em>came into existence.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#bdA5">See also 5</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdO_1_B1">
					<p><span class="ar long">بَدَأَ الشَّيْءَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> aor. and inf. n. as above, <span class="auth">(M,)</span> <span class="add">[<em>He began the thing; commenced it; set about it;</em> as also<span class="arrow"><span class="ar">ابتدأهُ↓</span></span>: accord. to the Mgh, the latter has this meaning, or, agreeably with the authority of the M and Ḳ, the meaning which here next follows:]</span> <em>he did the thing first, for the first time, by way of beginning,</em> or <em>originally;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابدأهُ↓</span></span> and<span class="arrow"><span class="ar">ابتدأهُ↓</span></span>; <span class="auth">(M, Ḳ;)</span> i. e., <em>not after the example of anything preceding.</em> <span class="auth">(TA. <span class="add">[But this addition seems rather to belong to another explanation to be mentioned below.]</span>)</span> One does not say,<span class="arrow"><span class="ar long">ابتدأ↓ زَيْدًا</span></span> nor <span class="ar">بَدَأَهُ</span>, because these two verbs <span class="add">[signifying as last explained above]</span> do not have for their objects corporeal things. <span class="auth">(Mgh.)</span> <span class="add">[El-Mutanakhkhil El-Hudhalee uses the phrase <span class="ar long">سَأَبْدُؤُهُمْ بِمَشْمَعِةٍ</span> <em>I will begin with them</em> <span class="auth">(meaning his guests)</span> <em>by sporting and jesting;</em> like the phrase in the Ḳur ix. 13 cited above: but different from these is the saying in the Ḳur xxxii. 6, <span class="ar long">وَبَدَأَ خَلْقِ ٱلْإِنْسَانِ مِنْ طِينٍ</span> <em>And He began the creation of man from clay.</em>]</span> The saying,<span class="arrow"><span class="ar long">فَإِنْ كَانَ السَّبُعُ ٱبْتَدَأَهُ↓</span></span> means <span class="ar long">ابتدأ أَخْذَهُ أَوْ عَضَّهُ</span> <span class="add">[<em>But if the beast,</em> or <em>bird, of prey has begun the seizing of him, or the biting of him</em>]</span>; the noun that is prefixed <span class="add">[to the pronoun]</span> being suppressed. <span class="auth">(Mgh.)</span> You say also,<span class="arrow"><span class="ar long">كَانَ ذٰلِكَ فِى ٱبْتِدَآءِ↓ الأَمْرِ</span></span> <em>That was in the beginning,</em> or <em>first, of the affair.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#badoCN">See also <span class="ar">بَدْءٌ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bdO_1_B2">
					<p><em>He originated the thing; brought it into being</em> or <em>existence; made it,</em> or <em>produced it, for the first time, it not having been before;</em> <span class="auth">(Mgh;)</span> <span class="add">[and]</span> so <span class="arrow"><span class="ar">ابدأهُ↓</span></span>, said <span class="add">[of God, and]</span> of a man, as the agent; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">ابتدأهُ↓</span></span>. <span class="auth">(Mgh in art. <span class="ar">بدع</span>.)</span> <span class="add">[Hence,]</span> <span class="ar long">بَدَأَ ٱللّٰهُ الخَلْقَ</span>, and<span class="arrow"><span class="ar">أَبْدَأَهُمْ↓</span></span>, <em>God created,</em> or <em>brought into existence, mankind,</em> or <em>the created beings:</em> <span class="auth">(M, Mṣb, Ḳ:)</span> both signify the same. <span class="auth">(Ṣ.)</span> <span class="arrow"><span class="ar long">مَا يُبْدِئُ↓ البَاطِلُ وَمَا يُعِيدُ</span></span> <span class="add">[in the Ḳur xxxiv. 48, means <em>What doth that which is false,</em> or <em>the Devil, originate,</em> or <em>produce in the first instance? and what doth it,</em> or <em>he, reproduce</em> after it hath perished?]</span>: Zj says that <span class="ar">مَا</span>, here, is in the place of an accus., meaning in each Instance <span class="ar long">أَىَّ شَىْءٍ</span>: or it may be a negative; and <span class="ar">الباطل</span> here is Iblees; i. e., <em>Iblees createth not, nor raiseth to life</em> after death. <span class="auth">(M.)</span> You say also,<span class="arrow"><span class="ar long">مَا يُبْدِئُ↓ وَمَا يُعِيدُ</span></span>, meaning<span class="arrow"><span class="ar long">مَا يَتَكَلَّمُ بِبَادِئَةٍ↓ وَلَا عَائِدَةٍ</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> i. e. <em>He does not say anything for the first time, nor anything for the second time;</em> or <em>anything original, nor anything in the way of repetition;</em> <span class="arrow"><span class="ar long">بَادِئَةُ↓ الكَلَامِ</span></span> signifying <em>what is said for the first time;</em> and <span class="ar long">عَائِدَةُ الكَلَامِ</span>, <em>what is said for the second time, afterwards:</em> <span class="auth">(TA:)</span> or <em>he says not anything:</em> <span class="auth">(A in art. <span class="ar">عود</span>:)</span> and <em>he has no art, artifice,</em> or <em>cunning.</em> <span class="auth">(IAạr, TA in art. <span class="ar">عود</span>; and A in the present art.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bdO_1_B3">
					<p><span class="ar long">بَدَأَ البِئْرَ</span> <em>He dug the well</em> <span class="add">[<em>for the first time:</em> <a href="#badieoCN">see <span class="ar">بَدِىْءٌ</span></a>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bdO_1_C1">
					<p><span class="ar long">بَدَأَ مِنْ أَرْضٍ إِلَى أَرْضٍ</span>, <span class="auth">(T,)</span> or <span class="ar long">مِنْ أَرْضِهِ</span>, <span class="auth">(Ḳ,)</span> <em>He went forth from a land to a land,</em> or <em>from his land;</em> as also<span class="arrow"><span class="ar">ابدأ↓</span></span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="bdO_1_D1">
					<p><span class="ar">بُدِئَ</span>, <span class="auth">(inf. n. as above, Ṣ, M, Ḳ,)</span> <em>He</em> <span class="auth">(a man, Ṣ, M)</span> <em>had the small-pox:</em> <span class="auth">(AZ, Aṣ, T, Ṣ, M, Ḳ:)</span> or <em>the</em> <span class="ar">حَصْبَة</span> <span class="add">[i. e. <em>measles,</em> or <em>spotted fever</em>]</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> or, as AZ says, and <em>the</em> <span class="ar">حصبة</span>: <span class="auth">(T:)</span> or, as Lḥ says, <em>there came forth upon him pustules resembling the small-pox:</em> but he adds, some say, <em>the small-pox itself:</em> <span class="auth">(M:)</span> the epithet applied to a person affected therewith is <span class="arrow"><span class="ar">مَبْدُوْءٌ↓</span></span>. <span class="auth">(AZ, Aṣ, Lḥ, T, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: D2</span>
				</div>
				<div class="sense" id="bdO_1_D2">
					<p>Also <em>He fell sick.</em> <span class="auth">(IAth, TA.)</span> In a trad. of ' Áïsheh occur the words, <span class="ar long">فِى اليَوْمِ الَّذِى بُدِئَ فِيهِ رَسُولِ ٱللّٰهِ</span> <span class="add">[meaning <em>In the day in which the Apostle of God fell sick</em>]</span>: and IAth says, <span class="ar long">مَتَى بُدِئَ فُلَانٌ</span> meaning <em>When did such a one fall sick?</em> is a phrase used in inquiring respecting the living <span class="add">[who has been attacked by illness]</span> and respecting the dead. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdO_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابدأ</span></h3>
				<div class="sense" id="bdO_4_A1">
					<p><span class="ar">ابدأ</span>: <a href="#bdA1">see 1</a>, in seven places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdO_4_A2">
					<p>Also <em>He did a new thing; a thing unknown before;</em> or <em>a strange,</em> or <em>wonderful, thing.</em> <span class="auth">(Ṣ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bdO_4_A3">
					<p>And <em>He voided excrement,</em> or <em>ordure;</em> or <em>broke wind;</em> syn. <span class="ar">نَجَا</span>; <span class="add">[as also <span class="ar">أَبْدَى</span>;]</span> said of a man. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bdO_4_A4">
					<p>And <em>He put forth his second teeth;</em> said of a child; <span class="auth">(M;)</span> and of a colt. <span class="auth">(TA voce <span class="ar">أَحْفَرَ</span>, q. v.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdO_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبدّأ</span></h3>
				<div class="sense" id="bdO_5_A1">
					<p><span class="ar">تبدّأ</span> <em>He,</em> or <em>it, began,</em> or <em>made a beginning.</em> <span class="auth">(KL.)</span> <span class="add">[<a href="#bdA1">See also 1</a>. Golius mentions, but without giving the authority, and without the vowel-signs, the saying, <span class="ar long">هَاتِ القِصَّةَ مِنْ ذِى تُبُدِّئَتْ</span>; but writing the last word <span class="ar">تبديت</span>, stating only that it is in the passive form; as meaning <em>Relate thou the story,</em> or <em>history, from the beginning.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdO_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتدأ</span></h3>
				<div class="sense" id="bdO_8_A1">
					<p><a href="#bdA1">see 1</a>, in seven places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdO_8_A2">
					<p><span class="ar long">ابتدأهُ بِوَعْدٍ</span> <em>He made him a promise in anticipation; without his asking it of him.</em> <span class="auth">(M in art. <span class="ar">انف</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badCN">
				<h3 class="entry"><span class="ar">بَدءٌ</span></h3>
				<div class="sense" id="badCN_A1">
					<p><span class="ar">بَدءٌ</span> inf.n. of 1; <span class="auth">(T, Ṣ, M, Mṣb;)</span> <span class="add">[The act of <em>beginning;</em>]</span> or the <em>doing</em> a thing <em>first.</em> <span class="auth">(M.)</span> You say, <span class="ar long">لَكَ البَدْءُ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">البُدْءُ↓</span></span>, <span class="auth">(Aṣ, TA,)</span> and<span class="arrow"><span class="ar">البَدْأَةُ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">البُدْأَةُ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">البِدْأَةُ↓</span></span>, <span class="auth">(L,)</span> and<span class="arrow"><span class="ar">البَدَآءَةُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">البُدَآءَةُ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">البُدَاهَةُ</span>, with <span class="ar">ه</span> substituted for <span class="ar">ء</span>, <span class="auth">(M, Mṭr,)</span> and<span class="arrow"><span class="ar">البِدَآءَةُ↓</span></span>, <span class="auth">(Mṭr, TA,)</span> and, accord. to IḲṭṭ, <span class="ar">البِدَايَةُ</span>, but see what follows, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">البَدِئَةُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">البُدَّآءَةُ↓</span></span>, <span class="auth">(AZ, TA,)</span> <em>It is for thee to begin,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>before any other,</em> in shooting or casting, &amp;c.: <span class="auth">(Ṣ:)</span> as to <span class="ar">البِدَايَةُ</span>, mentioned above, accord. to Mṭr <span class="add">[and Fei]</span>, <span class="auth">(TA,)</span> it is a vulgar word, <span class="auth">(Mgh, Mṣb, TA,)</span> as IB and several others have stated, <span class="auth">(Mṣb, TA,*)</span> a corruption of <span class="arrow"><span class="ar">البِدَآءَةُ↓</span></span>, <span class="auth">(Mgh, Mṣb,)</span> signifying <em>the first;</em> as also<span class="arrow"><span class="ar">البُدَآءَةُ↓</span></span>; and<span class="arrow"><span class="ar">البَدْأَةُ↓</span></span>: <span class="auth">(Mṣb:)</span> but IḲṭṭ says that it is a word of the dial. of the Ansár; <span class="ar long">بَدَأْتُ بِالشَّىْءِ</span> and <span class="ar long">بَدِيتُ بِهِ</span> signifying <span class="ar">قَدَّمْتُهُ</span>: <span class="add">[<a href="#bdA1">see 1</a>:]</span> and he cites the following verse of Ibn-Rawáhah:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بِٱسْمِ ٱلْإِلَاهِ وَبِهِ بَدِينَا</span> *</div> 
						<div class="star">* <span class="ar long">وَلَوْ عَبَدْنَا غَيْرَهُ شَقِينَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>In the name of God, and with it we begin; and if we worshipped any other than Him, we should be miserable</em>]</span>: <a href="index.php?data=02_b/049_bde">see art. <span class="ar">بدى</span></a>. <span class="auth">(TA. <span class="add">[This verse is also cited in the Ṣ in art. <span class="ar">بدو</span>, where, in one copy I find it as above; in another, with <span class="ar">بَدَيْنَا</span> instead of <span class="ar">بَدِيْنَا</span>.]</span>)</span> And you say, <span class="ar long">فَعَلَهُ عَوْذَا وَبَدْءًا</span>, <span class="auth">(T, Ṣ,)</span> and <span class="ar long">عَوْدَهُ عَلَى بَدْئِهِ</span>, <span class="auth">(M,)</span> and <span class="ar long">فِى عَوْدِهِ وَبَدْئِهِ</span>, and<span class="arrow"><span class="ar long">فِى عَوْدَتِهِ وَبَدْأَتِهِ↓</span></span>, <span class="auth">(Ṣ, M,)</span> <span class="add">[<em>He did it returning and beginning</em> again; or <em>returning to his beginning;</em> i. e. <em>he did it again from the beginning; he recommenced it:</em> or you say this]</span> meaning like as is meant by the saying next following. <span class="auth">(TA.)</span> <span class="ar long">رَجَعَ عَوْدَهُ عَلَى بَدْئِهِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar long">عَوْدًا عَلَى بَدْءٍ</span>, in both of which <span class="add">[and in the last following]</span> the verb may be trans., and the noun following therefore in the accus. case, <span class="auth">(TA,)</span> and <span class="ar long">فِى عَوْدِهِ وَبَدْئِهِ</span>, and<span class="arrow"><span class="ar long">فِى عَوْدَتِهِ وَبَدْأَتِهِ↓</span></span>, <span class="add">[in both of which, if correct, the verb must be intrans.,]</span> and <span class="ar long">عَوْدًا وَبَدْءًا</span>, <span class="add">[as though meaning <span class="ar long">عَائِدًا وَبَادِئًا</span>, used as a phrase denotative of state,]</span> <span class="auth">(Ḳ,)</span> <span class="add">[but in this last, and the two next preceding, accord. to the TA, the verb should be <span class="ar">فَعَلَهُ</span>, as in the next preceding sentence, instead of <span class="ar">رَجَعَ</span>, and this is confirmed by what is said in the Ḳ in art. <span class="ar">عود</span>,]</span> <em>He returned in the way whence he had come:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[accord. to the TA, the literal meaning of the first and second may be <em>he made his returning to revert to his beginning,</em> and <em>he made a returning to revert to a beginning:</em>]</span> or the meaning of the first, <span class="auth">(Sb, TA in art. <span class="ar">عود</span>, and Ḳ in that art.,)</span> and of the second, <span class="auth">(Ḳ in that art.,)</span> is, <em>he returned without stopping after he had gone away:</em> <span class="auth">(Sb, Ḳ:)</span> and sometimes it signifies the stopping in one's coming and then returning: <span class="auth">(Sb:)</span> <span class="add">[and <em>it returned to its first state; it recommenced:</em>]</span> and you say, <span class="ar long">رَجَعْتُ عَوْدِى عَلَى بَدْئِى</span>, meaning <em>I returned like as I had come.</em> <span class="auth">(Sb ubi suprà.)</span></p>
				</div>
				<span class="pb" id="Page_0164"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badCN_A2">
					<p>Also <em>First, or former; preceding all others,</em> or <em>preceding another;</em> as also<span class="arrow"><span class="ar long">البَدْءُ بَدِىْءٌ↓</span></span>; and <span class="ar">البَدِئُ</span> being syn. with <span class="ar">الأَوَّلُ</span>. <span class="auth">(Ṣ, Ḳ.)</span> Hence the saying, <span class="ar long">اِفْعَلْهُ بَادِى بَدْءٍ</span>, and<span class="arrow"><span class="ar long">بَادِى بَدِىْءٍ↓</span></span>, meaning <em>Do thou it the first thing,</em> or <em>the first of everything;</em> <span class="add">[accord. to different copies of the Ṣ;]</span> the <span class="ar">ى</span> in <span class="ar">بادى</span> being quiescent, in the place of the accus. case, accord. to usage; and sometimes they omit the <span class="add">[altogether]</span>, on account of frequent use <span class="add">[of the phrase]</span>, <a href="index.php?data=02_b/048_bdw">as will be stated in art. <span class="ar">بدو</span></a>, <span class="auth">(Ṣ in the present art.,)</span> saying <span class="ar long">بَادِى بَدٍ</span>, and <span class="ar">بَادِىبَدِى</span> <span class="auth">(Ṣ in art. <span class="ar">بدو</span>.)</span> You say also, <span class="ar long">اِفْعَلْهُ بَدْءًا</span>, and <span class="ar long">أَوَّلَ بَدْءٍ</span>, <span class="auth">(Th, M, Ḳ,)</span> and <span class="ar long">بَدْءَ بَدْءٍ</span>, <span class="auth">(CK,)</span> and <span class="ar long">بَدَا بَدْءٍ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar long">بَادِئَ↓ بَدْءٍ</span></span>, <span class="auth">(AʼObeyd, T, Ṣ, M, Ḳ,)</span> and <span class="ar long">بَادِىَ بَدٍ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar long">بَادِىْ بَدًا</span>, <span class="auth">(M, Ḳ, <span class="add">[in the CK <span class="ar long">بَادِىْ بَدٍ</span>,]</span>)</span> and <span class="ar long">بَادِىْ بَدًا</span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar long">بَادِئَ↓ بَدَا</span></span>, <span class="auth">(Ḳ,)</span> and <span class="ar long">بَادِىْ بَدَا</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar long">بَادِئَ↓ بَدِىْءٍ↓</span></span>, <span class="auth">(AʼObeyd, T, Ṣ, M, CK,)</span> and<span class="arrow"><span class="ar long">بَادِئَ↓ بَدِىٍّ</span></span>, which is anomalous, <span class="auth">(M,)</span> or <span class="ar long">بَادِىَ بَدِّىِ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar long">بَادِىْ بَدِيٍّ</span>, <span class="auth">(Fr, AʼObeyd, T, Ṣ, M,)</span> and<span class="arrow"><span class="ar long">بَادِئَ↓ بَدِئٍ↓</span></span>, <span class="auth">(Ṣ, CK,)</span> or<span class="arrow"><span class="ar long">بَادِىَ بَدِئٍ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> and<span class="arrow"><span class="ar long">بَادِىْ بَدْأَةَ↓</span></span>, <span class="auth">(M, Ḳ, TA,)</span> the former word being the act. part. n. of <span class="ar">بَدِىَ</span>, which is of the dial. of the Ansár, as mentioned above, and the latter being indecl., with fet-ḥ for its termination, <span class="auth">(TA, <span class="add">[in the CK the latter word is written <span class="ar">بَدْءَة</span>,]</span>)</span> and<span class="arrow"><span class="ar long">بَدْأَةَ↓ بَدْءٍ</span></span>, <span class="auth">(CK,)</span> and<span class="arrow"><span class="ar long">بَدْأَةَ بَدْأَةَ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar long">بَدْأَةَ↓ بَدِىْءٍ↓</span></span>, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar long">بَدِىْءَ↓ بَدْءٍ</span></span>, <span class="auth">(Ṣ, CK,)</span> and <span class="ar long">بَدْءَ ذِى بَدْءٍ</span>, <span class="auth">(Fr, T,)</span> and<span class="arrow"><span class="ar long">بَدْأَةَ↓ ذِى بَدْءٍ</span></span>, <span class="auth">(Fr, T, Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar long">بَدْأَةَ ذِى بَدْأَةٍ↓</span></span>, and<span class="arrow"><span class="ar long">بَدْأَةَ↓ ذِى بَدِىْءٍ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar long">بَدَأَةَ↓ ذِى بَدَآءَةَ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> not <span class="ar">بداءة</span> <span class="add">[as in the CK]</span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar long">بَدِىْءَ ذِى بَدِىْءٍ↓</span></span>, <span class="auth">(Ṣ, Ḳ, TA, <span class="add">[in the CK the last word is written <span class="ar">بَدْءٍ</span>,]</span>)</span> and<span class="arrow"><span class="ar long">بَدَآءَةِ↓ ذِى بَدِىْءٍ↓</span></span>, <span class="auth">(Ḳ,)</span> meaning <em>Do thou it the first thing;</em> <span class="auth">(Fr, T, Ḳ;)</span> so in a correct copy <span class="add">[of the Ḳ, and so I find in a MṢ. copy of the Ḳ and in the CK]</span>: accord. to another copy, <em>the first of everything:</em> <span class="auth">(TA:)</span> or <em>the first of first;</em> <span class="auth">(Ṣ;)</span> thus in the L: <span class="auth">(TA:)</span> the words here put in the accus. case <span class="add">[literally or virtually]</span> are so put <span class="add">[in some instances]</span> as adverbial nouns; or, accord. to MF, they may be <span class="add">[in some instances]</span> denotatives of state, with respect to the agent; the meaning being <span class="ar long">اِفْعَلْهُ حَالَةَ كَوْنِكَ بَادِئًا</span>, i. e. <span class="ar long">مُبْتَدِئَا بِهِ</span> <span class="add">[lit. <em>do thou it in the state of thy being beginning it</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[In like manner,]</span> you also say, <span class="ar long">بَدْءَ الرَّأْىِ</span>, and <span class="add">[more commonly]</span><span class="arrow"><span class="ar long">بَادِئَ↓ الرَّأْىِ</span></span>, <em>At first thought;</em> or <em>on the first opinion:</em> <span class="auth">(Lḥ, M:)</span> <span class="add">[<span class="ar long">بَدْءُ الرَّأْىِ</span> and]</span> <span class="arrow"><span class="ar long">بَادِئُ↓ الرَّأْىِ</span></span> signifying <em>the first,</em> and <em>beginning, of the idea, thought, opinion,</em> or <em>judgment;</em> or <em>what is perceived before considering well</em> or <em>thoroughly:</em> <span class="auth">(M:)</span> <span class="add">[and <span class="ar">بَدْءٌ</span> alone signifying <em>a first idea, thought, opinion,</em> or <em>judgment;</em> as is implied in the A, voce <span class="ar">صَيُّورٌ</span>, q. v.:]</span> hence,<span class="arrow"><span class="ar long">فَعَلَهُ فِى بَادِئِ↓ الرَّأْيِ</span></span> <span class="add">[<em>He did it at first thought,</em>, &amp;c.]</span>: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar long">أَنْتَ بَادِئَ↓ الرَّأْىِ تُرِيدُ ظُلْمَنَا</span></span>, and<span class="arrow"><span class="ar long">مُبْتَدَأَ↓ الرأى</span></span>, i.e. <em>Thou at first thought,</em>, &amp;c., <em>desirest to wrong us:</em> and one says also, <span class="ar long">بَادِىَ الرأى</span>, without; meaning <em>on the occasion of what appeared of opinion;</em> i. e. <em>at the first of what appeared thereof;</em> <span class="add">[or <em>at the first opinion's presenting itself;</em>;]</span> in which case, the phrase does not belong to this art. <span class="add">[but to art. <span class="ar">بدو</span>]</span>: it occurs in the Ḳur xi. 29: <span class="auth">(M:)</span> AA alone there read <span class="ar">بَادِئَ</span>, with; all the other readers pronounced it without <span class="ar">ء</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badCN_A3">
					<p>Also <em>A chief,</em> or <em>lord,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>who occupies the first place in chieftainship</em> or <em>lordship:</em> <span class="auth">(Ṣ:)</span> or, as some say, <em>a youth,</em> or <em>young man, whose judgment,</em> or <em>opinion, is deemed good, and who is consulted:</em> <span class="auth">(M:)</span> or it signifies also <em>an intelligent youth</em> or <em>young man:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">بُدُوْءٌ</span>. <span class="auth">(M.)</span> A poet <span class="auth">(namely, Ows Ibn-Maghrà Es-Saadee, TA)</span> says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">ثُنْيَانُنَا إِنْ أَتَاهُمْ كَانَ بَدْأَهُمُ</span> *</div> 
						<div class="star">* <span class="ar long">وَبَدْؤُهُمْ إِنْ أَتَانَا كِانَ ثُنْيَانَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Our second chief, if he came to them, would be their first chief; and their first chief, if he came to us, would be a second chief</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="badCN_A4">
					<p>Also, and<span class="arrow"><span class="ar">بَدْأَةٌ↓</span></span>, <em>A share,</em> or <em>portion,</em> of a slaughtered camel: <span class="auth">(Ṣ, Ḳ:)</span> or the <em>best share</em> or <em>portion</em> thereof: <span class="auth">(T:)</span> or the former word has the latter signification; and the latter word, the former signification: and the former signifies also <em>a bone with the meat,</em> or <em>flesh, that is on it:</em> <span class="auth">(M:)</span> and <em>a joint;</em> syn. <span class="ar">مَفْصِلٌ</span>; <span class="auth">(AA, T, M;)</span> and so <span class="ar">بَدًا</span> q.v.: <span class="auth">(AA, T:)</span> thepl. <span class="add">[of pauc.]</span> of <span class="ar">بَدْءٌ</span> is <span class="ar">أَبْدَآءٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">بُدُوْءٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> the former of which is the more common: <span class="auth">(TA:)</span> or this <a href="#badFA">is pl. of <span class="ar">بَدًا</span></a>. <span class="auth">(AA, T.)</span> The shares abovementioned <span class="add">[as commonly divided for the game called <span class="ar">المَيْسِر</span> q. v.]</span> are ten; namely, the two haunches, the two thighs properly so called, the two thighs commonly so called <span class="auth">(i. e. the tibiæ)</span>, the two shoulders, and the two arms; which last are the worst, because of the many veins <span class="add">[therein]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="badCN_A5">
					<p><a href="#badieoCN">See also <span class="ar">بَدِىْءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="budCN">
				<h3 class="entry"><span class="ar">بُدءٌ</span></h3>
				<div class="sense" id="budCN_A1">
					<p><span class="ar">بُدءٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>; second sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badiYN">
				<h3 class="entry"><span class="ar">بَدِئٌ</span></h3>
				<div class="sense" id="badiYN_A1">
					<p><span class="ar">بَدِئٌ</span>: <ref target="#badCN">see <span class="ar long">بَادِئَ بَدِئٍ</span>, or <span class="ar long">بَادِىَ بَدِئٍ</span>, voce <span class="ar">بَدءٌ</span></ref>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badoOapN">
				<h3 class="entry"><span class="ar">بَدْأَةٌ</span></h3>
				<div class="sense" id="badoOapN_A1">
					<p><span class="ar">بَدْأَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>, in thirteen places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدْأَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badoOapN_A2">
					<p>Also The <em>beginning,</em> or <em>outward course, of a military expedition;</em> opposed to <span class="ar">رَجْعَةٌ</span>, meaning the returning, or homeward course, thereof: occurring in a trad., in which it is said that the Prophet gave, in the case of the former, a fourth <span class="add">[of the spoil]</span>, and in the case of the latter, a third; i.e., when a troop went forth from the main body of the army and attacked a party of the enemy, they were to have a fourth of the spoil that they took, and the rest of the army was to share with them the remaining three fourths; and if a troop did so in returning, they were to have a third of all the spoil that they took, because of the greater difficulty and danger attending this case. <span class="auth">(T, Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدْأَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badoOapN_A3">
					<p><span class="ar long">كَانَ ذٰلِكَ فِى بَدْأَتِنَا</span>, and<span class="arrow"><span class="ar">بُدْأَتِنَا↓</span></span>, and<span class="arrow"><span class="ar">بِدْأَتِنَا↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">بَدَآءَتِنَا↓</span></span>, <span class="auth">(Lḥ, M, TA,)</span> and<span class="arrow"><span class="ar">بُدَآءَتِنَا↓</span></span>, and<span class="arrow"><span class="ar">بِدَآءَتِنَا↓</span></span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">بَدَأَتِنَا↓</span></span>, <span class="auth">(Lḥ, M, Ḳ,)</span> but <span class="add">[ISd says,]</span> I know not how that is, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">مُبْدَئِنَا↓</span></span>, and<span class="arrow"><span class="ar">مُبْدَئِنَا↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">مَبْدَأَتِنَا↓</span></span>, <span class="auth">(Lḥ, M, and so in some copies of the Ḳ,)</span> or <span class="ar">مَبْدَاتِنَا</span>, <span class="auth">(so in other copies of the Ḳ,)</span> thus in the <span class="ar">بَاهِر</span> of Ibn-ʼOdeys <span class="add">[in the CK Ibn-'Adebbes]</span>, <span class="auth">(Ḳ,)</span> which is said to indicate that we should hesitate respecting them <span class="add">[before admitting them to be of classical authority]</span>, are phrases meaning <em>That was in the first of our state,</em> and <em>in our adolescence.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدْأَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badoOapN_B1">
					<p>Also, <span class="auth">(so in a copy of the M, there written <span class="ar">بَدْأَة</span>,)</span> or<span class="arrow"><span class="ar">بُدْأَةٌ↓</span></span>, with damm, <span class="auth">(Ḳ,)</span> <em>A certain plant;</em> <span class="auth">(M;)</span> <em>a black thing, resembling a truffle</em> (<span class="ar">كَمْء</span>), <em>of which no use is made:</em> so says AḤn. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="budoOapN">
				<h3 class="entry"><span class="ar">بُدْأَةٌ</span></h3>
				<div class="sense" id="budoOapN_A1">
					<p><span class="ar">بُدْأَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>; second sentence: <a href="#badoOapN">and see <span class="ar">بَدْأَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bidoOapN">
				<h3 class="entry"><span class="ar">بِدْأَةٌ</span></h3>
				<div class="sense" id="bidoOapN_A1">
					<p><span class="ar">بِدْأَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>; second sentence: <a href="#badoOapN">and see <span class="ar">بَدْأَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badaOapN">
				<h3 class="entry"><span class="ar">بَدَأَةٌ</span></h3>
				<div class="sense" id="badaOapN_A1">
					<p><span class="ar">بَدَأَةٌ</span>: <a href="#badoOapN">see <span class="ar">بَدْأَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaMCN">
				<h3 class="entry"><span class="ar">بَدَآءٌ</span></h3>
				<div class="sense" id="badaMCN_A1">
					<p><span class="ar">بَدَآءٌ</span>, with medd; <span class="add">[<em>Excrement from the anus;</em> as also <span class="ar">بَدَّا</span>;]</span> a subst. from <span class="ar">أَبْدَأَ</span>, as meaning <span class="ar">نَجَا</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badieoCN">
				<h3 class="entry"><span class="ar">بَدِىْءٌ</span></h3>
				<div class="sense" id="badieoCN_A1">
					<p><span class="ar">بَدِىْءٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>, as signifying <em>First,</em> or <em>former;</em> in eight places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badieoCN_A2">
					<p>Also, applied to a thing, or an affair, <em>i. q</em> <span class="ar">بَدِيعٌ</span>, <span class="auth">(Ṣ, and so in a copy of the Ḳ,)</span> or <span class="ar">مُبْدَعٌ</span>: <span class="auth">(so in other copies of the Ḳ:)</span> <span class="add">[thus it signifies]</span> <em>Originated; brought into being</em> or <em>existence; made,</em> or <em>produced, for the first time, not having been before,</em> or <em>not after the similitude of any former thing:</em> <span class="auth">(TA:)</span> and <em>created:</em> <span class="auth">(M, Ḳ:)</span> and <em>wonderful:</em> <span class="auth">(M, Mṣb, TA:)</span> and <em>strange,</em> or <em>extraordinary, as not being after the similitude of any former thing.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدِىْءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badieoCN_A3">
					<p><span class="add">[Hence, as is implied in the Mgh,]</span> <span class="ar long">بِئْرٌ بَدِىْءٌ</span> <em>A well newly dug;</em> <span class="auth">(T, Mgh, Mṣb;)</span> <em>i. q.</em> <span class="ar">بَدِيعٌ</span>; <span class="auth">(M;)</span> or <em>dug since the era of El-Islám</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>not ancient;</em> <span class="auth">(Ṣ, Mgh, Mṣb;)</span> as also<span class="arrow"><span class="ar">بَدْءٌ↓</span></span>: <span class="auth">(Ṣ:)</span> the former epithet <span class="add">[in this sense]</span> is generally pronounced <span class="add">[<span class="ar">بَدِىٌّ</span>]</span> without <span class="ar">ء</span>: <span class="auth">(T:)</span> the well thus called is one <em>dug in a waste land that has no owner:</em> <span class="auth">(TA:)</span> AO says, <span class="auth">(TA,)</span> this epithet, and <span class="ar">بَدِيع</span>, are applied to a well when thou hast dug it; but if thou findest it to have been dug before thee, it is termed <span class="ar">خَفِيَّة</span>; and thus the well of Zemzem is termed <span class="ar">خفيّة</span>, because it was Ismá'eel's, and was filled up or covered over <span class="add">[after his time]</span>: <span class="auth">(T, TA:)</span> the term <span class="ar">قَلِيب</span> is <span class="add">[said to be]</span> applied to an ancient well of which neither the owner nor the digger is known: <span class="auth">(TA:)</span> it is said in a trad., that the <span class="ar">حَرِيم</span> of a well such as is termed <span class="ar">بدىء</span> <span class="add">[i. e. the space surrounding it and belonging to it]</span> is five-and-twenty cubits: <span class="auth">(T, Ṣ: <span class="add">[<a href="#HariymN">but see <span class="ar">حَرِيمٌ</span></a>:]</span>)</span> the pl. is <span class="ar">بُدُوْءٌ</span>: <span class="auth">(M:)</span> and AO says that <span class="ar">بُودَانٌ</span> <a href="#badieoCN">is pl. of <span class="ar">بَدِىْءٌ</span></a> applied to a well, and is syn. with <span class="ar">قُلْبَانٌ</span> <span class="add">[<a href="#qaliybN">a pl. of <span class="ar">قَلِيبٌ</span></a> which I have not found elsewhere]</span> and <span class="ar">رَكَايَا</span>, being formed by transposition of letters from <span class="ar">بُدْيَانٌ</span> <span class="add">[which is for <span class="ar">بُدْآنٌ</span>, as <span class="ar">بَدِىٌّ</span> is for <span class="ar">بَدِىْءٌ</span>; the <span class="ar">د</span> and <span class="ar">ى</span> being transposed, the word becomes <span class="ar">بُيْدَانٌ</span>, and this, by a rule of permutation, becomes <span class="ar">بُودَانٌ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="badaMCapN">
				<h3 class="entry"><span class="ar">بَدَآءَةٌ</span></h3>
				<div class="sense" id="badaMCapN_A1">
					<p><span class="ar">بَدَآءَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>, in three places: <a href="#badoOapN">and see <span class="ar">بَدْأَةٌ</span></a>: <a href="#badiyapN">and <span class="ar">بَدِئَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="budaMCapN">
				<h3 class="entry"><span class="ar">بُدَآءَةٌ</span></h3>
				<div class="sense" id="budaMCapN_A1">
					<p><span class="ar">بُدَآءَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>, in two places: <a href="#badoOapN">and see <span class="ar">بَدْأَةٌ</span></a>: <a href="#badiYoyapN">and see also <span class="ar">بَدِيْئَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bidaMCapN">
				<h3 class="entry"><span class="ar">بِدَآءَةٌ</span></h3>
				<div class="sense" id="bidaMCapN_A1">
					<p><span class="ar">بِدَآءَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>, in two places: <a href="#badoOapN">and see <span class="ar">بَدْأَةٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="badiyoYapN">
				<span class="pb" id="Page_0165"></span>
				<h3 class="entry"><span class="ar">بَدِيْئَةٌ</span></h3>
				<div class="sense" id="badiyoYapN_A1">
					<p><span class="ar">بَدِيْئَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>; second sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدِيْئَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badiyoYapN_A2">
					<p>Also, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَدَآءَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">بُدَآءَةٌ↓</span></span>, <span class="auth">(M,)</span> <em>i. q.</em> <span class="ar">بَدِيهَةٌ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar">بَدَاهَةٌ</span>, <span class="auth">(TA,)</span> or <span class="ar">بُدَاهَةٌ</span>, i. e. The <em>first occurrence</em> of a thing, <em>that happens to one unexpectedly:</em> <span class="auth">(M:)</span> <span class="add">[or the <em>first</em> of anything: and <em>an occurrence thereof by which one is taken unawares:</em> accord. to explanations in the Ḳ in art. <span class="ar">بده</span>:]</span> pl. of the first, <span class="ar">بَدَايَا</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">بَدِيْئَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badiyoYapN_A3">
					<p><span class="add">[And all app. signify The <em>faculty of extemporizing;</em> like <span class="ar">بَدِيهَةٌ</span> <span class="auth">(q. v.)</span>, &amp;c.]</span> You say,<span class="arrow"><span class="ar long">فُلَانٌ ذُو بَدَآءَةٍ↓ جَيِّدَةٍ</span></span>, i. e. <span class="ar long">بَدِيهَةٍ حَسَنَةٍ</span>, <span class="add">[meaning]</span> <em>Such a one has a good faculty of extemporizing;</em> or <em>of uttering,</em> or <em>relating, things by means of the promptness of his intelligence.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="budBaMCapN">
				<h3 class="entry"><span class="ar">بُدَّآءَةٌ</span></h3>
				<div class="sense" id="budBaMCapN_A1">
					<p><span class="ar">بُدَّآءَةٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>; second sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAdiYN">
				<h3 class="entry"><span class="ar">بَادِئٌ</span></h3>
				<div class="sense" id="baAdiYN_A1">
					<p><span class="ar">بَادِئٌ</span> <span class="add">[act. part. n. of 1]</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>, in nine places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAdiYapN">
				<h3 class="entry"><span class="ar">بَادِئَةٌ</span></h3>
				<div class="sense" id="baAdiYapN_A1">
					<p><span class="ar">بَادِئَةٌ</span>: <a href="#bdA1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabodaON">
				<h3 class="entry"><span class="ar">مَبْدَأٌ</span></h3>
				<div class="sense" id="mabodaON_A1">
					<p><span class="ar">مَبْدَأٌ</span> <span class="add">[originally noun of place and of time from 1; <em>A place,</em> and <em>a time, of beginning,</em>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">مَبْدَأٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mabodaON_A2">
					<p><a href="#badoOapN">See <span class="ar">بَدْأَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">مَبْدَأٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mabodaON_A3">
					<p><span class="add">[Also <em>A principle,</em> or <em>first rule,</em> of a science, &amp;c.: pl. <span class="ar">مَبَادِئُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">مَبْدَأٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="mabodaON_A4">
					<p><span class="add">[And The <em>primary import</em> of a word; opposed in this sense to <span class="ar">غَايَةٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mubodaON">
				<h3 class="entry"><span class="ar">مُبْدَأٌ</span></h3>
				<div class="sense" id="mubodaON_A1">
					<p><span class="ar">مُبْدَأٌ</span>: <a href="#badoOapN">see <span class="ar">بَدْأَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmubodiYu">
				<h3 class="entry"><span class="ar">المُبْدِئُ</span></h3>
				<div class="sense" id="AlmubodiYu_A1">
					<p><span class="ar">المُبْدِئُ</span>, applied to God, <em>The Creator,</em> or <em>Originator, of the things</em> <span class="add">[<em>that exist</em>]</span>, <em>who hath produced them at the beginning, not after the similitude of anything pre-existing.</em> <span class="auth">(Nh.)</span> And <span class="ar long">المُبْدِئُ المُعِيدُ</span>, so applied, <em>He who createth mankind, and who returneth them after life to death in the present world and after death to life on the day of resurrection.</em> <span class="auth">(TA in art. <span class="ar">عود</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">المُبْدِئُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlmubodiYu_A2">
					<p><span class="ar long">مُبْدِئُ مُعِيدٌ</span> A man <em>who has gone on warring,</em> or <em>warring and plundering, expeditions, time after time, and is experienced in affairs:</em> <span class="auth">(AʼObeyd, and Ḳ in art. <span class="ar">عود</span>:)</span> and a horse <em>upon which the owner has gone time after time on warring,</em> or <em>warring and plundering, expeditions;</em> <span class="auth">(TA in that art.;)</span> or <em>well trained and exercised,</em> <span class="auth">(Ḳ and TA in that art.)</span> <em>so as to be obedient to his rider.</em> <span class="auth">(TA in that art.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">المُبْدِئُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AlmubodiYu_A3">
					<p><span class="add">[For other significations of <span class="ar">مُبْدِئٌ</span>, see its verb <span class="auth">(4)</span>; <a href="#OaHofara">and see <span class="ar">أَحْفَرَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mabodaOapN">
				<h3 class="entry"><span class="ar">مَبْدَأَةٌ</span></h3>
				<div class="sense" id="mabodaOapN_A1">
					<p><span class="ar">مَبْدَأَةٌ</span>: <a href="#badoOapN">see <span class="ar">بَدْأَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboduwoCN">
				<h3 class="entry"><span class="ar">مَبْدُوْءٌ</span></h3>
				<div class="sense" id="maboduwoCN_A1">
					<p><span class="ar">مَبْدُوْءٌ</span> <span class="add">[pass. part. n. of 1; <em>Begun,</em>, &amp;c.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">مَبْدُوْءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maboduwoCN_B1">
					<p><a href="#budiya">See <span class="ar">بُدِئَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotadaON">
				<h3 class="entry"><span class="ar">مُبْتَدَأٌ</span></h3>
				<div class="sense" id="mubotadaON_A1">
					<p><span class="ar">مُبْتَدَأٌ</span>: <a href="#badoCN">see <span class="ar">بَدْءٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدأ</span> - Entry: <span class="ar">مُبْتَدَأٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mubotadaON_A2">
					<p><span class="add">[In grammar, as correlative of <span class="ar">خَبَرٌ</span>, <em>An inchoative.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0163.pdf" target="pdf">
							<span>Lanes Lexicon Page 163</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0164.pdf" target="pdf">
							<span>Lanes Lexicon Page 164</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0165.pdf" target="pdf">
							<span>Lanes Lexicon Page 165</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
