<article class="root" id="Root_bjd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/022_bjH">بجح</a></span>
				<span class="ar">بجد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/024_bjr">بجر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bjd_1">
				<h3 class="entry">1. ⇒ <span class="ar">بجد</span></h3>
				<div class="sense" id="bjd_1_A1">
					<p><span class="ar long">بَجَدَ بِالمَكَانِ</span>, <span class="auth">(Ṣ, A, L, Ḳ,*)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْجُدُ</span>}</span></add>, <span class="auth">(L,)</span> inf. n. <span class="ar">بُجُودٌ</span> <span class="auth">(Ṣ, L, Ḳ)</span> and <span class="ar">تَبْجِيدٌ</span>; <span class="auth">(Kr;)</span> and<span class="arrow"><span class="ar">بجّد↓</span></span>, inf. n. <span class="ar">تَبْجِيدٌ</span>; <span class="auth">(L, Ḳ;)</span> <em>He remained, stayed, abode,</em> or <em>dwelt,</em> <span class="auth">(Ṣ, A, L, Ḳ,)</span> <em>in the place;</em> <span class="auth">(Ṣ, A, L;)</span> <em>settled,</em> or <em>remained fixed, in it; not quitting it.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bjd_1_A2">
					<p><span class="ar long">بَجَدَتِ الإِبَلُ</span>, <span class="auth">(L, Ḳ,)</span> inf. n. <span class="ar">بُجُودٌ</span>; and<span class="arrow"><span class="ar">بجّدت↓</span></span>; <span class="auth">(L;)</span> <em>The camels kept to the place of pasturing.</em> <span class="auth">(L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bjd_2">
				<h3 class="entry">2. ⇒ <span class="ar">بجّد</span></h3>
				<div class="sense" id="bjd_2_A1">
					<p><a href="#bjd_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajadN">
				<h3 class="entry"><span class="ar">بَجَدٌ</span></h3>
				<div class="sense" id="bajadN_A1">
					<p><span class="ar">بَجَدٌ</span> <em>A company,</em> or <em>an assembly,</em> of men: and <em>a hundred,</em> and <em>more,</em> of horses: <span class="auth">(L, Ḳ:)</span> on the authority of El-Hejeree: <span class="auth">(TA:)</span> pl. <span class="ar">بُجُودٌ</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bajodapN">
				<h3 class="entry"><span class="ar">بَجْدَةٌ</span></h3>
				<div class="sense" id="bajodapN_A1">
					<p><span class="ar">بَجْدَةٌ</span> <em>i. q.</em> <span class="ar">أَصْلٌ</span> <span class="add">[The <em>root, basis,</em> or <em>foundation;</em> or the <em>origin,</em> or <em>source;</em> or the <em>most essential part,</em> or <em>very essence;</em> of a thing]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجد</span> - Entry: <span class="ar">بَجْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bajodapN_A2">
					<p>And <span class="add">[hence, app.,]</span> The <em>inward,</em> or <em>intrinsic, state</em> or <em>circumstances</em> of a case or an affair; as also<span class="arrow"><span class="ar">بُجْدَةٌ↓</span></span> and<span class="arrow"><span class="ar">بُجُدَةٌ↓</span></span>: <span class="auth">(Ṣ, L, Ḳ:)</span> or the <em>true,</em> or <em>real, state</em> or <em>circumstances</em> thereof; the <em>positive,</em> or <em>established, truth</em> thereof; from <span class="ar long">بَجَدَ بَالمَكَانِ</span>. <span class="auth">(A.)</span> You say, <span class="ar long">هُوَ عَالِمٌ بِبَجْدَةِ أَمْرِكَ</span>, <span class="auth">(Ṣ, A, L,)</span> and<span class="arrow"><span class="ar">بِبُجْدَتِهِ↓</span></span>, and<span class="arrow"><span class="ar">بِبُجُدَتِهِ↓</span></span>, <span class="auth">(Ṣ, L,)</span> <em>He is acquainted with the inward,</em> or <em>intrinsic, state</em> or <em>circumstances of thy case</em> or <em>affair:</em> <span class="auth">(Ṣ, L:)</span> or, <em>with the true,</em> or <em>real, state</em> or <em>circumstances thereof; with the positive,</em> or <em>established, truth thereof.</em> <span class="auth">(A.)</span> And <span class="ar long">عِنْدِهُ بَجْدَةُ ذٰلِكَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> with fet-ḥ, <span class="auth">(Ṣ,)</span> <em>He possesses the knowledge of that.</em> <span class="auth">(Ṣ, Ḳ.)</span> And hence, <span class="auth">(Ṣ,)</span> <span class="ar long">هَوَ ٱبْنُ بَجْدَتِهَا</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>contr. of</em> <span class="ar long">هو ابن نجْدَتِهَا</span>, <span class="auth">(A in art, <span class="ar">نجد</span>,)</span> or, as in the books of proverbs, <span class="ar long">أَنَا ٱبْنُ بَجْدَتِهَا</span>, the <span class="add">[affixed]</span> pronoun referring to <span class="ar">الأَرْض</span> <span class="add">[understood]</span>, as is said by Meyd and Z, <span class="auth">(TA,)</span> applied to <span class="add">[signify <em>He is,</em> or <em>I am,</em>]</span> <em>the person acquainted with the thing;</em> <span class="auth">(Ṣ, L, Ḳ;)</span> <em>possessing,</em> or <em>exercising, the skill requisite for it;</em> <span class="auth">(Ṣ, L;)</span> <em>the discriminator,</em> or <em>discerner, thereof;</em> <span class="auth">(L;)</span> and one says likewise, <span class="ar long">هُوَ ٱبْنُ مَدِينَتِهَا وَٱبْنُ بَجْدَتِهَا</span>: <span class="auth">(TA:)</span> it is also applied to <span class="add">[signify <em>he is,</em> or <em>I am,</em>]</span> <em>the skilful guide of the way</em> <span class="add">[<em>thereof</em>]</span>: <span class="auth">(L, Ḳ:)</span> and hence, <span class="add">[accord. to some,]</span> it is proverbially applied to any one acquainted with an affair; skilful therein: <span class="auth">(TA:)</span> and to <span class="add">[signify <em>he is,</em> or <em>I am,</em>]</span> <em>the person who will not quit,</em> or <em>depart from, his place;</em> from the saying <span class="ar long">بَجَدَ بَالمَكَانِ</span>: <span class="auth">(L:)</span> or <em>the person who will not depart from his saying:</em> <span class="auth">(Ḳ: <span class="add">[there explained by the words <span class="ar long">لِمَنْ لَا يَبْرَحُ مِنْ قَوْلِهِ</span>: but the TA supplies some apparent omissions in this explanation, making it to agree with that which here immediately precedes it, taken from the L; and adds that, in some copies of the Ḳ, <span class="ar long">عن قوله</span> is erroneously put for <span class="ar long">من قوله</span>: also, that he who remains in a place knows that place:]</span>)</span> or, accord. to some, <span class="ar">بَجْدَةٌ</span> signifies <em>dust,</em> or <em>earth;</em> so that <span class="ar long">أَنَا ٱبْنُ بَجْدَتَهَا</span> is as though it meant <em>I am created of its dust,</em> or <em>earth.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجد</span> - Entry: <span class="ar">بَجْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bajodapN_A3">
					<p>Also <em>A</em> <span class="add">[<em>desert, such as is termed</em>]</span> <span class="ar">صَحْرِآء</span>. <span class="auth">(Ḳ.)</span> Kaab Ibn-Zuheyr uses the phrase <span class="ar long">اِبْنُ بَجْدَتَهَا</span> as meaning <em>Its male chameleon;</em> the pronoun referring to a desert (<span class="ar">فَلَاة</span>) which he is describing. <span class="auth">(TA.)</span> And you say of a land covered with black locusts, <span class="ar long">أَصْبَحَتِ الأَرْضُ بَجْدَهً وَاحِدَةً</span> <span class="add">[<em>The land became,</em> or <em>has become, one desert, destitute of vegetable produce</em>]</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bujodahN">
				<h3 class="entry"><span class="ar">بُجْدَهٌ</span> / <span class="ar">بُجُدَةٌ</span></h3>
				<div class="sense" id="bujodahN_A1">
					<p><span class="ar">بُجْدَهٌ</span> and <span class="ar">بُجُدَةٌ</span>: <a href="#bajodapN">see <span class="ar">بَجْدَةٌ</span></a>; each in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bijaAdN">
				<h3 class="entry"><span class="ar">بِجَادٌ</span></h3>
				<div class="sense" id="bijaAdN_A1">
					<p><span class="ar">بِجَادٌ</span> <em>A striped garment of the kind called</em> <span class="ar">كِسَآء</span>, <span class="auth">(Ṣ, A, L, Ḳ,)</span> being <em>one of the kinds of</em> <span class="ar">كَسآء</span> <em>worn by the Arabs of the desert:</em> <span class="auth">(Ṣ, L:)</span> or, <em>of which the wool has been spun,</em> or <em>twisted, in the manner termed</em> <span class="ar">يَسْرَةً</span> <span class="add">[app. a mistranscription for <span class="ar">يَسْرًا</span> (<a href="#yasorN">see <span class="ar long">فَتْلٌ يَسْرٌ</span></a> <a href="index.php?data=28_e/015_ysr">in art. <span class="ar">يسر</span></a>)]</span>, <em>and woven with the instrument called</em> <span class="ar">صِيصَة</span>: pl. <span class="ar">بُجُدٌ</span>: a single oblong piece thereof is called <span class="ar">فَلِيجٌ</span>, of which the pl. is <span class="ar">فُلُجٌ</span>. <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بجد</span> - Entry: <span class="ar">بِجَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bijaAdN_A2">
					<p>Also <em>A kind of tent, of</em> <span class="add">[<em>the soft hair called</em>]</span> <span class="ar">وَبَر</span>. <span class="auth">(Ibn-El-Kelbee, TA voce <span class="ar">بَيْتٌ</span>, q. v.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAjidN">
				<span class="pb" id="Page_0153"></span>
				<h3 class="entry"><span class="ar">بَاجِدٌ</span></h3>
				<div class="sense" id="baAjidN_A1">
					<p><span class="ar">بَاجِدٌ</span> <em>Remaining, staying, abiding,</em> or <em>dwelling,</em> in a place; <span class="auth">(L;)</span> <em>settled,</em> or <em>remaining fixed,</em> in a land. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0152.pdf" target="pdf">
							<span>Lanes Lexicon Page 152</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0153.pdf" target="pdf">
							<span>Lanes Lexicon Page 153</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
