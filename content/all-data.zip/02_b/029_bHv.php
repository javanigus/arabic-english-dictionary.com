<article class="root" id="Root_bHv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/028_bHt">بحت</a></span>
				<span class="ar">بحث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/030_bHvr">بحثر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bHv_1">
				<h3 class="entry">1. ⇒ <span class="ar">بحث</span></h3>
				<div class="sense" id="bHv_1_A1">
					<p><span class="ar">بَحَثَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْحَثُ</span>}</span></add>, inf. n. <span class="ar">بَحْثٌ</span>, <em>He scraped it up;</em> <span class="add">[as one who seeks to find a thing therein;]</span> namely, the dust, or earth: <span class="auth">(L:)</span> and <em>he searched,</em> or <em>sought, for it,</em> or <em>after it,</em> <span class="auth">(namely, a thing,)</span> <em>in the dust,</em> or <em>earth;</em> as also<span class="arrow"><span class="ar">ابتحثهُ↓</span></span>: <span class="auth">(L, TA:)</span> thus each is made trans. by itself: and authors often say, <span class="ar long">بَحَثَ فِيهِ</span> <span class="add">[meaning <em>he searched,</em> or <em>inquired, into it; investigated, scrutinized,</em> or <em>examined, it</em>]</span>: <span class="auth">(TA:)</span> one says, <span class="ar long">بَحَثَ فِى الأَرْضِ</span> <em>he dug up the earth;</em> and thus it is used in the Ḳur v. 34: <span class="auth">(Mṣb:)</span> but accord. to the usage commonly known and obtaining, <span class="auth">(TA,)</span> you say, <span class="ar long">بَحَثَ عَنْهُ</span>, <span class="auth">(Ṣ, A, L, Mṣb, Ḳ,)</span> aor. as above, <span class="auth">(L, Mṣb, Ḳ,)</span> and so the inf. n.; <span class="auth">(L, Mṣb;)</span> as well as <span class="ar">بَحَثَهُ</span>; <span class="auth">(L;)</span> and<span class="arrow"><span class="ar long">ابتحث↓ عنه</span></span>; <span class="auth">(T, Ṣ, L, Ḳ;)</span> <span class="add">[in some copies of the Ḳ <span class="ar">انبحث</span>, which is said in the TA to be a mistake; and<span class="arrow"><span class="ar">ابتحثهُ↓</span></span>; <span class="auth">(see above;)</span>]</span> and<span class="arrow"><span class="ar long">تبحّث↓ عنه</span></span>; <span class="auth">(T, L, Ḳ;)</span> and<span class="arrow"><span class="ar long">استبحث↓ عنه</span></span>; <span class="auth">(L, Ḳ;)</span> and<span class="arrow"><span class="ar">استبحثهُ↓</span></span>; <span class="auth">(L;)</span> <span class="add">[<em>he scraped up the dust,</em> or <em>earth, from over it:</em> and hence,]</span> <em>he searched,</em> or <em>sought, for it, after it,</em> or <em>respecting it; he inquired, and sought for information, respecting it; he searched,</em> or <em>inquired, into it; investigated, scrutinized,</em> or <em>examined, it; he inquired respecting it, and searched to the utmost after it;</em> <span class="auth">(Ṣ,* A,* L, Mṣb,* Ḳ;*)</span> namely, a thing, <span class="auth">(Ṣ, L,)</span> or an affair, or event. <span class="auth">(Mṣb.)</span> You say also,<span class="arrow"><span class="ar long">استبحث↓ أَخَاهُ عَنْ سِرِهِّ</span></span> <em>He examined his brother respecting his secret.</em> <span class="auth">(A in art. <span class="ar">نبث</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHv_3">
				<h3 class="entry">3. ⇒ <span class="ar">باحث</span></h3>
				<div class="sense" id="bHv_3_A1">
					<p><span class="add">[<span class="ar long">باحثهُ عَنْ أَمْرٍ</span>, inf. n. <span class="ar">مُبَاحَثَةٌ</span>, <em>He searched,</em> or <em>inquired, with him into a thing;</em> or <em>investigated, scrutinized,</em> or <em>examined, with him a thing,</em> or <em>an affair:</em> and particularly, <em>in the way of disputation.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحث</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHv_3_A2">
					<p><span class="ar long">عَادَتُهُ أَنْ يُبَاحِثَ وَيُبَاهِتَ</span> <span class="add">[<em>His custom is to engage with another in mutual scrutiny</em> of secrets, or faults, or the like, <em>and in mutual calumniation,</em>, &amp;c.: <a href="#bHv_6">see 6</a>]</span>. <span class="auth">(A in art. <span class="ar">بهت</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bHv_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبحّث</span></h3>
				<div class="sense" id="bHv_5_A1">
					<p><a href="#bHv_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHv_6">
				<h3 class="entry">6. ⇒ <span class="ar">تباحث</span></h3>
				<div class="sense" id="bHv_6_A1">
					<p><span class="ar long">تَبَاحَثُوا عَنِ الأَسْرَارِ</span> <em>They searched,</em> or <em>inquired, into each other's secrets.</em> <span class="auth">(A in art. <span class="ar">نبث</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bHv_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتحث</span></h3>
				<div class="sense" id="bHv_8_A1">
					<p><span class="ar">إِبْتَحَثَ</span> <a href="#bHv_1">see 1</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحث</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bHv_8_A2">
					<p><span class="ar">ابتحث</span> also signifies <em>He played with the dust,</em> or <em>earth, termed</em> <span class="ar">بحاثة</span>; or <em>at the game called</em> <span class="ar">البحثة</span>. <span class="auth">(Ḳ.)</span> In a copy of the Ḳ, the verb is here incorrectly written <span class="ar">انبحث</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bHv_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبحث</span></h3>
				<div class="sense" id="bHv_10_A1">
					<p><a href="#bHv_1">see 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHovN">
				<h3 class="entry"><span class="ar">بَحْثٌ</span></h3>
				<div class="sense" id="baHovN_A1">
					<p><span class="ar">بَحْثٌ</span>, <span class="auth">(so in the Ḳ,)</span> or<span class="arrow"><span class="ar">بحِيثٌ↓</span></span>, <span class="auth">(so in the L,)</span> accord. to Sh, <span class="auth">(L,)</span> <em>A mine</em> <span class="auth">(L, Ḳ)</span> <em>in which one searches for gold and silver.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بحث</span> - Entry: <span class="ar">بَحْثٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="baHovN_B1">
					<p>Also the former, <em>A great serpent;</em> <span class="auth">(Ḳ;)</span> because it scrapes up the dust or earth. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbuHovapu">
				<h3 class="entry"><span class="ar">البُحْثَةُ</span></h3>
				<div class="sense" id="AlbuHovapu_A1">
					<p><span class="ar">البُحْثَةُ</span>, <span class="auth">(as written in the L,)</span> or <span class="ar">البَحْثَةُ</span>, <span class="auth">(as in the Ḳ,)</span> accord. to Sh, <span class="auth">(L,)</span> and<span class="arrow"><span class="ar">البُحّيّثَى↓</span></span>, <span class="auth">(L, Ḳ,)</span> accord. to ISh, <span class="auth">(L,)</span> <em>A certain game with</em> <span class="arrow"><span class="ar">بُحَاثَة↓</span></span>, i. e, <em>dust,</em> or <em>earth.</em> <span class="auth">(L, Ḳ.)</span> You say, <span class="ar long">لَعِبَ البُحْثَةَ</span> <em>He played the game thus called.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHuwvN">
				<h3 class="entry"><span class="ar">بَحُوثٌ</span></h3>
				<div class="sense" id="baHuwvN_A1">
					<p><span class="ar long">إِبِلٌ بَحُوثٌ</span> <em>Camels that scrape up the dust,</em> or <em>earth, with their fore feet, backwards,</em> <span class="auth">(AA, T, L, Ḳ,)</span> <em>in going;</em> i. e., <em>throwing it behind them;</em> or, as some say, <em>with their feet.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحث</span> - Entry: <span class="ar">بَحُوثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baHuwvN_A2">
					<p><span class="ar">البَحُوثُ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">سُوَرةُ البَحُوثِ</span>, <span class="auth">(L,)</span> thus written in the Fáïk, and if so, <span class="ar">بَحُوثٌ</span> is an intensive epithet, applying alike to a masc. and a fem. noun, like <span class="ar">صَبُورٌ</span>; <span class="auth">(TA;)</span> <span class="pb" id="Page_0156"></span>or, accord. to some, <span class="ar long">سُورَةُ البُحُوثِ</span>, <span class="auth">(L,)</span> <a href="#baHovi">pl. of <span class="ar">بَحْثِ</span></a>; <span class="auth">(TA;)</span> a name of <em>The chapter of the Ḳur-án called</em> <span class="ar long">سُورَةُ التَّوْبَةِ</span>, <span class="auth">(L, Ḳ,)</span> <em>and</em> <span class="ar">البَرَآءَةِ</span>; <span class="auth">(L;)</span> <span class="add">[chap. ix.;]</span> given to it because it inquires respecting the hypocrites and their secrets. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baHiyvN">
				<h3 class="entry"><span class="ar">بَحِيثٌ</span></h3>
				<div class="sense" id="baHiyvN_A1">
					<p><span class="ar">بَحِيثٌ</span>: <a href="#baHovN">see <span class="ar">بَحْثٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بحث</span> - Entry: <span class="ar">بَحِيثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baHiyvN_A2">
					<p><em>A secret:</em> whence the prov., <span class="ar long">بَدَا بَحِيثُهُمْ</span> <span class="add">[<em>Their secret became apparent,</em> or <em>revealed</em>]</span>. <span class="auth">(TA. <span class="add">[But in the Ṣ, in art. <span class="ar">نجث</span>, q. v., we find <span class="ar long">بَدَا نَجِيثُ القَوْمِ</span>; and so in Freytag's Arab. Prov. i. 159.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buHaAvapN">
				<h3 class="entry"><span class="ar">بُحَاثَةٌ</span></h3>
				<div class="sense" id="buHaAvapN_A1">
					<p><span class="ar">بُحَاثَةٌ</span> <em>Dust,</em> or <em>earth,</em> <span class="auth">(Az, Ḳ,)</span> <em>which is scraped up from what is searched for therein.</em> <span class="auth">(Az, TA.)</span> <a href="#AlbuHovapu">See <span class="ar">البُحْثَةُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlbuHayovae">
				<h3 class="entry"><span class="ar">البُحَيْثَى</span></h3>
				<div class="sense" id="AlbuHayovae_A1">
					<p><span class="ar">البُحَيْثَى</span>: <a href="#AlbuHovapu">see <span class="ar">البُحْثَةُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAHivN">
				<h3 class="entry"><span class="ar">بَاحِثٌ</span></h3>
				<div class="sense" id="baAHivN_A1">
					<p><span class="ar">بَاحِثٌ</span> <span class="add">[act. part. n. of 1; <em>Scraping up</em> dust or earth:, &amp;c.]</span>. <span class="ar long">كَالبَاحِثِ عَنِ الشَّفْرَةِ</span> <span class="add">[<em>Like him who is scraping up the dust,</em> or <em>earth, from over the great knife</em> with which he is to be slaughtered,]</span> is a prov.: <span class="auth">(Ṣ, L:)</span> and so <span class="ar long">كَبَاحِثَةٍ عَنْ حَتْفِهَا بِظِلْفِهَا</span> <span class="add">[<em>Like one searching for her death with her hoof</em>]</span>: originating from the fact of a ewe's digging up a knife in the dust, or earth, and then being slaughtered with it. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAHivaMCu">
				<h3 class="entry"><span class="ar">بَاحِثَآءُ</span></h3>
				<div class="sense" id="baAHivaMCu_A1">
					<p><span class="ar">بَاحِثَآءُ</span> <em>Dust,</em> or <em>earth,</em> <span class="auth">(L, Ḳ,)</span> <em>of the burrow of the Jerboa,</em> <span class="auth">(L,)</span> <em>resembling the</em> <span class="add">[<em>hole termed</em>]</span> <span class="ar">قَاصِعَآء</span>; <span class="auth">(L, Ḳ;)</span> <em>but it is not this:</em> pl. <span class="ar">بَاحِثَاوَاتٌ</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboHavN">
				<h3 class="entry"><span class="ar">مَبْحَثٌ</span></h3>
				<div class="sense" id="maboHavN_A1">
					<p><span class="ar">مَبْحَثٌ</span> <em>A place,</em> and <em>a time, of scraping up</em> or <em>digging; of searching, inquiring, investigating, scrutinizing,</em> or <em>examining:</em> pl. <span class="ar">مَبَاحِثُ</span>. <span class="auth">(KL.)</span> You say, <span class="ar long">تَرَكْتُهُ بِمَبَاحِثِ البَقَرِ</span> <span class="auth">(Ṣ, Ḳ*)</span> <span class="add">[<em>I left him in the places where the</em> wild <em>oxen scrape up the ground</em>]</span>; meaning, <em>in a desert place, destitute of herbage, or of human beings;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>in an unknown place;</em> <span class="auth">(Ḳ;)</span> i. e., <em>so that it was not known where he was.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0155.pdf" target="pdf">
							<span>Lanes Lexicon Page 155</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0156.pdf" target="pdf">
							<span>Lanes Lexicon Page 156</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
