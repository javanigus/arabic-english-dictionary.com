<article class="root" id="Root_bqE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/157_bqX">بقش</a></span>
				<span class="ar">بقع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/159_bql">بقل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bqE_1">
				<h3 class="entry">1. ⇒ <span class="ar">بقع</span></h3>
				<div class="sense" id="bqE_1_A1">
					<p><span class="ar">بَقِعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْقَعُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَقَعٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>It</em> <span class="auth">(a bird, and a dog,)</span> <em>was black and white;</em> syn. <span class="ar">بَلِقَ</span>; <span class="auth">(Ḳ;)</span> <span class="add">[or rather]</span> <span class="ar">بَقَعٌ</span> in birds and dogs is like <span class="ar">بَلَقٌ</span> in beasts that are ridden, or horses and the like: <span class="auth">(Ṣ, Ḳ:)</span> or <em>it</em> <span class="auth">(a crow, &amp;c.,)</span> <em>was partycoloured</em> or <em>pied.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bqE_1_A2">
					<p><em>He</em> <span class="auth">(a drawer of water, L, Ḳ, from a well, by means of a pulley and rope and bucket, L)</span> <em>had his body sprinkled with the water, so that some parts of it became wetted.</em> <span class="auth">(L. Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bqE_1_B1">
					<p><span class="ar long">مَا أَدْرِى أَيْنَ بَقَعَ</span> <em>I know not whither he went;</em> <span class="auth">(Ṣ, Ḳ;)</span> as though one said, to what <span class="ar">بُقْعَة</span> of the <span class="ar">بِقَاع</span> of the earth he went; <span class="auth">(Ṣ;)</span> not used except negatively; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">بَقَّعَ↓</span></span>. <span class="auth">(Fr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bqE_1_B2">
					<p><span class="ar long">بَقَعَتْهُمُ الدَّاهِيَةُ</span> <em>The calamity,</em> or <em>misfortune, befell them.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bqE_1_C1">
					<p><span class="ar">بُقِعَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> like <span class="ar">عُنِىَ</span>, <span class="auth">(Ḳ,)</span> <em>He was assailed with bad,</em> or <em>foul, speech,</em> or <em>language:</em> <span class="auth">(Ṣ, O, Ḳ:)</span> or <em>with calumny, slander,</em> or <em>false accusation.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">بُقِعَ بِقَبِيحٍ</span> <em>He was assailed with foul, evil,</em> or <em>abominable, speech,</em> or <em>language.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqE_2">
				<h3 class="entry">2. ⇒ <span class="ar">بقّع</span></h3>
				<div class="sense" id="bqE_2_A1">
					<p><span class="ar long">بقّع الثَّوْبَ</span> <em>He</em> <span class="auth">(a dyer)</span> <em>left spots,</em> or <em>portions, of the garment,</em> or <em>piece of cloth, undyed.</em> <span class="auth">(Mgh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bqE_2_A2">
					<p><span class="ar long">بقّع ثَوْبَهُ</span> <em>He</em> <span class="auth">(a waterer)</span> <em>sprinkled the water upon his garment, so that spots,</em> or <em>portions, of it became wetted.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bqE_2_A3">
					<p><span class="ar long">بقّع المَطَرُ فِى مَوَاضِعَ مِنَ الأَرْضِ</span>, inf. n. <span class="ar">تَبْقِيعٌ</span>, <em>The rain fell in places of the land, not universally.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bqE_2_B1">
					<p><span class="ar long">مَا أَدْرِى أَيْنَ بَقَّعَ</span>: <a href="#bqE_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqE_7">
				<h3 class="entry">7. ⇒ <span class="ar">انبقع</span></h3>
				<div class="sense" id="bqE_7_A1">
					<p><span class="ar">انبقع</span> <em>He went away quickly;</em> <span class="auth">(Ḳ;)</span> and <em>ran.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bqE_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتقع</span></h3>
				<div class="sense" id="bqE_8_A1">
					<p><span class="ar long">اُبْتُقِعَ لَوْنُهُ</span>, with damm, <em>i. q.</em> <span class="ar">اُنْتُقِعَ</span>, and <span class="ar">اُمْتُقِعَ</span>; <span class="auth">(the former in some copies of the Ḳ; the latter in others; and both in the TA;)</span> i. e. <em>His colour changed,</em> <span class="auth">(TA,)</span> <em>by reason of grief,</em> or <em>sorrow.</em> <span class="auth">(Ḥar p. 244.)</span> The last of these three verbs is the best. <span class="auth">(Ḥar ubi suprà.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqoEapN">
				<h3 class="entry"><span class="ar">بَقْعَةٌ</span></h3>
				<div class="sense" id="baqoEapN_A1">
					<p><span class="ar">بَقْعَةٌ</span> <em>A place in which water remains and stagnates;</em> <span class="auth">(Ḳ;)</span> <span class="add">[and <em>which is not a usual place of watering:</em> (<a href="#baAqiEapN">see <span class="ar">بَاقِعَةٌ</span></a>:) this is what is meant, app., by its being said that]</span> <span class="ar">بِقَاعٌ</span>, which is its pl., signifies the <em>contr. of</em> <span class="ar">مَشَارِعُ</span> <span class="add">[or watering-places to which men and beasts are accustomed to come]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">بَقْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baqoEapN_A2">
					<p><a href="#buqoEapN">See also what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buqoEapN">
				<h3 class="entry"><span class="ar">بُقْعَةٌ</span></h3>
				<div class="sense" id="buqoEapN_A1">
					<p><span class="ar">بُقْعَةٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">بَقْعَةٌ↓</span></span>, <span class="auth">(AZ, Mṣb, Ḳ,)</span> but the former is the more common, <span class="auth">(Mṣb,)</span> and more chaste, <span class="auth">(TA,)</span> <em>A piece, part, portion,</em> or <em>plot,</em> <span class="auth">(Mgh, Mṣb, Ḳ,)</span> of land, or ground, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>differing</em> <span class="add">[<em>in any manner,</em>]</span> <em>in colour,</em> <span class="auth">(Mgh,)</span> or <em>in appearance,</em> or <em>external state</em> or <em>condition,</em> <span class="auth">(Ḳ,)</span> <em>from that which adjoins it,</em> or <em>is next to it:</em> <span class="auth">(Mgh, Ḳ:)</span> this is the primary signification: <span class="auth">(Mgh:)</span> <span class="add">[<em>a patch of ground:</em>]</span> pl. <span class="ar">بِقَاعٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or this <a href="#baqoEapN">is pl. of <span class="ar">بَقْعَةٌ</span></a>, <span class="auth">(Mṣb, TA,)</span> and <a href="#buqoEapN">the pl. of <span class="ar">بُقْعَةٌ</span></a> is <span class="ar">بُقَعٌ</span>. <span class="auth">(Mgh, Mṣb, TA.)</span> You say <span class="ar long">أَرْضٌ فِيهَا بُقَعٌ مِنَ الجَرَادِ</span> <span class="add">[meaning <em>Land in which are bare places occasioned by the locusts</em>]</span>. <span class="auth">(Lḥ, Ḳ.)</span> And <span class="ar long">فِى الأَرْضِ مِنْ نَبْتٍ</span> <em>In the land are small portions of herbage.</em> <span class="auth">(AḤn.)</span> And <span class="ar long">بُقْعَةٌ مِنْ كَلَأ</span> <em>A patch of herbage.</em> <span class="auth">(TA in art. <span class="ar">بقطً</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">بُقْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="buqoEapN_A2">
					<p><span class="add">[The former also signifies <em>A spot;</em> or <em>small portion of any surface, distinct from what surrounds it.</em>]</span> And the pl. <span class="ar">بُقَعٌ</span> <em>Places</em> in a garment, or piece of cloth, which has been dyed, <em>remaining undyed.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">بُقَعُ المَآءِ</span> <em>Places</em> in a garment, or piece of cloth, which has been washed, <em>in which the water remains, undried.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">بُقْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="buqoEapN_A3">
					<p><span class="ar long">هُوَ حَسَنُ البُقْعَةِ عِنْدَ الأَمِيرِ</span> ‡ <em>He has a good station with the prince,</em> or <em>commander.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#julobapN">See also <span class="ar">جُلْبَةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqiEapN">
				<h3 class="entry"><span class="ar">بَقِعَةٌ</span></h3>
				<div class="sense" id="baqiEapN_A1">
					<p><span class="ar long">أَرْضٌ بَقِعَةٌ</span> <em>Land in which are</em> <span class="ar long">بُقَعٌ مِنَ الجَرَادِ</span> <span class="add">[meaning <em>bare place occasioned by the locusts</em>]</span>: <span class="auth">(Lḥ, Ḳ:)</span> and <em>land of which the herbage is unconnected</em> <span class="add">[or <em>in patches</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqaAEi">
				<h3 class="entry"><span class="ar">بَقَاعِ</span></h3>
				<div class="sense" id="baqaAEi_A1">
					<p><span class="ar long">أَصَابَهُ خُرْءُ بَقَاعِ</span>, like <span class="ar">قَطَامِ</span>, <span class="add">[indecl.,]</span> and decl., <span class="auth">(Ḳ,)</span> and imperfectly decl., so that you say also <span class="ar">بَقَاعٍ</span>, and <span class="ar">بَقَاعَ</span>, <span class="auth">(AZ, TA,)</span> <em>Dust and sweat came upon him, and discolorations produced thereby remained upon his body:</em> <span class="auth">(AZ, Ḳ:)</span> by <span class="ar">بقاع</span> is <span class="add">[lit.]</span> meant <em>land,</em> or <em>a land:</em> so says AZ: and <span class="ar long">عَلَيْهِ خُرْءُ بَقَاع</span> is said to mean <em>upon him is sweat which has become white upon his skin, like what are termed</em> <span class="ar">لُمَعٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baqiyEN">
				<h3 class="entry"><span class="ar">بَقِيعٌ</span></h3>
				<div class="sense" id="baqiyEN_A1">
					<p><span class="ar">بَقِيعٌ</span> <em>A place in which are roots of trees of various kinds:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>a wide,</em> or <em>spacious, place:</em> or <em>a place in which are trees:</em> <span class="auth">(Mṣb:)</span> or <em>a wide,</em> or <em>spacious, piece of land;</em> but not so called unless <em>containing trees;</em> <span class="auth">(TA;)</span> though <span class="ar long">بَقيعُ الغَرْقَدِ</span> continued to the name of a burialground of El-Medeeneh after the trees therein had ceased to be. <span class="auth">(Mṣb,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAqiEapN">
				<h3 class="entry"><span class="ar">بَاقِعَةٌ</span></h3>
				<div class="sense" id="baAqiEapN_A1">
					<p><span class="ar">بَاقِعَةٌ</span> <em>A bird</em> <span class="auth">(Ḳ, TA)</span> <em>that is cautious,</em> or <em>wary, and cunning,</em> or <em>wily, that looks to the right and left when drinking,</em> <span class="auth">(TA,)</span> <em>that does not come to drink to the</em> <span class="ar">مَشَارِع</span> <span class="add">[or <em>watering-places to which men and beats are accustomed to come</em>]</span>, <span class="auth">(Ḳ, TA, <span class="add">[but in the CK, for <span class="ar">مشارع</span> is put <span class="ar">مَشارِب</span>,]</span>)</span> <em>and the frequented waters,</em> <span class="auth">(TA,)</span> <em>from fear of being caught, but only drinks from the</em> <span class="ar">بَقْعَة</span>, i. e., the <em>place in which water remains and stagnates.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">بَاقِعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAqiEapN_A2">
					<p>Hence, as being likened thereto, ‡ <em>Any one that is cautious,</em> or <em>wary, cunning,</em> or <em>wily,</em> and <em>skilful:</em> <span class="auth">(TA:)</span> ‡ <em>a man possessing much cunning:</em> <span class="auth">(Ḳ, TA:)</span> <span class="add">[accord. to some]</span> so called because he alights and abides in <span class="add">[various]</span> parts (<span class="ar">بِقَاع</span>) of the earth, and often traverses countries, and possesses much knowledge thereof: to such, therefore, is likened ‡ <em>a man knowing,</em> or <em>skilful, in affairs, who investigates them much, and is experienced therein;</em> the <span class="ar">ة</span> being added to give intensiveness to the signification: <span class="auth">(TA:)</span> and ‡ <em>sharp,</em> or <em>quick, in intellect; knowing; whom nothing escapes, and who is not to be deceived, beguiled,</em> or <em>circumvented:</em> <span class="auth">(Ḳ, TA:)</span> pl. <span class="ar">بَوَاقِعُ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">مَا فُلَانٌ إِلَّا بَاقِعَةٌ مِنَ البَوَاقِعِ</span> ‡ <em>Such a one is none other than a very cunning man of the very cunning.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">بَاقِعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAqiEapN_A3">
					<p>Also † <em>A calamity,</em> or <em>misfortune,</em> <span class="auth">(Ṣ, TA,)</span> <em>that befalls a man.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboqaEu">
				<h3 class="entry"><span class="ar">أَبْقَعُ</span></h3>
				<div class="sense" id="OaboqaEu_A1">
					<p><span class="ar">أَبْقَعُ</span>, applied to a <span class="ar">غُرَاب</span> <span class="add">[or bird of the crowkind]</span>, <em>In which is blackness and whiteness;</em> <span class="auth">(Ṣ, TA;)</span> and so applied to a dog: <span class="auth">(Lḥ, TA voce <span class="ar">أَبْرَقُ</span>, q. v.:)</span> or, applied to the former, <em>having whiteness in the breast;</em> and this is the worst <span class="add">[or most ill-omened]</span> of the crow-kind: <span class="auth">(TA:)</span> <span class="add">[it is this species, accord. to some, which is called <span class="ar long">غُرَابُ البَيْنِ</span>: (<a href="index.php?data=02_b/238_byn">see art. <span class="ar">بين</span></a>:)]</span> or, applied to a <span class="ar">غراب</span>, &amp;c., <em>party-coloured,</em> or <em>pied:</em> <span class="auth">(Mṣb:)</span> or the <em>whitewinged</em> <span class="ar">غراب</span>: <span class="auth">(ISh, TA in art. <span class="ar">حذف</span>:)</span> pl., when thus applied, <span class="ar">بُقْعَانٌ</span>, <span class="auth">(TA,)</span> or <span class="ar">بِقْعَانٌ</span>, with kesr; the quality of a subst. being predominant in it; but when it is regarded as an epithet, <span class="add">[in which case the fem. is <span class="ar">بَقْعَآءُ</span>,]</span> its pl. is <span class="ar">بُقْعٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaboqaEu_A2">
					<p>Hence, as being likened to such a bird, ‡ Anything <em>bad, evil, wicked, mischievous,</em> <span class="add">[<em>ill-omened,</em>]</span> or <em>the like.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaboqaEu_A3">
					<p>And † <em>Leprous.</em> <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaboqaEu_A4">
					<p><span class="ar long">بُقْعَانُ الشَّأْمِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> with damm, <span class="auth">(Ḳ,)</span> mentioned in a trad., <span class="auth">(Ṣ,)</span> † <em>The servants and slaves of Syria;</em> because of their whiteness and redness, <span class="auth">(Ṣ, Ḳ,)</span> or blackness; <span class="auth">(Ṣ;)</span> or because of their whiteness and redness and blackness likened to a thing such as is termed <span class="ar">أَبْقَعُ</span>; <span class="auth">(TA;)</span> or <span class="auth">(Ḳ)</span> because they are of the Greeks and the Negroes: <span class="auth">(Ṣ, Ḳ:)</span> or so called because of the mixture of their colours; their predominant colours being white and yellow: AʼObeyd says that what is meant is whiteness and yellowness, and they are thus called because of their difference of colours and their being begotten of two races: but Ḳṭ says, <span class="ar">البُقْعَانُ</span> signifies † <em>those in whom is blackness and whiteness;</em> and one who is white without any admixture of blackness is not called <span class="ar">ابقع</span>: how then should the Greeks be called <span class="ar">بقعان</span> when they are purely white? and he adds that he thinks the meaning to be, the <em>offspring of Arabs, who are black,</em> <span class="add">[which is not to be understood literally, but rather in the sense of <em>swarthy,</em>]</span> <em>by female slaves of the Greeks, who are white.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaboqaEu_A5">
					<p><span class="ar">بُقْعٌ</span> is also applied to <em>Waterers</em> (<span class="ar">سُقَاةٌ</span>); because their bodies become sprinkled with the water, so that some parts thereof are wetted. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaboqaEu_A6">
					<p><span class="ar long">رَأَيْتُ قَوْمًا بُقْعًا</span> ‡ <em>I saw a people wearing patched garments;</em> said by El-Hajjáj; <span class="auth">(Ḳ, TA;)</span> and thus explained by him; i. e., by reason of their evil condition. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaboqaEu_A7">
					<p><span class="ar long">ذَوْدٌ بُقْعُ الذُّرَى</span> <em>A herd of camels having white humps.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaboqaEu_A8">
					<p><span class="ar">الأَبْقَعُ</span> <em>The mirage;</em> because of its varying, or assuming different hues. <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0236"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaboqaEu_A9">
					<p><span class="ar long">أَرْضٌ بَقْعَآءُ</span> <em>Land containing</em> <span class="add">[or <em>diversified with</em>]</span> <em>small pebbles.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بقع</span> - Entry: <span class="ar">أَبْقَعُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="OaboqaEu_A10">
					<p><span class="ar long">سَنَةٌ بَقْعَآءُ</span> ‡ <em>A barren,</em> or <em>an unfruitful, year:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>a year in which is fruitfulness and barrenness.</em> <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> And <span class="ar long">عَامٌ أَبْقَعُ</span> ‡ <em>A year in which the rain falls in places of the land, not universally.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">عَامٌ أُبَيْقِعُ↓</span></span>, <span class="auth">(Ḳ,)</span> the dim. form being used to denote terribleness, <span class="auth">(TA,)</span> ‡ <em>A year of little rain.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubayoqiEu">
				<h3 class="entry"><span class="ar">أُبَيْقِعُ</span></h3>
				<div class="sense" id="OubayoqiEu_A1">
					<p><span class="ar">أُبَيْقِعُ</span>, <a href="#OaboqaEu">dim. of <span class="ar">أَبْقَعُ</span></a>, which see, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaqBaEu">
				<h3 class="entry"><span class="ar">مُبَقَّعُ</span></h3>
				<div class="sense" id="mubaqBaEu_A1">
					<p><span class="ar long">هُوَ مُبَقَّعُ الرِّجْلَيْنِ</span> <em>He has his legs wetted by water in some places, so that their</em> <span class="add">[<em>general</em>]</span> <em>colour is different from the colour of those places.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0235.pdf" target="pdf">
							<span>Lanes Lexicon Page 235</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0236.pdf" target="pdf">
							<span>Lanes Lexicon Page 236</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
