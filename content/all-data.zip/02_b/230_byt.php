<article class="root" id="Root_byt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/229_byb">بيب</a></span>
				<span class="ar">بيت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/231_byH">بيح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="byt_1">
				<h3 class="entry">1. ⇒ <span class="ar">بيت</span> ⇒ <span class="ar">بات</span></h3>
				<div class="sense" id="byt_1_A1">
					<p><span class="ar">بَاتَ</span>, <span class="auth">(T, Ṣ M, &amp;c.,)</span> aor. <span class="ar">يَبِيتُ</span> and <span class="ar">يَبَاتُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَيْتُوتَةٌ</span> <span class="auth">(Lth, T, Ṣ A, Mṣb, Ḳ)</span> and <span class="ar">مَبِيتٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">مَبَاتٌ</span> <span class="auth">(Mṣb)</span> and <span class="ar">بَيْتٌ</span> and <span class="ar">بَيَاتٌ</span>, <span class="auth">(Ḳ,)</span> has two meanings: in that which more commonly obtains, the action is restricted to the night: <span class="auth">(Mṣb:)</span> it is by night, or in night; not in sleep: <span class="auth">(M:)</span> you say, <span class="ar long">بَاتَ يَفْعَلُ كَذَا</span>, meaning <em>He did such a thing by night,</em> or <em>at night:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> <span class="add">[or <em>he was in the night,</em> or <em>at night,</em> or <em>during the night, doing such a thing:</em> and <em>he passed,</em> or <em>spent, the night,</em> or <em>a night,</em> or a <em>part thereof,</em> or, as will be seen below, <em>he entered upon the night, doing such a thing:</em>]</span> like as one says, <span class="ar long">ظَلَّ يَفْعَلُ كَذَا</span> as meaning “he did such a thing by day,” or “at day-time:” <span class="auth">(Ṣ, Mṣb;*)</span> IḲooṭ and Es-Sarakustee and IḲṭṭ say that it has this meaning, and not “he slept:” <span class="auth">(Mṣb:)</span> <span class="add">[F adds,]</span> <span class="ar long">وَلَيْسَ مِنَ النَّوْمِ</span>, <span class="auth">(Ḳ,)</span> which is said to mean, “and the action is not one of sleep;” so that when one sleeps by night, or at night, it is not correct to say, <span class="ar long">بَاتَ يَنَامُ</span>: or, accord. to some, “its meaning is not that of sleeping;” so that one may say, <span class="ar long">بَاتَ زَيْدٌ نَائِمًا</span> <span class="add">[<em>Zeyd was in the night,</em>, &amp;c., or <em>passed,</em> or <em>spent, the night,</em>, &amp;c., <em>sleeping</em>]</span>: <span class="auth">(MF:)</span> <span class="add">[Fei says,]</span> it is only when one remains awake in the night: and hence the saying in the Ḳur <span class="add">[xxv. 65]</span>, <span class="ar long">وَٱلَّذِينَ يَبِيتُونَ لِرَّبِهِمْ سُجَّدًا وَقِيامًا</span> <span class="add">[<em>And those who pass the night prostrating themselves to their Lord and standing up</em> in prayer]</span>: <span class="auth">(Mṣb:)</span> Fr says that <span class="ar long">بَاتَ الرَّجُلُ</span> means <em>The man remained awake all the night,</em> engaged in acts of obedience or of disobedience: <span class="auth">(T, Mṣb:)</span> <span class="add">[or it means <em>the man entered upon the night;</em> or <em>he was in the night,</em> or <em>at night,</em> or <em>during the night,</em> in any state, or engaged in any action; for]</span> Zj says, <span class="auth">(M,)</span> <span class="ar">بَاتَ</span> is said of any one whom the night has overtaken, <span class="auth">(M, Ḳ,*)</span> whether he have slept or not slept: <span class="auth">(M:)</span> and Lth says, <span class="ar">البَيْتُوتَةُ</span> signifies <em>the entering upon the night:</em> one says, <span class="ar long">بِتُّ أَصْنَعُ كَذَا وَكَذَا</span> <span class="add">[<em>I entered upon the night doing such and such things</em>]</span>: and he adds, <span class="auth">(T,)</span> he who says <span class="ar">بَاتَ</span> as meaning <em>he slept</em> commits an error; for you say, <span class="ar long">بِتُّ أُرَاعِى النُّجُومَ</span> <span class="add">[<em>I entered upon,</em> or <em>passed, the night</em>]</span> <em>looking at the stars:</em> and how can he be sleeping who is looking at them? <span class="auth">(T, Mṣb:)</span> but Mullà ʼAbd-El-Hakeem, in his Commentaries on the Mutowwal, says that <span class="ar">بَاتَ</span> sometimes means <em>he remained, continued, stayed,</em> or <em>dwelt,</em> and <em>he alighted and abode, by night,</em> or <em>at night,</em> whether he slept or not: <span class="auth">(MF:)</span> and Ibn-Keysán says that it may be used in the same manner as <span class="ar">نَامَ</span> <span class="add">[<em>he slept</em>]</span>; and also, <span class="add">[as will be explained below,]</span> in the same manner as <span class="ar">كَانَ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">بَاتَ بَيْتُوتَةً صَالِحَةً</span> <span class="auth">(T)</span> or <span class="ar">طَيِّبَةً</span> <span class="auth">(A)</span> <span class="add">[<em>He passed,</em> or <em>entered upon, the night,</em> or <em>a night, in a good manner</em>]</span>. And <span class="ar long">بِتُّ القَوْمَ</span> and <span class="ar long">بِتُّ بِهِمْ</span> and <span class="ar long">بِتُّ عِنْدَهُمْ</span> <span class="add">[<em>I passed,</em> or <em>entered upon, the night,</em> or <em>a night, with,</em> or <em>at the abode of, the people,</em> or <em>company of men:</em> the last of these phrases is the most common]</span>. <span class="auth">(AʼObeyd, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byt_1_A2">
					<p>Secondly, it is used in the sense of <span class="ar">صَارَ</span> <span class="add">[<em>He became</em>]</span>; <span class="auth">(Mṣb;)</span> or in the same manner as <span class="ar">كَانَ</span> <span class="add">[<em>he was</em>]</span>. <span class="auth">(Ibn-Keysán, TA.)</span> One says, <span class="ar long">بَاتَ بِمَوْضِعِ كَذَا</span> <em>He became</em> <span class="add">[or <em>was</em>]</span> <em>in such a place;</em> whether in night-time or in day-time. <span class="auth">(Mṣb.)</span> And hence the saying of the lawyers, <span class="ar long">بَاتَ عِنْدَ ٱمْرَأَتِهِ لَيْلَةً</span> <em>He became</em> <span class="add">[or <em>was</em>]</span> <em>with his wife one night;</em> <span class="add">[which is the same as <em>he passed a night</em>, &amp;c.; though this, it will be observed, is not in this instance the signification of the verb alone;]</span> whether sleeping or not. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="byt_1_A3">
					<p><span class="add">[Thus it is used both as a “complete,” i. e. an attributive, verb, and also as an “incomplete,” i. e. a non-attributive, verb.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="byt_1_A4">
					<p><span class="ar">بَاتَ</span>, aor. <span class="ar">يَبِيتُ</span>, <span class="auth">(T, A,)</span> inf. n. <span class="ar">بَيْتٌ</span>, <span class="auth">(T, M, Ḳ,)</span> also signifies ‡ <em>He married,</em> or <em>took a wife:</em> <span class="auth">(T, A:)</span> <span class="add">[<a href="#baYotN">see <span class="ar">بَيْتٌ</span> below</a>:]</span> or † <em>he gave in marriage;</em> syn. of the inf. n. <span class="ar">تَزْوِيجٌ</span>. <span class="auth">(Kr, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byt_2">
				<h3 class="entry">2. ⇒ <span class="ar">بيّت</span></h3>
				<div class="sense" id="byt_2_A1">
					<p><span class="ar long">بيّت البَيْتَ</span> <em>He constructed,</em> or <em>built, the</em> <span class="ar">بَيْت</span> <span class="add">[i. e. <em>tent,</em> or <em>house,</em>, &amp;c.]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="byt_2_B1">
					<p><span class="ar long">بيّت الأَمْرِ</span>, <span class="add">[inf. n. as below,]</span> <em>He did,</em> or <em>performed, the thing,</em> or <em>affair, by night,</em> or <em>at night:</em> <span class="auth">(M:)</span> and <em>he thought,</em> or <em>meditated, upon it, considering its end,</em> or <em>issue,</em> or <em>result,</em> <span class="auth">(Zj, T, Ṣ, M, A, Mṣb, Ḳ,)</span> or <em>entered into it,</em> <span class="auth">(Zj, T,)</span> <em>by night,</em> or <em>at night.</em> <span class="auth">(Zj, T, Ṣ, M, &amp;c.)</span> And one says, <span class="ar long">بُيِّتَ بِلَيْلٍ</span>, <span class="auth">(T, A,)</span> meaning the same as <span class="ar long">دُبِّرَ بِلَيْلِ</span> <span class="add">[<em>It was thought,</em> or <em>meditated, upon,</em>, &amp;c., <em>by night,</em> or <em>at night</em>]</span>: <span class="auth">(T:)</span> <span class="add">[for]</span> <span class="ar long">بُيِّتَ الشَّىْءُ</span> also signifies <span class="add">[simply]</span> <em>the thing was thought upon, and considered as to its end, issue,</em> or <em>result;</em> syn. <span class="ar">قُدِّرَ</span>. <span class="auth">(Ṣ.)</span> Accord. to El-Marzookee, they say of a thing that is not done deliberately, and with good consideration of its issue or result, <span class="ar long">هٰذَا أَمْرٌ قُدِّرَ بِلَيْلٍ</span>; <span class="add">[in the text from which this is taken, without the syll. signs;]</span> and hence the saying in the Ḳur <span class="add">[iv. 83]</span>, <span class="ar long">بَيَّتَ طَائِفَةٌ مِنْهُمْ غَيْرِ ٱلَّذِى تَقُولُ</span> <span class="add">[<em>A part of them meditateth by night upon doing otherwise than that which thou sayest;</em> as is indicated in the M, where this is cited; and in like manner, <span class="ar">يُبَيِّتُونَ</span>, in the continuation of the same passage of the Ḳur, is explained in the T as meaning <span class="ar">يُدَبِّرُونَ</span>, and <span class="ar">يُقَدِّرُونَ</span>, <span class="auth">(i. e. <span class="ar long">مِنَ السُّوْءِ</span>,)</span> <span class="ar">لَيْلًا</span>]</span>: but Aboo-Hilál says that a thing is meditated upon in the night in order that one may apply himself to it with strong purpose, and not be diverted by other things, so that it may be done with more firmness; and he cites the same passage of the Ḳur. <span class="auth">(Ḥam p. 130.)</span> And hence, in the Ḳur <span class="add">[iv. 108]</span>, <span class="ar long">إِذْ يُبَيِّتُونَ مَا لَا يَرْضَى مِنَ القَوْلِ</span> <em>When they meditate,</em>, &amp;c., <span class="auth">(Ṣ, M, Bḍ, Jel,)</span> <em>by night,</em> <span class="auth">(Ṣ, M,)</span> <span class="add">[<em>what He will not approve, of speech,</em>]</span> <em>and prepare it</em> <span class="add">[<em>in their minds</em>]</span> (<span class="ar">يُزَوِّرُونَهُ</span> <span class="add">[<a href="index.php?data=11_z/123_zwr">see art. <span class="ar">زور</span></a>]</span>). <span class="auth">(Bḍ.)</span> It is said in a trad., <span class="ar long">لَا صِيَامَ لِمَنْ لَمْ يُبَيِّتِ الصِّيَامَ</span> <em>There is no fasting to him</em> <span class="add">[meaning <em>his fasting is null</em>]</span> <em>who does not purpose it from the night.</em> <span class="auth">(TA. <span class="add">[See another reading, voce <span class="ar">بَتَّ</span>.]</span>)</span> And you say, <span class="ar long">بَيَّتَ النِّيَّةَ</span> <em>He decided upon the purpose,</em> or <em>intention, by night,</em> or <em>in night-time.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">بَيَّتَ رَأْيَهُ</span> <em>He thought upon his opinion, and concealed it,</em> or <em>conceived it, in his mind.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="byt_2_B2">
					<p><span class="ar">بَيَّتَهُمْ</span>, inf. n. <span class="ar">تَبْيِيتٌ</span>, <span class="auth">(Mṣb, TA,)</span> <em>He came upon them,</em> <span class="auth">(Mgh, but the verb is there pl.,)</span> or <em>made a sudden attack upon them, and engaged with them in conflict,</em> <span class="auth">(Mṣb,)</span> or <em>made a great slaughter among them,</em> or <em>engaged with them in vehement conflict,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> namely, the enemy, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> or a people, <span class="auth">(M,)</span> <em>by night:</em> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ:)</span> <em>he came upon them</em> <span class="auth">(the sons of such a one)</span> <em>in the night, and made a sudden attack upon them, while they were heedless:</em> <span class="auth">(T:)</span> <em>he attacked them</em> <span class="auth">(the people of a house or place of abode)</span> <em>by night: he went to them</em> <span class="auth">(the enemy)</span> <em>in the night, without their knowledge, and took them by surprise.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="byt_2_B3">
					<p><span class="ar long">كَانَ لَا يُبَيِّتُ مَا لاًا وَلَا يُقَيِّلُهُ</span> <em>He used not to retain property until night, nor to retain it until noon,</em> when it came to him; but used to hasten the dividing of it. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="byt_2_B4">
					<p><a href="#byt_4">See also 4</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="byt_2_C1">
					<p><span class="ar long">بيّت النَّخْلَ</span> <em>He trimmed,</em> or <em>pruned, the palm-trees, by cutting off the stumps of the branches, or by cutting off the straggling branches, not in the best part thereof.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="byt_2_D1">
					<p><a href="#byt_5">See also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byt_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابيت</span> ⇒ <span class="ar">ابات</span></h3>
				<div class="sense" id="byt_4_A1">
					<p><span class="ar">اباتهُ</span>, inf. n. <span class="ar">إِبَاتَةٌ</span>, <em>He</em> <span class="auth">(God)</span> <em>made him,</em> or <em>caused him, to pass,</em> or <em>spend, the night,</em> <span class="add">[or <em>a part thereof,</em>]</span> or <em>to enter upon the night.</em> <span class="auth">(T, M, Ḳ.)</span> You say, <span class="ar long">أَبَاتَكَ ٱللّٰهُ حَسَنَةً</span> <span class="add">[<em>May God make thee to pass,</em> or <em>enter upon, the night with happiness</em>]</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">إِبَاتَةً حَسَنَةً</span> <span class="add">[<em>in a good manner of doing so</em>]</span>. <span class="auth">(T, A.)</span> And <span class="add">[in like manner,]</span> <span class="arrow"><span class="ar long">بَيَّتَكَ↓ ٱللّٰهُ فِى عَافِيَةٍ</span></span> <span class="add">[<em>May God make thee to pass,</em> or <em>enter upon, the night in health and safety</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">أَبَاتَهُ ٱللّٰهُ أَحْسَنَ بِيتَةٍ</span> <em>God made him to pass,</em> or <em>enter upon, the night in the best manner of doing so.</em> <span class="auth">(M, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byt_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبيّت</span></h3>
				<div class="sense" id="byt_5_A1">
					<p><span class="ar long">تبيّتهُ عَنْ حَاجَتِهِ</span> <span class="add">[so in the TA and in a MṢ. copy of the Ḳ: in the CK <span class="arrow"><span class="ar">بَيَّتَهُ↓</span></span>:]</span> <em>He withheld,</em> or <em>debarred, him from the thing that he wanted.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="byt_10">
				<span class="pb" id="Page_0280"></span>
				<h3 class="entry">10. ⇒ <span class="ar">استبيت</span> ⇒ <span class="ar">استبات</span></h3>
				<div class="sense" id="byt_10_A1">
					<p><span class="add">[<span class="ar">استبات</span> seems to signify <em>He asked for,</em> or <em>required,</em> <span class="ar">بِيت</span>, or <span class="ar">بِيتَة</span> i. e. <em>food:</em> (<a href="#musotabiytN">see <span class="ar">مُسْتَبِيتٌ</span></a>:) and also to have the contr. signification; i. e.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="byt_10_A2">
					<p><span class="add">[<em>He possessed food:</em> for you say,]</span> <span class="ar long">لَا يَسْتَبِيتُ لَيْلَةً</span> <em>He possesses not a night's food.</em> <span class="auth">(T, Ḳ.)</span> And <span class="ar long">لَا يَسْتَبِيتُ</span> <em>He has not food.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayotN">
				<h3 class="entry"><span class="ar">بَيْتٌ</span></h3>
				<div class="sense" id="bayotN_A1">
					<p><span class="ar">بَيْتٌ</span> <span class="add">[signifies <em>A tent;</em> properly, <em>having more than one pole;</em> but often applied without this restriction: and also <em>a house; a chamber; an apartment; a closet;</em> and <em>the like</em>]</span>: a <span class="ar">بَيْت</span> is <span class="add">[<em>a tent</em>]</span> <em>of</em> <span class="add">[<em>goats'</em>]</span> <em>hair</em> (<span class="ar">شَعَر</span>), <span class="auth">(M, A, Mgh, Mṣb, Ḳ,)</span> or <em>of wool:</em> <span class="auth">(Mgh:)</span> <em>a</em> <span class="ar">بيت</span> <em>of hair</em> <span class="add">[i. e. <em>hair-cloth</em>]</span> <em>is that kind</em> <span class="add">[<em>of tent</em>]</span> <em>which has more than one pole:</em> the word is masc.: and applies to <em>small</em> and <em>large:</em> <span class="auth">(M:)</span> tents of goats' hair are peculiar to people of cold countries and of fertile regions, where the goats have abundant hair; for the goats of the Arabs of the desert have short hair, not long enough to be spun: <span class="auth">(T in art. <span class="ar">بنى</span>:)</span> a <span class="ar">خِبَآء</span> is a small <span class="ar">بيت</span> of wool or of hair: a <span class="ar">بيت</span> is <em>what is larger than a</em> <span class="ar">خبآء</span>: next is the <span class="ar">مِظَلَّة</span>, which is larger than the <span class="ar">بيت</span>; but the term <span class="ar">بيت</span> is also applied to <em>a</em> <span class="ar">مظلّة</span> <em>when it is large and</em> <span class="ar">مُرَوَّق</span> <span class="add">[i. e. <em>furnished with a</em> <span class="ar">رِوَاق</span>, q. v.]</span>: <span class="auth">(T:)</span> Ibn-El-Kelbee says that the Arabs have six kinds of <span class="ar">بيت</span>; namely, a <span class="ar">قُبَّة</span>, which is of skins, or tanned hides; a <span class="ar">مِظَلَّة</span>, of hair; a <span class="ar">خِبَآء</span>, of wool; a <span class="ar">بِجَاد</span>, of soft hair (<span class="ar">وَبَر</span>); a <span class="ar">خَيْمَة</span>, of trees; an <span class="ar">أُقْنَة</span>, of stone; and a <span class="ar">سَوْط</span>, of hair; or this is the smallest of them: El-Baghdádee says that the <span class="ar">خباء</span> is a <span class="ar">بيت</span> made of soft hair (<span class="ar">وَبَر</span>), or of wool, or of hair <span class="add">[commonly so called]</span> (<span class="ar">شَعَر</span>), upon two poles, or three; and that a <span class="ar">بيت</span> is <span class="add">[<em>a tent</em>]</span> <em>upon six poles, or more, to the number of nine:</em> in the Towsheeh it is said that the term <span class="ar">خباء</span> is applied to a <span class="ar">بيت</span> of any kind: <span class="auth">(TA:)</span> a <span class="ar">بيت</span> is also <span class="add">[<em>a structure</em>]</span> <em>of clay,</em> or <em>tough or cohesive clay or earth;</em> <span class="auth">(A, Ḳ;)</span> <span class="add">[and <em>of baked bricks;</em> and <em>of stone;</em>]</span> the name being likewise applied to <em>a structure of a kind other than the structures which are called</em> <span class="ar">أَخْبِيَة</span> <span class="add">[or <em>tents</em>]</span>; <span class="auth">(M;)</span> signifying <em>a habitation</em> <span class="add">[<em>of any kind; an abode; a dwelling</em>]</span>: <span class="auth">(Mṣb:)</span> a man's <em>house;</em> syn. <span class="ar">دَارٌ</span>: <span class="auth">(T:)</span> <span class="add">[and particularly <em>a chamber;</em> i. e.]</span> <em>a single roofed structure</em> <span class="auth">(Mgh, Kull)</span> <em>having a place of entrance;</em> <span class="ar">مَنْزِلٌ</span> being applied to what comprises more than one <span class="add">[such]</span> <span class="ar">بيت</span>, and a roofed <span class="ar">صَحْن</span> <span class="add">[or vacant part, and a kitchen, inhabited by a man with his family]</span>; and <span class="ar">دَارٌ</span>, that which comprises more than one <span class="add">[such]</span> <span class="ar">بيت</span> and more than one <span class="add">[such]</span> <span class="ar">مَنْزِل</span> and a <span class="add">[court, or]</span> <span class="ar">صَحْن</span> without a roof: <span class="auth">(Kull:)</span> the pl. is <span class="ar">بُيُوتٌ</span>, <span class="auth">(Ṣ, M, Ḳ, &amp;c.,)</span> also pronounced <span class="ar">بِيُوتٌ</span>, <span class="auth">(TA,)</span> and <span class="ar">أَبْيَاتٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> the latter a pl. of pauc.; <span class="auth">(TA;)</span> and pl. pl. <span class="ar">بُيُوتَاتٌ</span> <span class="auth">(M, Mgh, Ḳ)</span> and <span class="ar">أَبَايِيتُ</span> <span class="auth">(Sb, Ṣ, M, Ḳ)</span> and <span class="ar">أَبْيَاوَاتٌ</span>, <span class="auth">(Fr, M, Ḳ,)</span> which last is extr.: <span class="auth">(M:)</span> the dim. is <span class="arrow"><span class="ar">بُيَيْتٌ↓</span></span>, also pronounced <span class="arrow"><span class="ar">بِيَيْتٌ↓</span></span>; <span class="auth">(Ṣ, Ḳ;)</span> and the vulgar say, <span class="ar">بُوَيْتٌ</span>, <span class="auth">(Ṣ,)</span> which is not allowable. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">هُوَ جَارِى بَيْتَ بَيْتَ</span>, <span class="auth">(T, Ṣ, M,)</span> <em>He is my neighbour</em> <span class="add">[<em>tent to tent,</em> or <em>house to house,</em> i. e.,]</span> <em>by contiguity</em> <span class="add">[<em>of our habitations</em>]</span>: <span class="ar long">بيت بيت</span> being made indecl. with fet-ḥ for the termination because they are two nouns made one: <span class="auth">(Ṣ:)</span> Sb says that some of the Arabs make them <span class="add">[thus]</span> indecl., like <span class="ar long">خَمْسَةَ عَشَرَ</span>, and some make the former a prefixed noun governing the latter in the gen. case, <span class="add">[saying <span class="ar long">بَيْتَ بَيْتٍ</span>,]</span> except when used as a denotative of state: <span class="auth">(M:)</span> one says also, <span class="ar long">بَيْتًا لِبَيْتٍ</span>, and <span class="ar long">بَيْتٌ لِبَيْتٍ</span>; <span class="auth">(Fr, T;)</span> which last, or <span class="ar long">بَيْتٌ إِلَى بَيْتٍ</span>, is the original form. <span class="auth">(Ḥar p. 353.)</span> <span class="ar long">بَنَى فُلَانٌ عَلَى ٱمْرَأَتِهِ</span> <span class="add">[lit. <em>Such a one constructed a tent over his wife,</em>]</span> means <em>such a one had his wife conducted to him on the occasion of his marriage, and brought her,</em> or <em>had her brought, into a pitched tent, having conveyed thither the utensils and furniture and other things that they required.</em> <span class="auth">(T.)</span> And <span class="ar long">أَهْلُ بَيْتُ النَّبِىِّ</span> <span class="add">[<em>The people of the house of the Prophet,</em>]</span> means <em>the Prophet's wives and his daughter and ʼAlee:</em> and so <span class="ar long">أَهْلَ ٱلْبَيْتِ</span> <span class="add">[i. e. <span class="ar long">يَخُصُّ أَهْلَ البَيْتِ</span> <em>He means particularly,</em> or <em>peculiarly, the people of the house</em>]</span>, in the Ḳur xxxiii. 33: <span class="ar">بَنُو</span> and <span class="ar">مَعْشَر</span> and <span class="ar">أَهْل</span> and <span class="ar">آل</span>, as prefixed nouns, being, as Sb says, the nouns most frequently occurring in the accus. case <span class="add">[for the reason indicated above, or, as the Arabian grammarians express it,]</span> <span class="ar long">عَلَى الاِخْتِصَاصِ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayotN_A2">
					<p>It also signifies <em>A</em> <span class="add">[<em>pavilion, palace,</em> or <em>mansion, such as is called</em>]</span> <span class="ar">قَصْر</span>: <span class="auth">(T, Ḳ:)</span> whence the saying of Gabriel, <span class="ar long">بَشِّرْ خَدِيجَةَ بِبَيْتٍ مِنْ قَصَبٍ</span>, i. e. <span class="add">[<em>Rejoice thou Khadeejeh by the announcement of</em>]</span> <em>a pavilion</em> (<span class="ar">قصر</span>) <em>of hollow pearls,</em> <span class="auth">(T, TA,)</span> or <em>of emerald.</em> <span class="auth">(TA. <span class="add">[<a href="index.php?data=21_q/109_qSb">See also art. <span class="ar">قصب</span></a>.]</span>)</span> <span class="ar long">بُيُوتًا غَيْرَ مَسْكُونَةٍ</span> <span class="add">[<em>Uninhabited houses</em>]</span>, in the Ḳur xxiv. 29, means <em>buildings for the reception of travellers, or for merchants and their goods, and the shops of the merchants and places in which things are sold, the entering of which is allowed by their owners:</em> or <em>ruins which a man enters for the purpose of easing nature.</em> <span class="auth">(M.)</span> And the <span class="ar">بُيُوت</span> which God has permitted to be raised, mentioned in the same chapter, verse 36, are <em>Mosques,</em> or <em>places of worship:</em> or, accord. to El-Ḥasan, <em>Jerusalem</em> (<span class="ar long">بَيْتُ المَقْدِسِ</span>); the pl. being applied to it as a mark of honour. <span class="auth">(Zj, M.)</span> <span class="ar">البَيْتُ</span> <span class="add">[<em>The House</em>]</span> applies particularly to ‡ <em>the Kaabeh</em> <span class="add">[<em>of Mekkeh</em>]</span>; <span class="auth">(Ḳ;)</span> as also <span class="ar long">بَيْتُ ٱللّٰهِ</span> <span class="add">[<em>the House of God</em>]</span>; <span class="auth">(AAF, M;)</span> and <span class="ar long">البَيْتُ الحَرَامُ</span> <span class="add">[<em>the Sacred House</em>]</span>; <span class="auth">(T;)</span> and <span class="ar long">البَيْتُ العَتِيقُ</span> <span class="add">[<em>the Ancient House</em>]</span>; <span class="auth">(Ṣ and Ḳ, &amp;c. in art. <span class="ar">عتق</span>;)</span> and accord. to some, <span class="ar long">البَيْتُ المَعْمُورُ</span>, q. v. <span class="auth">(Bḍ in lii. 4.)</span> <span class="add">[<span class="ar long">بَيْتُ المَالِ</span> signifies <em>The treasury of the state.</em> And <span class="ar long">بَيْتُ المَآءِ</span> is a euphemism for <em>The privy;</em> because water is put there for the purpose of ablution: also called <span class="ar long">بَيْتُ الفَرَاغِ</span>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayotN_A3">
					<p>Also † The <em>ark</em> of Noah: so in the Ḳur lxxi. last verse. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bayotN_A4">
					<p>‡ <em>A grave;</em> <span class="auth">(M, IAth, Ḳ;)</span> app. by way of comparison. <span class="auth">(M.)</span> So in a trad. of Aboo-Dharr: <span class="ar long">كَيْفَ تَصْنَعُ إِذَا مَاتَ النَّاسُ حَتَّى يَكُونُ البَيْتُ بِالوَصِيفِ</span>, meaning <em>How will thou do when men shall die so that the grave shall be sold for the</em> <span class="add">[<em>servant-</em>]</span> <em>boy?</em> <span class="auth">(IAth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bayotN_A5">
					<p>† The <em>habitation</em> of the <span class="ar">سُرْفَة</span>, which it constructs in a beautiful manner, <span class="auth">(AʼObeyd, M,)</span> of fragments of sticks; <span class="auth">(Yaạḳoob, M;)</span> and of the <span class="ar">صَيْدَنَانِىّ</span>, which it makes in the interior of the earth, and covers over: <span class="auth">(AʼObeyd, M:)</span> and † the <em>burrow,</em> or <em>hole,</em> of the <span class="ar">ضَبّ</span>, &amp;c.: and † the <em>web</em> of the spider: all, app., as being likened to the <span class="ar">بَيْت</span> of a man. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bayotN_A6">
					<p>‡ A man's <em>household.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bayotN_A7">
					<p>‡ The <em>wife</em> <span class="auth">(Aṣ, IAạr, T, M, A)</span> of a man. <span class="auth">(M, A.)</span> So in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَكِبَرٌ غَيَّرَنِى أمْ بَيْتُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Hath old age altered me, or a wife?</em>]</span>: <span class="auth">(Aṣ, T:)</span> or here it means <em>a household.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bayotN_A8">
					<p>The <em>nobility</em> of the Arabs; <span class="auth">(T, Mṣb, Ḳ;*)</span> as when one says, <span class="ar long">بَيْتُ تَمِيمٍ فِى بَنِى حَنْظَلَةَ</span> <span class="add">[<em>The nobility of Temeem is in the sons of Handhaleh</em>]</span>: <span class="auth">(T, Mṣb:*)</span> or the <em>family that comprises the nobility of a tribe;</em> as <span class="ar long">آلُ حِصْنٍ</span> of the <span class="ar">فَزَارِيُّون</span>, and <span class="ar long">آلُ الجُدَّيْنِ</span> of the <span class="ar">شَيْبَانِيُّون</span>, and <span class="ar long">آلُ عَبْدِ المَدَانِ</span> of the <span class="ar">حَارِثِيُّون</span>; which three were asserted by Ibn-El-Kelbee to be the highest of the families thus called of the Arabs: <span class="auth">(M:)</span> <span class="add">[see a verse of El-Lahabee cited voce <span class="ar">أَخْضَرُ</span>:]</span> pl. <span class="ar">بُيُوتٌ</span> and <span class="ar">بُيُوتَاتٌ</span>, <span class="auth">(T, M,)</span> the latter being pl. of the former. <span class="auth">(T.)</span> You say, <span class="ar long">هُوَ مِنْ أَهْلِ البُيُوتَاتِ</span> <em>He is of the people of nobility:</em> and <span class="ar long">مِنْ بَيْتٍ كَرِيمٍ</span> <span class="add">[<em>of a generous,</em> or <em>noble, house,</em> or <em>family</em>]</span>. <span class="auth">(A.)</span> <span class="add">[<a href="#banae">See also <span class="ar">بَنَى</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="bayotN_A9">
					<p><em>A noble person:</em> <span class="auth">(M, Mgh, Ḳ:)</span> pl. <span class="ar">بُيُوتٌ</span> and <span class="ar">بُيُوتَاتٌ</span>. <span class="auth">(Mgh.)</span> You say, <span class="ar long">فُلَانٌ بَيْتُ قَوْمِهِ</span> <em>Such a one is the noble person of his people.</em> <span class="auth">(Abu-l-ʼOmeythil El-Aarabee, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="bayotN_A10">
					<p>‡ The <span class="add">[<em>furniture termed</em>]</span> <span class="ar">فَرْش</span>, <span class="auth">(A, Mgh, Ḳ,)</span> or <span class="ar">مَتَاع</span>, <span class="auth">(TA,)</span> <em>of a tent</em> or <em>house,</em> <span class="auth">(Mgh, Ḳ,)</span> or <em>that is sufficient for a tent</em> or <em>house.</em> <span class="auth">(A.)</span> You say, <span class="ar long">تَزَوَّجْتُ فُلَانَةَ عَلَى بَيْتٍ</span> ‡ <em>I married,</em> or <em>took as a wife, such a woman for</em> <span class="add">[<em>my giving</em>]</span> <em>furniture sufficient for a tent</em> or <em>house,</em> <span class="auth">(A,)</span> or <em>furniture of a house</em> or <em>tent.</em> <span class="auth">(Mgh.)</span> <span class="add">[<a href="#byt_1">See 1</a>, last sentence.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="bayotN_A11">
					<p>A <span class="ar">بَيْت</span> of poetry, <span class="auth">(T, Ṣ, M, Mṣb,)</span> or of the poet, <span class="auth">(Ḳ,)</span> is ‡ <span class="add">[<em>A verse;</em> i. e.]</span> <em>what consists of certain known divisions</em> <span class="add">[or <em>feet</em>]</span> <em>called</em> <span class="ar long">أَجْزَآءُ التَّفْعِيلِ</span>; being termed <span class="ar">بيت</span> metaphorically, because of the conjoining of its component parts, one to another, in a particular manner, like as those of a tent are conjoined in its construction; <span class="auth">(Mṣb;)</span> because it consists of words collected together in a regular manner, and so resembles a tent, which is composed of a <span class="ar">سَقْف</span> and <span class="ar">كِفَآء</span> and <span class="ar">رِوَاق</span> and <span class="ar">عُمُد</span>: <span class="auth">(T:)</span> it is derived from the same word signifying a <span class="ar">خِبَآء</span> <span class="add">[or tent]</span>, and applies to the small and the great, as the <span class="ar">رَجَز</span> and the <span class="ar">طَوِيل</span>; and is <span class="add">[said to be]</span> thus called because it comprises words like as the tent comprises its inhabitants; wherefore its component parts are termed <span class="ar">أَسْبَاب</span> and <span class="ar">أَوْتَاد</span>, as being likened to the <span class="ar">اسباب</span> and <span class="ar">اوتاد</span> of tents: <span class="auth">(M:)</span> pl. <span class="ar">أَبْيَاتٌ</span> and <span class="ar">بُيُوتٌ</span>, <span class="auth">(M, A, Mṣb,)</span> the latter mentioned by Sb and IJ, <span class="auth">(M,)</span> <span class="add">[but rare,]</span> and <span class="add">[pl. pl.]</span> <span class="ar">أَبَايِيتُ</span>: <span class="auth">(A:)</span> Abu-l-Ḥasan says that if the <span class="ar">بيت</span> of poetry be likened to the <span class="ar">بيت</span> which is a tent or other kind of structure, there is no reason why it should not have the same pl. forms as the latter has. <span class="auth">(L.)</span> By the following words of a poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَبَيْتٍ عَلَى ظَهْرِ المَطِىِّ بَنَيْتُهُ</span> *</div> 
						<div class="star">* <span class="ar long">بِأَسْمَرَ مَشْقُوقِ الخَيَاشِيمِ يَرْعُفُ</span> *</div> 
					</blockquote>
					<p><span class="pb" id="Page_0281"></span><span class="add">[<em>Many a</em> <span class="ar">بيت</span> <em>upon the back of the camel have I constructed with a lawny thing slit in the nose</em> and <em>bleeding</em>]</span>, is meant, many a <span class="ar">بيت</span> of poetry have I written with the reed-pen. <span class="auth">(Ṣ.)</span> <span class="add">[<span class="ar">البَيْتَ</span>, written after a quotation of a part of a verse of poetry, means <span class="ar long">اِقْرَأِ البَيْتَ</span> <em>Read thou the verse.</em>]</span> <span class="ar long">بَيْتُ القَصِيدَةِ</span> <span class="add">[<em>The</em> chief <em>verse of the poem</em>]</span> is a phrase employed when a person composes a poem in praise of any one from whom he would obtain some object of desire and want, being applied to <em>that verse of the poem in which the author's want is mentioned:</em> and is a proverbial expression relating to that which is extraordinary and strange, and used in denoting the superiority of a part of a thing over the whole of it <span class="add">[regarded as a whole]</span>: <span class="add">[hence,]</span> one says, <span class="ar long">فُلَانٌ أَوَّلُ الجَرِيدَةِ وَبَيْتُ القَصِيدَةِ</span> † <span class="add">[<em>Such a one is the first of the detachment of horsemen, and the chief verse of the poem</em>]</span>. <span class="auth">(Ḥar p. 441.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biytN">
				<h3 class="entry"><span class="ar">بِيتٌ</span></h3>
				<div class="sense" id="biytN_A1">
					<p><span class="ar">بِيتٌ</span>: <a href="#biytapN">see <span class="ar">بِيتَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biytapN">
				<h3 class="entry"><span class="ar">بِيتَةٌ</span></h3>
				<div class="sense" id="biytapN_A1">
					<p><span class="ar">بِيتَةٌ</span> a subst. from <span class="ar">بَاتَ</span>: and signifying <em>A manner</em> or <em>mode,</em> and <em>state,</em> or <em>condition, of passing,</em> or <em>entering upon, the night.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#byt_4">See 4</a>; last sentence.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بِيتَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="biytapN_B1">
					<p><em>Food,</em> or <em>victuals;</em> and so<span class="arrow"><span class="ar">بِيتٌ↓</span></span>: <span class="auth">(A, Ḳ:)</span> <span class="add">[or particularly, of a night: for]</span> you say,<span class="arrow"><span class="ar long">مَا لَهُ بِيتُ↓ لَيْلَةٍ</span></span>, <span class="auth">(Ṣ M, A, Ḳ.)</span> and <span class="ar long">بِيتَةٌ لَيْلَةٍ</span>, <span class="auth">(T, Ṣ, M, A,)</span> <span class="ar long">مِنَ القُوتِ</span>, <span class="auth">(T,)</span> <em>He has not a night's food,</em> or <em>victuals.</em> <span class="auth">(T, Ṣ, M, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayaAtN">
				<h3 class="entry"><span class="ar">بَيَاتٌ</span></h3>
				<div class="sense" id="bayaAtN_A1">
					<p><span class="ar">بَيَاتٌ</span> <em>A coming upon the enemy by night;</em> <span class="auth">(Mgh;)</span> <em>a sudden attack upon, and conflict with, the enemy by night;</em> <span class="auth">(Mṣb;)</span> <em>a great slaughter</em> <span class="auth">(Ṣ, M)</span> <em>among the enemy,</em> <span class="auth">(Ṣ,)</span> or <em>a people,</em> <span class="auth">(M,)</span> <em>and vehement conflict with them;</em> <span class="auth">(Ṣ, M;)</span> <em>a coming upon people in the night, and making a sudden attack upon them, while they are heedless;</em> <span class="auth">(T;)</span> <em>an attack upon a people by night; a going to the enemy in the night, without their knowledge, and taking them by surprise:</em> <span class="auth">(TA:)</span> a subst. from 2; <span class="auth">(Ṣ, M, Mgh, Mṣb;)</span> like <span class="ar">سَلَامٌ</span> from <span class="ar">سَلَّمَ</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيَاتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayaAtN_A2">
					<p><span class="ar long">أَتَاهُمُ الأَمْرُ بَيَاتًا</span> <em>The thing,</em> or <em>event, happened,</em> or <em>came, to them in the latter part of the night.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="buyayotN">
				<h3 class="entry"><span class="ar">بُيَيْتٌ</span></h3>
				<div class="sense" id="buyayotN_A1">
					<p><span class="ar">بُيَيْتٌ</span>, also pronounced <span class="ar">بِيَيْتٌ</span>, <a href="#baYotN">dim. of <span class="ar">بَيْتٌ</span>, q. v.</a> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayBuwtN">
				<h3 class="entry"><span class="ar">بَيُّوتٌ</span></h3>
				<div class="sense" id="bayBuwtN_A1">
					<p><span class="ar">بَيُّوتٌ</span> <em>That has remained throughout a night</em> <span class="add">[<em>and so become stale; stale from being a night old</em>]</span>; as also<span class="arrow"><span class="ar">بَائِتٌ↓</span></span>: both, in this sense, <span class="add">[but the latter more usually,]</span> applied to bread. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيُّوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayBuwtN_A2">
					<p><em>Cold,</em> or <em>cool,</em> water, <span class="auth">(M, Ḳ,)</span> <em>that has become so from its having remained throughout a night:</em> <span class="auth">(M:)</span> or water <em>that remains during the night beneath the sky:</em> <span class="auth">(Ḥam p. 553:)</span> or water <em>that has been cooled in the leathern bag by night;</em> and in like manner, milk; for <span class="add">[Az says,]</span> I heard an Arab of the desert say, <span class="ar long">اِسْقِنِى مِنْ بَيُّوتِ السِّقَآءِ</span>, meaning <em>Give thou me to drink of the milk that has been milked at night and left in the skin so that it has become cold,</em> or <em>cool, by night.</em> <span class="auth">(T.)</span> In the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَصَبَّحَتْ حَوضَ قِرًى بَيُّوتَا</span> *</div> 
					</blockquote>
					<p>the meaning seems to be, <span class="ar long">قِرَى حَوْضٍ بَيُّوتَا</span>, i. e., <span class="add">[<em>And they</em> <span class="auth">(app. camels)</span> <em>came in the morning to</em>]</span> <em>the collected water of a trough, which</em> water <em>had remained throughout the night and so become cold,</em> or <em>cool;</em> the phrase being inverted. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيُّوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayBuwtN_A3">
					<p><span class="ar long">أَمْرٌ بَيُّوتٌ</span> † <em>An affair,</em> or <em>event, for which,</em> or <em>on account of which, one passes the night in anxiety</em> or <em>grief.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيُّوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bayBuwtN_A4">
					<p><span class="ar long">هَمٌّ بَيُّوتٌ</span> † <em>Anxiety,</em> or <em>grief, that has remained during the night in the bosom.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَيُّوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bayBuwtN_A5">
					<p><span class="ar long">سِنٌّ بَيُّوتَةٌ</span> <em>A tooth that does not fall out,</em> or <em>become shed.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAYitN">
				<h3 class="entry"><span class="ar">بَائِتٌ</span></h3>
				<div class="sense" id="baAYitN_A1">
					<p><span class="ar">بَائِتٌ</span> <span class="add">[<em>Passing,</em> or <em>spending, the night,</em> or <em>a night,</em> or <em>a part thereof;</em> or <em>entering upon the night;</em>, &amp;c.;]</span> act. part. n. of 1. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بيت</span> - Entry: <span class="ar">بَائِتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAYitN_A2">
					<p><a href="#bayBuwtN">See also <span class="ar">بَيُّوتٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabiytN">
				<h3 class="entry"><span class="ar">مَبِيتٌ</span></h3>
				<div class="sense" id="mabiytN_A1">
					<p><span class="ar">مَبِيتٌ</span> <em>A place in which one passes,</em> or <em>enters upon, the night.</em> <span class="auth">(M, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabayBitapN">
				<h3 class="entry"><span class="ar">مُتَبَيِّتَةٌ</span></h3>
				<div class="sense" id="mutabayBitapN_A1">
					<p><span class="ar">مُتَبَيِّتَةٌ</span> A woman <em>who has obtained a</em> <span class="ar">بَيْت</span> <span class="add">[i. e. <em>tent</em> or <em>house,</em> or <em>the furniture thereof,</em>]</span> <em>and a husband.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotabiytN">
				<h3 class="entry"><span class="ar">مُسْتَبِيتٌ</span></h3>
				<div class="sense" id="musotabiytN_A1">
					<p><span class="ar">مُسْتَبِيتٌ</span> <em>Poor,</em> or <em>needy;</em> <span class="add">[as though meaning <em>asking for,</em> or <em>requiring,</em> <span class="ar">بِيت</span> or <span class="ar">بِيتَة</span>, i. e. <em>food;</em> or <em>possessing food, and nothing beside;</em>]</span> syn. <span class="ar">فَقِيرٌ</span> <span class="add">[q. v.]</span>. <span class="auth">(IAạr, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0279.pdf" target="pdf">
							<span>Lanes Lexicon Page 279</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0280.pdf" target="pdf">
							<span>Lanes Lexicon Page 280</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0281.pdf" target="pdf">
							<span>Lanes Lexicon Page 281</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
