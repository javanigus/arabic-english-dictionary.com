<article class="root" id="Root_bdr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/042_bdO">بدأ</a></span>
				<span class="ar">بدر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/044_bdE">بدع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bdr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بدر</span></h3>
				<div class="sense" id="bdr_1_A1">
					<p><span class="ar">بَدَرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُرُ</span>}</span></add>, inf. n. <span class="ar">بَدْرٌ</span>, <em>It</em> <span class="auth">(the moon)</span> <em>became full.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdr_1_A2">
					<p>‡ <em>He</em> <span class="auth">(a boy)</span> <em>became full-grown and round;</em> implying comparison to the full moon. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bdr_1_A3">
					<p>† <em>It</em> <span class="auth">(fruit)</span> <em>attained to maturity.</em> <span class="auth">(TA, from a trad.)</span> <span class="add">[<a href="#bdr_4">See also 4</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bdr_1_A4">
					<p><em>It rose like the full moon.</em> <span class="auth">(Er Rághib.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdr_1_B1">
					<p><a href="#bdr_3">See also 3</a>, in six places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="bdr_1_B2">
					<p><span class="ar long">بَدَرَتْ مِنْهُ بَوَادِرُ غضَبٍ</span> and <span class="ar long">بَدَرَت بَوَادِرُ الخَيْلِ</span>: <a href="#baAdirapN">see <span class="ar">بَادِرَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="bdr_1_B3">
					<p><span class="ar long">بَدَرَتِ الإِبِلَ</span> <em>She</em> <span class="auth">(a camel)</span> <em>brought forth at an earlier period of the year than the other camels.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#badoriyBapN">See <span class="ar">بَدْرِيَّةٌ</span></a>, voce <span class="ar">بَدْرِىٌّ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="bdr_1_B4">
					<p><span class="ar long">خَرَجْتُ أَبْدُرُ</span> ‡ <em>I went forth to make water.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdr_3">
				<h3 class="entry">3. ⇒ <span class="ar">بادر</span></h3>
				<div class="sense" id="bdr_3_A1">
					<p><span class="ar">بادرهُ</span>, inf. n. <span class="ar">مُبَادَرَةٌ</span> and <span class="ar">بِدَارٌ</span>; and<span class="arrow"><span class="ar">ابتدرهُ↓</span></span>; <em>He hastened,</em> or <em>made haste,</em> or <em>strove to be first</em> or <em>beforehand, in doing</em> <span class="add">[or <em>attaining</em> or <em>obtaining</em>]</span> <em>it;</em> <span class="auth">(M, Ḳ, TA, TḲ;)</span> namely, a thing: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar long">بَدَرَ↓ غَيْرُهُ إِلَيْهِ</span></span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُرُ</span>}</span></add>; and <span class="ar long">بادرهُ اليه</span>; <span class="auth">(M;)</span> <em>He hastened with another,</em> or <em>vied</em> or <em>strove with him in hastening, to it</em> <span class="add">[or <em>to do</em> or <em>attain</em> or <em>obtain it</em>]</span>: syn. <span class="ar">عَاجَلَهُ</span>, <span class="auth">(M, Ḳ, TA,)</span> and <span class="ar long">أَسْرَعَ إِلَيْهِ</span>. <span class="auth">(TA.)</span> <span class="ar">بادر</span> <span class="add">[as well as <span class="arrow"><span class="ar">بَدَرَ↓</span></span> and<span class="arrow"><span class="ar">ابتدر↓</span></span>]</span> denotes mutual effort only when it is immediately trans.: when it is trans. by means of <span class="ar">إِلَى</span> <span class="add">[or <span class="ar">بِ</span> <span class="auth">(the former in the TA written by mistake <span class="ar">على</span>)</span>]</span>, there is nothing to show that it denotes this. <span class="auth">(MF.)</span> <span class="add">[But it is often immediately trans. without its denoting such effort.]</span> One says, <span class="ar">بادرهُ</span> <em>He hastened to do it</em> <span class="add">[&amp;c., as explained above]</span>; meaning, a thing that he desired, or wished for: <span class="auth">(TA:)</span> <span class="add">[and <span class="ar">بادربِهِ</span> signifies <em>the same;</em> or <em>he hastened with it:</em> and the former signifies also <em>he betook himself early to him</em> or <em>it:</em>]</span> and <span class="ar long">بادر إِلَيْهِ</span> <em>he hastened to it;</em> <span class="auth">(Ṣ, A;)</span> as also<span class="arrow"><span class="ar long">بَدَرَ↓ اليه</span></span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُرُ</span>}</span></add>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">بُدُورٌ</span>: <span class="auth">(Ṣ, Mṣb:)</span> or, accord. to Zj, agreeably with its derivation, <span class="add">[<a href="#badorN">see <span class="ar">بَدْرٌ</span></a>,]</span> <em>he employed the fulness of his power,</em> or <em>force, to hasten</em> <span class="add">[<em>to it</em>]</span>: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">بَدَرَهُ↓ الأَمْرُ</span></span>, and<span class="arrow"><span class="ar long">بَدَرَ↓ إِلَيْهِ</span></span>, <span class="auth">(aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْدُرُ</span>}</span></add>, inf. n. <span class="ar">بَدْرٌ</span>, TA, <span class="add">[or <span class="ar">بُدُورٌ</span>, as above,]</span>)</span> <em>the thing,</em> or <em>event, came to him,</em> or <em>happened to him, hastily, quickly,</em> or <em>speedily;</em> and, <em>beforehand</em> <span class="add">[or <em>before he expected it</em>]</span>; syn. <span class="ar">عَجِلَ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar">سَبَقَ</span>, <span class="auth">(M,)</span> or <span class="ar">اِسْتَبَقَ</span>: <span class="auth">(Ḳ:)</span> <span class="add">[and<span class="arrow"><span class="ar long">بَدَرَ↓ مِنْهُ قَوْلٌ</span></span>, and <span class="ar">فِعْلٌ</span>, <em>a saying,</em> and <em>an action, proceeded from him hastily, without premeditation:</em> <a href="#baAdirapN">see <span class="ar">بَادِرَةٌ</span></a>.]</span> It is said in a trad., <span class="ar long">بَادِرُوا بِالْأَعْمَالِ هَرَمًا</span> <span class="add">[<em>Strive ye to be before decrepitude with good works;</em> i. e., <em>to perform them before decrepitude</em>]</span>. <span class="auth">(El-Jámiʼ es- Sagheer.)</span> And in another, <span class="ar long">بَادِرُوا الصُّبْحَ بِالْوِتْرِ</span> <span class="add">[<em>Strive ye to be before daybreak with the prayers termed</em> <span class="ar">وتر</span>; i. e., <em>to perform them before daybreak</em>]</span>. <span class="auth">(Idem.)</span> And in another, <span class="ar long">بَادِرُوا بِصَلاَةِ المَغْرِبِ قَبْلَ طُلُوعِ النَّجْمِ</span> <span class="add">[<em>Hasten ye with,</em> or <em>to perform, the prayer of sunset before the rising of the star</em>]</span>. <span class="auth">(Idem.)</span> You say also, <span class="ar long">فُلَانٌ يُبَادِرُ فِى أَكْلِ مَالِ اليَتِيمِ</span> <span class="add">[<em>Such a one hastens in consuming the property of the orphan</em> before the latter is of full age]</span>. <span class="auth">(A.)</span> And <span class="ar long">بَادَرَ كِبَرَ اليَتِيمِ</span> <span class="add">[<em>He hastened to be before the orphan's attaining to full age in expending his property</em>]</span>; said of a guardian; <em>i. q.</em><span class="arrow"><span class="ar long">أَبْدَرَ↓ فِى مَالِ اليَتِيمِ</span></span>: <span class="auth">(Ḳ:)</span> and thus, <span class="ar long">بِدَارًاأَنْ يَكْبَرُوا</span>, in the Ḳur <span class="add">[iv. 5]</span>, means <em>hastening to be before their attaining to full age</em> in expending their property. <span class="auth">(Bḍ,* Jel.)</span> And <span class="ar long">بادرهُ الغَايَةَ</span> and <span class="ar long">إِلَى الغَايَةِ</span> <span class="add">[<em>He strove with him in hastening,</em> or <em>strove to get before him, to the goal</em>]</span>. <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">ابتدر↓ الغَايَةَ</span></span> and <span class="ar long">إِلَى الغَايَةِ</span> <span class="add">[<em>He strove in hastening,</em> or <em>strove to get first, to the goal</em>]</span>. <span class="auth">(Ḥam p. 46.)</span> And <span class="ar long">بَادَرَ بَعْضُهُمْ بَعْضًا إِلَى أَمْرٍ</span>, and<span class="arrow"><span class="ar long">ابتدروا↓ أَمْرًا</span></span>, and<span class="arrow"><span class="ar">تبادروهُ↓</span></span>, <em>They vied,</em> or <em>strove, one with another, in hastening to a thing,</em> or <em>an affair, trying which of them would be first.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابدر</span></h3>
				<div class="sense" id="bdr_4_A1">
					<p><span class="ar">ابدر</span> <em>He had the full moon rising to him,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> or <em>upon him:</em> <span class="auth">(A:)</span> a verb similar to <span class="ar">أَقْمَرَ</span> and <span class="ar">أَشْرَقَ</span>: <span class="auth">(A:)</span> or <em>he journeyed during a night of full moon.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bdr_4_B1">
					<p><em>It</em> <span class="auth">(an unripe date)</span> <em>became red.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#bdr_1">See also 1</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="bdr_4_C1">
					<p><span class="ar long">ابدر فِى المَالِ اليَتِيمِ</span>: <a href="#bdr_3">see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdr_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبادر</span></h3>
				<div class="sense" id="bdr_6_A1">
					<p><span class="ar">تبادروا</span> <em>They hastened together; vied,</em> or <em>strove, one with another, in hastening; made haste to be,</em> or <em>get, before one another; strove, one with another, to be first,</em> or <em>beforehand.</em> <span class="auth">(Ṣ, TA.)</span> You say, <span class="ar long">تبادروا إِلَى أَخْذِ السِّلَاحِ</span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar long">ابتدروا↓ السِّلَاحَ</span></span>, <span class="auth">(Ṣ, TA,)</span> <em>They hastened together,</em>, &amp;c., <em>to take the weapons.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">تبادروا البَاعَ</span> <span class="add">[<em>They hastened together;</em> or <em>vied,</em> or <em>strove, one with another, in hastening; to attain power,</em> or <em>eminence,</em> or <em>nobility</em>]</span>; as also<span class="arrow"><span class="ar">ابتدروهُ↓</span></span>. <span class="auth">(A.)</span> nd <span class="ar long">تبادروا أَمْرًآ</span>: <a href="#bdr_3">see 3</a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdr_6_A2">
					<p><span class="ar long">هٰذَا مَا يَتَبَادَرُ مِنْهُ</span> † <span class="add">[<em>This</em> meaning <em>is what appears from it</em> <span class="auth">(namely, the phrase, or sentence,)</span> <em>at first sight</em>]</span>. <span class="auth">(A phrase of frequent occurrence in the TA, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتدر</span></h3>
				<div class="sense" id="bdr_8_A1">
					<p><a href="#bdr_3">see 3</a>, in four places; <a href="#bdr_6">and see 6</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bdr_8_A2">
					<p><span class="ar long">اِبْتَدَرَتْ عَيْنَاىَ</span> <em>My eyes flowed with tears.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bdr_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">بَيْدَرَ</span></h3>
				<div class="sense" id="bdr_QQ1_A1">
					<p><span class="ar">بَيْدَرَ</span> <em>He heaped up</em> wheat. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badorN">
				<h3 class="entry"><span class="ar">بَدْرٌ</span></h3>
				<div class="sense" id="badorN_A1">
					<p><span class="ar">بَدْرٌ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ, &amp;c.,)</span> originally an inf. n., <span class="auth">(Mṣb,)</span> The <em>full moon;</em> <span class="auth">(M, A, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">بَادِرٌ↓</span></span>; <span class="auth">(L, Ḳ;)</span> the <em>moon in its fourteenth night:</em> <span class="auth">(Ṣ:)</span> or the latter signifies <span class="add">[simply]</span> the <em>moon:</em> <span class="auth">(IAạr, T:)</span> the moon in its fourteenth night is called <span class="ar">بدر</span> because it hastens to rise before the sun sets; <span class="auth">(Ṣ, M;)</span> and to set before the sun rises: <span class="auth">(TA:)</span> or because of its fulness; <span class="auth">(Ṣ, TA;)</span> as being likened to a <span class="ar">بَدْرَة</span>: or, as Er-Rághib thinks to be most probable, it is itself a primitive word: <span class="auth">(TA:)</span> pl. <span class="ar">بُدُورٌ</span>. <span class="auth">(M, A.)</span> Hence, <span class="ar long">لَيْلَةُ البَدْرِ</span> <span class="add">[<em>The night of the full moon;</em> which is]</span> <em>the fourteenth night</em> <span class="add">[<em>of the lunar month</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badorN_A2">
					<p>‡ <em>A lord, master,</em> or <em>chief,</em> <span class="auth">(M, Ḳ,)</span> of a people: so called as being likened to the full moon. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badorN_A3">
					<p>Applied to a boy, <span class="auth">(Zj, M, Ḳ,)</span> ‡ <em>Full of youthful vigour and of flesh:</em> <span class="auth">(Zj:)</span> or <em>full,</em> or <em>plump:</em> <span class="auth">(M:)</span> or <em>i. q.</em><span class="arrow"><span class="ar">مُبَادِرٌ↓</span></span> <span class="add">[<em>precocious</em>]</span>. <span class="auth">(T, Ḳ.)</span> <span class="add">[In this sense, an epithet; and so its fem. <span class="ar">بَدْرَةٌ</span> <span class="auth">(q. v.)</span>, applied to an eye.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="badorN_A4">
					<p>‡ <em>A cover;</em> or <em>a dish</em> or <em>plate;</em> syn. <span class="ar">طَبَقٌ</span>: <span class="auth">(Ibn-Wahb, Ḳ:)</span> because resembling the full moon, being round: so Az thinks. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="badorN_A5">
					<p><a href="#badorapN">See also <span class="ar">بَدْرَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badorapN">
				<h3 class="entry"><span class="ar">بَدْرَةٌ</span></h3>
				<div class="sense" id="badorapN_A1">
					<p><span class="ar">بَدْرَةٌ</span>, applied to an eye (<span class="ar">عَيْنٌ</span>), <em>Quick-sighted;</em> or <em>that sees before others:</em> <span class="auth">(Aṣ, T, Ṣ, Ḳ, TA:)</span> or <em>that sees before</em> <span class="add">[<em>the eyes of</em>]</span> <em>other horses;</em> applied to a horse's eye: <span class="auth">(IAạr, T, M:)</span> or <em>sharp-sighted:</em> or <em>round and large:</em> <span class="auth">(M:)</span> or <em>full like the full moon:</em> <span class="auth">(Ṣ, Ḳ:)</span> but the correct meaning is <span class="add">[said to be]</span> that <span class="add">[mentioned above as]</span> given by IAạr: <span class="auth">(M:)</span> or, accord. to IAạr, <em>full; not defective.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="badorapN_B1">
					<p>Also, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">بَدْرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> The <em>skin of a lamb</em> or <em>kid</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>when it has been weaned,</em> <span class="auth">(AZ, Ṣ, M,)</span> <em>used for milk:</em> for <span class="add">[when it is killed]</span> while it continues sucking, its skin, if used for milk, is called <span class="ar">شَكْوَةٌ</span>; <span class="pb" id="Page_0166"></span>and for clarified butter, <span class="ar">عُكَّة</span>: when it has been weaned, its skin for milk is called <span class="ar">بَدْرَة</span>; and for clarified butter, <span class="ar">مِسْأَد</span>: and when it is in its second year, its skin for milk is called <span class="ar">وَطْب</span>; and for clarified butter, <span class="ar">نِحْى</span>: <span class="auth">(AZ, Ṣ:)</span> pl. <span class="auth">(of the former, M)</span> <span class="ar">بِدَرٌ</span> and <span class="ar">بُدُورٌ</span>: <span class="auth">(M, Ḳ:)</span> the former said by El-Fárisee to be the only instance of the kind except <span class="ar">هِضَبٌ</span> <a href="#haDobapN">pl. of <span class="ar">هَضْبَةٌ</span></a>, and <span class="ar">بِضَعٌ</span> <a href="#baDoEapN">pl. of <span class="ar">بَضْعَةٌ</span></a> <span class="add">[or this may be <a href="#biDoEapN">pl. of <span class="ar">بِضْعَةٌ</span></a>]</span>. <span class="auth">(M. <span class="add">[But the assertion of El-Fárisee is incorrect (<a href="#HaYoDapN">see <span class="ar">حَيْضَةٌ</span></a>)</span>, unless it be meant to apply only to sound words; and in this case, at least one addition should be made, namely <span class="ar">قِصَعٌ</span> <a href="#qaSoEapN">pl. of <span class="ar">قَصْعَةٌ</span></a>.]</span>)</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="badorapN_B2">
					<p>Hence, <span class="auth">(M,)</span> the former word, <span class="auth">(Ṣ, M, A, Ḳ, &amp;c.,)</span> and<span class="arrow">↓</span> the latter also, <span class="auth">(Ḳ,)</span> The <em>sum of ten thousand dirhems:</em> <span class="auth">(Ṣ, A:)</span> or <em>a purse containing a thousand,</em> <span class="auth">(T, M, Ḳ,)</span> or <em>ten thousand, dirhems,</em> <span class="auth">(T, M,* A, Ḳ,)</span> or <em>seven thousand deenárs:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">بُدُورٌ</span>, <span class="auth">(TA,)</span> and pl. of pauc. <span class="ar">بِدَرَاتٌ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Albadarae">
				<h3 class="entry"><span class="ar">البَدَرَى</span></h3>
				<div class="sense" id="Albadarae_A1">
					<p><span class="ar long">اِسْتَبَقْنَا البَدَرَى</span> <em>We strove to outrun one another, vying, one with another, in haste.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badorieBN">
				<h3 class="entry"><span class="ar">بَدْرِىٌّ</span></h3>
				<div class="sense" id="badorieBN_A1">
					<p><span class="ar">بَدْرِىٌّ</span> Rain <em>that is before</em> (<span class="ar">قَبْلَ</span>), or <em>a little before</em> (<span class="ar">قُبَيْلَ</span>), or <em>in the first part of</em> (<span class="ar">قُبُلَ</span>), <em>winter.</em> <span class="auth">(Ḳ, accord. to different copies: the second reading is that followed in the TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="badorieBN_A2">
					<p><span class="ar">بَدْرِيَّةُ</span> A she-camel <em>whose mother has brought her forth at an earlier period of the year than that when the others brought forth, and therefore more abundant in milk than others, and of a more generous quality.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَدْرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="badorieBN_A3">
					<p>And the former, A <em>fat</em> young camel weaned from its mother. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="badaArieBN">
				<h3 class="entry"><span class="ar">بَدَارِىٌّ</span></h3>
				<div class="sense" id="badaArieBN_A1">
					<p><span class="ar">بَدَارِىٌّ</span> A lamb <em>brought forth a little before winter.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAdirN">
				<h3 class="entry"><span class="ar">بَادِرٌ</span></h3>
				<div class="sense" id="baAdirN_A1">
					<p><span class="ar">بَادِرٌ</span>: <a href="#badorN">see <span class="ar">بَدْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bayodarN">
				<h3 class="entry"><span class="ar">بَيْدَرٌ</span></h3>
				<div class="sense" id="bayodarN_A1">
					<p><span class="ar">بَيْدَرٌ</span> a word of the dial. of El-'Irák, <span class="auth">(AʼObeyd in art. <span class="ar">ربد</span> in the TA,)</span> <em>A place in which wheat,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> or <em>grain,</em> <span class="auth">(Mṣb,)</span> <em>is trodden out.</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَيْدَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bayodarN_A2">
					<p>It may also mean, tropically, ‡ The <em>wheat and straw therein:</em> <span class="auth">(Mgh:)</span> or rather, as Az says, on the authority of IAạr, it signifies <span class="add">[also]</span> <span class="auth">(Mgh)</span> <em>reaped grain collected together;</em> or <em>wheat collected together in the place in which it is trodden out;</em> syn. <span class="ar">كُدْسٌ</span>, <span class="auth">(M, Mgh, Ḳ,)</span> and <span class="ar">عَرَمَةٌ</span>: <span class="auth">(Mgh:)</span> Kr restricts it to wheat. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَيْدَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bayodarN_A3">
					<p>Accord. to the Towsheeh, it is <span class="add">[<em>A place</em>]</span> <em>for</em> <span class="add">[<em>drying</em>]</span> <em>dates.</em> <span class="auth">(TA in art. <span class="ar">جرن</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAdirapN">
				<h3 class="entry"><span class="ar">بَادِرَةٌ</span></h3>
				<div class="sense" id="baAdirapN_A1">
					<p><span class="ar">بَادِرَةٌ</span> <em>Hastiness of temper; passionateness:</em> <span class="auth">(Ṣ:)</span> or <em>a hasty saying,</em> or <em>action, that suddenly proceeds</em> (<span class="ar">يَبْدُرُ</span>, in the CK <span class="ar">يَبْدُو</span>,) <em>from one in anger:</em> <span class="auth">(M, A,* Mgh,* Mṣb,* Ḳ:)</span> and <em>a slip; a mistake; an error;</em> <span class="auth">(Ṣ, Mṣb;)</span> <em>on an occasion of one's being angry:</em> <span class="auth">(Ṣ:)</span> or <em>a bad, an abominable,</em> or <em>a foul, word</em> or <em>saying:</em> and <em>a quick fit of anger:</em> <span class="auth">(IAạr, T:)</span> pl. <span class="ar">بَوَادِرُ</span>, <span class="auth">(Ṣ, A.)</span> You say, <span class="ar long">أَخْشَى عَلَيْكَ بَادِرَتَهُ</span> <em>I fear for thee his hastiness of temper,</em> or <em>passionateness:</em> <span class="auth">(Ṣ:)</span> or <em>what may hastily proceed from him in his anger.</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">بَدَرَتْ↓ مِنْهُ يَوَادِرُ غَضَبٍ</span></span> <em>Slips, mistakes,</em> or <em>errors, on an occasion of his being angry, hastily proceeded from him.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">بَادِرَةُ الشَّرِّ</span> signifies <em>What hastily,</em> or <em>suddenly, befalls one, of evil,</em> or <em>mischief.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAdirapN_A2">
					<p><em>An intuitive knowledge, notion,</em> or <em>idea;</em> or <em>a faculty of judging rightly at the first of an unexpected occurrence;</em> or <em>a faculty of extemporizing;</em> syn. <span class="ar">بَدِيهَهٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">فُلَانُ حَسَنُ البَادِرَةِ</span> <em>Such a one has a good intuitive knowledge,</em>, &amp;c. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAdirapN_A3">
					<p>The <em>point</em> of a sword. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="baAdirapN_A4">
					<p>The <em>extremity</em> of an arrow, <em>next the head.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="baAdirapN_A5">
					<p>The <em>head</em> of a plant; <span class="auth">(M;)</span> the <em>first part</em> thereof <em>from which the earth cleaves asunder.</em> <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="baAdirapN_A6">
					<p>The <em>first that appears</em> of the <span class="add">[plant called]</span> <span class="ar">حِنَّآء</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="baAdirapN_A7">
					<p>The <em>leaves of the</em> <span class="add">[<em>herb called</em>]</span> <span class="ar">حُوَّآءَة</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="baAdirapN_A8">
					<p>The <em>best, and freshest in growth, of the</em> <span class="add">[<em>plant called</em>]</span> <span class="ar">وَرْس</span>. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="baAdirapN_A9">
					<p>Also, <span class="auth">(M, Ḳ,)</span> or <span class="ar">بَوَادِرُ</span>, <span class="auth">(Ṣ, A,)</span> which is the pl., <span class="auth">(Ḳ,)</span> of a man, &amp;c., <span class="auth">(Ṣ, M,)</span> The <em>portion of flesh,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> or the <em>portions thereof,</em> <span class="auth">(A,)</span> <em>between the shoulder-joint and the neck,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> or <em>between the necks and the shoulderjoints:</em> <span class="auth">(A:)</span> or the former, <span class="auth">(Ḳ,)</span> or its dual, <span class="auth">(M,)</span> of a man, the <em>two portions of flesh that are above the</em> <span class="ar">رُغَثَاوَانِ</span> <em>and below the</em> <span class="ar">ثَنْدُوَة</span>: <span class="auth">(M, Ḳ:)</span> or the dual, <span class="add">[relating to a camel, signifies]</span> the <em>two sides of the</em> <span class="ar">كِرْكِرَة</span> <span class="add">[or <em>callous lump on the breast</em>]</span>: or <em>two veins on either side thereof.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بدر</span> - Entry: <span class="ar">بَادِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="baAdirapN_A10">
					<p><span class="arrow"><span class="ar long">بَدَرَتْ↓ بَوَادِرُ الخَيْلِ</span></span> <em>The first,</em> or <em>fore parts,</em> (<span class="ar">أَوَائِل</span>,) <em>of the horses appeared</em> <span class="add">[or <em>suddenly came in view</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubadBarapN">
				<h3 class="entry"><span class="ar">مُبَدَّرَةٌ</span></h3>
				<div class="sense" id="mubadBarapN_A1">
					<p><span class="ar long">بَدْرَةٌ مُبَدَّرَةٌ</span> <span class="add">[<em>A sum such as is termed</em> <span class="ar">بدرة</span> <em>aggregated, made up,</em> or <em>completed</em>]</span>: the latter word is a corroborative; like the latter in <span class="ar long">قَنَاطِيرُ مُقَنْطَرَةٌ</span>, <span class="auth">(Ksh and Bḍ in iii. 12,)</span> and in <span class="ar long">أَلْفٌ مُؤَلَّفَةٌ</span>. <span class="auth">(Ksh ibid.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubaAdirN">
				<h3 class="entry"><span class="ar">مُبَادِرٌ</span></h3>
				<div class="sense" id="mubaAdirN_A1">
					<p><span class="ar">مُبَادِرٌ</span> applied to a boy: <a href="#badorN">see <span class="ar">بَدْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0165.pdf" target="pdf">
							<span>Lanes Lexicon Page 165</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0166.pdf" target="pdf">
							<span>Lanes Lexicon Page 166</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
