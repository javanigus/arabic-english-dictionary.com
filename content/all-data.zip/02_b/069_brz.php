<article class="root" id="Root_brz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/068_brcn">برذن</a></span>
				<span class="ar">برز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/070_brzx">برزخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="brz_1">
				<h3 class="entry">1. ⇒ <span class="ar">برز</span></h3>
				<div class="sense" id="brz_1_A1">
					<p><span class="ar">بَرَزَ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَبْرُزُ</span>}</span></add>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">بُرُوزٌ</span>, <span class="auth">(Ṣ, Mṣb, TA,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>went,</em> or <em>came,</em> or <em>passed, out,</em> or <em>forth; he issued.</em> <span class="auth">(Ṣ, A.)</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>went,</em> or <em>came,</em> or <em>passed, out,</em> or <em>forth, into the field, plain,</em> or <em>open tract or country:</em> <span class="auth">(Ḳ:)</span> or <em>did so to satisfy a want of nature:</em> <span class="auth">(TṢ, TA:)</span> as also, in the former sense, <span class="auth">(Ḳ,)</span> or in the latter, <span class="auth">(Ṣ,)</span> <span class="arrow"><span class="ar">تبرّز↓</span></span>; <span class="auth">(Ṣ, Ḳ, TA;)</span> and <span class="ar">بَرِزَ</span>; <span class="auth">(Ṣgh, TA;)</span> and so, in the former sense, <span class="arrow"><span class="ar">برّز↓</span></span> inf. n. <span class="ar">تَبْرِيزٌ</span>; <span class="auth">(Ḥar p. 510;)</span> <span class="add">[and in the latter sense, <span class="arrow"><span class="ar">بارز↓</span></span> accord. to an explanation of its part. n. <span class="ar">مُبَارِزٌ</span> in Ḥar p. 566:]</span> or<span class="arrow"><span class="ar">تبرّز↓</span></span> signifies <em>he voided his excrement,</em> or <em>ordure.</em> <span class="auth">(Mgh, Mṣb.)</span> You say, <span class="ar long">بَرَزَإِلَى القِرْنِ فِى الحَرْبِ</span> <em>He went,</em> or <em>came, out,</em> or <em>forth, into the field to his adversary in battle or war.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brz_1_A2">
					<p><em>He,</em> or <em>it,</em> <span class="auth">(a man, TA, or thing, Mṣb, or anything, Fr,)</span> <em>appeared,</em> or <em>became apparent,</em> <span class="auth">(Fr, Ṣgh, Mṣb, Ḳ,)</span> <em>after concealment,</em> <span class="auth">(Fr, Ḳ,)</span> or <em>after obscurity;</em> <span class="auth">(Ṣgh;)</span> as also <span class="ar">بَرِزَ</span> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="brz_1_A3">
					<p><span class="add">[<em>It was,</em> or <em>became, prominent,</em> or <em>projecting:</em> often used in this sense.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brz_1_B1">
					<p><span class="ar">بَرُزَ</span>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَرَازَةٌ</span>, <span class="auth">(Mṣb,)</span> <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, such as is termed</em> <span class="ar">بَرْزٌ</span> q. v.: <span class="auth">(Mṣb, Ḳ:)</span> and in like manner, <span class="ar">بَرُزَتْ</span>, inf. n. as above, <em>she</em> <span class="auth">(a woman)</span> <em>was,</em> or <em>became, such as is termed</em> <span class="ar">بَرْزَةٌ</span> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brz_2">
				<h3 class="entry">2. ⇒ <span class="ar">برّز</span></h3>
				<div class="sense" id="brz_2_A1">
					<p><span class="ar">برّزهُ</span>, <span class="auth">(inf. n. <span class="ar">تَبْرِيزٌ</span>, Ṣ, Ḳ,)</span> <em>He made it apparent, manifest, plain,</em> or <em>evident; he showed,</em> or <em>manifested, it;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> namely, a writing, or book, <span class="auth">(A,)</span> or other thing; <span class="auth">(Ṣ, A;)</span> as also<span class="arrow"><span class="ar">ابرزهُ↓</span></span>: <span class="auth">(A, Mṣb:)</span> or<span class="arrow"><span class="ar long">ابرز↓ الكِتَابَ</span></span> signifies <em>he put forth,</em> or <em>produced, the writing,</em> or <em>book;</em> syn. <span class="ar">أَخْرَجَهُ</span>: <span class="auth">(TA:)</span> and <span class="add">[as it often signifies in the present day,]</span> <em>published, it;</em> syn. <span class="ar">نَشَرَهُ</span>. <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="#brz_4">See also 4 below</a>.]</span> It is said in the Ḳur <span class="add">[xxvi. 91 and lxxix. 36]</span>, <span class="ar long">وَبُرِّزَتِ الجَحِيمُ</span>, meaning <em>And Hell shall be uncovered.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brz_2_A2">
					<p><span class="ar long">برّز رَاكِبَهُ</span> <em>He</em> <span class="auth">(a horse)</span> <em>saved his rider.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brz_2_B1">
					<p><a href="#brz_1">See also 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="brz_2_B2">
					<p><span class="add">[Hence,]</span> <span class="ar long">برّز الفَرَسُ</span>, <span class="auth">(Ṣ, Mṣb,)</span> or <span class="ar long">برّز عَلَى الخَيْلِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَبْرِيزٌ</span>, <span class="auth">(Mṣb,)</span> <em>The horse outstripped</em> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>the</em> <span class="add">[<em>other</em>]</span> <em>horses</em> <span class="auth">(Mṣb, Ḳ)</span> <em>in the race-ground:</em> <span class="auth">(Mṣb:)</span> it is said of a horse that outstrips in a race: and, accord. to some, the like is said of whatever outstrips: <span class="auth">(TA:)</span> and <span class="ar long">برّز عَلَى الغَايَةِ</span> <span class="add">[<em>He</em> <span class="auth">(a horse)</span> <em>passed beyond the goal</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="brz_2_B3">
					<p>Hence, <span class="ar long">برّز فِى العِلْمِ</span>, inf. n. as above, <em>He surpassed,</em> or <em>excelled, his fellows in knowledge.</em> <span class="auth">(Mṣb.)</span> And <span class="add">[simply]</span> <span class="ar">برّز</span> <em>He surpassed his companions</em> <span class="auth">(Ṣ, Ḳ)</span> <em>in excellence,</em> or <em>in courage.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">برّز عَلَى أَقْرَانِهِ</span> <span class="add">[<em>He surpassed,</em> or <em>excelled, his fellows,</em> or <em>his opponents</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="brz_2_C1">
					<p><a href="#brz_4">See also 4</a>, last signification.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brz_3">
				<span class="pb" id="Page_0187"></span>
				<h3 class="entry">3. ⇒ <span class="ar">بارز</span></h3>
				<div class="sense" id="brz_3_A1">
					<p><span class="ar long">بارزهُ فِى الحَرْبِ</span>, <span class="auth">(A, Mṣb,* Ḳ*)</span> inf. n. <span class="ar">مُبَارَزَةٌ</span> and <span class="ar">بِرَازٌ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> <em>He went,</em> or <em>came, out,</em> or <em>forth, in the field, to</em> <span class="add">[<em>encounter</em>]</span> <em>him</em> <span class="auth">(i. e. his adversary)</span> <em>in battle, or war.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brz_3_B1">
					<p><a href="#brz_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brz_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابرز</span></h3>
				<div class="sense" id="brz_4_A1">
					<p><span class="ar">ابرزهُ</span> <em>He made,</em> or <em>caused, him</em> <span class="auth">(a man)</span> <em>to go,</em> or <em>come,</em> or <em>pass, out,</em> or <em>forth:</em> <span class="auth">(Ṣ:)</span> <span class="add">[or <em>to go,</em> or <em>come,</em> or <em>pass, out,</em> or <em>forth, into the field, plain,</em> or <em>open tract or country:</em> (<a href="#brz_1">see 1</a>:)]</span> and <em>he made,</em> or <em>caused, it</em> <span class="auth">(a thing)</span> <em>to go,</em> or <em>come,</em> or <em>pass, out,</em> or <em>forth;</em> or <em>he put it,</em> or <em>took it,</em> or <em>drew it, out,</em> or <em>forth;</em> syn. <span class="ar">أَخْرَجَهُ</span>; as also<span class="arrow"><span class="ar">استبرزهُ↓</span></span>. <span class="auth">(Ḳ.)</span> <a href="#brz_2">See also 2</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="brz_4_B1">
					<p><span class="ar">ابرز</span> <em>He determined, resolved,</em> or <em>decided, upon journeying:</em> <span class="auth">(IAạr, Ḳ:)</span> the vulgar say <span class="arrow"><span class="ar">برّز↓</span></span> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brz_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبرّز</span></h3>
				<div class="sense" id="brz_5_A1">
					<p><a href="#brz_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="brz_6">
				<h3 class="entry">6. ⇒ <span class="ar">تبارز</span></h3>
				<div class="sense" id="brz_6_A1">
					<p><span class="ar long">هُمَا يَتَبَارَزَانِ</span> <em>They two</em> <span class="auth">(meaning two adversaries)</span> <em>go,</em> or <em>come, out,</em> or <em>forth, into the field, each to</em> <span class="add">[<em>encounter</em>]</span> <em>the other,</em> in battle or war. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="brz_6_A2">
					<p><span class="ar">تبارزا</span> <em>They both separated themselves, each from his company, and betook themselves each to the other.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="brz_10">
				<h3 class="entry">10. ⇒ <span class="ar">استبرز</span></h3>
				<div class="sense" id="brz_10_A1">
					<p><a href="#brz_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="barozN">
				<h3 class="entry"><span class="ar">بَرْزٌ</span> /<span class="ar">بَرْزَةٌ</span></h3>
				<div class="sense" id="barozN_A1">
					<p><span class="ar">بَرْزٌ</span> A man <em>characterized by pleasing or goodly aspect, and by intelligence:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرْزَةٌ</span>}</span></add>: <span class="auth">(Ṣ, TA:)</span> or a man <em>of open condition or state:</em> <span class="auth">(TA:)</span> or <em>pure in disposition;</em> <span class="auth">(TA;)</span> <em>abstaining from what is unlawful and indecorous;</em> <span class="auth">(Ṣ, A, Mṣb:)</span> <em>of great dignity</em> or <em>estimation:</em> <span class="auth">(Mṣb:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَرْزَةٌ</span>}</span></add>: <span class="auth">(A, Mṣb:)</span> pl. fem. <span class="ar">بَرْزَاتٌ</span>: <span class="auth">(A:)</span> or, as also<span class="arrow"><span class="ar">بَرْزِىٌّ↓</span></span> a man <em>who abstains from what is unlawful and indecorous, and in whose intelligence,</em> <span class="auth">(Ḳ,)</span> or, as in some copies of the Ḳ, <em>in whose excellence,</em> <span class="ar">بِفَضْلِهِ</span>, but this is app. a mistranscription, or, as some say, <em>in whose abstinence from what is unlawful and indecorous,</em> <span class="auth">(TA,)</span> <em>and his judgment, confidence is placed:</em> <span class="auth">(Ḳ:)</span> and <span class="ar">بَرْزَةٌ</span> a woman <em>whose good qualities or actions,</em> or <em>whose beauties, are apparent: </em> <span class="auth">(Ḳ:)</span> or <em>open in her converse;</em> syn. <span class="ar">مُتَاجِرَةٌ</span>: or, as in some correct lexicons, <em>disdainful of mean things;</em> syn. <span class="ar">مُتَجَالَّةٌ</span>: or <em>of middle age,</em> (<span class="ar">كَهْلَةٌ</span>,) <em>who is not veiled or concealed like young women:</em> <span class="auth">(TA:)</span> or <em>of great dignity or estimation:</em> <span class="auth">(AO, TA:)</span> or <em>who goes or comes forth to people, and with whom they sit, and of whom they talk, and who abstains from what is unlawful and indecorous, and is intelligent:</em> <span class="auth">(TA:)</span> or <em>who abstains from what is unlawful and indecorous, and goes or comes forth to men, and talks with them, and is advanced in age beyond those women who are kept concealed:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>open in her converse,</em> (<span class="ar">مُتَجَاهِرَةٌ</span>,) <em>of middle age,</em> (<span class="ar">كَهْلَةٌ</span>,) <em>of great dignity or estimation, who goes or comes forth to people, and with whom they sit and talk, and who abstains from what is unlawful and indecorous:</em> <span class="auth">(Ḳ:)</span> or <em>in whose judgment, and her abstaining from what is unlawful and indecorous, confidence is placed:</em> <span class="auth">(TA:)</span> or <em>who does not veil her face from a man and bend her head down towards the ground.</em> <span class="auth">(IAạr, on the authority of Ibn-Ez-Zubeyr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="barozieBN">
				<h3 class="entry"><span class="ar">بَرْزِىٌّ</span></h3>
				<div class="sense" id="barozieBN_A1">
					<p><span class="ar">بَرْزِىٌّ</span>: <a href="#barozN">see <span class="ar">بَرْزٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="baraAzN">
				<h3 class="entry"><span class="ar">بَرَازٌ</span></h3>
				<div class="sense" id="baraAzN_A1">
					<p><span class="ar">بَرَازٌ</span> <em>A field, plain,</em> or <em>wide expanse of land,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>without trees;</em> <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">بِرَازٌ↓</span></span>; but this latter form is rare: <span class="auth">(Mṣb:)</span> or <em>an open tract of land destitute of herbage and trees and without hills or mountains:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>a place in which is no covert of trees or other things:</em> <span class="auth">(Fr, Ṣ:)</span> <em>an open place in which is no covert of trees or other things:</em> <span class="auth">(Fr, Ṣ:)</span> <em>an open place in which is no covert.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: <span class="ar">بَرَازٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baraAzN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">خَرَجَ إِلَى البَرَازِ</span> ‡ <em>He went forth to satisfy a want of nature.</em> <span class="auth">(A.)</span> And <span class="ar long">إِذَا أَرَادَ البَرَازَ أَبْعَدَ</span> ‡ <span class="add">[<em>When he desired to satisfy a want of nature, he went far off</em>]</span>: a trad.; respecting which El-Khaṭṭábee says that the relaters of traditions err respecting the word, pronouncing it with kesr, for<span class="arrow"><span class="ar">بِرَازٌ↓</span></span> is an inf. n.: but <span class="auth">(SM says that)</span> authorities differ as to this point. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: <span class="ar">بَرَازٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baraAzN_A3">
					<p><span class="add">[It is further said,]</span> <span class="ar">بَرَازٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> or<span class="arrow"><span class="ar">بِرَازٌ↓</span></span> <span class="auth">(Ṣ, Ḳ,)</span> is metonymically applied to ‡ <em>Excrement; human ordure;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> the <em>feces of food.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="biraAzN">
				<h3 class="entry"><span class="ar">بِرَازٌ</span></h3>
				<div class="sense" id="biraAzN_A1">
					<p><span class="ar">بِرَازٌ</span>: <a href="#baraAzN">see <span class="ar">بَرَازٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baArizN">
				<h3 class="entry"><span class="ar">بَارِزٌ</span></h3>
				<div class="sense" id="baArizN_A1">
					<p><span class="ar">بَارِزٌ</span> act. part. n. of <span class="ar">بَرَزَ</span> <span class="add">[q. v.]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: <span class="ar">بَارِزٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baArizN_A2">
					<p><em>Wholly,</em> or <em>entirely, apparent</em> or <em>manifest.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">برز</span> - Entry: <span class="ar">بَارِزٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baArizN_A3">
					<p><span class="ar long">أَرْضٌ بَارِزَةٌ</span> <em>Land that is apparent, open,</em> or <em>uncovered,</em> <span class="auth">(Bḍ and Jel in xviii. 45, and TA,)</span> <em>upon which is no mountain nor any other thing,</em> <span class="auth">(Jel,)</span> or <em>that has no hill nor mountain nor sand.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiborizieBN">
				<h3 class="entry"><span class="ar">إِبْرِزِىٌّ</span></h3>
				<div class="sense" id="IiborizieBN_A1">
					<p><span class="ar">إِبْرِزِىٌّ</span>: <a href="#IiboriyzN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboriyzN">
				<h3 class="entry"><span class="ar">إِبْرِيزٌ</span></h3>
				<div class="sense" id="IiboriyzN_A1">
					<p><span class="ar">إِبْرِيزٌ</span> <span class="auth">(Sh, IAạr, A, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">إِبْرِزِىٌّ↓</span></span>, <span class="auth">(Sh, IAạr, Ḳ,)</span> the latter of which is incorrectly written in <span class="add">[some of]</span> the copies of the Ḳ <span class="ar">إِبْرِيزِىٌّ</span>, <span class="auth">(TA,)</span> <em>Pure</em> gold: <span class="auth">(Sh, Mṣb, Ḳ:)</span> or <em>an ornament of pure gold:</em> <span class="auth">(IAạr:)</span> the former an arabicized word <span class="add">[app. from the Greek <span class="gr">ὄβρυζον</span>, as also the latter]</span>: <span class="auth">(Mṣb:)</span> of the measure <span class="ar">إِفْعِيلٌ</span>; the <span class="ar">ء</span> and <span class="ar">ى</span> being augmentative. <span class="auth">(IJ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maborazN">
				<h3 class="entry"><span class="ar">مَبْرَزٌ</span></h3>
				<div class="sense" id="maborazN_A1">
					<p><span class="ar">مَبْرَزٌ</span> <span class="add">[lit. <em>A place to which one goes forth in the field,</em> or <em>plain,</em> or <em>open tract or country;</em>]</span> <em>a privy,</em> or <em>place where one performs ablution;</em> syn. <span class="ar">مُتَوَضَّأْ</span>; <span class="auth">(Ṣ;)</span> <span class="add">[as also<span class="arrow"><span class="ar">مُتَبَرَّزٌ↓</span></span>, occurring in the TA in art. <span class="ar">جوز</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muborazN">
				<h3 class="entry"><span class="ar">مُبْرَزٌ</span></h3>
				<div class="sense" id="muborazN_A1">
					<p><span class="ar long">كِتَابٌ مُبْرَزٌ</span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">مَبْرُوزٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>A writing,</em> or <em>book, put forth,</em> or <em>published;</em> syn. <span class="ar">مَنْشُورٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>made apparent, shown,</em> or <em>manifested:</em> <span class="auth">(Mṣb:)</span> <span class="arrow">↓</span> the latter anomalous; <span class="auth">(Ṣ, Mṣb;)</span> being from <span class="ar">أَبْرَزَ</span>; <span class="auth">(Mṣb;)</span> and AḤát disapproved it; and thought that it might be a mistake for <span class="ar">مَزْبُورٌ</span>, meaning “written;” but it <span class="add">[is said that it]</span> occurs in two poems of Lebeed: <span class="auth">(Ṣ:)</span> in one of these instances, however, for <span class="ar">المَبْرُوزُ</span>, some read <span class="ar">المُبْرَزُ</span>; and Ṣgh says that he found not the other instance in the poems of Lebeed: IJ says that <span class="arrow"><span class="ar">المَبْرُوزٌ↓</span></span> is for <span class="ar long">المَبْرُوزٌ بِهِ</span>. <span class="auth">(TA.)</span> You say,<span class="arrow"><span class="ar long">قَدْ أَعْطَوْهُ كِتَابًا مَبْرُوزًا↓</span></span> <em>They had given him a writing,</em> or <em>book, published;</em> i. e., <span class="ar">مَنْشُورًا</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboruwzN">
				<h3 class="entry"><span class="ar">مَبْرُوزٌ</span></h3>
				<div class="sense" id="maboruwzN_A1">
					<p><span class="ar">مَبْرُوزٌ</span>: <a href="#muborazN">see <span class="ar">مُبْرَزٌ</span></a>, throughout.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutabarBazN">
				<h3 class="entry"><span class="ar">مُتَبَرَّزٌ</span></h3>
				<div class="sense" id="mutabarBazN_A1">
					<p><span class="ar">مُتَبَرَّزٌ</span>: <a href="#maborazN">see <span class="ar">مَبْرَزٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0186.pdf" target="pdf">
							<span>Lanes Lexicon Page 186</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0187.pdf" target="pdf">
							<span>Lanes Lexicon Page 187</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
