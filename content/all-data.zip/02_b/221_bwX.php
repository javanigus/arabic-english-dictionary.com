<article class="root" id="Root_bwX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/220_bws">بوس</a></span>
				<span class="ar">بوش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/222_bwE">بوع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bwX_1">
				<h3 class="entry">1. ⇒ <span class="ar">بوش</span> ⇒ <span class="ar">باش</span></h3>
				<div class="sense" id="bwX_1_A1">
					<p><span class="ar">بَاشَ</span>, aor. <span class="ar">يَبُوشُ</span>, inf. n. <span class="ar">بَوْشٌ</span>, <em>He mixed,</em> or <em>confounded.</em> <span class="auth">(Fr.)</span> <a href="#XaAba">See also <span class="ar">شَابَ</span></a>, <a href="index.php?data=13_X/174_Xwb">in art. <span class="ar">شوب</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bwX_1_A2">
					<p><em>He associated with</em> <span class="ar">بَوْش</span>, meaning, <em>people of the lowest</em> or <em>basest</em> or <em>meanest sort.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بوش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bwX_1_A3">
					<p><span class="ar">بَاشُوا</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(A, Ḳ,)</span> <em>They</em> <span class="auth">(mixed people, A, Ḳ, of the lowest or basest or meanest sort, TA)</span> <em>cried out,</em> or <em>vociferated;</em> or <em>did so calling for aid</em> or <em>succour;</em> or <em>in distress and impatience;</em> or <em>in fear.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bwX_2">
				<h3 class="entry">2. ⇒ <span class="ar">بوّش</span></h3>
				<div class="sense" id="bwX_2_A1">
					<p><span class="ar">بوّشوا</span>, inf. n. <span class="ar">تَبْوِيشٌ</span>, <em>They became mixed,</em> or <em>confused:</em> <span class="auth">(Ḳ:)</span> or <em>numerous, and mixed</em> or <em>confused:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">تبوّشوا↓</span></span> signifies the same. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bwX_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبوّش</span></h3>
				<div class="sense" id="bwX_5_A1">
					<p><a href="#bwX_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawoXN">
				<h3 class="entry"><span class="ar">بَوْشٌ</span></h3>
				<div class="sense" id="bawoXN_A1">
					<p><span class="ar">بَوْشٌ</span> <em>A mixed</em> or <em>confused assembly</em> or <em>company:</em> <span class="auth">(A, Ḳ:)</span> or <em>an assembly,</em> or <em>a company, of mixed</em> or <em>confused people:</em> <span class="auth">(Ṣ:)</span> or only <em>of different tribes:</em> or <em>a multitude of men:</em> as also<span class="arrow"><span class="ar">بُوشٌ↓</span></span>, in these several senses: <span class="auth">(Ḳ:)</span> and, accord. to the women of Temeem, <em>of beasts</em> also: <span class="auth">(Aboo-ʼAdnán, TA in art. <span class="ar">هوش</span>:)</span> or <em>people of the lowest</em> or <em>basest</em> or <em>meanest sort:</em> <span class="auth">(IAạr:)</span> or <em>a family,</em> or <em>household:</em> <span class="auth">(ISd:)</span> and <span class="add">[it is said by F that]</span> it also signifies <em>sons of the same father, when assembled together:</em> <span class="auth">(Ḳ:)</span> resembling a contr. signification to that mentioned above, which restricts the application to such as are of different tribes: but it is said in the O, that <span class="ar long">بَنُو الاباء</span>, <span class="add">[app. a mistake for <span class="ar long">بَنُو الأَبِ</span>, meaning sons of the same father,]</span> when assembled together, are not called by this name: <span class="auth">(TA:)</span> <span class="ar">أَوْبَاشٌ</span> is a pl. of this word, formed by transposition. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">جَاؤُوا فِى هَوْشٍ وَبَوْشٍ</span> <em>They came in assemblage and multitude.</em> <span class="auth">(A.)</span> And <span class="ar long">جَآءَ مِنَ النَّاسِ الهَوْشُ وَالبَوْشُ</span> <em>The multitude of the people came:</em> <span class="auth">(AZ:)</span> or <em>the assembly and family</em> or <em>household.</em> <span class="auth">(ISd.)</span> And <span class="ar long">تَرَكْتُهُمْ هَوْشًا بَوْشًا</span> <em>I left them</em> <span class="add">[<em>in great numbers</em> and]</span> <em>in confusion.</em> <span class="auth">(Ḳ.)</span> And<span class="arrow"><span class="ar long">بَوْشٌ بَائِشٌ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> or<span class="arrow"><span class="ar long">بُوشٌ↓ بَائِشٌ↓</span></span>, <span class="auth">(CK,)</span> <span class="add">[app. <em>A numerous,</em> or <em>large, assembly of mixed</em> or <em>confused people.</em>]</span> And<span class="arrow"><span class="ar long">جَآءَ بِالبَوْشِ البَائِشِ↓</span></span> <em>He came with multitude,</em> or <em>the multitude.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwXN">
				<h3 class="entry"><span class="ar">بُوشٌ</span></h3>
				<div class="sense" id="buwXN_A1">
					<p><span class="ar">بُوشٌ</span>: <a href="#baWoXN">see <span class="ar">بَوْشٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bawoXieBN">
				<h3 class="entry"><span class="ar">بَوْشِىٌّ</span></h3>
				<div class="sense" id="bawoXieBN_A1">
					<p><span class="ar">بَوْشِىٌّ</span> A <em>poor</em> man <em>having a numerous family</em> or <em>household:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>having a family</em> or <em>household:</em> <span class="auth">(Aboo-Saʼeed:)</span> and one <em>of the baser and common sort of men:</em> as also<span class="arrow"><span class="ar">بُوشِىٌّ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="buwXieBN">
				<h3 class="entry"><span class="ar">بُوشِىٌّ</span></h3>
				<div class="sense" id="buwXieBN_A1">
					<p><span class="ar">بُوشِىٌّ</span>: <a href="#baWoXieBN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baAYiXN">
				<h3 class="entry"><span class="ar">بَائِشٌ</span></h3>
				<div class="sense" id="baAYiXN_A1">
					<p><span class="ar">بَائِشٌ</span>: <a href="#baWoXN">see <span class="ar">بَوْشٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0275.pdf" target="pdf">
							<span>Lanes Lexicon Page 275</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
