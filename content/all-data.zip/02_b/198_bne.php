<article class="root" id="Root_bne">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/197_bnw">بنو</a></span>
				<span class="ar">بنى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/199_bhO">بهأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bne_1">
				<h3 class="entry">1. ⇒ <span class="ar">بنى</span></h3>
				<div class="sense" id="bne_1_A1">
					<p><span class="ar">بَنَاهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْنِىُ</span>}</span></add>, <span class="auth">(M, Mṣb,)</span> and <span class="ar">ـُ</span>, but the former is the more common, <span class="auth">(M,)</span> <span class="add">[or rather the only form commonly known,]</span> inf. n. <span class="ar">بِنَآءٌ</span> <span class="auth">(T, Ṣ, M, Mgh, Ḳ)</span> and <span class="ar">بِنًا</span> <span class="auth">(T, and TA as from the M <span class="add">[but it is not in the transcript of the M in the TT]</span>)</span> and <span class="ar">بَنْىٌ</span> and <span class="ar">بُنْيَانٌ</span> and <span class="ar">بِنْيَةٌ</span> and <span class="ar">بنَايَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>He built it; framed it; constructed it; contr. of</em> <span class="ar">هَدَمَهُ</span>; <span class="auth">(M, Ḳ;)</span> namely, a house, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> or tent, <span class="auth">(Ṣ,* Mṣb,)</span>, &amp;c.; <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">ابتناه↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">بنّاهُ↓</span></span>; <span class="auth">(M, Ḳ;)</span> or the last has teshdeed given to it to denote muchness, or frequency, or repetition, of the action, or its application to many objects; and hence you say, <span class="ar long">بنّى قُصُورًا</span> <span class="add">[<em>He built palaces,</em> or <em>pavilions:</em> or <em>he raised them high:</em> see the pass. part. n. below]</span>. <span class="auth">(Ṣ, TA.)</span> AḤn speaks of a kind of plank as being used <span class="ar long">فِى بِنَآءِ السُّفُنِ</span> <span class="add">[<em>in the construction of ships</em>]</span>: but <span class="ar">بِنَآءٌ</span> is originally used only in relation to that which does not grow; as stone, and clay, and the like. <span class="auth">(M.)</span> You say also, <span class="ar long">بَنَى أَرْضًا</span>, for <span class="ar long">بَنَى فِى أَرْضٍ</span> <span class="add">[<em>He built in,</em> or <em>upon, land</em>]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bne_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">بَنَى عَلَى أَهْلِهِ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> or <span class="ar long">عَلَى ٱمْرَأَتِهِ</span>, <span class="auth">(Mgh,)</span> and <span class="ar long">بَنَى بِهَا</span> also, <span class="auth">(M, Mgh, Mṣb, Ḳ,)</span> accord. to IDrd <span class="auth">(Mgh, Mṣb)</span> and IJ, <span class="auth">(M,)</span> and occurring in traditions and elsewhere, though said in the Ṣ to be vulgar, <span class="auth">(IAth, MF,)</span> and said to be so by ISk, <span class="auth">(T, Mṣb,)</span> and by some said to be not allowable, <span class="auth">(M,)</span> but the former is the more chaste, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">بِنَآءٌ</span>; <span class="auth">(Ṣ, TA;)</span> as also<span class="arrow"><span class="ar">ابتنى↓</span></span>, <span class="auth">(Ḳ,)</span> i. e. <span class="ar long">ابتنى عليها</span>, <span class="auth">(ISk, Mṣb,)</span> or <span class="ar long">ابتنى بِهَا</span>, <span class="auth">(IJ, M,)</span> <em>He had his wife conducted to him on the occasion of the marriage:</em> <span class="auth">(ISk, T, Ṣ, Mṣb, Ḳ:)</span> or <em>he went in to his wife</em> <span class="add">[<em>for the first time</em>]</span>: <span class="auth">(Mgh, Mṣb:)</span> originating from the fact that the bridegroom used, on that occasion, to pitch a tent for her, <span class="auth">(ISk, T, Ṣ, Mgh, Mṣb,)</span> a new tent, <span class="auth">(Mgh, Mṣb,)</span> and furnish it with what was requisite, <span class="auth">(Mṣb,)</span> or a new tent was set up for him, <span class="auth">(Mgh, Mṣb,)</span> in honour of him. <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#baYotN">See also <span class="ar">بَيْتٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bne_1_A3">
					<p><span class="ar">بِنَايَةٌ</span> is sometimes used in relation to nobility: <span class="auth">(M, Ḳ:)</span> and the verb thus used is <span class="ar">بَنَى</span>, as above, <span class="auth">(T, M,)</span> having <span class="add">[also]</span> <span class="ar">بِنًى</span> for its inf. n., <span class="auth">(IAạr, T,)</span> and <span class="ar">بِنَآءٌ</span>; held by many to be tropical, but by some to be proper. <span class="auth">(MF.)</span> Lebeed says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَبَنَى لَنَا رَفِيعًا سَمْكُهُ</span> *</div> 
						<div class="star">* <span class="ar long">فَسَمَا إِلَيْهِ كَهْلُهَا وَغُلَامُهَا</span> *</div> 
					</blockquote>
					<p><span class="auth">(M)</span> <em>And He</em> <span class="auth">(namely, God,)</span> <em>hath built for us a house of nobility of lofty pitch, and its</em> <span class="auth">(the tribe's)</span> <em>middle-aged and its youth have risen to it:</em> i. e., all of them have attained to high degrees. <span class="auth">(EM, p. 180.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="bne_1_A4">
					<p><span class="ar long">بَنَى بَدَنَهُ</span> <em>It</em> <span class="auth">(food)</span> <em>fattened his body,</em> <span class="auth">(Ḳ,)</span> <em>and made it large:</em> <span class="auth">(TA:)</span> and <span class="ar long">بَنَى لَحْمَهُ</span>, <span class="auth">(T, M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَبْنِىُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">بِنَآءٌ</span>, <span class="auth">(M,)</span> or <span class="ar">بَنْىٌ</span>, <span class="auth">(TA,)</span> <em>It</em> <span class="auth">(food)</span> <em>made his flesh to grow,</em> <span class="auth">(T, M, Ḳ,)</span> <em>and to become large.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="bne_1_A5">
					<p><span class="ar long">بَنَى الرَّجُلَ</span> <em>He reared, brought up,</em> or <em>educated, the man;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">ابتناهُ↓</span></span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="bne_1_A6">
					<p><span class="add">[<span class="ar long">بَنَى كَلِمَةً</span>, inf. n. <span class="ar">بِنَآءٌ</span>, <em>He formed a word.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="bne_1_A7">
					<p><span class="add">[And <em>He made a word indeclinable, so as to end invariably with a quiescent letter</em> or <em>with a particular vowel.</em>]</span> <span class="ar long">بِنَآءُ كَلِمَةٍ</span> <span class="add">[when the former word is considered as the inf. n. of the pass. form <span class="ar">بُنِىَ</span>, generally]</span> signifies <em>A word's keeping always the same mode of termination, ending with a quiescent letter</em> or <em>with a particular vowel, not by reason of any governing word:</em> <span class="auth">(M, Ḳ:)</span> as though the word resembled a fixed, immoveable building. <span class="auth">(M.)</span> <span class="add">[You say, <span class="ar long">بُنِيَتْ عَلَى السُّكُونِ</span> <em>It was made indeclinable, with a quiescent letter for its termination;</em> and <span class="ar long">عَلَى الفَتْحِ</span> <em>with fet-ḥ for its termination;</em>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="bne_1_A8">
					<p><span class="add">[And in like manner you say, <span class="ar long">بَنَى القَصِيدَةَ عَلَى البَآءِ</span>, &amp;c., <em>He made the</em> <span class="ar">قصيدة</span> <em>to have</em> <span class="ar">ب</span>, &amp;c., <em>for its rhyme-letter,</em> or <em>its chief rhyme-letter.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bne_1_B1">
					<p><span class="ar long">بَنَتِ القَوْسُ عَلَى وَتَرِهَا</span> <em>The bow clave to its string</em> <span class="auth">(T, Ṣ, Ḳ)</span> <em>so that it</em> <span class="auth">(the latter)</span> <em>almost broke.</em> <span class="auth">(T, Ṣ.)</span> <span class="add">[See the part. n. below.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bne_2">
				<h3 class="entry">2. ⇒ <span class="ar">بنّى</span></h3>
				<div class="sense" id="bne_2_A1">
					<p><a href="#bne_1">see 1</a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bne_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابنى</span></h3>
				<div class="sense" id="bne_4_A1">
					<p><span class="ar">ابناهُ</span> <em>He made him to build, frame,</em> or <em>construct, a house,</em> or <em>tent:</em> <span class="auth">(Ṣ:)</span> or <em>he gave him a building:</em> or <em>he gave him that wherewith to build a house:</em> <span class="auth">(M, Ḳ:)</span> and <span class="ar long">ابناهُ بَيْتًا</span> <em>he gave him a house,</em> or <em>tent, to build</em> or <em>frame</em> or <em>construct.</em> <span class="auth">(T.)</span> It is said in a prov., <span class="ar long">المِعْزَى تُبْهِى وَلَا تُبْنِى</span> <span class="add">[<em>Goats rend,</em> or <em>make holes, and render vacant, and do not afford materials for fabricating tents</em>]</span>; i. e., they do not yield hair of which a tent is fabricated; <span class="auth">(T, Ṣ;*)</span> for the tents of the Arabs <span class="add">[of the desert]</span> are of the kind called <span class="ar">طِرَاف</span>, made of skin, and <span class="ar">أَخْبِيَة</span>, made of wool or of camels' fur, and not of <span class="ar">شَعَر</span> <span class="add">[by which is especially meant goats' hair]</span>, <span class="auth">(Ṣ,)</span> or, as is found in the handwriting of Aboo-Sahl, of wool or of skin: <span class="auth">(TA:)</span> or the meaning is, <em>goats rend</em> tents, or <em>pierce</em> them <em>with holes,</em> by their leaping upon them, <span class="auth">(T and Ṣ in art. <span class="ar">بهو</span>,)</span> so that they cannot be inhabited, <span class="auth">(Ṣ in that art.,)</span> <em>and do not aid in the fabrication of tents;</em> <span class="pb" id="Page_0261"></span>for the goats of the Arabs of the desert have short hair, not long enough to be spun; whereas the goats of the cold countries, and of the people of the fertile regions, have abundant hair, and of this the Akrád <span class="add">[or Kurdees]</span> fabricate their tents. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bne_4_A2">
					<p><span class="add">[Hence,]</span> <em>He introduced him to his wife</em> <span class="add">[<em>on the occasion of his marriage</em>]</span>: whence the saying of ʼAlee, <span class="ar long">مَتَى تُبْنيِنِى</span>, accord. to IAth properly meaning <span class="ar long">مَتَى تَجْعَلُنِى أَبْنِى بِزَوْجَتِى</span> <span class="add">[<em>When wilt thou make me to have my wife conducted to me?</em> or, <em>to go in to my wife?</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bne_5">
				<h3 class="entry">5. ⇒ <span class="ar">تبنّى</span></h3>
				<div class="sense" id="bne_5_A1">
					<p><span class="ar">تَبَنَّتْ</span>, said of a woman sitting, <span class="auth">(T, TA,)</span> <em>She became like a tent</em> <span class="auth">(T, IAth, Ḳ,* TA)</span> <em>of the kind called</em> <span class="ar">مِبْنَاةٌ</span>, <span class="auth">(T, TA,)</span> i. e., <em>a</em> <span class="ar">قُبَّة</span> <em>of skin; by reason of her fatness,</em> <span class="auth">(T, IAth, TA,)</span> <em>and largeness,</em> <span class="auth">(T, TA,)</span> or <em>fleshiness:</em> <span class="auth">(IAth, TA:)</span> or <em>she parted her legs;</em> as though from <span class="ar">مِبْنَاة</span>, i. e. a <span class="ar">قُبَّة</span> of skin, which, when pitched, is spread out by the ropes: so this woman, sitting cross-legged, spread apart her legs. <span class="auth">(T, TA.)</span> And <span class="ar">تبنّى</span>, said of a camel's hump, <em>It became fat.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bne_5_B1">
					<p><span class="ar">تبنّاهُ</span> <em>He adopted him as a son:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>he asserted him to be,</em> or <em>claimed him as, a son:</em> <span class="auth">(M:)</span> and <span class="ar long">تبنّى بِهِ</span> signifies the same. <span class="auth">(Zj, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bne_8">
				<h3 class="entry">8. ⇒ <span class="ar">ابتنى</span></h3>
				<div class="sense" id="bne_8_A1">
					<p><span class="ar">ابتنى</span>: <a href="#bne_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bne_8_B1">
					<p>Also <em>It became built, framed,</em> or <em>constructed.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binotN">
				<h3 class="entry"><span class="ar">بِنْتٌ</span> / <span class="ar">بَنَاتٌ</span></h3>
				<div class="sense" id="binotN_A1">
					<p><span class="ar">بِنْتٌ</span>; pl. <span class="ar">بَنَاتٌ</span>: <a href="#IibonN">fem. of <span class="ar">اِبْنٌ</span></a>, <a href="#IibonN">which see</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bunFe">
				<h3 class="entry"><span class="ar">بُنًى</span></h3>
				<div class="sense" id="bunFe_A1">
					<p><span class="ar">بُنًى</span>: <a href="#binaACN">see <span class="ar">بِنَآءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binFe">
				<h3 class="entry"><span class="ar">بِنًى</span></h3>
				<div class="sense" id="binFe_A1">
					<p><span class="ar">بِنًى</span>: <a href="#binaACN">see <span class="ar">بِنَآءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banaApu">
				<h3 class="entry"><span class="ar">بَنَاةُ</span></h3>
				<div class="sense" id="banaApu_A1">
					<p><span class="ar long">بَنَاةُ اللَّحْمِ</span>, <span class="auth">(IB, TA,)</span> the former of which words is incorrectly written in the Ḳ <span class="ar">بنات</span>, <span class="auth">(TA,)</span> A girl <em>whose flesh has been made to grow and become large:</em> <span class="auth">(IB, Ḳ, TA: <span class="add">[in the CK, <span class="ar">مَبْنِيَّةٌ</span> is erroneously put for <span class="ar">مَبْنِيَّتُهُ</span>:]</span>)</span> or, accord. to a learned scholiast, this is a mistake of IB, and the meaning is <em>sweet in odour;</em> i. e. <em>sweet in the odour of the flesh.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banaAtN">
				<h3 class="entry"><span class="ar">بَنَاتٌ</span></h3>
				<div class="sense" id="banaAtN_A1">
					<p><span class="ar">بَنَاتٌ</span>: <a href="#binotN">pl. of <span class="ar">بِنْتٌ</span></a>; and sometimes of <span class="ar">اِبْنٌ</span>: <a href="#IibonN">see <span class="ar">اِبْنٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banuwna">
				<h3 class="entry"><span class="ar">بَنُونَ</span></h3>
				<div class="sense" id="banuwna_A1">
					<p><span class="ar">بَنُونَ</span>: <a href="#IibonN">pl. of <span class="ar">اِبْنٌ</span></a>, which see below.</p>
				</div>
			</section>
			<hr>
			<section class="entry refg" id="bunoyapN">
				<h3 class="entry"><span class="ar">بُنْيَةٌ</span></h3>
				<div class="sense" id="bunoyapN_A1">
					<p><span class="ar">بُنْيَةٌ</span>: <a href="#binaACN">see <span class="ar">بِنَآءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="binoyapN">
				<h3 class="entry"><span class="ar">بِنْيَةٌ</span></h3>
				<div class="sense" id="binoyapN_A1">
					<p><span class="ar">بِنْيَةٌ</span> <em>A form, mode,</em> or <em>manner, of building</em> or <em>framing</em> or <em>construction;</em> a word like <span class="ar">مِشْيَةٌ</span> and <span class="ar">رِكْبَةٌ</span>. <span class="auth">(T, TA.)</span> <span class="add">[The <em>form,</em> or <em>mode of formation,</em> of a word.]</span> <em>Natural constitution:</em> as in the phrase, <span class="ar long">فُلَانٌ صَحِيحُ البِنْيَةِ</span> <span class="add">[<em>Such a one is sound in natural constitution</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بِنْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="binoyapN_A2">
					<p><a href="#binaACN">See also <span class="ar">بِنَآءٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="binotieBN">
				<h3 class="entry"><span class="ar">بِنْتِىٌّ</span></h3>
				<div class="sense" id="binotieBN_A1">
					<p><span class="ar">بِنْتِىٌّ</span>: <a href="#banawieBN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banawieBN">
				<h3 class="entry"><span class="ar">بَنَوِىٌّ</span></h3>
				<div class="sense" id="banawieBN_A1">
					<p><span class="ar">بَنَوِىٌّ</span> <em>Of,</em> or <em>relating to, a son;</em> <a href="#IibonN">rel. n. of <span class="ar">اِبْنٌ</span></a>; as also<span class="arrow"><span class="ar">اِبْنِىٌّ↓</span></span> <span class="add">[with <span class="ar">ٱ</span> when connected with a preceding word]</span>: <span class="auth">(Ṣ, Mṣb:)</span> the latter is allowable, <span class="auth">(Mṣb,)</span> and used by some. <span class="auth">(Ṣ.)</span> And <em>Of,</em> or <em>relating to, a daughter;</em> <a href="#binotN">rel. n. of <span class="ar">بِنْتٌ</span></a>; as also<span class="arrow"><span class="ar">بِنْتِىٌّ↓</span></span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> the latter accord. to Yoo; <span class="auth">(Ṣ, M;)</span> but rejected by Sb. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بَنَوِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="banawieBN_A2">
					<p>Also <em>Of,</em> or <em>relating to, what are termed</em> <span class="ar long">بُنَيَّاتُ الطَّرِيقِ</span>, i. e., <em>the small roads that branch off from the main road.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bunoyaAnN">
				<h3 class="entry"><span class="ar">بُنْيَانٌ</span> / <span class="ar">بُنْيَانَةٌ</span></h3>
				<div class="sense" id="bunoyaAnN_A1">
					<p><span class="ar">بُنْيَانٌ</span> and <span class="ar">بُنْيَانَةٌ</span>: <a href="#binaACN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="binaMCN">
				<h3 class="entry"><span class="ar">بِنَآءٌ</span></h3>
				<div class="sense" id="binaMCN_A1">
					<p><span class="ar">بِنَآءٌ</span> <span class="add">[originally an inf. n.: (<a href="#bne_1">see 1</a>, first sentence:) then applied to <em>A building; a structure; an edifice;</em>]</span> <em>a thing that is built,</em> or <em>constructed;</em> pl. <span class="ar">أَبْنِيَةٌ</span>, and pl. pl. <span class="ar">أَبْنِيَاتٌ</span>: <span class="auth">(M, Ḳ:)</span> and<span class="arrow"><span class="ar">بُنْيَانٌ↓</span></span> <span class="add">[also]</span> has this meaning; <span class="auth">(Mṣb;)</span> <span class="add">[and is likewise originally an inf. n.;]</span> or this signifies <em>a wall;</em> syn. <span class="ar">حَائِطٌ</span>; <span class="auth">(Ṣ;)</span> or it may be a pl., <span class="add">[or rather a coll. gen. n., meaning <em>buildings, structures, edifices,</em> or <em>walls,</em>]</span> of which the sing. <span class="add">[or n. un.]</span> is <span class="arrow"><span class="ar">بُنْيَانَةٌ↓</span></span>, and as such may be masc. and fem: <span class="auth">(Er-Rághib, TA:)</span> <span class="arrow"><span class="ar">بِنْيَةٌ↓</span></span> and<span class="arrow"><span class="ar">بُنْيَةٌ↓</span></span> also signify <span class="add">[the same as <span class="ar">بِنَآءٌ</span> as explained above; or]</span> <em>a thing that one has built, framed,</em> or <em>constructed;</em> <span class="auth">(M, Ḳ;)</span> or, accord. to some, the former of these two relates to objects of the senses, and the latter to objects of the mind, to glory or honour or the like; <span class="auth">(MF, TA;)</span> and their pls. are <span class="arrow"><span class="ar">بِنًى↓</span></span> and<span class="arrow"><span class="ar">بُنًى↓</span></span>; <span class="auth">(Ḳ;)</span> or, accord. to the Ṣ and M, these two appear to be sings.; <span class="auth">(TA;)</span> <span class="add">[or they may be pls. or sings.; for J says that]</span> <span class="ar">البُنَى</span> is like <span class="ar">البِنَى</span>; one says, <span class="ar">بُنْيَةٌ</span> and <span class="ar">بُنًى</span>, and <span class="ar">بِنْيَةٌ</span> and <span class="ar">بِنًى</span>; <span class="auth">(Ṣ;)</span> <span class="add">[and ISd says that]</span> <span class="ar">بِنْيَةٌ</span> and <span class="ar">بُنْيَةٌ</span> signify as above, and so <span class="ar">بِنًى</span> and <span class="ar">بُنًى</span>; or, accord. to Aboo-Is-ḥáḳ, <span class="ar">بِنًى</span> <a href="#binoyapN">is pl. of <span class="ar">بِنْيَةٌ</span></a>; or it may be used by poetic licence for <span class="ar">بِنَآءٌ</span>: <span class="auth">(M:)</span> accord. to IAạr, <span class="ar">بِنًى</span> signifies <em>buildings,</em> or <em>structures, of clay:</em> and also <span class="add">[<em>tents</em>]</span> <em>of wool;</em> <span class="auth">(T;)</span> and <span class="ar">بِنَآءٌ</span> likewise signifies <em>a tent</em> <span class="auth">(M, TA)</span> <em>in which the Arabs of the desert dwell, in the desert,</em> <span class="auth">(TA,)</span> <em>such as is called</em> <span class="ar">خِبَآء</span>; <span class="auth">(M, TA;*)</span> and <span class="ar">طِرَافٌ</span> and <span class="ar">قُبَّةٌ</span> and <span class="ar">مِضْرَبٌ</span> are names applied to dwellings of the same kind; <span class="auth">(TA;)</span> pl. <span class="ar">أَبْنِيَةٌ</span>: <span class="auth">(M:)</span> the <em>moveable dwelling, such as the</em> <span class="ar">خَيْمَة</span> <em>and</em> <span class="ar">مِظَلَّة</span> <em>and</em> <span class="ar">فُسْطَاط</span> <em>and</em> <span class="ar">سُرَادِق</span> <em>and the like,</em> is called <span class="ar">بِنَآءٌ</span> as being likened to the building of burnt bricks and of clay and of gypsum. <span class="auth">(M.)</span> <span class="add">[<a href="#baniyBapN">See also <span class="ar">بَنِيَّةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بِنَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="binaMCN_A2">
					<p>Also The <em>roof,</em> or <em>ceiling,</em> of a house or chamber or the like; as in the Ḳur <span class="add">[ii. 20]</span>, <span class="ar long">الَّذِى جَعَلَ لَكُمُ الأَرْضَ فِراشًا وَالسَّمَآءَ بِنَآءً</span> <span class="add">[<em>Who hath made for you the earth as a bed, and the heaven as a roof,</em> or <em>ceiling</em>]</span>: <span class="auth">(Ṣ, <span class="add">[but wanting in some copies,]</span> and Jel:)</span> so says AZ: <span class="auth">(Ṣ:)</span> or the meaning here is, <em>as a tent</em> (<span class="ar">قُبَّة</span>) pitched over you. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بِنَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="binaMCN_A3">
					<p>And The <em>body, with the limbs</em> or <em>members.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بِنَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="binaMCN_A4">
					<p>And <em>i. q.</em> <span class="ar">نِطْعٌ</span> <span class="add">[<em>A thing that is spread on the ground to serve as a table for food, &amp;c., made of leather;</em> like <span class="ar">مِبْنَاةٌ</span>]</span>: occurring in a trad., where it is mentioned as spread on the ground, on a day of rain, for Moḥammad to pray upon: so says Sh. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunaeBN">
				<h3 class="entry"><span class="ar">بُنَىٌّ</span></h3>
				<div class="sense" id="bunaeBN_A1">
					<p><span class="ar">بُنَىٌّ</span>, <span class="add">[said to be]</span> originally <span class="ar">بُنَيْوٌ</span>, <em>A little son;</em> <span class="add">[used as a term of endearment;]</span> <span class="auth">(Mṣb;)</span> <a href="#IibonN">dim. of <span class="ar">اِبْنٌ</span></a>. <span class="auth">(Ṣ, Mgh, Mṣb.)</span> You say, <span class="ar long">يَا بُنَىِّ</span> and <span class="ar long">يَا بُنَىَّ</span> <span class="add">[<em>O my little son,</em> or <em>O my child</em>]</span>, with kesr to the <span class="ar">ى</span> and with fet-ḥ also; like as you say, <span class="ar long">يَا أَبَتِ</span> and <span class="ar long">يَا أَبَتَ</span> <span class="add">[<a href="index.php?data=01_A/011_Abw">which see in art. <span class="ar">ابو</span></a>, <a href="#OabN">voce <span class="ar">أَبٌ</span></a>]</span>. <span class="auth">(Fr, Ṣ, Ḳ.)</span> <span class="add">[The fem. is <span class="ar">بُنَيَّةٌ</span> <em>A little daughter;</em> <a href="#binotN">dim. of <span class="ar">بِنْتٌ</span></a>. And hence,]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بُنَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bunaeBN_A2">
					<p><span class="ar long">بُنَيَّاتُ الطَّرِيقَ</span> <em>The small roads that branch off from the main road;</em> <span class="auth">(Ṣ;)</span> <em>what are termed</em> <span class="ar">التُّرَّهَاتُ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بُنَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bunaeBN_A3">
					<p>The Arabs say, <span class="ar long">الرِّفْقُ بُنَىُّ الحِلْمِ</span>, meaning <span class="ar">الرفق</span> <em>is like</em> <span class="ar">الحلم</span>. <span class="auth">(IAạr, ISd.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bunuwBapN.1">
				<h3 class="entry"><span class="ar">بُنُوَّةٌ</span></h3>
				<div class="sense" id="bunuwBapN.1_A1">
					<p><span class="ar">بُنُوَّةٌ</span> <em>Sonship:</em> <span class="auth">(Lth, Zj, Ṣ, M, Mṣb, Ḳ:)</span> <span class="add">[it may be originally <span class="ar">بُنُويَةٌ</span>, for Az says, app. on the authority of Zj,]</span> it is not a decisive proof that the last radical is <span class="ar">و</span>, since they say <span class="ar">فُتُوَّةٌ</span>, though the dual <span class="add">[of the word from which this is derived]</span> is <span class="ar">فَتَيَانِ</span>; <span class="auth">(T;)</span> <span class="add">[and ISd says that]</span> <span class="ar">بُنُوَّةٌ</span> is thus because of the ḍammeh. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlbaniyBapu">
				<h3 class="entry"><span class="ar">البَنِيَّةُ</span></h3>
				<div class="sense" id="AlbaniyBapu_A1">
					<p><span class="ar">البَنِيَّةُ</span> <span class="add">[properly <em>The building,</em> like <span class="ar">البِنَآءُ</span>, &amp;c.: but particularly applied to]</span> <em>the Kaabeh;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> because of its nobleness. <span class="auth">(M, Ḳ.)</span> One says, <span class="ar long">لَا وَرَبِّ هٰذِهِ البَنِيَّةِ مَا كَانَ كَذَا وَكَذَا</span> <span class="add">[<em>No, by the Lord of this building</em> <span class="auth">(the Kaabeh)</span>, <em>such and such thing were not</em>]</span>: <span class="auth">(Ṣ, TA:)</span> and this was a common form of oath. <span class="auth">(TA.)</span> The Kaabeh is also called <span class="ar long">بَنِيَّةُ إِبْرَاهِيمَ</span> <span class="add">[<em>The building of Abraham</em>]</span>; because he built it. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="banBaMCN">
				<h3 class="entry"><span class="ar">بَنَّآءٌ</span></h3>
				<div class="sense" id="banBaMCN_A1">
					<p><span class="ar">بَنَّآءٌ</span> <em>A builder;</em> <span class="add">[meaning <em>one whose business is that of building;</em>]</span> <em>an architect.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#baAnK">See also what next follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAnK">
				<h3 class="entry"><span class="ar">بَانٍ</span></h3>
				<div class="sense" id="baAnK_A1">
					<p><span class="ar">بَانٍ</span> <span class="add">[<em>Building, framing,</em> or <em>constructing</em>]</span>: accord. to AʼObeyd, its pl. is <span class="ar">أَبْنَآءٌ</span>; and in like manner, <span class="ar">أَجْنَآءٌ</span> <a href="#jaAnK">is pl. of <span class="ar">جَانٍ</span></a>: and hence the prov., <span class="ar long">أَبْنَاؤُهَا أَجْنَاؤُهَا</span>, <span class="auth">(M,)</span> or <span class="ar long">أَجْنَاؤُهَا أَبْنَاؤُهَا</span>, i. e. <em>The injurers thereof,</em> meaning this house (<span class="ar long">هٰذِهِ الدَّار</span>), <em>by demolishing it, are the builders thereof.</em> <span class="auth">(Ṣ in art. <span class="ar">جنى</span>.)</span> ISd says, I am of opinion that these two pls. are not used except in this prov.: and J says, in art. <span class="ar">جنى</span>, I think that the prov. is originally <span class="ar long">جُنَاتُهَا بُنَاتُهَا</span>; but IB affirms that it is not so: and he says that the prov. is applied to him who does, or makes, a thing without consideration, and commits a fault therein, which he repairs by undoing what he has done or made: it originated from the fact that the daughter of a certain king of El-Yemen, during his absence on a military expedition, built, by the advice of others, a house, which he, disliking it, commanded them to demolish. <span class="auth">(TA in art. <span class="ar">جنى</span>. <span class="add">[See also Freytag's Arab. Prov. i. 294.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بَانٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAnK_A2">
					<p><em>A bridegroom:</em> from <span class="ar long">بَنَى عَلَى أَهْلِهِ</span> <span class="add">[q. v.]</span>. <span class="auth">(TA.)</span> And hence, <em>Any one going in to his wife.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بَانٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAnK_A3">
					<p><span class="ar long">قَوْسٌ بَانِيةٌ</span> <em>A bow cleaving to its string</em> <span class="auth">(T, Ṣ, M, Ḳ)</span> <em>so that it</em> <span class="auth">(the latter)</span> <em>almost breaks;</em> <span class="auth">(T, Ṣ, M;)</span> the doing of which is a fault; <span class="auth">(M;)</span> <em>contr. of</em> <span class="ar">بَائِنَةٌ</span> <span class="add">[q. v.]</span>: <span class="auth">(Ṣ and M in art. <span class="ar">بين</span>:)</span> and so<span class="arrow"><span class="ar">بَانَاةٌ↓</span></span> <span class="auth">(T, M, Ḳ)</span> in the dial. of Teiyi: <span class="auth">(T, M:)</span> or the latter signifies <em>widely separate from its string</em> <span class="add">[like <span class="ar">بَائِنَةٌ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAnaApN">
				<h3 class="entry"><span class="ar">بَانَاةٌ</span></h3>
				<div class="sense" id="baAnaApN_A1">
					<p><span class="ar">بَانَاةٌ</span>: <a href="#baAnK">see <span class="ar">بَانٍ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بَانَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAnaApN_A2">
					<p>Also, <span class="auth">(in <span class="add">[some of]</span> the copies of the Ḳ erroneously written <span class="ar">بانات</span>, TA,)</span> A man <em>bending himself over his bow-string when shooting.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بَانَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="baAnaApN_A3">
					<p>And <em>Small</em> <span class="ar">نَبْل</span> <span class="add">[or <em>arrows</em>]</span>. <span class="auth">(M and TA in art. <span class="ar">بين</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAniyapN">
				<h3 class="entry"><span class="ar">بَانِيَةٌ</span></h3>
				<div class="sense" id="baAniyapN_A1">
					<p><span class="ar">بَانِيَةٌ</span> <a href="#baAnK">fem. of <span class="ar">بَانٍ</span> <span class="add">[q. v.]</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">بَانِيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baAniyapN_A2">
					<p><a href="#bawaAnK">Also sing. of <span class="ar">بَوَانٍ</span></a>, <span class="auth">(TA,)</span> which signifies The <em>ribs of</em> <span class="add">[<em>the breast,</em> or <em>of the part thereof called</em>]</span> <em>the</em> <span class="ar">زَوْر</span>: <span class="auth">(M, Ḳ:)</span> or the <em>bones of the breast:</em> or the <em>shoulder-blades and the four legs:</em> <span class="auth">(TA:)</span> and the <em>legs</em> of a she-camel. <span class="auth">(M, Ḳ.)</span> <span class="pb" id="Page_0262"></span>One says, <span class="add">[likening a man to a camel lying down,]</span> <span class="ar long">أَلْقَى بَوَانِيهُ</span>, meaning <em>He took up his abode, and settled,</em> <span class="auth">(T, M, Ḳ,)</span> in a place; like <span class="ar long">أَلْقَى عَصَاهُ</span>. <span class="auth">(T, M.)</span> <span class="ar long">أَلْقَى الشَّأْمُ بَوَانِيَهُ</span> <span class="add">[meaning <em>Syria became in a settled state</em>]</span> occurs in a trad. as related by AʼObeyd: and if he said <span class="ar">بَوَائِنَهُ</span>, it would be allowable; <span class="ar">بَوَائِنُ</span> being <a href="#bwAn">pl. of <span class="ar">بوان</span></a>, <span class="add">[i. e. <span class="ar">بُوَانٌ</span> or <span class="ar">بِوَانٌ</span>,]</span> which is a name for any tent-pole except in the middle of the <span class="ar">بَيْت</span>, which has three poles. <span class="auth">(T.)</span> And it is said in another trad., <span class="ar long">أَلْقَتِ السَّمَآءُ بِرَكَ بَوَانِيهَا</span>, meaning <em>The sky cast down the rain that it contained.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AibonN">
				<h3 class="entry"><span class="ar">اِبْنٌ</span></h3>
				<div class="sense" id="AibonN_A1">
					<p><span class="ar">اِبْنٌ</span>, meaning <em>A son;</em> <span class="auth">(M, Mgh, Ḳ;)</span> because he is the father's building, made to be so by God; <span class="auth">(Er-Rághib, TA;)</span> and ‡ <em>a son's son;</em> and ‡ <em>a descendant more remote;</em> <span class="auth">(Mṣb;)</span> is with a conjunctive <span class="ar">ا</span> <span class="add">[when not immediately preceded by a quiescence, written <span class="ar">ٱبْنٌ</span>]</span>; <span class="auth">(Zj, T, M;)</span> <span class="add">[and when immediately preceded by the proper name of a man and immediately followed by the proper name of his parent, written without the <span class="ar">ا</span>, as in <span class="ar long">زَيْدُ بْنُ عَمْرٍو</span> <em>Zeyd the son of ʼAmr</em> <span class="auth">(in which case it should also be observed that the former proper name is without tenween)</span>; unless the words compose a proposition, as in <span class="ar long">زَيْدٌ ٱبْنُ عَمْرٍو</span> <em>Zeyd is the son of ʼAmr;</em> or in the case of an interrogation, as in <span class="ar long">هَلْ زَيْدٌ ٱبْنُ عَمْرٍو</span> <em>Is Zeyd the son of ʼAmr?</em>]</span>: the pl. is <span class="arrow"><span class="ar">بَنُونَ↓</span></span> <span class="auth">(T, Ṣ, Mgh, Mṣb)</span> in the nom. case, and <span class="ar">بَنِينَ</span> in the accus. and gen.; <span class="auth">(Mgh;)</span> and <span class="ar">أَبْنَآءٌ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> which is a pl. of pauc.: <span class="auth">(Mṣb:)</span> <span class="add">[and hence it is argued that]</span> the sing. is of the measure <span class="ar">فَعَلٌ</span> with the final radical letter elided and the conjunctive <span class="ar">ا</span> prefixed; <span class="auth">(M;)</span> originally <span class="ar">بَنَىٌ</span>, <span class="auth">(M, Ḳ,)</span> with <span class="ar">ى</span>, as we judge, because <span class="add">[the aor.]</span> <span class="ar">يَبْنِى</span> is more common than <span class="ar">يَبْنُو</span>: <span class="auth">(M:)</span> or originally <span class="ar">بَنَوٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> with two fet-ḥahs, because it has <span class="ar">بَنُونَ</span> for a pl., and the perfect pl. does not admit of change <span class="add">[in its vowels beyond that which is here made in <span class="ar">بَنُونَ</span> for <span class="ar">بَنَوُونَ</span>]</span>; <span class="auth">(Mṣb;)</span> and because it has for a pl. <span class="ar">أَبْنَآءٌ</span>, like as <span class="ar">جَمَلٌ</span> has <span class="ar">أَجْمَالٌ</span>; <span class="auth">(Ṣ;)</span> and the elided letter is <span class="ar">و</span>, <span class="auth">(Akh, T, Ṣ,)</span> as in <span class="ar">أَبٌ</span> and <span class="ar">أَخٌ</span>, <span class="auth">(Ṣ,)</span> because <span class="ar">و</span> is more commonly elided than <span class="ar">ى</span>; <span class="auth">(Akh, T;)</span> or because the fem. is <span class="ar">بِنْتٌ</span> and <span class="add">[<a href="#OaxN">that of <span class="ar">أَخٌ</span></a> is]</span> <span class="ar">أُخْتٌ</span>; for we do not see this <span class="ar">ه</span> <span class="add">[or <span class="ar">ت</span>]</span> affixed in the fem. except when <span class="ar">و</span> is elided in the masc., as is shown by <span class="ar">أَخَوَاتٌ</span> and <span class="ar">هَنَوَاتٌ</span>; <span class="auth">(Ṣ;)</span> though <span class="ar">بُنُوَّةٌ</span> is not a decisive proof that the last radical is <span class="ar">و</span>, for a reason stated above in the explanation of it: <span class="auth">(T:)</span> or, as some say, it is originally <span class="ar">بِنْوٌ</span>, with kesr to the. <span class="ar">ب</span>, like <span class="ar">حِمْلٌ</span>, because they say <span class="ar">بِنْتٌ</span>, and a change <span class="add">[of a vowel]</span> in a case of this kind is rare: <span class="auth">(Mṣb:)</span> <span class="add">[but J says,]</span> it may not be of the measure <span class="ar">فِعْلٌ</span> nor <span class="ar">فُعْلٌ</span>, because it has <span class="ar">بَنُونَ</span> with fet-ḥ to the <span class="ar">ب</span>, for a pl.; nor of the measure <span class="ar">فَعْلٌ</span>, because this has <span class="add">[generally]</span> for its <span class="add">[broken]</span> pl. <span class="ar">أَفْعُلٌ</span> or <span class="ar">فُعُولٌ</span>: <span class="auth">(Ṣ:)</span> Zj says that it is originally <span class="ar">بِنْىٌ</span> or <span class="ar">بِنْوٌ</span>, or it may be originally <span class="ar">بَنًا</span>; that it is app. the last accord. to those who say <span class="ar">بَنُون</span>; and that <span class="ar">أَبْنَآءٌ</span> may be pl. of the measure <span class="ar">فَعَلٌ</span> <a href="#fiEolN">and of <span class="ar">فِعْلٌ</span></a>; that <span class="ar">بِنْتٌ</span> favours its being of the latter; but that it may be of the measure <span class="ar">فَعَلٌ</span> changed to <span class="ar">فِعْلٌ</span>, as <span class="ar">فَعَلٌ</span> is changed to <span class="ar">فُعْلٌ</span> in the case of <span class="ar">أُخْتٌ</span>. <span class="auth">(T.)</span> Beside the pls. mentioned above, <span class="ar">اِبْنٌ</span> has a quasi-pl. n., namely <span class="arrow"><span class="ar">أَبْنَى↓</span></span>, of the same measure as <span class="ar">أَعْمَى</span>; <span class="auth">(Mgh, TA;*)</span> a sing. denoting the pl.: or, as some say, <span class="ar">اِبْنٌ</span> has for pls. <span class="ar">أَبْنَآءٌ</span> and <span class="ar">أَبْنَى</span>. <span class="auth">(TA.)</span> Lḥ mentions the phrase, <span class="ar long">هٰؤُلَآءِ أَبْنَا أَبْنَائِهِمْ</span> <span class="add">[or <span class="ar long">أَبْنَى ابنائهم</span> <em>These are the sons of their sons.</em>]</span>. <span class="auth">(M.)</span> Sometimes <span class="ar">م</span> is affixed to <span class="ar">اِبْنٌ</span> <span class="add">[so that it becomes <span class="arrow"><span class="ar">اِبْنُمٌ↓</span></span> or <span class="ar">اِبْنَمٌ</span> at the beginning of a sentence, and<span class="arrow"><span class="ar">ٱبْنُمٌ↓</span></span> or <span class="ar">ٱبُنَمٌ</span> in other cases]</span>: the word is then doubly declinable <span class="add">[like <span class="ar">اِمْرُؤٌ</span> or <span class="ar">ٱمْرُأٌ</span>]</span>: you say, <span class="ar long">هٰذَا ٱبْنُمٌ</span> <span class="add">[<em>This is a son</em>]</span>, and <span class="ar long">رَأَيْتُ ٱبْنَمًا</span> <span class="add">[<em>I saw a son</em>]</span>, and <span class="ar long">مَرَرْتُ بِٱبْنِمٍ</span> <span class="add">[<em>I passed by a son</em>]</span>; making the <span class="ar">ن</span> similarly declinable to the <span class="ar">م</span>; and the <span class="ar">ا</span> is with kesr in every case <span class="add">[when the word commences a sentence, whether you make the word doubly declinable or not]</span>: <span class="auth">(AHeyth,* Ṣ:)</span> <span class="add">[for]</span> some make it singly declinable, leaving the <span class="ar">ن</span> with fet-ḥ in every case <span class="add">[as the <span class="ar">ر</span> in <span class="ar">اِمْرَأٌ</span> or <span class="ar">ٱمْرَأٌ</span>]</span>; saying, <span class="ar long">هٰذَا ٱبْنَمُكَ</span> <span class="add">[<em>This is thy son</em>]</span>, and <span class="ar long">رَأَيْتُ ٱبْنَمَكَ</span> <span class="add">[<em>I saw thy son</em>]</span>, and <span class="ar long">مَرَرْتُ بِٱبْنَمِكَ</span> <span class="add">[<em>I passed by thy son</em>]</span>. <span class="auth">(AHeyth, TA.)</span> Hassán says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَلَدْنَا بَنِى العَنْقَآءِ وَٱبْنَىْ مُحَرِّقٍ</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">فَأَكْرِمْ بِنَا خَالًا وَأَكْرِمْ بِنَا ٱبْنَمَا↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>We begot the sons of El-'Ankà, and the two sons of Moharrik; and how generous are we as a maternal uncle! and how generous are we as a son!</em>]</span>, <span class="auth">(Ṣ, Ḳ,*)</span> i. e., <span class="ar">ٱبْنَا</span>: the <span class="ar">م</span> is augmentative, and the hemzeh <span class="add">[or rather <span class="ar">ا</span>]</span> is that of conjunction. <span class="auth">(Ḳ.)</span> And Ru-beh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بُكَآءَ شَكْلَى فَقَدَتْ حَمِيمَا</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">فَهْىَ تُنَادِى بِأَبِى وَٱبْنِيمَا↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>As the weeping of a bereft woman, who has lost a relation, therefore she calls out, With my father</em> would I ransom thee, <em>and a son</em>]</span>; meaning <span class="ar">ٱبْنِمَا</span>. <span class="auth">(TA.)</span> <a href="#IibonN">The fem. of <span class="ar">اِبْنٌ</span></a> is <span class="arrow"><span class="ar">اِبْنَةٌ↓</span></span> or <span class="ar">ٱبْنَةٌ</span> <span class="add">[with the conjunctive <span class="ar">ا</span> when not commencing a sentence]</span> and<span class="arrow"><span class="ar">بِنْتٌ↓</span></span> <span class="add">[meaning <em>A daughter;</em> and † <em>any female descendant</em>]</span>: <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ:)</span> accord. to Sb, <span class="auth">(M,)</span> <span class="ar">اِبْنَةٌ</span> is formed from <span class="ar">اِبْنٌ</span> by affixing <span class="ar">ه</span> <span class="add">[or <span class="ar">ة</span>]</span>; but not so <span class="ar">بِنْتٌ</span>; for this is formed by affixing <span class="ar">ى</span> as a letter of quasi-coordination, and then substituting for it <span class="ar">ت</span>: <span class="auth">(M, Ḳ:)</span> <span class="add">[but if the <span class="ar">ت</span> be substituted for <span class="ar">ى</span>, it seems more probable that the <span class="ar">ى</span> is the final radical:]</span> or, as some say, the <span class="ar">ت</span> is substituted for <span class="ar">و</span>: <span class="auth">(M:)</span> <span class="add">[Mṭr says,]</span> the <span class="ar">ت</span> is substituted for the final radical: <span class="auth">(Mgh:)</span> accord. to Ks, it is originally with <span class="ar">ه</span> <span class="add">[or <span class="ar">ة</span>]</span>, because it has a fem. meaning: <span class="auth">(IAạr, Mṣb:)</span> <span class="add">[my own opinion is most agreeable with this of Ks; and with that of Zj, which will be mentioned below; or, perhaps, is identical with that of Zj: I think it most probable that, as <span class="ar">اِبْنٌ</span> is generally held to be originally <span class="ar">بَنَىٌ</span> or <span class="ar">بَنَوٌ</span>, so <span class="ar">اِبْنَةٌ</span> and <span class="ar">بِنْتٌ</span> are both originally <span class="ar">بَنَيَةٌ</span> or <span class="ar">بَنَوَةٌ</span>, and that <span class="ar">بِنْتٌ</span> is formed from <span class="ar">اِبْنَةٌ</span> by suppressing the alif, transferring its kesreh to the <span class="ar">ب</span>, making the <span class="ar">ن</span> quiescent, and changing the <span class="ar">ة</span> into <span class="ar">ت</span>, which is therefore said to be not the sign of the fem. gender, either because it is not <span class="ar">ة</span>, but is a substitute for <span class="ar">ة</span>, or because it is preceded by a quiescent letter:]</span> AHn says that the <span class="ar">ت</span> is substituted for the final radical letter, which is <span class="ar">و</span>; and that it is not the sign of the fem. gender, because the letter <span class="add">[next]</span> before it is quiescent: this <span class="add">[he says]</span> is the opinion of Sb, and is the right opinion; for he says that if you were to use it as the proper name of a man, you would make it perfectly decl.; and if the <span class="ar">ت</span> were to denote the fem. gender, the name would not be perfectly decl.: <span class="auth">(TA:)</span> and the same is said respecting the <span class="ar">ت</span> in <span class="ar">أُخْتٌ</span>: <span class="auth">(TA in art. <span class="ar">اخو</span>:)</span> this <span class="ar">ت</span> remains in a case of pause <span class="auth">(Ks, IAạr, Ṣ, Mṣb)</span> as in the case of the connexion of the word with a word following: <span class="auth">(Ṣ:)</span> but one should not say <span class="ar">اِبِنْتٌ</span>, <span class="auth">(Th, T, Ṣ.)</span> because the <span class="ar">ا</span> is required only on account of the quiescence of the <span class="ar">ب</span>, and is therefore dropped when this is made movent: <span class="auth">(Ṣ:)</span> Zj says that, in forming <a href="#binotN">the pl. of <span class="ar">بِنْتٌ</span></a> <span class="add">[<a href="#IibonapN">and of <span class="ar">اِبْنَةٌ</span></a>]</span>, the sing. is reduced to its original form, which is <span class="ar">فَعْلَةٌ</span> <span class="add">[as I find it written in the transcript from the T in the TT, but it may be a mistake for <span class="ar">فَعَلَپٌ</span>,]</span> with the last radical letter suppressed: <span class="auth">(T in TT:)</span> the pl. is <span class="ar">بَنَاتٌ</span> <span class="auth">(T, Ṣ, Mṣb)</span> alone: <span class="auth">(Ṣ:)</span> <span class="add">[and this is generally treated as a fem. pl. of the perfect, or sound, kind, although the <span class="ar">ت</span> in <span class="ar">بِنْتٌ</span> is said to be not a sign of the fem. gender; so that you say, <span class="ar long">رَأَيْتُ بَنَاتِكَ</span> <em>I saw thy daughters;</em> but sometimes]</span> one says, <span class="ar long">رَأَيْتُ بَنَاتَكَ</span>, with fet-ḥ <span class="add">[as the case-ending]</span>, treating the <span class="ar">ت</span> as a radical letter. <span class="auth">(Ṣ.)</span> It is said in the Bári' that when men and women are mixed together, the masc. pl. is made predominant; so that one says, <span class="ar long">بَنُو فُلَانٍ</span> <span class="add">[meaning <em>The sons and daughters,</em> or <em>the children, of such a one</em>]</span>; and even, <span class="ar long">اِمْرَأَةٌ مِنْ بَنى تَمِيمٍ</span> <span class="add">[<em>A woman of the children of Temeem</em>]</span>; and accordingly, if <span class="ar long">بَنُو فُلَانٍ</span> is applied to denote the persons to whom a legacy is left, the males and the females are included therein. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AibonN_A2">
					<p>When <span class="ar">اِبْن</span> is applied to that which is not a human being, <span class="auth">(IAmb, Mṣb,)</span> to an irrational being, <span class="auth">(Mṣb,)</span> it has for its pl. <span class="ar">بَنَات</span>: <span class="auth">(IAmb, Mṣb:)</span> thus the pl. of <span class="ar long">اِبْنُ مَخَاضٍ</span> <span class="add">[<em>A young male camel in his second year</em>]</span> is <span class="ar long">بَنَاتُ مَخَاضٍ</span>: <span class="auth">(Mgh, Mṣb:)</span> that of <span class="ar long">اِبْنُ لَبُونٍ</span> <span class="add">[<em>A male camel that has entered upon his third year</em>]</span> is <span class="ar long">بَنَاتُ لَبُونٍ</span>: <span class="auth">(Mṣb:)</span> and that of <span class="ar long">اِبْنُ نَعْشٍ</span> <span class="add">[<em>Any one of the stars of the tail of Ursa Major</em> or <em>of that of Ursa Minor</em>]</span> is <span class="ar long">بَنَاتُ نَعْشٍ</span>; but sometimes, by poetic licence, <span class="ar long">بَنُو نَعْشٍ</span>: and hence, or to make a distinction between the males and the females, the lawyers say, <span class="ar long">بَنُو اللَّبُونِ</span>. <span class="auth">(IAmb, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AibonN_A3">
					<p><span class="arrow"><span class="ar">بَنَاتٌ↓</span></span> also signifies ‡ <em>Dolls with which young girls play:</em> <span class="auth">(Ṣ, Mgh, Ḳ:)</span> sing. <span class="ar">بِنْتٌ</span>. <span class="auth">(Mgh.)</span> It occurs in this sense in a trad., in which ʼÁïsheh speaks of her playing therewith <span class="auth">(Ṣ, Mgh)</span> when, being nine years of age, she was conducted as a bride to Moḥammad. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="AibonN_A4">
					<p><span class="ar">اِبْن</span> is often prefixed to some other noun <span class="auth">(T, M, Mṣb)</span> that particularizes its signification, because of a close connexion between the two meanings: <span class="auth">(Mṣb:)</span> and so is <span class="arrow"><span class="ar">بِنْت↓</span></span>. <span class="auth">(T, M.)</span> <span class="pb" id="Page_0263"></span><span class="add">[Most of the compounds thus formed will be found explained in the arts. to which belong the nouns that occupy the second place. The following are among the more common, and are therefore here mentioned, as exs. of different kinds.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="AibonN_A5">
					<p><span class="ar long">اِبْنُ الطِّينِ</span> <span class="add">[<em>The son of earth,</em> or <em>clay,</em> meaning]</span> <em>Adam.</em> <span class="auth">(T.)</span> <span class="ar long">اِبْنُ اللَّيْلِ</span> and <span class="ar long">اِبْنُ الطَّرِيقِ</span> <em>The thief,</em> or <em>robber.</em> <span class="auth">(T.)</span> Also the former, <em>The wayfarer,</em> or <em>traveller;</em> <span class="auth">(Er-Rághib, TA;)</span> and so <span class="ar long">اِبْنُ السَّبِيلِ</span>. <span class="auth">(Mṣb, Er-Rághib.)</span> <span class="ar long">اِبْنُ حَرْبٍ</span> <em>A warrior:</em> <span class="auth">(Er-Rághib, TA:)</span> and <span class="ar long">اِبْنُ الحَرْبِ</span> <span class="add">[<em>the warrior;</em> or]</span> <em>he who suffices for war, and who defends.</em> <span class="auth">(Mṣb.)</span> <span class="ar long">اِبْنُ الدُّنْيَا</span> <em>The rich man.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="AibonN_A6">
					<p><span class="ar long">اِبْنُ آوَى</span> <span class="add">[<em>The jackal;</em>]</span> <em>a certain beast of prey.</em> <span class="auth">(TA.)</span> <span class="ar long">اِبْنُ عِرْسٍ</span> <em>The</em> <span class="ar">سُرْعُوب</span> <span class="add">[or <em>weasel</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="AibonN_A7">
					<p><span class="ar long">اِبْنُ أَدِيمٍ</span> <em>A skin for water or milk made of one hide;</em> and <span class="ar long">اِبْنُ أَدِيمَيْنِ</span> <em>one made of two hides;</em> and <span class="ar long">اِبْنُ ثَلَاثَهِ آدِمَةٍ</span> <em>one made of three hides.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="AibonN_A8">
					<p><span class="ar long">اِبْنَةُ الجَبَلِ</span> <em>The echo.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="AibonN_A9">
					<p><span class="ar long">بَنَاتُ بِئْسٍ</span> and <span class="ar long">بَنَاتُ طَبَقٍ</span> and <span class="ar long">بَنَاتُ بَرْحٍ</span> and <span class="ar long">بَنَاتُ أَوْدَكَ</span> <em>Calamities,</em> or <em>misfortunes.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بنى</span> - Entry: <span class="ar">اِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="AibonN_A10">
					<p>Ru-beh said of a man who was mentioned to him, <span class="ar long">كَانَ إِحْدَى بَنَاتِ مَسَاجِدِ ٱللّٰهِ</span>; as though he asserted that <em>He was one of the pebbles of the mosque</em> <span class="add">[or rather <em>of the mosques of God</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AibonapN.1">
				<h3 class="entry"><span class="ar">اِبْنَةٌ</span> / <span class="ar">ٱبْنَةٌ</span></h3>
				<div class="sense" id="AibonapN.1_A1">
					<p><span class="ar">اِبْنَةٌ</span> or <span class="ar">ٱبْنَةٌ</span>: <a href="#IibonN">fem. of <span class="ar">اِبْنٌ</span></a>, <a href="#IibonN">which see</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AibonumN.1">
				<h3 class="entry"><span class="ar">اِبْنُمٌ</span> / 
							<span class="ar">اِبْنَمٌ</span> / 
							<span class="ar">ٱبْنُمٌ</span> / 
							<span class="ar">ٱبْنَمٌ</span></h3>
				<div class="sense" id="AibonumN.1_A1">
					<p><span class="ar">اِبْنُمٌ</span> and <span class="ar">اِبْنَمٌ</span>, or <span class="ar">ٱبْنُمٌ</span> and <span class="ar">ٱبْنَمٌ</span>: <a href="#IibonN">see <span class="ar">اِبْنٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oabonae">
				<h3 class="entry"><span class="ar">أَبْنَى</span></h3>
				<div class="sense" id="Oabonae_A1">
					<p><span class="ar">أَبْنَى</span>: <a href="#IibonN">quasi-pl. n. of <span class="ar">اِبْنٌ</span> which see</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AibonaeBN">
				<h3 class="entry"><span class="ar">اِبْنَىٌّ</span></h3>
				<div class="sense" id="AibonaeBN_A1">
					<p><span class="ar">اِبْنَىٌّ</span>: <a href="#banawieBN">see <span class="ar">بَنَوِىٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="QboniymaA">
				<h3 class="entry"><span class="ar">ٱبْنِيمَا</span></h3>
				<div class="sense" id="QboniymaA_A1">
					<p><span class="ar">ٱبْنِيمَا</span>, for <span class="ar">ٱبْنِمَا</span>: <a href="#IibonN">see a verse cited voce <span class="ar">اِبْنٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OubayonN">
				<h3 class="entry"><span class="ar">أُبَيْنٌ</span></h3>
				<div class="sense" id="OubayonN_A1">
					<p><span class="ar">أُبَيْنٌ</span> <span class="add">[<a href="#IibonN">an unused, or unusual, dim. of <span class="ar">اِبْنٌ</span></a>]</span>: <a href="#OubaYonK">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubayonK">
				<h3 class="entry"><span class="ar">أُبَيْنٍ</span></h3>
				<div class="sense" id="OubayonK_A1">
					<p><span class="ar">أُبَيْنٍ</span>, of the same measure as <span class="ar">أُعَيْمٍ</span>, <a href="#Oabonae">is the dim. of <span class="ar">أَبْنَى</span></a>, which is like <span class="ar">أَعْمَى</span>, <span class="auth">(Sb, IB, Mgh,)</span> and is quasi-<a href="#IibonN">pl. of <span class="ar">اِبْنٌ</span></a>. <span class="auth">(Mgh.)</span> Moḥammad is related, in a trad., to have said, <span class="ar long">أُبَيْنِى لَا تَرْمُوا جَمْرَةَ العَبَقَبِةِ حَتَّى تَطْلُعَ الشَّمْسُ</span> <span class="add">[<em>O little</em> <span class="auth">(meaning <em>dear</em>)</span> <em>sons, cast not ye the pebble of the 'Akabeh</em> (<a href="#jamorapN">see <span class="ar">جَمْرَةٌ</span></a>) <em>until the sun rise</em>]</span>, <span class="auth">(TA,)</span> or <span class="ar long">أُبَيْنِىَّ الخ</span> <span class="add">[<em>O my little sons</em>, &amp;c.]</span>: <span class="auth">(Mgh, TA:)</span> IAth says that the hemzeh is augmentative; and that there are differences of opinion respecting the form of the word and its meaning: some say that it <a href="#Oabonae">is the dim. of <span class="ar">أَبْنَى</span></a>, like <span class="ar">أَعْمَى</span>, a sing. word denoting a pl. meaning, or, accord. to some, <a href="#IibonN">a pl. of <span class="ar">اِبْنٌ</span></a>, as well as <span class="ar">أَبْنَآءٌ</span>: some say that it <a href="#IibonN">is the dim. of <span class="ar">اِبْنٌ</span></a>; <span class="add">[and if so, we must read <span class="ar">أُبَيْنِى</span> <em>my little son;</em>]</span> but this requires consideration <span class="add">[more especially as it is followed by a pl. verb]</span>: AO says that it <a href="#banieBa">is the dim. of <span class="ar">بَنِىَّ</span></a>, <a href="#IibonN">pl. of <span class="ar">اِبْنٌ</span></a> with the affixed pronoun of the first pers. <span class="add">[sing.]</span>; and this requires us to read <span class="ar">أُبَيْنِىَّ</span>. <span class="auth">(TA.)</span> J says, in the Ṣ, that <a href="#OabonaACN">the dim. of <span class="ar">أَبْنَآءٌ</span></a> <span class="add">[<a href="#IibonN">pl. of <span class="ar">اِبْنٌ</span></a>]</span> is <span class="arrow"><span class="ar">أُبَيْنَآءٌ↓</span></span>, and, if you will, <span class="arrow"><span class="ar">أُبَيْنُونَ↓</span></span>; and he cites a verse in which occurs the expression <span class="ar">أُبَيْنِيكَ</span>, <span class="add">[in the gen. case, meaning <em>thy little sons,</em>]</span> and adds, it is as though its sing. were <span class="ar">إِبْنٌ</span>, with the disjunctive <span class="ar">ا</span>, whence the dim. <span class="arrow"><span class="ar">أُبَيْنٌ↓</span></span>, in the pl. <span class="ar">أُبَيْنُونَ</span>: but he should have said, as though its sing. were <span class="ar">أَبْنَى</span>, like <span class="ar">أَعْمَى</span>, originally <span class="ar">أَبْنَوُ</span>. <span class="auth">(IB, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OubayonaMC">
				<h3 class="entry"><span class="ar">أُبَيْنَآء</span></h3>
				<div class="sense" id="OubayonaMC_A1">
					<p><span class="ar">أُبَيْنَآء</span>: <a href="#OubaYonK">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oubayonuwna">
				<h3 class="entry"><span class="ar">أُبَيْنُونَ</span></h3>
				<div class="sense" id="Oubayonuwna_A1">
					<p><span class="ar">أُبَيْنُونَ</span>: <a href="#OubaYonK">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mibonaApN">
				<h3 class="entry"><span class="ar">مِبْنَاةٌ</span></h3>
				<div class="sense" id="mibonaApN_A1">
					<p><span class="ar">مِبْنَاةٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">مَبْنَاةٌ</span> <span class="auth">(M, Ḳ)</span> <em>A</em> <span class="ar">نِطْع</span> <span class="add">[like <span class="ar">بِنَآءٌ</span>, which see for an explanation]</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> and <em>a</em> <span class="ar">سِتْر</span> <span class="add">[i. e. <em>curtain</em> or <em>the like</em>]</span>: <span class="auth">(Ḳ:)</span> or <em>a thing in the form of a</em> <span class="ar">سِتْر</span>: <span class="auth">(M:)</span> or <em>a</em> <span class="add">[<em>tent of the kind called</em>]</span> <span class="ar">قُبَّة</span>, <em>made of skins,</em> or <em>hides:</em> <span class="auth">(IAạr, T:)</span> or <em>a thing of skins,</em> or <em>hides, of like form to the</em> <span class="ar">قُبَّة</span>, <em>which a woman places in,</em> or <em>at, the side of her tent</em> (<span class="ar long">فِى كِسْرِ بَيْتِهَا</span>), <em>and in which she dwells;</em> and may-be she has sheep, or goats, and is content with the possession of these, exclusively of the other sheep, or goats, for herself and her garments <span class="add">[and app. for making of their skins her <span class="ar">مبناه</span>]</span>; and she has a covering (<span class="ar">إِزَار</span>) <span class="add">[extended]</span> in the middle of the <span class="ar">بَيْت</span> <span class="add">[or tent]</span>, within, to protect her from the heat, and from the violent rain, so that she and her clothes are not wetted: <span class="auth">(Aboo-ʼAdnán, T:)</span> or, accord. to Aṣ, <em>a mat</em> (<span class="ar">حَصِيرٌ</span>), or <em>a</em> <span class="ar">نِطْع</span>, <em>which the trafficker spreads upon the things that he sells:</em> and they used to put the mats (<span class="ar">الحُصُر</span>) upon the <span class="ar">أَنْطَاع</span> <span class="add">[<a href="#niToE">pl. of <span class="ar">نِطْع</span></a>]</span>, and go round about with them <span class="add">[in the market]</span>: the <span class="ar">مبناة</span> is thus called because it is made of skins joined together: <span class="auth">(T:)</span> also <em>a receptacle of the kind called</em> <span class="ar">عَيْبَة</span>: <span class="auth">(M, Ḳ:)</span> such is said to be its meaning: <span class="auth">(Ṣ:)</span> pl. <span class="ar">مَبَانٍ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mabonieBN">
				<h3 class="entry"><span class="ar">مَبْنِىٌّ</span></h3>
				<div class="sense" id="mabonieBN_A1">
					<p><span class="ar">مَبْنِىٌّ</span> <span class="add">[<em>Built,</em>, &amp;c.: <a href="#bne_1">see 1</a>]</span>. <span class="ar long">أَرْضٌ مَبْنِيَّةٌ</span> means <span class="ar long">أَرْضٌ مَبْنِىٌّ فِيهَا</span> <span class="add">[<em>Land built in</em> or <em>upon</em>]</span>; and is deemed a chaste phrase. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubanBFe">
				<h3 class="entry"><span class="ar">مُبَنًّى</span></h3>
				<div class="sense" id="mubanBFe_A1">
					<p><span class="ar">مُبَنًّى</span> <em>Raised high;</em> applied to a palace, or pavilion. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mubotanFe">
				<h3 class="entry"><span class="ar">مُبْتَنًى</span></h3>
				<div class="sense" id="mubotanFe_A1">
					<p><span class="ar">مُبْتَنًى</span> <span class="add">[pass. part. n. of <span class="ar">اِبْتَنَاهُ</span>]</span> is used in the place of the inf. n. <span class="add">[of that verb, agreeably with many other instances, or accord. to a common licence]</span>, meaning The act of <em>building, framing,</em> or <em>constructing.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0260.pdf" target="pdf">
							<span>Lanes Lexicon Page 260</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0261.pdf" target="pdf">
							<span>Lanes Lexicon Page 261</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0262.pdf" target="pdf">
							<span>Lanes Lexicon Page 262</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0263.pdf" target="pdf">
							<span>Lanes Lexicon Page 263</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
