<article class="root" id="Root_bEr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/141_bEd">بعد</a></span>
				<span class="ar">بعر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/143_bED">بعض</a></span>
			</h2>
			<hr>
			<section class="entry main" id="bEr_1">
				<h3 class="entry">1. ⇒ <span class="ar">بعر</span></h3>
				<div class="sense" id="bEr_1_A1">
					<p><span class="ar">بَعَرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَرُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">بَعْرٌ</span> <span class="auth">(Ṣ, Mṣb,)</span> said of an animal having the kind of foot called <span class="ar">خُفّ</span>, <span class="auth">(Mgh, Mṣb, Ḳ,)</span> <span class="add">[i. e.,]</span> of a camel, and also of a sheep and goat, <span class="auth">(Ṣ,)</span> and of a cloven-hoofed animal <span class="auth">(Mgh, Mṣb, Ḳ)</span> of the wild kind of bull or cow, but not of the domestic kind, and of the gazelle-kind, beside the other two cloven-hoofed kinds mentioned before, and of the hare or rabbit, <span class="auth">(TA,)</span> <em>He voided dung.</em> <span class="auth">(Ṣ,* Mgh, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="bEr_1_A2">
					<p><span class="ar">بَعَرَهُ</span> <em>He threw at him a piece of</em> <span class="ar">بَعْر</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="bEr_1_A3">
					<p><span class="ar">بَعَرَتْ</span>, said of a widow, <em>She threw the piece of</em> <span class="ar">بَعْر</span>; <em>i. q.</em><span class="arrow"><span class="ar long">رَمَتْ بِالبَعْرَة↓</span></span>; meaning <em>she ended the number of days during which she had to wait after the death of her husband before she could marry again.</em> <span class="auth">(A.)</span> <span class="add">[It seems to have been customary for the widow to collect a number of pieces of <span class="ar">بَعْر</span>, as many as the days she had to wait before she could marry again, and to throw away one each day: so that the saying means She threw the last piece of <span class="ar">بعر</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEr_1_B1">
					<p><span class="ar">بَعِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَبْعَرُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">بَعَرٌ</span>, <span class="auth">(TA,)</span> <em>He</em> <span class="auth">(a camel)</span> <em>became a</em> <span class="ar">بَعِير</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="bEr_2">
				<h3 class="entry">2. ⇒ <span class="ar">بعّر</span></h3>
				<div class="sense" id="bEr_2_A1">
					<p><a href="#bEr_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEr_3">
				<h3 class="entry">3. ⇒ <span class="ar">باعر</span></h3>
				<div class="sense" id="bEr_3_A1">
					<p><span class="ar long">بَاعَرَتْ حَالِبَهَا</span>, <span class="add">[inf. n., app., <span class="ar">بِعَارٌ</span>, q. v.,]</span> said of a ewe or she-goat, <span class="auth">(Ḳ,)</span> and of a she-camel, <span class="auth">(TA,)</span> <em>She befouled her milker with her dung.</em> <span class="auth">(TA voce <span class="ar">بِعَارٌ</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">بعر</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="bEr_3_B1">
					<p><span class="ar long">بَاعَرَتْ إِلَى حَالِبِهَا</span> <em>She</em> <span class="auth">(a ewe or goat, and a camel,)</span> <em>hastened to her milker.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="bEr_4">
				<h3 class="entry">4. ⇒ <span class="ar">ابعر</span></h3>
				<div class="sense" id="bEr_4_A1">
					<p><span class="ar">ابعر</span> <em>He cleansed</em> an intestine, or a gut, <em>of its</em> <span class="ar">بَعْر</span>; as also<span class="arrow"><span class="ar">بعّر↓</span></span>, inf. n. <span class="ar">تَبْعِيرٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEorN">
				<h3 class="entry"><span class="ar">بَعْرٌ</span> / <span class="ar">بَعْرَةٌ</span></h3>
				<div class="sense" id="baEorN_A1">
					<p><span class="ar">بَعْرٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and<span class="arrow"><span class="ar">بَعَرٌ↓</span></span> <span class="auth">(Mṣb, Ḳ)</span> <span class="add">[coll. gen. ns. signifying <em>Camels',</em> and <em>sheeps',</em> and <em>goats',</em> and <em>similar, dung;</em>]</span> <em>dung</em> <span class="auth">(Mṣb, Ḳ)</span> <em>of animals having the kind of foot called</em> <span class="ar">خُفّ</span>, <span class="auth">(A, Mgh, Mṣb, Ḳ)</span> <span class="add">[i. e.,]</span> <em>of the camel,</em> and also <em>of the sheep</em> and <em>goat,</em> <span class="auth">(Ṣ,)</span> and <em>of cloven-hoofed animals</em> <span class="auth">(A, Mgh, Mṣb, Ḳ)</span> <em>of the wild kind of bull and cow, but not of the domestic kind,</em> and <em>of the gazelle-kind,</em> beside the two other cloven-hoofed kinds, and <em>of the hare</em> or <em>rabbit:</em> <span class="auth">(TA:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">بَعْرَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mgh, Ḳ:)</span> and pl. <span class="ar">أَبْعَارٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ)</span> One says, <span class="ar long">هُوَ أَهْوَنُ عَلَىَّ مِنْ بَعْرَةٍ يُرْمَى بِهَا كَلْبٌ</span> <span class="add">[<em>He is a lighter thing to me than a piece of</em> <span class="ar">بعر</span> <em>that is thrown at a dog</em>]</span>. <span class="auth">(A.)</span> And it is said in a prov., <span class="ar long">أَنْتَ كَصَاحِبِ البَعْرَةِ</span> <span class="add">[<em>Thou art like the owner of the piece of</em> <span class="ar">بعر</span>, or <span class="ar long">أَنْتَ فِى مِثْلِ صَاحِبِ البَعْرَةِ</span> <em>Thou art in a condition like that of the owner of the piece of</em> <span class="ar">بعر</span>; <span class="auth">(meaning the person for whom it was intended;)</span> applied to him who reveals a thing relating to himself; <span class="auth">(see Freytag's Arab. Prov. i. 85;)</span>]</span> originating from the fact that a man had a suspicion respecting some one among his people; so he collected them to search out from them the truth of the case, and took a piece of <span class="ar">بعر</span>, and said, “I am about to throw this my piece of <span class="ar">بعر</span> at the person whom I suspect;” whereupon one of them withdrew himself quickly, and said, “Throw it not at me;” and confessed. <span class="auth">(TA.)</span> <a href="#baEarato">See also <span class="ar">بَعَرَتْ</span>, above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="baEarN">
				<h3 class="entry"><span class="ar">بَعَرٌ</span></h3>
				<div class="sense" id="baEarN_A1">
					<p><span class="ar">بَعَرٌ</span>: <a href="#baEorN">see <span class="ar">بَعْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="biEaArN">
				<h3 class="entry"><span class="ar">بِعَارٌ</span></h3>
				<div class="sense" id="biEaArN_A1">
					<p><span class="ar">بِعَارٌ</span>, a subst., <span class="add">[<a href="#bEr_3">or inf. n. of 3</a>,]</span> The <em>befouling of her milker with her dung,</em> by a ewe or she-goat, <span class="auth">(Ḳ,)</span> or a camel: <span class="auth">(TA:)</span> it is reckoned a fault, because the animal that does so sometimes casts her dung into the milking-vessel. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baEiyrN">
				<h3 class="entry"><span class="ar">بَعِيرٌ</span></h3>
				<div class="sense" id="baEiyrN_A1">
					<p><span class="ar">بَعِيرٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> sometimes pronounced <span class="ar">بَعِيرٌ</span>, <span class="auth">(Ḳ,)</span> which latter is of the dial. of BenooTemeem, but the former is the more chaste, <span class="auth">(TA,)</span> <em>A camel, male or female;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as applied to a camel, like <span class="ar">إِنْسَانٌ</span> applied to a human being; <span class="auth">(Ṣ, Mṣb;)</span> whereas <span class="ar">جَمَلٌ</span> is applied only to a male camel, and <span class="ar">نَاقَةٌ</span> to a she-camel; <span class="pb" id="Page_0227"></span><span class="ar">بَكْرٌ</span> and <span class="ar">بَكْرَةٌ</span> are respectively terms like <span class="ar">فَتنًى</span> and <span class="ar">فَتَاةٌ</span>; and <span class="ar">قَلُوصٌ</span> is like the term <span class="ar">جَارِيَةٌ</span>; so say, among others, ISk and Az and IJ; and it is added in the Mutahffidh, that the terms <span class="ar">جمل</span> and <span class="ar">ناقة</span> are applied only when the animal has entered the seventh year: <span class="auth">(Mṣb:)</span> but <span class="ar">بعير</span> is more commonly applied to the <em>male camel;</em> <span class="auth">(Mṣb, Ḳ;)</span> and only to <em>one that has entered its fifth year;</em> <span class="auth">(Ṣ, Ḳ;)</span> or <em>that has entered its ninth year:</em> <span class="auth">(Ḳ:)</span> the pl. is <span class="ar">أَبْعِرَةٌ</span> <span class="add">[a pl. of pauc.]</span> and <span class="ar">بُعْرَانٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">بِعْرَانٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بُعُرٌ</span> <span class="auth">(TA)</span> and (<a href="#OaboEirapN">pl. of <span class="ar">أَبْعِرَةٌ</span></a> TA) <span class="ar">أَبَاعِرُ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">أَبَاعِيرُ</span> <span class="auth">(Ḳ.)</span> If one say, <span class="ar long">أَعْطُونِى بَعِيرًا</span> <span class="add">[<em>Give ye to me a</em> <span class="ar">بعير</span>]</span>, the persons so addressed, accord. to EshSháfi'ee, are not to give a she-camel: <span class="auth">(Mṣb:)</span> but the following phrases are transmitted from the Arabs: <span class="ar long">صَرَعَتْنِى بَعِيرِى</span> <em>My she-camel threw me down prostrate:</em> <span class="auth">(Ṣ, A:)</span> and <span class="ar long">حَلَبْتُ بَعِيرِى</span> <em>I milked my camel:</em> <span class="auth">(A, Mṣb:)</span> and <span class="ar long">شَرِبْتُ مِنْ لَبَنِ بَعِيرِى</span> <em>I drank of the milk of my camel:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">كِلَا هٰذِيْنِ البِعْرَيْنِ نَاقَةٌ</span> <em>Each of these two camels is a she-camel.</em> <span class="auth">(A.)</span> <span class="ar long">لَيْلَةُ البَعِيرِ</span> <span class="add">[<em>The night of the camel</em>]</span>, mentioned in a trad. of Jábir, means the night in which the Prophet purchased of him his camel. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">بعر</span> - Entry: <span class="ar">بَعِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="baEiyrN_A2">
					<p>Also <em>An ass:</em> <span class="auth">(IKh, Ḳ:)</span> so in the Ḳur xii. 72; but this signification is of rare occurrence: <span class="auth">(IKh:)</span> and <em>anything that carries:</em> <span class="auth">(IKh, Ḳ:)</span> so in the Hebrew language <span class="add">[<span class="he">בְעִיר</span> <span class="auth">(see Gen. xlv. 17)</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="baAEirN">
				<h3 class="entry"><span class="ar">بَاعِرٌ</span></h3>
				<div class="sense" id="baAEirN_A1">
					<p><span class="ar">بَاعِرٌ</span> A widow <em>throwing the piece of</em> <span class="ar">بَعْر</span>; meaning <em>ending the number of days during which she has had to wait after the death of her husband previously to her being allowed to marry again.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#bEr_1">See 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maboEarN">
				<h3 class="entry"><span class="ar">مَبْعَرٌ</span></h3>
				<div class="sense" id="maboEarN_A1">
					<p><span class="ar">مَبْعَرٌ</span> and<span class="arrow"><span class="ar">مِبْعَرٌ↓</span></span> <span class="add">[and<span class="arrow"><span class="ar">مَبْعَرَةٌ↓</span></span> <span class="auth">(occurring in the Ḳ in art. <span class="ar">خور</span>)</span>]</span> The <em>place</em> <span class="add">[or <em>passage</em> <span class="auth">(as is shown in the Lexicons in many places)</span>]</span> <em>of the</em> <span class="ar">بَعْر</span>; <span class="add">[i. e. the <em>rectum;</em> the <em>intestine,</em> or <em>gut, containing the</em> <span class="ar">بَعْر</span>;]</span> of any quadruped: <span class="auth">(Ḳ:)</span> pl. <span class="ar">مَبَاعِرُ</span>. <span class="auth">(TA.)</span> It is said in a prov., <span class="ar long">إِنَّ هٰذَا الدَّاعِرَ مَا زَالَ يَنْحَرُ الأَبَاعِرَ وَيَنْثِلُ المَبَاعِرَ</span> <span class="add">[<em>Verily this bad man has not ceased to slaughter camels and to cleanse the intestines containing the dung</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miboEarN">
				<h3 class="entry"><span class="ar">مِبْعَرٌ</span></h3>
				<div class="sense" id="miboEarN_A1">
					<p><span class="ar">مِبْعَرٌ</span>: <a href="#maboEarN">see <span class="ar">مَبْعَرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maboEarapN">
				<h3 class="entry"><span class="ar">مَبْعَرَةٌ</span></h3>
				<div class="sense" id="maboEarapN_A1">
					<p><span class="ar">مَبْعَرَةٌ</span>: <a href="#maboEarN">see <span class="ar">مَبْعَرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="miboEaArN">
				<h3 class="entry"><span class="ar">مِبْعَارٌ</span></h3>
				<div class="sense" id="miboEaArN_A1">
					<p><span class="ar">مِبْعَارٌ</span> A ewe or she-goat, <span class="auth">(Ḳ,)</span> or a she-camel, <span class="auth">(TA,)</span> <em>that befouls with her dung</em> (<span class="ar">تُبَاعِرُ</span>) <em>her milker.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="#biEaArN">See <span class="ar">بِعَارٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0226.pdf" target="pdf">
							<span>Lanes Lexicon Page 226</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0227.pdf" target="pdf">
							<span>Lanes Lexicon Page 227</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
