<article class="root" id="Root_ATr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/098_AT">اط</a></span>
				<span class="ar">اطر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/100_ATm">اطم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ATr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أطر</span></h3>
				<div class="sense" id="ATr_1_A1">
					<p><span class="ar">أَطَرَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْطِرُ</span>}</span></add> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْطُرُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَطْرٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">أطّرهُ↓</span></span> inf. n. <span class="ar">تَأْطِيرٌ</span>; <span class="auth">(Ḳ;)</span> <em>He bent it,</em> or <em>curved it;</em> <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.;)</span> namely, a bow, <span class="auth">(Ṣ, A,)</span> and a twig, or the like: <span class="auth">(A:)</span> <em>he laid hold upon one of its two extremities, and curved it: he bent it, or curved it;</em> namely, anything; <span class="ar long">عَلَى شَّىْءٍ</span> <em>upon a thing:</em> and the latter verb, <span class="add">[or both,]</span> <em>he bent it into the form of a hoop, bringing its two extremities together.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ATr_1_A2">
					<p>It is said of Adam, <span class="ar long">كَانَ طُوَالًا فَأَطَّرَهُ↓ ٱللّٰهُ</span> <em>He was tall, and God bent him, and diminished his height.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="ATr_1_A3">
					<p>And one says, <span class="ar long">أَخَذَ عَلَى يَدَىِ الظَّالِمِ وَأَطَرَهُ عَلَى الحَقِّ</span> ‡ <span class="add">[<em>He laid hold upon the two hands,</em> or <em>arms, of the wrongdoer,</em> or <em>prevented, restrained,</em> or <em>withheld, him from doing that which he desired,</em>]</span> <em>and bent him to</em> <span class="add">[<em>conformity with</em>]</span> <em>what was right.</em> <span class="auth">(AA, from a trad.)</span> And <span class="ar long">أَطَرْتَ فُلَانًا عَلَى مَوَدَّتِكَ</span> ‡ <span class="add">[<em>Thou hast bent such a one to love thee</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="ATr_1_A4">
					<p><span class="ar long">أَطَرَ السَّهْمَ</span> <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْطِرُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْطُرُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ, Ḳ,)</span> <em>He wound an</em> <span class="ar">أُطْرَة</span> <em>upon the arrow.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="ATr_1_A5">
					<p><span class="ar long">أَطَرَ البَيْتَ</span>, <span class="auth">(TḲ,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> <em>He made an</em> <span class="ar">إِطَار</span>, which is a <em>thing resembling a zone</em> or <em>belt, to the tent</em> or <em>house.</em> <span class="auth">(Ḳ, TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ATr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أطّر</span></h3>
				<div class="sense" id="ATr_2_A1">
					<p><a href="#ATr_1">see 1</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ATr_2_B1">
					<p><span class="ar">أَطَّرَتْ</span>, inf. n. <span class="ar">تَأْطِيرٌ</span> <em>She</em> <span class="auth">(a girl, IAạr)</span> <em>remained in the house,</em> or <em>tent, of her father, some time,</em> or <em>long,</em> <span class="auth">(IAạr, Ḳ,)</span> <em>without marrying.</em> <span class="auth">(IAạr.)</span> <span class="add">[<a href="#ATr_5">See also 5</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ATr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأطّر</span></h3>
				<div class="sense" id="ATr_5_A1">
					<p><span class="ar">تأطّر</span> <em>It</em> <span class="auth">(a spear)</span> <em>bent:</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>it</em> <span class="auth">(a thing)</span> <em>became crooked, curved,</em> or <em>bent;</em> as also<span class="arrow"><span class="ar">انأطر↓</span></span>: <span class="auth">(Ḳ, TA:)</span> <em>it became bent into the form of a hoop, its two extremities being brought together.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ATr_5_A2">
					<p><span class="ar">تَأَطَّرَتْ</span> <em>She affected a bending of her person, body,</em> or <em>limbs, in her gait.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ATr_5_B1">
					<p><em>He confined himself</em> <span class="auth">(Ḳ, TA)</span> in a place. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="ATr_5_B2">
					<p><span class="ar">تَأَطَّرَتْ</span> <em>She</em> <span class="auth">(a woman)</span> <em>remained,</em> or <em>stayed, in her house,</em> or <em>tent;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>she kept to it.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#ATr_2">See also 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="ATr_7">
				<h3 class="entry">7. ⇒ <span class="ar">انأطر</span></h3>
				<div class="sense" id="ATr_7_A1">
					<p><a href="#ATr_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaTorN">
				<h3 class="entry"><span class="ar">أَطْرٌ</span></h3>
				<div class="sense" id="OaTorN_A1">
					<p><span class="ar">أَطْرٌ</span> The <em>place of curvature</em> (<span class="ar">مُنْحَنَى</span>) of a bow, and of a cloud: <span class="auth">(Ḳ, TA:)</span> an inf. n. used as a subst., and, being so used, admitting the dual form: or the <em>bent,</em> or <em>curved, part of the extremity</em> of a bow; to which Tarafeh likens the curving of the ribs of a she-camel: <span class="auth">(TA:)</span> and <em>what resembles a curvature, seen in the clouds:</em> an inf. n. in the sense of a pass. part. n. <span class="auth">(Skr, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuTorapN">
				<h3 class="entry"><span class="ar">أُطْرَةٌ</span></h3>
				<div class="sense" id="OuTorapN_A1">
					<p><span class="ar">أُطْرَةٌ</span> The <em>sinew that is wound immediately above the notch</em> of an arrow; <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِطَارٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">أُطْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuTorapN_A2">
					<p>The <em>edge of the glans</em> of the penis; <span class="auth">(Ḳ,* TA;)</span> as also<span class="arrow">↓</span> the latter word. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">أُطْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OuTorapN_A3">
					<p>The <em>flesh surrounding the nail:</em> <span class="auth">(Ḳ:)</span> pl.<span class="ar">أُطَرٌ</span> and <span class="ar">إِطَارٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">أُطْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OuTorapN_A4">
					<p><em> A mixture of ashes and blood with which a fracture in a cooking-pot is smeared</em> <span class="auth">(Ṣ, Ḳ)</span> <em>and repaired.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiTaArN">
				<h3 class="entry"><span class="ar">إِطَارٌ</span></h3>
				<div class="sense" id="IiTaArN_A1">
					<p><span class="ar">إِطَارٌ</span> <em>Anything that surrounds another thing:</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ:)</span> as the <em>hoop</em> of a tambourine, <span class="auth">(A, Mgh, TA,)</span> and of a sieve. <span class="auth">(Ṣ, A, Mgh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiTaArN_A2">
					<p><em>A ring of hair surrounding the head, the middle of it being bald.</em> <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0067"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiTaArN_A3">
					<p>The <em>branches of a vine, bent,</em> or <em>wreathed, so as to form a covering over-head.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiTaArN_A4">
					<p><a href="#OuTorapN">See also <span class="ar">أُطْرَةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IiTaArN_A5">
					<p><span class="ar long">إِطَارُ الحَافِرِ</span> <em>The part of the hoof of a horse or the like which surrounds,</em> or <em>extends around, the</em> <span class="ar">أَشْعَر</span> <span class="add">[q.v.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IiTaArN_A6">
					<p><span class="ar long">إِطَارُ الشَّفَةِ</span> <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> ‡ <em>The part,</em> <span class="auth">(A,)</span> or <em>flesh,</em> <span class="auth">(Mṣb,)</span> <em>surrounding the lip:</em> <span class="auth">(A, Mṣb:)</span> or <em>the part that separates between the lip and the hairs of the mustache:</em> <span class="auth">(Ḳ:)</span> or <em>the edge of the upper lip, between the lip itself and the parts where the hair grows:</em> <span class="auth">(IAth:)</span> or <em>the rising edge,</em> or <em>ridge, between the part where the mustache is clipped and the lip, intermixing with the mouth.</em> <span class="auth">(AʼObeyd.)</span> The Muslim should clip his mustache so that this part shall appear. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="IiTaArN_A7">
					<p><span class="ar long">إِطَارُ بَيْتٍ</span> <em>A thing resembling a zone,</em> or <em>belt, of a tent</em> or <em>house.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">إِطَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="IiTaArN_A8">
					<p><span class="ar long">إِطَارِ مِنَ النَّاسِ</span> ‡ <em>A ring,</em> or <em>circle, of men.</em> <span class="auth">(Ḳ.)</span> One says, <span class="ar long">هُمْ إِطَارٌ لِبَنِى فُلَانٍ</span> ‡ <em>They have alighted and taken up their abode</em> <span class="add">[<em>so that they form a ring</em>]</span> <em>around the sons of such a one.</em> <span class="auth">(A, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaTiyrN">
				<h3 class="entry"><span class="ar">أَطِيرٌ</span></h3>
				<div class="sense" id="OaTiyrN_A1">
					<p><span class="ar">أَطِيرٌ</span> <em>A sin; a crime; an offence.</em> <span class="auth">(Ṣ, Ḳ.)</span> One says, <span class="ar long">أَخَذَنِى بِأَطِيرِ غَيْرِى</span> <em>He punished me for the sin, crime,</em> or <em>offence, of another than myself.</em> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoTuwrapN">
				<h3 class="entry"><span class="ar">مَأْطُورَةٌ</span></h3>
				<div class="sense" id="maOoTuwrapN_A1">
					<p><span class="ar">مَأْطُورَةٌ</span> <em>A bow.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اطر</span> - Entry: <span class="ar">مَأْطُورَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOoTuwrapN_A2">
					<p><em>A milking-vessel of skin</em> (<span class="ar">عُلْبَةٌ</span>) <em>for the head of which a twig is bent into the form of a hoop, and put round, after which its lip is covered;</em> <span class="auth">(Ḳ, TA;)</span> or, <em>sometimes, the edges of the skin of the</em> <span class="ar">علبة</span> <em>are folded upon the hoop-formed twig, and dry upon it.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0066.pdf" target="pdf">
							<span>Lanes Lexicon Page 66</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0067.pdf" target="pdf">
							<span>Lanes Lexicon Page 67</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
