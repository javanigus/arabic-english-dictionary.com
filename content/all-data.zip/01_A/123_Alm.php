<article class="root" id="Root_Alm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/122_Alk">الك</a></span>
				<span class="ar">الم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/124_Alms">المس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alm_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألم</span></h3>
				<div class="sense" id="Alm_1_A1">
					<p><span class="ar">أَلِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَمُ</span>}</span></add>, inf. n. <span class="ar">أَلَمٌ</span>, <em>It,</em> <span class="auth">(as, for instance, the belly, T, Ṣ, or the head, Mṣb,)</span> or <em>he,</em> <span class="auth">(a man, T, Ṣ, Mṣb,)</span> <em>was in pain; had,</em> or <em>suffered, pain; ached.</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ.)</span> <span class="ar long">أَلِمَ بَطْنَهُ</span> <span class="add">[<em>He was in pain,</em> or <em>had pain, in his belly</em>]</span> <span class="auth">(M)</span> and <span class="ar long">أَلِمْتَ بَطْنَكَ</span> <span class="add">[<em>thou wast in pain,</em> or <em>hadst pain, in thy belly</em>]</span> <span class="auth">(T, Ṣ)</span> or <span class="ar">رَأْسَكَ</span> <span class="add">[<em>in thy head</em>]</span> <span class="auth">(Mṣb)</span> are like <span class="ar long">سَفِهَ رَأْيَهُ</span> <span class="auth">(M)</span> and <span class="ar long">رَشِدْتَ أَمْرَكَ</span> <span class="auth">(Ṣ, T)</span> and <span class="ar long">وَجِعْتَ رَأْسَكَ</span>; <span class="auth">(Mṣb;)</span> the noun being in the accus. case accord. to Ks as an explicative, though explicatives are <span class="add">[by rule]</span> indeterminate, as in <span class="ar long">قَرِرْتُ بِهِ عَيْنًا</span> and <span class="ar long">ضَقْتُ بِهِ ذَرْعًا</span>; <span class="auth">(T;)</span> the regular form being <span class="add">[<span class="ar long">أَلِمَ بَطْنُهُ</span> and]</span> <span class="ar long">أَلِمَ بَطْنُكَ</span>, <span class="auth">(T, Ṣ,)</span> as the verb is intrans. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alm_4">
				<h3 class="entry">4. ⇒ <span class="ar">آلم</span></h3>
				<div class="sense" id="Alm_4_A1">
					<p><span class="ar">آلَمْتُهُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِيلَامٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>I caused him pain</em> or <em>aching.</em> <span class="auth">(Ṣ,* M, Mṣb, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّم</span></h3>
				<div class="sense" id="Alm_5_A1">
					<p><span class="ar">تألّم</span> <em>He was,</em> or <em>became, pained:</em> <span class="auth">(M,* Mṣb, Ḳ:*)</span> or <em>he expressed pain, grief,</em> or <em>sorrow; lamented; complained; made lamentation</em> or <em>complaint; moaned;</em> syn. <span class="ar">تَوَجَّعَ</span>, <span class="auth">(T, Ṣ,)</span> and <span class="ar">شَكَى</span>. <span class="auth">(T.)</span> You say, <span class="ar long">تَأَلَّمَ فُلَانٌ مِنْ فُلَانٍ</span> <span class="add">[<em>Such a one expressed pain,</em>, &amp;c., <em>on account of</em> the conduct or the like of <em>such a one; complained of such a one</em>]</span>: <span class="auth">(T:)</span> and <span class="ar long">لِأَزْمَةِ الزَّمَانِ</span> <span class="add">[<em>on account of the hardness of the time</em>]</span>. <span class="auth">(TA in art. <span class="ar">ازم</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oalamo">
				<h3 class="entry"><span class="ar">أَلَمْ</span></h3>
				<div class="sense" id="Oalamo_A1">
					<p><span class="ar">أَلَمْ</span>: <a href="#lamo">see <span class="ar">لَمْ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalamN">
				<h3 class="entry"><span class="ar">أَلَمٌ</span></h3>
				<div class="sense" id="OalamN_A1">
					<p><span class="ar">أَلَمٌ</span> <em>Pain; ache;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَيْلَمَةٌ↓</span></span>: <span class="auth">(T, M, Ḳ:)</span> pl. <span class="auth">(of the former, T, M)</span> <span class="ar">آلَامٌ</span>. <span class="auth">(T, M, Ḳ.)</span> You say,<span class="arrow"><span class="ar long">مَا أَجِدُ أَيْلَمَةً↓ وَلَا أَلَمًا</span></span> <em>I do not find pain nor ache;</em> i. e. <span class="ar">وَجَعًا</span>: so says AZ: and IAạr says, <span class="arrow"><span class="ar long">أَيْلَمَةً وَلَا أَلَمَةً↓</span></span> as meaning the same. <span class="auth">(T.)</span> And the Arabs say,<span class="arrow"><span class="ar long">لَأُبِيتَنَّكَ عَلَى أَيْلَمَةٍ↓</span></span>, meaning <em>I will assuredly bring upon thee</em> <span class="add">[lit. <em>make thee to pass the night in</em>]</span> <em>distress,</em> or <em>difficulty.</em> <span class="auth">(Sh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalimN">
				<h3 class="entry"><span class="ar">أَلِمٌ</span></h3>
				<div class="sense" id="OalimN_A1">
					<p><span class="ar">أَلِمٌ</span> <em>Being in pain; having,</em> or <em>suffering, pain; aching.</em> <span class="auth">(M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalamapN">
				<h3 class="entry"><span class="ar">أَلَمَةٌ</span></h3>
				<div class="sense" id="OalamapN_A1">
					<p><span class="ar">أَلَمَةٌ</span>: <a href="#OalamN">see <span class="ar">أَلَمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilaAma">
				<h3 class="entry"><span class="ar">إِلَامَ</span></h3>
				<div class="sense" id="IilaAma_A1">
					<p><span class="ar">إِلَامَ</span> a contraction of <span class="ar long">إلَى مَا</span>: <a href="#Iilae">see <span class="ar">إِلَى</span></a>, last sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaliymN">
				<h3 class="entry"><span class="ar">أَلِيمٌ</span></h3>
				<div class="sense" id="OaliymN_A1">
					<p><span class="ar">أَلِيمٌ</span> <em>Causing pain</em> or <em>aching; painful;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>i. q.</em><span class="arrow"><span class="ar">مُؤْلِمٌ↓</span></span>; <span class="auth">(T, M, Mṣb;)</span> like <span class="ar">سَمِيعٌ</span> as syn. with <span class="ar">مُسْمِعٌ</span>: <span class="auth">(Ṣ:)</span> so when applied to punishment <span class="add">[or torment or torture]</span>: <span class="auth">(T, Mṣb:)</span> or, thus applied, <em>painful,</em> or <em>causing pain</em> or <em>aching, in the utmost degree.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaluwmapN">
				<h3 class="entry"><span class="ar">أَلُومَةٌ</span></h3>
				<div class="sense" id="OaluwmapN_A1">
					<p><span class="ar">أَلُومَةٌ</span> <em>Lowness, ignobleness, baseness, vileness,</em> or <em>meanness.</em> <span class="auth">(O, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayolamapN">
				<h3 class="entry"><span class="ar">أَيْلَمَةٌ</span></h3>
				<div class="sense" id="OayolamapN_A1">
					<p><span class="ar">أَيْلَمَةٌ</span>: <a href="#OalamN">see <span class="ar">أَلَمٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الم</span> - Entry: <span class="ar">أَيْلَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OayolamapN_A2">
					<p>Accord. to IAạr, <span class="auth">(T,)</span> <em>A sound,</em> or <em>voice.</em> <span class="auth">(T, Ḳ.)</span> You say, <span class="ar long">مَا سَمِعْتُ لَهُ أَيْلَمَةٌ</span> <em>I heard not any sound,</em> or <em>voice, of,</em> or <em>belonging to, him,</em> or <em>it.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الم</span> - Entry: <span class="ar">أَيْلَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OayolamapN_A3">
					<p>Accord. to AA, <span class="auth">(T,)</span> <em>Motion.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWolimN">
				<h3 class="entry"><span class="ar">مُؤْلِمٌ</span></h3>
				<div class="sense" id="muWolimN_A1">
					<p><span class="ar">مُؤْلِمٌ</span>: <a href="#OaliymN">see <span class="ar">أَلِيمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0082.pdf" target="pdf">
							<span>Lanes Lexicon Page 82</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
