<article class="root" id="Root_Asd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/076_Astbrq">استبرق</a></span>
				<span class="ar">اسد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/078_Asr">اسر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asd_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسد</span></h3>
				<div class="sense" id="Asd_1_A1">
					<p><span class="ar">أَسِدَ</span>, <span class="auth">(Ṣ, M, A, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْسَدُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَسَدٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He</em> <span class="auth">(a man, M)</span> <em>was,</em> or <em>became, like a lion,</em> <span class="auth">(Ṣ, M, A, Ḳ,)</span> <em>in his boldness,</em> <span class="auth">(A,)</span> <em>and his other dispositions;</em> <span class="auth">(Ṣ, A, TA;)</span> <span class="pb" id="Page_0057"></span>as also<span class="arrow"><span class="ar">استأسد↓</span></span>; <span class="auth">(M, A, Ḳ;)</span> <span class="add">[and<span class="arrow"><span class="ar">تأسّد↓</span></span>; (<a href="#OasidN">see <span class="ar">أَسِدٌ</span></a>;)]</span> <span class="ar">عَلَيْهِ</span> <em>towards him,</em> or <em>against him.</em> <span class="auth">(A.)</span> You say <span class="ar long">أَسَدٌ بَيِّنُ الأَسَدِ</span> <span class="add">[<em>A lion bearing evidence of being like a lion in boldness</em>]</span>: an extr. phrase, like <span class="ar long">حِقَّةٌ بَيِنَّةٌ الحِّقَةِ</span>; <span class="auth">(TA;)</span> which is <span class="add">[said to be]</span> the only other instance of the kind. <span class="auth">(TA in art. <span class="ar">حق</span>.)</span> <span class="add">[Hence the saying,]</span> <span class="ar long">إِذَا دَخَلَ فَهِدَ وَإِذَا خَرَجَ أَسِدَ</span> ‡ <span class="add">[<em>When he comes in, he is like a lynx; and when he goes out, he is like a lion:</em> <a href="#fahida">see <span class="ar">فَهِدَ</span></a>]</span>. <span class="auth">(Ṣ, from a trad.)</span> You say also, <span class="ar long">أَسِدَ عَلَيْهِ</span> meaning † <em>He became emboldened against him;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">استأسد↓</span></span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> And † <em>He was,</em> or <em>became, angry with him:</em> <span class="auth">(M, L, Ḳ:*)</span> or <span class="auth">(so accord. to the M and L, but in the Ḳ, “and,”)</span> <em>behaved in a light and hasty manner,</em> or <em>foolishly,</em> or <em>ignorantly, towards him.</em> <span class="auth">(M, L, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asd_1_A2">
					<p><span class="ar">أَسِدَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. as above, <span class="auth">(Ḳ,)</span> and so the inf. n., <span class="auth">(TA,)</span> also signifies † <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>became stupified</em> <span class="auth">(Ṣ, Ḳ)</span> <em>by fear</em> <span class="auth">(Ṣ)</span> <em>at seeing a lion.</em> <span class="auth">(Ṣ, Ḳ.)</span> Thus it has two contr. meanings. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Asd_1_B1">
					<p><span class="ar">أَسَدَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْسِدُ</span>}</span></add>, <em>i. q.</em> <span class="ar">سَبَعَ</span> <span class="add">[† <em>He bit</em> another <em>with his teeth, like as does the beast of prey:</em> or <em>he reviled, vilified,</em> or <em>vituperated,</em> another; <em>charged</em> him <em>with a vice</em> or <em>fault</em> or <em>the like;</em> or <em>assailed</em> him <em>with foul language, such as displeased</em> him]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Asd_1_B2">
					<p><a href="#Asd_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Asd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أسّد</span></h3>
				<div class="sense" id="Asd_2_A1">
					<p><a href="#Asd_4">see 4</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asd_4">
				<h3 class="entry">4. ⇒ <span class="ar">آسد</span></h3>
				<div class="sense" id="Asd_4_A1">
					<p><span class="ar">آسدهُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> or <span class="ar long">آسدهُ بِالصَّيْدِ</span>, <span class="auth">(A,)</span> inf. n. <span class="ar">إِيسَادٌ</span>; <span class="auth">(TA;)</span> and <span class="ar">اوسدهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> in which the <span class="ar">أ</span> <span class="add">[i. e. the second <span class="ar">أ</span>, for <span class="ar">آسدهُ</span> is originally <span class="ar">أَأْسدهُ</span>,]</span> is changed into <span class="ar">و</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">أسدّهُ↓</span></span>; <span class="auth">(Ḳ;)</span> ‡ <em>He incited him</em> <span class="auth">(namely a dog)</span> <em>to the chase.</em> <span class="auth">(Ṣ, M, A, Mṣb, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asd_4_A2">
					<p><span class="ar long">آسد بَيْنَ الكِلَابِ</span> ‡ <em>He incited the dogs to attack one another.</em> <span class="auth">(A.)</span> And <span class="ar long">آسد بَيْنَ القَوْمِ</span>, <span class="auth">(Ṣ, M, A, L, Mṣb,)</span> inf. n. <span class="ar">إِيسَادٌ</span>; <span class="auth">(Mṣb;)</span> or<span class="arrow"><span class="ar">أَسَدَ↓</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْسِدُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> ‡ <em>He excited discord, dissension, disorder, strife, quarrelling,</em> or <em>animosity, between,</em> or <em>among, the people,</em> or <em>company of men.</em> <span class="auth">(Ṣ, M, A, L, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Asd_4_B1">
					<p><span class="ar long">آسد السَّيْرَ</span> <em>He journeyed with energy;</em> syn. <span class="ar">أَسْأَدَهُ</span>; <span class="auth">(IJ, M;)</span> from which it is probably formed by transposition. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Asd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأسّد</span></h3>
				<div class="sense" id="Asd_5_A1">
					<p><a href="#Asd_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asd_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأسد</span></h3>
				<div class="sense" id="Asd_10_A1">
					<p><span class="ar">استأسد</span> <em>He called</em> a lion. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Asd_10_B1">
					<p><a href="#Asd_1">See 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Asd_10_B2">
					<p>† <em>He became accustomed,</em> or <em>habituated,</em> <span class="add">[to a thing, as a dog to the chase,]</span> <em>and emboldened;</em> syn. <span class="ar">ضَرِىَ</span> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Asd_10_B3">
					<p>‡ <em>It</em> <span class="auth">(a plant, or herbage,)</span> <em>became strong, and tangled, or luxuriant:</em> <span class="auth">(Ṣ:)</span> or <em>became tall and large:</em> or <em>grew to its utmost height:</em> <span class="auth">(M:)</span> or <em>attained its full growth, and became tangled,</em> or <em>luxuriant,</em> <span class="auth">(M,)</span> <em>and strong:</em> <span class="auth">(TA:)</span> or <em>became tall, and dry</em> (<span class="ar">جَفَّ</span> <span class="add">[perhaps a mistake for <span class="ar">اِلْتَفَّ</span>, as in the Ṣ and M,]</span>) <em>and large,</em> <span class="auth">(A, TA,)</span> <em>and spread every way:</em> <span class="auth">(A:)</span> or <em>became tall, and attained its full growth.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Asd_10_C1">
					<p><span class="ar">اُسْتُوسِدَ</span> <span class="auth">(Ḳ, TA, <span class="add">[or <span class="ar">اُسْتُؤْسِدَ</span>,]</span> in the CK <span class="ar">اسْتَوْسَدَ</span>)</span> † <em>He</em> <span class="auth">(a man, TA)</span> <em>was,</em> or <em>became, excited, roused, provoked,</em> (<span class="ar">هُيِّجَ</span>, Ḳ, TA, in the CK <span class="ar">هَيَّجَ</span>,) or <em>incited.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasadN">
				<h3 class="entry"><span class="ar">أَسَدٌ</span></h3>
				<div class="sense" id="OasadN_A1">
					<p><span class="ar">أَسَدٌ</span> <span class="add">[The <em>lion;</em>]</span> <em>a certain beast of prey,</em> <span class="auth">(M, TA,)</span> <em>well known:</em> <span class="auth">(M, A, Mṣb, Ḳ:)</span> IKh and others have mentioned more than five hundred names for it; and it is said to have a thousand names <span class="add">[in the Arabic language; but these, with few exceptions, are epithets used as substs.]</span>: <span class="auth">(TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آسُدٌ</span> <span class="auth">(Ṣ, Ḳ <span class="add">[in the TA with two hemzehs, <span class="ar">أَأْسُدٌ</span>, which is the original form, but deviating from the regular pronunciation,]</span>)</span> and <span class="ar">آسَادٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">أُسُودٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أُسُدٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">أُسْدٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> the last two of which are contractions of the form next preceding them, <span class="auth">(Ṣ)</span> and <span class="ar">أُسْدَانٌ</span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">مَأْسَدَةٌ↓</span></span>, <span class="auth">(Mṣb, Ḳ,)</span> the last called by some a pl., but <span class="add">[rightly]</span> said by others to be a quasi-pl. n.: <span class="auth">(TA:)</span> the female is called <span class="ar">أَسَدَةٌ</span>; <span class="auth">(AZ, Ks, Ṣ, M, A, Mṣb, Ḳ;)</span> or <span class="ar">أَسَدٌ</span> is applied to the male and the female, and sometimes the female is called <span class="ar">أَسَدَةٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: <span class="ar">أَسَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasadN_A2">
					<p><span class="ar long">لَقِيتُ مِنْهُ أَسَدًا</span> is a phrase <span class="add">[meaning <em>I found him to be a man of exceeding boldness;</em> being]</span> expressive of an intensive degree of boldness. <span class="auth">(Mughnee in art. <span class="ar">ب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: <span class="ar">أَسَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OasadN_A3">
					<p><span class="ar">الأَسَدُ</span> † <em>The constellation Leo.</em> <span class="auth">(Ḳzw, &amp;c.)</span> <span class="add">[<a href="#AlcBiraAEu">See <span class="ar">الذِّرَاعُ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: <span class="ar">أَسَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OasadN_A4">
					<p>And † <em>The star Cor Leonis,</em> or <em>Regulus.</em> <span class="auth">(Ḳzw, &amp;c.)</span> <span class="add">[<a href="#Aljabohapu">See <span class="ar">الجَبْهَةُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasidN">
				<h3 class="entry"><span class="ar">أَسِدٌ</span></h3>
				<div class="sense" id="OasidN_A1">
					<p><span class="ar">أَسِدٌ</span> ‡ <span class="add">[<em>Like a lion;</em>]</span> <em>bold; daring;</em> as also<span class="arrow"><span class="ar">أَسِيدٌ↓</span></span> and<span class="arrow"><span class="ar">مُتَأَسِّدٌ↓</span></span> <span class="add">[and<span class="arrow"><span class="ar">مُسْتَأْسِدٌ↓</span></span> (<a href="#Asd_10">see 10</a>)]</span>. <span class="auth">(Mṣb.)</span> You say <span class="ar long">أَسَدٌ أَسِدٌ</span> <span class="add">[<em>A bold,</em> or <em>fierce, lion</em>]</span>, adding the latter word to give intensiveness of signification. <span class="auth">(IAạr, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: <span class="ar">أَسِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasidN_A2">
					<p><span class="add">[Its fem.]</span> <span class="ar">أَسِدَةٌ</span> <span class="add">[app. applied to a bitch]</span> signifies † <em>Accustomed,</em> or <em>habituated,</em> <span class="add">[to the chase,]</span> <em>and emboldened;</em> syn. <span class="ar">ضَارِيَةٌ</span>. <span class="auth">(Ḳ, TA, in the CK <span class="ar">صارِيَة</span>.)</span> <span class="add">[<a href="#Asd_10">See also 10</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasidapN">
				<h3 class="entry"><span class="ar">أَسِدَةٌ</span></h3>
				<div class="sense" id="OasidapN_A1">
					<p><span class="ar">أَسِدَةٌ</span> <em>A</em> <span class="add">[<em>kind of enclosure for the protection of camels, sheep,</em> or <em>goats, such as is called</em>]</span> <span class="ar">حَظِيرةَ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[Like <span class="ar">أَصِيدَةٌ</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: <span class="ar">أَسِدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OasidapN_B1">
					<p><span class="add">[<a href="#OasidN">See also <span class="ar">أَسِدٌ</span></a>, of which it is the fem.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusodieBN">
				<h3 class="entry"><span class="ar">أُسْدِىٌّ</span></h3>
				<div class="sense" id="OusodieBN_A1">
					<p><span class="ar">أُسْدِىٌّ</span>, with damm, <span class="auth">(IB, Ḳ,)</span> thus correctly written, <span class="auth">(IB,)</span> in the L <span class="add">[and Ṣ]</span> <span class="ar">أَسْدِىٌّ</span>, <span class="auth">(TA,)</span> <em>A kind of garments</em> or <em>cloths</em> (<span class="ar">ثِيَابٌ</span>, Ṣ, for which is put, in the Ḳ, erroneously, <span class="ar">نَبَاتٌ</span>, TA): occurring in a poem of El-Hoteiäh, <span class="auth">(Ṣ,)</span> who likens thereto an extensive, even, waterless desert. <span class="auth">(L.)</span> IB says that he is in error who mentions it in the present art.: Aboo-ʼAlee says that <span class="ar">أُسْدِىٌّ</span> and <span class="ar">أُسْتِىٌّ</span> are quasi-pls. of <span class="ar">سَدَّى</span> and <span class="ar">سَتًى</span> as signifying <span class="ar long">ثَوْبٌ مَسْدِىٌّ</span>, and originally <span class="ar">أُسْدُوىٌ</span> and <span class="ar">أُسْتُوىٌ</span>; like as <span class="ar">أُمْعُوزٌ</span> is a quasi-<a href="#maEozN">pl. of <span class="ar">مَعْزٌ</span></a>. <span class="auth">(L.)</span> <span class="add">[<a href="index.php?data=12_s/074_sdw">But see art. <span class="ar">سدو</span></a> <a href="../">and <span class="ar">سدى</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasiydN">
				<h3 class="entry"><span class="ar">أَسِيدٌ</span></h3>
				<div class="sense" id="OasiydN_A1">
					<p><span class="ar">أَسِيدٌ</span>: <a href="#OasidN">see <span class="ar">أَسِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisaAdapN">
				<h3 class="entry"><span class="ar">إِسَادَةٌ</span></h3>
				<div class="sense" id="IisaAdapN_A1">
					<p><span class="ar">إِسَادَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أُسَادَةٌ</span> <span class="auth">(Ḳ)</span> <em>i. q.</em> <span class="ar">وِسَادَةٌ</span> <span class="add">[<em>A pillow,</em>, &amp;c.]</span>: <span class="auth">(Ṣ, Ḳ:)</span> like <span class="ar">إِشَاحٌ</span> for <span class="ar">وِشَاحٌ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWosidN">
				<h3 class="entry"><span class="ar">مُؤْسِدٌ</span></h3>
				<div class="sense" id="muWosidN_A1">
					<p><span class="ar">مُؤْسِدٌ</span> ‡ One <em>who trains a dog,</em> or <em>dogs, to the chase.</em> <span class="auth">(L, Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOosadapN">
				<h3 class="entry"><span class="ar">مَأْسَدَةٌ</span></h3>
				<div class="sense" id="maOosadapN_A1">
					<p><span class="ar">مَأْسَدَةٌ</span> <em>A place in which are lions:</em> <span class="auth">(Mṣb, Ḳ:)</span> or <span class="ar long">أَرْضٌ مَأْسَدَةٌ</span> <em>a land having lions in it:</em> <span class="auth">(Ṣ, A:)</span> or <em>a land abounding with lions:</em> <span class="auth">(M, R:)</span> pl. <span class="ar">مَآسِدُ</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسد</span> - Entry: <span class="ar">مَأْسَدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOosadapN_A2">
					<p><a href="#OasadN">See also <span class="ar">أَسَدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOasBidN">
				<h3 class="entry"><span class="ar">مُتَأَسِّدٌ</span></h3>
				<div class="sense" id="mutaOasBidN_A1">
					<p><span class="ar">مُتَأَسِّدٌ</span>: <a href="#OasidN">see <span class="ar">أَسِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="musotaOosidN">
				<h3 class="entry"><span class="ar">مُسْتَأْسِدٌ</span></h3>
				<div class="sense" id="musotaOosidN_A1">
					<p><span class="ar">مُسْتَأْسِدٌ</span>: <a href="#OasidN">see <span class="ar">أَسِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0057.pdf" target="pdf">
							<span>Lanes Lexicon Page 57</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
