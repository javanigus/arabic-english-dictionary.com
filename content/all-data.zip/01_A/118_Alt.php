<article class="root" id="Root_Alt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/117_Alb">الب</a></span>
				<span class="ar">الت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/119_Ald">الد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alt_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألت</span></h3>
				<div class="sense" id="Alt_1_A1">
					<p><span class="ar">أَلَتَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِتُ</span>}</span></add>, inf. n.<span class="ar">أَلْتٌ</span>, <em>It</em> <span class="auth">(a thing)</span> <em>decreased; diminished; lessened; became defective, deficient, incomplete, or imperfect.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alt_1_B1">
					<p><span class="ar long">أَلَتَهُ حَقَّهُ</span>, <span class="auth">(Ṣ, M, A, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِتُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَلْتٌ</span> <span class="auth">(Ṣ, M)</span> and <span class="ar">إِلَاتَهُ</span>; <span class="auth">(M;)</span> and <span class="ar">أَلِتَهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَتُ</span>}</span></add>; <span class="auth">(Fr;)</span> and<span class="arrow"><span class="ar">آلتهُ↓</span></span> <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">إِيلَاتٌ</span>; <span class="auth">(Ḳ;)</span> as also <span class="ar">أَلَاتَهُ</span>, inf. n. <span class="ar">إِلَاتٌ</span>, <span class="auth">(so in a MṢ. copy of the Ḳ,)</span> or <span class="ar">إِلَاتَةٌ</span>; <span class="auth">(so in the L: <span class="add">[agreeably with analogy, and therefore probably the correct reading: <a href="index.php?data=23_l/187_lyt">see art. <span class="ar">ليت</span></a>, to which it belongs: in SM's copy of the Ḳ, and in the CK, the verb is written <span class="ar">أَلْأَتَهُ</span>, and the inf. n. <span class="ar">إِلْآتٌ</span>: by MF, the verb is written <span class="arrow"><span class="ar">آلَتَهُ↓</span></span>, of the measure <span class="ar">فَاعَلَ</span> and the inf. n. <span class="ar">إِلَاتٌ</span> like <span class="ar">قِتَالٌ</span>:]</span>)</span> <span class="add">[and <span class="ar">لَاتَهُ</span>, aor. <span class="ar">يَلِيتٌ</span>; and <span class="ar">وَلَتَهُ</span>; and <span class="ar">أَوْلَتَهُ</span>;]</span> <em>He diminished to him his right, or due; abridged him, or defrauded him, of a portion of it:</em> <span class="auth">(Fr, Ṣ, M, A, Ḳ:)</span> and in like manner, <span class="ar long">أَلَتَهُ مَالَهُ</span> and<span class="arrow"><span class="ar">آلتهُ↓</span></span>, &amp;c., <em>he diminished to him his property; or abridged him, or defrauded him, of a portion of it:</em> <span class="auth">(M, TA:)</span> and <span class="ar long">أَلَتَ الشَّىْءَ</span> <em> he diminished the thing.</em> <span class="auth">(Mṣb.)</span> <span class="add">[Hence,]</span> <span class="ar long">مَا أَلْتَنَاهُمْ مِنْ عَمَلِهِمْ مِنْ شَىْءٍ</span> <span class="add">[in the Ḳur lii. 21, <em>We will not diminish to them aught of</em> the reward <em>of their work</em>]</span>: <span class="auth">(T, A:)</span> or, accord. to one reading, <span class="auth">(that of Ibn-Ketheer, TA,)</span> <span class="ar long">ما أَلِتْنَاهُمْ</span>. <span class="auth">(T, TA.)</span> <span class="add">[<a href="index.php?data=23_l/187_lyt">See also art. <span class="ar">ليت</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Alt_1_C1">
					<p><span class="ar">أَلَتَهُ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> or <span class="ar long">أَلَتَهُ عَنْ وَجْهِهِ</span>, <span class="auth">(TA,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِتُ</span>}</span></add>; <span class="auth">(T;)</span> as also <span class="ar">لَاتَهُ</span>; these being two dial. vars. one of the other, mentioned by Yz, on the authority of AA; <span class="auth">(Ṣ;)</span> <span class="add">[and <span class="ar">أَلَاتَهُ</span>; (<a href="index.php?data=23_l/187_lyt">see art. <span class="ar">ليت</span></a>;)]</span> <em>He withheld him, or restrained him,</em> <span class="auth">(Ṣ, Ḳ,)</span> and <em>turned him, or averted him,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> <em>from his course, purpose, or object.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الت</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Alt_1_D1">
					<p><span class="ar">أَلَتَهُ</span>, <span class="auth">(M, Ḳ,)</span> or <span class="ar long">أَلَتَهُ يَمِينًا</span>, <span class="auth">(Aṣ, T, Ṣ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِتُ</span>}</span></add>, inf. n. <span class="ar">أَلْتٌ</span>, <em>He made him to swear, or take an oath:</em> <span class="auth">(Aṣ, T, Ṣ, Ḳ:)</span> or <em>he desired of him that he should swear, or give his testimony, for him.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">أَلَتَهُ بِيَمِينٍ</span>, inf. n. as above, <em>He pressed him,</em> or <em>pressed hard upon him, with an oath.</em> <span class="auth">(M.)</span> It is related that a man said to ʼOmar, “Fear God, O prince of the faithful:” and another, hearing him, said, <span class="ar long">أَتَأْلِتُ عَلَى أَمِيرِ المُؤْمِنِينَ</span>, meaning <em>Dost thou lower the dignity of the prince of the faithful? or dost thou diminish to him</em> <span class="add">[<em>the respect that is due to him</em>]</span>? accord. to IAạr.: or rather, <em>dost thou conjure the prince of the faithful?</em> his saying “Fear God” being as though he conjured him by God: for the Arabs say, <span class="ar long">أَلَتُّكَ بِٱللّٰهِ لَمَّا فَعَلْتَ كَذَا</span>, meaning <em>I conjure thee by God but that thou do thus, or such a thing.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alt_3">
				<h3 class="entry">3. ⇒ <span class="ar">آلت</span></h3>
				<div class="sense" id="Alt_3_A1">
					<p><a href="#Alt_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alt_4">
				<h3 class="entry">4. ⇒ <span class="ar">آلت</span></h3>
				<div class="sense" id="Alt_4_A1">
					<p><a href="#Alt_1">see 1</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalotN">
				<h3 class="entry"><span class="ar">أَلْتٌ</span></h3>
				<div class="sense" id="OalotN_A1">
					<p><span class="ar">أَلْتٌ</span> <em>Deficiency:</em> as in the saying, <span class="ar long">مَا فِى مَزَاوِدِهِمْ أَلْتٌ</span> <span class="add">[<em>There is not, in their provision-bags, any deficiency</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الت</span> - Entry: <span class="ar">أَلْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OalotN_B1">
					<p><em>A swearing;</em> syn. <span class="ar">حَلِفٌ</span> <span class="auth">(M, TA.)</span> <span class="add">[Perhaps an inf. n. in this sense.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الت</span> - Entry: <span class="ar">أَلْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OalotN_B2">
					<p><em>An oath:</em> as in the saying, when one has not given thee thy right, or due, <span class="ar long">قَيِّدْهُ بِالْأَلْتِ</span> <span class="add">[<em>Bind thou him by oath</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الت</span> - Entry: <span class="ar">أَلْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OalotN_C1">
					<p><em>Calumny, slander,</em> or <em>false accusation.</em> <span class="auth">(Kr, M, Ḳ.)</span> <span class="add">[Perhaps an inf. n. in this sense also.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OulotapN">
				<h3 class="entry"><span class="ar">أُلْتَةٌ</span></h3>
				<div class="sense" id="OulotapN_A1">
					<p><span class="ar">أُلْتَةٌ</span> <em>A small gift.</em> <span class="auth">(AA, T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الت</span> - Entry: <span class="ar">أُلْتَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OulotapN_B1">
					<p><em>An oath such as is termed</em> <span class="ar">غَمُوس</span>, q. v. <span class="auth">(AA, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0079.pdf" target="pdf">
							<span>Lanes Lexicon Page 79</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
