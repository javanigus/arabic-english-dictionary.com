<article class="root" id="Root_Avr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/018_Av">اث</a></span>
				<span class="ar">اثر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/020_Avf">اثف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Avr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أثر</span></h3>
				<div class="sense" id="Avr_1_A1">
					<p><span class="ar long">أَثَرَ خُفَّ البَعِيرِ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُرُ</span>}</span></add>, inf. n. <span class="ar">أَثْرٌ</span>, <em>He made an incision in the foot of the camel</em> <span class="add">[<em>in order to know and trace the footprints</em>]</span>; as also<span class="arrow"><span class="ar">أثّرهُ↓</span></span>. <span class="auth">(M.)</span> And <span class="ar long">أَثَرَ البَعِيرِ</span> <em>He made a mark upon the bottom of the camel's foot with the iron instrument called</em> <span class="ar">مِئْثَرَة</span> <em>in order that the footprints upon the ground might be known:</em> <span class="auth">(T, TT:)</span> or <em>he scraped the inner</em> <span class="add">[i. e. <em>under</em>]</span> <em>part of the camel's foot with that instrument in order that the footprints might be traced.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avr_1_A2">
					<p><span class="ar long">أَثَرَ الحَدِيثَ</span>, <span class="auth">(T, Ṣ, M, A, &amp;c.,)</span> <span class="ar long">عَنِ القَوْمِ</span>, <span class="auth">(M,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُرُ</span>}</span></add> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِرُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">أَثْرٌ</span><span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَثَارَهٌ</span> and <span class="ar">أُثْرَهٌ</span>, <span class="auth">(M, Ḳ,)</span> the last from Lḥ, but in my opinion, <span class="add">[says ISd,]</span> it is correctly speaking a subst., and syn. with <span class="ar">مَأْثُرَهٌ</span> and <span class="ar">مَأْثَرَهٌ</span>, <span class="auth">(M,)</span> <em>He related,</em> or <em>recited, the tradition, narrative,</em> or <em>story, as received,</em> or <em>heard, from the people; transmitted the narrative,</em> or <em>story, by tradition, from the people:</em> <span class="auth">(T, Ṣ,* M, A, L, Mṣb,* Ḳ:*)</span> or <em>he related that wherein they had preceded</em> <span class="add">[<em>as narrators:</em> so I render <span class="ar long">أَنْبَأَهُمْ بِمَا سَبَقُوا فِيهِ</span>, believing <span class="ar">هم</span> to have been inserted by a mistake of a copyist in the M, and hence in the L also:]</span> from <span class="ar">الأَثَرُ</span>. <span class="auth">(M, L.)</span> <span class="add">[<a href="#OavarN">See <span class="ar">أَثَرٌ</span></a>.]</span> You say also, <span class="ar long">أثَرَ عَنْهُ الكَذِبَ</span>, meaning <em>He related, as heard from him, what was false.</em> <span class="auth">(L, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Avr_1_A3">
					<p><span class="ar">أَثْرٌ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُرُ</span>}</span></add>, <span class="auth">(M,)</span> inf. n. <span class="ar">أَثْرٌ</span>, <span class="auth">(M, Ḳ.)</span> also signifies <em>Multum inivit</em> camelus camelam. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avr_1_B1">
					<p><span class="ar long">أَثِرَ لِلْأَمْرِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْثَرُ</span>}</span></add>, <em>He applied,</em> or <em>gave, his whole attention to the thing,</em> or <em>affair, having his mind unoccupied by other things.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Avr_1_B2">
					<p><span class="ar long">أَثِرَ عَلَى الْأَمْرِ</span> <em>He determined, resolved,</em> or <em>decided, upon the thing,</em> or <em>affair.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Avr_1_B3">
					<p><span class="ar long">لَقَدْ أَثِرْتُ أَنْ أَفْعَلَ كَذَا و كَذَا</span>, <span class="auth">(Lth, T, L,)</span> inf. n. <span class="ar">أَثْرٌ</span> and <span class="ar">أَثَرٌ</span>, <span class="auth">(L,)</span> <em>I have assuredly purposed to do such and such things.</em> <span class="auth">(Lth, T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Avr_1_B4">
					<p><a href="#Avr_4">See also 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="Avr_1_B5">
					<p><a href="#Avr_10">And see 10</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أثّر</span></h3>
				<div class="sense" id="Avr_2_A1">
					<p><span class="ar long">أثّر فِيهِ</span>, inf. n. <span class="ar">تَأْثِيرٌ</span>, <em>He,</em> or <em>it, made,</em> <span class="auth">(Mṣb,)</span> or <em>left,</em> <span class="auth">(M, Ḳ,)</span> or <em>caused to remain,</em> <span class="auth">(Ṣ,)</span> <em>an impression,</em> or <em>a mark,</em> or <em>trace, upon him,</em> or <em>it.</em> <span class="auth">(Ṣ,* M, Mṣb, Ḳ.*)</span> It is said of a sword, <span class="add">[meaning <em>It made,</em> or <em>left, a mark,</em> or <em>scar, upon him,</em> or <em>it,</em>]</span> and in like manner of a blow. <span class="auth">(T, TA.)</span> <span class="add">[Whence,]</span> <span class="ar long">أَثَّرَ فِى عِرْضِهِ</span> cross; <span class="add">[<em>He scarred his honour</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">وخش</span>.)</span> You say also, <span class="ar long">أَثَّرَ بِوَجْهِهِ وَبِجَبِينِهِ السُّجُودُ</span> <span class="add">[<em>Prostration in prayer made,</em> or <em>left, a mark,</em> or <em>marks, upon his face and upon his forehead</em>]</span>. <span class="auth">(T,* TA.)</span> <a href="#Avr_1">See also 1</a>, first sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avr_2_A2">
					<p><em>He,</em> or <em>it, made an impression,</em> or <em>produced an effect, upon him,</em> or <em>it; impressed, affected,</em> or <em>influenced, him,</em> or <em>it.</em> <span class="auth">(The Lexicons passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Avr_2_A3">
					<p><span class="ar long">أَثَّرَ كَذَا بِكَذَا</span>, <span class="auth">(T, TT,)</span> or<span class="arrow"><span class="ar">آثَرَ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>He,</em> or <em>it, made such a thing to be followed by such a thing.</em> <span class="auth">(T, TT, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avr_4">
				<h3 class="entry">4. ⇒ <span class="ar">آثر</span></h3>
				<div class="sense" id="Avr_4_A1">
					<p><a href="#Avr_2">see 2</a>, last sentence.</p>						
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avr_4_A2">
					<p><span class="add">[Hence, app.,]</span> <span class="ar">آثرهُ</span>, <span class="auth">(Aṣ, T, M, Mṣb,)</span> inf. n. <span class="ar">إِيثَارٌ</span>, <span class="auth">(Aṣ, T,)</span> <em>He preferred him,</em> or <em>it.</em> <span class="auth">(Aṣ, T, M, Mṣb, TA.)</span> You say, <span class="ar long">آثرهُ عَلَيْهِ</span> <em>He preferred him before him:</em> so in the Ḳur xii. 91. <span class="auth">(Aṣ, M.)</span> And <span class="ar long">آثَرْتُ فُلاَنًا عَلَى نَفْسِى</span> <span class="add">[<em>I preferred such a one before myself</em>]</span>, from <span class="ar">الإِيثَار</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">قَدْ آثَرْتُكَ</span> <em>I have preferred for thee it; I have preferred to give thee it, rather than any other thing.</em> <span class="auth">(T.)</span> And <span class="ar long">آثَرَ أَنْ يَفْعَلَ كَذَا</span> <em>He preferred doing such a thing;</em> as also<span class="arrow"><span class="ar">أَثِرَ↓</span></span>, inf. n. <span class="ar">أَثَرٌ</span>; and <span class="ar">أَثَرَ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Avr_4_A3">
					<p><span class="ar">آثر</span> also signifies <em>He chose,</em> or <em>elected,</em> or <em>selected.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Avr_4_A4">
					<p>And <span class="ar">آثِرهُ</span> <em>He honoured him; paid him honour.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأثّر</span></h3>
				<div class="sense" id="Avr_5_A1">
					<p><span class="ar">تأثّر</span> <em>It received an impression,</em> or <em>a mark,</em> or <em>trace; became impressed,</em> or <em>marked.</em> <span class="auth">(Mṣb.)</span></p>						
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avr_5_A2">
					<p><em>He,</em> or <em>it, had an impression made,</em> or <em>an effect produced, upon him,</em> or <em>it; became impressed, affected,</em> or <em>influenced.</em> <span class="auth">(The Lexicons passim.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avr_5_B1">
					<p><a href="#Avr_8">See also 8</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتثر</span></h3>
				<div class="sense" id="Avr_8_A1">
					<p><span class="ar">ائْتَثَرَهُ</span>, <span class="add">[written with the disjunctive alif <span class="ar">اِيتَثَرَهُ</span>,]</span> and<span class="arrow"><span class="ar">تأثّرهُ↓</span></span>, <em>He followed his footsteps:</em> <span class="auth">(M, Ḳ:)</span> or <em>did so diligently,</em> or <em>perseveringly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأثر</span></h3>
				<div class="sense" id="Avr_10_A1">
					<p><span class="ar long">استأثر عَلَى أَصْحَابِهِ</span>; <span class="auth">(ISk, Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar long">أَثِرَ↓ عَلَيْهِمْ</span></span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْثَرُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> <em>He chose for himself</em> <span class="add">[<em>in preference to his companions</em>]</span> <span class="auth">(ISk, Ṣ, Ḳ)</span> <em>good things,</em> <span class="auth">(Ḳ,)</span> <em>in partition,</em> <span class="auth">(TA,)</span> or <em>good actions, and qualities of the mind.</em> <span class="auth">(ISk, Ṣ.)</span> And <span class="ar long">استأثر بالشَّىْءِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">الشَّىْءَ</span>, <span class="auth">(Mṣb,)</span> <em>He had the thing to himself, with none to share with him in it:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> and the former signifies <em>he appropriated the thing to himself exclusively,</em> <span class="auth">(M, Ḳ,)</span> <span class="ar long">عَلَى غَيْرِهِ</span> <em>in preference to another</em> or <em>others.</em> <span class="auth">(M.)</span> It is said in a trad., <span class="ar long">إِذَا اسْتَأْثَرَ ٱللّٰهُ بِشَىْءٍ فَالْهَ عَنُهُ</span> <em>When God appropriateth a thing to Himself exclusively, then be thou diverted from it so as to forget it.</em> <span class="auth">(M.)</span> And one says, <span class="ar long">اِسْتأْثَرَ ٱللّٰهُ بِفُلَانٍ</span>, <span class="auth">(and <span class="ar">فُلَانًا</span>, TA,)</span> <span class="add">[<em>God took such a one to Himself,</em>]</span> when a person has died and it is hoped that he is forgiven. <span class="auth">(Ṣ, M, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavorN">
				<h3 class="entry"><span class="ar">أَثْرٌ</span></h3>
				<div class="sense" id="OavorN_A1">
					<p><span class="ar">أَثْرٌ</span>, <span class="auth">(AZ, T, Ṣ, A, L, Ḳ, &amp;c.,)</span> said by Yaạḳoob to be the only form known to Aṣ, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">أَثَرٌ↓</span></span>, which is a form used by poetic licence, <span class="auth">(M, L,)</span> and<span class="arrow"><span class="ar">أثْرَةٌ↓</span></span>, <span class="auth">(M, L, Ḳ,)</span> and<span class="arrow"><span class="ar">أُثُرٌ↓</span></span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">أُثُرٌ↓</span></span>, which is in like manner a sing., not a pl., <span class="auth">(T, L,)</span> and<span class="arrow"><span class="ar">أثْرَةٌ↓</span></span>, <span class="auth">(El-Leblee,)</span> and<span class="arrow"><span class="ar">أَثِيرْ↓</span></span>, <span class="auth">(Ḳ,)</span> The <em>diversified wavy marks, streaks,</em> or <em>grain,</em> of a sword; syn. <span class="ar">فِرِنْدٌ</span>; <span class="auth">(Aṣ, T, Ṣ, M, A, L, Ḳ;)</span> and <span class="ar">تَسَلْسُلٌ</span>; and <span class="ar">دِيبَاجَةُ</span>; <span class="auth">(AZ, T;)</span> and its <em>lustre,</em> or <em>glitter:</em> <span class="auth">(M, L:)</span> pl. <span class="add">[of the first]</span> <span class="ar">أُثُرْ</span>: <span class="auth">(T, M, L, Ḳ:)</span> <a href="#OuvorapN">the pl. of <span class="ar">أُثْرَةٌ</span></a> is <span class="ar">أُثَرٌ</span>. <span class="auth">(El-Leblee.)</span> Khufáf Ibn-Nudbeh Es-Sulamee says, <span class="add">[describing swords,]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">جَلَاهَا الصَّيْقَلُونَ فَإَخْلَصُوهَا</span> *</div> 
						<div class="star">* <span class="ar long">خِفَافاً كُلُّهَا يَتْقِى بِأَثْرِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>The furbishers polished them, and freed them from impurities,</em> making them <em>light: each of them preserving itself</em> from the evil eye <em>by means of</em> its <em>lustre</em>]</span>: i. e., each of them opposes to thee its <span class="ar">فِرِنْد</span>: <span class="auth">(Ṣ, L:)</span> <span class="ar">يَتْقِى</span> is a contraction of <span class="ar">يَتَّقِى</span>; and the meaning is, when a person looks at them, their bright rays meet his eye, so that he cannot continue to look at them. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuvorN">
				<h3 class="entry"><span class="ar">أُثْرٌ</span></h3>
				<div class="sense" id="OuvorN_A1">
					<p><span class="ar">أُثْرٌ</span> The <em>scar of a wound, remaining when the latter has healed;</em> <span class="auth">(Aṣ, Sh, T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أُثُرٌ↓</span></span><span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">أَثَرٌ↓</span></span>: <span class="auth">(Sh, T:)</span> pl. <span class="ar">آثَارٌ</span>, though properly <span class="ar">إِثَارٌ</span>, with kesr to the <span class="ar">ا</span> <span class="add">[but why this is said, I do not see; for <span class="ar">آثَارٌ</span> is a regular pl. of all the three forms of the sing.;]</span> and <span class="ar">إُثُورٌ</span> may be correctly used as a pl. <span class="auth">(Sh, T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuvorN_A2">
					<p><em>A mark made with a hot iron upon the inner</em> <span class="add">[i. e. <em>under</em>]</span> <em>part of a camel's foot, by which to trace his footprints:</em> <span class="auth">(M, Ḳ:)</span> pl. <span class="ar">أُثُورٌ</span>. <span class="auth">(M.)</span> <span class="add">[<a href="#OuvorapN">See also <span class="ar">أُثْرَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OuvorN_A3">
					<p><em>Lustre,</em> or <em>brightness,</em> of the face; as also<span class="arrow"><span class="ar">أُثُرٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OuvorN_A4">
					<p><a href="#OavorN">See <span class="ar">أَثْرٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OuvorN_B1">
					<p><a href="#IivorN">See also <span class="ar">إِثْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IivorN">
				<h3 class="entry"><span class="ar">إِثْرٌ</span></h3>
				<div class="sense" id="IivorN_A1">
					<p><span class="ar">إِثْرٌ</span>: <a href="#OavarN">see <span class="ar">أَثَرٌ</span></a>, in three places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">إِثْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IivorN_A2">
					<p><a href="#OavorN">and <span class="ar">أَثْرٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">إِثْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IivorN_A3">
					<p><a href="#AvirN">and see <span class="ar">آثِرٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">إِثْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IivorN_B1">
					<p>Also, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">أُثْرٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> but the latter is disallowed by more than one authority, <span class="auth">(TA,)</span> <em>What is termed the</em> <span class="ar">خُلَاصَة</span> <span class="add">[q. v.]</span> <em>of clarified butter:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or, as some say, the <em>milk when the clarified butter has become separated from it.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#qiXodapN">See also <span class="ar">قِشْدَةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavarN">
				<h3 class="entry"><span class="ar">أَثَرٌ</span></h3>
				<div class="sense" id="OavarN_A1">
					<p><span class="ar">أَثَرٌ</span> <em>A remain,</em> or <em>relic,</em> of a thing; <span class="auth">(M, Mṣb, Ḳ;)</span> as of a house; as also<span class="arrow"><span class="ar">أَثَارَةٌ↓</span></span>: <span class="auth">(Mṣb:)</span> <em>a trace remaining</em> of a thing; and of the stroke, or blow, of a sword: <span class="auth">(Ṣ:)</span> <a href="#OuvorN">see also <span class="ar">أُثْرٌ</span></a>: <em>a sign, mark,</em> or <em>trace;</em> opposed to the <span class="ar">عَيْن</span>, or thing itself: <span class="auth">(TA:)</span> <em>a footstep, vestige,</em> or <em>track; a footprint;</em> the <em>impression,</em> or <em>mark, made by the foot of a man</em> <span class="add">[<em>&amp;c.</em>]</span> <em>upon the ground;</em> as also<span class="arrow"><span class="ar">إِثْرٌ↓</span></span>: and <em>an impress,</em> or <em>impression,</em> of anything: <span class="auth">(El-Wáʼee:)</span> pl. <span class="ar">آثَارٌح</span><span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">إُثُورٌ</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[The sing. is also frequently used in a pl. sense: and the former of these pls. is often used to signify <em>Remains,</em> or <em>monuments,</em> or <em>memorials, of antiquity,</em> or <em>of any past time.</em>]</span> <span class="pb" id="Page_0019"></span>It is said in a prov., <span class="ar long">لَا أَطْلُبُ أَثَرًا بَعْدَ عَيْنٍ</span> <em>I will not seek a trace,</em> or <em>vestige,</em> <span class="add">[or, as we rather say in English, <em>a shadow,</em>]</span> <em>after</em> suffering <em>a reality,</em> or <em>substance,</em> to escape me: or, as some relate it, <span class="ar long">لَا تَطْلُبْ</span> <em>seek not thou.</em> <span class="auth">(Ḥar pp. 120 and 174.)</span> And one says, <span class="ar long">قَطَعَ ٱللّٰهُ أَثَرَهُ</span> <span class="add">[<em>May God cut short his footsteps</em>]</span>: meaning may <em>God render him crippled:</em> for when one is crippled, his footsteps cease. <span class="auth">(TA.)</span> And <span class="ar long">فُلَانٌ لَيَصْدُقُ أَثَرُهُ</span>, and <span class="ar">أَثَرَهُ</span>, <em>Such a one,</em> if asked, <em>will not tell thee truly whence he comes:</em> <span class="auth">(M in art. <span class="ar">صدق</span>:)</span> a prov. said of a liar. <span class="auth">(TA.)</span> And <span class="ar">خَرَجْتُ</span>, <span class="auth">(Ṣ, M,* Ḳ,)</span> and <span class="ar">جَئْتُ</span>, <span class="auth">(El-Wáʼee, Mṣb,)</span> <span class="ar long">فيِ أَثَرِهِ</span>, and<span class="arrow"><span class="ar long">فى إِثْرِهِ↓</span></span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> the former of which is said by more than one to be the more chaste, <span class="auth">(TA,)</span> <span class="add">[but the latter seems to be the more common,]</span> and <span class="ar long">عَلَى أَثَرِهِ</span>, and<span class="arrow"><span class="ar long">على إِثْرِهِ↓</span></span>, <span class="auth">(El-Wáʼee, Mṣb,)</span> <em>I went out,</em> <span class="auth">(Ṣ, &amp;c.,)</span> and <em>I came,</em> <span class="auth">(El-Wáʼee, Mṣb,)</span> <em>after him:</em> <span class="auth">(M, A, Ḳ:)</span> or <em>at his heel:</em> <span class="auth">(Expos. of the Fṣ:)</span> or <em>following near upon him,</em> or <em>hard upon him,</em> or <em>near after him,</em> or <em>following him nearly:</em> <span class="auth">(Mṣb:)</span> <em>as though treading in his footsteps.</em> <span class="auth">(El-Wáʼee.)</span> And <span class="ar long">أَثَرَ ذِى أَثِيرَيْنِ</span>: <a href="#AvirN">see <span class="ar">آثِرٌ</span></a>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavarN_A2">
					<p><em>An impress</em> or <em>impression, a mark, stamp, character,</em> or <em>trace, in a fig. sense; an effect.</em> <span class="auth">(The Lexicons passim.)</span> You say, <span class="ar long">عَلَى مَاشِيَتِهِ أَثَرٌ حَسَنٌ</span> <em>Upon his camels,</em> or <em>sheep,</em> or <em>goats, is an impress of a good state,</em> or <em>condition; of fatness, and of good tending;</em> like <span class="ar">إِصْبَعٌ</span>. <span class="auth">(TA in art. <span class="ar">صبع</span>.)</span> And <span class="ar long">إِنَّهُ لَحَسَنُ الأَثَرِفِى مَالِهِ</span> <em>Verily he has the impress of a good state,</em> or <em>condition, in his camels,</em> or <em>sheep,</em> or <em>goats;</em> like <span class="ar long">حَسَنُ الإِصْبَعِ</span>, and <span class="ar">المَسِ</span>. <span class="auth">(TA ubi suprà.)</span> And <span class="ar long">عَلَيْهِ أَثَرُ كَذَا</span> <em>He,</em> or <em>it, bears the mark, stamp, character,</em> or <em>trace, of such a thing.</em> <span class="auth">(The Lexicons passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OavarN_A3">
					<p><span class="add">[The pl.]</span> <span class="ar">آثَارٌ</span> also signifies <em>Signs,</em> or <em>marks, set up to show the way.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OavarN_A4">
					<p>Also the sing., <em>i. q.</em> <span class="ar">أَثْرٌ</span>, q. v. <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OavarN_A5">
					<p>Also <em>i. q.</em> <span class="ar">خَبَرٌ</span> <span class="add">[both of which words are generally held to be syn., as meaning <em>A tradition,</em> or <em>narration relating or describing a saying or an action, &amp;c., of Moḥammad</em>]</span>: <span class="auth">(M, Ḳ:)</span> or, accord. to some, the former signifies <em>what is related as received from</em> <span class="add">[<em>one or more of</em>]</span> <em>the Companions of Moḥammad;</em> <span class="auth">(TA;)</span> but it may also be applied to <em>a saying of the Prophet;</em> <span class="auth">(Kull p. 152;)</span> and the latter, what is from Moḥammad himself; <span class="auth">(TA;)</span> or from another; or from him or another: <span class="auth">(Kull p. 152:)</span> or the former signifies <em>i. q.</em> <span class="ar">سُنَّةٌ</span> <span class="add">[<em>a practice or saying,</em> or the <em>practices and sayings collectively, of Moḥammad, or any other person who is an authority in matters of religion, namely, any prophet, or a Companion of Moḥammad, as handed down by tradition</em>]</span>: <span class="auth">(Ṣ, A:)</span> pl. <span class="ar">آثَارٌ</span>. <span class="auth">(Ṣ, M.)</span> You say, <span class="ar long">وَجَدْتُهُ فِى الأَثَرِ</span> <span class="add">[<em>I found it in the traditions of the practices and sayings of the Prophet;, &amp;c.</em>]</span>: and <span class="ar long">فُلَانٌ مِنْ حَمَلَةِ الآثَارِ</span> <span class="add">[<em>Such a one is of those who bear in their memories, knowing by heart, the traditions of the practices and sayings of the Prophet;</em>, &amp;c.]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OavarN_A6">
					<p>A man's <em>origin;</em> as in the sayings, <span class="ar long">مَا يُدْرَى لَهُ أَيْنَ أَثَرٌ</span> <em>It is not known where was his origin;</em> and <span class="ar long">مَا يُدْرَى لَهُ مَا أثَرٌ</span> <em>It is not known what is his origin.</em> <span class="auth">(Ks, Lḥ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OavarN_A7">
					<p>The <em>term,</em> or <em>period, of life:</em> so called because it follows life: <span class="auth">(Mṣb, TA:)</span> or from the same word as signifying the print of one's foot upon the ground; because when one dies, his footprints cease to be seen. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OavarN_A8">
					<p><span class="add">[For the former of these two reasons,]</span> <span class="ar">آثَارَهُمْ</span> in the Ḳur xxxvi. 11 means <em>The rewards and punishments of their good and evil lives.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OavarN_B1">
					<p><span class="ar">آثَارٌ</span> is also <a href="#vaOorN">a pl. of <span class="ar">ثَأْرٌ</span>, q. v.</a>; formed by transposition from <span class="ar">أَثْآرٌ</span>. <span class="auth">(Yaạḳoob, and M in art. <span class="ar">ثأر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavurN">
				<h3 class="entry"><span class="ar">أَثُرٌ</span></h3>
				<div class="sense" id="OavurN_A1">
					<p><span class="ar">أَثُرٌ</span> A man <em>who chooses for himself</em> <span class="add">[in preference to his companions]</span> <span class="auth">(ISk, Ṣ, M, Ḳ)</span> <em>good things,</em> <span class="auth">(Ḳ,)</span> <em>in partition,</em> <span class="auth">(M, TA,)</span> or <em>good actions, and qualities of the mind;</em> <span class="auth">(ISk, Ṣ;)</span> as also<span class="arrow"><span class="ar">أَثِرٌ↓</span></span> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OavirN">
				<h3 class="entry"><span class="ar">أَثِرٌ</span></h3>
				<div class="sense" id="OavirN_A1">
					<p><span class="ar">أَثِرٌ</span>: <a href="#OavurN">see <span class="ar">أَثُرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuvurN">
				<h3 class="entry"><span class="ar">أُثُرٌ</span></h3>
				<div class="sense" id="OuvurN_A1">
					<p><span class="ar">أُثُرٌ</span>: <a href="#OuvorN">see <span class="ar">أُثْرٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثُرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuvurN_A2">
					<p><a href="#OavorN">and see <span class="ar">أَثْرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OavorapN">
				<h3 class="entry"><span class="ar">أَثْرَةٌ</span></h3>
				<div class="sense" id="OavorapN_A1">
					<p><span class="ar">أَثْرَةٌ</span>: <a href="#OavaArapN">see <span class="ar">أَثَارَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuvorapN">
				<h3 class="entry"><span class="ar">أُثْرَةٌ</span></h3>
				<div class="sense" id="OuvorapN_A1">
					<p><span class="ar">أُثْرَةٌ</span>: <a href="#OavaArapN">see <span class="ar">أَثَارَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuvorapN_A2">
					<p><em>A mark which is made by the Arabs of the desert upon the inner</em> <span class="add">[i. e. <em>under</em>]</span> <em>part of a camel's foot;</em> as also<span class="arrow"><span class="ar">تَأْثُورٌ↓</span></span>, and, accord. to some, <span class="arrow"><span class="ar">تُؤْثُورَهُ↓</span></span>, whence one says, <span class="ar long">رَأَيْتُ أُثْرَتَهُ</span>, and<span class="arrow"><span class="ar">تُؤْثُورَهُ↓</span></span>, <em>I saw the place of his footsteps upon the ground:</em> <span class="auth">(M:)</span> or the <em>abrasion of the inner</em> <span class="add">[i. e. <em>under</em>]</span> <em>part of a camel's foot with the instrument of iron called</em> <span class="ar">مِئْثَرَة</span> <em>and</em> <span class="ar">تُؤْثُور</span>, <em>in order that his footprints may be traced.</em> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#OuvorN">See also <span class="ar">أُثْرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OuvorapN_A3">
					<p><a href="#OavorN">See also <span class="ar">أَثْرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OuvorapN_A4">
					<p><a href="#maOovurapN">And see <span class="ar">مَأْثُرَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OuvorapN_A5">
					<p><em>Preference.</em> <span class="auth">(A.)</span> You say, <span class="ar long">لَهُ عِنْدِى أُثْرَةٌ</span> <em>He has a preference in my estimation.</em> <span class="auth">(A.)</span> And <span class="ar long">هُوَ ذُو أُثْرَةٍ عِنْدَ الأَمِيرِ</span> <em>He has a preference in the estimation of the prince,</em> or <em>commander.</em> <span class="auth">(A.)</span> And <span class="ar long">فُلَانٌ ذُو أُثْرَةٍ عِنْدَ فُلَانٍ</span>, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">أَثَرَةٍ↓</span></span>, <span class="auth">(T,)</span> <em>Such a one is a favourite with such a one.</em> <span class="auth">(T, TA.)</span> <a href="#OavarapN">See also <span class="ar">أَثَرَةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OuvorapN_A6">
					<p><span class="ar long">أُثْرَةَ ذِى أَثِيرٍ</span>: <a href="#AvirN">see <span class="ar">آثِرٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أُثْرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OuvorapN_B1">
					<p><em>Dearth, scarcity, drought,</em> or <em>sterility,</em> (<span class="ar">جَدْبٌ</span> <span class="add">[in the CK <span class="ar">جَذْب</span>]</span>,) <em>and an unpleasant state</em> or <em>condition.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IivorapN">
				<h3 class="entry"><span class="ar">إِثْرَةٌ</span></h3>
				<div class="sense" id="IivorapN_A1">
					<p><span class="ar">إِثْرَةٌ</span>: <a href="#OavarapN">see <span class="ar">أَثَرَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">إِثْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IivorapN_A2">
					<p><span class="ar">إِثْرَةً</span>: <a href="#AvirN">see <span class="ar">آثِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavarapN">
				<h3 class="entry"><span class="ar">أَثَرَةٌ</span></h3>
				<div class="sense" id="OavarapN_A1">
					<p><span class="ar">أَثَرَةٌ</span>: <a href="#OavaArapN">see <span class="ar">أَثَارَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثَرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavarapN_A2">
					<p>A subst. <span class="add">[signifying The <em>appropriation of a thing or things to oneself exclusively:</em> the <em>having a thing to oneself, with none to share with him in it:</em>]</span> from <span class="ar long">اِسْتَأْثَرَ بِالشَّىْءِ</span>. <span class="auth">(Ṣ, M.)</span> And, as also<span class="arrow"><span class="ar">أُثْرَةٌ↓</span></span>and<span class="arrow"><span class="ar">إِثْرَةٌ↓</span></span>and<span class="arrow"><span class="ar">إُثْرَى↓</span></span>, The <em>choice for oneself</em> <span class="add">[in preference to his companions]</span> <em>of good things,</em> <span class="auth">(M,* Ḳ,* TA,)</span> <em>in partition;</em> <span class="auth">(M, TA;)</span> the <em>choice and preference of the best of things, and taking it,</em> or <em>them, for oneself:</em> <span class="auth">(TA:)</span> the pl. of the second is <span class="ar">أُثَرٌ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">أَخَذَهُ بِلَا أَثَرَةٍ</span>, and<span class="arrow"><span class="ar long">بلا أُثْرَةٍ↓</span></span>, <span class="add">[&amp;c.,]</span> <em>He took it without a choice and preference of the best of the things, and the taking the best for himself.</em> <span class="auth">(T, TA.)</span> And a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَقُلْتَ لَهُ يَا ذِئْبُ هَلْ لَكَ فىِ أَخٍ</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">يُؤَاسِى بِلَا أُثْرَي↓ عَلَيْكَ وَلَا بُخْلِ</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And I said to him, O wolf, hast thou a desire for a brother who will share without choice of the best things for himself in preference to thee, and without niggardness?</em>]</span>. <span class="auth">(M, TA.)</span> <a href="#OuvorapN">See also <span class="ar">أُثْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ouvorae">
				<h3 class="entry"><span class="ar">أُثْرَى</span></h3>
				<div class="sense" id="Ouvorae_A1">
					<p><span class="ar">أُثْرَى</span>: <a href="#OavarapN">see <span class="ar">أَثَرَةٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaviyrN">
				<h3 class="entry"><span class="ar">أَثِيرٌ</span></h3>
				<div class="sense" id="OaviyrN_A1">
					<p><span class="ar">أَثِيرٌ</span>: <a href="#OavarapN">see <span class="ar">أَثَرَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaviyrN_A2">
					<p><span class="add">[<em>That makes a large footprint,</em> or <em>the like.</em>]</span> You say, <span class="ar long">دَابَّةٌ أَثِيَرةٌ</span> <em>A beast that makes a large footprint upon the ground with its hoof,</em> <span class="auth">(AZ, Ṣ, M, Ḳ,)</span> or <em>with its soft foot, such as that of the camel.</em> <span class="auth">(AZ, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaviyrN_A3">
					<p>A man <em>possessing power and authority; honoured:</em> pl. <span class="ar">أُثَرَآءُ</span>: fem. <span class="ar">أَثِيرَةٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaviyrN_A4">
					<p><span class="ar long">فُلَانٌ أَثِيرِى</span> <em>Such a one is my particular friend:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>is the person whom I prefer.</em> <span class="auth">(A.)</span> <span class="ar long">فُلَانٌ أَثِيرٌعِنْدَ فُلَانٍ</span> <em>Such a one is a favourite with such a one.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaviyrN_A5">
					<p><span class="ar long">آثِرَ ذِى أَثِيرٍ</span>, and <span class="ar long">أَوَّلَ ذِى أَثِيرٍ</span>, &amp;c.: <a href="#AvirN">see <span class="ar">آثِرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaviyrN_A6">
					<p><span class="ar long">شَىْءٌ كَثِيرٌ أَثِيرٌ</span> <span class="add">[<em>A thing very abundant, copious,</em> or <em>numerous</em>]</span>: <span class="ar">اثير</span> is here an imitative sequent, <span class="auth">(Ṣ, Ḳ,*)</span> like <span class="ar">بَثِيرٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">أَثِيرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaviyrN_B1">
					<p><span class="ar">الأَثِيرُ</span> <span class="add">[<span class="gr">ὁ αἰθήρ</span>, <em>The ether;</em>]</span> <em>the ninth, which is the greatest, sphere, which rules over</em> <span class="add">[<em>all</em>]</span> <em>the other spheres:</em> <span class="add">[said to be]</span> so called because it affects the others (<span class="ar long">يُؤَثِرُ فِى غَيْرِهِ</span>). <span class="auth">(MF.)</span> <span class="add">[It is also called <span class="ar long">فَلَكُ الأَطْلَسِ</span>, and <span class="ar long">فَلَكُ العَرْشِ</span>; and is said to be next above that called <span class="ar long">فَلَكُ الكُرْسِىِّ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavaArapN">
				<h3 class="entry"><span class="ar">أَثَارَةٌ</span></h3>
				<div class="sense" id="OavaArapN_A1">
					<p><span class="ar">أَثَارَةٌ</span>: <a href="#OavarN">see <span class="ar">أَثَرٌ</span></a>. You say, <span class="ar long">سَمِنَتِ الإبِلُ عَلَى أَثَارَةٍ</span>, <span class="auth">(Ṣ, M,*)</span> or <span class="ar long">على أَثَارَةٍ مِنْ شَحْمٍ</span>, <span class="auth">(A,)</span> <em>The camels acquired fat, upon,</em> or <em>after, remains of fat.</em> <span class="auth">(Ṣ, M,* A.)</span> And <span class="ar long">غَضِبَ عَلَى أَثَارَةٍ قِبْلَ ذَاكَ</span> <em>He became angry the more, having been angry before that.</em> <span class="auth">(Lḥ, M.)</span> And <span class="ar long">أَغْضَبَنِى فُلَانٌ عَلَى أَثَارَةِ غَضَبٍ</span> <em>Such a one angered me when anger yet remained in me.</em> <span class="auth">(A.)</span> And <span class="ar long">أَثَارَةٌ مِنْ عِلْمٍ</span>, and<span class="arrow"><span class="ar">أَثَرَةٌ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">أُثْرَةٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> or<span class="arrow"><span class="ar">أَثْرَةٌ↓</span></span>, <span class="auth">(T,)</span> the first of which is the most approved, <span class="auth">(M,)</span> and is <span class="add">[originally]</span> an inf. n., <span class="add">[<a href="#Oavara">see <span class="ar long">أَثَرَ الآحَدِيثَ</span></a>,]</span> <span class="auth">(T,)</span> signify <em>A remain,</em> or <em>relic, of knowledge,</em> <span class="auth">(Zj, T, Ṣ, M, Ḳ, and Jel in xlvi. 3 of the Ḳur,)</span> <em>transmitted,</em> or <em>handed down,</em> <span class="auth">(Ḳ, Jel,)</span> <em>from the former generations:</em> <span class="auth">(Jel:)</span> or <em>what is transmitted,</em> or <em>handed down, of knowledge:</em> <span class="auth">(Zj, M:)</span> or <em>somewhat transmitted from the writings of the former generations:</em> <span class="auth">(TA:)</span> by the knowledge spoken of <span class="add">[in the Ḳur ubi suprà]</span> is meant that of writing, which was given to certain of the prophets. <span class="auth">(I’Ab.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MvirN">
				<h3 class="entry"><span class="ar">آثِرٌ</span></h3>
				<div class="sense" id="MvirN_A1">
					<p><span class="ar">آثِرٌ</span> One <em>who relates,</em> or <em>recites, a tradition, narrative,</em> or <em>story,</em> or <em>traditions, &amp;c., as received,</em> or <em>heard, from another,</em> or <em>others; a narrator thereof.</em> <span class="auth">(T, Ṣ,* L.)</span> The saying of ʼOmar, on his being forbidden by Moḥammad to swear by his father, <span class="ar long">مَا حَلَفْتُ بِهِ ذَاكِراً وَلَا آثِرًا</span>, means <em>I did not swear by him uttering</em> (<em>the oath</em>) <em>as proceeding in the first instance from myself, nor repeating</em> (<em>it</em>) <em>as heard from another particular person.</em> <span class="auth">(AʼObeyd, T, Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">آثِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MvirN_A2">
					<p><span class="ar long">أَفْعَلُ هذَا آثِرًا مَّا</span>, <span class="auth">(IAạr, T, Ṣ, Ḳ,)</span> and <span class="ar">آثِرًا</span> without <span class="ar">ما</span>, <span class="auth">(IAạr, T,)</span> and<span class="arrow"><span class="ar long">آثِرَ ذِى أَثِيرٍ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> mean <em>I will do this the first of every thing.</em> <span class="auth">(Ṣ, Ḳ.*)</span> And in like manner, after <span class="ar">لَقِيتُهُ</span> <span class="add">[<em>I met him,</em> or <em>it</em>]</span>, one says, <span class="ar long">آثِرًا مَّا</span>, <span class="add">[and<span class="arrow"><span class="ar long">آثِرَ ذِى أَثِيرٍ↓</span></span>,]</span> and<span class="arrow"><span class="ar long">أَوَّلَ ذِى أَثِيرٍ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <span class="pb" id="Page_0020"></span>and <span class="ar long">آثِرَ ذَاتِ يَدِى</span>, <span class="auth">(M,)</span> or <span class="ar long">ذَاتِ يَدَيْنِ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar long">ذِى يَدَيْنِ</span>, <span class="auth">(IAạr, M, Ḳ,)</span> and<span class="arrow"><span class="ar long">أَثِيرَةَ ذِى أَثِيرٍ↓</span></span>, and<span class="arrow"><span class="ar long">إُثْرَةَ↓ ذِى أثِيرَيْنِ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar long">آثِرَ ذِى أَثِيرَيْنِ↓</span></span>, <span class="auth">(M, as from Lḥ,)</span> or<span class="arrow"><span class="ar long">أَثَرَ↓ ذِى أَثِيرَيْنِ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar long">إِثْرَ↓ ذِى أَثِيرَيْنِ↓</span></span> and<span class="arrow"><span class="ar long">إِثْرَةً↓ مَّا</span></span>: <span class="auth">(Lḥ, M, Ḳ:)</span> or, as some say, <span class="arrow"><span class="ar">الأَثِيرُ↓</span></span>signifies <em>the daybreak,</em> or <em>down;</em> and<span class="arrow"><span class="ar long">ذُو أَثِيرٍ↓</span></span>, <em>the time thereof.</em> <span class="auth">(M, TA.)</span> Fr says that <span class="ar long">اِبْدَأْ بِهذَا آثِرًا مَّا</span>, and<span class="arrow"><span class="ar long">آثِرَ ذِى أَثِيرٍ↓</span></span>, and<span class="arrow"><span class="ar long">أَثِيرَ ذِى أَثِيرٍ↓</span></span>, signify <em>Begin thou with this first of every thing.</em> <span class="auth">(TA.)</span> One says also, <span class="ar long">اِفْعَلْهُ آثِرًا مَّا</span>, <span class="auth">(T, M, TA,)</span> and<span class="arrow"><span class="ar long">إِثْرًا↓ مَّا</span></span>, <span class="auth">(M, TA,)</span> meaning <em>Do thou it</em> <span class="add">[<em>at least</em>]</span>, <em>if thou do nothing else:</em> <span class="auth">(T, M, TA:)</span> or, as some say, <em>do thou it in preference to another thing,</em> or <em>to other things:</em> <span class="ar">ما</span> being redundant, but <span class="add">[in this case]</span> not to be omitted, because <span class="add">[it is a corroborative, and]</span> the meaning of the phrase is, do thou it by choice, or preference, and with care. <span class="auth">(M, TA.)</span> Mbr says that the phrase <span class="ar long">خُذْ هذَا آثِرًا مَّا</span> means <em>Take thou this in preference;</em> i. e., I give it thee in preference; as though one desired to take, of another, one thing, and had another thing offered to him for sale: and <span class="ar">ما</span> is here redundant. <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOovuwrN">
				<h3 class="entry"><span class="ar">تَأْثُورٌ</span></h3>
				<div class="sense" id="taOovuwrN_A1">
					<p><span class="ar">تَأْثُورٌ</span>: <a href="#OuvorapN">see <span class="ar">آُثْرَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuWovuwrN">
				<h3 class="entry"><span class="ar">تُؤْثُورٌ</span></h3>
				<div class="sense" id="tuWovuwrN_A1">
					<p><span class="ar">تُؤْثُورٌ</span>: <a href="#AvorapN">see <span class="ar">آثْرَةٌ</span></a>, in two places: <a href="#miYovarapN">and see <span class="ar">مِئْثَرَةٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOvurapN">
				<h3 class="entry"><span class="ar">مَأثُرَةٌ</span></h3>
				<div class="sense" id="maOvurapN_A1">
					<p><span class="ar">مَأثُرَةٌ</span> <span class="auth">(T, Ṣ, M, Ḳ, &amp;c.)</span> and <span class="ar">مَأْثَرَةٌ</span><span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أُثْرَةٌ↓</span></span><span class="auth">(M, Ḳ)</span> <em>A generous quality</em> or <em>action;</em> <span class="auth">(AZ, Ṣ;)</span> so called because related, or handed down, by generation from generation: <span class="auth">(Ṣ:)</span> or <em>a generous quality that is inherited by generation from generation:</em> <span class="auth">(M, Ḳ:)</span> <em>a generous quality,</em> or <em>action, related,</em> or <em>handed down by tradition from one's ancestors:</em> <span class="auth">(A:)</span> <em>a cause of glorying:</em> <span class="auth">(AZ:)</span> and <em>precedence in</em> <span class="ar">أُثْرَةٌ</span><span class="add">[or <em>grounds of pretension to respect,</em>, &amp;c.]</span>: pl. of the first and second, <span class="ar">حَسَب</span>. <span class="auth">(AZ, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYovarapN">
				<h3 class="entry"><span class="ar">مِئْثَرَةٌ</span></h3>
				<div class="sense" id="miYovarapN_A1">
					<p><span class="ar">مِئْثَرَةٌ</span> and<span class="arrow"><span class="ar">تُؤْثُورٌ↓</span></span> <em>An iron instrument</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>with which the bottom of a camel's foot is marked, in order that his footprints upon the ground may be known:</em> <span class="auth">(M:)</span> or, <em>with which the inner</em> <span class="add">[i. e. <em>under</em>]</span> <em>part of a camel's foot is scraped, in order that his footprints may be traced:</em> <span class="auth">(Ṣ, Ḳ:)</span> or<span class="arrow"><span class="ar">تؤثور↓</span></span>has a different meaning, explained above, voce <span class="ar">أُثْرَةٌ</span>. <span class="auth">(M.)</span> The <span class="ar">مِيثَرَة</span> of a horse's saddle is without hemz. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOovuwrN">
				<h3 class="entry"><span class="ar">مَأْثُورٌ</span></h3>
				<div class="sense" id="maOovuwrN_A1">
					<p><span class="ar">مَأْثُورٌ</span> A camel <em>having a mark made upon the bottom of his foot with the iron instrument called</em> <span class="ar">مِئْثَرَة</span>, <em>in order that his footprints upon the ground may be known:</em> <span class="auth">(T:)</span> or <em>having the inner</em> <span class="add">[i. e. <em>under</em>]</span> <em>part of his foot scraped with that instrument, in order that his footprints may be traced.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">مَأْثُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOovuwrN_A2">
					<p>A sword <em>having in its</em> <span class="ar">مَتْن</span><span class="add">[or <em>broad side;</em> or <em>the middle of the broad side, of the blade,</em>]</span> <em>diversified wavy marks, streaks,</em> or <em>grain,</em> or <em>lustre</em> or <em>glitter:</em> <span class="auth">(M, Ḳ: <span class="add">[in some copies of the latter of which, instead of <span class="ar">أَثْرٌ</span>, I find <span class="ar">أَثَرٌ</span>:]</span>)</span> or <em>having its</em> <span class="ar">متن</span> <em>of female,</em> or <em>soft, iron, and its edge of male iron,</em> or <em>steel:</em> <span class="auth">(Ḳ:)</span> or <em>that is said to be of the fabric of the jinn,</em> or <em>genii;</em> <span class="auth">(Ṣ, M, Ḳ*)</span> and not from <span class="ar">الأَثْر</span>, as signifying <span class="ar">الفِرِنْد</span>: <span class="auth">(Ṣ, M:)</span> so says Aṣ: <span class="auth">(Ṣ:)</span> <span class="add">[ISd says,]</span> <span class="ar">مأثور</span> is in my opinion a pass. part. n. that has no verb: <span class="auth">(M:)</span> or it signifies an <em>ancient</em> sword, <em>which has passed by inheritance from great man to great man.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثر</span> - Entry: <span class="ar">مَأْثُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOovuwrN_A3">
					<p>A tradition, narrative, or story, <em>handed down from one to another, from generation to generation.</em> <span class="auth">(T, Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0018.pdf" target="pdf">
							<span>Lanes Lexicon Page 18</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0019.pdf" target="pdf">
							<span>Lanes Lexicon Page 19</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0020.pdf" target="pdf">
							<span>Lanes Lexicon Page 20</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
