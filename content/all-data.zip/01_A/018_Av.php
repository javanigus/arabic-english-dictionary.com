<article class="root" id="Root_Av">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/017_Ate">اتى</a></span>
				<span class="ar">اث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/019_Avr">اثر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Av_1">
				<h3 class="entry">1. ⇒ <span class="ar">أثّ</span></h3>
				<div class="sense" id="Av_1_A1">
					<p><span class="ar">أَثَّ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِثُ</span>}</span></add> <span class="auth">(T, Ṣ, M, L, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُثُ</span>}</span></add> and <span class="ar">َ</span> <add><span class="new">{<span class="ar">يَأْثَثُ</span>}</span></add>, <span class="auth">(M, L, Ḳ,)</span> inf. n. <span class="ar">أَثَاثَةٌ</span><span class="auth">(T, Ṣ, M, L, Ḳ)</span> and <span class="ar">أَثَاثٌ</span><span class="auth">(M, L, Ḳ)</span> and <span class="ar">أُثُوثَةٌ</span>, <span class="auth">(M,)</span> or <span class="ar">أُثُوُثٌ</span>, <span class="auth">(L, Ḳ,)</span> <em>It</em> <span class="auth">(anything)</span> <em>was,</em> or <em>became, much in quantity, abundant,</em> or <em>numerous:</em> and <em>great,</em> or <em>large:</em> <span class="auth">(M, L:)</span> <em>it</em> <span class="auth">(herbage, or a herb,)</span> <em>was,</em> or <em>became, abundant,</em> or <em>plenteous, and tangled,</em> or <em>luxuriant;</em> <span class="auth">(T, Ṣ, Ḳ;)</span> or <em>abundant and tall:</em> <span class="auth">(M:)</span> <em>it</em> <span class="auth">(hair)</span> <em>was,</em> or <em>became, abundant and long.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Av_1_A2">
					<p><span class="ar">أَثَّتْ</span>, <span class="auth">(M, Ḳ,)</span>) aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُثُ</span>}</span></add>, inf. n. <span class="ar">أَثٌّ</span>, <span class="auth">(M,)</span> said of a woman, <em>She was,</em> or <em>became, large in the hinder parts.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Av_2">
				<h3 class="entry">2. ⇒ <span class="ar">أثّث</span></h3>
				<div class="sense" id="Av_2_A1">
					<p><span class="ar">أثّثهُ</span> <em>He made it plain, level, smooth, soft,</em> or <em>easy to lie</em> or <em>ride</em> or <em>walk upon.</em> <span class="auth">(M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Av_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأثّث</span></h3>
				<div class="sense" id="Av_5_A1">
					<p><span class="ar">تأثّث</span> <em>He obtained,</em> or <em>acquired, goods, household-goods,</em> or <em>furniture and utensils and the like;</em> or <em>abundance of the goods, conveniences,</em> or <em>comforts, of life;</em> <span class="auth">(Ṣ;)</span> or <em>property;</em> <span class="auth">(Ṣ, M;)</span> or <em>wealth;</em> or <em>what was good.</em> <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OavBN">
				<h3 class="entry"><span class="ar">أَثٌّ</span> / <span class="ar">أَثَّةٌ</span></h3>
				<div class="sense" id="OavBN_A1">
					<p><span class="ar">أَثٌّ</span>; fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَثَّةٌ</span>}</span></add>: <a href="#OaviyvN">see <span class="ar">أَثِيثٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavaAvN">
				<h3 class="entry"><span class="ar">أَثَاثٌ</span></h3>
				<div class="sense" id="OavaAvN_A1">
					<p><span class="ar">أَثَاثٌ</span> <em>Goods;</em> or <em>utensils and furniture of a house or tent; household-goods;</em> syn. <span class="ar">مَتَاعٌ</span>; <span class="auth">(T, M;)</span> or <span class="ar long">مَتَاعُ بَيْت</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>of whatever kind; consisting of clothes, and stuffing for mattresses or the like, or outer garments</em> <span class="add">[<em>&amp;c.</em>]</span>: <span class="auth">(M, TA:)</span> or <span class="auth">(so accord. to the M and Ḳ, but in the T “also,”)</span> <em>all property,</em> <span class="auth">(AZ, T, Ṣ, M, Ḳ,)</span> <span class="add">[<em>consisting of</em>]</span> <em>camels, and sheep or goats, and slaves, and utensils and furniture or householdgoods:</em> <span class="auth">(AZ, T, Ṣ:)</span> or <em>abundant property:</em> or <em>abundance of property:</em> <span class="auth">(M, TA:)</span> <span class="add">[in which last sense it is an inf. n. used as simple subst.:]</span> or <em>what is made,</em> or <em>taken, for use,</em> and <em>i. q.</em> <span class="ar">مَتَاعٌ</span>; <em>not what is for merchandise:</em> or <em>what is new, of the utensils and furniture of a house or tent; not what is old and worn out:</em> <span class="auth">(TA:)</span> <span class="pb" id="Page_0018"></span><span class="add">[it is a coll. gen. n., and]</span> the n. un. is with <span class="ar">اثر</span>: <span class="auth">(AZ, T, Ṣ, M, Mṣb, Ḳ:)</span> or it has no n. un.: <span class="auth">(Fr, T, Ṣ, Mṣb, Ḳ:)</span> if you form a pl. from <span class="ar">اثاث</span>, you say, <span class="ar long">ثَلَاثَةُ آثَّةٍ</span>, <span class="add">[originally <span class="ar">أَأْثِثَة</span>, like <span class="ar">أَطْعِمَة</span>, <a href="#TaEaAm">pl. of <span class="ar">طَعَام</span></a>,]</span> and <span class="ar long">أُثُثٌ كَثِيرَةٌ</span>. <span class="auth">(Fr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaviyvN">
				<h3 class="entry"><span class="ar">أَثِيثٌ</span></h3>
				<div class="sense" id="OaviyvN_A1">
					<p><span class="ar">أَثِيثٌ</span> <em>Much in quantity, abundant,</em> or <em>numerous:</em> and <em>great,</em> or <em>large:</em> as also<span class="arrow"><span class="ar">أَثٌّ↓</span></span>; <span class="auth">(M, Ḳ;)</span> which is, in my opinion, <span class="add">[says ISd, originally <span class="ar">أَثِثٌ</span>,]</span> of the measure <span class="ar">فَعِلٌ</span>: <span class="auth">(M:)</span> the fem. is <span class="ar">أَثِيثَةٌ</span>: and the pl. is <span class="ar">إِثَاثٌ</span> and <span class="ar">أَثَائِثُ</span>; <span class="auth">(M, Ḳ;*)</span> both being pls. of the masc. and of the fem.; <span class="auth">(Ḳ;)</span> or the latter is pl. of the fem. only; <span class="auth">(M,* MF;)</span> but the former is <span class="add">[pl. of the masc.,]</span> like <span class="ar">كِرَامٌ</span> <a href="#kariymN">as pl. of <span class="ar">كَرِيمٌ</span></a>, <span class="auth">(TA,)</span> and is pl. of the fem. also. <span class="auth">(M.)</span> You say, <span class="ar long">نَبَاتٌ أَثِيثٌ</span> <em>Herbage,</em> or <em>a herb, that is abundant,</em> or <em>plenteous, and tangled,</em> or <em>luxuriant:</em> <span class="auth">(T, Ṣ:)</span> or <em>abundant and tall.</em> <span class="auth">(M.)</span> And <span class="ar long">شَعَرٌ أَثِيثٌ</span> <em>Hair that is abundant, and tangled,</em> or <em>luxuriant:</em> <span class="auth">(Ṣ:)</span> or <em>abundant</em> <span class="auth">(T, M)</span> <em>and long.</em> <span class="auth">(M.)</span> And <span class="ar long">لِحْيَةٌ أَثِيثَةٌ</span>, and<span class="arrow"><span class="ar">أَثَّةٌ↓</span></span>, <em>A thick beard.</em> <span class="auth">(M, TA.)</span> And <span class="ar long">اِمْرَأَةٌ أَثِيثَةٌ</span> <em>A fleshy woman:</em> <span class="auth">(M, TA:)</span> pl. <span class="ar">أَثَائِثُ</span>, <span class="auth">(M,)</span> signifying <em>fleshy</em> women; <span class="auth">(Ṣ, M, Ḳ;)</span> as also <span class="ar">إِثَاثٌ</span>: <span class="auth">(M:)</span> or the former of these pls. signifies <em>tall, full-grown,</em> women. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavaAvieBu">
				<h3 class="entry"><span class="ar">أَثَاثِىُّ</span></h3>
				<div class="sense" id="OavaAvieBu_A1">
					<p><span class="ar">أَثَاثِىُّ</span> <em>i. q.</em> <span class="ar">أَثَافِىُّ</span>, <span class="auth">(Ḳ,)</span> i. e. The <span class="add">[<em>three</em>]</span> <em>stones which are set up and upon which the cooking-pot is placed:</em> the <span class="add">[second]</span> <span class="ar">ث</span> is said to be a substitute for <span class="ar">ف</span>, and some hold the hemzeh to be augmentative. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0017.pdf" target="pdf">
							<span>Lanes Lexicon Page 17</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0018.pdf" target="pdf">
							<span>Lanes Lexicon Page 18</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
