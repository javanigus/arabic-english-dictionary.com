<article class="root" id="Root_AXf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/089_AXr">اشر</a></span>
				<span class="ar">اشف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/091_AXk">اشك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IiXofae">
				<h3 class="entry"><span class="ar">إِشْفَى</span></h3>
				<div class="sense" id="IiXofae_A1">
					<p><span class="ar">إِشْفَى</span>, of the measure <span class="ar">فِعْلَى</span>, <span class="add">[and therefore fem., and imperfectly decl.,]</span> <span class="auth">(Ṣ, Mṣb,)</span> accord. to some; but accord. to others, of the measure <span class="ar">إِفْعَلٌ</span> like <span class="ar">إِصْبَعٌ</span> as Kh is related to have said, <span class="auth">(Mṣb,)</span> which latter is said by IB to be the correct measure, the <span class="add">[incipient]</span> <span class="ar">ا</span> being augmentative, and the word <span class="add">[masc.,]</span> with tenween, <span class="add">[i. e. <span class="ar">إِشْفًى</span>,]</span> perfectly decl.: <span class="auth">(TA:)</span> The <em>instrument belonging to the</em> <span class="ar">إِسكَاف</span> <span class="add">[or <em>sewer of skins</em> or <em>leather</em>]</span>; <span class="auth">(Ṣ,* Mṣb, TA;)</span> i. e., <em>with which he sews;</em> and the <em>instrument with which he bores,</em> or <em>perforates:</em> <span class="auth">(TA:)</span> the <em>instrument for boring,</em> or <em>perforating,</em> <span class="auth">(Ḳ in art. <span class="ar">شفى</span>)</span> <em>belonging to the</em> <span class="ar">أَسَاكِفَة</span>; said by ISk to be that <em>which is used for water-skins,</em> or <em>milk-skins, and leather water-bags, and the like;</em> that used for sandals, or shoes, being called <span class="ar">مِخْصَفٌ</span>: <span class="auth">(Ṣ and TA in art. <span class="ar">شفى</span>:)</span> and the <span class="add">[<em>instrument called</em>]</span> <span class="ar">سِرَاد</span> <em>with which skin,</em> or <em>leather, is sewed:</em> <span class="auth">(Ḳ in art. <span class="ar">شفى</span>:)</span> <em>i. q.</em> <span class="ar">مِخْرَزٌ</span>: <span class="auth">(Mgh in art. <span class="ar">شفى</span>:)</span> pl. <span class="ar">أَشَافٍ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ: <span class="add">[in the CK, erroneously, <span class="ar">اَشافِىُّ</span>]</span>)</span> In the Ḳ, in the present art., <span class="ar">الإِسْكَافُ</span> is put, by a mistake of the copyists, for <span class="ar">لِلْإِسْكَافِ</span> <span class="auth">(TA.)</span> <a href="../">See also art. <span class="ar">شفى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0062.pdf" target="pdf">
							<span>Lanes Lexicon Page 62</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
