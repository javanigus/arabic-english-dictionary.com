<article class="root" id="Root_ArD">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/055_ArX">ارش</a></span>
				<span class="ar">ارض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/057_ArT">ارط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ArD_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرض</span></h3>
				<div class="sense" id="ArD_1_A1">
					<p><span class="ar long">أَرُضَتِ الأَرْضُ</span>, <span class="auth">(Ṣ, Ḳ, <span class="add">[in two copies of the Ṣ <span class="ar">أُرِضَت</span>, but this is evidently a mistake,]</span>)</span> with damm, <span class="auth">(Ṣ,)</span> like <span class="ar">كَرُمَت</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَرَاضَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>The land became thriving,</em> or <em>productive;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">استأرضت↓</span></span>; <span class="auth">(TA;)</span> <em>it became pleasing to the eye, and disposed by nature to yield good produce;</em> <span class="auth">(Ḳ, TA;)</span> <em>it became fruitful, and in good condition;</em> <span class="auth">(M;)</span> <em>it collected moisture, and became luxuriant with herbage; it became soft to tread upon, pleasant to sit upon, productive, and good in its herbage</em> or <em>vegetation:</em> <span class="auth">(AḤn:)</span> and <span class="ar long">أَرَضَتِ الأَرْضُ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُضُ</span>}</span></add>, <span class="auth">(TA,)</span> <em>the land became abundant in herbage,</em> or <em>pasture.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ArD_1_A2">
					<p><span class="ar">أَرُضَ</span>, inf. n. <span class="ar">أَرَاضَةٌ</span>, is also said of a man, meaning † <em>He was,</em> or <em>became, lowly,</em> or <em>submissive, and naturally disposed to good,</em> or <em>to do good.</em> <span class="auth">(L, TA,)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ArD_1_B1">
					<p><span class="ar long">أَرَضَ الأَرْضَ</span> <em>He found the land to be abundant in herbage,</em> or <em>pasture.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="ArD_1_C1">
					<p><span class="ar long">أُرِضَتِ الخَشَبَةُ</span>, <span class="auth">(Ṣ, A, Mṣb, TA,)</span> in the pass. form, <span class="auth">(Mṣb,)</span> like <span class="ar">عُنِى</span>, <span class="auth">(TA,)</span> aor. <span class="ar">تُؤْرَضُ</span>, <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">أَرْضٌ</span>, <span class="auth">(Ṣ, A, TA,)</span> with sukoon <span class="add">[to the <span class="ar">ر</span>]</span>; <span class="auth">(Ṣ, TA;)</span> and some add <span class="ar">أَرِضَت</span>, aor. <span class="ar">تَأْرَضُ</span>, inf. n. as above; <span class="auth">(TA; <span class="add">[and so in a copy of the Ṣ in the place of what here precedes;]</span>)</span> <em>The piece of wood was,</em> or <em>became, eaten by the</em> <span class="ar">أَرَضَة</span>, q. v. <span class="auth">(Ṣ, A, Mṣb, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="ArD_1_D1">
					<p><span class="ar long">أَرِضَتِ القَرْحَةٌ</span>, <span class="auth">(Ṣ, M. Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَضُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَرَضٌ</span>, <span class="auth">(Ṣ, M,)</span> <em>The ulcer,</em> or <em>sore, became blistered,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>and wide,</em> <span class="auth">(M,)</span> <em>and corrupt</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>by reason of thick purulent matter,</em> <span class="auth">(Ṣ,)</span> <em>and dissundered;</em> <span class="auth">(M;)</span> so says Aṣ; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">استأرضت↓</span></span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="ArD_1_E1">
					<p><span class="ar">أُرِضَ</span>, like <span class="ar">عُنِىَ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَرْضٌ</span>; <span class="auth">(TA;)</span> or <span class="ar">أَرِضَ</span>, like <span class="ar">سَمِعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَضُ</span>}</span></add>, inf. n. <span class="ar">أَرْضٌ</span>; <span class="auth">(L;)</span> <em>He was,</em> or <em>became, affected with</em> <span class="ar">زُكَام</span> <span class="add">[or <em>rheum</em>]</span>. <span class="auth">(L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArD_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّض</span></h3>
				<div class="sense" id="ArD_2_A1">
					<p><span class="ar">ارّض</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">تَأْرِيضٌ</span>, <span class="auth">(Ḳ,)</span> <em>He depastured the herbage of the earth,</em> or <em>land:</em> and <em>he sought after it:</em> <span class="auth">(Ḳ:)</span> or, accord. to some, <span class="ar">تَأْرِيضٌ</span> denotes this latter signification with respect to a place of alighting, or abiding: <span class="auth">(TA:)</span> and you say <span class="add">[also]</span>,<span class="arrow"><span class="ar long">تأرّض↓ المَنْزِلَ</span></span> <em>he sought after, and chose, the place for alighting,</em> or <em>abiding:</em> <span class="auth">(M, TA:)</span> and<span class="arrow"><span class="ar long">تَرَكْتُ الحَىَّ يَتَأَرَّضُونَ↓ لِلْمَنْزِلِ</span></span> <em>I left the tribe seeking after a tract of country in which to alight,</em> or <em>abide.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ArD_2_B1">
					<p><em>He,</em> or <em>it, rendered heavy;</em> <span class="add">[app. meaning <em>slow,</em> or <em>sluggish;</em> <a href="#ArD_5">see 5</a>;]</span> syn. <span class="ar">ثَقَّلَ</span>. <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="ArD_2_B2">
					<p><em>He made to tarry; to tarry and wait,</em> or <em>expect;</em> or <em>to be patient, and tarry, and wait,</em> or <em>expect.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArD_4">
				<span class="pb" id="Page_0048"></span>
				<h3 class="entry">4. ⇒ <span class="ar">آرض</span></h3>
				<div class="sense" id="ArD_4_A1">
					<p><span class="ar">آرض</span>, inf. n. <span class="ar">إِيْرَاضٌ</span>: <a href="#ArD_5">see 5</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ArD_4_B1">
					<p><span class="ar long">مَا آرَضُ هذَا المَكَانَ</span> <em>How abundant is the herbage</em> (<span class="ar">عُشْب</span>) <em>of this place!</em> or, as some say, <span class="ar long">مَا آرَضَ هذِهِ الأَرْضَ</span> <em>How level,</em> or <em>soft, and productive, and good, is this land!</em> <span class="auth">(Lḥ, AḤn.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="ArD_4_C1">
					<p><span class="ar">آرَضَهُ</span>, <span class="auth">(Ṣ, Ḳ, <span class="add">[in the CK, incorrectly, <span class="ar">اَرَضَهُ</span>,]</span>)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> <em>He</em> <span class="auth">(God)</span> <em>caused him to be affected with</em> <span class="ar">زُكَام</span> <span class="add">[or <em>rheum</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArD_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأرّض</span></h3>
				<div class="sense" id="ArD_5_A1">
					<p><span class="ar">تارّض</span> <em>It</em> <span class="auth">(herbage)</span> <em>became in such a state that it might be cut.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ArD_5_B1">
					<p><em>He clave,</em> or <em>kept, to the ground, not quitting it:</em> <span class="auth">(A:)</span> and<span class="arrow"><span class="ar">آرض↓</span></span>, inf. n. <span class="ar">إِيرَاضٌ</span>, <em>he remained upon the ground:</em> and <span class="ar long">تأرّض بِالمَكَانِ</span> <em>he remained fixed in the place, not quitting it:</em> or <em>he waited,</em> or <em>expected, and stood upon the ground:</em> and, as also<span class="arrow"><span class="ar long">استأرض↓ بالمكان</span></span>, <em>he remained, and tarried,</em> or <em>tarried in expectation, in the place:</em> or <em>he remained fixed therein:</em> <span class="auth">(TA:)</span> and <span class="ar">تأرّض</span> alone, <em>he tarried, loitered, stayed, waited,</em> or <em>paused in expectation:</em> <span class="auth">(Ṣ, TA:)</span> and <em>he was,</em> or <em>became, heavy, slow,</em> or <em>sluggish, inclining,</em> or <em>propending, to the ground;</em> <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[as also<span class="arrow"><span class="ar">استأرض↓</span></span>, accord. to IB's explanation of its act. part. n.]</span> You say, <span class="ar long">فُلَانٌ إِنْ رَأَى مَطْعَمًا تَأَرَّضَ وَإِنْ أَصَابَ مَطْعَمًا أَعْرَضَ</span> <span class="add">[<em>Such a one, if he see food, cleaves,</em> or <em>keeps, to the ground, not quitting it; and if he obtain food, turns away:</em> or <span class="ar">تأرّض</span> may here be rendered agreeably with the explanation next following]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="ArD_5_B2">
					<p><span class="ar long">جَآءِ فُلَانٌ يَتَأَرَّضُ لِى</span> <span class="auth">(Ṣ, Ḳ,* TA)</span> <em>Such a one came asking,</em> or <em>petitioning, for a thing that he wanted, to me;</em> syn. <span class="ar">يَتَصَدَّى</span>, and <span class="ar">يَتَعَرَّضُ</span>; <span class="auth">(Ṣ, Ḳ, TA;)</span> and <span class="ar">تَضَرَّعَ</span> is also a syn. of <span class="ar">تَأَرَّضَ</span>, used in this manner. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="ArD_5_C1">
					<p><a href="#ArD_2">See also 2</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArD_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأرض</span></h3>
				<div class="sense" id="ArD_10_A1">
					<p><a href="#ArD_5">see 5</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ArD_10_A2">
					<p><span class="ar long">استأرض السَّحَابُ</span> <em>The clouds expanded,</em> or <em>spread:</em> or, as some say, <em>became fixed,</em> or <em>stationary.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ArD_10_B1">
					<p><a href="#ArD_1">See also 1</a>, first signification:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="ArD_10_C1">
					<p><a href="#ArD_1">and see 1</a> again, last signification but one.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlOaroDu">
				<h3 class="entry"><span class="ar">الأَرْضُ</span></h3>
				<div class="sense" id="AlOaroDu_A1">
					<p><span class="ar">الأَرْضُ</span> <span class="add">[<em>The earth;</em>]</span> <em>that whereon are mankind:</em> <span class="auth">(TA:)</span> <span class="add">[and <em>earth, as opposed to heaven:</em> and <em>the ground,</em> as meaning <em>the surface of the earth, on which we tread and sit and lie;</em> and <em>the floor:</em> without <span class="ar">ال</span> signifying <em>a land,</em> or <em>country:</em> and <em>a piece of land</em> or <em>ground:</em> and <em>land,</em> or <em>soil,</em> or <em>ground, considered in relation to its quality:</em>]</span> it is fem.: <span class="auth">(Ṣ, A, Mṣb, Ḳ:)</span> and is a coll. gen. n.; <span class="auth">(Ṣ, A, Ḳ;)</span> of which the n. un. should be <span class="ar">أَرْضَةٌ</span>, but this they did not say: <span class="auth">(Ṣ:)</span> or a pl. having no sing.; <span class="auth">(A, Ḳ;)</span> for <span class="ar">أَرْضَةٌ</span> has not been heard: <span class="auth">(Ḳ:)</span> its pl. is <span class="ar">أَرَضَاتٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> in <span class="add">[some of]</span> the copies of the Ḳ <span class="ar">أَرْضَاتٌ</span>, <span class="auth">(TA,)</span> for they sometimes form the pl. of a word which has not the fem. <span class="ar">ة</span> with <span class="ar">ا</span> and <span class="ar">ت</span>, as in the instance of <span class="ar">عُرُسَاتٌ</span>; <span class="auth">(Ṣ;)</span> and <span class="ar">أَرَضُونَ</span>, <span class="add">[which is more common,]</span> <span class="auth">(AZ, AḤn, Ṣ, Mgh, Mṣb, Ḳ,)</span> with fet-ḥ to the <span class="ar">ر</span>, <span class="auth">(AZ, AḤn, Mgh, Mṣb,)</span> and with <span class="ar">و</span> and <span class="ar">ن</span>, though a fem. has not its pl. formed <span class="add">[regularly]</span> with <span class="ar">و</span> and <span class="ar">ن</span> unless it is of the defective kind, like <span class="ar">ثُبَةٌ</span> and <span class="ar">ظُبَةٌ</span>, but they have made the <span class="ar">و</span> and <span class="ar">ن</span> <span class="add">[in this instance]</span> a substitute for the <span class="ar">ا</span> and <span class="ar">ت</span> which they have elided <span class="add">[from <span class="ar">أَرَضَاتٌ</span>]</span>, and have left the fet-ḥah of the <span class="ar">ر</span> as it was; <span class="auth">(Ṣ;)</span> but they also said <span class="ar">أَرْضُونَ</span>, <span class="auth">(AZ, AḤn, Ṣ,)</span> sometimes, making the <span class="ar">ر</span> quiescent; <span class="auth">(Ṣ;)</span> and <span class="ar">أُرُوضٌ</span> <span class="auth">(AZ, AḤn, Mṣb, Ḳ)</span> is sometimes used as a pl., as in the saying <span class="ar long">مَا أَكْثَرَ أُرُوضَ بَنِى فُلَانٍ</span> <span class="add">[<em>How many are the lands of the sons of such a one!</em>]</span>; <span class="auth">(TA;)</span> and another <span class="add">[and very common]</span> pl. is <span class="add">[<span class="ar">أَرَاضٍ</span>, with the article written]</span> <span class="ar">الأَرَاضِى</span>, contr. to rule, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> as though they had formed a pl. from <span class="ar">آرُضٌ</span>; <span class="auth">(Ṣ;)</span> thus written in all the copies of the Ṣ; <span class="add">[accord. to SM; but in one copy of the Ṣ, I find <span class="ar long">كَأَنَّهُمْ جَمَعُوا ااراضًا</span>; and in another, <span class="ar">ارضًا</span>;]</span> and in one copy <span class="add">[is added]</span>, “thus it is found in his <span class="add">[J's]</span> handwriting;” but IB says that correctly he should have said <span class="ar">أَرْضَى</span>, like <span class="ar">أَرْطَى</span>; for as to <span class="ar">آرُضٌ</span>, its regular pl. would be <span class="ar">أَوَارِضُ</span>; and <span class="add">[SM says]</span> I have found it observed in a marginal note to the Ṣ that <a href="#AruDN">the pl. of <span class="ar">آرُضٌ</span></a> would be <span class="ar">أَآرِضُ</span>, like as <span class="ar">أَكَالِبُ</span> <a href="#OakolubN">is pl. of <span class="ar">أَكْلُبٌ</span></a>; and wherefore did he not say that <span class="ar">الاراضى</span> is a pl. of an unused sing., like <span class="ar">لَيَالٍ</span> and <span class="ar">أَهَالٍ</span>, so that it is as though it were <a href="#OaroDaApN">pl. of <span class="ar">أَرْضَاةٌ</span></a>, like as <span class="ar">لَيَالٍ</span> <a href="#laYolaApN">is pl. of <span class="ar">لَيْلَاةٌ</span></a>? yet if any one should propose the plea that it may be formed by transposition from <span class="ar">أَآرِضُ</span>, he would not say what is improbable; its measure being in this case <span class="ar">أَعَالِفُ</span>; the word being <span class="ar">أَرَاضِئُ</span>, and the <span class="ar">ء</span> being changed into <span class="ar">ى</span>: <span class="auth">(TA:)</span> accord. to Abu-l-Khattáb, <span class="auth">(Ṣ,)</span> <span class="ar">آرَاضٌ</span> is also <a href="#OaroDN">a pl. of <span class="ar">أَرْضٌ</span></a>, <span class="auth">(Ṣ, Ḳ,)</span> like as <span class="ar">آهَالٌ</span> <a href="#OaholN">is a pl. of <span class="ar">أَهْلٌ</span></a>; <span class="auth">(Ṣ;)</span> but IB says that, in the opinion of the critics, the truth with respect to what is related on the authority of Abu-l-Khattáb is, that from <span class="ar">أَرْضٌ</span> and <span class="ar">أَهْلٌ</span> are formed <span class="ar">أَرَاضٍ</span> and <span class="ar">أَهَالٍ</span>, as though they were pls. of <span class="ar">أَرْضَاةٌ</span> and <span class="ar">أَهْلَاةٌ</span>; like as they said <span class="ar">لَيْلَةٌ</span> and <span class="ar">لَيَال</span>, as though this were <a href="#laYolaApN">pl. of <span class="ar">لَيْلَاةٌ</span></a>. <span class="auth">(TA.)</span> It is said in proverbs, <span class="ar long">أَجْمَعُ مِنَ الأَرْضِ</span> <span class="add">[<em>More comprehensive than the earth</em>]</span>: <span class="auth">(TA:)</span> and <span class="ar long">آمَنُ مِنَ الأَرْضِ</span> <span class="add">[<em>More trustworthy than the earth,</em> in which treasures are securely buried]</span>: and <span class="ar long">أَشَدُّ مِنَ الأَرْضِ</span> <span class="add">[<em>Harder than the earth,</em> or <em>ground</em>]</span>: <span class="auth">(A, TA:)</span> and <span class="ar long">أَذَلُّ مِنَ الأَرْضِ</span> <span class="add">[<em>More vile,</em> or <em>more submissive, than the earth,</em> or <em>ground</em>]</span>. <span class="auth">(TA.)</span> And you say, <span class="ar long">مَنْ أَطَاعَنِى كُنْتُ لَهُ أَرْضَا</span> ‡ <span class="add">[<em>Whoso obeyeth me, I will be to him</em> as <em>ground</em> whereon one treads]</span>; denoting submissiveness. <span class="auth">(A, TA.)</span> And <span class="ar long">فُلَانٌ إِنٌ ضُرِبَ فَأَرْضٌ</span> ‡ <span class="add">[<em>Such one, if he be beaten, is</em> like <em>ground</em>]</span>; i. e. he cares not for beating. <span class="auth">(A, TA.)</span> One says also, <span class="ar long">لَا أَرْضَ لَكَ</span> <span class="add">[<em>Mayest thou have no land,</em> or <em>country!</em> or <em>thou hast no land,</em> or <em>country</em>]</span>; like as one says, <span class="ar long">لَا أُمَّ لَكَ</span>. <span class="auth">(Ṣ, Ḳ,)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlOaroDu_A2">
					<p><span class="add">[And hence,]</span> <span class="ar long">هُوَ ابْنُ أَرْضٍ</span> <em>He is a stranger,</em> <span class="auth">(A, Ḳ, TA,)</span> <em>of whom neither father nor mother is known.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AlOaroDu_A3">
					<p><span class="ar long">اِبْنُ الأَرْضِ</span> <span class="add">[with the art. <span class="ar">ال</span> prefixed to the latter word]</span> is <em>A certain plant,</em> <span class="auth">(AḤn, Ḳ,)</span> <em>which comes forth upon the summits of the</em> <span class="add">[<em>hills called</em>]</span> <span class="ar">آكَام</span>, <em>having a stem</em> (<span class="ar">أَصْل</span>), <em>but not growing tall,</em> <span class="auth">(AḤn,)</span> <em>which resembles hair, and is eaten,</em> <span class="auth">(AḤn, Ḳ,)</span> <em>and quickly dries up;</em> <span class="auth">(AḤn;)</span> <em>a species of</em> <span class="ar">بَقْل</span>, as also <span class="ar long">بِنْتُ الأَرْضِ</span>: <span class="auth">(Ṣ in art. <span class="ar">بنى</span>:)</span> and <span class="ar long">بَنَاتُ الأَرْضِ</span> <em>plants:</em> <span class="auth">(M in art. <span class="ar">بسر</span>:)</span> and <em>the places which are concealed from the pastor.</em> <span class="auth">(Ṣ in that art.)</span> Also <em>The pool that is left by a torrent:</em> <span class="auth">(T in art. <span class="ar">بنى</span>:)</span> and <span class="ar long">بَنَاتُ الأَرْضِ</span> <em>pools in which are remains of water:</em> <span class="auth">(IAạr in TA art. <span class="ar">بسر</span>:)</span> and <em>rivulets.</em> <span class="auth">(T in art. <span class="ar">بنى</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="AlOaroDu_A4">
					<p><span class="ar">أَرْضٌ</span> is also used to signify † <em>A carpet;</em> or <em>anything that is spread:</em> and in this sense, in poetry, it is sometimes made masc. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="AlOaroDu_A5">
					<p>And † <em>Anything that is low.</em> <span class="auth">(Ṣ, Ḳ.)</span> And ‡ The <em>lower,</em> or <em>lowest, part of the legs</em> of a horse or the like: <span class="auth">(Ṣ, Ḳ:)</span> or the <em>legs</em> of a camel or of a horse or the like: and the <em>part that is next to the ground thereof.</em> <span class="auth">(TA.)</span> You say <span class="ar long">بَعِيرٌ شَدِيدُ الأَرْضِ</span> ‡ <em>A camel strong in the legs.</em> <span class="auth">(TA.)</span> And <span class="ar long">فَرَسٌ بَعِيدٌ مَا بَيْمَ أَرْضِهِ وَسَمَائِهِ</span> ‡ <em>A horse that is large and tall.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="AlOaroDu_A6">
					<p>Also, of a man, ‡ The <em>knees and what is beneath,</em> or <em>below,</em> <span class="auth">(lit. <em>after,</em>)</span> <em>them.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="AlOaroDu_A7">
					<p>And of a sandal, † <span class="add">[The <em>lower surface of the sole;</em>]</span> the <em>part that touches the ground.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AlOaroDu_B1">
					<p><em>A febrile shivering; a tremor:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>vertigo:</em> or it signifies also <em>vertigo arising from a relaxed state, and occasioning a defluxion from the nose and eyes.</em> <span class="auth">(TA.)</span> I’Ab is related to have said, on the occasion of an earthquake, <span class="ar long">أَزُلْزِلَتِ الأَرْضُ أَمْ بِى أَرْضٌ</span>, <span class="auth">(Ṣ,)</span> i. e. <span class="add">[<em>Hath the earth been made to quake, or is there in me</em>]</span> <em>a tremor?</em> or <em>a vertigo?</em> <span class="auth">(TA.)</span> <span class="add">[<span class="ar long">أَهْلُ الأَرْضِ</span> signifies <em>A certain class of the jinn,</em> or <em>genii;</em> by whom human beings are believed to be possessed, and affected by an involuntary tremor; whence it seems that this appellation may perhaps be from <span class="ar">أَرْضٌ</span> as signifying “a tremor.” <a href="#maOoruwDN">See <span class="ar">مَأْرُوضٌ</span></a>: <a href="#xabalN">and see <span class="ar">خَبَلٌ</span></a>, as explained in the Ṣ.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="AlOaroDu_B2">
					<p>Also <em>Rheum;</em> syn. <span class="ar">زُكَامٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> in this sense masc.; or, accord. to Kr, fem., on the authority of Ibn-Aḥmar. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">الأَرْضُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="AlOaroDu_C1">
					<p><a href="#maOoruwDN">See also <span class="ar">مَأْرُوضٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaraDN">
				<h3 class="entry"><span class="ar">أَرَضٌ</span></h3>
				<div class="sense" id="OaraDN_A1">
					<p><span class="ar">أَرَضٌ</span>: <a href="#OaraDapN">see <span class="ar">أَرَضَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuroDapN">
				<h3 class="entry"><span class="ar">أُرْضَةٌ</span></h3>
				<div class="sense" id="OuroDapN_A1">
					<p><span class="ar">أُرْضَةٌ</span>: <a href="#IiroDapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiroDapN">
				<h3 class="entry"><span class="ar">إِرْضَةٌ</span></h3>
				<div class="sense" id="IiroDapN_A1">
					<p><span class="ar">إِرْضَةٌ</span> of herbage, <em>What suffices the camels,</em> or <em>other pasturing animals, for a year:</em> <span class="auth">(IAạr, AḤn, M:)</span> or <em>abundant herbage</em> or <em>pasture;</em> as also<span class="arrow"><span class="ar">أُرْضَةٌ↓</span></span> and<span class="arrow"><span class="ar">إِرَضَةٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaraDapN">
				<h3 class="entry"><span class="ar">أَرَضَةٌ</span></h3>
				<div class="sense" id="OaraDapN_A1">
					<p><span class="ar">أَرَضَةٌ</span> <span class="add">[The <em>wood-fretter;</em>]</span> <em>a certain insect that eats wood,</em> <span class="auth">(Ṣ A, Mṣb, Ḳ,)</span> <em>well known;</em> <span class="auth">(A, Ḳ;)</span> it is <em>a white worm, resembling the ant, appearing in the days of the</em> <span class="add">[<em>season called</em>]</span> <span class="ar">رَبِيع</span>: <span class="auth">(TA:)</span> there are two kinds: <em>one kind is small, like the large of the</em> <span class="ar">ذَرّ</span> <span class="add">[or <em>grubs of ants</em>]</span>; <em>and this is the bane of wood in particular:</em> <span class="auth">(AḤn, TA:)</span> or <em>this kind is the bane of wood and of other things, and is a white worm with a black head, not having wings, and it penetrates into the earth, and builds for itself a habitation of clay,</em> or <em>soil; and this is said to be that which ate the staff of Solomon</em> <span class="add">[as is related in the Ḳur xxxiv. 13, where it is called <span class="ar long">دَابَّةُ الأَرْضِ</span>, as is said in the A]</span>: <span class="auth">(TA:)</span> the other kind <span class="add">[<em>is the termite,</em> or <em>white ant; termes fatale</em> of Linn.; called by Forskål <span class="auth">(in his Descr. Animalium, &amp;c., p. 96,)</span> <em>termes arda, destructor; and this</em>]</span> <em>is like a large common ant, having wings; it is the bane of everything that is of wood, and of plants; except that it does not attack what is moist, or succulent; and it has legs:</em> <span class="auth">(AḤn, TA:)</span> <span class="pb" id="Page_0049"></span>the pl. is <span class="arrow"><span class="ar">أَرَضٌ↓</span></span> <span class="auth">(AḤn, Mṣb, TA)</span> and <span class="ar">أَرَضَاتٌ</span>; <span class="auth">(Mṣb;)</span> or, as some <span class="add">[more properly]</span> say, <span class="ar">أَرَضٌ</span> is a quasi-pl. <span class="add">[or coll. gen.]</span> n. <span class="auth">(AḤn, TA.)</span> It is said in a prov., <span class="ar long">آكَلُ مِنَ الأَرَضَةِ</span> <span class="add">[<em>More consuming than the wood-fretter,</em> or <em>the termite</em>]</span>. <span class="auth">(TA.)</span> And in another, <span class="ar long">أَفْسَدُ مِنَ الأَرَضَةِ</span> <span class="add">[<em>More marring,</em> or <em>injuring,</em> or <em>destructive, than the wood-fretter,</em> or <em>the termite.</em>]</span> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OariDapN">
				<h3 class="entry"><span class="ar">أَرِضَةٌ</span></h3>
				<div class="sense" id="OariDapN_A1">
					<p><span class="ar">أَرِضَةٌ</span>: <a href="#OariyDN">see <span class="ar">أَرِيضٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiraDapN">
				<h3 class="entry"><span class="ar">إِرَضَةٌ</span></h3>
				<div class="sense" id="IiraDapN_A1">
					<p><span class="ar">إِرَضَةٌ</span>: <a href="#IiroDapN">see <span class="ar">إِرْضَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaruwDN">
				<h3 class="entry"><span class="ar">أَرُوضٌ</span></h3>
				<div class="sense" id="OaruwDN_A1">
					<p><span class="ar">أَرُوضٌ</span>: <a href="#OaryDN">see <span class="ar">أَريضٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OariyDN">
				<h3 class="entry"><span class="ar">أَرِيضٌ</span></h3>
				<div class="sense" id="OariyDN_A1">
					<p><span class="ar">أَرِيضٌ</span> part. n. of <span class="ar">أَرُضَ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">أَرِيضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OariyDN_A2">
					<p>You say <span class="ar long">أَرْضٌ أَرِيضَةٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and<span class="arrow"><span class="ar">أَرِضَةٌ↓</span></span> <span class="auth">(TA)</span> <em>Land that is thriving,</em> or <em>productive;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> <em>pleasing to the eye;</em> <span class="auth">(AA, Ṣ, A, Ḳ;)</span> <em>and disposed by nature to yield good produce:</em> <span class="auth">(A, Ḳ, TA:)</span> or <em>fruitful; increasing in plants</em> or <em>herbage:</em> <span class="auth">(IAạr:)</span> or <em>level,</em> or <em>soft:</em> <span class="auth">(ISh:)</span> or <em>that collects moisture, and becomes luxuriant with herbage; that is soft to tread upon, pleasant to sit upon, productive, and good in its herbage</em> or <em>vegetation:</em> <span class="auth">(AḤn:)</span> it also signifies <em>a wide land;</em> syn. <span class="ar">عَرِيضَةٌ</span>: <span class="auth">(TA:)</span> and <span class="ar">إِرَاضٌ</span> <span class="add">[<a href="#OariyDN">as pl. of <span class="ar">أَرِيضٌ</span></a>]</span> is syn. with <span class="ar">عِرَاضٌ</span> and <span class="ar">وِسَاعٌ</span>; <span class="auth">(AA, Ḳ, TA;)</span> as though the <span class="ar">ء</span> were a substitute for the <span class="ar">ع</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">أَرِيضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OariyDN_A3">
					<p><span class="ar">أَرِيضٌ</span> is also an imitative sequent to <span class="ar">عَرِيضٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> as in the phrase <span class="ar long">أَرِيضٌ شَىْءٌ عَرِيضٌ</span> <span class="add">[<em>A very wide thing</em>]</span>: <span class="auth">(Ṣ:)</span> or it signifies <em>fat,</em> as an epithet: <span class="auth">(Ḳ:)</span> some use it in this sense without <span class="ar">عرِيض</span>, applied to a kid. <span class="auth">(Ṣ.)</span> And you say, <span class="ar long">اِمْرَأَةٌ عَرِيضَةٌ أَرِيضَةٌ</span> <span class="add">[<em>A very wide,</em> or <em>wide and fat, woman;</em> or, as seems to be indicated in the TA in art. <span class="ar">عرَض</span>, <em>prolific and perfect</em>]</span>; and in like manner,<span class="arrow"><span class="ar">مُؤْرِضَةٌ↓</span></span>. <span class="auth">(TA.)</span> You say also <span class="ar long">رَجُلٌ أَرِيضٌ</span>, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar long">أَرُوضٌ↓ لِلْخَيْرِ</span></span>, <span class="auth">(A,)</span> <em>A man lowly,</em> or <em>submissive;</em> <span class="auth">(Ṣ;)</span> <em>naturally disposed to good,</em> or <em>to do good.</em> <span class="auth">(Ṣ, A.)</span> And <span class="ar long">نَفْسٌ وَاسِعٌ أَرِيضٌ</span>: <a href="#raAbiTN">see <span class="ar">رَابِطٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MraDuhumo">
				<h3 class="entry"><span class="ar">آرَضُهُمْ</span></h3>
				<div class="sense" id="MraDuhumo_A1">
					<p><span class="ar long">هُوَ آرَضُهُمْ بِهِ</span> <em>He is the most adapted, meet, suited, fitted,</em> or <em>fit, of them, for it;</em> or <em>most worthy of them of it.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">هُوَآرَضُهُمْ أَنْ يَفْعَلَ ذلِكَ</span> <em>He is the most adapted,</em>, &amp;c., or <em>most worthy, of them to do that.</em> <span class="auth">(Aṣ, Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWoriDapN">
				<h3 class="entry"><span class="ar">مُؤْرِضَةٌ</span></h3>
				<div class="sense" id="muWoriDapN_A1">
					<p><span class="ar">مُؤْرِضَةٌ</span>: <a href="#OariyDN">see <span class="ar">أَرِيضٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoruwDN">
				<h3 class="entry"><span class="ar">مَأْرُوضٌ</span></h3>
				<div class="sense" id="maOoruwDN_A1">
					<p><span class="ar">مَأْرُوضٌ</span> Wood <em>eaten by the</em> <span class="ar">أَرَضَة</span> <span class="add">[or <em>woodfretter,</em> or <em>termite,</em> but generally meaning the former]</span>; <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَرْضٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">مَأْرُوضٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maOoruwDN_B1">
					<p>A person <em>affected with</em> <span class="ar">خَبَل</span> <span class="add">[q. v.]</span> <em>from the jinn,</em> or <em>genii, and</em> <span class="add">[<em>what are called</em>]</span> <span class="ar long">أَهْلُ الأَرْضِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> i. e. <span class="auth">(so accord. to the Ṣ and TA, but in the Ḳ “and”)</span> <em>he who moves about his head and body involuntarily.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">مَأْرُوضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="maOoruwDN_B2">
					<p>A person <em>affected with</em> <span class="ar">زُكَام</span> <span class="add">[or <em>rheum</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> accord. to Ṣgh, <span class="add">[who seems, like J, not to have known <span class="ar">أُرِضَ</span>,]</span> from <span class="ar">آرَضَهُ</span>; <span class="auth">(Ṣgh, TA;)</span> whereas by rule, <span class="add">[if from <span class="ar">آرِضَهُ</span>,]</span> it should be <span class="ar">مُؤْرَضٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaOoriDN">
				<h3 class="entry"><span class="ar">مُسْتَأْرِضٌ</span></h3>
				<div class="sense" id="musotaOoriDN_A1">
					<p><span class="ar long">فَسِيلٌ مُسْتَأْرِضٌ</span>, and <span class="ar long">وَدِيَّةٌ مُسْتَأْرِضَةٌ</span>, <em>A young palm-tree,</em> and <em>a small young palm-tree, having a root in the ground:</em> such as grows forth from the trunk of the mother-tree is called <span class="ar">رَاكِبٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارض</span> - Entry: <span class="ar">مُسْتَأْرِضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="musotaOoriDN_A2">
					<p><span class="ar">مُسْتَأْرِضٌ</span> also signifies <em>Heavy, slow,</em> or <em>sluggish, inclining,</em> or <em>propending, to the ground.</em> <span class="auth">(IB.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0047.pdf" target="pdf">
							<span>Lanes Lexicon Page 47</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0048.pdf" target="pdf">
							<span>Lanes Lexicon Page 48</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0049.pdf" target="pdf">
							<span>Lanes Lexicon Page 49</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
