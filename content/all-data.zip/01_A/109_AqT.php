<article class="root" id="Root_AqT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/108_AqHwAn">اقحوان</a></span>
				<span class="ar">اقط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/110_Akd">اكد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AqT_1">
				<h3 class="entry">1. ⇒ <span class="ar">أقط</span></h3>
				<div class="sense" id="AqT_1_A1">
					<p><span class="ar">أَقَطَهُ</span>, aor <span class="ar">ـِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَقْطٌ</span>, <span class="auth">(Ṣ,)</span> <em>He made it</em> <span class="auth">(namely food)</span> <em>with</em> <span class="ar">أَقِط</span> q. v. infrà. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اقط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AqT_1_A2">
					<p>Also, <span class="auth">(aor. and inf. n. as above, TA,)</span> <em>He fed him with</em> <span class="ar">أَقِط</span>: <span class="auth">(AʼObeyd, Ḳ:)</span> like <span class="ar">لَبَنَهُ</span> from <span class="ar">لَبَنٌ</span> and <span class="ar">لَبَأَهُ</span> from <span class="ar">لِبَأٌ</span> Lḥ mentions the verb in this sense as used without its being made transitive. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اقط</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AqT_1_A3">
					<p><span class="add">[<span class="ar">أَقِطَ</span> in the CK is a mistake for <span class="ar">آقَطَ</span> q. v.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AqT_4">
				<h3 class="entry">4. ⇒ <span class="ar">آقط</span></h3>
				<div class="sense" id="AqT_4_A1">
					<p><span class="ar">آقَطَ</span>, <span class="auth">(Lḥ, Ḳ, <span class="add">[in the CK, incorrectly, <span class="ar">أَقِطَ</span>,]</span>)</span> of the measure <span class="ar">أَفْعَلَ</span>, agreeably with a common rule, applying to anything, <span class="auth">(Lḥ, TA,)</span> <em>He had much</em> <span class="ar">أَقِط</span>; <em>his</em> <span class="ar">أَقِط</span> <em>became much,</em> or <em>abundant.</em> <span class="auth">(Lḥ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AqT_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتقط</span></h3>
				<div class="sense" id="AqT_8_A1">
					<p><span class="ar">ائتقط</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَقَطَ</span>]</span> <em>He made,</em> or <em>prepared,</em> <span class="ar">أَقِط</span>: <span class="auth">(Ṣ:)</span> strangely omitted in the O and in the Ḳ. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaqiTN">
				<h3 class="entry"><span class="ar">أَقِطٌ</span></h3>
				<div class="sense" id="OaqiTN_A1">
					<p><span class="ar">أَقِطٌ</span> <span class="auth">(Fr, Az, Ṣ, Mṣb, Ḳ)</span> and <span class="ar">إِقِطٌ</span> <span class="auth">(Fr, O, Ḳ)</span> and <span class="ar">أَقَطٌ</span> <span class="auth">(Fr, Ḳ)</span> and <span class="ar">إِقْطٌ</span>, <span class="auth">(Ṣ, O, Mṣb, Ḳ,)</span> the last sometimes occurring in poetry, and formed from the first, by transferring the vowel of the <span class="ar">ق</span> to the preceding letter, <span class="auth">(Ṣ,)</span> or a contraction of the second, accord. to a common usage of <span class="add">[the tribe of]</span> Temeem in the cases of words of this measure, <span class="auth">(O,)</span> and <span class="ar">أَقْطٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">أُقْطٌ</span>, <span class="auth">(Aṣ, Ḳ,)</span> of all which the first is the most chaste, and the last is strange, <span class="auth">(TA,)</span> <span class="add">[<em>A preparation of dried curd;</em>]</span> <em>a preparation of,</em> or <em>thing made from, milk</em> <span class="auth">(Az, Mṣb, Ḳ)</span> <em>of sheep</em> or <em>goats,</em> <span class="auth">(Ḳ,)</span> <em>which has been churned, and of which the butter has been taken,</em> <span class="auth">(Az, Mṣb, Ḳ,)</span> <em>cooked, and then left until it becomes concrete:</em> <span class="auth">(Az, Mṣb:)</span> or <em>made from the milk of camels,</em> in particular: <span class="auth">(IAạr:)</span> or <em>milk which is dried, and has become hard, like stone; with which one cooks;</em> repeatedly mentioned in trads.: <span class="auth">(TA:)</span> or <em>a thing made from milk; being a kind of cheese:</em> <span class="auth">(Ḥar p. 587:)</span> pl. <span class="ar">أُقْطَانٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaqBaATN">
				<h3 class="entry"><span class="ar">أَقَّاطٌ</span></h3>
				<div class="sense" id="OaqBaATN_A1">
					<p><span class="ar">أَقَّاطٌ</span> <em>A maker of</em> <span class="ar">أَقِط</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoquwTN">
				<h3 class="entry"><span class="ar">مَأْقُوطٌ</span></h3>
				<div class="sense" id="maOoquwTN_A1">
					<p><span class="ar">مَأْقُوطٌ</span> Food <em>made with</em> <span class="ar">أَقِط</span>. <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
