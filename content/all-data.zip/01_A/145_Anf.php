<article class="root" id="Root_Anf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/144_Ans">انس</a></span>
				<span class="ar">انف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/146_Anq">انق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Anf_1">
				<h3 class="entry">1. ⇒ <span class="ar">أنف</span></h3>
				<div class="sense" id="Anf_1_A1">
					<p><span class="ar">أَنَفَهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْنِفُ</span>}</span></add> <span class="auth">(M, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْنُفُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَنْفٌ</span>, <span class="auth">(M,)</span> <em>He struck,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> or <em>hit,</em> or <em>hurt,</em> <span class="auth">(M,)</span> <em>his nose;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> namely, a man's. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anf_1_A2">
					<p><em>It</em> <span class="auth">(the water)</span> <em>reached his nose,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> on the occasion of his descending into a river; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">آنفهُ↓</span></span>, <span class="auth">(Ḳ, <span class="add">[but in some copies written again <span class="ar">أَنَفَهُ</span>,]</span>)</span> inf. n. <span class="ar">إِينَافٌ</span>. <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Anf_1_B1">
					<p><span class="ar long">أَنَفَتِ الإِبِلُ</span>, <span class="auth">(inf. n. as above, TA,)</span> <em>The camels trod herbage,</em> or <em>pasture, such as is termed</em> <span class="ar">أُنُف</span>, <span class="auth">(ISk, Ṣ, Ḳ,)</span> i. e., <em>which had not been pastured upon.</em> <span class="auth">(Ṣ.)</span> <span class="add">[But in the TT, as from the M, I find <span class="arrow"><span class="ar">آانَفَ↓</span></span>, <span class="auth">(which should rather be written <span class="ar">أَانَفَ</span>, or, accord. to the more usual mode, <span class="ar">آنَفَ</span>,)</span> <em>He trod such herbage,</em> or <em>pasture.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Anf_1_C1">
					<p><span class="ar">أَنِفَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْنَفُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَنَفٌ</span>, <span class="auth">(M,)</span> <em>He</em> <span class="auth">(a camel)</span> <em>had a complaint of,</em> or <em>suffered pain in, his nose, from the</em> <span class="ar">بُرَة</span> <span class="add">[or <em>nose-ring</em>]</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> from ISk. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Anf_1_C2">
					<p><span class="ar long">أَنِفَتِ الإِبِلُ</span>, accord. to certain of the Kilábees, means <em>The flies alighted upon the noses of the camels, and they sought places which they did not seek before.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="Anf_1_C3">
					<p><span class="ar long">أَنِفَ مِنْهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْنَفُ</span>}</span></add>, inf. n. <span class="ar">أَنَفٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَنَفَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> or the latter is a simple subst., <span class="auth">(Mṣb,)</span> <span class="add">[<em>He turned up his nose at it;</em>]</span> <em>he disdained it; scorned it; abstained from it,</em> or <em>refused to do it, by reason of disdain and pride;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> <em>he disliked it,</em> or <em>hated it, and his soul was above it;</em> <span class="auth">(L;)</span> namely, a thing: <span class="auth">(Ṣ, M, L, Mṣb:)</span> and <em>he shunned it, avoided it,</em> or <em>kept himself far from it:</em> <span class="auth">(Mṣb:)</span> and <em>he disliked it,</em> or <em>hated it;</em> namely, a saying. <span class="auth">(AZ, T, Mṣb.)</span> You say, <span class="ar long">مَارَأَيْتُ أَحْمَى أَنَفًا مِنْ فُلَانٍ</span> <span class="add">[<em>I have not seen any one more vehemently disdainful,</em> or <em>scornful, than such a one</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">حَمَلَ مِنْ ذٰلِكَ أَنَفًا</span> <em>He conceived, in consequence of that, disdain,</em> or <em>scorn, arising from indignation and anger.</em> <span class="auth">(TA, from a trad.)</span> <span class="add">[The verb is also trans. without <span class="ar">من</span>: you say,]</span> <span class="ar long">يَأْنَفُ أَنْ يُضامَ</span> <span class="add">[<em>He disdains,</em> or <em>scorns,</em> or <em>refuses to bear,</em> or <em>to submit to, being injured</em>]</span>. <span class="auth">(Ḳ.)</span> <span class="add">[When immediately trans.,]</span> <span class="ar">أَنِفَ</span> also signifies <em>He loathed, disliked,</em> or <em>regarded with disgust.</em> <span class="auth">(IAạr, T.)</span> You say, <span class="ar long">أَنِفَ البَعِيرُ الكَلَأَ</span> <em>The camel loathed, disliked,</em> or <em>regarded with disgust, the herbage,</em> or <em>pasture.</em> <span class="auth">(T.)</span> And <span class="ar long">أَنفَ الطَّعَامَ وَغَيْرَهُ</span> <em>He disliked the food</em>, &amp;c. <span class="auth">(M.)</span> And <span class="ar long">أَنِفَتْ فَرَسِى هٰذِهِ هٰذَا البَلَدَ</span> <em>This my mare disliked this region.</em> <span class="auth">(T, as heard from an Arab of the desert.)</span> And <span class="ar long">تَأْنَفُ فَحْلَهَا</span> <em>She</em> <span class="auth">(a woman, and a mare, and a camel, being pregnant,)</span> <em>dislikes her male,</em> or <em>stallion.</em> <span class="auth">(T.)</span> And <span class="ar">أَنِفَتْ</span>, said of a woman, signifies <em>She, being pregnant, had no appetite for anything.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anf_2">
				<h3 class="entry">2. ⇒ <span class="ar">أنّف</span></h3>
				<div class="sense" id="Anf_2_A1">
					<p><a href="#Anf_4">see 4</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Anf_2_B1">
					<p><span class="ar">تَأْنِيفٌ</span> also signifies † The <em>sharpening,</em> or <em>making pointed, the extremity</em> of a thing. <span class="auth">(Ṣ.)</span> You say of a spear-head, or an arrow-head, or a blade, <span class="ar">أُنِّفّ</span>, inf. n. <span class="ar">تَأْنِيفٌ</span>, <span class="auth">(Ḳ,)</span> † <em>It was sharpened</em> or <em>pointed</em> <span class="add">[<em>at its extremity</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Anf_2_B2">
					<p><span class="add">[Used as a subst.,]</span> † <em>Sharpness of the extremity</em> of the hock; which, in a horse, is approved. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Anf_2_B3">
					<p><span class="ar long">أُنِّفَ تَأْنِيفَ السَّيْرِ</span>, said by an Arab of the desert in describing a horse, means † <em>He was made even, like as is made even the cut thong</em> or <em>strap.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Anf_2_C1">
					<p>† The <em>seeking after herbage,</em> or <em>pasture,</em> <span class="auth">(Ḳ, TA,)</span> <em>such as is termed</em> <span class="ar">أُنُف</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Anf_2_C2">
					<p><span class="ar long">أنّف مَالَهُ</span>, <span class="auth">(T,)</span> or <span class="ar">الإِبِلَ</span>, <span class="auth">(Ḳ,)</span> inf. n. as above; and<span class="arrow"><span class="ar">آنَفَهَا↓</span></span>, <span class="auth">(T, Ṣ, Ḳ,)</span> inf. n. <span class="ar">إِينَافٌ</span>; <span class="auth">(T;)</span> † <em>He pastured his beasts upon the first of the herbage:</em> <span class="auth">(T:)</span> or <em>he pursued, with the camels, repeatedly,</em> or <em>gradually,</em> or <em>step by step,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>after the first of the herbage,</em> <span class="auth">(Ṣ,)</span> or <em>after the herbage which had not been pastured upon:</em> <span class="auth">(Ḳ,* TA:)</span> or <em>he went with them thereto.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anf_4">
				<span class="pb" id="Page_0116"></span>
				<h3 class="entry">4. ⇒ <span class="ar">آنف</span></h3>
				<div class="sense" id="Anf_4_A1">
					<p><span class="ar">آنفهُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">إِينَافٌ</span>, <span class="auth">(Ṣ,)</span> <em>He,</em> <span class="auth">(Ṣ,)</span> or <em>it,</em> <span class="auth">(M,)</span> <em>made him to have a complaint of,</em> or <em>to suffer pain in, his nose.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anf_4_A2">
					<p><a href="#Anf_1">See also <span class="ar">أَنَفَهُ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Anf_4_A3">
					<p><em>He,</em> or <em>it, induced him to feel disdain, scorn, indignation, and anger;</em> <span class="auth">(IF, M, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">انّفهُ↓</span></span>, inf. n. <span class="ar">تَأْنِيفٌ</span>: <span class="auth">(Ḳ:)</span> or <em>caused him to dislike,</em> or <em>hate,</em> or <em>to loath,</em> or <em>feel disgust.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Anf_4_B1">
					<p>† <em>He hastened it;</em> namely, his affair. <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Anf_4_C1">
					<p><a href="#Anf_2">See also 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Anf_4_D1">
					<p><span class="ar">آنف</span> as an intrans. verb: <a href="#Anf_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anf_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأنّف</span></h3>
				<div class="sense" id="Anf_5_A1">
					<p><span class="ar long">تَتَأَنَّفُ الشَّهَوَاتِ</span> † <em>She desires of her husband, with eagerness, one thing after another, by reason of intense longing in pregnancy.</em> <span class="auth">(T, the Moḥeeṭ, L, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anf_5_A2">
					<p><span class="ar long">يَتَأَنَّفُ الإِخْوَانَ</span> † <em>He seeks the brethren, they disdaining,</em> or <em>scorning,</em> or <em>disliking; not holding social intercourse with any one.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Anf_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتنف</span></h3>
				<div class="sense" id="Anf_8_A1">
					<p><a href="#Anf_10">see 10</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anf_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأنف</span></h3>
				<div class="sense" id="Anf_10_A1">
					<p><span class="ar">استأنفهُ</span> and<span class="arrow"><span class="ar">ائتنفهُ↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَنَفَهُ</span>]</span> † <em>He took</em> <span class="add">[<em>its</em> <span class="ar">أَنْف</span>, i. e.,]</span> <em>the first of it:</em> <span class="auth">(M:)</span> <em>he began it,</em> or <em>commenced it:</em> <span class="auth">(Ṣ,* M, Mṣb, Ḳ:*)</span> or <em>i. q.</em> <span class="ar">اِسْتَقْبَلَهُ</span> <span class="add">[which has also the latter of the two significations mentioned above, <span class="auth">(Mgh in art. <span class="ar">قبل</span>,)</span> and moreover signifies <em>he anticipated it;</em> and from what follows here, it seems to be probable that this last signification, as well as the other, may be meant by it in this instance]</span>: <span class="auth">(T, M:)</span> namely, a thing, <span class="auth">(M, Mṣb,)</span> or an affair. <span class="auth">(T.)</span> You say, <span class="ar long">استأنفهُ بِوَعْدٍ</span> † <em>He made him a promise in anticipation; without his asking it of him.</em> <span class="auth">(M.)</span> And, of a woman, <span class="ar long">اُسْتُؤْنِفَتْ بِالنِّكَاحِ أَوَّلًا</span> † <span class="add">[<em>She was just married,</em> or <em>bedded, for the first time</em>]</span>. <span class="auth">(M.)</span> <a href="#OunufN">See also <span class="ar">أُنُفٌ</span></a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anf_10_A2">
					<p><span class="add">[Hence, <span class="ar long">حَرْفُ ٱسْتِئْنَافٍ</span>, in grammar, <em>An inceptive particle, placed at the commencement of a new proposition grammatically independent of that which precedes it.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanofN">
				<h3 class="entry"><span class="ar">أَنْفٌ</span></h3>
				<div class="sense" id="OanofN_A1">
					<p><span class="ar">أَنْفٌ</span> a word of well-known meaning; <span class="auth">(Lth, T, Ḳ;)</span> The <em>nose;</em> syn. <span class="ar">مَعْطِسٌ</span>; <span class="auth">(Mṣb;)</span> the <em>aggregate composed of the two nostrils and the septum and the</em> <span class="add">[<em>bone called</em>]</span> <span class="ar">قَصَبَة</span>, which is the hard part of the <span class="ar">انف</span>; <span class="auth">(MF;)</span> <em>i. q.</em> <span class="ar">مَنْخِرٌ</span> <span class="add">[which is evidently an explanation by a synecdoche, as this word properly signifies <em>nostril</em>]</span>: <span class="auth">(M:)</span> it pertains to man and to others: <span class="auth">(Ṣ:)</span> <span class="arrow"><span class="ar">أُنْفٌ↓</span></span> is a dial. var. of the same; <span class="auth">(MF, TA;)</span> and so is <span class="arrow"><span class="ar">إِنْفٌ↓</span></span>, which is a form used by the vulgar peculiarly: <span class="auth">(TA:)</span> the pl. <span class="add">[of pauc.]</span> is <span class="ar">آنُفٌ</span> and <span class="ar">آنَافٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">أُنُوفٌ</span>. <span class="auth">(T, Ṣ, M, Mṣb, Ḳ.)</span> The dual is applied to The <em>two nostrils;</em> as in the saying of Muzáhim El-'Okeylee, <span class="ar long">يَسُوفُ بِأَنْفِيْهِ النِّقَاعَ</span> <span class="add">[<em>He scents with his two nostrils the dust</em>]</span>. <span class="auth">(TA.)</span> You say also, <span class="ar long">هُوَ يَتَتَبَّعُ أَنْفَهُ</span> ‡ <em>He scents,</em> or <em>sniffs, the odour, and follows it.</em> <span class="auth">(T, <span class="add">[in which, however, I find <span class="ar">يَتْبَعُ</span> in the place of <span class="ar">يتتبّع</span>]</span> O, L, Ḳ, TA.)</span> And, of a she-camel, <span class="ar long">تَرْأَمُ بِأَنْفِهِا</span> † <span class="add">[<em>She makes a show of affection with her nose, by smelling her young one;</em> not having true love]</span>. <span class="auth">(Ṣ, M, Ḳ, voce <span class="ar">مُذَائِرٌ</span>;, &amp;c.: <a href="#muEaAriDN">see also <span class="ar">مُعَارِضٌ</span></a>.)</span> And <span class="ar long">مَاتَ حَتْفَ أَنْفِهِ</span> <span class="auth">(Ṣ, Ḳ, &amp;c., in art. <span class="ar">حتف</span>,)</span> and <span class="ar long">حتف أَنْفِيْهِ</span>, <span class="auth">(Ḳ ibid.,)</span> † <em>He died</em> <span class="add">[<em>a natural death,</em>]</span> <em>on his bed,</em> <span class="auth">(Ḳ,)</span> <em>without being slain or beaten</em> <span class="auth">(Ṣ, Ḳ)</span> <em>or drowned or burned.</em> <span class="auth">(Ḳ. <span class="add">[<a href="index.php?data=06_H/016_Htf">See art. <span class="ar">حتف</span></a>]</span>)</span> And <span class="ar long">حَمِىَ أَنْفُهُ</span> ‡ <em>He became vehemently angry,</em> or <em>enraged;</em> as also <span class="ar long">وَرِمَ أَنْفُهُ</span>. <span class="auth">(IAth. <span class="add">[<a href="index.php?data=06_H/185_Hme">See also art. <span class="ar">حمى</span></a>]</span>)</span> And <span class="ar long">رَجُلٌ حَمِىُّ الأَنْفِ</span> ‡ <em>A disdainful,</em> or <em>scornful, man; who disdains,</em> or <em>scorns, being injured.</em> <span class="auth">(T, Ḳ, TA. <span class="add">[<a href="index.php?data=06_H/185_Hme">See, again, art. <span class="ar">حمى</span></a>.]</span>)</span> And <span class="ar long">سَمِىُّ الأَنْفِ</span> † <span class="add">[lit. <em>Highnosed,</em> signifies the same;]</span> <em>i. q.</em> <span class="ar">أَنْفَانُ</span>. <span class="auth">(T, Ḳ.)</span> And <span class="ar long">أَنْفٌ فِى السَّمَآءِ وَٱسْتٌ فِى المَآءِ</span> † <span class="add">[<em>A nose in the sky and a rump in the water</em>]</span>; a prov., applied to him who magnifies himself in words and is little in actions. <span class="auth">(Ḥar p. 641.)</span> And <span class="ar long">حَعَلَ أَنْفَهُ فِى قَفَاهُ</span> ‡ <span class="add">[lit. <em>He put his nose in the back of his neck</em>]</span>; meaning <em>he turned away from the truth,</em> or <em>what was right, and betook himself to what was false,</em> or <em>vain:</em> <span class="auth">(Ḳ, TA:)</span> expressing the utmost degree of turning away, or turning the head, from a thing. <span class="auth">(TA.)</span> And <span class="ar long">أَضَاعَ مَطْلَبَ أَنْفِهِ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar long">مُوْضِعَ أَنْفِهِ</span>, <span class="auth">(M,)</span> † <span class="add">[<em>He neglected,</em> or <em>left unprotected,</em>]</span> <em>the womb from which he had come forth:</em> <span class="auth">(Th, M:)</span> or <em>the</em> <span class="ar">فَرْج</span> <em>of his mother.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> And <span class="ar long">هُوَ الفَحْلُ لَا يُقْرَعُ أَنْفُهُ</span>, and <span class="ar long">لَا يُقْدَعُ</span>, <em>He is the speaker,</em> or <em>orator, who is not to be rebutted.</em> <span class="auth">(TA.)</span> <span class="ar long">الأَسدِ أَنْفُ</span> † <span class="add">[<em>The nose of the lion</em>]</span> is <em>the asterism called</em> <span class="ar">النَّثْرَةُ</span>, q. v. <span class="auth">(Ḳzw in his Description of the Mansions of the Moon.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنْفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanofN_A2">
					<p>† <span class="add">[<em>A prominent part</em> of anything, as being likened to a nose;]</span> the <em>extremity</em> of anything. <span class="auth">(M.)</span> <span class="add">[Thus,]</span> <span class="ar long">أَنْفُ جَبَلٍ</span> ‡ <em>A prominence,</em> or <em>projecting part, of a mountain.</em> <span class="auth">(T, Ṣ, M, Mṣb, TA.)</span> <span class="ar long">أَنْفُ النَّابِ</span>, <span class="auth">(Ṣ, M. Ḳ, TA,)</span> in <span class="add">[some of]</span> the copies of the Ḳ erroneously, <span class="ar">البَابِ</span>, <span class="auth">(TA,)</span> ‡ <em>The extremity,</em> <span class="auth">(Ṣ, M, Ḳ, TA,)</span> or <em>edge,</em> <span class="auth">(M, TA,)</span> <em>of the canine tooth,</em> or <em>tush, when it comes forth.</em> <span class="auth">(Ṣ, M, Ḳ, TA.)</span> <span class="ar long">أَنْفُ خُفِّ البَعِيرِ</span> † <em>The extremity of the</em> <span class="ar">مَنْسِم</span> <span class="add">[i. e. <em>toe,</em> or <em>each of the two nails of the foot,</em>]</span> <em>of the camel.</em> <span class="auth">(T, Ḳ.)</span> <span class="ar long">أَنْفُ اللِّحْيَةِ</span> ‡ <em>The fore part,</em> <span class="auth">(M, TA,)</span> or <em>side,</em> <span class="auth">(Ḳ,)</span> <em>of the beard.</em> <span class="auth">(M, Ḳ, TA.)</span> <span class="ar long">أَنْفُ النَّعْلِ</span> † <em>The toe,</em> or <em>foremost extremity, of the sandal</em> <span class="add">[also called its <span class="ar">أَسَلَة</span> and its <span class="ar">ذُنَابَة</span>]</span>. <span class="auth">(M.)</span> <span class="ar long">أَنْفَا القَوْسِ</span> † <em>The two extremities which are in the inner sides of the two curved ends of the bow.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنْفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OanofN_A3">
					<p>† The <em>first,</em> or <em>first part,</em> of anything; <span class="auth">(Ṣ, M, Ḳ;)</span> relating also to times; <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar">مُسْتَأْنَفٌ↓</span></span> <span class="auth">(M, TA.)</span> Thus, <span class="ar long">أَنْفُ المَرْعَى</span> † <em>The first of the herbage,</em> or <em>pasture.</em> <span class="auth">(Ṣ,* M.)</span> <span class="ar long">أَنْفُ المَطَرِ</span> † <em>The first vegetation produced by the rain.</em> <span class="auth">(T, Ḳ.)</span> <span class="ar long">جَآءَ فِى أَنْفِ الخَيْلِ</span> ‡ <span class="add">[<em>He came among the first of the horses,</em> or <em>horsemen</em>]</span>. <span class="auth">(TA.)</span> <span class="ar long">سَارَ فِى أَنْفِ النَّهَارِ</span> ‡ <span class="add">[<em>He journeyed in the first part of the day</em>]</span>. <span class="auth">(TA.)</span> <span class="ar long">هٰذَا أَنْفُ عَمَلِ فُلَانٍ</span> ‡ <em>This is the first of the things which such a one has begun to do.</em> <span class="auth">(T, TA.)</span> <span class="ar long">أَنْفُ الشَّدِّ</span>, <span class="auth">(T, Ṣ, M,)</span> and <span class="ar">العَدْوِ</span>, <span class="auth">(M,)</span> † <em>The first of the run,</em> or <em>running:</em> <span class="auth">(T:)</span> <em>the most vehement thereof.</em> <span class="auth">(T, Ṣ, M, Ḳ.*)</span> <span class="ar long">أَنْفُ البَرْدِ</span> † <em>The first of the cold:</em> <span class="auth">(T:)</span> <em>the most vehement thereof;</em> <span class="auth">(T, Ṣ, M;)</span> so says Yaákoob. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنْفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OanofN_A4">
					<p>‡ <em>A lord,</em> or <em>chief.</em> <span class="auth">(IAạr, T, Ḳ.)</span> You say, <span class="ar long">هُوَ أَنْفُ قَوْمِهِ</span> ‡ <em>He is the lord,</em> or <em>chief, of his people.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنْفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OanofN_A5">
					<p>‡ <em>A piece broken off</em> of a cake of bread. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنْفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OanofN_A6">
					<p>† <em>A part</em> of ground, or land, <em>that is hard, and lying open, exposed to the sun.</em> <span class="auth">(IF, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OunofN">
				<h3 class="entry"><span class="ar">أُنْفٌ</span></h3>
				<div class="sense" id="OunofN_A1">
					<p><span class="ar">أُنْفٌ</span>: <a href="#OanofN">see <span class="ar">أَنْفٌ</span></a>, first sentence:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنْفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OunofN_B1">
					<p><a href="#OunufN">and see <span class="ar">أُنُفٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IinofN">
				<h3 class="entry"><span class="ar">إِنْفٌ</span></h3>
				<div class="sense" id="IinofN_A1">
					<p><span class="ar">إِنْفٌ</span>: <a href="#OanofN">see <span class="ar">أَنْفٌ</span></a>, first sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanifN">
				<h3 class="entry"><span class="ar">أَنِفٌ</span></h3>
				<div class="sense" id="OanifN_A1">
					<p><span class="ar">أَنِفٌ</span> A camel <em>having a complaint of,</em> or <em>suffering pain in, his nose, from the</em> <span class="ar">بُرَة</span> <span class="add">[or <em>nose-ring</em>]</span>: <span class="auth">(ISk, Ṣ, M, Ḳ:)</span> or <em>wounded by the nose-rein, whether it be with a</em> <span class="ar">خِشَاش</span> <em>or</em> <span class="ar">بُرَة</span> <span class="auth">(AʼObeyd, T, M)</span> <em>or</em> <span class="ar">خِزَامَة</span> <span class="add">[all of which are different kinds of nose-rings]</span>. <span class="auth">(AʼObeyd, T.)</span> And consequently, <em>Submissive, and tractable:</em> <span class="auth">(Ṣ, TA:)</span> or <em>submissive and obedient, that dislikes chiding and beating, and goes as he is able to do spontaneously and easily:</em> <span class="auth">(Aboo-Saʼeed, TA:)</span> and<span class="arrow"><span class="ar">آنِفٌ↓</span></span> signifies the same; <span class="auth">(AʼObeyd, M, Ḳ;)</span> but the former is the more correct and the more chaste: <span class="auth">(Ṣgh, Ḳ:)</span> by rule, it should be <span class="ar">مَأْنُوفٌ</span>, like <span class="ar">مَصْدُورٌ</span>, <span class="auth">(T, Ṣ, M,)</span> and <span class="ar">مَبْطُونٌ</span>. <span class="auth">(T, Ṣ.)</span> To such a camel, the believer is likened in a trad.; <span class="auth">(T, Ṣ, M;)</span> because he ceases not to complain, or suffer pain; <span class="auth">(M;)</span> or because he does not require to be chidden nor to be punished, but endures and performs what is incumbent on him. <span class="auth">(Aboo-Saʼeed, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanifN_A2">
					<p><em>Disdaining,</em> or <em>disdainful; scorning,</em> or <em>scornful; i. q.</em> <span class="ar long">حَمِىُّ الأَنْفِ</span>: and<span class="arrow"><span class="ar">أَنْفَانُ↓</span></span> <span class="add">[signifies the same;]</span> <em>i. q.</em> <span class="ar long">سَمِىُّ الأَنْفِ</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنِفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OanifN_B1">
					<p><a href="#AnifN">See also <span class="ar">آنِفٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OunufN">
				<h3 class="entry"><span class="ar">أُنُفٌ</span></h3>
				<div class="sense" id="OunufN_A1">
					<p><span class="ar long">رَوْضَةٌ أُنُفٌ</span> ‡ <em>A meadow of new herbage,</em> <span class="auth">(Mṣb,)</span> <em>not pastured upon</em> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>by any one;</em> <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">مُؤْنِفٌ↓</span></span>: <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> or <em>untrodden:</em> contracted, by poetic licence, into <span class="arrow"><span class="ar">أُنْفٌ↓</span></span>, in a verse of Abu-n-Nejm. <span class="auth">(M.)</span> And <span class="ar long">كَلَأٌ أُنُفٌ</span> † <em>Herbage not pastured upon</em> <span class="auth">(Ṣ, M)</span> <em>by any one.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنُفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OunufN_A2">
					<p><span class="ar long">كَأْسٌ ٱنُفٌ</span> † <em>A cup of wine not drunk:</em> <span class="auth">(Ḳ:)</span> or <em>from which one has not drunk before;</em> as though the drinking thereof were <span class="add">[but just]</span> begun; like <span class="ar long">رَوْضَةٌ أُنُفٌ</span>: <span class="auth">(Ṣ)</span> or † <em>full:</em> and in like manner, <span class="ar long">مَنْهَلٌ أُنُفٌ</span> † <span class="add">[<em>a full watering-place</em>]</span>; <span class="auth">(M;)</span> or ‡ <em>not before drunk from.</em> <span class="auth">(TA.)</span> And <span class="ar long">خَمْرٌ أُنُفٌ</span> ‡ <em>Wine of which none has before been taken from its jar.</em> <span class="auth">(M, TA.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنُفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OunufN_A3">
					<p><span class="ar long">أَرْضٌ أُنُفٌ</span> <em>i. q.</em> <span class="ar">أَنِيغَةٌ</span>, q. v. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنُفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OunufN_A4">
					<p><span class="ar long">نَقِيذَةٌ أُنْفٌ</span> † <em>A long</em> <span class="add">[as though <em>new and undiminished</em>]</span> <em>coat of mail.</em> <span class="auth">(L in art. <span class="ar">نقذ</span>, from El-Mufaddal.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنُفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OunufN_A5">
					<p><span class="ar long">أَمْرٌ أُنُفٌ</span> † <em>An event brought to pass at the first, not being before decreed:</em> <span class="auth">(Ḳ, TA:)</span> accord. to those who assert that there is no decreeing <span class="add">[by God]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنُفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OunufN_A6">
					<p><span class="ar long">مِشْيَةٌ أُنُفٌ</span> † <em>A goodly</em> <span class="add">[as though <em>novel</em>]</span> <em>gait,</em> or <em>manner of walking.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أُنُفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OunufN_A7">
					<p><span class="ar long">آتِيكَ مِنْ ذِى أُنُفٍ</span> is like the phrase <span class="ar long">مِنْ ذِى قَبَلٍ</span>; i. e., <span class="ar long">فِيمَا يُسْتَقْبَلٌ</span> <span class="add">[<em>I will come to thee in what is</em> (<em>now</em>) <em>to be begun</em> (<em>of time</em>); meaning, <em>immediately;</em> nearly the same as <span class="ar">آنِفًا</span>, but relating to the nearest future time, whereas this latter relates to the nearest past time]</span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="pb" id="Page_0117"></span>And <span class="ar long">أَفْعَلُ ذَاكَ مِنْ ذِى أُنُفٍ</span>:i. e.,<span class="arrow"><span class="ar long">فِيمَا يُسْتَأْنَفُ↓</span></span> <span class="add">[<em>I will do that in what is</em> (<em>now</em>) <em>to begun</em>, &amp;c.]</span>; like <span class="ar long">مِنْ ذِى عَوْضٍ</span>. <span class="auth">(Ḳ in art. <span class="ar">عوض</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oanofapu">
				<h3 class="entry"><span class="ar">أَنْفَةُ</span></h3>
				<div class="sense" id="Oanofapu_A1">
					<p><span class="ar long">أَنْفَةُ الصَّلَاةِ</span> † <em>The beginning,</em> or <em>commencement, of prayer;</em> <span class="auth">(Ḳ;)</span> i. e. <em>the first saying of</em> <span class="ar long">اَللّٰهُ أَكْبَرُ</span>: <span class="auth">(TA:)</span> accord. to a relation of a trad., in which it occurs, with damm, <span class="add">[<span class="ar">أُنْفَة</span>,]</span> <span class="auth">(IAth, Ḳ,)</span> but correctly with fet-ḥ. <span class="auth">(Hr, IAth, Ḳ.)</span> The <span class="ar">ة</span> seems to be here added to <span class="ar">أَنْف</span> as it is in <span class="ar">ذَنَبَةٌ</span> for <span class="ar">ذَنَبٌ</span>. <span class="auth">(Ṣgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanafapN">
				<h3 class="entry"><span class="ar">أَنَفَةٌ</span></h3>
				<div class="sense" id="OanafapN_A1">
					<p><span class="ar">أَنَفَةٌ</span> <em>Disdain; scorn; disdainful and proud incompliance or refusal;</em> <span class="auth">(Mṣb;)</span> <em>indignation;</em> and <em>anger:</em> <span class="auth">(TA:)</span> a subst. <span class="add">[or, accord. to the Ṣ and M and Ḳ, an inf. n.]</span> from <span class="ar long">أَنِفَ مِنْهُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OanofaAnu">
				<h3 class="entry"><span class="ar">أَنْفَانُ</span></h3>
				<div class="sense" id="OanofaAnu_A1">
					<p><span class="ar">أَنْفَانُ</span>: <a href="#OanifN">see <span class="ar">أَنِفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanofiyBapN">
				<h3 class="entry"><span class="ar">أَنْفِيَّةٌ</span></h3>
				<div class="sense" id="OanofiyBapN_A1">
					<p><span class="ar">أَنْفِيَّةٌ</span> <em>Snuff, for the nose:</em> but this is post-classical. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanuwfN">
				<h3 class="entry"><span class="ar">أَنُوفٌ</span></h3>
				<div class="sense" id="OanuwfN_A1">
					<p><span class="ar">أَنُوفٌ</span> A man <em>very disdainful, scornful,</em> or <em>indignant; very disdainfully and proudly incompliant</em> or <em>refusing;</em> <span class="auth">(M;)</span> <em>who disdains,</em> or <em>scorns, exceedingly, to do ignoble deeds:</em> <span class="auth">(Ḥar p. 312:)</span> pl. <span class="ar">أُنُفٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنُوفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanuwfN_A2">
					<p>A woman <em>whose nose has a pleasant odour:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or <em>whom one likes to smell:</em> <span class="auth">(IAạr, M:)</span> or <em>who disdains, scorns, abstains from, shuns,</em> or <em>dislikes, that in which is no good.</em> <span class="auth">(Ibn-ʼAbbád, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaniyfN">
				<h3 class="entry"><span class="ar">أَنِيفٌ</span></h3>
				<div class="sense" id="OaniyfN_A1">
					<p><span class="ar">أَنِيفٌ</span> † A mountain <em>which produces vegetation before other regions.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> And <span class="ar long">أَرْضٌ أَنِيفَةٌ</span>, <span class="auth">(T, M,)</span> or <span class="ar long">أَنِيفَةُ النَّبْتِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> † <em>Land that produces its vegetation early:</em> <span class="auth">(T:)</span> or <em>that produces vegetation quickly:</em> <span class="auth">(Eṭ-Ṭáee, ISk, Ṣ, Ḳ:)</span> or <em>that produces vegetation;</em> as also<span class="arrow"><span class="ar">أُنُفٌ↓</span></span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">أَنِيفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaniyfN_B1">
					<p>Applied to iron, <em>i. q.</em> <span class="ar">أَنِيثُ</span>; i. e. <em>Soft.</em> <span class="auth">(Aboo-Turáb, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OunaAfieBN">
				<h3 class="entry"><span class="ar">أُنَافِىٌّ</span></h3>
				<div class="sense" id="OunaAfieBN_A1">
					<p><span class="ar">أُنَافِىٌّ</span> <span class="auth">(with damm, Ḳ)</span> <em>Having a large nose;</em> <span class="auth">(Yaạḳoob, Ṣ, M, Ḳ;)</span> applied to a man: <span class="auth">(M, Ḳ:)</span> similar to <span class="ar">عُضَادِّىٌ</span> and <span class="ar">أُذَانِىٌّ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mnafu">
				<h3 class="entry"><span class="ar">آنَفُ</span></h3>
				<div class="sense" id="Mnafu_A1">
					<p><span class="ar">آنَفُ</span> <span class="add">[<em>More,</em> and <em>most, disdainful,</em>, &amp;c.]</span>. You say, <span class="ar long">مَا رَأَيْتُ آنَفَ مِنْ فُلَان</span> <em>I have not seen any one more disdainful,</em> or <em>scornful,</em> or <em>indignant, than such a one.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">آنَفُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Mnafu_B1">
					<p><span class="ar long">هٰذِهِ آنَفُ بِلَادِ ٱللّٰهِ</span> <em>This is the speediest, in producing vegetation, of the countries of God.</em> <span class="auth">(T, Ṣ,* M,* Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MnifN">
				<h3 class="entry"><span class="ar">آنِفٌ</span></h3>
				<div class="sense" id="MnifN_A1">
					<p><span class="ar">آنِفٌ</span>: <a href="#OanifN">see <span class="ar">أَنِفٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">آنِفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MnifN_B1">
					<p><span class="ar">آنِفًا</span> means † <em>In the beginning,</em> or <em>first part, of this present time in which we are;</em> from <span class="ar">أَنْفٌ</span> as meaning the “first,” or “first part,” of a thing: and hence what here immediately follows. <span class="auth">(Ḥam p. 348.)</span> <span class="ar long">مَا ذَا قَالَ آنِفًا</span>, <span class="auth">(T, Ṣ,* M, Ḳ,*, &amp;c.,)</span> and<span class="arrow"><span class="ar">أَنِفًا↓</span></span>, <span class="auth">(IAạr, Bḍ, Ḳ, Jel,)</span> in the Ḳur <span class="add">[xlvii. 18]</span>, <span class="auth">(M, &amp;c.,)</span> means ‡ <em>What was this that he said just now?</em> <span class="auth">(Zj, T, M, Bḍ, Jel:)</span> or, <em>a little while ago?</em> <span class="auth">(IAạr, T, Ḳ:)</span> i. e., <em>in the first time near to us?</em> <span class="auth">(Zj, T, M:)</span> from <span class="ar long">اِسْتَأْنَفْتُ الشَّىْءَ</span> “I began the thing.” <span class="auth">(Zj, T, M.)</span> You say also, <span class="ar long">أَتَيْتُ فُلَانًا آنِفًا</span> ‡ <span class="add">[<em>I came to such a one a little while ago</em>]</span>; like as you say, <span class="ar long">مِنْ ذِى قِبَلٍ</span>. <span class="auth">(Lth, T.)</span> And <span class="ar long">جَآءَ آنِفًا</span> ‡ <em>He came a little while ago;</em> syn. <span class="ar">قُبَيْلَ</span>. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">فَعَلَهُ بِآنِفَةٍ↓</span></span>, mentioned by IAạr, but not explained by him; in my opinion, <span class="add">[says ISd,]</span> like <span class="ar long">فَعَلَهُ آنِفًا</span> ‡ <span class="add">[<em>He did it a little while ago:</em> or <em>just now</em>]</span>. <span class="auth">(M.)</span> And it is said in a trad., <span class="ar long">أُنْزِلَتْ عَلَيَّ سُورَةٌ آنِفًا</span> <em>A chapter of the Ḳur-án has been sent down to me now.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MnifapN">
				<h3 class="entry"><span class="ar">آنِفَةٌ</span></h3>
				<div class="sense" id="MnifapN_A1">
					<p><span class="ar">آنِفَةٌ</span> ‡ The <em>first part of life</em> (<span class="ar">مَيْعَة</span> and <span class="ar">أَوَّلِيَّة</span>) of a boy. <span class="auth">(Ks, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">آنِفَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MnifapN_A2">
					<p><a href="#AnifN">See also <span class="ar">آنِفٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWonafN">
				<h3 class="entry"><span class="ar">مُؤْنَفٌ</span> / <span class="ar">مُؤْنَفَةٌ</span></h3>
				<div class="sense" id="muWonafN_A1">
					<p><span class="ar">مُؤْنَفٌ</span>; its fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُؤْنَفَةٌ</span>}</span></add>: <a href="#muwanBafN">see voce <span class="ar">مُؤَنَّفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWonifN">
				<h3 class="entry"><span class="ar">مُؤْنِفٌ</span></h3>
				<div class="sense" id="muWonifN_A1">
					<p><span class="ar">مُؤْنِفٌ</span>: <a href="#OunufN">see <span class="ar">أُنُفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWanBafN">
				<h3 class="entry"><span class="ar">مُؤَنَّفٌ</span></h3>
				<div class="sense" id="muWanBafN_A1">
					<p><span class="ar">مُؤَنَّفٌ</span> † <em>Sharpened at its extremity;</em> or <em>pointed;</em> <span class="auth">(M, Ḳ;)</span> applied to a spear-head, or an arrowhead, or a blade, <span class="auth">(Ḳ,)</span> or anything. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">مُؤَنَّفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWanBafN_A2">
					<p>† <em>Made even:</em> a thong, or strap, <em>made of a certain measure, and evenly.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">مُؤَنَّفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWanBafN_B1">
					<p><span class="ar long">إِبِلٌ مُؤَنَّفَةٌ</span> † <em>Camels with which one pursues repeatedly,</em> or <em>gradually,</em> or <em>step by step, after the first of the herbage;</em> and so<span class="arrow"><span class="ar">مُؤْنَفَةٌ↓</span></span>: <span class="auth">(M:)</span> and the former epithet is applied to sheep or goats. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">مُؤَنَّفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="muWanBafN_B2">
					<p>The former of these two epithets, applied to a woman, signifies † <em>Just married</em> or <em>bedded,</em> (<span class="ar long">الَّتِى ٱسْتُؤْنِفَتْ بِالنِّكَاحِ</span>,) <em>for the first time.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOonuwfN">
				<h3 class="entry"><span class="ar">مَأْنُوفٌ</span></h3>
				<div class="sense" id="maOonuwfN_A1">
					<p><span class="ar">مَأْنُوفٌ</span> A camel <em>that is urged on by</em> <span class="add">[<em>means of the rein attached to</em>]</span> <em>his nose.</em> <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYonaAfN">
				<h3 class="entry"><span class="ar">مِئْنَافٌ</span></h3>
				<div class="sense" id="miYonaAfN_A1">
					<p><span class="ar">مِئْنَافٌ</span> † A man <em>who begins to make use of the places of pasturing and alighting;</em> <span class="auth">(M;)</span> <em>who pastures his beasts upon the first of the herbage.</em> <span class="auth">(Aṣ, T, Ḳ.* <span class="add">[In the CK, <span class="ar long">اُنُفُ الكَلَأِ</span> is put for <span class="ar long">أَنْفَ الكَلَأِ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">مِئْنَافٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="miYonaAfN_A2">
					<p>† A man <span class="auth">(TA)</span> <em>journeying in the beginning,</em> or <em>first part, of the night:</em> <span class="auth">(Ḳ:)</span> so in all the copies of the Ḳ; but correctly, as in the Moḥeeṭ and the O, <em>in the beginning,</em> or <em>first part, of the day.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotanafN">
				<h3 class="entry"><span class="ar">مُؤْتَنَفٌ</span></h3>
				<div class="sense" id="muWotanafN_A1">
					<p><span class="ar">مُؤْتَنَفٌ</span> † <span class="add">[A place]</span> <em>from which nothing has been eaten;</em> as also<span class="arrow"><span class="ar">مُتَأَنِّفٌ↓</span></span>; <span class="auth">(Ḳ;)</span> which latter is explained by Ibn-ʼAbbád as signifying a place <em>not eaten</em> <span class="add">[<em>from</em>]</span> <em>before.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انف</span> - Entry: <span class="ar">مُؤْتَنَفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWotanafN_A2">
					<p><span class="ar long">جَارِيَةٌ مُؤْتَنَفَةُ الشَّبَابِ</span> † A girl <span class="add">[<em>in the prime of youth;</em>]</span> <em>in whom no trace of agedness appears.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOanBifN">
				<h3 class="entry"><span class="ar">مُتَأَنِّفٌ</span></h3>
				<div class="sense" id="mutaOanBifN_A1">
					<p><span class="ar">مُتَأَنِّفٌ</span>: <a href="#muWotanafN">see <span class="ar">مُؤْتَنَفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="musotaOonafN">
				<h3 class="entry"><span class="ar">مُسْتَأْنَفٌ</span></h3>
				<div class="sense" id="musotaOonafN_A1">
					<p><span class="ar">مُسْتَأْنَفٌ</span>: <a href="#OanofN">see <span class="ar">أَنْفٌ</span></a>, in the latter part of the paragraph.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0115.pdf" target="pdf">
							<span>Lanes Lexicon Page 115</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0116.pdf" target="pdf">
							<span>Lanes Lexicon Page 116</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0117.pdf" target="pdf">
							<span>Lanes Lexicon Page 117</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
