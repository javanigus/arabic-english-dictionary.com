<article class="root" id="Root_Axc">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/034_Axt">اخت</a></span>
				<span class="ar">اخذ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/036_Axr">اخر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Axc_1">
				<h3 class="entry">1. ⇒ <span class="ar">أخذ</span></h3>
				<div class="sense" id="Axc_1_A1">
					<p><span class="ar">أَخَذَ</span>, <span class="auth">(Ṣ, A, L, &amp;c.,)</span> in the first pers. of which, <span class="ar">أَخَذْتُ</span>, <span class="add">[and the like,]</span> the <span class="ar">ذ</span> is generally changed into <span class="ar">ت</span>, and incorporated into the <span class="add">[augmentative]</span> <span class="ar">ت</span>, <span class="add">[but in pronunciation only, for one writes <span class="ar">أَخَذتُّ</span> and the like,]</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْخُذُ</span>}</span></add>, imperative <span class="ar">خُذْ</span>, originally <span class="ar">ٱؤْخُذْ</span>, <span class="auth">(Ṣ, L,)</span> which latter form sometimes occurs, <span class="add">[but with <span class="ar">و</span> in the place of <span class="ar">ؤْ</span> when the <span class="ar">ا</span> is pronounced with damm,]</span> <span class="auth">(TA,)</span> inf. n. <span class="ar">أَخْذٌ</span> <span class="auth">(Ṣ, L, Mṣb, Ḳ, &amp;c.)</span> and <span class="ar">تَأْخَاذٌ</span>, <span class="auth">(Ṣ, L, Ḳ,)</span> the latter having an intensive signification; <span class="auth">(MF;)</span> and <span class="ar">وَخَذَ</span> is a dial. var., as mentioned by Ibn-Umm-Kásim and others on the authority of AḤei; <span class="auth">(MF in art. <span class="ar">تخذ</span>;)</span> <em>He took; he took with his hand; he took hold of;</em> <span class="auth">(Ṣ, A, L, Mṣb, Ḳ;)</span> a thing. <span class="auth">(Ṣ, L.)</span> You say, <span class="ar long">خُذِ الخِطَامَ</span> and <span class="ar long">خُذْ بِالخِطَامَ</span> <em>Take thou,</em> or <em>take thou with thy hand,</em> or <em>take thou hold of, the nose-rein</em> of the camel: <span class="auth">(Ṣ, L, Mṣb:)</span> the <span class="ar">ب</span> in the latter phrase being redundant. <span class="auth">(Mṣb.)</span> <span class="add">[And <span class="ar long">أَخَذَ بِيَدِهِ</span>, lit. <em>He took his hand,</em> or <em>arm;</em> meaning † <em>he aided,</em> or <em>assisted, him:</em> a phrase of frequent occurrence.]</span> And <span class="ar long">أَخَذَ عَلَىيَدِ فُلَانٍ</span> † <em>He prevented, restrained,</em> or <em>withheld, such a one from doing that which he desired; as though he laid hold upon his hand,</em> or <em>arm:</em> <span class="auth">(L:)</span> and <span class="ar long">أَخَذَ عَلَى يَدِهِ دُونَ مَا يُرِيُدهُ</span> <span class="add">[signifies the same]</span>. <span class="auth">(Ḳ in art. <span class="ar">لغد</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Axc_1_A2">
					<p>Also, inf. n. <span class="ar">أَخْذٌ</span>, <em>He took,</em> or <em>received; contr. of</em> <span class="ar">أَعْطَى</span>. <span class="auth">(L.)</span> <span class="add">[Hence,]</span> <span class="ar long">أَخَذَ عَنْهُ</span>, † <em>He received from him traditions,</em> and <em>the like.</em> <span class="auth">(TA passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Axc_1_A3">
					<p>† <span class="add">[<em>He took,</em> or <em>derived,</em> or <em>deduced,</em> a word, a phrase, and a meaning.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Axc_1_A4">
					<p>‡ <em>He took, received,</em> or <em>admitted, willingly,</em> or <em>with approbation; he accepted.</em> <span class="auth">(B, MF.)</span> So in the Ḳur <span class="add">[vii. 198]</span>, <span class="ar long">خُذِ العَفْوَ</span> ‡ <span class="add">[<em>Take thou willingly,</em> or <em>accept thou, superfluous property,</em> or <em>such as is easily spared</em> by others]</span>. <span class="auth">(MF.)</span> So too in the same <span class="add">[iii. 75]</span>, <span class="ar long">وَأَخَذتُّمْ عَلَى ذٰلِكُمْ إِصْرِى</span> ‡ <span class="add">[<em>And do ye accept my covenant to that effect?</em>]</span>. <span class="auth">(B.)</span> <span class="add">[And in the phrases, <span class="ar long">أَخَذْنَا مِيثَاقَكُمْ بِالعَمَلِ بِمَا فِى التَّوْارَاةِ</span>, <span class="auth">(Jel ii. 60,)</span> and <span class="ar long">عَلَى العَمّلِ بما فى التوارة</span>, <span class="auth">(Idem ii. 87,)</span> † <em>We accepted your covenant to do according to what is in the Book of the Law revealed to Moses.</em>]</span> <span class="ar long">خُذْ عَنْكَ</span> <span class="add">[is elliptical, and]</span> means <span class="ar long">خُذْ مَا أَقُولُ وَدَع عَنْكَ الشَّكَ والمِرآءَ</span> † <span class="add">[<em>Accept thou what I say, and dismiss from thee doubt and obstinate disputation</em>]</span>. <span class="auth">(Ṣ, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Axc_1_A5">
					<p><em>He took</em> a thing <em>to,</em> or <em>for, himself; took possession of</em> it; <em>got,</em> or <em>acquired,</em> it; syn. <span class="ar">حَازَ</span>; <span class="auth">(Z, Er-Rághib, B;)</span> which, accord. to Z and Er-Rághib and others, is the primary signification; <span class="auth">(MF;)</span> and <span class="ar">حَصَّلَ</span>. <span class="auth">(B.)</span> <span class="add">[<a href="#Axc_8">See also 8</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Axc_1_A6">
					<p><span class="add">[<em>He took and kept;</em>]</span> <em>he retained; he detained:</em> as in the Ḳur <span class="add">[xii. 78]</span>, <span class="ar long">فَخُذْ أَحَدَنَا مَكَانَهُ</span> <span class="add">[<em>Therefore retain thou one of us in his stead</em>]</span>. <span class="auth">(B.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Axc_1_A7">
					<p><span class="add">[<em>He took,</em> as meaning <em>he took away.</em> Hence,]</span> <span class="ar long">أَخَذَ مِنْهُ السَّيْرُ</span> <em>Journeying,</em> or <em>travel, took from him strength;</em> (<span class="ar">القُوَّةَ</span> being understood;) <em>weakened him.</em> <span class="auth">(Ḥar p. 529.)</span> And <span class="ar long">أَخَذَ مِنَ الشَّارِبِ</span>, <span class="auth">(Mgh,)</span> and <span class="ar long">مِنَ الشَّعَرِ</span>, <span class="auth">(Mṣb,)</span> <em>He clipped,</em> or <em>cut off from,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>the mustache,</em> <span class="auth">(Mgh,)</span> and <em>the hair.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Axc_1_A8">
					<p><em>He,</em> or <em>it, took by force;</em> or <em>seized:</em> <span class="auth">(B:)</span> † <em>he,</em> or <em>it, overcame, overpowered,</em> or <em>subdued:</em> said by some to be the primary signification. <span class="auth">(MF.)</span> <span class="add">[<a href="#EalowBaA">See also <span class="ar long">أَخَذَهُ عَلْوَّا</span></a>, &amp;c., <a href="index.php?data=27_w/053_wHd">in art. <span class="ar">علو</span></a>: <a href="#faWoqu">and <span class="ar long">أَخَذَهُ مِنْ فَوْقُ</span></a>, &amp;c., <a href="index.php?data=20_f/225_fwq">in art. <span class="ar">فوق</span></a>.]</span> It is said in the Ḳur <span class="add">[ii. 256]</span>, <span class="ar long">لَا تَأْخُذُهُ سِنَةِ وَلَا نَوْمٌ</span> † <em>Neither drowsiness nor sleep shall seize</em> <span class="add">[or <em>overcome</em>]</span> <em>Him.</em> <span class="auth">(B.)</span> <span class="add">[And you say, <span class="ar long">أَخَذَتْهُ رِعْدَةٌ</span> † <em>A tremour seized, took, affected,</em> or <em>influenced, him.</em> And <span class="ar long">أَخَذَهُ بَطْنُهُ</span> † <em>His belly affected him with a desire to evacuate it.</em>]</span> You say also, <span class="ar long">أَخَذَ فِيهِ الشَّرَابُ</span> † <em>The wine affected him,</em> or <em>influenced him, so that he became intoxicated.</em> <span class="auth">(TA in art. <span class="ar">ثمل</span>.)</span> And <span class="ar long">أَخَذَ الرَّأْسَ</span> <span class="auth">(Mṣb in art. <span class="ar">سور</span>, &amp;c.)</span> and <span class="ar long">أَخَذَ بِالرَّأْسِ</span> <span class="auth">(Ḳ in art. <span class="ar">حمى</span>, &amp;c.)</span> † <span class="add">[<em>It had an overpowering influence upon the head</em>]</span>; meaning wine. <span class="auth">(Mṣb, Ḳ.)</span> And <span class="ar long">أَخَذَ بِالحَلْقِ</span> <span class="add">[<em>It</em> <span class="auth">(food, &amp;c.)</span> <em>choked</em>]</span>. <span class="auth">(IAạr in art. <span class="ar">نشب</span> in the TA, and Ṣ in art. <span class="ar">بشع</span>, &amp;c.)</span> And <span class="ar long">لَا يَأْخُذُ فِيهِ قَوْلُ قَائِلٍ</span> † <span class="add">[<em>Nothing that any one may say will have any power,</em> or <em>effect,</em> or <em>influence, upon him</em>]</span>; meaning that he obeyeth no one. <span class="auth">(L in art. <span class="ar">ليت</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Axc_1_A9">
					<p><em>He took captive.</em> <span class="auth">(L, Mṣb, B.)</span> So in the Ḳur <span class="add">[ix. 5]</span>, <span class="ar long">فَٱقْتُلُوا ٱلمُشْرِكِينَ حَيْثُ وَجَدتُّمُوهُمْ وَخُذُوهُمْ</span> <span class="add">[<em>Then slay ye the believers in a plurality of gods wherever,</em> or <em>whenever, ye find them, and take them captives</em>]</span>. <span class="auth">(Bḍ, L, B.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Axc_1_A10">
					<p><a href="#Axc_2">See also 2</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Axc_1_A11">
					<p><em>He gained the mastery over</em> a person, <em>and killed,</em> or <em>slew,</em> him; <span class="auth">(Zj, L;)</span> as also<span class="arrow"><span class="ar">آخَذَ↓</span></span>: <span class="auth">(L:)</span> or simply, † <em>he killed,</em> or <em>slew.</em> <span class="auth">(B.)</span> It is said in the Ḳur <span class="add">[xl. 5]</span>, <span class="ar long">وَهَمَّتْ كُّلُ أُمَّةٍ بِرَسُولِهِمْ لِيَأْخُذُوهُ</span>, meaning <span class="add">[<em>And every nation hath purposed against their apostle</em>]</span> <em>that they might gain the mastery over him, and slay him;</em> <span class="auth">(Zj, L;)</span> or † <em>that they might slay him.</em> <span class="auth">(B.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="Axc_1_A12">
					<p>† <em>He</em> <span class="auth">(God, Mṣb)</span> <em>destroyed</em> a person: <span class="auth">(Mṣb, MF:)</span> and † <em>extirpated,</em> or <em>exterminated.</em> <span class="auth">(MF.)</span> <span class="ar long">فَأَخَذَهُمُ ٱللّٰهُ بِذُنُوبِهِمْ</span> <span class="add">[in the Ḳur iii. 9 and xl. 22]</span> means <em>But God destroyed them for their sins.</em> <span class="auth">(Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="Axc_1_A13">
					<p>‡ <em>He punished,</em> or <em>chastised;</em> <span class="auth">(L, Mṣb, B, Ḳ, MF;)</span> as also<span class="arrow"><span class="ar">آخَذَ↓</span></span>: <span class="auth">(L, Mṣb, MF:)</span> as in the phrases, <span class="ar long">أَخَذَهُ بِذَنْبِهِ</span> <span class="auth">(Mṣb, Ḳ *)</span> <span class="pb" id="Page_0029"></span>and<span class="arrow"><span class="ar long">آخَذَهُ↓ بِهِ</span></span>, inf. n. of the latter <span class="ar">مُؤَاخَذَةٌ</span>, <span class="auth">(Ṣ, L, Mṣb, Ḳ,)</span> ‡ <em>he punished,</em> or <em>chastised, him for his sin,</em> or <em>offence:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">أُخِذَ بِذَنْبِهِ</span> means † <em>he was restrained and requited and punished for his sin,</em> or <em>offence:</em> <span class="auth">(L:)</span> or, accord. to some, <span class="ar">أَخَذَ</span> signifies <em>he extirpated,</em> or <em>exterminated;</em> and<span class="arrow"><span class="ar">آخذ↓</span></span> <em>he punished,</em> or <em>chastised, without extirpating,</em> or <em>exterminating.</em> <span class="auth">(MF.)</span> <span class="add">[F or<span class="arrow"><span class="ar">آخذ↓</span></span>,]</span> some say <span class="ar">وَاخَذَ</span>, <span class="auth">(Ṣ, L,)</span> which is not allowable, <span class="auth">(Ḳ,)</span> accord. to some; but accord. to others, it is a chaste form; <span class="auth">(MF;)</span> of the dial. of El-Yemen, and used by certain of the seven readers <span class="add">[of the Ḳur-án]</span> in the instance of <span class="ar long">لَا يُوَاخِذُكُمُ ٱللّٰهُ</span> <span class="add">[ii. 225 and v. 91]</span>; and the inf. N. in that dial. Is <span class="ar">مُوَاخَذَةٌ</span>, and the imperative is <span class="ar">وَاخِذْ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="Axc_1_A14">
					<p>‡ <em>He made a violent assault upon</em> a person, <em>and wounded</em> him <em>much.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[You say also, <span class="ar long">أَخَذَهُ بِلِسَانِهِ</span>, meaning † <em>He assailed him with his tongue; vituperated him; spoke against him.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="Axc_1_A15">
					<p><span class="add">[<em>He took, took to,</em> or <em>adopted.</em>]</span> You say, <span class="ar long">أَخَذَ أَخَذَهُمْ</span> and <span class="ar">إِخْذَهُمْ</span>, &amp;c.: <a href="#OaxocN">see <span class="ar">أَخْذٌ</span>, below</a>. And <span class="ar long">أَخَذَ فِى طَرِيقِ كَذَا</span> <span class="add">[<em>He took such a road</em>]</span>: and <span class="ar long">أَخَذَ عَنْ يَمِينِهِ أَوْ يَسَارِهِ</span> <span class="add">[<em>he took the way by,</em> or <em>on, the right of him,</em> or <em>it, or the left of him,</em> or <em>it</em>]</span>. <span class="auth">(Ṣ in art. <span class="ar">نظر</span>.)</span> <span class="add">[And <span class="ar long">أَخَذَ بِالحَزْمِ</span>, and <span class="ar long">فِى الحَزْمِ</span>, <span class="auth">(the former the more common, the latter occurring in art. <span class="ar">حوط</span> in the Ḳ,)</span> † <em>He took the course prescribed by prudence, discretion, precaution,</em> or <em>good judgment; he used precaution:</em> and, like <span class="ar long">أَخَذَ بِالثِّقَهِ</span>, † <em>he took the sure course</em> in his affair.]</span> And <span class="ar long">أَخَذَ حِذْرَهُ</span> † <em>He took care; became cautious,</em> or <em>vigilant.</em> <span class="auth">(Bḍ in iv. 73 and 103.)</span> <span class="add">[And <span class="ar long">أَخَذَ بِمَا قَالَ فُلَانٌ</span> † <em>He took to,</em> or <em>adopted and followed,</em> or <em>adhered to, what such a one said:</em> see Ḥar p. 367; where it is said that <span class="ar">اخذ</span> when thus used is made trans. by means of <span class="ar">ب</span> because it implies the meaning of <span class="ar">تَشَبَّثَ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="Axc_1_A16">
					<p><em>He took to, set about, began,</em> or <em>commenced;</em> as in the saying, <span class="ar long">أَخَذَ يَفْعَلُ كَذَا</span> <em>He took to, set about, began,</em> or <em>commenced, doing such a thing;</em> in which case, accord. to Sb, <span class="ar">اخذ</span> is one of those verbs which do not admit of one's putting the act. part. n. in the place of the verb which is its enunciative: <span class="add">[i. e., one may not say <span class="ar">فَاعِلًا</span> in the place of <span class="ar">يفعل</span> in the phrase above:]</span> and as in <span class="ar long">أَخَذَ فِى كَذَا</span> <em>He began, commenced,</em> or <em>entered upon, such a thing.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A17</span>
				</div>
				<div class="sense" id="Axc_1_A17">
					<p><span class="add">[It is used in a variety of other phrases, in which the primary meaning is more or less apparent; and several of these will be found explained with other words occurring therein. The following instances may be here added.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A18</span>
				</div>
				<div class="sense" id="Axc_1_A18">
					<p><span class="ar long">طَرِيقٌ يَأْخُذُ فِى رَمْلَةٍ</span> <span class="add">[<em>A road leading into,</em> or <em>through, a tract of sand</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">فرز</span>.)</span> And <span class="ar long">أَخَذَ بِهِمُ الطَّرِيقُ فِى غَيْرِ المَحَجَّةِ</span> <span class="add">[<em>The road lead them otherwise than in the beaten track</em>]</span>. <span class="auth">(T* and A in art. <span class="ar">بهرج</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A19</span>
				</div>
				<div class="sense" id="Axc_1_A19">
					<p><span class="ar long">مَا أَخَذَتْكَ عَيْنِى مُنْذُ حِينٍ</span> † <em>My eye hath not seen thee for some time;</em> like <span class="ar">مَاظَفِرَتْكَ</span>. <span class="auth">(T in art. <span class="ar">ظفر</span>.)</span> And <span class="ar long">مَا فِى الحَىِّ أَحَدٌ تَأْخُذُهُ عَيْنِى</span> <span class="add">[explained to me by IbrD as meaning † <em>There is not in the tribe any one whom my eye regards as worthy of notice</em> or <em>respect</em> by reason of his greatness therein]</span>. <span class="auth">(TA in art. <span class="ar">جهر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A20</span>
				</div>
				<div class="sense" id="Axc_1_A20">
					<p><span class="ar long">أَخَذْتُ عِنْدَهُ يَدَى</span>, and <span class="ar">مَعْروفاً</span>: <a href="#Axc_8">see 8</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Axc_1_B1">
					<p><span class="ar">أَخِذَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْخَذُ</span>}</span></add>, inf. n. <span class="ar">أَخَذٌ</span>, <span class="auth">(Ṣ, L, Ḳ,)</span> <em>He</em> <span class="auth">(a young camel)</span> <em>suffered heaviness of the stomach, and indigestion, from the milk:</em> <span class="auth">(Ṣ:)</span> or <em>became disordered in his belly, and affected with heaviness of the stomach, and indigestion, from taking much milk.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Axc_1_B2">
					<p><em>He</em> <span class="auth">(a camel, L, Ḳ, or a sheep or goat, L)</span> <em>became affected by madness,</em> or <em>demoniacal possession;</em> <span class="auth">(Ḳ;)</span> or <em>by what resembled that.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Axc_1_B3">
					<p><span class="ar long">أَخِذَتْ عَيْنُهُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْخَذُ</span>}</span></add>, inf. n. <span class="ar">أَخَذٌ</span>, <em>His eye became affected by inflammation, pain, and swelling,</em> or <em>ophthalmia.</em> <span class="auth">(Ibn-Es-Seed, L, Ḳ.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Axc_1_C1">
					<p><span class="ar">أَخُذَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْخُذُ</span>}</span></add>, inf. n. <span class="ar">أُخُوذَةٌ</span>, <em>It</em> <span class="auth">(milk)</span> <em>was,</em> or <em>became, sour.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#AxicN">See <span class="ar">آخِذٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axc_2">
				<h3 class="entry">2. ⇒ <span class="ar">أخّذ</span></h3>
				<div class="sense" id="Axc_2_A1">
					<p><span class="ar">أَخَّذَتْهُ</span>, <span class="auth">(Ṣ, L, Ḳ,*)</span> inf. n. <span class="ar">تَأْخِيذٌ</span>, <span class="auth">(Ṣ, L,)</span> <em>She captivated,</em> or <em>fascinated, him,</em> <span class="auth">(namely, her husband,)</span> <em>and restrained him, by a kind of enchantment,</em> or <em>charm,</em> and especially <em>so as to withhold him from carnal conversation with other women;</em> <span class="auth">(Ṣ,* L, Ḳ,* TA;)</span> as also<span class="arrow"><span class="ar">أَخَذَتْهُ↓</span></span>; and<span class="arrow"><span class="ar">آخَذَتْهُ↓</span></span> <span class="add">[of which the inf. n. is app. <span class="ar">إِيخَاذٌ</span>]</span>. <span class="auth">(L, TA.)</span> A woman says, <span class="ar long">أُؤَخِّذُ جَمَلِى</span> <em>I captivate,</em> or <em>fascinate, my husband, by a kind of enchantment,</em> or <em>charm, and withhold him from other women.</em> <span class="auth">(L, from a trad.)</span> And one says, of a man, <span class="ar long">يُؤَخِّذُ عَنِ ٱمْرَأَتِهِ</span> <em>He withholds others</em> <span class="add">[<em>by a kind of enchantment,</em> or <em>charm,</em>]</span> <em>from carnal conversation with his wife.</em> <span class="auth">(Mṣb.)</span> The sister of Subh El-ʼÁdee said, in bewailing him, when he had been killed by a man pushed towards him upon a couch-frame, or raised couch, <span class="arrow"><span class="ar long">أَخَذتُّ↓ عَنْكَ الرَّاكِبَ وَالسَّاعِىَ وَالمَاشِىَ والقَاعِدَ وَالقَائِمَ وَلَمْ آخُذْ عَنْكَ النَّائِمَ</span></span> <span class="add">[<em>I withheld from thee by enchantment the rider and the runner and the walker and the sitter and the stander, and did not so withhold from thee the prostrate</em>]</span>. <span class="auth">(L.)</span> And one says of a beautiful garment,<span class="arrow"><span class="ar long">أَخَذَ↓ القُلُوبَ مَأْخَذَهُ</span></span> <span class="add">[<em>It captivated hearts in a manner peculiar to it</em>]</span>: <span class="auth">(Ḳ in art. <span class="ar">حصر</span>: <span class="add">[in the CK, incorrectly, <span class="ar">اَخَذَت</span> and <span class="ar">القُلُوبُ</span>:]</span>)</span> and <span class="ar long">اخذ بِقَلْبِهِ</span> <span class="add">[<em>He,</em> or <em>it, captivated his heart;</em> or]</span> <em>he</em> <span class="add">[or <em>it</em>]</span> <em>pleased him,</em> or <em>excited his admiration.</em> <span class="auth">(TA in art. <span class="ar">اله</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Axc_2_B1">
					<p><span class="ar long">أخّذ اللَّبَنَ</span>, inf. n. as above, <em>He made the milk sour.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#AxicN">See <span class="ar">آخِذٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Axc_3">
				<h3 class="entry">3. ⇒ <span class="ar">آخذ</span></h3>
				<div class="sense" id="Axc_3_A1">
					<p><span class="ar">آخذ</span>, inf. n. <span class="ar">مُؤَاخَذَةٌ</span>: <a href="#Axc_1">see 1</a>, in the middle portion of the paragraph, in five places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axc_4">
				<h3 class="entry">4. ⇒ <span class="ar">آخذ</span></h3>
				<div class="sense" id="Axc_4_A1">
					<p><span class="ar">آخذ</span>, inf. n., app., <span class="ar">إِيخَاذٌ</span>: <a href="#Axc_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axc_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتخذ</span></h3>
				<div class="sense" id="Axc_8_A1">
					<p><span class="ar">ائتخذ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَخَذَ</span>]</span> occurs in its original form; and is changed into <span class="ar">ٱتَّخَذَ</span> <span class="add">[with the disjunctive alif <span class="ar">اِتَّخَذَ</span>]</span>; this being of the measure <span class="ar">افتعل</span> from <span class="ar">أَخْذُ</span>, the <span class="add">[radical]</span> <span class="ar">ء</span> being softened, and changed into <span class="ar">ت</span>, and incorporated <span class="add">[into the augmentative <span class="ar">ت</span>]</span>: hence, when it had come to be much used in <a href="#AftEl">the form of <span class="ar">افتعل</span></a> <span class="add">[thus changed]</span>, they imagined the <span class="add">[former]</span> <span class="ar">ت</span> to be a radical letter <span class="add">[unchanged]</span>, and formed from it a verb of the measure <span class="ar">فَعِلَ</span>, aor. <span class="ar">يَفْعَلُ</span>; saying, <span class="ar">تَخِذَ</span>, aor. <span class="ar">يَتْخَذُ</span>, <span class="auth">(Ṣ, L, Mṣb,*)</span> inf. n. <span class="ar">تَخَذٌ</span> and <span class="ar">تَخْذٌ</span>: <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">ٱسْتَخَذَ↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِسْتَخَذَ</span>]</span>, of which exs. will be found below, is also used for <span class="ar">اتّخذ</span>; one of the two <span class="ar">ت</span> s being changed into <span class="ar">س</span>, like as <span class="ar">س</span> is changed into <span class="ar">ت</span> in <span class="ar">سِتٌّ</span> <span class="add">[for <span class="ar">سِدْسٌ</span>]</span>: or <span class="ar">استخذ</span> may be of the measure <span class="ar">استفعل</span> from <span class="ar">تَخِذَ</span>; one of the two <span class="ar">ت</span> s being suppressed; after the manner of those who say <span class="ar">ظَلْتُ</span> for <span class="ar">ظَلِلْتُ</span>: <span class="auth">(Ṣ, L:)</span> and IAth says that <span class="ar">اتّخذ</span>, in like manner, is of the measure <span class="ar">افتعل</span> from <span class="ar">تَخِذَ</span>; not from <span class="ar">أَخَذَ</span>: <span class="auth">(L and Ḳ in art. <span class="ar">تخذ</span>:)</span> but IAth is not one who should contradict J, whose opinion on this point is corroborated by the fact that they say <span class="ar">ٱتَّزَرَ</span> from <span class="ar">إِزَارٌ</span>, and <span class="ar">ٱتَّمَنَ</span> from <span class="ar">أَمْنٌ</span>, and <span class="ar">ٱتَّهَلَ</span> from <span class="ar">أَهْلٌ</span>; and there are other instances of the same kind: or, accord. to some, <span class="ar">اتّخذ</span> is from <span class="ar">وَخَذَ</span>, <a href="#Oaxaca">a dial. var. of <span class="ar">أَخَذَ</span></a>, and is originally <span class="ar">اِوْتَخَذَ</span>. <span class="auth">(MF.)</span> <span class="add">[The various significations of <span class="ar">اتّخذ</span> and <span class="ar">تَخِذَ</span> and <span class="ar">استخذ</span> will be here given under one head.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Axc_8_A2">
					<p>You say, <span class="ar long">إِئْتَخَذُوا فِى القِتَالِ</span>, <span class="auth">(Ṣ, L, Ḳ,*)</span> and <span class="ar long">فى الحَرْبِ</span>, <span class="auth">(Mṣb,)</span> with two hemzehs, <span class="auth">(Ṣ, L, Ḳ,)</span> or, correctly, <span class="ar">إِيتَخَذُوا</span>, with one hemzeh, <span class="add">[or <span class="ar">اِيتَخَذُوا</span>,]</span> as two hemzehs cannot occur together in one word, <span class="auth">(marginal note in a copy of the Ṣ,)</span> <span class="add">[but in a case of wasl, the first hemzeh being suppressed, the second remains unchanged,]</span> <em>They took,</em> or <em>seized,</em> (<span class="ar">أَخَذُوا</span>,) <em>one another</em> <span class="auth">(Ṣ, L, Mṣb, Ḳ)</span> <em>in fight,</em> <span class="auth">(Ṣ, L,)</span> and <em>in war;</em> <span class="auth">(Mṣb;)</span> and so <span class="ar">اِتَّخَذُوا</span>. <span class="auth">(Mṣb.)</span> And <span class="ar long">اِيتَخَذَ القَوْمُ</span> <em>The people,</em> of <em>company of men, wrestled together, each taking hold in some manner upon him who wrestled with him, to throw him down.</em> <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Axc_8_A3">
					<p><span class="add">[<span class="ar">اتّخذ</span>, as also<span class="arrow"><span class="ar">استخذ↓</span></span>, and]</span> <span class="ar">تَخِذَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْخَذُ</span>}</span></add>, <span class="auth">(Ḳ in art. <span class="ar">تخذ</span>,)</span> inf. n. <span class="ar">تَخَذَ</span> and <span class="ar">تَخْذٌ</span>, <span class="auth">(TA in art. <span class="ar">تخذ</span>,)</span> likewise signifies <em>i. q.</em> <span class="ar">أَخَذَ</span>, <span class="auth">(Ḳ in art. <span class="ar">تخذ</span>, and B and TA in the present art.,)</span> as meaning <em>He took</em> a thing <em>to,</em> or <em>for, himself; took possession of</em> it; <em>got,</em> or <em>acquired,</em> it; syn. <span class="ar">حَازَ</span> and <span class="ar">حَصَّلَ</span>. <span class="auth">(B, TA.)</span> Some read, <span class="add">[in the Ḳur, xviii. 76,]</span> <span class="ar long">لَتَخِذْتَ عَلَيْهِ أَجْراً</span> <span class="add">[<em>Thou mightest assuredly have taken for thyself a recompense for it</em>]</span>: <span class="auth">(Ṣ, L, Ḳ in art. <span class="ar">تخذ</span>, and TA in the present art.:)</span> this is the reading of Mujáhid, <span class="auth">(Fr, TA,)</span> and is authorized by I’Ab, and is that of Aboo-ʼAmr Ibn-El-ʼAlà and AZ, and so it is written in the model-copy of the Ḳur, and so the readers <span class="add">[in general]</span> read: <span class="auth">(AM, L, TA:)</span> so read Ibn-Ketheer and the Basrees; he and Yaạḳoob and Hafs pronouncing the <span class="ar">ذ</span>; the others incorporating it <span class="add">[into the <span class="ar">ت</span>]</span>: <span class="auth">(Bḍ:)</span> some read <span class="ar">لاٱتَّخَذتَّ</span>; <span class="auth">(L and Ḳ in art. <span class="ar">تخذ</span>;)</span> but these read at variance with the scripture. <span class="auth">(AM, L, TA.)</span> <span class="arrow"><span class="ar long">استخذ↓ أَرْضاً</span></span> is a phrase mentioned by Mbr as used by some of the Arabs, <span class="auth">(Ṣ, L,)</span> and signifies <em>i. q.</em> <span class="ar">اِتَّخَذَهَا</span> <span class="add">[<em>He took for himself a piece of land</em>]</span>. <span class="auth">(Ṣ, L, Ḳ.)</span> And <span class="ar long">اتّخذ وَلَدَّا</span> <span class="add">[in the Ḳur, ii. 110, &amp;c.,]</span> signifies <em>He got a son,</em> or <em>offspring.</em> <span class="auth">(Bḍ, &amp;c. See also below.)</span> And <span class="ar">تَخِذَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْخَذُ</span>}</span></add>, inf. n. <span class="ar">تَخَذٌ</span> and <span class="ar">تَخْذٌ</span>, also signifies <em>He gained, acquired,</em> or <em>earned,</em> wealth, <span class="auth">(L, and Mṣb in arts. <span class="ar">اخذ</span> and <span class="ar">تخذ</span>,)</span> or a thing. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Axc_8_A4">
					<p><span class="arrow"><span class="ar long">استخذ↓ عَلَيْهِمْ يَدًا</span></span> and <span class="ar">عِنْدَهُمْ</span> signify alike, <em>i. q.</em> <span class="ar">اتّخذ</span> <span class="add">[<em>He did to them a benefit,</em> or <em>favour;</em> as though he earned one for himself in prospect, making it to be incumbent on them as a debt to him]</span>: <span class="auth">(ISh:)</span> and <span class="ar long">اِتَّخَذْتُ عِنْدَهُ مَعْروفًا</span> means <span class="add">[in like manner, as also<span class="arrow"><span class="ar long">أَخَذْتُ↓ عنده معروفا</span></span>, and <span class="ar">يَدَّا</span>, <span class="auth">(and <span class="ar long">اِتَّخَذَ فِيهِ حُسْناً</span> has a similar meaning; see Ḳur xviii. 85;)</span>]</span> <span class="pb" id="Page_0030"></span><em>I did to him a benefit,</em> or <em>favour;</em> syn. <span class="ar long">أَسْدَيْتُهُ إِلَيْهِ</span>. <span class="auth">(Mṣb in art. <span class="ar">سدى</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Axc_8_A5">
					<p><span class="ar">اتّخذ</span> also signifies <em>He made</em> a thing; syn. <span class="ar">عَمِلَ</span>; like <span class="ar">تَخِذَ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْخَذُ</span>}</span></add>,]</span> inf. n. <span class="ar">تَخَذٌ</span> and <span class="ar">تَخْذٌ</span>: <span class="auth">(L:)</span> <em>he made,</em> or <em>manufactured,</em> a bow, a water-skin, &amp;c., <span class="ar long">مِنْ كَذَا</span> <em>of such a thing: he made,</em> or <em>prepared,</em> a dish of food, a medicine, &amp;c.: either absolutely or <em>for himself.</em> <span class="auth">(The Lexicons passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Axc_8_A6">
					<p>Also <em>He made,</em> or <em>constituted,</em> or <em>appointed;</em> syn. <span class="ar">جَعَلَ</span>; doubly trans.; <span class="auth">(B, Mṣb;)</span> and so <span class="ar">تَخِذَ</span>. <span class="auth">(Mṣb in art. <span class="ar">تخذ</span>.)</span> You say, <span class="ar long">اتّخذهُ صَدِيقًا</span> <em>He made him</em> <span class="add">[or <em>took him as</em>]</span> <em>a friend;</em> <span class="auth">(Mṣb in the present art.;)</span> and so <span class="ar">تَخِذَهُ</span>. <span class="auth">(Idem in art. <span class="ar">تخذ</span>.)</span> And <span class="ar long">اتّخذهُ هُزُؤًا</span> <span class="add">[in the Ḳur ii. 63 and 231, &amp;c.,]</span> means <em>He made him,</em> or <em>it, a subject of derision.</em> <span class="auth">(Bḍ, Jel.)</span> And <span class="ar long">اتّخذهُ وَلَدًا</span> <span class="add">[in the same, xii. 21 and xxviii. 8,]</span> <em>He made him,</em> or <em>took</em> or <em>adopted him as, a son.</em> <span class="auth">(Bḍ. See also above.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axc_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأخذ</span></h3>
				<div class="sense" id="Axc_10_A1">
					<p><span class="ar">ٱسْتَخَذَ</span>, written with the disjunctive alif <span class="ar">اِسْتَخَذَ</span>: <a href="#Axc_8">see 8</a>, in four places. <span class="add">[Other meanings may be inferred from explanations of <span class="ar">مُسْتَأْخِذٌ</span>, q. v. infrà.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxocN">
				<h3 class="entry"><span class="ar">أَخْذٌ</span></h3>
				<div class="sense" id="OaxocN_A1">
					<p><span class="ar">أَخْذٌ</span> <a href="#Axc_1">inf. n. of <span class="ar">أَخَذَ</span>, q. v.</a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaxocN_A2">
					<p>† <em>A way,</em> or <em>manner, of life;</em> as also<span class="arrow"><span class="ar">إِخْذٌ↓</span></span>. <span class="auth">(Ṣ, L, Ḳ.)</span> You say, <span class="ar long">ذَهَبَ بَنُو فُلَانٍ وَمَنْ أَخَذَ أَخْذَهُمْ</span>, <span class="auth">(Ṣ, L, Ḳ,*)</span> and<span class="arrow"><span class="ar">إِخْذَهُمْ↓</span></span>, <span class="auth">(L, Ḳ,)</span> the former of the dial. of Temeem, and the latter of the dial. of El-Ḥijáz, <span class="auth">(TA,)</span> meaning † <em>The sons of such a one went away,</em> or <em>passed away, and those who took to their way of life,</em> <span class="auth">(Ṣ, L, Ḳ,)</span> <em>and adopted their manners,</em> or <em>dispositions:</em> <span class="auth">(Ḳ:)</span> and <span class="ar long">مَنْ أَخَذَ أَخْذُهُمْ</span> and<span class="arrow"><span class="ar">إِخْذُهُمْ↓</span></span>, and <span class="ar long">مَنْ أَخَذَ أَخْذُهُمْ</span> <span class="add">[in the CK <span class="ar">اَخْذُهُمْ</span>]</span> and<span class="arrow"><span class="ar">إِخْذُهُمْ↓</span></span>, signify <span class="add">[virtually]</span> the same: <span class="auth">(Ḳ:)</span> or <span class="ar long">مَنْ أَخَذَهُ أَخْذُهُمْ</span> and<span class="arrow"><span class="ar">إِخْذُهُمْ↓</span></span> signify <span class="add">[properly]</span> <span class="ar long">مَنْ أَخَذَهُ أَخْذُهُمْ وَسِيرَتُهُمْ</span> <span class="add">[<em>those whom their way of life took,</em> or <em>influenced</em>]</span>. <span class="auth">(ISk, Ṣ L.)</span> One says also,<span class="arrow"><span class="ar long">ٱسْتُعْمِلَ فُلَانٌ عَلَ الشَّامِ وَمَا أَخَذَ إِخْذَهُ↓</span></span>, with kesr, meaning † <span class="add">[<em>Such a one was appointed prefect over Syria,</em>]</span> <em>and he did not take to that good way of life which it was incumbent on him to adopt:</em> you should not say <span class="ar">أَخْذَهُ</span>: <span class="auth">(AA, Ṣ, L:)</span> or it means <em>and what was adjacent to it:</em> <span class="auth">(Fr, L:)</span> or, accord. to the Wáʼee, one says, in this case, <span class="arrow"><span class="ar long">وَمَا أَخَذَ إِخْذَهُ↓</span></span> and <span class="ar">أَخْذُهُ</span> and<span class="arrow"><span class="ar">أُخْذُهُ↓</span></span>, with kesr and fet-ḥ and damm <span class="add">[to the hemzeh, and with the <span class="ar">ذ</span> marfooah, as in instances before]</span>. <span class="auth">(Et-Tedmuree, MF.)</span> One also says,<span class="arrow"><span class="ar long">لَوْ كُنْتَ مِنَّا لَأَخَذتَّ بِإخْذِنَا↓</span></span>, <span class="auth">(Ṣ, L,)</span> with kesr to the <span class="ar">ا</span>, <span class="auth">(L,)</span> <span class="add">[in a copy of the Ṣ <span class="ar">بِأَخْذِنَا</span>, which seems to be also allowable, accord. to the dial. of Temeem,]</span> meaning <em>Wert thou of us, then thou hadst taken to,</em> or <em>wouldst take to, our manners,</em> or <em>dispositions, and fashion,</em> <span class="auth">(Ṣ, L,)</span> <em>and garb, and way of life.</em> <span class="auth">(L.)</span> The words of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَلَوْ كُنْتُمْ مُنَّا أَخَذْنَا بِإِخْذِكُمْ</span> *</div> 
					</blockquote>
					<p>IAar explains as meaning <em>And were ye of us, we had caught and restored to you your camels:</em> but no other says so. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaxocN_A3">
					<p><span class="ar long">نُجُومُ الأَخْذِ</span> <em>The Mansions of the Moon;</em> <span class="auth">(Ṣ, L, Ḳ;)</span> also called <span class="ar long">نُجُومُ الأَنْوَآءٌ</span>; <span class="auth">(L; <span class="add">[<a href="../">see art. <span class="ar">نوء</span></a>;]</span>)</span> called by the former appellation because the moon every night enters (<span class="ar long">يَأْخُذُ فِى</span>) one of those mansions: <span class="auth">(Ṣ, L:)</span> or <em>the stars which are cast at those</em> <span class="add">[<em>devils</em>]</span> <em>who listen by stealth</em> <span class="add">[<em>to the conversations of the angels</em>]</span>: <span class="auth">(L, Ḳ:)</span> but the former explanation is the more correct. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaxocN_A4">
					<p><a href="#IixaAco">See also <span class="ar">إِخَاذْ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxocN">
				<h3 class="entry"><span class="ar">أُخْذٌ</span></h3>
				<div class="sense" id="OuxocN_A1">
					<p><span class="ar">أُخْذٌ</span>, whence <span class="ar long">مَا أَخَذَ أُخْذُهُ</span>: <a href="#OaxocN">see <span class="ar">أَخْذٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أُخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuxocN_A2">
					<p><a href="#IixaAcN">It is also a pl. of <span class="ar">إِخَاذٌ</span></a>; <span class="auth">(Ṣ, L;)</span> <a href="#IixocN">and of <span class="ar">إِخْذٌ</span></a> or <span class="ar">إِخْذَةٌ</span>, explained below with <span class="ar">إِخَاذٌ</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IixocN">
				<h3 class="entry"><span class="ar">إِخْذٌ</span></h3>
				<div class="sense" id="IixocN_A1">
					<p><span class="ar">إِخْذٌ</span> <span class="add">[The <em>act of taking, taking with the hand,</em>, &amp;c.]</span>, a subst. from <span class="ar">أَخَذَ</span>. <span class="auth">(Ṣ, L, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">إِخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IixocN_A2">
					<p><a href="#OaxocN">See also <span class="ar">أَخْذٌ</span></a>, in nine places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">إِخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IixocN_A3">
					<p><a href="#IixaAcN">And see <span class="ar">إِخَاذٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">إِخْذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IixocN_A4">
					<p>Also <em>A mark made with a hot iron upon a camel's side when a disease therein is feared.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxacN">
				<h3 class="entry"><span class="ar">أَخَذٌ</span></h3>
				<div class="sense" id="OaxacN_A1">
					<p><span class="ar">أَخَذٌ</span> <em>Heaviness of the stomach, and indigestion,</em> of a young camel, <em>from the milk.</em> <span class="auth">(Ḳ.)</span><span class="add">[<a href="#Oaxica">See <span class="ar">أَخِذَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخَذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaxacN_A2">
					<p><a href="#OuxucN">See also <span class="ar">أُخُذٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxicN">
				<h3 class="entry"><span class="ar">أَخِذٌ</span></h3>
				<div class="sense" id="OaxicN_A1">
					<p><span class="ar">أَخِذٌ</span> A young camel <em>disordered in his belly, and affected with heaviness of the stomach, and indigestion, from taking much milk.</em> <span class="auth">(AZ, Fr, L.)</span><span class="add">[<a href="#SaboHaAnu">See also <span class="ar">صَبْحَانُ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخِذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaxicN_A2">
					<p>A camel, or a young camel, or a sheep or goat, <em>affected by what resembles madness,</em> or <em>demoniacal possession.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخِذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaxicN_A3">
					<p>A man <em>affected with inflammation of the eye; with pain and swelling of the eye; with ophthalmia;</em> <span class="auth">(Ṣ, L;)</span> as also<span class="arrow"><span class="ar">مُسْتَأْخِذٌ↓</span></span>. <span class="auth">(L.)</span> See also this latter.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخِذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaxicN_A4">
					<p><a href="#AxicN">See also <span class="ar">آخِذٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxucN">
				<h3 class="entry"><span class="ar">أُخُذٌ</span></h3>
				<div class="sense" id="OuxucN_A1">
					<p><span class="ar">أُخُذٌ</span> <span class="auth">(Ṣ, L, Ḳ)</span> and<span class="arrow"><span class="ar">أَخَذٌ↓</span></span>, <span class="auth">(Ibn-Es-Seed, L, Ḳ,)</span> which latter is the regular form, <span class="auth">(L,)</span> <em>Inflammation of the eye; pain and swelling of the eye; ophthalmia.</em> <span class="auth">(Ṣ, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxocapN">
				<h3 class="entry"><span class="ar">أَخْذَةٌ</span></h3>
				<div class="sense" id="OaxocapN_A1">
					<p><span class="ar">أَخْذَةٌ</span> <span class="add">[<a href="#Oaxaca">inf. n. un. of <span class="ar">أَخَذَ</span></a>, <em>An act of taking,</em>, &amp;c.: <em>an act of punishment,</em> or <em>chastisement,</em> or <em>the like;</em> as in the Ḳur lxix. 10: pl. <span class="ar">أَخَذَاتٌ</span>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخْذَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaxocapN_A2">
					<p><span class="ar long">أَخَذُوا أَخَذَاتِهِمْ</span> <em>They took their places of abode.</em> <span class="auth">(IAth and L, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxocapN">
				<h3 class="entry"><span class="ar">أُخْذَةٌ</span></h3>
				<div class="sense" id="OuxocapN_A1">
					<p><span class="ar">أُخْذَةٌ</span> <em>A manner of taking,</em> or <em>seizing,</em> of a man with whom one is wrestling: pl. <span class="ar">أُخَذٌ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أُخْذَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuxocapN_A2">
					<p><em>A kind of enchantment,</em> or <em>fascination, like</em> <span class="ar">سِحْر</span>, <span class="auth">(Ṣ, L, Mṣb,* Ḳ,)</span> <em>which captivates the eye and the like,</em> <span class="auth">(L,)</span> <em>and by which enchantresses withhold their husbands from other women;</em> called by the vulgar <span class="ar">رِبَاطٌ</span> and <span class="ar">عَقْدٌ</span>; and practised by the women in the time of ignorance: <span class="auth">(TA:)</span> or <em>a kind of bead</em> (<span class="ar">خَزَرَةٌ</span>, Ṣ, L, Ḳ) <em>with which one captivates,</em> or <em>fascinates,</em> or <em>restrains;</em> <span class="auth">(Ḳ;)</span> <em>with which women captivate,</em> or <em>fascinate,</em> or <em>restrain, men,</em> <span class="auth">(Ṣ, L,)</span> <em>and withhold them from other women:</em> <span class="auth">(L:)</span> or <em>i. q.</em> <span class="ar">رُقْيَةٌ</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أُخْذَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OuxocapN_A3">
					<p><em>A pitfall dug for catching a lion.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أُخْذَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OuxocapN_A4">
					<p><span class="ar long">بَادِرْ بِزَنْدِكَ أُخْذَةَ النَّارِ</span> <span class="add">[<em>Strive thou to be before the time called</em> <span class="auth">(that of)</span> <span class="ar long">اخذة النار</span> <em>with thy wooden instrument for producing fire;</em> i. e. <em>haste thou to use it before that time;</em>]</span> means <em>the time a little after the prayer of sunset;</em> asserted to be the worst time in which to strike fire. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IixocapN">
				<h3 class="entry"><span class="ar">إِخْذَةٌ</span></h3>
				<div class="sense" id="IixocapN_A1">
					<p><span class="ar">إِخْذَةٌ</span>: <a href="#IixaAcN">see <span class="ar">إِخَاذٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IixaAcN">
				<h3 class="entry"><span class="ar">إِخَاذٌ</span></h3>
				<div class="sense" id="IixaAcN_A1">
					<p><span class="ar">إِخَاذٌ</span> and<span class="arrow"><span class="ar">إِخَاذَةٌ↓</span></span> <em>A pool of water left by a torrent:</em> pl. <span class="ar">أُخُذٌ</span>: <span class="auth">(AO, Ḳ:)</span> both signify the same: <span class="auth">(L:)</span> or<span class="arrow"><span class="ar">إِخَاذَةٌ↓</span></span> signifies <em>a thing like a pool of water left by a torrent;</em> and <span class="ar">إِخَاذٌ</span> is its pl. <span class="add">[or a coll. gen. n.]</span>; and the pl. of this latter is <span class="ar">أُخُذٌ</span>, like as <span class="ar">كُتُبٌ</span> <a href="#kitaAbN">is pl. of <span class="ar">كِتَابٌ</span></a>, and sometimes it is contracted into <span class="ar">أُخْذٌ</span>: <span class="auth">(Ṣ, L:)</span> the like of this is said by Aboo-ʼAdnán: <span class="auth">(L:)</span> and <span class="ar">إِخَاذَاتٌ</span> is also <a href="#IixAcapN">a pl. of <span class="ar">إِخاذَةٌ</span></a>, occurring in a trad., and signifying <em>pools which receive the rain-water, and retain it for drinkers:</em> <span class="auth">(IAth, L:)</span> or the correct word is <span class="ar">إِخَاذٌ</span>, without <span class="ar">ة</span>, and it signifies <em>a place where beasts assemble at a pool of water left by a torrent;</em> and its pl. is <span class="ar">أُخُذٌ</span> <span class="auth">(AA, AʼObeyd, L)</span> and <span class="ar">آخَاذٌ</span>, which latter is extr.: <span class="auth">(L:)</span> but as to <span class="arrow"><span class="ar">إِخَاذَةٌ↓</span></span>, it has a different signification, which will be found below; i. e. land of which a man takes possession for himself, &amp;c.: <span class="auth">(AA, L:)</span> or <span class="ar">إِخَاذٌ</span> is a coll. gen. n., and<span class="arrow"><span class="ar">إِخَاذَةٌ↓</span></span> is its n. un., and signifies <em>a receptacle made for water to collect therein:</em> and<span class="arrow"><span class="ar">أَخْذٌ↓</span></span> signifies <em>a thing that one digs for himself, in the form of a watering-trough, which retains water for some days;</em> and its pl. is <span class="ar">أُخْذَانٌ</span>: <span class="auth">(L:)</span> and<span class="arrow"><span class="ar">إِخْذٌ↓</span></span> and<span class="arrow"><span class="ar">إِخْذَةٌ↓</span></span> also signify <em>a thing that one digs in the form of a wateringtrough;</em> and the pl. is <span class="ar">أُخْذٌ</span> and <span class="ar">إِخَاذٌ</span>. <span class="auth">(L.)</span> In a trad. of Mesrook Ibn-El-Ajda', <span class="ar">إِخَاذ</span> are likened to the Companions of Moḥammad; and it is added, that one <span class="arrow"><span class="ar">إِخَاذَة↓</span></span> suffices for a rider; and one, for two riders; and one, for a company of men: <span class="auth">(Ṣ, L:)</span> meaning that among them were the young and the old, and the possessor of knowledge and the possessor of more knowledge. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">إِخَاذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IixaAcN_A2">
					<p><a href="#IixaAcapN">See also <span class="ar">إِخَاذَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxiycN">
				<h3 class="entry"><span class="ar">أَخِيذٌ</span> / <span class="ar">أَخِيذَةٌ</span></h3>
				<div class="sense" id="OaxiycN_A1">
					<p><span class="ar">أَخِيذٌ</span> <em>i. q.</em><span class="arrow"><span class="ar">مَأْخُوذٌ↓</span></span> <span class="add">[<em>Taken; taken with the hand;</em>, &amp;c.]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخِيذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaxiycN_A2">
					<p><em>A captive:</em> <span class="auth">(Ṣ, L, Mṣb, Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَخِيذَةٌ</span>}</span></add>. <span class="auth">(Ṣ, L.)</span> Hence the saying, <span class="ar long">أَكْذَبُ مِنْ أَخِيذِ الجَيشِ</span> <em>More lying than the captive of the army:</em> meaning him whom his enemies have taken captive, and whom they desire to conduct them to his people, and who lies to them to his utmost. <span class="auth">(Fr, L.)</span> <span class="add">[<a href="#SaboHaAnu">See another ex. voce <span class="ar">صَبْحَانُ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">أَخِيذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaxiycN_A3">
					<p><em>A strange,</em> or <em>foreign, old man.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IixaAcapN">
				<h3 class="entry"><span class="ar">إِخَاذَةٌ</span></h3>
				<div class="sense" id="IixaAcapN_A1">
					<p><span class="ar">إِخَاذَةٌ</span> <em>Land which a man,</em> <span class="auth">(Ṣ, L, Ḳ,)</span> <em>or a Sul- tán,</em> <span class="auth">(Ṣ, L,)</span> <em>takes for himself;</em> as also<span class="arrow"><span class="ar">إِخَاذٌ↓</span></span>: <span class="auth">(Ṣ, L, Ḳ:)</span> or <em>land which a man takes for himself, and brings into a state of cultivation after its having been waste:</em> <span class="auth">(AA, Mgh, L:)</span> or <em>waste land which the owner gives to him who shall cultivate it:</em> <span class="auth">(Mgh:)</span> and <em>land which the Imám gives to one, not being property,</em> <span class="auth">(Ḳ,)</span> or <em>not being the property of another.</em> <span class="auth">(TA, as from the Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">إِخَاذَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IixaAcapN_A2">
					<p><a href="#IixaAcN">See also <span class="ar">إِخَاذٌ</span></a>, in five places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">إِخَاذَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IixaAcapN_A3">
					<p>Also The <em>handle</em> of a <span class="add">[shield of the kind called]</span> <span class="ar">حَجَفَة</span>; <span class="auth">(Ḳ; <span class="add">[in the L written <span class="ar">جحْفة</span>, with the <span class="ar">ج</span> before the <span class="ar">ح</span>;]</span>)</span> also called its <span class="ar">ثقاف</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxiycapN">
				<h3 class="entry"><span class="ar">أَخِيذَةٌ</span></h3>
				<div class="sense" id="OaxiycapN_A1">
					<p><span class="ar">أَخِيذَةٌ</span> <em>A thing that is taken by force.</em> <span class="auth">(L.)</span><span class="add">[<a href="#OaxiycN">See also <span class="ar">أَخِيذٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxBaAcN">
				<h3 class="entry"><span class="ar">أَخَّاذٌ</span></h3>
				<div class="sense" id="OaxBaAcN_A1">
					<p><span class="ar">أَخَّاذٌ</span> One <em>who takes eagerly,</em> or <em>greedily:</em> whence the saying, <span class="ar long">مَا أَنْتَ إِلَّا أَخَّاذٌ نَبَّاذٌ</span> <em>Thou art none other than one who taketh a thing eagerly,</em> or <em>greedily, and then throweth it away quickly.</em> <span class="auth">(A.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MxicN">
				<h3 class="entry"><span class="ar">آخِذٌ</span></h3>
				<div class="sense" id="MxicN_A1">
					<p><span class="ar">آخِذٌ</span>, <span class="auth">(as in some copies of the Ḳ, in both of the senses here explained,)</span> <span class="pb" id="Page_0031"></span>or<span class="arrow"><span class="ar">أَخِذْ↓</span></span> <span class="auth">(as in other copies of the Ḳ, and in the L and TA, <span class="add">[but the former is the more agreeable with the form of the pl.,]</span>)</span> A camel <em>beginning to become fat;</em> <span class="auth">(L, Ḳ;)</span> or <em>to become aged:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">أَوَاخِذُ</span> <span class="auth">(L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">آخِذٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MxicN_B1">
					<p>Milk <em>that bites the tongue;</em> syn. <span class="ar">قَارِصٌ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#Oaxuca">See <span class="ar">أَخُذَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoxacN">
				<h3 class="entry"><span class="ar">مَأْخَذٌ</span></h3>
				<div class="sense" id="maOoxacN_A1">
					<p><span class="ar">مَأْخَذٌ</span> <span class="add">[<em>A place where,</em> or <em>whence, a thing is taken:</em> pl. <span class="ar">مَآخِذُ</span>.]</span> <span class="add">[Hence,]</span> <span class="ar long">مَآخِذُ الطَّيْرِ</span> <em>The places whence birds are taken.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">مَأْخَذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOoxacN_A2">
					<p><span class="add">[<em>The source of derivation</em> of a word or phrase or meaning.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">مَأْخَذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOoxacN_A3">
					<p><em>A way</em> <span class="add">[<em>which one takes</em>]</span>; as in the phrase, <span class="ar long">المَأْخَذَ الأَقْرَبَ سَلَكَ</span> <em>He went the nearest way.</em> <span class="auth">(Mṣb. in art. <span class="ar">خصر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">مَأْخَذٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="maOoxacN_A4">
					<p><span class="add">[<a href="#Axc_2">See also 2</a>, last sentence but one.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOoxuwcN">
				<h3 class="entry"><span class="ar">مَأْخُوذٌ</span></h3>
				<div class="sense" id="maOoxuwcN_A1">
					<p><span class="ar">مَأْخُوذٌ</span>: <a href="#OaxiycN">see <span class="ar">أَخِيذٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaxBacN">
				<h3 class="entry"><span class="ar">مُؤَخَّذٌ</span></h3>
				<div class="sense" id="muWaxBacN_A1">
					<p><span class="ar long">رَجُلٌ مُؤَخَّذٌ عَنِ النِّسَآءِ</span> <em>A man withheld</em> <span class="add">[<em>by a kind of enchantment</em> or <em>charm</em> (<a href="#Axc_2">see 2</a>)]</span> <em>from women.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWotaxicN">
				<h3 class="entry"><span class="ar">مُؤْتَخِذٌ</span></h3>
				<div class="sense" id="muWotaxicN_A1">
					<p><span class="ar">مُؤْتَخِذٌ</span>: <a href="#musotaOoxicN">see what follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaOoxicN">
				<h3 class="entry"><span class="ar">مُسْتَأْخِذٌ</span></h3>
				<div class="sense" id="musotaOoxicN_A1">
					<p><span class="ar">مُسْتَأْخِذٌ</span> <span class="add">[<em>Requiring to be clipped;</em> i. e.]</span> <em>long;</em> applied to hair. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخذ</span> - Entry: <span class="ar">مُسْتَأْخِذٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="musotaOoxicN_B1">
					<p><em>Lowering his head,</em> or <em>stooping,</em> <span class="auth">(Aṣ, Ṣ, L, Ḳ,)</span> <em>by reason of inflammation of the eyes,</em> or <em>ophthalmia,</em> <span class="auth">(Aṣ, Ṣ, L,)</span> or <em>by reason of pain,</em> <span class="auth">(Aṣ, Ṣ, L, Ḳ,)</span> or <em>from some other cause;</em> <span class="auth">(L;)</span> as also<span class="arrow"><span class="ar">أَخِذٌ↓</span></span>, q. v. <span class="auth">(TA.)</span> <em>Lowly,</em> or <em>submissive,</em> <span class="auth">(AA, L, Ḳ,)</span> by reason of disease; as also<span class="arrow"><span class="ar">مُؤْتَخِذٌ↓</span></span>. <span class="auth">(AA, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0028.pdf" target="pdf">
							<span>Lanes Lexicon Page 28</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0029.pdf" target="pdf">
							<span>Lanes Lexicon Page 29</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0030.pdf" target="pdf">
							<span>Lanes Lexicon Page 30</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0031.pdf" target="pdf">
							<span>Lanes Lexicon Page 31</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
