<article class="root" id="Root_ASd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/092_AXn">اشن</a></span>
				<span class="ar">اصد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/094_ASr">اصر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ASd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أصّد</span></h3>
				<div class="sense" id="ASd_2_A1">
					<p><span class="ar">أصّدهُ</span>, inf. n. <span class="ar">تَأْصِيدٌ</span>, is from <span class="ar">أُصْدَةٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> <span class="add">[app. meaning <em>He made it an</em> <span class="ar">أُصْدَة</span>: or <em>he wore it as an</em> <span class="ar">أُصْدَة</span>: and hence <span class="ar">مُؤَصَّدٌ</span> or <span class="ar">مُؤَصَّدَةٌ</span> as explained below: or]</span> <em>he clad him with an</em> <span class="ar">أُصْدَة</span>. <span class="auth">(TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ASd_4">
				<h3 class="entry">4. ⇒ <span class="ar">آصد</span></h3>
				<div class="sense" id="ASd_4_A1">
					<p><span class="ar">آصد</span> <span class="add">[in some copies of the Ḳ <span class="ar">أَصَدَ</span>, which is a mistake, (<a href="#muWoSadN">see the pass. part. n. <span class="ar">مُؤْصَدٌ</span>, below</a>,)]</span> <em>He closed</em> (<span class="ar">أَغْلَقَ</span>, Ṣ, A, Ḳ, and so in the M in art. <span class="ar">وصد</span>, or <span class="ar">أَطْبَقَ</span>, as in the M in the present art.) a door, or an entrance; as also <span class="ar">اوصد</span>; <span class="auth">(Ṣ, M, A, Ḳ;)</span> of which it is a dial. var. <span class="auth">(Ṣ.)</span> And <em>He covered,</em> or <em>covered over,</em> a cooking-pot. <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuSodapN">
				<h3 class="entry"><span class="ar">أُصْدَةٌ</span></h3>
				<div class="sense" id="OuSodapN_A1">
					<p><span class="ar">أُصْدَةٌ</span> <span class="auth">(Ṣ, M, Ḳ, and Ḥam p. 223)</span> and<span class="arrow"><span class="ar">أَصِيدَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">مُؤَصَّدٌ↓</span></span> <span class="auth">(Ṣ* M,)</span> or<span class="arrow"><span class="ar">مُؤَصَّدَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A garment of the kind called</em> <span class="ar">صِدَار</span> <em>worn by a young girl:</em> when a girl attains to the age of puberty, she is clad with a <span class="ar">دِرْع</span>: <span class="auth">(M:)</span> or <em>a small shirt for a little girl:</em> or <em>worn beneath the</em> <span class="ar">ثَوْب</span>; <span class="auth">(Ḳ:)</span> or the <span class="ar">أُصْدَة</span> is <em>a garment without sleeves, worn by a bride and by a little girl:</em> <span class="auth">(M:)</span> or <em>a small shirt</em> or <em>shift, worn beneath the</em> <span class="ar">ثوب</span>; and <em>also worn by little girls:</em> <span class="auth">(Ṣ:)</span> or <em>a garment of which the sewing is not complete:</em> or <em>i. q.</em> <span class="ar">بَقِيرَةٌ</span>: or <em>i. q.</em> <span class="ar">صُدْرَةٌ</span>. <span class="auth">(Ḥam ubi suprà.)</span> Kutheiyir says,</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">وَقَدْ دَرَّعُوهَا وَهْىَ ذَاتُ مُؤَصَّدٍ↓</span></span> *</div> 
						<div class="star">* <span class="ar long">مَجُوبٍ وَلَمَّا يَلْبَسِ الدِّرْعَ رِيدُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They clad her with a</em> <span class="ar">دِرْع</span> <em>when she wore a</em> <span class="ar">مُؤَصَّد</span> <em>with an opening cut out at the neck and bosom, when her equal in age had not yet worn the</em> <span class="ar">درع</span>]</span>. <span class="auth">(Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSiydN">
				<h3 class="entry"><span class="ar">أَصِيدٌ</span></h3>
				<div class="sense" id="OaSiydN_A1">
					<p><span class="ar">أَصِيدٌ</span> <em>A court;</em> or <em>an open or a wide space in front of a house, or extending from its sides;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <a href="#waSiydN">a dial. var. of <span class="ar">وَصِيدٌ</span></a>, <span class="auth">(Ṣ,)</span> which is the more common form: <span class="auth">(M:)</span> <span class="pb" id="Page_0063"></span>or the <em>extreme and exterior part of a house:</em> <span class="auth">(Mirḳát el-Loghah, and Meyd, as rendered by Golius:)</span> or <em>an intermediate place between the threshold or door and the house; a place which looks neither upon the public nor upon the interior parts, whether it be an area or a vestibule.</em> <span class="auth">(Ibn-Maạroof, as rendered by Golius.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSiydapN">
				<h3 class="entry"><span class="ar">أَصِيدَةٌ</span></h3>
				<div class="sense" id="OaSiydapN_A1">
					<p><span class="ar">أَصِيدَةٌ</span>: <a href="#OuSodapu">see <span class="ar">أُصْدَةُ</span></a></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصد</span> - Entry: <span class="ar">أَصِيدَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaSiydapN_B1">
					<p><em>A</em> <span class="add">[<em>hind of enclosure for the protection of camels, sheep,</em> or <em>goats, such as is called</em>]</span> <span class="ar">حَظِيرَةٌ</span>: <span class="auth">(M, Ḳ:)</span> or <em>like a </em> <span class="ar">حظيرة</span>, <span class="auth">(Ṣ, and Ḥam p.223,)</span> <span class="add">[<em>but made</em>]</span> <em>of rocks, or great masses of stone:</em> <span class="auth">(Ḥam:)</span> <a href="#waSiydapN">a dial. var. of <span class="ar">وَصِيدَةٌ</span> <span class="add">[q. v.]</span></a>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">إِصَادٌ</span> <span class="auth">(Ḥam.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWoSadN">
				<h3 class="entry"><span class="ar">مُؤْصَدٌ</span></h3>
				<div class="sense" id="muWoSadN_A1">
					<p><span class="ar">مُؤْصَدٌ</span> <em>Closed; closed over,</em> or <em>covered:</em> occurring in the Ḳur <span class="add">[xc. 20 and]</span> civ. 8; <span class="auth">(L;)</span> in which AA reads <span class="ar">مُؤْصَدَةٌ</span> <span class="add">[with hemz; others reading this word without hemz]</span>. <span class="auth">(Ṣ, L.)</span> You say <span class="ar long">بَابٌ مُؤْصَدٌ</span> <span class="add">[<em>A closed door</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">قِدْرٌ مُؤْصَدَةٌ</span> <em>A covered cooking-pot.</em> <span class="auth">(A.)</span> And <span class="ar long">بَابُ العَفْوِ عَنْهُ مُؤْصَدٌ</span> † <span class="add">[<em>The door of forgiveness is closed from him; i. e., against him</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaSBadN">
				<h3 class="entry"><span class="ar">مُؤَصَّدٌ</span> / <span class="ar">مُؤَصَّدَةٌ</span></h3>
				<div class="sense" id="muWaSBadN_A1">
					<p><span class="ar">مُؤَصَّدٌ</span>, or <span class="ar">مُؤَصَّدَةٌ</span>: <a href="#OuSodapN">see <span class="ar">أُصْدَةٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0062.pdf" target="pdf">
							<span>Lanes Lexicon Page 62</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0063.pdf" target="pdf">
							<span>Lanes Lexicon Page 63</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
