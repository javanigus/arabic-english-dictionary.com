<article class="root" id="Root_Arm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/060_Ark">ارك</a></span>
				<span class="ar">ارم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/062_Are">ارى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Arm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرم</span></h3>
				<div class="sense" id="Arm_1_A1">
					<p><span class="ar">أَرَمَهُ</span>, <span class="auth">(Ṣ, Ḥar p. 99,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْرِمُ</span>}</span></add>, inf. n. <span class="ar">أَرْمٌ</span>, <span class="auth">(Ṣ,)</span> <em>He took away,</em> or <em>removed, its</em> <span class="ar">أَرُومَةٌ</span>, or <span class="ar">أَصْل</span>: <span class="auth">(Ḥar ubi suprà:)</span> <span class="add">[<em>he extirpated it; eradicated it:</em>]</span> <em>he ate it.</em> <span class="auth">(Ṣ.)</span> You say, <span class="ar long">أَرَمَتِ السَّائِمَةُ المَرْعَى</span>, aor. as above, <em>The pasturing beasts consumed,</em> or <em>made an end of, the pasturage, not leaving of it anything.</em> <span class="auth">(AḤn, M.)</span> And <span class="ar long">أَرَمَ مَا عَلَى الخِوَانِ</span>, <span class="auth">(T,)</span> or <span class="ar">المَائِدَةِ</span>, <span class="auth">(Th, M, Ḳ,)</span> aor. as above, <span class="auth">(M,)</span> <em>He ate what was on the table,</em> <span class="auth">(Th, T, M, Ḳ,)</span> <em>not leaving anything.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">أَرَمَتْهُمُ السَّنَةُ</span>, <span class="auth">(AHeyth, T, M, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُمُ</span>}</span></add>, <span class="auth">(so in the T, as on the authority of AHeyth,)</span> inf. n. as above, <span class="auth">(M,)</span> <em>The year of dearth,</em> or <em>drought,</em> or <em>sterility, extirpated them;</em> <span class="auth">(T;)</span> or <em>devoured them;</em> <span class="auth">(AHeyth, T;)</span> or <em>cut them off.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">أَرَمَتِ السَّنَةُ بِأَمْوَالِنَا</span> <em>The year of dearth,</em> or <em>drought,</em> or <em>sterility, devoured everything</em> <span class="add">[<em>of our property</em> or <em>cattle</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَرَمَتِ الأَرْضُ المَيِّتَ</span> <em>The earth consumed the dead body.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Arm_1_B1">
					<p><span class="ar long">أَرِمَ المَالُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَمُ</span>}</span></add>, <em>The property,</em> or <em>cattle, perished,</em> or <em>came to nought.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiromN">
				<h3 class="entry"><span class="ar">إِرْمٌ</span></h3>
				<div class="sense" id="IiromN_A1">
					<p><span class="ar">إِرْمٌ</span>: <a href="#IiramN">see <span class="ar">إِرَمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarimN">
				<h3 class="entry"><span class="ar">أَرِمٌ</span></h3>
				<div class="sense" id="OarimN_A1">
					<p><span class="ar">أَرِمٌ</span> <span class="add">[part. n. of <span class="ar">أَرِمَ</span>]</span>. You say <span class="ar long">أَرْضُ أَرِمَةٌ</span>, meaning <em>Land upon which rain has not fallen for a long time:</em> <span class="auth">(T:)</span> or <em>land which does not give growth to anything.</em> <span class="auth">(TA.)</span> <span class="add">[Not to be confounded with <span class="ar">آرِمَهٌ</span>, q. v.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارم</span> - Entry: <span class="ar">أَرِمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OarimN_B1">
					<p><a href="#IiramN">See also what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiramN">
				<h3 class="entry"><span class="ar">إِرَمٌ</span></h3>
				<div class="sense" id="IiramN_A1">
					<p><span class="ar">إِرَمٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَرِمٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> like <span class="ar">كَتِفٌ</span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">إِرْمٌ↓</span></span>, <span class="auth">(so in a copy of the M,)</span> and<span class="arrow"><span class="ar">إِرَمِىٌّ↓</span></span> and<span class="arrow"><span class="ar">أَرَمِىٌّ↓</span></span>, <span class="auth">(M, Ḳ,)</span> from Lḥ, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">أَرْمِىٌّ↓</span></span>, from Lḥ, <span class="auth">(so in a copy of the M,)</span> and<span class="arrow"><span class="ar">إِرْمِىٌّ↓</span></span>, from Lḥ, <span class="auth">(TA,)</span> and <span class="ar">يَرَمِىٌّ</span>, <span class="auth">(M, Ḳ,)</span> from Lḥ, <span class="auth">(TA,)</span> and <span class="ar">أَيْرَمِىٌّ</span>, <span class="auth">(T, Ḳ,)</span> <em>A sign,</em> or <em>mark, set up to show the way;</em> <span class="auth">(M, Ḳ;)</span> <em>stones set up as a sign,</em> or <em>mark, to show the way in the desert:</em> <span class="auth">(Ṣ:)</span> or particularly <em>one belonging to</em> <span class="add">[<em>the tribe of</em>]</span>' <em>Ád:</em> <span class="auth">(M, Ḳ:)</span> accord. to ISh, the <span class="ar">إِرَم</span> is <span class="add">[<em>a thing</em>]</span> <em>like a man in a standing posture upon the head of a hill, whereby one is directed to the right way, and whereby the land is marked, composed of stones set one upon another, and is only the work of the Muslims, and such is made by people in the present day, upon the road:</em> <span class="auth">(T:)</span> or <em>such as was made by the people in the time of ignorance, who were accustomed, when they found a thing in their way and could not take it with them, to leave upon it some stones, whereby to know it, until, when they returned, they took it:</em> <span class="auth">(TA:)</span> the pl. <span class="add">[of pauc.]</span> is <span class="ar">آرَامٌ</span> and <span class="add">[of mult.]</span> <span class="ar">أُرُومٌ</span> <span class="auth">(ISh, T, Ṣ, M, Ḳ:)</span> or <span class="ar">أُرُومٌ</span> signifies the <em>graves,</em> or <em>sepulchres, of</em> <span class="add">[<em>the tribe of</em>]</span>' <em>Ád.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارم</span> - Entry: <span class="ar">إِرَمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IiramN_B1">
					<p><span class="add">[<span class="ar">إِرَمٌ</span> in the phrase <span class="ar long">إِرَمُ ذَاتُ العِمَادِ</span> (<a href="index.php?data=18_E/195_Emd">see art. <span class="ar">عمد</span></a>) is a proper name; but whether of a place, or a tribe, or an individual, is disputed: it is commonly believed to be the name of <em>The terrestrial paradise of Sheddád the son of 'Ád:</em> see Bḍ lxxxix. 6.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaromaMCu">
				<h3 class="entry"><span class="ar">أَرْمَآءُ</span></h3>
				<div class="sense" id="OaromaMCu_A1">
					<p><span class="ar long">أَرْضٌ أَرْمَآءُ</span> <em>Land in which there is not a root,</em> or <em>stock, of a tree; as though it were</em> <span class="arrow"><span class="ar">مَأْرُومَة↓</span></span> <span class="add">[or <em>extirpated</em>]</span>: <span class="auth">(O:)</span> or <em>land in which neither root nor branch is left;</em> as also<span class="arrow"><span class="ar">مَأْرُومَةٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaromieBN">
				<h3 class="entry"><span class="ar">أَرْمِىٌّ</span> / 
							<span class="ar">إِرْمِىٌّ</span> / 
							<span class="ar">أَرَمِىٌّ</span> / 
							<span class="ar">إِرَمِىٌّ</span></h3>
				<div class="sense" id="OaromieBN_A1">
					<p><span class="ar">أَرْمِىٌّ</span> and <span class="ar">إِرْمِىٌّ</span> and <span class="ar">أَرَمِىٌّ</span> and <span class="ar">إِرَمِىٌّ</span>: <a href="#IiramN">see <span class="ar">إِرَمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaruwmN">
				<h3 class="entry"><span class="ar">أَرُومٌ</span></h3>
				<div class="sense" id="OaruwmN_A1">
					<p><span class="ar">أَرُومٌ</span>: <a href="#OaruwmapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaruwmapN">
				<h3 class="entry"><span class="ar">أَرُومَةٌ</span></h3>
				<div class="sense" id="OaruwmapN_A1">
					<p><span class="ar">أَرُومَةٌ</span> <span class="auth">(T, M, Ḳ)</span> and <span class="ar">أُرُومَةٌ</span>, <span class="auth">(M, Ḳ,)</span> the latter of the dial. of Temeem, <span class="auth">(TA,)</span> or this is not allowable, <span class="auth">(T,)</span> or<span class="arrow"><span class="ar">أَرُومٌ↓</span></span>, <span class="auth">(Ṣ,)</span> or this is the pl., <span class="auth">(M, Ḳ,)</span> <span class="add">[or a coll. gen. n.,]</span> The <em>root,</em> or <em>base,</em> or <em>lowest part,</em> syn. <span class="ar">أَصْل</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> of a tree <span class="auth">(T, Ṣ)</span> of any kind; <span class="auth">(T;)</span> and of a horn: <span class="auth">(Ṣ:)</span> or, of a tree, <span class="add">[or plant, the <em>root-stock,</em> or <em>rhizoma,</em> or]</span> the <em>part from which branch off the</em> <span class="ar">عُرُوق</span> <span class="add">[or <em>roots properly so called</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">عرق</span>. <span class="add">[<a href="#janobapN">See an instance of its use voce <span class="ar">جَنْبَةٌ</span></a>; <a href="#jinovN">another, voce <span class="ar">جِنْثٌ</span></a>; <a href="#jazarN">and another, voce <span class="ar">جَزَرٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارم</span> - Entry: <span class="ar">أَرُومَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaruwmapN_A2">
					<p>And <span class="add">[hence,]</span> † The <em>origin,</em> or <em>stock,</em> of a man: <span class="auth">(TA:)</span> ‡ The <em>origin</em> of <span class="ar">حَسَب</span> <span class="add">[or grounds of pretension to respect or honour, &amp;c.]</span>. <span class="auth">(Ḥar p. 99.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MrimapN">
				<h3 class="entry"><span class="ar">آرِمَةٌ</span></h3>
				<div class="sense" id="MrimapN_A1">
					<p><span class="ar long">سَنَةٌ آرِمَةٌ</span> <span class="auth">(Ṣ, Ḳ, TA <span class="add">[in the CK, erroneously, <span class="ar">اَرِمَةٌ</span>]</span>)</span> <em>An extirpating year of dearth</em> or <em>drought</em> or <em>sterility:</em> <span class="auth">(Ṣ:)</span> or <em>a year of dearth</em>, &amp;c. <em>cutting off people.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOoruwmapN">
				<h3 class="entry"><span class="ar">مَأْرُومَةٌ</span></h3>
				<div class="sense" id="maOoruwmapN_A1">
					<p><span class="ar long">أَرْضٌ مَأْرُومَةٌ</span>: <a href="#OaromaACu">see <span class="ar">أَرْمَآءُ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0051.pdf" target="pdf">
							<span>Lanes Lexicon Page 51</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
