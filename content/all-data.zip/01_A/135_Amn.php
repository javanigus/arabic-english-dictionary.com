<article class="root" id="Root_Amn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/134_Aml">امل</a></span>
				<span class="ar">امن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/136_Amh">امه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Amn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمن</span></h3>
				<div class="sense" id="Amn_1_A1">
					<p><span class="ar">أَمِنَ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَنُ</span>}</span></add>, <span class="auth">(T, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَمْنٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">إِمْنٌ</span> <span class="auth">(Zj, M, Ḳ)</span> and <span class="ar">أَمَنٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أَمَنَةٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">إِمْنَةٌ</span> <span class="auth">(T)</span> and <span class="ar">أَمَانٌ</span> <span class="auth">(M, Ḳ)</span> <span class="add">[and app. <span class="ar">أَمَانَةٌ</span>, for it is said in the Ṣ that this is syn. with <span class="ar">أَمَانٌ</span>,]</span> and <span class="ar">آمنٌ</span>, an instance of an inf. n. of the measure <span class="ar">فَاعِلٌ</span>, which is strange, <span class="auth">(MF,)</span> or this is a subst. like <span class="ar">فَالِجٌ</span>, <span class="auth">(M,)</span> <em>He was,</em> or <em>became,</em> or <em>felt, secure, safe,</em> or <em>in a state of security</em> or <em>safety;</em> originally, <em>he was,</em> or <em>became, quiet,</em> or <em>tranquil, in heart,</em> or <em>mind;</em> <span class="auth">(Mṣb;)</span> <em>he was,</em> or <em>became, secure,</em> or <em>free from fear;</em> <span class="ar">أَمْنٌ</span> signifying the <em>contr. of</em> <span class="ar">خَوْفٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and so <span class="ar">أَمَنَةٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">آمِنٌ</span> <span class="add">[&amp;c.]</span>: <span class="auth">(M, Ḳ:)</span> <em>he was,</em> or <em>became,</em> or <em>felt, free from expectation of evil,</em> or <em>of an object of dislike</em> or <em>hatred, in the coming time;</em> originally, <em>he was,</em> or <em>became, easy in mind, and free from fear.</em> <span class="auth">(El-Munáwee, TA.)</span> <span class="add">[<a href="#OamonN">See <span class="ar">أَمْنٌ</span>, below</a>.]</span> You say also, <span class="ar long">يَإْمَنُ عَلَى نَفْسِهِ</span> <span class="add">[<em>He is secure,</em> or <em>safe,</em> or <em>free from fear, for himself</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">أَمِنَ البَلَدُ</span>, meaning <em>The inhabitants of the country</em> or <em>district,</em> or <em>town, were in a state of security,</em> or <em>confidence, therein.</em> <span class="auth">(Mṣb.)</span> The verb is trans. by itself, and by means of the particle <span class="ar">مِنْ</span>; as in <span class="ar long">أَمَنَ زَيْدٌ الأَسَدَ</span> and <span class="ar long">أَمِنَ مِنَ الأَسَدِ</span>, meaning <em>Zeyd was,</em> or <em>became,</em> or <em>felt, secure from, safe from,</em> <span class="add">[or <em>free from fear of,</em>]</span> <em>the lion.</em> <span class="auth">(Mṣb.)</span> You say also, <span class="ar long">أَمِنَ كَذِبَ مَنْ أَخْبَرَهُ</span> <span class="add">[<em>He was secure from,</em> or <em>free from fear of, the lying of him who informed him</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">لَا آنَنُ أَنْ يَكُونَ كَذلِكَ</span> <span class="add">[<em>I am not free from fear of its being so; I am not sure but that it may be so</em>]</span>. <span class="auth">(Mgh in art. <span class="ar">نبذ</span>; and other lexicons passim.)</span> And, of a strong-made she camel, <span class="ar long">أَمِنَتْ أَنْ تَكُونَ ضَعَيفَةً</span> <span class="add">[<em>She was secure from,</em> or <em>free from fear of, being weak</em>]</span>: <span class="auth">(M: <span class="add">[in a copy of the Ṣ <span class="ar">أُمِنَتْ</span>:]</span>)</span> and <span class="ar long">أَمِنَتِ العِثَارَ وَالإَعْيَآءٍ</span> <span class="add">[<em>She was secure from,</em> or <em>free from fear of, stumbling, and becoming jaded</em>]</span>: <span class="auth">(M:)</span> and <span class="ar long">أُمِنَ عِثَارُهَا</span> <span class="add">[<em>Her stumbling was not feared</em>]</span>. <span class="auth">(So in a copy of the Ṣ.)</span> And, of a highly-prized camel, <span class="ar long">أُمِنَ أَنْ يُنْحَرَ</span> <span class="add">[<em>It was not feared that he would be slaughtered;</em> or <em>his being slaughtered was not feared</em>]</span>. <span class="auth">(M.)</span> <span class="add">[<span class="ar">أَمنَهُ</span> sometimes means <em>He was,</em> or <em>became, free from fear, though having cause for fear, of him,</em> or <em>it.</em> i. e. <em>he thought himself secure,</em> or <em>safe, from him</em> or <em>it.</em> <span class="auth">(See Ḳur vii. 97.)</span>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amn_1_A2">
					<p><span class="ar">أمِنَهُ</span> <span class="auth">(inf. n. <span class="ar">أَمْنٌ</span> TḲ)</span> <span class="add">[and accord. to some copies of the Ḳ <span class="arrow"><span class="ar">آمَنَهُ↓</span></span>]</span> and<span class="arrow"><span class="ar">أمّنهُ↓</span></span> <span class="auth">(inf. n. <span class="ar">تَأْمِينٌ</span> Ḳ)</span> and<span class="arrow"><span class="ar">ائتمنهُ↓</span></span> <span class="auth">(<span class="add">[written with the disjunctive alif <span class="ar">اِيتَمَنَهُ</span>, and]</span> also written <span class="ar">اِتَّمَنَهُ</span>, on the authority of Th, which is extr., like <span class="ar">اِتَّهَلَ</span> <span class="add">[&amp;c.]</span>, M)</span> and<span class="arrow"><span class="ar">استأمنهُ↓</span></span> all signify the same <span class="auth">(M, Ḳ, TA)</span> <span class="add">[<em>He trusted,</em> or <em>confided, in him;</em> <span class="auth">(as also <span class="ar long">آمن بِهِ</span>, q. v.;)</span> <em>he intrusted him with,</em> or <em>confided to him, power, authority, control,</em> or <em>a charge; he gave him charge</em> over a thing or person: these meanings are vaguely indicated in the M and Ḳ and TA.]</span>. You say, <span class="ar long">يَأْمَنُهُ النَّاسُ وَلَا يَخَافُونَ غَائِلَتَهُ</span> <span class="add">[<em>Men,</em> or <em>people, trust,</em> or <em>confide, in him, and do not fear his malevolence,</em> or <em>mischievousness</em>]</span>. <span class="auth">(T, M.)</span> And <span class="ar long">أَمِنَهُ عَلَى كَذَا</span> <span class="auth">(Ṣ, Mgh,* Mṣb *)</span> and<span class="arrow"><span class="ar long">ائتمنهُ↓ عَلَيْهِ</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <span class="add">[<em>He trusted,</em> or <em>confided, in him with respect to such a thing; he intrusted him with,</em> or <em>confided to him, power, authority, control,</em> or <em>a charge, over it; he gave him charge over it;</em>]</span> <em>he made him,</em> or <em>took him as,</em> <span class="ar">أَمِين</span> <em>over such a thing.</em> <span class="auth">(Mgh.)</span> Hence, in a trad., the <span class="ar">مُؤَذِّن</span> is said to be <span class="ar">مُؤْتَمَنٌ</span>; i. e.<span class="arrow"><span class="ar long">يَأْتَمِنُهُ↓ النَّاسُ عَلَ الأَوْقَاتِ الَّتِى يُؤَذَّنُ فِيهَا</span></span> <span class="add">[<em>Men trust,</em> or <em>confide, in him with respect to the times in which he calls to prayer</em>]</span>, and know, by his calling to prayer, what they are commanded to do, as to praying and fasting and breaking fast. <span class="auth">(Mgh.)</span> It is said in the Ḳur <span class="add">[xii. 11]</span>, <span class="ar long">مَا لَكَ لَا تَأْمَنُنَا عَلَى يُوسُفَ</span> and <span class="add">[<span class="ar">تَأْمَنَّا</span>]</span> with idghám <span class="add">[i. e. <em>What aileth thee that thou dost not trust,</em> or <em>confide, in us with respect to Joseph?</em> or, <em>that thou dost not give us charge over Joseph?</em>]</span>; <span class="auth">(Ṣ;)</span> meaning, why dost thou fear us for him? <span class="auth">(Bḍ;)</span> some pronouncing the verb in a manner between those of the former and the latter modes of writing it; but Akh says that the latter is better: <span class="auth">(Ṣ:)</span> some read <span class="ar">تِيمَنَّا</span>. <span class="auth">(Bḍ.)</span> You say also,<span class="arrow"><span class="ar long">اُوتُمِنَ↓ فُلَانٌ</span></span> <span class="add">[<em>Such a one was trusted,</em> or <em>confided, in</em>, &amp;c.;]</span> when it begins a sentence, changing the second <span class="ar">ء</span> into <span class="ar">و</span>; in like manner as you change it into <span class="ar">ى</span> when the first is with kesr, as in <span class="ar">اِيتَمَنَهُ</span>; and into <span class="ar">ا</span> when the first is with fet-ḥ, as in <span class="ar">آمَنَ</span>. <span class="auth">(Ṣ.)</span> The phrase<span class="arrow"><span class="ar long">اُوتُمِنَ↓ أَمَانَةً</span></span>, in a saying of Moḥammad, if it be not correctly <span class="ar long">عَلَى أَمَانَةٍ</span>, may be explained as implying the meaning of <span class="ar long">اُسْتُحْفِظَ أَمَانَةً</span> <span class="add">[<em>He was asked to take care of a deposite;</em> or <em>he was intrusted with it</em>]</span>. <span class="auth">(Mgh.)</span> <span class="add">[You also say, <span class="ar long">أَمِنَهُ بِكَذَا</span>, meaning <em>He intrusted him with such a thing;</em> as, for instance, money or other property: see two exs. in the Ḳur iii. 68.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amn_1_B1">
					<p><span class="ar">أَمُنَ</span>, <span class="auth">(M, Mgh, Ḳ,)</span> or <span class="ar">أَمِنَ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">أَمَانَةٌ</span>, <span class="auth">(M, Mgh, Mṣb,)</span> <em>He was,</em> or <em>became, trusted in,</em> or <em>confided in:</em> <span class="auth">(M, Ḳ:)</span> or <em>he was,</em> or <em>became, trusty, trustworthy, trustful, confidential,</em> or <em>faithful:</em> said of a man. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amn_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّن</span></h3>
				<div class="sense" id="Amn_2_A1">
					<p><span class="ar">أمّنهُ</span>, inf. n. <span class="ar">تَأْمِينٌ</span>: <a href="#Amn_4">see 4</a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amn_2_A2">
					<p><a href="#Amn_1_A2">and see also <span class="ar">أَمِنَهُ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amn_2_B1">
					<p><span class="ar">أمّن</span>, inf. n. as above, also signifies <em>He said</em> <span class="ar">آمِينَ</span> or <span class="ar">أَمِينَ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> after finishing the Fátihah, <span class="auth">(T,)</span> or <span class="ar long">عَلَى الدُّعَآءِ</span> <em>on the occasion of the prayer,</em> or <em>supplication.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amn_4">
				<h3 class="entry">4. ⇒ <span class="ar">آمن</span></h3>
				<div class="sense" id="Amn_4_A1">
					<p><span class="ar">آمَنَ</span> is originally <span class="ar">أَأْمَنَ</span>; the second <span class="ar">ء</span> being softened. <span class="auth">(Ṣ.)</span> You say, <span class="ar">آمنهُ</span>, <span class="add">[inf. n. <span class="ar">إِيمَانٌ</span>;]</span> <span class="auth">(Ṣ, M, Mṣb;)</span> and<span class="arrow"><span class="ar">أمّنهُ↓</span></span>, <span class="add">[inf. n. <span class="ar">تَأْمِينٌ</span>;]</span> <span class="auth">(M, TA;)</span> meaning <em>He rendered him secure,</em> or <em>safe;</em> <span class="auth">(Mṣb;)</span> <em>he rendered him secure,</em> or <em>free from fear;</em> <span class="auth">(Ṣ, M, TA;)</span> <em>contr. of</em> <span class="ar">أَخَافهُ</span>: <span class="auth">(TA:)</span> so in <span class="ar long">آمَنْتُهُ مِنْهُ</span> <em>I rendered him secure,</em> or <em>safe, from him,</em> or <em>it.</em> <span class="auth">(Mṣb.)</span> And of God you say, <span class="ar long">آمَنَ عِبادَهُ مِنْ أَنْ يَظْلِمَهُمْ</span> <span class="add">[<em>He hath rendered his servants secure from his wronging them</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">يُؤْمِنُ عِبَادَهُ مِنْ عَذَابِهِ</span> <span class="add">[<em>He rendereth his servants secure from his punishment</em>]</span>. <span class="auth">(M.)</span> You say also, <span class="ar long">آمَنْتُ الأَسِيرَ</span>, meaning <em>I gave,</em> or <em>granted,</em> <span class="ar">الأَمَان</span> <span class="add">[i. e. <em>security</em> or <em>safety,</em> or <em>protection</em> or <em>safeguard,</em> or <em>the promise</em> or <em>assurance of security</em> or <em>safety,</em> or <em>indemnity,</em> or <em>quarter,</em>]</span> <em>to the captive.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">آمَنَ فُلَانٌ الَعَدُوَّ</span> <span class="add">[<em>Such a one granted security,</em>, &amp;c., <em>to the enemy</em>]</span>, inf. n. as above. <span class="auth">(T.)</span> It is said in the Ḳur ch. ix. <span class="add">[verse 12]</span>, accord. to one reading, <span class="ar long">لَا إِيمَانَ لَهُمْ</span> <em>They have not the attribute of granting protection;</em> meaning that when they grant protection, they do not fulfil their engagement to protect. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amn_4_B1">
					<p><span class="ar">إِيمَانٌ</span> also signifies The <em>believing</em> <span class="add">[a thing, or in a thing, and particularly in God]</span>; syn. <span class="ar">تَصْدِيقٌ</span>; <span class="auth">(T, Ṣ, &amp;c.;)</span> by common consent of the lexicologists and other men of science: <span class="auth">(T:)</span> its primary meaning is the <em>becoming true to the trust with respect to which God has confided in one, by a firm believing with the heart; not by profession of belief with the tongue only, without the assent of the heart;</em> for he who does not firmly believe with his heart is either a hypocrite or an ignorant person. <span class="auth">(T, TA.)</span> Its verb is intrans. and trans. <span class="auth">(TA, from a Commentary on the Mutowwal.)</span> You say, <span class="ar">آمَنَ</span>, meaning <em>He believed.</em> <span class="auth">(T.)</span> And it is said to be trans. by itself, like <span class="ar">صَدَّقَ</span>; and by means of <span class="ar">بِ</span>, considered as meaning <span class="ar">اِعْتِرَافٌ</span> <span class="add">[or <em>acknowledgment</em>]</span>; and by means of <span class="ar">لِ</span>, considered as meaning <span class="ar">إِذْعَانٌ</span> <span class="add">[or <em>submission</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[Thus]</span> you say, <span class="add">[<span class="ar">آمنهُ</span> and]</span> <span class="ar long">آمن بِهِ</span>, <span class="auth">(inf. n. <span class="ar">إِيمَانٌ</span>, T, Ḳ,)</span> namely, a thing. <span class="auth">(T, M.)</span> And <span class="ar long">آمن بِٱللّٰهِ</span> <em>He believed in God.</em> <span class="auth">(T.)</span> It seems to be meant by what is said in the Ksh <span class="add">[in ii. 2]</span>, that <span class="ar long">آمن بِهِ</span> <span class="add">[or <span class="ar">آمَنَهُ</span>]</span> properly signifies <span class="ar long">آمَنَهُ التَّكْذِيبَ</span> <span class="add">[<em>He rendered him secure from being charged with lying,</em> or <em>falsehood</em>]</span>; and that the meaning <em>he believed him</em> or <em>in him,</em> is tropical; but this is at variance with what its author says in the A; and Es-Saạd says that this latter meaning is proper. <span class="auth">(TA.)</span> <span class="pb" id="Page_0101"></span>The phrase in the Ḳur <span class="add">[ix. 61]</span>, <span class="ar long">وَيُؤْمِنُ لِلْمؤْمِنِينَ</span>, accord. to Th, means <em>And he believeth the believers; giveth credit to them.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Amn_4_B2">
					<p>Sometimes it is employed to signify The <em>acknowledging with the tongue</em> only; and hence, in the Ḳur <span class="add">[lxiii. 3]</span>, <span class="ar long">ذلِكَ بأَنَّهُمْ آمَنُوا ثُمَّ كَفَرُوا</span> <em>That is because they acknowledged with the tongue, then disacknowledged with the heart.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Amn_4_B3">
					<p>Also † The <em>trusting,</em> or <em>confiding,</em> or <em>having trust</em> or <em>confidence.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[You say, <span class="ar long">آمن بِهِ</span>, meaning <em>He trusted,</em> or <em>confided, in him,</em> or <em>it:</em> for]</span> the verb of <span class="ar">ايمان</span> in this sense is trans. by means of <span class="ar">بِ</span> without implication; as Bḍ says. <span class="auth">(TA.)</span> <span class="add">[And it is also trans. by itself: for]</span> you say, <span class="ar long">مَا آمَنَ أَنْ يَجِدَ صَحَابَةً</span>, meaning ‡ <em>He trusted not that he would find companions;</em> <span class="auth">(M,* Ḳ,* TA;)</span> said of one who has formed the intention of journeying: or the meaning is <span class="ar long">مَا كَادَ</span> <span class="add">[i. e. <em>he hardly,</em> or <em>scarcely, found</em>, &amp;c.; or <em>he was not near to finding</em>, &amp;c.]</span>. <span class="auth">(M, Ḳ.)</span> <a href="#Amn_1_A2">See also <span class="ar">أَمِنَهُ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Amn_4_B4">
					<p>Also The <em>manifesting humility</em> or <em>submission, and the accepting the Law,</em> <span class="auth">(Zj, T,* Ḳ,)</span> <em>and that which the Prophet has said</em> or <em>done, and the firm believing thereof with the heart;</em> <span class="auth">(Zj, T, M;)</span> without which firm belief, the manifesting of humility or submission, and the accepting that which the Prophet has said or done, is termed <span class="ar">إِسْلَامٌ</span>, for which one's blood is to be spared. <span class="auth">(T.)</span> <span class="add">[In this sense, it is trans. by means of <span class="ar">لِ</span>, accord. to some, as shown above; or by means of <span class="ar">بِ</span>, for, accord. to Fei,]</span> you say, <span class="ar long">آمَنْتُ بِٱللّٰهِ</span>, inf. n. as above, meaning <em>I submitted,</em> or <em>resigned, myself to God.</em> <span class="auth">(Mṣb.)</span> <span class="add">[There are numerous other explanations which it is needless to give, differing according to different persuasions.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="Amn_4_B5">
					<p><span class="add">[<a href="#IiymaAn">See also <span class="ar">إِيمَان</span> below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Amn_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتمن</span></h3>
				<div class="sense" id="Amn_8_A1">
					<p><a href="#Amn_1">see 1</a>, in five places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amn_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأمن</span></h3>
				<div class="sense" id="Amn_10_A1">
					<p><span class="ar">استأمنهُ</span> <em>He asked,</em> or <em>demanded, of him</em> <span class="ar">الأَمَان</span> <span class="add">[i. e. <em>security</em> or <em>safety,</em> or <em>protection</em> or <em>safeguard,</em> or <em>the promise</em> or <em>assurance of security</em> or <em>safety,</em> or <em>indemnity,</em> or <em>quarter</em>]</span>. <span class="auth">(T,* Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amn_10_A2">
					<p><a href="#Amn_1_A2">See also <span class="ar">أَمِنَهُ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Amn_10_A3">
					<p><span class="ar long">استأمن إِلَيْهِ</span> <em>He entered within the pale of his</em> <span class="ar">أمَان</span> <span class="add">[or <em>protection,</em> or <em>safeguard</em>]</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamonN">
				<h3 class="entry"><span class="ar">أَمْنٌ</span></h3>
				<div class="sense" id="OamonN_A1">
					<p><span class="ar">أَمْنٌ</span> <span class="add">[<a href="#Amn_1">an inf. n. of <span class="ar">أَمِنِ</span></a>: as a simple subst. it signifies <em>Security,</em> or <em>safety:</em> (<a href="#Oamina">see <span class="ar">أَمِنَ</span></a>:) or]</span> <em>security</em> as meaning <em>freedom from fear;</em> <a href="#xaWofN">contr. of <span class="ar">خَوْفٌ</span></a>; <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِمْنٌ↓</span></span> <span class="auth">(Zj, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَمِنٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">أَمَنَهُ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> <span class="add">[and<span class="arrow"><span class="ar">إِمْنَةٌ↓</span></span> (<a href="#Oamina">see <span class="ar">أَمِنَ</span></a>)]</span> and<span class="arrow"><span class="ar">أَمَانٌ↓</span></span> and<span class="arrow"><span class="ar">آمِنٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <a href="#Amn_1">which last is an inf. n. of <span class="ar">أَمِنَ</span> <span class="add">[like the rest]</span></a>, <span class="auth">(MF,)</span> or a subst. like <span class="ar">فَالِجٌ</span>; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar">أَمَانَةٌ↓</span></span> is syn. with <span class="ar">أَمَانٌ</span>, <span class="auth">(Ṣ,)</span> both of these signifying <em>security,</em> or <em>safety,</em> and <em>freedom from fear:</em> <span class="auth">(PṢ:)</span> or <span class="ar">أَمْنٌ</span> signifies <em>freedom from expectation of evil,</em> or <em>of an object of dislike</em> or <em>hatred, in the coming time;</em> originally, <em>ease of mind, and freedom from fear.</em> <span class="auth">(El-Munáwee, TA.)</span> You say, <span class="ar long">أَنْتَ فِى أَمْنٍ</span> <span class="add">[<em>Thou art in a state of security</em>]</span>, <span class="auth">(T, M,)</span> <span class="ar long">مِنْ ذَاكَ</span> <span class="add">[<em>from that</em>]</span>; and<span class="arrow"><span class="ar long">فى أَمَانٍ↓</span></span> signifies the same; <span class="auth">(T;)</span> and so<span class="arrow"><span class="ar long">فى آمِنٍ↓</span></span>. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">أَمَنَةً↓ نُعَاسًا</span></span>, in the Ḳur <span class="add">[iii. 148]</span>, means <em>Security</em> (<span class="ar">أَمْنًا</span>) <span class="add">[and <em>slumber</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="arrow"><span class="ar">أَمَانٌ↓</span></span> also signifies <em>Protection,</em> or <em>safeguard:</em> and <span class="add">[very frequently]</span> <em>a promise,</em> or <em>an assurance, of security</em> or <em>safety; indemnity;</em> or <em>quarter:</em> in Pers. <span class="ar">پَنَاهْ</span> and <span class="ar">زِنْهَارٌ</span>: <span class="auth">(KL:)</span> syn. <span class="ar">إِلُّ</span>. <span class="auth">(Ḳ in art. <span class="ar">ال</span>.)</span> You say,<span class="arrow"><span class="ar long">دَخَلَ فِى أَمَانِهِ↓</span></span> <span class="add">[<em>He entered within the pale of his protection,</em> or <em>safeguard</em>]</span>. <span class="auth">(Ṣ, Mṣb.)</span> <span class="add">[And<span class="arrow"><span class="ar long">كُنٌ فِى أَمَانِ↓ ٱللّٰهِ</span></span> <em>Be thou in the protection,</em> or <em>safeguard, of God.</em>]</span> And<span class="arrow"><span class="ar long">أَعْطَيْتُهُ الأَمَانَ↓</span></span> <span class="add">[<em>I gave,</em> or <em>granted, to him security</em> or <em>safety,</em> or <em>protection</em> or <em>safeguard,</em> or <em>the promise</em> or <em>assurance of security</em> or <em>safety,</em> or <em>indemnity,</em> or <em>quarter</em>]</span>; namely, a captive. <span class="auth">(Mṣb.)</span> And<span class="arrow"><span class="ar long">طَلَبَ مِنْهُ الأَمَانَ↓</span></span> <span class="add">[<em>He asked,</em> or <em>demanded, of him security</em> or <em>safety,</em> or <em>protection</em> or <em>safeguard,</em>, &amp;c., as in the next preceding ex.]</span>. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamonN_A2">
					<p><span class="ar">أَمْنًا</span> in the Ḳur ii. 119 means <span class="ar long">ذَا أَمْن</span> <span class="add">[<em>Possessed of security</em> or <em>safety</em>]</span>: <span class="auth">(Aboo-Is-ḥáḳ, M:)</span> or <span class="ar long">مَوْضِعَ أَمْنٍ</span> <span class="add">[<em>a place of security</em> or <em>safety;</em> like <span class="ar">مَأْمَنًا</span>]</span>. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamonN_A3">
					<p><a href="#AminN">See also <span class="ar">آمِنٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OamonN_A4">
					<p>You say also, <span class="ar long">مَا أَحْسَنَ أَمْنَكَ</span>, and<span class="arrow"><span class="ar">أَمَنَكَ↓</span></span>, meaning <em>How good is thy religion!</em> and <em>thy natural disposition!</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimonN">
				<h3 class="entry"><span class="ar">إِمْنٌ</span></h3>
				<div class="sense" id="IimonN_A1">
					<p><span class="ar">إِمْنٌ</span>: <a href="#OamonN">see <span class="ar">أَمْنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OamanN">
				<h3 class="entry"><span class="ar">أَمَنٌ</span></h3>
				<div class="sense" id="OamanN_A1">
					<p><span class="ar">أَمَنٌ</span>: <a href="#OamonN">see <span class="ar">أَمْنٌ</span></a>, first and last sentences.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaminN">
				<h3 class="entry"><span class="ar">أَمِنٌ</span></h3>
				<div class="sense" id="OaminN_A1">
					<p><span class="ar">أَمِنٌ</span>: <a href="#AminN">see <span class="ar">آمِنٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaminN_A2">
					<p>Also, <span class="auth">(Ḳ, <span class="add">[there said to be like <span class="ar">كَتِفٌ</span>,]</span>)</span> or<span class="arrow"><span class="ar">آمِنٌ↓</span></span>, <span class="auth">(M, <span class="add">[so written in a copy of that work,]</span>)</span> <em>Asking,</em> or <em>demanding,</em> or <em>seeking, protection, in order to be secure,</em> or <em>safe,</em> or <em>free from fear, for himself:</em> <span class="auth">(M, Ḳ:)</span> so says IAạr. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimonapN">
				<h3 class="entry"><span class="ar">إِمْنَةٌ</span></h3>
				<div class="sense" id="IimonapN_A1">
					<p><span class="ar">إِمْنَةٌ</span>: <a href="#OamonN">see <span class="ar">أَمْنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OmanapN">
				<h3 class="entry"><span class="ar">أمَنَةٌ</span></h3>
				<div class="sense" id="OmanapN_A1">
					<p><span class="ar">أمَنَةٌ</span>: <a href="#OamonN">see <span class="ar">أَمْنٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أمَنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OmanapN_A2">
					<p><a href="#OamaAnapN">and see also <span class="ar">أَمَانَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أمَنَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OmanapN_B1">
					<p>Also A man <em>who trusts,</em> or <em>confides, in every one;</em> <span class="auth">(T, Ṣ, M;)</span> and so<span class="arrow"><span class="ar">أُمَنَةٌ↓</span></span>: <span class="auth">(Ṣ:)</span> and <em>who believes in everything that he hears; who disbelieves in nothing:</em> <span class="auth">(Lḥ, T:)</span> or <em>in whom men,</em> or <em>people, trust,</em> or <em>confide, and whose malevolence,</em> or <em>mischievousness, they do not fear:</em> <span class="auth">(T, M:)</span> and<span class="arrow"><span class="ar">أُمَنَةٌ↓</span></span> signifies <em>trusted in,</em> or <em>confided in;</em> <span class="add">[like <span class="ar">أَمِينٌ</span>;]</span> and by rule should be <span class="ar">أُمْنَةٌ</span>, because it has the meaning of a pass. part. n. <span class="add">[like <span class="ar">لُعْنَةٌ</span> and <span class="ar">ضُحْكَةٌ</span> and <span class="ar">لُقْطَلةٌ</span>, &amp;c. (<a href="#laqaTN">see <span class="ar">لَقَطٌ</span></a>)]</span>: <span class="auth">(M:)</span> or both signify one <em>in whom every one trusts,</em> or <em>confides, in,</em> or <em>with respect to, everything.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أمَنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OmanapN_B2">
					<p><a href="#OamiynN">See also <span class="ar">أَمِينٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OumanapN">
				<h3 class="entry"><span class="ar">أُمَنَةٌ</span></h3>
				<div class="sense" id="OumanapN_A1">
					<p><span class="ar">أُمَنَةٌ</span>: <a href="#OamanapN">see <span class="ar">أَمَنَةٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OamaAnN">
				<h3 class="entry"><span class="ar">أَمَانٌ</span></h3>
				<div class="sense" id="OamaAnN_A1">
					<p><span class="ar">أَمَانٌ</span>: <a href="#OamonN">see <span class="ar">أَمْنٌ</span></a>, in seven places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamuwnN">
				<h3 class="entry"><span class="ar">أَمُونٌ</span></h3>
				<div class="sense" id="OamuwnN_A1">
					<p><span class="ar">أَمُونٌ</span>, applied to a she camel, of the measure <span class="ar">فَعُولٌ</span> in the sense of the measure <span class="ar">مَفْعُولَةٌ</span>, like <span class="ar">عَصُوبٌ</span> and <span class="ar">حَلُوبٌ</span>, ‡ <em>Trusted,</em> or <em>confided, in;</em> <span class="auth">(T;)</span> <em>firmly, compactly,</em> or <em>strongly, made;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> <em>secure from,</em> or <em>free from fear of, being weak:</em> <span class="auth">(Ṣ, M:)</span> also, that is <em>secure from,</em> or <em>free from fear of, stumbling, and becoming jaded:</em> <span class="auth">(M:)</span> or <em>strong, so that her becoming languid is not feared:</em> <span class="auth">(A, TA:)</span> pl. <span class="ar">أُمُنٌ</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#OamynN">See also what next follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamiynN">
				<h3 class="entry"><span class="ar">أَمِينٌ</span></h3>
				<div class="sense" id="OamiynN_A1">
					<p><span class="ar">أَمِينٌ</span> <em>Trusted; trusted in; confided in;</em> <span class="auth">(T,* Ṣ,* M, Mṣb,* Ḳ;)</span> as also<span class="arrow"><span class="ar">أُمَّانٌ↓</span></span>; <span class="auth">(Ṣ, M, Ḳ;)</span> <em>i. q.</em><span class="arrow"><span class="ar">مَأْمُونٌ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">مُؤْتَمَنٌ↓</span></span>: <span class="auth">(ISk, T, Ḳ:)</span> <span class="add">[<em>a person in whom one trusts</em> or <em>confides; a confidant; a person intrusted with,</em> or <em>to whom is confided, power, authority, control,</em> or <em>a charge,</em> <span class="ar long">عَلَى شَىْءٍ</span> <em>over a thing; a person intrusted with an affair,</em> or <em>with affairs,</em> i. e., <em>with the management,</em> or <em>disposal, thereof; a confidential agent,</em> or <em>superintendent; a commissioner; a commissary; a trustee; a depositary;</em>]</span> <em>a guardian:</em> <span class="auth">(TA:)</span> <em>trusty; trustworthy; trustful; confidential; faithful:</em> <span class="auth">(Mgh, Mṣb:*)</span> pl. <span class="ar">أُمَنَآءُ</span>, and, accord. to some, <span class="arrow"><span class="ar">أَمَنَةٌ↓</span></span>, as in a trad. in which it is said, <span class="ar long">أَصْحَابِى أَمَنَةٌ لِأُمَّتِى</span>, meaning <em>My companions are guardians to my people:</em> or, accord. to others, this is pl. of<span class="arrow"><span class="ar">آمِنٌ↓</span></span> <span class="add">[app. in a sense mentioned below in this paragraph, so that the meaning in this trad. is <em>my companions are persons who accord trust,</em> or <em>confidence, to my people</em>]</span>. <span class="auth">(TA.)</span> Hence, <quote></quote></p><div class="star">* <span class="ar long">أَلَمْ تَعْلَمِى يَا أَسْمَ وَيْحَكِ أَنَّنِى</span> *</div> <div class="star">* <span class="ar long">حَلَفْتُ يَمِينًا لَا أَخُونُ أَمِينِى</span> *</div>  <span class="add">[<em>Knowest thou not, O Asmà</em> (<span class="ar">أَسْمَآء</span>, curtailed for the sake of the metre), <em>mercy on thee!</em> or <em>woe to thee! that I have sworn an oath that I will not act treacherously to him in whom I trust?</em>]</span> i. e.<span class="arrow"><span class="ar">مَأْمُونِى↓</span></span>: <span class="auth">(Ṣ:)</span> or the meaning here is, <em>him who trusts,</em> or <em>confides, in me;</em> <span class="auth">(ISk, T;)</span> <span class="add">[i. e.]</span> it is here <em>syn. with</em> <span class="arrow"><span class="ar">آمِنِى↓</span></span>. <span class="auth">(M.)</span> <span class="add">[Hence also,]</span> <span class="ar long">الأَمِينُ فِى القِمَارِ</span>, <span class="auth">(Ḳ voce <span class="ar">مُجُمِدٌ</span>, &amp;c.,)</span> or <span class="ar">أَمِينُ</span>, <span class="ar">القِمَارِ</span>, <span class="add">[<em>The person who is intrusted, as deputy, with the disposal of the arrows in the game called</em> <span class="ar">المَيْسِر</span>; or]</span> <em>he who shuffles the arrows;</em> <span class="ar long">الَّذِى يَضْرِبُ بِالقِدَاحِ</span>. <span class="auth">(EM p. 105.)</span> <span class="add">[Hence also,]</span> <span class="ar long">الرُّوحُ الأَمِينُ</span> <span class="add">[<em>The Trusted,</em> or <em>Trusty, Spirit</em>]</span>; <span class="auth">(Ḳur xxvi. 193;)</span> applied to Gabriel, because he is intrusted with the revelation of God. <span class="auth">(Bḍ.)</span> <span class="arrow"><span class="ar">أُمَّانٌ↓</span></span>, mentioned above, and occurring in a verse of El-Aạshà, applied to a merchant, is said by some to mean <em>Possessed of religion and excellence.</em> <span class="auth">(M.)</span> <span class="arrow"><span class="ar">مُؤْتَمَنٌ↓</span></span> is applied, in a trad., to the <span class="ar">مُؤَذِّن</span>, as meaning that men trust, or confide, in him with respect to the times in which he calls to prayer, and know by his call what they are commanded to do as to praying and fasting and breaking fast. <span class="auth">(Mgh.)</span> <span class="arrow"><span class="ar long">هُوَ مَأْمُونُ↓ المُعَامَلَةِ</span></span> means <em>He is</em> <span class="add">[<em>trusty,</em> or <em>trustworthy, in dealing with others;</em> or]</span> <em>free from exorbitance and deceit</em> or <em>artifice</em> or <em>craft to be feared.</em> <span class="auth">(Mṣb.)</span><p></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamiynN_A2">
					<p><em>An aid,</em> or <em>assistant;</em> syn. <span class="ar">عَوْنٌ</span> <span class="add">[here app. meaning, as it often does, <em>an armed attendant,</em> or <em>a guard</em>]</span>; because one trusts in his strength, and is without fear of his being weak. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamiynN_A3">
					<p>† The <em>strong;</em> syn. <span class="ar">قَوِىٌّ</span>. <span class="auth">(Ḳ, TA: <span class="add">[in the latter of which is given the same reason for this signification as is given in the M f<a href="#Ewn">or that of <span class="ar">عون</span></a>; for which <span class="ar">قوى</span> may be a mistranscription; but <a href="#OamuwnN">see <span class="ar">أَمُونٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OamiynN_A4">
					<p>One <em>who trusts,</em> or <em>confides, in</em> another; <span class="auth">(ISk, T, Ḳ;)</span> <span class="add">[as also<span class="arrow"><span class="ar">آمِنٌ↓</span></span>, of which see an ex. voce <span class="ar">حَذِرٌ</span>;]</span> so accord. to ISk in the verse cited above in this paragraph: <span class="auth">(T:)</span> thus it bears two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OamiynN_A5">
					<p><a href="#AminN">See also <span class="ar">آمِنٌ</span></a>, in five places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمِينٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamiynN_B1">
					<p><a href="#Amiyna">And see <span class="ar">آمِينَ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamaAnapN">
				<span class="pb" id="Page_0102"></span>
				<h3 class="entry"><span class="ar">أَمَانَةٌ</span></h3>
				<div class="sense" id="OamaAnapN_A1">
					<p><span class="ar">أَمَانَةٌ</span>: <a href="#OamonN">see <span class="ar">أَمْنٌ</span></a>, first sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamaAnapN_A2">
					<p><em>Trustiness; trustworthiness; trustfulness; faithfulness; fidelity;</em> <span class="auth">(M, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَمَنَةٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span> <span class="ar long">أَمَانَةُ ٱللّٰهِ</span> <span class="add">[for <span class="ar long">أَمَانَةُ ٱللّٰهِ قَسَمِى</span> or <span class="ar long">مَا أُقْسِمُ</span> <em>The faithfulness of God is my oath</em> or <em>that by which I swear</em>]</span> is composed of an inf. n. prefixed to the agent, and the former is in the nom. case as an inchoative; the phrase being like <span class="ar long">لَعَمْرُ ٱللّٰهِ</span>, as meaning an oath; and the enunciative being suppressed, and meant to be understood: accord. to some, you say, <span class="ar long">أَمَانَةَ ٱللّٰهِ</span> <span class="add">[app. for <span class="ar long">نَشَدْتُكَ أَمَانَةَ ٱللّٰهِ</span> <em>I adjure thee,</em> or <em>conjure thee, by the faithfulness of God,</em> or <em>the like</em>]</span>, making it to be governed in the accus. case by the verb which is to be understood: and some correctly say, <span class="ar long">وَأَمَانَةِ ٱللّٰهِ</span> <span class="add">[<em>By the faithfulness of God</em>]</span>, with the <span class="ar">و</span> which denotes an oath: <span class="auth">(Mgh:)</span> or this last is an oath accord. to Aboo-Ḥaneefeh; but Esh-Sháfiʼee does not reckon it as such: and it is forbidden in a trad. to swear by <span class="ar">الأَمَانَة</span>; app. because it is not one of the names of God. <span class="auth">(TA.)</span> <span class="add">[Or these phrases may have been used, in the manner of an oath, agreeably with explanations here following.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمَانَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamaAnapN_B1">
					<p><em>A thing committed to the trust and care of a person; a trust; a deposite;</em> <span class="auth">(Mgh, Mṣb;)</span> and <em>the like:</em> <span class="auth">(Mṣb:)</span> <em>property committed to trust and care:</em> <span class="auth">(TA:)</span> pl. <span class="ar">أَمَانَاتٌ</span>. <span class="auth">(Mgh, Mṣb.)</span> It is said in the Ḳur <span class="add">[viii. 27]</span>, <span class="ar long">وَتَخُونُوا أَمَانَاتِكُمْ</span> <span class="add">[<em>Nor be ye unfaithful to the trusts committed to you</em>]</span>. <span class="auth">(Mgh.)</span> And in the same <span class="add">[xxxiii. 72]</span>, <span class="ar long">إِنَّا عَرَضْنَاالأَمَانَةَ عَلَى السّموَاتِ وَالْأَرْضِوَالْجِبَالِ فَأَبَيْنَ أَنْ يَحْمِلْنَهَا وَأَشْفَقْنَ مِنْهَا وَحَمَلَهَا الْإِنْسَانُ</span> <span class="add">[<em>Verily we proposed,</em> or <em>offered, the trust</em> which we have committed to man <em>to the heavens and the earth and the mountains, and</em> <span class="auth">(accord. to explanations of Bḍ and others)</span> <em>they refused to take it upon themselves,</em> or <em>to accept it, and they feared it, but man took it upon himself,</em> or <em>accepted it:</em> or, <span class="auth">(accord. to another explanation of Bḍ, also given in the T, and in the Ḳ in art. <span class="ar">حمل</span>, &amp;c.,)</span> <em>they refused to be unfaithful to it, and they feared it, but man was unfaithful to it:</em> but in explaining what this trust was, authors greatly differ: accord. to some,]</span> <span class="ar">الامانة</span> here means <em>obedience;</em> so called because the rendering thereof is incumbent: or <em>the obedience which includes that which is natural and that which depends upon the will:</em> <span class="add">[for]</span> it is said that when God created these <span class="add">[celestial and terrestrial]</span> bodies, He created in them understanding: or it may here <span class="add">[and in some other instances]</span> mean <em>reason,</em> or <em>intellect:</em> <span class="add">[and <em>the faculty of volition:</em> and app. <em>conscience:</em> these being trusts committed to us by God, to be faithfully employed: <span class="auth">(see an ex. voce <span class="ar">جَذْرٌ</span>:)</span>]</span> and <em>the imposition of a task</em> or <em>duty</em> or <em>of tasks</em> or <em>duties</em> <span class="add">[app. <em>combined with reason</em> or <em>intellect, which is necessary for the performance thereof</em>]</span>: <span class="auth">(Bḍ:)</span> or it here means <em>prayers and other duties for the performance of which there is recompense and for the neglect of which there is punishment:</em> <span class="auth">(Jel:)</span> or, accord. to I’Ab and Saʼeed Ibn-Jubeyr, <span class="auth">(T,)</span> <em>the obligatory statutes which God has imposed upon his servants:</em> <span class="auth">(T, Ḳ:*)</span> or, <span class="auth">(T, Ḳ,)</span> accord. to Ibn-ʼOmar, <span class="add">[<em>the choice between</em>]</span> <em>obedience and disobedience</em> was offered to Adam, and he was informed of the recompense of obedience and the punishment of disobedience: but, in my opinion, he says, <span class="auth">(T,)</span> it here means <em>the intention which one holds in the heart,</em> <span class="auth">(T, Ḳ,)</span> <em>with respect to the belief which he professes with the tongue, and with respect to all the obligatory statutes which he externally fulfils;</em> <span class="auth">(Ḳ;)</span> because God has confided to him power over it, and not manifested it to any <span class="add">[other]</span> of his creatures, so that he who conceives in his mind, with respect to the acknowledgment of the unity of God, <span class="auth">(T, Ḳ,)</span> and with respect to belief <span class="add">[in general]</span>, <span class="auth">(T,)</span> the like of that which he professes, he fulfils the <span class="ar">امانة</span> <span class="add">[or trust]</span>, <span class="auth">(T, Ḳ,)</span> and he who conceives in his mind disbelief while he professes belief with the tongue is unfaithful thereto, and every one who is unfaithful to that which is confided to him is <span class="add">[termed]</span> <span class="ar">حَامِلٌ</span>, <span class="auth">(T,)</span> or <span class="ar long">حَامِلُ الأَمَانَةِ</span>, and <span class="ar">مُحْتَمِلُهَا</span>: <span class="auth">(Bḍ:)</span> and by <span class="ar">الإِنْسَانُ</span> is here meant the doubting disbeliever. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أَمَانَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OamaAnapN_B2">
					<p>Also, <span class="add">[as being a trust committed to him by God, A man's]</span> <em>family,</em> or <em>household;</em> syn. <span class="ar">أَهْلٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumBaAnN.1">
				<h3 class="entry"><span class="ar">أُمَّانٌ</span></h3>
				<div class="sense" id="OumBaAnN.1_A1">
					<p><span class="ar">أُمَّانٌ</span>: <a href="#OamynN">see <span class="ar">أَمينٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أُمَّانٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OumBaAnN.1_B1">
					<p>Also One <em>who does not write;</em> as though he were (<span class="ar">كَأَنَّهُ</span> <span class="add">[in the CK <span class="ar">لاَنَّهُ</span> because he is]</span>) an <span class="ar">أُمِّى</span>. <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="index.php?data=01_A/128_Am">But this belongs to art. <span class="ar">ام</span></a>; being of the measure <span class="ar">فُعْلَانٌ</span>, like <span class="ar">عُرْيَانٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">أُمَّانٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OumBaAnN.1_B2">
					<p>And <em>A sower,</em> or <em>cultivator of land;</em> <span class="add">[perhaps meaning <em>a clown,</em> or <em>boor;</em>]</span> syn. <span class="ar">زَرَّاعٌ</span>: <span class="auth">(CK:)</span> or <em>sowers,</em> or <em>cultivators of land;</em> syn. <span class="ar">زُرَّاعٌ</span>: <span class="auth">(Ḳ, TA:)</span> in one copy of the Ḳ <span class="ar">زِرَاع</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MminN">
				<h3 class="entry"><span class="ar">آمِنٌ</span></h3>
				<div class="sense" id="MminN_A1">
					<p><span class="ar">آمِنٌ</span> <em>Secure, safe,</em> or <em>free from fear;</em> as also<span class="arrow"><span class="ar">أَمِينٌ↓</span></span> <span class="auth">(Lḥ, T,* Ṣ,* M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَمِنٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span> Hence, in the Ḳur <span class="add">[xcv. 3]</span>, <span class="arrow"><span class="ar long">وَهذَا الْبَلَدِ الْأَمِينِ↓</span></span> <span class="add">[<em>And this secure town</em>]</span>; <span class="auth">(Akh, Lḥ, T, Ṣ, M;)</span> meaning Mekkeh. <span class="auth">(M.)</span> <span class="ar long">بَلَدٌ آمِنٌ</span> and<span class="arrow"><span class="ar">أَمِينٌ↓</span></span> means <em>A town,</em> or <em>country,</em> or <em>district, of which the inhabitants are in a state of security,</em> or <em>confidence, therein.</em> <span class="auth">(Mṣb.)</span> It is also said in the Ḳur <span class="add">[xliv. 51]</span>, <span class="arrow"><span class="ar long">إِنَّ الْمُتَّقِينَ فِى مَقَامٍ أَمِينٍ↓</span></span>, meaning <span class="add">[<em>Verily the pious</em> shall be <em>in an abode</em>]</span> <em>wherein they shall be secure from the accidents,</em> or <em>casualties, of fortune.</em> <span class="auth">(M.)</span> <span class="add">[And hence,]</span><span class="arrow"><span class="ar">الأَمِينُ↓</span></span> is one of the epithets applied to God, <span class="auth">(Mgh, Ḳ,)</span> on the authority of El-Ḥasan; <span class="auth">(Mgh;)</span> an assertion requiring consideration: it may mean <em>He who is secure with respect to the accidents,</em> or <em>casualties, of fortune:</em> but <a href="#AlmuWominu">see <span class="ar">المُؤْمِنُ</span></a>, which is <span class="add">[well known as]</span> an epithet applied to God. <span class="auth">(TA.)</span> <span class="ar long">آمِنُ المَالِ</span> means <em>What is secure from being slaughtered, of the camels, because of its being highly prized;</em> by <span class="ar">المال</span> being meant <span class="ar">الإِبِل</span>: or, as some say, ‡ <em>what is highly esteemed, of property</em> of any kind; as though, if it had intellect, it would feel secure from being exchanged. <span class="auth">(M.)</span> You say, <span class="ar long">أَعْطَيْتُهُ مِنْ آمِنِ مَالِى</span>, <span class="auth">(Ḳ, TA, <span class="add">[in the CK <span class="ar">آمَنِ</span>,]</span>)</span> meaning ‡ <em>I gave him of the choice,</em> or <em>best, of my property; of what was highly esteemed thereof;</em> <span class="auth">(Ḳ, TA;)</span> and<span class="arrow"><span class="ar long">مِنْ أَمْنِ↓ مَالِى</span></span> which Az explains as meaning <em>of the choice,</em> or <em>best, of my property.</em> <span class="auth">(TA: <span class="add">[in which is given a verse cited by ISk showing that <span class="ar">أَمْن</span>, thus used, is not a mistranscription for <span class="ar">آمِن</span>.]</span>)</span> And <span class="ar long">آمِنُ الحِلْمِ</span> means <em>Steadfast in forbearance</em> or <em>clemency; of whose becoming disordered in temper, and free from self-restraint, there is no fear.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">آمِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MminN_A2">
					<p><a href="#OamiynN">See also <span class="ar">أَمِينٌ</span></a>, in three places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">آمِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MminN_A3">
					<p><a href="#OaminN">and see <span class="ar">اَمِنٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">آمِنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MminN_B1">
					<p><a href="#OamiynN">See also <span class="ar">أَمِينٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mmiyna">
				<h3 class="entry"><span class="ar">آمِينَ</span></h3>
				<div class="sense" id="Mmiyna_A1">
					<p><span class="ar">آمِينَ</span> <span class="add">[in the CK, erroneously, <span class="ar">آمِينُ</span>]</span> and<span class="arrow"><span class="ar">أَمِينَ↓</span></span>; <span class="auth">(Th, T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> both chaste and well known, <span class="auth">(TA,)</span> the latter of the dial. of El-Ḥijáz, <span class="auth">(Mṣb, TA,)</span> as some say, <span class="auth">(TA,)</span> <span class="add">[and this, though the less common, is the original form, for]</span> the medd in the former is only to give fulness of sound to the fet-ḥah of the <span class="ar">أ</span>, <span class="auth">(Th, M, Mṣb, TA,)</span> as is shown by the fact that there is no word in the Arabic language of the measure <span class="ar">فَاعِيلٌ</span>; <span class="auth">(Mṣb, TA;)</span> and some pronounce the former <span class="ar">آمِّينَ</span>, <span class="auth">(Ḳ,)</span> which is said by some of the learned to be a dial. var., <span class="auth">(Mṣb,)</span> but this is a mistake, <span class="auth">(Ṣ, Mṣb,)</span> accord. to authorities of good repute, and is one of old date, originating from an assertion of Aḥmad Ibn-Yaḥyà, <span class="add">[i. e. Th,]</span> that <span class="ar">آمِينَ</span> is like <span class="ar">عَاصِينَ</span>, by which he was falsely supposed to mean its having the form of a pl., <span class="add">[and being consequently <span class="ar">آمِّينَ</span>,]</span> <span class="auth">(Mṣb, <span class="add">[and part of this is said in the M,]</span>)</span> whereas he thereby only meant that the <span class="ar">م</span> is without teshdeed, like the <span class="ar">ص</span> in <span class="ar">عَاصِينَ</span>; <span class="auth">(M;)</span> beside that the sense of <span class="ar">قَاصِدِينَ</span> <span class="add">[which <a href="#AmBiyna">is that of <span class="ar">آمِّينَ</span></a>, from <span class="ar">أَمَّ</span>,]</span> would be inconsistent after the last phrase of the first chapter of the Ḳur <span class="add">[where <span class="ar">آمينَ</span> is usually added]</span>; <span class="auth">(Mṣb;)</span> and sometimes it is pronounced with imáleh, <span class="add">[i. e. “émeena,”]</span> as is said by El-Wáhidee in the Beseet; <span class="auth">(Ḳ;)</span> but this is unknown in works on lexicology, and is said to be a mispronunciation of some of the Arabs of the desert of El-Yemen: <span class="auth">(MF:)</span> each form is indecl., <span class="auth">(Ṣ,)</span> with fet-ḥ for its termination, like <span class="ar">أَيْنَ</span> and <span class="ar">كَيْفَ</span>, to prevent the occurrence of two quiescent letters together: <span class="auth">(T, Ṣ, TA:)</span> it is a word used immediately after a prayer, or supplication: <span class="auth">(Ṣ,* M:)</span> <span class="add">[it is best expressed, when occurring in a translation, by the familiar Hebrew equivalent <em>Amen:</em>]</span> El-Fárisee says that it is a compound of a verb and a noun; <span class="auth">(M;)</span> meaning <em>answer Thou me;</em> <span class="add">[i. e. <em>answer Thou my prayer;</em>]</span> <span class="auth">(M, Mgh;*)</span> or <em>O God, answer Thou:</em> <span class="auth">(Zj, T, Mṣb, Ḳ:)</span> or <em>so be it:</em> <span class="auth">(AḤát, Ṣ, Mṣb, Ḳ:)</span> or <em>so do Thou,</em> <span class="auth">(Ḳ, TA,)</span> <em>O Lord:</em> <span class="auth">(TA:)</span> it is strangely asserted by some of the learned, that, after the Fátihah, <span class="add">[or Opening Chapter of the Ḳur-án,]</span> it is a prayer which implies all that is prayed for in detail in the Fátihah: so in the Towsheeh: <span class="auth">(MF:)</span> or it is <em>one of the names of God:</em> <span class="auth">(M, Mṣb, Ḳ:)</span> so says El-Ḥasan <span class="auth">(M, Mṣb)</span> El-Basree: <span class="auth">(Mṣb:)</span> but the assertion that it is for <span class="ar long">يَا اَللّٰهُ</span> <span class="add">[<em>O God</em>]</span>, and that <span class="ar">اسْتَجِبٌ</span> <span class="add">[<em>answer Thou</em>]</span> is meant to be understood, is not correct accord. to the lexicologists; for, were it so, it would be with refa, not nasb. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiymaAnN">
				<h3 class="entry"><span class="ar">إِيمَانٌ</span></h3>
				<div class="sense" id="IiymaAnN_A1">
					<p><span class="ar">إِيمَانٌ</span> <span class="add">[<a href="#Amn_4">inf. n. of 4, q. v.</a>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">إِيمَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiymaAnN_A2">
					<p><span class="add">[Used as a simple subst., <em>Belief;</em> particularly <em>in God, and in his word and apostles, &amp;c.: faith: trust,</em> or <em>confidence:</em>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">إِيمَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiymaAnN_A3">
					<p>Sometimes it means <em>Prayer;</em> syn. <span class="ar">صَلَاةٌ</span>: as in the Ḳur <span class="add">[ii. 138]</span>, where it is said, <span class="ar long">وَمَا كَانَ ٱللّٰهُ لِيُضِيعَ إِيَمانَكُمْ</span>, <span class="auth">(Bḍ, Jel, TA,)</span> i. e. <span class="add">[<em>God will not make to be lost</em>]</span> <em>your prayer</em> towards Jerusalem, <span class="auth">(Bḍ,* Jel,)</span> as some explain it. <span class="auth">(Bḍ.)</span></p>
				</div>
				<span class="pb" id="Page_0103"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">إِيمَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiymaAnN_A4">
					<p>Sometimes, also, it is used as meaning <em>The law brought by the Prophet.</em> <span class="auth">(Er-Rághib, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomanN">
				<h3 class="entry"><span class="ar">مَأْمَنٌ</span></h3>
				<div class="sense" id="maOomanN_A1">
					<p><span class="ar">مَأْمَنٌ</span> <em>A place of security</em> or <em>safety</em> or <em>freedom from fear;</em> or <em>where one feels secure.</em> <span class="auth">(M, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWomanN">
				<h3 class="entry"><span class="ar">مُؤْمَنٌ</span></h3>
				<div class="sense" id="muWomanN_A1">
					<p><span class="ar">مُؤْمَنٌ</span> pass. part. n. of <span class="ar">آمَنَهُ</span>. <span class="auth">(T.)</span> It is said in the Ḳur <span class="add">[iv. 96]</span>, accord. to one reading, <span class="auth">(T, M,)</span> that of Aboo-Jaạfar El-Medenee, <span class="auth">(T,)</span> <span class="ar long">لَسْتَ مُؤْمَنًا</span> <span class="add">[<em>Thou art not granted security,</em> or <em>safety,</em>, &amp;c.; or]</span> <em>we will not grant thee security,</em>, &amp;c. <span class="auth">(T, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWominN">
				<h3 class="entry"><span class="ar">مُؤْمِنٌ</span></h3>
				<div class="sense" id="muWominN_A1">
					<p><span class="ar">مُؤْمِنٌ</span> <span class="add">[act. part. n. of 4; <em>Rendering secure,</em>, &amp;c.]</span>. <span class="ar">المُؤْمِنُ</span> is an epithet applied to God; meaning <em>He who rendereth mankind secure from his wronging them:</em> <span class="auth">(T, Ṣ:)</span> or <em>He who rendereth his servants secure from his punishment:</em> <span class="auth">(M, IAth:)</span> <em>i. q.</em> <span class="ar">المُهَيْمِنُ</span>, <span class="auth">(M,)</span> which is originally <span class="ar">المُؤَأْمِنُ</span>; <span class="add">[for the form <span class="ar">مُفْعِلٌ</span> is originally <span class="ar">مُؤَفْعِلٌ</span>;]</span> the second <span class="ar">ء</span> being softened, and changed into <span class="ar">ى</span>, and the first being changed into <span class="ar">ه</span>: <span class="auth">(Ṣ:)</span> or <em>the Believer of his servants</em> <span class="auth">(Th, M, TA)</span> <em>the Muslims, on the day of resurrection, when the nations shall be interrogated respecting the messages of their apostles:</em> <span class="auth">(TA:)</span> or <em>He who will faithfully perform to his servants what He hath promised them:</em> <span class="auth">(T, TA:)</span> or <em>He who hath declared in his word the truth of his unity.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">مُؤْمِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWominN_A2">
					<p><span class="add">[Also <em>Believing,</em> or <em>a believer;</em> particularly <em>in God, and in his word and apostles, &amp;c.: faithful: trusting,</em> or <em>confiding:</em>, &amp;c.: <a href="#Amn_4">see 4</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomuwnN">
				<h3 class="entry"><span class="ar">مَأْمُونٌ</span></h3>
				<div class="sense" id="maOomuwnN_A1">
					<p><span class="ar">مَأْمُونٌ</span>: <a href="#OamiynN">see <span class="ar">أَمِينٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امن</span> - Entry: <span class="ar">مَأْمُونٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOomuwnN_A2">
					<p><span class="ar">مَأْمُونَةٌ</span> A woman <em>whose like is sought after and eagerly retained because of her valuable qualities.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomuwniyBapN">
				<h3 class="entry"><span class="ar">مَأْمُونِيَّةٌ</span></h3>
				<div class="sense" id="maOomuwniyBapN_A1">
					<p><span class="ar">مَأْمُونِيَّةٌ</span> <em>A certain kind of food; so called in relation to El-Ma-moon.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWotamanN">
				<h3 class="entry"><span class="ar">مُؤْتَمَنٌ</span></h3>
				<div class="sense" id="muWotamanN_A1">
					<p><span class="ar">مُؤْتَمَنٌ</span>: <a href="#OamiynN">see <span class="ar">أَمِينٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0100.pdf" target="pdf">
							<span>Lanes Lexicon Page 100</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0101.pdf" target="pdf">
							<span>Lanes Lexicon Page 101</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0102.pdf" target="pdf">
							<span>Lanes Lexicon Page 102</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0103.pdf" target="pdf">
							<span>Lanes Lexicon Page 103</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
