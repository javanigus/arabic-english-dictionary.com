<article class="root" id="Root_Afq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/102_Afx">افخ</a></span>
				<span class="ar">افق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/104_Afk">افك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Afq_1">
				<h3 class="entry">1. ⇒ <span class="ar">أفق</span></h3>
				<div class="sense" id="Afq_1_A1">
					<p><span class="ar">أَفَقَ</span>, <span class="auth">(JK, Ṣ, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِقُ</span>}</span></add>, <span class="auth">(JK, Ḳ,)</span> inf. n. <span class="ar">أَفْقٌ</span>, <span class="auth">(TḲ,)</span> <em>He went his own way, at random,</em> or <em>heedlessly,</em> (<span class="ar long">رَكِبَ رَأْسَهُ</span>,) <em>and went away in the</em> <span class="ar">آفَاق</span> <span class="add">[or <em>regions,</em>, &amp;c., <em>of the land</em>]</span>: <span class="auth">(Lth, JK, Ḳ:)</span> or <em>he went away in,</em> or <em>into, the land,</em> or <em>country:</em> <span class="auth">(Ṣ:)</span> and <em>he took his way into the</em> <span class="ar">آفاق</span> <span class="add">[or <em>regions,</em>, &amp;c.,]</span> <em>of the land.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Afq_1_A2">
					<p><span class="add">[Hence, app.,]</span> <span class="ar">أَفَقَ</span>, aor. as above; thus, says IB, accord. to Ḳz, and thus it is given on the authority of Kr; <span class="auth">(TA;)</span> <span class="add">[<a href="#AfiqN">see <span class="ar">آفِقٌ</span></a>;]</span> or <span class="ar">أَفِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْفَقُ</span>}</span></add>, <span class="auth">(Ṣ, O, Ḳ,)</span> inf. n. <span class="ar">أَفَقٌ</span>; <span class="auth">(Ṣ;)</span> <em>He attained the utmost degree,</em> <span class="add">[as though he reached the <span class="ar">أُفُق</span> <span class="auth">(or horizon, or furthest point of view,)</span>]</span> <em>in generosity;</em> <span class="auth">(Ṣ, O, Ḳ;)</span> or <em>in knowledge,</em> or <em>science;</em> or <em>in chasteness of speech,</em> or <em>eloquence, and in the combination of excellent qualities.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Afq_1_A3">
					<p>Also, <span class="ar">أَفَقَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِقُ</span>}</span></add>, <span class="auth">(Kr, Ibn-ʼAbbád, JK, Ḳ,)</span> inf. n. <span class="ar">أَفْقٌ</span>, <span class="auth">(JK, TA,)</span> <em>He overcame,</em> or <em>surpassed.</em> <span class="auth">(Kr, Ibn-ʼAbbád, JK, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Afq_1_A4">
					<p>And, inf. n, <span class="ar">أُفُوقٌ</span>, <em>He was goodly,</em> or <em>beautiful; he possessed the quality of exciting admiration and approval by his beauty and the pleasingness of his aspect;</em> said of a camel, and of a horse. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Afq_1_A5">
					<p><span class="ar long">أَفَقَ عَلَيْهِ</span> <span class="auth">(JK, TA)</span> <em>He</em> <span class="auth">(a man)</span> <em>excelled him;</em> namely, another man: <span class="auth">(JK:)</span> or <em>he preceded him in excellence;</em> or <em>outwent him therein;</em> as also <span class="ar">أَفَقَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِقُ</span>}</span></add>. <span class="auth">(TA.)</span> <span class="add">[It is like <span class="ar">فَاقَهُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Afq_1_A6">
					<p><span class="ar long">أَفَقَ فِى العَطَآءِ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِقُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَفْقٌ</span>, <span class="auth">(TA,)</span> <em>He gave to some more than to others.</em> <span class="auth">(Ṣ, Ḳ.)</span> So in the saying of El-Aạshà,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَلَا المَلِكَ النُّعْمَانُ يَوْمَ لَقِيتُهُ</span> *</div> 
						<div class="star">* <span class="ar long">بِغِبْطَتِهِ يُعْطِى القُطُوطَ وَيَأْفِقُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Nor the King En-Noamán, on the day that I met him, in his goodly,</em> or <em>happy, condition, giving gifts,</em> or <em>stipends,</em> or <em>written obligations conferring gifts, and giving to some more than to others</em>]</span>: <span class="auth">(Ṣ:)</span> or the meaning is, <em>writing</em> <span class="add">[<em>writs of</em>]</span> <em>gifts, and sealing</em> them: or, as some say, <em>taking his way into the</em> <span class="ar">آفاق</span> <span class="add">[or <em>regions,</em>, &amp;c.,]</span> <em>of the land.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">افق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Afq_1_B1">
					<p><span class="ar">أَفَقَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِقُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَفْقٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He tanned it</em> <span class="auth">(namely a hide)</span> <em>until it became what is termed</em> <span class="ar">أَفِيق</span>. <span class="auth">(Ṣ, Mṣb,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Afq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأفّق</span></h3>
				<div class="sense" id="Afq_5_A1">
					<p><span class="ar long">تأفّق بِنَا</span> <em>He</em> <span class="auth">(a man, Aṣ, TA)</span> <em>came to us</em> <span class="ar long">مِنْ أُفُقٍ</span> <span class="add">[<em>from a region,</em>, &amp;c., <em>of the land</em>]</span>: <span class="auth">(Aṣ, Ḳ:)</span> or <em>came to us, and alighted at our abode as a guest:</em> and in the Nawádir el-Aaráb, <span class="ar long">تأفّق بِهِ</span> is said to signify <em>he reached him,</em> or <em>overtook him;</em> as also <span class="ar long">تلّفق به</span> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OufoqN">
				<h3 class="entry"><span class="ar">أُفْقٌ</span></h3>
				<div class="sense" id="OufoqN_A1">
					<p><span class="ar">أُفْقٌ</span>: <a href="#OufuqN">see <span class="ar">أُفُقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafaqN">
				<h3 class="entry"><span class="ar">أَفَقٌ</span></h3>
				<div class="sense" id="OafaqN_A1">
					<p><span class="ar">أَفَقٌ</span> The <em>main and middle part</em> (<span class="ar">سَنَن</span>) of a road; <span class="auth">(Ḳ;)</span> the <em>face,</em> or <em>surface,</em> thereof: <span class="auth">(IAạr, Ḳ:)</span> pl. <span class="ar">آفَاقٌ</span>. <span class="auth">(Ḳ.)</span> Hence the saying, <span class="ar long">قَعَدَ فُلَانٌ عَلَى أَفَقِ الطَّرِيقِ</span> <span class="add">[<em>Such a one sat upon the main and middle part,</em> or <em>face,</em> or <em>surface, of the road</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أَفَقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OafaqN_A2">
					<p>The <em>flanks,</em> or <em>ilia:</em> or, as some say, <em>skins;</em> or <em>skin;</em> as in the saying, <span class="ar long">شَرِبْتُ حَتَّى مَلَأْتُ أَفَقِى</span> <em>I drank until I filled my skin:</em> <span class="auth">(JK:)</span> pl. <span class="add">[or rather coll. gen. n.]</span> of <span class="arrow"><span class="ar">أَفَقَةٌ↓</span></span>; <span class="auth">(IAạr;)</span> which signifies the <em>flank;</em> <span class="auth">(IAạr, Ḳ;)</span> as does also <span class="arrow"><span class="ar">آفِقَةٌ↓</span></span>. <span class="auth">(Th, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أَفَقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OafaqN_A3">
					<p>Also pl., <span class="auth">(Ṣ, Ḳ,)</span> or <span class="add">[rather]</span> quasi-pl. n., <span class="auth">(M, Ḳ,)</span> of <span class="ar">أَفِيقٌ</span>, q. v. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OafiqN">
				<h3 class="entry"><span class="ar">أَفِقٌ</span></h3>
				<div class="sense" id="OafiqN_A1">
					<p><span class="ar">أَفِقٌ</span>: <a href="#OafiyqN">see <span class="ar">أَفِيقٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OufuqN">
				<h3 class="entry"><span class="ar">أُفُقٌ</span></h3>
				<div class="sense" id="OufuqN_A1">
					<p><span class="ar">أُفُقٌ</span> <span class="auth">(JK, Ṣ, Mgh, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">أُفْقٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> <em>A side;</em> meaning <em>a lateral,</em> or <em>an outward</em> or <em>adjacent, part</em> or <em>portion;</em> or <em>a part, region, quarter,</em> or <em>tract, considered with respect to its collocation</em> or <em>juxtaposition</em> or <em>direction,</em> or <em>considered as belonging to a whole;</em> or <em>a remote side;</em> syn. <span class="ar">نَاحِيَةٌ</span>; <span class="auth">(JK, Ṣ, Mgh, Mṣb, Ḳ;)</span> and <em>a border,</em> or <em>an extremity;</em> <span class="auth">(JK;)</span> of a land, or of the earth; and of the sky, or heavens: <span class="auth">(JK, Mgh, Mṣb:)</span> <span class="add">[or the <em>horizon,</em> or <em>part next to the horizon, of the sky</em> and <em>of the earth;</em>]</span> or <em>what appears of the sides</em> (<span class="ar">النَّوَاحِى</span>) <em>of the celestial sphere,</em> <span class="auth">(Ḳ, TA,)</span> and <em>of the borders,</em> or <em>extremities, of the earth:</em> <span class="auth">(TA:)</span> or the <em>place whence blows the south wind,</em> and <em>the north wind,</em> and <em>the west wind,</em> and <em>the east wind:</em> <span class="auth">(Ḳ,* TA:)</span> pl. <span class="ar">آفَاقٌ</span>: <span class="auth">(JK, Ṣ, Mgh, Mṣb, Ḳ:)</span> and the sing. also is used as a pl.; <span class="pb" id="Page_0069"></span>like <span class="ar">فُلْكٌ</span>, as is said in the Nh: <span class="auth">(MF:)</span> thus in the verse of El-ʼAbbás, in praise of the Prophet:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَنْتَ لَمَّ وُلِدْتَ أَشْرَقَتِ الأَرْ</span> *</div> 
						<div class="star">* <span class="ar long">ضُوَضَآءَ تْ بِنُورِكَ الأُفُقُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When thou wast born, the earth became bright, and the tracts of the horizon,</em> or <em>the regions, shone with thy light</em>]</span>: or, as some say, <span class="ar">الافق</span> is made fem. by him as meaning <span class="ar">النَّاحِيَةُ</span>. <span class="auth">(TA.)</span> The phrase <span class="ar long">حِينَ يَغِيبُ الأُفُقُ</span> means <em>When the redness,</em> or <em>whiteness, in the</em> <span class="ar">أُفُق</span> <span class="add">[or <em>horizon</em>]</span> <em>disappears.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أُفُقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OufuqN_A2">
					<p>Also, in like manner, The <em>side,</em> or <em>lateral part,</em> of a tent: <span class="auth">(JK:)</span> or the <em>part between the</em> <span class="add">[<em>two</em>]</span> <em>anterior</em> <span class="add">[<em>pieces of wood called the</em>]</span> <span class="ar">زِرَّانِ</span>, <em>in the</em> <span class="add">[<em>fore part called the</em>]</span> <span class="ar">رِوَاق</span>, of a tent: <span class="auth">(Ḳ:)</span> and the <em>sides,</em> or <em>lateral parts,</em> of a tent of the kind belonging to the Arabs of the desert. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أُفُقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OufuqN_B1">
					<p><span class="ar">أُفُقٌ</span> is also said to be <a href="#OafiyqN">a pl. of <span class="ar">أَفِيقٌ</span></a>; but this is disallowed by Lḥ. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أُفُقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OufuqN_C1">
					<p><a href="#AfiqN">See also <span class="ar">آفِقٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafaqapN">
				<h3 class="entry"><span class="ar">أَفَقَةٌ</span></h3>
				<div class="sense" id="OafaqapN_A1">
					<p><span class="ar">أَفَقَةٌ</span>: <a href="#OafaqN">see <span class="ar">أَفَقٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أَفَقَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OafaqapN_B1">
					<p>Also <em>A burying of a skin,</em> or <em>hide, in the earth, so that its hair may be removed, and it may become ready for tanning.</em> <span class="auth">(Lth, Ḳ,* TA.)</span> <span class="add">[<a href="#OafiyqN">See <span class="ar">أَفِيقٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafaqieBN">
				<h3 class="entry"><span class="ar">أَفَقِىٌّ</span></h3>
				<div class="sense" id="OafaqieBN_A1">
					<p><span class="ar">أَفَقِىٌّ</span>, <span class="auth">(ISk, JK, T, Ṣ, Mgh, Mṣb, Ḳ,)</span> contr. to rule, <span class="auth">(T, Mṣb,)</span> and<span class="arrow"><span class="ar">أُفُقِىٌّ↓</span></span>, <span class="auth">(Aṣ, ISk, Ṣ, Mgh, Mṣb, Ḳ,)</span> agreeably with rule, <span class="auth">(Ṣ,)</span> being a rel. n. from <span class="ar">أُفُقٌ</span>, <span class="auth">(Mṣb,)</span> and some <span class="auth">(namely the lawyers, in relation to pilgrimage and the like, MF)</span> say <span class="arrow"><span class="ar">آفَاقِىٌّ↓</span></span>, <span class="auth">(Mgh, MF,)</span> which is incorrect, <span class="auth">(Mgh, Mṣb,)</span> or whether it be correct, after the manner of <span class="ar">أَنْصَارِىٌّ</span> and the like, requires consideration, <span class="auth">(MF,)</span> an epthet applied to a man, <span class="auth">(ISk, Ṣ, Mṣb,)</span> meaning One <em>who is from the</em> <span class="ar">آفَاق</span> <span class="add">[or <em>lateral parts,</em> or <em>regions,</em>]</span> <em>of the land;</em> <span class="auth">(ISk,* Ṣ, Mṣb;*)</span> mentioned by Aboo-Naṣr: <span class="auth">(Ṣ, referring to the first form of the word:)</span> or one <em>who goes about in the</em> <span class="ar">آفَاق</span>: <span class="auth">(JK:)</span> or one <em>who goes through the</em> <span class="ar">آفاق</span> <em>of the land in search of sustenance:</em> <span class="auth">(Ḳ,* TA:)</span> as also<span class="arrow"><span class="ar">أَفَّاقٌ↓</span></span>. <span class="auth">(Ḳ, TA.)</span> <span class="ar long">أُفُقِىُّ مَكَّةَ</span> or <span class="ar long">أَفَقِىُّ مكّة</span> means <em>He who is without the places where the pilgrims coming to Mekkeh enter upon the state of</em> <span class="ar">إِحْرَام</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OufuqieBN">
				<h3 class="entry"><span class="ar">أُفُقِىٌّ</span></h3>
				<div class="sense" id="OufuqieBN_A1">
					<p><span class="ar">أُفُقِىٌّ</span>: <a href="#OafaqieBN">see <span class="ar">أَفَقِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafiyqN">
				<h3 class="entry"><span class="ar">أَفِيقٌ</span></h3>
				<div class="sense" id="OafiyqN_A1">
					<p><span class="ar">أَفِيقٌ</span>: <a href="#AfiqN">see <span class="ar">آفِقٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أَفِيقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OafiyqN_A2">
					<p>Applied also to a bucket (<span class="ar">دَلْو</span>), meaning <em>Excelling other buckets.</em> <span class="auth">(AA, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">افق</span> - Entry: <span class="ar">أَفِيقٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OafiyqN_B1">
					<p>Also, <span class="auth">(Aṣ, Th, JK, Ṣ, Mgh, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">أَفِيقَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> or the latter is a more particular term than the former, like as <span class="ar">جِلْدَةٌ</span> is more so than <span class="ar">جِلْدٌ</span>, <span class="auth">(Mgh,)</span> and<span class="arrow"><span class="ar">أَفِقٌ↓</span></span>, <span class="auth">(Ḳ, <span class="add">[but see what follows,]</span>)</span> The <em>skin,</em> or <em>hide, that is not completely tanned,</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>so that it is unsubstantial, not firm,</em> or <em>strong,</em> or <em>tough:</em> <span class="auth">(Mgh:)</span> when its tanning is complete, and it becomes red, it is termed <span class="ar">أَدِيم</span>: therefore <span class="ar">أَفِيقٌ</span> is of the measure <span class="ar">فَعِيلٌ</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>: <span class="auth">(Mṣb:)</span> or <em>in the second stage of its tanning;</em> for in the first stage it is termed <span class="ar">مَنِيْئَة</span>; then, <span class="ar">افيق</span>; and then, <span class="ar">اديم</span>: <span class="auth">(TA:)</span> or <em>that is tanned, but before it is sewed:</em> <span class="auth">(Aṣ, Ṣ, Ḳ:)</span> or <em>before it is cut,</em> or <em>slit:</em> <span class="auth">(Ḳ:)</span> or <em>when it comes forth from the tan, its tanning being finished,</em> <span class="auth">(JK, TA,)</span> <em>its</em> <span class="add">[<em>original</em>]</span> <em>odour being</em> <span class="add">[<em>still</em>]</span> <em>in it:</em> <span class="auth">(TA:)</span> or <em>after it is tanned:</em> <span class="auth">(Mṣb:)</span> or <em>not tanned:</em> <span class="auth">(Th, TA:)</span> or <em>that is tanned without</em> <span class="ar">قَرَظ</span> <em>or</em> <span class="ar">أَرْطَى</span> <em>or any of the tans of the people of Nejd:</em> <span class="auth">(TA:)</span> ISd says, I think that Th has mentioned <span class="arrow"><span class="ar">أَفِقٌ↓</span></span> as syn. with <span class="ar">أَفِيقٌ</span>, and explained it as signifying the <em>skin,</em> or <em>hide, that is not tanned;</em> but I am not sure of it: <span class="auth">(TA:)</span> the pl. is <span class="ar">أَفَقٌ</span>, <span class="auth">(Lḥ, JK, Ṣ, Mṣb, Ḳ,)</span> like as <span class="ar">أَدَمٌ</span> <a href="#OadiymN">is pl. of <span class="ar">أَدِيمٌ</span></a>, <span class="auth">(Ṣ,)</span> or this is a quasi-pl. n., <span class="auth">(M, Ḳ,)</span> and <span class="ar">أُفُقٌ</span> <span class="auth">(JK, Ḳ)</span> is allowable, <span class="auth">(JK,)</span> or, accord. to Lḥ, it is not allowable, <span class="auth">(TA,)</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">آفِقَةٌ</span>, <span class="auth">(Aṣ, Ṣ, Ḳ,)</span> like as <span class="ar">آدمَةٌ</span> and <span class="ar">أَرْغِفَةٌ</span> are pls. of <span class="ar">أَدِيمٌ</span> and <span class="ar">رَغِيفٌ</span>. <span class="auth">(Aṣ, Ṣ.)</span> <span class="arrow"><span class="ar">أَفِيقَةٌ↓</span></span> signifies also <em>A</em> <span class="ar">سِقَآء</span> <span class="add">[or <em>skin for water or milk</em>, &amp;c.]</span> <em>made of a hide of the kind termed</em> <span class="ar">أَفِيق</span>. <span class="auth">(Mgh.)</span> And <span class="ar">أَفِيقٌ</span> also signifies The <em>skin</em> of a man, and of any beast. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OafiyqapN">
				<h3 class="entry"><span class="ar">أَفِيقَةٌ</span></h3>
				<div class="sense" id="OafiyqapN_A1">
					<p><span class="ar">أَفِيقَةٌ</span>: <a href="#OafiyqN">see <span class="ar">أَفِيقٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OafBaAqN">
				<h3 class="entry"><span class="ar">أَفَّاقٌ</span></h3>
				<div class="sense" id="OafBaAqN_A1">
					<p><span class="ar">أَفَّاقٌ</span>: <a href="#OafaqieBN">see <span class="ar">أَفَقِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MfiqN">
				<h3 class="entry"><span class="ar">آفِقٌ</span> / <span class="ar">آفِقَةٌ</span></h3>
				<div class="sense" id="MfiqN_A1">
					<p><span class="ar">آفِقٌ</span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> of the measure <span class="ar">فَاعِلٌ</span>, <span class="auth">(Ṣ, Ḳz, TA, <span class="add">[in the CK <span class="ar">اَفِقٌ</span>, and in like manner in a copy of the JK,]</span>)</span> from <span class="ar">أَفِقَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or, as IB says, accord. to Ḳz, from <span class="ar">أَفَقَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِقُ</span>}</span></add>, and so accord. to Kr, and shown to be of the measure <span class="ar">فَاعِلٌ</span> by several verses in which it occurs, <span class="auth">(TA,)</span> One <em>who has attained the utmost degree in generosity;</em> <span class="auth">(Ṣ, Ḳ;)</span> or <em>in knowledge,</em> or <em>science;</em> or <em>in chasteness of speech,</em> or <em>eloquence, and in the combination of excellent qualities;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">أَفِيقٌ↓</span></span>: <span class="auth">(Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَفِيقَةٌ</span>}</span></add>. <span class="auth">(IF, Ḳ.)</span> Also applied to a horse, <em>Generous with respect to both parents:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">آفِقَةٌ</span>}</span></add>. <span class="auth">(Ṣ.)</span> And applied to a camel, <em>That excites admiration and approval by his generousness, excellence, high blood,</em> or <em>the like;</em> <span class="auth">(JK;)</span> and so<span class="arrow"><span class="ar">أُفُقٌ↓</span></span>, <span class="auth">(JK, Ṣ, Ḳ,)</span> applied to a horse, <span class="auth">(Ṣ, Ḳ,)</span> and a mare, <span class="auth">(JK, Ṣ, Ḳ,)</span> and a she-camel. <span class="auth">(JK.)</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MfiqapN">
				<h3 class="entry"><span class="ar">آفِقَةٌ</span></h3>
				<div class="sense" id="MfiqapN_A1">
					<p><span class="ar">آفِقَةٌ</span>: <a href="#OafaqN">see <span class="ar">أَفَقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MfaAqieBN">
				<h3 class="entry"><span class="ar">آفَاقِىٌّ</span></h3>
				<div class="sense" id="MfaAqieBN_A1">
					<p><span class="ar">آفَاقِىٌّ</span>: <a href="#OafaqieBN">see <span class="ar">أَفَقِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0068.pdf" target="pdf">
							<span>Lanes Lexicon Page 68</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0069.pdf" target="pdf">
							<span>Lanes Lexicon Page 69</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
