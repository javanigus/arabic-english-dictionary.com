<article class="root" id="Root_Asb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/072_As">اس</a></span>
				<span class="ar">اسب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/074_Ast">است</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asb_4">
				<h3 class="entry">4. ⇒ <span class="ar">آسب</span></h3>
				<div class="sense" id="Asb_4_A1">
					<p><span class="ar long">آسبت الأَرْضُ</span> <em>The land produced</em> <span class="add">[<em>herbage such as is termed</em>]</span> <span class="ar">عُشْب</span>; syn. <span class="ar">أَعْشَبَت</span>. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisobN">
				<h3 class="entry"><span class="ar">إِسْبٌ</span></h3>
				<div class="sense" id="IisobN_A1">
					<p><span class="ar">إِسْبٌ</span> The <em>hair of the pubes:</em> <span class="auth">(M, Ḳ:)</span> or <em>of the pudendum:</em> <span class="auth">(Th, M, Ḳ:)</span> or <em>of the podex:</em> <span class="auth">(Ṣ, Ḳ:)</span> it may be, <span class="auth">(Ṣ,)</span> or is said to be, <span class="auth">(M,)</span> from <span class="ar">وِسْبٌ</span>, <span class="auth">(Ṣ, M,)</span> which signifies “herbage,” or “plants,” <span class="auth">(Ṣ,)</span> or “abundance of herbage:” <span class="auth">(M:)</span> the <span class="ar">و</span> being changed into <span class="ar">ء</span>, as in the case of <span class="ar">إِرْتق</span> and <span class="ar">وِرْثٌ</span>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">أُسُوبٌ</span>, and, accord. to IJ, <span class="ar">آسَابٌ</span>. <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWasBabN">
				<h3 class="entry"><span class="ar">مُؤَسَّبٌ</span></h3>
				<div class="sense" id="muWasBabN_A1">
					<p><span class="ar">مُؤَسَّبٌ</span> A ram <em>having much wool.</em> <span class="auth">(M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
