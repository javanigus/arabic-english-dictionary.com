<article class="root" id="Root_Amr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/131_Amd">امد</a></span>
				<span class="ar">امر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/133_Ams">امس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Amr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمر</span></h3>
				<div class="sense" id="Amr_1_A1">
					<p><span class="ar">أَمَرَهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُرُ</span>}</span></add>, <span class="auth">(M, &amp;c.,)</span> inf. n. <span class="ar">أَمْرٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">إِمَارٌ</span>, <span class="auth">(M, L, Ḳ,)</span> which latter, however, is disapproved by MF, <span class="auth">(TA,)</span> and <span class="ar">إِيمَارٌ</span> is syn. therewith, <span class="auth">(Ḳ,)</span> but this also is disapproved by MF, and deemed by him strange, <span class="add">[being by rule the inf. n. of <span class="arrow"><span class="ar">آمَرَهُ↓</span></span>, respecting which see what follows,]</span> <span class="auth">(TA,)</span> and <span class="ar">آمِرَةٌ</span>, <span class="auth">(M, Ḳ,)</span> which is one of the inf. ns. <span class="add">[or quasi-inf. ns.]</span> of the measure <span class="ar">فَاعِلَةٌ</span>, like <span class="ar">عَافِيَةٌ</span> and <span class="ar">عَاقِبَةٌ</span>, <span class="auth">(M,)</span> <em>He commanded him; ordered him; bade him; enjoined him;</em> the inf. n. signifying the <em>contr. of</em> <span class="ar">نَهْىٌ</span>; <span class="auth">(T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">آمرهُ↓</span></span>, <span class="auth">(Kr, M, Ḳ,)</span> mentioned by AʼObeyd also as a dial. var. of <span class="ar">أَمَرَهُ</span>: <span class="auth">(Mṣb:)</span> but AʼObeyd says that <span class="ar">آمَرْتُهُ</span> and <span class="ar">أَمرْتُهُ</span> are syn. <span class="add">[in a sense different from that explained above, i. e.]</span> as meaning <span class="ar">كَثَّرْتُهُ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">أَمَرَهُ بِهِ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar long">أَمَرَهُ إِيَّاهُ</span>, suppressing the prep., <span class="auth">(M,)</span> <em>He commanded, ordered, bade,</em> or <em>enjoined, him to do it.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">أمَرْتُكَ أَنْ تَفْعَلَ</span>, and <span class="ar">لِتَفْعَلَ</span>, and <span class="ar long">بِأنْ تَفْعَلَ</span>, <em>I commanded, ordered, bade,</em> or <em>enjoined, thee to do</em> <span class="add">[such a thing]</span>. <span class="auth">(M.)</span> <span class="add">[And <span class="ar long">أَمَرَهُ بِكَذَا</span> as meaning <em>He commanded him,</em> or <em>ordered him, to make use of such a thing; or the like:</em> whence, in a trad.,]</span> <span class="ar long">أُمِرْتُ بِالسِّوَاكِ</span> <span class="add">[<em>I have been commanded to make use of the tooth-stick</em>]</span>. <span class="auth">(El-Jámiʼ eṣ-Ṣagheer.)</span> <span class="add">[And <em>He enjoined him such a thing;</em> as, for instance, patience.]</span> The imperative of <span class="ar">أَمَرَ</span> is <span class="ar">مُرْ</span>; originally <span class="ar">اؤْمُرْ</span>; which also occurs <span class="add">[with <span class="ar">وَ</span> in the place of <span class="ar">ؤ</span> when the <span class="ar">ا</span> is pronounced with damm]</span>: <span class="auth">(M:)</span> but <span class="add">[generally]</span> when it is not preceded by a conjunction, <span class="auth">(Mṣb,)</span> i. e., by <span class="ar">وَ</span> or <span class="ar">فَ</span>, <span class="auth">(T,)</span> you suppress the <span class="ar">ء</span>, <span class="add">[i. e. the radical <span class="ar">ء</span>, and with it the conjunctive <span class="ar">ا</span> preceding it,]</span> contr. to rule, and say, <span class="ar long">مُرْهُ بِكَذَا</span> <span class="add">[<em>Command,</em> or <em>order,</em> or <em>bid,</em> or <em>enjoin, thou him to do such a thing</em>]</span>; like as you say, <span class="ar">كُلْ</span> and <span class="ar">خُذْ</span>: when, however, it is preceded by a conjunction, the practice commonly obtaining is, to restore the <span class="ar long">وَأْمُرْ بِكَذَا</span>, agreeably with analogy, and thus to say, <span class="ar long">أَمُرْ بِكَذَا</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amr_1_A2">
					<p><span class="add">[You say also, <span class="ar long">أَمَرَ بِهِ فَقُتِلَ</span> <em>He gave an order respecting him, and accordingly he was slain.</em> And <span class="ar long">أَمَرَ لَهُ بِكَذَا</span> <em>He ordered that such a thing should be done, or given, to him</em>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Amr_1_A3">
					<p>In the Ḳur <span class="add">[xvii. 17]</span>, <span class="ar long">أَمَرْنَا مُتْرَفِيهَا فَفَسَقُوا فِيهَا</span>, so accord. to most of the readers, <span class="auth">(T, &amp;c.,)</span> means <em>We commanded</em> <span class="add">[<em>its luxurious inhabitants</em>]</span> to obey, <em>but they transgressed therein,</em> or <em>departed from the right way,</em> or <em>disobeyed:</em> <span class="auth">(Fr, T, Ṣ, &amp;c.:)</span> so says Aboo-Is-ḥáḳ; adding that, although one says, <span class="ar long">أَمَرتُ زَيْدًا فَضَرَبَ عَمْرًا</span>, meaning <em>I commanded Zeyd to beat ʼAmr, and he beat him,</em> yet one also says, <span class="ar long">أَمَرْتُكَ فَعَصَيْتَنِى</span> <span class="add">[<em>I commanded thee, but thou disobeyedst me</em>]</span>: or, accord. to some, the meaning is, <em>We multiplied its luxurious inhabitants;</em> <span class="auth">(T;)</span> and this is agreeable with another reading, namely, <span class="arrow"><span class="ar">آمَرْنَا↓</span></span>; <span class="auth">(TA;)</span> and a reading of El-Ḥasan, namely, <span class="ar">أَمِرْنَا</span>, like <span class="ar">عَلِمْنَا</span>, may be a dial. var., of the same signification: <span class="auth">(M:)</span> <a href="#Amr_4">see 4</a>, in two places: or it may be from <span class="ar">الإِمَارَةُ</span>; <span class="auth">(Ṣ, TA;)</span> <span class="add">[in which case it seems that we should read <span class="arrow"><span class="ar">أَمَّرْنَا↓</span></span>; or, perhaps, <span class="ar">أَمَرْنَا</span>: <a href="#Amr_2">see 2</a>:]</span> Abu-l-ʼÁliyeh reads <span class="arrow"><span class="ar">أَمَّرْنَا↓</span></span>, and this is agreeable with the explanation of I’Ab, who says that the meaning is, <em>We made its chiefs to have authority, power,</em> or <em>dominion.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Amr_1_A4">
					<p><span class="ar">أَمَرَهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُرُ</span>}</span></add>, also signifies <em>He commanded, ordered, bade,</em> or <em>enjoined, him to do that which it behooved him to do.</em> <span class="auth">(A.)</span> <span class="add">[<em>He counselled,</em> or <em>advised, him</em>.]</span> One says, <span class="ar">مُرْنِى</span>, meaning <em>Counsel thou me; advise thou me.</em> <span class="auth">(A.)</span></p>
				</div>
				<span class="pb" id="Page_0096"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Amr_1_A5">
					<p><span class="ar long">أَمَرَ بِاقْتِنَاصٍ</span>, said of a wild animal, means <em>He rendered</em> the beholder <em>desirous of capturing</em> him. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amr_1_B1">
					<p><span class="ar">أَمَرَ</span>, <span class="auth">(Aṣ, Fr, Th, T, Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُرُ</span>}</span></add>; <span class="auth">(Mṣb, TA;)</span> and <span class="ar">أَمُرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُرُ</span>}</span></add>; <span class="auth">(Ṣ, M, IḲṭṭ, Ḳ;)</span> and <span class="ar">أَمِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَرُ</span>}</span></add>; <span class="auth">(M, Ḳ, and several other authorities; but by some this is disallowed; TA;)</span> inf. n. <span class="ar">أَمْرٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">إِمْرَةٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">إِمَارَةٌ</span>; <span class="auth">(Aṣ, T, Ṣ;)</span> or the second is a simple subst.; <span class="auth">(Ḳ;)</span> or perhaps it is meant in the Ṣ that this and the third are quasi-inf. ns.; <span class="auth">(MF;)</span> <em>He had,</em> or <em>held, command; he presided as a commander, governor, lord, prince,</em> or <em>king;</em> <span class="auth">(M, Mṣb, Ḳ;)</span> <em>he became an</em> <span class="ar">أَمِير</span>; <span class="auth">(Aṣ, T, Ṣ;)</span> <span class="ar long">عَلَى القَوْمِ</span> <em>over the people.</em> <span class="auth">(M,* Mṣb, Ḳ.)</span> <span class="add">[<a href="#Amr_5">See also 5</a>.]</span> <span class="ar long">أَمَرَ فُلَانٌ وَأُمِرَ عَلَيْهِ</span>, or<span class="arrow"><span class="ar long">وأُمِّرَ↓ عليه</span></span>, <span class="auth">(as in different copies of the Ṣ,)</span> <span class="add">[<em>Such a one has held command and been commanded,</em>]</span> is said of one who has been a commander, or governor, after having been a subject of a commander, or governor; meaning <em>such a one is a person of experience;</em> or <em>one who has been tried,</em> or <em>proved and strengthened, by experience.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Amr_1_C1">
					<p><span class="ar">أَمَرَهُ</span> as syn. with <span class="ar">آمَرَهُ</span>: <a href="#Amr_4">see 4</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Amr_1_D1">
					<p><span class="ar">أَمِرَ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَرُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَمَرٌ</span> and <span class="ar">أَمْرَة</span>; <span class="auth">(M, Ḳ, TA; the latter written in the CK <span class="ar">اَمْرَة</span>;)</span> and <span class="ar">أمُرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَرُ</span>}</span></add>; <span class="auth">(IḲṭṭ;)</span> † <em>It</em> <span class="auth">(a thing, M, Mṣb, or a man's property, or camels or the like, Abu-l-Ḥasan and Ṣ, and a people, T, Ṣ)</span> <em>multiplied;</em> or <em>became many,</em> or <em>much,</em> or <em>abundant;</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> and <em>became complete.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: D2</span>
				</div>
				<div class="sense" id="Amr_1_D2">
					<p>And the former, † <em>His beasts multiplied;</em> or <em>became many;</em> <span class="auth">(M, Ḳ;)</span> <span class="add">[as also<span class="arrow"><span class="ar">آمر↓</span></span>; for you say,]</span> <span class="arrow"><span class="ar long">آمر↓ بَنُو فُلَانٍ</span></span>, inf. n. <span class="ar">إِيمَارٌ</span>, † <em>The property,</em> or <em>camels</em> or <em>the like, of the sons of such a one multiplied;</em> or <em>became many,</em> or <em>abundant.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="Amr_1_E1">
					<p><span class="ar long">أَمِرَ الأَمْرُ</span>, <span class="auth">(Akh, Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَرُ</span>}</span></add>, inf. n. <span class="ar">أَمَرٌ</span>, <span class="auth">(Akh, Ṣ,)</span> † <em>The affair,</em> or <em>case,</em> <span class="auth">(i. e., a man's affair, or case, Akh, Ṣ,)</span> <em>became severe, distressful, grievous,</em> or <em>afflictive.</em> <span class="auth">(Akh, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّر</span></h3>
				<div class="sense" id="Amr_2_A1">
					<p><span class="ar">أمّرهُ</span>, inf. n. <span class="ar">تَأْمِيرٌ</span>, <em>He made him,</em> or <em>appointed him, commander, governor, lord, prince,</em> or <em>king.</em> <span class="auth">(Ṣ,* Mgh, Mṣb.)</span> <span class="add">[And it seems to be indicated in the Ṣ that <span class="arrow"><span class="ar">أَمَرَهُ↓</span></span>, without teshdeed, signifies the same.]</span> <a href="#Amr_1">See 1</a>, in three places. You say also, <span class="ar">أُمِّرَعَلَيْنَا</span> <span class="auth">(A, TA)</span> <em>He was made,</em> or <em>appointed, commander,</em>, &amp;c., <em>over us.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amr_2_A2">
					<p>Also <em>He appointed him judge,</em> or <em>umpire.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Amr_2_A3">
					<p><span class="ar long">أمّر القَنَاةَ</span> † <em>He affixed a spear-head to the cane</em> or <em>spear.</em> <span class="auth">(T, M.)</span> <span class="add">[See also the pass. part. n., below.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Amr_2_A4">
					<p><span class="ar">أمّرأَمَارَةٍ</span> <em>He made</em> <span class="add">[a thing]</span> <em>a sign,</em> or <em>mark, to show the way.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amr_3">
				<h3 class="entry">3. ⇒ <span class="ar">آمر</span></h3>
				<div class="sense" id="Amr_3_A1">
					<p><span class="ar long">آمرهُ فِى أَمْرِهِ</span>, <span class="auth">(T,* Ṣ, M, Mṣb,)</span> inf. n. <span class="ar">مُؤَامَرَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He consulted him respecting his affair,</em> or <em>case;</em> <span class="auth">(T,* Ṣ, M, Mṣb, Ḳ,* TA;)</span> as also <span class="ar">وَامَرَهُ</span>; <span class="auth">(TA;)</span> or this is not a chaste form; <span class="auth">(IAth, TA;)</span> or it is vulgar; <span class="auth">(Ṣ, TA;)</span> and<span class="arrow"><span class="ar">استأمرهُ↓</span></span>, <span class="auth">(M,)</span> inf. n. <span class="ar">اسْتِئْمَارٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">ائتمرهُ↓</span></span>, <span class="auth">(T,)</span> inf. n. <span class="ar">ائتِمَارٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> It is said in a trad., <span class="ar long">آمِرُوا النِّسَآءَ فِى أَنْفُسِهِنَّ</span> <em>Consult ye women respecting themselves,</em> as to marrying them. <span class="auth">(TA.)</span> And in another trad., <span class="ar long">آمَرَتْ نَفْسَهَا</span>, meaning <em>She consulted herself,</em> or <em>her mind;</em> as also<span class="arrow"><span class="ar long">استأمرت↓ نفسها</span></span>. <span class="auth">(TA.)</span> <span class="add">[See another ex. voce <span class="ar">نَفْسٌ</span>. <a href="#Amr_8">And see also 8</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amr_4">
				<h3 class="entry">4. ⇒ <span class="ar">آمر</span></h3>
				<div class="sense" id="Amr_4_A1">
					<p><span class="ar">آمر</span>, inf. n. <span class="ar">إِيمَارٌ</span>: <a href="#Amr_1">see 1</a>, last sentence but one, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amr_4_B1">
					<p><span class="ar">آمْرٌ</span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">أَمَرَهُ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> accord. to some, <span class="auth">(M,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُرُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَمْرٌ</span>; <span class="auth">(Mṣb;)</span> both signifying the same accord. to AO, <span class="auth">(Ṣ,)</span> or AʼObeyd, <span class="auth">(TA,)</span> but the latter is of weak authority, <span class="auth">(Ḳ,)</span> or is not allowable; <span class="auth">(M;)</span> and, accord. to El-Hasan's reading of xvii. 17 of the Ḳur, (<a href="#Amr_1">see 1</a>,) <span class="arrow"><span class="ar">أَمِرَهُ↓</span></span> also; <span class="auth">(M;)</span> † <em>He</em> <span class="auth">(a man)</span> <em>multiplied it;</em> or <em>made it many,</em> or <em>much,</em> or <em>abundant:</em> <span class="auth">(Ṣ, Mṣb:)</span> <em>He</em> <span class="auth">(God)</span> <em>multiplied,</em> or <em>made many</em> or <em>much</em> or <em>abundant, his progeny,</em> and <em>his beasts:</em> <span class="auth">(M, Ḳ:)</span> and <span class="ar long">آمر مَالَهُ</span> † <em>He</em> <span class="auth">(God)</span> <em>multiplied,</em>, &amp;c., <em>his property,</em> or <em>camels</em> or <em>the like.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Amr_4_C1">
					<p><a href="#Amr_1">See also 1</a>, first sentence, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأمّر</span></h3>
				<div class="sense" id="Amr_5_A1">
					<p><span class="ar">تأمّر</span> <em>He became made,</em> or <em>appointed, commander, governor, lord, prince,</em> or <em>king;</em> <span class="auth">(Mṣb;)</span> <em>he received authority, power,</em> or <em>dominion;</em> <span class="ar">عَلَيْهِمْ</span> <em>over them.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<a href="#Oamara">See also <span class="ar">أَمَرَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amr_5_A2">
					<p><a href="#Amr_8">See also 8</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Amr_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآمر</span></h3>
				<div class="sense" id="Amr_6_A1">
					<p><a href="#Amr_8">see 8</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتمر</span></h3>
				<div class="sense" id="Amr_8_A1">
					<p><span class="ar">ائتمر</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَمَرَ</span>]</span> <em>He obeyed,</em> or <em>conformed to, a command;</em> <span class="auth">(Ṣ,* M, Mgh, Ḳ;*)</span> <em>he heard and obeyed.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">ائتمر بِخَيْرٍ</span>, meaning <em>He was as though his mind commanded him to do good and he obeyed the command.</em> <span class="auth">(M.)</span> And <span class="add">[you use it transitively, saying,]</span> <span class="ar long">ائتمر الأَمْرَ</span> <em>He obeyed,</em> or <em>conformed to, the command.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">لَا يَأْتَمِرُ رُشْدًا</span> <em>He will not do right of his own accord.</em> <span class="auth">(A.)</span> Imra el-Keys says, <span class="auth">(Ṣ,)</span> or En-Nemir Ibn-Towlab, <span class="auth">(T,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَيَعْدُو عَلَى المَرْءِ مَا يَأْتَمِرْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And that which man obeys wrongs him,</em> or <em>injures him</em>]</span>; meaning, that which his own soul commands him to do, and which he judges to be right, but in which often is found his destruction: <span class="auth">(Ṣ:)</span> or, accord. to Ḳṭ, <em>that</em> evil <em>which man purposes to do:</em> <span class="auth">(T:)</span> or <em>that which man does without consideration, and without looking to its result.</em> <span class="auth">(AʼObeyd, T.)</span> <span class="add">[See what follows.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amr_8_A2">
					<p><em>He undertook a thing without consulting;</em> <span class="auth">(Ḳṭ, T;)</span> as though his soul, or mind, ordered him to do it and he obeyed it: <span class="auth">(TA:)</span> <em>he followed his own opinion only.</em> <span class="auth">(Mgh.)</span> One says, <span class="ar long">أَمَرْتُهُ فأْتَمَرَ وَأَبَى أَنْ يَأْتَمِرَ</span>, <span class="auth">(A, Mgh,)</span> meaning <em>I commanded him, but he followed his own opinion only, and refused to obey.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Amr_8_A3">
					<p><em>He formed an opinion, and consulted his own mind, and determined upon it.</em> <span class="auth">(Sh, T.)</span> And <span class="ar long">ائتمر رَأْيَهُ</span> <em>He consulted his own mind,</em> or <em>judgment,</em> respecting what was right for him to do. <span class="auth">(Sh, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Amr_8_A4">
					<p><span class="ar">ائتمروا</span>, <span class="auth">(A, Mṣb,)</span> inf. n. <span class="ar">ائْتِمَارٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">تآمروا↓</span></span>, <span class="auth">(A,)</span> inf. n. <span class="ar">تَآمُرٌ</span>, of the measure <span class="ar">تَفَاعُلٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">تأمّروا↓</span></span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَأَمُّرٌ</span>; <span class="auth">(Ḳ;)</span> <em>They consulted together:</em> <span class="auth">(Ṣ,* A, Mṣb, Ḳ:*)</span> or <span class="ar">ائتمروا</span> and<span class="arrow"><span class="ar">تآمروا↓</span></span> signify <em>they commanded, ordered, bade,</em> or <em>enjoined, one another;</em> like as one says, <span class="ar">اقتتلوا</span> and <span class="ar">تقاتلوا</span>, and <span class="ar">اختصموا</span> and <span class="ar">تخاصموا</span>: <span class="auth">(T:)</span> or <span class="ar long">ائتمروا عَلَى الأَمْرِ</span> and<span class="arrow"><span class="ar long">تآمروا↓ عَلَيْهِ</span></span>, <em>they determined,</em> or <em>settled, their opinions respecting the affair,</em> or <em>case:</em> <span class="auth">(M:)</span> and <span class="ar long">ائتمروا بِهِ</span>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> signifies <em>they purposed it,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,*)</span> namely, a thing, <span class="auth">(Mṣb, Ḳ,)</span> <em>and consulted one another respecting it.</em> <span class="auth">(Ṣ.)</span> It is said in the Ḳur <span class="add">[lxv. 6]</span>, <span class="ar long">وَأْتَمِرُوا بَيْنَكُمْ بِمَعْرُوفٍ</span> <em>And command ye,</em> or <em>enjoin ye, one another to do good:</em> <span class="add">[such is app. the meaning,]</span> but God best knoweth: <span class="auth">(T:)</span> or, accord. to Ḳṭ, <em>purpose ye among yourselves to do good.</em> <span class="auth">(TA.)</span> And in the same <span class="add">[xxviii. 19]</span>, <span class="ar long">إِنَّ الْمَلَأَ يَأْتَمِرُونَ بِكَ لِيَقْتُلوُكَ</span>, meaning <em>Verily the chiefs command one another respecting thee, to slay thee:</em> <span class="auth">(Zj, T:)</span> or <em>consult together against thee, to slay thee:</em> <span class="auth">(AO, T:)</span> or <em>purpose against thee, to slay thee:</em> <span class="auth">(Ḳṭ, T:)</span> but the last but one of these explanations is better than the last. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Amr_8_A5">
					<p><a href="#Amr_3">See also 3</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Amr_8_A6">
					<p>Accord. to El-Bushtee, <span class="ar">ائتمرهُ</span> also signifies <em>He gave him permission:</em> but this has not been heard from an Arab. <span class="auth">(Az, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Amr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأمر</span></h3>
				<div class="sense" id="Amr_10_A1">
					<p><a href="#Amr_3">see 3</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamorN">
				<h3 class="entry"><span class="ar">أَمْرٌ</span></h3>
				<div class="sense" id="OamorN_A1">
					<p><span class="ar">أَمْرٌ</span> <em>A command; an order; a bidding; an injunction; a decree; an ordinance; a prescript:</em> <span class="auth">(Ṣ,* Mṣb,* TA, &amp;c.:)</span> pl. <span class="ar">أَوَامِرُ</span>: <span class="auth">(Ṣ, Mṣb, &amp;c.:)</span> so accord. to common usage; and some writers of authority justify and explain it by saying that <span class="ar">أَمْرٌ</span> is <span class="add">[originally]</span> <span class="ar long">مَأْمُوُرٌ بِهِ</span>; that it is then changed to the measure <span class="ar">فَاعِلٌ</span>; <span class="add">[i. e., to <span class="ar">آمِرٌ</span>;]</span> like <span class="ar long">أَمْرٌ عَارِفٌ</span>, which is originally <span class="ar">مَعْرُوفٌ</span>; and <span class="ar long">عِيشَةٌ راضِيَةٌ</span>, originally <span class="ar">مَرْضِيَّةٌ</span>;, &amp;c.; <span class="add">[and then, to <span class="ar">أَمْرٌ</span>;]</span> and that <span class="ar">فَاعِلٌ</span> becomes in the pl. <span class="ar">فَوَاعِلُ</span>; so that <span class="ar">أَوَامَرُ</span> <a href="#maOomuwrN">is the pl. of <span class="ar">مَإْمُورٌ</span></a>: others say that it has this form of pl. to distinguish it from <span class="ar">أَمْرٌ</span> in the sense of <span class="ar">حَالٌ</span> <span class="add">[&amp;c.]</span>, in which sense it has for its pl. <span class="ar">أُمُورٌ</span>. <span class="auth">(Mṣb, TA.)</span> <span class="add">[But I think that <span class="ar">أَوَامِرُ</span> may be properly and originally <a href="#AmirapN">pl. of <span class="ar">آمِرَةٌ</span></a>, for <span class="ar long">آيَةٌ آمِرَةٌ</span>, or the like. MF says that, accord. to the T and M, <a href="#OamorN">the pl. of <span class="ar">أَمْرٌ</span></a> in the sense explained in the beginning of this paragraph is <span class="ar">أُمُورٌ</span>: but he seems to have founded his assertion upon corrupted copies of those works; for in the M, I find nothing on this point; and in the T, not, as he says, <span class="ar long">الأَمْرُضِدُّ النَّهْىَ وَاحِدُ الأُمُور</span>, but <span class="ar long">قَالَ اللَّيْثُ الأَمْرُ مَعْرُوفٌ نَقِيضُ النَّهْىِ وَاحِدُ الأُمُورِ</span>, evidently meaning that <span class="ar">أَمْرٌ</span> <a href="#nahoeN">signifies the contr. of <span class="ar">نَهْىٌ</span></a>, and is also, in another sense, <a href="#OumuwrN">the sing. of <span class="ar">أُمُورٌ</span></a>.]</span> <span class="add">[Hence,]</span> <span class="ar long">أُولُو الأَمْرِ</span> <em>Those who hold command</em> or <em>rule,</em> and <em>the learned men.</em> <span class="auth">(M, Ḳ. <span class="add">[See Ḳur iv. 62.]</span>)</span> And <span class="ar">أَمْرُٱللّٰهِ</span> <em>The threatened punishment of God:</em> so in the Ḳur x. 25, and xi. 42, and xvi.1; in which last place occur the words, <span class="ar long">أَتَى أَمْرُ ٱللّٰهِ فَلَا تَسْتَعْجِلُوهُ</span>, meaning <em>The threatened punishment ordained of God hath, as it were, come:</em> so near is it, that it is as though it had already come: <em>therefore desire not ye to hasten it.</em> <span class="auth">(Zj, M, TA.)</span> And <em>The purpose of God.</em> <span class="auth">(Bḍ and Jel in lxv. 3;, &amp;c.)</span> And <span class="ar long">الأَمْرُ قَرِيبٌ</span> <em>The resurrection,</em> or <em>the time thereof, is near.</em> <span class="auth">(Mgh, from a trad.)</span> And <span class="ar long">مَا فَعَلْتُهُ عَنْ أَمْرِى</span>, in the Ḳur xviii. 81, <em>I did it not of my own judgment:</em> <span class="auth">(Bḍ:)</span> or, <em>of my own choice.</em> <span class="auth">(Jel.)</span> <span class="add">[Hence also <span class="ar">الأَمْرُ</span>, in grammar, signifies <em>The imperative form</em> of a verb.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamorN_A2">
					<p>Also <em>A thing; an affair; a business; a matter; a concern: a state, of a person</em> or <em>thing,</em> or <em>of persons</em> or <em>things</em> or <em>affairs or circumstances; a condition; a case: an accident; an event: an action:</em> <span class="pb" id="Page_0097"></span>syn. <span class="ar">شَأْنٌ</span>: <span class="auth">(M, F, TA:)</span> and <span class="ar">حَالٌ</span>, <span class="auth">(Mṣb, TA,)</span> and <span class="ar">حَالَةٌ</span>: <span class="auth">(Mṣb:)</span> and <span class="ar">حَادِثَةٌ</span>: <span class="auth">(Ḳ:)</span> and <span class="ar">فِعْلٌ</span>: <span class="auth">(MF, TA:)</span> and <em>a thing that is said; a saying:</em> <span class="auth">(TA voce <span class="ar">أُولُو</span>, at the end of art. <span class="ar">ال</span>:)</span> pl. <span class="ar">أُمُورٌ</span>; <span class="auth">(Ṣ, M, Ḳ, &amp;c.;)</span> its only pl. in the senses here explained. <span class="auth">(TA.)</span> You say, <span class="ar long">أَمْرُ فُلَانٍ مُسْتَقِيمٌ</span> <span class="add">[<em>The affair,</em> or <em>the like, of such a one is in a right state</em>]</span>: and <span class="ar long">امُورُهُ مُسْتَقِيمَةٌ</span> <span class="add">[<em>His affairs are in a right state</em>]</span>. <span class="auth">(Ṣ, A.)</span> And <span class="ar long">شَتَّتَ أَمْرَهُ</span> <em>He dissipated, disorganized, disordered, unsettled,</em> or <em>broke up, his state of things,</em> or <em>affairs.</em> <span class="auth">(Aṣ, TA in art. <span class="ar">شعب</span>.)</span> <span class="add">[<span class="ar">امر</span> seems to be here used, as in many other instances, rather in the sense of the pl. than in that of the sing.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamorN_A3">
					<p><span class="ar long">أَمْرٌ كُلِّىٌّ</span> <span class="add">[<em>A universal,</em> or <em>general, prescript, rule,</em> or <em>canon</em>]</span>. <span class="auth">(Mṣb voce <span class="ar">قَاعِدَةٌ</span>, KT voce <span class="ar">قَانُونٌ</span>, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimorN">
				<h3 class="entry"><span class="ar">إِمْرٌ</span></h3>
				<div class="sense" id="IimorN_A1">
					<p><span class="ar">إِمْرٌ</span> a subst. from <span class="ar">أَمِرَالِأَمْرُ</span> in the sense of <span class="ar">اِشْتَدَّ</span>; <span class="auth">(Ṣ;)</span> or a subst. from <span class="ar">أَمِرَ</span> as signifying <span class="ar">كَثُرَ</span> and <span class="ar">تَمَّ</span>; <span class="auth">(M;)</span> † <span class="add">[<em>A severe, a distressful, a grievous,</em> or <em>an afflictive, thing:</em> or]</span> <em>a terrible, and foul,</em> or <em>very foul, thing:</em> or <em>a wonderful thing.</em> <span class="auth">(TA,)</span> Hence, <span class="add">[used as an epithet, like <span class="ar">أَمِرٌ</span>, q. v.,]</span> in the Ḳur <span class="add">[xviii. 70]</span>, <span class="ar long">لَقَدْ جِئْتَ شَيْئًا إِمْرًا</span> † <em>Verily thou hast done a severe, a distressful, a grievous,</em> or <em>an afflictive, thing:</em> <span class="auth">(Ṣ:)</span> or <em>a terrible, and foul,</em> or <em>very foul, thing:</em> <span class="auth">(TA:)</span> or <em>a wonderful thing:</em> <span class="auth">(Ṣ:)</span> or <em>an abominable, a foul,</em> or <em>an evil, and a wonderful, thing:</em> <span class="auth">(Ks, M, Ḳ:*)</span> or <em>a terrible and an abominable thing;</em> signifying more than <span class="ar">نَكْرًا</span>, <span class="add">[which occurs after, in verse 73,]</span> inasmuch as the <span class="add">[presumed]</span> drowning of the persons in the ship was more abominable than the slaying of one person: <span class="auth">(Zj, T:)</span> or <em>a crafty, and an abominable,</em> or <em>a foul,</em> or <em>an evil, and a wonderful, thing;</em> and derived from <span class="ar long">أَمِرَ القَوْمُ</span> as meaning <span class="ar">كَثُرُوا</span>. <span class="auth">(Ks.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamarN">
				<h3 class="entry"><span class="ar">أَمَرٌ</span></h3>
				<div class="sense" id="OamarN_A1">
					<p><span class="ar">أَمَرٌ</span> a coll. gen. n. of which <span class="ar">أَمَرَةٌ</span> <span class="auth">(q. v.)</span> is the n. un.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمَرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamarN_B1">
					<p><a href="#taOomuwrN">See also <span class="ar">تَأْمُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamirN">
				<h3 class="entry"><span class="ar">أَمِرٌ</span> / <span class="ar">أَمِرَةٌ</span></h3>
				<div class="sense" id="OamirN_A1">
					<p><span class="ar">أَمِرٌ</span>: <a href="#IimBarN">see <span class="ar">إِمَّرٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamirN_B1">
					<p>† <em>Multiplied;</em> or <em>become many,</em> or <em>much,</em> or <em>abundant.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#Oamira">See <span class="ar">أَمِرَ</span></a>.]</span> You say <span class="ar long">زَرْعٌ أَمِرٌ</span> † <em>Abundant seed-produce.</em> <span class="auth">(Lḥ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OamirN_B2">
					<p>† A man <em>whose beasts have multiplied,</em> or <em>become many</em> or <em>abundant.</em> <span class="auth">(M.)</span> † A man <em>blessed,</em> or <em>prospered,</em> <span class="auth">(Ibn-Buzurj, M, Ḳ,*)</span> <em>in his property:</em> <span class="auth">(M:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَمِرَةٌ</span>}</span></add>. <span class="auth">(Ibn-Buzurj.)</span> And with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَمِرَةٌ</span>}</span></add>, † A woman <em>blessed to her husband</em> <span class="add">[<em>by her being prolific</em>]</span>: from the signification of <span class="ar">كَثْرَةٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OamirN_C1">
					<p>† <em>Severe; distressful; afflictive.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#IimorN">See also <span class="ar">إِمْرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamorapN">
				<h3 class="entry"><span class="ar">أَمْرَةٌ</span></h3>
				<div class="sense" id="OamorapN_A1">
					<p><span class="ar">أَمْرَةٌ</span> <em>A single command, order, bidding,</em> or <em>injunction:</em> as in the saying, <span class="ar long">لَكَ عَلَىَّ أَمْرَةٌ مُطَاعَةٌ</span> <em>Thou hast authority to give me one command, order, bidding,</em> or <em>injunction,</em> which shall be <em>obeyed</em> by me. <span class="auth">(Ṣ, M,* A, Mṣb, Ḳ.)</span> You should not say, <span class="add">[in this sense,]</span> <span class="ar">إِمْرَةٌ</span>, with kesr. <span class="auth">(T, Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمْرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamorapN_B1">
					<p><a href="#IimorapN">See also <span class="ar">إِمْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimorapN">
				<h3 class="entry"><span class="ar">إِمْرَةٌ</span></h3>
				<div class="sense" id="IimorapN_A1">
					<p><span class="ar">إِمْرَةٌ</span> a subst. from <span class="ar">أَمَرَ</span> <span class="add">[q. v.]</span>; <em>Possession of command;</em> the <em>office,</em> and <em>authority, of a commander, governor, lord, prince,</em> or <em>king;</em> <span class="auth">(M,* Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِمَارَةٌ↓</span></span> <span class="auth">(Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَمَارَةٌ↓</span></span>; <span class="auth">(L, Ḳ;)</span> but this last is by some disallowed, and is said in the Fṣ and its Expositions to be unknown. <span class="auth">(MF.)</span> It is said in a trad., <span class="ar long">لَعَلَّكَ سآءَ تْكَ إِمْرَةُ ابْنِ عَمِّكَ</span> <em>Perhaps thy paternal uncle's son's possession of command hath displeased thee.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">إِمْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IimorapN_A2">
					<p><span class="add">[And hence, † <em>Increase,</em> or <em>abundance,</em> or <em>the like;</em> as also other forms mentioned in what follows.]</span> You say, <span class="ar long">فِى وَجْهِ مَالِكَ تَعْرِفُ إِمْرَتَهُ</span> † <em>In the face of thy property,</em> <span class="add">[meaning such as consists in camels or the like, and also money,]</span> <em>thou knowest its increase and abundance,</em> and <em>its expense:</em> <span class="auth">(Ṣ:)</span> or<span class="arrow"><span class="ar">إِمَّرَتَهُ↓</span></span>, and<span class="arrow"><span class="ar">إِمّرَتَهُ↓</span></span>, which latter is a dial. var. of weak authority, and<span class="arrow"><span class="ar">أَمَّرَتَهُ↓</span></span>, i. e., <em>its increase and abundance:</em> <span class="auth">(M:)</span> or<span class="arrow"><span class="ar">إِمَّرَتَهُ↓</span></span> as meaning <em>its prosperous state;</em> as also<span class="arrow"><span class="ar">أَمَارَتَهُ↓</span></span>, and<span class="arrow"><span class="ar">أَمْرَتَهُ↓</span></span>: <span class="auth">(Ibn-Buzurj:)</span> accord. to AHeyth, who reads<span class="arrow"><span class="ar long">تُعْرَفُ إِمَّرَتُهُ↓</span></span>, the meaning is, <em>its decrease;</em> but the correct meaning is, <em>its increase,</em> as Fr explains it. <span class="auth">(T, TA.)</span> It is said respecting anything of which one knows what is good in it at first sight: <span class="auth">(Lḥ, M:)</span> and means, on a thing's presenting itself, thou knowest its goodness. <span class="auth">(T.)</span> One says also,<span class="arrow"><span class="ar long">مأَحْسَنَ أَمَارَتَهُمْ↓</span></span> † <em>How good is their multiplying, and the multiplying of their offspring and of their number!</em> <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">لَا جَعَلَ ٱللّٰهُ فِيهِ إِمَّرَةً↓</span></span> † <em>May God not make an increase to be therein.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamarapN">
				<h3 class="entry"><span class="ar">أَمَرَةٌ</span></h3>
				<div class="sense" id="OamarapN_A1">
					<p><span class="ar">أَمَرَةٌ</span> <em>Stones:</em> <span class="auth">(Ḳ:)</span> <span class="add">[or <em>a heap of stones:</em>]</span> or it <a href="#OamarN">is the n. un. of <span class="ar">أَمَرٌ</span></a>, which signifies <em>stones:</em> <span class="auth">(M:)</span> or the latter signifies <em>stones set up in order that one may be directed thereby to the right way:</em> <span class="auth">(Ḥam p. 409:)</span> and the former also signifies <em>a hill;</em> <span class="auth">(M, Ḳ;)</span> and <span class="ar">أَمَرٌ</span> is <span class="add">[used as]</span> its pl.: <span class="auth">(M:)</span> and <em>a sign,</em> or <em>mark, by which anything is known;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَمَارٌ↓</span></span> and<span class="arrow"><span class="ar">أَمَارَةٌ↓</span></span>; <span class="auth">(Aṣ, Ṣ;)</span> and <span class="ar">أَمَرٌ</span> is <span class="add">[used as]</span> its pl. in this sense also: <span class="auth">(M:)</span> or <em>a sign,</em> or <em>mark, set up to show the way;</em> <span class="auth">(AA, Fr;)</span> as also<span class="arrow"><span class="ar">أَمَارٌ↓</span></span> and<span class="arrow"><span class="ar">أَمَارَهٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or <em>a small sign,</em> or <em>mark, of stones, to show the way, in a waterless desert;</em> <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">أَمَارٌ↓</span></span> <span class="add">[and<span class="arrow"><span class="ar">أَمَارَةٌ↓</span></span>]</span>; and <em>any sign,</em> or <em>mark, that is prepared:</em> <span class="auth">(TA:)</span> or <em>a structure like a</em> <span class="ar">مَنَارَة</span> <span class="add">[here app. meaning a <em>tower of a mosque</em>]</span>, <em>upon a mountain, wide like a house</em> or <em>tent, and larger, of the height of forty times the stature of a man, made in the time of 'Ád and Irem; in some instances its foundation being like a house, though it consists only of stones piled up, one upon another, cemented together with mud, appearing as though it were of natural formation:</em> <span class="auth">(ISh, T:)</span> the pl. <span class="auth">(in all the senses above, Ḳ)</span> <span class="add">[or rather the coll. gen. n.,]</span> is <span class="ar">أَمَرٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمَرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamarapN_B1">
					<p><a href="#IimorapN">See also <span class="ar">إِمْرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamaArN">
				<h3 class="entry"><span class="ar">أَمَارٌ</span></h3>
				<div class="sense" id="OamaArN_A1">
					<p><span class="ar">أَمَارٌ</span> and<span class="arrow"><span class="ar">أَمَارَةٌ↓</span></span> <em>A sign, mark,</em> or <em>token.</em> <span class="auth">(Aṣ, Ṣ Mgh.)</span> See also each voce <span class="ar">أَمَرَةٌ</span>, in three places. You say, <span class="ar long">هِى أَمَارَةُ مَا بَيْنِى وَبَيْنَكَ</span> <em>It is a sign,</em> or <em>token, of what is between me and thee.</em> <span class="auth">(T,* TA.)</span> And a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَا طَلَعَتْ شَمْسُ النَّهَارِ فَإِنَّهَا</span> *</div> 
						<div class="star">* <span class="ar long">أَمَارَةُ تَسْلِيمِى عَلَيْكِ فَسَلِّمِى</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When the sun of day rises, it is a sign of my saluting thee, therefore do thou salute</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamaArN_A2">
					<p>Also <em>A time:</em> <span class="auth">(Aṣ, Ṣ, Ḳ:)</span> so IAạr explains the latter word, not particularizing the time as definite or otherwise: <span class="auth">(M:)</span> or <em>a definite time:</em> <span class="auth">(TA:)</span> or <em>a time,</em> or <em>place, of promise</em> or <em>appointment; an appointed time</em> or <em>place;</em> syn. <span class="ar">مَوْعِدٌ</span>: <span class="auth">(M, Mgh, Ḳ:)</span> or, accord. to some, the former word is pl. <span class="add">[or rather col. gen. n.]</span> of the latter. <span class="auth">(TA.)</span> El-ʼAjjáj says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذْ رَدَّهَا بِكَيْدِهِ فَارْتَدَّتِ</span> *</div> 
						<div class="star">* <span class="ar long">إِلَى أَمَارٍ وَأَمَارِ مُدَّتِى</span> *</div> 
					</blockquote>
					<p><em>When He</em> <span class="auth">(meaning God)</span> <em>brings it,</em> <span class="auth">(namely my soul,)</span> <em>by his skilful ordering,</em> and his power, <span class="add">[<em>and it is thus brought,</em> or <em>it thus comes, to a set time, and</em>]</span> <em>to the time of the end of my appointed period:</em> <span class="ar">امارمدّتى</span> being as above; the former word being prefixed to the latter, governing it in the gen. case. <span class="auth">(IB. <span class="add">[In the Ṣ we find <span class="ar long">وَأَمَارٌ مُدَّتِى</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamuwrN">
				<h3 class="entry"><span class="ar">أَمُورٌ</span></h3>
				<div class="sense" id="OamuwrN_A1">
					<p><span class="ar">أَمُورٌ</span> <span class="add">[an intensive epithet from <span class="ar">أَمَرَهُ</span>]</span>. You say, <span class="ar long">إِنَّهُ لَأَمُورٌ بِالْمَعْروفِ وَنَهُوٌّ عَنِ الْمُنْكَرِ</span> <em>Verily he is one who strongly commands,</em> or <em>enjoins, good conduct, and who strongly forbids evil conduct.</em> <span class="auth">(Ṣ in art. <span class="ar">نهى</span>, and A.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamiyrN">
				<h3 class="entry"><span class="ar">أَمِيرٌ</span> / <span class="ar">أَمِيرَةٌ</span></h3>
				<div class="sense" id="OamiyrN_A1">
					<p><span class="ar">أَمِيرٌ</span> <em>One having, holding,</em> or <em>possessing, command;</em> <span class="auth">(Ṣ;)</span> <em>a commander; a governor; a lord;</em> <span class="auth">(M,* Mṣb;)</span> <em>a prince,</em> or <em>king:</em> <span class="auth">(M, Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَمِيرَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">إُمَرَآءُ</span>. <span class="auth">(M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamiyrN_A2">
					<p><em>A leader of the blind.</em> <span class="auth">(M, Ḳ.)</span> So in the saying of El-Aạshà:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَاكَانَ هَادِى الفَتَى فِى البِلَا</span> *</div> 
						<div class="star">* <span class="ar long">دِصَدْرَ القَنَاةِ أَطَاعَ الأَمِيرَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When the young man's guide in the countries,</em> or <em>lands,</em> or <em>the like, is the top of the cane, he obeys the leader of the blind</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamiyrN_A3">
					<p>A woman's <em>husband.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OamiyrN_A4">
					<p><em>A neighbour.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OamiyrN_A5">
					<p><em>A person with whom one consults:</em> <span class="auth">(A, Ḳ:)</span> <em>any one of whom one begs counsel,</em> or <em>advice, in a case of fear.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">هُوَ أَمِيرِى</span> <em>He is the person with whom I consult.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamaArapN">
				<h3 class="entry"><span class="ar">أَمَارَةٌ</span></h3>
				<div class="sense" id="OamaArapN_A1">
					<p><span class="ar">أَمَارَةٌ</span>: <a href="#IimorapN">see <span class="ar">إِمْرَةٌ</span></a>, in three places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamaArapN_A2">
					<p><a href="#OamarapN">and see also <span class="ar">أَمَرَةٌ</span></a>, in three places; and <span class="ar">أَمَارٌ</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimaArapN">
				<h3 class="entry"><span class="ar">إِمَارَةٌ</span></h3>
				<div class="sense" id="IimaArapN_A1">
					<p><span class="ar">إِمَارَةٌ</span>: <a href="#IimorapN">see <span class="ar">إِمْرَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">إِمَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IimaArapN_A2">
					<p><span class="ar">الإِمَارَةُ</span> is also used for <span class="ar long">صَاحِبُ الإمَارَةِ</span>, i. e. <span class="ar">الأَمِيرُ</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamBarN">
				<h3 class="entry"><span class="ar">أَمَّرٌ</span></h3>
				<div class="sense" id="OamBarN_A1">
					<p><span class="ar">أَمَّرٌ</span>: <a href="#IimBarN">see the next paragraph</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimBarN">
				<h3 class="entry"><span class="ar">إِمَّرٌ</span></h3>
				<div class="sense" id="IimBarN_A1">
					<p><span class="ar">إِمَّرٌ</span> A man <em>who consults every one respecting his case;</em> as also<span class="arrow"><span class="ar">أَمِرٌ↓</span></span> and<span class="arrow"><span class="ar">أَمَّارَةٌ↓</span></span>: <span class="auth">(M:)</span> or a man <em>resembling</em> <span class="add">[<em>in stupidity</em>]</span> <em>a kid:</em> <span class="add">[see the latter part of this paragraph:]</span> <span class="auth">(Th, M:)</span> or, as also<span class="arrow"><span class="ar">إِمَّرَةٌ↓</span></span> <span class="auth">(Ṣ, M, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">أَمَّرٌ↓</span></span> and<span class="arrow"><span class="ar">أَمَّرَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> a man <em>having weak judgment,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>stupid,</em> <span class="auth">(T, M,)</span> or <em>weak, without judgment,</em> <span class="auth">(M, L,)</span> or <em>without intellect,</em> or <em>intelligence,</em> <span class="auth">(T,)</span> <em>who obeys the command of every one,</em> <span class="auth">(T, Ṣ,)</span> <em>who complies with what every one desires to do in all his affairs;</em> <span class="auth">(Ḳ;)</span> a <em>stupid</em> man, <em>of weak judgment, who says to another, Command me to execute thine affair.</em> <span class="auth">(IAth.)</span> It is said in a trad., <span class="ar long">مَنْ يُطِعْ إِمَّرَةً لَا يَأْكُلْ ثَمَرَةً</span> <span class="add">[<em>He who obeys a stupid man,</em>, &amp;c., <em>shall not eat fruit:</em> or the meaning is]</span> <em>he who obeys a stupid woman shall be debarred from good.</em> <span class="auth">(IAth.)</span> <span class="pb" id="Page_0098"></span><span class="arrow"><span class="ar">إِمَّرَةٌ↓</span></span> is applied to a woman and to a man: when it is applied to a man, the <span class="ar">ة</span> is added to give intensiveness to the signification. <span class="auth">(ISh.)</span> The following saying,<span class="arrow"><span class="ar long">إِذَا طَلَعَتِ الشِّعْرَى سَفَرًا فَلَا تُرْسِلْ فِيهَا إِمَّرَةً↓ وَلَا إِمَّرًا</span></span>, in rhyming prose, means <span class="add">[<em>When Sirius rises in the clear twilight,</em>]</span> <em>send not thou among them</em> (<em>meaning the camels</em>) <em>a man without intelligence</em> <span class="add">[<em>in a great degree, nor one who is so in a less degree;</em> or <em>a woman without intelligence, nor a man without intelligence;</em>]</span> to manage them. <span class="auth">(Sh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">إِمَّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IimBarN_A2">
					<p>Also, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">إِمَّرَةٌ↓</span></span> and<span class="arrow"><span class="ar">أَمَّرَ↓</span></span> and<span class="arrow"><span class="ar">أُمَّرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A young lamb:</em> <span class="auth">(M, Ḳ:)</span> or the first (<span class="ar">إِمَرٌ</span>) and the second, <em>a young kid:</em> <span class="auth">(M, TA:)</span> or the former of these two, <em>a male lamb:</em> <span class="auth">(M, TA:)</span> or <em>a young male lamb:</em> <span class="auth">(Ṣ:)</span> and the latter of them, <em>a female lamb:</em> <span class="auth">(M, TA:)</span> or <em>a young female lamb.</em> <span class="auth">(Ṣ, M.)</span> One says,<span class="arrow"><span class="ar long">مَا لَهُ إِمَّرٌ وَلَا إِمَّرَةٌ↓</span></span>, meaning <em>He has not a male lamb nor a female lamb:</em> <span class="auth">(M, TA:)</span> or <em>he has not anything.</em> <span class="auth">(T, Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OamBarapN">
				<h3 class="entry"><span class="ar">أَمَّرَةٌ</span></h3>
				<div class="sense" id="OamBarapN_A1">
					<p><span class="ar">أَمَّرَةٌ</span>: <a href="#IimBarN">see <span class="ar">إِمَّرٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimBarapN">
				<h3 class="entry"><span class="ar">إِمَّرَةٌ</span></h3>
				<div class="sense" id="IimBarapN_A1">
					<p><span class="ar">إِمَّرَةٌ</span>: <a href="#IimBarN">see <span class="ar">إِمَّرٌ</span></a>, in six places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">إِمَّرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IimBarapN_B1">
					<p><a href="#IimorapN">and see <span class="ar">إِمْرَةٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimBirapN">
				<h3 class="entry"><span class="ar">إِمِّرَةٌ</span></h3>
				<div class="sense" id="IimBirapN_A1">
					<p><span class="ar">إِمِّرَةٌ</span>: <a href="#IimorapN">see <span class="ar">إِمْرَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamBaArN">
				<h3 class="entry"><span class="ar">أَمَّارٌ</span></h3>
				<div class="sense" id="OamBaArN_A1">
					<p><span class="ar">أَمَّارٌ</span> <span class="add">[<em>Wont to command</em>]</span>. <span class="add">[Hence,]</span> <span class="ar long">النَّفْسُ الأَمَّارَةُ</span> <span class="add">[<em>The soul that is wont to command</em>]</span>; <span class="auth">(A;)</span> <em>the soul that inclines to the nature of the body, that commands to the indulgence of pleasures and sensual appetites, drawing the heart downwards, so that it is the abode of evils, and the source of culpable dispositions.</em> <span class="auth">(KT.)</span> <span class="add">[<a href="#nafosN">See <span class="ar">نَفْسٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamBaArapN">
				<h3 class="entry"><span class="ar">أَمَّارَةٌ</span></h3>
				<div class="sense" id="OamBaArapN_A1">
					<p><span class="ar">أَمَّارَةٌ</span> <a href="#OamBaArN">fem. of <span class="ar">أَمَّارٌ</span> <span class="add">[q. v.]</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">أَمَّارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamBaArapN_A2">
					<p><a href="#IimBarN">See also <span class="ar">إِمَّرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MmirN">
				<h3 class="entry"><span class="ar">آمِرٌ</span></h3>
				<div class="sense" id="MmirN_A1">
					<p><span class="ar">آمِرٌ</span> <span class="add">[act. part. n. of <span class="ar">أَمَرَهُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">آمِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MmirN_A2">
					<p><span class="ar">آمِرٌ</span> and<span class="arrow"><span class="ar">مُؤْتَمِرٌ↓</span></span> <em>Two days,</em> <span class="auth">(Ṣ,)</span> <em>the last,</em> <span class="auth">(Ḳ,)</span> <em>the former being the sixth, and the latter the seventh,</em> <span class="auth">(M,)</span> <em>of the days called</em> <span class="ar long">أَيَّامُ الَجُوزِ</span>: <span class="auth">(Ṣ, M, Ḳ: <span class="add">[<a href="#EajuwzN">but see <span class="ar">عَجُوزٌ</span></a>:]</span>)</span> as though the former commanded men to be cautious, and the latter consulted them as to whether they should set forth on a journey or stay at home: <span class="auth">(Ṣ:)</span> accord. to Az, the latter is applied as an epithet to the day as meaning <span class="ar">يُؤْتَمَرُفِيهِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOomurieBN">
				<h3 class="entry"><span class="ar">تَأْمُرِىٌّ</span></h3>
				<div class="sense" id="taOomurieBN_A1">
					<p><span class="ar">تَأْمُرِىٌّ</span>: <a href="#taOomuwrN">see <span class="ar">تَأْمُورٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuWomurieBN">
				<h3 class="entry"><span class="ar">تُؤْمُرِىٌّ</span> / <span class="ar">تُومُرِىٌّ</span></h3>
				<div class="sense" id="tuWomurieBN_A1">
					<p><span class="ar">تُؤْمُرِىٌّ</span>, and without <span class="ar">ء</span> (<span class="ar">تُومُرِىٌّ</span>): <a href="#taOomuwrN">see <span class="ar">تَأْمُورٌ</span></a>, in six places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOomuwrN">
				<h3 class="entry"><span class="ar">تَأْمُورٌ</span></h3>
				<div class="sense" id="taOomuwrN_A1">
					<p><span class="ar">تَأْمُورٌ</span> and<span class="arrow"><span class="ar">تَأْمُورَةٌ↓</span></span> are properly mentioned in this art.; the measure of the former being <span class="ar">تَفْعُولٌ</span>; <span class="auth">(Ḳ;)</span> and that of the latter, <span class="ar">تَفْعُولَةٌ</span>: <span class="auth">(TA:)</span> not as J has imagined; <span class="add">[who writes them without <span class="ar">ء</span>, and mentions them in art. <span class="ar">تمر</span>;]</span> <span class="auth">(Ḳ;)</span> their measures accord. to him being <span class="ar">فَاعُولٌ</span> and <span class="ar">فَاعُولَةٌ</span>. <span class="auth">(TA.)</span> <span class="add">[But in all the senses here explained, they appear to be with and without <span class="ar">ء</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taOomuwrN_A2">
					<p>The former signifies The <em>soul:</em> <span class="auth">(Ṣ in art. <span class="ar">تمر</span>, where it is written without <span class="ar">ء</span>; and M, A, Ḳ:)</span> because it is that which is wont to command. <span class="auth">(A.)</span> One says, <span class="ar long">قَدْ عَلِمَ تَأْمُورُكَ ذلِكَ</span> <em>Thy soul,</em> or <em>self, hath known that.</em> <span class="auth">(AZ, and T in art. <span class="ar">تمر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taOomuwrN_A3">
					<p>The <em>intellect:</em> <span class="auth">(M:)</span> as in the saying, <span class="ar long">عَرَفْتُهُ بِتَأْمُورِى</span> <em>I knew it by my intellect.</em> <span class="auth">(M in art. <span class="ar">تمر</span>, without <span class="ar">ء</span>; and TA.)</span> You say also, <span class="ar long">هُوَ ابْنُ تَأْمُورِهَا</span>, meaning <em>He is the knowing with respect to it.</em> <span class="auth">(TA in art. <span class="ar">بنى</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taOomuwrN_A4">
					<p>The <em>heart,</em> <span class="auth">(T in art. <span class="ar">تمر</span> without <span class="ar">ء</span>, and M, A, Ḳ,)</span> <em>itself.</em> <span class="auth">(M, TA.)</span> Hence the saying, <span class="ar long">حَرْفٌ فِى تَأْمُورِى خَيْرٌ مِنْ عَشَرَةٍ فى وِ عَائِكَ</span> <span class="add">[<em>One word in my heart is better than ten in thy receptacle</em>]</span>. <span class="auth">(T in art. <span class="ar">تمر</span>, and TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="taOomuwrN_A5">
					<p>The <em>pericardium.</em> <span class="auth">(M in art. <span class="ar">تمر</span>, without <span class="ar">ء</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="taOomuwrN_A6">
					<p>The <em>core,</em> or <em>black</em> or <em>inner part,</em> or <em>clot of blood,</em> (<span class="ar">حَبَّة</span>, M, Ḳ, or <span class="ar">عَلَقَة</span>, TA,) and <em>life,</em> and <em>blood, of the heart:</em> <span class="auth">(M, Ḳ:)</span> or <em>blood,</em> <span class="auth">(Aṣ, Ṣ, M, in art. <span class="ar">تمر</span>, and Ḳ,)</span> absolutely: <span class="auth">(TA:)</span> and <span class="ar long">تَأْمُورُ النَّفْسِ</span> signifies <em>the life-blood:</em> <span class="auth">(Aṣ, Ṣ:)</span> or <em>the blood of the body:</em> <span class="auth">(Ṣ in art. <span class="ar">نفس</span>:)</span> and <em>the life of the soul.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="taOomuwrN_A7">
					<p>Also, as being likened to blood, <span class="auth">(TA,)</span> ‡ <em>Wine;</em> and so<span class="arrow"><span class="ar">تَأْمُورَةٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> and</p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="taOomuwrN_A8">
					<p>‡ <em>A dye:</em> <span class="auth">(M, TA:)</span> and</p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="taOomuwrN_A9">
					<p>‡ <em>Saffron.</em> <span class="auth">(Aṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="taOomuwrN_A10">
					<p><span class="add">[Hence also,]</span> ‡ <em>Water.</em> <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">مَا فىِ الرَّكِيَّةِ تَامُورٌ</span>, <span class="auth">(T, Ṣ in art. <span class="ar">تمر</span>, and M,)</span> or <span class="ar">تَأْمُورٌ</span>, <span class="auth">(A,)</span> ‡ <em>There is not in the well any water.</em> <span class="auth">(T, Ṣ, M, A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="taOomuwrN_B1">
					<p>The <em>wezeer</em> (<span class="ar">وَزِير</span>) <em>of a king:</em> <span class="auth">(M, Ḳ:)</span> because his command is effectual. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="taOomuwrN_C1">
					<p><em>Any one:</em> as in the saying, <span class="ar long">مَابِهَا تَأْمُورٌ</span>, <span class="auth">(T in art. <span class="ar">تمر</span>, A, Ḳ,)</span> as also<span class="arrow"><span class="ar">تُؤْمُورٌ↓</span></span>, <span class="auth">(T in art. <span class="ar">تمر</span>, and Ḳ,)</span> each with an augmentative <span class="ar">ت</span>, and without <span class="ar">ء</span> as well as with it, accord. to Er-Raḍee and others, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">تَأْمُرِىُّ↓</span></span>, and<span class="arrow"><span class="ar">تَأْمُورِىُّ↓</span></span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">تُؤْمُرِىُّ↓</span></span>, <span class="auth">(T in art. <span class="ar">تمر</span>, M, TA,)</span> or without <span class="ar">ء</span>, <span class="auth">(Ṣ, M, Ḳ, in art. <span class="ar">تمر</span>,)</span> and<span class="arrow"><span class="ar">أَمَرٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <em>There is not in it</em> <span class="auth">(i. e. in the house, <span class="ar">الدار</span>, M, A, TA)</span> <em>any one.</em> <span class="auth">(M, A, Ḳ, and T and Ṣ in art. <span class="ar">تمر</span>.)</span> You say also,<span class="arrow"><span class="ar long">بِلَادٌ خَلَآءٌ لَيْسَ فِيهَا تُومُرِىٌّ↓</span></span> <em>Vacant regions wherein is not any one.</em> <span class="auth">(Ṣ in art. <span class="ar">تمر</span>.)</span> <span class="arrow"><span class="ar">تُؤْمُرِىٌّ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">تُومُرِىٌّ↓</span></span> <span class="auth">(Ṣ in art. <span class="ar">تمر</span>)</span> and<span class="arrow"><span class="ar">تَأْمُورِىٌّ↓</span></span> and<span class="arrow"><span class="ar">تَأْمُرِيٌّ↓</span></span> <span class="auth">(M, Ḳ)</span> also signify <em>A man,</em> or <em>human being.</em> <span class="auth">(Ṣ,* M, Ḳ.)</span> You say, speaking of a beautiful woman,<span class="arrow"><span class="ar long">مَا رَأَيْتُ تُومُرِيَّا↓ أَحْسَنَ مِنْهَا</span></span> <em>I have not seen a human being,</em> or <em>creature, more beautiful than she:</em> <span class="auth">(Ṣ and M in art. <span class="ar">تمر</span>:)</span> and<span class="arrow"><span class="ar long">مَا رَأَيْتُ تُومُرِيَّا↓ أَحْسَنَ مِنْهُ</span></span> <span class="add">[<em>I have not seen a man more beautiful than he</em>]</span>. <span class="auth">(T and Ṣ in art. <span class="ar">تمر</span>.)</span> Accord. to some, they are used only in negative phrases; but accord. to others, they are also used in such as are affirmative. <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="taOomuwrN_C2">
					<p>Also <em>Anything:</em> as in the saying <span class="ar long">أَكَلَ الذِّئْبُ الشَّاةَ فَمَا تَرَكَ مِنْهَا تَامُورًا</span> <span class="add">[<em>The wolf ate the sheep,</em> or <em>goat, and left not of it anything</em>]</span>. <span class="auth">(T and Ṣ in art. <span class="ar">تمر</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="taOomuwrN_D1">
					<p><em>A child, young one,</em> or <em>fœtus</em> syn. <span class="ar">وَلَدٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="taOomuwrN_E1">
					<p>The <em>receptacle</em> (<span class="ar">وِعَآء</span>) <em>of the child, young one,</em> or <em>fœtus.</em> <span class="auth">(M in art. <span class="ar">تمر</span>, without <span class="ar">ء</span>; and Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E2</span>
				</div>
				<div class="sense" id="taOomuwrN_E2">
					<p><em>A</em> <span class="ar">وِعَآء</span> <span class="add">[<em>in the ordinary sense;</em> i. e. <em>a bag,</em> or <em>receptacle, for travelling-provisions and for goods or utensils, &amp;c.</em>]</span>. <span class="auth">(M, Ḳ.)</span> Hence the saying, <span class="ar long">أَنْتَ أَعْلَمُ بِتَأْمُورِكَ</span> <em>Thou art best acquainted with what thou hast with thee;</em> and <em>with thine own mind.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E3</span>
				</div>
				<div class="sense" id="taOomuwrN_E3">
					<p>Also, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">تَأْمُورَةٌ↓</span></span>, <span class="auth">(M, <span class="add">[in which the former is not given in the following senses,]</span> and Ḳ,)</span> or<span class="arrow"><span class="ar">تَامُورَةٌ↓</span></span>, <span class="auth">(Ṣ in art. <span class="ar">تمر</span>,)</span> <em>A ewer,</em> syn. <span class="ar">إِبْرِيقٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>for wine:</em> <span class="auth">(Ṣ:)</span> and, <span class="auth">(M, Ḳ,)</span> or, as some say, <span class="auth">(TA,)</span> <em>a</em> <span class="ar">حُقَّة</span> <span class="auth">(M, Ḳ, TA)</span> <em>in which wine is put.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E4</span>
				</div>
				<div class="sense" id="taOomuwrN_E4">
					<p>Also the first, <span class="auth">(M, Ḳ,)</span> or<span class="arrow">↓</span> third, <span class="auth">(T and Ṣ in art. <span class="ar">تمر</span>,)</span> The <em>chamber,</em> or <em>cell,</em> (<span class="ar">صَوْمَعَة</span>, T and M in art. <span class="ar">تمر</span>, without <span class="ar">ء</span>, and Ṣ and Ḳ, and <span class="ar">نامُوى</span>, M, Ḳ,) <em>of a monk.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E5</span>
				</div>
				<div class="sense" id="taOomuwrN_E5">
					<p>And hence, <span class="auth">(TA,)</span> the first, <span class="auth">(Ḳ,)</span> and<span class="arrow">↓</span> second, <span class="auth">(M, Ḳ,)</span> or<span class="arrow">↓</span> third, of these three words, <span class="auth">(T and Ṣ, in art. <span class="ar">تمر</span>,)</span> ‡ The <em>covert,</em> or <em>retreat, of a lion.</em> <span class="auth">(T, Ṣ, M, Ḳ.)</span> Whence, <span class="arrow"><span class="ar long">فُلَانٌ أَسَدٌ فِى تَامُورَتِهِ↓</span></span> ‡ <em>Such a one is a lion in his covert:</em> <span class="auth">(T and Ṣ in art. <span class="ar">تمر</span>:)</span> a saying borrowed from ʼAmr Ibn-Maadee-Kerib: <span class="auth">(T and Ṣ ibid:)</span> or, accord. to some, it means, <em>a lion in the greatness of his courage,</em> and <em>in his heart.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="taOomuwrN_F1">
					<p>Also <span class="auth">(i. e. the first only)</span> <em>Play,</em> or <em>sport, of girls</em> or <em> of boys.</em> <span class="auth">(Th, M in art. <span class="ar">تمر</span> without <span class="ar">ء</span>, and Ḳ.)</span></p>
				</div>
						<span type="dis">＝</span>
				<div class="sense" id="taOomuwrN_g1">
					<p><a href="#yaOomuwrN">See also <span class="ar">يَأْمُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tuWomuwrN">
				<h3 class="entry"><span class="ar">تُؤْمُورٌ</span></h3>
				<div class="sense" id="tuWomuwrN_A1">
					<p><span class="ar">تُؤْمُورٌ</span> <em>A sign,</em> or <em>mark, set up to show the way in a waterless desert;</em> <span class="auth">(Ḳ, TA;)</span> <em>consisting of stones piled up, one upon another:</em> <span class="auth">(TA:)</span> pl. <span class="ar">تَآمِيرُ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#OamarapN">See <span class="ar">أَمَرَةٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تُؤْمُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tuWomuwrN_B1">
					<p><a href="#taOomuwrN">See also <span class="ar">تَأْمُورٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOomuwrapN">
				<h3 class="entry"><span class="ar">تَأْمُورَةٌ</span></h3>
				<div class="sense" id="taOomuwrapN_A1">
					<p><span class="ar">تَأْمُورَةٌ</span>, and without <span class="ar">ء</span>: <a href="#taOomuwrN">see <span class="ar">تَأْمُورٌ</span></a>, in eight places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">تَأْمُورَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taOomuwrapN_A2">
					<p>Also The <em>pericardium;</em> the <em>integument</em> (<span class="ar">غِلَاف</span>) <em>of the heart.</em> <span class="auth">(Ṣ in art. <span class="ar">تمر</span>: there written without <span class="ar">ء</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOomuwrieBN">
				<h3 class="entry"><span class="ar">تَأْمُورِىٌّ</span></h3>
				<div class="sense" id="taOomuwrieBN_A1">
					<p><span class="ar">تَأْمُورِىٌّ</span>: <a href="#taOomuwrN">see <span class="ar">تَأْمُورٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYomarN">
				<h3 class="entry"><span class="ar">مِئْمَرٌ</span></h3>
				<div class="sense" id="miYomarN_A1">
					<p><span class="ar">مِئْمَرٌ</span> <em>Counsel; advice:</em> as in the saying, <span class="ar long">فُلَانٌ بَعِيدٌ مِنَ المِئْمَرِ قَرِيبٌ مِنَ المِئْبَرِ</span> <em>Such a one is far from counsel,</em> or <em>advice: near to calumny,</em> or <em>slander.</em> <span class="auth">(A.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWamBarN">
				<h3 class="entry"><span class="ar">مُؤَمَّرٌ</span></h3>
				<div class="sense" id="muWamBarN_A1">
					<p><span class="ar">مُؤَمَّرٌ</span> <em>Made,</em> or <em>appointed, commander, governor, lord, prince,</em> or <em>king:</em> <span class="auth">(Ṣ, M, Ḳ:*)</span> <em>made to have authority, power,</em> or <em>dominion:</em> <span class="auth">(T, M, Ḳ:)</span> in which latter sense it is explained by Khálid, as applied by Ibn-Mukbil to a spear. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مُؤَمَّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWamBarN_A2">
					<p>† A cane, or spear-shaft, <em>having a spearhead affixed to it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مُؤَمَّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="muWamBarN_A3">
					<p>† A spear-head <span class="auth">(T, TA)</span> <em>sharpened;</em> syn. <span class="ar">مُحَدَّدٌ</span>. <span class="auth">(T, M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مُؤَمَّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="muWamBarN_A4">
					<p><em>Distinguished,</em> or <em>defined,</em> (<span class="ar">مُحَدَّدٌ</span>,) <em>by signs,</em> or <em>marks:</em> <span class="auth">(TA:)</span> or, as some say, <span class="auth">(TA,)</span> <em>marked with a hot iron;</em> syn. <span class="ar">مُوْسُومٌ</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomuwrN">
				<h3 class="entry"><span class="ar">مَأْمُورٌ</span></h3>
				<div class="sense" id="maOomuwrN_A1">
					<p><span class="ar">مَأْمُورٌ</span> <span class="add">[pass. part. n. of <span class="ar">أَمَرَهُ</span>, q. v.]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مَأْمُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOomuwrN_A2">
					<p>It is said in a trad., <span class="auth">(Ṣ, &amp;c.,)</span> <span class="ar long">خَيْرُ المَالِ مُهْرَةٌ مَأْمُورَةٌ وَسِكَّةٌ مَأْبُورَةٌ</span> ‡ <em>The best of property are a prolific filly</em> <span class="add">[<em>and a row of palm-trees,</em> or perhaps <em>a tall palmtree, fecundated</em>]</span>; <span class="auth">(AZ, AʼObeyd, T, Ṣ, A, Ḳ;)</span> as though the filly were commanded <span class="add">[by God]</span> to be so: <span class="auth">(A, in which the epithet <span class="ar">مأمورة</span> thus used is said to be tropical:)</span> <span class="add">[or]</span> <span class="ar">مأمورة</span> is thus for the sake of conformity to <span class="ar">مأبورة</span>, and is originally <span class="ar">مُؤْمَرَةٌ</span>, <span class="auth">(Ṣ, M,* Ḳ,)</span> from <span class="ar long">آمَرَهَا ٱللّٰهُ</span>: <span class="auth">(TA:)</span> or it is a dial. var. of weak authority; <span class="auth">(Ḳ;)</span> though, accord. to AZ, it signifies <em>made to have abundant offspring,</em> from <span class="ar long">أَمَرَ ٱللّٰهُ المُهْرَةَ</span>, meaning “God made the filly to have abundant offspring,” <a href="#AmarahaA">a dial. var. of <span class="ar">آمَرَهَا</span></a>, as AʼObeyd also asserts it to be. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maMmiru">
				<h3 class="entry"><span class="ar">مَآمِرُ</span> / <span class="ar">مَآمِيرُ</span></h3>
				<div class="sense" id="maMmiru_A1">
					<p><span class="ar">مَآمِرُ</span> and <span class="ar">مَآمِيرُ</span>: <a href="#muWotamirN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotamirN">
				<h3 class="entry"><span class="ar">مُؤْتَمِرٌ</span></h3>
				<div class="sense" id="muWotamirN_A1">
					<p><span class="ar">مُؤْتَمِرٌ</span> <span class="add">[<em>Obeying,</em> or <em>conforming to, a command;</em>, &amp;c.: <a href="#Amr_8">see 8</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مُؤْتَمِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWotamirN_A2">
					<p>One <em>who acts according to his own opinion;</em> <span class="auth">(T;)</span> <em>who follows his own opinion only:</em> or <em>who hastes to speak.</em> <span class="auth">(M.)</span></p>
				</div>
				<span class="pb" id="Page_0099"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مُؤْتَمِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWotamirN_B1">
					<p><a href="#AmirN">See also <span class="ar">آمِرٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امر</span> - Entry: <span class="ar">مُؤْتَمِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="muWotamirN_B2">
					<p>Also, and <span class="ar">المُؤْتَمِرُ</span>, <span class="add">[<em>The month which is now commonly called</em>]</span> <span class="ar">المُحَرَّمُ</span>: <span class="auth">(M, Ḳ:)</span> the former appellation (<span class="ar">مؤتمر</span>) is that by which the tribe of 'Ád called it: <span class="auth">(Ibn-El-Kelbee:)</span> pl. <span class="arrow"><span class="ar">مَآمِرُ↓</span></span> and <span class="ar">مَآمِيرُ</span> <span class="add">[both anomalous]</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#XahorN">See <span class="ar">شَهْرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="yaOomuwrN">
				<h3 class="entry"><span class="ar">يَأْمُورٌ</span></h3>
				<div class="sense" id="yaOomuwrN_A1">
					<p><span class="ar">يَأْمُورٌ</span>; <span class="auth">(M, Ḳ;)</span> so in all the copies of the Ḳ but in the L and other lexicons, <span class="arrow"><span class="ar">تَأْمُورٌ↓</span></span>; <span class="auth">(TA;)</span> <em>A certain beast of the sea:</em> or, as some say, <em>a small beast:</em> <span class="auth">(M:)</span> and <em>a kind of mountain-goat:</em> <span class="auth">(M, Ḳ:)</span> or <em>a certain wild beast,</em> <span class="auth">(Ḳ, TA,)</span> or <em>a beast resembling the mountain-goat,</em> <span class="auth">(M,)</span> <em>having a single branching horn in the middle of his head.</em> <span class="auth">(M, TA.)</span> <span class="add">[<a href="#yaHomuwrN">See <span class="ar">يَحْمُورٌ</span></a>, the <em>oryx.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0095.pdf" target="pdf">
							<span>Lanes Lexicon Page 95</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0096.pdf" target="pdf">
							<span>Lanes Lexicon Page 96</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0097.pdf" target="pdf">
							<span>Lanes Lexicon Page 97</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0098.pdf" target="pdf">
							<span>Lanes Lexicon Page 98</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0099.pdf" target="pdf">
							<span>Lanes Lexicon Page 99</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
