<article class="root" id="Root_ArT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/056_ArD">ارض</a></span>
				<span class="ar">ارط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/058_Arf">ارف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ArT_1">
				<h3 class="entry"><span class="add">[<itype>1.</itype> <span class="new">{<span class="ar">أرط</span>}</span>]</span></h3>
				<div class="sense" id="ArT_1_A1">
					<p><span class="add">[<span class="ar">ارط</span> The unaugmented verb from this root seems to be unknown, if it were ever in use, for it is not mentioned, though the pass. part. n., <span class="ar">مَأْرُوطٌ</span>, is mentioned as having three significations, which see below.]</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="ArT_2">
				<h3 class="entry">2. ⇒ <span class="ar">ارّط</span></h3>
				<div class="sense" id="ArT_2_A1">
					<p><a href="#ArT_4">see 4</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArT_4">
				<h3 class="entry">4. ⇒ <span class="ar">آرط</span></h3>
				<div class="sense" id="ArT_4_A1">
					<p><span class="ar long">آرَطَتِ الأَرْضُ</span>, <span class="auth">(AHeyth, Ḳ,)</span> of the measure <span class="ar">أَفْعَلَت</span>, <span class="add">[originally]</span> with two alifs, <span class="auth">(TA,)</span> <span class="add">[aor. <span class="ar">يُؤْرِطُ</span>, inf. n. <span class="ar">إِيرَاطٌ</span>,]</span> <em>The land produced the kind of trees called</em> <span class="ar">أَرْطًى</span> <span class="add">[or <span class="ar">أَرْطَى</span>]</span>; <span class="auth">(AHeyth, Ḳ;)</span> as also <span class="ar">أَرْطَت</span>, inf. n. <span class="ar">إِرْطَآءٌ</span>; or this is a corruption, attributable to J: so says the author of the Ḳ, following AHeyth: but it is no corruption, for it is mentioned by the authors on verbs and by ISd and others; <span class="auth">(MF, TA;)</span> for instance, by AḤn, in his book on plants, and by IF, in the Mj: <span class="auth">(TA:)</span> <span class="add">[and J mentions it in its proper place, in art. <span class="ar">رطى</span>, as well as in the present art.:]</span> <span class="arrow"><span class="ar">أَرَّطَت↓</span></span>, with the <span class="ar">ر</span> musheddedeh, has also been found in the handwriting of certain of the men of letters; but this is a corruption. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OariTN">
				<h3 class="entry"><span class="ar">أَرِطٌ</span></h3>
				<div class="sense" id="OariTN_A1">
					<p><span class="ar">أَرِطٌ</span> <em>A colour like that of the</em> <span class="ar">أَرْطًى</span> <span class="add">[or <span class="ar">أَرْطَى</span>]</span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaroTFe">
				<h3 class="entry"><span class="ar">أَرْطًى</span></h3>
				<div class="sense" id="OaroTFe_A1">
					<p><span class="ar">أَرْطًى</span>, <span class="auth">(Mbr, Ṣ, Ḳ,)</span> of the measure <span class="ar">فَعْلًى</span>, because you say <span class="ar long">أَدِيمٌ مَأْرُوطٌ</span>, <span class="add">[explained below,]</span> <span class="auth">(Mbr, Ṣ,)</span> the alif <span class="auth">(Mbr, Ṣ, Ḳ)</span> ending it <span class="auth">(Mbr)</span> <span class="add">[written <span class="ar">ى</span>]</span> being a letter of quasi-coordination, <span class="auth">(Ṣ, Ḳ,)</span> not to denote the fem. gender, <span class="auth">(Mbr, Ṣ,)</span> its n. un. being <span class="ar">أَرْطَاةٌ</span>, <span class="auth">(Mbr, Ṣ, Ḳ,)</span> wherefore it is with tenween when indeterminate, but not when determinate: <span class="auth">(Ṣ, Ḳ:)</span> or it is of the measure <span class="ar">أَفْعَلٌ</span>, <span class="auth">(Mbr,* Ṣ,)</span> the last letter being radical, <span class="auth">(Mbr,)</span> because you say <span class="ar long">أَدِيمٌ مَرْطِيُّ</span>, <span class="auth">(Mbr, Ṣ,)</span> and in this case it should be mentioned among words with an infirm letter <span class="add">[for the last radical]</span>, and is with tenween both when determinate and when indeterminate; <span class="auth">(Ṣ;)</span> <span class="add">[but this is a mistake, for when it is determinate, it can be with tenween only if used as a proper name; therefore,]</span> IB observes, that if you make its last letter radical, its measure is <span class="ar">أَفْعَل</span>, and a word of this measure, if a subst., is imperfectly decl. when determinate, but perfectly decl. when indeterminate: <span class="auth">(TA:)</span> <span class="add">[the author of the Ḳ copies the error of the Ṣ, saying, “or its alif is radical,” <span class="auth">(meaning its last letter,)</span> “and in this case it is always with tenween;” and he adds, “or,” <span class="auth">(for which he should have said “and,”)</span> its measure is <span class="ar">أَفْعَل</span>: to all which it is necessary to add, that some of the grammarians hold it to be also of the measure <span class="ar">فَعْلَى</span>, ending with a fem. alif, and therefore assign to it no n. un.:]</span> <em>A kind of tree,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>of those growing in sands,</em> <span class="auth">(Ṣ, TA,)</span> <em>resembling the kind called</em> <span class="ar">عِضَاه</span>, <em>growing as a branch</em> <span class="add">[in the TA <span class="ar">عَصَبًا</span>, for which I read <span class="ar">غُضْنًا</span>,]</span> <em>from a single stem, to the height of the stature of a man, the leaves whereof are what are termed</em> <span class="ar">هَدَب</span> <span class="add">[q. v., and are included among those termed <span class="ar">خُوص</span>]</span>, <span class="auth">(AḤn, TA,)</span> <em>and its flower is like that of the</em> <span class="ar">خِلَاف</span> <span class="add">[or <em>salix ægyptia</em>]</span>, <span class="auth">(AḤn, Ḳ,)</span> <em>save in being smaller, the colour being one; and the odour thereof is pleasant: it grows in sands, and therefore the poets make frequent mention of the wild bulls' and cows' taking refuge among this and other trees of the sands, burrowing at their roots to hide themselves there, and to protect themselves from the heat and cold and rain, but not among the trees in hard ground, for burrowing in the sand is easy:</em> <span class="auth">(AḤn, TA:)</span> <em>its fruit is like the</em> <span class="ar">عُنَّاب</span> <span class="add">[or <em>jujube</em>]</span>, <em>bitter, and is eaten by camels in its fresh moist state, and its roots are red,</em> <span class="auth">(AḤn, Ḳ,)</span> <em>intensely red:</em> <span class="auth">(AḤn, TA:)</span> AḤn adds, a man of the Benoo-Asad informed me, that <em>the leaves</em> (<span class="ar">هَدَب</span>) <em>of the</em> <span class="ar">ارطى</span> <em>are red like the red pomegranate: its fruit also is red:</em> <span class="auth">(TA:)</span> the dual is <span class="ar">أَرْطَيَانِ</span>: <span class="auth">(AḤn, TA:)</span> and the pl. <span class="ar">أَرْطَيَاتٌ</span> and <span class="ar">أَرَاطَيِ</span> and <span class="ar">أَرَاطٍ</span>, <span class="auth">(AḤn, Ḳ,)</span> in the accus. case <span class="ar">أرَاطِى</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaroTawieBN">
				<h3 class="entry"><span class="ar">أَرْطَوِىٌّ</span></h3>
				<div class="sense" id="OaroTawieBN_A1">
					<p><span class="ar">أَرْطَوِىٌّ</span>: <a href="#OaroTaAwieBu">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaroTaAwieBu">
				<h3 class="entry"><span class="ar">أَرْطَاوِىُّ</span></h3>
				<div class="sense" id="OaroTaAwieBu_A1">
					<p><span class="ar">أَرْطَاوِىُّ</span>: <a href="#maOoruwTN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoruwTN">
				<h3 class="entry"><span class="ar">مَأْرُوطٌ</span></h3>
				<div class="sense" id="maOoruwTN_A1">
					<p><span class="ar">مَأْرُوطٌ</span> A hide <em>tanned with</em> <span class="ar">أَرْطًى</span>; <span class="auth">(Ṣ, Ḳ;)</span> i. e. <em>with the leaves thereof;</em> <span class="auth">(Ṣ in art. <span class="ar">رطى</span>;)</span> as also<span class="arrow"><span class="ar">مُؤَرْطًي↓</span></span>; <span class="auth">(TA;)</span> and so <span class="ar">مَرْطِيٌّ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارط</span> - Entry: <span class="ar">مَأْرُوطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOoruwTN_A2">
					<p>A camel <em>having a complaint from eating</em> <span class="ar">أَرْطًى</span>: <span class="auth">(L, Ḳ:*)</span> and a camel <em>that eats</em> <span class="ar">أَرْطًى</span>, <span class="auth">(AZ, Ṣ, Ḳ,)</span> <em>and keeps to it;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">أَرْطَوِىُّ↓</span></span> <span class="auth">(AZ, Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">أَرْطَاوِىٌّ↓</span></span>. <span class="auth">(Ibn-ʼAbbád, Ṣgh, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaroTFe">
				<h3 class="entry"><span class="ar">مُؤَرْطًى</span></h3>
				<div class="sense" id="muWaroTFe_A1">
					<p><span class="ar">مُؤَرْطًى</span>: <a href="#maOoruwTN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0049.pdf" target="pdf">
							<span>Lanes Lexicon Page 49</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
