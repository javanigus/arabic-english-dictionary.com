<article class="root" id="Root_Arz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/053_Arx">ارخ</a></span>
				<span class="ar">ارز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/055_ArX">ارش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OarozN">
				<span class="pb" id="Page_0047"></span>
				<h3 class="entry"><span class="ar">أَرْزٌ</span></h3>
				<div class="sense" id="OarozN_A1">
					<p><span class="ar">أَرْزٌ</span> and<span class="arrow"><span class="ar">أُرْزٌ↓</span></span> The <em>pine-tree;</em> syn. <span class="ar long">شَجَرُ الصَّنَوْبَرِ</span>: <span class="auth">(Ḳ:)</span> or this is called <span class="arrow"><span class="ar">أَرْرَةٌ↓</span></span>, and <span class="ar">أَرْزٌ</span> is the pl.: <span class="auth">(AʼObeyd, Ṣ:)</span> <span class="add">[or rather <span class="ar">أَرْزٌ</span> is a coll. gen. n., and <span class="ar">أَرْزَةٌ</span> is the n. un.:]</span> or the <em>male of that kind of tree;</em> <span class="auth">(AḤn, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَرْزَةٌ↓</span></span>; <span class="auth">(Ḳ;)</span> and the author of the Minháj adds, it is <em>that which does not produce fruit; but pitch</em> (<span class="ar">زِفْت</span>) <em>is extracted from its trunks and roots, and its wood is employed as a means of light, like as candles are employed; and it grows not in the land of the Arabs:</em> AʼObeyd says, <span class="arrow"><span class="ar">أَرْزَةٌ↓</span></span> is the <em>name of a tree well known in Syria, called with us</em> <span class="ar">صَنَوْبَرٌ</span>, <em>because of its fruit:</em> he says also, I have seen this kind of tree, called <span class="ar">أَرْزَةٌ</span>, and it is called in El-'Irák <span class="ar">صَنَوْبَرٌ</span>, but this last is the name of the fruit of the <span class="ar">أَرْز</span>: <span class="auth">(TA:)</span> or <em>i. q.</em> <span class="ar">عَرْعَرٌ</span> <span class="add">[a name given to the <em>cypress</em> and to the <em>juniper-tree</em>]</span>. <span class="auth">(Ḳ.)</span> It is said in a trad.,<span class="arrow"><span class="ar long">مَثَلُ الكَافِرِ مَثَلُ الأَرْزَةِ↓ المُجْذِيَةِ عَلَى الأَرْضِ حَتَّى يَكُونَ آنْجِعَافُهَا بِمَرَّةٍ وَاحِدَةٍ</span></span> <span class="add">[<em>The similitude of the unbeliever is the similitude of the pine-tree standing firmly upon the ground until it is pulled up at once</em>]</span>: respecting which AA and AO say that it is <span class="arrow"><span class="ar">الأَرَزَة↓</span></span>, with fet-ḥ to the <span class="ar">ر</span>; meaning the tree called <span class="ar">الأَرْزَن</span>: but AʼObeyd thinks this to be a mistake, and that it is <span class="arrow"><span class="ar">الأَرْزَة↓</span></span>, with the <span class="ar">ر</span> quiescent. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OurozN">
				<h3 class="entry"><span class="ar">أُرْزٌ</span></h3>
				<div class="sense" id="OurozN_A1">
					<p><span class="ar">أُرْزٌ</span>: <a href="#OarozN">see <span class="ar">أَرْزٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارز</span> - Entry: <span class="ar">أُرْزٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OurozN_B1">
					<p><a href="#OaruzBN">and see also <span class="ar">أَرُزٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaruzN">
				<h3 class="entry"><span class="ar">أَرُزٌ</span></h3>
				<div class="sense" id="OaruzN_A1">
					<p><span class="ar">أَرُزٌ</span>: <a href="#OaruzBN">see <span class="ar">أَرُزٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuruzN">
				<h3 class="entry"><span class="ar">أُرُزٌ</span></h3>
				<div class="sense" id="OuruzN_A1">
					<p><span class="ar">أُرُزٌ</span>: <a href="#OaruzBN">see <span class="ar">أَرُزٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OarozapN">
				<h3 class="entry"><span class="ar">أَرْزَةٌ</span></h3>
				<div class="sense" id="OarozapN_A1">
					<p><span class="ar">أَرْزَةٌ</span>: <a href="#OarozN">see <span class="ar">أَرْزٌ</span></a>, in five places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarazapN">
				<h3 class="entry"><span class="ar">أَرَزَةٌ</span></h3>
				<div class="sense" id="OarazapN_A1">
					<p><span class="ar">أَرَزَةٌ</span> The <em>tree called</em> <span class="ar">أَرْزَنٌ</span> <span class="add">[which is <em>a hard kind, from which staves are made</em>]</span>: <span class="auth">(AA, Ṣ, Ḳ:)</span> some say that it is <span class="arrow"><span class="ar">آرِزَةٌ↓</span></span>, of the measure <span class="ar">فَاعِلَةٌ</span>; but AʼObeyd disapproves of this. <span class="auth">(TA.)</span> <a href="#ArozN">See also <span class="ar">أرْزٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaruzBN">
				<h3 class="entry"><span class="ar">أَرُزٌّ</span></h3>
				<div class="sense" id="OaruzBN_A1">
					<p><span class="ar">أَرُزٌّ</span> and<span class="arrow"><span class="ar">أُرُزٌّ↓</span></span> and<span class="arrow"><span class="ar">أُرْزٌ↓</span></span> and<span class="arrow"><span class="ar">أُرُزٌ↓</span></span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَرُزٌ↓</span></span> and<span class="arrow"><span class="ar">آرُزٌ↓</span></span> <span class="auth">(Kr, Ḳ)</span> and <span class="ar">رُزٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">رُنْزٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> the first of which is the form commonly obtaining among persons of distinction; the last but one, that commonly obtaining among the vulgar; <span class="auth">(TA;)</span> and the last, of the dial. of 'AbdEl-Keys; <span class="auth">(Ṣ, TA;)</span> <span class="add">[<em>Rice;</em>]</span> <em>a certain grain,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>well known:</em> <span class="auth">(Ḳ:)</span> <span class="add">[said in the TA to be a species of <span class="ar">بُرّ</span>; but this is an improper explanation:]</span> <em>there are several kinds; Egyptian and Persian and Indian; and the best kind is the</em> <span class="ar">جوهرى</span> <span class="add">[perhaps a mistake for <span class="ar">مِصْرىّ</span>, or Egyptian]</span>: <em>it is cold and dry in the second degree;</em> or, as some say, <em>moderate;</em> or, as some say, <em>hot in the first degree; and its husk is poisonous.</em> <span class="auth">(El-Minháj, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuruzBN">
				<h3 class="entry"><span class="ar">أُرُزٌّ</span></h3>
				<div class="sense" id="OuruzBN_A1">
					<p><span class="ar">أُرُزٌّ</span>: <a href="#OaruzBN">see <span class="ar">أَرُزٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MruzN">
				<h3 class="entry"><span class="ar">آرُزٌ</span></h3>
				<div class="sense" id="MruzN_A1">
					<p><span class="ar">آرُزٌ</span>: <a href="#OaruzBN">see <span class="ar">أَرُزٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MrizapN">
				<h3 class="entry"><span class="ar">آرِزَةٌ</span></h3>
				<div class="sense" id="MrizapN_A1">
					<p><span class="ar">آرِزَةٌ</span>: <a href="#OarazapN">see <span class="ar">أَرَزَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0047.pdf" target="pdf">
							<span>Lanes Lexicon Page 47</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
