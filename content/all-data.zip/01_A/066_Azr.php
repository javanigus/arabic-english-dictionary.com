<article class="root" id="Root_Azr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/065_Azj">ازج</a></span>
				<span class="ar">ازر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/067_Azf">ازف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزر</span></h3>
				<div class="sense" id="Azr_1_A1">
					<p><span class="ar">أَزَرَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِرُ</span>}</span></add>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">أَزْرٌ</span>. <span class="auth">(IAạr, Ḳ,)</span> <em>It surrounded,</em> or <em>encompassed, it,</em> <span class="auth">(IAạr,* Ḳ,* TA,)</span> namely, a thing. <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Azr_1_A2">
					<p><a href="#Azr_2">See also 2</a>, in two places: <a href="#Azr_3">and see 3</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أزّر</span></h3>
				<div class="sense" id="Azr_2_A1">
					<p><span class="ar">أزّرهُ</span>, inf. n. <span class="ar">تَأْزِيرٌ</span>, <em>He put on him,</em> or <em>clad him with, an</em> <span class="ar">إِزَار</span>; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">أَزَرَهُ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Azr_2_A2">
					<p><em>It covered it:</em> <span class="auth">(Ḳ,* TA:)</span> as in the phrase, <span class="ar long">أزّر النَّبْتُ الأَرْضَ</span> <em>The herbage covered the ground,</em> or <em>land.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Azr_2_A3">
					<p>‡ <em>He repaired the lower part of it,</em> <span class="auth">(namely, a wall,)</span> <em>and thus made that part like an</em> <span class="ar">إِزَار</span>: <span class="auth">(Mgh, Mṣb:*)</span> <em>he cased</em> <span class="add">[<em>the lower part of</em>]</span> <em>it,</em> <span class="auth">(namely, a wall,)</span> <em>and thus strengthened it.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Azr_2_A4">
					<p>‡ <em>He strengthened him,</em> or <em>it;</em> <span class="auth">(Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">أَزَرَهُ↓</span></span>, <span class="auth">(Fr,)</span> inf. n. <span class="ar">أَزْرٌ</span> <span class="auth">(Fr, Ḳ.)</span> <span class="add">[<a href="#Azr_3">See also 3</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azr_3">
				<h3 class="entry">3. ⇒ <span class="ar">آزر</span></h3>
				<div class="sense" id="Azr_3_A1">
					<p><span class="ar">آزِرِهُ</span>, <span class="auth">(Fr, Ṣ, A, Mṣb,)</span> for which the vulgar say <span class="ar">وَازَرَهُ</span>, <span class="auth">(Fr, Ṣ,)</span> the latter an extr. form, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُؤَازَرَةٌ</span>; <span class="auth">(Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">أَزَرَهُ↓</span></span>; <span class="auth">(TA;)</span> <em>He aided, assisted,</em> or <em>helped, him;</em> <span class="auth">(Fr, Ṣ, A, Mṣb, Ḳ;*)</span> <em>and strengthened him.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#Azr_2">See also 2</a>.]</span> You say, <span class="ar long">آزَرْتُ الرَّخُلَ عَلَ فُلَانٍ</span> <em>I aided, assisted,</em> or <em>helped, and strengthened, the man against such a one.</em> <span class="auth">(Zj.)</span> And <span class="ar long">أَرَدْتُ كَذَا فَآزَرَنِى عَلَيْهِ فُلَانٌ</span> <em>I desired to do such a thing, and such a one aided, assisted,</em> or <em>helped, me to do it.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Azr_3_A2">
					<p><span class="ar long">آزَرَ الزَّرْعُ بَعْضُهُ بَعْضًا</span>, <span class="auth">(A,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> ‡ <em>The seed-produce became tangled,</em> or <em>luxuriant,</em> <span class="auth">(A, Ḳ,)</span> <em>one part reaching to another,</em> <span class="auth">(A,)</span> <em>and one part strengthening another;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar long">تأزّر↓ الزَّرْعُ</span></span>: <span class="auth">(TA:)</span> or<span class="arrow"><span class="ar long">تأزّر↓ النَّبْتُ</span></span> signifies <em>the herbage became tangled,</em> or <em>luxuriant, and strong.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Azr_3_A3">
					<p><span class="ar long">آزَرَ الشَّىْءُ الشَّىْءَ</span>, <span class="auth">(TA,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> <em>The thing equalled,</em> or <em>was equal to, the thing: the thing matched,</em> or <em>corresponded to, the thing.</em> <span class="auth">(Ḳ,* TA.)</span> In some copies of the Ḳ, in the place of <span class="ar">المُسَاوَاةُ</span>, is found <span class="ar">المُؤَاسَاةُ</span>: the former is the correct reading. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Azr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأزّر</span></h3>
				<div class="sense" id="Azr_5_A1">
					<p><a href="#Azr_8">see 8</a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Azr_5_A2">
					<p><a href="#Azr_3">and see also 3</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتزر</span></h3>
				<div class="sense" id="Azr_8_A1">
					<p><span class="ar">اِيتَزَرَ</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> originally <span class="ar">ٱئْتَزَرَ</span>, <span class="auth">(Mgh, Mṣb,)</span> and<span class="arrow"><span class="ar">تأزّر↓</span></span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">ايتزر بِالإِزَارِ</span>, and<span class="arrow"><span class="ar long">تأزَر↓ بِهِ</span></span>, <span class="auth">(Ḳ,)</span> <em>He put on,</em> or <em>wore, the</em> <span class="ar">إِزَارَ</span>: <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> <span class="ar">اِتَّزَرَ</span> is wrong, <span class="auth">(Nh,)</span> or vulgar, <span class="auth">(Mgh,)</span> and should not be said: it occurs in certain of the trads., but is probably a corruption of the relaters: <span class="auth">(Ḳ:)</span> or it is a correct form, <span class="add">[like <span class="ar">اتَّخَذَ</span>, &amp;c., (<a href="index.php?data=01_A/035_Axc">see art. <span class="ar">اخذ</span></a>,)]</span> <span class="auth">(Mṣb, MF,)</span> accord. to El-Karmánee and Ṣgh and others. <span class="auth">(MF.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazorN">
				<h3 class="entry"><span class="ar">أَزْرٌ</span></h3>
				<div class="sense" id="OazorN_A1">
					<p><span class="ar">أَزْرٌ</span> <em>Strength.</em> <span class="auth">(IAạr, Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">أَزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OazorN_A2">
					<p>And <span class="auth">(or as some say, TA)</span> <em>Weakness:</em> thus bearing two contr. significations. <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">أَزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OazorN_A3">
					<p>And The <em>back.</em> <span class="auth">(IAạr, Ṣ, Ḳ.)</span> <span class="ar long">اُشْدُدْ بِهِ أَزْرِى</span>, in the Ḳur <span class="add">[xx. 32]</span>, means <em>Strengthen Thou by him my back:</em> <span class="auth">(IAạr, Ṣ:)</span> or <em>confirm Thou by him my strength:</em> or <em>strengthen Thou by him my weakness.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">أَزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OazorN_A4">
					<p><em>Aid, assistance,</em> or <em>help.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">أَزْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OazorN_A5">
					<p>Also, <span class="auth">(Ṣ,)</span> or<span class="arrow"><span class="ar">أُزْرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> The <em>place,</em> <span class="auth">(Ḳ,)</span> or <em>part of</em> <span class="add">[<em>each of</em>]</span> <em>the two flanks,</em> <span class="auth">(Ṣ,)</span> <em>where the</em> <span class="ar">إِزَار</span> <em>is tied in a knot.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuzorN">
				<h3 class="entry"><span class="ar">أُزْرٌ</span></h3>
				<div class="sense" id="OuzorN_A1">
					<p><span class="ar">أُزْرٌ</span>: <a href="#OazorN">see <span class="ar">أَزْرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IizorN">
				<h3 class="entry"><span class="ar">إِزْرٌ</span></h3>
				<div class="sense" id="IizorN_A1">
					<p><span class="ar">إِزْرٌ</span>: <a href="#IizaArN">see <span class="ar">إِزَارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IizorapN">
				<h3 class="entry"><span class="ar">إِزْرَةٌ</span></h3>
				<div class="sense" id="IizorapN_A1">
					<p><span class="ar">إِزْرَةٌ</span> <em>Any particular mode,</em> or <em>manner, of putting on,</em> or <em>wearing, the</em> <span class="ar">إِزَار</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">إِنَّهُ لَحَسَنُ الإِزْرَةِ</span> <span class="add">[<em>Verily he has a good manner of putting on,</em> or <em>wearing, the</em> <span class="ar">ازار</span>]</span>. <span class="auth">(A.)</span> And <span class="ar long">اِيتَزَرَ إِزْرَةً حَسَنَةً</span> <em>He put on,</em> or <em>wore, the</em> <span class="ar">ازار</span> <em>in a good manner.</em> <span class="auth">(Ṣ.)</span> <span class="pb" id="Page_0053"></span>And it is said in a trad., <span class="ar long">إِزْرَةُ المُؤْمِنِ إِلَى نِصْفِ السَّاقِ وَلَا جُنَاحَ عَلَيْهِ فِيمَا بَيْنَهُ وَبَيْنَ الكَعْبَيْنِ</span> <span class="add">[<em>The believer's mode of wearing the</em> <span class="ar">ازار</span> <em>is</em> to have it reaching <em>to the middle of the shank; and there shall be no sin chargeable to him with respect to what is between that and the two ankles</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IizaArN">
				<h3 class="entry"><span class="ar">إِزَارٌ</span></h3>
				<div class="sense" id="IizaArN_A1">
					<p><span class="ar">إِزَارٌ</span>, masc. and fem., and<span class="arrow"><span class="ar">إِزَارَةٌ↓</span></span>, and<span class="arrow"><span class="ar">مِئْزَرٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">مِئْزَرَةٌ↓</span></span>, <span class="auth">(Lḥ,)</span> and<span class="arrow"><span class="ar">إِزْرٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A thing well known;</em> <span class="auth">(Ṣ, Mṣb;)</span> <span class="add">[<em>a waist-wrapper;</em>]</span> <em>a wrapper for covering,</em> or <em>which covers, the lower part of the body,</em> <span class="add">[<em>from the waist downwards, concealing the thighs, and generally the upper half, or more, of the shanks,</em> (<a href="#OazorN">see <span class="ar">أَزْرٌ</span></a>, or <span class="ar">أُزْرٌ</span>, and <span class="ar">إِزْرَةٌ</span>,)]</span> <em>not sewed:</em> or <em>such as is beneath the shoulders,</em> or <em>on the lower half of the body:</em> the <span class="ar">رِدَآءِ</span> is that which covers the upper half of the body; or that which is upon the shoulders and back; and this also is not sewed: each of these explanations is correct: <span class="auth">(MF:)</span> or <em>i. q.</em> <span class="ar">مِلْحَفَةٌ</span>: <span class="auth">(Ḳ:)</span> <span class="add">[in the present day, <span class="ar">إِزَار</span>, vulgarly pronounced <span class="ar">إِيزَار</span>, is also applied to <em>a woman's outer covering,</em> or <em>wrapper, of white calico;</em> described in my “Modern Egyptians:” and<span class="arrow"><span class="ar">مِئْزَرٌ↓</span></span>, to <em>a pair of drawers:</em> and app., in post-classical writings, to <em>anything resembling a waist-wrapper, worn on any part of the person, and in any manner; sometimes as a turban:</em>]</span> and <span class="ar">إِزَارٌ</span> also signifies <em>anything with which one is veiled, concealed,</em> or <em>covered:</em> <span class="auth">(Th, Ḳ:)</span> its pl. is <span class="ar">آزِرَةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> a pl. of pauc., <span class="auth">(Ṣ, Mṣb,)</span> and <span class="auth">(of mult., Ṣ, Mṣb)</span> <span class="ar">أُزُرٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">أُزْرٌ</span>, <span class="auth">(Ḳ,)</span> which is of the dial. of Temeem, or, accord. to MF, a contraction of <span class="ar">أُزُرٌ</span>: <span class="auth">(TA:)</span> and <a href="#myzr">the pl. of <span class="ar">مئزر</span></a> is <span class="ar">مَآزِرُ</span> <span class="auth">(Mṣb.)</span> You say,<span class="arrow"><span class="ar long">شَدَّ لِلأَمْرِ مِئْزَرَهُ↓</span></span> ‡ <em>He prepared himself for the thing, affair,</em> or <em>business.</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">شَدَّ المِئْزَرَ↓</span></span> ‡ <em>He abstained from sexual intercourse:</em> or <em>he prepared himself for religious service.</em> <span class="auth">(TA, from a trad.)</span> And <span class="ar long">اِخْضَرَّ إِزَارِى</span> ‡ (<em>The place of</em>) <em>my</em> <span class="ar">ازار</span> <em>became black:</em> or, rather, <em>became of a</em> <span class="add">[<em>blackish</em>]</span> <em>hue inclining to green:</em> because the hair when it first grows is of that hue. <span class="auth">(Ḥar p. 494.)</span> And <span class="ar long">دَارِى إِزَارِى</span> <span class="add">[<em>My house is my covering</em>]</span>: said by Es-Sarawee to IAạr, on the latter's expressing his surprise at the former's walking in his house naked. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">إِزَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IizaArN_A2">
					<p>‡ <em>Continence; chastity.</em> <span class="auth">(Ḳ, TA.)</span> You say, <span class="ar long">فُلَانٌ عَفِيفُ الإِ زَارِ</span>, and<span class="arrow"><span class="ar">المِئْزَرِ↓</span></span> ‡ <em>Such a one is continent, abstaining from women with whom it is unlawful to him to have commerce:</em> <span class="auth">(AʼObeyd:)</span> and in like manner, <span class="ar long">فُلَانٌ طَيّبُ الإِزَارِ</span>. <span class="auth">(TA in art. <span class="ar">حجز</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">إِزَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IizaArN_A3">
					<p>‡ One's <em>wife:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or one's <em>self:</em> <span class="auth">(IḲt, Suh:)</span> or one's <em>wife and family:</em> or one's <em>family and self.</em> <span class="auth">(TA.)</span> One says, <span class="ar long">فِدًى لَكَ إِزَارِى</span>‡ <em>May my wife be a ransom for thee:</em> <span class="auth">(Aboo-ʼOmar El-Jarmee, Ṣ:)</span> or <em>myself.</em> <span class="auth">(IḲt, Suh.)</span> And it is said in a trad. respecting the vow of allegiance made at the 'Akabeh, <span class="ar long">لَنَمْنَعَنَّكَ مِمَّا نَمْنَعُ مِنْهُ أُزُرَنَا</span> ‡ <em>We will assuredly defend thee from that from which we defend our wives and our families:</em> or <em>ourselves.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">إِزَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IizaArN_A4">
					<p>‡ <em>A ewe.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="#muwazBarapN">But see <span class="ar long">شَاةٌ مُؤَزَّرَةٌ</span></a>.]</span> And <span class="ar long">إِزَارْ إِزَارْ</span> is <em>A cry by which a ewe is called to be milked.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IizaArapN">
				<h3 class="entry"><span class="ar">إِزَارَةٌ</span></h3>
				<div class="sense" id="IizaArapN_A1">
					<p><span class="ar">إِزَارَةٌ</span>: <a href="#IizaArN">see <span class="ar">إِزَارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mzaru">
				<h3 class="entry"><span class="ar">آزَرُ</span> / <span class="ar">أَزْرَآءُ</span></h3>
				<div class="sense" id="Mzaru_A1">
					<p><span class="ar long">فَرَسٌ آزَرُ</span>, and <span class="ar">أَزْرَآءُ</span>, <span class="add">[which is the fem.,]</span> ‡ <em>A horse,</em> and <em>a mare, white in the hinder part,</em> <span class="auth">(A, TA,)</span> which is the place of the <span class="ar">إِزَار</span> of a man; <span class="auth">(TA;)</span> <span class="add">[i. e., it corresponds to the lower part of the body of a man:]</span> when the whiteness descends to the thighs, the epithet <span class="ar">مَسَرْوَلٌ</span> is employed: <span class="auth">(A:)</span> or the former signifies <em>a horse white in the thighs, and having his fore parts black,</em> or <em>of any colour:</em> <span class="auth">(AO, Ḳ:)</span> pl. <span class="ar">أُزْرٌ</span> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miYozarN">
				<h3 class="entry"><span class="ar">مِئْزَرٌ</span></h3>
				<div class="sense" id="miYozarN_A1">
					<p><span class="ar">مِئْزَرٌ</span>: <a href="#IizaArN">see <span class="ar">إِزَارٌ</span></a>, in five places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miYozarapN">
				<h3 class="entry"><span class="ar">مِئْزَرَةٌ</span></h3>
				<div class="sense" id="miYozarapN_A1">
					<p><span class="ar">مِئْزَرَةٌ</span>: <a href="#IizaArN">see <span class="ar">إِزَارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWazBarapN">
				<h3 class="entry"><span class="ar">مُؤَزَّرَةٌ</span></h3>
				<div class="sense" id="muWazBarapN_A1">
					<p><span class="ar long">شَاةٌ مُؤَزَّرَةٌ</span> ‡ <em>A ewe,</em> or <em>she-goat, that is</em> <span class="add">[<em>black in the hinder part</em>]</span> <em>as though attired with a black</em> <span class="ar">إِزَار</span>. <span class="auth">(A; <span class="add">[in which is added, <span class="ar long">وَيُقَالُ لَهَا إِزَارٌ</span>, which may mean, “and one says, She has an <span class="ar">ازار</span>;” or “and one calls her <span class="ar">ازار</span>;” but more probably the former is meant thereby;]</span> and Ḳ; <span class="add">[in which <span class="ar">نَعْجَةٌ</span>, “a ewe,” is put in the place of <span class="ar">شَاةٌ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازر</span> - Entry: <span class="ar">مُؤَزَّرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWazBarapN_A2">
					<p><span class="ar long">نَصْرٌ مُؤَزَّرٌ</span> ‡ <em>Aid</em> <span class="add">[<em>made</em>]</span> <em>effective and powerful:</em> <span class="auth">(Ḳ, TA:)</span> occurring in a trad. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOozuwraAtK">
				<h3 class="entry"><span class="ar">مَأْزُورَاتٍ</span></h3>
				<div class="sense" id="maOozuwraAtK_A1">
					<p><span class="ar">مَأْزُورَاتٍ</span> <a href="#maWozuwraAtK">for <span class="ar">مَوْزُورَاتٍ</span></a>: <a href="index.php?data=27_w/104_wzr">see art. <span class="ar">وزر</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0052.pdf" target="pdf">
							<span>Lanes Lexicon Page 52</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0053.pdf" target="pdf">
							<span>Lanes Lexicon Page 53</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
