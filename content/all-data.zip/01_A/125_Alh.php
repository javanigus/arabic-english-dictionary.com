<article class="root" id="Root_Alh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/124_Alms">المس</a></span>
				<span class="ar">اله</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/126_Alw">الو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alh_1">
				<h3 class="entry">1. ⇒ <span class="ar">أله</span></h3>
				<div class="sense" id="Alh_1_A1">
					<p><span class="ar">أَلَهَ</span>, <span class="auth">(Ṣ, and so in some copies of the Ḳ,)</span> with fet-ḥ, <span class="auth">(Ṣ,)</span> or <span class="ar">أَلِهَ</span>, <span class="auth">(Mgh, Mṣb, and so in some copies of the Ḳ,)</span> like <span class="ar">تَعِبَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَهُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">إِلَاهَةٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">أُلُوهَةٌ</span> and <span class="ar">أُلُوهِيَّپٌ</span>, <span class="auth">(Ḳ,)</span> <em>He served, worshipped,</em> or <em>adored;</em> syn. <span class="ar">عَبَدَ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> Hence the reading of I’Ab, <span class="add">[in the Ḳur vii. 124,]</span> <span class="ar long">وَيَذَرَكَ وَإِلَاهَتَكَ</span> <span class="add">[<em>And leave thee, and the service,</em> or <em>worship,</em> or <em>adoration, of thee;</em> instead of <span class="ar">وَآلِهَتَكَ</span> <em>and thy gods,</em> which is the common reading]</span>; for he used to say that Pharaoh was worshipped, and did not worship: <span class="auth">(Ṣ:)</span> so, too, says, Th: and IB says that the opinion of I’Ab is strengthened by the sayings of Pharaoh <span class="add">[mentioned in the Ḳur lxxix. 24 and xxviii. 38]</span>, “I am your lord the most high,” and “I did not know any god of yours beside me.” <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alh_1_B1">
					<p><span class="ar">أَلِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَهُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَلَهٌ</span>, <span class="auth">(Ṣ,)</span> <em>He was,</em> or <em>became, confounded,</em> or <em>perplexed, and unable to see his right course;</em> <span class="auth">(Ṣ, Ḳ;)</span> originally <span class="ar">وَلِهَ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Alh_1_B2">
					<p><span class="ar long">أَلِهَ عَلَى فُلَانٍ</span> <em>He was,</em> or <em>became, vehemently impatient,</em> or <em>affected with vehement grief,</em> or <em>he manifested vehement grief and agitation, on account of such a one;</em> <span class="auth">(Ṣ, Ḳ;)</span> like <span class="ar">وَلِهَ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Alh_1_B3">
					<p><span class="ar long">أَلِهَ إِلَيْهِ</span> <em>He betook himself to him by reason of fright</em> or <em>fear, seeking protection;</em> or <em>sought,</em> or <em>asked, aid,</em> or <em>succour, of him: he had recourse,</em> or <em>betook himself, to him for refuge, protection,</em> or <em>preservation.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Alh_1_B4">
					<p><span class="ar long">أَلِهَ بِالمَكَانِ</span> <em>He remained, stayed, abode,</em> or <em>dwelt, in the place.</em> <span class="auth">(MF.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Alh_1_C1">
					<p><span class="ar">أَلَهَهُ</span>, <span class="auth">(Ḳ,)</span> like <span class="ar">مَنَعَهُ</span>, <span class="auth">(TA,)</span> <span class="add">[in the CK <span class="ar">اَلِهَهُ</span>,]</span> <em>He protected him; granted him refuge; preserved, saved, rescued,</em> or <em>liberated, him; aided,</em> or <em>succoured, him;</em> or <em>delivered him from evil: he rendered him secure,</em> or <em>safe.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alh_2">
				<h3 class="entry">2. ⇒ <span class="ar">ألّه</span></h3>
				<div class="sense" id="Alh_2_A1">
					<p><span class="ar">تَأْلِيهٌ</span> <span class="add">[inf. n. of <span class="ar">أَلَّهَهُ</span> <em>He made him,</em> or <em>took him as, a slave; he enslaved him;</em>]</span> <em>i. q.</em> <span class="ar">تَعْبِيدٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alh_2_A2">
					<p><span class="add">[The primary signification of <span class="ar">أَلَّهَهُ</span> seems to be, <em>He made him to serve, worship,</em> or <em>adore.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اله</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Alh_2_A3">
					<p><span class="add">[Accord. to Freytag, besides having the former of the two meanings explained above, it signifies <em>He reckoned him among gods; held him to be a god; made him a god:</em> but he does not mention his authority.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alh_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّه</span></h3>
				<div class="sense" id="Alh_5_A1">
					<p><span class="ar">تألّه</span> <em>He devoted himself to religious services</em> or <em>exercises; applied himself to acts of devotion.</em> <span class="auth">(JK, Ṣ, Mṣb, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OulohaAniyBapN">
				<h3 class="entry"><span class="ar">أُلْهَانِيَّةٌ</span></h3>
				<div class="sense" id="OulohaAniyBapN_A1">
					<p><span class="ar">أُلْهَانِيَّةٌ</span>: <a href="#IilaAhapN">see <span class="ar">إِلَاهَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilRhN">
				<h3 class="entry"><span class="ar">إِلٰهٌ</span> / <span class="ar">إِلَاهٌ</span></h3>
				<div class="sense" id="IilRhN_A1">
					<p><span class="ar">إِلٰهٌ</span>, or <span class="ar">إِلَاهٌ</span>, <span class="add">[the former of which is the more common mode of writing the word,]</span> is of the measure <span class="ar">فعَالٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> like <span class="ar">كِتَابٌ</span> in the sense of <span class="ar">مَكْتُوبٌ</span>, and <span class="ar">بِسَاطٌ</span> in the sense of <span class="ar">مَبْسُوطً</span>, <span class="auth">(Mṣb,)</span> meaning<span class="arrow"><span class="ar">مَأْلُوهٌ↓</span></span> <span class="add">[<em>An object of worship</em> or <em>adoration;</em> i. e. <em>a god, a deity</em>]</span>; <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>anything that is taken as an object of worship</em> or <em>adoration, accord. to him who takes it as such:</em> <span class="auth">(Ḳ:)</span> with the article <span class="ar">ال</span>, properly, <em>i. q.</em> <span class="ar">ٱللّٰهُ</span>; <span class="add">[sec this word below;]</span> but applied by the believers in a plurality of gods to <em>what is worshipped</em> by them <em>to the exclusion of</em> <span class="ar">ٱللّٰه</span>: <span class="auth">(Mṣb:)</span> pl. <span class="ar">آلِهَةٌ</span>: <span class="auth">(Mṣb, TA:)</span> which signifies <em>idols:</em> <span class="auth">(JK, Ṣ, TA:)</span> in the Ḳ, this meaning is erroneously assigned to <span class="ar">إِلَاهَةٌ</span>: <span class="auth">(TA:)</span> <span class="add">[not so in the CK; but there, <span class="ar">الالِهَةُ</span> is put in a place where we should read <span class="ar">الإِلَاهَةُ</span>, or <span class="ar">إِلَاهَةُ</span> without the article:]</span> <a href="#IilaAhapN"><span class="arrow"><span class="ar">الإِلَاهَةُ↓</span></span></a> <span class="add">[is the fem. of <span class="ar">الإِلَاهُ</span>, and]</span> signifies <span class="add">[the <em>goddess:</em> and particularly]</span> <em>the serpent:</em> <span class="add">[<span class="auth">(a meaning erroneously assigned in the CK to <span class="ar">الآلِهَةُ</span>; as also other meanings here following:)</span> because it was a special object of the worship of some of the ancient Arabs:]</span> <span class="auth">(Ḳ:)</span> or <em>the great serpent:</em> <span class="auth">(Th:)</span> and <em>the</em> <span class="add">[<em>new moon;</em> or <em>the moon when it is termed</em>]</span> <span class="ar">هِلَال</span>: <span class="auth">(Th, Ḳ:)</span> and, <span class="auth">(Ṣ, Ḳ,)</span> as also<span class="arrow"><span class="ar">إِلَاهَةُ↓</span></span>, without <span class="ar">ال</span>, the former perfectly decl., and the latter imperfectly decl., <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">الأُلَاهَةُ↓</span></span>, <span class="auth">(IAạr, Ḳ,)</span> and<span class="arrow"><span class="ar">أُلَاهَةُ↓</span></span>, <span class="auth">(IAạr, TA,)</span> and<span class="arrow"><span class="ar">الأَلَاهَةُ↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="pb" id="Page_0083"></span><span class="add">[and app.<span class="arrow"><span class="ar">أَلَاهَةُ↓</span></span>,]</span> and<span class="arrow"><span class="ar">الأَلِيهَةُ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>the sun;</em> <span class="auth">(Ṣ, Ḳ;)</span> app. so called because of the honour and worship which they paid to it: <span class="auth">(Ṣ:)</span> or <em>the hot sun.</em> <span class="auth">(Th, TA.)</span> <span class="add">[<span class="ar">إِلهٌ</span> is the same as the Hebrew <span class="he">אֱלוׄהַ</span> and The Chaldee <span class="he">אֱלֶה</span>; and is of uncertain derivaTion: accord. To some,]</span> it is originally <span class="ar">وِلَاهٌ</span>, like as <span class="ar">إِشَاحٌ</span> is originally <span class="ar">وِشَاحٌ</span>; meaning that mankind yearn towards him who is thus called, <span class="add">[seeking protection or aid,]</span> in their wants, and humble themselves to him in their afflictions, like as every infant yearns towards its mother. <span class="auth">(TA.)</span> <span class="add">[See also the opinions, cited below, on the derivation of <span class="ar">ٱللّٰهُ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalaAhapu">
				<h3 class="entry"><span class="ar">أَلَاهَةُ</span> / <span class="ar">الأَلَاهَةُ</span></h3>
				<div class="sense" id="OalaAhapu_A1">
					<p><span class="ar">أَلَاهَةُ</span> and <span class="ar">الأَلَاهَةُ</span>: <a href="#IilhN">see <span class="ar">إِلهٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OulaAhapu">
				<h3 class="entry"><span class="ar">أُلَاهَةُ</span> / <span class="ar">الأُلَاهَةُ</span></h3>
				<div class="sense" id="OulaAhapu_A1">
					<p><span class="ar">أُلَاهَةُ</span> and <span class="ar">الأُلَاهَةُ</span>: <a href="#IilhN">see <span class="ar">إِلهٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اله</span> - Entry: <span class="ar">أُلَاهَةُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OulaAhapu_B1">
					<p><span class="ar">أُلَاهَةٌ</span>: <a href="#IilaAhapN">see <span class="ar">إِلَاهَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilaAhapN">
				<h3 class="entry"><span class="ar">إِلَاهَةٌ</span></h3>
				<div class="sense" id="IilaAhapN_A1">
					<p><span class="ar">إِلَاهَةٌ</span> <a href="#Alh_1">inf. n. of 1, q. v.</a> <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اله</span> - Entry: <span class="ar">إِلَاهَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IilaAhapN_B1">
					<p><em>Godship; divinity;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">أُلَاهَةٌ↓</span></span> <span class="auth">(CK <span class="add">[not found by me in any MṢ. copy of the Ḳ]</span>)</span> and<span class="arrow"><span class="ar">أُلْهَانِيَّةٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اله</span> - Entry: <span class="ar">إِلَاهَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="IilaAhapN_C1">
					<p><span class="ar">إِلَاهَةُ</span> and <span class="ar">الإِلَاهَةُ</span>: <a href="#IilhN">see <span class="ar">إِلهٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlOaliyhapu">
				<h3 class="entry"><span class="ar">الأَلِيهَةُ</span></h3>
				<div class="sense" id="AlOaliyhapu_A1">
					<p><span class="ar">الأَلِيهَةُ</span>: <a href="#IilhN">see <span class="ar">إِلهٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilRhieBN">
				<h3 class="entry"><span class="add">[<span class="ar">إِلٰهِىٌّ</span> / <span class="ar">إِلَاهِىٌّ</span>]</span></h3>
				<div class="sense" id="IilRhieBN_A1">
					<p><span class="add">[<span class="ar">إِلٰهِىٌّ</span>, or <span class="ar">إِلَاهِىٌّ</span>, <em>Of,</em> or <em>relating to, God</em> or <em>a god; divine; theological:</em> Hence, <span class="ar long">العِلْمُ الإِلهِىُّ</span> or <span class="ar">الإِلَاهِىٌّ</span>: <a href="#AlIilhiyBapu">see what next follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlIilRhiyBapu">
				<h3 class="entry"><span class="add">[<span class="ar">الإِلٰهِيَّةُ</span> / <span class="ar">الإِلَاهِيَّةُ</span>]</span></h3>
				<div class="sense" id="AlIilRhiyBapu_A1">
					<p><span class="add">[<span class="ar">الإِلٰهِيَّةُ</span>, or <span class="ar">الإِلَاهِيَّةُ</span>, <em>Theology; the science of the being and attributes of God, and of the articles of religious belief;</em> also termed <span class="ar long">عِلْمُ الإِلهِيَّاتِ</span> or <span class="ar">الإِلَاهِيَّاتِ</span>, and<span class="arrow"><span class="ar long">العِلْمُ الإِلهِىُّ↓</span></span> or <span class="ar">الإِلَاهِىُّ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="QllBRhu">
				<h3 class="entry"><span class="ar">ٱللّٰهُ</span></h3>
				<div class="sense" id="QllBRhu_A1">
					<p><span class="ar">ٱللّٰهُ</span>, <span class="add">[written with the disjunctive alif <span class="ar">اَللّٰهُ</span>, meaning <em>God,</em> i. e. <em>the only true god,</em>]</span> accord. to the most correct of the opinions respecting it, which are twenty in number, <span class="auth">(Ḳ,)</span> or more than thirty, <span class="auth">(MF,)</span> is a proper name, <span class="auth">(Mṣb, Ḳ,)</span> applied to <em>the Being who exists necessarily, by Himself, comprising all the attributes of perfection;</em> <span class="auth">(TA;)</span> a proper name denoting <em>the true god,</em> comprising all the excellent divine names; a unity comprising all the essences of existing things; <span class="auth">(Ibn-El-ʼArabee, TA;)</span> the <span class="ar">ال</span> being inseparable from it: <span class="auth">(Mṣb:)</span> not derived: <span class="auth">(Lth, Mṣb, Ḳ:)</span> or it is originally <span class="ar">إِلهٌ</span>, or <span class="ar">إِلَاهٌ</span>, <span class="auth">(Sb, AHeyth, Ṣ, Mṣb, Ḳ,)</span> of the measure <span class="ar">فِعَالٌ</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>, meaning <span class="ar">مَأْلُوهٌ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> with <span class="add">[the article]</span> <span class="ar">ال</span> prefixed to it, <span class="auth">(Sb, AHeyth, Ṣ, Mṣb,)</span> so that it becomes <span class="ar">الإِلَاهُ</span>, <span class="auth">(Sb, AHeyth, Mṣb,)</span> then the vowel of the hemzeh is transferred to the <span class="ar">ل</span> <span class="add">[before it]</span>, <span class="auth">(Mṣb,)</span> and the hemzeh is suppressed, <span class="auth">(Sb, AHeyth, Ṣ, Mṣb,)</span> so that there remains <span class="ar">ٱللّٰهُ</span>, or <span class="ar">الِلَاهُ</span>, after which the former <span class="ar">ل</span> is made quiescent, and incorporated into the other: <span class="auth">(Sb, AHeyth, Mṣb:)</span> the suppression of the hemzeh is for the purpose of rendering the word easy of utterance, on account of the frequency of its occurrence: and the <span class="ar">ال</span> is not a substitute for the hemzeh; for were it so, it would not occur therewith in <span class="ar">الإِلَاهُ</span>: <span class="auth">(Ṣ:)</span> so says J; but IB says that this is not a necessary inference, because <span class="ar">الإِلَاهُ</span> applies to God (<span class="ar">ٱللّٰهُ</span>) and also to the idol that is worshipped; whereas <span class="ar">ٱللّٰهُ</span> applies only to God; and therefore, in using the vocative form of address, one may say, <span class="ar long">يَا اَللّٰهُ</span> <span class="add">[<em>O God</em>]</span>, with the article <span class="ar">ال</span> and with the disjunctive hemzeh; but one may not say, <span class="ar long">يَا الإِلَاهُ</span> either with the disjunctive or with the conjunctive hemzeh: <span class="auth">(TA:)</span> Sb allows that it may be originally <span class="ar">لَاهٌ</span>: <a href="index.php?data=23_l/197_lyh">see art. <span class="ar">ليه</span></a>: <span class="auth">(Ṣ:)</span> some say that it is from <span class="ar">أَلِهَ</span>, either because minds are confounded, or perplexed, by the greatness, or majesty, of God, or because He is the object of recourse for protection, or aid, in every case: or from <span class="ar">أَلَهَهُ</span>, meaning “he protected him,”, &amp;c., as explained above: <a href="#Alh_1">see 1</a>, last sentence. <span class="auth">(TA.)</span> The <span class="ar">ال</span> is pronounced with the disjunctive hemzeh in using the vocative form of address <span class="add">[<span class="ar long">يَا اَللّٰهُ</span>]</span> because it is inseparably prefixed as an honourable distinction of this name; <span class="auth">(Ṣ;)</span> or because a pause upon the vocative particle is intended in honour of the name; <span class="auth">(Ṣ in art. <span class="ar">ليه</span>;)</span> and AAF says that it is also thus pronounced in a form of swearing; as in <span class="ar long">أَفَاَللّٰهِ لَتَفْعَلَنَّ</span> <span class="add">[an elliptical phrase, as will be shown below, meaning <em>Then, by God, wilt thou indeed do</em> such a thing?]</span>; though he denies its being thus pronounced because it is inseparable; regarding it as a substitute for the suppressed hemzeh of <span class="ar">الإِلَاهُ</span>: <span class="auth">(Ṣ in the present art.:)</span> Sb mentions this pronunciation in <span class="ar long">يَا اَللّٰهُ</span>; and Th mentions the pronunciation of <span class="ar long">يَا ٱللّٰهُ</span> also, with the conjunctive hemzeh: Ks, moreover, mentions, as used by the Arabs, the phrase <span class="ar long">يَلَهْ اَغْفِرْلِى</span> <span class="add">[<em>O God, forgive me</em>]</span>, for <span class="ar long">يَا ٱللّٰهُ</span>; but this is disapproved. <span class="auth">(ISd, TA.)</span> The word is pronounced in the manner termed <span class="ar">تَفْخِيم</span>, <span class="add">[i. e., with the broad sound of the lengthened fet-ḥ, and with a full sound of the letter <span class="ar">ل</span>,]</span> for the purpose of showing honour to it; but when it is preceded by a kesreh, <span class="add">[as in <span class="ar">بِٱللّٰهِ</span> <em>By God,</em> and <span class="ar long">بِسْمِ ٱللّٰهِ</span> <em>In the name of God,</em>]</span> it is pronounced in the <span class="add">[contr.]</span> manner termed <span class="ar">تَرْقِيق</span>: AḤát says that some of the vulgar say, <span class="ar">لَاوَٱللّٰهْ</span> <span class="add">[<em>No, by God</em>]</span>, suppressing the alif, which should necessarily be uttered, as in <span class="ar">الرَّحْمنُ</span>, which is in like manner written without alif; and he adds that some person has composed a verse in which the alif <span class="add">[in this word]</span> is suppressed, erroneously. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">اَللّٰهَ ٱللّٰهَ فِى كَذَا</span>, <span class="add">[a verb being understood,]</span> meaning <em>Fear ye God, fear ye God, with respect to such a thing.</em> <span class="auth">(Marginal note in a copy of the Jámiʼ eṣ-Ṣagheer. <span class="add">[See another ex. voce <span class="ar">كَرَّةٌ</span>.]</span>)</span> And <span class="ar long">اَللّٰهَ لَأَفْعَلَنَّ</span> and <span class="ar long">اَللّٰهِ لَأَفْعَلَنَّ</span> <span class="add">[<em>By God, I will assuredly do</em> such a thing]</span>: in the former is understood a verb significant of swearing; and in the latter, <span class="add">[or in both, for a noun is often put in the accus. case because of a particle understood,]</span> a particle <span class="add">[such as <span class="ar">بِ</span> or <span class="ar">وَ</span>]</span> denoting an oath. <span class="auth">(Bḍ in ii. 1.)</span> And <span class="ar long">لِلهِ مَا فَعَلْتُ</span>, meaning <span class="ar long">وَٱللّٰهِ مَا فَعَلْتُ</span> <span class="add">[<em>By God, I did not,</em> or <em>have not done,</em> such a thing]</span>. <span class="auth">(JK.)</span> And <span class="ar long">لِلّهِ دَرُّكَ</span> ‡ <em>To God be attributed thy deed!</em> <span class="auth">(A in art. <span class="ar">در</span>:)</span> or <em>the good that hath proceeded from thee!</em> or <em>thy good deed!</em> or <em>thy gift!</em> and <em>what is received from thee!</em> <span class="add">[and <em>thy flow of eloquence!</em> and <em>the like</em>]</span>: a phrase expressive of admiration of anything: <span class="auth">(TA in art. <span class="ar">در</span>:)</span> <span class="add">[when said to an eloquent speaker or poet, it may be rendered <em>divinely art thou gifted!</em>]</span>. And <span class="ar long">لِلّهِ دَرُّهُ</span> ‡ <em>To God be attributed his deed!</em> <span class="add">[&amp;c.]</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">در</span>.)</span> And <span class="ar long">لِلّهِ القَائِلُ</span> <span class="add">[meaning <em>To God be attributed</em> (<em>the eloquence of</em>) <em>the sayer!</em> or]</span> <em>how good,</em> or <em>beautiful, is the saying of the sayer,</em> or <em>of him who says</em> <span class="add">[such and such words]</span>! or it is like the phrase <span class="ar long">لِلّهِ دَرُّهُ</span>, meaning † <em>To God be attributed his goodness!</em> and <em>his pure action!</em> <span class="auth">(Ḥar p. 11.)</span> And <span class="ar long">لِلّهِ فُلَانٌ</span> <span class="add">[<em>To God be attributed</em> (<em>the excel-lence,</em> or <em>goodness,</em> or <em>deed,</em>, &amp;c., <em>of</em>) <em>such a one!</em>]</span> explained by Az as meaning <em>wonder ye at such a one: how perfect is he!</em> <span class="auth">(Ḥar ibid.)</span> <span class="add">[And <span class="ar long">لِلّهِ أَبُوكَ</span>: <a href="index.php?data=01_A/011_Abw">see art. <span class="ar">ابو</span></a>.]</span> And <span class="ar long">لَاهِ أَنْتَ</span>, meaning <span class="ar long">لِلّهِ أَنْتَ</span> <span class="add">[lit. <em>To God be thou attributed!</em> i. e. <em>to God be attributed thine excellence!</em> or <em>thy goodness!</em> or <em>thy deed!</em>, &amp;c.]</span>. <span class="auth">(JK.)</span> <span class="add">[Similar to <span class="ar">لِلّهِ</span>, thus used, is the Hebrew expression <span class="he">לֵאלׂהִים</span> after an epithet signifying “great” or the like.]</span> <span class="ar long">إِنَّالِلّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ</span>, in the Ḳur <span class="add">[ii. 151]</span>, said on the occasion of an affliction, means <em>Verily to God we belong,</em> as property and servants, He doing with us what He willeth, <em>and verily unto Him we return</em> in the ultimate state of existence, and He will recompense us. <span class="auth">(Jel.)</span> AZ mentions the phrase <span class="ar">الحَمْدُلَاهِ</span> <span class="add">[meaning <span class="ar">الحَمْدُلِلّهِ</span> <em>Praise be to God</em>]</span>: but this is not allowable in the Ḳur-án: it is only related as heard from the Arabs of the desert, and those not knowing the usage of the Ḳur-án. <span class="auth">(Az, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اله</span> - Entry: <span class="ar">ٱللّٰهُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="QllBRhu_A2">
					<p><span class="arrow"><span class="ar">اَللّهُمَّ↓</span></span> is an expression used in prayer; as also <span class="ar">لَاهُمَّ</span>; <span class="auth">(JK, Mṣb;)</span> meaning <span class="ar long">يَا اَللّٰهُ</span> <span class="add">[<em>O God</em>]</span>; the <span class="ar">م</span> being a substitute for <span class="add">[the suppressed vocative particle]</span> <span class="ar">يا</span>; <span class="auth">(Ṣ in art. <span class="ar">ليه</span>, and Bḍ in iii. 25;)</span> but one says also, <span class="ar long">يَا اَللّهُمَّ</span>, <span class="auth">(JK, and Ṣ ibid,)</span> by poetic licence: <span class="auth">(Ṣ ibid:)</span> or the meaning, accord. to some, is <span class="ar long">يَا اَللّٰهُ أُمَّنَا بِخَيْرٍ</span> <span class="add">[<em>O God, bring us good</em>]</span>; <span class="auth">(JK, and Bḍ ubi suprà;)</span> and hence the origin of the expression. <span class="auth">(Bḍ.)</span> You say also <span class="ar long">اَللّهُمَّ إِلَّا</span> <span class="add">[which may be rendered, inversely, <em>Unless, indeed;</em> or <em>unless, possibly</em>]</span>: the former word being thus used to denote that the exception is something very rare. <span class="auth">(Mṭr in the commencement of his Expos. of the Maḳámát of El-Ḥareeree, and Ḥar pp. 52 and 53.)</span> And <span class="ar long">اَللّهُمَّ نَعَمْ</span> <span class="add">[which may be rendered, inversely, <em>Yes, indeed;</em> or <em>yea, verily</em>]</span>: the former word being used in this case as corroborative of the answer to an interrogation, negative and affirmative. <span class="auth">(Ḥar p. 563.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AallBRhumBa">
				<h3 class="entry"><span class="ar">اَللّٰهُمَّ</span></h3>
				<div class="sense" id="AallBRhumBa_A1">
					<p><span class="ar">اَللّٰهُمَّ</span>: <a href="#AlBlAhu_A2">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOoluwhN">
				<h3 class="entry"><span class="ar">مَأْلُوهٌ</span></h3>
				<div class="sense" id="maOoluwhN_A1">
					<p><span class="ar">مَأْلُوهٌ</span>: <a href="#IilAhN">see <span class="ar">إِلٰهٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0082.pdf" target="pdf">
							<span>Lanes Lexicon Page 82</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0083.pdf" target="pdf">
							<span>Lanes Lexicon Page 83</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
