<article class="root" id="Root_Ayh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/181_Ayn">اين</a></span> 
				<span class="ar">ايه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=02_b/000_b">ب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ayh_2">
				<h3 class="entry">2. ⇒ <span class="ar">أيّه</span></h3>
				<div class="sense" id="Ayh_2_A1">
					<p><span class="ar long">ايّه بِهَا</span>, <span class="auth">(Ṣ, TA,)</span> and, accord. to some, <span class="ar">بِهِمْ</span> <span class="auth">(TA,)</span> and <span class="ar">بِهِ</span>, <span class="auth">(Ḳ,* TA,)</span> inf. n. <span class="ar">تَأْيِيهٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He cried out to,</em> or <em>shouted to, and called,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>them,</em> namely, camels, <span class="auth">(Ṣ, TA,)</span> and, accord. to some, horses, and men, <span class="auth">(TA,)</span> and <em>him,</em> <span class="auth">(Ḳ, TA,)</span> namely, a camel: <span class="auth">(TA:)</span> or <span class="ar long">ايّه به</span> signifies <em>he said to him,</em> namely, a man, and a horse, <span class="ar long">يَا وَيْهَاهْ</span> <span class="add">[<em>Ho! On!</em>]</span>: <span class="auth">(AʼObeyd:)</span> and <em>he said to him,</em> namely, a man, <span class="ar long">يَا أَيُّهَا الرَّجُلُ</span> <span class="add">[<em>O thou man</em>]</span>: <span class="auth">(Ḳ:)</span> or <em>he called him,</em> <span class="ar long">يا ايّها الرجل</span>: <span class="auth">(IAth:)</span> and <em>he cried out to him,</em> or <em>at him;</em> or <em>drove him away with crying</em> or <em>a cry;</em> namely, an object of the chase. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oayoha">
				<h3 class="entry"><span class="ar">أَيْهَ</span></h3>
				<div class="sense" id="Oayoha_A1">
					<p><span class="add">[<span class="ar">أَيْهَ</span> would seem to be <a href="#waYoha">a dial. var. of <span class="ar">وَيْهَ</span></a>; for it is said that]</span> <span class="ar">أَيْهَكَ</span> is syn. with <span class="ar">وَيْهَكَ</span>. <span class="auth">(Ḳ: <span class="add">[<a href="#waYoha">but see <span class="ar">وَيْهَ</span></a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايه</span> - Entry: <span class="ar">أَيْهَ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oayoha_B1">
					<p><span class="ar">أَيْهًا</span>: <a href="#OaYohaAta">see <span class="ar">أَيْهَاتَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iiyho">
				<h3 class="entry"><span class="ar">إِيهْ</span></h3>
				<div class="sense" id="Iiyho_A1">
					<p><span class="ar">إِيهْ</span>, with the <span class="ar">ه</span> quiescent, is a word used in chiding, or checking; meaning <span class="ar">حَسْبُكَ</span> <span class="add">[<em>Sufficient for thee</em> is such a thing;, &amp;c.]</span>. <span class="auth">(ISd, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايه</span> - Entry: <span class="ar">إِيهْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Iiyho_A2">
					<p><span class="ar">إِيهًا</span> signifies, <span class="auth">(Ṣ, Ḳ,)</span> as also <span class="ar">ايهَ</span>, <span class="auth">(Ḳ,)</span> a command to be silent, <span class="auth">(Ṣ, Ḳ,)</span> and to abstain; <span class="auth">(Ṣ, TA;)</span> i. e. <em>Be silent;</em> and <em>abstain,</em> or <em>desist:</em> <span class="auth">(TA:)</span> both are used in chiding, or checking: and <span class="ar">هِيهَ</span> is used in the place of <span class="ar">إِيهَ</span>. <span class="auth">(Lth, TA.)</span> You say <span class="add">[also,]</span> <span class="ar long">إِيهًا عَنَّا</span> <em>Be silent,</em> and <em>abstain from</em> <span class="add">[<em>troubling</em>]</span> <em>us.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">إِيهَا عَنِّى ٱلْآنَ</span> <em>Abstain thou from</em> <span class="add">[<em>Troubling</em>]</span> me now. <span class="auth">(AZ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايه</span> - Entry: <span class="ar">إِيهْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Iiyho_A3">
					<p><span class="ar">إِيهًا</span> also occurs as meaning <em>I hold that to be true, and approve it.</em> <span class="auth">(IAth, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايه</span> - Entry: <span class="ar">إِيهْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Iiyho_B1">
					<p><span class="ar">إِيهِ</span>, as also <span class="ar">إِيهَ</span> and <span class="ar">إِيهٍ</span>, is a word denoting a desire, or demand, for one to add, or to give, or do, more; <span class="auth">(Lth, Ḳ;)</span> and a desire for one to speak: <span class="auth">(Ḳ:)</span> it <span class="auth">(i. e. <span class="ar">إِيهِ</span>)</span> is an imperative verbal noun, <span class="auth">(Ṣ,)</span> indecl., with kesr for its termination: <span class="auth">(Ḳ:)</span> you say to a man, when you desire, or demand, his telling or saying more of a <span class="add">[certain]</span> story or subject of discourse, or his doing more of a <span class="add">[certain]</span> deed, <span class="ar">إِيهِ</span>, with kesr. to the <span class="ar">ه</span>; <span class="auth">(Ṣ;)</span> <span class="add">[i. e. <em>Tell me,</em> or <em>say, more of this; say on; go on,</em> or <em>proceed, with this;</em> or <em>do more of this;</em>]</span> and <span class="ar long">ٱفْعَلْ إِيهِ</span> <span class="add">[<em>Go on,</em> or <em>proceed, with this; do it</em>]</span>; <span class="auth">(AZ;)</span> and for <span class="ar">إِيهِ</span>, you say, <span class="ar">هِيهِ</span>: <span class="auth">(Lth:)</span> but when you make no interruption after it, you pronounce it with tenween, <span class="auth">(ISk, Ṣ, Ḳ,)</span> and say <span class="ar">إِيهٍ</span>, <span class="auth">(ISk, Ṣ,)</span> which means <span class="ar">حَدِّثْنَا</span> <span class="add">[i. e. <em>Tell us,</em> or <em>relate to us, something</em>]</span>; <span class="auth">(Ks, Lḥ, ISk,* Ṣ;*)</span> and for this one says <span class="ar">هِيهٍ</span>, by substitution of one letter for another: <span class="auth">(Ks, Lḥ:)</span> or it means <span class="ar">زِدْ</span> <span class="add">[i. e. <em>tell,</em> or <em>say,</em> or <em>do, something more</em>]</span>; and <span class="ar">هَاتِ</span> <span class="add">[i. e. <em>give,</em> or <em>relate, something</em>]</span>; <span class="auth">(Ḥar p. 592;)</span> and <span class="ar">تَكَلَّمَ</span> <span class="add">[i. e. <em>speak</em>]</span>. <span class="auth">(Idem p. 419.)</span> In the following saying of Dhu-r-Rummeh,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَقَفْنَا وَقُلْنَا إِيهِ عَنْ أُمِّ سَالِمٍ</span> *</div> 
						<div class="star">* <span class="ar long">وَمَا بَالُ تَكْلِيمِ الدِّيَارِ البَلَاقِعِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>We stopped, and we said, Tell us some tidings:</em> inform us (<span class="ar">أَخْبِرِينَا</span> being app. understood) <em>respecting Umm-Sálim: but what is the case</em> <span class="auth">(meaning what is the use)</span> <em>of speaking to the vacant dwellings?</em>]</span>, he has used the word without tenween, though making no interruption after it, because he intended a pause. <span class="auth">(ISk, Ṣ.)</span> Ibn-Es-Seree says, When you say, <span class="ar long">إِيهِ يَا رَجُلُ</span>, you only command him to tell you more of the subject of discourse known to you and him, as though you said, <span class="ar long">هَاتِ الحَدِيثَ</span> <span class="add">[<em>Give,</em> or <em>relate, the story,</em> or <em>narrative, O man</em>]</span>: but if you say, <span class="ar">إِيهٍ</span>, with tenween, it is as though you said, <span class="ar long">هَاتِ حَدِيثًا مَّا</span> <span class="add">[<em>Give,</em> or <em>relate, some story</em> or <em>narrative</em>]</span>, because the tenween renders indeterminate: and Dhu-rRummeh meant the tenween, but omitted it through necessity. <span class="auth">(Ṣ.)</span> Aṣ says that Dhu-rRummeh has committed a mistake; the expression of the Arabs being only <span class="ar">إِيهٍ</span> <span class="add">[in a case of this kind]</span>: ISd says, the truth is, that it is without tenween when determinate, and with tenween when indeterminate; and that Dhu-r-Rummeh asks the ruins to tell him more of a known story, as though he said, <em>Relate to us the story,</em> or <em>tell us the tidings:</em> <span class="auth">(TA:)</span> Aboo-Bekr Ibn-Es-Sarráj says, citing this verse, that <span class="ar">ايه</span> is not known in a case of this kind without tenween in any of the dialects; meaning that it is never conjoined with a following word unless it be with tenween. <span class="auth">(IB, TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayohaA">
				<span class="pb" id="Page_0140"></span>
				<h3 class="entry"><span class="ar">أَيْهَا</span></h3>
				<div class="sense" id="OayohaA_A1">
					<p><span class="ar">أَيْهَا</span>: <a href="#OaYohaAta">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayohaAta">
				<h3 class="entry"><span class="ar">أَيْهَاتَ</span></h3>
				<div class="sense" id="OayohaAta_A1">
					<p><span class="ar">أَيْهَاتَ</span> <em>i. q.</em> <span class="ar">هَيْهَاتَ</span> <span class="add">[<em>Far,</em> or <em>far from being believed</em> or <em>from the truth,</em> is such a thing: or <em>remoteness,</em> or <em>remoteness from being believed</em> or <em>from the truth, is to be attributed to such a thing.</em>]</span>: as also<span class="arrow"><span class="ar">أَيْهَانِ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">أَيْهَانَ↓</span></span>, <span class="auth">(Ḳ, TA, in the CK <span class="ar">اَيْهَانُ</span>,)</span> <span class="add">[and several other dial. vars., for which <a href="#haYohaAta">see <span class="ar">هَيْهَاتَ</span></a>,]</span> and<span class="arrow"><span class="ar">أَيْهَا↓</span></span>, <span class="auth">(TA; and so in some copies of the Ṣ and Ḳ; in other copies of these, <span class="arrow"><span class="ar">أَيْهًا↓</span></span>; <span class="add">[but the former is app. the right;]</span>)</span> with the <span class="ar">ن</span> <span class="add">[or the <span class="ar">ت</span>]</span> suppressed, <span class="auth">(TA,)</span> which is said in pronouncing <span class="add">[a thing]</span> to be remote <span class="add">[whether in a proper or a tropical sense]</span>: <span class="auth">(Ṣ, TA:)</span> Th explains <span class="arrow"><span class="ar">أَيْهَانِ↓</span></span> as meaning <span class="ar long">بَعِيدٌ ذٰلِكَ</span> AA explains it as meaning <span class="ar long">بَعُدَ ذٰلِكَ</span>, making it a verbal noun; and this is the correct explanation: <span class="auth">(TA:)</span> or the meaning is <span class="ar">البُعْدُ</span>, <span class="add">[as I have indicated above,]</span> <span class="auth">(Ḳ in art. <span class="ar">هيه</span>,)</span> but this is only when <span class="ar">لِ</span> is prefixed to what follows it, as Sb says. <span class="auth">(TA. <span class="add">[<a href="#haYohaAta">See <span class="ar">هَيْهَاتَ</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayohaAna">
				<h3 class="entry"><span class="ar">أَيْهَانَ</span> / <span class="ar">أَيْهَانِ</span></h3>
				<div class="sense" id="OayohaAna_A1">
					<p><span class="ar">أَيْهَانَ</span> and <span class="ar">أَيْهَانِ</span>: <a href="#OaYohaAta">see <span class="ar">أَيْهَاتَ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBihN">
				<h3 class="entry"><span class="ar">أَيِّهٌ</span></h3>
				<div class="sense" id="OayBihN_A1">
					<p><span class="ar">أَيِّهٌ</span> <em>Having a strong,</em> or <em>loud, voice; and vigilant,</em> or <em>wary.</em> <span class="auth">(Ḥam p. 675.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayBuhaA">
				<h3 class="entry"><span class="ar">أَيُّهَا</span></h3>
				<div class="sense" id="OayBuhaA_A1">
					<p><span class="ar">أَيُّهَا</span>: <a href="#OaeBN">see <span class="ar">أَىٌّ</span></a>; last portion of the paragraph.</p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0139.pdf" target="pdf">
							<span>Lanes Lexicon Page 139</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0140.pdf" target="pdf">
							<span>Lanes Lexicon Page 140</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
