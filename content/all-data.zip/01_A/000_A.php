<article class="root" id="Root_A">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="../../Preface.html">Preface</a></span>
				<span class="ar">ا</span>
				 <span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/001_Ab">اب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="A">
				<span class="pb" id="Page_0001"></span>
				<h3 class="entry"><span class="ar">ا</span></h3>
				<h4 class="entry">Arabic Letter <span class="ar">ا</span></h4>
				<div class="sense" id="A_A1">
					<p><em>The first letter of the alphabet</em><span class="add">[according to the order in which the letters are now commonly disposed; and also according to the original order, <a href="index.php?data=01_A/002_Abjd">which see in art. <span class="ar">ابجد</span></a>]</span>: called <span class="ar">أَلِفٌ</span>. <span class="add">[This name, like most of the other names of Arabic letters, is traceable to the Phœnician language, in which it signifies “an ox;” the ancient Phœnician form of the letter thus called being a rude representation of an ox's head.]</span> It is, of all the letters, that which is most frequent in speech: and some say that, in <span class="ar">آلٓمٓ</span>, in the Ḳur <span class="add">[ch. ii., &amp;c.]</span>, it is a name of God. <span class="auth">(TA.)</span> Its name is properly fem., as is also that of every other letter; <span class="add">[and hence its pl. is <span class="ar">أَلِفَاتٌ</span>;]</span> but it may be made masc.: so says Ks: Sb says that all the letters of the alphabet are masc. and fem., like as <span class="ar">اللِّسَانُ</span> is masc. and fem. <span class="auth">(M.)</span> As a letter of the alphabet, it is abbreviated, <span class="add">[or short, and is written <span class="ar">ا</span>, as it also is generally when occurring in a word, except at the end, when, in certain cases, it is written <span class="ar">ى</span>,]</span> and is pronounced with a pause after it: and it is also prolonged: <span class="auth">(Ṣ, Ḳ,* TA:)</span> <span class="add">[in the latter case, it is written <span class="ar">آءٌ</span>; and]</span> this is the case when it is made a subst.: and when it is not called a letter, <span class="add">[i. e. when one does not prefix to it the word <span class="ar">حَرْف</span>,]</span> it is <span class="add">[properly]</span> fem. <span class="auth">(Ṣ.)</span> Its dim. is <span class="ar">أُيَيَّةٌ</span>, meaning <em>an</em> <span class="ar">اء</span> <em>written small,</em> or <em>obscure,</em> <span class="auth">(Ṣ, IB,)</span> according to those who make it fem. and who say, <span class="ar long">زَيَّيْتُ زَايًا</span> and <span class="ar long">ذَيَّلْتُ ذَالًا</span>; but <span class="ar">أُوَيَّةٌ</span> according to those who say, <span class="ar long">زَوَّيْتُ زَايًا</span>. <span class="auth">(IB.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="A_B1">
					<p><span class="ar">أَلِفٌ</span> <span class="add">[properly so called]</span> is <em>one of the letters of prolongation</em> and <em>of softness</em> and <em>of augmentation;</em> the letters of augmentation being ten, which are comprised in the saying, <span class="ar long">ألْيَوْمَ تَنْسَاهُ</span> <span class="add">[“to-day thou wilt forget it”]</span>. <span class="auth">(Ṣ.)</span> There are two species of <span class="ar">الف</span>; namely, <span class="ar">لَيِّنَةٌ</span> <span class="add">[or <em>soft</em>]</span>, and <span class="ar">مُتَحَرِّكَةٌ</span> <span class="add">[or <em>movent</em>]</span>; the former of which is <span class="add">[properly]</span> called <span class="ar">أَلِفٌ</span>; and the latter, <span class="ar">هَمْزَةٌ</span>; <span class="auth">(Ṣ, TA;)</span> which is a faucial letter, pronounced in the furthest part of the fauces <span class="add">[by a sudden emission of the voice after a total suppression, so that it resembles in sound a feebly-uttered <span class="ar">ع</span> whence the form of the character (<span class="ar">ء</span>) whereby it is represented]</span>: but this latter is sometimes tropically called <span class="ar">الف</span>; and both <span class="add">[as shown above]</span> are of the letters of augmentation. <span class="auth">(Ṣ in art. <span class="ar">او</span>, and TA.)</span> There are also two other species of <span class="ar">الف</span>; namely, <span class="ar long">أَلِفُ وَصْلٍ</span> <span class="add">[<em>the alif of conjunction</em> or <em>connexion,</em> or <em>the conjunctive</em> or <em>connexive alif</em>]</span>; and <span class="ar long">أَلِفُ قَطْعٍ</span> <span class="add">[<em>the alif of disjunction,</em> or <em>the disjunctive alif</em>]</span>; every one that is permanent in the connexion of words being of the latter species; and that which is not permanent, <span class="add">[i. e. which is not pronounced, unless it is an alif of prolongation,]</span> of the former species; and this is without exception augmentative; <span class="add">[but it is sometimes a substitute for a suppressed radical letter, as in <span class="ar">ٱبْنٌ</span>, originally <span class="ar">بَنَىٌ</span> or <span class="ar">بَنَوٌ</span>;]</span> whereas the alif of disjunction is sometimes augmentative, as in the case of the interrogative alif <span class="add">[to be mentioned below, and in other cases]</span>; and sometimes radical, as in <span class="ar">أَخَذَ</span> and <span class="ar">أَمَرَ</span>: <span class="auth">(Ṣ, TA:)</span> or, according to Aḥmad Ibn-Yaḥyà and Moḥammad Ibn-Yezeed, <span class="auth">(T, TA,)</span> the primary <span class="ar">أَلِفَات</span> are three; the rest being subordinate to these: namely, <span class="ar long">أَلِفٌ أَصْلِيَّةٌ</span> <span class="add">[<em>radical alif</em>]</span>, <span class="auth">(T, Ḳ, TA,)</span> as in <span class="ar">إِلْفٌ</span> and <span class="ar">أَكَلَ</span> <span class="auth">(T)</span> and <span class="ar">أَخَذَ</span>; <span class="auth">(Ḳ;)</span> and <span class="ar long">أَلِفٌ قَطْعِيَّةٌ</span> <span class="add">[<em>disjunctive alif</em>]</span>, as in <span class="ar">أَحْمَدُ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">أَحْمَرُ</span> <span class="auth">(T)</span> and <span class="ar">أَحْسَنَ</span>; <span class="auth">(T, Ḳ;)</span> and <span class="ar long">أَلِفٌ وَصْلِيَّةٌ</span> <span class="add">[<em>conjunctive</em> or <em>connexive alif</em>]</span>, <span class="auth">(T, Ḳ,)</span> as in <span class="ar">ٱسْتِخْرَاجٌ</span> <span class="auth">(T)</span> and <span class="ar">ٱسْتَخْرَجَ</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="A_B2">
					<p>The <span class="ar">أَلِف</span> which is one of the letters of prolongation and of softness is called <span class="ar long">الأَلِفُ الهَادِئَةُ</span> <span class="add">[<em>the quiescent alif,</em> and <span class="ar long">الأَلِفُ السَّاكِنَةُ</span>, which signifies the same]</span>: <span class="auth">(MF, TA:)</span> it is an aerial letter, <span class="auth">(Mughnee, MF, TA,)</span> merely a sound of prolongation after a fet-ḥah; <span class="auth">(T, TA;)</span> and cannot have a vowel, <span class="auth">(IB, Mughnee, MF,)</span> wherefore it cannot commence a word: <span class="auth">(Mughnee:)</span> when they desire to make it movent, if it is converted from <span class="ar">و</span> or <span class="ar">ى</span>, they restore it to its original, as in <span class="ar">عَصَوَانِ</span> and <span class="ar">رَحَيَانِ</span>; and if it is not converted from <span class="ar">و</span> or <span class="ar">ى</span>, they substitute for it hemzeh, as in <span class="ar">رَسَائِلُ</span>, in which the hemzeh is a substitute for the <span class="ar">ا</span> in <span class="add">[the sing.]</span> <span class="ar">رِسَالَةٌ</span>. <span class="auth">(IB.)</span> IJ holds that the name of this letter is <span class="ar">لَا</span>, <span class="add">[pronounced <em>lá</em> or <em>lé,</em> without, or with, imáleh, like the similar names of other letters, as <span class="ar">بَا</span> and <span class="ar">تَا</span> and <span class="ar">ثَا</span>, &amp;c.,]</span> and that it is the letter which is mentioned <span class="add">[next]</span> before <span class="ar">ى</span> in reckoning the letters; the <span class="ar">ل</span> being prefixed to it because it cannot be pronounced at the beginning of its name, as other letters can, as, for instance, <span class="ar">ص</span> and <span class="ar">ج</span>; and he adds that the teachers <span class="add">[in schools]</span> err in pronouncing its name <span class="ar long">لَامَ ٱلِفْ</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="A_B3">
					<p>The grammarians have other particular appellations for alifs, which will be here mentioned. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="A_B4">
					<p><span class="ar long">الأَلِفُ المَجْهُولَةُ</span> <span class="add">[<em>The unknown alif</em>]</span> is such as that in <span class="ar">فَاعِلٌ</span> <span class="add">[or <span class="ar">فَاعَلَ</span>]</span> and <span class="ar">فَاعُولٌ</span>; i. e., every <span class="ar">ا</span>, <span class="auth">(T, Ḳ,)</span> of those having no original <span class="add">[from which they are converted, not being originally <span class="ar">أ</span> nor <span class="ar">و</span> nor <span class="ar">ى</span>, but being merely a formative letter, and hence, app., termed “unknown”]</span>, <span class="auth">(T,)</span> inserted for the purpose of giving fulness of sound to the fet-ḥah in a verb and in a noun; <span class="auth">(T, Ḳ;)</span> and this, when it becomes movent, becomes <span class="ar">و</span>, as in the case of <span class="ar">خَاتَمٌ</span> and <span class="ar">خَوَاتِمُ</span>, becoming <span class="ar">و</span> in this case because it is movent, and followed by a quiescent <span class="ar">ا</span>, which <span class="ar">ا</span> is the <span class="ar">ا</span> of the pl., and is also <span class="ar">مجهولة</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="A_B5">
					<p><span class="ar long">أَلِفَاتُ المَدَّاتِ</span> <span class="add">[<em>The alifs of prolongations</em>]</span> are such as those <span class="add">[which are inserted for the same purpose of giving fulness of sound to the fet-ḥah]</span> in <span class="ar">كَلْكَالٌ</span>, for <span class="ar">كَلْكَلٌ</span>, and <span class="ar">خَاتَامٌ</span>, for <span class="ar">خَاتَمٌ</span>, and <span class="ar">دَانَاقٌ</span>, for <span class="ar">دَانَقٌ</span>. <span class="auth">(T, Ḳ.)</span> In like manner, <span class="ar">و</span> is inserted after a ḍammeh, as in <span class="ar">أَنْظُورُ</span>; and <span class="ar">ى</span> after a kesreh, as in <span class="ar">شِيمَالٌ</span>. <span class="auth">(TA.)</span> An alif of this species is also called <span class="ar long">أَلِفُ الإِشْبَاعِ</span> <span class="add">[<em>The alif added to give fulness of sound</em> to a fet-ḥah preceding it]</span>: and so is the alif in <span class="ar">مَنَا</span> used in imitation <span class="add">[of a noun in the accus. case; as when one says, <span class="ar long">رَأَيْتُ رَجُلًا</span> <span class="auth">(pronounced <span class="ar">رَجُلَا</span>)</span> “I saw a man,” and the person to whom these words are addressed says, <span class="ar">مَنَا</span> <em>Whom?</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B6</span>
				</div>
				<div class="sense" id="A_B6">
					<p><span class="ar long">أَلِفُ الصِّلَةِ</span> <span class="add">[<em>The alif of annexation,</em> or <em>the annexed alif,</em>]</span> is that which is an annex to the fet-ḥah of a rhyme, <span class="auth">(T, Ḳ,)</span> and to that of the fem. pronoun <span class="ar">هَا</span>: in the former case as in</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بَانَتْ سُعَادُ وَأَمْسَى حَبْلُهَا ٱنْقَطَعَا</span> *</div> 
					</blockquote>
					<p>in which <span class="ar">ا</span> is made an annex to the fet-ḥah of the <span class="ar">ع</span> <span class="add">[of the rhyme]</span>; and in the saying in the Ḳur <span class="add">[xxxiii. 10]</span>, <span class="ar long">وَتَظُنُّونَ بِٱللّٰهِ الظُّنُونَا</span>, in which the <span class="ar">ا</span> after the last <span class="ar">ن</span> is an annex to the fet-ḥah of that <span class="ar">ن</span>; and in other instances in the final words of verses of the Ḳur-án, as <span class="ar">قَوَارِيرَا</span> and <span class="ar">سَلْسَبِيلَا</span> <span class="add">[in lxxvi. 15 and 18]</span>: in the other case as in <span class="ar">ضَرَبْتُهَا</span> and <span class="ar long">مَرَرْتُ بِهَا</span>. <span class="auth">(T.)</span> The difference between it and <span class="ar long">أَلِفُ الوَصْلِ</span> is, that the latter is in the beginnings of nouns and verbs, and the former is in the endings of nouns <span class="add">[and verbs]</span>. <span class="auth">(T, Ḳ.)</span> It is also called <span class="ar long">أَلِفُ الإِطْلَاقِ</span> <span class="add">[<em>The alif of unbinding,</em> because the vowel ending a rhyme prevents its being <span class="ar">مُقَيَّد</span>, i. e. “bound” by the preceding consonant]</span>: <span class="auth">(Mughnee;)</span> and <span class="ar long">أَلِفُ الفَاصِلَةِ</span> <span class="add">[<em>the alif of the final word of a verse of poetry</em> or <em>of a verse of the Ḳur-án</em> or <em>of a clause of rhyming prose</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[This last appellation must not be confounded with that which here next follows.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B7</span>
				</div>
				<div class="sense" id="A_B7">
					<p><span class="ar long">الأَلِفُ الفَاصِلَةُ</span> <span class="add">[<em>The separating alif</em>]</span> is the <span class="ar">ا</span> which is written after the <span class="ar">و</span> of the pl. to make a separation between that <span class="ar">و</span> and what follows it, as in <span class="ar">شَكَرُوا</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">كَفَرُوا</span>, and in the like of <span class="ar">يَغْزُوا</span> and <span class="ar">يَدْعُوا</span> <span class="add">[and <span class="ar">يَرْضَوْا</span>]</span>; but when a pronoun is affixed to the verb, this <span class="ar">ا</span>, being needless, does not remain: <span class="auth">(T:)</span> also the <span class="ar">ا</span> which makes a separation between the <span class="ar">ن</span> which is a sign of the fem. gender and the heavy <span class="add">[or doubled]</span> <span class="ar">ن</span> <span class="add">[in the corroborated form of the aor. and imperative]</span>, <span class="auth">(T, Ḳ,)</span> because a triple combination of <span class="ar">ن</span> is disliked, <span class="auth">(T,)</span> as in <span class="add">[<span class="ar">يَفْعَلْنَانِّ</span> and <span class="ar">تَفْعَلْنَانِّ</span> and]</span> <span class="ar">اِفْعَلْنَانِّ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar long">لَا تَفْعَلْنَانِّ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B8</span>
				</div>
				<div class="sense" id="A_B8">
					<p><span class="ar long">أَلِفُ النُّونِ الخَفِيفَةِ</span> <span class="add">[<em>The alif of the light,</em> or <em>single, noon</em> in the contracted corroborated form of the aor. and imperative]</span>, as in the phrase in the Ḳur <span class="add">[xcvi. 15]</span>, <span class="ar long">لَنَسْفَعًا بِالنَّاصِيَةِ</span> <span class="add">[<a href="index.php?data=12_s/132_sfE">explained in art. <span class="ar">سفع</span></a>]</span>, <span class="auth">(T, Ḳ,)</span> and the phrase <span class="add">[in xii. 32]</span>, <span class="ar long">وَلَيَكُونًا مِنَ الصَّاغِرِينَ</span> <span class="add">[<em>And he shall assuredly be of those in a state of vileness,</em> or <em>ignominy</em>]</span>, in both of which instances the pause is made with <span class="ar">ا</span> <span class="add">[only, without tenween, so that one says <span class="ar">لَنَسْفَعَا</span> and <span class="ar">لَيَكُونَا</span>, and this seems to be indicated in Expositions of the Ḳur-án as the proper pronunciation of these two words in the phrases here cited, the former of which, and the first word of the latter, I find thus written in an excellent copy of the Mughnee, with a fet-ḥah only instead of tenween, though I find them written in copies of the Ḳur-án and of the Ḳ with tenween, and for this reason only I have written them therewith in the first places above]</span>, <span class="pb" id="Page_0002"></span>this <span class="ar">ا</span> being a substitute for the light <span class="ar">ن</span>, which is originally the heavy <span class="ar">ن</span>: and among examples of the same is the saying of El-Aạshà,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَلَاتَحْمَدِ المُثْرِينَ وَٱللّٰهَ فَٱحْمَدَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And praise not thou the opulent, but God do thou praise</em>]</span>, the poet meaning <span class="ar">فَٱحْمَدَنْ</span>, but pausing with an <span class="ar">ا</span>: <span class="auth">(T:)</span> and accord. to ʼIkrimeh Ed-Ḍabbee, in the saying of Imra-el-Ḳeys,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قِفَا نَبْكِ مِنْ ذِكْرَى حَبِيبٍ وَمَنْزِلِ</span> *</div> 
					</blockquote>
					<p><span class="add">[what is meant is, <em>Do thou pause that we may weep by reason of the remembrance of an object of love, and of a place of abode,</em> for]</span> the poet means <span class="ar">قِفَنْ</span>, but substitutes <span class="ar">ا</span> for the light <span class="ar">ن</span>; <span class="auth">(TA;)</span> or, accord. to some, <span class="ar">قفا</span> is in this case <span class="add">[a dual]</span> addressed to the poet's two companions. <span class="auth">(EM p. 4.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B9</span>
				</div>
				<div class="sense" id="A_B9">
					<p><span class="ar long">أَلِفُ العِوَضِ</span> <span class="add">[<em>The alif of exchange</em>]</span> is that which is substituted for the tenween <span class="auth">(T, Ḳ)</span> of the accus. case when one pauses upon it, <span class="auth">(T,)</span> as in <span class="ar long">رَأَيْتُ زَيْدَا</span> <span class="auth">(T, Ḳ <span class="add">[and so in the copy of the Mughnee mentioned above, but in the copies of the T I find <span class="ar">زَيْدًا</span>,]</span>)</span> and <span class="ar long">فَعَلْتُ خَيْرَا</span> and the like. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B10</span>
				</div>
				<div class="sense" id="A_B10">
					<p><span class="ar long">أَلِفُ التَّعَايِى</span> <span class="add">[<em>The alif of inability to express what one desires to say</em>]</span>, <span class="auth">(T,)</span> or <span class="ar long">أَلِفُ التَّغَابِى</span> <span class="add">[<em>the alif of feigning negligence</em> or <em>heedlessness</em>]</span>, <span class="auth">(Ḳ,)</span> <span class="add">[but the former is evidently, in my opinion, the right appellation,]</span> is that which is added when one says <span class="ar long">إِنَّ عُمَرَ</span>, and then, being unable to finish his saying, pauses, saying <span class="ar long">إِنَّ عُمَرَا</span>, <span class="add">[in the CK <span class="ar">عُمَرَآ</span>,]</span> prolonging it, desiring to be helped to the speech that should reveal itself to him, <span class="auth">(T, Ḳ,)</span> and at length saying <span class="ar">مُنْطَلِقٌ</span>, meaning to say, if he were not unable to express it, <span class="ar long">إِنَّ عُمَرَ مُنْطَلِقٌ</span> <span class="add">[<em>Verily ʼOmar is going away</em>]</span>. <span class="auth">(T.)</span> The <span class="ar">ا</span> in a case of this kind is <span class="add">[also]</span> said to be <span class="ar">لِلتَّذَكُّرِ</span> <span class="add">[<em>for the purpose of endeavouring to remember</em>]</span>; and in like manner, <span class="ar">و</span>, when one desires to say, <span class="ar long">يَقُومُ زَيْدٌ</span>, and, forgetting <span class="ar">زيد</span>, prolongs the sound in endeavouring to remember, and says <span class="ar">يَقُومُو</span>. <span class="auth">(Mughnee in the sections on <span class="ar">ا</span> and <span class="ar">و</span>.)</span> It is also added to a curtailed proper name of a person called to, or hailed, as in <span class="ar long">يَا عُمَا</span> for <span class="ar long">يَا عُمَرُ</span> <span class="add">[which is an ex. contrary to rule, as <span class="ar">عُمَرُ</span> is masc. and consists of only three letters]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B11</span>
				</div>
				<div class="sense" id="A_B11">
					<p><span class="ar long">أَلِفُ النُّدْبَةِ</span> <span class="add">[<em>The alif of lamentation</em>]</span>, as in <span class="ar long">وَا زَيْدَاهْ</span> <span class="add">[<em>Alas, Zeyd!</em>]</span>, <span class="auth">(T, Ḳ,)</span> i. e. the <span class="ar">ا</span> after the <span class="ar">د</span>; <span class="auth">(T;)</span> and one may say <span class="ar long">وَا زَيْدَا</span>, without the <span class="ar">ه</span> of pausation. <span class="auth">(Alfeeyeh of Ibn-Málik, and I’Aḳ p. 272.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B12</span>
				</div>
				<div class="sense" id="A_B12">
					<p><span class="ar long">أَلِفُ الٱِسْتِنْكَارِ</span> <span class="add">[<em>The alif of disapproval</em>]</span>, <span class="auth">(T,)</span> or <span class="ar long">الأَلِفُ لِلْإِنْكَارِ</span> <span class="add">[which means the same]</span>, <span class="auth">(Mughnee,)</span> is similar to that next preceding, as in <span class="ar long">أَأَبُو عُمَرَاهْ</span> <span class="add">[<em>What! Aboo-ʼOmar?</em>]</span> in reply to one who says, “Aboo-ʼOmar came;” the <span class="ar">ه</span> being added in this case after the letter of prolongation like as it is in <span class="ar long">وَا فُلَانَاهْ</span> said in lamentation. <span class="auth">(T.)</span> <span class="add">[The ex. given in the Mughnee is <span class="ar long">آ عَمْرَاهْ</span>, as said in reply to one who says, “I met ʼAmr;” and thus I find it written, with <span class="ar">آ</span>; but this is a mistranscription of the interrogative <span class="ar">أَ</span>, which <a href="#A_D1">see below</a>.]</span> In this case it is only added to give fulness of sound to the vowel; for you say, <span class="ar">أَلرَّجُلُوهْ</span> <span class="add">[<em>What! the man?</em> for <span class="ar">أَٱلرَّجُلُوهْ</span>,]</span> after one has said “The man stood;” and <span class="ar">أَلرَّجُلَاهْ</span> in the accus. case; and <span class="ar">أَلرَّجُلِيهْ</span> in the gen. case. <span class="auth">(Mughnee in the section on <span class="ar">و</span>. <span class="add">[But in my copy of that work, in these instances, the incipient <span class="ar">ا</span>, which is an <span class="ar">ا</span> of interrogation, is written <span class="ar">آ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B13</span>
				</div>
				<div class="sense" id="A_B13">
					<p><span class="ar long">الأَلِفُ المُنْقَلِبَةُ عَنْ يَآءِ الإِضَافَةِ</span> <span class="add">[<em>The alif that is converted from the affixed pronoun</em> <span class="ar">ى</span>]</span>, as in <span class="ar long">يَا غُلَامَا أَقْبِلْ</span> <span class="add">[<em>O my boy, advance thou,</em>]</span> for <span class="ar long">يَا غُلَامِى</span>; <span class="auth">(TA in art. <span class="ar">حرز</span>;)</span> <span class="add">[and <span class="ar long">يَاعَجَبَا لِزَيْدٍ</span> <span class="auth">(I’Aḳ p. 271)</span> <em>O my wonder at Zeyd!</em> for <span class="ar long">يا عَجَبِى لزيد</span>;]</span> and in <span class="ar long">يَا أَبَتَا</span> for <span class="ar long">يَا أَبَتِى</span>, and <span class="ar long">يَا وَيْلَتَا</span> for <span class="ar long">يَا وَيْلَتِى</span>, and <span class="ar">يَابِأَبَا</span> and <span class="ar long">يَا بِأَبَاهْ</span> for <span class="ar long">يَا بِأَبِى</span> <span class="auth">(T and TA in art. <span class="ar">بأ</span>.)</span> <span class="add">[This is sometimes written <span class="ar">ى</span>, but preceded by a fet-ḥah.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B14</span>
				</div>
				<div class="sense" id="A_B14">
					<p><span class="ar long">الأَلِفُ المُحَوَّلَةُ</span> <span class="add">[<em>The transmuted alif,</em> in some copies of the Ḳ <span class="ar long">أَلِفُ المُحَوَّلَةِ</span>, which, as MF observes, is put for the former,]</span> is every <span class="ar">ا</span> that is originally <span class="ar">و</span> or <span class="ar">ى</span> <span class="auth">(T, Ḳ)</span> movent, <span class="auth">(T,)</span> as in <span class="ar">قَالَ</span> <span class="add">[originally <span class="ar">قَوَلَ</span>]</span>, and <span class="ar">بَاعَ</span> <span class="add">[originally <span class="ar">بَيَعَ</span>]</span>, <span class="auth">(T, Ḳ,)</span> and <span class="ar">غَزَا</span> <span class="add">[originally <span class="ar">غَزَوَ</span>]</span>, and <span class="ar">قَضَى</span> <span class="add">[originally <span class="ar">قَضَىَ</span>]</span>, and the like of these. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B15</span>
				</div>
				<div class="sense" id="A_B15">
					<p><span class="ar long">أَلِفُ التَّثْنِيَةِ</span> <span class="add">[<em>The alif of the dual,</em> or rather, <em>of dualization</em>]</span>, <span class="auth">(T, Ḳ,)</span> in verbs, <span class="auth">(TA,)</span> as in <span class="ar">يَجْلِسَانِ</span> and <span class="ar">يَذْهَبَانِ</span>, <span class="auth">(T, Ḳ,)</span> and in nouns, <span class="auth">(T,)</span> as in <span class="ar">الزَّيْدَانِ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">العَمْرَانِ</span>; <span class="auth">(T;)</span> <span class="add">[i. e.]</span> the <span class="ar">ا</span> which in verbs is a dual pronoun, as in <span class="ar">فَعَلَا</span> and <span class="ar">يَفْعَلَانِ</span>, and in nouns a sign of the dual and an indication of the nom. case, as in <span class="ar">رَجُلَانِ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B16</span>
				</div>
				<div class="sense" id="A_B16">
					<p>It is also indicative of the accus. case, as in <span class="ar long">رَأَيْتُ فَاهُ</span> <span class="add">[<em>I saw his mouth</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B17</span>
				</div>
				<div class="sense" id="A_B17">
					<p><span class="ar long">أَلِفُ الجَمْعِ</span> <span class="add">[<em>The alif of the plural,</em> or <em>of pluralization</em>]</span>, as in <span class="ar">مَسَاجِدُ</span> and <span class="ar">جِبَالٌ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">فُرْسَانٌ</span> and <span class="ar">فَوَاعِلُ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B18</span>
				</div>
				<div class="sense" id="A_B18">
					<p><span class="ar long">أَلِفُ التَّأْنِيثِ</span> <span class="add">[<em>The alif denoting the fem. gender</em>]</span>, as in <span class="ar">حُبْلَى</span> <span class="auth">(Mughnee, Ḳ)</span> and <span class="ar">سَكْرَى</span> <span class="add">[in which it is termed <span class="ar">مَقْصُورَة</span> <em>shortened</em>]</span>, and the meddeh in <span class="ar">حَمْرَآءُ</span> <span class="auth">(Ḳ)</span> and <span class="ar">بَيْضَآءُ</span> and <span class="ar">نُفَسَآءُ</span> <span class="add">[in which it is termed <span class="ar">مَمْدُودَة</span> <em>lengthened</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B19</span>
				</div>
				<div class="sense" id="A_B19">
					<p><span class="ar long">أَلِفُ الإِلْحَاقِ</span> <span class="add">[<em>The alif of adjunction,</em> or <em>quasi-coordination; that which renders a word an adjunct to a particular class,</em> i. e. <em>quasi-coordinate to another word, of which the radical letters are more in number than those of the former word,</em> <span class="auth">(see the sentence next following,)</span>]</span>, <span class="auth">(Mughnee, TA,)</span> as in <span class="ar">أَرْطًا</span> <span class="auth">(Mughnee)</span> <span class="add">[or <span class="ar">أَرْطًى</span>; and the meddeh in <span class="ar">عِلْبَآءٌ</span>, &amp;c.]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B20</span>
				</div>
				<div class="sense" id="A_B20">
					<p><span class="ar long">أَلِفُ التَّكْثِيرِ</span> <span class="add">[<em>The alif of multiplication,</em> i. e. <em>that merely augments the number of the letters of a word without making it either fem.</em> or <em>quasi-coordinate to another, unaugmented, word</em>]</span>, as in <span class="ar">قَبَعْثَرَى</span> <span class="auth">(Mughnee, TA)</span> <span class="add">[correctly <span class="ar">قَبَعْثَرًى</span>]</span>, in which the <span class="ar">ا</span> <span class="add">[here written <span class="ar">ى</span>]</span> is not to denote the fem. gender, <span class="auth">(Ṣ and Ḳ in art. <span class="ar">قبعثر</span>,)</span> because its fem. is <span class="ar">قَبَعْثَرَاةٌ</span>, as Mbr. says; <span class="auth">(Ṣ and TA in that art.;)</span> nor to render it quasi-coordinate to another word, <span class="auth">(Ḳ and TA in that art.,)</span> as is said in the Lubáb, because there is no noun of six radical letters to which it can be made to be so; but accord. to Ibn-Málik, a word is sometimes made quasi-coordinate to one comprising augmentative letters, as <span class="ar">اِقْعَنْسَسَ</span> is to <span class="ar">اِحْرَنْجَمَ</span>. <span class="auth">(TA in that art.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="A_C1">
					<p><span class="ar long">أَلِفَاتُ الوَصْلِ</span> <span class="add">[<em>The alifs of conjunction</em> or <em>connexion,</em> or <em>the conjunctive</em> or <em>connexive alifs</em>]</span>, <span class="auth">(T, Ḳ,)</span> which are in the beginnings of nouns, <span class="auth">(T,)</span> <span class="add">[as well as in certain well-known cases in verbs,]</span> occur in <span class="ar">ٱبْنٌ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">ٱبْنُمٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">ٱبْنَةٌ</span> and <span class="ar">ٱثْنَانِ</span> and <span class="ar">ٱثْنَتَانِ</span> and <span class="ar">ٱمْرُؤٌ</span> and <span class="ar">ٱمْرَأَةٌ</span> and <span class="ar">ٱسْمٌ</span> and <span class="ar">ٱسْتٌ</span>, <span class="auth">(T, Ḳ,)</span> which have a kesreh to the <span class="ar">ا</span> when they commence a sentence, <span class="add">[or occur alone, i. e., when immediately preceded by a quiescence,]</span> but it is elided when they are connected with a preceding word, <span class="auth">(T,)</span> <span class="add">[by which term “word” is included a particle consisting of a single letter with its vowel,]</span> and <span class="ar">ٱيْمُنٌ</span> and <span class="ar">ٱيْمُ</span> <span class="add">[and variations thereof, which have either a fet-ḥah or a kesreh to the <span class="ar">ا</span> when they commence a sentence, or occur alone]</span>, <span class="auth">(Ḳ,)</span> and in the article <span class="ar">ٱلْ</span>, the <span class="ar">ا</span> of which has a fet-ḥah when it commences a sentence. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="A_D1">
					<p><span class="ar long">أَلِفُ القَطْعِ</span> <span class="add">[<em>The alif of disjunction,</em> or <em>the disjunctive alif,</em>]</span> is in the beginnings of sing. nouns and of pl. nouns: it may be known by its permanence in the dim., and by its not being a radical letter: thus it occurs in <span class="ar">أَحْسَنُ</span>, of which the dim. is <span class="ar">أُحَيْسِنُ</span>: <span class="auth">(IAmb, T:)</span> in pls. it occurs in <span class="ar">أَلْوَانٌ</span> and <span class="ar">أَزْوَاجٌ</span> <span class="auth">(IAmb, T, Ḳ)</span> and <span class="ar">أَلْسِنَةٌ</span> <span class="add">[&amp;c.]</span>: <span class="auth">(IAmb, T:)</span> <span class="add">[it also occurs in verbs of the measure <span class="ar">أَفْعَلَ</span>, as <span class="ar">أَكْرَمَ</span>; in which cases it is sometimes <span class="ar">لِلسَّلْبِ</span>, i. e. <em>privative,</em> <span class="auth">(like the Greek alpha,)</span> as in <span class="ar">أَقْسَطَ</span> “he did away with injustice,” which is termed <span class="ar">قُسُوطٌ</span> and <span class="ar">قَسْطٌ</span>, inf. ns. of <span class="ar">قَسَطَ</span>:]</span> it is distinguished from the radical <span class="ar">ا</span>, as shown above: <span class="auth">(IAmb, T:)</span> or it is sometimes augmentative, as the interrogative <span class="ar">أَ</span> <span class="add">[to be mentioned below]</span>; and sometimes radical, as in <span class="ar">أَخَذَ</span> and <span class="ar">أَمَرَ</span>; and is thus distinguished from the conjunctive <span class="ar">ا</span>, which is never other than augmentative. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D2</span>
				</div>
				<div class="sense" id="A_D2">
					<p><span class="ar long">أَلِفُ التَّفْضِيلِ وَالتَّقْصِيرِ</span> <span class="add">[<em>The alif denoting excess and deficiency,</em> i. e., <em>denoting the comparative and superlative degrees</em>]</span>, as in <span class="ar long">فُلَانٌ أَكْرَمُ مِنْكَ</span> <span class="add">[<em>Such a one is more generous,</em> or <em>noble, than thou</em>]</span>, <span class="auth">(T, Ḳ,*)</span> and <span class="ar long">أَلْأَمُ مِنْكَ</span> <span class="add">[<em>more ungenerous,</em> or <em>ignoble, than thou</em>]</span>, <span class="auth">(T,)</span> and <span class="ar long">أَجْهَلُ النَّاسِ</span> <span class="add">[<em>the most ignorant of men</em>]</span>. <span class="auth">(T, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D3</span>
				</div>
				<div class="sense" id="A_D3">
					<p><span class="ar long">أَلِفُ العِبَارَةِ</span> <span class="add">[<em>The alif of signification</em>]</span>, <span class="auth">(T, Ḳ,)</span> as though, <span class="auth">(T,)</span> or because, <span class="auth">(TA,)</span> significant of the speaker, <span class="auth">(T, TA,)</span> also called <span class="ar">العَامِلَةُ</span> <span class="add">[<em>the operative</em>]</span>, as in <span class="ar long">أَنَا أَسْتَغْفِرُ ٱللّٰهَ</span> <span class="add">[<em>I beg forgiveness of God</em>]</span>, <span class="auth">(T, Ḳ,)</span> and <span class="ar long">أَنَا أَفْعَلُ كَذَا</span> <span class="add">[<em>I do thus</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D4</span>
				</div>
				<div class="sense" id="A_D4">
					<p><span class="ar long">أَلِفُ الٱِسْتِفْهَامِ</span> <span class="add">[<em>The alif of interrogation,</em> or <em>the interrogative alif</em>]</span>, <span class="auth">(T, Ṣ, Mṣb in art. <span class="ar">همز</span>, Mughnee,)</span> as in <span class="ar long">أَزَيْدٌ قَائِمٌ</span> <span class="add">[<em>Is Zeyd standing?</em>]</span>, <span class="auth">(Mughnee,)</span> and <span class="ar long">أَزَيْدٌ عِنْدَكَ أَمْ عَمْرٌو</span> <span class="add">[<em>Is Zeyd with thee,</em> or <em>at thine abode, or ʼAmr?</em>]</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">أَقَامَ زَيْدٌ</span> <span class="add">[<em>Did Zeyd stand?</em>]</span>, said when the asker is in ignorance, and to which the answer is <span class="ar">لَا</span> or <span class="ar">نَعَمْ</span>; <span class="auth">(Mṣb;)</span> and in a negative phrase, as <span class="ar long">أَلَمْ نَشْرَحْ</span> <span class="add">[<em>Did we not dilate,</em> or <em>enlarge?</em> in the Ḳur xciv. 1]</span>. <span class="auth">(Mughnee.)</span> <span class="pb" id="Page_0003"></span>When this is followed by another hemzeh, an <span class="ar">ا</span> is interposed between the two hemzehs, <span class="add">[so that you say <span class="ar">أَاأَنْتَ</span>, also written <span class="ar">آأَنْتَ</span>,]</span> as in the saying of Dhu-r-Rummeh,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَيَا ظَبْيَةَ الوَعْسَآءَ بَيْنَ جَلَاجِلٍ</span> *</div> 
						<div class="star">* <span class="ar long">وَبَيْنَ النَّقَا أَاأَنْتِ أَمْ أُمُّ سَالِمِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O thou doe-gazelle of El-Waạsà between Jelájil and the oblong gibbous hill of sand, is it thou, or Umm-Sálim?</em>]</span>; <span class="auth">(T, Ṣ;)</span> but some do not this. <span class="auth">(T.)</span> <span class="add">[It is often conjoined with <span class="ar">إِنَّ</span>, as in the Ḳur xii. 90, <span class="ar long">أَئِنَّكَ لَأَنْتَ يُوسُفُ</span> <em>Art thou indeed Joseph?</em>]</span> It is sometimes used to make a person acknowledge, or confess, a thing, <span class="auth">(T, Mṣb in art. <span class="ar">همز</span>, Mughnee,)</span> and to establish it, <span class="auth">(Mṣb,)</span> as in the phrase in the Ḳur <span class="add">[v. 116]</span>, <span class="ar long">أَأَنْتَ قُلْتَ لِلنَّاسِ</span> or <span class="ar">آأَنْتَ</span> <span class="add">[<em>Didst thou say to men?</em>]</span>, <span class="auth">(T,)</span> and <span class="ar long">أَلَمْ نَشْرَحْ</span> <span class="add">[explained above]</span>, <span class="auth">(Mṣb in art. <span class="ar">همز</span>,)</span> and in <span class="ar long">أَضَرَبْتَ زَيْدًا</span> or <span class="ar long">أَأَنْتَ ضَرَبْتَ</span> <span class="add">[<em>Didst thou beat Zeyd?</em>]</span>, and <span class="ar long">أَزَيْدًا ضَرَبْتَ</span> <span class="add">[<em>Zeyd didst thou beat?</em>]</span>. <span class="auth">(Mughnee.)</span> And for reproving, <span class="auth">(T, Mughnee,)</span> as in the phrase in the Ḳur <span class="add">[xxxvii. 153]</span>, <span class="ar long">أصْطَفَى ٱلْبَنَاتِ عَلَى ٱلْبَنِينَ</span> <span class="add">[<em>Hath He chosen daughters in preference to sons?</em>]</span>, <span class="auth">(T,)</span> <span class="add">[but see the next sentence,]</span> and <span class="add">[in the same ch., verse 93,]</span> <span class="ar long">أَتَعْبُدُونَ مَا تَنْحِتُونَ</span> <span class="add">[<em>Do ye worship what ye hew out?</em>]</span>. <span class="auth">(Mughnee.)</span> And to express a nullifying denial, as in <span class="add">[the words of the Ḳur xvii. 42,]</span> <span class="ar long">أَفَأَصْفَاكُمْ رَبُّكُمْ بِٱلْبَنِينَ وَٱتَّخَذَ مِنَ ٱلْمَلَائِكَةِ إِنَاثًا</span> <span class="add">[<em>Hath then your Lord preferred to give unto you sons, and gotten for himself, of the angels, daughters?</em>]</span>. <span class="auth">(Mughnee.)</span> And to denote irony, as in <span class="add">[the Ḳur xi. 89,]</span> <span class="ar long">أَصَلَوَاتُكَ تَأْمُرُكَ أَنْ نَتْرُكَ مَا يَعْبُدُ آبَاؤُنَا</span> <span class="add">[<em>Do thy prayers enjoin thee that we should leave what our fathers worshipped?</em>]</span>. <span class="auth">(Mughnee.)</span> And to denote wonder, as in <span class="add">[the Ḳur xxv. 47,]</span> <span class="ar long">أَلَمْ تَرَ إِلَى رَبِّكَ كَيْفَ مَدَّ ٱلظِّلَّ</span> <span class="add">[<em>Hast thou not considered</em> the work of <em>thy Lord, how He hath extended the shade?</em>]</span>. <span class="auth">(Mughnee.)</span> And to denote the deeming a thing slow, or tardy, as in <span class="add">[the Ḳur lvii., 15,]</span> <span class="ar long">أَلَمْ يَأْنِ لِلَّذِينَ آمَنُوا</span> <span class="add">[<em>Hath not the time yet come for those who have believed?</em>]</span>. <span class="auth">(Mughnee.)</span> And to denote a command, as in <span class="add">[the Ḳur iii. 19,]</span> <span class="ar">أَأَسْلَمْتُمْ</span>, meaning <span class="ar">أَسْلِمُوا</span> <span class="add">[<em>Enter ye into the religion of El-Islám</em>]</span>. <span class="auth">(Mughnee, and so Jel.)</span> And to denote equality, occurring after <span class="ar">سَوَآءٌ</span> and <span class="ar long">مَا أُبَالِى</span> and <span class="ar long">مَا أَدْرِى</span> and <span class="ar long">لَيْتَ شِعْرِى</span>, and the like, as in <span class="add">[the Ḳur lxiii. 6,]</span> <span class="ar long">سَوَآءٌ عَلَيْهِمْ أَسْتَغْفَرْتَ لَهُمْ أَمْ لَمْ تَسْتَغْفِرْ لَهُمْ</span> <span class="add">[It will be <em>equal to them whether thou beg forgiveness for them or do not beg forgiveness for them</em>]</span>, and in <span class="ar long">مَا أُبَالِى أَقُمْتَ أَمْ قَعَدْتَ</span> <span class="add">[<em>I care not whether thou stand or sit</em>]</span>: and the general rule is this, that it is the hemzeh advening to a phrase, or proposition, of which the place may be supplied by the inf. n. of its verb; for one may say, <span class="ar long">سَوَآءٌ عَلَيْهِمُ ٱلْأِسْتِغْفَارُ وَعَدَمُهُ</span> <span class="add">[<em>Equal to them</em> will be <em>the begging of forgiveness and the not doing so</em>]</span>, and <span class="ar long">مَا أُبَالِى بِقِيَامِكَ وَعَدَمِهِ</span> <span class="add">[<em>I care not for thy standing and thy not doing so</em>]</span>: <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D5</span>
				</div>
				<div class="sense" id="A_D5">
					<p><span class="ar long">أَلِفُ النِّدَآءِ</span> <span class="add">[<em>The alif of calling,</em> or <em>vocative alif</em>]</span>, <span class="auth">(T, Ṣ,* Mughnee,* Ḳ,)</span> as in <span class="ar">أَزَيْدُ</span>, meaning <span class="ar long">يَا زَيْدُ</span> <span class="add">[<em>O Zeyd</em>]</span>, <span class="auth">(T, Ḳ,)</span> and in <span class="ar long">أَزَيْدُ أَقْبِلْ</span> <span class="add">[<em>O Zeyd, advance</em>]</span>, <span class="auth">(Ṣ,)</span> used in calling him who is near, <span class="auth">(Ṣ, Mughnee,)</span> to the exclusion of him who is distant, because it is abbreviated. <span class="auth">(Ṣ.)</span> <span class="ar">آ</span>, with medd, is a particle used in calling to him who is distant, <span class="auth">(Mughnee, Ḳ,)</span> as in <span class="ar long">آَزَيْدُ أَقْبِلْ</span> <span class="add">[<em>Ho there,</em> or <em>soho,</em> or <em>holla, Zeyd, advance</em>]</span>. <span class="auth">(TA.)</span> Az says, You say to a man, in calling him, <span class="ar">آفُلَانُ</span> and <span class="ar">أَفُلَانُ</span> and <span class="ar long">آيَا فُلَانُ</span> <span class="auth">(TA)</span> or <span class="ar">أَيَا</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">ايا</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D6</span>
				</div>
				<div class="sense" id="A_D6">
					<p><span class="ar">إِٱللّٰهِ</span>, for <span class="ar long">إِىْ وَٱللّٰهِ</span>: <a href="#Iie">see <span class="ar">إِى</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D7</span>
				</div>
				<div class="sense" id="A_D7">
					<p>In a dial. of some of the Arabs, hemzeh is used in a case of pausing at the end of a verb, as in their saying to a woman, <span class="ar">قُولِئْ</span> <span class="add">[<em>Say thou</em>]</span>, and to two men, <span class="ar">قُولَأْ</span> <span class="add">[<em>Say ye two</em>]</span>, and to a pl. number, <span class="ar">قُولُؤْ</span> <span class="add">[<em>Say ye</em>]</span>; but not when the verb is connected with a word following it: and they say also <span class="ar">لَأْ</span>, with a hemzeh, <span class="add">[for <span class="ar">لَا</span>,]</span> in a case of pausation. <span class="auth">(T.)</span> But Aḥmad Ibn-Yaḥyà says, All men say that when a hemzeh occurs at the end of a word, <span class="add">[i. e. in a case of pausation,]</span> and has a quiescent letter before it, it is elided in the nom. and gen. case, though retained in the accus. case <span class="add">[because followed by a quiescent <span class="ar">ا</span>]</span>, except Ks alone, who retains it in all cases: when it occurs in the middle of a word, all agree that it should not be dropped. <span class="auth">(T.)</span> AZ <span class="add">[however]</span> says that the people of El-Ḥijáz, and Hudheyl, and the people of Mekkeh and El-Medeeneh, do not pronounce hemzeh <span class="add">[at all]</span>: and ʼEesà Ibn-’Omar says, Temeem pronounce hemzeh, and the people of El-Ḥijáz, in cases of necessity, <span class="add">[in poetry,]</span> do so. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D8</span>
				</div>
				<div class="sense" id="A_D8">
					<p>Ks cites, <span class="add">[as exhibiting two instances of a rare usage of <span class="ar">أَا</span>, or <span class="ar">آ</span>, in a case of pausing, in the place of a suppressed word,]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">دَعَا فُلَانٌ رَبَّهُ فَأَسْمَعَا</span> *</div> 
						<div class="star">* <span class="ar long">الخَيْرُ خَيْرَانِ وَإِنْ شَرٌّ فَأَا</span> *</div> 
						<div class="star">* <span class="ar long">وَلَا أُرِيدُ الشَّرَّ إِلَّا أَنْ تَأَا</span> *</div> 
					</blockquote>
					<p><span class="add">[written without the syll. signs in the MṢ. from which I transcribe this citation, but the reading seems to be plain, and the meaning, <em>Such a one supplicated his Lord, and made</em> his words <em>to be heard,</em> saying, <em>Good</em> is <em>double good; and if evil</em> be my lot, <em>then evil; but I desire not evil unless Thou will</em> that it should befall me]</span>: and he says, he means, <span class="ar long">إِلَّا أَنْ تَشَآءَ</span>; this being of the dial. of Benoo-Saạd, except that it is <span class="add">[with them]</span> <span class="ar">تَا</span>, with a soft <span class="ar">ا</span> <span class="add">[only]</span>: also, in replying to a person who says, “Wilt thou not come?” one says, <span class="ar">فَأْ</span>, meaning <span class="ar">فَٱذْهَبْ</span> <span class="add">[<em>Then go thou with us</em>]</span>: and in like manner, by <span class="ar">فأا</span>, in the saying above, is meant <span class="ar">فَشَرٌّ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="A_E1">
					<p>Hemzeh also sometimes occurs as a verb; <span class="ar">إِه</span>, i. e. <span class="ar">إِ</span> with the <span class="ar">ه</span> of pausation added, being the imperative of <span class="ar">وَأَى</span> as syn. with <span class="ar">وَعَدَ</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ا</span> - Entry: <span class="ar">ا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="A_F1">
					<p><span class="add">[As a numeral, <span class="ar">ا</span> denotes <em>One.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0001.pdf" target="pdf">
							<span>Lanes Lexicon Page 1</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0002.pdf" target="pdf">
							<span>Lanes Lexicon Page 2</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0003.pdf" target="pdf">
							<span>Lanes Lexicon Page 3</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
