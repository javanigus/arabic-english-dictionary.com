<article class="root" id="Root_AnA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/138_An">ان</a></span>
				<span class="ar">انا</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/140_Anb">انب</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="OanaA.1">
				<h3 class="entry"><span class="ar">أَنَا</span></h3>
				<div class="sense" id="OanaA.1_A1">
					<p><span class="ar">أَنَا</span> <span class="auth">(pronoun of the first person sing.)</span>: <a href="index.php?data=01_A/138_An">see art. <span class="ar">ان</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0111.pdf" target="pdf">
							<span>Lanes Lexicon Page 111</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
