<article class="root" id="Root_ATm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/099_ATr">اطر</a></span>
				<span class="ar">اطم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/101_Af">اف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OuTumN">
				<h3 class="entry"><span class="ar">أُطُمٌ</span> / <span class="ar">أُطْمٌ</span></h3>
				<div class="sense" id="OuTumN_A1">
					<p><span class="ar">أُطُمٌ</span> and <span class="ar">أُطْمٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> like <span class="ar">أُجُمٌ</span> and <span class="ar">أُجْمٌ</span>, <span class="auth">(Ṣ, and Mgh in art. <span class="ar">اجم</span>)</span> <em>A fortress:</em> or, as some say, <em>any lofty building:</em> <span class="auth">(Mgh:)</span> or <em>a</em> <span class="add">[<em>building such as is termed</em>]</span> <span class="ar">قَصْر</span> <span class="add">[q. v.]</span>: <span class="auth">(IAạr, Ḳ:)</span> and <em>any fortress built of stones:</em> and <em>any square, roofed, house:</em> <span class="auth">(Ḳ:)</span> pl. <span class="auth">(of pauc., TA)</span> <span class="ar">آطَامٌ</span> <span class="auth">(Ṣ, Mgh. Ḳ)</span> and <span class="auth">(of mult., TA)</span> <span class="ar">أُطُومٌ</span>: <span class="auth">(Ḳ:)</span> <span class="ar">آطَامٌ</span> signifies <em>fortresses of the people of El-Medeeneh:</em> and one of these is termed <span class="arrow"><span class="ar">أَطَمَةٌ↓</span></span>: <span class="auth">(Ṣ:)</span> or this signifies <span class="add">[simply]</span> <em>a fortress;</em> and its pl. is <span class="ar">آطَامٌ</span> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaTamapN">
				<h3 class="entry"><span class="ar">أَطَمَةٌ</span></h3>
				<div class="sense" id="OaTamapN_A1">
					<p><span class="ar">أَطَمَةٌ</span>: <a href="#OuTumN">see above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MTaAmN">
				<h3 class="entry"><span class="ar long">آطَامٌ مُؤَطَّمَةٌ</span></h3>
				<div class="sense" id="MTaAmN_A1">
					<p><span class="ar long">آطَامٌ مُؤَطَّمَةٌ</span> <em>Lofty</em> <span class="add">[<em>fortresses,</em>, &amp;c.]</span>: <span class="auth">(A, TA:)</span> <span class="add">[or it may signify <em>fortresses,</em>, &amp;c., <em>disposed in order,</em> or <em>grouped together;</em> for it is said to be]</span> a phrase like <span class="ar long">أَبْوَابٌ مُبَوَّبَةٌ</span>, <span class="auth">(O, TA,)</span> or like <span class="ar long">أَجْنَادٌ مُجَنَّدَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0067.pdf" target="pdf">
							<span>Lanes Lexicon Page 67</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
