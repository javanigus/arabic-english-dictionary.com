<article class="root" id="Root_Anb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/139_AnA">انا</a></span>
				<span class="ar">انب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/141_Ant">انت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Anb_2">
				<h3 class="entry">2. ⇒ <span class="ar">أنّب</span></h3>
				<div class="sense" id="Anb_2_A1">
					<p><span class="ar">أنّبهُ</span>, inf. n. <span class="ar">تَأْنِيبٌ</span>, <em>He blamed, reproved, reprehended, chid,</em> or <em>reproached, him:</em> <span class="auth">(Ṣ, M, A, Ḳ:)</span> or <em>he did so severely,</em> or <em>angrily:</em> <span class="auth">(ISk, T, Ṣ, M, A, Ḳ:)</span> or, <em>with the utmost severity</em> or <em>harshness:</em> <span class="auth">(T, M, TA:)</span> or <em>he repulsed him,</em> meaning a person who asked something of him, <em>in the most abominable manner.</em> <span class="auth">(M,* Ḳ,* TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OunobuwbN">
				<h3 class="entry"><span class="ar">أُنْبُوبٌ</span></h3>
				<div class="sense" id="OunobuwbN_A1">
					<p><span class="ar">أُنْبُوبٌ</span> <em>An internodal portion,</em> or the <em>portion between any two joints,</em> or <em>knots,</em> of a cane, or reed, and of a spear-shaft: <span class="auth">(T:)</span> <span class="add">[and]</span> <em>a spear,</em> or <em>lance:</em> <span class="pb" id="Page_0112"></span>pl. <span class="ar">أَنَابِيبُ</span>: mentioned in this art. <span class="add">[in the T, and]</span> by Ibn-El-Mukarram <span class="add">[in the L]</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=25_n/010_nb">See also art. <span class="ar">نب</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0111.pdf" target="pdf">
							<span>Lanes Lexicon Page 111</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0112.pdf" target="pdf">
							<span>Lanes Lexicon Page 112</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
