<article class="root" id="Root_Asw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/085_Asn">اسن</a></span>
				<span class="ar">اسو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/087_Ase">اسى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asw_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسو</span> ⇒ <span class="ar">أسى</span></h3>
				<div class="sense" id="Asw_1_A1">
					<p><span class="ar long">أَسَا الجُرْحَ</span>, <span class="auth">(aor. <span class="ar">يَأْسُو</span> Ṣ,)</span> inf. n. <span class="ar">أَسْوٌ</span> and <span class="ar">أَسًا</span>, <span class="add">[but in the Ṣ, the latter seems to be mentioned as a simple subst.,]</span> <em>He dressed the wound; treated it curatively,</em> or <em>surgically.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asw_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">هٰذَ أَمْرٌ لَا يُؤْسَى كَلْمُهُ</span> † <span class="add">[<em>This is an affair of which the evil</em> <span class="auth">(lit. <em>the wound</em>)</span> <em>will not be remedied</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Asw_1_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar long">أَسَا بَيْنَهُمْ</span>, <span class="auth">(first pers. <span class="ar">أَسَوْتُ</span>, Ṣ, Mṣb, inf. n. <span class="ar">أَسْوٌ</span>, Ṣ, M,)</span> ‡ <em>He made peace, effected a reconciliation,</em> or <em>adjusted a difference, between them;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar long">أسّى↓ بينهم</span></span>. <span class="auth">(El-Muärrij, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Asw_1_B1">
					<p><span class="ar">أَسِيَ</span> aor. <span class="ar">يَأْسَى</span>, inf. n. <span class="ar">أَسًا</span> or <span class="ar">أَسًى</span>, <em>He grieved,</em> or <em>mourned,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <span class="ar">عَلَيْهِ</span> <span class="add">[<em>for him,</em> or <em>it</em>]</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar long">عَلَى مُصِيبَةٍ</span> <span class="add">[<em>for an affliction</em>]</span>, and <span class="ar">لِفُلَانٍ</span> <span class="add">[<em>for such a one</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[This belongs to the present art. <a href="index.php?data=01_A/087_Ase">and to art. <span class="ar">اسى</span></a>; but is distinguished in the M and Ḳ by being mentioned only in the latter art.; though the inf. n. is mentioned in the Ḳ in both arts.]</span> Hence the saying, <span class="ar long">الإِسَآءُ يَدْفَعُ الأَسَا</span> <span class="add">[<em>Medicine dispels grief,</em> or <em>mourning</em>]</span> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asw_2">
				<h3 class="entry">2. ⇒ <span class="ar">أسّو</span> ⇒ <span class="ar">أسّى</span></h3>
				<div class="sense" id="Asw_2_A1">
					<p><span class="ar long">أسّى بَيْنَهُمْ</span>: <a href="#Asw_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Asw_2_B1">
					<p><span class="ar">أسّاهُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَأْسِيَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>i. q.</em> <span class="ar">عَزَّاهُ</span> <span class="add">[<em>He exhorted him,</em> or <em>enjoined him, to be patient; to take patience;</em> or <em>to take example by,</em> or <em>console himself by the example of, him who had suffered the like affliction</em>]</span>; <span class="auth">(Ṣ, M, Ḳ, TA;)</span> <em>saying to him, Wherefore dost thou grieve,</em> or <em>mourn, when such a one is thine example</em> (<span class="ar">إِسْوَتُكَ</span>) i. e. <em>what has befallen thee befell him, and he was patient; therefore take thou example by him and so be consoled</em> (<span class="ar long">تَأَسِّ بِهِ</span>). <span class="auth">(TA.)</span> You say, <span class="ar long">أسّاهُ بِمُصِيبَةٍ</span> i. e. <span class="ar">عَزَّاهُ</span> <span class="add">[<em>He exhorted him,</em> or <em>enjoined him, to be patient,</em>, &amp;c., <em>by</em> mentioning <em>an affliction</em> that had befallen another; unless <span class="ar">بمصيتة</span> be a mistranscription for <span class="ar">لِمُصِيبَةٍ</span> <em>on account of an affliction</em>]</span>; as also<span class="arrow"><span class="ar">آساهُ↓</span></span>, with medd. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asw_3">
				<h3 class="entry">3. ⇒ <span class="ar">آسو</span> ⇒ <span class="ar">آسى</span></h3>
				<div class="sense" id="Asw_3_A1">
					<p><span class="ar long">آسَيْتُهُ بِمَالِى</span>, <span class="auth">(Ṣ, Mgh,)</span> inf. n. <span class="ar">مُؤَاسَاةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>I made him my object of imitation</em> (<span class="ar">إِسْوَتِى</span>), <span class="add">[meaning <em>I made myself like him,</em>]</span> <em>in respect of my property:</em> <span class="auth">(Ṣ:)</span> or <em>I made him an object of imitation</em> <span class="add">[<em>with,</em> or <em>in respect of, my property</em>]</span>, <em>I imitating his example, and he imitating my example:</em> <span class="auth">(Mgh:)</span> and <span class="ar">وَاسَيْتُهُ</span> is a dial. var., but of weak authority: <span class="auth">(Ṣ, Mgh:)</span> and <span class="ar">آسَانِى</span> <span class="add">[alone]</span> <em>he made me an object of imitation to him by giving me of his property</em> <span class="add">[<em>and thus reducing himself to my condition in some degree while in the same degree raising me to his</em>]</span>; <span class="auth">(Ḥam p. 696;)</span> and <span class="ar">أُوَاسِيهِ</span> <span class="add">[thus without a second <span class="ar">ء</span>]</span> <em>I make him the object of my own imitation and so share with him my property:</em> <span class="auth">(Id p. 198:)</span> or <span class="ar long">آساهُ بِمَالِهِ</span> signifies <em>he gave him of his property, and made him an object of imitation in respect of it:</em> or only, <em>of food sufficient for his want;</em> not of what is superabundant: <span class="auth">(M, Ḳ:)</span> whence the saying, <span class="ar long">رَحِمَ ٱللّٰهُ رَجُلًا أَعْطَى مِنْ فَضْلٍ وَوَاسَى مِنْ كَفَافٍ</span> <span class="add">[<em>May God have mercy on a man who has given of superabundance, and imparted of food only sufficient for his want so as to make himself equal with him to whom he imparts of such food</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[and <span class="ar">آساهُ</span> signifies <em>he shared with him:</em> and <em>he was,</em> or <em>became, equal with him:</em> for]</span> <span class="ar">المُوَاسَاةُ</span> occurs often in trads., signifying the <em>sharing with another,</em> or <em>making another to share with one, in the means of subsistence</em> <span class="add">[<em>&amp;c.</em>]</span>; and is originally <span class="add">[<span class="ar">المُؤَاسَاةُ</span>,]</span> with <span class="ar">ء</span>: also, the <em>being,</em> or <em>becoming, equal with another:</em> <span class="auth">(TA:)</span> and you say, <span class="ar long">آسَيْتُهُ بِنَفْسِى</span>, meaning <em>I made him equal with myself;</em> in the dial. of El-Yemen <span class="ar">وَاسَيْتُهُ</span>. <span class="auth">(Mṣb.)</span> <span class="ar long">آسِ بَيْنَ النَّاسِ فِى وَجْهِكَ</span>, in a letter of ʼOmar, means <em>Make thou the people to share</em> <span class="add">[<em>alike</em>]</span>, <em>one with another, in thy consideration and regard:</em> or, as some say, <em>make thou them equal</em> <span class="add">[<em>in respect thereof</em>]</span>. <span class="auth">(Mgh.)</span> The saying <span class="ar long">مَا يُؤَاسِى فُلَانٌ فُلَانًا</span> is explained in three different ways: accord. to El-Mufaddal Ibn-Moḥammad, it means <em>Such a one does not make such a one to share with him:</em> accord. to El-Muärraj, <em>does not good to such a one;</em> from the saying of the Arabs, <span class="ar long">آسِ فُلَانًا بِخَيْرٍ</span> <em>Do thou good to such a one:</em> or, as some say, <em>does not give such a one any compensation for his love,</em> or <em>affection, nor for his relationship;</em> from <span class="ar">الأَوْسُ</span>, meaning <span class="ar">العَوْضُ</span>; being originally <span class="ar">يُؤَاوِسُهُ</span>, then <span class="ar">يُؤَاسِوُهُ</span>, and then <span class="ar">يُؤَاسِيهِ</span>: or it may be from <span class="ar long">أَسَوْتُ الجُرْحَ</span>. <span class="auth">(IDrd, TA.)</span> <span class="add">[<a href="#OavarapN">See also an ex. voce <span class="ar">أَثَرَةٌ</span></a>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Asw_4">
				<h3 class="entry">4. ⇒ <span class="ar">آسو</span> ⇒ <span class="ar">آسى</span></h3>
				<div class="sense" id="Asw_4_A1">
					<p><a href="#Asw_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأسّو</span> ⇒ <span class="ar">تأسّى</span></h3>
				<div class="sense" id="Asw_5_A1">
					<p><span class="ar">تأسّى</span>: <a href="#Asw_8">see 8</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asw_5_A2">
					<p><em>I. q.</em> <span class="ar">تَعَزَّى</span> <span class="add">[<em>He took patience;</em> or <em>constrained himself to be patient;</em> or <em>he took example by,</em> or <em>became consoled by the example of, another who had suffered in like manner and had been patient</em>]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span> You say, <span class="ar long">تأسّى بِهِ</span>, i. e. <span class="ar long">تَعَزَّى بِهِ</span> <span class="add">[<em>He took patience,</em> or <em>constrained himself to be patient, by reflecting upon him,</em> or <em>it;</em> or <em>he took example by him,</em> or <em>became consoled by his example,</em> meaning the example of a person who had suffered in like manner and had been patient]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#Asw_2">See 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآسو</span> ⇒ <span class="ar">تآسى</span></h3>
				<div class="sense" id="Asw_6_A1">
					<p><span class="ar">تَآسَوْا</span> signifies <span class="ar long">آسَى بَعْضُهُمْ بعْضًا</span> <span class="add">[<em>They imitated one another with their property, one giving of his property to another, so that they thus equalised themselves; they imitated one another and so shared together their property; they shared, one with another, in the means of subsistence, &amp;c.; they were,</em> or <em>became, equal, one with another:</em> <a href="#Asw_3">see 3</a>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإِنَّ الأُولَى بِالطَّفِّ مِنْ آل هَاشِمٍ</span> *</div> 
						<div class="star">* <span class="ar long">تَآسَوْا فَسَنُّوا لِلْكِرَامِ التَّآسِيَا</span> *</div> 
					</blockquote>
					<p><span class="auth">(Ṣ,)</span> in which <span class="ar">تآسوا</span> is from <span class="ar">المُؤَاسَاةُ</span>; not from <span class="ar">التَّأَسِّى</span>, as it is stated to be by Mbr, who says that <span class="ar">تآسوا</span> means <span class="ar">تَوَاسَوْاا</span> and <span class="ar">تَعَزَّوْا</span>. <span class="auth">(IB, TA.)</span> <span class="add">[This verse cited and translated <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>, <a href="#Oulae">voce <span class="ar">أُلَى</span>, q. v.</a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asw_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتسو</span> ⇒ <span class="ar">ائتسى</span></h3>
				<div class="sense" id="Asw_8_A1">
					<p><span class="ar long">ائتسى بِهِ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَسَى</span>]</span> <em>He imitated him; followed his example; did as he did, following his example,</em> or <em>taking him as an example, an exemplar, a pattern,</em> or <em>an object of imitation; he took example by him;</em> <span class="auth">(Ṣ, Mgh, Mṣb, TA;)</span> as also<span class="arrow"><span class="ar long">تأسّى↓ بِهِ</span></span>: <span class="auth">(Mṣb, TA:)</span> <em>he made him an object of imitation</em> (<span class="ar">إِسْوَة</span>) <span class="add">[<em>to himself</em>]</span>. <span class="auth">(M, Ḳ.)</span> One says, <span class="ar long">لَا تَأْتَسِ بِمَنْ لَيْسَ لَكَ بِإِسْوَةٍ</span> <em>Do not thou imitate him who is not for thee a</em> <span class="add">[<em>fit</em>]</span> <em>object of imitation.</em> <span class="auth">(Ṣ, M.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asw_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">أَسْوَيْتُهُ</span></h3>
				<div class="sense" id="Asw_QQ1_A1">
					<p><span class="ar long">أَسْوَيْتُهُ بِهِ</span> <span class="add">[<em>I made him to imitate him, to follow his example,</em> or <em>to take example by him;</em>]</span> <em>I made him an example, an exemplar, a pattern,</em> or <em>an object of imitation, to him:</em> <span class="auth">(M, Ḳ:)</span> from IAạr: and if from <span class="ar">الإِسْوَةُ</span>, as he asserts it be, the measure of this verb is <span class="ar">فَعْلَيْتُ</span>, like <span class="ar">دَرْبَيْتُ</span> and <span class="ar">جَعْبَيْتُ</span>. <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasFA">
				<h3 class="entry"><span class="ar">أَسًا</span> / <span class="ar">أَسًى</span></h3>
				<div class="sense" id="OasFA_A1">
					<p><span class="ar">أَسًا</span> or <span class="ar">أَسًى</span> <em>Curative,</em> or <em>surgical, treatment.</em> <span class="auth">(Ṣ.)</span> <span class="add">[See the verb <span class="ar">أَسَا</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">أَسًا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OasFA_B1">
					<p><em>Grief,</em> or <em>mourning.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[See the verb <span class="ar">أَسِىَ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasK">
				<h3 class="entry"><span class="ar">أَسٍ</span></h3>
				<div class="sense" id="OasK_A1">
					<p><span class="ar">أَسٍ</span>: <a href="#OasowaAnu">see <span class="ar">أَسْوَانُ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusFe">
				<h3 class="entry"><span class="ar">أُسًى</span></h3>
				<div class="sense" id="OusFe_A1">
					<p><span class="ar">أُسًى</span> <em>Patience.</em> <span class="auth">(Ṣ.)</span></p>	
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">أُسًى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OusFe_B1">
					<p><a href="#OusowapN">Also pl. of <span class="ar">أُسْوَةٌ</span></a>, like as <span class="ar">إِسًى</span> <a href="#IisowapN">is pl. of <span class="ar">إِسْوَةٌ</span></a>. <span class="auth">(Ṣ,* Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasowapN">
				<h3 class="entry"><span class="ar">أَسْوَةٌ</span></h3>
				<div class="sense" id="OasowapN_A1">
					<p><span class="ar">أَسْوَةٌ</span>: <a href="#IisowapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OusowapN">
				<h3 class="entry"><span class="ar">أُسْوَةٌ</span></h3>
				<div class="sense" id="OusowapN_A1">
					<p><span class="ar">أُسْوَةٌ</span>: <a href="#IisowapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisowapN">
				<h3 class="entry"><span class="ar">إِسْوَةٌ</span></h3>
				<div class="sense" id="IisowapN_A1">
					<p><span class="ar">إِسْوَةٌ</span> and<span class="arrow"><span class="ar">أُسْوَةٌ↓</span></span> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَسْوَةٌ↓</span></span>, mentioned by Er-Rághib in one of his works, <span class="auth">(MF,)</span> <em>An example; an exemplar; a pattern; an object of imitation; a person by whom one takes example;</em> syn. <span class="ar">قُدْوَةٌ</span> or <span class="ar">قِدْوَةٌ</span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> each a subst. from <span class="ar long">اِيتَسَى بِهِ</span>; <span class="auth">(Mgh;)</span> i. e. <span class="ar long">مَا يُؤْتَسَى بِهِ</span>: <span class="auth">(TA:)</span> explained by Er-Rághib as meaning the <em>condition in which is a man in respect of another's imitating</em> <span class="add">[<em>him</em>]</span>, <em>whether good or bad, pleasing or hurtful:</em> <span class="auth">(TA:)</span> <span class="pb" id="Page_0061"></span>also <em>a thing</em> <span class="add">[or <em>person</em>]</span> <em>by which one who is in grief,</em> or <em>mourning, takes example,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>for the being consoled</em> (<span class="ar">لِلتَّعَزِّى</span>) <em>thereby:</em> <span class="auth">(Ṣ:)</span> pl. <span class="ar">إِسًى</span> and <span class="ar">أُسًى</span>; <span class="auth">(Ṣ, Ḳ;)</span> the former of the first sing., and the latter of the second. <span class="auth">(TA.)</span> The first of these meanings is intended in the saying, <span class="ar long">لِى فِى فُلَانٍ إِسْوَةٌ</span> and <span class="ar">أُسْوَةٌ</span> <span class="add">[<em>I have in such a one an example,</em>, &amp;c.]</span>. <span class="auth">(Ṣ.)</span> The saying, <span class="ar long">مَا سَوِى التُّرَابِ مِنَ الأَرْضِ إِسْوَةُ التُّرَابِ</span> is tropical, meaning ‡ <em>There is nothing but the dust of the earth,</em> or <em>ground, that follows the dust.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">إِسْوَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IisowapN_A2">
					<p>Also an inf. n., <span class="add">[or rather a quasi-inf. n.,]</span> syn. with <span class="ar">اِيتِسَآءٌ</span> <span class="add">[<a href="#Asw_8">inf. n. of 8</a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasowaAnu">
				<h3 class="entry"><span class="ar">أَسْوَانُ</span></h3>
				<div class="sense" id="OasowaAnu_A1">
					<p><span class="ar">أَسْوَانُ</span> <em>Grieving, mourning,</em> or <em>sorrowful;</em> <span class="auth">(M, Ḳ;)</span> as also <span class="ar">أَسْيَانُ</span> and<span class="arrow"><span class="ar">أَسٍ↓</span></span>, <span class="auth">(M in art. <span class="ar">اسى</span>,)</span> or<span class="arrow"><span class="ar">آسٍ↓</span></span> <span class="auth">(Ḳ in art. <span class="ar">اسى</span> <span class="add">[to which alone the first of these three belongs, but the second and third may be regarded as belonging either to that art. or to the present,]</span>)</span> or<span class="arrow"><span class="ar">أَسِىٌّ↓</span></span> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="index.php?data=01_A/087_Ase">See art. <span class="ar">اسى</span></a>]</span> It is <span class="add">[sometimes]</span> followed by <span class="ar">أَتْوَانُ</span> <span class="add">[as an imitative sequent corroborating its meaning]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisaMCN">
				<h3 class="entry"><span class="ar">إِسَآءٌ</span></h3>
				<div class="sense" id="IisaMCN_A1">
					<p><span class="ar">إِسَآءٌ</span> and<span class="arrow"><span class="ar">أَسُوٌّ↓</span></span> <em>A medicine,</em> or <em>remedy;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> the latter, <span class="auth">(Ṣ,)</span> or each, <span class="auth">(TA,)</span> particularly <em>a vulnerary:</em> <span class="auth">(Ṣ, TA:)</span> pl. <span class="add">[of each, as is indicated in the TA,]</span> <span class="ar">آسِيَةٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">إِسَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IisaMCN_A2">
					<p>The former is also <a href="#AsK">a pl. of <span class="ar">آسٍ</span></a>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasuwBN">
				<h3 class="entry"><span class="ar">أَسُوٌّ</span></h3>
				<div class="sense" id="OasuwBN_A1">
					<p><span class="ar">أَسُوٌّ</span>: <a href="#IisaACN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasieBN">
				<h3 class="entry"><span class="ar">أَسِىٌّ</span></h3>
				<div class="sense" id="OasieBN_A1">
					<p><span class="ar">أَسِىٌّ</span> <em>i. q.</em><span class="arrow"><span class="ar">مَأْسُوٌّ↓</span></span>; <span class="auth">(Ṣ, M, Ḳ;)</span> i. e., <em>Dressed;</em> or <em>treated curatively,</em> or <em>surgically;</em> applied to a wound. <span class="auth">(Ṣ, M.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">أَسِىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OasieBN_B1">
					<p><a href="#OasowaAnu">See also <span class="ar">أَسْوَانُ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusaAwapN">
				<h3 class="entry"><span class="ar">أُسَاوَةٌ</span></h3>
				<div class="sense" id="OusaAwapN_A1">
					<p><span class="ar">أُسَاوَةٌ</span> <em>Medical, curative, therapeutical,</em> <span class="add">[or <em>surgical,</em>]</span> <em>treatment.</em> <span class="auth">(Ibn-El-Kelbee, Ṣgh, Ḳ.)</span> By rule it should be <span class="add">[<span class="ar">إِسَاوَةٌ</span>,]</span> with kesr. <span class="auth">(Ṣgh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MsK">
				<h3 class="entry"><span class="ar">آسٍ</span></h3>
				<div class="sense" id="MsK_A1">
					<p><span class="ar">آسٍ</span> <em>A physician; one skilled in medical, curative, therapeutical,</em> <span class="add">[or <em>surgical,</em>]</span> <em>treatment</em> <span class="add">[<em>particularly of wounds</em>]</span>: pl. <span class="ar">أُسَاةٌ</span> and <span class="ar">إِسَآءٌ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> said by IJ to be the only instance of <span class="ar">فُعْلَةٌ</span> and <span class="ar">فِعَالٌ</span> interchangeable except <span class="ar">رُعَاةٌ</span> and <span class="ar">رِعَآءٌ</span> pls. of <span class="ar">رَاعٍ</span>: <span class="auth">(M:)</span> and <span class="ar">آسُونَ</span> occurs <span class="add">[as its pl.]</span> in a verse of Hoteiäh. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">آسٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MsK_A2">
					<p>With the people of the desert, <span class="auth">(Ṣ,)</span> <span class="add">[its fem.]</span> <span class="ar">آسِيَةٌ</span> signifies ‡ <em>A female circumciser</em> <span class="add">[<em>of girls</em>]</span>. <span class="auth">(Ṣ, Ḳ: <span class="add">[mentioned in the latter in art. <span class="ar">اسى</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسو</span> - Entry: <span class="ar">آسٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MsK_B1">
					<p><a href="#OasuwaAnu">See also <span class="ar">أَسُوَانُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOosuwBN">
				<h3 class="entry"><span class="ar">مَأْسُوٌّ</span></h3>
				<div class="sense" id="maOosuwBN_A1">
					<p><span class="ar">مَأْسُوٌّ</span>: <a href="#OasieBN">see <span class="ar">أَسِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0060.pdf" target="pdf">
							<span>Lanes Lexicon Page 60</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0061.pdf" target="pdf">
							<span>Lanes Lexicon Page 61</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
