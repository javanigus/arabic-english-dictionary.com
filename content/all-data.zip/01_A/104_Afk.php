<article class="root" id="Root_Afk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/103_Afq">افق</a></span>
				<span class="ar">افك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/105_Afl">افل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Afk_1">
				<h3 class="entry">1. ⇒ <span class="ar">أفك</span></h3>
				<div class="sense" id="Afk_1_A1">
					<p><span class="ar">أَفَكَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِكُ</span>}</span></add>, inf. n. <span class="ar">أَفْكٌ</span>, <span class="auth">(with fet-ḥ, Ṣ, TA, its only form, TA, <span class="add">[in the CK <span class="ar">اِفْك</span>,]</span>)</span> <em>He changed his,</em> or <em>its, manner of being,</em> or <em>state;</em> <span class="auth">(Ṣ, Ḳ;)</span> and <em>he turned him,</em> or <em>it,</em> <span class="auth">(i. e., anything, Mṣb,)</span> <em>away,</em> or <em>back;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <span class="ar long">عَنِ الشَّىْءِ</span> <span class="add">[<em>from the thing</em>]</span>; <span class="auth">(Ṣ;)</span> or <span class="ar long">عَنْ وَجْهِهِ</span> <span class="add">[<em>from his,</em> or <em>its, mode,</em> or <em>manner, of being,</em>, &amp;c.]</span>: <span class="auth">(Mṣb:)</span> so in the Ḳur xlvi. 21, <span class="ar long">أَجِئْتَنَا لِتَأْفِكَنَا عَنْ آلِهَتِنَا</span> <em>Hast thou come to us to turn us away,</em> or <em>back, from our gods?</em> <span class="auth">(Bḍ:)</span> or <em>he turned him away,</em> or <em>back, by lying:</em> <span class="auth">(TA:)</span> or <em>he changed,</em> or <em>perverted, his judgment,</em> or <em>opinion:</em> <span class="auth">(Ḳ:)</span> or <em>he deceived him,</em> or <em>beguiled him, and so turned him away,</em> or <em>back:</em> and simply <em>he deceived him,</em> or <em>beguiled him:</em> and <span class="ar">أُفِكَ</span> signifies <em>he was turned from his judgment,</em> or <em>opinion, by deceit,</em> or <em>guile.</em> <span class="auth">(TA.)</span> It is said in the Ḳur <span class="add">[li. 9]</span>, <span class="ar long">يُؤْفَكُ عَنْهُ مَنْ أُفِكَ</span>, i. e., <em>He will be turned away from it</em> <span class="auth">(namely, the truth,)</span> <em>who is turned away</em> in the foreknowledge of God: <span class="auth">(TA:)</span> or, accord. to Mujáhid, <span class="ar long">يُؤْفَنُ عَنْهُ مَنْ أُفِنَ</span> <span class="add">[<em>he will be weak in intellect and judgment so as to be thereby turned away from it who is weak in intellect and judgment</em>]</span>. <span class="auth">(Ṣ, TA.)</span> You say also, <span class="ar long">أُفِكَ الرَّجُلُ عَنِ الخَيْرِ</span> <em>The man was turned away,</em> or <em>back, from good,</em> or <em>prosperity.</em> <span class="auth">(Sh.)</span> And <span class="ar">أَفَكَهُ</span>, <span class="auth">(Ḳ, TA,)</span> inf. n. as above, <span class="auth">(TA,)</span> <em>He forbade him what he wished,</em> <span class="auth">(Ḳ, TA,)</span> <em>and turned him away,</em> or <em>back, from it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Afk_1_A2">
					<p><span class="ar">أَفَكَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِكُ</span>}</span></add>; <span class="auth">(Mṣb, Ḳ;)</span> and <span class="ar">أَفِكَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْفَكُ</span>}</span></add>; <span class="auth">(IAạr, Ḳ;)</span> inf. n. <span class="ar">إِفْكٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">أَفْكٌ</span> and <span class="ar">أَفَكٌ</span> and <span class="ar">أُفُوكٌ</span>; <span class="auth">(Ḳ;)</span> <em>He lied; uttered a falsehood; said what was untrue;</em> <span class="auth">(Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">أفّك↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَأْفِيكٌ</span>: <span class="auth">(TA:)</span> because a lie is a saying that is turned from its proper way, or mode. <span class="auth">(Bḍ in xxiv. 11.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Afk_1_A3">
					<p><span class="ar long">أَفَكَ النَّاسَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِكُ</span>}</span></add>, inf. n. <span class="ar">أَفْكٌ</span>, <em>He told the people what was false;</em> <span class="ar">أَفَكَ</span> and <span class="ar">أَفَكْتُهُ</span> being like <span class="ar">كَذَبَ</span> and <span class="ar">كَذَبْتُهُ</span>. <span class="auth">(Az, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Afk_1_A4">
					<p><span class="ar long">أَفَكَ فُلَانًا</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَفْكٌ</span>; <span class="auth">(TA;)</span> or the verb is <span class="arrow"><span class="ar">آفَكَ↓</span></span>; <span class="auth">(so in the printed edition of Bḍ, xlvi. 27;)</span> <em>He,</em> or <em>it, made such a one to lie,</em> or <em>say what was untrue.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Afk_1_A5">
					<p><span class="ar">أُفِكَ</span> <em>He was weak</em> <span class="add">[<em>as though perverted</em>]</span> <em>in his intellect and judgment</em> or <em>opinion.</em> <span class="auth">(Ḳ,* TA.)</span> But <span class="ar long">أَفَكَهُ ٱللّٰهُ</span> as meaning <em>God rendered weak his intellect</em> is not used. <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Afk_1_A6">
					<p>‡ <em>It</em> <span class="auth">(a place)</span> <em>was not rained upon, and had no vegetation,</em> or <em>herbage.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Afk_2">
				<h3 class="entry">2. ⇒ <span class="ar">أفّك</span></h3>
				<div class="sense" id="Afk_2_A1">
					<p><a href="#Afk_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Afk_4">
				<h3 class="entry">4. ⇒ <span class="ar">آفك</span></h3>
				<div class="sense" id="Afk_4_A1">
					<p><a href="#Afk_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Afk_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتفك</span></h3>
				<div class="sense" id="Afk_8_A1">
					<p><span class="ar long">ٱئْتَفَكَتِ البَلْدَةُ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَفَكَت</span>]</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="ar">بِأَهْلِهَا</span>, <span class="auth">(Ṣ,)</span> <em>The land,</em> or <em>district,</em> or <em>the town,</em> or <em>the like, was,</em> or <em>became, overturned,</em> or <em>subverted,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>with its inhabitants:</em> <span class="auth">(Ṣ:)</span> as were the towns of the people of Lot. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Afk_8_A2">
					<p>Hence it is said of El-Basrah, <span class="ar long">قَدِ ٱئْتَفَكَتْ بِأَهْلِهَا مَرَّتَيْنِ</span>, meaning ‡ <em>It has been submerged with its inhabitants twice;</em> as though subverted. <span class="auth">(Sh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Afk_8_A3">
					<p>You say also, <span class="ar long">اِيتَفَكَتْ تِلْكَ الأَرْضُ</span> ‡ <em>That land has been burnt up by drought.</em> <span class="auth">(IAạr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IifokN">
				<h3 class="entry"><span class="ar">إِفْكٌ</span></h3>
				<div class="sense" id="IifokN_A1">
					<p><span class="ar">إِفْكٌ</span> <span class="add">[an inf. n. used as a subst.;]</span> <em>A lie; a falsehood;</em> <span class="auth">(Ṣ, TA;)</span> as also<span class="arrow"><span class="ar">أَفِيكَةٌ↓</span></span>: pl. <span class="auth">(of the latter, Ḳ)</span> <span class="ar">أَفَائِكُ</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say,<span class="arrow"><span class="ar long">يَا لَلْأَفِيكَةِ↓</span></span>, and<span class="arrow"><span class="ar long">يَا لِلْأَفِيكَةِ↓</span></span>; <span class="add">[and<span class="arrow"><span class="ar">لَلْأَفَيِّكَةِ↓</span></span>, using the dim. form for the purpose of enhancement; i. e. <em>O the lie!</em> and <em>O the great lie!</em>]</span> the <span class="ar">ل</span> with fet-ḥ denoting calling to aid; and with kesr denoting wonder, as though the meaning were, O man, wonder thou at this great lie. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Afkp">
				<h3 class="entry"><span class="ar">افكة</span></h3>
				<div class="sense" id="Afkp_A1">
					<p><span class="ar">افكة</span> <span class="add">[so in the TA, without any syll. signs; app. either <span class="ar">أَفْكَةٌ</span>, an inf. n. of un., or<span class="arrow"><span class="ar">آفِكَةٌ↓</span></span>, like <span class="ar">دَاهِيَةٌ</span>;]</span> <em>A punishment sent by God, whereby the dwellings of a people are overturned:</em> occurring in a trad. relating to the story of the people of Lot. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafikapN">
				<h3 class="entry"><span class="ar">أَفِكَةٌ</span></h3>
				<div class="sense" id="OafikapN_A1">
					<p><span class="ar long">سَنَةٌ أَفِكَةٌ</span> ‡ <em>A year of drought</em> or <em>sterility:</em> <span class="auth">(Ḳ, TA:)</span> <span class="pb" id="Page_0070"></span>pl. <span class="ar">أَوَافِكُ</span> <span class="add">[contr. to rule, as though the sing. were <span class="arrow"><span class="ar">آفِكَةٌ↓</span></span>]</span>. <span class="auth">(Z, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OafuwkN">
				<h3 class="entry"><span class="ar">أَفُوكٌ</span></h3>
				<div class="sense" id="OafuwkN_A1">
					<p><span class="ar">أَفُوكٌ</span>: <a href="#OafBaAkN">see <span class="ar">أَفَّاكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafiykN">
				<h3 class="entry"><span class="ar">أَفِيكٌ</span></h3>
				<div class="sense" id="OafiykN_A1">
					<p><span class="ar">أَفِيكٌ</span> One who is <em>turned from his judgment,</em> or <em>opinion, by deceit,</em> or <em>guile;</em> as also<span class="arrow"><span class="ar">مَأْفُوكٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">أَفِيكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OafiykN_A2">
					<p><em>Lacking strength</em> or <em>power</em> or <em>ability, and having little prudence and artifice.</em> <span class="auth">(Lth, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">أَفِيكٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OafiykN_B1">
					<p><a href="#OafBaAkN">See also <span class="ar">أَفَّاكٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafiykapN">
				<h3 class="entry"><span class="ar">أَفِيكَةٌ</span></h3>
				<div class="sense" id="OafiykapN_A1">
					<p><span class="ar">أَفِيكَةٌ</span>: <a href="#IifokN">see <span class="ar">إِفْكٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">أَفِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OafiykapN_A2">
					<p>Also <em>A severe,</em> or <em>distressing, calamity.</em> <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OufayBikapN">
				<h3 class="entry"><span class="ar">أُفَيِّكَةٌ</span></h3>
				<div class="sense" id="OufayBikapN_A1">
					<p><span class="ar">أُفَيِّكَةٌ</span>: <a href="#IifokN">see <span class="ar">إِفْكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafBaAkN">
				<h3 class="entry"><span class="ar">أَفَّاكٌ</span> / <span class="ar">أَفَّاكَةٌ</span></h3>
				<div class="sense" id="OafBaAkN_A1">
					<p><span class="ar">أَفَّاكٌ</span> <em>A great,</em> or <em>habitual, liar;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَفُوكُ↓</span></span>, <span class="auth">(Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">أَفِيكٌ↓</span></span>: <span class="auth">(Ḳ:)</span> fem. of the first <span class="add">[and last]</span> with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَفَّاكَةٌ</span>}</span></add>: but the second is both masc. and fem.: <span class="auth">(Mṣb:)</span> the pl. of the second is <span class="ar">افك</span> with damm <span class="add">[i. e. <span class="ar">أُفْكٌ</span>, accord. to the rule of the Ḳ, but the TA seems to indicate that it is <span class="ar">أُفُكٌ</span>, by likening it to <a href="#SabuwrN">the pl. of <span class="ar">صَبُورٌ</span></a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MfikapN">
				<h3 class="entry"><span class="ar">آفِكَةٌ</span></h3>
				<div class="sense" id="MfikapN_A1">
					<p><span class="ar">آفِكَةٌ</span>: <a href="#Afkp">see <span class="ar">افكة</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">آفِكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MfikapN_A2">
					<p><a href="#OafikpN">and see <span class="ar long">سَنَةٌ أَفِكةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOofuwkN">
				<h3 class="entry"><span class="ar">مَأْفُوكٌ</span></h3>
				<div class="sense" id="maOofuwkN_A1">
					<p><span class="ar">مَأْفُوكٌ</span> <span class="add">[<em>Changed in his,</em> or <em>its, manner of being,</em> or <em>state: turned away,</em> or <em>back, from a thing:</em>, &amp;c.]</span>: <a href="#maOofuwnN">see <span class="ar">مَأْفُونٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">مَأْفُوكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOofuwkN_A2">
					<p><em>Weak</em> <span class="add">[<em>as though perverted</em>]</span> <em>in his intellect</em> <span class="auth">(AZ, Ṣ, Ḳ)</span> <em>and judgment</em> or <em>opinion;</em> as also <span class="ar">ة</span>: <span class="auth">(AZ, Ṣ:)</span> accord. to AʼObeyd, <span class="auth">(or AA, as in one copy of the Ṣ,)</span> a man <em>who does not attain,</em> or <em>obtain, good,</em> or <em>prosperity.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">مَأْفُوكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOofuwkN_A3">
					<p>Also, <span class="auth">(Ḳ,)</span> fem. with <span class="ar">مَأْفُونٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> ‡ A place, <span class="auth">(Ḳ,)</span> or land, (<span class="ar">أَرْضٌ</span>, Ṣ, Z,) <em>not rained upon, and having no vegetation,</em> or <em>herbage.</em> <span class="auth">(Ṣ, Z, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmuWotafikaAtu">
				<h3 class="entry"><span class="ar">المُؤْتَفِكَاتُ</span></h3>
				<div class="sense" id="AlmuWotafikaAtu_A1">
					<p><span class="ar">المُؤْتَفِكَاتُ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">المُوْتَفِكَةٌ</span>, <span class="auth">(TA,)</span> both occurring in the Ḳur, <span class="add">[the former in ix. 71 and lxix. 9, and the latter in liii. 54,]</span> <em>The cities overthrown,</em> or <em>subverted, by God, upon the people of Lot.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افك</span> - Entry: <span class="ar">المُؤْتَفِكَاتُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlmuWotafikaAtu_A2">
					<p>The former also signifies <em>The winds that turn over</em> <span class="add">[<em>the surface of</em>]</span> <em>the earth,</em> or <em>ground:</em> <span class="auth">(Ḳ:)</span> or <em>the winds that blow from different quarters:</em> it is said <span class="auth">(by the Arabs, Ṣ)</span> that when these winds blow much, the earth <span class="auth">(i. e. its seed-produce, TA)</span> thrives, or yields increase. <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0069.pdf" target="pdf">
							<span>Lanes Lexicon Page 69</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
