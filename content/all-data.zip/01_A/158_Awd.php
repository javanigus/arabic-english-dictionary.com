<article class="root" id="Root_Awd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/157_Awb">اوب</a></span>
				<span class="ar">اود</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/159_Awz">اوز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Awd_1">
				<h3 class="entry">1. ⇒ <span class="ar">أود</span> ⇒ <span class="ar">آد</span></h3>
				<div class="sense" id="Awd_1_A1">
					<p><span class="ar">أَوِدَ</span>, aor. <span class="ar">يَأْوَدُ</span>, inf. n. <span class="ar">أَوَدٌ</span>, <em>It</em> <span class="auth">(a thing, T, Ṣ, M, or an arrow, AḤn, M)</span> <em>was,</em> or <em>became, of itself, crooked, curved,</em> or <em>bent.</em> <span class="auth">(T, Ṣ, M, A,* Ḳ.)</span> <span class="add">[<a href="#Awd_5">See also 5</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awd_1_B1">
					<p><span class="ar">آدَ</span>, aor. <span class="ar">يَؤُودُ</span>, inf. n. <span class="ar">أَوْدٌ</span>, <em>It</em> <span class="auth">(the day)</span> <em>receded,</em> in the evening. <span class="auth">(T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Awd_1_B2">
					<p><em>It</em> <span class="auth">(the evening, T, Ṣ)</span> <em>declined.</em> <span class="auth">(T, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Awd_1_B3">
					<p><em>It</em> <span class="auth">(a thing, L)</span> <em>returned.</em> <span class="auth">(M, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Awd_1_B4">
					<p><span class="ar long">آدَتِ الظِّلَالِ</span> <em>The shadows returned, and inclined towards the east.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="Awd_1_B5">
					<p><span class="ar long">آدَ عَلَيْهِ</span> <em>He inclined towards him;</em> or <em>pitied him.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Awd_1_C1">
					<p><span class="ar">آدَهُ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> first pers. <span class="ar">أُدْتُهُ</span>, <span class="auth">(M,)</span> or <span class="ar">أُدتُّهُ</span>, <span class="auth">(Ḳ, TA, <span class="add">[in the CK, erroneously, <span class="ar">اِدتُّهُ</span>,]</span>)</span> aor. <span class="ar">يَؤُودُ</span>, inf. n. <span class="ar">أَوْدٌ</span>, <span class="auth">(Aṣ, T, M, Mṣb,)</span> <em>He crooked, curved,</em> or <em>bent, it;</em> <span class="auth">(Aṣ, T, Ṣ, L, Mṣb, Ḳ;)</span> i. e., a stick, <span class="auth">(Aṣ, T, L,)</span> or other thing; <span class="auth">(L;)</span> as also<span class="arrow"><span class="ar">أوّدهُ↓</span></span>. <span class="auth">(L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Awd_1_C2">
					<p><span class="ar">آدَهُ</span>, aor. <span class="ar">يَؤُودُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">أَوْدٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">أُوُودٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>It</em> <span class="auth">(a load)</span> <em>oppressed him by its weight; pressed heavily upon him; burdened him.</em> <span class="auth">(AZ, T, Ṣ, A, Mṣb.)</span> And <em>It</em> <span class="auth">(a thing, or an affair,)</span> <em>oppressed, distressed,</em> or <em>afflicted, him:</em> <span class="auth">(M, L, Ḳ:)</span> <span class="pb" id="Page_0125"></span>and <span class="add">[in like manner]</span> <span class="arrow"><span class="ar">تأوّدهُ↓</span></span>, <span class="auth">(L, Ḳ,)</span>or<span class="arrow"><span class="ar">تآودهُ↓</span></span>, <span class="auth">(T,)</span> as also <span class="ar">تآداهُ</span>, <span class="auth">(L, Ḳ,)</span> the last formed by transposition <span class="auth">(T, L)</span> from the second, <span class="auth">(T,)</span> or first, <span class="auth">(L,)</span> said of an affair, <em>it pressed heavily upon him; oppressed him.</em> <span class="auth">(T, L, Ḳ.)</span> You say,<span class="arrow"><span class="ar long">مَا آدَكَ فَهْوَ لِى آئِدٌ↓</span></span> <em>What hath burdened</em> <span class="add">[or <em>distressed</em>]</span> <em>thee, it</em> <span class="auth">(that thing)</span> <em>is burdening</em> <span class="add">[or <em>distressing</em>]</span> <em>to me.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أوّد</span></h3>
				<div class="sense" id="Awd_2_A1">
					<p><a href="#Awd_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأوّد</span></h3>
				<div class="sense" id="Awd_5_A1">
					<p><span class="ar">تأوّد</span> <em>It</em> <span class="auth">(a stick, T, L, or some other thing, L)</span> <em>became, by an extraneous operation, crooked, curved,</em> or <em>bent;</em> <span class="auth">(T, Ṣ, M, A, L, Ḳ;)</span> as also<span class="arrow"><span class="ar">انآد↓</span></span>. <span class="auth">(T, Ṣ, M, L, Ḳ: <span class="add">[in the CK <span class="ar">فَأْتادَ</span> is erroneously put for <span class="ar">فَٱنْآدَ</span>.]</span>)</span> El-ʼAjjáj says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَمْ يَكُ يَنْآدُ فَأَمْسَى ٱنْآدَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>He used not to become bent, and he has become bent</em>]</span>, making the pret. to be a denotative of state because <span class="ar">قَدْ</span> is meant to be understood, as in the saying in the Ḳur <span class="add">[iv. 92]</span>, <span class="ar long">أَوْ جَاؤُوكُمْ حَصِرَتْ صُدُورُهُمْ</span>. <span class="auth">(Ṣ.)</span> You say also, <span class="ar long">تَأَوَّدَتْ فِى قِيَامِهَا</span> <em>She</em> <span class="auth">(a woman)</span> <em>bent in her rising, by reason of her heaviness.</em> <span class="auth">(T and L in art. <span class="ar">وأد</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awd_5_B1">
					<p><a href="#Awd_1_C2">see <span class="ar">آدَهُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awd_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآود</span></h3>
				<div class="sense" id="Awd_6_A1">
					<p><span class="ar">تآودهُ</span>: <a href="#Awd_1_C2">see <span class="ar">آدَهُ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awd_7">
				<h3 class="entry">7. ⇒ <span class="ar">انأود</span> ⇒ <span class="ar">انآد</span></h3>
				<div class="sense" id="Awd_7_A1">
					<p><span class="ar">انآد</span>: <a href="#Awd_5">see 5</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اود</span> - Entry: 7.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awd_7_A2">
					<p>Also <em>He became oppressed,</em> or <em>burdened</em> <span class="add">[by a load]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawidN">
				<h3 class="entry"><span class="ar">أَوِدٌ</span></h3>
				<div class="sense" id="OawidN_A1">
					<p><span class="ar">أَوِدٌ</span>; <span class="auth">(T, M;)</span> or<span class="arrow"><span class="ar">آوَدُ↓</span></span>; fem. <span class="ar">أَوْدَآءُ</span>; <span class="auth">(Ḳ;)</span> <em>Crooked, curved,</em> or <em>bent.</em> <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mwadu">
				<h3 class="entry"><span class="ar">آوَدُ</span></h3>
				<div class="sense" id="Mwadu_A1">
					<p><span class="ar">آوَدُ</span>; fem. <span class="ar">أَوْدَآءُ</span>: <a href="#OawidN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYidN">
				<h3 class="entry"><span class="ar">آئِدٌ</span></h3>
				<div class="sense" id="MYidN_A1">
					<p><span class="ar">آئِدٌ</span> <em>Burdening</em> <span class="add">[or <em>distressing</em>]</span>. <span class="auth">(Ṣ.)</span> <a href="#Awd_1">See 1</a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maWuwdN">
				<h3 class="entry"><span class="ar">مَؤُودٌ</span></h3>
				<div class="sense" id="maWuwdN_A1">
					<p><span class="ar">مَؤُودٌ</span> <em>Oppressed, pressed heavily upon,</em> or <em>burdened,</em> by a load. <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maMwidu">
				<h3 class="entry"><span class="ar">مَآوِدُ</span></h3>
				<div class="sense" id="maMwidu_A1">
					<p><span class="ar">مَآوِدُ</span> <em>Calamities:</em> <span class="auth">(IAạr, M, L, Ḳ:)</span> as also <span class="ar">مَوَائِدُ</span>, which is app. formed by transposition. <span class="auth">(M, L.)</span> Some say that <span class="ar">مآود</span> <a href="#muWoyidN">is pl. of <span class="ar">مُؤْيِدٌ</span></a>, and derive this word <span class="add">[<a href="#muWoyidN">which see</a> <a href="index.php?data=01_A/173_Ayd">in art. <span class="ar">ايد</span></a>]</span> from <span class="ar">آدَهُ</span>, aor. <span class="ar">يَؤُودٌ</span>, meaning “it oppressed him by its weight:” <span class="auth">(T, L:)</span> or it has no sing. <span class="auth">(IAạr, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0124.pdf" target="pdf">
							<span>Lanes Lexicon Page 124</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0125.pdf" target="pdf">
							<span>Lanes Lexicon Page 125</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
