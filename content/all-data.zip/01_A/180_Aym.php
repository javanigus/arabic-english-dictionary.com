<article class="root" id="Root_Aym">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/179_Ayl">ايل</a></span>
				<span class="ar">ايم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/181_Ayn">اين</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Aym_1">
				<h3 class="entry">1. ⇒ <span class="ar">أيم</span> ⇒ <span class="ar">آم</span></h3>
				<div class="sense" id="Aym_1_A1">
					<p><span class="ar">آمَتْ</span>, <span class="auth">(T, M, Mgh, Ḳ,)</span> aor. <span class="ar">تَئِيمُ</span>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">أَيْمَةٌ</span>, <span class="auth">(T, M, Mgh, Ḳ,)</span> or this is a simple subst., <span class="auth">(Mṣb,)</span> and <span class="ar">إِيمَةٌ</span> and <span class="ar">أَيْمٌ</span> and <span class="ar">أُيُومٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>She had no husband;</em> said of a virgin and of one who is not a virgin; <span class="auth">(IAạr, T, M, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">تأيّمت↓</span></span> <span class="auth">(Lth, T, M)</span> and<span class="arrow"><span class="ar">ائتامت↓</span></span>: <span class="auth">(M:)</span> or, as some say, <span class="arrow"><span class="ar">تأيّمت↓</span></span> signifies <em>she lost her husband by his death, she being still fit for husbands, having in her a remaining force of youth:</em> <span class="auth">(T:)</span> and you say, <span class="ar long">آمَتْ مِنْ زَوْجِهَا</span>, aor. <span class="ar">تَئِيمُ</span>, inf. n. <span class="ar">أَيْمَةٌ</span> and <span class="ar">أَيْمٌ</span> and <span class="ar">أُيُومٌ</span>, <span class="auth">(Ṣ, TA, <span class="add">[accord. to the former app. signifying the same as <span class="ar">آمَتْ</span> alone as explained above: or]</span>)</span> meaning <em>she became bereft of her husband by his death, or by his being slain, and remained without marrying.</em> <span class="auth">(TA.)</span> And <span class="ar">آمَ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> aor. <span class="ar">يَئِيمُ</span>, <span class="auth">(T, Mṣb,)</span> inf. n. <span class="ar">أَيْمَةٌ</span>, <span class="auth">(T,)</span> <em>He had no wife:</em> <span class="auth">(T, Mṣb:)</span> or <em>he lost his wife by her death:</em> <span class="auth">(Ṣ,* Ḳ,* and Ḥam p. 650:)</span> and <em>he did not marry;</em> as also<span class="arrow"><span class="ar">تأيّم↓</span></span>. <span class="auth">(Ḥam ubi suprà.)</span> It is said of the Prophet, in a trad., <span class="ar long">كَانَ يَتَعَوَّذُ مِنَ الأَيْمَةِ</span> <span class="auth">(T, Ṣ)</span> <em>He used to pray for preservation from remaining long without a wife.</em> <span class="auth">(T.)</span> And Yezeed Ibn-El-Hakam Eth-Thakafee says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">كُلُّ ٱمْرِئٍ سَتَئِيمُ مِنْهُ العِرْسُ أَوْمِنْهَا يَئِيمُ</span> *</div> 
					</blockquote>
					<p><span class="auth">(Ṣ)</span> i. e. <em>Every man, the wife will be bereft of him by his death, or he will be bereft of her by her death.</em> <span class="auth">(Ḥam p. 531.)</span> <span class="pb" id="Page_0138"></span>One says also, <span class="ar long">مَا لَهُ آمَ وَعَامَ</span>, meaning <span class="add">[<em>What aileth him?</em>]</span> <em>May his wife and his cattle die,</em> or <em>perish, so that he shall have no wife</em> (<span class="ar long">حَتَّى يَئيِمَ</span>) <em>and be vehemently desirous of milk</em> (<span class="ar">يَعِيمَ</span>). <span class="auth">(Ṣ, Ḳ: <span class="add">[in the CK, erroneously, <span class="ar long">امٌ و عامٌ</span>; and in a MṢ. copy of the Ḳ <span class="ar long">آمٌ ولاعامٌ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aym_2">
				<h3 class="entry">2. ⇒ <span class="ar">أيّم</span></h3>
				<div class="sense" id="Aym_2_A1">
					<p><span class="ar long">أَيَّمَهُ ٱللّٰهُ</span> inf. n. <span class="ar">تَأْيِيمٌ</span>, <em>God made him to have no wife.</em> <span class="auth">(Ḳ,* TḲ.)</span> And <span class="ar long">أَيَّمْتُ المَرْأَةَ</span>, inf. n. as above; <span class="auth">(Ḥam p. 11, and TA;*)</span> or<span class="arrow"><span class="ar long">أَأَ مْتُهَا↓</span></span>, like <span class="ar">أَعَمْتُهَا</span>; <span class="auth">(T, Ṣ;)</span> <em>I made the woman to be a widow, by slaying her husband.</em> <span class="auth">(T,* Ṣ, and Ḥam ubi suprà.)</span> Taäbata-sharrà says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَأَيَّمْتُ نِسْوَانًا وَأَيْتَمْتُ إِلْدَةً</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And I have made women widows, by slaying their husbands; and children fatherless</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Aym_4">
				<h3 class="entry">4. ⇒ <span class="ar">آيم</span></h3>
				<div class="sense" id="Aym_4_A1">
					<p><span class="ar long">أَأَمْتُ المَرْأَةَ</span>: <a href="#Aym_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aym_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأيّم</span></h3>
				<div class="sense" id="Aym_5_A1">
					<p><span class="ar">تَأَيَّمَتْ</span> and <span class="ar">تأيّم</span>: <a href="#Aym_1">see 1</a>, in three places. The former is also explained as signifying <em>She became forlorn</em> (<span class="ar">تَحَوَّشَتْ</span>) <em>of her husband.</em> <span class="auth">(Ḳ in art. <span class="ar">حوش</span>.)</span> And also, <span class="auth">(TA,)</span> or <span class="ar long">تَأَيَّمَتْ زَمَانًا</span>, <span class="auth">(ISk, T, Ṣ,)</span> <em>She remained some time without marrying.</em> <span class="auth">(ISk, T, Ṣ, TA.)</span> And <span class="ar">تأيّم</span>, <span class="auth">(Mṣb, Ḳ,)</span> or <span class="ar long">تأيّم زَمَانًا</span>, <span class="auth">(ISk, T, Ṣ,)</span> <em>He remained some time without marrying.</em> <span class="auth">(ISk, T, Ṣ Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aym_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتيم</span></h3>
				<div class="sense" id="Aym_8_A1">
					<p><span class="ar">ٱئْتَامَتْ</span>, written with the disjunctive alif <span class="ar">اِيتَامَتْ</span>: <a href="#Aym_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايم</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Aym_8_B1">
					<p><span class="ar">ٱئْتَمْتُهَا</span>, <span class="auth">(M, Ḳ,)</span> like <span class="ar">ٱعْتَمْتُهَا</span>, <span class="auth">(TA,)</span> <em>I took her as my wife, she being what is termed</em> <span class="ar">أَيِّم</span> <span class="add">[<em>without a husband</em>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oayoma">
				<h3 class="entry"><span class="ar">أَيْمَ</span></h3>
				<div class="sense" id="Oayoma_A1">
					<p><span class="ar">أَيْمَ</span> is a contraction of <span class="ar long">أَىُّ مَا</span>, meaning <span class="ar long">أَىُّ شَىْءٍ</span>: it is thus in the saying, <span class="ar long">أَيْمَ هُوَيَا فُلَانُ</span> <span class="add">[<em>What thing is it, O such a one?</em>]</span>: and <span class="ar long">أَيْمَ تَقُولُ</span> <span class="add">[<em>What thing sayest thou?</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايم</span> - Entry: <span class="ar">أَيْمَ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oayoma_B1">
					<p><span class="ar long">اَيْمُ ٱللّٰهِ</span> <span class="add">[for <span class="ar long">اَيْمُنُ ٱللّٰهِ</span>]</span>: <a href="index.php?data=28_e/027_ymn">see in art. <span class="ar">يمن</span></a>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayamBu">
				<h3 class="entry"><span class="ar">أَيَمُّ</span></h3>
				<div class="sense" id="OayamBu_A1">
					<p><span class="ar">أَيَمُّ</span>, for <span class="ar">أَأَمُّ</span>: <a href="index.php?data=01_A/128_Am">see art. <span class="ar">ام</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayomaA">
				<h3 class="entry"><span class="ar">أَيْمَا</span></h3>
				<div class="sense" id="OayomaA_A1">
					<p><span class="ar">أَيْمَا</span>: <a href="#OamBaA">see <span class="ar">أَمَّا</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايم</span> - Entry: <span class="ar">أَيْمَا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OayomaA_B1">
					<p><a href="#IimBaA">and <span class="ar">إِمَّا</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiymaA">
				<h3 class="entry"><span class="ar">إِيمَا</span></h3>
				<div class="sense" id="IiymaA_A1">
					<p><span class="ar">إِيمَا</span>: <a href="#IimBaA">see <span class="ar">إِمَّا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayomaAnu">
				<h3 class="entry"><span class="ar">أَيْمَانُ</span></h3>
				<div class="sense" id="OayomaAnu_A1">
					<p><span class="ar">أَيْمَانُ</span> A man <em>whose wife has died:</em> and <span class="ar">أَيْمَى</span> A woman <em>whose husband has died:</em> pl. <span class="ar">أَيَامَى</span>, of both; like as <span class="ar">سَكَارَى</span> <a href="#sakoraAnu">is pl. of <span class="ar">سَكْرَانُ</span></a>: accord. to ISk, <span class="ar">أَيَامَى</span> is originally <span class="ar">أَيَائِمُ</span>. <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#OayBimN">See also <span class="ar">أَيِّمٌ</span></a>.]</span> <span class="ar long">أَيْمَانُ عَيْمَانُ</span> are epithets applied to a man, <span class="auth">(M, Ḳ, TA,)</span> meaning <em>Whose wife</em> <span class="add">[<em>and cattle</em>]</span> <em>have died</em> or <em>perished</em> <span class="add">[<em>so that he has no wife and is vehemently desirous of milk;</em> as shown above; <a href="#Aym_1">see 1</a>, last signification]</span>: <span class="auth">(TA:)</span> the former relates to wives; and the latter, to milk: <span class="auth">(Ṣ, Ḳ, TA:)</span> fem. <span class="ar long">أَيْمَى عَيْمَى</span>, applied to a woman. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBimN">
				<h3 class="entry"><span class="ar">أَيِّمٌ</span></h3>
				<div class="sense" id="OayBimN_A1">
					<p><span class="ar">أَيِّمٌ</span> A woman <em>having no husband;</em> <span class="auth">(Lth, T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> <em>whether she be a virgin or not;</em> <span class="auth">(IAạr, T, Ṣ, M, Mgh, Ḳ;)</span> or <em>whether she have married before or not;</em> <span class="auth">(Ṣgh, Mṣb;)</span> as also <span class="ar">أَيِّمَةٌ</span>; <span class="auth">(Mṣb;)</span> <span class="add">[said to be]</span> applied to one <em>who has not married:</em> <span class="auth">(IAạr, T:)</span> or <em>if not a virgin;</em> accord. to <span class="add">[the Imám]</span> Moḥammad; agreeably with a reading of a trad. by which the <span class="ar">أَيِّم</span> is distinguished from the virgin: <span class="auth">(Mgh:)</span> also, the former, a man <em>having no wife;</em> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ;)</span> <em>whether he have married before or not:</em> <span class="auth">(Ṣ, Ṣgh, Ḳ:)</span> or <em>who has not married:</em> <span class="auth">(IAạr, T:)</span> pl. <span class="ar">أَيَامَى</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">أَيَائِمُ</span>; <span class="auth">(M, Ḳ;)</span> the latter of which is the original form: <span class="auth">(Ṣ, M:)</span> <span class="add">[or both, accord. to the Mṣb, are pls. of <span class="ar">أَيْمَانُ</span>, q. v.:]</span> and <span class="ar">أَيِّمُونَ</span> is a pl. applied to men, and <span class="ar">أَيِّمَاتٌ</span> applied to women: and <span class="ar">آمَةٌ</span>, also, signifying men <em>having no wives,</em> is pl. of<span class="arrow"><span class="ar">آئِمٌ↓</span></span> for <span class="ar">أَيِّمٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايم</span> - Entry: <span class="ar">أَيِّمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OayBimN_A2">
					<p>Also A <em>free</em> woman: <span class="auth">(Ḳ:)</span> pl., in this sense also, <span class="ar">أَيَامَى</span>, used in this sense in the Ḳur xxiv. 32, <span class="auth">(T, TA,)</span> accord. to some. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايم</span> - Entry: <span class="ar">أَيِّمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OayBimN_A3">
					<p>And <em>A female relation;</em> <span class="auth">(Ḳ;)</span> in which sense also <span class="ar">أَيَامَى</span> is pl.; <span class="auth">(T, TA;)</span> meaning <em>such as the daughter and the sister and the maternal aunt.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MYimN">
				<h3 class="entry"><span class="ar">آئِمٌ</span></h3>
				<div class="sense" id="MYimN_A1">
					<p><span class="ar">آئِمٌ</span>: <a href="#OayBimN">see <span class="ar">أَيِّمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoyamapN">
				<h3 class="entry"><span class="ar">مَأْيَمَةٌ</span></h3>
				<div class="sense" id="maOoyamapN_A1">
					<p><span class="ar long">الحَرْبُ مَأْيَمَةٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> <span class="ar">لِلنِّسآءَ</span> <span class="auth">(M, Ḳ)</span> <em>War is a cause of widowing to women; it slays the men, and leaves the wives without husbands.</em> <span class="auth">(T, Ṣ, M, Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWoyamapN">
				<h3 class="entry"><span class="ar">مُؤْيَمَةٌ</span></h3>
				<div class="sense" id="muWoyamapN_A1">
					<p><span class="ar">مُؤْيَمَةٌ</span> A <em>rich,</em> or <em>wealthy, woman,</em> or one <em>possessing competence</em> or <em>sufficiency, having no husband.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maMYimu.1">
				<h3 class="entry"><span class="ar">مَآئِمُ</span></h3>
				<div class="sense" id="maMYimu.1_A1">
					<p><span class="ar">مَآئِمُ</span>: <a href="#AmBapN">see <span class="ar">آمَّةٌ</span></a>, <a href="index.php?data=01_A/128_Am">in art. <span class="ar">ام</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0138.pdf" target="pdf">
							<span>Lanes Lexicon Page 138</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
