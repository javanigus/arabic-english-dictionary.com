<article class="root" id="Root_Arx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/052_Arj">ارج</a></span>
				<span class="ar">ارخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/054_Arz">ارز</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Arx_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرخ</span></h3>
				<div class="sense" id="Arx_1_A1">
					<p><span class="ar long">أَرَخَ الكِتَابَ</span>: <a href="#Arx_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arx_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّخ</span></h3>
				<div class="sense" id="Arx_2_A1">
					<p><span class="ar long">أَرَّخَ الكِتَابَ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَأْرِيخٌ</span>; <span class="auth">(Ṣ, Mgh;)</span> and<span class="arrow"><span class="ar">أَرَخَهُ↓</span></span>, <span class="auth">(IḲṭṭ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَرْخٌ</span>; <span class="auth">(TA;)</span> but the former is the more common, <span class="auth">(Mṣb,)</span> and the latter is by some rejected, though correct accord. to IḲṭṭ and others; <span class="auth">(MF;)</span> and<span class="arrow"><span class="ar">آرخهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُؤَارَخَةٌ</span>; <span class="auth">(TA;)</span> as also <span class="ar">وَرَّخَهُ</span>, inf. n. <span class="ar">تَوْرِيخٌ</span>; <span class="auth">(Ṣ, Mgh,* Mṣb;)</span> in which the <span class="ar">و</span> is a substitute for the <span class="ar">ء</span>; <span class="auth">(Yaạḳoob, Mṣb;)</span> a form seldom used; <span class="auth">(Mṣb;)</span> <em>He dated the writing,</em> or <em>letter; inscribed it with a date,</em> or <em>note of the time when it was written.</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ.)</span> You say also, <span class="ar long">أَرَّخَ الكِتَابَ بِيَوْمِ كَذَا</span> <em>He inscribed the writing,</em> or <em>letter, with the date of such a day.</em> <span class="auth">(Ṣ, L.)</span> And <span class="ar long">أَرَّخَ البَيِّنَةَ</span> <em>He dated,</em> or <em>mentioned the date of, the evidence, proof,</em> or <em>voucher:</em> in the contr. case saying, <span class="ar">أَطْلَقَ</span>. <span class="auth">(Mṣb.)</span> Some say that <span class="ar">تأريخ</span> is an arabicized word, <span class="auth">(L, Mṣb,)</span> borrowed by the Muslims from the people of the Bible: <span class="add">[i. e., from the Jews or Christians; app. from the Hebr. <span class="he">יָרֵחַ</span> the “moon,” or <span class="he">יֶרַח</span> “a month;“or from the Chald. <span class="he">יְרַח</span> “a month;” as observed by Golius:]</span> <span class="auth">(L:)</span> others say that it is <span class="add">[pure]</span> Arabic: <span class="auth">(Mṣb, TA:)</span> some, that it is formed by transposition from <span class="ar">تَأْخِيرٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Arx_3">
				<h3 class="entry">3. ⇒ <span class="ar">آرخهُ</span></h3>
				<div class="sense" id="Arx_3_A1">
					<p><a href="#Arx_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuroxapN">
				<h3 class="entry"><span class="ar">أُرْخَةٌ</span></h3>
				<div class="sense" id="OuroxapN_A1">
					<p><span class="ar">أُرْخَةٌ</span>: <a href="#taOoriyxN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOoriyxN">
				<h3 class="entry"><span class="ar">تَأْرِيخٌ</span></h3>
				<div class="sense" id="taOoriyxN_A1">
					<p><span class="ar">تَأْرِيخٌ</span> <a href="#Arx_2">inf. n. of 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارخ</span> - Entry: <span class="ar">تَأْرِيخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taOoriyxN_A2">
					<p>Also, <span class="add">[as a subst., generally pronounced without <span class="ar">ء</span>,]</span> <em>A date; an era; an epoch;</em> <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">أُرْخَةٌ↓</span></span> is a subst. <span class="add">[signifying the same,]</span> from <span class="ar">أَرَخَ</span>. <span class="auth">(Ḳ.)</span> <span class="ar long">تَأْرِيخُ الهِجْرَةِ</span> is <em>The era,</em> or <em>epoch, of the Emigration</em> <span class="add">[or <em>Flight</em> <span class="auth">(for such it really was)</span>]</span> of Moḥammad <span class="add">[from Mekkeh to El-Medeeneh]</span>, <span class="auth">(L, Mṣb,)</span> which his companions, in the time of ʼOmar, agreed to make their era, commencing the year from the first appearance of the new moon of <span class="add">[the month]</span> El-Moharram, <span class="add">[two months before the Flight itself,]</span> and making the day to commence from sunset: <span class="auth">(Mṣb:)</span> it is also called <span class="ar long">تَأْرِيخَ المُسْلِمِينَ</span> <em>the era,</em> or <em>epoch, of the Muslims.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارخ</span> - Entry: <span class="ar">تَأْرِيخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taOoriyxN_A3">
					<p>Also The <em>utmost limit, term,</em> or <em>time,</em> of anything: whence the saying, <span class="ar long">فُلَانٌ تَأْرِيخُ قُوْمِهِ</span> <em>Such a one is the person from whom date the nobility,</em> or <em>eminence, and dominion,</em> or <em>authority, of his people.</em> <span class="auth">(Eṣ-Ṣoolee, Mgh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارخ</span> - Entry: <span class="ar">تَأْرِيخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taOoriyxN_A4">
					<p><span class="add">[Also, <em>A chronicle; a book of annals; a history:</em> pl. <span class="ar">تَوَارِيخُ</span>, from <span class="ar">تَوْرِيخٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWarBixN">
				<h3 class="entry"><span class="add">[<span class="ar">مُؤَرِّخٌ</span>]</span></h3>
				<div class="sense" id="muWarBixN_A1">
					<p><span class="add">[<span class="ar">مُؤَرِّخٌ</span> <em>A chronicler; a writer of annals; a historian.</em>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0046.pdf" target="pdf">
							<span>Lanes Lexicon Page 46</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
