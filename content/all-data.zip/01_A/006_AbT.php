<article class="root" id="Root_AbT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/005_AbD">ابض</a></span>
				<span class="ar">ابط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/007_Abq">ابق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AbT_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبط</span></h3>
				<div class="sense" id="AbT_1_A1">
					<p><span class="ar">أَبَطَهُ</span> <em>i. q.</em> <span class="ar">هَبَطَهُ</span>, q. v.: <span class="auth">(IAạr, Az, Ṣgh, Ḳ:)</span> said of God. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AbT_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّط</span></h3>
				<div class="sense" id="AbT_5_A1">
					<p><span class="ar">تأبّطهُ</span> <em>He put it</em> <span class="auth">(a thing, Ṣ Mgh, Mṣb)</span> <em>beneath his</em> <span class="ar">إِبْط</span> <span class="add">[or <em>arm-pit</em>]</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> or in <em>his</em> <span class="ar">إِبْط</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<span class="pb" id="Page_0007"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AbT_5_A2">
					<p>Hence, <span class="auth">(Ḳ,)</span> <span class="ar long">تَأَبَّطَ شَرَّا</span>, the surname of Thábit the son of Jábir <span class="auth">(Ṣ, Ḳ)</span> El-Fahmee: <span class="auth">(Ṣ:)</span> because they assert that the sword never quitted him: <span class="auth">(Ṣ:)</span> or because he put beneath his arm-pit a quiver of arrows, and took a bow, or put beneath his arm-pit a knife, and came to an assembly of Arabs, and smote some of them. <span class="auth">(Ḳ.)</span> It is invariable: but if you desire to express the dual or pl., you say, <span class="ar long">ذَوَا تَأَبَّطَ شَرًّا</span> and <span class="ar long">ذَوُو تَأَبَّطَ شَرٍّا</span>, or you say <span class="ar">كِلَاهُمَا</span> and <span class="ar">كُلُّهُمْ</span>. <span class="auth">(Ṣ.)</span> It does not admit of the formation of a dim., nor is it abridged: <span class="auth">(Ṣ, Ḳ:)</span> but some of the Arabs used to say <span class="ar">تَأَبَّطُ</span> <span class="add">[so written with refa]</span>, using a single word, accord. to Sb, as is said in the L. <span class="auth">(TA.)</span> Its rel. n. is <span class="arrow">↓<span class="ar">تَأَبَّطِىٌّ</span></span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AbT_5_A3">
					<p><span class="add">[Hence also]</span> <span class="ar long">تأبّط فُلَانٌ فُلَانًا</span> † <em>Such a one placed such a one under his protection.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="AbT_5_A4">
					<p><span class="ar">تأبّط</span> also signifies <em>He put his</em> <span class="ar">رِدَآء</span>, <span class="auth">(Ṣ,)</span> or <em>garment,</em> <span class="auth">(Mgh, Ḳ,)</span> <em>under his right arm, and then threw</em> <span class="add">[<em>a portion of</em>]</span> <em>it over his left shoulder,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> in prayer, or in <span class="ar">إِحْرَام</span>; <span class="auth">(Mgh;)</span> as also <span class="ar">اِضْطَبَعَ</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#tawaXBaHa">See also <span class="ar">تَوَشَّحَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboTN">
				<h3 class="entry"><span class="ar">إِبْطٌ</span></h3>
				<div class="sense" id="IiboTN_A1">
					<p><span class="ar">إِبْطٌ</span> <span class="add">[The <em>armpit;</em>]</span> the <em>inner side of the shoulderjoint:</em> <span class="auth">(ISd, Ḳ:)</span> or the <em>part beneath the</em> <span class="ar">جَنَاح</span> <span class="add">[which signifies the <em>arm, upper arm, armpit,</em> and <em>wing,</em>, &amp;c.]</span>: <span class="auth">(Ṣ, Mṣb:)</span> also written <span class="arrow">↓<span class="ar">إِبِطٌ</span></span>; <span class="auth">(Mṣb, Ḳ;)</span> which is said to be a dial. var. by some of the moderns; but this is strange, on account of what is said respecting <span class="ar">إِبِلٌ</span>; <span class="auth">(Mṣb;)</span> for Sb says that there are only two substs. of the measure <span class="ar">فِعِلٌ</span>, which are <span class="ar">إِبِلٌ</span> and <span class="ar">حِبِرٌ</span>; and one epithet, namely <span class="ar">بِلِزٌ</span>: other instances have been mentioned, but their transmission from Sb is not established: <span class="auth">(Mṣb. in art. <span class="ar">ابل</span>:)</span> it is also said that there is no other word like <span class="ar">إِبِلٌ</span>; but this means, in its original form, and does not deny that there are words like it by the insertion of a second vowel like the first, such as this and many other words: <span class="auth">(TA:)</span> <span class="add">[<a href="#IibidN">see also <span class="ar">إِبِدٌ</span></a>:]</span> it is fem.; <span class="auth">(Mgh;)</span> or masc. and fem.; <span class="auth">(Ṣ, Mṣb;)</span> sometimes the latter; <span class="auth">(Lḥ, Ḳ;)</span> but the making it masc. is more approved: <span class="auth">(TA:)</span> Fr cites, from certain of the Arabs, the phrase, <span class="auth">(Ṣ,)</span> <span class="ar long">فَرَفَعَ السَّوْطَ حَتَّى بَرَقَتْ إِبْطُهُ</span> <span class="add">[<em>And he raised the whip so that his armpit shone</em>]</span>: <span class="auth">(Ṣ, Mṣb:)</span> the pl. is <span class="ar">آبَاطٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: <span class="ar">إِبْطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiboTN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">ضَرَبَ آبَاطَ الأُمُورِ وَمَغَابِنَهَا</span> ‡ <span class="add">[<em>He hit the secret and occult particulars of the affairs</em>]</span>. <span class="auth">(A, TA <span class="add">[followed by the words <span class="ar long">وَٱشْتَقَّ ضَمَائِرَهَا وَبَوَاطِنَهَا</span>, a pleonastic addition, merely explaining what goes before.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: <span class="ar">إِبْطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiboTN_A3">
					<p>And <span class="ar long">ضَرَبَ آبَاطَ المَفَازَةِ</span> ‡ <span class="add">[<em>He traversed the recesses of the desert</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: <span class="ar">إِبْطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiboTN_A4">
					<p>And <span class="ar long">إِبْطُ جَبَلٍ</span> † <em>The foot,</em> or <em>bottom,</em> or <em>lowest part,</em> (<span class="ar">سَفَحْ</span>,) <em>of a mountain.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: <span class="ar">إِبْطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IiboTN_A5">
					<p>And <span class="ar long">إِبْطُ رَمْلٍ</span> † <em>The place where the main body of sand ends:</em> <span class="auth">(Ṣ:)</span> or <em>what is thin, of sand:</em> <span class="auth">(Ḳ:)</span> or <em>the lowest part of an oblong tract of sand collected together and elevated, where the main body thereof ends, and it becomes thin.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: <span class="ar">إِبْطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IiboTN_A6">
					<p>And <span class="ar long">إِبعطُ الشِّمَالِ</span> † <em>Evil fortune; ill luck.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibiTN">
				<h3 class="entry"><span class="ar">إِبِطٌ</span></h3>
				<div class="sense" id="IibiTN_A1">
					<p><span class="ar">إِبِطٌ</span>: <a href="#IiboTN">see <span class="ar">إِبْطٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboTiyBN">
				<h3 class="entry"><span class="ar">إِبْطِيٌّ</span></h3>
				<div class="sense" id="IiboTiyBN_A1">
					<p><span class="ar">إِبْطِيٌّ</span> <span class="add">[<em>Of,</em> or <em>relating to, the armpit</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابط</span> - Entry: <span class="ar">إِبْطِيٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiboTiyBN_A2">
					<p><span class="ar">الإِبْطِىُّ</span> <em>The axillary vein.</em> <span class="auth">(Golius, on the authority of Meyd.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibaATN">
				<h3 class="entry"><span class="ar">إِبَاطٌ</span></h3>
				<div class="sense" id="IibaATN_A1">
					<p><span class="ar long">السَّيْفُ إِبَاطٌ لِى</span> <em>The sword is beneath my</em> <span class="ar">أِبْط</span> <span class="add">[or <em>armpit</em>]</span>: and <span class="ar long">السَّيْفُ عِطَا فِى وَإِبَاطِى</span> <em>I put, or place, the sword upon my side, and beneath my</em> <span class="ar">إِبْط</span>. <span class="auth">(TA.)</span> And <span class="ar">جَعَلْتُهُ</span> <em>I put it</em> <span class="auth">(namely the sword, TA)</span> <em>next my</em> <span class="ar">إِبْط</span> <span class="auth">(Ḳ, TA.)</span> The Hudhalee, <span class="auth">(Ṣ, TA,)</span> El-Mutanakhkhil, describing water to which he came to drink, <span class="auth">(TA,)</span> says, <span class="auth">(Ṣ, TA,)</span> accord. to the Deewán, but some ascribe the words to Taäbbata-Sharrà, <span class="auth">(TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">شَرِبْتُ بِجَّمِهِ وَصَدَرْتُ عَنْهُ</span> *</div> 
						<div class="star">* <span class="ar long">وَأَبْيَضُ صَارِمٌ ذَكَرٌ إِبَاطِى</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>I drank of the main body thereof, and returned from it, and a sharp steel-edged sword was</em>]</span> <em>beneath my</em> <span class="ar">إِبْط</span>: <span class="auth">(Ṣ, TA:)</span> or, accord. to one relation, the poet said, <span class="ar long">بِأَبْيَضَ صَارِمٍ ذَكَرٍ</span>: and accord. to another, <span class="ar long">وَعَضْبٌ صَارِمٌ</span>: Skr says that the last word of the verse is a contraction of <span class="ar">آبَاطِى</span>: and Ibn-Es-Seeráfee, that it is originally <span class="arrow">↓<span class="ar">إِبَاطِىٌّ</span></span>; and if so, it is an epithet. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibaATieBN">
				<h3 class="entry"><span class="ar">إِبَاطِىٌّ</span></h3>
				<div class="sense" id="IibaATieBN_A1">
					<p><span class="ar">إِبَاطِىٌّ</span>: <a href="#IibaATN">see what next preceedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOabBaTieBN">
				<h3 class="entry"><span class="ar">تَأَبَّطِىٌّ</span></h3>
				<div class="sense" id="taOabBaTieBN_A1">
					<p><span class="ar">تَأَبَّطِىٌّ</span>: <a href="#AbT_5">see 5</a>..</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0006.pdf" target="pdf">
							<span>Lanes Lexicon Page 6</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0007.pdf" target="pdf">
							<span>Lanes Lexicon Page 7</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
