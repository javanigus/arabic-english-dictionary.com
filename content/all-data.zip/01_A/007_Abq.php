<article class="root" id="Root_Abq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/006_AbT">ابط</a></span>
				<span class="ar">ابق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/008_Abl">ابل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abq_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبق</span></h3>
				<div class="sense" id="Abq_1_A1">
					<p><span class="ar">أَبَقَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِقُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, &amp;c.,)</span> which is the most common form, <span class="auth">(Mṣb,)</span> and <span class="ar">ـُ</span>, <span class="auth">(Ṣ, TṢ, Mgh, Mṣb,)</span> and <span class="ar">ـَ</span>, <span class="auth">(Ḳ,)</span> so in the copies of the Ḳ in the place of <span class="ar">ـُ</span>; <span class="auth">(TA;)</span> and <span class="ar">أَبِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْبَقُ</span>}</span></add>; <span class="auth">(IDrd, Mṣb, Ḳ;)</span>, inf. n. <span class="ar">إِبَاقٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb)</span> and <span class="ar">أَبْقٌ</span> and <span class="ar">أَبَقٌ</span>, <span class="auth">(Ḳ,)</span> or the first of these is a simple subst., and the second and third are the inf. ns.; <span class="auth">(Mṣb;)</span> <em>He</em> <span class="auth">(a slave)</span> <em>ran away,</em> or <em>fled,</em> <span class="auth">(T, Ṣ, Mgh, Mṣb,)</span> or <em>went away,</em> <span class="auth">(Ḳ,)</span> <em>from his master,</em> <span class="auth">(T, Mṣb,)</span> <em>without</em> <span class="add">[<em>being induced to do so by</em>]</span> <em>fear, or severity of work:</em> <span class="auth">(Mṣb, Ḳ:)</span> thus the signification is restricted in the ʼEyn: <span class="auth">(Mṣb:)</span> and in this case, the law ordains that the slave shall be restored; but if the act arise from severity of work or from fear, he is not to be restored: <span class="auth">(Lth, TA:)</span> in the Ḳur xxxvii. 140, it is said of Jonas, <span class="auth">(T, Bḍ,)</span> because he fled from his people without the permission of his Lord: <span class="auth">(Bḍ:)</span> and it is also, tropically, said of a fish: <span class="auth">(Mgh:)</span> or <em>he</em> <span class="auth">(a slave)</span> <em>hid himself, and then went away:</em> <span class="auth">(M, Ḳ:)</span> as also<span class="arrow">↓<span class="ar">تأبّق</span></span>: <span class="auth">(M:)</span> or this signifies, simply, <em>he hid,</em> or <em>concealed, himself:</em> or <em>he confined, restricted, limited, restrained,</em> or <em>withheld, himself:</em> <span class="auth">(Ṣ, Ḳ:)</span> or it has both of the last two significations: <span class="auth">(Ṣgh:)</span> and <em>he abstained</em> from a thing, <em>as from a sin,</em> or <em>crime.</em> <span class="auth">(IAạr, Ḳ *.)</span> A poet says, <span class="auth">(Ṣ,)</span> namely, 'Ámir Ibn-Kaab, <span class="auth">(AZ,)</span> or 'Ámán Ibn-Kaab, or, as some say, Ghámán, <span class="auth">(AA,)</span></p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow">↓<span class="ar long">أَلَا قَالَتْ بَهَانِ وَلَمْ تَأَبَّقْ</span></span> *</div> 
						<div class="star">* <span class="ar long">كَبِرْتَ وَلَا يَلِيقُ بِكَ النَّعِيمُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Now surely Baháni said, and she did not hide herself,</em> or <em>did not restrain herself, Thou hast grown old, and enjoyment doth not befit thee</em>]</span>: <span class="auth">(Ṣ:)</span> or <em>she did not hide herself</em> <span class="add">[or <em>her mind</em>]</span>, <em>but said openly:</em> <span class="auth">(TA:)</span> or <em>she did not go far</em> <span class="add">[from the person whom she addressed, or from the truth]</span>; so says AZ, taking it from <span class="ar">إِبَاقٌ</span> as relating to a slave: <span class="auth">(TA:)</span> or <em>she did not abstain</em> from her speech, as <em>from a sin,</em> or <em>crime:</em> <span class="auth">(IAạr:)</span> or <em>she did not disdain,</em> or <em>scorn.</em> <span class="auth">(TA.)</span> AḤát says that he asked Aṣ respecting <span class="arrow">↓<span class="ar">تأبّق</span></span>, and he answered that he knew it not. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّق</span></h3>
				<div class="sense" id="Abq_5_A1">
					<p><a href="#Abq_1">see 1</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابق</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abq_5_A2">
					<p><span class="ar">تَأَبَّقَتْ</span> <em>She</em> <span class="auth">(a camel)</span> <em>withheld her milk.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابق</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abq_5_A3">
					<p><span class="ar long">تأبّق الشَّىْءَ</span> <span class="add">[or <span class="ar long">مِنَ الشَّىْءِ</span>]</span> <em>He denied,</em> or <em>disacknowledged, the thing.</em> <span class="auth">(Ḳ.)</span> One says to a man, “Verily in thee is such a quality; “and he replies, <span class="ar long">مَا أَتَأَبَّقُ</span> <em>I do not deny,</em> or <em>disacknowledge:</em> and one says, “O son of such a woman;” and the man replies, <span class="ar long">مَا أَتَأَبَّقُ مِنْهَا</span> <em>I do not deny,</em> or <em>disacknowledge, her.</em> <span class="auth">(IF.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabuwqN">
				<h3 class="entry"><span class="ar">أَبُوقٌ</span></h3>
				<div class="sense" id="OabuwqN_A1">
					<p><span class="ar">أَبُوقٌ</span>: <a href="#AbiqN">see <span class="ar">آبِقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabBaAqN">
				<h3 class="entry"><span class="ar">أَبَّاقٌ</span></h3>
				<div class="sense" id="OabBaAqN_A1">
					<p><span class="ar">أَبَّاقٌ</span>: <a href="#AbiqN">see <span class="ar">آبِقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbiqN">
				<h3 class="entry"><span class="ar">آبِقٌ</span></h3>
				<div class="sense" id="MbiqN_A1">
					<p><span class="ar">آبِقٌ</span> A slave <em>running away,</em> or <em>fleeing,</em>, &amp;c.; a <em>runaway,</em> or <em>fugitive,</em> slave; part. n. of <span class="ar">أَبَقَ</span>; <span class="auth">(Mgh, Mṣb, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">أَبُوقٌ</span></span> <span class="add">[but in an intensive, or frequentative, sense, i. e. <em>who runs away,</em> or <em>flees, &amp;c., much,</em> or <em>often;</em> and so<span class="arrow">↓<span class="ar">أَبَّاقٌ</span></span>, occurring in the Ḳ, in art. <span class="ar">ملخ</span>]</span>: <span class="auth">(IF, Ḳ:)</span> pl.<span class="ar">أُبَّاقٌ</span> <span class="auth">(Mgh, Mṣb, Ḳ)</span> and <span class="ar">أُبَّقٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0007.pdf" target="pdf">
							<span>Lanes Lexicon Page 7</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
