<article class="root" id="Root_AjS">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/026_Ajr">اجر</a></span>
				<span class="ar">اجص</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/028_Ajl">اجل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IijBaASN">
				<h3 class="entry"><span class="ar">إِجَّاصٌ</span> / <span class="ar">إِجَّاصَةٌ</span></h3>
				<div class="sense" id="IijBaASN_A1">
					<p><span class="ar">إِجَّاصٌ</span> <span class="add">[The <em>plum;</em>]</span> <em>a certain fruit,</em> <span class="auth">(Ḳ, TA,)</span> <em>of the description termed</em> <span class="ar">فَاكِهَة</span>, <span class="auth">(TA,)</span> <em>well known;</em> <span class="auth">(Mṣb, Ḳ;)</span> <em>cold and moist; or, as some say, of moderate temperature;</em> <span class="auth">(TA;)</span> <em>which facilitates the flow of the yellow bile;</em> <span class="auth">(Ḳ;)</span> i. e., <em>its juice,</em> or <em>water, does so, when drunk with sugar-candy</em> (<span class="ar">طَبَرْزَذ</span>) <em>and manna</em> (<span class="ar">تَرَنْجُبِين</span>) <em>added to it;</em> <span class="auth">(TA;)</span> <em>and allays thirst, and heat of the heart;</em> <span class="auth">(Ḳ;)</span> <em>but it relaxes the stomach, and does not agree with it; and it generates a watery mixture; and its injurious effect is repelled by the drinking of sugary</em> <span class="ar">سِكَنْجُبِين</span> <span class="add">[or <em>oxymel</em>]</span>: <em>it is of several kinds:</em> <span class="auth">(TA:)</span> <span class="add">[<em>the most common is the Damasc,</em> or <em>Damascene, plum:</em>]</span> <em>the best is</em> <span class="auth">(Ḳ, TA)</span> <em>the Armenian,</em> <span class="auth">(TA,)</span> <em>that which is sweet and large:</em> <span class="auth">(Ḳ, TA:)</span> <em>the sour,</em> or <em>acid, is less laxative, and more cold:</em> <span class="auth">(TA:)</span> the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">إِجَّاصَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> you should not say <span class="ar">إِنْجَاصٌ</span>; <span class="auth">(Yaạḳoob, Ṣ, Ḳ;)</span> or this is a word of weak authority, <span class="auth">(Ḳ, TA,)</span> and you say <span class="ar">إِجَّاصٌ</span> and <span class="ar">إِنجَاصٌ</span> like as one says <span class="ar">إِجَّارٌ</span> and <span class="ar">إِنْجَارٌ</span>: <span class="auth">(TA:)</span> in the dial. of the Syrians, the <span class="ar">إِجَّاصٌ</span> <span class="add">[or <span class="ar">إِنْجَاص</span> or <span class="ar">إِنجَاس</span> accord. to common modern usage among them]</span> is the <span class="add">[<em>pear</em> which they formerly called]</span> <span class="ar">مِشْمِش</span> and <span class="add">[which others call]</span> <span class="ar">كُمَّثْرَى</span>: <span class="auth">(Ḳ:)</span> <em>it is of the growth of the country of the Arabs:</em> <span class="auth">(AḤn:)</span> <span class="ar">اجّاص</span> is an adventitious word, <span class="auth">(Ṣ, Ḳ,)</span> or arabicized, <span class="auth">(Mṣb,)</span> because <span class="ar">ج</span> and <span class="ar">ص</span> do not both occur in any Arabic word: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or, accord. to Az, they do so occur; as, for instance, in <span class="ar">حَصَّصَ</span>, and in <span class="ar">صَجٌّ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0024.pdf" target="pdf">
							<span>Lanes Lexicon Page 24</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
