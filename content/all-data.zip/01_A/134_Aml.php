<article class="root" id="Root_Aml">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/133_Ams">امس</a></span>
				<span class="ar">امل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/135_Amn">امن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Aml_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمل</span></h3>
				<div class="sense" id="Aml_1_A1">
					<p><span class="ar">أَمَلَهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُلُ</span>}</span></add>, <span class="auth">(T, Ṣ, M, Mṣb,)</span> and <span class="ar">ـِ</span>, <span class="auth">(so in the M accord. to the TT,)</span> inf. n. <span class="ar">أَمَلٌ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> this being the inf. n. accord. to IJ, <span class="add">[as distinguished from <span class="ar">أَمْلٌ</span> and <span class="ar">إِمْلٌ</span>,]</span> <span class="auth">(M,)</span> <em>He hoped it;</em> or <em>hoped for it;</em> syn. <span class="ar">رَجَاهُ</span>; <span class="auth">(Ṣ,* M,* <span class="add">[<a href="#OamalN">see <span class="ar">أَمَلٌ</span> below</a>,]</span> K;)</span> meaning, what was good for him; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">أمَلهُ↓</span></span>, <span class="auth">(T,* M, Ḳ,)</span> inf. n. <span class="ar">تَأميلٌ</span>: <span class="auth">(Ṣ, T:)</span> or <em>he expected it;</em> <span class="add">[or <em>had a distant,</em> or <em>remote, expectation of it;</em> for]</span> it is mostly used in relation to that of which the occurrence, or coming to pass, is deemed remote; as in the saying of Zuheyr,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَرْجُو وَآمُلُ أَنْ تَدْنُو مَوَدَّتُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>I hope, and have a distant expectation, that her love may approach</em>]</span>: he who has determined upon a journey to a distant town or country says, <span class="ar long">أَمَلْتُ الوُصُولَ</span> <span class="add">[<em>I have formed an expectation,</em> or <em>a distant expectation, of arriving</em>]</span>; but he does not say, <span class="ar">طَمِعْتُ</span> until he has become near thereto; for <span class="ar">طَمَعٌ</span> relates only to that of which the occurrence, or coming to pass, is <span class="add">[deemed]</span> near: and <span class="ar">الرَّجَآءُ</span> is between <span class="ar">الأَمَلُ</span> and <span class="ar">الطَّمَعُ</span>; for it is sometimes attended with fear that the thing expected may not come to pass, wherefore it is used in the sense of fear; and when the fear is strong, <span class="add">[lest the thing expected should not come to pass, it denotes distant expectation, and thus]</span> it is used in the sense of <span class="ar">الأَمَلُ</span>; whence the usage in the verse of Zuheyr; but otherwise it is used in the sense of <span class="ar">الطَّمَعُ</span>: <span class="auth">(Mṣb:)</span> or <span class="ar">الرجاء</span> signifies the expectation of benefit, or advantage, from some preceding cause or means: so says El-Harállee: or it is properly syn. with <span class="ar">الأَمَلُ</span>; and in common conventional language, means the clinging of the heart to the coming to pass of a future desired event: so says Ibn-El-Kemál: or, accord. to Er-Rághib, an opinion requiring the coming to pass of an event in which will be a cause of happiness: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">أمّلهُ↓</span></span>, inf. n. <span class="ar">تَأْمِيلٌ</span>, signifies <em>he expected it much;</em> and is more commonly used than the form without teshdeed. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aml_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّل</span></h3>
				<div class="sense" id="Aml_2_A1">
					<p><a href="#Aml_1">see 1</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Aml_2_B1">
					<p><span class="ar">تَأْمِيلٌ</span> also signifies The <em>inducing</em> <span class="add">[one]</span> <em>to hope</em> or <em>expect.</em> <span class="auth">(KL.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aml_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأمّل</span></h3>
				<div class="sense" id="Aml_5_A1">
					<p><span class="ar long">تأمّل الشَّىْءِ</span> <span class="add">[<em>He considered the thing,</em> or <em>studied it,</em> or <em>contemplated it, carefully,</em> or <em>attentively, with investigation;</em>]</span> <em>he looked at the thing endeavouring to obtain a clear knowledge of it:</em> <span class="auth">(Ṣ:)</span> or <em>i. q.</em> <span class="ar">تَدَبَّرَهُ</span>; <span class="auth">(Mṣb, TA;)</span> i. e., <span class="auth">(Mṣb,)</span> <em>he looked into the thing, considered it, examined it,</em> or <em>studied it, repeatedly,</em> <span class="auth">(Mṣb, TA,)</span> <em>in order to know it,</em> or <em>until he knew it,</em> <span class="auth">(Mṣb,)</span> or <em>in order to ascertain its real case:</em> <span class="auth">(TA:)</span> or <em>he looked intently,</em> or <em>hardly, at,</em> or <em>towards, the thing:</em> <span class="auth">(TA:)</span> or <span class="ar">تأمّل</span> signifies <em>he acted,</em> or <em>proceeded, deliberately, not hastily,</em> syn. <span class="ar">تَثَبَّتَ</span>, <span class="auth">(T, M,)</span> or <em>he paused,</em> or <em>waited,</em> syn. <span class="ar">تَلَبِّثَ</span>, <span class="auth">(Ḳ,)</span> <em>in an affair,</em> and <em>in consideration;</em> <span class="auth">(M, Ḳ, TA;)</span> <em>he paused, and acted with deliberation.</em> <span class="auth">(TA.)</span> <span class="ar long">فِيهِ تَأَمُّلٌ</span> <span class="add">[meaning <em>It requires careful,</em> or <em>attentive, consideration,</em> or simply <em>it requires consideration,</em>]</span> is a phrase <span class="add">[of frequent occurrence in the larger lexicons, &amp;c., used to imply doubt, and also to insinuate politely that the words to which it relates are false, or wrong,]</span> like <span class="ar long">فِيهِ نَظَرٌ</span> <span class="add">[q. v.]</span>. <span class="auth">(MF in art. <span class="ar">صفح</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OamolN">
				<h3 class="entry"><span class="ar">أَمْلٌ</span></h3>
				<div class="sense" id="OamolN_A1">
					<p><span class="ar">أَمْلٌ</span>: <a href="#OamalN">see <span class="ar">أَمَلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimolN">
				<h3 class="entry"><span class="ar">إِمْلٌ</span></h3>
				<div class="sense" id="IimolN_A1">
					<p><span class="ar">إِمْلٌ</span>: <a href="#OamalN">see <span class="ar">أَمَلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamalN">
				<h3 class="entry"><span class="ar">أَمَلٌ</span></h3>
				<div class="sense" id="OamalN_A1">
					<p><span class="ar">أَمَلٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">إِمْلٌ↓</span></span> <span class="auth">(IJ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَمْلٌ↓</span></span>, <span class="auth">(Ḳ,)</span> the first of which is an inf. n., accord. to IJ, <span class="auth">(M,)</span> and is the form commonly known, <span class="auth">(TA,)</span> <em>Hope;</em> syn. <span class="ar">رَجَآءٌ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> or <em>expectation;</em> <span class="add">[or <em>distant,</em> or <em>remote, expectation;</em> being]</span> mostly used in relation to that of which the occurrence, or coming to pass, is deemed remote: applied also to <em>an affection of the heart from some good to be attained:</em> <span class="auth">(Mṣb, TA: <span class="add">[in both of which are further explanations, for which <a href="#Aml_1">see 1</a>:]</span>)</span> <span class="arrow"><span class="ar">إِمْلَةٌ↓</span></span>, also, signifies the same as <span class="ar">أَمَلٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> or <span class="ar">تَإْمِيلٌ</span>; <span class="auth">(Lḥ, M, Ḳ;)</span> <span class="add">[or <em>a manner of hoping</em> or <em>expecting;</em> for J adds,]</span> and it is like <span class="ar">جِلْسَةٌ</span> and <span class="ar">رِكْبَةٌ</span>: <span class="auth">(Ṣ:)</span> <span class="pb" id="Page_0100"></span>and<span class="arrow"><span class="ar">مُؤَمَّلٌ↓</span></span>, likewise, signifies the same as <span class="ar">إَمَلٌ</span>: <span class="auth">(TA:)</span> <a href="#AmalN">the pl. of <span class="ar">أمَلٌ</span></a> and <span class="ar">إَمْلٌ</span> and <span class="ar">أَمْلٌ</span> is <span class="ar">آمَلٌ</span>. <span class="auth">(M,* Ḳ, TA.)</span> You say, <span class="ar long">خَابَ سَعْيُهُ وَأَمَلُهُ</span> <span class="add">[<em>His labour, and his hope,</em> or <em>expectation, were disappointed, frustrated,</em> or <em>balked</em>]</span>. <span class="auth">(A and TA in art. <span class="ar">خيب</span>.)</span> And<span class="arrow"><span class="ar long">مَا أَطْوَلَ إَمْلَتَهُ↓</span></span> <em>How far-reaching is his hope,</em> or <em>expectation!</em> <span class="auth">(T,* Ṣ, M, Ḳ:)</span> <span class="add">[or <em>his manner of hoping</em> or <em>expecting!</em>]</span> from <span class="ar">الأَمَلُ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امل</span> - Entry: <span class="ar">أَمَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamalN_A2">
					<p>Also, the first, <em>An object of hope.</em> <span class="auth">(Jel in xviii. 44.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimolapN">
				<h3 class="entry"><span class="ar">إِمْلَةٌ</span></h3>
				<div class="sense" id="IimolapN_A1">
					<p><span class="ar">إِمْلَةٌ</span>: <a href="#OamalN">see <span class="ar">أَمَلٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MmilN">
				<h3 class="entry"><span class="ar">آمِلٌ</span></h3>
				<div class="sense" id="MmilN_A1">
					<p><span class="ar">آمِلٌ</span> act. part. n. of 1; <span class="add">[<em>Hoping:</em> or]</span> <em>expecting.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#Aml_1">See 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWamBalN">
				<h3 class="entry"><span class="ar">مُؤَمَّلٌ</span></h3>
				<div class="sense" id="muWamBalN_A1">
					<p><span class="ar">مُؤَمَّلٌ</span> One <em>whose beneficence may be hoped for.</em> <span class="auth">(Ḥar p. 183.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امل</span> - Entry: <span class="ar">مُؤَمَّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWamBalN_A2">
					<p><span class="ar">المُؤَمَّلُ</span> <em>The eighth of the horses that are started together in a race;</em> <span class="auth">(Ḳ;)</span> these being ten: <span class="auth">(TA:)</span> or <em>the ninth thereof:</em> <span class="auth">(TA in explanation of <span class="ar">السُّكَيْتُ</span>:)</span> or <em>the seventh thereof.</em> <span class="auth">(Ḥam p. 46.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امل</span> - Entry: <span class="ar">مُؤَمَّلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWamBalN_B1">
					<p><a href="#OamalN">See also <span class="ar">أَمَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomuwlN">
				<h3 class="entry"><span class="ar">مَأْمُولٌ</span></h3>
				<div class="sense" id="maOomuwlN_A1">
					<p><span class="ar">مَأْمُولٌ</span> pass. part. n. of 1; <span class="add">[<em>Hoped:</em> or]</span> <em>expected.</em> <span class="auth">(Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0099.pdf" target="pdf">
							<span>Lanes Lexicon Page 99</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0100.pdf" target="pdf">
							<span>Lanes Lexicon Page 100</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
