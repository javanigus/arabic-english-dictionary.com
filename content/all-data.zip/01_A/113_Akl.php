<article class="root" id="Root_Akl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/112_Akf">اكف</a></span>
				<span class="ar">اكل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/114_Akm">اكم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Akl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أكل</span></h3>
				<div class="sense" id="Akl_1_A1">
					<p><span class="ar">أَكَلَهُ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْكُلُ</span>}</span></add>,]</span> inf. n. <span class="ar">أَكْلٌ</span> and <span class="ar">مَأْكَلٌ</span>, <span class="add">[<em>He ate it,</em>]</span> <span class="auth">(Ṣ, Ḳ,)</span> namely, food. <span class="auth">(Ṣ.)</span> Er-Rummánee says that <span class="ar">أَكْلٌ</span> properly signifies The <em>swallowing</em> food <em>after chewing</em> it; so that the swallowing of pebbles is not properly thus termed: <span class="auth">(Mṣb:)</span> or, accord. to Ibn-El-Kemál, the <em>conveying,</em> or <em>transmitting, to the belly</em> what may be chewed, <em>whether</em> <span class="add">[<em>the thing be</em>]</span> <em>chewed or not;</em> so that it does not apply to milk, nor to <span class="ar">سَوِيق</span>: and as to the saying of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مِنَ الآكِلِينَ المَآءَ ظُلْمًا فَمَا أَرَى</span> *</div> 
						<div class="star">* <span class="ar long">يَنَالُونَ خَيْرًا بَعْدَ أَكْلِهِمُ المَآءَ</span> *</div> 
					</blockquote>
					<p>† <span class="add">[<em>Of the eaters of</em> what they purchase with the price of <em>water, wrongfully, I do not see</em> any <em>attain good after their eating of</em> what they have purchased with the price of <em>the water,</em>]</span> he means a people who used to sell water and purchase with the price thereof what they would eat: <span class="auth">(TA:)</span> <span class="add">[for you say, <span class="ar long">أَكَلَ كَذَا</span> as meaning † <em>He ate the price of such a thing:</em> see another ex. voce <span class="ar">إِكَافٌ</span>; and another voce <span class="ar">ثَدْىٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_1_A2">
					<p>The saying, in the Ḳur <span class="add">[v. 70]</span>, <span class="ar long">لَأَكَلُوا مِنْ فَوْقِهِمْ وَمِنْ تَحْتِ أَرْجُلِهِمْ</span> <span class="add">[<em>They should eat</em> things <em>above them and</em> things <em>beneath their feet</em>]</span> means, their means of subsistence should be made ample; <span class="auth">(Bḍ, TA;)</span> by the pouring of the blessings of the heaven and the earth upon them; or by the abundance of the fruit of the trees, and the produce of the grains sown; or by their being blessed with gardens of ripe fruits, so that they should gather them from the upper part of each tree, and pick up what should have fallen upon the ground. <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Akl_1_A3">
					<p><span class="ar long">اِنْقَطَعَ أَكْلُهُ</span> <span class="add">[lit. <em>His eating became cut off,</em> or <em>stopped,</em>]</span> means ‡ <em>he died;</em> <span class="add">[<a href="#OukulN">see also <span class="ar">أُكُلٌ</span></a>;]</span> and so <span class="ar long">اِسْتَوْفَى أَكْلَهُ</span> <span class="add">[lit. <em>he completed his eating</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Akl_1_A4">
					<p><span class="ar long">أَكَلَ رَؤْقَهُ</span> <span class="add">[lit. <em>He ate his life,</em>]</span> means ‡ <em>he became extremely aged, and his teeth fell out, one after another.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Akl_1_A5">
					<p><span class="ar long">هُوَ يَأْكُلُ النَّاسَ</span>, and <span class="ar long">يَأْكُلُ لُحُومَ النَّاسِ</span> <span class="add">[<em>He eats men,</em> and <em>eats the flesh of men,</em>]</span> means ‡ <em>he defames men;</em> or <em>does so in their absence:</em> <span class="auth">(TA:)</span> and the action thus signified may be <span class="add">[<em>with words, or by making signs</em>]</span> <em>with the side of the mouth,</em> and <em>with the eye,</em> and <em>with the head.</em> <span class="auth">(TA in art. <span class="ar">همز</span>.)</span> It is said in the Ḳur <span class="add">[xlix. 12]</span>, <span class="ar long">أَيُحِبُّ أَحَدُكُمْ أَنْ يَأْكلَ لَحْمَ أَخِيهِ مَيْتًا</span> <span class="add">[lit. <em>Would any one of you like to eat the flesh of his brother when dead?</em>]</span>; defamation, or defamation of the absent, being meant thereby. <span class="auth">(Ṣ,* Ibn-ʼArafeh, Bḍ, Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Akl_1_A6">
					<p><span class="ar long">أَكَلَ غَنَمِى وَشَرِبَهَا</span> ‡ <span class="add">[<em>He ate</em> the flesh of <em>my sheep, and drank</em> the milk of <em>them,</em> means, like <span class="ar long">أَكَلَ مَالِى</span>, <em>he ate, fed upon, devoured,</em> or <em>consumed, my wealth,</em> or <em>property:</em> <a href="#Akl_2">see 2</a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Akl_1_A7">
					<p><span class="ar long">أَكَلَتِ النَّارُ الحَطَبَ</span> ‡ <em>The fire devoured,</em> or <em>consumed, the firewood.</em> <span class="auth">(Ṣ, Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Akl_1_A8">
					<p><span class="ar long">أَكَلَتْ أَظْفَارَهُ الحِجَارَةُ</span> ‡ <span class="add">[<em>The stones wore away his nails</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Akl_1_A9">
					<p><span class="ar long">الوَاوُ فِى مَرْئىٍّ أَكَلَتْهَا اليَآءُ</span> † <span class="add">[<em>The</em> <span class="ar">و</span> <em>in</em> <span class="ar">مَرْئِىّ</span>, <em>the</em> <span class="ar">ى</span> <em>has swallowed it up</em>]</span>; because it is originally <span class="ar">مَرْؤُوىٌ</span>: a phrase occurring in the ʼEyn. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Akl_1_A10">
					<p><span class="ar long">أَكَلَ عُمُرَهُ</span> ‡ <em>He consumed his life.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Akl_1_A11">
					<p>It is said in a trad., <span class="auth">(TA,)</span> <span class="ar long">أُمِرْتُ بِقَرْيَةٍ تَأْكُلُ القُرَى</span> ‡ <span class="add">[<em>I have been commanded to have given unto me a town which shall devour the</em> other <em>towns</em>]</span>; <span class="auth">(Ḳ, TA;)</span> said to be Yethrib <span class="add">[afterwards called El-Medeeneh]</span>; <span class="auth">(TA;)</span> i. e., the people of which shall conquer the <span class="add">[other]</span> towns and make spoil of their possessions: or it denotes the superior excellence of that town; and is like the saying, <span class="ar long">هٰذَا حَدِيثٌ يَأْكُلُ الأَحَادِيثَ</span> <span class="add">[<em>This is a tradition which does away with,</em> or <em>overrules, the</em> other <em>traditions</em>]</span>. <span class="auth">(Ṣgh. Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="Akl_1_A12">
					<p><span class="ar long">أَكْلُ السِّكِّينِ اللَّحْمَ</span> means ‡ <em>The knife's cutting the flesh.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="Akl_1_A13">
					<p><span class="ar long">أَكَلَنِى رَأْسِى</span>, inf. n. <span class="ar">إِكْلَةٌ</span> and <span class="ar">أُكَالٌ</span> and <span class="ar">أَكَالٌ</span>, ‡ <em>My head itched.</em> <span class="auth">(Ḳ, TA.)</span> An Arab was heard to say, <span class="add">[as is often said in the present day,]</span> <span class="ar long">جِلْدِى يَأْكُلُنِى</span> ‡ <em>My skin itches.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Akl_1_B1">
					<p><span class="ar">أَكِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْكَلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَكَلٌ</span>, <span class="auth">(TA,)</span> ‡ <em>It</em> <span class="auth">(a limb, or member, <span class="add">[and a sore,]</span> and a piece of stick, or wood,)</span> <em>became corroded</em> or <em>cankered,</em> or <em>decayed, by the mutual eating away of its several parts;</em> as also<span class="arrow"><span class="ar">ائتكل↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَكَلَ</span>]</span>, and<span class="arrow"><span class="ar">تأكّل↓</span></span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Akl_1_B2">
					<p><span class="ar long">أَكِلَتِ الأَسْنَانُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. and inf. n. as in the next preceding sentence, <span class="auth">(Mṣb,)</span> ‡ <em>The teeth rubbed together and wasted away;</em> by reason of age; <span class="auth">(Ṣ;)</span> or <em>fell out, one after another:</em> <span class="auth">(Mṣb:)</span> or <em>broke in pieces,</em> or <em>became much broken:</em> <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar">تأكّلت↓</span></span> signifies the same; <span class="auth">(Ṣ, Mṣb;)</span> and so<span class="arrow"><span class="ar">ائتكلت↓</span></span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Akl_1_B3">
					<p><span class="ar long">أَكِلَتِ النَّاقَةُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْكَلُ</span>}</span></add>, inf. n. <span class="ar">أَكَالٌ</span>, † <em>The she-camel experienced an itching and annoyance in her belly,</em> <span class="auth">(Ṣ, O, Ḳ,)</span> <em>from the growth of the hair,</em> <span class="auth">(Ṣ, O,)</span> or <em>from the growth of the fur,</em> <span class="auth">(Ḳ,)</span> <em>of her fœtus.</em> <span class="auth">(Ṣ, O, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أكّل</span></h3>
				<div class="sense" id="Akl_2_A1">
					<p><span class="add">[<span class="ar">أكّلهُ</span>, inf. n. <span class="ar">تَأْكِيلٌ</span>, <em>He made him to eat</em> a thing.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_2_A2">
					<p><span class="ar long">أَكَّلَ مَالِى وَشرَّبَهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> <span class="add">[lit. <em>He made</em> people <em>to eat my property, and made</em> them <em>to drink it,</em>]</span> means ‡ <em>he fed men,</em> or <em>the people, with my property,</em> or <em>cattle.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Akl_2_A3">
					<p><span class="ar long">ظَلَّ مَالِى يُؤَكَّلُ وَيُشَرَّبُ</span>, <span class="auth">(so in some copies of the Ḳ and in the TA,)</span> or <span class="ar long">يُؤَكِّلُ ويُشَرِّبُ</span>, <span class="auth">(so in two copies of the Ṣ and in a copy of the Ḳ,)</span> <span class="add">[of which the former is app. the right reading, as the lit. meaning seems to be <em>My cattle passed the day made to eat and made to drink,</em>]</span> i. e., ‡ <em>pasturing as they pleased.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Akl_2_A4">
					<p><span class="ar long">أكّلهُ الشَّىْءَ</span>, inf. n. as above, ‡ <em>He charged against him,</em> or <em>accused him of doing, the thing;</em> as also<span class="arrow"><span class="ar">آكلهُ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> inf. n. <span class="ar">إِيكَالٌ</span>. <span class="auth">(TA.)</span> In <span class="add">[some of]</span> the copies of the Ḳ, for <span class="ar">اِدَّعَاهُ</span>, we here find, erroneously, <span class="ar">دَعَاهُ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">أَكَّلْتَنِى مَا لَمْ آكُلْ</span> <span class="add">[lit. <em>Thou hast made me to eat what I have not eaten,</em>]</span> meaning ‡ <em>thou hast charged against me,</em> or <em>accused me of doing, what I have not done;</em> as also<span class="arrow"><span class="ar">آكَلْتَنِى↓</span></span>. <span class="auth">(Ṣ, TA.)</span> So too, <span class="ar long">أَشْرَبْتَنِى مَا لَمْ أَشْرَبٌ</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">شرب</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akl_3">
				<h3 class="entry">3. ⇒ <span class="ar">آكل</span></h3>
				<div class="sense" id="Akl_3_A1">
					<p><span class="ar">آكلهُ</span>, inf. n. <span class="ar">مُؤَاكَلَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">إِكَاِلٌ</span>, <span class="auth">(Ḳ,)</span> <em>He ate with him;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also <span class="ar">وَاكَلَهُ</span>, though of weak authority; <span class="auth">(Ḳ;)</span> or this latter is not allowable. <span class="auth">(Ṣ, Ṣgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_3_A2">
					<p><span class="ar">مُؤَاكَلَةٌ</span> which is forbidden in a trad. is † <em>A debtor's giving a thing to his creditor in order that he may abstain from taking the debt.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akl_4">
				<h3 class="entry">4. ⇒ <span class="ar">آكل</span></h3>
				<div class="sense" id="Akl_4_A1">
					<p><span class="ar">آكل</span>, <span class="add">[inf. n. <span class="ar">إِيكَالٌ</span>,]</span> said of the palm-tree, and of seed-produce, <span class="auth">(Ṣ, Ḳ,)</span> and of anything, <span class="auth">(Ṣ,)</span> <em>It had ripe fruit; it supplied food.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_4_A2">
					<p><span class="ar long">آكلهُ الشَّىْءَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> <em>He gave him to eat the thing; he fed him with the thing.</em> <span class="auth">(Ṣ,* Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Akl_4_A3">
					<p><a href="#Akl_2">See also 2</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Akl_4_A4">
					<p><span class="ar long">آكل النَّارَ</span> † <em>He fed,</em> or <em>supplied, the fire with fuel.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Akl_4_A5">
					<p><span class="ar long">آكل بَيْنَ النَّاسِ</span>, <span class="auth">(A, Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ, O,)</span> ‡ <em>He busied himself among the people with propagating calumnies:</em> <span class="auth">(Ṣ, O, TA:)</span> or <em>he created,</em> or <em>excited, disagreement, dissension, strife, among them;</em> or <em>made,</em> or <em>did, mischief among them:</em> <span class="auth">(A, TA:)</span> or <em>he incited them, one against another.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<span class="pb" id="Page_0072"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Akl_4_A6">
					<p><span class="ar long">آكَلْتُكَ فُلَانًا</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">آكَلَ فُلَانٌ فُلانًا</span>, <span class="auth">(Ḳ, <span class="add">[in the CK, erroneously, <span class="ar long">فُلَانٌ فُلَانًا</span>,]</span>)</span> ‡ <em>I made thee,</em> <span class="auth">(Ṣ,)</span> or <em>he made such a one,</em> <span class="auth">(Ḳ,)</span> <em>to have dominion,</em> or <em>authority,</em> or <em>power, over such a one.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأكّل</span></h3>
				<div class="sense" id="Akl_5_A1">
					<p><span class="ar">تأكّل</span>: <a href="#Akl_1">see 1</a>, latter part, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_5_A2">
					<p><a href="#Akl_8">and see also 8</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Akl_5_A3">
					<p>Also, said of a sword, <span class="auth">(Ṣ, Ḳ,)</span> and of silver <span class="auth">(Ḳ, TA)</span> molten, <span class="auth">(TA,)</span> and of lightning, and of collyrium, and of aloes, <span class="auth">(Ḳ,)</span> and of anything shiny, <span class="auth">(TA,)</span> ‡ <em>It shone, gleamed,</em> or <em>glistened,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>much,</em> or <em>intensely;</em> <span class="auth">(Ḳ;)</span> when said of a sword, <em>by reason of its sharpness.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتكل</span></h3>
				<div class="sense" id="Akl_8_A1">
					<p><span class="ar">ائتكل</span> <span class="add">[with the disjunctive alif <span class="ar">اِيتَكَلَ</span>]</span>: <a href="#Akl_1">see 1</a>, latter part, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_8_A2">
					<p><span class="ar long">أَمَا تَنْفَكُّ تَأْتَكِلُ</span> <em>Dost thou not cease to eat our flesh,</em> <span class="add">[i. e., <em>to wound our reputations,</em> (<a href="#Akl_1">see 1</a>,)]</span> <em>and to defame us?</em> <span class="auth">(Aboo-Naṣr, TA.)</span> But see below.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Akl_8_A3">
					<p><span class="ar long">ائتكلتِ النَّارُ</span> ‡ <em>The fire flamed,</em> or <em>blazed, vehemently; as though one part thereof devoured another.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Akl_8_A4">
					<p><span class="ar long">ائتكل غَضَبًا</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">مِنَ الغَضَبِ</span>, <span class="auth">(Ṣ,)</span> ‡ <em>He burned,</em> or <em>burned fiercely, with,</em> or <em>by reason of, anger.</em> <span class="auth">(Ṣ, Ḳ.)</span> The phrase mentioned above, <span class="ar long">اما تنفكّ تأتكل</span>, is also cited as an ex. of this meaning. <span class="auth">(Ṣ, TA.)</span> You say likewise, <span class="ar long">ائتكل مِنْهُ</span> ‡ <em>He was,</em> or <em>became, angry with him, and excited,</em> or <em>provoked, against him,</em> <span class="auth">(Ḳ, TA,)</span> <em>and vehement,</em> or <em>severe;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar long">تأكل↓ منه</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأكل</span></h3>
				<div class="sense" id="Akl_10_A1">
					<p><span class="ar long">استأكلهُ الشَّىْءَ</span> ‡ <em>He asked,</em> or <em>begged, of him to assign to him the thing,</em> or <em>to make it be to him, as a means of subsistence,</em> or <em>a thing to be eaten.</em> <span class="auth">(Ḳ, TA.)</span></p>	
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akl_10_A2">
					<p><span class="ar long">يَسْتَأْكِلُ الضُّعَفَآءَ</span> ‡ <em>He takes</em> <span class="auth">(Ṣ, Ḳ, TA)</span> <em>and devours</em> <span class="auth">(TA)</span> <em>the possessions of the weak ones.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OukolN">
				<h3 class="entry"><span class="ar">أُكْلٌ</span></h3>
				<div class="sense" id="OukolN_A1">
					<p><span class="ar">أُكْلٌ</span>: <a href="#OukulN">see <span class="ar">أُكُلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakalN">
				<h3 class="entry"><span class="ar">أَكَلٌ</span></h3>
				<div class="sense" id="OakalN_A1">
					<p><span class="ar">أَكَلٌ</span> <a href="#Akl_1">inf. n. of <span class="ar">أَكِلَ</span> <span class="add">[q. v.]</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OakalN_A2">
					<p><span class="ar long">فِى أَسْنَانِهِ أَكَلٌ</span> ‡ <em>In his teeth is a rubbing together and wasting away;</em> by reason of age. <span class="auth">(Ṣ, TA.)</span> <a href="#OukulN">See also <span class="ar">أُكُلٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakilN">
				<h3 class="entry"><span class="ar">أَكِلٌ</span></h3>
				<div class="sense" id="OakilN_A1">
					<p><span class="ar">أَكِلٌ</span> <span class="add">[part. n. of <span class="ar">أَكِلَ</span>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OakilN_A2">
					<p><span class="ar long">نَاقَةٌ أَكِلَةٌ</span> † <em>A she-camel experiencing an itching and annoyance in her belly,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>from the growth of the hair,</em> <span class="auth">(Ṣ,)</span> or <em>from the growth of the fur,</em> <span class="auth">(Ḳ,)</span> <em>of her fœtus.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OakilN_A3">
					<p><span class="add">[<span class="ar">الاَكِلُ</span> is erroneously put, in the CK, for <span class="ar">الآكِلُ</span>, in a sense explained below.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OukulN">
				<h3 class="entry"><span class="ar">أُكُلٌ</span></h3>
				<div class="sense" id="OukulN_A1">
					<p><span class="ar">أُكُلٌ</span> and<span class="arrow"><span class="ar">أُكْلٌ↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.;)</span> the latter a contraction of the former; <span class="auth">(Mṣb;)</span> <em>What is eaten;</em> <span class="auth">(Ṣ, Mṣb, TA;)</span> as also<span class="arrow"><span class="ar">أُكْلَةٌ↓</span></span> and<span class="arrow"><span class="ar">أَكْلَةٌ↓</span></span> <span class="auth">(Lḥ, TA)</span> and<span class="arrow"><span class="ar">مَأْكَلَةٌ↓</span></span> and<span class="arrow"><span class="ar">مَأْكُلَةٌ↓</span></span> <span class="auth">(Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">مَأْكُولٌ↓</span></span>; <span class="auth">(Lḥ, Mṣb;)</span> <em>any eatable;</em> i. e. <em>anything that is eaten;</em> <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">أَكَالٌ↓</span></span> signifies <span class="add">[<em>the same, an eatable,</em> or]</span> <em>food.</em> <span class="auth">(Ṣ, TA.)</span> You say of one who is dead, <span class="ar long">اِنْقَطَعَ أُكُلُهُ</span> <span class="add">[<em>His food has become cut off,</em> or <em>stopped:</em> in the TA, <span class="ar">أَكْلُهُ</span>: <a href="#Akl_1">see 1</a>]</span>. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">مَا ذُقْتُ أَكَالَّا↓</span></span> <em>I have not tasted food.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكُلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OukulN_A2">
					<p><em>Fruit</em> <span class="auth">(Ṣ, Ḳ <span class="add">[in the latter of which, in some copies, <span class="ar">التَّمْرُ</span> is put for <span class="ar">الثَّمَرُ</span>, erroneously, as is said in the TA]</span>)</span> of palmtrees and other trees <span class="add">[&amp;c.]</span>. <span class="auth">(Ṣ.)</span> So in the Ḳur <span class="add">[xiii. 35]</span>, <span class="ar long">أُكُلُهَا دَائِمٌ</span> <span class="add">[<em>Its fruit</em> shall be <em>perpetual</em>]</span>: <span class="auth">(Ṣ, TA:)</span> meaning that the fruits thereof shall be not as those of the present world, which come to one at one time and not at another. <span class="auth">(TA.)</span> <span class="add">[Pl. <span class="ar">آكَالٌ</span>; occurring in the M and Ḳ in art. <span class="ar">اتو</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكُلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OukulN_A3">
					<p>‡ <em>Means of subsistence:</em> <span class="auth">(Ḳ:)</span> <em>worldly good fortune,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and ample means of subsistence.</em> <span class="auth">(Ṣ.)</span> You say, <span class="ar long">فُلَانٌ ذُو أُكُلٍ</span> ‡ <em>Such a one is possessed of worldly good fortune, and ample means of subsistence:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">عَظِيمُ الأُكُلِ</span> ‡ <em>possessed of</em> <span class="add">[<em>great</em>]</span> <em>good fortune;</em> or <em>of a</em> <span class="add">[<em>great and</em>]</span> <em>good share of the means of subsistence.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكُلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OukulN_A4">
					<p>‡ <em>Thickness, substantialness,</em> or <em>closeness</em> or <em>compactness of texture,</em> of a garment, or piece of cloth; <span class="auth">(Ṣ, Ḳ, TA;)</span> and <em>strength</em> thereof. <span class="auth">(Ḳ.)</span> You say <span class="ar long">ثَوْبٌ ذُو أُكُلٍ</span> ‡ <em>A garment,</em> or <em>piece of cloth, having thickness,</em>, &amp;c.: and <span class="ar long">قِرْطَاسٌ ذُو أُكُلٍ</span> ‡ <em>paper having thickness,</em>, &amp;c. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكُلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OukulN_A5">
					<p>‡ <em>Intelligence; judgment;</em> <span class="auth">(Aboo-Naṣr, Ṣ, Ḳ;)</span> <em>firmness of intellect.</em> <span class="auth">(Ḳ, TA.)</span> You say <span class="ar long">رَجُلٌ ذُو أُكُلٍ</span> ‡ <em>A man possessing intelligence and judgment.</em> <span class="auth">(Aboo-Naṣr, Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakolapN">
				<h3 class="entry"><span class="ar">أَكْلَةٌ</span></h3>
				<div class="sense" id="OakolapN_A1">
					<p><span class="ar">أَكْلَةٌ</span> <em>A single act of eating</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> <em>until one is satisfied.</em> <span class="auth">(Ṣ.)</span> Hence the saying, <span class="ar long">المُعْتَادُ أَكْلَتَانِ الغَدَآءُ وَالعَشَآءُ</span>, meaning <em>That to which people are accustomed is two acts of eating,</em> the eating of <em>the morning-meal and</em> that of <em>the evening-meal.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OakolapN_A2">
					<p><a href="#OukolapN">See also <span class="ar">أُكْلَةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OakolapN_A3">
					<p><a href="#OukulN">And see <span class="ar">أُكُلٌ</span></a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OukolapN">
				<h3 class="entry"><span class="ar">أُكْلَةٌ</span></h3>
				<div class="sense" id="OukolapN_A1">
					<p><span class="ar">أُكْلَةٌ</span> <em>A morsel,</em> or <em>small mouthful,</em> of food. <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ.)</span> <span class="add">[For the pl., see below.]</span> You say, <span class="ar long">أَكَلْتُ أُكْلَةً وَاحِدَةً</span> <em>I ate one morsel.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">أَكلَ بِأَخِيهِ أُكْلَةً</span> † <span class="add">[<em>He ate a morsel by means of</em> defaming <em>his brother</em>]</span> is said, in a trad., of a man who is on terms of brotherhood with another, and then goes to his enemy, and speaks of him in a manner not good, in order that he may give him a present for doing so. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OukolapN_A2">
					<p><em>A small round cake of bread;</em> syn. <span class="ar">قُرْصَةٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> <em>a single</em> <span class="ar">قُرْص</span>: <span class="auth">(Mgh:)</span> pl. <span class="ar">أُكَلٌ</span>, as below. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OukolapN_A3">
					<p><a href="#OukulN">See also <span class="ar">أُكُلٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OukolapN_A4">
					<p>Also † <em>i. q.</em> <span class="ar">طُعْمَةٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> which is also syn. with <span class="arrow"><span class="ar">مَأْكَلَةٌ↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ, in art. <span class="ar">طعم</span>;)</span> i. e. <em>An assigned,</em> or <em>appointed, means of subsistence; such as a grant of a tract of land; and a tax,</em> or <em>portion of a tax</em> or <em>taxes; and the like;</em> <span class="auth">(Mgh in explanation of <span class="ar">طُعْمَةٌ</span>, and TA in explanation of the same <a href="#maOokalapN">and of <span class="ar">مَأْكَلَةٌ</span></a> in art. <span class="ar">طعم</span>;)</span> and <span class="add">[it is also said that]</span> <span class="arrow"><span class="ar">مَأْكَلَةٌ↓</span></span> signifies <em>a thing that is assigned,</em> or <em>appointed,</em> or <em>granted, to a man, so that he is not to be reckoned with,</em> or <em>called to account, for it:</em> <span class="auth">(TA in the present art.:)</span> <span class="add">[thus it applies to <em>any absolute grant, either of land,</em> (<em>as an allodium, an appanage, &amp;c.,</em>) <em>or of revenue:</em>]</span> pl. <span class="ar">أُكَلٌ</span> <span class="auth">(Ḳ)</span> <span class="add">[and app. also <span class="ar">آكَالٌ</span>, which see below]</span>. You say, <span class="ar long">هٰذَا الشَّىْءُ أُكلَةٌ لَكَ</span> <em>This thing is a</em> <span class="ar">طُعْمَة</span> <em>to thee,</em> or <em>for thee.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OukolapN_A5">
					<p><a href="#OakiylapN">See also <span class="ar">أَكِيلَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكْلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OukolapN_B1">
					<p>Also, and<span class="arrow"><span class="ar">إِكْلَةٌ↓</span></span> <span class="auth">(Ṣ, Z, Ṣgh, Ḳ)</span> and<span class="arrow"><span class="ar">أَكْلَةٌ↓</span></span>, <span class="auth">(Kr, Ḳ,)</span> ‡ <em>Defamation;</em> or <em>defamation of the absent.</em> <span class="auth">(Ṣ, Z, Ṣgh, Ḳ.)</span> You say, <span class="ar long">إِنَّهُ لَذُو أُكْلَةٍ</span> and<span class="arrow"><span class="ar">إِكْلَةٍ↓</span></span> <span class="auth">(Ṣ, TA)</span> and<span class="arrow"><span class="ar">أَكْلَةٍ↓</span></span> <span class="auth">(TA)</span> ‡ <em>Verily he is one who defames men;</em> or, <em>who does so in their absence.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IikolapN">
				<h3 class="entry"><span class="ar">إِكْلَةٌ</span></h3>
				<div class="sense" id="IikolapN_A1">
					<p><span class="ar">إِكْلَةٌ</span> <em>A mode,</em> or <em>manner,</em> <span class="auth">(Ḳ,)</span> or <em>state,</em> or <em>condition,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>in which one eats:</em> <span class="auth">(Ṣ, Ḳ:*)</span> like <span class="ar">جِلْسَةٌ</span> and <span class="ar">رِكْبَةٌ</span>: <span class="auth">(Ṣ, TA:)</span> and the <em>posture of the eater, reclining or sitting.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">إِنَّهُ لَحَسَنُ الإِكْلَةِ</span> <span class="add">[<em>Verily he has a good mode,</em>, &amp;c., <em>of eating</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">إِكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IikolapN_A2">
					<p><a href="#OukolapN">See also <span class="ar">أُكْلَةٌ</span></a>, last two sentences.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">إِكْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IikolapN_A3">
					<p>‡ The <em>itch:</em> or <em>an itching:</em> <span class="auth">(Ṣ, Ḳ:)</span> as also<span class="arrow"><span class="ar">أُكَالٌ↓</span></span>, <span class="auth">(Aṣ, Ṣ, Ḳ,)</span> <span class="add">[<a href="#Oakalanie">see <span class="ar long">أَكَلَنِى رَأْسِى</span></a>, of which both are said to be inf. ns.,]</span> and<span class="arrow"><span class="ar">أَكِلَةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> so the last is written accord. to the correct copies of the Ḳ: accord. to Esh-Shiháb, in the Shifá el-Ghaleel, it would seem to be <span class="ar">أُكْلَةٌ</span>; but this is at variance with the authority of the leading lexicologists: the same word, <span class="ar">أَكِلَةٌ</span>, is also explained in the Ḳ as signifying <em>a disease in a limb,</em> or <em>member, in consequence of which one part is</em> <span class="add">[<em>as it were</em>]</span> <em>eaten by another;</em> <span class="add">[a meaning which I believe to be correct, (<a href="#OukaAlN">see <span class="ar">أُكَالٌ</span></a>,) although SM says,]</span> but this is identical with the <em>itch,</em> or <em>an itching:</em> and<span class="arrow"><span class="ar">أَكَلَانٌ↓</span></span> is a vulgar term for the same; and so is <span class="arrow"><span class="ar">آكِلَةٌ↓</span></span>, with medd, given as correct by Eth-Tha'álibee, in <span class="add">[his book entitled]</span> the Mudáf and Mensoob, but disallowed by El-Khafájee. <span class="auth">(TA.)</span> One says, <span class="ar long">إِنِّى لَأَجِدُ فِى جَسَدِى إِكْلَةً</span> ‡ <span class="add">[<em>Verily I experience in my body an itching.</em>]</span> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OakilapN">
				<h3 class="entry"><span class="ar">أَكِلَةٌ</span></h3>
				<div class="sense" id="OakilapN_A1">
					<p><span class="ar">أَكِلَةٌ</span>: <a href="#IikolapN">see <span class="ar">إِكْلَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OukalapN">
				<h3 class="entry"><span class="ar">أُكَلَةٌ</span></h3>
				<div class="sense" id="OukalapN_A1">
					<p><span class="ar">أُكَلَةٌ</span>: <a href="#OakuwlN">see <span class="ar">أَكُولٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OakalaAnN">
				<h3 class="entry"><span class="ar">أَكَلَانٌ</span></h3>
				<div class="sense" id="OakalaAnN_A1">
					<p><span class="ar">أَكَلَانٌ</span>: <a href="#IikolapN">see <span class="ar">إِكْلَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OakaAlN">
				<h3 class="entry"><span class="ar">أَكَالٌ</span></h3>
				<div class="sense" id="OakaAlN_A1">
					<p><span class="ar">أَكَالٌ</span>: <a href="#OukulN">see <span class="ar">أُكُلٌ</span></a>, first and second sentences.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OukaAlN">
				<h3 class="entry"><span class="ar">أُكَالٌ</span></h3>
				<div class="sense" id="OukaAlN_A1">
					<p><span class="ar">أُكَالٌ</span> ‡ <em>A corrosion,</em> or <em>cankering,</em> or <em>decaying,</em> of a limb, or member, <span class="add">[and of a sore,]</span> <em>from the mutual eating away of its several parts;</em> as also<span class="arrow"><span class="ar">إِكَالٌ↓</span></span>. <span class="auth">(Ḳ, TA.)</span> <span class="add">[<a href="#OakilapN">See also <span class="ar">أَكِلَةٌ</span></a>, voce <span class="ar">إِكْلَةٌ</span>, where a similar meaning is assigned to the former of these two words; and the same seems to be indicated in the Mṣb.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OukaAlN_A2">
					<p>See also another signification voce <span class="ar">إِكْلَةٌ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أُكَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OukaAlN_A3">
					<p><span class="ar long">بَهَا أُكَالٌ</span>, said of a she-camel, ‡ <em>She has an itching and annoyance in her belly,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>from the growth of the hair,</em> <span class="auth">(Ṣ,)</span> or <em>of the fur,</em> <span class="auth">(Ḳ,)</span> <em>of her fœtus.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IikaAlN">
				<h3 class="entry"><span class="ar">إِكَالٌ</span></h3>
				<div class="sense" id="IikaAlN_A1">
					<p><span class="ar">إِكَالٌ</span>: <a href="#OukaAlN">see <span class="ar">أُكَالٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakuwlN">
				<h3 class="entry"><span class="ar">أَكُولٌ</span></h3>
				<div class="sense" id="OakuwlN_A1">
					<p><span class="ar long">رَجُلٌ أَكُولٌ</span> and<span class="arrow"><span class="ar">أُكَلَةٌ↓</span></span> and<span class="arrow"><span class="ar">أَكِيلٌ↓</span></span> all signify the same; <span class="auth">(Ḳ;)</span> i. e. <em>A man who eats much;</em> <span class="add">[<em>who is a great eater; edacious; voracious;</em>]</span> as also<span class="arrow"><span class="ar">أَكَّالٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakiylN">
				<h3 class="entry"><span class="ar">أَكِيلٌ</span></h3>
				<div class="sense" id="OakiylN_A1">
					<p><span class="ar">أَكِيلٌ</span> <em>One who eats with another.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OakiylN_A2">
					<p><a href="#AkilN">See also <span class="ar">آكِلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OakiylN_A3">
					<p><a href="#OakuwlN">and see <span class="ar">أَكُولٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OakiylN_B1">
					<p><em>I. q.</em> <span class="arrow"><span class="ar">مَأْكُولٌ↓</span></span> <span class="add">[<em>as signifying Eaten</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OakiylN_B2">
					<p><a href="#OakiylapN">See also <span class="ar">أَكِيلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakuwlapN">
				<h3 class="entry"><span class="ar">أَكُولَةٌ</span></h3>
				<div class="sense" id="OakuwlapN_A1">
					<p><span class="ar">أَكُولَةٌ</span> <em>A sheep,</em> or <em>goat, which is set apart</em> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <em>to be eaten,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <span class="add">[i. e.]</span> <em>to be slaughtered,</em> <span class="auth">(Mṣb,)</span> <em>and which is fattened,</em> <span class="auth">(Ṣ, Mgh,)</span> <em>and the taking of which by the collector of the poor-rate is disapproved;</em> <span class="auth">(Ṣ;)</span> <em>not left to pasture by itself, being of the best of the beasts:</em> <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">أَكِيلَةٌ↓</span></span> occurs in the same sense, applied to a sheep, or goat, fattened to be eaten. <span class="auth">(Mgh.)</span> <span class="pb" id="Page_0073"></span>Hence the prov., <span class="ar long">مَرْعًى وَلَا أَكُولَةً</span> <span class="add">[lit. <em>Pasturage, and no</em> <span class="ar">اكولة</span>]</span>; meaning † <em>wealth collected together, and none expended.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكُولَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OakuwlapN_A2">
					<p>Also <em>Barren;</em> applied to a sheep or goat <span class="add">[app. because such is generally eaten]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OukuwlapN">
				<h3 class="entry"><span class="ar">أُكُولَةٌ</span></h3>
				<div class="sense" id="OukuwlapN_A1">
					<p><span class="ar">أُكُولَةٌ</span>: <a href="#OakiylapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakiylapN">
				<h3 class="entry"><span class="ar">أَكِيلَةٌ</span></h3>
				<div class="sense" id="OakiylapN_A1">
					<p><span class="ar">أَكِيلَةٌ</span> and<span class="arrow"><span class="ar">أَكِيلٌ↓</span></span> and<span class="arrow"><span class="ar">أُكُولَةٌ↓</span></span>, with two dammehs, <span class="auth">(Ḳ,)</span> so in the copies of the Ḳ, but perhaps a mistake for<span class="arrow"><span class="ar">أُكْلَةٌ↓</span></span>, <span class="auth">(TA,)</span> a word of a bad dial., <span class="auth">(Ḳ,* TA,)</span> and<span class="arrow"><span class="ar">مَأْكُولٌ↓</span></span> and<span class="arrow"><span class="ar">مُؤَاكِلٌ↓</span></span>, <span class="auth">(Ḳ, TA, <span class="add">[in some copies of the former of which, instead of <span class="ar long">وَهِىَ قَبِيحَةٌ وَالمَأْكُولِ وَالمَؤَاكِلِ</span>, meaning, as is said in the TA, <span class="ar long">وَهِىَ لُغَةٌ قَبِيحَةٌ</span>, &amp;c., we find <span class="ar long">وَهِىَ قَبِيحَةٌ المَأْكُولِ وَالمَؤَاكِلِ</span>,]</span>)</span> <em>A sheep,</em> or <em>goat, which is set</em> <span class="auth">(Ḳ, TA)</span> <em>in the lurking-place of a hunter</em> <span class="auth">(TA)</span> <em>for the purpose of catching thereby the wolf and the like.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OakiylapN_A2">
					<p>And the first two words, <span class="auth">(Ḳ,)</span> or <span class="ar long">أَكِيلَةٌ سَبُعٍ</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> <em>A beast which has been eaten,</em> <span class="auth">(Ṣ,* Ḳ,)</span> or <em>partly eaten,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>by a beast or bird of prey,</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> <em>and then rescued from it:</em> <span class="auth">(Mgh, TA:)</span> the <span class="ar">ة</span> in <span class="ar">اكيلة</span> being added because the quality of a subst. is predominant in it. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">أَكِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OakiylapN_A3">
					<p><a href="#OakuwlapN">See also <span class="ar">أَكُولَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OakBaAlN">
				<h3 class="entry"><span class="ar">أَكَّالٌ</span></h3>
				<div class="sense" id="OakBaAlN_A1">
					<p><span class="ar">أَكَّالٌ</span>: <a href="#OakuwlN">see <span class="ar">أَكُولٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MkilN">
				<h3 class="entry"><span class="ar">آكِلٌ</span></h3>
				<div class="sense" id="MkilN_A1">
					<p><span class="ar">آكِلٌ</span> <em>Eating;</em> or <em>an eater;</em> as also<span class="arrow"><span class="ar">أَكِيلٌ↓</span></span>: pl. <span class="ar">أَكَلَةٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">هُمْ أَكَلَةُ رَأْسٍ</span> <span class="add">[lit. <em>They are eaters of a head</em>]</span>; meaning † <em>they are few; one head satisfying their stomachs.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MkilN_A2">
					<p><span class="ar">آكِلَةٌ</span> ‡ <em>Pasturing beasts.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MkilN_A3">
					<p><span class="ar long">آكِلَةُ اللَّحْمِ</span> † <em>The knife;</em> <span class="auth">(Ḳ, TA;)</span> because it cuts the flesh: <span class="auth">(TA:)</span> and <em>the pointed staff</em> or <em>stick;</em> <span class="auth">(Ḳ, TA;)</span> as being likened thereto: <span class="auth">(TA:)</span> and <em>fire:</em> <span class="auth">(Ḳ:)</span> and <em>whips;</em> <span class="auth">(Sh, Ḳ;)</span> because they burn the skin. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MkilN_A4">
					<p><span class="ar">الآكِلُ</span>, <span class="add">[in the CK, erroneously, <span class="ar">الاَكِلُ</span>,]</span> ‡ <em>The king.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[Opposed to <span class="ar">المَأْكُولُ</span>, q. v.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="MkilN_A5">
					<p><span class="ar long">آكِلُ الرِّبَا</span> ‡ <span class="add">[<em>The receiver of usury</em>]</span>: occurring in a trad., in which it is said,<span class="arrow"><span class="ar long">لُعِنَ آكِلُ الرِّبَا وَمُؤْكِلُهُ↓</span></span> ‡ <span class="add">[<em>The receiver of usury is cursed, and the giver thereof</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MkilapN">
				<h3 class="entry"><span class="ar">آكِلَةٌ</span></h3>
				<div class="sense" id="MkilapN_A1">
					<p><span class="ar">آكِلَةٌ</span> <a href="#AkilN">fem. of <span class="ar">آكِلٌ</span>, q. v.</a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكِلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MkilapN_A2">
					<p><a href="#IikolapN">See also <span class="ar">إِكْلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MkaAlN">
				<h3 class="entry"><span class="ar">آكَالٌ</span></h3>
				<div class="sense" id="MkaAlN_A1">
					<p><span class="ar">آكَالٌ</span> <span class="add">[app. a pl. of pauc. of <span class="ar">أُكُلٌ</span>, q. v., <a href="#OukolN">and of <span class="ar">أُكْلٌ</span></a>, agreeably with analogy,]</span> ‡ The <span class="add">[<em>grants termed</em>]</span> <span class="ar">مَآكِل</span> of kings; <span class="auth">(Ḳ;)</span> their <span class="ar">طُعَم</span> <span class="add">[<a href="#TuEomapN">pl. of <span class="ar">طُعْمَةٌ</span></a>, explained above, voce <span class="ar">أُكْلَةٌ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MkaAlN_A2">
					<p>† The <em>stipends</em> of soldiers. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">آكَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MkaAlN_A3">
					<p><span class="ar">ذَووالآكَالِ</span>, for which J has erroneously put <span class="ar">الآكال</span>, <span class="add">[in the Ṣ,]</span> <span class="auth">(TṢ, Ḳ,)</span> without <span class="ar">ذوو</span>, <span class="auth">(TA,)</span> ‡ <em>The lords,</em> or <em>chiefs, of the tribes, who take the</em> <span class="ar">مِرْبَاع</span> <span class="add">[or <em>fourth part of the spoil,</em> which was the chief's portion in the time of ignorance]</span> <span class="auth">(Ṣ, TṢ, Ḳ, TA)</span> <em>&amp;c.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOokalN">
				<h3 class="entry"><span class="ar">مَأْكَلٌ</span></h3>
				<div class="sense" id="maOokalN_A1">
					<p><span class="ar">مَأْكَلٌ</span>, <span class="auth">(Ṣ,)</span> <span class="add">[in measure]</span> like <span class="ar">مَقْعَدٌ</span>, <span class="auth">(TA,)</span> <span class="add">[<a href="#Akl_1">an inf. n. of <span class="ar">أَكَلَ</span>, q. v.</a>:]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOokalN_A2">
					<p><span class="add">[and also signifying]</span> <em>Gain.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOokalN_A3">
					<p><span class="add">[Also <em>A place, and a time, of eating:</em> pl. <span class="ar">مَآكِلُ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWokalN">
				<h3 class="entry"><span class="ar">مُؤْكَلٌ</span></h3>
				<div class="sense" id="muWokalN_A1">
					<p><span class="ar">مُؤْكَلٌ</span> † <em>Fortunate; possessed of good fortune; prosperous.</em> <span class="auth">(Aboo-Saʼeed, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWokilu">
				<h3 class="entry"><span class="ar">مُؤْكِلُ</span></h3>
				<div class="sense" id="muWokilu_A1">
					<p><span class="ar long">مُؤْكِلُ الرِّبَا</span> ‡ <span class="add">[<em>The giver of usury:</em> <a href="#AkilN">see <span class="ar">آكِلٌ</span></a>, last sentence]</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOokalapN">
				<h3 class="entry"><span class="ar">مَأْكَلَةٌ</span></h3>
				<div class="sense" id="maOokalapN_A1">
					<p><span class="ar">مَأْكَلَةٌ</span> and<span class="arrow"><span class="ar">مَأْكُلَةٌ↓</span></span>: <a href="#OukulN">see <span class="ar">أُكُلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOokalapN_A2">
					<p>and for the former, <a href="#OukolapN">see also <span class="ar">أُكْلَةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOokalapN_A3">
					<p><span class="add">[Also, both words, i. q. <span class="ar">مِيرَةٌ</span> i. e. <em>Corn,</em> or <em>any provision, which a man brings,</em> or <em>purveys, for himself</em> or <em>his family,</em> or <em>for sale</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="maOokalapN_A4">
					<p>Also used in the sense explained above, voce <span class="ar">أُكُلٌ</span>, <span class="add">[as a subst.,]</span> and likewise as an epithet, so that one says <span class="ar long">شَاةٌ مأكلهٌ</span> <span class="add">[as meaning <em>A sheep,</em> or <em>goat, that is eaten</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="maOokalapN_A5">
					<p>Both words signify <span class="add">[also]</span> <em>A place whence one eats.</em> <span class="auth">(Ṣ, O.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="maOokalapN_A6">
					<p><span class="add">[And hence]</span> one says, <span class="ar long">اِتَّخَذْتُ فُلَانًا مَأْكَلَةً</span> and <span class="ar">مَأْكَلَةٌ</span> † <span class="add">[<em>I took for myself such a one as a person from whom to obtain what to eat</em>]</span>. <span class="auth">(Ṣ, O.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="maOokalapN_A7">
					<p><span class="add">[The pl. is <span class="ar">مَآكِلُ</span>: of which see an ex. voce <span class="ar">آكَالٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOokulapN">
				<h3 class="entry"><span class="ar">مَأْكُلَةٌ</span></h3>
				<div class="sense" id="maOokulapN_A1">
					<p><span class="ar">مَأْكُلَةٌ</span>: <a href="#maOokalapN">see the paragraph next preceding, throughout</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYokalapN">
				<h3 class="entry"><span class="ar">مِئْكَلَةٌ</span></h3>
				<div class="sense" id="miYokalapN_A1">
					<p><span class="ar">مِئْكَلَةٌ</span> <em>Anything in</em> <span class="add">[i. e. <em>out of</em>]</span> <em>which one eats:</em> <span class="auth">(Lḥ, Ḳ:)</span> or <span class="add">[<em>bowls of the kind called</em>]</span> <span class="ar">صِحَاف</span>, <span class="auth">(Ṣ,)</span> or <em>a</em> <span class="add">[<em>bowl of the kind called</em>]</span> <span class="ar">صَحْفَة</span>, <span class="auth">(TA,)</span> <em>in which the tribe find it easy to cook,</em> <span class="auth">(so in a copy of the Ṣ and in the TA,)</span> or <em>to put,</em> <span class="auth">(so in another copy of the Ṣ,)</span> <em>flesh-meat and</em> <span class="add">[<em>the kind of porridge called</em>]</span> <span class="ar">عَصِيدَة</span>: <span class="auth">(Ṣ, TA:)</span> or <em>a bowl not so large as a</em> <span class="ar">صَحفة</span>, <em>but next to it in size, that satisfies the stomachs of two men, or three:</em> <span class="auth">(Ṣ voce <span class="ar">صَحْفَةٌ</span>:)</span> <span class="add">[or]</span> <em>a small</em> <span class="add">[<em>bowl of the kind called</em>]</span> <span class="ar">قَصْعَةٌ</span>, <em>that satisfies the stomachs of three:</em> and <em>a small</em> <span class="add">[<em>cooking-pot such as is called</em>]</span> <span class="ar">بُرْمَه</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOokuwlN">
				<h3 class="entry"><span class="ar">مَأْكُولٌ</span></h3>
				<div class="sense" id="maOokuwlN_A1">
					<p><span class="ar">مَأْكُولٌ</span>: <a href="#OakiylN">see <span class="ar">أَكِيلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكُولٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOokuwlN_A2">
					<p><a href="#OukulN">and <span class="ar">أُكُلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكُولٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOokuwlN_A3">
					<p><a href="#OakiylapN">and <span class="ar">أَكِيلَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مَأْكُولٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="maOokuwlN_A4">
					<p>† The <em>subjects</em> of a king. <span class="auth">(Z, Ḳ, TA.)</span> Hence the trad., <span class="ar long">مَأْكُولٌ حِمْيَرَ خَيْرٌ مِنْ آكِلِهَا</span> ‡ <em>The subjects of Himyer are better than their king,</em> or <em>ruler.</em> <span class="auth">(Z, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYokaAlN">
				<h3 class="entry"><span class="ar">مِئْكَالٌ</span></h3>
				<div class="sense" id="miYokaAlN_A1">
					<p><span class="ar">مِئْكَالٌ</span> <em>A spoon:</em> <span class="auth">(Ḳ:)</span> because one eats with it. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaAkilN">
				<h3 class="entry"><span class="ar">مُؤَاكِلٌ</span></h3>
				<div class="sense" id="muWaAkilN_A1">
					<p><span class="ar">مُؤَاكِلٌ</span>: <a href="#OakiylapN">see <span class="ar">أَكِيلَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكل</span> - Entry: <span class="ar">مُؤَاكِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWaAkilN_A2">
					<p>Also, <span class="add">[like<span class="arrow"><span class="ar">مُسْتَأْكِلٌ↓</span></span>,]</span> † <em>One who takes and devours the possessions of men.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="musotaOokilN">
				<h3 class="entry"><span class="ar">مُسْتَأْكِلٌ</span></h3>
				<div class="sense" id="musotaOokilN_A1">
					<p><span class="ar">مُسْتَأْكِلٌ</span>: <a href="#muwaAkilN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0071.pdf" target="pdf">
							<span>Lanes Lexicon Page 71</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0072.pdf" target="pdf">
							<span>Lanes Lexicon Page 72</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0073.pdf" target="pdf">
							<span>Lanes Lexicon Page 73</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
