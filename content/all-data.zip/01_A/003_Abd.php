<article class="root" id="Root_Abd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/002_Abjd">ابجد</a></span>
				<span class="ar">ابد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/004_Abr">ابر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abd_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبد</span></h3>
				<div class="sense" id="Abd_1_A1">
					<p><span class="ar">أَبَدَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِدُ</span>}</span></add>, inf. n. <span class="ar">أُبُودٌ</span>, <em>He remained, stayed, abode,</em> or <em>dwelt,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> <em>constantly, continually,</em> or <em>permanently, without quitting,</em> <span class="auth">(T, L,)</span> <span class="ar">بِمَكَانٍ</span> <em>in a place;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> and so <span class="ar">أَبَدَ</span> having for its aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُدُ</span>}</span></add>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abd_1_A2">
					<p><span class="ar">أَبَدَ</span>, <span class="auth">(Ṣ, M, A, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِدُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُدُ</span>}</span></add>, <span class="auth">(T, Ṣ, M, L, Mṣb, Ḳ,)</span>, inf. n. <span class="ar">أُبُودٌ</span>; <span class="auth">(M, L, Mṣb;)</span> and<span class="arrow"><span class="ar">تأبّد↓</span></span>; <span class="auth">(T, M, A, Mgh, L;)</span> <em>He</em> <span class="auth">(a beast)</span> <em>became wild,</em> or <em>sky;</em> syn. <span class="ar">تَوَحَّشَ</span>: <span class="auth">(Ṣ, M, A, Mgh, L, Mṣb, Ḳ:)</span> <span class="add">[because wild animals live long, unless killed by accident; accord. to what is said by Aṣ and others in explanation of <span class="ar">أوَابِدٌ</span> <span class="auth">(sing. <span class="ar">آبِدَةٌ</span>)</span> applied to animals, as meaning wild:]</span> <em>took fright, and fled,</em> or <em>ran away at random:</em> <span class="auth">(Mgh:)</span> <em>took fright at, and shunned, mankind.</em> <span class="auth">(T, Mṣb.)</span> <span class="ar">أُبُودٌ</span> also signifies The <em>shrinking</em> from a thing, or <em>shunning</em> it; syn. <span class="ar">نُفُورٌ</span>. <span class="auth">(Kull pp. 30 and 31.)</span> And <span class="ar">أَبِدَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْبَدُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">تأبّد↓</span></span>; <span class="auth">(A, Ḳ;)</span> <em>He</em> <span class="auth">(a man, Ṣ, A,)</span> <em>became unsocial, unsociable, unfamiliar,</em> or <em>sky; like a wild animal;</em> syn. <span class="ar">توحّش</span>. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abd_1_A3">
					<p><span class="add">[Hence,]</span> <span class="ar">أَبَدَ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِدُ</span>}</span></add>, inf. n. <span class="ar">أُبُودٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He</em> <span class="auth">(a poet)</span> <em>made use, in his verses, of words,</em> or <em>phrases, strange, unusual, unfamiliar,</em> or <em>far from being intelligible,</em> <span class="auth">(Ḳ,* TA,)</span> <em>such as were not understood</em> <span class="auth">(Ḳ)</span> <em>at first sight,</em> or <em>on first consideration.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Abd_1_A4">
					<p><span class="add">[And perhaps from <span class="ar">أَبِدَ</span> in the sense explained above, but more probably, I think, by the substitution of <span class="ar">أ</span> for <span class="ar">و</span>,]</span> <span class="ar">أَبِدَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْبَدُ</span>}</span></add>, <span class="auth">(T, Ṣ, &amp;c.,)</span>, inf. n. <span class="ar">أَبَدٌ</span>, <span class="auth">(L,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>was angry;</em> <span class="auth">(T, Ṣ, M, L, Ḳ;)</span> as also <span class="ar">أَمِدَ</span> and <span class="ar">وَبِدَ</span> and <span class="ar">وَمِدَ</span> and <span class="ar">عَبِدَ</span>. <span class="auth">(T, L.)</span> You say, <span class="ar long">أَبِدَ عَلَيْهِ</span> <em>He was angry with him.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أبّد</span></h3>
				<div class="sense" id="Abd_2_A1">
					<p><span class="ar">أبّد</span>, inf. n. <span class="ar">تَأْبِيدٌ</span>, <em>He made,</em> or <em>rendered, perpetual.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[See also the pass. part. n. below.]</span> <span class="ar long">لَمْ أَفْعَلْ تَأْبِيدًا</span> is a phrase used as though meaning<span class="arrow"><span class="ar long">لَمْ آتِ بِآبِدَةٍ↓</span></span> <span class="add">[<em>I did not a deed ever to be remembered,</em> or <em>mentioned</em>]</span>. <span class="auth">(Ḥam p. 191.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abd_2_A2">
					<p><em>He,</em> or <em>it, made</em> <span class="add">[a beast]</span> <em>to take fright; to become wild,</em> or <em>sky.</em> <span class="auth">(KL.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّد</span></h3>
				<div class="sense" id="Abd_5_A1">
					<p><span class="ar">تأبّد</span>: <a href="#Abd_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abd_5_A2">
					<p><em>He</em> <span class="auth">(a man)</span> <em>was long distant from his home;</em> expl. by <span class="ar long">طَالَتْ غُرْبَتُهُ</span>; <span class="auth">(Ḳ;)</span> or <em>was long in a state of celibacy;</em> <span class="ar long">طالت عُزْبَتُهُ</span>, as in one copy of the Ḳ; <span class="auth">(TA;)</span> <em>and became little in need,</em> or <em>little desirous, of women.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abd_5_A3">
					<p><em>It</em> <span class="auth">(a place of abode or sojourning)</span> <em>became deserted</em> <span class="add">[<em>by mankind</em>]</span>: <span class="auth">(T, M, Ḳ:)</span> and <em>became inhabited by wild animals.</em> <span class="auth">(T, M, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibodN">
				<h3 class="entry"><span class="ar">إِبْدٌ</span></h3>
				<div class="sense" id="IibodN_A1">
					<p><span class="ar">إِبْدٌ</span>: <a href="#IibidN">see <span class="ar">إِبِدٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabadN">
				<h3 class="entry"><span class="ar">أَبَدٌ</span></h3>
				<div class="sense" id="OabadN_A1">
					<p><span class="ar">أَبَدٌ</span> <em>Time,</em> syn. <span class="ar">دَهْرٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>in an absolute sense:</em> <span class="auth">(TA:)</span> or <em>a long time,</em> syn. <span class="ar long">دَهْرٌ طَوِيلٌ</span>: <span class="auth">(A, and Mgh: <span class="add">[and this may be meant in the Ṣ, &amp;c. by the syn. <span class="ar">دَهْرٌ</span> alone, q. v.:]</span>)</span> or, properly, <em>a long time</em> (<span class="ar long">دهر طويل</span>) <em>that is unlimited:</em> <span class="auth">(Mṣb, TA:)</span> or <em>an extended space of time that is indivisible;</em> for you say <span class="ar long">زَمَانُ كَذَا</span>: “the time of such a thing,” but not <span class="ar long">أَبَدُ كَذَا</span>: <span class="auth">(Er-Rághib:)</span> <span class="add">[and generally, <em>time,</em> or <em>duration,</em> or <em>continuance,</em> or <em>existence, without end; endless time,</em>, &amp;c.; <em>prospective eternity;</em> opposed to <span class="ar">أَزَلٌ</span>, which signifies “time, or duration, &amp;c., without beginning:” <span class="auth">(see the latter word for further explanations, &amp;c.:)</span> each of these significations may be meant by the explanation in the Ṣ and M and Ḳ, which is also given in the Mṣb: each correctly applies in particular instances:]</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آبَادٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">أُبُودٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> <span class="add">[and <span class="ar">أَبَدُونَ</span>, of which an ex. will be found below]</span>: but the use of these pls. is restricted to particular cases, to signify portions of time, or to serve as corroboratives to the sing.: <span class="auth">(MF:)</span> as signifying an extended indivisible space of time, <span class="add">[or the like,]</span> <span class="ar">أَبَدٌ</span> should have neither dual nor pl.; but <span class="ar">آبَادٌ</span> is sometimes said, when the sing. is restricted to denote a particular part, or portion, of the whole of that to which it applies, in like manner as a generic noun is restricted to a special and partial signification: some, however, have mentioned <span class="ar">آبَادٌ</span> as being post-classical; not of the language of the Arabs called <span class="ar long">العَرَبُ العَرْبَآءُ</span>. <span class="auth">(Er-Rághib.)</span> <span class="ar long">طَالَ الأَبَدْ عَلَى لُبَدْ</span> <span class="add">[<em>The time became long to Lubad,</em> the last, and the longest of life, of Luk- mán's seven vultures, to the term of the life of which his own term of life was decreed to extend,]</span> is a proverb applied to any thing that has been of long duration. <span class="auth">(M.)</span> And you say, <span class="ar long">رَزَقَكَ ٱللّٰهُ عُمُرًا طَوِيلَ الآبَادِ بَعِيدَ الآمَادِ</span> <span class="add">[<em>May God grant thee a life long in duration</em> <span class="auth">(lit. <em>durations,</em> the pl. form being used not in its proper sense, but to give intensiveness of signification)</span>, <em>and remote in limit</em> <span class="auth">(lit. <em>limits</em>)</span>]</span>. <span class="auth">(A.)</span> And <span class="ar long">كَانَ هٰذَا فِى آبَادِ الدَّهْرِ</span> <em>This was a long time ago.</em> <span class="auth">(Mgh.)</span> And<span class="arrow"><span class="ar long">أَبَدٌ آبِدٌ↓</span></span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar long">أَبَدٌ أَبِيدٌ↓</span></span>, <span class="auth">(Ṣ, M, TA,)</span> meaning <span class="ar">دَائِمٌ</span> <span class="add">[in an intensive sense]</span>; <span class="auth">(TA;)</span> <span class="add">[<em>A long,</em> or <em>an endless, period of time;</em>]</span> like as you say, <span class="ar long">دَهْرٌ دَاهِرٌ</span> <span class="auth">(Ṣ)</span> or <span class="ar long">دَهْرٌ دَهِيرٌ</span>. <span class="auth">(M.)</span> <span class="add">[In each of these phrases, the latter word is added as a corroborative, or to give intensiveness to the signification.]</span> <span class="ar">لِلْأَبِدَ</span> and <span class="ar">لِأَبِدٍ</span> and <span class="add">[in an intensive sense, as will be seen below,]</span> <span class="ar long">لِأَبِدَ أَبَدٍ</span> and <span class="ar long">لِأَبَدِ الأَبَدِ</span>, accord. to different recitals of a trad., signify <em>To the end of time; for ever;</em> and <em>for ever and ever.</em> <span class="auth">(TA.)</span> <span class="ar">أَبَدًا</span> is an adv. n., of which the signification includes all future time; <span class="add">[meaning <em>Ever;</em> like <span class="ar">قَطُّ</span> in relation to past time;]</span> <span class="auth">(El-Khafájee, El-Bedr Ed-Demámeenee, MF;)</span> and <span class="ar long">عَلَى الأَبَدِ</span> signifies the same. <span class="auth">(TA.)</span> <span class="add">[So, too, does <span class="ar">الأَبَدَ</span>, unless used in a limited sense known to the hearer.]</span> When you say, <span class="ar long">لَا أُكَلِّمُهُ أَبَدًا</span>, you mean, <span class="add">[<em>I will not speak to him as long as I live,</em> or <em>henceforth,</em> or <em>ever;</em> or <em>I will never speak to him;</em> i. e.,]</span> from the time of your speaking to the end of your life. <span class="auth">(Mṣb.)</span> <span class="add">[In this case, <span class="ar">أَبَدًا</span> may also be considered as a mere corroborative. It is used in both these ways (<span class="ar">للتَّأْسِيسِ</span> and <span class="ar">لِلتَّوْكِيدِ</span>) in affirmative as well as negative sentences. For exs. of its use in affirmative sentences, see the Ḳur xviii. 2 and iv. 60, &amp;c.]</span> One also says, <span class="ar long">لَا أَفْعَلُهُ</span>, <span class="auth">(Ṣ, M, A,)</span> and <span class="ar long">لَا آتِيهِ</span>, <span class="auth">(T, Ḳ,)</span> <span class="ar long">أَبَدَ الآبَادِ</span>, <span class="auth">(T, M, A, Ḳ,)</span> which, though of classical authority, is said to be no evidence of the use of <span class="ar">آباد</span> <a href="#OabadN">as a pl. of <span class="ar">أَبَدٌ</span></a> in a general way by the Arabs of the classical ages, as it is here added merely as a corroborative, as <span class="ar">آزال</span> is in the phrase <span class="ar long">أَزَلَ الآزَالِ</span>; <span class="auth">(MF;)</span> and <span class="ar long">أَبَدَ الأَبَدِينَ</span>, <span class="auth">(M, A, Ḳ,)</span> in which the latter word is not a rel. n., for if so it would be <span class="ar">الأَبَدِيِّينَ</span>, but app. a pl., <span class="auth">(M,)</span> like <span class="ar">أَرَضُونَ</span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar long">أَبَدَ الآبِدِينَ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> like as you say, <span class="ar long">دَهْرَ الآبِدِينَ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar long">أَبَدَ الأَبَدِيَّةِ↓</span></span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar long">أَبَدَ الأَبِيدِ↓</span></span>; <span class="auth">(T, Ṣ, M, A, Ḳ;)</span> and<span class="arrow"><span class="ar long">أَبِيدَ الأَبِيدِ↓</span></span>; <span class="auth">(M, Ḳ;)</span> and <span class="ar long">أَبَدَ الأَبَدِ</span>; <span class="auth">(Ḳ;)</span> <span class="pb" id="Page_0005"></span>and <span class="ar long">أَبَدَ الدَّهْرِ</span> <span class="auth">(M, Ḳ; <span class="add">[in the T <span class="ar long">يَدَ الدَّهْرِ</span>;]</span>)</span> all of which phrases are the same in meaning; <span class="auth">(Ḳ;)</span> <span class="add">[i. e. <em>I will not do it,</em> and <em>I will not come to him,</em> <span class="auth">(or <span class="ar long">لا آتيه</span> may here mean the same as <span class="ar long">لا افعله</span>,)</span> <em>during the endless space of all future times,</em> or <em>time;</em> or <em>the like;</em> or <em>for ever and ever;</em> <span class="gr">εἰς αἰῶνα τῶν αἰώνων</span>; <em>in seculum seculorum; in omne ævum;</em>]</span> the last word in every case being a corroborative. <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">أَبَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabadN_A2">
					<p>Also, <span class="add">[for <span class="ar long">ذُو أَبَدٍ</span>, and <span class="auth">(applied to a fem. n.)</span> <span class="ar long">ذَاتُ أَبَدٍ</span>,]</span> <em>Lasting:</em> or <em>everlasting.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> So in the saying, <span class="ar long">الدُّنيَاء أَمَدٌ وَالآخِرَةُ أَبَدٌ</span> <span class="add">[<em>The present state of existence is limited in duration, but the final state of existence is everlasting</em>]</span>. <span class="auth">(ʼObeyd Ibn-ʼOmeyr and L.)</span> And <span class="ar">الأَبَدُ</span> signifies <span class="add">[<em>The Everlasting;</em> i. e. God; because He alone is<span class="arrow">↓<span class="ar long">البَاقِى الأَبَدِيّ</span></span> <em>The Enduring without end</em> or <em>cessation;</em> for the Muslims hold that all living creatures <span class="auth">(even the angels)</span> must die, and be raised again to life: or]</span> <em>The Ancient without beginning.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">أَبَدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabadN_B1">
					<p>Also <em>Offspring that is a year old.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabidN">
				<h3 class="entry"><span class="ar">أَبِدٌ</span></h3>
				<div class="sense" id="OabidN_A1">
					<p><span class="ar">أَبِدٌ</span> <em>Unsocial, unsociable, unfamiliar,</em> or <em>shy; like a wild animal;</em> applied to a man, and to a young camel: <span class="auth">(Ṣ, L:)</span> and<span class="arrow">↓<span class="ar">إِبِدٌ</span></span>, applied to a female slave, and to a she-ass, signifies <em>shunning mankind, shy,</em> or <em>wild.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#AbidN">See also <span class="ar">آبِدٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">أَبِدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabidN_B1">
					<p><a href="#IibidN">See also <span class="ar">إِبِدٌ</span></a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibidN">
				<h3 class="entry"><span class="ar">إِبِدٌ</span></h3>
				<div class="sense" id="IibidN_A1">
					<p><span class="ar">إِبِدٌ</span>: <a href="#OabidN">see <span class="ar">أَبِدٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">إِبِدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IibidN_B1">
					<p>This word, <span class="auth">(Lth, ISh, Ṣ, Ḳ,)</span> said by Lth and ISh to be the only word of its measure heard from the Arabs except <span class="ar">إِبِلٌ</span> and <span class="ar">نِكِحٌ</span> and <span class="ar">خِطِبٌ</span>, but Az says that he had not heard the last two from any person worthy of reliance, and that they are pronounced <span class="ar">نِكْحٌ</span> and <span class="ar">خِطْبٌ</span>, <span class="auth">(L,)</span> <span class="add">[<a href="#IibilN">see <span class="ar">إِبِلٌ</span></a>,]</span> and<span class="arrow"><span class="ar">أَبِدٌ↓</span></span> and<span class="arrow"><span class="ar">إِبْدٌ↓</span></span>, <span class="auth">(Ḳ,)</span> which are thought by Az to be dial. vars. of the first, <span class="auth">(L,)</span> applied to a female slave, and to a she-ass, signify <em>Prolific; that breeds,</em> or <em>brings forth, plentifully;</em> <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">أَبِدٌ↓</span></span> and<span class="arrow"><span class="ar">أَبِدَةٌ↓</span></span> <span class="auth">(Aboo-Málik, TA)</span> and<span class="arrow"><span class="ar">إِبِدَةٌ↓</span></span>, <span class="auth">(Aboo-Málik, Ḳ,)</span> applied to a she-camel, signify the same: <span class="auth">(Aboo-Málik, Ḳ, TA:)</span> and <span class="ar">إِبِدٌ</span> <span class="auth">(Lth, ISh, L)</span> and<span class="arrow"><span class="ar">أَبِدٌ↓</span></span>, <span class="auth">(M, L,)</span> applied to a female slave, <span class="auth">(M, L,)</span> and to a she-ass, <span class="auth">(Lth, ISh, M, L,)</span> and to a mare, <span class="auth">(M, L,)</span> <em>that brings forth every year;</em> <span class="auth">(Lth, ISh, L;)</span> or applied as a pl. to the female slave and the mare and the she-ass, <em>that breed,</em> or <em>bring forth:</em> <span class="auth">(M, L:)</span> and <span class="ar">الإِبِدَانِ</span> <em>the female slave and the mare.</em> <span class="auth">(Ḳ, TA.)</span> In the following saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَنْ يُقْلِعَ الجَدُّ النَّكِدْ</span> *</div> 
						<div class="star">* <span class="ar long">الَّابِجَدِّ ذِى الإِبِدْ</span> *</div> 
						<div class="star">* <span class="ar long">فِى كُلِّ مَا عَامٍ تَلِدْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Hard fortune will not depart save with the fortune</em> which is the necessary attendant <em>of the possessor of the female slave,</em> as long as he possesses her, <span class="auth">(or, if we take <span class="ar">ذى</span> in the sense of <span class="ar">هٰذِهِ</span>, <em>save with the fortune of this female slave,</em>)</span> <em>who every year</em> (<span class="ar">ما</span> being redundant) <em>brings forth,</em>]</span> <span class="ar">الابد</span> means the female slave because her being prolific is an obstacle to prosperity, and is not good fortune; i. e., she only increases evil <span class="add">[and brings reproach upon her master by bearing him children; for the Arab in ancient times was considered as dishonoured by his having a child by a slave]</span>. <span class="auth">(Ṣ.)</span> The Arabs also said,<span class="arrow"><span class="ar long">لَنْ يَبْلُغَ الجَدَّ النَّكِدْ الاَّ الأَبِدْ↓</span></span>, meaning <em>Nothing will attain to the object of removing hard fortune save female slaves and beasts or cattle which breed,</em> or <em>bring forth.</em> <span class="auth">(M, L: <span class="add">[in the latter of which is added, <span class="ar long">فِى كُلِّ عَامٍ تَلِدْ</span> <em>in every year bringing forth.</em>]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabidapN">
				<h3 class="entry"><span class="ar">أَبِدَةٌ</span></h3>
				<div class="sense" id="OabidapN_A1">
					<p><span class="ar">أَبِدَةٌ</span>: <a href="#IibidN">see <span class="ar">إِبِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibidapN">
				<h3 class="entry"><span class="ar">إِبِدَةٌ</span></h3>
				<div class="sense" id="IibidapN_A1">
					<p><span class="ar">إِبِدَةٌ</span>: <a href="#IibidN">see <span class="ar">إِبِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabadieBN">
				<h3 class="entry"><span class="ar">أَبَدِىٌّ</span></h3>
				<div class="sense" id="OabadieBN_A1">
					<p><span class="ar">أَبَدِىٌّ</span>: <a href="#OabadN">see <span class="ar">أَبَدٌ</span></a>, last sentence but one.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabadiyBapN">
				<h3 class="entry"><span class="ar">أَبَدِيَّةٌ</span></h3>
				<div class="sense" id="OabadiyBapN_A1">
					<p><span class="ar">أَبَدِيَّةٌ</span> <span class="add">[The <em>quality,</em> or <em>attribute, of unlimited, indivisible,</em> or <em>endless, duration; everlastingness</em>]</span>. <span class="auth">(M, Ḳ.)</span> <a href="#OabadN">See <span class="ar">أَبَدٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">أَبَدِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabadiyBapN_A2">
					<p><span class="ar">أَبَدِيَّاتٌ</span> a term applied to <em>Sayings of which the following is an ex.:</em> <span class="ar long">لَا آتِيكَ مَا بَلَّ بَحْرٌ صُوفَةً</span>. <span class="auth">(M in art. <span class="ar">صوف</span> <span class="add">[q. v.]</span>;, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabuwdN">
				<h3 class="entry"><span class="ar">أَبُودٌ</span></h3>
				<div class="sense" id="OabuwdN_A1">
					<p><span class="ar">أَبُودٌ</span>: <a href="#AbidN">see <span class="ar">آبِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabiydN">
				<h3 class="entry"><span class="ar">أَبِيدٌ</span></h3>
				<div class="sense" id="OabiydN_A1">
					<p><span class="ar">أَبِيدٌ</span>: <a href="#OabadN">see <span class="ar">أَبَدٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbidN">
				<h3 class="entry"><span class="ar">آبِدٌ</span> / <span class="ar">آبِدَةٌ</span></h3>
				<div class="sense" id="MbidN_A1">
					<p><span class="ar">آبِدٌ</span> <em>Remaining, staying, abiding,</em> or <em>dwelling, constantly, continually,</em> or <em>permanently,</em> in a place; applied to a man <span class="add">[and to a bird]</span>. <span class="auth">(L.)</span> And <span class="ar">أَوَابِدُ</span> <span class="add">[<a href="#AbidapN">pl. of <span class="ar">آبِدَةٌ</span></a>]</span> Birds <em>that remain in a country constantly, winter and summer;</em> <span class="auth">(T, L;)</span> <em>contr. of</em> <span class="ar">قَوَاطِعُ</span>. <span class="auth">(A, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">آبِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MbidN_A2">
					<p>For the phrases <span class="ar long">أَبَدٌ آبِدٌ</span> and <span class="ar long">أَبَدَ الآبِدِينَ</span>, <a href="#OabadN">see <span class="ar">أَبَدٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">آبِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MbidN_A3">
					<p>A <em>wild</em> animal; <span class="auth">(M, L, Mṣb;)</span> <em>that shuns, and takes fright at, mankind, amp;c.:</em> <span class="auth">(L, Mṣb:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">آبِدَةٌ</span>}</span></add>: pl. <span class="add">[properly fem.]</span> <span class="ar">أَوَابِدُ</span>, <span class="auth">(M, Mgh, L,)</span> and <span class="add">[masc. and fem.]</span> <span class="ar">أُبَّدٌ</span>: <span class="auth">(M, L:)</span> and<span class="arrow">↓<span class="ar">أَبُودٌ</span></span> is syn. with <span class="ar">آبِدٌ</span>; <span class="auth">(M;)</span> as also<span class="arrow">↓<span class="ar">مُتَأَبِّدٌ</span></span>. <span class="auth">(A.)</span> Wild animals are called <span class="ar">أَوَابِدُ</span> <span class="auth">(Ṣ, M, L, Ḳ)</span> and <span class="ar">أُبَّدٌ</span> <span class="auth">(M, L, Ḳ)</span> because they endure for a long, or <span class="add">[naturally]</span> unlimited, time; <span class="auth">(M, L;)</span> because they do not die a natural death, <span class="auth">(Aṣ, M, L, Ḳ,)</span> but from some evil accident; and the same is asserted of the serpent. <span class="auth">(Aṣ, M, L.)</span> <span class="add">[<a href="#OabidN">See also <span class="ar">أَبِدٌ</span></a>.]</span> <span class="add">[Hence,]</span> <span class="ar long">قَيْدُ الأَوَابِدِ</span> † <em>The light,</em> or <em>active, horse, which overtakes the wild animals, and which they can hardly,</em> or <em>never, escape:</em> so called because he prevents their escaping the pursuer like a shackle. <span class="auth">(Mṣb.)</span> <span class="add">[<a href="index.php?data=21_q/234_qyd">See also art. <span class="ar">قيد</span></a>.]</span> <span class="add">[Hence also the saying,]</span> <span class="ar long">النِّعَمُ أَوَابِدُ فَقَيِّدُوهَا بِالشُّكْرِ</span> ‡ <span class="add">[<em>Benefits are fugitive,</em> or <em>fleeting; therefore detain ye them by gratitude</em>]</span>. <span class="auth">(A trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbidapN">
				<h3 class="entry"><span class="ar">آبِدَةٌ</span></h3>
				<div class="sense" id="MbidapN_A1">
					<p><span class="ar">آبِدَةٌ</span> <a href="#AbidN">fem. of <span class="ar">آبِدٌ</span>, q. v.</a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">آبِدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MbidapN_A2">
					<p>Also, <span class="add">[as a subst.,]</span> † <em>A deed,</em> <span class="auth">(Ḥar p. 364,)</span> or <em>a calamity,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>ever to be remembered,</em> or <em>mentioned,</em> <span class="auth">(Ṣ, M, Ḳ, Ḥar,)</span> <em>by reason of its extraordinary nature, and its grievousness:</em> <span class="auth">(Ḥar:)</span> or <em>a great,</em> or <em>formidable, event, at which people take fright,</em> or <em>are alarmed:</em> <span class="auth">(TA:)</span> or <em>a strange, abominable,</em> or <em>evil, thing:</em> <span class="auth">(Ḥam p. 627:)</span> pl. <span class="ar">أَوَابِدُ</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">جَاءَ فُلَانٌ بِآبِدَةٍ</span> <em>Such a one did,</em> or <em>brought to pass,</em> <span class="add">[<em>a deed</em> or]</span> <em>calamity ever to be remembered,</em> or <em>mentioned.</em> <span class="auth">(Ṣ.)</span> <a href="#Abd_2">See also 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">آبِدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MbidapN_A3">
					<p>‡ <em>A strange, an unusual,</em> or <em>an unfamiliar, word</em> or <em>saying; one far from being intelligible;</em> <span class="auth">(M;)</span> pl. <span class="ar">أَوَابِدُ</span>, signifying <em>expressions of subtile meanings;</em> so called because <em>remote from perspicuity.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">آبِدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MbidapN_A4">
					<p>The pl. also signifies ‡ <em>Strange, unusual, unfamiliar,</em> or <em>extraordinary, rhymes,</em> or <em>verses,</em> or <em>poems;</em> syn. <span class="ar long">شَوَارِدُ مِنَ القَوَافِى</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">قَوَافٍ شُرَّدٌ</span>. <span class="auth">(Ḳ.)</span> El-Farezdaḳ says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَنْ تُدْرِكُوا كَرَمِى بِلُؤْمِ أَبِيكُمُ</span> *</div> 
						<div class="star">* <span class="ar long">وَأَوَابِدِى بِتَنَحُّلِ الأَشْعَارِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Ye will not attain to my nobility with the ignobleness of your father, nor to my extraordinary verses by arrogating to yourselves the verses of other men</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#Abd_1">See <span class="ar">أَبَدَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWabBadN">
				<h3 class="entry"><span class="ar">مُؤَبَّدٌ</span> / <span class="ar">مُؤَبَّدَةٌ</span></h3>
				<div class="sense" id="muWabBadN_A1">
					<p><span class="ar">مُؤَبَّدٌ</span> <span class="add">[<em>Made,</em> or <em>rendered, perpetual</em>]</span>. You say, <span class="ar long">وَقَفَ أَرْضَهُ وَقْفًا مُؤَبَدًا</span> <em>He made his land an unalienable bequest for pious uses in perpetuity, not to be sold nor to be inherited.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابد</span> - Entry: <span class="ar">مُؤَبَّدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWabBadN_A2">
					<p>Also, with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُؤَبَّدَةٌ</span>}</span></add>, A she-camel that is <em>wild, and intractable,</em> or <em>unmanageable;</em> syn. <span class="ar long">وَحْشِيَّةٌ مُعْتَاصَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOabBidN">
				<h3 class="entry"><span class="ar">مُتَأَبِّدٌ</span></h3>
				<div class="sense" id="mutaOabBidN_A1">
					<p><span class="ar">مُتَأَبِّدٌ</span>: <a href="#AbidN">see <span class="ar">آبِدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0004.pdf" target="pdf">
							<span>Lanes Lexicon Page 4</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0005.pdf" target="pdf">
							<span>Lanes Lexicon Page 5</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
