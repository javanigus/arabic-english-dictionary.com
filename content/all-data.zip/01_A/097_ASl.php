<article class="root" id="Root_ASl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/096_ASTrlAb">اصطرلاب</a></span>
				<span class="ar">اصل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/098_AT">اط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ASl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أصل</span></h3>
				<div class="sense" id="ASl_1_A1">
					<p><span class="ar">أَصُلَ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَصَالَةٌ</span>; <span class="auth">(TA;)</span> or <span class="ar">أَصِلَ</span>; <span class="auth">(M;)</span> <em>It</em> <span class="auth">(a thing, M)</span> <em>had,</em> or <em>came to have, root,</em> or <em>a foundation;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تأصّل↓</span></span>: <span class="auth">(M:)</span> or <em>it was,</em> or <em>became, firm,</em> or <em>established,</em> and <em>firmly rooted</em> or <em>founded;</em> as also<span class="arrow"><span class="ar">تأصّل↓</span></span>: <span class="auth">(Ḳ:)</span> and <span class="add">[in like manner]</span> <span class="arrow"><span class="ar">استأصل↓</span></span> <em>it</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became, firm in its root</em> or <em>foundation, and strong.</em> <span class="auth">(Mṣb.)</span> You say,<span class="arrow"><span class="ar long">اِسْتَأْصَلَتِ↓ الشَجَرَةُ</span></span> <em>The tree</em> <span class="add">[<em>took root;</em> or]</span> <em>grew, and became firm in its root.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ASl_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">أَصُلَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ, M,)</span> <em>He</em> <span class="auth">(a man, Ṣ,* M)</span> <em>was,</em> or <em>became, firm,</em> <span class="auth">(Ṣ, M, Ḳ;)</span> or <em>sound,</em> <span class="auth">(Ṣ,)</span> <em>of judgment;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>intelligent.</em> <span class="auth">(M: <span class="add">[and so, probably, in correct copies of the Ḳ; but in a MṢ. copy of the Ḳ and in the CK; and TA, instead of <span class="ar">عَاقِل</span>, the reading in the M, I find <span class="ar">عَاقِب</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="ASl_1_A3">
					<p>Also, <span class="auth">(Ṣ,* Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ, TA,)</span> <em>It</em> <span class="auth">(judgment, or opinion,)</span> <em>was,</em> or <em>became, firm,</em> or <em>sound,</em> <span class="auth">(Ṣ,* TA,)</span> or <em>good.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="ASl_1_A4">
					<p>And, inf. n. as above, <em>It</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became, eminent, noble,</em> or <em>honourable.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ASl_1_B1">
					<p><span class="ar">أَصَلَهُ</span>, <span class="add">[aor. and inf. n. as in what follows next after this sentence,]</span> <em>He hit,</em> or <em>struck, its root,</em> or <em>foundation; that by being which it was what it was,</em> or <em>in being which it consisted;</em> or <em>its ultimate constituent.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="ASl_1_B2">
					<p>And hence, <span class="auth">(A, TA,)</span> <span class="ar long">أَصَلَهُ عِلْمًا</span>, <span class="auth">(A, Ḳ, TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْصُلُ</span>}</span></add>, inf. n. <span class="ar">أَصْلٌ</span>: <span class="auth">(TA;)</span> or<span class="arrow"><span class="ar">آصَلَهُ↓</span></span> <span class="add">[with medd, <span class="auth">(which I think to be a mistake, unless this be a dial. var.,)</span> and without <span class="ar">علما</span>]</span>; <span class="auth">(so in a copy of the M;)</span> † <em>He knew it completely,</em> or <em>thoroughly,</em> or <em>superlatively well,</em> syn. <span class="ar">قَتَلَهُ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[i. e.]</span> <span class="ar long">قَتَلَهُ عِلْمًا</span>, <em>so that he was acquainted with its</em> <span class="ar">أَصْل</span> <span class="add">[or <em>root,</em> or <em>foundation,</em> or its <em>ultimate constituent,</em> as is indicated in the A and TA]</span>: <span class="auth">(M:)</span> or this is from <span class="ar">أَصَلَةٌ</span>, as meaning “a certain very deadly serpent;” <span class="auth">(A, TA;)</span> <span class="add">[whence the phrase,]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="ASl_1_B3">
					<p><span class="ar long">أَصَلَتْهُ الأَصَلَةُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَصْلٌ</span>, <span class="auth">(TA,)</span> <em>The</em> <span class="add">[<em>serpent called</em>]</span> <span class="ar">اصلة</span> <em>sprang upon him</em> <span class="auth">(Ḳ, TA)</span> <em>and slew him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="ASl_1_C1">
					<p><span class="ar">أَصِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْصَلُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">أَصَلٌ</span>, <span class="auth">(M,)</span> said of water, <em>i. q.</em> <span class="ar">أَسِنَ</span>; <span class="auth">(M, Ḳ;)</span> i. e. <em>It became altered for the worse</em> <span class="auth">(M, TA)</span> <em>in its taste and odour,</em> <span class="auth">(TA,)</span> <em>from fetid black mud</em> <span class="auth">(Ḳ, TA)</span> <em>therein:</em> so says Ibn-ʼAbbád: <span class="auth">(TA:)</span> and said of flesh-meat, <em>it became altered</em> <span class="auth">(Ḳ, TA)</span> <em>in like manner.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="ASl_1_D1">
					<p><span class="ar long">أَصِلَ فُلَانٌ يَفْعَلُ كَذَا وَكَذَا</span> <em>Such a one set about,</em> or <em>commenced, doing thus and thus,</em> or <em>such and such things.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ASl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أصّل</span></h3>
				<div class="sense" id="ASl_2_A1">
					<p><span class="ar">أصلّهُ</span>, inf. n. <span class="ar">تَأْصِيلٌ</span>, <em>He made it to have a firm,</em> or <em>fixed, root,</em> or <em>foundation, whereon to build,</em> <span class="auth">(Mṣb, TA,)</span> i. e., <em>whereon another thing might be built.</em> <span class="auth">(El-Munáwee, TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">أصّل مَالَهُ</span> <em>i. q.</em> <span class="ar">أَثَّلَهُ</span> <span class="add">[<em>He made his wealth,</em> or <em>property, to have root,</em> or <em>a foundation;</em> or <em>to become firm,</em> or <em>established,</em> and <em>firmly rooted</em> or <em>founded:</em> see, below, <span class="ar long">أَصْلُ مَالٍ</span>, and <span class="ar long">مَالٌ لَهُ أَصْلٌ</span>]</span>. <span class="auth">(M and Ḳ in art. <span class="ar">اثل</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ASl_2_A2">
					<p><span class="ar long">أصّل الأُصُولَ</span> <span class="add">[<em>He disposed, arranged, distributed, classified,</em> or <em>set in order, the fundamentals, fundamental articles, principles, elements,</em> or <em>rudiments,</em> of a science, &amp;c.,]</span> is a phrase similar to <span class="ar long">بَوَّبَ الأَبْوَابَ</span> and <span class="ar long">رَتَّبَ الرُّتَبَ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ASl_4">
				<h3 class="entry">4. ⇒ <span class="ar">آصل</span></h3>
				<div class="sense" id="ASl_4_A1">
					<p><span class="ar">آصل</span>, <span class="auth">(inf. n. <span class="ar">إِيصَالٌ</span>, TA,)</span> <em>He entered upon the time called</em> <span class="ar">أَصِيل</span>, q. v. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ASl_4_B1">
					<p><a href="#ASl_1">See also <span class="ar long">أَصَلَهُ عِلْمًا</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="ASl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأصّل</span></h3>
				<div class="sense" id="ASl_5_A1">
					<p><span class="ar">تأصّل</span>: <a href="#ASl_1">see 1</a>, first sentence, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="ASl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأصل</span></h3>
				<div class="sense" id="ASl_10_A1">
					<p><span class="ar">استأصل</span>: <a href="#ASl_1">see 1</a>, in two places, first and second sentences.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ASl_10_B1">
					<p><span class="ar">استأصلهُ</span> <em>He uprooted it; unrooted it; eradicated it; extirpated it; pulled it up,</em> or <em>out,</em> or <em>off, from its root,</em> or <em>foundation,</em> or <em>lowest part,</em> <span class="auth">(Ṣ, TA,)</span> or <em>with its roots,</em> or <em>foundations,</em> or <em>lowest parts;;</em> <span class="auth">(TA;)</span> <em>he cut it off</em> <span class="auth">(M, Mṣb)</span> <em>from its root,</em> or <em>lowest part,</em> <span class="auth">(M,)</span> or <em>with its roots,</em> or <em>lowest parts.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">اِسْتَأْصَلَ ٱللّٰهُ شَأْفَتَهُمْ</span>, a precative phrase, meaning <em>May God</em> <span class="add">[<em>extirpate</em> or]</span> <em>remove</em> (<em>from them</em>) <em>their</em> <span class="ar">شأفة</span>; which is an ulcer, or a purulent pustule, that comes forth in the foot, and is cauterized, and in consequence goes away: <span class="auth">(M:)</span> or <span class="ar long">استأصل شأفتهم</span> <span class="add">[in general usage]</span> means <em>he extirpated them,</em> or <em>may he extirpate them;</em> or <em>he cut off,</em> or <em>may he cut off, the last remaining of them.</em> <span class="auth">(TA. <span class="add">[<a href="../">See also art. <span class="ar">شأف</span></a>.]</span>)</span> And <span class="ar long">استأصل القَوْمَ</span>, i. e. <span class="ar long">قَطَعَ أَصْلَهُمْ</span> <span class="add">[<em>He cut off the root, race,</em> or <em>stock, of the people;</em> i. e. <em>he extirpated them</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">استأصل ٱللّٰهُ الكُفَّارَ</span> <em>God destroyed altogether</em> or <em>entirely,</em> or <em>may God destroy altogether</em> or <em>entirely, the unbelievers.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">استأصل الخِتَانَ</span> <em>He performed the circumcision so as to remove the prepuce utterly.</em> <span class="auth">(TA in art. <span class="ar">سحت</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSolN">
				<h3 class="entry"><span class="ar">أَصْلٌ</span></h3>
				<div class="sense" id="OaSolN_A1">
					<p><span class="ar">أَصْلٌ</span> The <em>lower,</em> or <em>lowest, part</em> of a thing; <span class="add">[i. e. its <em>root, bottom,</em> or <em>foot;</em>]</span> <span class="auth">(M, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">يَأْصُولٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> so of a mountain: and of a wall; <span class="auth">(TA;)</span> i. e. its <em>foundation,</em> or <em>base:</em> <span class="auth">(Mṣb:)</span> and of a tree <span class="add">[or plant]</span>; <span class="auth">(TA;)</span> i. e. <span class="add">[its <em>stem,</em> or <em>trunk,</em> or <em>stock,</em> or]</span> the <em>part from which the branches are broken off:</em> <span class="auth">(TA in art. <span class="ar">كسر</span>:)</span> <span class="add">[and also its <em>root,</em> or <em>foot;</em> for]</span> the <span class="ar">سَاق</span> of a tree is said to be the part between its <span class="ar">أَصْل</span> and the place where its branches shoot out: <span class="auth">(TA in art. <span class="ar">سوق</span>:)</span> <span class="add">[and <em>a stump</em> of a tree: and hence, <em>a block</em> of wood: <span class="auth">(see exs. voce <span class="ar">نَقِيرٌ</span>:)</span>]</span> pl. <span class="ar">أُصُولٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">آصُلٌ</span>: <span class="auth">(AḤn, Ḳ:)</span> <span class="add">[ISd says that]</span> the former is its only pl.: <span class="auth">(M:)</span> <span class="add">[but]</span> the latter pl. occurs in a verse of Lebeed, <span class="auth">(which see below,)</span> as cited by AḤn. <span class="auth">(TA.)</span> You say, <span class="ar long">قَعَدَ فِى أَصْلِ جَبَلِ</span> <em>He sat upon,</em> or <em>at, the lowest part</em> <span class="add">[&amp;c.]</span> <em>of the mountain;</em> and <span class="ar long">فِى أَصْلِ الحَائِطِ</span> <em>at the lowest part</em> <span class="add">[&amp;c.]</span> <em>of the wall.</em> <span class="auth">(TA.)</span> And <span class="ar long">قَلَعَهُ مِنْ أَصْلِهِ</span> <span class="add">[<em>He pulled it up,</em> or <em>out,</em> or <em>off, from its root,</em> or <em>foundation,</em> or <em>lowest part</em>]</span>; and <span class="ar">بأُصُولِهِ</span> <span class="add">[<em>with its roots,</em> or <em>foundations,</em> or <em>lowest parts;</em> both meaning, <em>utterly, entirely,</em> or <em>altogether</em>]</span>. <span class="auth">(TA in explanation of <span class="ar">استأصلهُ</span>, q. v.)</span> And <span class="ar long">قَلَعَ أَصْلَ الشَّجَرَةِ</span> <em>He pulled up,</em> or <em>out, the lowest part,</em> <span class="add">[or <em>stem</em> or <em>stock</em> or <em>root</em> or <em>foot</em> or <em>stump,</em>]</span> <em>of the tree.</em> <span class="auth">(TA.)</span> Lebeed says, <span class="add">[of a wild cow,]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَجْتَافُ آصُلَ قَالِصٍ مُتَنَبِّذٍ</span> *</div> 
						<div class="star">* <span class="ar long">بِعُجُوبِ أَنْقَآءٍ يَمِيلُ هَيَامُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>She enters into the midst of the stems of trees with high branches, apart from others,</em> i. e. from other trees, <em>in the hinder parts of sand-hills, the fine loose sand thereof inclining</em> upon her]</span>: <span class="auth">(AḤn, TA:)</span> but as some relate it, <span class="ar long">أَصْلًا قَالِصًا</span>. <span class="auth">(TA. <span class="add">[See EM, p. 161.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaSolN_A2">
					<p><em>A thing upon which another thing is built</em> or <em>founded</em> <span class="add">[either properly or tropically]</span>: <span class="auth">(KT, Kull p. 50, TA:)</span> the <em>foundation,</em> or <em>basis,</em> of a thing, <span class="add">[either properly or tropically,]</span> <em>which being imagined to be taken away,</em> or <em>abstracted, by its being taken away,</em> or <em>abstracted, the rest thereof becomes also taken away,</em> or <em>abstracted:</em> <span class="auth">(Er-Rághib, TA:)</span> <em>that upon which the existence</em> of anything <em>rests</em> <span class="add">[or <em>depends</em>]</span>; so the father is <span class="ar">اصل</span> to the offspring, and the river is <span class="ar">اصل</span> to the streamlet that branches off from it: <span class="auth">(Mṣb:)</span> or <em>a thing upon which another thing depends as a branch;</em> as the father in relation to the son: <span class="auth">(Kull:)</span> <span class="add">[i. e. the <em>origin, source, beginning,</em> or <em>commencement,</em> of a thing: the <em>origin, original, root, race,</em> or <em>stock,</em> from which a man springs. Hence <span class="ar long">شَىْءٌ لَهُ أَصْلٌ</span> <em>A thing having root,</em> or <em>a foundation;</em> and consequently, <em>having rootedness, fixedness, im- mobility, stability,</em> or <em>permanence; rooted, fixed, immoveable, stable,</em> or <em>permanent.</em> Whence,]</span> <span class="ar long">مَالٌ لَهُ أَصْلٌ</span>, <span class="auth">(Mgh voce <span class="ar">عَقَارٌ</span>,)</span> and <span class="ar long">مِلْكٌ ثَابِتٌ لَهُ أَصْلٌ</span>, <span class="auth">(Mṣb in explanation of that word,)</span> and <span class="ar long">مَا لَهُ أَصْلٌ</span>, <span class="auth">(KT in explanation of the same,)</span> <span class="add">[<em>Real,</em> or <em>immoveable, property;</em>]</span> <em>property such as consists in a house or land yielding a revenue;</em> <span class="auth">(Mgh;)</span> or <em>such as a house and palm-trees;</em> <span class="auth">(Mṣb;)</span> or <em>such as land and a house.</em> <span class="auth">(KT.)</span> <span class="add">[Hence, also, <span class="ar long">أَصْلٌ مَالٍ</span> signifying <em>A source of wealth</em> or <em>profit; a stock, fund, capital,</em> or <em>principal.</em> You say,]</span> <span class="ar long">اِتَّخَذْتُهُ لِنَفْسِى أَصْلَ مَالٍلِلنَّسْلِ لَا لِلِتِّجَارَةِ</span> <span class="add">[<em>I took it for myself as a source of wealth</em> or <em>profit, for breeding, not for traffic</em>]</span>. <span class="auth">(Mgh in art. <span class="ar">قنو</span>.)</span> You say also, <span class="ar long">بَاعَ أَصْلَ أَرْضِهِ</span> <span class="add">[meaning <em>He sold the fundamental property, i. e. the property itself, of his land</em>]</span>. <span class="auth">(Ṣ voce <span class="ar">عِكْرٌ</span>.)</span> <span class="add">[<a href="#bqae_4">See also an ex. in conjugation 4</a> <a href="../">in art. <span class="ar">بقَى</span></a>: and another in <a href="#Hbs_1">the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=06_H/004_Hbs">of art. <span class="ar">حبس</span></a>.]</span> And <span class="ar long">أَخَذَهُ بِأَصْلِهِ</span> <span class="add">[<em>He took it as it were with its root,</em> or <em>the like;</em> meaning, <em>entirely</em>]</span>. <span class="auth">(Ḳ. <span class="add">[<a href="#OaSiylapN">See <span class="ar">أَصِيلَةٌ</span></a>.]</span>)</span> And <span class="ar long">قَطَعَ أَصْلَهُمْ</span> <span class="add">[<em>He cut off their root, race,</em> or <em>stock; i. e. he extirpated them</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">فُلَانٌ فِى أَصْلِ صِدْقِ</span>, <span class="auth">(Ṣ and L in art. <span class="ar">ضنأ</span>,)</span> <span class="pb" id="Page_0065"></span>and <span class="ar long">فِى أَصْلِ سُوْءٍ</span>, <span class="auth">(L ibid.,)</span> <em>Such a one is of an excel-lent origin,</em> or <em>race,</em> or <em>stock,</em> <span class="auth">(Ṣ, L,)</span> and <em>of a bad origin,</em> or <em>race,</em> or <em>stock;</em> <span class="auth">(L;)</span> <span class="ar">اصل</span> being here syn. with <span class="ar">ضِنْء</span> <span class="auth">(Ṣ, L)</span> and <span class="ar">مَعْدِن</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">فُلَانٌ فِى أَصْلِ الكَرَمِ</span> <em>Such a one is of</em> <span class="add">[a race]</span> <em>the source of generosity,</em> or <em>nobleness;</em> <span class="ar">اصل</span> being here syn. with <span class="ar">بُؤْبُؤ</span>. <span class="auth">(Ṣ in art. <span class="ar">بأ</span>.)</span> And <span class="ar long">لَا أَصْلَ لَهُ وَلَا فَصْلَ</span> <em>He has no</em> <span class="ar">حَسَب</span> <span class="add">[i. e. <em>grounds of pretension to respect</em> or <em>honour;</em> or <em>rank,</em> or <em>nobility,</em> or <em>the like</em>]</span>; <em>nor tongue</em> <span class="add">[<em>i. e. eloquence</em>]</span>: <span class="auth">(Ks, Ṣ, O, Mṣb:)</span> or <em>he has no intellect,</em> <span class="auth">(IAạr, Mṣb, El-Munáwee,)</span> <em>nor eloquence:</em> <span class="auth">(El-Munáwee, TA:)</span> or <em>he has no lineage, nor tongue:</em> <span class="auth">(L:)</span> or <em>he has no father, nor child:</em> <span class="auth">(Kull p. 53:)</span> <span class="add">[or <em>he has no</em> known <em>stock nor branch;</em> for]</span> <span class="ar">فَصْلٌ</span> <a href="#OaSolN">is the contr. of <span class="ar">أَصْلٌ</span></a>, and in relationship signifies <em>a branch.</em> <span class="auth">(Mṣb in art. <span class="ar">فصل</span>.)</span> You say also, <span class="ar long">مَا فَعَلْتُهُ أَصْلًا</span>, meaning <em>I have not done it ever;</em> and <em>I will not do it ever;</em> the last word being in the accus. case as an adverbial noun; i. e. <em>I have not done it at any time;</em> and <em>I will not do it at any time.</em> <span class="auth">(Mṣb, El-Munáwee, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaSolN_A3">
					<p><span class="add">[It also signifies The <em>original,</em> or <em>elemental, matter, material, substance,</em> or <em>part,</em> of a thing; syn. with <span class="ar">عُنْصُرٌ</span>;]</span> <em>that from which a thing is taken</em> <span class="add">[or <em>made</em>]</span>. <span class="auth">(KT voce <span class="ar">دَاخِلٌ</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaSolN_A4">
					<p><span class="add">[The <em>fundamental,</em> or <em>essential, part</em> of a thing. Hence, <a href="#OuSuwlN">sing. of <span class="ar">أُصُولٌ</span></a> as signifying The <em>fundamentals, fundamental articles</em> or <em>dogmas, principles, elements,</em> or <em>rudiments,</em> of a science, &amp;c. Whence,]</span> <span class="ar long">عِلْمُ الأُصُولِ</span>, <span class="auth">(TA,)</span> <span class="add">[meaning]</span> <span class="ar long">عِلْمُ أُصُولِ الدِّينِ</span> <span class="add">[<em>The science of the fundamentals, fundamental articles</em> or <em>dogmas,</em> or <em>principles, of religion; the science of theology,</em> or <em>divinity; according to the system of the Muslims, as distinguished from that of the philosophers;</em>]</span> <em>the science of the articles,</em> or <em>tenets, of belief;</em> also called <span class="ar long">الفِقْهُ الأَكْبَرُ</span>; <span class="auth">(Kull. voce <span class="ar">فِقْه</span>;)</span> and <span class="add">[more commonly]</span> <span class="ar long">عِلْمُ الكَلَامِ</span>. <span class="auth">(Ḥájjee Khaleefeh.)</span> <span class="add">[<a href="#ASl_2">See also 2</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaSolN_A5">
					<p><em>A radical</em> <span class="auth">(as opposed to an augmentative)</span> <em>letter;</em> as being an essential element of a word. <span class="auth">(The Lexicons passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaSolN_A6">
					<p>The <em>original form</em> of a word. <span class="auth">(The same passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaSolN_A7">
					<p>The <em>original,</em> or <em>primary, signification</em> of a word. <span class="auth">(The same passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaSolN_A8">
					<p><em>An original copy</em> of a book: and <em>a copy</em> of a book <em>from which one quotes, or transcribes, any portion.</em> <span class="auth">(TA, &amp;c., passim.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaSolN_A9">
					<p><span class="add">[The <em>original,</em> or <em>primary, state,</em> or <em>condition:</em> or]</span> the <em>old state,</em> or <em>condition.</em> <span class="auth">(Kull p. 50.)</span> You say, <span class="ar long">الأَصْلُ فِى الأَشْيَآءِ الإِبَاحَةُ وَالطَّهَارَةُ</span> <em>The old state,</em> or <em>condition, of things is that of being allowable,</em> or <em>lawful, and that of being pure,</em> or <em>clean.</em> <span class="auth">(Kull ubi suprà.)</span> And <span class="ar long">رَجَعَتْ إِلَى أَصْلِهَا</span> <em>She returned,</em> or <em>reverted,</em> <span class="add">[<em>to her original,</em> or <em>old, state,</em> or <em>condition;</em> or <em>to her natural disposition;</em>]</span> <em>to a natural disposition which she had relinquished.</em> <span class="auth">(Ṣ voce <span class="ar">عِتْرٌ</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="OaSolN_A10">
					<p><span class="add">[The <em>utmost point,</em> or <em>degree, to which a person,</em> or <em>thing, can go,</em> or <em>be brought</em> or <em>reduced:</em> and, app., the <em>utmost that one can do.</em> Hence the saying,]</span> <span class="ar long">لَأَضْطَرَّنَّكَ إِلَى أَصْلِكَ</span> <span class="add">[<em>I will assuredly impel thee,</em> or <em>drive thee, against thy will, to the utmost point to which thou canst go,</em> or <em>be brought</em> or <em>reduced:</em> or, <em>constrain thee to do thine utmost</em>]</span>. <span class="auth">(IAạr in L, art. <span class="ar">قح</span> <span class="add">[where it is given in explanation of the phrases <span class="ar">لَأَضْطَرَّنَّكَ</span> and <span class="ar">قُحَاحِكَ</span>; and so in the T in art. <span class="ar">تر</span> in explanation of the former of these two phrases; which is said in the M, in art. <span class="ar">تر</span>, to mean <em>I will assuredly make thee to have recourse to thine utmost effort,</em> or <em>endeavour;</em> <a href="index.php?data=21_q/025_qH">and in the L in art. <span class="ar">قح</span></a> this is given as another explanation of the latter of the same two phrases. <a href="#qaraArN">See also the saying, <span class="ar long">لَأُلْجِئَنَّكَ إِلَى قُرِّ قَرَارِكَ</span>, explained voce <span class="ar">قَرَارٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="OaSolN_A11">
					<p><span class="add">[<em>That by being which a thing is what it is,</em> or <em>in being which it consists;</em> or its <em>ultimate constituent;</em> syn. <span class="ar">حَقِيقَةٌ</span>; a meaning well known; and indicated, in the A and TA, by the coupling of <span class="ar">حَقِيقَة</span> with <span class="ar">أَصْل</span>, evidently as an explicative adjunct.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="OaSolN_A12">
					<p><span class="add">[The <em>prime</em> of a thing; the <em>principal, purest, best,</em> or <em>choicest, part thereof; what is,</em> or <em>constitutes, the most essential part</em> thereof; its <em>very essence.</em> Hence,]</span> <span class="ar long">أَصْلُ دَارٍ</span> <span class="add">[<em>The principal part of a country</em>]</span>; <span class="auth">(Aṣ, Ṣ, Mṣb, Ḳ, voce <span class="ar">عَقْرٌ</span>;)</span> <span class="add">[which is]</span> <em>the place where the people dwell,</em> or <em>abide.</em> <span class="auth">(As and Ṣ ibid. <span class="add">[<a href="#EaqorN">See <span class="ar">عَقْرٌ</span></a>.]</span>)</span> And <span class="ar long">أَصْلٌ قَوْمٍ</span> <span class="add">[<em>The principal place of abode of a people</em>]</span>. <span class="auth">(Ṣ and Ḳ <a href="#baYoDapN">voce <span class="ar">بَيْضَةٌ</span></a>. <span class="add">[<a href="#baYoDapN">See this word</a>.]</span>)</span> And <span class="ar long">هُوَ فِى أَصْلِ قَوْمِهِ</span> <em>He is of the prime,</em> or <em>of the purest in race, the best,</em> or <em>the choicest, of his people;</em> i. q. <span class="ar">صُيَّابَتِهِمْ</span>, and <span class="ar">صُيَّابِهِمْ</span>. <span class="auth">(TA in art. <span class="ar">صيب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="OaSolN_A13">
					<p><em>What is most fit,</em> or <em>proper:</em> as when one says, <span class="ar long">الأَصْلُ فِى الإِنْسَانِ العِلْمُ</span> <span class="add">[<em>What is most fit,</em> or <em>proper, in man, is knowledge</em>]</span>; i. e., knowledge is more fit, or proper, than ignorance: and <span class="ar long">الأَصْلُ فِى المُبْتَدَإِ التَّقْدِيمُ</span> <em>What is</em> <span class="add">[<em>most</em>]</span> <em>fit,</em> or <em>proper, in the case of the inchoative, is the putting</em> <span class="add">[it]</span> <em>before</em> <span class="add">[the enunciative]</span>, whenever there is no obstacle. <span class="auth">(Kull p.50.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="OaSolN_A14">
					<p><em>What is preponderant in relation to what is preponderated:</em> as, in language, the word used in its proper sense <span class="add">[in relation to that used in a tropical sense]</span>. <span class="auth">(Kull ibid.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="OaSolN_A15">
					<p><em>What is</em> <span class="add">[<em>essential,</em> or]</span> <em>requisite,</em> or <em>needful:</em> as when one says <span class="ar long">الأَصْلُ فِى الحَيَوَانِ الغِذَآءُ</span> <span class="add">[<em>What is essential,</em> or <em>requisite,</em> or <em>needful, in the case of the animal, is food</em>]</span>. <span class="auth">(Kull ibid.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="OaSolN_A16">
					<p><em>A</em> <span class="add">[<em>primary,</em> or]</span> <em>universal,</em> or <em>general, rule,</em> or <em>canon.</em> <span class="auth">(Kull ibid.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A17</span>
				</div>
				<div class="sense" id="OaSolN_A17">
					<p><em>An indication, an evidence,</em> or <em>a proof, in relation to that which is indicated,</em> or <em>evidenced,</em> or <em>proved.</em> <span class="auth">(Kull ibid.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaSalN">
				<h3 class="entry"><span class="ar">أَصَلٌ</span></h3>
				<div class="sense" id="OaSalN_A1">
					<p><span class="ar">أَصَلٌ</span>: <a href="#OaSalapN">see its n. un., <span class="ar">أَصَلَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSilN">
				<h3 class="entry"><span class="ar">أَصِلٌ</span></h3>
				<div class="sense" id="OaSilN_A1">
					<p><span class="ar">أَصِلٌ</span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">أَصِيلٌ↓</span></span>, <span class="auth">(M,)</span> i. q. <span class="arrow"><span class="ar">مُسْتَأْصِلٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span> You say <span class="ar long">قَلْعٌ أَصِلٌ</span> <em>Eradicating,</em> or <em>extirpating, evulsion:</em> <span class="auth">(TA:)</span> or<span class="arrow"><span class="ar long">قَطْعٌ أَصِيلٌ↓</span></span> <em>extirpating excision.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuSulN">
				<h3 class="entry"><span class="ar">أُصُلٌ</span></h3>
				<div class="sense" id="OuSulN_A1">
					<p><span class="ar">أُصُلٌ</span>, said by some to be a pl., and by others to be a dial. var., of <span class="ar">أَصِيلٌ</span>: see the latter word, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSalapN">
				<h3 class="entry"><span class="ar">أَصَلَةٌ</span></h3>
				<div class="sense" id="OaSalapN_A1">
					<p><span class="ar">أَصَلَةٌ</span>: <a href="#OaSiylapN">see <span class="ar">أَصِيلَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصَلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaSalapN_B1">
					<p>Also <em>A kind of serpent, the most malignant,</em> or <em>noxious, of serpents:</em> <span class="auth">(Ṣ:)</span> or <em>a serpent,</em> <span class="auth">(M, Ḳ,)</span> <em>short,</em> <span class="auth">(M, <span class="add">[where, in the only copy to which I have access, I find added, <span class="ar">كَالرِئَةِ</span>, app. a mistranscription, for <span class="ar">كَالرُّمَّةِ</span>, <em>like the fragment of a rope,</em>]</span>)</span> or <em>small,</em> <span class="auth">(Ḳ,)</span> <em>red, but not intensely red,</em> <span class="auth">(M,)</span> <em>very deadly, of the most malignant,</em> or <em>noxious, kind,</em> <span class="auth">(TA,)</span> <em>having one leg, upon which it stands,</em> <span class="auth">(M, TA,)</span> <em>then turns round, then springs,</em> <span class="auth">(TA,)</span> <em>that springs upon a man, and blows, killing everything upon which it blows:</em> <span class="auth">(M:)</span> or, as some say, <em>a great serpent,</em> <span class="auth">(M, Ḳ,)</span> <em>that kills by its blowing:</em> <span class="auth">(Ḳ:)</span> or <em>one of the very crafty kinds of serpents, short and broad, said to be like the shaft of an arrow, and it springs upon the horseman:</em> <span class="auth">(Mṣb:)</span> pl. <span class="arrow"><span class="ar">أَصَلٌ↓</span></span>, <span class="auth">(Ṣ, M. Mṣb, Ḳ,)</span> <span class="add">[or rather this is a coll. gen. n.,]</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">آصَالٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OaSalapN_B2">
					<p><span class="add">[Hence, app.,]</span> † <em>Short and broad:</em> applied to a man and to a woman. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSolieBN">
				<h3 class="entry"><span class="ar">أَصْلِىٌّ</span></h3>
				<div class="sense" id="OaSolieBN_A1">
					<p><span class="ar">أَصْلِىٌّ</span> <span class="add">[<em>Radical; fundamental; primitive; original; underived:</em> an epithet of extensive application; and particularly applied to a letter of a word, as opposed to augmentative; and to a signification]</span>. <span class="auth">(The Lexicons, &amp;c. passim.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSoliyBapN">
				<h3 class="entry"><span class="ar">أَصْلِيَّةٌ</span></h3>
				<div class="sense" id="OaSoliyBapN_A1">
					<p><span class="ar">أَصْلِيَّةٌ</span> <span class="add">[The <em>quality denoted by the epithet</em> <span class="ar">أَصْلِىٌّ</span>; <em>radicalness,</em>, &amp;c.:]</span> a term used by IJ <span class="add">[and others]</span> in the place of <span class="ar">تَأَصُّلٌ</span>: <a href="#ASl_5">see 5</a>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSiylN">
				<h3 class="entry"><span class="ar">أَصِيلٌ</span></h3>
				<div class="sense" id="OaSiylN_A1">
					<p><span class="ar">أَصِيلٌ</span> <span class="add">[<em>Having root,</em> or <em>a foundation;</em> and consequently, <em>having rootedness, fixedness, immobility, stability,</em> or <em>permanence; rooted, fixed, immoveable, stable,</em> or <em>permanent</em>]</span>. You say, <span class="ar long">إِنَّ النَّخْلَ فِى أَرْضِنَا لَأَصِيلٌ</span> <em>Verily the palm-trees in our land remain permanently, not perishing.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaSiylN_A2">
					<p>A man <em>having</em> <span class="ar">أَصْل</span>, <span class="auth">(Ḳ, TA,)</span> i. e., <em>lincage,</em> or <em>pedigree:</em> <span class="auth">(TA:)</span> or <em>established in his</em> <span class="ar">أَصْل</span>: <span class="auth">(Abu-l-Baḳà, TA:)</span> or <em>noble,</em> or <em>generous.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaSiylN_A3">
					<p>A man <em>firm of judgment, and intelligent.</em> <span class="auth">(M, Ḳ.* <span class="add">[Accord. to the copies of the latter, the signification is <span class="ar long">عَاقِبٌ ثَابِتُ الرَّأْىِ</span>: but I think that the right reading of the first word is <span class="ar">عَاقِلٌ</span>, as in the M, in which this word occupies the last place in the explanation.]</span>)</span> And <span class="ar long">أَصِيلُ الرَّأْىِ</span> A man <em>firm,</em> or <em>sound, of judgment.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">رَأْىٌ أَصِيلٌ</span> <em>Judgment having</em> <span class="ar">أَصْل</span> <span class="add">[i. e. <em>firmness</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">مَجْدٌ أَصِيلٌ</span> <em>Glory, honour, dignity,</em> or <em>nobility, having a firm root</em> or <em>foundation.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">شَرٌّ أَصِيلٌ</span> <em>Vehement evil</em> or <em>mischief.</em> <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaSiylN_B1">
					<p><a href="#OaSilN">See also <span class="ar">أَصِلٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OaSiylN_B2">
					<p><span class="add">[Hence, app.,]</span> <span class="ar">الأَصِيلُ</span> <em>Destruction:</em> and <em>death:</em> as also, in both senses, <span class="arrow"><span class="ar">الأَصِيلَةُ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OaSiylN_C1">
					<p><span class="add">[The <em>evening;</em> or]</span> i. q. <span class="ar">عَشِىٌّ</span>; <span class="auth">(M, Ḳ, Mṣb, TA;)</span> i. e. <span class="auth">(Mṣb, TA)</span> the <em>time from the</em> <span class="ar">عَصْر</span>, <span class="auth">(Ṣ, TA,)</span> <em>from the prayer of the</em> <span class="ar">عصر</span>, <span class="auth">(Mṣb,)</span> <em>to sunset;</em> <span class="auth">(Ṣ, Mṣb, TA;)</span> as also<span class="arrow"><span class="ar">أَصِيلَةٌ↓</span></span>: <span class="auth">(R, TA:)</span> the pl. is <span class="ar">أُصُلٌ</span>, <span class="auth">(Ṣ, M, R, Mṣb, Ḳ,)</span> or<span class="arrow">↓</span> this is a sing., <span class="auth">(TA,)</span> or it may be a sing., <span class="auth">(M,)</span> for it is used as such, <span class="auth">(M, TA,)</span> and <span class="ar">أُصْلَانٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">آصَالٌ</span>, <span class="auth">(Ṣ, M, Ṣgh, Ḳ,)</span> <span class="add">[a pl. of pauc.,]</span> or, accord. to Es-Saláh Es-Safadee, this <a href="#OuSulN">is a pl. of <span class="ar">أُصُلٌ</span></a>, the sing., not the pl., <span class="auth">(TA,)</span> or it <a href="#OuSulN">is pl. of <span class="ar">أُصُلٌ</span></a>, <span class="auth">(Zj, M,)</span> which may be a pl. or a sing., <span class="auth">(M,)</span> and <span class="ar">أَصَائِلُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> as though <a href="#OaSiylapN">pl. of <span class="ar">أَصِيلَةٌ</span></a>, <span class="auth">(Ṣ,)</span> or it is pl. of this last word. <span class="auth">(R, TA.)</span> You say, <span class="ar long">لَقِيتُهُ أَصِيلًا</span> and<span class="arrow"><span class="ar">أُصُلًا↓</span></span>, i. e. <span class="add">[<em>I met him in the evening,</em>]</span> <span class="ar">عَشِيًّا</span>. <span class="auth">(A, TA.)</span> From the pl. <span class="ar">أُصْلَانُ</span> is formed the dim. <span class="arrow"><span class="ar">أُصَيْلَانٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> which is extr., <span class="auth">(M, Ḳ,)</span> because the dim. of a pl. is <span class="add">[regularly]</span> formed only from a pl. of pauc., which <span class="ar">اصلان</span> is not; or, if <span class="ar">اصلان</span> be a sing., like <span class="ar">رُمَّانٌ</span> and <span class="ar">قُرْبَانٌ</span>, this dim. is regular: <span class="auth">(M:)</span> <span class="pb" id="Page_0066"></span>sometimes, <span class="auth">(Ḳ,)</span> one says also <span class="arrow"><span class="ar">أُصَيْلَالٌ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> substituting <span class="ar">ل</span> for the <span class="add">[final]</span> <span class="ar">ن</span> <span class="auth">(Ṣ, M.*)</span> You say,<span class="arrow"><span class="ar long">لَقِيتُهُ أُصَيْلَانًا↓</span></span> and<span class="arrow"><span class="ar">أُصَيْلَالًا↓</span></span>, meaning, as above, <span class="ar">عَشِيًّا</span>: <span class="auth">(A, TA:)</span> and Lḥ mentions <span class="arrow"><span class="ar long">لَقِيتُهُ أُصَيَّالًا↓</span></span>. <span class="auth">(So in two copies of the Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaSiylapN">
				<h3 class="entry"><span class="ar">أَصِيلَةٌ</span></h3>
				<div class="sense" id="OaSiylapN_A1">
					<p><span class="ar">أَصِيلَةٌ</span> A man's <em>whole property:</em> <span class="auth">(M, Ḳ:)</span> or his <em>palm-trees:</em> <span class="auth">(Ḳ, TA: in the CK his <em>palmtree:</em>)</span> thus in the dial. of El-Ḥijáz. <span class="auth">(O, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaSiylapN_A2">
					<p><span class="ar long">أَخَذَهُ بِأَصِيلَتِهِ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">بِأَصَلَتِهِ↓</span></span>, <span class="auth">(IAạr, M, Ḳ,)</span> <em>He took it altogether,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <span class="add">[as it were]</span> <em>with its root,</em> <span class="auth">(Ṣ, M,)</span> <em>not leaving aught of it.</em> <span class="auth">(TA.)</span> And <span class="ar long">جَاؤُوا بِأَصِيلَتِهِمْ</span> <em>They came altogether; the whole of them.</em> <span class="auth">(Ṣ, Z.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaSiylapN_B1">
					<p><span class="ar long">لِفُلَانٍ أَرْضٌ أَصِيلَةٌ</span> <em>To such a one belongs land long possessed, or inherited from his parents, by means of which he has his living:</em> a phrase of the people of Et-Táïf. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصل</span> - Entry: <span class="ar">أَصِيلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OaSiylapN_C1">
					<p><a href="#OaSiylN">See also <span class="ar">أَصِيلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuSuwlieBN">
				<h3 class="entry"><span class="ar">أُصُولِىٌّ</span></h3>
				<div class="sense" id="OuSuwlieBN_A1">
					<p><span class="ar">أُصُولِىٌّ</span> One <em>skilled in the science termed</em> <span class="ar long">عِلْمٌ الأُصُولِ</span>: <a href="#OaSolN">see <span class="ar">أَصْلٌ</span></a>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuSayBaAlN">
				<h3 class="entry"><span class="ar">أُصَيَّالٌ</span> / <span class="ar">أُصَيَّالًا</span></h3>
				<div class="sense" id="OuSayBaAlN_A1">
					<p><span class="ar long">لَقِيتُهُ أُصَيَّالًا</span>: <a href="#OaSiylN">see <span class="ar">أَصِيلٌ</span></a>, last sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuSayolaAnN">
				<h3 class="entry"><span class="ar">أُصَيْلَانٌ</span> / <span class="ar">أُصَيْلَالٌ</span></h3>
				<div class="sense" id="OuSayolaAnN_A1">
					<p><span class="ar">أُصَيْلَانٌ</span> and <span class="ar">أُصَيْلَالٌ</span>: <a href="#OaSiylN">see <span class="ar">أَصِيلٌ</span></a>, in four places, last two sentences.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWoSilFA">
				<h3 class="entry"><span class="ar">مُؤْصِلًا</span></h3>
				<div class="sense" id="muWoSilFA_A1">
					<p><span class="ar long">لَقِيتُهُ مُؤْصِلًا</span> <em>I met him entering upon the time called the</em> <span class="ar">أَصِيل</span>. <span class="auth">(TA.)</span> And <span class="ar long">أَتَيْنَا مُؤْصِلِينَ</span> <em>We came entering upon the time so called.</em> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaSBalN">
				<h3 class="entry"><span class="ar">مُؤَصَّلٌ</span></h3>
				<div class="sense" id="muWaSBalN_A1">
					<p><span class="ar long">أَصْلٌ مُؤَصَّلٌ</span> <span class="add">[<em> A root,</em> or <em>foundation,</em> or <em>the like, made firm,</em> or <em>fixed,</em> or <em>established</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#OaSiylN">See also <span class="ar">أَصِيلٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaOoSalapN">
				<h3 class="entry"><span class="ar">مُسْتَأْصَلَةٌ</span></h3>
				<div class="sense" id="musotaOoSalapN_A1">
					<p><span class="ar long">شَاةٌ مُسْتَأْصَلَةٌ</span> <em>A sheep,</em> or <em>goat, whose horn has been taken from its root.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="musotaOoSilN">
				<h3 class="entry"><span class="ar">مُسْتَأْصِلٌ</span></h3>
				<div class="sense" id="musotaOoSilN_A1">
					<p><span class="ar">مُسْتَأْصِلٌ</span>: <a href="#OaSilN">see <span class="ar">أَصِلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="yaOoSuwlN">
				<h3 class="entry"><span class="ar">يَأْصُولٌ</span></h3>
				<div class="sense" id="yaOoSuwlN_A1">
					<p><span class="ar">يَأْصُولٌ</span>: <a href="#OaSolN">see <span class="ar">أَصْلٌ</span></a>, first sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0064.pdf" target="pdf">
							<span>Lanes Lexicon Page 64</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0065.pdf" target="pdf">
							<span>Lanes Lexicon Page 65</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0066.pdf" target="pdf">
							<span>Lanes Lexicon Page 66</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
