<article class="root" id="Root_Azm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/069_Azl">ازل</a></span>
				<span class="ar">ازم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/071_Aze">ازى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزم</span></h3>
				<div class="sense" id="Azm_1_A1">
					<p><span class="ar">أَزَمَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِمُ</span>}</span></add>, inf. n. <span class="ar">أَزْمٌ</span> and <span class="ar">أُزُومٌ</span>, <em>He bit with the whole mouth, vehemently:</em> <span class="auth">(Ḳ:)</span> or <em>with the canine teeth:</em> or you say, <span class="ar">أَزَمَهُ</span>, and <span class="ar long">أَزَمَ عَلَيْهِ</span>, meaning <em>he bit it, and then repeated</em> <span class="add">[<em>the action</em>]</span> <em>upon it, not letting it go:</em> or <em>he seized upon it with his mouth:</em> <span class="auth">(TA:)</span> or <span class="ar">أَزَمَهُ</span> signifies <span class="add">[simply]</span> <em>he bit it:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">أَزَمَ عَلَيْهِ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِمُ</span>}</span></add>, inf. n. <span class="ar">أَزْمٌ</span>; and <span class="ar">أَزِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْزَمُ</span>}</span></add>, inf. n. <span class="ar">أَزَمٌ</span>; <em>the same;</em> or <em>he seized,</em> or <em>took hold, upon it with his teeth:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">أَزَمْتُ يَدَ الرَّجُلِ</span> <em>I bit the arm,</em> or <em>hand, of the man most vehemently.</em> <span class="auth">(TA.)</span> <span class="ar long">أَزَمَ بِهَا</span> occurs in a trad. as meaning <em>He bit it,</em> <span class="auth">(referring to a ring of a coat of mail,)</span> <em>and held it between two of his central teeth.</em> <span class="auth">(AO.)</span> And in another trad., <span class="ar long">أَزَمَ فِى يَدِهِ</span>, meaning <em>He bit his arm,</em> or <em>hand.</em> <span class="auth">(TA.)</span> And you say, <span class="ar long">أَزَمَ الفَرَسُ عَلَى فَأْسِ اللِّجَامِ</span> <em>The horse seized</em> <span class="add">[<em>with his teeth,</em> or <em>champed,</em>]</span> <em>upon the</em> <span class="ar">فأس</span> <span class="add">[q. v.]</span> <em>of the bit.</em> <span class="auth">(Ḳ.)</span> And <span class="ar">أَزْمٌ</span> signifies also The <em>cutting with the canine tooth,</em> and <em>with a knife,</em> <span class="auth">(Ḳ,)</span> and <em>with other things.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Azm_1_A2">
					<p><span class="add">[And hence,]</span> <span class="ar long">أَزَمَ عَلَيْنَا</span>, <span class="auth">(Ṣ, Mṣb,* Ḳ,*)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِمُ</span>}</span></add>, inf. n. <span class="ar">أَزْمٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">أُزُومٌ</span>, <span class="auth">(TA,)</span> said of a time, <span class="auth">(Ṣ, Mṣb,)</span> or a year, <span class="auth">(Ḳ,)</span> <em>It was,</em> or <em>became, distressful,</em> or <em>afflictive, to us,</em> <span class="add">[<em>as though it bit us,</em>]</span> <em>by drought, dearth,</em> or <em>scarcity;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>and scant in its good things;</em> <span class="auth">(Ṣ;)</span> as also <span class="ar">أَزِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْزَمُ</span>}</span></add>, inf. n. <span class="ar">أَزَمٌ</span>. <span class="auth">(Mṣb.)</span> And <span class="ar long">أَصَابَتْهُمْ سَنَةٌ أَزَمَتْهُمْ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> inf. n. <span class="ar">أَزْمٌ</span>, <span class="auth">(Ṣ,)</span> <em>A year,</em> or <em>year of dearth</em> or <em>drought</em> or <em>sterility, befell them, which extirpated them:</em> <span class="auth">(Ṣ, Ḳ:*)</span> or, accord. to Sh, the verb in this sense is only with <span class="ar">و</span>. <span class="auth">(TA. <span class="add">[<a href="index.php?data=01_A/061_Arm">See art. <span class="ar">ارم</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Azm_1_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar long">أَزَمَ بِهِ</span>, <span class="auth">(AZ, Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَزْمٌ</span>, <span class="auth">(TA,)</span> <em>He clave to him,</em> namely, his companion; <span class="auth">(AZ, Ṣ, Ḳ;)</span> and <em>to it,</em> namely, a place. <span class="auth">(Ḳ.)</span> And <span class="ar long">أَزَمَ عَلَيْهِ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِمُ</span>}</span></add>, inf. n. <span class="ar">أَزْمٌ</span>, <span class="auth">(TA,)</span> <em>He kept, attended,</em> or <em>applied himself, constantly, perseveringly,</em> or <em>assiduously, to it;</em> <span class="auth">(Ḳ;)</span> <em>he clave to it.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَزَمَ بِضَيْعَتِهِ</span>, or <span class="ar">لَهَا</span>, <span class="auth">(accord. to different copies of the Ḳ, the former being the reading in the TA,)</span> and <span class="ar">عَلَيْها</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">أُزُومٌ</span>, <span class="auth">(AZ, TA,)</span> <em>He kept, attended,</em> or <em>applied himself, constantly, perseveringly,</em> or <em>assiduously, to his</em> <span class="ar">ضيعة</span> <span class="add">[or <em>land,</em>, &amp;c.]</span>. <span class="auth">(AZ, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Azm_1_A4">
					<p><span class="ar">أَزَمَ</span>, <span class="auth">(Nh, Ḳ,)</span> inf. n. <span class="ar">أَزْمٌ</span>, <span class="auth">(Nh, TA,)</span> also signifies <em>He held his teeth together, one upon another:</em> <span class="auth">(Nh:)</span> <span class="add">[and <em>he compressed,</em> or <em>put together, his lips:</em> (<a href="#AzimN">see <span class="ar">آزِمٌ</span></a>:)]</span> and <em>he closed,</em> or <em>locked,</em> a door. <span class="auth">(Ḳ, TA.)</span> It is said in a trad., <span class="ar long">السِّوَاكُ تَسْتَعْمِلُهُ عِنْدَ تَغَيُّرِ الفَمِ مِنَ الأَزْمِ</span> <em>The stick for cleaning the teeth, thou shalt use it on the occasion of the mouth's becoming altered in odour from the holding of the teeth together.</em> <span class="auth">(Nh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Azm_1_A5">
					<p><span class="add">[And hence,]</span> <span class="ar">أَزَمَ</span>, <span class="auth">(Ṣ, Nh, Mṣb,)</span> inf. n. <span class="ar">أَزْمٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <em>He held, refrained,</em> or <em>abstained,</em> <span class="auth">(Ṣ, Ḳ,*)</span> <span class="ar long">عَنِ الشَّىْءِ</span> <em>from the thing:</em> <span class="auth">(Ṣ, TA:)</span> and <em>he held, refrained,</em> or <em>abstained, from desiring much:</em> <span class="auth">(TA:)</span> and <em>from food</em> <span class="auth">(Mṣb, Ḳ *)</span> <em>and drink;</em> <span class="auth">(Mṣb;)</span> as also <span class="ar">أَزِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْزَمُ</span>}</span></add>, inf. n. <span class="ar">أَزَمٌ</span>: <span class="auth">(Mṣb:)</span> and <em>from speech;</em> <span class="auth">(Nh, Ḳ;*)</span> <em>like as does the faster from food:</em> and hence, <span class="auth">(Nh,)</span> or from the next preceding signification, <span class="auth">(Mṣb,)</span> <span class="ar">حِمْيَةٌ</span> <span class="add">[meaning as explained in what follows]</span> is termed <span class="ar">أَزْمٌ</span>: <span class="auth">(Nh, Mṣb:)</span> but accord. to the relation commonly known, of a trad. in which <span class="ar">أَزَمَ</span> is said to occur in the last of the senses explained above, the word is <span class="ar">أَرَمَّ</span>, with <span class="ar">ر</span> and with teshdeed in the case of the <span class="ar">م</span>. <span class="auth">(Nh.)</span> It is related in a trad., that ʼOmar having asked El-Hárith Ibn-Keledeh, the <span class="ar">طَبِيب</span> of the Arabs, “What is the <span class="add">[best]</span> remedy?” <span class="auth">(Ṣ,)</span> or having asked him respecting <span class="add">[the best]</span> medical, or curative, treatment, <span class="auth">(Mṣb,)</span> the latter said, <span class="ar">الأَزْمُ</span>, meaning <span class="ar">الحِمْيَةُ</span>; <span class="auth">(Ṣ, Mṣb;)</span> both these words here meaning <em>The practising abstinence;</em> <span class="auth">(PṢ;)</span> or <em>the abstaining,</em> or <em>desisting, from eating:</em> <span class="auth">(TA:)</span> or, in this instance, <span class="auth">(TA,)</span> <span class="ar">الأَزْمُ</span> signifies <em>the not putting in food upon food:</em> and <span class="auth">(some say, TA)</span> <em>the being silent:</em> <span class="auth">(Ḳ, TA:)</span> and it signifies also <em>strength.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Azm_1_A6">
					<p><span class="ar long">أَزَمَ الشَّىْءُ</span> <em>The thing became contracted; became drawn together,</em> or <em>compressed;</em> as also <span class="ar">أَزِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْزَمُ</span>}</span></add>. <span class="auth">(Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azm_5">
				<span class="pb" id="Page_0055"></span>
				<h3 class="entry">5. ⇒ <span class="ar">تأزّم</span></h3>
				<div class="sense" id="Azm_5_A1">
					<p><span class="ar long">تأزّم القَوْمُ</span>, <span class="auth">(TA,)</span> or <span class="ar long">تأزّم القَوْمُ دَارَهُمْ</span>, <span class="auth">(Ṣ,)</span> <em>The people,</em> or <em>company of men, stayed, remained,</em> or <em>dwelt, long in their abode.</em> <span class="auth">(Ṣ, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OazomN">
				<h3 class="entry"><span class="ar">أَزْمٌ</span></h3>
				<div class="sense" id="OazomN_A1">
					<p><span class="ar">أَزْمٌ</span>: <a href="#OazomapN">see <span class="ar">أَزْمَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazimN">
				<h3 class="entry"><span class="ar">أَزِمٌ</span> / <span class="ar">أَزِمَةٌ</span></h3>
				<div class="sense" id="OazimN_A1">
					<p><span class="ar">أَزِمٌ</span> <span class="add">[<a href="#Azm_1">part. n. of <span class="ar">أَزِمَ</span></a>; fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَزِمَةٌ</span>}</span></add>]</span>: <a href="#OazomapN">see <span class="ar">أَزْمَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazomapN">
				<h3 class="entry"><span class="ar">أَزْمَةٌ</span></h3>
				<div class="sense" id="OazomapN_A1">
					<p><span class="ar">أَزْمَةٌ</span> <span class="add">[<a href="#Azm_1">inf. n. of un. of 1</a>: and hence,]</span> <em>A single act of eating;</em> <span class="auth">(Ḳ, TA;)</span> i. e. <em>an eating but once in the course of the day;</em> like <span class="ar">وَجْبَةٌ</span> <span class="add">[q. v.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">أَزْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OazomapN_A2">
					<p>Also, <span class="auth">(Fr, Ṣ, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">أَزَمَةٌ↓</span></span> and<span class="arrow"><span class="ar">آزِمَةٌ↓</span></span>, <span class="auth">(Fr, Ḳ, <span class="add">[the last in the CK like the first,]</span>)</span> <em>Straitness, hardness,</em> or <em>distress;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>drought, dearth,</em> or <em>sterility:</em> <span class="auth">(Ṣ, Mṣb:)</span> pl. <span class="auth">(of the first, TA)</span> <span class="arrow"><span class="ar">أَزْمٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="add">[or rather this is a coll. gen. n.,]</span> like as <span class="ar">تَمْرٌ</span> is of <span class="ar">تَمْرَةٌ</span>, <span class="auth">(TA,)</span> <span class="add">[<a href="#Azm_1">but originally an inf. n. of <span class="ar">أَزَمَ</span>. q. v.</a>,]</span> and <span class="ar">إِزَمٌ</span>, <span class="auth">(Ḳ,)</span> like as <span class="ar">بِدَرٌ</span> is of <span class="ar">بَدْرَةٌ</span>. <span class="auth">(TA.)</span> Hence the trad., <span class="ar long">اشْتَدِّى أَزْمَةٌ تَنْفَرِجِى</span>, meaning <em>Become severe, O year of drought,</em> or <em>dearth,</em> or <em>sterility:</em> then <em>thou wilt pass away:</em> though it has been strangely asserted that <span class="ar">ازمة</span> is here the proper name of a woman, to whom, on an occasion of her being taken with the pains of labour, these words were said by the Prophet. <span class="auth">(TA.)</span> You also say <span class="ar long">سَنَةٌ أَزْمَةٌ</span> and<span class="arrow"><span class="ar">أَزِمَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> so in the copies of the Ḳ, there said to be like <span class="ar">فَرِحَةٌ</span>, but correctly <span class="arrow"><span class="ar">آزِمَةٌ↓</span></span>, as in the M, &amp;c., <span class="auth">(TA,)</span> <span class="add">[or both are correct, being part. ns., respectively, of <span class="ar">أَزِمَ</span> and <span class="ar">أَزَمَ</span>,]</span> and<span class="arrow"><span class="ar">أَزُومَةٌ↓</span></span>, meaning <em>A distressful,</em> or <em>an afflictive, year;</em> <span class="auth">(Ḳ;)</span> <em>a year of vehement drought</em> or <em>dearth</em> or <em>sterility.</em> <span class="auth">(TA.)</span> And <span class="ar">أَوَازِمُ</span> <span class="add">[pl. of<span class="arrow"><span class="ar">آزِمَةٌ↓</span></span>, used as a subst.,]</span> signifies <em>Distressful,</em> or <em>afflictive, years.</em> <span class="auth">(TA.)</span> <span class="arrow"><span class="ar">أَزَامِ↓</span></span>, also, <span class="auth">(Ḳ,)</span> or, accord. to Aboo-ʼAlee, <span class="arrow"><span class="ar">أَزُومُ↓</span></span>, <span class="auth">(IB,)</span> <span class="add">[each a proper name, as denoting a kind of personification,]</span> signifies <em>The year of drought</em> or <em>dearth</em> or <em>sterility.</em> <span class="auth">(Ḳ.)</span> And you say,<span class="arrow"><span class="ar long">نَزَلَتْ بِهِمْ أَزَام↓</span></span> and<span class="arrow"><span class="ar">أَزُومُ↓</span></span> <em>Severe straitness,</em> or <em>distress, befell them.</em> <span class="auth">(Ṣ, TA.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OazamapN">
				<h3 class="entry"><span class="ar">أَزَمَةٌ</span></h3>
				<div class="sense" id="OazamapN_A1">
					<p><span class="ar">أَزَمَةٌ</span>: <a href="#OazomapN">see <span class="ar">أَزْمَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OazimapN">
				<h3 class="entry"><span class="ar">أَزِمَةٌ</span></h3>
				<div class="sense" id="OazimapN_A1">
					<p><span class="ar">أَزِمَةٌ</span>: <a href="#OazomapN">see <span class="ar">أَزْمَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OazaAmi">
				<h3 class="entry"><span class="ar">أَزَامِ</span></h3>
				<div class="sense" id="OazaAmi_A1">
					<p><span class="ar">أَزَامِ</span>: <a href="#OazomapN">see <span class="ar">أَزْمَةٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuzaAmN">
				<h3 class="entry"><span class="ar">أُزَامٌ</span></h3>
				<div class="sense" id="OuzaAmN_A1">
					<p><span class="ar">أُزَامٌ</span>: <a href="#OazuwmN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazuwmN">
				<h3 class="entry"><span class="ar">أَزُومٌ</span></h3>
				<div class="sense" id="OazuwmN_A1">
					<p><span class="ar">أَزُومٌ</span>: <a href="#AzNm">see <span class="ar">آزٌم</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">أَزُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OazuwmN_A2">
					<p><span class="ar">أَزُومُ</span>: <a href="#OazomapN">see <span class="ar">أَزْمَةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">أَزُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OazuwmN_A3">
					<p>Also, the former, <em>Cleaving</em> to a thing; <span class="auth">(Ḳ;)</span> and so<span class="arrow"><span class="ar">أُزَامٌ↓</span></span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OazuwmapN">
				<h3 class="entry"><span class="ar">أَزُومَةٌ</span></h3>
				<div class="sense" id="OazuwmapN_A1">
					<p><span class="ar">أَزُومَةٌ</span>: <a href="#OazomahN">see <span class="ar">أَزْمَهٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MzimN">
				<h3 class="entry"><span class="ar">آزِمٌ</span></h3>
				<div class="sense" id="MzimN_A1">
					<p><span class="ar">آزِمٌ</span> act. part. n. of <span class="ar">أَزَمَ</span> <em>Biting with the whole mouth, vehemently:</em> <span class="add">[&amp;c.:]</span> as also<span class="arrow"><span class="ar">أَزُومٌ↓</span></span>: <span class="auth">(Ḳ: <span class="add">[in the CK the former is erroneously written <span class="ar">اَزْمٌ</span>:]</span>)</span> or the latter signifies <em>that has a habit of biting;</em> or <em>that bites much;</em> syn. <span class="ar">عَضُوضٌ</span>: <span class="auth">(Ḥam p. 532:)</span> pl. of the former <span class="ar">أُزُومٌ</span>: <span class="auth">(Ḥam p. 360:)</span> and of the latter <span class="ar">أُزُمٌ</span>. <span class="auth">(Ḥam p. 609.)</span> <span class="add">[Hence,]</span><span class="arrow"><span class="ar">الأَزُومُ↓</span></span> <em>The biting lion;</em> or <em>the lion that bites much,</em> or <em>vehemently;</em> <span class="ar long">الأَسَدُ العَضُوضُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">آزِمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MzimN_A2">
					<p><span class="add">[Hence also,]</span> The <em>canine tooth;</em> syn. <span class="ar">نَابٌ</span>; and so<span class="arrow"><span class="ar">آزِمَةٌ↓</span></span>; and<span class="arrow"><span class="ar">أَزُومٌ↓</span></span>: pl. of the first <span class="ar">أُزَّمٌ</span>; and of the second <span class="ar">آوازِم</span>; and of the third <span class="ar">أُزُمٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">آزِمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MzimN_A3">
					<p>Also <em>Having his lips compressed,</em> or <em>put together.</em> <span class="auth">(AZ, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MzimapN">
				<h3 class="entry"><span class="ar">آزِمَةٌ</span></h3>
				<div class="sense" id="MzimapN_A1">
					<p><span class="ar">آزِمَةٌ</span>: <a href="#AzimN">see <span class="ar">آزِمٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">آزِمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MzimapN_A2">
					<p><a href="#OazomapN">and see also <span class="ar">أَزْمَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOozimN">
				<h3 class="entry"><span class="ar">مَأْزِمٌ</span></h3>
				<div class="sense" id="maOozimN_A1">
					<p><span class="ar">مَأْزِمٌ</span> <em>A narrow,</em> or <em>strait, place; a place of narrowness</em> or <em>straitness;</em> <span class="auth">(Ṣ, Ḳ;)</span> like <span class="ar">مَأْزِلٌ</span>; <span class="auth">(Ṣ;)</span> of a land, and of the pudendum muliebre, and of life, <span class="auth">(Ḳ,)</span> or of the means of subsistence; <span class="auth">(Lḥ, Ḳ;)</span> or <em>of any kind:</em> <span class="auth">(TA:)</span> <em>any narrow road between two mountains:</em> <span class="auth">(Ṣ, Mṣb:)</span> <em>a narrow place in mountains, such that one part meets another, and the place beyond widens:</em> <span class="auth">(TA:)</span> pl. <span class="ar">مَآزِمُ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازم</span> - Entry: <span class="ar">مَأْزِمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOozimN_A2">
					<p>And hence, <span class="auth">(Mṣb,)</span> <em>A place of war</em> or <em>fight;</em> <span class="auth">(Ṣ, Mṣb;)</span> because of the straitness of the state thereof, and the difficulty of escape from it. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOazBimN">
				<h3 class="entry"><span class="ar">مُتَأَزِّمٌ</span></h3>
				<div class="sense" id="mutaOazBimN_A1">
					<p><span class="ar">مُتَأَزِّمٌ</span> <em>Smitten,</em> or <em>afflicted, by</em> <span class="ar">أُزْمَة</span> <span class="add">[or <em>straitness,</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> or <em>expressing pain</em> or <em>grief,</em> or <em>lamenting,</em> or <em>complaining, on account of the straitness,</em> or <em>distressfulness,</em> or <em>afflictiveness,</em> (<span class="ar">أَزْمَة</span> and <span class="ar">شِدَّة</span>,) <em>of time,</em> or <em>fortune.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0054.pdf" target="pdf">
							<span>Lanes Lexicon Page 54</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0055.pdf" target="pdf">
							<span>Lanes Lexicon Page 55</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
