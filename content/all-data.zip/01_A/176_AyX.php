<article class="root" id="Root_AyX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/175_Ays">ايس</a></span>
				<span class="ar">ايش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/177_AyD">ايض</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="OayoXa">
				<h3 class="entry"><span class="ar">أَيْشَ</span></h3>
				<div class="sense" id="OayoXa_A1">
					<p><span class="ar">أَيْشَ</span>, for <span class="ar long">أَىُّ شَىْءٍ</span>: <a href="#OaeBN">see <span class="ar">أَىٌّ</span></a>, <a href="index.php?data=01_A/170_Ae">in art. <span class="ar">اى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
