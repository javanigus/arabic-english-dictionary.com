<article class="root" id="Root_AT">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/097_ASl">اصل</a></span>
				<span class="ar">اط</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/099_ATr">اطر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AT_1">
				<h3 class="entry">1. ⇒ <span class="ar">أطّ</span></h3>
				<div class="sense" id="AT_1_A1">
					<p><span class="ar">أَطَّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْطِطُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَطِيطٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أَطٌّ</span>, <span class="auth">(TA,)</span> <em>It produced, made, gave, emitted,</em> or <em>uttered, a sound, noise, voice,</em> or <em>cry;</em> <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[and particularly, <em>it creaked;</em> and <em>it moaned;</em>]</span> said of a camel's saddle, <span class="auth">(Ṣ,* Ḳ, <span class="add">[in the CK, <span class="ar">الرَّجُلُ</span> is put by mistake for <span class="ar">الرَّحْلُ</span>]</span>)</span> <span class="add">[and particularly of a new camel's saddle,]</span> and the like, <span class="auth">(Ḳ,)</span> such as a <span class="add">[plaited or woven girth called]</span> <span class="ar">نِسْع</span> and of everything of which the sound resembles that of a new camel's saddle, <span class="auth">(TA,)</span> and of a palm-trunk, and of a tree of the kind called <span class="ar">سِدْر</span>, <span class="auth">(Ṣ TA,)</span> or of the kind called <span class="ar">سَرْح</span>, <span class="auth">(TA,)</span> and of a cane or reed on the occasion of its being straightened, <span class="add">[in which instance it is said to be tropical, but if so it is tropical in several other instances,]</span> and of a bow, <span class="auth">(TA,)</span> and of the belly by reason of emptiness, <span class="auth">(Ṣ,* TA,)</span> and, in a trad. of Aboo-Dharr, ‡ of heaven, or the sky, notwithstanding there being <span class="add">[really]</span> no <span class="ar">أَطِيط</span> in this instance, for it is meant to denote <span class="add">[the presence of]</span> multitude, and confirmation of the majesty of God. <span class="auth">(TA.)</span> <span class="add">[It is also said of other things, as will be shown by phrases here following, and by explanations of <span class="ar">أَطِيطٌ</span> below.]</span> You also say, <span class="ar long">أَطَّتِ الإِبِلُ</span>, <span class="auth">(Ḳ,)</span> aor. as above, inf. n. <span class="ar">أَطِيطٌ</span>, <span class="auth">(TA,)</span> <em>The camels moaned by reason of fatigue,</em> or <em>uttering their yearning cry to their young,</em> <span class="auth">(Ḳ, TA,)</span> and sometimes <em>by reason of fulness of their udders with milk.</em> <span class="auth">(TA.)</span> And <span class="ar long">لَا آتِيكَ مَا أَطَّتِ الإِبِلُ</span> <em>I will not come to thee as long as camels utter cries</em> <span class="add">[or <em>moan</em>]</span> <em>by reason of the heaviness of their loads.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">لَا أَفْعَلُ ذٰلِكَ مَا أَطَّتِ الإِبِلُ</span>, meaning <em>I will not do that ever.</em> <span class="auth">(TA.)</span> And <span class="ar long">مَا لَنَا بَعِيرٌ يَئِطُّ</span> <em>We have not a camel that moans,</em> or <em>cries;</em> meaning <em>we have not any camel;</em> for the camel cannot but do so. <span class="auth">(TA, from a trad.)</span> <span class="add">[<a href="#OaTiyTN">See also <span class="ar">أَطِيطٌ</span>, below</a>.]</span> And <span class="ar long">أَطَّتْ لَهُ رَحِمِى</span> ‡ <span class="add">[<em>My feeling of relationship,</em> or <em>sympathy of blood,</em>]</span> <em>became affected with tenderness,</em> or <em>compassion,</em> and <em>became moved,</em> <span class="add">[or rather <em>pleaded,</em>]</span> <em>for him</em> <span class="add">[or <em>in his favour</em>]</span>: <span class="auth">(Ḳ, TA:)</span> and hence<span class="arrow"><span class="ar">التَّأَطُّطُ↓</span></span> <span class="add">[inf. n. of the verb in the syn. phrase <span class="ar long">تَأَطَّطَتْ لَهُ رَحِمِى</span>]</span>. <span class="auth">(Ṣgh, TA.)</span> And <span class="ar long">أَطَّتْ بِكَ الرَّحِمُ</span> <span class="add">[<em>The feeling of relationship,</em> or <em>sympathy of blood, pleaded,</em> or <em>hath pleaded, in thee;</em>]</span> i. e., <em>inclined thee to favour.</em> <span class="auth">(Ḥam p. 765.)</span> <span class="add">[See another ex. voce <span class="ar">حَاسَّةٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AT_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأطّط</span></h3>
				<div class="sense" id="AT_5_A1">
					<p><a href="#AT_1">see 1</a>, near the end.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaTBN">
				<h3 class="entry"><span class="ar">أَطٌّ</span></h3>
				<div class="sense" id="OaTBN_A1">
					<p><span class="ar">أَطٌّ</span>: <a href="#OaTiyTN">see <span class="ar">أَطِيطٌ</span>, below</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuTBaTN">
				<h3 class="entry"><span class="ar">أُطَّطٌ</span></h3>
				<div class="sense" id="OuTBaTN_A1">
					<p><span class="ar long">نُسُوعٌ أُطَّطٌ</span> <span class="add">[<a href="#ATBN">pl. of <span class="ar">آطٌّ</span></a>, part. n. of 1,]</span> <em>Creaking</em> <span class="add">[<em>plaited,</em> or <em>woven, thongs</em>]</span>. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaTiyTN">
				<h3 class="entry"><span class="ar">أَطِيطٌ</span></h3>
				<div class="sense" id="OaTiyTN_A1">
					<p><span class="ar">أَطِيطٌ</span> <span class="add">[as explained in what here follows seems to be properly an inf. n., though, like all inf. ns., it may be used as a subst.:]</span> The <em>sounding,</em> or <em>the like,</em> or the <em>sound,</em> or <em>the like,</em> <span class="add">[and particularly the <em>creaking,</em> or <em>creaking sound,</em> and the <em>moaning,</em> or <em>moaning sound,</em>]</span> of a camel's saddle <span class="auth">(Ṣ, Ḳ, TA)</span> when new; <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">أَطٌّ↓</span></span> of the litters and saddles of camels when the riders are heavy thereon; and the former, also, of a door; said, in a trad., of the gate of paradise, by reason of its being crowded; <span class="auth">(TA;)</span> and of a plaited or woven thong when stretching; <span class="auth">(Ez-Zejjájee, TA;)</span> and of the back <span class="add">[when strained]</span>; <span class="auth">(Ḳ;)</span> and of the bowels, <span class="auth">(TA,)</span> and of the belly, or inside, by reason of hunger, <span class="auth">(Ḳ,)</span> or by reason of vehement hunger; <span class="auth">(TA;)</span> and of camels, <span class="auth">(Ṣ, Ḳ,)</span> by reason of their burdens, <span class="auth">(Ḳ,)</span> or by reason of the heaviness of their burdens; <span class="auth">(Ṣ;)</span> and the <em>prolonging of the cries</em> of camels: <span class="auth">(TA:)</span> but ʼAlee Ibn-Hamzeh says that the cry of camels is termed <span class="ar">رُغَآءٌ</span>, and that <span class="ar">أَطِيطٌ</span> signifies the <em>sounding,</em> or <em>sound,</em> of their bellies, or insides, <em>by reason of repletion from drinking.</em> <span class="auth">(IB, TA.)</span> <span class="ar long">أَهْلٌ صَهِيلٍ ؤَأَطِيطٍ</span>, occurring in a trad., means † <em>Possessors of horses and of camels.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اط</span> - Entry: <span class="ar">أَطِيطٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaTiyTN_A2">
					<p>Also † <em>Hunger,</em> <span class="auth">(Ḳ, TA,)</span> itself, as well as the sound of the bowels or belly by reason thereof: from Ez-Zejjájee. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaTBaATN">
				<h3 class="entry"><span class="ar">أَطَّاطٌ</span> / <span class="ar">أَطَّاطَةٌ</span></h3>
				<div class="sense" id="OaTBaATN_A1">
					<p><span class="ar">أَطَّاطٌ</span> <em>Sounding much; noisy;</em> <span class="auth">(Ḳ, TA;)</span> <em>having a sound:</em> applied <span class="add">[to any of the things mentioned above in the explanations of <span class="ar">أَطَّ</span> and <span class="ar">أَطِيطٌ</span>; and]</span> to a hide; and to a camel repleted with drink; and to a road: fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَطَّاطَةٌ</span>}</span></add>: which, applied to a woman, signifies one <em>whose</em> <span class="ar">فَرْج</span> <em>has a sound</em> <span class="ar long">إِذَا جُومِعَتْ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0066.pdf" target="pdf">
							<span>Lanes Lexicon Page 66</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
