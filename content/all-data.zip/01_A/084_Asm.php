<article class="root" id="Root_Asm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/083_Asl">اسل</a></span>
				<span class="ar">اسم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/085_Asn">اسن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسم</span></h3>
				<div class="sense" id="Asm_1_A1">
					<p><span class="ar">أَسَمَهُ</span> <a href="#wsm_1">a dial. var. of <span class="ar">وَسَمَهُ</span>, q. v.</a> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AisomN">
				<h3 class="entry"><span class="ar">اِسْمٌ</span></h3>
				<div class="sense" id="AisomN_A1">
					<p><span class="ar">اِسْمٌ</span>: <a href="index.php?data=12_s/208_smw">see art. <span class="ar">سمو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusaAmapu">
				<h3 class="entry"><span class="ar">أُسَامَةُ</span></h3>
				<div class="sense" id="OusaAmapu_A1">
					<p><span class="ar">أُسَامَةُ</span>, determinate, <span class="auth">(Ṣ, M, Ḳ,)</span> and imperfectly decl., <span class="auth">(M, Mṣb,)</span> as a proper name, <span class="auth">(Mṣb, Ḳ,)</span> <span class="pb" id="Page_0060"></span><em>The lion;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> as also <span class="ar">الأُسَامَةُ</span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0059.pdf" target="pdf">
							<span>Lanes Lexicon Page 59</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0060.pdf" target="pdf">
							<span>Lanes Lexicon Page 60</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
