<article class="root" id="Root_Ale">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/126_Alw">الو</a></span>
				<span class="ar">الى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/128_Am">ام</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ale_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألى</span></h3>
				<div class="sense" id="Ale_1_A1">
					<p><span class="ar">أَلِىَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">يَأْلَى</span>, inf. n. <span class="ar">أَلًى</span>, <span class="auth">(Ṣ,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>was,</em> or <em>became, large in the</em> <span class="ar">أُلْيَة</span>, q. v. <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ale_1_B1">
					<p><span class="ar">أَلَيْتَ</span>: <a href="#Alw_1">see 1</a> <a href="index.php?data=01_A/126_Alw">in art. <span class="ar">الو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaloeN">
				<h3 class="entry"><span class="ar">أَلْىٌ</span></h3>
				<div class="sense" id="OaloeN_A1">
					<p><span class="ar">أَلْىٌ</span>: <a href="#IilFe">see <span class="ar">إِلًى</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْىٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaloeN_B1">
					<p><a href="#OalayaAnN">and see also <span class="ar">أَلَيَانٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalFe">
				<h3 class="entry"><span class="ar">أَلًى</span></h3>
				<div class="sense" id="OalFe_A1">
					<p><span class="ar">أَلًى</span>: <a href="#IilFe">see <span class="ar">إِلًى</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلًى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OalFe_B1">
					<p><a href="#OalayaAnN">and see also <span class="ar">أَلَيَانٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuloeN">
				<h3 class="entry"><span class="ar">أُلْىٌ</span></h3>
				<div class="sense" id="OuloeN_A1">
					<p><span class="ar">أُلْىٌ</span>: <a href="#IilFe">see <span class="ar">إِلًى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oulae">
				<h3 class="entry"><span class="ar">أُلَى</span></h3>
				<div class="sense" id="Oulae_A1">
					<p><span class="ar">أُلَى</span>, <span class="auth">(so in some copies of the Ṣ and in the M,)</span> accord. to Sb, or <span class="ar">أُلَا</span>, <span class="auth">(so likewise in the M, in which it is mentioned in art. <span class="ar">الى</span>, <span class="add">[and thus it is always pronounced,]</span>)</span> or <span class="ar">أُولَى</span>; <span class="auth">(so in several copies of the Ṣ and in the Ḳ, in the last division of each of those works, <span class="add">[and thus it is generally written;]</span>)</span> and with the lengthened <span class="ar">ا</span>, <span class="add">[and this is the more common form of the word, i. e.<span class="arrow"><span class="ar">أُلَآءِ↓</span></span>, as it is always pronounced, or <span class="ar">أُولَآءِ</span>, as it is generally written, both of which modes of writing it I find in the M.,]</span> <span class="auth">(Ṣ, M, Ḳ,)</span> of the same measure as <span class="ar">غُرَاب</span>, <span class="auth">(M,)</span> indecl., with a kesreh for its termination; <span class="auth">(Ṣ;)</span> <span class="add">[<em>These</em> and <em>those,</em>]</span> a pl. having no proper sing., <span class="auth">(Ṣ, Ḳ,)</span> or a noun denoting a pl., <span class="auth">(M,)</span> or its sing. is <span class="ar">ذَا</span> for the masc. and <span class="ar">ذِهْ</span> for the fem., <span class="auth">(Ṣ, Ḳ,)</span> for it is both masc. and fem., <span class="auth">(Ṣ,)</span> and is applied to rational beings and to irrational things. <span class="auth">(M.)</span> <span class="add">[Thus,]</span> <span class="ar long">هُمْ أُولَآءِ عَلَى أَثَرِى</span>, in the Ḳur xx. 86, means <span class="add">[<em>They are these, following near after me;</em> or]</span> <em>they are near me, coming near after me.</em> <span class="auth">(Jel, and Bḍ says the like.)</span> And in the same, iii. 115, <span class="ar long">هَاأَنْتُمْ أُولَآءِ تُحِبُّونَهُمْ وَلَا يُحِبُّونَكُمْ</span> <em>Now ye,</em> O ye <em>these</em> believers, <em>love them, and they love not you.</em> <span class="auth">(Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أُلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oulae_A2">
					<p>The particle <span class="auth">(M)</span> <span class="ar">هَا</span> <span class="auth">(Ṣ, Ḳ)</span> used as an inceptive to give notice of what is about to be said is prefixed to it, <span class="add">[i. e., to the form with the lengthened <span class="ar">ا</span>,]</span> <span class="auth">(Ṣ, M, Ḳ,)</span> so that you say, <span class="arrow"><span class="ar">هؤُلَآءِ↓</span></span> <span class="add">[meaning <em>These,</em> like as <span class="ar">هذَا</span> means “this”]</span>. <span class="auth">(Ṣ, Ḳ.)</span> And AZ says that some of the Arabs say, <span class="ar long">هؤَلَآءِ قَوْمُكَ</span> <span class="add">[<em>These are thy people</em>]</span>, <span class="auth">(Ṣ, M,*)</span> and<span class="arrow"><span class="ar long">رَأَيْتُ هؤُلَآءٍ↓</span></span> <span class="add">[<em>I saw these</em>]</span>, <span class="auth">(M,)</span> with tenween and kesr <span class="auth">(Ṣ, M)</span> to the hemzeh; <span class="auth">(Ṣ;)</span> and this, says IJ, is of the dial. of Benoo-'Okeyl. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أُلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oulae_A3">
					<p>And the <span class="ar">ك</span> of allocution is added to it, so that you say, <span class="ar">أُولئِكَ</span>, <span class="add">[or <span class="ar">آُولَآئِكَ</span>, which is the same, and <span class="ar">أُولئِكُمْ</span>, or <span class="ar">أُولَآئِكُمْ</span>, &amp;c.,]</span> and <span class="ar">أُولَاكَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">أُولَالِكَ</span>, <span class="auth">(so in some copies of the Ṣ and in the Ḳ,)</span> or <span class="ar">أُلَالِكَ</span>, <span class="auth">(so in some copies of the Ṣ and in the M,)</span> in which the <span class="add">[second]</span> <span class="ar">ل</span> is augmentative, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">أُلَّاكَ↓</span></span>, with teshdeed, <span class="auth">(Ḳ,)</span> <span class="add">[all meaning <em>Those,</em> like as <span class="ar">ذَاكَ</span> and <span class="ar">ذلِكَ</span> mean “that” and hence]</span> Ks says that when one says <span class="ar">أُولَآئكَ</span>, the sing. is <span class="ar">ذلِكَ</span>; and when one says <span class="ar">أُولَاكَ</span>, the sing. is <span class="ar">ذَاكَ</span>; <span class="auth">(Ṣ;)</span> or <span class="ar">أُلَالِكَ</span> <span class="add">[or <span class="ar">أُولَالِكَ</span>, each with an augmentative <span class="ar">ل</span>, like <span class="ar">ذلِكَ</span>, <span class="auth">(and this, I doubt not, is the correct statement,)</span>]</span> is as though it were <a href="#clika">pl. of <span class="ar">ذلِكَ</span></a>: <span class="auth">(M:)</span> but one does not say <span class="ar">هَاؤُلَالِكَ</span>, or <span class="ar">هأُولَالِكَ</span>, <span class="auth">(M,)</span> <span class="add">[nor <span class="ar">هَؤُلَائِكَ</span>, or the like.]</span> <span class="add">[Thus it is said in the Ḳur ii. 4, <span class="ar long">أُولَآئِكَ عَلَ هُدًى مِنْ رَبِّهِمْ وَأُولَآئِكَ هُمُ المُفْلِحُونَ</span> <em>Those follow a right direction from their Lord, and those are they who shall prosper.</em>]</span> <span class="pb" id="Page_0087"></span>And sometimes <span class="ar">أُولَآئِكَ</span> is applied to irrational things, as in the phrase <span class="ar long">بَعْد أُولَآئِكَ الأَيَّامِ</span> <span class="add">[<em>After those days</em>]</span>; and in the Ḳur <span class="add">[xvii. 38]</span>, where it is said, <span class="ar long">إِنَّ السَّمْعَ وَالْبَصَرَ وَالْفُؤَادَ كُلُّ أُولَآئِكَ كَانَ عَنْهُ مَسْؤُولًا</span> <span class="add">[<em>Verily the ears and the eyes and the heart, all of those shall be inquired of</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أُلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oulae_A4">
					<p>The dims. are <span class="arrow"><span class="ar">إُلَيَّا↓</span></span> and<span class="arrow"><span class="ar">أُلَيَّآءِ↓</span></span> <span class="auth">(Ṣ, M)</span> and<span class="arrow"><span class="ar">هؤُلَيَّآءِ↓</span></span>: <span class="auth">(M:)</span> for the formation of the dim. of a noun of vague application does not alter its commencement, but leaves it in its original state, with fet-ḥ or damm, <span class="add">[as the case may be,]</span> and the <span class="ar">ى</span> which is the characteristic of the dim. is inserted in the second place if the word is one of two letters, <span class="add">[as in the instance of <span class="ar">ذَيَّا</span>, <a href="#caA">dim. of <span class="ar">ذَا</span></a>,]</span> and in the third place if it is a word of three letters. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أُلَى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oulae_B1">
					<p><span class="ar">الأُلَى</span>, <span class="auth">(as in some copies of the Ṣ and T,)</span> of the same measure as <span class="ar">العُلَى</span>; <span class="auth">(Ṣ; <span class="add">[wherefore the author of the TA prefers this mode of writing it, which expresses the manner in which it is always pronounced;]</span>)</span> or <span class="ar">الأُلَا</span>; <span class="auth">(ISd, TA;)</span> or <span class="ar">الأُولَى</span>; <span class="auth">(so in some copies of the Ṣ and T;)</span> is likewise a pl. having no proper sing., <span class="add">[meaning <em>They who, those which,</em> and simply <em>who,</em> and <em>which,</em>]</span> its sing. being <span class="ar">الَّذِى</span>; <span class="auth">(Ṣ;)</span> or is changed from being a noun of indication so as to have the meaning of <span class="ar">الَّذِينَ</span>; as also<span class="arrow"><span class="ar">الأُلَآءِ↓</span></span>; wherefore they have the lengthened as well as the shortened alif, and that with the lengthened alif is made indecl. by terminating with a kesreh. <span class="auth">(ISd.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإِنَّ الإُولَى بِالطَّفِّ مِنْ آلِ هَاشِمٍ</span> *</div> 
						<div class="star">* <span class="ar long">تَآسَوْا فَسَنُّوا لِلْكِرَامِ التَّآسِيَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And they who are in Et-Taff, of the family of Háshim, shared their property, one with another, and so set the example, to the generous, of the sharing of property</em>]</span>. <span class="auth">(T, and Ṣ in art. <span class="ar">اسو</span>, where, in one copy, I find <span class="ar">الأُلَى</span> in the place of <span class="ar">الأُولَى</span>.)</span> And another poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإَنَّ الإُلَآءِ يَعْلَمُونَكَ مِنْهُمُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And verily they who know thee, of them</em>]</span>: which shows what has been said above, respecting the change of meaning. <span class="auth">(ISd.)</span> Ziyád El-Aajam uses the former of the two words without <span class="ar">ال</span>, saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَأَنْتُمْ أُولَى جِئْتُمْ مَعَ البَقْلِ وَالدَّبَى</span> *</div> 
						<div class="star">* <span class="ar long">فَطَارَ وَهذَا شَخْصُكُمْ غَيْرُ طَائِرِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>For ye are they who came with the herbs,</em> or <em>leguminous plants, and the young locusts, and they have gone away, while these, yourselves, are not going away</em>]</span>: <span class="auth">(T:)</span> he means that their nobility is recent. <span class="auth">(Ḥam p. 678; where, instead of <span class="ar">فأنتم</span> and <span class="ar">اولى</span>, we find <span class="ar">وَأَنْتُمُ</span> and <span class="ar">أُلَا</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أُلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Oulae_B2">
					<p>In the phrase <span class="ar long">العَرَبُ الأُولَى</span>, <span class="auth">(as in the L, and in some copies of the Ṣ and Ḳ,)</span> or <span class="ar">الأُلَى</span>, <span class="auth">(as also in the L, and in other copies of the Ṣ and Ḳ, <span class="add">[and thus it is always pronounced,]</span>)</span> <span class="ar">الاولى</span> or <span class="ar">الالى</span> may also signify <span class="ar">الَّذِينَ</span>, the verb <span class="ar">سَلَفُوا</span> being suppressed after it, because understood; <span class="add">[so that the meaning is, <em>The Arabs who have preceded,</em> or <em>passed away;</em>]</span> so says Ibn-EshShejeree: <span class="auth">(L:)</span> or it is formed by transposition from <span class="ar">الأُوَلُ</span>, being <a href="#Ouwlae">pl. of <span class="ar">أُولَى</span></a> <span class="add">[<a href="#OawBalu">fem. of <span class="ar">أَوَّلُ</span></a>]</span>, like as <span class="ar">أُخَرُ</span> <a href="#Axa">is pl. of <span class="ar">آخَ</span></a>: and it is thus in the phrase, <span class="ar long">ذَهَبَتِ العَرَبُ الأُولَى</span> or <span class="ar">الأُلَى</span> <span class="add">[<em>The first Arabs have passed away</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> ʼObeyd Ibn-El-Abras uses the phrase, <span class="ar long">نَحْنُ الأُلَى</span> <span class="add">[as meaning <em>We are the first</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiloeN">
				<h3 class="entry"><span class="ar">إِلْىٌ</span></h3>
				<div class="sense" id="IiloeN_A1">
					<p><span class="ar">إِلْىٌ</span>: <a href="#IilFe">see <span class="ar">إِلًى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Iilae.1">
				<h3 class="entry"><span class="ar">إِلَى</span></h3>
				<div class="sense" id="Iilae.1_A1">
					<p><span class="ar">إِلَى</span>: <a href="#IilFe">see <span class="ar">إِلًى</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">إِلَى.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Iilae.1_B1">
					<p><a href="index.php?data=01_A/126_Alw">and see also art. <span class="ar">الو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilFe">
				<h3 class="entry"><span class="ar">إِلًى</span></h3>
				<div class="sense" id="IilFe_A1">
					<p><span class="ar">إِلَى</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَلًى↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> the latter said by Zekereeyà to be the most common, and the same is implied in the Ṣ, but MF says that this is not known, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">إِلْوٌ↓</span></span>, <span class="auth">(T,)</span> or<span class="arrow"><span class="ar">أَلْوٌ↓</span></span>, <span class="auth">(Es-Semeen, Ḳ,)</span> like <span class="ar">دَلْوٌ</span>, <span class="auth">(Es-Semeen, TA,)</span> <span class="add">[belonging to art. <span class="ar">الو</span>,]</span> and<span class="arrow"><span class="ar">إِلْىٌ↓</span></span> <span class="auth">(T, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَلْىٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">أُلْيٌ↓</span></span> <span class="auth">(Es-Sakháwee, Zekereeyà, TA)</span> and<span class="arrow"><span class="ar">إِلَى↓</span></span>, <span class="auth">(the same,)</span> or <span class="ar">إِلَا</span>, occurring at the end of a verse, but it may be a contraction of <span class="ar">إِلَّا</span>, meaning <span class="ar">عَهْدًا</span>, <span class="auth">(M,)</span> <em>A benefit, benefaction, favour, boon,</em> or <em>blessing:</em> pl. <span class="ar">آلَآءٌ</span>. <span class="auth">(T, Ṣ, M, Ḳ, &amp;c.)</span> IAmb says that <span class="ar">إِلًى</span> and <span class="ar">أَلًى</span> are originally <span class="ar">وِلًا</span> and <span class="ar">وَلًا</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaloyapN">
				<h3 class="entry"><span class="ar">أَلْيَةٌ</span></h3>
				<div class="sense" id="OaloyapN_A1">
					<p><span class="ar">أَلْيَةٌ</span> The <em>buttock,</em> or <em>buttocks, rump,</em> or <em>posteriors,</em> syn. <span class="ar">عَجِيزَةٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="add">[more properly]</span> <span class="ar">عَجُزٌ</span>, <span class="auth">(M,)</span> of a man, &amp;c., <span class="auth">(M,)</span> or of a sheep or goat, <span class="auth">(Lth, T, Ṣ,)</span> and of a man, <span class="auth">(Lth, T,)</span> or of a ewe: <span class="auth">(ISk, T:)</span> or the <em>flesh and fat thereon:</em> <span class="auth">(M, Ḳ:)</span> you should not say <span class="arrow"><span class="ar">إِلْيَةٌ↓</span></span>, <span class="auth">(T, Ṣ, Ḳ,)</span> a form mentioned by the expositors of the Fṣ, but said to be vulgar and low; <span class="auth">(TA;)</span> nor <span class="ar">لِيَّةٌ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> with kesr to the <span class="ar">ل</span>, and with teshdeed to the <span class="ar">ى</span>, as in the Ṣ, <span class="add">[but in a copy of the Ṣ, and in one of the T, written without teshdeed,]</span> a form asserted to be correct by some, but it is rarer and lower than <span class="ar">إِلْيَةٌ</span>, though it is the form commonly obtaining with the vulgar: <span class="auth">(TA:)</span> the dual. is <span class="arrow"><span class="ar">أَلْيَانِ↓</span></span>, <span class="auth">(AZ, T, Ṣ,)</span> without <span class="ar">ت</span>; <span class="auth">(Ṣ;)</span> but <span class="ar">أَلْيَتَانِ</span> sometimes occurs: <span class="auth">(IB:)</span> <span class="ar long">أَلَصُّ الأَلْيَتَيْنِ</span> is an epithet applied to the Zenjee, <span class="auth">(Ḳ in art. <span class="ar">لص</span>,)</span> meaning <em>having the buttocks cleaving together:</em> <span class="auth">(TA in that art.:)</span> the pl. is <span class="ar">أَلْيَاتٌ</span> <span class="auth">(T, M, Ḳ)</span> and <span class="ar">أَلَايَا</span>; <span class="auth">(M, Ḳ;)</span> the latter anomalous. <span class="auth">(M.)</span> Lḥ mentions the phrase, <span class="ar long">إِنَّهُ لَذُو أَلْيَاتٍ</span> <span class="add">[<em>Verily he has</em> large <em>buttocks</em>]</span>; as though the term <span class="ar">إَلْيَةٌ</span> applied to every part of what is thus called. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaloyapN_A2">
					<p><em>Fat,</em> as a subst.: <span class="auth">(M:)</span> and <em>a piece of fat.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaloyapN_A3">
					<p>The <em>tail,</em> or <em>fat of the tail,</em> <span class="auth">(Pers. <span class="ar">دُنْبَهٌ</span>,)</span> of a sheep. <span class="auth">(KL.)</span> <span class="add">[Both of these significations <span class="auth">(the “tail,” and “fat of the tail,” of a sheep)</span> are now commonly given to <span class="ar">لِيَّة</span>, a corruption of <span class="ar">أَلْيَةٌ</span> mentioned above: and in the Ḳ, voce <span class="ar">طُنْبُورٌ</span>, it is said that the Pers. <span class="ar long">دُنْبَهْ بَرَّهْ</span> signifies <span class="ar long">أَلْيَةُ الحَمَلِ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaloyapN_A4">
					<p><span class="ar long">أَلْيَةُ السَّاقِ</span> <em>The muscle of the shank;</em> syn. <span class="ar long">حَمَاةُ السَّاقِ</span> <span class="add">[<a href="#HamaApu">which see</a>, <a href="index.php?data=06_H/226_Hwm">in art. <span class="ar">حمو</span></a>]</span>. <span class="auth">(AAF, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaloyapN_A5">
					<p><span class="ar long">أَلْيَةُ الإِبْهَامِ</span> <em>The portion of flesh that is at the root of the thumb;</em> <span class="auth">(Ṣ, M;)</span> <em>and which is also called its</em> <span class="ar">ضَرَّة</span>; <span class="auth">(M;)</span> or <em>the part to which corresponds the</em> <span class="ar">ضَرَّة</span>; <span class="auth">(Ṣ;)</span> <em>and which is also called</em> <span class="ar long">أَلْيَةُ الكَفِّ</span>; the <span class="ar">ضَرَّة</span> being the portion of flesh in (<span class="ar">فِى</span>, <span class="add">[app. a mistranscription for <span class="ar">مِنْ</span> <em>from</em>]</span>) the little finger to the prominent extremity of the ulna next that finger, at the wrist: <span class="auth">(TA:)</span> or <em>the portion of flesh in the</em> <span class="ar">ضَرَّة</span> <em>of the thumb.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaloyapN_A6">
					<p><span class="ar long">أَلْيَةُ الخَنْصِرِ</span> <em>The portion of flesh that is beneath the little finger;</em> <span class="add">[app. <em>what is described above, as called the</em> <span class="ar">ضَرَّة</span>, <em>extending from that finger to the prominent extremity of the ulna, at the wrist;</em>]</span> <em>also called</em> <span class="ar long">أَلْيَةُ اليَدِ</span>. <span class="auth">(Lth, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaloyapN_A7">
					<p><span class="ar long">أَلْيَتَا الكَفِّ</span> <em>The</em> <span class="ar">أَلْيَة</span> <em>of the thumb</em> <span class="add">[<em>described above as also called by itself</em> <span class="ar long">أَلْيَةُ الكَفِّ</span>]</span> <em>and the</em> <span class="ar">ضَرَّة</span> <em>of the little finger</em> <span class="add">[respecting which see the next preceding sentence]</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaloyapN_A8">
					<p><span class="ar long">القَدَمِ أَلْيَةُ</span> <em>The part of the human foot upon which one treads, which is the portion of flesh beneath</em> <span class="add">[or <em>next to</em>]</span> <em>the little toe.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaloyapN_A9">
					<p><span class="ar long">أَلْيَةُ الحَافِرِ</span> <em>The hinder part of the solid hoof.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiloyapN">
				<h3 class="entry"><span class="ar">إِلْيَةٌ</span></h3>
				<div class="sense" id="IiloyapN_A1">
					<p><span class="ar">إِلْيَةٌ</span>: <a href="#OaloyapN">see <span class="ar">أَلْيَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaloyaAnu">
				<h3 class="entry"><span class="ar">أَلْيَانُ</span></h3>
				<div class="sense" id="OaloyaAnu_A1">
					<p><span class="ar">أَلْيَانُ</span>: <a href="#OalayaAnN">see <span class="ar">أَلَيَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaloyaAni">
				<h3 class="entry"><span class="ar">أَلْيَانِ</span></h3>
				<div class="sense" id="OaloyaAni_A1">
					<p><span class="ar">أَلْيَانِ</span> an irreg. dual of <span class="ar">أَلَيَانٌ</span>, q. v.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalayaAnN">
				<h3 class="entry"><span class="ar">أَلَيَانٌ</span></h3>
				<div class="sense" id="OalayaAnN_A1">
					<p><span class="ar">أَلَيَانٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَلْيَانُ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">آلَى↓</span></span>, <span class="auth">(T, Ṣ, Ḳ,)</span> of the measure <span class="ar">أَفْعَلُ</span>, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">آلٌ↓</span></span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">أَلًى↓</span></span>, <span class="auth">(so in some copies of the Ḳ, and so accord. to the TA,)</span> or<span class="arrow"><span class="ar">أَلْىٌ↓</span></span>, <span class="auth">(so in a copy of the Ḳ,)</span> or<span class="arrow"><span class="ar">أَلِىٌ↓</span></span>, <span class="auth">(accord. to the CK,)</span> and<span class="arrow"><span class="ar">آلٍ↓</span></span>, <span class="auth">(M, Ḳ,)</span> applied to a ram, <em>Large in the</em> <span class="ar">أَلْيَة</span>, q. v.: <span class="auth">(T,* Ṣ, M,* Ḳ,* TA:)</span> and so, applied to a ewe, <span class="ar">أَلَيَانَةٌ</span>, <span class="auth">(T, M, Ḳ, <span class="add">[in the CK <span class="ar">اَلْيَانَةٌ</span>,]</span>)</span> <a href="#OalayaAnN">fem. of <span class="ar">أَلَيَانٌ</span></a>; <span class="auth">(T;)</span> and<span class="arrow"><span class="ar">أَلْيَآءٌ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> <a href="#Alae">fem. of <span class="ar">آلَى</span></a>: <span class="auth">(T, Ṣ:)</span> and in like manner these epithets <span class="add">[masc. and fem. respectively, <span class="ar">آلَى</span>, however, being omitted in the M,]</span> are applied to a man and to a woman; <span class="auth">(M, Ḳ;)</span> or, accord. to Aboo-Is-ḥáḳ, <span class="auth">(M,)</span> <span class="ar">آلَى</span> is applied to a man, and <span class="ar">عَجْزَآءُ</span> to a woman, but not <span class="ar">أَلْيَآءُ</span>, <span class="auth">(Ṣ, M,)</span> though <span class="add">[it is asserted that]</span> some say this, <span class="auth">(Ṣ,)</span> Yz saying so, accord. to AʼObeyd, <span class="auth">(IB,)</span> but AʼObeyd has erred in this matter: <span class="auth">(M:)</span> the pl. is <span class="ar">أُلْىٌ</span>, <span class="auth">(T, Ṣ, M, Ḳ, <span class="add">[in the CK erroneously written with fet-ḥ to the <span class="ar">ا</span>,]</span>)</span> <a href="#Alae">pl. of <span class="ar">آلَى</span></a>, <span class="auth">(T, Ṣ, M,)</span> <a href="#AlK">or of <span class="ar">آلٍ</span></a>; of the former because an epithet of this kind is generally of the measure <span class="ar">أَفْعَلُ</span>, or of the latter after the manner of <span class="ar">بُزْلٌ</span> <a href="#baAzilN">as pl. of <span class="ar">بَازِلٌ</span></a>, and <span class="ar">عُودٌ</span> <a href="#EaAyidN">as pl. of <span class="ar">عَائِدٌ</span></a>; <span class="auth">(M;)</span> applied to rams <span class="auth">(T, Ṣ M)</span> and to ewes, <span class="auth">(T, Ṣ,)</span> and to men and to women; <span class="auth">(M, Ḳ)</span> and <span class="ar">أَلَيَانَاتٌ</span>, <span class="auth">(Ṣ, M, Ḳ, <span class="add">[in the CK <span class="ar">اَلْيانات</span>,]</span>)</span> <a href="#OalayaAnapN">pl. of <span class="ar">أَلَيَانَةٌ</span></a>, <span class="auth">(TA,)</span> <span class="add">[but]</span> applied to rams <span class="auth">(Ṣ)</span> <span class="add">[as well as ewes]</span>, or to women, <span class="auth">(M, Ḳ,)</span> and, also applied to women, <span class="ar">إِلَآءٌ</span>, <span class="auth">(M, and so in a copy of the Ḳ, <span class="add">[in the CK <span class="ar">اَلآء</span>,]</span>)</span> or <span class="ar">آلَآءٌ</span>, <span class="auth">(so in some copies of the Ḳ, and in the TA,)</span> with medd, <a href="#OalFe">pl. of <span class="ar">أَلًى</span></a>, <span class="auth">(TA,)</span> and <span class="ar">أَلَايَا</span>, <span class="auth">(Ḳ,)</span> <a href="#OaloyaAnu">pl. of <span class="ar">أَلْيَانُ</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OulaMCi">
				<h3 class="entry"><span class="ar">أُلَآءِ</span> / 
							<span class="ar">هٰؤُلَآءِ</span> / 
							<span class="ar">هٰؤُلَآءٍ</span> / 
							<span class="ar">الأُلَآُءِ</span></h3>
				<div class="sense" id="OulaMCi_A1">
					<p><span class="ar">أُلَآءِ</span> and <span class="ar">هٰؤُلَآءِ</span> and <span class="ar">هٰؤُلَآءٍ</span> and <span class="ar">الأُلَآُءِ</span>: <a href="#Oulae">see <span class="ar">أُلَى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalieN">
				<h3 class="entry"><span class="ar">أَلِىٌ</span></h3>
				<div class="sense" id="OalieN_A1">
					<p><span class="ar">أَلِىٌ</span>, mentioned in this art. in the Ḳ: <a href="index.php?data=01_A/126_Alw">see art. <span class="ar">الو</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الى</span> - Entry: <span class="ar">أَلِىٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OalieN_B1">
					<p><a href="#OalayaAnN">and see also <span class="ar">أَلَيَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OulayBaA">
				<h3 class="entry"><span class="ar">أُلَيَّا</span> / 
							<span class="ar">أُلَيَّآءِ</span> / 
							<span class="ar">هٰؤُلَيَّآءِ</span></h3>
				<div class="sense" id="OulayBaA_A1">
					<p><span class="ar">أُلَيَّا</span> and <span class="ar">أُلَيَّآءِ</span> and <span class="ar">هٰؤُلَيَّآءِ</span>: <a href="#Oulae">see <span class="ar">أُلَى</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalBaMCK">
				<span class="pb" id="Page_0088"></span>
				<h3 class="entry"><span class="ar">أَلَّآءٍ</span></h3>
				<div class="sense" id="OalBaMCK_A1">
					<p><span class="ar">أَلَّآءٍ</span> A man <em>who sells fat, which is termed</em> <span class="ar">الأَلْيَةُ</span>. <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OulBaAka">
				<h3 class="entry"><span class="ar">أُلَّاكَ</span></h3>
				<div class="sense" id="OulBaAka_A1">
					<p><span class="ar">أُلَّاكَ</span>: <a href="#Oulae">see <span class="ar">أُلَى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MlN">
				<h3 class="entry"><span class="ar">آلٌ</span></h3>
				<div class="sense" id="MlN_A1">
					<p><span class="ar">آلٌ</span>: <a href="#OalayaAnN">see <span class="ar">أَلَيَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MlK.1">
				<h3 class="entry"><span class="ar">آلٍ</span></h3>
				<div class="sense" id="MlK.1_A1">
					<p><span class="ar">آلٍ</span>: <a href="#OalayaAnN">see <span class="ar">أَلَيَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mlae">
				<h3 class="entry"><span class="ar">آلَى</span> / <span class="ar">أَلْيَآءُ</span></h3>
				<div class="sense" id="Mlae_A1">
					<p><span class="ar">آلَى</span>, and its fem. <span class="ar">أَلْيَآءُ</span>: <a href="#OalayaAnN">see <span class="ar">أَلَيَانٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0086.pdf" target="pdf">
							<span>Lanes Lexicon Page 86</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0087.pdf" target="pdf">
							<span>Lanes Lexicon Page 87</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0088.pdf" target="pdf">
							<span>Lanes Lexicon Page 88</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
