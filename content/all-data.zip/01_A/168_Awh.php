<article class="root" id="Root_Awh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/167_Awn">اون</a></span>
				<span class="ar">اوه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/169_Awe">اوى</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Awh_1">
				<h3 class="entry">1. ⇒ <span class="ar">أوه</span> ⇒ <span class="ar">آه</span></h3>
				<div class="sense" id="Awh_1_A1">
					<p><a href="#Awh_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awh_2">
				<h3 class="entry">2. ⇒ <span class="ar">أوّه</span></h3>
				<div class="sense" id="Awh_2_A1">
					<p><a href="#Awh_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awh_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأوّه</span></h3>
				<div class="sense" id="Awh_5_A1">
					<p><span class="ar">تأوّه</span>; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">أوّه↓</span></span>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> inf. n. <span class="ar">تَأْوِيةٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">آهَ↓</span></span>, inf. n. <span class="ar">أَوْهٌ</span>; <span class="auth">(Ḳ;)</span> <em>He said</em> <span class="ar">آهِ</span> or <span class="ar">أَوْهِ</span>, &amp;c. <span class="add">[i. e. <em>Ah!</em> or <em>alas!</em>]</span>; <span class="auth">(Ṣ, Mgh, Ḳ;)</span> <em>he moaned;</em> or <em>uttered a moan,</em> or <em>moaning,</em> or <em>prolonged voice of complaint;</em> <span class="auth">(Ṣ, TA;)</span> <em>i. q.</em> <span class="ar">تَوَجَّعَ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mhi.1">
				<h3 class="entry"><span class="ar">آهِ</span></h3>
				<div class="sense" id="Mhi.1_A1">
					<p><span class="ar">آهِ</span>, <span class="auth">(Az, Ṣ, Mṣb, Ḳ, &amp;c.,)</span> as also <span class="ar">آهٍ</span>, <span class="auth">(IAmb, Ḳ,)</span> and <span class="ar">آهًا</span>, and<span class="arrow"><span class="ar">آهَةً↓</span></span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">أَوْهِ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">أَوْهَ↓</span></span>, <span class="auth">(ISd, Ḳ,)</span> and<span class="arrow"><span class="ar">أَوْهُ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow">↓<span class="ar">أَوِّهْ</span></span>, <span class="auth">(Ṣ,)</span> or<span class="arrow"><span class="ar">أَوِّهِ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">أَوَّهْ↓</span></span>, <span class="auth">(Hr, Mgh, Mṣb, Ḳ,)</span> so in some copies of the Ṣ, but in a copy in the author's handwriting <span class="arrow"><span class="ar">آوَّهْ↓</span></span>, there said to be with medd, and with teshdeed and fet-ḥ to the <span class="ar">و</span>, and with the <span class="ar">ه</span> quiescent, <span class="auth">(TA,)</span> <span class="add">[or,]</span> accord. to Aboo-Tálib, <span class="ar">آوَّهْ</span>, with medd, thus pronounced by the vulgar, is wrong, <span class="auth">(T in art. <span class="ar">او</span>,)</span> and<span class="arrow"><span class="ar">أَوَّاه↓</span></span>, and<span class="arrow"><span class="ar">أَوُّوه↓</span></span>, <span class="add">[in both of which, and in some other forms which follow, it is doubtful whether the <span class="ar">ه</span> be quiescent or movent, and if movent, with what vowel,]</span> <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">آوُوهُ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> or<span class="arrow"><span class="ar">أَوُوهُ↓</span></span>, but said by ISd to be with medd, and mentioned by AḤát as heard from the Arabs, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">أَوَتَاه↓</span></span>, <span class="auth">(Ḳ, TA,)</span> or<span class="arrow"><span class="ar">أَوَتَاهُ↓</span></span>, <span class="auth">(CK,)</span> or<span class="arrow"><span class="ar">أَوَّتَاه↓</span></span>, and<span class="arrow"><span class="ar">آوَّتَاه↓</span></span>, <span class="auth">(Ṣ, <span class="add">[in one copy of which the <span class="ar">ه</span> is marked as quiescent,]</span>)</span> and<span class="arrow"><span class="ar">آوَيَّاه↓</span></span>, <span class="auth">(Ḳ, TA,)</span> with medd, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">أَوِيَّاهُ↓</span></span>, <span class="auth">(CK,)</span> and <span class="ar">أَوِّ</span> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">آوِ</span>, and <span class="ar">آوٍ</span>, <span class="auth">(Ḳ, TA,)</span> and <span class="ar">وَاهًا</span>, and <span class="ar">هَاهٌ</span> or <span class="ar">هَاهُ</span>, <span class="auth">(TA,)</span> <span class="add">[<em>Ah!</em> or <em>alas!</em>]</span> a word imitative of the voice, cry, or exclamation, of the <span class="ar">مُتَأَهِّه</span>; <span class="auth">(Az and TA in explanation of <span class="ar">آهِ</span>;)</span> <span class="add">[i. e.]</span> a word expressive of pain, grief, sorrow, lamentation, complaint, or moaning; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, TA;)</span> denoting the prolongation of the voice with complaint: <span class="auth">(Ṣ, TA, after <span class="ar">أَوَّهْ</span> or <span class="ar">آوَّهْ</span>:)</span> sometimes, also, a man says <span class="ar">آهِ</span> from a motive of affection, or pity, or compassion, and of impatience: <span class="auth">(Az, TA:)</span> <span class="add">[and it is also said that]</span> <span class="ar">آهًا</span> is a word expressive of grief or lamentation, or of most intense grief or lamentation or regret; <span class="add">[that]</span> it is put in the accus. case as being used in the manner of inf. ns.; and <span class="add">[that]</span> the hemzeh is originally <span class="ar">و</span>: but IAth says, <span class="ar">آهًا</span> is a word expressive of pain, grief, sorrow, lamentation, complaint, or moaning, used in relation to evil, like as <span class="ar">وَاهًا</span> is used in relation to good: <span class="auth">(TA in art. <span class="ar">اه</span>:)</span> and <span class="ar">آوَّهْ</span> and <span class="ar">آوِ</span> and <span class="ar">آوٍ</span> are cries uttered to horses, to make them return. <span class="auth">(ISh and TA <a href="index.php?data=01_A/169_Awe">in art. <span class="ar">اوى</span></a>. <a href="#Awe_2">See 2</a> in that art. in the present work.)</span> You say, <span class="ar long">آهِ مِنْ كَذَا</span> <span class="add">[<em>Ah,</em> or <em>alas, on account of,</em> or <em>for, such a thing!</em>]</span>; <span class="auth">(Ṣ, Mṣb;)</span> and in like manner, <span class="ar">أَوْهِ</span> <span class="add">[&amp;c.]</span>, followed by <span class="ar">مِنْ</span>, and by <span class="ar">لِ</span>, <span class="auth">(Ṣ, TA,)</span> and by <span class="ar">عَلَى</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#OawBi">See also <span class="ar">أَوِّ</span></a> <a href="index.php?data=01_A/156_Aw">in art. <span class="ar">او</span></a>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="MhapN">
				<span class="pb" id="Page_0130"></span>
				<h3 class="entry"><span class="ar">آهَةٌ</span></h3>
				<div class="sense" id="MhapN_A1">
					<p><span class="ar">آهَةٌ</span> a subst. from <span class="ar">تَأَوَّهَ</span>; occurring in the saying of El-Muthakkib El-'Abdee,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَا مَاقُمْتُ أَرْحَلُهَا بِلَيْلٍ</span> *</div> 
						<div class="star">* <span class="ar long">تَأَوَّهُ آهَةَ الرَّجُلِ الحَزِينِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When I arise to saddle her, by night, she moans with the moaning of the sorrowful man</em>]</span>: <span class="auth">(Ṣ, ISd:)</span> ISd says that, in his opinion, the subst. is here put in the place of the inf. n., i. e. <span class="ar">تَأَوُّه</span>: <span class="auth">(TA:)</span> but some recite the verse differently, saying, <span class="ar">أَهَّةَ</span>, from <span class="ar">أَهَّ</span> meaning <span class="ar">تَوَجَّعَ</span>: <span class="auth">(Ṣ:)</span> and some say, <span class="ar long">تَهَوَّهُ هَاهَةَ</span>. <span class="auth">(TA.)</span> And hence the saying, in imprecating evil on a man, <span class="ar long">آهَةً لَكَ</span> <span class="add">[May God cause <em>moaning to thee!</em>]</span>, and <span class="ar long">أَوَّةً لَكَ</span>, with the <span class="ar">ه</span> suppressed, and with teshdeed to the <span class="ar">و</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#OawBapN">See also <span class="ar">أَوَّةٌ</span></a> <a href="index.php?data=01_A/156_Aw">in art. <span class="ar">او</span></a>.]</span> <a href="#Ahi">And see <span class="ar">آهِ</span> above</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوه</span> - Entry: <span class="ar">آهَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MhapN_B1">
					<p><span class="add">[Also]</span> <em>Measles:</em> thus in the phrase, used in imprecating evil on a man, <span class="ar long">آهَةً وَمَاهَةً</span> <span class="add">[May God cause]</span> <em>measles and small-pox</em> <span class="add">[to befall thee]</span>! <span class="auth">(Ḳ,* TA,)</span> mentioned by Lḥ on the authority of Aboo-Khálid. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oawohi">
				<h3 class="entry"><span class="ar">أَوْهِ</span> / 
							<span class="ar">أَوْهَ</span> / 
							<span class="ar">أَوْهُ</span> / 
							<span class="ar">أَوِّه</span></h3>
				<div class="sense" id="Oawohi_A1">
					<p><span class="ar">أَوْهِ</span> and <span class="ar">أَوْهَ</span> and <span class="ar">أَوْهُ</span> and <span class="ar">أَوِّه</span>, &amp;c.: <a href="#Ahi">see <span class="ar">آهِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawBaAhN">
				<h3 class="entry"><span class="ar">أَوَّاهٌ</span></h3>
				<div class="sense" id="OawBaAhN_A1">
					<p><span class="ar">أَوَّاهٌ</span> A man <em>often saying Ah!</em> or <em>alas!</em> or <em>often moaning:</em> <span class="auth">(Mgh:)</span> or one <em>who says Ah!</em> or <em>alas! from a motive of affection,</em> or <em>pity,</em> or <em>compassion,</em> and <em>fear:</em> or <em>mourning,</em> or <em>sorrowing, much,</em> or <em>often:</em> <span class="auth">(TA:)</span> or <em>compassionate; tender-hearted:</em> or <em>often praying,</em> or <em>frequent in prayer:</em> <span class="auth">(Ḳ,* TA:)</span> or one <em>who celebrates the praises of God,</em> or <em>praises Him greatly,</em> or <em>glorifies Him:</em> or <em>who praises much,</em> or <em>often:</em> or <em>who abases himself,</em> or <em>addresses himself with earnest supplication,</em> <span class="add">[<em>to God</em>]</span>, <em>confident of his prayer's being answered:</em> <span class="auth">(TA:)</span> or one <em>having certain knowledge</em> <span class="auth">(Ḳ, TA)</span> <em>of his prayer's being answered:</em> <span class="auth">(TA:)</span> or <em>inviting much,</em> or <em>often, to what is good:</em> <span class="auth">(TA:)</span> or <em>skilled in the law:</em> or <em>a believer;</em> so in the Abyssinian language: <span class="auth">(Ḳ:)</span> occurring in the Ḳur <span class="add">[ix. 115 and xi. 77]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوه</span> - Entry: <span class="ar">أَوَّاهٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OawBaAhN_B1">
					<p><a href="#Ahi">See also <span class="ar">آهِ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oawuwhu">
				<h3 class="entry"><span class="ar">أَوُوهُ</span> / 
							<span class="ar">آوُوهُ</span> / 
							<span class="ar">أَوُّوه</span></h3>
				<div class="sense" id="Oawuwhu_A1">
					<p><span class="ar">أَوُوهُ</span>, or <span class="ar">آوُوهُ</span>, and <span class="ar">أَوُّوه</span>: <a href="#Ahi">see <span class="ar">آهِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OawataAh">
				<h3 class="entry"><span class="ar">أَوَتَاه</span> / 
							<span class="ar">أَوَتَاهُ</span> / 
							<span class="ar">أَوَّتَاه</span> / 
							<span class="ar">آوَّتَاه</span></h3>
				<div class="sense" id="OawataAh_A1">
					<p><span class="ar">أَوَتَاه</span>, or <span class="ar">أَوَتَاهُ</span>, or <span class="ar">أَوَّتَاه</span>, and <span class="ar">آوَّتَاه</span>: <a href="#Ahi">see <span class="ar">آهِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OawiyBaAhu">
				<h3 class="entry"><span class="ar">أَوِيَّاهُ</span> / <span class="ar">آوَيَّاه</span></h3>
				<div class="sense" id="OawiyBaAhu_A1">
					<p><span class="ar">أَوِيَّاهُ</span>, or <span class="ar">آوَيَّاه</span>: <a href="#Ahi">see <span class="ar">آهِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOawBihN">
				<h3 class="entry"><span class="ar">مُتَأَوِّهٌ</span></h3>
				<div class="sense" id="mutaOawBihN_A1">
					<p><span class="ar">مُتَأَوِّهٌ</span> <span class="add">[<em>Saying Ah!</em>, &amp;c.: <span class="auth">(see the verb:)</span> and]</span> <em>abasing himself;</em> or <em>addressing himself with earnest supplication</em> <span class="add">[<em>to God</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#OawBaAhN">See also <span class="ar">أَوَّاهٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0129.pdf" target="pdf">
							<span>Lanes Lexicon Page 129</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0130.pdf" target="pdf">
							<span>Lanes Lexicon Page 130</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
