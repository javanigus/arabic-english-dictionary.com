<article class="root" id="Root_Ajl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/027_AjS">اجص</a></span>
				<span class="ar">اجل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/029_Ajm">اجم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ajl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أجل</span></h3>
				<div class="sense" id="Ajl_1_A1">
					<p><span class="ar">أَجِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْجَلُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَجَلٌ</span>, <span class="auth">(Mṣb,)</span> <em>It</em> <span class="auth">(a thing, Mṣb, <span class="add">[as, for instance, a thing purchased, and the price thereof, and a thing promised or threatened or foretold, and also payment for a thing purchased, and the fulfilment of a promise or threat or prediction, and any event,]</span>)</span> <em>was,</em> or <em>became, delayed, postponed, kept back;</em> <span class="add">[and therefore, <em>future;</em>]</span> syn. <span class="ar">تَأَخَّرَ</span>; <span class="auth">(Ḳ;)</span> and <span class="ar">أَجَلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُلُ</span>}</span></add>, inf. n. <span class="ar">أُجُولٌ</span>, signifies the same. <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#AjilN">See <span class="ar">آجِلٌ</span></a> <a href="#OajalN">and <span class="ar">أَجَلٌ</span></a>. The primary signification seems to be, <em>It had a term,</em> or <em>period, appointed for it, at which it should fall due,</em> or <em>come to pass.</em>]</span></p>
				</div>
				<span class="pb" id="Page_0025"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ajl_1_B1">
					<p><span class="ar">أَجَلَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَجُلٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">أجّلهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَأْجِيلٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">آجلهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُؤَاجَلَةٌ</span>; <span class="auth">(TḲ;)</span> <em>He confined, restricted, restrained, withheld, debarred, hindered,</em> or <em>prevented, him.</em> <span class="auth">(Ḳ, TA.)</span> Hence the phrase, <span class="ar long">أَجَلُوا مَالَهُمْ</span> <em>They confined, restricted,</em>, &amp;c., <em>their cattle from the pasturage.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Ajl_1_C1">
					<p><span class="ar long">أَجَلَ عَلَيْهِمْ شَرًّا</span>, <span class="auth">(Ṣ, Mṣb,)</span> or <span class="ar">الشَّرَّ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُلُ</span>}</span></add> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِلُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَجْلٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He committed against them evil,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and <em>drew it,</em> or <em>procured it, to them:</em> <span class="auth">(Mṣb:)</span> and <span class="auth">(Ṣ, in the Ḳ “or”)</span> <em>he excited it, stirred it up,</em> or <em>provoked it, against them:</em> <span class="auth">(Ṣ, Ḳ:)</span> or, accord. to AZ, <span class="ar long">أَجَلْتُ عَلَيْهِمٌ</span>, inf. n. as above, signifies <em>I committed a crime against them:</em> and AA says that <span class="ar long">جَلَبْتُ عَلَيْهِمْ</span> and <span class="ar">جَرَرْتُ</span> and <span class="ar">أَجَلْتُ</span> have one and the same signification. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Ajl_1_C2">
					<p>And <span class="ar long">أَجَلَ لِأَهْلِهِ</span>, <span class="auth">(Lḥ, Ḳ,)</span> inf. n. as above, <span class="auth">(TA,)</span> <em>He gained, acquired,</em> or <em>earned,</em> and <em>collected,</em> and <em>brought,</em> or <em>purveyed,</em> and <em>exercised skill in the management of affairs, for his family.</em> <span class="auth">(Lḥ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أجّل</span></h3>
				<div class="sense" id="Ajl_2_A1">
					<p><span class="ar long">أَجَّلَ الأَجَلَ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَأْجِيلٌ</span>, <span class="auth">(Ḳ, TA,)</span> <em>He defined the term,</em> or <em>period;</em> <span class="auth">(Ḳ,* TA;)</span> <em>assigned, appointed,</em> or <em>specified, it.</em> <span class="auth">(TA.)</span> It is said in the Ḳur <span class="add">[vi. 128]</span>, <span class="ar long">وَبَلَغْنَا أَجَلَنَا ٱلَّذِى أَجَّلْتَ لَنَا</span> <span class="add">[<em>And we have reached our term which Thou hast assigned,</em> or <em>appointed, for us;</em>]</span> meaning, the day of resurrection; <span class="auth">(Bḍ,* Jel;)</span> or the term of death; or, as some say, the term of extreme old age. <span class="auth">(TA.)</span> And <span class="ar">أَجَّلْتُهُ</span>, inf. n. as above, signifies <em>I assigned,</em> or <em>appointed, for him,</em> or <em>it, a term,</em> or <em>period.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ajl_2_A2">
					<p><span class="ar">أَجَّلَنِى</span> <em>He granted me a delay,</em> or <em>postponement.</em> <span class="auth">(TA.)</span> You say,<span class="arrow"><span class="ar long">اِسْتَأْجَلْتُهُ↓ فَأَجَّلَنِى أِلَى مُدَّةٍ</span></span> <span class="auth">(Ṣ, Ḳ, TA)</span> <em>I desired, asked, demanded,</em> or <em>requested, of him a term,</em> or <em>period,</em> <span class="add">[<em>of delay,</em> or <em>postponement,</em>]</span> <em>and he granted me a delay,</em> or <em>postponement, to a certain term,</em> or <em>period.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ajl_2_A3">
					<p><a href="#Ajl_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajl_3">
				<h3 class="entry">3. ⇒ <span class="ar">آجل</span></h3>
				<div class="sense" id="Ajl_3_A1">
					<p><span class="ar">آجلهُ</span>, inf. n. <span class="ar">مُؤَاجَلَةٌ</span>: <a href="#Ajl_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأجّل</span></h3>
				<div class="sense" id="Ajl_5_A1">
					<p><span class="ar">تأجّل</span> <em>i. q.</em><span class="arrow"><span class="ar">استأجل↓</span></span>; <span class="auth">(Ḳ, TA;)</span> i. e. <em>He asked,</em> or <em>requested, that a term,</em> or <em>period, should be assigned, appointed,</em> or <em>specified, for him.</em> <span class="auth">(TA.)</span> It is said in a trad. of Mek-hool, <span class="ar long">كُنَّا مَرَابِطِينَ بِا لسَّاحِلِ فَتَأَجَّلَ مُتَأَجِّلٌ</span> <span class="add">[<em>We were keeping post on the frontier of the enemy, in the tract on the sea-coast, and</em>]</span> <em>a person asked,</em> or <em>requested, that a term,</em> or <em>period, should be assigned,</em> or <em>appointed,</em> or <em>specified, for him,</em> and that permission should be granted him to return to his family. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ajl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استَأجل</span></h3>
				<div class="sense" id="Ajl_10_A1">
					<p><a href="#Ajl_2">see 2</a> <a href="#Ajl_5">and 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajolN">
				<h3 class="entry"><span class="ar">أَجْلٌ</span></h3>
				<div class="sense" id="OajolN_A1">
					<p><span class="ar">أَجْلٌ</span> <a href="#Ajl_1">is originally the inf. n. of <span class="ar long">أَجَلَ شَرًّا</span></a> “he committed evil;” and is used to indicate the causation of crimes; and afterwards, by extension of its application, to indicate any causation: <span class="auth">(Bḍ in v. 35:)</span> one says, <span class="ar long">فَعَلْتُهُ مِنْ أَجْلِكَ</span>, and<span class="arrow"><span class="ar long">من إِجْلِكَ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar long">فَعَلْتُهُ أَجْلَكَ</span>, and<span class="arrow"><span class="ar">إِجْلَكَ↓</span></span>, <span class="auth">(so in some copies of the Ḳ,)</span> and <span class="ar long">من أَجْلَالِكَ</span>, and <span class="ar long">من إِجْلَالِكَ</span>, <span class="auth">(Ḳ, <span class="add">[belonging to art. <span class="ar">جلو</span>, in which also they are mentioned,]</span>)</span> and <span class="ar long">من أَجْلالِكَ</span>, and <span class="ar long">من إِجْلَالِكَ</span>, <span class="auth">(so in some copies of the Ḳ and in the TA, <span class="add">[<a href="index.php?data=05_j/120_jl">belonging to art. <span class="ar">جل</span></a>,]</span>)</span> i. e. <span class="add">[<em>I did it</em>]</span> <span class="ar long">مِنْ جَرَّاكَ</span>, <span class="auth">(Ṣ,)</span> which means <span class="add">[originally]</span> <em>in consequence of thy committing it:</em> <span class="auth">(Bḍ ubi suprà:)</span> <span class="add">[and then, by extension of its application, as shown above, <em>because of thee,</em> or <em>of thine act</em>, &amp;c.; <em>on thine account; for thy sake;</em> as also <span class="ar">لِأَجْلِكَ</span>, which is more common in the present day:]</span> or <span class="ar long">منْ جَلَلِكَ</span>: <span class="auth">(Ḳ:)</span> and <span class="ar long">مِنْ أَجْلِهِ كَانَ كَذَا</span>, i. e. <span class="ar">بِسَبَبِهِ</span> <span class="add">[<em>Because of him,</em> or <em>it, it was thus,</em> or <em>such a thing was</em>]</span>. <span class="auth">(Mṣb.)</span> An instance of its occurrence without <span class="ar">مِنْ</span> <span class="add">[or <span class="ar">لِ</span>]</span> is presented by the saying of 'Adee Ibn-Zeyd,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَجْلَ أَنَّ ٱللّٰهَ قَدْ فَضَّلَكُمْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Because that God hath made you to have excel-lence,</em> or <em>hath preferred you</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IijolN">
				<h3 class="entry"><span class="ar">إِجْلٌ</span></h3>
				<div class="sense" id="IijolN_A1">
					<p><span class="ar">إِجْلٌ</span>, whence <span class="ar long">فَعَلْتُهُ مِنْ إِجْلِكَ</span>, and <span class="ar long">فَعَلْتُهُ إِجْلَكَ</span>: <a href="#OajolN">see <span class="ar">أَجْلٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oajalo">
				<h3 class="entry"><span class="ar">أَجَلْ</span></h3>
				<div class="sense" id="Oajalo_A1">
					<p><span class="ar">أَجَلْ</span>, <span class="auth">(Ṣ, Mughnee, Ḳ,)</span> with the <span class="ar">ل</span> quiescent, <span class="auth">(Mughnee,)</span> is written with kesr and with fet-ḥ <span class="add">[to the medial letter, i. e.<span class="arrow"><span class="ar">أَجِلْ↓</span></span> as well as <span class="ar">أَجَلْ</span>]</span> like <span class="ar">نعم</span> <span class="add">[which is written <span class="ar">نَعِمٌ</span> as well as <span class="ar">نَعَمْ</span>]</span>: <span class="auth">(TA:)</span> it is a particle <span class="auth">(Mughnee)</span> denoting a reply; like <span class="ar">نَعَمْ</span>; <span class="auth">(Ṣ, Mughnee, Ḳ;)</span> importing acknowledgment of the truth of the speaker, to him who gives information; and the making a thing known, to him who asks information; and a promise, to him who seeks, or demands; <span class="auth">(Mughnee;)</span> i. e. <em>It is as thou sayest</em> <span class="add">[in the first case; and <em>yes,</em> or <em>yea,</em> in the same, and in the other cases]</span>; <span class="auth">(Ḳ voce <span class="ar">بَسَلٌ</span>;)</span> therefore it occurs after such sayings as “Zeyd stood” and “did Zeyd stand?” and “beat thou Zeyd:” but El-Málakee restricts the information to that which is affirmative, and the saying expressive of seeking or demanding to that which is without prohibition: and it is said by some that it does not occur after an interrogation: <span class="auth">(Mughnee:)</span> Er-Raḍee says, in the Expos. of the Káfiyeh, after Z and others, that it is to denote acknowledgment of the truth of information, and does not occur after a saying in which is the meaning of seeking, or demanding: <span class="auth">(TA:)</span> or, accord. to Z and Ibn-Málik and others, it relates particularly to information: and accord. to Ibn-Kharoof, it occurs mostly after information: <span class="auth">(Mughnee:)</span> in the Expos. of the Tes-heel, it is said to be for denoting acknowledgment of the truth of information, past or other, affirmative or negative, and not to occur after an interrogation: <span class="auth">(TA:)</span> Akh says that it is better than <span class="ar">نَعَمْ</span> <span class="auth">(Ṣ, Mughnee, Ḳ *)</span> after information, <span class="auth">(Mughnee,)</span> in acknowledging the truth of what is said; <span class="auth">(Ṣ, Mughnee, Ḳ;)</span> and <span class="ar">نعم</span> is better than it after an interrogation: <span class="auth">(Ṣ, Mughnee, Ḳ:)</span> so that when one says, <span class="ar long">سَوْفَ تَذْهَبُ</span> <span class="add">[Thou wilt, or shalt, go away]</span>, thou sayest <span class="ar">أَجَلْ</span> <span class="add">[<em>Yes</em>]</span>; and it is better than <span class="ar">نعم</span>: but when one says, <span class="ar">أَتَذْهَبُ</span> <span class="add">[Wilt thou go away?]</span>, thou sayest <span class="ar">نعم</span>; and it is better than <span class="ar">اجل</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajalN">
				<h3 class="entry"><span class="ar">أَجَلٌ</span></h3>
				<div class="sense" id="OajalN_A1">
					<p><span class="ar">أَجَلٌ</span> The <em>term,</em> or <em>period,</em> of a thing: <span class="auth">(Ṣ, Ḳ:)</span> its <em>assigned, appointed,</em> or <em>specified, term</em> or <em>period:</em> this is the primary signification: <span class="auth">(TA:)</span> or the <em>term,</em> or <em>period,</em> and <em>time of falling due,</em> of a thing: <span class="auth">(Mṣb:)</span> pl. <span class="ar">آجَالٌ</span>. <span class="auth">(Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">أَجَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OajalN_A2">
					<p>Hence, The <em>period of</em> women's <em>waiting, before they may marry again, after divorce:</em> as in the Ḳur ii. 231 and 232. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">أَجَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OajalN_A3">
					<p>The <em>period,</em> or <em>extremity of time, in which falls due a debt</em> <span class="auth">(Ḳ, TA)</span> and <em>the like.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">بَاعَهُ إِيَّاهُ إِلَى أَجَلٍ</span> <span class="add">[<em>He sold it to him for payment at an appointed period</em>]</span>: and <span class="ar long">سَلَّمَ الدَّارَاهِمَ فِى طَعَامٍ إِلَى أَجَلٍ</span> <span class="add">[<em>He delivered the money for wheat,</em> or <em>the like, to be given at an appointed period</em>]</span>. <span class="auth">(Mṣb in art. <span class="ar">كلأ</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">أَجَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OajalN_A4">
					<p>The <em>term,</em> or <em>period, of death;</em> <span class="auth">(Ḳ;)</span> the <em>time in which God has eternally decreed the end of life by slaughter or otherwise:</em> or, as some say, the <em>whole duration of life:</em> and <em>its end:</em> a man's <em>life</em> being thus termed: and his <em>death, by which it terminates:</em> <span class="auth">(Kull p. 17:)</span> the <em>assigned,</em> or <em>appointed, duration of the life</em> of a man. <span class="auth">(TA.)</span> One says, <span class="ar long">دَنَا أَجَلُهُ</span>, meaning <em>His death drew near;</em> originally, <span class="ar long">ٱسْتِيفَآءُ الأَجَلِ</span> <em>the completion of the duration of life.</em> <span class="auth">(TA.)</span> In the Ḳur vi. 128, (<a href="#Ajl_2">see 2, above</a>,) the meaning is, The <em>term of death:</em> or, as some say, the <em>term of extreme old age:</em> <span class="auth">(TA:)</span> or the <em>day of resurrection.</em> <span class="auth">(Bḍ,* Jel.)</span> The words of the Ḳur <span class="add">[vi. 2]</span> <span class="ar long">ثُمَّ قَضَى أَجَلًا وَأَجَلٌ مَسَمَّى عِنْدَهُ</span> mean <span class="add">[<em>Then He decreed a term,</em>]</span> <em>the term of death, and</em> <span class="add">[<em>there is a term named with Him,</em>]</span> <em>the term of the resurrection:</em> or <em>the period between the creation and death,</em> and <em>the period between death and the resurrection;</em> for <span class="ar">اجل</span> is applied to the <em>end of a space of time</em> and to the <em>whole thereof:</em> <span class="auth">(Bḍ:)</span> or the meaning is, <em>the period of sleep,</em> and <em>the period of death:</em> <span class="auth">(Bḍ, TA:)</span> or <em>the period of those who have passed away,</em> and <em>the period of those who remain and those who are to come:</em> <span class="auth">(Bḍ:)</span> or <em>the period of remaining in this world,</em> and <em>the period of remaining in the world to come:</em> or in both instances <em>death</em> is meant; <span class="add">[<em>accidental,</em> and <em>natural;</em>]</span> for the <span class="ar">اجل</span> of some is by accidental means, as the sword, and drowning, and burning, and eating what disagrees, and other means of destruction; while some have their full periods granted to them and are preserved in health until they die a natural death: or the <span class="ar">اجل</span> of some is that of him who dies in a state of happiness and enjoyment; and of others, that of him who reaches a limit beyond which God has no<span class="ar">?</span> appointed, in the natural course of this world, any one to remain therein; and to both of these, reference is made in the Ḳur <span class="add">[xvi. 72 and]</span> xxii. 5. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">أَجَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OajalN_A5">
					<p>Sometimes, also, it means <em>Destruction:</em> and thus it has been explained as occurring in the Ḳur <span class="add">[vii. 184]</span>, where it is said, <span class="ar long">وَأَنْ عَسَى أَنْ يَكُونَ قَدِ ٱ قْتَرَبَ أَجَلُهُمْ</span> <span class="add">[<em>And that, may be, their destruction shall have drawn near</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oajilo">
				<h3 class="entry"><span class="ar">أَجِلْ</span></h3>
				<div class="sense" id="Oajilo_A1">
					<p><span class="ar">أَجِلْ</span>: <a href="#OajalN">see <span class="ar">أَجَلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajilN">
				<h3 class="entry"><span class="ar">أَجِلٌ</span></h3>
				<div class="sense" id="OajilN_A1">
					<p><span class="ar">أَجِلٌ</span>: <a href="#AjilN">see <span class="ar">آجِلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajiylN">
				<h3 class="entry"><span class="ar">أَجِيلٌ</span></h3>
				<div class="sense" id="OajiylN_A1">
					<p><span class="ar">أَجِيلٌ</span> <em>Having a delay,</em> or <em>postponement, granted to him, to a certain time; i. q.</em> <span class="arrow"><span class="ar long">مُؤَجَّلٌ↓ إِلَى وَقْتٍ</span></span>. <span class="auth">(Lth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">أَجِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OajiylN_A2">
					<p><a href="#AjilN">See also <span class="ar">آجِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MjilN">
				<h3 class="entry"><span class="ar">آجِلٌ</span></h3>
				<div class="sense" id="MjilN_A1">
					<p><span class="ar">آجِلٌ</span> <em>Delayed; postponed; kept back;</em> syn. <span class="ar">مُتَأَخِّرٌ</span>; <span class="add">[but in some copies of the Ḳ, for <span class="ar">آجِلٌ</span>, we find<span class="arrow"><span class="ar">أَجِلٌ↓</span></span>;]</span> as also<span class="arrow"><span class="ar">أَجِيلٌ↓</span></span>, of which the pl. is <span class="ar">أُجْلٌ</span>: <span class="auth">(Ḳ:)</span> and therefore, <span class="auth">(TA,)</span> <em>not present; future; to come; contr. of</em> <span class="ar">عَاجِلٌ</span>: <span class="auth">(Ṣ, Mṣb, TA:)</span> <span class="pb" id="Page_0026"></span>and<span class="arrow"><span class="ar">مُتَأَجِّلٌ↓</span></span>, also, signifies <em>delayed, deferred,</em> or <em>postponed, to the time of the end of a period;</em> originally, <em>contr. of</em> <span class="ar">مُتَعَجِّلٌ</span>. <span class="auth">(Mgh.)</span> <span class="add">[<a href="#OajiylN">See also <span class="ar">أَجِيلٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">آجِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MjilN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">الآجِلَةُ</span> <em>The</em> <span class="add">[<em>future,</em>]</span> <em>latter, ultimate,</em> or <em>last, dwelling,</em> or <em>abode,</em> or <em>life; the world to come;</em> syn. <span class="ar">الآخِرَةُ</span>; <span class="auth">(Ḳ, TA;)</span> <em>contr. of</em> <span class="ar">العَاجِلَةُ</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">آجِلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MjilN_B1">
					<p><em>Committing</em> a crime; or <em>a committer</em> of a crime. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWajBalN">
				<h3 class="entry"><span class="ar">مُؤَجَّلٌ</span></h3>
				<div class="sense" id="muWajBalN_A1">
					<p><span class="ar">مُؤَجَّلٌ</span> <em>Determined, defined,</em> or <em>limited, as to time;</em> applied to a writing: so in the Ḳur iii. 139: <span class="auth">(Bḍ, Jel, TA:)</span> and to a debt; <em>contr. of</em> <span class="ar">حَالٌّ</span>, q. v. <span class="auth">(Mgh in art. <span class="ar">حل</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجل</span> - Entry: <span class="ar">مُؤَجَّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWajBalN_A2">
					<p><a href="#OajiylN">See also <span class="ar">أَجِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOajBilN">
				<h3 class="entry"><span class="ar">مُتَأَجِّلٌ</span></h3>
				<div class="sense" id="mutaOajBilN_A1">
					<p><span class="ar">مُتَأَجِّلٌ</span>: <a href="#AjilN">see <span class="ar">آجِلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0024.pdf" target="pdf">
							<span>Lanes Lexicon Page 24</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0025.pdf" target="pdf">
							<span>Lanes Lexicon Page 25</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0026.pdf" target="pdf">
							<span>Lanes Lexicon Page 26</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
