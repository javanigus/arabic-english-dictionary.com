<article class="root" id="Root_Arb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/049_Ar">ار</a></span>
				<span class="ar">ارب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/051_Arv">ارث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Arb_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرب</span></h3>
				<div class="sense" id="Arb_1_A1">
					<p><span class="ar">أَرُبَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُبُ</span>}</span></add>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَرَابَةٌ</span> <span class="auth">(AZ, T, Ṣ, M, Ḳ)</span> and <span class="ar">إِرَبٌ</span>, like <span class="ar">صِغَرٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He was,</em> or <em>became, cunning, characterized by intelligence with craft and forecast,</em> or simply <em>intelligent, excellent in judgment, sagacious,</em> <span class="auth">(T, <span class="add">[in which it is said that Aṣ is related to have assigned this signification to <span class="ar">أَرِبَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَبُ</span>}</span></add>, inf. n. <span class="ar">أَرَبٌ</span>,]</span> S, M, Ḳ,)</span> <em>and knowing in affairs.</em> <span class="auth">(M.)</span> <span class="add">[The TA assigns the former inf. n. to it when it signifies simply intelligence, and the latter when it has the more comprehensive signification of cunning.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Arb_1_A2">
					<p><span class="ar long">أَرِبَ بِالشَّىْءِ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَبُ</span>}</span></add>,]</span> <em>He became expert,</em> or <em>skilful, in the thing:</em> <span class="auth">(M:)</span> or <em>he became accustomed to,</em> or <em>practised</em> or <em>exercised in, the thing,</em> <span class="auth">(Ṣ, Ḳ,*)</span> <em>and became knowing,</em> or <em>skilful</em> <span class="add">[<em>therein</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Arb_1_A3">
					<p><span class="ar">أَرِبَ</span>, inf. n. <span class="ar">أَرَبٌ</span>, is also <em>syn. with</em> <span class="ar">أَنِسَ</span> <span class="add">[app. as meaning <em>He became familiar</em> with a person or thing]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Arb_1_A4">
					<p>And <span class="ar long">أَرِبَ بِالشَّىْءِ</span> also signifies <em>He devoted,</em> or <em>addicted, himself,</em> or <em>clave,</em> or <em>kept, to the thing:</em> <span class="auth">(T, Ḳ:)</span> and <em>he was,</em> or <em>became, niggardly, avaricious,</em> or <em>tenacious, of the thing.</em> <span class="auth">(T, M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Arb_1_A5">
					<p>And <span class="ar long">أَرِبَ فِى الأَمْرِ</span>, and<span class="arrow"><span class="ar long">تأرّب↓ فِيهِ</span></span>, <em>He exerted,</em> or <em>employed, his power and ability in the affair, and understood it:</em> <span class="auth">(ISh, T:)</span> or <span class="ar">تأرّب</span> signifies <em>he exerted his strength, force,</em> or <em>energy;</em> or <em>strained himself;</em> <span class="auth">(Aṣ, Ṣ, M;)</span> <span class="ar long">فِى الشَّىْءِ</span> <span class="add">[<em>in the thing</em>]</span>; <span class="auth">(Aṣ, Ṣ;)</span> and <span class="ar long">فِى حَاجَتِهِ</span> <span class="add">[<em>in his needful affair,</em> or <em>in the accomplishment of his want</em>]</span>. <span class="auth">(Aṣ, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Arb_1_A6">
					<p><span class="ar long">أَرِبَ عَلَيْهِ</span> <em>He had,</em> or <em>obtained, power over him,</em> or <em>it.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Arb_1_B1">
					<p><span class="ar">أَرِبَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَبُ</span>}</span></add>, <span class="auth">(T, Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَرَبٌ</span>, <span class="auth">(T, Ṣ,)</span> <em>He was,</em> or <em>became, in want,</em> or <em>need.</em> <span class="auth">(T, Ṣ, Ḳ.)</span> <span class="add">[<a href="#Oaribota">See <span class="ar long">أَرِبْتَ عَنْ ذِى يَدَيْكَ</span></a>, and two other phrases following it, in a later part of this paragraph.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Arb_1_B2">
					<p><span class="ar long">أَرِبَ إِلَيْهِ</span>, <span class="auth">(M, Mṣb,)</span> or <span class="ar">بِهِ</span> <span class="auth">(T,)</span> aor. and inf. n. as above, <em>He wanted it; was,</em> or <em>became, in want,</em> or <em>need, of it;</em> <span class="auth">(T, M, Mṣb;)</span> and <em>sought it,</em> or <em>desired it;</em> <span class="auth">(T;)</span> namely, a thing. <span class="auth">(T, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Arb_1_B3">
					<p><span class="ar long">أَرِبَ الدَّهْرُ</span> <em>Fortune was,</em> or <em>became, hard,</em> or <em>adverse:</em> <span class="auth">(T, Ṣ, Ḳ:)</span> as though it wanted something of us, for which it pressed hard. <span class="auth">(M, TA.)</span> And <span class="ar long">أَرِبَ عَلَيْهِ</span> <em>He was,</em> or <em>became, hard upon him</em> in his demand. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Arb_1_C1">
					<p><span class="ar">أَرَبَهُ</span>, <span class="add">[from <span class="ar">إِرَبٌ</span>,]</span> <em>He struck upon a member,</em> or <em>limb, belonging to him.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<span class="pb" id="Page_0045"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Arb_1_C2">
					<p><span class="ar">أَرِبَ</span>, <span class="auth">(T, Ṣ, Ḳ, TA,)</span> <em>His member,</em> or <em>limb,</em> <span class="auth">(generally meaning the <em>arm,</em> or <em>hand,</em> M,)</span> <em>was cut off:</em> <span class="auth">(M, Ḳ:)</span> or <em>dropped off:</em> <span class="auth">(T:)</span> and <em>his members,</em> or <em>limbs,</em> <span class="auth">(generally relating to <span class="add">[the <em>members,</em> or <em>fingers, of</em>]</span> <em>the arm,</em> or <em>hand,</em> TA,)</span> <em>dropped off, one after another,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>in consequence of his being affected by the disease termed</em> <span class="ar">جُذَام</span>: <span class="auth">(TA:)</span> and <em>it</em> <span class="auth">(said of a member, or limb,)</span> <em>dropped off.</em> <span class="auth">(TA.)</span> The phrase, <span class="ar long">أَرِبْتَ عَنْ ذِى يَدَيْكَ</span>, <span class="auth">(T, TA,)</span> or <span class="ar long">مِنْ ذى يديك</span>, <span class="auth">(Ṣ, TA, <span class="add">[and said in the latter to be likewise found in the T, but I have consulted two copies of the T and found only <span class="ar">عن</span>,]</span>)</span> or <span class="ar long">فِى ذى يديك</span>, <span class="auth">(IAạr, as related by Sh,)</span> or <span class="ar long">مِنْ يَدَيْكَ</span>, <span class="auth">(Ḳ,)</span> but MF says that <span class="ar">من</span> in this phrase is a mistranscription, <span class="auth">(TA,)</span> means, <em>May the members</em> <span class="add">[or <em>fingers</em>]</span> <em>of thy hands,</em> or <em>arms, drop off:</em> <span class="auth">(Ṣ, Ḳ, TA:)</span> or it means, <em>may what is in thy hands depart from thee, so that thou shalt be in want:</em> occurring in a trad. <span class="auth">(IAạr, T, TA.)</span> And <span class="ar long">أَرِبَ مَا لَهُ</span>, said by Moḥammad on the occasion of a man's coming to him and asking him to acquaint him with some work that should introduce him into Paradise, means, accord. to Ḳṭ, <em>May his members,</em> or <em>limbs, drop off,</em> or <em>be cut off: what aileth him?</em> <span class="auth">(TA:)</span> or, accord. to IAạr, <em>may he become in want: what aileth him?</em> <span class="auth">(T, TA:)</span> but IAth says that this has been related in three different ways: first, <span class="ar">أَرِبَ</span>, signifying an imprecation, <span class="add">[as rendered above,]</span> and used as expressive of wonder: secondly, <span class="arrow"><span class="ar long">أَرَبٌ↓ مَّا لَهُ</span></span>; i. e. <span class="ar">حَاجَةٌ لَهُ</span>; <span class="ar">مَا</span> being <span class="add">[syntactically]</span> redundant, denoting littleness; the meaning being, <em>he has some little want:</em> or, as some say, <em>a want hath brought him: what aileth him?</em> thirdly, <span class="arrow"><span class="ar">أَرِبٌ↓</span></span>; i. e. <span class="ar long">هُوَ أَرِبٌ</span>; meaning <em>he is intelligent,</em> or <em>sagacious,</em> or <em>skilful,</em> <span class="add">[as is said in the T,]</span> <em>and perfect: what aileth him?</em> or <em>what is his affair?</em> the inchoative being suppressed. <span class="auth">(TA.)</span> <span class="ar long">مَا لَهُ أَرِبَتْ يَدُهُ</span>, <span class="auth">(M, Ḳ,*)</span> another form of imprecation, <span class="auth">(M,)</span> means <em>What aileth him? may his arm,</em> or <em>hand, be cut off:</em> or, <em>may he become poor, and want what is in the hands of others.</em> <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="Arb_1_C3">
					<p><span class="add">[Hence, perhaps,]</span> <span class="ar long">أَرِبَتْ مَعِدَتُهُ</span> <em>His stomach became vitiated, disordered,</em> or <em>in an unsound state.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C4</span>
				</div>
				<div class="sense" id="Arb_1_C4">
					<p><span class="ar">أَرِبَ</span> also signifies <em>He prostrated himself firmly,</em> or <em>fixedly, upon his</em> <span class="add">[<em>seven</em>]</span> <em>members</em> <span class="add">[<em>mentioned in the explanations of the word</em> <span class="ar">إِرْبٌ</span>]</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arb_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّب</span></h3>
				<div class="sense" id="Arb_2_A1">
					<p><span class="ar">أرّب</span>, inf. n. <span class="ar">تَأرِيبٌ</span>, <em>He,</em> or <em>it,</em> <span class="add">[<em>made,</em> or <em>rendered, cunning,</em> or <em>intelligent, excellent in judgment, sagacious, and knowing in affairs;</em> (<a href="#Oaruba">see <span class="ar">أَرُبَ</span></a>;)]</span> <em>made to have knowledge,</em> or <em>skill;</em> or <em>made to understand.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Arb_2_B1">
					<p><em>He was,</em> or <em>became, avaricious;</em> <span class="add">[<em>in a state of vehement want</em> of a thing;]</span> <em>eagerly desirous.</em> <span class="auth">(AʼObeyd, TA.)</span> <span class="add">[<a href="#Arb_1">See also 1</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Arb_2_C1">
					<p><em>He cut up,</em> or <em>cut into pieces,</em> <span class="auth">(T, A, Mgh,)</span> a sheep, or goat, <span class="auth">(A, Mgh,)</span> <em>limb by limb.</em> <span class="auth">(T, A, Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Arb_2_C2">
					<p><em>He cut off</em> a member, or limb, <em>entire.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="Arb_2_C3">
					<p><em>He made entire,</em> or <em>complete,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> a thing, <span class="auth">(Ṣ,)</span> a lot, or portion, <span class="auth">(T, TA,)</span> or anything. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arb_3">
				<h3 class="entry">3. ⇒ <span class="ar">آرب</span></h3>
				<div class="sense" id="Arb_3_A1">
					<p><span class="ar">آربهُ</span>, <span class="auth">(Ṣ, A,)</span> inf. n. <span class="ar">مُؤَارَبَةٌ</span>, <span class="auth">(M, A,)</span> <em>He strove,</em> or <em>endeavoured, to outwit, deceive, beguile,</em> or <em>circumvent, him;</em> syn. <span class="ar">دَاهَاهُ</span>. <span class="auth">(Ṣ, M,* A.*)</span> It is said in a trad., <span class="auth">(TA,)</span> <span class="ar long">مُؤَارَبَةُ الأَرِيبِ جَهْلٌ وَعَنَآءٌ</span> <span class="add">[<em>The striving to outwit the cunning,</em> or <em>intelligent,</em> or <em>sagacious, is ignorance, and labour</em> without profit]</span>: <span class="auth">(A, TA:)</span> i. e., the intelligent is not to be outwitted. <span class="auth">(TA.)</span> And <span class="ar long">آرب بِهِ</span> signifies <em>He practised an artifice, a stratagem,</em> or <em>a fraud, upon him.</em> <span class="auth">(TA, from a trad.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arb_4">
				<h3 class="entry">4. ⇒ <span class="ar">آرب</span></h3>
				<div class="sense" id="Arb_4_A1">
					<p><span class="ar long">آرب عَلَيْهِمْ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> of the measure <span class="ar">أَفْعَلَ</span>, <span class="auth">(T,)</span> inf. n. <span class="ar">إِيرَابٌ</span> <span class="add">[originally <span class="ar">إِئْرَابٌ</span>]</span>, <span class="auth">(Ḳ,)</span> <em>He was successful against them, and overcame them.</em> <span class="auth">(T, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأرّب</span></h3>
				<div class="sense" id="Arb_5_A1">
					<p><span class="ar">تأرّب</span> <em>He affected,</em> or <em>endeavoured to acquire,</em> (<span class="ar">تَكَلَّفَ</span>,) <em>cunning,</em> or <em>intelligence, and excellence of judgment,</em> <span class="auth">(Ḳ, TA,)</span> <em>and deceit, guile,</em> or <em>artifice, and wickedness, mischievousness,</em> or <em>malignity.</em> <span class="auth">(TA.)</span><span class="add">[<a href="#IirobN">See <span class="ar">إِرْبٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Arb_5_A2">
					<p><span class="ar long">تأرّب فِى الأَمْرِ</span>: <a href="#Arb_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OarobN">
				<h3 class="entry"><span class="ar">أَرْبٌ</span></h3>
				<div class="sense" id="OarobN_A1">
					<p><span class="ar">أَرْبٌ</span>: <a href="#IirobN">see what next follows</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IirobN">
				<h3 class="entry"><span class="ar">إِرْبٌ</span></h3>
				<div class="sense" id="IirobN_A1">
					<p><span class="ar">إِرْبٌ</span> <em>Cunning, intelligence with craft and forecast,</em> or simply <em>intelligence, excellence of judgment, sagacity,</em> <span class="auth">(T, Ṣ, M, L, Ḳ,)</span> <em>and knowledge in affairs;</em> <span class="auth">(M, L;)</span> as also<span class="arrow"><span class="ar">إِرْبَةٌ↓</span></span> and<span class="arrow"><span class="ar">أُرْبَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">أَرَبٌ↓</span></span>, <span class="auth">(M, A,)</span> or<span class="arrow"><span class="ar">أَرْبٌ↓</span></span>. <span class="auth">(L.)</span> You say, <span class="ar long">هُوَ ذُو إِرْبٍ</span> <span class="add">[<em>He is a possessor of cunning,</em> or <em>intelligence,</em>, &amp;c.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IirobN_A2">
					<p><em>Intelligence and religion.</em> <span class="auth">(Th, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IirobN_A3">
					<p><em>Deceit, guile, artifice,</em> or <em>fraud;</em> syn. <span class="ar">مَكْرٌ</span>: so in the L and other lexicons: in the Ḳ, <span class="ar">نُكْرٌ</span> <span class="add">[i. e. “cunning,”, &amp;c., as above]</span>: <span class="auth">(TA:)</span> and so<span class="arrow"><span class="ar">إِرْبَةٌ↓</span></span>; syn. <span class="ar">حِيلَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IirobN_A4">
					<p><em>Wickedness, mischievousness,</em> or <em>malignity; hidden rancour, malevolence,</em> or <em>malice.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[In a trad. it occurs in this sense written, in the TA, <span class="arrow"><span class="ar">أَرْب↓</span></span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IirobN_B1">
					<p><a href="#OarabN">See also <span class="ar">أَرَبٌ</span></a>, in four places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="IirobN_C1">
					<p>Also <em>A member; a distinct and complete part of an animal body; a limb;</em> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> or <em>such as is made complete,</em> or <em>entire, not wanting anything:</em> <span class="auth">(M:)</span> pl. <span class="ar">آرَابٌ</span> <span class="auth">(Ṣ, M, Mgh, Mṣb)</span> and <span class="ar">أَرْآبٌ</span>; <span class="auth">(Ṣ, Mgh;)</span> the latter formed by transposition. <span class="auth">(Mgh.)</span> You say, <span class="ar long">قَطَّعْتُهُ إِرْبًا إِرْبًا</span> <em>I cut him up, member by member,</em> or <em>limb by limb.</em> <span class="auth">(TA.)</span> And <span class="ar long">السُّجُودُ عَلَى سَبْعَةِ آرَابٍ</span> or <span class="ar">أَرْآبٍ</span> <em>Prostration</em> <span class="add">[in prayer]</span> <em>is</em> <span class="add">[performed]</span> <em>on seven members;</em> <span class="auth">(Ṣ, Mgh;)</span> namely, the. forehead, the hands, the knees, and the feet. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="IirobN_C2">
					<p>Also The <em>membrum genitale;</em> the <em>pudendum;</em> syn. <span class="ar">فَرْجٌ</span>: <span class="auth">(M, Ḳ:)</span> but some say that this signification is not known: <span class="add">[<a href="#OarabN">see <span class="ar">أَرَبٌ</span></a>:]</span> in some copies of the Ḳ, the explanation is written <span class="ar">فَرَحٌ</span>, with the unpointed <span class="ar">ح</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="IirobN_C3">
					<p><span class="ar">آرَابٌ</span> <span class="add">[the pl.]</span> also signifies <em>Pieces of flesh,</em> or <em>of flesh-meat.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarabN">
				<h3 class="entry"><span class="ar">أَرَبٌ</span></h3>
				<div class="sense" id="OarabN_A1">
					<p><span class="ar">أَرَبٌ</span>: <a href="#IirobN">see <span class="ar">إِرْبٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">أَرَبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OarabN_B1">
					<p><em>Want,</em> or <em>need;</em> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِرْبٌ↓</span></span> and<span class="arrow"><span class="ar">إرْبَةٌ↓</span></span> <span class="auth">(the same, and A)</span> and<span class="arrow"><span class="ar">أُرْبَةٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">مَأْرَبَةٌ↓</span></span> and<span class="arrow"><span class="ar">مَأْرُبَةٌ↓</span></span> <span class="auth">(T, Ṣ, M, A, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">مَأْرِبَةٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">مَأْرَبٌ↓</span></span>: <span class="auth">(M, A:)</span> the pl. <span class="add">[of <span class="ar">أَرَبٌ</span> or <span class="ar">إِرْبٌ</span>]</span> is <span class="ar">آرَابٌ</span>, and <span class="add">[of <span class="ar">إِرْبَةٌ</span>, and perhaps of the other sings. commencing with <span class="ar">ا</span>]</span> <span class="ar">إِرَبٌ</span>; <span class="auth">(M;)</span> and <a href="#mArbp">the pl. of <span class="ar">مأربة</span></a> is <span class="ar">مَآرِبُ</span>. <span class="auth">(T, Mṣb.)</span> It is said in a trad., respecting Moḥammad, <span class="ar long">كَانَ أَمْلَكَكُمْ لاربه</span> <em>He had the most power, of you, over his want, and desire:</em> <span class="auth">(M,* Mgh,* Mṣb,* TA:)</span> IAth says that the most common reading is <span class="ar">لِأَرَبِهِ</span>, meaning <span class="ar">لِحَاجَتِهِ</span>: but some read<span class="arrow"><span class="ar">لِاْربِهِ↓</span></span>, <span class="add">[as in the M and Mgh,]</span> i. e., either the same as above, <span class="add">[and so in the Mgh,]</span> or <span class="ar">لِعُضْوِهِ</span>, by which is specially meant the membrum genitale: <span class="auth">(TA:)</span> but this is not known. <span class="auth">(M.)</span> Respecting the phrase <span class="ar long">أَرَبَ مَّا لَهُ</span>, <a href="#Arb_1">see 1</a>. You say also,<span class="arrow"><span class="ar long">مَا إِرْبُكَ↓ أِلَى هٰذَا</span></span> <em>What is</em> <span class="add">[the reason of]</span> <em>thy want of this?</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">مَا لِى فِيهِ إِربٌ↓</span></span> <em>I have no want of it.</em> <span class="auth">(A.)</span> By<span class="arrow"><span class="ar long">غَيْرِ أُولِى الأَرْبَةِ↓</span></span>, in the Ḳur <span class="add">[xxiv. 31]</span>, are meant <em>Idiots;</em> or <em>persons deficient in intellect:</em> <span class="add">[from <span class="ar">إِرْبَةٌ</span> as meaning “intelligence:”]</span> <span class="auth">(Saʼeed Ibn-Jubeyr, Ṣ:)</span> or <em>not such as have need of women.</em> <span class="auth">(Jel.)</span> <span class="arrow"><span class="ar long">مَأَرَبَةٌ↓ لَا حَفَاوَةٌ</span></span>, <span class="auth">(Ṣ, A,)</span> or<span class="arrow"><span class="ar long">مَأْرَبٌ↓ لَا حَفَاوَةٌ</span></span>, <span class="auth">(M,)</span> is a proverb, <span class="auth">(Ṣ, A,)</span> meaning He only honours thee <em>for the sake of something which he wants</em> of thee; <em>not for love</em> of thee: <span class="auth">(A, Meyd:)</span> or only thy <em>want</em> brought thee; <em>not</em> the object of <em>paying extraordinary honour</em> to me. <span class="auth">(M.)</span> <span class="add">[See also Freytag's Arab. Prov., ii. 690.]</span> You say also,<span class="arrow"><span class="ar long">أَلْحِقْ بِمَأْرَبِكَ↓ مِنَ الأَرْضِ</span></span>, meaning, <em>Go thou whither thou wilt;</em> <span class="add">[<em>so as to attain thy want</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaribN">
				<h3 class="entry"><span class="ar">أَرِبٌ</span></h3>
				<div class="sense" id="OaribN_A1">
					<p><span class="ar">أَرِبٌ</span>: <a href="#OariybN">see <span class="ar">أَرِيبٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">أَرِبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaribN_A2">
					<p>Also <span class="add">[<em>Expert; skilful:</em> (<a href="#Oariba">see <span class="ar">أَرِبَ</span></a>, of which it is the part. n.:) or]</span> <em>accustomed to,</em> or <em>practised</em> or <em>exercised in, a thing, and knowing,</em> or <em>skilful.</em> <span class="auth">(Ṣ, TA.)</span> <a href="#Arb_1">See also 1</a>, in the latter part of the paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">أَرِبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaribN_B1">
					<p><span class="ar long">أَرِبٌ بِشَىْ ءٍ</span>, <span class="add">[or <span class="ar long">إِلَى شَىْءٍ</span>, (<a href="#Oariba">see <span class="ar">أَرِبَ</span></a>,)]</span> or<span class="arrow"><span class="ar">آرِبٌ↓</span></span>, of the measure <span class="ar">فَاعِلٌ</span>, <span class="auth">(Mṣb,)</span> <em>Wanting, needing,</em> or <em>desiring, a thing.</em> <span class="auth">(Mṣb,* TA in art. <span class="ar">مهر</span>, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OurobapN">
				<h3 class="entry"><span class="ar">أُرْبَةٌ</span></h3>
				<div class="sense" id="OurobapN_A1">
					<p><span class="ar">أُرْبَةٌ</span>: <a href="#IirobN">see <span class="ar">إِرْبٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">أُرْبَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OurobapN_B1">
					<p><a href="#OarabN">and <span class="ar">أَرَبٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IirobapN">
				<h3 class="entry"><span class="ar">إِرْبَةٌ</span></h3>
				<div class="sense" id="IirobapN_A1">
					<p><span class="ar">إِرْبَةٌ</span>: <a href="#IirobN">see <span class="ar">إِرْبٌ</span></a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">إِرْبَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IirobapN_B1">
					<p><a href="#OarabN">and <span class="ar">أَرَبٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ourabae">
				<h3 class="entry"><span class="ar">أُرَبَى</span></h3>
				<div class="sense" id="Ourabae_A1">
					<p><span class="ar">أُرَبَى</span> <em>Calamity; misfortune:</em> <span class="auth">(T, Ṣ, M, A, Ḳ:)</span> <span class="add">[said to be]</span> the only word of this measure except <span class="ar">أُرَمَى</span> and <span class="ar">شُعَبَى</span> <span class="add">[names of two places]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OurobaAnN">
				<h3 class="entry"><span class="ar">أُرْبَانٌ</span></h3>
				<div class="sense" id="OurobaAnN_A1">
					<p><span class="ar">أُرْبَانٌ</span> <span class="auth">(M, Ḳ)</span>: <a href="#EurobaAnN">dial. var. of <span class="ar">عُرْبَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OurobuwnN">
				<h3 class="entry"><span class="ar">أُرْبُونٌ</span></h3>
				<div class="sense" id="OurobuwnN_A1">
					<p><span class="ar">أُرْبُونٌ</span> <span class="auth">(TA)</span>: <a href="#EurobuwnN">dial. var. of <span class="ar">عُرْبُونٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OarabuwnN">
				<h3 class="entry"><span class="ar">أَرَبُونٌ</span></h3>
				<div class="sense" id="OarabuwnN_A1">
					<p><span class="ar">أَرَبُونٌ</span> <span class="auth">(TA)</span>: <a href="#EarabuwnN">dial. var. of <span class="ar">عَرَبُونٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OariybN">
				<h3 class="entry"><span class="ar">أَرِيبٌ</span></h3>
				<div class="sense" id="OariybN_A1">
					<p><span class="ar">أَرِيبٌ</span> <em>Cunning, characterized by intelligence with craft and forecast,</em> or simply <em>intelligent</em> <span class="add">[as in the Ṣ]</span>, <em>excellent in judgment, sagacious,</em> <span class="auth">(T, Ṣ,* M, Ḳ,)</span> <em>and knowing in affairs;</em> <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar">أَرِبٌ↓</span></span>: <span class="auth">(Ḳ:)</span> pl. of the former <span class="ar">أَرَبَآءُ</span>. <span class="auth">(T, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارب</span> - Entry: <span class="ar">أَرِيبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OariybN_B1">
					<p><span class="ar long">قِدْرٌ أَرِيبَةٌ</span> <em>A wide, an ample,</em> or <em>a capacious, cooking-pot.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mrabu">
				<h3 class="entry"><span class="ar">آرَبُ</span></h3>
				<div class="sense" id="Mrabu_A1">
					<p><span class="ar">آرَبُ</span> <em>More,</em> or <em>most, cunning,</em> or <em>intelligent, excellent in judgment,</em> or <em>sagacious.</em> <span class="auth">(A.)</span><span class="add">[<a href="#OariybN">See <span class="ar">أَرِيبٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MribN">
				<h3 class="entry"><span class="ar">آرِبٌ</span></h3>
				<div class="sense" id="MribN_A1">
					<p><span class="ar">آرِبٌ</span>: <a href="#OaribN">see <span class="ar">أَرِبٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOorabN">
				<h3 class="entry"><span class="ar">مَأْرَبٌ</span></h3>
				<div class="sense" id="maOorabN_A1">
					<p><span class="ar">مَأْرَبٌ</span>: <a href="#OarabN">see <span class="ar">أَرَبٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOorabapN">
				<h3 class="entry"><span class="ar">مَأْرَبَةٌ</span> / 
							<span class="ar">مَأْرُبَةٌ</span> / 
							<span class="ar">مَأْرِبَةٌ</span></h3>
				<div class="sense" id="maOorabapN_A1">
					<p><span class="ar">مَأْرَبَةٌ</span> and <span class="ar">مَأْرُبَةٌ</span> and <span class="ar">مَأْرِبَةٌ</span>: <a href="#OarabN">see <span class="ar">أَرَبٌ</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWarBabN">
				<h3 class="entry"><span class="ar">مُؤَرَّبٌ</span></h3>
				<div class="sense" id="muWarBabN_A1">
					<p><span class="ar">مُؤَرَّبٌ</span> A member, or limb, <em>cut off entire:</em> <span class="auth">(T:)</span> <span class="pb" id="Page_0046"></span>or an <em>entire, unbroken,</em> member, or limb: <span class="auth">(Ṣ:)</span> and anything <em>made entire, complete,</em> or <em>perfect.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">كَتِفٌ مُؤَرَّبَةٌ</span> <em>A shoulder cut off entire,</em> <span class="auth">(Mgh, TA,)</span> <em>having none of its flesh taken from it,</em> <span class="auth">(Mgh,)</span> <em>without any deficiency.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0044.pdf" target="pdf">
							<span>Lanes Lexicon Page 44</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0045.pdf" target="pdf">
							<span>Lanes Lexicon Page 45</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0046.pdf" target="pdf">
							<span>Lanes Lexicon Page 46</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
