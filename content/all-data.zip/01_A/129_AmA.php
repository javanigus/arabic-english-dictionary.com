<article class="root" id="Root_AmA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/128_Am">ام</a></span>
				<span class="ar">اما</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/130_Amt">امت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OamaA">
				<h3 class="entry"><span class="ar">أَمَا</span></h3>
				<div class="sense" id="OamaA_A1">
					<p><span class="ar">أَمَا</span>, used to denote an interrogation, is a compound of the interrogative hemzeh and the negative <span class="ar">مَا</span>: <span class="auth">(M:)</span> it is a mere interrogative <span class="add">[respecting a negative, like <span class="ar">أَلَا</span>]</span>; as in the saying, <span class="ar long">أَمَا تَسْتَحْيِى مِنَ ٱللّٰهِ</span> <span class="add">[<em>Art not thou ashamed for thyself,</em> or <em>of thyself, with respect to God?</em>]</span>. <span class="auth">(Lth, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamaA_A2">
					<p><span class="add">[IHsh says, after explaining two other usages of <span class="ar">أَمَا</span> which we have yet to mention,]</span> El-Málakee adds a third meaning of <span class="ar">أَمَا</span>, saying that it is a particle denoting <span class="ar">عَرْضٌ</span> <span class="add">[or the asking, or requiring, a thing in a gentle manner]</span>, like <span class="add">[<span class="ar">أَلَا</span> <span class="auth">(q. v.)</span> and]</span> <span class="ar">لَوْلَا</span>; and is connected peculiarly with a verb; as in <span class="ar long">أَمَا تَقُومُ</span> <span class="add">[<em>Wherefore wilt not thou do stand?</em>]</span>, and <span class="ar long">أَمَا تَفْعَلُ</span> <span class="add">[<em>Wherefore wilt not thou do</em> such a thing?]</span>; which may be explained by saying that the hemzeh is used as an interrogative to make one confess, or acknowledge, a thing, as it is in <span class="ar">أَلَمْ</span> and <span class="ar">أَلَا</span>, and that <span class="ar">مَا</span> is a negative. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamaA_A3">
					<p>It is also an inceptive word, used in the manner of <span class="ar">أَلَا</span>: <span class="auth">(M:)</span> followed by <span class="ar">أَلَا</span>, it is <em>syn. with</em> <span class="ar">أَلَا</span>: <span class="auth">(Ṣ:)</span> <span class="add">[meaning <em>Now:</em> or <em>now surely:</em> or]</span> both of these meaning <em>verily,</em> or <em>truly;</em> i. c. <span class="ar">حَقًّا</span>: and for this reason Sb allows one's saying, <span class="ar long">أَمَا إنَّه مُنْطَلقٌ</span> and <span class="ar long">أَمَا أَنَّهُ مُنْطَلقٌ</span> <span class="add">[<em>Verily,</em> or <em>truly, he is going away</em>]</span>; with kesr after the manner of <span class="ar long">أَلَا إِنَّهُ</span>, and with fet-ḥ after the manner of <span class="ar long">حَقًّا أَنَّهُ</span>: and <span class="ar long">هَمَا وَٱللّٰهِ لَقَدْ كَانَ كَذَا</span> is mentioned as meaning <span class="ar long">أَمَا وَٱللّٰهِ</span> <span class="add">[&amp;c., i. e. <em>Verily,</em> or <em>truly, by God, such a thing did indeed happen</em>]</span>; the <span class="ar">ه</span> being a substitute for the hemzeh: <span class="auth">(M:)</span> so too <span class="ar long">حَمَى وٱللّٰه</span> <span class="add">[or <span class="ar long">حَمَا وٱللّٰه</span>]</span>: <span class="auth">(Ṣgh and Ḳ in art. <span class="ar">حمى</span>:)</span> it denotes the truth of the words which follow it; as when you say, <span class="ar long">أَمَا إِنَّ زَيْدًا عَاقِلٌ</span>, meaning <em>Truly,</em> or <em>properly speaking,</em> not tropically, <em>Zeyd is intelligent;</em> and <span class="ar long">أَمَّا و ٱللّٰه قَد ضَرَبَ زَيْدٌ عَمْرًا</span> <span class="add">[<em>Truly,</em>, &amp;c., <em>by God, Zeyd beat,</em> or <em>struck, Amr</em>]</span>: <span class="auth">(Ṣ in art. <span class="ar">امو</span>:)</span> <span class="add">[in other words,]</span> it corroborates an oath and a sentence; <span class="pb" id="Page_0093"></span>as in <span class="ar long">أَمَا وَٱللّٰه لَئِنْ سْهَرْتُ لَكَ لَيْلَةً لَأَ دَعَنَّكَ نَادِمًا</span> <span class="add">[<em>Verily,</em> or <em>now surely, by God, if I remain awake for thee a night, then will I indeed leave thee repenting</em>]</span>; and <span class="ar long">أَمَا لَو عَلِمْتُ مَكَانَكَ لَأَزْعَجْتُكَ مِنْهُ</span> <span class="add">[<em>Verily,</em> or <em>now surely, if I had known thy place of being, then had I unsettled thee,</em> or <em>removed thee, from it</em>]</span>; and <span class="ar long">أَمَا إِنَّهُ لَرَجُلٌ كَرِيمٌ</span> <span class="add">[<em>Verily,</em> or <em>now surely, he is</em> <span class="auth">(emphatically)</span> <em>a generous man</em>]</span>: <span class="auth">(T:)</span> or it is an inceptive particle, used in the manner of <span class="ar">أَلَا</span>; <span class="add">[meaning <em>now:</em> or <em>now surely:</em>]</span> <span class="auth">(Mughnee:)</span> or a particle used to give notice of what is about to be said: only put before a proposition <span class="add">[as in exs. mentioned above]</span>: <span class="auth">(TA:)</span> and often occurring before an oath <span class="add">[as in exs. mentioned above]</span>: and sometimes its hemzeh is changed into <span class="ar">ه</span> or <span class="ar">ع</span>, before the oath; each with the <span class="ar">ا</span> remaining; <span class="add">[written <span class="ar">هَمَا</span> or <span class="ar">عَمَا</span>;]</span> and with the <span class="ar">ا</span> elided; <span class="add">[written <span class="ar">هَمَ</span> or <span class="ar">عَمَ</span>;]</span> or with the <span class="ar">ا</span> elided, but without the substitution; <span class="add">[written <span class="ar">أَمَ</span>;]</span> and when <span class="ar">انَّ</span> occurs after <span class="ar">أَمَا</span>, it is with kesr, as it is after <span class="ar">أَلَا</span>: and it also means <span class="ar">حَقًّا</span> <span class="add">[<em>verily,</em> or <em>truly</em>]</span>: or <span class="ar">أَحقًّا</span> <span class="add">[<em>verily?</em> or <em>truly?</em>]</span>: accord. to different opinions: and in this case, <span class="ar">انَّ</span> after it is with fet-ḥ, as it is after <span class="ar">حَقَّا</span>: accord. to Ibn-Kharoof, this is a particle: but some say that it is a noun in the sense of <span class="ar">حَقًّا</span>: and others, that it consists of two words, namely, the interrogative hemzeh and <span class="ar">مَا</span> as a noun in the sense of <span class="ar">شَىْءٌ</span>; i. e. <span class="ar long">أَذالِكَ الشَّىْءُ حَقٌّ</span> <span class="add">[<em>is that thing ture?</em>]</span>; so that the meaning is <span class="ar">أَحَقًّا</span>: <span class="add">[if so, <span class="ar long">أَمَا أَنَّه مُنْطَلقٌ</span> means <em>Verily,</em> or <em>truly, is he going away?</em>]</span> and this, which is what Sb says, is the correct opinion: <span class="ar">مَا</span> is virtually in the accus. case, as an adverbial noun, like as <span class="ar">حَقًّا</span> is literally: and <span class="ar">أَنَّ</span> with its complement is an inchoative, of which the adverbial noun is the enunciative: but Mbr says that <span class="ar">حَقًّا</span> is the inf. n. of <span class="ar">يَحِقُّ</span>, which is suppressed, and that <span class="ar">أنَّ</span> with its complement is an agent. <span class="auth">(Mughnee.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamBaA">
				<h3 class="entry"><span class="ar">أَمَّا</span></h3>
				<div class="sense" id="OamBaA_A1">
					<p><span class="ar">أَمَّا</span> is a conditional and partitive and corroborative particle; and is sometimes written <span class="ar">أَيْمَا</span>, by the change of the first <span class="ar">م</span> into <span class="ar">ى</span>. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamBaA_A2">
					<p>It is used as a conditional particle in the words of the Ḳur <span class="add">[ii.24]</span>, <span class="ar long">فأَمَّا الَّذِينَ آمَنُوا فَيَعْلَمُونَ أَنَّهُ الْحَقُّ مِنْ رَبِّهِمْ وَأَمَّا الَّذِينَ كَفَرُوا فَيَقُولُونَ مَا ذَا أَرَادَ ٱللّٰهُ بِهذَا مَثَلاً</span> <span class="add">[<em>For as for those who have believed, they know that it is the truth from their Lord; but as for those who have disbelieved, they say, What is it that God meaneth by this as a parable</em>?]</span>. <span class="auth">(Mughnee,* Ḳ,* TA.)</span> That it denotes a condition is shown by the necessary occurrence of <span class="ar">ف</span> after it; for if this <span class="ar">ف</span> were a conjunction, it would not be prefixed to the enunciative; and if it were redundant, it might be dispensed with; but it may not be dispensed with except in a case of necessity in poetry or in a case of an ellipsis.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamBaA_A3">
					<p>In most cases, <span class="auth">(Mughnee, Ḳ,)</span> it is used as a partitive, <span class="auth">(Ṣ, Mughnee, Ḳ,)</span> implying the meaning of a condition; <span class="auth">(Ṣ; <span class="add">[in which it is mentioned with <span class="ar">أَمَا</span>;]</span>)</span> and thus it is used in the passage of the Ḳur cited above; <span class="auth">(Mughnee;)</span> and in the following exs. <span class="add">[in the Ḳur xviii. 78 and 79 and 81]</span>, <span class="ar long">أَمَّا السَّفِينَةُ فَكَانَتْ لِمَسَاكِينَ يَعْمَلُونَ فِى البَحْرِ</span> and <span class="ar long">وَأَمَا الْغُلَامُ فَكَانَ أَبَوَاهُ مُؤْمِنِينَ</span> and <span class="ar long">وأَمَّا الْجِدَارُ فَكَانَ لِغلَامَينِ يَتَيمَيْنِ</span> <span class="add">[<em>As for the ship, it belonged to poor men who worked on the sea … and as for the boy, his two parents were believers … and as for the wall, it belonged to two orphan boys</em>]</span>. <span class="auth">(Mughnee,* Ḳ,* TA.)</span> <span class="add">[It is a partitive also in the phrase <span class="ar long">أَمَّا بَعْدُ</span>, <a href="#baEodu">which see</a> <a href="index.php?data=02_b/141_bEd">in art. <span class="ar">بعد</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OamBaA_A4">
					<p>Few have mentioned its use as a corroborative: <span class="auth">(Mughnee:)</span> it is thus used in the phrase <span class="ar long">أَمَّا زَيْدٌ فَذَاهِبٌ</span> <span class="add">[<em>Whatever be the case,</em> or <em>happen what will</em> or <em>what may,</em> or <em>at all events, Zeyd is going away</em>]</span>, when you mean that Zeyd is inevitably going away, and determined, or decided, upon doing so: <span class="auth">(Z cited in the Mughnee, and Ḳ:)</span> therefore Sb explains it as meaning, in this case, <span class="ar long">مَهْمَا يَكُنْ مِنْ شَىْءٍ</span> <span class="add">[<em>whatever be the case,</em>, &amp;c., as above, or, in some instances, <em>happen what would</em> or <em>what might</em>]</span>; thereby showing it to be a corroborative, and to have a conditional meaning: <span class="auth">(Z cited in the Mughnee: <span class="add">[and the same explanation of it is given, with a similar ex., in the Ṣ, in art. <span class="ar">امو</span>:]</span>)</span> the <span class="ar">فَ</span>, in this case, is transferred from its proper place before the inchoative, and put before the enunciative. <span class="auth">(I'AK p. 306.)</span> Ks says that <span class="ar">أَمَّا</span> is used in commanding and forbidding and announcing: you say, <span class="ar long">أَمَّا ٱللّٰهَ فَاعْبُدْ</span> <span class="add">[<em>Whatever be the case,</em> or <em>happen what will,</em>, &amp;c., <em>God worship thou</em>]</span>: and <span class="ar long">أَمَّا الخَمْرَ فَلَا تَشْرَبْهَا</span> <span class="add">[i. e. <span class="ar long">أَمَّا الخَمْرَ فَلَا تَشْرَبْهَا</span> <span class="auth">(as is shown in the case of a similar ex. in the Mughnee, though you may say <span class="ar long">أَمَّا الخَمْرُ فَلَا تَشْرَبْهَا</span>, without an ellipsis, like as you say <span class="ar long">أمَّا ثَمُودُ فَهَدَيْنَاهُمْ</span> as well as <span class="ar long">أَمَّا ثَمُودَ</span>, in the Ḳur xli. 16, accord. to different readers,)</span> <em>Whatever be the case,</em>, &amp;c., <em>wine</em> (<em>drink not</em>), <em>drink not thou it</em>]</span>: and <span class="ar long">أَمَّا زَيْدٌ فَخَرَجَ</span> <span class="add">[<em>Whatever be the case,</em>, &amp;c., <em>with respect to other things, Zeyd has gone forth;</em> or <em>whatever be the case with respect to others, as for Zeyd, he has gone forth</em>]</span>: whereas <span class="ar">إِمَّا</span> <span class="add">[which see in the next paragraph]</span> is used in expressing a condition and in expressing doubt and in giving option and in taking option. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OamBaA_A5">
					<p><span class="add">[IHsh says that in his opinion,]</span> in the phrase <span class="ar long">أَمَّا العَبِيدَ فَذُو عَبِيدٍ</span>, thus heard, with <span class="ar">العبيد</span> in the accus. case, the meaning is, <span class="ar long">مَهَما ذَكَرْتَ</span> <span class="add">[&amp;c., i. e. <em>Whenever thou mentionest the slaves, he is a possessor of slaves:</em> but I would rather say that the meaning is, <span class="ar long">أَمَّا ذِكْرُكَ العَبِيدَ</span>, &amp;c., i. e. <em>as for thy mentioning the slaves,</em>, &amp;c.]</span>: and so in similar phrases which have been heard. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamBaA_B1">
					<p>Distinct from the foregoing is <span class="ar">أَمَّا</span> in the saying in the Ḳur <span class="add">[xxvii. 86]</span>, <span class="ar long">أَمَّا ذاكُنْتُمْ تَعمَلُونَ</span> <span class="add">[<em>Or rather, what is it that ye were doing?</em>]</span>: for here it is a compound of the unconnected <span class="ar">أَمْ</span> and the interrogative <span class="ar">مَا</span> <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OamBaA_C1">
					<p>So too in the saying of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَبَا خُرَاشَةَ أَمَّا أَنْتَ ذَا نَسفَرٍ</span> *</div> 
						<div class="star">* <span class="ar long">فَإنَّ قُوْمِىَ لَمْ تَأكُلْهُمُ الضَّبُعُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O Aboo-Khurásheh, because thou wast possessor of a number of men</em> dost thou boast? <em>Verily, my people, the year of dearth,</em> or <em>of sterility, hath not consumed them</em>]</span>: for here it is a compound of the <span class="ar">أَنْ</span> termed <span class="ar">مَصُدَرِيَّة</span> <span class="add">[which combines with a verb following it to form an equivalent to an inf. n.]</span> and the redundant <span class="ar">مَا</span>: <span class="ar long">أَمَّا أَنْتَ</span> is for <span class="ar long">لِأَنْ كُنْتَ</span>; the preposition and the verb are suppressed for the sake of abridgment, so that the pronoun <span class="add">[<span class="ar">تَ</span> in <span class="ar">كُنْتَ</span>]</span> becomes separate; and <span class="ar">مَا</span> is substituted for the verb <span class="add">[thus deprived of its affixed pronoun]</span>, and the <span class="ar">ن</span> <span class="add">[of <span class="ar">ان</span>]</span> is incorporated into the <span class="ar">م</span> <span class="add">[of <span class="ar">ما</span>]</span>. <span class="auth">(Mughnee.)</span> <span class="add">[See another reading of this verse voce <span class="ar">إِمَّا</span>; and there also, immediately after, another ex. <span class="auth">(accord. to the Mughnee)</span> of <span class="ar">أَمَّا</span> used in the manner explained above. <a href="#Oano">See also <span class="ar">أَنْ</span></a> as a conditional particle, like <span class="ar">إِنْ</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">أَمَّا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="OamBaA_D1">
					<p>Also <em>i. q.</em> <span class="ar">إِمَّا</span>, q. v. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimBaA">
				<h3 class="entry"><span class="ar">إِمَّا</span></h3>
				<div class="sense" id="IimBaA_A1">
					<p><span class="ar">إِمَّا</span> is sometimes written <span class="ar">أَمَّا</span>, and sometimes its first <span class="ar">م</span> is changed into <span class="ar">ى</span>, <span class="add">[forming <span class="ar">أَيْمَا</span> or <span class="ar">إِيْمَا</span> or both, as will be shown below,]</span> <span class="auth">(Mughnee, <span class="add">[in my copy of which it is written <span class="ar">أَيْمَا</span>, and so in some copies of the Ḳ,]</span> and Ḳ, <span class="add">[in some copies of which it is written <span class="ar">إيمَا</span>,]</span>)</span> and it is held by Sb to be a compound of <span class="ar">إِنْ</span> and <span class="ar">مَا</span>, <span class="auth">(Mughnee,)</span> or as denoting the complement of a condition it is a compound of <span class="ar">إِنْ</span> and <span class="ar">مَا</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IimBaA_A2">
					<p>It denotes doubt; <span class="auth">(Ks, T, Mughnee, Ḳ;)</span> as in <span class="ar long">مَا أَدْرِى مَنْ قَامَ إِمَّا زَيْدٌ وَإِمَّا عَمْرٌو</span> <span class="add">[<em>I know not who stood: either Zeyd or ʼAmr</em>]</span>: <span class="auth">(Ks, T:)</span> and <span class="ar long">جَآءَنِى إِمَّا زَيْدٌ وَإِمَّا عَمْرٌو</span> <span class="add">[<em>There came to me either Zeyd or ʼAmr</em>]</span>, said when one knows not which of them came. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IimBaA_A3">
					<p>It also denotes vagueness of meaning; as in <span class="add">[the Ḳur ix. 107,]</span> <span class="ar long">إِمَّا يُعَذِّبُهُم وأمَّا يَتُوبُ عَلَيْهِمْ</span> <span class="add">[<em>Either He will punish them or He will turn unto them with forgiveness</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IimBaA_A4">
					<p>It also denotes giving option; as in <span class="add">[the Ḳur xviii. 85,]</span> <span class="ar long">إِمَّا أَن تُعَذِّبَ وإِمَّا أَنْ تَتَّخِذَ فِيِهِمْ حُسْناً</span> <span class="add">[<em>Either do thou punish, or do thou what is good to them</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IimBaA_A5">
					<p>It also denotes the making a thing allowable; as in <span class="ar long">تَعَلَّمْ إِمَّا فِقْهًا وإِمَّا نَحْوًا</span> <span class="add">[<em>Learn thou either low or syntax;</em> <span class="auth">(an ex. given in the T, on the authority of Ks, as an instance of the usage of <span class="ar">إِمَّا</span> to denote giving option;)</span>]</span> but its use with this intent is disputed by some, <span class="auth">(Mughnee, Ḳ,)</span> while they assert it of <span class="ar">أَوْ</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IimBaA_A6">
					<p>It is also used as a partitive; as in <span class="add">[the Ḳur lxxvi. 3,]</span> <span class="ar long">إمَّا شَاكِراً و إمَّا كَفُورًا</span> <span class="add">[<em>Either,</em> or <em>whether, being thankful or being unthankful</em>]</span>; <span class="auth">(Mughnee, Ḳ;)</span> the two epithets being here in the accus. case as denotatives of state: or, accord. to the Koofees, <span class="ar">إمَّا</span> may be here <span class="add">[a compound of]</span> the conditional <span class="ar">إِنْ</span> and the redundant <span class="ar">مَا</span>; <span class="ar">كَانَ</span>, accord. to Ibn-EshShejeree, being understood after it: <span class="auth">(Mughnee:)</span> and Fr says that the meaning is, <span class="ar long">إِنْ شَكَرَ وَإِنْ كَفَرَ</span> <span class="add">[<em>if he be thankful and if he be unthankful</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="IimBaA_A7">
					<p>It also denotes taking option; as in the saying, <span class="ar long">لِى دَارٌ بِالكُوفَةِ فَأنَا خَارِجٌ إلَيْهَا فَإمَّا أَنْ أَسْكُنَهَا وإِمَّا أَنْ أَبِيعَهَا</span> <span class="add">[<em>I have a house in El-Koofeh, and I am going forth to it, and either I will inhabit it or I will sell it:</em> but this is similar to the usage first mentioned above]</span>. <span class="auth">(Ks, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="IimBaA_A8">
					<p>It is a conjunction, <span class="auth">(Ṣ in art. <span class="ar">امو</span>, and Mughnee,)</span> accord. to most authorities, i. e., the second <span class="ar">إِمَّا</span> in the like of the saying, <span class="ar long">جَاءَنِى إمَّا زَيْدٌ وإِمَّا عَمْرٌو</span> <span class="add">[mentioned above]</span>; <span class="auth">(Mughnee;)</span> <span class="pb" id="Page_0094"></span>used in the manner of <span class="ar">أَوْ</span> in all its cases except this one, that in the use of <span class="ar">او</span> you begin with assurance, and then doubt comes upon you; whereas you begin with <span class="ar">إِمَّا</span> in doubt, and must repeat it; as in the saying last mentioned: <span class="auth">(Ṣ: <span class="add">[and the like is said in the Mughnee, after the explanations of the meanings:]</span>)</span> but some assert that it is like the first <span class="ar">إِمَّا</span>, not a conjunction; because it is generally preceded by the conjunction <span class="ar">و</span>: and some assert that <span class="ar">إِمَّا</span> conjoins the noun with the noun, and the <span class="ar">و</span> conjoins <span class="ar">إِمَّا</span> with <span class="ar">إِمَّا</span>; but the conjoining of a particle with a particle is strange. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="IimBaA_A9">
					<p>Sometimes the <span class="ar">و</span> is suppressed; as in the following verse, <span class="auth">(Mughnee,)</span> of El-Ahwas; <span class="auth">(Ṣ;)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا لَيْتَمَا أُمُّنِا شَالَتْ نَعَامَتُهَا</span> *</div> 
						<div class="star">* <span class="ar long">أَيْمَا إِلَى جَنَّةٍ أَيْمَا إِلَى نَارِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O, would that our mother took her departure, either to Paradise or Hell-fire!</em>]</span>; <span class="auth">(Ṣ,* Mughnee, Ḳ;)</span> cited by Ks, with <span class="ar">ايما</span> for <span class="ar">إِمَّا</span>: <span class="auth">(T:)</span> and sometimes it is with kesr <span class="add">[i. e. <span class="ar">إِيمَا</span>]</span>: <span class="auth">(Ṣ:)</span> IB says that it is correctly <span class="ar">إِمَّا</span>, with kesr; asserting the original to be <span class="ar">إِمَّا</span>, with kesr, only. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="IimBaA_A10">
					<p>And sometimes the former <span class="ar">مَا</span> is dispensed with; as in the following verse, <span class="auth">(Mughnee,)</span> which shows also that <span class="ar">مَا</span> is sometimes suppressed;</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">سَقَتْهُ ارَّوَاعِدُ مِنْ صَيِّفٍ</span> *</div> 
						<div class="star">* <span class="ar long">وَإِنْ مِنْ خَرِيفٍ فَلَنْ يَعْدَمَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>The thundering clouds of summer-rain watered him, or of autumn-rain; so he will not want</em> sufficient drink]</span>: i. e. <span class="ar long">إِمَّا مِنْ صَيِّفٍ وَإِمَّا مِنْ خَرِيفٍ</span>. <span class="auth">(Mughnee, Ḳ.)</span> Mbr and Aṣ say that <span class="ar">إِنْ</span> is here conditional, and that the <span class="ar">ف</span> is its complement: but this assertion is of no weight; for the object is the description of a mountain-goat as having sufficient drink in every case: AO says that <span class="ar">إِنْ</span> in this verse is redundant. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="IimBaA_A11">
					<p>Sometimes, also, one does not require to mention the second <span class="ar">إِمَّا</span>, by mentioning what supplies its place; as in the saying, <span class="ar long">إِمَّا أَنْ تَتَكَلَّمَ بِخَيْرٍ وَإِلَّا فاسْكُتْ</span> <span class="add">[<em>Either do thou speak what is good or else be silent</em>]</span>. <span class="auth">(Mughnee.)</span> <span class="add">[<a href="index.php?data=01_A/116_AlA">See art. <span class="ar">الا</span></a>, near its end.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IimBaA_B1">
					<p>Distinct from the foregoing is <span class="ar">إِمَّا</span> in the saying in the Ḳur <span class="add">[xix. 26]</span>, <span class="ar long">فَإِمَّأِتَريِنَّ مِنَ الْبَشَرِ أَحَدًاِ</span> <span class="add">[<em>And if thou see, of mankind, any one</em>]</span>: for this is <span class="add">[a compound of]</span> the conditional <span class="ar">إِن</span> and the redundant <span class="ar">مَا</span>. <span class="auth">(Ṣ* in art. <span class="ar">امو</span>, and Mughnee.)</span> <span class="add">[In like manner,]</span> you say, in expressing a condition, <span class="ar long">إِمَّا تَشْتِمَنَّ زْيدًا فَإِنَّهُ يَحْلُمُ عَنْكَ</span> <span class="add">[<em>If thou revile Zeyd, he will treat thee with forbearance</em>]</span>. <span class="auth">(Ks, T.)</span> And <span class="ar long">إِمَّا تَأْتِنِى أُكْرِمْكَ</span> <span class="add">[<em>If thou come to me, I will treat thee with honour</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="IimBaA_B2">
					<p>In the following saying, <span class="ar long">إِمَّا أَنْتَ مُنْطَلِقًا انْطَلَقْتُ</span> <span class="add">[<em>If thou be going away, I go away</em>]</span>, the <span class="ar">مَا</span> is not that which restrains the particle to which it is subjoined from governing, but is a substitute for a verb; <span class="auth">(Ḳ and TA in art. <span class="ar">مَا</span>;)</span> as though the speaker said, <span class="ar long">إِذَا صِرْتَ مُنْطَلِقًا</span> <span class="add">[or rather <span class="ar long">إِنْ صِرْتَ</span>]</span>. <span class="auth">(TA in that art.)</span> And hence the saying of the poet, <span class="add">[of which a reading different from that here following has been given voce <span class="ar">أَمَّا</span>,]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَبَا خُرَاشَةَ إِمَّا أَنْتَ ذَا نَسفَرٍ</span> *</div> 
						<div class="star">* <span class="ar long">فَإنَّ قَوْمِىَ لَمْ تَإْكُلْهُمُ الضَّبُغُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O Aboo-Khurásheh, if thou be possessor of a number of men, verily, my people, the year of dearth,</em> or <em>of sterility, hath not consumed them</em>]</span>; as though he said, <span class="ar long">إِنْ كُنْتُ ذَا نَفَرٍ</span>. <span class="auth">(TA in that art.)</span> <span class="add">[But IHsh states the case differently; saying,]</span> An instance of <span class="ar long">أَمَّا أَنْتَ مُنطَلِقًا انْطَلَقْتُ</span> not used to restrain from governing, but as a substitute for a verb, occurs in the saying, <span class="ar long">أَمَّا أَنْتَ مُنطَلِقًا اِنْطَلَقْتُ</span> <span class="add">[<em>Because thou wast going away, I went away</em>]</span>; originally, <span class="ar long">اِنْطَلَقْتُ لِأَنْ كُنْتَ مُنطَلِقاً</span>: <span class="add">[for an explanation of which, see what is said of <span class="ar long">أَمَّا أَنْتَ</span> in a reading of the verse commencing with <span class="ar long">أَبَا خُرَاشَة</span> voce <span class="ar">أَمَّا</span>:]</span> but accord. to El-Fárisee and IJ, the government belongs to <span class="ar">مَا</span>; not to <span class="ar">كَانَ</span> <span class="add">[or <span class="ar">كُنْتَ</span>]</span>. <span class="auth">(Mughnee in art. <span class="ar">مَا</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اما</span> - Entry: <span class="ar">إِمَّا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="IimBaA_B3">
					<p>So too in the saying, <span class="ar long">اِفْعَلْ هذَا إِمَّالَا</span>, meaning <span class="ar long">إِنْ كُنْتَ لَاتَفْعَلُ غَيْرَهُ</span> <span class="add">[i. e. <em>Do thou this if thou wilt not do another thing;</em> or <em>do thou this at least</em>]</span>; <span class="auth">(Mughnee and Ḳ, each in art. <span class="ar">مَا</span>;)</span> indicating a person's refusal to do <span class="add">[fully]</span> that which he is ordered to do: <span class="auth">(TA in that art.:)</span> or <span class="ar long">إِمَّالَا فَافْعَلْ كَذَا</span>, meaning <em>if thou wilt not do that, then do thou this;</em> the three particles <span class="add">[<span class="ar">إِنْ</span> and <span class="ar">مَا</span> and <span class="ar">لَا</span>]</span> being made as one word: so says Lth: <span class="auth">(T:)</span> <span class="add">[J says,]</span> <span class="ar long">إِمَّالَا فَافْعَلْ كَذَا</span> is pronounced with imáleh, <span class="add">[i. e. “immá-lè,”]</span> and is originally <span class="ar long">إِن لَا</span> with <span class="ar">مَا</span> as a connective; and the meaning is, <em>if that thing will not be, then do thou thus:</em> <span class="auth">(Ṣ in art. <span class="ar">لَا</span>:)</span> <span class="add">[but]</span> AḤát <span class="add">[disallows this pronunciation, and]</span> says, sometimes the vulgar, in the place of <span class="ar long">اِفْعَلْ ذٰلِكَ إِمَّالَا</span>, say, <span class="ar long">اِفْعَلْ ذٰلِكَ بَارِى</span> <span class="add">[<em>Do thou that at least</em>]</span>; but this is Persian, and is rejected as wrong: and they say also, <span class="ar">أُمَّالَىْ</span>, with damm to the <span class="ar">ا</span> <span class="add">[and with imáleh in the case of the final vowel, and thus it is vulgarly pronounced in the present day]</span>; but this too is wrong; for it is correctly <span class="ar">إِمَّالَا</span>, <span class="add">[with kesr, and]</span> not pronounced with imáleh, for particles <span class="add">[in general]</span> are not thus pronounced: <span class="auth">(T:)</span> and the vulgar also convert the hemzeh into <span class="ar">ه</span> with damm <span class="add">[saying <span class="ar">هُمَّالَىْ</span>]</span>. <span class="auth">(TA in art. <span class="ar">مَا</span>.)</span> <span class="add">[Fei says,]</span> <span class="ar">لَا</span> is a substitute for the verb in the saying, <span class="ar long">إِمَّالَا فَافْعَلْ هٰذَا</span>, the meaning being <em>If thou do not that, then</em> <span class="add">[<em>at least</em>]</span> <em>do thou this:</em> the origin thereof is this; that certain things are incumbent on a man to do, and he is required to do them, but refuses; and then one is content with his doing some, or a part, of them, and says to him thus: i. e., <em>if thou wilt not do all, then do thou this:</em> then the verb is suppressed, on account of the frequency of the usage of the phrase, and <span class="ar">مَا</span> is added to give force to the meaning: and some say that it is for this reason that <span class="ar">لَا</span> is here pronounced with imáleh; because it serves for the verb; like as <span class="ar">بَلَى</span> is, and the vocative <span class="ar">يَا</span>: but it is said that it is correctly pronounced without imáleh; because particles <span class="add">[in general]</span> are not pronounced therewith; as Az says. <span class="auth">(Mṣb in art. <span class="ar">لَا</span>.)</span> <span class="add">[El-Ḥareeree says that]</span> <span class="ar">إِمَّالَا</span> is properly <span class="add">[a compound of]</span> three particles, which are <span class="ar">إِنْ</span> and <span class="ar">مَا</span> and <span class="ar">لَا</span>, made as one word, and the <span class="ar">ا</span> at the end thereof is like the <span class="ar">ا</span> of <span class="ar">حُبَارَى</span> <span class="add">[in which it is written <span class="ar">ى</span>, agreeably with rule]</span>; wherefore it is pronounced with imáleh, like as is the <span class="ar">ا</span> of this latter word. <span class="auth">(Durrat el-Ghowwáṣ, in De Sacy's Anthol. Gr. Ar. p. 57 of the Arabic text.)</span> In the Lubáb it is said that <span class="ar">لَا</span> is used as a negative of the future, as in <span class="ar long">لا تَفْعَلْ</span>; and the verb <span class="add">[in <span class="ar">إِمَّالَا</span>]</span> is suppressed; so it <span class="add">[<span class="ar">لا</span>]</span> serves as a substitute in the saying, <span class="ar long">اِفْعَلْ هٰذَا إِمَّالَا</span>; therefore they pronounce its <span class="ar">ا</span> with imáleh: and IAth says that the Arabs sometimes pronounced <span class="ar">لَا</span> with a slight imáleh; and the vulgar make the imáleh thereof full, so that its <span class="ar">ا</span> becomes <span class="ar">ى</span>; but this is wrong. <span class="auth">(TA.)</span> You say also, <span class="ar long">خُذْ هٰذَا إِمَّالَا</span>, meaning <em>Take thou this if thou take not that.</em> <span class="auth">(T.)</span> It is related that the Prophet saw a runaway camel, and said, “To whom belongeth this camel?” when, lo, some young men of the Ansár said, “We have drawn water upon him during twenty years, and yet he has in him fat; so we desired to slaughter him; but he escaped from us.” He said, “Will ye sell him?” They answered, “No: but he is thine.” And he said, <span class="ar long">إِمَّالَا فأَحْسِنُوا إِلَيْهِ حَتَّى يأْتِيَهُ أَجَلُهُ</span>, meaning <em>If ye will not sell him, act well to him until his term of life come to him.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0092.pdf" target="pdf">
							<span>Lanes Lexicon Page 92</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0093.pdf" target="pdf">
							<span>Lanes Lexicon Page 93</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0094.pdf" target="pdf">
							<span>Lanes Lexicon Page 94</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
