<article class="root" id="Root_Atm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/013_Atb">اتب</a></span>
				<span class="ar">اتم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/015_Atn">اتن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Atm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أتم</span></h3>
				<div class="sense" id="Atm_1_A1">
					<p><span class="ar">أَتْمٌ</span>, <span class="auth">(M, Ḳ,)</span> in, or in relation to, a <span class="ar">سِقَآء</span> <span class="add">[or skin for water or milk]</span>, <span class="auth">(TA,)</span> signifies The <em>having two punctures of a seam</em> (<span class="ar">خُزْرَتَانِ</span>) <em>rent so as to become one.</em> <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">أَتَمَتِ القِرْبَةٌ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْتِمُ</span>}</span></add>, inf. n. <span class="ar">أَتْمٌ</span>, <em>The water-skin had its two punctures</em> (<span class="ar">خزرتاها</span> <span class="add">[or rather <em>two of its punctures,</em> agreeably with the explanation of the inf. n. in the M and Ḳ, as given above,]</span>) <em>rent so that they became one.</em> <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Atm_1_A2">
					<p><span class="add">[And hence,]</span> The <em>meeting together of the</em> <span class="ar">مَسْلَكَانِ</span> <span class="add">[or <em>vagina and rectum</em>]</span>: whence <span class="ar">أَتُومٌ</span> <span class="add">[q. v.]</span> as an epithet applied to a woman. <span class="auth">(Ḥam p. 373.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Atm_1_A3">
					<p><span class="add">[It seems to be indicated in the T, that one says, <span class="ar long">أَتِمَ النِسَآءُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْتَمُ</span>}</span></add>, and <span class="ar">أَتَمَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْتِمُ</span>}</span></add>; as meaning, or perhaps the former only, <em>The women assembled,</em> or <em>came together:</em> for I there find, immediately after <span class="ar">مَأْتَمٌ</span> as signifying “a place in which women assemble,” “one says, <span class="ar">أَتِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْتَمُ</span>}</span></add>, and <span class="ar">أَتَمَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْتِمُ</span>}</span></add>:” but it is then added that, accord. to Khálid Ibn-Yezeed, <span class="ar">مأتم</span> is from <span class="ar">أَتِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْتَمُ</span>}</span></add>.]</span></p> 
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Atm_1_B1">
					<p><em>I. q.</em> <span class="ar">فَتْقٌ</span> <span class="add">[The act of <em>rending, rending asunder, ripping,</em> or <em>the like;</em> or <em>undoing the sewing</em> of a thing]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Atm_1_B2">
					<p>The act of <em>cutting.</em> <span class="auth">(Ṣgh, Ḳ.)</span> You say, <span class="ar">أَتَمَهُ</span> <em>He cut it.</em> <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Atm_1_C1">
					<p><span class="ar">أَتَمَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْتِمُ</span>}</span></add>, also signifies <em>He brought together,</em> or <em>united,</em> two things. <span class="auth">(T.)</span> <span class="add">[<a href="#OatuwmN">See <span class="ar">أَتُومٌ</span></a>, <a href="#maOotamN">and <span class="ar">مَأْتَمٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Atm_1_D1">
					<p><span class="ar long">أَتَمَ بِالمَكَانِ</span>, <span class="auth">(Ṣgh, Mṣb,)</span> with two forms of aor., <span class="add">[app. <span class="ar">ـِ</span> and <span class="ar">ـُ</span>,]</span> <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">أَتْمٌ</span>, <span class="auth">(Ṣgh, Ḳ,)</span> or <span class="ar">أُتُومٌ</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">أَتِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْتَمُ</span>}</span></add>; <span class="auth">(Mṣb;)</span> <em>He stayed, remained, dwelt,</em> or <em>abode, in the place.</em> <span class="auth">(Ṣgh, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Atm_2">
				<h3 class="entry">2. ⇒ <span class="ar">أتّم</span></h3>
				<div class="sense" id="Atm_2_A1">
					<p><a href="#Atm_4">see 4</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Atm_4">
				<h3 class="entry">4. ⇒ <span class="ar">آتم</span></h3>
				<div class="sense" id="Atm_4_A1">
					<p><span class="ar">آتَمَهَا</span>, inf. n. <span class="ar">إِيتَآمٌ</span>; and<span class="arrow"><span class="ar">أَتَّمَهَا↓</span></span>, inf. n. <span class="ar">تَأْتِيمٌ</span>; <em>He rendered her such as is termed</em> <span class="ar">أَتُوم</span>, q. v. <span class="auth">(O, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatuwmN">
				<h3 class="entry"><span class="ar">أَتُومٌ</span></h3>
				<div class="sense" id="OatuwmN_A1">
					<p><span class="ar">أَتُومٌ</span> is primarily used in relation to the <span class="ar">سِقآء</span> <span class="add">[or skin for water or milk; as meaning]</span> <em>Having two punctures of a seam</em> (<span class="ar">خُرْزَتَانِ</span>) <em>rent so that they become one.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: <span class="ar">أَتُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OatuwmN_A2">
					<p>And hence, <span class="auth">(Ṣ,)</span> or from <span class="ar">أَتَمَ</span> as meaning “he brought together, or united,” two things, <span class="auth">(T,)</span> A woman <em>whose</em> <span class="ar">مَسْلَكَانِ</span> <span class="add">[or <em>vagina and rectum</em>]</span> <em>meet together in one,</em> <span class="add">[<em>by the rupture of the part between them,</em>]</span> <span class="auth">(T, M,)</span> <em>becoming conjoined, so that the</em> <span class="ar">فَرْج</span> <em>is enlarged thereby,</em> <span class="auth">(TA,)</span> <em>on the occasion of devirgination;</em> <span class="auth">(M;)</span> <em>i. q.</em> <span class="ar">مُفْضَاةٌ</span>, <span class="auth">(T, Ṣ, M,)</span> as some say; <span class="auth">(T;)</span> or <span class="ar">مُفَاضَةٌ</span>; <span class="auth">(Ḳ; <span class="add">[said in the TA to be a mistake: but <span class="ar">مُفْضَاةٌ</span> and <span class="ar">مُفَاضَةٌ</span> are said in the M, in art. <span class="ar">فيض</span>, to have the same signification;]</span>)</span> a woman <em>whose</em> <span class="ar">مَسْلَكَانِ</span> <em>have become one:</em> <span class="auth">(Ḥam p. 271:)</span> or, as some say, <em>small in the</em> <span class="ar">فَرْجَ</span> <span class="add">[or <em>vagina</em>]</span>: <span class="auth">(M:)</span> or it has these two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOotamN">
				<h3 class="entry"><span class="ar">مَأْتَمٌ</span></h3>
				<div class="sense" id="maOotamN_A1">
					<p><span class="ar">مَأْتَمٌ</span> <a href="#Atm_1">is a quasi-inf. n. of <span class="ar">أَتَمَ</span></a> in the last of the senses explained above. <span class="auth">(Mṣb.)</span> <span class="add">[Thus it signifies <em>A staying, remaining, dwelling,</em> or <em>abiding,</em> in a place. But it more commonly signifies]</span> The <em>assembling</em> of women <span class="add">[and of men also]</span> <em>in a case of rejoicing</em> and <em>of mourning.</em> <span class="auth">(Ḥar p. 234.)</span></p>
				</div>
				<span class="pb" id="Page_0014"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: <span class="ar">مَأْتَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOotamN_A2">
					<p>It is also a noun of time from the same. <span class="auth">(Mṣb.)</span> <span class="add">[Thus it signifies <em>A time of staying</em> or <em>remaining,</em>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: <span class="ar">مَأْتَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOotamN_A3">
					<p>And it is also a noun of place from the same. <span class="auth">(Mṣb.)</span> <span class="add">[And thus it signifies <em>A place of staying</em> or <em>remaining,</em>, &amp;c. But it more commonly signifies]</span> <em>A place of assembling</em> of women <span class="add">[and of men also]</span> <em>in a case of rejoicing</em> and <em>of mourning:</em> from <span class="ar">أَتِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْتَمُ</span>}</span></add>, accord. to Khálid Ibn-Yezeed. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: <span class="ar">مَأْتَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="maOotamN_A4">
					<p>And hence, tropically, <span class="auth">(Mṣb,)</span> ‡ <em>Women assembling together</em> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ)</span> <em>in a case of rejoicing</em> and <em>of mourning,</em> <span class="auth">(T, M, Mgh, Ḳ,)</span> or <em>in a case of good</em> and <em>of evil:</em> <span class="auth">(Ṣ, Mṣb:)</span> or <em>any assembly,</em> <span class="auth">(M, Ḳ,)</span> <em>of men</em> and <em>of women,</em> <span class="auth">(M,)</span> <em>in a case of mourning</em> or <em>of rejoicing:</em> <span class="auth">(M, Ḳ:)</span> or particularly <em>of young women;</em> <span class="auth">(M, Ḳ,)</span> accord. to some; but it is not so: and some assert that the word is derived from <span class="ar">أَتْمٌ</span>, in the first of the senses explained in this art.; and from <span class="ar">أَتُومٌ</span>, as an epithet applied to a woman; because it signifies <em>women coming together, and meeting face to face, in a case of good</em> and <em>of evil:</em> <span class="auth">(M:)</span> the pl. is <span class="ar">مَآتِمُ</span>. <span class="auth">(Ṣ, Mgh.)</span> Abu-l-ʼAṭà Es-Sindee says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">عَشِيَّةَ قَامَ النَّائِحَاتُ وَشُقِّقَتْ</span> *</div> 
						<div class="star">* <span class="ar long">جُيُوبٌ بِأَيْدِى مَأْتَمٍ وَخُدُودُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>In the evening when arose the wailing women</em> to wail, <em>and openings at the necks and bosoms</em> of garments <em>were rent with the hands of assembled</em> mourning <em>women, and cheeks</em> also were lacerated]</span>: <span class="auth">(Ṣ, M, Mgh:)</span> i. e., <span class="ar long">بِأَيْدِى نِسَآءٍ</span>. <span class="auth">(Ṣ.)</span> And another says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حَتَّى تَرَاهُنَّ لَدَيْهِ قُيَّمَا</span> *</div> 
						<div class="star">* <span class="ar long">كَمَا تَرَى حَوْلَ الأَمِيرِ المأْتَمَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>So that thou seest them</em> <span class="auth">(referring to women)</span> <em>standing in his presence,</em> or <em>at,</em> or <em>by, it, like as thou seest the assembly of men around the prince,</em> or <em>commander</em>]</span>: <span class="ar">المأتم</span> here necessarily denoting men. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتم</span> - Entry: <span class="ar">مَأْتَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="maOotamN_A5">
					<p>IKt says, <span class="auth">(Mṣb,)</span> it is used by the vulgar to denote <em>An affliction,</em> or <em>evil accident;</em> <span class="auth">(Ṣ, Mgh, Mṣb;)</span> <span class="add">[and Mṭr adds,]</span> and <em>a wailing:</em> <span class="auth">(Mgh:)</span> they say, <span class="ar long">كُنَّا فِى مَإْتَمِ فَلَانٍ</span> <span class="add">[meaning <em>We were present at the affliction of such a one</em>]</span>: <span class="auth">(Ṣ, Mṣb:)</span> or <span class="ar long">كُنَّا فِى مَأْتَمِ بَنِى فُلَلنٍ</span> <span class="add">[meaning, <em>We were present at the affliction,</em> and <em>wailing, of the sons of such a one</em>]</span>: <span class="auth">(Mgh:)</span> but the correct word in this case, <span class="auth">(Ṣ, Mgh,)</span> or the better, <span class="auth">(Mṣb,)</span> is <span class="ar">مَنَاحَة</span>: <span class="auth">(Ṣ, Mgh, Mṣb:)</span> so says IAmb. <span class="auth">(Mgh.)</span> But accord. to IB, nothing forbids that it may occur in the sense of <em>A place of wailing;</em> and in the sense of <em>mourning,</em> and <em>wailing,</em> and <em>weeping;</em> for therefore do women assemble: and thus it may be in the saying of Et-Teymee, respecting Manṣoor Ibn-Ziyád,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَالنَّاسُ مَأْتَمُهُمْ عَلَيْهِ وَاحِدٌ</span> *</div> 
						<div class="star">* <span class="ar long">فِى كلِّ دَارٍ رَنَّةٌ وَزَفِيرُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>The people's mourning,</em>, &amp;c., <em>for him was one: in every house was a moaning, and a sighting</em>]</span>: and in the saying of another,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَضْحَى بَنَاتُ السُّبِىِّ إِذْ قُتِلُوا</span> *</div> 
						<div class="star">* <span class="ar long">فِى مَأْتَمٍ وَالسِّبَاعُ فِى عُرُسِ</span> *</div> 
					</blockquote>
					<p>i. e. <span class="add">[<em>The daughters of the captives, when they were slain, became, in the early part of the day,</em>]</span> <em>in a state mourning; and the beasts of prey, in a state of rejoicing.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0013.pdf" target="pdf">
							<span>Lanes Lexicon Page 13</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0014.pdf" target="pdf">
							<span>Lanes Lexicon Page 14</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
