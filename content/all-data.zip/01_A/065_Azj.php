<article class="root" id="Root_Azj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/064_Azb">ازب</a></span>
				<span class="ar">ازج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/066_Azr">ازر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azj_2">
				<h3 class="entry">2. ⇒ <span class="ar">أزّج</span></h3>
				<div class="sense" id="Azj_2_A1">
					<p><span class="ar">أزّج</span>, inf. n. <span class="ar">تَأْزِيجٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <em>He built</em> a structure of the kind called <span class="ar">أَزَجٌ</span>, <em>and made</em> it <em>long:</em> <span class="auth">(Ḳ:)</span> or <em>he built</em> a house, or chamber, <em>in the form of what is so called.</em> <span class="auth">(Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazajN">
				<h3 class="entry"><span class="ar">أَزَجٌ</span></h3>
				<div class="sense" id="OazajN_A1">
					<p><span class="ar">أَزَجٌ</span> <em>A certain kind of structure;</em> <span class="auth">(Ṣ, Ḳ;)</span> or <em>a house,</em> or <em>chamber, built in a long,</em> or <em>an oblong, form;</em> <span class="auth">(Mgh, L, Mṣb;)</span> <em>called in Persian</em> <span class="fa">أُوِسْتَانٌ</span>, <span class="auth">(Mgh, L,)</span> <em>and also, in the same language,</em> <span class="ar">سَغْ</span>, <em>and</em> <span class="ar">كَمَرْ</span>: <span class="auth">(Mgh:)</span> <span class="add">[i. e. <em>an oblong, arched,</em> or <em>vaulted, structure</em> or <em>edifice;</em> (<em>such as a bridge;</em> <a href="#qanoTarapN">see <span class="ar">قَنْطَرَةٌ</span></a>;) <em>a portico, gallery,</em> or <em>piazza;</em> accord. to Golius and Freytag, <span class="la"><em>ædificii genus oblongum et fornicatum, porticus instar;</em></span> to which Freytag adds, <span class="la"><em>portæ arcus superior:</em></span>]</span> or, accord. to some, <em>a roof:</em> <span class="auth">(Mṣb:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آزَاجٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">آزُجٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">إِزَجَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0052.pdf" target="pdf">
							<span>Lanes Lexicon Page 52</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
