<article class="root" id="Root_Akf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/111_Akr">اكر</a></span>
				<span class="ar">اكف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/113_Akl">اكل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Akf_2">
				<h3 class="entry">2. ⇒ <span class="ar">أكّف</span></h3>
				<div class="sense" id="Akf_2_A1">
					<p><span class="ar long">اكّف الإِكَافَ</span>, inf. n. <span class="ar">تَأْكِيفٌ</span>, <em>He made the</em> <span class="ar">اكاف</span>; <span class="auth">(Ḳ;)</span> as also <span class="ar">وكّفهُ</span>, inf. n. <span class="ar">تَوْكِيفٌ</span>; which latter, accord. to IF, is the original form. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akf_2_A2">
					<p><a href="#Akf_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akf_4">
				<h3 class="entry">4. ⇒ <span class="ar">آكف</span></h3>
				<div class="sense" id="Akf_4_A1">
					<p><span class="ar long">آكف الحِمَارَ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِيكَافٌ</span>, <span class="auth">(Ḳ,)</span> <em>He bound,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> or <em>put,</em> <span class="auth">(Mṣb, TA,)</span> <em>the</em> <span class="ar">إِكَاف</span> <em>upon the ass;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">أكّفهُ↓</span></span>; <span class="auth">(Ṣgh, Ḳ;)</span> and <span class="ar">اوكفهُ</span>; <span class="auth">(Ṣ, Mgh, Ḳ;)</span> which is of the dial. of the people of El-Ḥijáz; the first being of the dial. of Benoo-Temeem: and in like manner, <span class="ar">البَغْلَ</span> <em>the mule.</em> <span class="auth">(Lḥ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IikaAfN">
				<h3 class="entry"><span class="ar">إِكَافٌ</span></h3>
				<div class="sense" id="IikaAfN_A1">
					<p><span class="ar">إِكَافٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">أُكَافٌ</span>, <span class="auth">(Ḳ,)</span> as also <span class="ar">وِكَافٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and <span class="ar">وُكَافٌ</span>, <span class="auth">(Ḳ in art. <span class="ar">وكف</span>,)</span> The <span class="ar">بَرْذَعَة</span>, <span class="add">[i. e. <em>pad,</em> or <em>stuffed saddle, generally stuffed with straw,</em>]</span> <span class="auth">(Ḳ,)</span> of the ass, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> and also used for the mule, and for the camel; <span class="auth">(TA in art. <span class="ar">وكف</span>;)</span> a saddle like the <span class="ar">رَحْل</span> and <span class="ar">قَتَب</span>: <span class="auth">(TA:)</span> and <em>a saddle</em> of a horse <em>made in the form of the ass's</em> <span class="ar">اكاف</span>, <em>having at its fore part</em> <span class="add">[or <em>pommel</em>]</span> <em>a thing resembling a pomegranate:</em> <span class="auth">(Mgh:)</span> <span class="add">[<a href="#qatabN">see also <span class="ar">قَتَبٌ</span></a>:]</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آكِفَةٌ</span> <span class="auth">(TA)</span> and <span class="add">[of mult.]</span> <span class="ar">أُكُفٌ</span>. <span class="auth">(Ṣ, Mgh, Mṣb, TA.)</span> Yaạḳoob asserts that the <span class="ar">ا</span> in <span class="ar">إِكَافٌ</span> is a substitute for the <span class="ar">و</span> in <span class="ar">وِكَافٌ</span>. <span class="auth">(TA.)</span> A rájiz says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِنَّ لَنَا أَحْمِرَةً عِجَافَا</span> *</div> 
						<div class="star">* <span class="ar long">يَأْكُلْنَ كُلَّ لَيْلَةٍ إِكَافَا</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>Verily we have some lean asses</em>]</span> <em>which eat every night</em> the price of <em>an</em> <span class="ar">اكاف</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakBaAfN">
				<h3 class="entry"><span class="ar">أَكَّافٌ</span></h3>
				<div class="sense" id="OakBaAfN_A1">
					<p><span class="ar">أَكَّافٌ</span> The <em>maker of the kind of saddle called</em> <span class="ar">إِكَاف</span>. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0071.pdf" target="pdf">
							<span>Lanes Lexicon Page 71</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
