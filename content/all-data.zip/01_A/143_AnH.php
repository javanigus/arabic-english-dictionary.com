<article class="root" id="Root_AnH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/142_Anv">انث</a></span>
				<span class="ar">انح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/144_Ans">انس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AnH_1">
				<h3 class="entry">1. ⇒ <span class="ar">أنح</span></h3>
				<div class="sense" id="AnH_1_A1">
					<p><span class="ar">أَنَحَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْنِحُ</span>}</span></add>, inf. n. <span class="ar">أَنْحٌ</span> and <span class="ar">أَنِيحٌ</span> and <span class="ar">أَنُوحٌ</span>, <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>breathed hard,</em> or <em>violently, in consequence of heaviness,</em> or <em>oppression, experienced by him as an effect of disease,</em> or <em>of being out of breath,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>as though he made a reiterated hemming in his throat,</em> (<span class="ar long">كَأَنَّهُ يَتَنَحْنَحُ</span>,) <em>and did not speak clearly,</em> or <em>plainly:</em> <span class="auth">(Ṣ, TA:)</span> or <em>he made a reiterated hemming in his throat</em> (<span class="ar">تَنَحْنَحَ</span>), when asked for a thing, <em>by reason of niggardliness:</em> <span class="auth">(L:)</span> or <em>he uttered a long,</em> or <em>vehement, sigh,</em> or <em>a kind of groaning sound,</em> (<span class="ar">زَفَرَ</span>,) when asked for a thing. <span class="auth">(A.)</span> You say, <span class="ar long">يَأْنِحُ عَلَى مَالِهِ</span> <em>He utters a long,</em> or <em>vehement, sigh,</em> or <em>a kind of groaning sound, over his property</em> <span class="add">[from unwillingness to part with it]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انح</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AnH_1_A2">
					<p>It is said in a trad. of Ibn-ʼOmar, <span class="ar long">رَأَى رَجُلًا يَأْنِحُ بِبَطْنِهِ</span>, meaning, <span class="add">[it is asserted, though this seems doubtful, <em>He saw a man</em>]</span> <em>raising,</em> or <em>lifting, his belly with an effort, oppressed by its weight:</em> from <span class="ar">أُنُوحٌ</span> in the last of the senses assigned to it below. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OunBaHN">
				<h3 class="entry"><span class="ar">أُنَّحٌ</span></h3>
				<div class="sense" id="OunBaHN_A1">
					<p><span class="ar">أُنَّحٌ</span>: <a href="#AniHN">see <span class="ar">آنِحٌ</span>, with which it is syn., and of which it is also pl.</a></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OanuwHN">
				<h3 class="entry"><span class="ar">أَنُوحٌ</span></h3>
				<div class="sense" id="OanuwHN_A1">
					<p><span class="ar">أَنُوحٌ</span>: <a href="#AniHN">see <span class="ar">آنِحٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OunuwHN">
				<h3 class="entry"><span class="ar">أُنُوحٌ</span></h3>
				<div class="sense" id="OunuwHN_A1">
					<p><span class="ar">أُنُوحٌ</span>: <span class="add">[<a href="#AnH_1">see 1</a>:]</span> it is also explained as signifying <em>A sound like that which is termed</em> <span class="ar">زَفِيرٌ</span>, <em>arising from grief,</em> or <em>anger,</em> or <em>repletion of the belly,</em> or <em>jealousy:</em> <span class="auth">(L:)</span> <em>a sound accompanied by a reiterated hemming in the throat</em> (<span class="ar long">صَوْتٌ مَعَ تَنَحْنُحٍ</span>): <span class="auth">(Aṣ:)</span> and <em>a sound that is heard from a man's inside, with breathing, and a shortness of breath,</em> or <em>panting for breath, which affects fat men;</em> as also<span class="arrow"><span class="ar">أَنِيحٌ↓</span></span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaniyHN">
				<h3 class="entry"><span class="ar">أَنِيحٌ</span></h3>
				<div class="sense" id="OaniyHN_A1">
					<p><span class="ar">أَنِيحٌ</span>: <a href="#OunuwHN">see <span class="ar">أُنُوحٌ</span></a>. <span class="add">[<a href="#AnH_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OanBaAHN">
				<h3 class="entry"><span class="ar">أَنَّاحٌ</span></h3>
				<div class="sense" id="OanBaAHN_A1">
					<p><span class="ar">أَنَّاحٌ</span>: <a href="#AniHN">see <span class="ar">آنِحٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MniHN">
				<h3 class="entry"><span class="ar">آنِحٌ</span></h3>
				<div class="sense" id="MniHN_A1">
					<p><span class="ar">آنِحٌ</span> act. part. n. of 1; A man <em>breathing hard,</em> or <em>violently,</em>, &amp;c.: and a man <em>who, when he is asked for a thing, makes a reiterated hemming in his throat</em> (<span class="ar">يَتَنَحْنحُ</span>), <em>by reason of niggardliness;</em> <span class="pb" id="Page_0113"></span>as also<span class="arrow"><span class="ar">أَنُوحٌ↓</span></span>, and<span class="arrow"><span class="ar">أُنَّحٌ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">أَنَّاحٌ↓</span></span>: <span class="auth">(Lḥ:)</span> or<span class="arrow"><span class="ar">أَنُوحٌ↓</span></span> signifies a man <em>who hangs back from,</em> or <em>falls short of, doing generous deeds;</em> as also <span class="ar">أَزُوحٌ</span>: <span class="auth">(El-Ghanawee and Ṣ in art. <span class="ar">ازح</span>, and TA in the present art.:)</span> and is also applied to a horse, meaning <em>that runs, and makes a kind of groaning noise;</em> <span class="ar long">إِذَا جَرَى فَزَفَرَ</span>: this is the right reading in the Ḳ: in some copies <span class="ar long">اذا جرى قَرْقَرَ</span> <span class="add">[<em>that makes a rumbling sound in his belly when he runs</em>]</span>: <span class="auth">(TA:)</span> <a href="#AniHN">the pl. of <span class="ar">آنِحٌ</span></a> is <span class="ar">أُنَّحٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انح</span> - Entry: <span class="ar">آنِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MniHN_A2">
					<p><span class="ar">آنِحَةٌ</span>, applied to a female, signifies <em>Short.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0112.pdf" target="pdf">
							<span>Lanes Lexicon Page 112</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0113.pdf" target="pdf">
							<span>Lanes Lexicon Page 113</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
