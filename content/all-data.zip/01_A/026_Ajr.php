<article class="root" id="Root_Ajr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/025_Aj">اج</a></span>
				<span class="ar">اجر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/027_AjS">اجص</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ajr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أجر</span></h3>
				<div class="sense" id="Ajr_1_A1">
					<p><span class="ar">أَجَرَهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُرُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِرُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> which latter form of the aor., though known to most of the lexicologists, is disacknowledged by a few of them, <span class="auth">(TA,)</span> inf. n. <span class="ar">أَجْرٌ</span>; <span class="auth">(Ṣ, Mṣb;)</span> and<span class="arrow"><span class="ar">آجرهُ↓</span></span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> a form disacknowledged by Aṣ, but said by some to be the more chaste of the two, of the form <span class="ar">أَفْعَلَ</span>, not <span class="ar">فَاعَلَ</span>, as IḲṭṭ by evident inadvertence makes it to be by saying that its aor. is <span class="ar">يُؤَاجِرُ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">إِيجَارٌ</span>; <span class="auth">(Ṣ;)</span> <em>He</em> <span class="auth">(God, Ṣ, A, Mgh, Mṣb, and a man, Mgh)</span> <em>recompensed, compensated,</em> or <em>rewarded, him,</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ,)</span> <span class="ar long">عَلَى مَا فَعَلَ</span> <em>for what he had done.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#OajorN">See <span class="ar">أَجْرٌ</span>, below</a>.]</span> <span class="ar long">أُجِرَ فُلَانٌ خَمْسَةً مِنْ وَلَدِهِ</span> <span class="add">[<em>Such a one became entitled to a reward for five of his children,</em> by their death, <span class="auth">(for it is believed that the Muslim will be rewarded in Paradise for a child that has died in infancy)</span>]</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">أُجِرَ وَلَدَهُ</span>, <span class="auth">(A,)</span> and <span class="ar long">أُجِرَ فِى أَوْلَادِهِ</span>, <span class="auth">(Ḳ,)</span> mean that his children died, and became <span class="add">[causes of]</span> his reward. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ajr_1_A2">
					<p><span class="ar">أَجَرَهُ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُرُ</span>}</span></add>, <span class="auth">(Ṣ,)</span> <span class="add">[<em>He served him for hire, pay,</em> or <em>wages;</em>]</span> <em>he became his hired man,</em> or <em>hireling.</em> <span class="auth">(Ṣ, Ḳ.)</span> So in the Ḳur xxviii. 27. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ajr_1_A3">
					<p><span class="ar">أَجَرَهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُرُ</span>}</span></add>, <span class="auth">(L, Mṣb, Ḳ,)</span> and <span class="ar">ـِ</span>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَجْرٌ</span>, <span class="auth">(L, Ḳ,)</span> <em>He let him</em> <span class="auth">(namely his slave)</span> <em>on hire,</em> or <em>for pay,</em> or <em>wages;</em> <span class="auth">(L,* Mṣb,* Ḳ;)</span> as also<span class="arrow"><span class="ar">آجرهُ↓</span></span>, inf. n. <span class="ar">إِيجَارٌ</span>; <span class="auth">(ʼEyn, Mgh, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">آجرهُ↓</span></span>, inf. n. <span class="ar">مؤاجرة</span>: <span class="auth">(Ḳ:)</span> all these are good forms of speech, used by the Arabs: <span class="auth">(L:)</span> or<span class="arrow"><span class="ar">آجرهُ↓</span></span> having for its inf. n. <span class="ar">مؤاجرة</span> signifies <em>he appointed him</em> <span class="auth">(namely another man)</span> <em>hire, pay,</em> or <em>wages, for his work;</em> <span class="auth">(Mj, Mgh;)</span> or <em>he engaged with him to give him hire, pay,</em> or <em>wages;</em> <span class="auth">(A, Mgh, Mṣb;)</span> and can have only one objective complement: whereas,<span class="arrow">↓</span> when it is of the measure <span class="ar">أَفْعَلَ</span> it is doubly trans.; <span class="auth">(Mgh, Mṣb;)</span> so that one says,<span class="arrow"><span class="ar long">آجَرَنِي↓ مَمْلُوكَهُ</span></span> <em>He let me his slave on hire.</em> <span class="auth">(Mgh.)</span> One also says, <span class="ar long">أَجَرَ الدَّارَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُرُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِرُ</span>}</span></add>, inf. n. <span class="ar">أَجْرٌ</span>, <em>He let the house on hire;</em> and so<span class="arrow"><span class="ar long">آجر↓ الدَّارَ</span></span>, <span class="add">[inf. n. <span class="ar">إِيجَارٌ</span>:]</span> <span class="auth">(Mṣb, TA:)</span> and<span class="arrow"><span class="ar long">آجرهُ↓ الدَّارَ</span></span>, <span class="add">[inf. n. <span class="ar">إِيجَارٌ</span>,]</span> <em>He let to him the house on hire:</em> <span class="auth">(Ṣ, A, Mgh, Mṣb:)</span> the latter verb being of the measure <span class="ar">أَفْعَلَ</span>, not of the measure <span class="ar">فَاعَلَ</span>: <span class="auth">(A, Mgh, Mṣb:)</span> and the vulgar say, <span class="ar">وَاجَرَ</span>: <span class="auth">(Ṣ:)</span> some, however, say,<span class="arrow"><span class="ar long">آجَرْتُ↓ الدَّارَ</span></span>, inf. n. <span class="ar">مُؤَاجَرَةٌ</span>, making the verb of the measure <span class="ar">فاعل</span>: <span class="auth">(Mṣb, TA:)</span> some also say,<span class="arrow"><span class="ar long">آجَرْتُ↓ الدَّارَ زَيْدَّا</span></span> <span class="add">[<em>I let the house to Zeyd</em>]</span>, inverting the order of the words: <span class="auth">(Mṣb, TA:)</span> and the lawyers say,<span class="arrow"><span class="ar long">آجَرْتُ↓ الدَّارَ مِنْ زَيْدٍ</span></span> <span class="add">[in the same sense, like as <span class="ar long">بِعْتُ مِنْ زَيْدٍ الدَّارِ</span> means the same as <span class="ar long">بِعْتُ زَيْداً الدَّارَ</span>]</span>. <span class="auth">(Mṣb: <span class="add">[but in the Mgh, the like of this is said to be vulgar.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajr_3">
				<h3 class="entry">3. ⇒ <span class="ar">آجر</span></h3>
				<div class="sense" id="Ajr_3_A1">
					<p><span class="ar">آجر</span>, inf. n. <span class="ar">مُؤَاجَرَةٌ</span>: <a href="#Ajr_1">see 1</a>, latter half, in three places: <a href="#Ajr_1">and see 1</a>. One says also, of a woman, <span class="auth">(Ḳ,)</span> or a whorish female slave, <span class="auth">(TA,)</span> <span class="ar">آجَرَتْ</span>, <span class="add">[of the measure <span class="ar">فَاعَلَتْ</span>, not <span class="ar">أَفْعَلَتْ</span>, (<a href="#muWojirN">see <span class="ar">مُؤْجِرٌ</span>, below</a>,)]</span> meaning <em>She prostituted herself for hire.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ajr_4">
				<h3 class="entry">4. ⇒ <span class="ar">آجر</span></h3>
				<div class="sense" id="Ajr_4_A1">
					<p><span class="ar">آجر</span>, inf. n. <span class="ar">إِيجَارٌ</span>: <a href="#Ajr_1">see 1</a>, first sentence:</p>						
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ajr_4_A2">
					<p><a href="#Ajr_1">and see the latter half of the same paragraph <span class="new">{1}</span></a>, in seven places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتجر</span></h3>
				<div class="sense" id="Ajr_8_A1">
					<p><span class="ar">ائتجر</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَجَرَ</span>]</span> <em>He gave alms, seeking thereby to obtain a reward</em> <span class="add">[<em>from God</em>]</span>: <span class="auth">(L, Ḳ *:)</span> <span class="pb" id="Page_0024"></span>and <span class="ar">ائتجربِهِ</span> <em>He gave it as alms, seeking thereby a reward.</em> <span class="auth">(L.)</span> <span class="ar">ٱتَّجَرَ</span> for <span class="ar">ائتجر</span> is not allowable, because <span class="ar">ء</span> cannot be incorporated into <span class="ar">ت</span>: <span class="add">[or, accord. to some, this is allowable, as in <span class="ar">ٱتَّزَرَ</span> for <span class="ar">ائتزر</span>, and <span class="ar">ٱتَّمَنَ</span> for <span class="ar">ائتمن</span>, &amp;c.:]</span> Hr allows it; and cites an ex. in a trad.; but IAth says that the proper reading in this instance is <span class="ar">يَأْتَجِرُ</span>, not <span class="ar">يَتَّجِرُ</span>; or, if the latter be allowed, it is from <span class="ar">التِّجَارَةُ</span>, not from <span class="ar">الأَجْرُ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ajr_8_A2">
					<p><span class="ar long">اُوتُجِرَ عَلَيْهِ بِكَذَا</span> <span class="add">[in which the radical <span class="ar">ء</span> is changed into <span class="ar">و</span> because the alif preceding it is made disjunctive and with damm, <span class="auth">(in one copy of the Ṣ, and in the L and TA, erroneously written <span class="ar">اِيْتَجَرَ</span>,)</span> <em>He was hired to do it for such a sum</em> or <em>thing,</em> (<a href="#muWotajarN">see <span class="ar">مُؤْتَجَرٌ</span>, below</a>,)]</span> is from <span class="ar">الأُجْرَةُ</span>. <span class="auth">(Ṣ, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأجر</span></h3>
				<div class="sense" id="Ajr_10_A1">
					<p><span class="ar">استأجرهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">آجرهُ↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="add">[the latter of the measure <span class="ar">فَاعَلَ</span>, as has been clearly shown above, from the A and Mgh and Mṣb,]</span> <em>He hired him; took him as a hired man,</em> or <em>hireling.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span> You say also, <span class="ar long">استأجر الدَّارَ</span> <span class="add">[<em>He hired the house; took it on hire</em>]</span>. <span class="auth">(A, Mgh,)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajorN">
				<h3 class="entry"><span class="ar">أَجْرٌ</span></h3>
				<div class="sense" id="OajorN_A1">
					<p><span class="ar">أَجْرٌ</span> <em>A recompense, compensation,</em> or <em>reward,</em> <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> <em>for what one has done;</em> <span class="auth">(Ḳ;)</span> <em>i. q.</em> <span class="ar">ثَوَابٌ</span>; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">إِجَارَةٌ↓</span></span> and<span class="arrow"><span class="ar">أَجَارَةٌ↓</span></span> and<span class="arrow"><span class="ar">أُجَارَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> of which three forms the first is the most generally known and the most chaste, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">أُجْرَةٌ↓</span></span>: <span class="auth">(TA:)</span> or, as some say, there is a distinction between <span class="ar">أَجْرٌ</span> and <span class="ar">ثَوَابٌ</span>: El-ʼEynee says, in the Expos. of El-Bukháree, that what is obtained by the fundamental practices of the law, and by obligatory religious services, is termed <span class="ar">ثواب</span>; and what is obtained by supererogatory acts of religion, <span class="ar">اجر</span>; for <span class="ar">ثواب</span> is properly a substitute for a thing itself; and <span class="ar">اجر</span>, for the profit arising from a thing; though each is sometimes used in the sense of the other: <span class="auth">(TA:)</span> it is well known that <span class="ar">اجر</span> signifies <em>a recompense,</em> or <em>reward, from God to a man, for righteous conduct;</em> <span class="auth">(MF;)</span> <em>and</em> <span class="arrow"><span class="ar">إِجَارَةٌ↓</span></span>, <em>recompense, compensation, hire, pay,</em> or <em>wages, from one man to another, for work;</em> <span class="auth">(Mgh, MF;)</span> and hence <span class="ar">الأَجِيرُ</span>; <span class="auth">(MF;)</span> and<span class="arrow"><span class="ar">أُجْرَةٌ↓</span></span> also has this latter signification, <span class="auth">(Mgh, TA,)</span> and is syn. with <span class="ar">كِرَآءٌ</span>; <span class="auth">(Ṣ, Mgh, Ḳ;)</span> <span class="add">[signifying likewise <em>rent</em> for a house, and <em>the like;</em>]</span> but <span class="ar">أَجْرٌ</span> is used <span class="add">[sometimes]</span> in the sense of <span class="ar">إِجَارَةٌ</span> and in <a href="#OujorapN">that of <span class="ar">أُجْرَةٌ</span></a>: <span class="auth">(Mṣb:)</span> <a href="#OajorN">the pl. of <span class="ar">أَجْرٌ</span></a> is <span class="ar">أُجُورٌ</span> <span class="auth">(Mṣb, Ḳ)</span> and <span class="ar">آجَارٌ</span>; <span class="auth">(Ḳ;)</span> but the latter form was unknown to MF: <span class="auth">(TA:)</span> the pl. of<span class="arrow"><span class="ar">أُجْرَةٌ↓</span></span> is <span class="ar">أَجَرٌ</span> and <span class="ar">أُجُرَاتٌ</span> and <span class="ar">أُجَرَاتٌ</span>. <span class="auth">(Mṣb.)</span> <span class="add">[One says, <span class="ar long">أَجْرُكَ عَلَى ٱللّٰهِ</span> <em>Thy recompense is due from God.</em> And, to console a person for the death of a relation or friend, <span class="ar long">عَظَّمَ ٱللّٰهُ أَجْرَكَ فِيهِ</span> <em>May God largely compensate thee for him!</em> i. e., for the loss of him.]</span> By the expression <span class="ar long">أَجْرٍ كِرِيمٍ</span> in the Ḳur xxxvi. 10 is said to be meant <em>Paradise.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: <span class="ar">أَجْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OajorN_A2">
					<p>‡ <em>A dowry,</em> or <em>nuptial gift; a gift that is given to,</em> or <em>for, a bride:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">أُجُورٌ</span>: so in the Ḳur xxxiii. 49 <span class="add">[&amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: <span class="ar">أَجْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OajorN_A3">
					<p>† <em>Praise; good fame.</em> <span class="auth">(Ḳ.)</span> So, as some say, in the Ḳur xxix. 26. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajurN">
				<h3 class="entry"><span class="ar">أَجُرٌ</span> / <span class="ar">أُجُرٌ</span></h3>
				<div class="sense" id="OajurN_A1">
					<p><span class="ar">أَجُرٌ</span> and <span class="ar">أُجُرٌ</span>: <a href="#AjurBN">see <span class="ar">آجُرٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OujorapN">
				<h3 class="entry"><span class="ar">أُجْرَةٌ</span></h3>
				<div class="sense" id="OujorapN_A1">
					<p><span class="ar">أُجْرَةٌ</span>: <a href="#OajorN">see <span class="ar">أَجْرٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IijoriyBaA">
				<h3 class="entry"><span class="ar">إِجْرِيَّا</span> / <span class="ar">إِجْرِيَّآءُ</span></h3>
				<div class="sense" id="IijoriyBaA_A1">
					<p><span class="ar">إِجْرِيَّا</span> and <span class="ar">إِجْرِيَّآءُ</span>: <a href="#IijBiyrae">see <span class="ar">إِجِّيرَى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajuwrN">
				<h3 class="entry"><span class="ar">أَجُورٌ</span></h3>
				<div class="sense" id="OajuwrN_A1">
					<p><span class="ar">أَجُورٌ</span>: <a href="#AjurBN">see <span class="ar">آجُرٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajiyrN">
				<h3 class="entry"><span class="ar">أَجِيرٌ</span></h3>
				<div class="sense" id="OajiyrN_A1">
					<p><span class="ar">أَجِيرٌ</span> <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> <em>A hired man; a hireling:</em> <span class="auth">(L:)</span> or of the measure <span class="ar">فَعِيلٌ</span> in the sense of the measure <span class="ar">مُفَاعَلٌ</span>, i. e. <em>a man with whom one has engaged to give him hire, pay,</em> or <em>wages:</em> <span class="auth">(Mgh, Mṣb:*)</span> pl. <span class="ar">أُجَرَآءُ</span>. <span class="auth">(L, Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IijaArapN">
				<h3 class="entry"><span class="ar">إِجَارَةٌ</span> / 
							<span class="ar">أَجَارَةٌ</span> / 
							<span class="ar">أُجَارَةٌ</span></h3>
				<div class="sense" id="IijaArapN_A1">
					<p><span class="ar">إِجَارَةٌ</span> and <span class="ar">أَجَارَةٌ</span> and <span class="ar">أُجَارَةٌ</span>: <a href="#OajorN">see <span class="ar">أَجْرٌ</span></a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: <span class="ar">إِجَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IijaArapN_A2">
					<p><span class="ar">إِجَارَةٌ</span> also signifies The <em>giving of usufructs for a compensation.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجر</span> - Entry: <span class="ar">إِجَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IijaArapN_A3">
					<p>And <em>Land which its owners have let to him who will build upon it:</em> so explained by the lawyers. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IijBaArN">
				<h3 class="entry"><span class="ar">إِجَّارٌ</span></h3>
				<div class="sense" id="IijBaArN_A1">
					<p><span class="ar">إِجَّارٌ</span> <span class="auth">(Ṣ, M, IAth, Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">إِجَّارَةٌ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">إِنْجَارٌ↓</span></span> <span class="auth">(Mgh, Ḳ)</span> The <em>flat top,</em> or <em>roof, of a house,</em> <span class="auth">(Ṣ, M, IAth, Mgh, Ḳ,)</span> <em>that has not around it anything to prevent a person's falling from it:</em> <span class="auth">(M,* IAth:)</span> of the dial. of the people of Syria and of El-Ḥijáz: <span class="auth">(Ṣ:)</span> pl. <span class="add">[of the first and second]</span> <span class="ar">أَجَاجِيرُ</span> and <span class="ar">أَجَاجِرَةٌ</span>; <span class="auth">(AʼObeyd, Ṣ, Ḳ;)</span> and <span class="add">[of the third]</span> <span class="ar long">أَنَا جِيرُ</span>. <span class="auth">(Mgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IijBaArapN">
				<h3 class="entry"><span class="ar">إِجَّارَةٌ</span></h3>
				<div class="sense" id="IijBaArapN_A1">
					<p><span class="ar">إِجَّارَةٌ</span>: <a href="#IijBaArN">see <span class="ar">إِجَّارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IijBiyrae">
				<h3 class="entry"><span class="ar">إِجِّيرَى</span></h3>
				<div class="sense" id="IijBiyrae_A1">
					<p><span class="ar">إِجِّيرَى</span> <span class="auth">(ISk, Ḳ)</span> and<span class="arrow"><span class="ar">إِجْرِيَّا↓</span></span> and<span class="arrow"><span class="ar">إِجْرِيَّآءُ↓</span></span> <span class="auth">(Ṣ in art. <span class="ar">هجر</span>)</span> <em>A custom; a habit.</em> <span class="auth">(ISk, Ḳ, and Ṣ ubi suprà.)</span> The hemzeh is said to be a substitute for <span class="ar">ه</span> <span class="add">[in <span class="ar">هِجِّيرَى</span>, &amp;c.]</span> <span class="auth">(TA.)</span> You say, <span class="ar long">مَا زَالَ ذٰلِكَ إِجِّيرَاهُ</span> <em>That ceased not to be his custom,</em> or <em>habit.</em> <span class="auth">(ISk.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MjarN">
				<h3 class="entry"><span class="ar">آجَرٌ</span> / 
							<span class="ar">آجُرٌ</span> / 
							<span class="ar">آجِرٌ</span> / 
							<span class="ar">آجُرُونَ</span> / 
							<span class="ar">آجِرُونَ</span></h3>
				<div class="sense" id="MjarN_A1">
					<p><span class="ar">آجَرٌ</span> and <span class="ar">آجُرٌ</span> and <span class="ar">آجِرٌ</span>, and the pls. <span class="ar">آجُرُونَ</span> and <span class="ar">آجِرُونَ</span>: <a href="#AjurBN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MjurBN">
				<h3 class="entry"><span class="ar">آجُرٌّ</span> / <span class="ar">آجُرَّةٌ</span></h3>
				<div class="sense" id="MjurBN_A1">
					<p><span class="ar">آجُرٌّ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">آجُرٌّ↓</span></span> <span class="auth">(AA, Ks, Ḳ)</span> and<span class="arrow"><span class="ar">آجُورٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">أَجُورٌ↓</span></span> and<span class="arrow"><span class="ar">يَاجُورٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">أَجُرٌ↓</span></span> <span class="auth">(as in some copies of the Ḳ)</span> and<span class="arrow"><span class="ar">آجَرٌ↓</span></span>, <span class="auth">(as in some copies of the Ḳ and in the TA,)</span> or<span class="arrow"><span class="ar">أُجُرٌ↓</span></span>, <span class="auth">(as in other copies of the Ḳ,)</span> and<span class="arrow"><span class="ar">آجِرٌ↓</span></span> <span class="add">[to which is erroneously added in the CK <span class="ar">آجِرَةٌ</span>]</span> and <span class="add">[the pls.]</span><span class="arrow"><span class="ar">آجُرُونَ↓</span></span> and<span class="arrow"><span class="ar">آجِرُونَ↓</span></span> <span class="auth">(Ḳ)</span> are syn., <span class="auth">(Ṣ, Ḳ,)</span> of Persian origin, <span class="auth">(Ṣ,)</span> <span class="add">[from <span class="ar">آگُورْ</span> or <span class="ar">آگُرْ</span>,]</span> arabicized, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> signifying <em>Baked bricks;</em> <span class="auth">(Mṣb;)</span> <em>baked clay,</em> <span class="auth">(Mgh, L,)</span> <em>with which one builds:</em> <span class="auth">(Ṣ, L:)</span> <span class="ar">آجُرٌّ</span> and <span class="ar">آجُورٌّ</span> and <span class="ar">آجُرٌ</span> <span class="add">[&amp;c.]</span> are pls., <span class="add">[or rather coll. gen. ns., except the two forms ending with <span class="ar">و</span> and <span class="ar">ن</span>,]</span> and their sings. <span class="add">[or rather ns. un.]</span> are with <span class="ar">ة</span>, i. e. <span class="ar">آجُرَّةٌ</span>, &amp;c. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MjuwrN">
				<h3 class="entry"><span class="ar">آجُورٌ</span></h3>
				<div class="sense" id="MjuwrN_A1">
					<p><span class="ar">آجُورٌ</span>: <a href="#AjurBN">see <span class="ar">آجُرٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IinojaArN">
				<h3 class="entry"><span class="ar">إِنْجَارٌ</span></h3>
				<div class="sense" id="IinojaArN_A1">
					<p><span class="ar">إِنْجَارٌ</span>: <a href="#IijBaArN">see <span class="ar">إِجَّارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWojarN">
				<h3 class="entry"><span class="ar">مُؤْجَرٌ</span></h3>
				<div class="sense" id="muWojarN_A1">
					<p><span class="ar">مُؤْجَرٌ</span> <span class="add">[A slave, or]</span> a house, <em>let on hire;</em> <span class="auth">(Akh, T, Mṣb;)</span> as also<span class="arrow"><span class="ar">مَأْجُورٌ↓</span></span>; <span class="auth">(L;)</span> and some say, <span class="arrow"><span class="ar">مُؤَاجَرٌ↓</span></span>. <span class="auth">(Akh, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWojirN">
				<h3 class="entry"><span class="ar">مُؤْجِرٌ</span></h3>
				<div class="sense" id="muWojirN_A1">
					<p><span class="ar">مُؤْجِرٌ</span> One <em>who lets on hire</em> <span class="add">[a slave, or]</span> a house: one should not say <span class="arrow"><span class="ar">مُوَاجِرٌ↓</span></span>; for this is wrong with respect to the classical language, and abominable with respect to the conventional acceptation and common usage; a foul reproach being meant thereby <span class="add">[as is shown by the explanation of <span class="ar">آجَرَتْ</span>, given above: or, accord to some, it is allowable when it relates to a house: (<a href="#Ajr_1">see <span class="ar">أَجَرَهُ</span></a>:) it seems to be disallowed only when used absolutely]</span>. <span class="auth">(A, Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOojuwrN">
				<h3 class="entry"><span class="ar">مَأْجُورٌ</span></h3>
				<div class="sense" id="maOojuwrN_A1">
					<p><span class="ar">مَأْجُورٌ</span>: <a href="#muWojarN">see <span class="ar">مُؤْجَرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaAjarN">
				<h3 class="entry"><span class="ar">مُؤَاجَرٌ</span></h3>
				<div class="sense" id="muWaAjarN_A1">
					<p><span class="ar">مُؤَاجَرٌ</span>: <a href="#muWojarN">see <span class="ar">مُؤْجَرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaAjirN">
				<h3 class="entry"><span class="ar">مُؤَاجِرٌ</span></h3>
				<div class="sense" id="muWaAjirN_A1">
					<p><span class="ar">مُؤَاجِرٌ</span>: <a href="#muWojirN">see <span class="ar">مُؤْجِرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotajarN">
				<h3 class="entry"><span class="ar">مُؤْتَجَرٌ</span></h3>
				<div class="sense" id="muWotajarN_A1">
					<p><span class="ar">مُؤْتَجَرٌ</span> <span class="add">[part. n. of <span class="ar">اُوتُجِرَ</span>]</span>. Moḥammad Ibn-Bishr El-Khárijee, not <span class="add">[as is said in the Ṣ]</span> Aboo-Dahbal, says, <span class="auth">(L,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا لَيْتَ أَنِّى بِأَثْوَابِى وَرَاحِلَتِى</span> *</div> 
						<div class="star">* <span class="ar long">عَبْدٌ لِأَهْلِكَ هٰذَا الشَّهْرَ مُؤْتَجَرُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O would that I were, with my clothes and my riding-camel, a hired slave to thy family, this month</em>]</span>: <span class="auth">(Ṣ, L.)</span> i. e., <span class="ar long">مَعَ أَثْوَابِى</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="yaAjuwrN">
				<h3 class="entry"><span class="ar">يَاجُورٌ</span></h3>
				<div class="sense" id="yaAjuwrN_A1">
					<p><span class="ar">يَاجُورٌ</span>: <a href="#AjurBN">see <span class="ar">آجُرٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0023.pdf" target="pdf">
							<span>Lanes Lexicon Page 23</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0024.pdf" target="pdf">
							<span>Lanes Lexicon Page 24</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
