<article class="root" id="Root_Ays">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/174_Ayr">اير</a></span>
				<span class="ar">ايس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/176_AyX">ايش</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ays_1">
				<h3 class="entry">1. ⇒ <span class="ar">أيس</span></h3>
				<div class="sense" id="Ays_1_A1">
					<p><span class="ar long">أَيِسَ مِنْهُ</span>, <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> aor. <span class="ar">يَأْيَسُ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">يَأْيِسُ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">أَيَسٌ</span>, <span class="auth">(Mṣb,)</span> or <span class="ar">إِيَاسٌ</span>, <span class="auth">(Ḳ,)</span> or it has the same inf. n. as <span class="ar">يَئِسَ</span>, namely <span class="ar">يَأْسٌ</span>, <span class="auth">(Ṣ,)</span> with which <span class="arrow"><span class="ar">إِيَاسٌ↓</span></span> is syn., <span class="auth">(Mgh,)</span> but this last is a contraction of <span class="ar">إِيآسٌ</span>, of the measure <span class="ar">إِيعَاسٌ</span>, as determined by Az, and is not an inf. n. of <span class="ar">أَيِسَ</span> as some think it to be, <span class="auth">(Mgh, art. <span class="ar">يئِس</span>,)</span> <em>He despaired of it;</em> syn. <span class="ar">قنِط</span>: <span class="auth">(Ḳ:)</span> <a href="#yayisa">a dial. var. of <span class="ar">يَئِسَ</span></a>: <span class="auth">(ISk, Ṣ, TA:)</span> or it is not so, but is formed by transposition from <span class="ar">يَئِسَ</span>, because it has no <span class="add">[proper]</span> inf. n.; and <span class="ar">إِيَاسٌ</span>, the proper name of a man, is not to be adduced in evidence, for it is of the measure <span class="ar">فِعَالٌ</span> from <span class="ar">الأَوْسُ</span>, “the act of giving:” <span class="auth">(Preface to the M, quoted in the TA:)</span> if it were <a href="#yayisa">a dial. var. of <span class="ar">يَئِسَ</span></a>, they would say <span class="ar">إِسْتُ</span> for <span class="ar">أَيِسْتُ</span>: <span class="auth">(M, TA:)</span> and <span class="ar">أُيِسَ</span>, incorrectly written <span class="ar">أُويسَ</span>, also signifies the same. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايس</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ays_1_B1">
					<p><span class="ar">أَيْسَ</span>: <a href="#laYosa">see <span class="ar">لَيْسَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ays_2">
				<h3 class="entry">2. ⇒ <span class="ar">أيّس</span></h3>
				<div class="sense" id="Ays_2_A1">
					<p><a href="#Ays_4">see 4</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ays_4">
				<h3 class="entry">4. ⇒ <span class="ar">آيس</span></h3>
				<div class="sense" id="Ays_4_A1">
					<p><span class="ar">آيَسَهُ</span> <em>He made him to despair;</em> <span class="auth">(Ḳ;)</span> like <span class="ar">أَيْأَسَهُ</span>; <span class="auth">(Ṣ, Mgh;)</span> and so<span class="arrow"><span class="ar">أيّسهُ↓</span></span>, <span class="auth">(Ṣ,* Ḳ,)</span> inf. n. <span class="ar">تَأْيِيسٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayisN">
				<h3 class="entry"><span class="ar">أَيِسٌ</span></h3>
				<div class="sense" id="OayisN_A1">
					<p><span class="ar">أَيِسٌ</span> and<span class="arrow"><span class="ar">آيِسٌ↓</span></span> <span class="add">[<em>Despairing</em>]</span>; part. ns. of <span class="ar">أَيِسَ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايس</span> - Entry: <span class="ar">أَيِسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OayisN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">آيِسَةٌ</span> <span class="add">[and accord. to Golius <span class="arrow"><span class="ar">أَيْسَآءُ↓</span></span>, both properly meaning <em>Despairing</em> of the recurrence of the menstrual flux;]</span> <em>who has not menstruated in a period of five and fifty years.</em> <span class="auth">(KT.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayosaMCu">
				<h3 class="entry"><span class="ar">أَيْسَآءُ</span></h3>
				<div class="sense" id="OayosaMCu_A1">
					<p><span class="ar">أَيْسَآءُ</span>: <a href="#OayisN">see <span class="ar">أَيِسٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyaAsN">
				<h3 class="entry"><span class="ar">إِيَاسٌ</span></h3>
				<div class="sense" id="IiyaAsN_A1">
					<p><span class="ar">إِيَاسٌ</span>: <a href="#Ays_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MyisN">
				<h3 class="entry"><span class="ar">آيِسٌ</span></h3>
				<div class="sense" id="MyisN_A1">
					<p><span class="ar">آيِسٌ</span>: <a href="#OayisN">see <span class="ar">أَيِسٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
