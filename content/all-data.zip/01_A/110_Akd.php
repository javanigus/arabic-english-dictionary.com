<article class="root" id="Root_Akd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/109_AqT">اقط</a></span>
				<span class="ar">اكد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/111_Akr">اكر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Akd_1">
				<h3 class="entry">1. ⇒ <span class="ar">أكد</span></h3>
				<div class="sense" id="Akd_1_A1">
					<p><span class="ar">أَكَدَ</span> <em>He trod</em> wheat. <span class="auth">(IAạr, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أكّد</span></h3>
				<div class="sense" id="Akd_2_A1">
					<p><span class="ar">أكّد</span>, inf. n. <span class="ar">تَأْكِيدٌ</span>, <em>i. q.</em> <span class="ar">وَكَّدَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> of which it is a dial. var.; <span class="auth">(Ṣ;)</span> but it is not so chaste as the latter, and by some is disallowed. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akd_4">
				<h3 class="entry">4. ⇒ <span class="ar">آكد</span></h3>
				<div class="sense" id="Akd_4_A1">
					<p><span class="ar">آكد</span> <em>i. q.</em> <span class="ar">أَوْكَدَ</span>. <span class="auth">(Ṣ in art. <span class="ar">وكد</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأكّد</span></h3>
				<div class="sense" id="Akd_5_A1">
					<p><span class="ar">تأكّد</span> <em>i. q.</em> <span class="ar">تَوَكَّدَ</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">وكد</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IkaAdN">
				<h3 class="entry"><span class="ar">إكَادٌ</span></h3>
				<div class="sense" id="IkaAdN_A1">
					<p><span class="ar">إكَادٌ</span> <a href="#OakaAyidN">sing. of <span class="ar">أَكَائِدٌ</span></a> and <span class="ar">تَآكِيدٌ</span>, <span class="auth">(Ḳ,)</span> both of which are irreg. in relation to their sing., <span class="auth">(TA,)</span> signifying <span class="auth">(i. e. the pls.)</span> <em>Thongs,</em> or <em>straps, by which the</em> <span class="ar">قَرَبُوس</span> <em>is bound to the two side-boards of a horse's saddle.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#wikaAdN">See also <span class="ar">وِكَادٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakiydN">
				<h3 class="entry"><span class="ar">أَكِيدٌ</span></h3>
				<div class="sense" id="OakiydN_A1">
					<p><span class="ar">أَكِيدٌ</span> <em>Firm;</em> <span class="auth">(Ḳ, TA;)</span> applied to a covenant, or compact. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
