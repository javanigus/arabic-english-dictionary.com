<article class="root" id="Root_Arq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/058_Arf">ارف</a></span>
				<span class="ar">ارق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/060_Ark">ارك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Arq_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرق</span></h3>
				<div class="sense" id="Arq_1_A1">
					<p><span class="ar">أَرِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَقُ</span>}</span></add>, inf. n. <span class="ar">أَرَقٌ</span>, <span class="auth">(T, Ṣ, Ḳ, &amp;c.,)</span> <em>He was sleepless,</em> or <em>wakeful,</em> or <em>sleep departed from him,</em> <span class="auth">(JK, T,)</span> <em>by night;</em> <span class="auth">(T;)</span> <em>i. q.</em> <span class="ar">سَهِرَ</span> <span class="auth">(Ṣ, Mgh, Ṣgh, Ḳ)</span> <span class="ar">بِاللَّيْلِ</span>; <span class="auth">(Ṣgh, Ḳ;)</span> or <em>i. q.</em> <span class="ar">سَهِدَ</span>: <span class="auth">(Ṣ, and L and Ḳ in art. <span class="ar">سهد</span>:)</span> or <em>sleep departed from him by reason of a malady,</em> or <em>a distracting accident</em> or <em>event:</em> <span class="auth">(M:)</span> or <em>he was sleepless</em> or <em>wakeful</em> (<span class="ar">سَهِرَ</span>) <em>in a case that was disliked,</em> or <em>evil;</em> <span class="ar">سَهِرَ</span> having a general sense: <span class="auth">(M, F:)</span> or <em>he shut his eyes one while and opened them another,</em> <span class="add">[<em>being unable to continue sleeping,</em>]</span> whereas <span class="ar">سَهِرَ</span> signifies he did not sleep at all: <span class="auth">(Deewán of the Hudhalees, cited by Freytag in his Lex.:)</span> or <span class="ar">أَرَقٌ</span> signifies <em>sleeplessness,</em> or <em>wakefulness, engendered by anxiety and grief:</em> <span class="auth">(Ḥar p. 162:)</span> and<span class="arrow"><span class="ar">ائترق↓</span></span> <span class="add">[with the disjunctive alif written <span class="ar">اِيتَرَقَ</span>]</span> signifies the same as <span class="ar">أَرِقَ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Arq_1_B1">
					<p><span class="ar long">أُرِقَتِ النَّخْلَةُ</span> <span class="add">[and <span class="ar long">أُرِقَ الزّرْعُ</span>]</span> <em>The palm-tree</em> <span class="add">[and <em>the seed-produce</em>]</span> <em>was affected,</em> or <em>smitten, by what is termed</em> <span class="ar">أَرَقَان</span>. <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arq_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّق</span></h3>
				<div class="sense" id="Arq_2_A1">
					<p><span class="ar long">أَرَّقَنِى كَذَا</span>, <span class="auth">(JK, Ṣ, Ḳ,*)</span> inf. n. <span class="ar">تَأْرِيقٌ</span>. <span class="auth">(Ṣ, Mgh,)</span> <em>Such a thing rendered me,</em> or <em>caused me to be, sleepless</em> or <em>wakeful;</em> <span class="auth">(JK, Ṣ, Mgh,* Ḳ;*)</span> as also<span class="arrow"><span class="ar">آرقنى↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">إِيرَاقٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Arq_4">
				<h3 class="entry">4. ⇒ <span class="ar">آرق</span></h3>
				<div class="sense" id="Arq_4_A1">
					<p><a href="#Arq_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Arq_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائترق</span></h3>
				<div class="sense" id="Arq_8_A1">
					<p><a href="#Arq_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaroqN">
				<h3 class="entry"><span class="ar">أَرْقٌ</span></h3>
				<div class="sense" id="OaroqN_A1">
					<p><span class="ar">أَرْقٌ</span>: <a href="#OaraqaAnN">see <span class="ar">أَرَقَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaruqN">
				<h3 class="entry"><span class="ar">أَرُقٌ</span></h3>
				<div class="sense" id="OaruqN_A1">
					<p><span class="ar">أَرُقٌ</span>: <a href="#OariqN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OariqN">
				<h3 class="entry"><span class="ar">أَرِقٌ</span></h3>
				<div class="sense" id="OariqN_A1">
					<p><span class="ar">أَرِقٌ</span> <em>Sleepless</em> or <em>wakeful</em> <span class="auth">(Ṣ, Ḳ)</span> <em>by night</em> <span class="auth">(Ḳ)</span> <span class="add">[<em>by reason of a malady,</em> or <em>a distracting accident</em> or <em>event,</em>, &amp;c. (<a href="#Arq_1">see 1</a>)]</span>; as also<span class="arrow"><span class="ar">آرِقٌ↓</span></span> <span class="auth">(IF, Ḳ)</span> and<span class="arrow"><span class="ar">أَرُقٌ↓</span></span> and<span class="arrow"><span class="ar">أُرُقٌ↓</span></span>; or the last signifies <em>habitually so.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuruqN">
				<h3 class="entry"><span class="ar">أُرُقٌ</span></h3>
				<div class="sense" id="OuruqN_A1">
					<p><span class="ar">أُرُقٌ</span>: <a href="#OariqN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaraqaAnN">
				<h3 class="entry"><span class="ar">أَرَقَانٌ</span></h3>
				<div class="sense" id="OaraqaAnN_A1">
					<p><span class="ar">أَرَقَانٌ</span> <span class="auth">(JK, Ṣ, Ḳ)</span> and <span class="ar">أَرُقَانٌ</span> and <span class="ar">أَرْقَانٌ</span> and <span class="ar">إِرِقَانٌ</span> and <span class="ar">إِرْقَانٌ</span> and<span class="arrow"><span class="ar">أَرْقٌ↓</span></span> and<span class="arrow"><span class="ar">أُرَاقٌ↓</span></span> <span class="auth">(Ḳ)</span> <em>i. q.</em> <span class="ar">يَرَقَانٌ</span>; <span class="auth">(JK, Ṣ, Ḳ;)</span> <span class="ar">أرَقَانٌ</span> being a dial. var. of this last; <span class="auth">(Ṣ;)</span> or the hemzeh is a substitute for the <span class="ar">ى</span>; <span class="auth">(L;)</span> and <span class="ar">يرقان</span> is the word most commonly known; <span class="auth">(Ḳ;)</span> <em>A blight,</em> or <em>disease, which affects,</em> or <em>smites, seed-produce:</em> <span class="auth">(JK, Ṣ, Ḳ:)</span> and <em>a disease</em> <span class="add">[namely <em>jaundice</em>]</span> <em>which affects,</em> or <em>smites, man,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>causing the person to become yellow</em> <span class="add">[or <em>blackish</em>]</span>; <span class="auth">(TA;)</span> it is <em>a disease which changes the colour of the person excessively to yellowness or blackness, by the flowing of the yellow or black humour to the skin and the part next thereto, without putridity.</em> <span class="auth">(Ibn-Seenà <span class="add">[Avicenna]</span>, K.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuraAqN">
				<h3 class="entry"><span class="ar">أُرَاقٌ</span></h3>
				<div class="sense" id="OuraAqN_A1">
					<p><span class="ar">أُرَاقٌ</span>: <a href="#OaraqaAnN">see <span class="ar">أَرَقَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MriqN">
				<h3 class="entry"><span class="ar">آرِقٌ</span></h3>
				<div class="sense" id="MriqN_A1">
					<p><span class="ar">آرِقٌ</span>: <a href="#OariqN">see <span class="ar">أَرِقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoruwqN">
				<h3 class="entry"><span class="ar">مَأْرُوقٌ</span></h3>
				<div class="sense" id="maOoruwqN_A1">
					<p><span class="ar long">زَرْعٌ مَأْرُوقٌ</span> <em>Seed-produce affected,</em> or <em>smitten, with a blight,</em> or <em>disease,</em> <span class="auth">(JK, Ṣ, Ḳ,)</span> <em>such as is termed</em> <span class="ar">أَرَقَان</span>; <span class="auth">(JK, Ṣ;)</span> as also <span class="ar">مَيْرُوقٌ</span> <span class="add">[from <span class="ar">يَرَقَان</span>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar long">نَخْلَةٌ مَأْرُوقَةٌ</span> <em>a palm-tree affected,</em> or <em>smitten, therewith.</em> <span class="auth">(JK, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0050.pdf" target="pdf">
							<span>Lanes Lexicon Page 50</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
