<article class="root" id="Root_Ah">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/152_Anyh">انيه</a></span>
				<span class="ar">اه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/154_Ahb">اهب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ah_1">
				<h3 class="entry">1. ⇒ <span class="ar">أهّ</span></h3>
				<div class="sense" id="Ah_1_A1">
					<p><span class="ar">أَهَّ</span>, <span class="auth">(Ṣ in art. <span class="ar">اوه</span>, and Ḳ,)</span> inf. n. <span class="ar">أَةٌّ</span> <span class="auth">(Ḳ)</span> and <span class="ar">أَهَّةٌ</span> <span class="auth">(Ṣ,* Ḳ)</span> and the same without teshdeed; <span class="auth">(Ḳ,* TA; <span class="add">[app. meaning <span class="ar">آهَةٌ</span>, <a href="index.php?data=01_A/168_Awh">which, however, belongs to art. <span class="ar">اوه</span>, q. v.</a>;]</span>)</span> or <span class="ar">إِهَّةٌ</span>; <span class="auth">(so in the CK; <span class="add">[but in some copies of the Ḳ, and<span class="arrow"><span class="ar">أَهَّهَ↓</span></span>, as in the TḲ, where it is said that the inf. n. of this form of the verb is <span class="ar">تَأْهِيهٌ</span>;]</span>)</span> and<span class="arrow"><span class="ar">تأهّه↓</span></span>; <span class="auth">(Ḳ;)</span> <span class="add">[<em>i. q.</em> <span class="ar">آهَ</span> <em>and</em> <span class="ar">أَوَّهَ</span> <em>and</em> <span class="ar">تَأَهِيهٌ</span>; or]</span> <em>He expressed pain</em> or <em>grief</em> or <em>sorrow,</em> or <em>he lamented</em> or <em>complained</em> or <em>moaned,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>as one in an evil state, and broken in spirit by grief</em> or <em>mourning, and said</em> <span class="ar">آهِ</span>, or <span class="ar">هَاهْ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="index.php?data=01_A/168_Awh">See a verse cited in art. <span class="ar">اوه</span></a>, <a href="#AhapN">voce <span class="ar">آهَةٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ah_2">
				<h3 class="entry">2. ⇒ <span class="ar">أهّه</span></h3>
				<div class="sense" id="Ah_2_A1">
					<p><a href="#Ah_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ah_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأهّه</span></h3>
				<div class="sense" id="Ah_5_A1">
					<p><a href="#Ah_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iiho">
				<h3 class="entry"><span class="ar">إِهْ</span></h3>
				<div class="sense" id="Iiho_A1">
					<p><span class="ar">إِهْ</span>, i. e. <span class="ar">إِ</span> with the <span class="ar">ه</span> of pausation; imperative of <span class="ar">وَأَى</span>, q. v. <span class="auth">(Mughnee in art. <span class="ar">الف</span>)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mhi">
				<h3 class="entry"><span class="ar">آهِ</span> / 
							<span class="ar">آهٍ</span> / 
							<span class="ar">آهًا</span></h3>
				<div class="sense" id="Mhi_A1">
					<p><span class="ar">آهِ</span> and <span class="ar">آهٍ</span> and <span class="ar">آهًا</span>, &amp;c.: <a href="index.php?data=01_A/168_Awh">see art. <span class="ar">اوه</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0120.pdf" target="pdf">
							<span>Lanes Lexicon Page 120</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
