<article class="root" id="Root_ASTbl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/094_ASr">اصر</a></span>
				<span class="ar">اصطبل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/096_ASTrlAb">اصطرلاب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IiSoTabolN">
				<span class="pb" id="Page_0064"></span>
				<h3 class="entry"><span class="ar">إِصْطَبْلٌ</span></h3>
				<div class="sense" id="IiSoTabolN_A1">
					<p><span class="ar">إِصْطَبْلٌ</span> <em>A stable</em> <span class="auth">(Ḳ)</span> <em>for</em> <span class="ar">دَوَابّ</span> <span class="add">[i. e. <em>horses</em> or <em>mules</em> or <em>asses</em>]</span>: <span class="auth">(Ṣ <span class="add">[in some copies of which it is omitted]</span> and Ḳ:)</span> the <span class="ar">ا</span> is radical, because an augmentative does not occur at the beginning of a word of four or five letters unless derived from a verb: <span class="auth">(Ṣ:)</span> <span class="add">[probably from the barbarous Greek <span class="gr">σταβλίον</span>:]</span> AA says that it is not of the <span class="add">[genuine]</span> language of the Arabs: <span class="auth">(Ṣ:)</span> IB says that it is a foreign word, used by the Arabs: <span class="auth">(TA:)</span> accord. to some, <span class="auth">(TA,)</span> it is of the dial. of Syria: <span class="auth">(Ḳ, TA:)</span> the pl. is <span class="ar">أَصَاطِبُ</span>: and the dim. <span class="ar">أُصَيْطِبٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0064.pdf" target="pdf">
							<span>Lanes Lexicon Page 64</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
