<article class="root" id="Root_Abr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/003_Abd">ابد</a></span>
				<span class="ar">ابر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/005_AbD">ابض</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبر</span></h3>
				<div class="sense" id="Abr_1_A1">
					<p><span class="ar long">أَبَرَ الكَلْبِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِرُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُرُ</span>}</span></add> <span class="auth">(Ḳ,)</span>, inf. n. <span class="ar">أَبْرٌ</span>, <span class="auth">(TA,)</span> <em>He gave the dog, to eat, a needle in bread:</em> <span class="auth">(Ṣ, Ḳ:)</span> and <span class="add">[app., in like manner, <span class="ar long">أَبَرَ الشَّاةَ</span> <em>he gave the sheep,</em> or <em>goat, to eat, a needle in its fodder:</em> for you say,]</span> <span class="ar long">أُبِرَتِ الشَّاة</span> <em>the sheep,</em> or <em>goat, ate a needle in the fodder.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abr_1_A2">
					<p><span class="ar long">أَبَرَتْهُ العَقْرَبُ</span> ‡ <em>The scorpion stung him with the extremity of its tail.</em> <span class="auth">(Ṣ, M, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abr_1_A3">
					<p><span class="ar">أَبَرَهُ</span> ‡ <em>He spoke evil of him behind his back,</em> or <em>in his absence,</em> or <em>otherwise, with truth,</em> or <em>though it might be with truth;</em> or <em>defamed him;</em> <span class="auth">(IAạr, T, A, Ḳ;)</span> and <em>annoyed him,</em> or <em>hurt him.</em> <span class="auth">(IAạr, T, A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abr_1_B1">
					<p><span class="ar">أَبَرَ</span>, <span class="auth">(T, Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِرُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُرُ</span>}</span></add>, inf. n. <span class="ar">أَبْرٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">إِبَارٌ</span> and <span class="ar">إِبَارَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>He fecundated</em> a palm-tree <span class="add">[by means of the spadix of the male tree, which is bruised, or brayed, and sprinkled upon the spadix of the female; or by inserting a stalk of a raceme of the male tree into the spathe of the female, after shaking off the pollen of the former upon the spadix of the female (<a href="#OaloqaHa">see <span class="ar">أَلْقَحَ</span></a>)]</span>; <span class="auth">(T, Ṣ, A, Mṣb;)</span> as also<span class="arrow">↓<span class="ar">أبّر</span></span>, <span class="auth">(Ṣ, A,)</span> inf. n. <span class="ar">تَأْبِيرٌ</span>: <span class="auth">(Ṣ:)</span> or the latter has an intensive and frequentative signification <span class="add">[meaning the doing so much, or frequently, or to many palmtrees]</span>: <span class="auth">(Mṣb:)</span> and the former <span class="auth">(Ṣ, M, A, Ḳ)</span> and<span class="arrow">↓<span class="ar"></span></span> latter, <span class="auth">(M, A, Ḳ,)</span> <em>he dressed,</em> or <em>put into a good</em> or <em>right</em> or <em>proper state,</em> a palm-tree, <span class="auth">(Ṣ, M, A, Ḳ,)</span> and seed-produce, <span class="auth">(M, Ḳ,)</span> or any thing, as, for instance, a snare for catching game. <span class="auth">(AḤn, M.)</span> You say also, <span class="ar long">أُبِرَتِ النَّخْلَةُ</span>, and<span class="arrow">↓<span class="ar">أُبِّرَت</span></span>, and <span class="ar">وُبِرَت</span>, <em>The palm-tree was fecundated.</em> <span class="auth">(Aboo-ʼAmr Ibn-El-ʼAlà, L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Abr_1_C1">
					<p><span class="ar">أَبِرَ</span>, aor. <span class="ar">ـBَ</span>, <em>He,</em> <span class="auth">(a man, TA,)</span> or <em>it, was,</em> or <em>became, in a good</em> or <em>right</em> or <em>proper state.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Abr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أبّر</span></h3>
				<div class="sense" id="Abr_2_A1">
					<p><a href="#Abr_1">see 1</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّر</span></h3>
				<div class="sense" id="Abr_5_A1">
					<p><span class="ar">تأبّر</span> <em>It</em> <span class="auth">(a palm-tree, A and Mṣb, or a young palm-tree, Ṣ)</span> <em>admitted,</em> or <em>received, fecundation:</em> <span class="auth">(Ṣ, A, Mṣb:)</span> <em>it became fecundated of itself.</em> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتبر</span></h3>
				<div class="sense" id="Abr_8_A1">
					<p><span class="ar">ٱئْتَبَرَهُ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيْتَبَرَهُ</span>]</span> <em>He asked him to fecundate,</em> or <em>to dress,</em> or <em>put into a good</em> or <em>right</em> or <em>proper state, his palmtrees,</em> or <em>his seed-produce.</em> <span class="auth">(T, Ṣ, M,* Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abr_8_B1">
					<p><a href="#baOara">See also <span class="ar">بَأَرَ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiborapN">
				<h3 class="entry"><span class="ar">إِبْرَةٌ</span></h3>
				<div class="sense" id="IiborapN_A1">
					<p><span class="ar">إِبْرَةٌ</span> <em>A needle;</em> <span class="auth">(T, Mṣb;)</span> <em>an iron</em> <span class="ar">مِسَلَّة</span>: <span class="auth">(M, Ḳ:)</span> <span class="pb" id="Page_0006"></span>pl. <span class="ar">إِبَرٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">إِبَارٌ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">إِبْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiborapN_A2">
					<p>‡ The <em>sting,</em> or <em>extremity of the tail,</em> of a scorpion; <span class="auth">(Ṣ,* M, A, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">مِئْبَرٌ</span></span>; of which latter the pl. is <span class="ar">مَآبِرُ</span>: <span class="auth">(A:)</span> and of a bee. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">إِبْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiborapN_A3">
					<p>‡ The <em>extremity</em> of a horn. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">إِبْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiborapN_A4">
					<p>‡ The <span class="add">[<em>privy</em>]</span> <em>member</em> of a man. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">إِبْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IiborapN_A5">
					<p><span class="ar long">إِبْرَةٌ الذِّرَاعِ</span> ‡ <em>The extremity of the elbow;</em> <span class="auth">(Zj in his Khalk el-Insán; and A;)</span> <em>the extremity of the</em> <span class="ar">ذِرَاع</span> <span class="add">[here meaning the <em>ulna</em>]</span> <em>of the arm,</em> <span class="auth">(Ḳ,)</span> <em>from which the measurer by the cubit measures;</em> <span class="auth">(TA;)</span> <span class="add">[this being always done from the extremity of the elbow;]</span> <em>the extremity of the bone from which the measurer by the cubit measures:</em> the extremity of the os humeri which is next to the elbow is called the <span class="ar">قَبِيح</span>; and the <span class="ar">زُجّ</span> of the elbow is between the <span class="ar">قبيح</span> and the <span class="ar long">ابرة الذراع</span>: <span class="auth">(T:)</span> or <em>a small bone, the head of which is large, and the rest slender, compactly joined to the</em> <span class="ar">قبيح</span>: <span class="auth">(TA voce <span class="ar">قبيح</span>:)</span> or <em>the slender part of the</em> <span class="ar">ذراع</span>: <span class="auth">(Ṣ, M:)</span> or <em>a bone,</em> <span class="auth">(as in some copies of the Ḳ,)</span> or <em>small bone,</em> <span class="auth">(as in other copies of the Ḳ and in the M,)</span> which latter is the right reading, <span class="auth">(TA,)</span> <em>even with the extremity of the</em> <span class="ar">زَنْد</span> <span class="add">[which is applied to the <em>ulna</em> and to the <em>radius</em>]</span> <em>of,</em> or <em>from,</em> (<span class="ar">من</span>,) <em>the</em> <span class="ar">ذراع</span> <span class="add">[or <em>fore arm</em>]</span> <em>to the extremity of the finger.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">إِبْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IiborapN_A6">
					<p><span class="ar">الإبْرَةُ</span> also signifies ‡ <em>The bone of what is termed</em> <span class="ar">وَتَرَةُ</span> <span class="add">[i. e. <em>of the heel-tendon</em> of a man, or <em>of the hock</em> of a beast]</span>, <span class="auth">(M, Ḳ,)</span> <em>which is a small bone adhering to the</em> <span class="ar">كَعْب</span> <span class="add">[i. e. to the <em>ankle</em> or to the <em>hock</em>]</span>: <span class="auth">(M, TA:)</span> and <span class="add">[app. more correctly “or”]</span> <em>the slender part of the</em> <span class="ar">عرقوب</span> <span class="add">[or <em>hock</em>]</span> <em>of the horse:</em> <span class="auth">(M,* Ḳ,* TA:)</span> in the <span class="ar">عرقوبان</span> <span class="add">[or two hocks]</span> are <span class="add">[what are termed]</span> <span class="ar">إِبْرَتَانِ</span>, which are <em>the external extremity of each hock.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">إِبْرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="IiborapN_A7">
					<p><a href="#miYobarapN">See also <span class="ar">مِئْبَرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiborieBN">
				<h3 class="entry"><span class="ar">إِبْرِىٌّ</span></h3>
				<div class="sense" id="IiborieBN_A1">
					<p><span class="ar">إِبْرِىٌّ</span>: <a href="#OabBaArN">see <span class="ar">أَبَّارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibaArN">
				<h3 class="entry"><span class="ar">إِبَارٌ</span></h3>
				<div class="sense" id="IibaArN_A1">
					<p><span class="ar">إِبَارٌ</span> a subst. <span class="add">[signifying The <em>fecundation</em> of a palm-tree]</span>: <span class="auth">(Ṣ:)</span> or it is an inf. n.: <span class="add">[<a href="#Abr_1">see 1</a>:]</span> or it signifies <em>a palm-tree whereof the spadix is used for the purpose of fecundation.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabuwrN">
				<h3 class="entry"><span class="ar">أَبُورٌ</span></h3>
				<div class="sense" id="OabuwrN_A1">
					<p><span class="ar">أَبُورٌ</span>: <a href="#miYobarN">see <span class="ar">مِئْبَرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabBaArN">
				<h3 class="entry"><span class="ar">أَبَّارٌ</span></h3>
				<div class="sense" id="OabBaArN_A1">
					<p><span class="ar">أَبَّارٌ</span> <em>A maker of needles:</em> <span class="auth">(T, M, Ḳ:)</span> and <em>a seller thereof:</em> or the latter is called <span class="arrow">↓<span class="ar">إِبْرِىٌّ</span></span> of which <span class="ar">إِبَرِىٌّ</span> is a corruption. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">أَبَّارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabBaArN_A2">
					<p>† The <em>flea.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">أَبَّارٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabBaArN_B1">
					<p><a href="#baOBrN">See also <span class="ar">بَأّرٌ</span></a>, <a href="../">in art. <span class="ar">بأر</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mbiru">
				<h3 class="entry"><span class="ar">آبِرُ</span></h3>
				<div class="sense" id="Mbiru_A1">
					<p><span class="ar">آبِرُ</span> One <em>who fecundates</em> a palm-tree, or palmtrees: <em>who dresses,</em> or <em>puts into a good</em> or <em>right</em> or <em>proper state,</em> a palm-tree, or palm-trees, or seedproduce; <span class="auth">(T, TA;)</span> or any work of art; and hence applied to the fecundater of the palm-tree. <span class="auth">(Aboo-ʼAbd-Er-Raḥmán, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">آبِرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Mbiru_A2">
					<p><span class="ar long">مَا بِهَا آبِرٌ</span> † <em>There is not in it</em> <span class="add">[namely the house (<span class="ar">الدار</span>)]</span> <em>any one.</em> <span class="auth">(TA from the Expositions of the Fṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOobirN">
				<h3 class="entry"><span class="ar">مَأْبِرٌ</span></h3>
				<div class="sense" id="maOobirN_A1">
					<p><span class="ar">مَأْبِرٌ</span>: <a href="#miYobarN">see <span class="ar">مِئْبَرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYobarN">
				<h3 class="entry"><span class="ar">مِئْبَرٌ</span></h3>
				<div class="sense" id="miYobarN_A1">
					<p><span class="ar">مِئْبَرٌ</span> The <em>place</em> <span class="add">[or <em>case</em>]</span> <em>of the needle.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">مِئْبَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="miYobarN_A2">
					<p>† The <em>tongue.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">مِئْبَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="miYobarN_A3">
					<p><a href="#IiborapN">See also <span class="ar">إِبْرَةٌ</span></a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">مِئْبَرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="miYobarN_A4">
					<p><a href="#miYobarapN">and <span class="ar">مِئْبَرَةٌ</span></a></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">مِئْبَرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="miYobarN_B1">
					<p>Also, <span class="auth">(T, L, Ḳ,)</span> and<span class="arrow">↓<span class="ar">مَأْبِرٌ</span></span>, <span class="auth">(T, L,)</span> and<span class="arrow">↓<span class="ar">أَبُورٌ</span></span>, <span class="auth">(Mṣb,)</span> <em>That.</em> <span class="auth">(Mṣb, Ḳ,)</span> <span class="add">[namely]</span> <em>what is called</em> <span class="ar">جُشر</span>, <span class="auth">(T, TT,)</span> or <span class="ar">جُشّ</span>, <span class="auth">(so in a copy of the T,)</span> <span class="add">[in the L and TA it is said to be “like <span class="auth">(what is termed)</span> <span class="ar">الحش</span>,” thus written with the unpointed <span class="ar">ح</span>, and without any syll. signs, perhaps a mistranscription for <span class="ar">حُشْر</span>, and doubtless meaning the <em>anthers,</em> or the <em>pollen</em>,]</span> <em>with which palm-trees are fecundated.</em> <span class="auth">(T, L, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYobarapN">
				<h3 class="entry"><span class="ar">مِئْبَرَةٌ</span></h3>
				<div class="sense" id="miYobarapN_A1">
					<p><span class="ar">مِئْبَرَةٌ</span> <span class="auth">(Lḥ, Ṣ, M, Ḳ)</span> and<span class="arrow">↓<span class="ar">مِئْبَرٌ</span></span> and<span class="arrow">↓<span class="ar">إِبْرَةٌ</span></span> <span class="auth">(M, Ḳ)</span> ‡ <em>Malicious and mischievous misrepresentation; calumny;</em> or <em>slander;</em> <span class="auth">(Lḥ, Ṣ, M, Ḳ;)</span> and the † <em>marring,</em> or <em>disturbance, of the state of union</em> or <em>concord</em> or <em>friendship</em> or <em>love between a people</em> or <em>between two parties:</em> <span class="auth">(Lḥ, Ṣ, Ḳ, TA:)</span> pl. <span class="ar">مَآبِرٌ</span>. <span class="auth">(Ṣ, M.)</span> You say, <span class="ar long">خَبُثَتْ مِنْهُمُ المَخَابِرْ فَمَشَتْ بَيْنَهُمُ المَآبِرْ</span> ‡ <span class="add">[<em>Their internal states,</em> or <em>qualities, became bad,</em> or <em>evil,</em> or <em>corrupt, and in consequence calumnies became current among them</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWabBarN">
				<h3 class="entry"><span class="ar">مُؤَبَّرٌ</span></h3>
				<div class="sense" id="muWabBarN_A1">
					<p><span class="ar">مُؤَبَّرٌ</span>: <a href="#maOobuwrN">see what follows</a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOobuwrN">
				<h3 class="entry"><span class="ar">مَأْبُورٌ</span> / <span class="ar">مَأْبُورَةٌ</span></h3>
				<div class="sense" id="maOobuwrN_A1">
					<p><span class="ar">مَأْبُورٌ</span> A dog <em>that has had a needle given him, to eat, in bread:</em> <span class="auth">(Ṣ:)</span> and, with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مَأْبُورَةٌ</span>}</span></add>, applied to a sheep or goat (<span class="ar">شاة</span>) <em>that has eaten a needle in its fodder, and in whose inside it has stuck fast;</em> in consequence of which the animal eats nothing, or, if it eat, the eating does it no good. <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">المُؤْمِنُ كَٱلْكَلْبِ المَأْبُورِ</span> <em>The believer is like the dog that has had a needle given to him, to eat, in bread.</em> <span class="auth">(Ṣ.)</span> <span class="add">[Accord. to IbrD, the meaning is, that he is generous and incautious, so that he is easily deceived.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابر</span> - Entry: <span class="ar">مَأْبُورٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maOobuwrN_B1">
					<p>Also, <span class="auth">(T, Ṣ, A,)</span> and<span class="arrow">↓<span class="ar">مُؤَبَّرٌ</span></span>, <span class="auth">(Ṣ,)</span> A palm-tree <em>fecundated:</em> <span class="auth">(T, Ṣ, A:)</span> and the same, and seed-produce, <em>dressed,</em> or <em>put into a good</em> or <em>right</em> or <em>proper state.</em> <span class="auth">(T, TA.)</span> The former is the meaning in the phrase <span class="ar long">سِكَّةٌ مَأْبُورَةٌ</span>, <span class="auth">(T, Ṣ,)</span> occurring in a trad., <span class="add">[q. v. voce <span class="ar">مَأْمُورٌ</span>,]</span> i. e. <em>A row of palm-trees</em> <span class="add">[or perhaps <em>a tall palm-tree</em>]</span> <em>fecundated:</em> or, as some say, this phrase means <em>a ploughshare properly prepared for ploughing.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0005.pdf" target="pdf">
							<span>Lanes Lexicon Page 5</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0006.pdf" target="pdf">
							<span>Lanes Lexicon Page 6</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
