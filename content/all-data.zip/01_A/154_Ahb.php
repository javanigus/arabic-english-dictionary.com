<article class="root" id="Root_Ahb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/153_Ah">اه</a></span>
				<span class="ar">اهب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/155_Ahl">اهل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ahb_2">
				<h3 class="entry">2. ⇒ <span class="ar">أهّب</span></h3>
				<div class="sense" id="Ahb_2_A1">
					<p><span class="ar long">أهّبهُ لِلْأَمْرِ</span>, <span class="add">[inf. n. <span class="ar">تَأْهِيبٌ</span>,]</span> <em>He furnished, prepared, equipped,</em> or <em>accoutred, him, for the thing,</em> or <em>affair; he furnished him,</em> or <em>provided him, with the apparatus, gear, tackling, implements, instruments, tools,</em> or <em>the like, proper,</em> or <em>necessary, for it.</em> <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ahb_2_A2">
					<p><span class="ar long">أهّب الأَمْرَ</span> <em>He prepared the thing,</em> or <em>affair.</em> <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ahb_2_A3">
					<p><a href="#Ahb_5">See also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ahb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأهّب</span></h3>
				<div class="sense" id="Ahb_5_A1">
					<p><span class="ar">تأهّب</span> <em>He furnished, prepared, equipped,</em> or <em>accoutred, himself; furnished,</em> or <em>provided, himself with proper,</em> or <em>necessary, apparatus, gear, tackling, implements, instruments, tools,</em> or <em>the like;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> <span class="ar">لِلسَّفَرِ</span> <em>for journeying;</em> <span class="auth">(Mṣb;)</span> or <span class="ar">لِلْأَمْرِ</span> <em>for the thing,</em> or <em>affair;</em> as also<span class="arrow"><span class="ar">أهّب↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OahabN">
				<h3 class="entry"><span class="ar">أَهَبٌ</span></h3>
				<div class="sense" id="OahabN_A1">
					<p><span class="ar">أَهَبٌ</span>: <a href="#IihaAbN">see <span class="ar">إِهَابٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuhobapN">
				<h3 class="entry"><span class="ar">أُهْبَةٌ</span></h3>
				<div class="sense" id="OuhobapN_A1">
					<p><span class="ar">أُهْبَةٌ</span> <em>Apparatus, equipments, equipage, accoutrements, furniture, gear, tackling, implements, instruments, tools,</em> or <em>the like;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> as in <span class="ar long">أُهْبَةُ الحَرْبِ</span> <span class="add">[<em>the apparatus, arms, weapons, equipage,</em> or <em>accoutrements, of war</em>]</span>; <span class="auth">(Ṣ;)</span> as also <span class="ar">هُبَةٌ</span>: <span class="auth">(Ḳ:)</span> pl. of the former, <span class="ar">أُهَبٌ</span>. <span class="auth">(Ṣ, Mṣb.)</span> You say, <span class="ar long">أَخَذَ لِذٰلِكَ الأَمْرِ أُهْبَتهُ</span> <span class="add">[<em>He took his apparatus, &amp;c., for that thing,</em> or <em>affair;</em> also meaning, <em>he made his preparation,</em> or <em>he prepared himself, for it</em>]</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IihaAbN">
				<h3 class="entry"><span class="ar">إِهَابٌ</span></h3>
				<div class="sense" id="IihaAbN_A1">
					<p><span class="ar">إِهَابٌ</span> <em>A skin,</em> or <em>hide,</em> <span class="auth">(A, Mṣb, Ḳ,)</span> in an absolute sense, <span class="auth">(A,)</span> of a bull or cow, sheep or goat, or wild animal: <span class="auth">(TA:)</span> or <em>a skin,</em> or <em>hide, not yet tanned:</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ:)</span> and sometimes applied to the <em>skin</em> of a man: <span class="auth">(Mṣb:)</span> pl. <span class="auth">(of pauc., TA)</span> <span class="ar">آهِبَةٌ</span> <span class="auth">(IAạr, Ḳ)</span> and <span class="auth">(of mult., TA)</span> <span class="ar">أُهُبٌ</span>, <span class="auth">(Ṣ, A, Mgh, Mṣb, Mṣb, Ḳ,)</span> with two dammehs, <span class="auth">(Mgh, Mṣb,)</span> and<span class="arrow"><span class="ar">أهَبٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> contr. to rule, <span class="auth">(Ṣ, Mṣb,)</span> or, accord. to Sb, <span class="auth">(L,)</span> this last is a quasi-pl. n.: <span class="auth">(Mgh, L:)</span> in one copy of the Ḳ, it is written <span class="ar">آهُب</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">جَاعُوا حَتَّى أَكَلُوا الأُهُبَ</span> <span class="add">[<em>They hungered so that they ate the skins,</em> or <em>hides</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">كَادَ يَخْرُجُ مِنْ إِهَابِهِ فِى عَدْوِهِ</span> † <span class="add">[<em>He almost issued from his skin in his running</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">حَقَنَ الدِّمَآءَ فِى أُهُبِهَا</span> † <span class="add">[<em>He spared the people's blood in their bodies</em>]</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0120.pdf" target="pdf">
							<span>Lanes Lexicon Page 120</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
