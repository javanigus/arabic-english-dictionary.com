<article class="root" id="Root_Awle">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/164_Awlw">اولو</a></span>
				<span class="ar">اولى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/166_Awm">اوم</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Ouwlae.1">
				<h3 class="entry"><span class="ar">أُولَى</span> / 
							<span class="ar">أُولَآءَ</span> / 
							<span class="ar">أُولٰئِكَ</span> / 
							<span class="ar">أُولَآئِكَ</span></h3>
				<div class="sense" id="Ouwlae.1_A1">
					<p><span class="ar">أُولَى</span> <a href="#OawBalu">fem. of <span class="ar">أَوَّلُ</span></a>: <a href="#OawBalu">see the latter</a> <a href="../">in art. <span class="ar">وأل</span></a>.</p>
				</div>
				<span class="pb" id="Page_0129"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اولى</span> - Entry: <span class="ar">أُولَى.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ouwlae.1_B1">
					<p><span class="ar">أُولَى</span> as a pl., and its var. <span class="ar">أُولَآءَ</span>; and <span class="ar">أُولٰئِكَ</span>, or <span class="ar">أُولَآئِكَ</span>;, &amp;c.: <a href="#Oulae">see <span class="ar">أُلَى</span></a>, <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0128.pdf" target="pdf">
							<span>Lanes Lexicon Page 128</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0129.pdf" target="pdf">
							<span>Lanes Lexicon Page 129</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
