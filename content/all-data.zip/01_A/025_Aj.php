<article class="root" id="Root_Aj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/024_Avn">اثن</a></span>
				<span class="ar">اج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/026_Ajr">اجر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Aj_1">
				<h3 class="entry">1. ⇒ <span class="ar">أجّ</span></h3>
				<div class="sense" id="Aj_1_A1">
					<p><span class="ar long">أَجَّتِ النَّارُ</span>, <span class="auth">(Ṣ, A, Mṣb,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُجُ</span>}</span></add> <span class="auth">(Ṣ, Mṣb)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِجُ</span>}</span></add>, <span class="auth">(M, TA,)</span> <span class="add">[the former contr. to analogy, and the latter agreeable therewith, in the case of an intrans. verb of this class,]</span> inf. n. <span class="ar">أَجِيحٌ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> <em>The fire burned, burned up, burned brightly,</em> or <em>fiercely,</em> <span class="auth">(Mṣb,)</span> <em>blazed,</em> or <em>flamed,</em> or <em>blazed</em> or <em>flamed fiercely;</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">تأجّجت↓</span></span> <span class="auth">(Ṣ, A, Ḳ)</span> and<span class="arrow"><span class="ar">ائتجّت↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَجَّت</span>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>made a sound by its blazing</em> or <em>flaming.</em> <span class="auth">(ISd, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Aj_1_A2">
					<p><span class="ar">أَجَّ</span>,, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُجُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> contr. to analogy, <span class="auth">(TA,)</span> and <span class="ar">ـِ</span>, <span class="auth">(Jm, TṢ, L, Ḳ,)</span> but this is rejected by AA, <span class="auth">(MF,)</span> inf. n. <span class="ar">أَجٌّ</span> <span class="auth">(Ṣ)</span> and <span class="ar">أَجِيحٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He</em> <span class="auth">(an ostrich)</span> <em>ran, making a</em> <span class="add">[<em>rustling</em>]</span> <em>sound,</em> or <em>noise, such as is termed</em> <span class="ar">حَفِيفٌ</span>. <span class="auth">(Ṣ, L, Ḳ, &amp;c.)</span> And, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُجُ</span>}</span></add>, <span class="auth">(T, A,)</span> inf. n. <span class="ar">أَجٌّ</span>, <span class="auth">(T, TA,)</span> † <em>He hastened,</em> or <em>was quick, in his pace; walked quickly;</em> or <em>went a pace between a walk and a run;</em> <span class="auth">(T, Nh;)</span> said of a man; <span class="auth">(Nh, from a trad.;)</span> and of a camel: <span class="auth">(IB:)</span> or ‡ <em>he made a sound,</em> or <em>noise,</em> in his pace or going, <em>like that of the blazing,</em> or <em>flaming, of fire.</em> <span class="auth">(A.)</span> You say, <span class="ar long">أَجَّ أَجَّةَ الظَّلِيمِ</span> <span class="pb" id="Page_0023"></span>‡ <span class="add">[<em>He made a rustling sound</em> in going along, <em>like that of the ostrich</em>]</span>. <span class="auth">(A.)</span> And <span class="ar">أَجَّ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِجُ</span>}</span></add>, <span class="add">[so in the TA,]</span> inf. n. <span class="ar">أَجِيحٌ</span>, † <em>It</em> <span class="auth">(a camel's saddle)</span> <em>made a sound</em> or <em>noise</em> <span class="add">[produced by his running]</span>. <span class="auth">(AZ, TA.)</span> And <span class="ar">أَجِيحٌ</span> signifies also † The <em>sounding</em> of water <em>in pouring forth.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Aj_1_A3">
					<p><span class="ar">أَجَّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُجُ</span>}</span></add>, <span class="auth">(Ṣ, L,)</span> inf. n. <span class="ar">أُجُوحٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>It</em> <span class="auth">(water)</span> <em>was,</em> or <em>became, such as is termed</em> <span class="ar">أُجَاح</span>. <span class="auth">(Ṣ, L, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Aj_1_B1">
					<p><span class="ar">أَجَّهُ</span> <em>He rendered it</em> <span class="auth">(namely water)</span> <em>such as is termed</em> <span class="ar">أُجَاج</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aj_2">
				<h3 class="entry">2. ⇒ <span class="ar">أجّج</span></h3>
				<div class="sense" id="Aj_2_A1">
					<p><span class="ar long">أجّج النَّارَ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> inf. n. <span class="ar">تَأْجِيحٌ</span>, <span class="auth">(Ḳ,)</span> <em>He made the fire to</em> <span class="add">[<em>burn, burn up, burn brightly</em> or <em>fiercely,</em> (<a href="#Aj_1">see 1</a>,)]</span> <em>blaze,</em> or <em>flame,</em> or <em>blaze</em> or <em>flame fiercely.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Aj_2_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">أجّج بَيْنَهُمْ شَرَّا</span> † <em>He kindled evil,</em> or <em>mischief, among them.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aj_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأجّج</span></h3>
				<div class="sense" id="Aj_5_A1">
					<p><a href="#Aj_1">see 1</a>.</p>						
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Aj_5_A2">
					<p>Hence <span class="ar">تأجّج</span> also signifies <em>It gave light; shone;</em> or <em>shone brightly.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Aj_5_A3">
					<p><a href="#Aj_8">See also 8</a>, where a contracted form of this verb is mentioned.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aj_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتجّ</span></h3>
				<div class="sense" id="Aj_8_A1">
					<p><a href="#Aj_1">see 1</a>.</p>						
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Aj_8_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">ائتجّ النَّهَارُ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيْتَجَّ</span>]</span> <em>The day was,</em> or <em>became, intensely hot,</em> or <em>fiercely burning;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَأَجَّ↓</span></span> and <span class="ar">تأجّج</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajBapN">
				<h3 class="entry"><span class="ar">أَجَّةٌ</span></h3>
				<div class="sense" id="OajBapN_A1">
					<p><span class="ar">أَجَّةٌ</span> <em>Intenseness of heat,</em> and <em>its fierce burning;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَجِيحٌ↓</span></span> <span class="add">[<a href="#Aj_1">inf. n. of 1</a>]</span>, and<span class="arrow"><span class="ar">أَجَاجٌ↓</span></span>, and<span class="arrow"><span class="ar">ٱئْستِجَاجٌ↓</span></span> <span class="add">[inf. N. of 8]</span>: pl. <span class="ar">إِجَاجٌ</span>. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">جَآتْ أَجَّةٌ الصَّيْفِ</span> <em>The intense heat,</em> or <em>fierce burning, of summer came.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: <span class="ar">أَجَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OajBapN_A2">
					<p>The <em>sound</em> of fire; as also<span class="arrow"><span class="ar">أَجِيحٌ↓</span></span>. <span class="auth">(ISd, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: <span class="ar">أَجَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OajBapN_A3">
					<p>‡ The <em>sound,</em> or <em>noise, and commotion,</em> of an ostrich running, and of people walking or passing along. <span class="auth">(A.)</span> You say, <span class="ar long">أَجَّ أَجَّةَ الظَلِيمِ</span> <span class="add">[explained above: <a href="#Aj_1">see 1</a>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: <span class="ar">أَجَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OajBapN_A4">
					<p>† <em>Confusion:</em> <span class="auth">(Ṣ, Ḳ:)</span> or, as also<span class="arrow"><span class="ar">أَجِيحٌ↓</span></span>, the <em>confusion arising from the talking</em> of a people, and the <em>sound,</em> or <em>noise, of</em> their <em>walking</em> or <em>passing along.</em> <span class="auth">(L.)</span> You say, <span class="ar long">القَوْمُ فِى أَجَّةٍ</span> <em>The people are in a state of confusion</em> <span class="add">[&amp;c.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajaAjN">
				<h3 class="entry"><span class="ar">أَجَاجٌ</span></h3>
				<div class="sense" id="OajaAjN_A1">
					<p><span class="ar">أَجَاجٌ</span>: <a href="#OajBapN">see <span class="ar">أَجَّةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OujaAjN">
				<h3 class="entry"><span class="ar">أُجَاجٌ</span></h3>
				<div class="sense" id="OujaAjN_A1">
					<p><span class="ar">أُجَاجٌ</span> Anything <em>burning to the mouth, whether salt or bitter or hot.</em> <span class="auth">(MF.)</span> <span class="add">[Hence,]</span> <span class="ar long">مَآءٌ أُجَاجٌ</span>, <span class="auth">(Ṣ, A, Ḳ, &amp;c.,)</span> and<span class="arrow"><span class="ar">إِجَاجٌ↓</span></span>, <span class="auth">(Mṣb,)</span> <em>Water that burns by its saltness:</em> <span class="auth">(A:)</span> or <em>salt water:</em> or <em>bitter water:</em> <span class="auth">(TA:)</span> or <em>salt, bitter water:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>very salt water:</em> <span class="auth">(I’Ab:)</span> or <em>bitter and very salt water:</em> <span class="auth">(Mṣb:)</span> or <em>very salt water, that burns by reason of its saltness:</em> or <em>very bitter water:</em> or <em>water very salt and bitter, like the water of the sea:</em> <span class="auth">(TA:)</span> or <em>water of which no use is made for drinking, or for watering seed-produce, or for other purposes:</em> <span class="auth">(El-Ḥasan:)</span> or <em>very hot water:</em> <span class="auth">(TA:)</span> the pl. is the same <span class="add">[as the sing.; or <span class="ar">أُجَاجٌ</span> is also used as a quasi-pl. n.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IijaAjN">
				<h3 class="entry"><span class="ar">إِجَاجٌ</span></h3>
				<div class="sense" id="IijaAjN_A1">
					<p><span class="ar">إِجَاجٌ</span>: <a href="#OujaAjN">see <span class="ar">أُجَاجٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajuwjN">
				<h3 class="entry"><span class="ar">أَجُوجٌ</span></h3>
				<div class="sense" id="OajuwjN_A1">
					<p><span class="ar">أَجُوجٌ</span> <em>Giving light; shining;</em> or <em>shining brightly.</em> <span class="auth">(AA, Ṣ, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajiyjN">
				<h3 class="entry"><span class="ar">أَجِيجٌ</span></h3>
				<div class="sense" id="OajiyjN_A1">
					<p><span class="ar">أَجِيجٌ</span> <a href="#Aj_1">inf. n. of 1, which see:</a> <a href="#OajBapN">and see also <span class="ar">أَجَّةٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajBaAjN">
				<h3 class="entry"><span class="ar">أَجَّاجٌ</span></h3>
				<div class="sense" id="OajBaAjN_A1">
					<p><span class="ar long">هَجِيرٌ أَجَّاجٌ</span> <span class="add">[<em>A vehemently hot,</em> or <em>fiercelyburning, summer-midday</em>]</span>. <span class="auth">(A.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OjBN">
				<h3 class="entry"><span class="ar">أجٌّ</span> / <span class="ar">أجَّةٌ</span></h3>
				<div class="sense" id="OjBN_A1">
					<p><span class="ar">أجٌّ</span>; fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أجَّةٌ</span>}</span></add>: <a href="#AlOawaAjBu">see <span class="ar">الأَوَاججُ</span>, below</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mjuwju">
				<h3 class="entry"><span class="ar">آجُوجُ</span></h3>
				<div class="sense" id="Mjuwju_A1">
					<p><span class="ar">آجُوجُ</span>: <a href="#yaOojuwju">see <span class="ar">يَأْجُوجُ</span>, below</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlOawaAjiju">
				<h3 class="entry"><span class="ar">الأَوَاجِجُ</span></h3>
				<div class="sense" id="AlOawaAjiju_A1">
					<p><span class="ar long">السَّمَائِمُ الأَوَاجِجُ</span> <span class="add">[<em>The fiercely-burning hot winds;</em> the latter word being pl. of<span class="arrow"><span class="ar">آجَّةٌ↓</span></span>, fem. of<span class="arrow"><span class="ar">آجٌّ↓</span></span>, which is the act. part. n. of <span class="ar">أَجَّ</span>;]</span> is used by poetic licence for <span class="ar">الأَوَاجُّ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="QYotijaAjN">
				<h3 class="entry"><span class="ar">ٱئْتِجَاجٌ</span></h3>
				<div class="sense" id="QYotijaAjN_A1">
					<p><span class="ar">ٱئْتِجَاجٌ</span> inf. N. of 8, <a href="#Aj_8">which see <span class="new">{8}</span></a>: <a href="#OajapN">and see also <span class="ar">أَجَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOojuwju">
				<h3 class="entry"><span class="ar">مَأْجُوجُ</span></h3>
				<div class="sense" id="maOojuwju_A1">
					<p><span class="ar">مَأْجُوجُ</span>: <a href="#yaOojuwjN">see what follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="yaOojuwjN">
				<h3 class="entry"><span class="ar">يَأْجُوجٌ</span></h3>
				<div class="sense" id="yaOojuwjN_A1">
					<p><span class="ar">يَأْجُوجٌ</span> One <em>who walks quickly,</em> and <em>runs, in this and that manner.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اج</span> - Entry: <span class="ar">يَأْجُوجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="yaOojuwjN_A2">
					<p><span class="ar">يَأْجُوجُ</span> and<span class="arrow"><span class="ar">مَأْجُوجُ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> imperfectly decl., <span class="auth">(Ṣ,)</span> <span class="add">[<em>Gog and Magog;</em>]</span> <em>two tribes of God's creatures;</em> <span class="auth">(TA;)</span> or <em>two great nations;</em> <span class="auth">(Mṣb;)</span> or <em>two tribes of the children of Japheth the son of Noah:</em> or, as some say, <em>the former, of the Turks;</em> and <em>the latter, of the Jeel</em> <span class="add">[meaning <em>Jeel-Jeelán,</em> said in the TA in art. <span class="ar">جيل</span>, on the authority of ISd, to be <em>a people beyond the Deylem;</em> and on the authority of Az, to be <em>believers in a plurality of gods;</em> (<em>the Geli</em> and <em>Gelœ</em> of Ptolemy and Strabo, as observed by Sale, in a note on ch. xviii. v. 93 of the Ḳur, on the authority of Golius in Alfrag. p. 207;)]</span>: <span class="auth">(Bḍ in xviii. 93:)</span> <span class="add">[said by the Arabs to be <em>Scythians of the furthest East; particularly those on the north of the Chinese:</em> <span class="auth">(Golius:)</span> or, as some say, <em>the descendants of Japheth, and all the nations inhabiting the north of Asia and of Europe:</em> <span class="auth">(Freytag:)</span>]</span> <em>said</em> in a rad., <span class="auth">(TA,)</span> on the authority of I’Ab, <span class="auth">(Mṣb,)</span> <em>to compose nine tenths of mankind:</em> <span class="auth">(Mṣb, TA:)</span> or <span class="ar">يأجوج</span> is the name of <em>the males,</em> and <span class="ar">مأجوج</span> is that of <em>the females:</em> <span class="auth">(Mṣb:)</span> he who pronounces them thus, and makes the <span class="ar">أ</span> a radical letter, says that the former is of the measure <span class="ar">يَفْعُولُ</span>, and the latter of the measure <span class="ar">مَفْعُولُ</span>; as though from <span class="ar long">أَجَيجُ النَّارِ</span>; <span class="auth">(Akh, Ṣ, Mṣb;*)</span> or from <span class="ar long">مَآءٌ أُجَاجٌ</span>; <span class="auth">(TA;)</span> or from <span class="ar">أَجَّ</span> said of an ostrich; and imperfectly decl. as being determinate and fem.: <span class="auth">(Bḍ ubi suprà:)</span> he who pronounces them without <span class="ar">ء</span>, making the <span class="ar">ا</span> in each an augmentative letter, says that the former is from <span class="ar">يَجَجْتُ</span>, and the latter from <span class="ar">مَجَجْتُ</span>: <span class="auth">(Akh, Ṣ, Ḳ:)</span> this is the case if they be Arabic: <span class="auth">(TA:)</span> but some say that they are foreign names; <span class="auth">(Mṣb, TA;)</span> their being imperfectly decl. is said to indicate this; <span class="auth">(Bḍ ubi suprà;)</span> and if so, the <span class="ar">ا</span> in them is similar to that in <span class="ar">هَارُوت</span> and <span class="ar">مَارُوت</span> and <span class="ar">دَاوُود</span> and the like; and the <span class="ar">ء</span>, anomalous, as that in <span class="ar">عَأْلِمٌ</span> and the like; and their measure is <span class="ar">فَاعُولُ</span>. <span class="auth">(Mṣb.)</span> Ru-beh used to read <span class="arrow"><span class="ar">آجُوجُ↓</span></span> and <span class="ar">مَاجُوجُ</span> <span class="add">[in the CK <span class="ar">مأجُوج</span>]</span>; and Aboo-Mo'ádh, <span class="ar">يَمْجُوجُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0022.pdf" target="pdf">
							<span>Lanes Lexicon Page 22</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0023.pdf" target="pdf">
							<span>Lanes Lexicon Page 23</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
