<article class="root" id="Root_Alk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/121_Alq">الق</a></span>
				<span class="ar">الك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/123_Alm">الم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alk_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألك</span></h3>
				<div class="sense" id="Alk_1_A1">
					<p><span class="ar long">أَلَكَ الِلّجَامَ</span>, <span class="auth">(ISd, Ḳ,)</span> <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْلُكُ</span>}</span></add> or <span class="ar">ـِ</span>,]</span> inf. n. <span class="ar">أَلْكٌ</span>, <span class="auth">(ISd, TA,)</span> <em>He</em> <span class="auth">(a horse)</span> <em>chewed,</em> or <em>champed, the bit;</em> syn. <span class="ar">عَلَكَهُ</span>. <span class="auth">(ISd, Ḳ.)</span> One says, of a horse, <span class="ar long">يألكُ اللُّجُمَ</span> <em>He chews,</em> or <em>champs, the bits:</em> but the verb commonly known is <span class="ar">يَلُوكَ</span>, or <span class="ar">يَعْلُكُ</span>. <span class="auth">(Lth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alk_1_A2">
					<p><span class="add">[Hence, accord. to some, (<a href="#OaluwkN">see <span class="ar">أَلُوكٌ</span></a>,)]</span> <span class="ar long">أَلَكَ بَيْنَ القَوْمِ</span>, <span class="auth">(Mṣb, TA,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِكُ</span>}</span></add>, inf. n. <span class="ar">أَلْكٌ</span> and <span class="ar">أُلُوكٌ</span>, <span class="auth">(Mṣb,)</span> <em>He acted as a messenger</em> (<span class="ar">تَرَسَّلَ</span>) <em>between the people.</em> <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Alk_1_A3">
					<p>And <span class="ar">أَلَكَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِكُ</span>}</span></add>, inf. n. <span class="ar">أَلْكٌ</span>, <em>He conveyed,</em> or <em>communicated, to him a message.</em> <span class="auth">(Kr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Alk_1_A4">
					<p>And <span class="ar">أَلَكَ</span> <em>He sent.</em> <span class="auth">(IB in art. <span class="ar">لوك</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alk_4">
				<h3 class="entry">4. ⇒ <span class="ar">آلك</span></h3>
				<div class="sense" id="Alk_4_A1">
					<p><span class="ar">أَلِكْنِى</span> is from <span class="ar">أَلَكَ</span> signifying “he sent;” and is originally <span class="ar">أَأْلِكْنِى</span>; the <span class="add">[second]</span> hemzeh being transposed and placed after the <span class="ar">ل</span>, it becomes <span class="ar">أَلْئِكْنِى</span>; then the hemzeh has its vowel transferred to the <span class="ar">ل</span> and is thrown out; as is done in the case of <span class="ar">مَلَكٌ</span>, which is originally <span class="ar">مَأْلَكٌ</span>, then <span class="ar">مَلْأَكٌ</span>, and then <span class="ar">مَلَكٌ</span>: <span class="auth">(IB in art. <span class="ar">لوك</span>:)</span> it means <em>Be thou my messenger;</em> and <em>bear thou my message;</em> and is often used by the poets. <span class="auth">(Ṣ in art. <span class="ar">لوك</span>.)</span> Accord. to IAmb, one says, <span class="ar long">أَلِكْنِى إِلَى فُلَانٍ</span>, meaning <em>send thou me to such a one:</em> <span class="add">[but I do not know any instance in which this meaning is applicable:]</span> and the original form is <span class="ar">أَلْئِكْنِى</span>; or, if from <span class="ar">الأَلُوكُ</span>, the original form is <span class="ar">أَأْلِكْنِى</span>: and he also says that it means <em>be thou my messenger to such a one.</em> <span class="auth">(TA.)</span> One says also, <span class="ar long">أَلِكْنِى إِلَيْهَا بِرِسَالَةٍ</span>, which should properly mean <em>Send thou me to her with a message:</em> but it is an inverted phrase; since the meaning is, <em>be thou my messenger to her with this message</em> <span class="add">[or <em>rather with a message</em>]</span>: and <span class="ar long">أَلِكْنِى إِلَيْهَا بِالسَّلَامِ</span> i. e. <em>convey thou,</em> or <em>communicate thou, to her my salutation;</em> or <em>be thou my messenger to her</em> <span class="add">[<em>with salutation</em>]</span>: and sometimes this <span class="add">[prep.]</span> <span class="ar">ب</span> is suppressed, so that one says, <span class="ar long">أَلِكْنِى إِلَيْهَا السَّلَامَ</span>: sometimes, also, the person sent is he to whom the message is sent; as in the saying, <span class="ar long">أَلِكْنِى إِلَيْكَ السَّلَامَ</span> <span class="add">[virtually meaning <em>receive thou my salutation;</em> but literally]</span> <em>be thou my messenger to thyself with salutation.</em> <span class="auth">(TA.)</span> Lḥ mentions the phrase <span class="ar long">أَلَكْتُهُ إِلَيْهِ</span>, with respect to a message, aor. <span class="ar">أُلِيكُهُ</span>, inf. n. <span class="ar">إِلَاكَهٌ</span>; in which case, the hemzeh <span class="add">[in the aor. and inf. n.]</span> is converted into a letter of prolongation. <span class="auth">(TA in art. <span class="ar">لأك</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alk_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّك</span></h3>
				<div class="sense" id="Alk_5_A1">
					<p><a href="#OaluwkN">see <span class="ar">أَلُوكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alk_10">
				<h3 class="entry">10. ⇒ <span class="ar">استألك</span></h3>
				<div class="sense" id="Alk_10_A1">
					<p><span class="ar long">استألك مَأْلُكَتَهُ</span> <em>He bore,</em> or <em>conveyed, his message;</em> <span class="auth">(Ḳ;)</span> as also <span class="ar">استلأك</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaluwkN">
				<h3 class="entry"><span class="ar">أَلُوكٌ</span></h3>
				<div class="sense" id="OaluwkN_A1">
					<p><span class="ar">أَلُوكٌ</span> <em>A thing that is eaten</em> <span class="add">[or rather <em>chewed,</em> as will be seen below]</span>: so in the phrases, <span class="ar long">هذَا أَلُوكُ صِدْقٍ</span> like <span class="ar long">عَلُوجُ صِدْقٍ</span> and <span class="ar long">عَلُوكُ صِدْقٍ</span> <span class="add">[<em>This is an excellent thing that is chewed</em>]</span>, and <span class="ar long">مَا تَلَوَّكْتُ بِأَلُوكٍ</span> <span class="add">[or<span class="arrow"><span class="ar long">مَا تَأَلَّكْتُ↓ بِأَلُوكٍ</span></span> <span class="auth">(Ḳ in art. <span class="ar">علج</span>)</span>]</span> like <span class="ar long">مَا تَعَلَّجْتُ بِعَلُوجٍ</span> <span class="add">[app. meaning <em>I have not occupied myself in chewing with anything that is chewed</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الك</span> - Entry: <span class="ar">أَلُوكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaluwkN_A2">
					<p><span class="add">[And hence, accord. to some,]</span> <em>A message,</em> or <em>communication sent from one person or party to another;</em> <span class="auth">(Lth, Ṣ, M, Ḳ, &amp;c.; <span class="add">[in the CK, after <span class="ar">الرِّسالَةُ</span>, by which <span class="ar">الأَلُوكُ</span> is explained in the Ḳ, &amp;c., we find <span class="ar long">قِبَلَ المَلِكِ مُشْتَقٌّ منهُ</span>, in which the first two words should be <span class="ar long">قِيلَ المَلَكُ</span>, as in other copies of the Ḳ and in the TA; and <span class="ar">الاُلُوكُ</span> is erroneously put, in the CK, for <span class="ar">الأَلُوكُ</span>;]</span>)</span> said by Lth and ISd to be so called because it is <span class="add">[as it were]</span> chewed in the mouth; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">أَلُوكَهٌ↓</span></span> <span class="auth">(ISd, Ṣgh, Ḳ)</span> and<span class="arrow"><span class="ar">مَأْلُكَةٌ↓</span></span> <span class="auth">(Lth, Ṣ, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">مَأْلَكَةٌ↓</span></span> <span class="auth">(Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">مَأْلُكٌ↓</span></span>: <span class="auth">(Ṣ, M, Mṣb. Ḳ, &amp;c.:)</span> accord. to Kr, <span class="auth">(TA,)</span> this last is the only word of the measure <span class="ar">مَفْعُلٌ</span>: <span class="auth">(Ḳ, TA:)</span> but accord. to Sb and Akh, there is no word of this measure: <span class="auth">(TA:)</span> <span class="add">[i. e. there is none originally of this measure:]</span> <span class="pb" id="Page_0082"></span>other instances have been mentioned; namely, <span class="ar">مَكْرُمٌ</span> and <span class="ar">مَعُونٌ</span> <span class="add">[originally <span class="ar">مَعْوُنٌ</span>]</span> and <span class="ar">مَقْبُرٌ</span> and <span class="ar">مَهْلُكٌ</span> and <span class="ar">مَيْسُرٌ</span>, which last occurs in the Ḳur <span class="add">[ii. 280]</span>, accord. to one reading, in the words <span class="ar long">فَنَظِرَةٌ إِلَى مَيْسُرِهِ</span>; but it is said that each of these, and <span class="ar">مَأْلُكٌ</span> also, may be regarded as originally with <span class="ar">ة</span>; or, accord. to AḤei, each is <span class="add">[virtually, though not in the language of the grammarians,]</span> a pl. of the same with <span class="ar">ة</span>; <span class="auth">(MF, TA;)</span> and Akh says the same with respect to <span class="ar">مَكْرُمٌ</span> and <span class="ar">مَعُونٌ</span>: <span class="auth">(TA:)</span> Seer says that each is curtailed of <span class="ar">ة</span> by poetic licence; but this assertion will not apply to <span class="ar">مَيْسُرٌ</span>, as it occurs in the Ḳur. <span class="auth">(MF, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الك</span> - Entry: <span class="ar">أَلُوكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaluwkN_A3">
					<p><span class="ar">أَلُوكٌ</span> also signifies <em>A messenger.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ. <span class="add">[In the CK here follows, <span class="ar long">والمأْلُوْكُ والمَأْلُقُ</span>: but the right reading is <span class="ar long">وَالمَأْلُوكُ المَأْلُوقُ</span>, as in other copies and in the TA.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaluwkahN">
				<h3 class="entry"><span class="ar">أَلُوكَهٌ</span></h3>
				<div class="sense" id="OaluwkahN_A1">
					<p><span class="ar">أَلُوكَهٌ</span>: <a href="#OaluwkN">see <span class="ar">أَلُوكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOolakN">
				<h3 class="entry"><span class="ar">مَأْلَكٌ</span></h3>
				<div class="sense" id="maOolakN_A1">
					<p><span class="ar">مَأْلَكٌ</span> is said to be <a href="#malakN">the original form of <span class="ar">مَلَكٌ</span></a> <span class="add">[<em>An angel;</em> so called because he conveys, or communicates, the message from God; <span class="auth">(Ḳ,* TA, in art. <span class="ar">لأك</span>;)</span>]</span> derived from <span class="ar">أَلُوكٌ</span>; <span class="auth">(Mṣb, Ḳ, TA; <span class="add">[but in the CK is a mistake here, pointed out above, voce <span class="ar">أَلُوكٌ</span>;]</span>)</span> so that the measure of <span class="ar">مَلَكٌ</span> is <span class="ar">مَعَلٌ</span>: <span class="auth">(Mṣb:)</span> <span class="ar">مَلَكٌ</span> is both sing. and pl.: Ks says that it is originally <span class="ar">مَأْلَكٌ</span>, from <span class="ar">أَلُوكٌ</span> signifying “a message;” then, by transposition, <span class="ar">مَلْأَكٌ</span>, a form also in use; and then, in consequence of frequency of usage, the hemzeh is suppressed, so that it becomes <span class="ar">مَلَكٌ</span>; but in forming the pl., they restore it to <span class="ar">مَلْأَكٌ</span>, saying <span class="ar">مَلَائِكَةٌ</span>, and <span class="ar">مَلَائِكُ</span> also: <span class="auth">(Ṣ in art. <span class="ar">ملك</span>:)</span> or, accord. to some, it is from <span class="ar">لَأَكَ</span> “he sent;” so that the measure of <span class="ar">مَلَكٌ</span> is <span class="ar">مَفَلٌ</span>: and there are other opinions respecting it: <span class="auth">(Mṣb:)</span> some say that its <span class="ar">م</span> is a radical: <a href="index.php?data=24_m/171_mlk">see art. <span class="ar">ملك</span></a>. <span class="auth">(TA in art. <span class="ar">لأك</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOolukN">
				<h3 class="entry"><span class="ar">مَأْلُكٌ</span></h3>
				<div class="sense" id="maOolukN_A1">
					<p><span class="ar">مَأْلُكٌ</span>: <a href="#OaluwkN">see <span class="ar">أَلُوكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOolakapN">
				<h3 class="entry"><span class="ar">مَأْلَكَةٌ</span></h3>
				<div class="sense" id="maOolakapN_A1">
					<p><span class="ar">مَأْلَكَةٌ</span>: <a href="#OaluwkN">see <span class="ar">أَلُوكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOolukapN">
				<h3 class="entry"><span class="ar">مَأْلُكَةٌ</span></h3>
				<div class="sense" id="maOolukapN_A1">
					<p><span class="ar">مَأْلُكَةٌ</span>: <a href="#OaluwkN">see <span class="ar">أَلُوكٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0081.pdf" target="pdf">
							<span>Lanes Lexicon Page 81</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0082.pdf" target="pdf">
							<span>Lanes Lexicon Page 82</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
