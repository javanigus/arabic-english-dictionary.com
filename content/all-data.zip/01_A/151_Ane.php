<article class="root" id="Root_Ane">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/150_Anw">انو</a></span>
				<span class="ar">انى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/152_Anyh">انيه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ane_1">
				<h3 class="entry">1. ⇒ <span class="ar">أنى</span></h3>
				<div class="sense" id="Ane_1_A1">
					<p><span class="ar">أَنَى</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> aor. <span class="ar">يَأْنِى</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">إِنٌى</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">أَنْىٌ</span> and <span class="ar">أَنَآءٌ</span>, <span class="auth">(M, Ḳ,)</span> or, accord. to <span class="add">[some of the copies of]</span> the M, <span class="ar">أَنًى</span>, <span class="auth">(TA, <span class="add">[in which this is said to be the right form,]</span>)</span> or <span class="ar">أَنًا</span>, <span class="auth">(as written in the CK,)</span> said of a thing, <em>Its time came;</em> or <em>it was,</em> or <em>became,</em> or <em>drew, near;</em> syn. <span class="ar long">أَتَى وَقْتُهُ</span>, and <span class="ar long">جَآءَ أَنَاهُ</span>; <span class="auth">(Bḍ lvii. 15 <span class="add">[in explanation of a passage cited voce <span class="ar">أَنْ</span>]</span>;)</span> or <span class="ar">حَانَ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> or <span class="ar">أَنَى</span>, aor. <span class="ar">يَأْنِى</span>, inf. n. <span class="ar">أَنْىٌ</span>, signifies <em>it was,</em> or <em>became,</em> or <em>drew, near;</em> and <em>it was,</em> or <em>became, present.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَنَى لَكَ أَنْ تَفْعَلَ</span>, aor. <span class="ar">يَأْنِى</span>; and <span class="ar">آنَ</span>, aor. <span class="ar">يَئِينُ</span>; and <span class="ar long">نَالَ لك</span>, aor. <span class="ar">يَنِيلُ</span>; and <span class="ar">أَنَالَ</span>; all meaning <span class="ar long">حَانَ لَكَ</span> <span class="add">[<em>The time has come,</em> or <em>has drawn near, for thee that thou shouldst do</em> such a thing: or <em>the time of thy doing</em> such a thing <em>has come to thee:</em> or <em>thy doing</em> such a thing <em>has drawn near</em>]</span>: so says Zj; and Fr says the like: but the best of these is <span class="ar long">أَنَى لَكَ</span>. <span class="auth">(T.)</span> And <span class="ar long">أَنَى الرَّحِيلُ</span> <em>The time of departure came,</em> or <em>drew near;</em> syn. <span class="ar long">حَانَ وَقْتُهُ</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ane_1_A2">
					<p><em>It came,</em> or <em>attained, to its time; to its full,</em> or <em>final, time</em> or <em>state; to maturity,</em> or <em>ripeness; it became mature,</em> or <em>ripe;</em> <span class="auth">(T, Ṣ, M, IAmb,* Mṣb,* Ḳ;)</span> or, accord. to some, only when said of a plant; <span class="auth">(M, Ḳ;)</span> <span class="add">[or it signifies also]</span> <em>it became thoroughly cooked.</em> <span class="auth">(T, Mṣb.*)</span> Hence, in the Ḳur <span class="add">[xxxiii. 53]</span>, <span class="ar long">غَيْرَنَاظِرِينَ إِنَاهُ</span> <em>Not waiting,</em> or <em>watching, for its becoming thoroughly cooked;</em> or <em>for its cooking becoming finished.</em> <span class="auth">(T, Ṣ,* M.)</span> <span class="add">[<a href="#IinFe">See also <span class="ar">إِنًى</span>, below</a>.]</span> You say also, <span class="ar long">أَنَى الحَمِيمُ</span>, <span class="auth">(inf. n. <span class="ar">أَنْىٌ</span>, TA,)</span> <em>The hot water became heated to the utmost degree.</em> <span class="auth">(Ṣ, Ḳ.)</span> And <span class="ar long">أَنَى المَآءُ</span> <em>The water became hot to the utmost degree.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ane_1_B1">
					<p><span class="ar">أَنَى</span>, aor. <span class="ar">أُنِىٌّ</span>, inf. n. <span class="ar">أَنْىٌ</span>, <em>It</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became, behind,</em> or <em>after, its time:</em> <span class="auth">(Lth, T:)</span> or <span class="ar">أَنَى</span>, inf. n. <span class="ar">أُنِىٌّ</span>, <em>it,</em> or <em>he,</em> <span class="auth">(a man, TA,)</span> <em>was,</em> or <em>became, behind, backward,</em> or <em>late; it,</em> or <em>he, delayed,</em> or <em>held back;</em> <span class="auth">(M, Ḳ;)</span> as also <span class="ar">أَنِىَ</span>, aor. <span class="ar">يَأْنَى</span>, inf. n. <span class="ar">إِنًى</span>; and<span class="arrow"><span class="ar">أَنَّى↓</span></span>, inf. n. <span class="ar">تَأْنِيَةٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Ane_1_B2">
					<p><a href="#Ane_5">See also 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ane_2">
				<h3 class="entry">2. ⇒ <span class="ar">أنّى</span></h3>
				<div class="sense" id="Ane_2_A1">
					<p><a href="#Ane_4">see 4</a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ane_2_B1">
					<p><a href="#Ane_1">and see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انى</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Ane_2_B2">
					<p>You say also, <span class="ar long">أَنَّيْتُ فِى الشَّىْءِ</span> <em>I fell short,</em> or <em>fell short of what was requisite</em> or <em>what I ought to have done,</em> or <em>flagged,</em> or <em>was remiss, in,</em> or <em>in respect of, the thing.</em> <span class="auth">(TA. <span class="add">[The verb is there written without any syll. signs; but the context seems to indicate that it is as above.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ane_4">
				<h3 class="entry">4. ⇒ <span class="ar">آنى</span></h3>
				<div class="sense" id="Ane_4_A1">
					<p><span class="ar">آنى</span> and<span class="arrow"><span class="ar">أنّى↓</span></span> signify the same. <span class="auth">(IAạr, T, M.)</span> You say, <span class="ar">آنَاهُ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> with medd, <span class="auth">(Mṣb,)</span> aor. <span class="ar">يُؤْنِيهِ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">إِينَآءٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[in the CK, <span class="ar long">اَنَيْتُهُ اِنْيًا</span> is erroneously put for <span class="ar long">آنَيْتُهُ إِينَآءٌ</span>,]</span> <em>He postponed it, put it off, deferred it, delayed it, retarded it;</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> <em>retrained it, withheld it, impeded it;</em> <span class="auth">(Ṣ, TA;)</span> whatever the thing be. <span class="auth">(T.)</span> <span class="pb" id="Page_0119"></span>And<span class="arrow"><span class="ar long">أَنَّيْتُ↓ الطَّعَامَ فِى النَّارِ</span></span> <em>I kept the food long upon the fire.</em> <span class="auth">(TA.)</span> And <span class="ar long">لَا تُؤْنِ فُرْصَتَكَ</span> <em>Postpone not thou,</em> or <em>defer not, thine opportunity,</em> or <em>the time when thou art able to do a thing.</em> <span class="auth">(T.)</span> And it is said in a trad., respecting the prayer of Friday, <span class="ar long">رَأَيْتُكَ آنَيْتَ وَآذَيْتَ</span> <span class="auth">(M,* Mgh,* TA)</span> <em>I see thee to have delayed</em> coming, <em>and to have done what is annoying</em> to others by stepping over the necks <span class="add">[of those already in their places in the mosque]</span>: <span class="auth">(Aṣ, Mgh,* TA:)</span> a saying of ʼOmar. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ane_4_B1">
					<p><span class="ar">آنَاهُ</span> also signifies <em>He made him,</em> or <em>it, to be distant, remote,</em> or <em>far off; removed far away, alienated,</em> or <em>estranged, him,</em> or <em>it;</em> like <span class="ar">أَنْآهُ</span> <span class="add">[from which it is formed by transposition]</span>. <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar">يُؤْنِيكَ</span> occurs in a verse of Es-Sulameeyeh; <span class="auth">(M, TA;)</span> meaning <span class="ar">يُنْئِيكَ</span>; the <span class="ar">ء</span> being put before the <span class="ar">ن</span> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ane_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأنّى</span></h3>
				<div class="sense" id="Ane_5_A1">
					<p><span class="ar">تأنّى</span> <em>He acted deliberately,</em> or <em>leisurely, not hastily;</em> as also<span class="arrow"><span class="ar">استأنى↓</span></span>; and<span class="arrow"><span class="ar">أَنِىَ↓</span></span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">يَأْنَى</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أنْىٌ</span>: <span class="auth">(TA:)</span> <em>he acted with moderation, gently, deliberately,</em> or <em>leisurely; without haste;</em> and <em>with gravity, staidness, sedateness,</em> or <em>calmness;</em> <span class="ar long">فِى الأَمْرِ</span> <em>in the affair;</em> as also<span class="arrow"><span class="ar">استأنى↓</span></span>: <span class="auth">(Mgh:)</span> or <em>he acted gently;</em> <span class="auth">(IAạr, T, TA;)</span> as also<span class="arrow"><span class="ar">أَنِىَ↓</span></span>, aor. and inf. n. as above: <span class="auth">(TA:)</span> or <em>he acted gently, and waited;</em> <span class="ar long">فِى الأَمْرِ</span> <em>in the affair:</em> <span class="auth">(Ṣ:)</span> or <em>he waited,</em> or <em>was patient,</em> or <em>waited with patience,</em> <span class="auth">(T, Mṣb,)</span> <em>and did not hasten,</em> in an affair. <span class="auth">(Mṣb.)</span> <span class="ar">التَّأَتِّى</span> and <span class="ar">التَّأَنِّى</span> are nearly syn.: you say, <span class="ar long">تأنّى لَهُ</span> <em>He acted gently with him,</em> <span class="add">[or <em>to him,</em>]</span> <em>and did not hasten in his affair.</em> <span class="auth">(Mgh.)</span> You say also,<span class="arrow"><span class="ar long">استأنى↓ بِهِ</span></span> <em>He waited patiently with him;</em> or <em>waited, and had patience, with him;</em> <span class="auth">(Ṣ, TA;)</span> <em>he did not hasten him;</em> <span class="auth">(Lth, T;)</span> as also<span class="arrow"><span class="ar">استأناهُ↓</span></span>. <span class="auth">(ʼEyn, Ḥar p. 67.)</span> And<span class="arrow"><span class="ar long">اُسْتُؤْنِىَ↓ بِهِ حَوْلًا</span></span> <span class="add">[<em>He was waited patiently with for a year</em>]</span>. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">اِسْتَأْنِ↓ فِى أَمْرِكَ</span></span> <em>Hasten not in thine affair.</em> <span class="auth">(Lth, T.)</span> And<span class="arrow"><span class="ar long">اِسْتَأْنَيْتُ↓ فِى الطَّعَامِ</span></span> <em>I waited for the food to become perfectly prepared</em> or <em>cooked.</em> <span class="auth">(Ḥar p. 67.)</span> And <span class="ar long">تَأَنَّيْتُ الرَّجُلَ</span> <span class="auth">(and <span class="ar">عَلَيْهِ</span>, M and Ḳ <a href="index.php?data=25_n/170_nZr">in art. <span class="ar">نظر</span></a>, <span class="add">[<a href="#nZr_8">see <span class="ar">اِنْتَظَرَهُ</span></a>,]</span>)</span> <em>I waited for the man;</em> as also<span class="arrow"><span class="ar long">اِسْتَأْنَيْتُ↓ بِهِ</span></span>: whence,<span class="arrow"><span class="ar long">يُسْتَأنَى↓ بِالْجِرَاحَاتِ</span></span> <em>One should wait for the issues,</em> or <em>consequences,</em> or <em>results, of wounds.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">تَأنَّيْتُكَ حَتَّى لَا أَنَاةَ بِى</span> <span class="add">[<em>I have waited patiently for thee until there is no disposition to wait patiently in me</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ane_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأنى</span></h3>
				<div class="sense" id="Ane_10_A1">
					<p><a href="#Ane_5">see 5</a>, passim.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OanoeN">
				<h3 class="entry"><span class="ar">أَنْىٌ</span></h3>
				<div class="sense" id="OanoeN_A1">
					<p><span class="ar">أَنْىٌ</span>: <a href="#IinoeN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinoeN">
				<h3 class="entry"><span class="ar">إِنْىٌ</span></h3>
				<div class="sense" id="IinoeN_A1">
					<p><span class="ar">إِنْىٌ</span> <span class="auth">(AO, T, Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">إِنًى↓</span></span>, <span class="auth">(Akh, T, Ṣ, Mṣb,)</span> the latter in <span class="add">[some of]</span> the copies of the Ḳ erroneously written <span class="ar">أَنَآءٌ</span>, <span class="auth">(TA,)</span> <span class="add">[and in other copies of the same omitted,]</span> and<span class="arrow"><span class="ar">إِنْوٌ↓</span></span>, <span class="auth">(Akh, Th, T, Ṣ, M, Ḳ,)</span> with <span class="ar">و</span> substituted for <span class="ar">ى</span>, <span class="auth">(AAF, M,)</span> and<span class="arrow"><span class="ar">أَنْىٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">أَنًى↓</span></span>, <span class="auth">(M, IAmb,)</span> <em>An hour,</em> or <em>a short portion,</em> or <em>a time,</em> or <em>an indefinite time,</em> (<span class="ar">سَاعَةٌ</span>,) of the night: <span class="auth">(Zj, T, Ṣ, M, Ḳ:)</span> or <em>a time</em> or <em>season</em> (<span class="ar">وَقْتٌ</span>) of the night: <span class="auth">(M in art. <span class="ar">انو</span>:)</span> or <em>i. q.</em> <span class="ar">وَهْنٌ</span> <span class="add">[the <em>period about midnight;</em> or the <em>time after an hour,</em> or <em>a short period, of the night;</em> or <em>when the night is departing</em>]</span>: <span class="auth">(M, Ḳ:)</span> or <em>any</em> <span class="ar">سَاعَة</span> <span class="add">[i. e. <em>hour,</em> or <em>short portion,</em> or <em>time,</em>]</span> <span class="auth">(M, Ḳ)</span> of the night: <span class="auth">(M:)</span> <span class="add">[and <em>any period of time;</em> as will be seen below:]</span> or, accord. to some, <span class="auth">(M,)</span> <span class="arrow"><span class="ar">إِنًى↓</span></span> signifies the <em>whole day;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَنًى↓</span></span>: <span class="auth">(Ḳ:)</span> the pl. is <span class="ar">آنَآءٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أُنىٌّ</span> and <span class="ar">إِنِىٌّ</span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">مَضَى إِنْىٌ مِنَ الَّيْلِ</span> and<span class="arrow"><span class="ar">إِنْوٌ↓</span></span> <span class="add">[&amp;c.]</span> <em>A time,</em> or <em>season,</em> <span class="add">[&amp;c.,]</span> (<span class="ar">وَقْتٌ</span>, <span class="add">[&amp;c.,]</span>) <em>of the night passed:</em> <span class="auth">(M in art. <span class="ar">انو</span>:)</span> dual <span class="ar">إِنْيَانِ</span> and <span class="ar">إِنْوَانِ</span>. <span class="auth">(Ṣ.)</span> And a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَتَمَّتْ حَمْلَهَا فِى بَعْضِ شَهْرٍ</span> *</div> 
						<div class="star">* <span class="ar long">وَحَمْلُ الحَامَلَاتِ إنًى طَوِيلُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>She completed her gestation in a portion of a month; but the gestation of the pregnant</em> in general <em>is a long period of time</em>]</span>. <span class="auth">(IAạr, T.)</span> Another uses the phrase <span class="ar long">ضَحَّاكُ الأُنِىْ</span>, occurring at the end of a verse, <span class="add">[for <span class="ar long">ضحّاك الأُنِىِّ</span>,]</span> meaning <em>Found to be laughing whenever one comes to him.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanFe">
				<h3 class="entry"><span class="ar">أَنًى</span></h3>
				<div class="sense" id="OanFe_A1">
					<p><span class="ar">أَنًى</span>: <a href="#IinoeN">see <span class="ar">إِنْىٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">أَنًى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanFe_A2">
					<p>The <em>utmost point, reach,</em> or <em>degree,</em> <span class="auth">(M, Ḳ,)</span> of a thing; <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar">إِنًى↓</span></span>: so in the phrase, <span class="ar long">بَلَغَ أَنَاهُ</span> and <span class="ar">إِنَاهُ</span> <em>It</em> <span class="auth">(a thing, M)</span> <em>attained its utmost point, reach,</em> or <em>degree:</em> <span class="auth">(M, Ḳ:)</span> or this means, <span class="add">[or, accord. to the CK, “and” it means,]</span> <em>its state of being thoroughly cooked; its state of maturity;</em> or <em>its full,</em> or <em>final, time</em> or <em>state.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#Ane_1">See 1</a>, where an ex. from the Ḳur xxxiii. 53 is cited. Both words are said to be inf. ns.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">أَنًى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OanFe_B1">
					<p><a href="#OanaApN">See also <span class="ar">أَنَاةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinFe">
				<h3 class="entry"><span class="ar">إِنًى</span></h3>
				<div class="sense" id="IinFe_A1">
					<p><span class="ar">إِنًى</span>: <a href="#IinieN">see <span class="ar">إِنِىٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">إِنًى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IinFe_A2">
					<p><a href="#OanFe">and see <span class="ar">أَنًى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanaMCN">
				<h3 class="entry"><span class="ar">أَنَآءٌ</span></h3>
				<div class="sense" id="OanaMCN_A1">
					<p><span class="ar">أَنَآءٌ</span> <span class="add">[<em>Postponement; a putting off; a deferring; a delaying; a retarding: restraint; a withholding; an impeding:</em>]</span> a subst. from <span class="ar">آنَاهُ</span>, aor. <span class="ar">يُؤْنِيهِ</span>, inf. n. <span class="ar">إِينَآءٌ</span>, meaning “he postponed it,”, &amp;c.: <span class="auth">(Ṣ, Mṣb,* TA:)</span> the context of the Ḳ erroneously requires it to be understood as a subst. from <span class="ar">أَنَى</span>, aor. <span class="ar">يَأْنى</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinaMCN">
				<h3 class="entry"><span class="ar">إِنَآءٌ</span></h3>
				<div class="sense" id="IinaMCN_A1">
					<p><span class="ar">إِنَآءٌ</span> <em>A certain thing of which one makes use,</em> <span class="auth">(M,)</span> <em>well known;</em> <span class="auth">(Ṣ, Ḳ;)</span> namely, <em>a vessel,</em> or <em>receptacle,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>for water</em> <span class="add">[<em>&amp;c.</em>]</span>: <span class="auth">(Mgh:)</span> pl. <span class="ar">آنِيَةٌ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> originally <span class="ar">أَأْنِيَةٌ</span>; <span class="auth">(M;)</span> and <span class="ar">أَوَانٍ</span>; <span class="auth">(T, Ṣ, M, Mgh, Ḳ;)</span> the former a pl. of pauc.; and the latter a pl. of mult., <span class="auth">(Mgh,)</span> <a href="#AniyapN">pl. of <span class="ar">آنِيَةٌ</span></a>. <span class="auth">(T, Ṣ, M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanaApN">
				<h3 class="entry"><span class="ar">أَنَاةٌ</span></h3>
				<div class="sense" id="OanaApN_A1">
					<p><span class="ar">أَنَاةٌ</span> <em>Moderation; gentleness; deliberateness; a leisurely manner of proceeding,</em> or <em>of deportment,</em>, &amp;c.; <em>patience,</em> as meaning <em>contr. of hastiness:</em> and <em>gravity; staidness; sedateness; calmness:</em> a subst. from <span class="ar">تَأَنَّى</span>; <span class="auth">(Ṣ, Mṣb;)</span> syn. <span class="ar">تُؤَدَةٌ</span>; <span class="auth">(T;)</span> and <span class="ar">رِفْقٌ</span>; <span class="auth">(Ḥam p. 317;)</span> and <span class="ar">حِلْمٌ</span> and <span class="ar">وَقَارٌ</span>; <span class="auth">(M, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">أنًى↓</span></span>. <span class="auth">(M, Ḳ, TA. <span class="add">[In the CK, <span class="ar">كالاَنْىِ</span> is erroneously put for <span class="ar">كَالأَنَى</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">أَنَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanaApN_A2">
					<p>Also <em>Hope:</em> <span class="add">[in this sense, accord. to the TA, written with kesr; but this is doubtless a mistake, probably occasioned by a mistranscription:]</span> so in the charge of 'Orweh to his sons; <span class="ar long">يَا بَنِىَّ إِذَا رَأَيْتُمْ خَلَّةً رَائِعَةً مِنْ رَجُلٍ فَلَا تَقْطَعُوا أَنَاتَكُمْ مِتْهُ وَإِنْ كَانَ عِنْدَ النَّاسِ رَجُلَ سَؤْءٍ</span> <span class="add">[<em>O my sons, when ye see a quality exciting admiration and approval, in a man, cut not ye off your hope of him, though he be in the estimation of the people a bad man</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">أَنَاةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OanaApN_B1">
					<p>A woman <em>in whom is a languor on the occasion of rising,</em> or <em>standing up;</em> <span class="auth">(T, Ṣ, Ḳ;)</span> <em>and a gentle,</em> or <em>grave, deportment:</em> <span class="auth">(Ṣ:)</span> or <em>in whom is a languor impeding from rising,</em> or <em>standing up:</em> <span class="auth">(Aṣ:)</span> and <span class="ar">وَهْنَانَةٌ</span> signifies the like: <span class="auth">(T:)</span> Sb says that it is originally <span class="ar">وَنَاةٌ</span>, like as <span class="ar">أَحَدٌ</span> is originally <span class="ar">وَحَدٌ</span>; from <span class="ar">الوَنَى</span>: <span class="auth">(Ṣ:)</span> the people of El-Koofeh say that it is only <span class="ar">وَنَاةٌ</span>: so says Lth: and he says that <span class="ar">أَنَاةٌ</span> signifies, as applied to a woman, <em>blessed, prospered,</em> or <em>abounding in good,</em> as it is explained also by ADk, and <em>forbearing, gentle, grave, staid, sedate,</em> or <em>calm,</em> and <em>compliant,</em> or <em>agreeing with another in mind</em> or <em>opinion:</em> and the pl. is <span class="ar">أَنَواتٌ</span>: or, as some say, it signifies a <em>grave, staid, sedate,</em> or <em>calm,</em> woman, <em>who does not clamour, nor utter foul language.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanieBN">
				<h3 class="entry"><span class="ar">أَنِىٌّ</span></h3>
				<div class="sense" id="OanieBN_A1">
					<p><span class="ar">أَنِىٌّ</span>, as part. n. of 1, A thing <em>of which the time has come,</em> or <em>drawn near:</em> and <em>which has come,</em> or <em>attained, to its time; to its full,</em> or <em>final, time</em> or <em>state; to maturity,</em> or <em>ripeness:</em> but accord. to some, only applied to a plant. <span class="auth">(M, Ḳ.)</span> <span class="add">[Compare <span class="ar">آنٍ</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">أَنِىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OanieBN_B1">
					<p><em>Behind,</em> or <em>after, the time; backward,</em> or <em>late; delayed,</em> or <em>held back;</em> <span class="auth">(Ḳ, TA; <span class="add">[but wanting in a MṢ. copy of the former in my possession, and in the CK;]</span>)</span> as also<span class="arrow"><span class="ar">آنٍ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iiniyho">
				<h3 class="entry"><span class="ar">إِنِيهْ</span></h3>
				<div class="sense" id="Iiniyho_A1">
					<p><span class="ar">إِنِيهْ</span> a word expressive of disapproval, and of deeming a thing remote or improbable: Sb relates that it was said to an Arab of the desert, who had taken up his abode in a town, or place, “Wilt thou go forth when the desert shall have become plentiful in herbage?” and he said, <span class="ar long">أَأَنَا إِنِيهْ</span> <span class="add">[<em>What, I, indeed?</em>]</span>, meaning “Do ye say this to me when I am know to do thus?” as though he disapproved of their questioning him: but there is much diversity of opinion respecting this word: <span class="auth">(TA:)</span> <span class="add">[accord. to some,]</span> it is composed of the redundant <span class="ar">إِنْ</span> and the meddeh denoting disapproval <span class="add">[followed by the <span class="ar">ه</span> of silence]</span>. <span class="auth">(Mughnee voce <span class="ar">إِنٌ</span>.)</span> <span class="add">[See what is said of the redundant <span class="ar">انْ</span> in the present work.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanBae">
				<h3 class="entry"><span class="ar">أَنَّى</span></h3>
				<div class="sense" id="OanBae_A1">
					<p><span class="ar">أَنَّى</span> signifies <em>Whence?</em> syn. <span class="ar long">مِنْ أَيْنَ</span>; <span class="auth">(T, Ṣ, M;)</span> being an interrogative respecting the direction, or quarter, from which a thing is: <span class="auth">(Mṣb:)</span> and <em>whence</em> <span class="add">[used to denote a condition]</span>: <span class="auth">(TA:)</span> and <em>where?</em> and <em>where</em> <span class="add">[used to denote a condition]</span>; syn. <span class="ar">أَيْنَ</span>: <span class="auth">(T, Ḳ: <span class="add">[in which latter the first signification is not mentioned:]</span>)</span> and as one of the adverbial nouns used to denote a condition, <em>whencesoever; from whatever direction</em> or <em>quarter:</em> <span class="auth">(Ṣ:)</span> and <em>wherever; wheresoever:</em> <span class="auth">(Lth, T:)</span> and <em>when?</em> and <em>when</em> <span class="add">[used to den a condition]</span>; syn. <span class="ar">مَتَى</span>: <span class="auth">(T, Ḳ: <span class="add">[but in the latter of these, in art. <span class="ar">ان</span>, in the place of <span class="ar">مَتَى</span> we find <span class="ar">حَيْثُ</span>, which I regard as a mistake:]</span>)</span> and <em>how?</em> syn. <span class="ar">كَيْفَ</span>: <span class="auth">(Lth, T, Ṣ, M, Ḳ:)</span> and <em>however.</em> <span class="auth">(Lth, TA.)</span> <span class="pb" id="Page_0120"></span><span class="add">[I mention all these significations together because one of them is assigned by some authorities and another by others to <span class="ar">انّى</span> in one and the same instance.]</span> You say, <span class="ar long">أَنَّى يَكُونُ هٰذَا</span> <em>Whence, from what direction</em> or <em>quarter, from what way, will,</em> or <em>should, be this?</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أَنَّى لَكَ هٰذَا</span> <em>Whence</em> <span class="add">[came, or cometh,]</span> <em>to thee this?</em> <span class="auth">(Ṣ.)</span> It is said in the Ḳur <span class="add">[iii. 32]</span>, <span class="ar long">يَا مَرْيَمُ أَنَّى لَكِ هٰذَا</span> <em>O Mary, whence</em> <span class="add">[came]</span> <em>to thee this?</em> <span class="auth">(T.)</span> And in the same <span class="add">[xxxiv. 51]</span>, <span class="ar long">وَأَنَّى لَهُمُ ٱلتَّنَاوُشُ مِنْ مَكَانٍ بَعِيدٍ</span>, meaning <span class="add">[<em>But</em>]</span> <em>whence</em> <span class="add">[<em>shall the attaining</em> of belief <em>be possible to them from a distant place,</em> i. e., <span class="auth">(as explained in the Ṣ in art. <span class="ar">نوش</span>,)</span> in the world to come, when they have disbelieved in the present world? or <em>but how, &amp;c.?</em>]</span>. <span class="auth">(T.)</span> And in the same <span class="add">[1xxx. 25]</span>, accord. to one reading, <span class="ar long">أَنَّى صَبَبْنَا المَآءَ صَبَّا</span>, meaning <em>Where have we poured forth the water, pouring?</em> but in this is an allusion to the direction <span class="add">[whence the rain comes]</span>; and it may be rendered <em>whence?</em>, &amp;c.; and accord. to this reading, the pause upon <span class="ar">طَعَامِهٌ</span> <span class="add">[immediately preceding]</span> is complete. <span class="auth">(IAmb, T.)</span> And you say, <span class="ar long">أَنَّى تَأْتِنِى آتِكَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> meaning <em>Whencesoever,</em> or <em>from whatever direction</em> or <em>quarter, thou shalt come to me, I will come to thee.</em> <span class="auth">(Ṣ.)</span> In the saying of 'Alkameh,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمُطْعَمُ الغُنْمِ يُوْمَ الغُنْمِ مُطْعَمُهُ</span> *</div> 
						<div class="star">* <span class="ar long">أَنَّى تَوَجَّهَ وَالمَحْرُومُ مَحْرُومُ</span> *</div> 
					</blockquote>
					<p>the meaning is, <span class="add">[<em>And he who is given spoil to enjoy,</em> <span class="auth">(lit., who is fed therewith,)</span> <em>on the day of spoil, is given it to enjoy</em>]</span> <em>wherever he repairs,</em> or <em>however he repairs,</em> <span class="add">[<em>and the prohibited is prohibited.</em>]</span> <span class="auth">(Lth, T, TA.)</span> The saying in the Ḳur <span class="add">[iii. 159]</span>, <span class="ar long">قُلْتُمٌ أَنَّى هٰذَا</span> means <em>Ye say, When is this?</em> or <em>How is this?</em> <span class="auth">(T,)</span> or <em>Whence is this?</em> <span class="auth">(T, Bḍ, Jel.)</span> And <span class="ar long">أَنَّى شئْتُمْ</span>, in the same, <span class="add">[ii. 223,]</span> may mean <em>Whence,</em> or <em>when,</em> or <em>how, ye will.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">أَنَّى لَكَ أَنْ تَفْتَحَ الحِصْنَ</span>, meaning <em>How</em> <span class="add">[<em>is it,</em> or <em>will it be, possible for thee to open,</em> or <em>conquer, the fortress</em>]</span>? <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MnK">
				<h3 class="entry"><span class="ar">آنٍ</span></h3>
				<div class="sense" id="MnK_A1">
					<p><span class="ar">آنٍ</span> <em>Hot,</em> or <em>heated, to the utmost degree:</em> applied to hot water, <span class="auth">(Ṣ, M, Ḳ,)</span> in the Ḳur lv. 44: <span class="auth">(Ṣ, M:)</span> fem. <span class="ar">آنِيَةٌ</span>; occurring in the Ḳur lxxxviii. 5. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">آنٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MnK_B1">
					<p><a href="#OanieBN">See also <span class="ar">أَنِىٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انى</span> - Entry: <span class="ar">آنٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="MnK_C1">
					<p>Also A man <em>much characterized by moderation, gentleness,</em> or <em>deliberateness; by a leisurely manner of proceeding,</em> or <em>of deportment, &amp;c.; by patience,</em> as meaning <em>contr. of hastiness; by gravity, staidness, sedateness,</em> or <em>calmness.</em> <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MniyapF">
				<h3 class="entry"><span class="ar">آنِيَةً</span> / <span class="ar">آنِيَةٍ</span></h3>
				<div class="sense" id="MniyapF_A1">
					<p><span class="ar long">أَتَيْتُهُ آنِيَةً بَعْدَ آنِيَةٍ</span> is a phrase mentioned by AAF, meaning <em>I came to him time after time:</em> in which, <span class="add">[says ISd,]</span> I am of opinion that <span class="ar">آنية</span> is of the measure <span class="ar">فَاعِلَةٌ</span> from <span class="ar">الإنَى</span>: but the word commonly known is <span class="ar">آوِنَة</span> <span class="add">[<a href="#OawaAnN">pl. of <span class="ar">أَوَانٌ</span></a>; or <span class="ar">آيِنَة</span>, which is syn. with <span class="ar">آوِنَة</span>: <a href="#OawaAnN">see <span class="ar">أَوَانٌ</span></a>]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0118.pdf" target="pdf">
							<span>Lanes Lexicon Page 118</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0119.pdf" target="pdf">
							<span>Lanes Lexicon Page 119</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0120.pdf" target="pdf">
							<span>Lanes Lexicon Page 120</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
