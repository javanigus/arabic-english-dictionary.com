<article class="root" id="Root_Ab">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/000_A">ا</a></span>
				<span class="ar">اب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/002_Abjd">ابجد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ab_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبّ</span></h3>
				<div class="sense" id="Ab_1_A1">
					<p><span class="ar">أَبَّ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِبُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> agreeably with analogy in the case of an intrans. verb of this class, <span class="auth">(TA,)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُبُ</span>}</span></add>, <span class="auth">(AZ, T, Ṣ, M, Ḳ,)</span> contr. to analogy, <span class="auth">(TA,)</span>, inf. n. <span class="ar">أَبٌّ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">أَبِيبٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أَبَابٌ</span> and <span class="ar">أَبَابَةٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">إِبَابَةٌ</span>; <span class="auth">(M;)</span> and<span class="arrow"><span class="ar">ٱئْتَبَّ↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَبَّ</span>]</span>; <span class="auth">(T, Ḳ;)</span> <em>He prepared himself,</em> <span class="auth">(AZ, Ṣ, M, A, Ḳ,)</span> and <em>equipped himself,</em> <span class="auth">(AZ, Ṣ, A,)</span> for (<span class="ar">لِ</span>) departing, or going away, <span class="auth">(AZ, Ṣ,)</span> or for journeying: <span class="auth">(M, A, Ḳ:)</span> or <em>he determined upon journeying, and prepared himself.</em> <span class="auth">(T.)</span> El-Aạshà says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">صَرَمْتُ وَلَمْ أَصْرِمْكُمُ وَكَصَارِمٍ</span> *</div> 
						<div class="star">* <span class="ar long">أَخٌ قَدْ طَوَى كَشْحًا وَأَبَّ لِيَذْهَبَا</span> *</div> 
					</blockquote>
					<p><span class="auth">(T, Ṣ, M, TA,)</span> i. e. <em>I cut</em> <span class="add">[in effect, <em>while I did not really cut</em>]</span> <em> you: for like one who cuts is a brother who has determined and prepared to go away.</em> <span class="auth">(TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">لَا عَبَابَ وَلَا أَبَابَ</span>, <span class="add">[or <span class="ar long">لا عَبَابِ ولا أَبَابِ</span>,]</span> a prov. <span class="add">[<a href="index.php?data=01_A/002_Abjd">which see explained in art. <span class="ar">ابجد</span></a>]</span>. <span class="auth">(TA.)</span> <span class="add">[And hence the saying,]</span> <span class="ar long">هُوَ فِى أَبَابِهِ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">أَبَابَتِهِ</span>, and <span class="ar">إِبَابَتِهِ</span>, <span class="auth">(M,)</span> <em>He is in his</em> <span class="add">[<em>state of,</em> or <em>he is engaged in his,</em>]</span> <em>preparation</em> or <em>equipment</em> <span class="add">[for departing or journeying]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span> The hemzeh in <span class="ar">أَبَّ</span> is sometimes changed into <span class="ar">و</span>; and thus <span class="ar">وَبَّ</span>, inf. n. <span class="ar">وَبٌّ</span>, signifies <em>He prepared himself to assault,</em> or <em>charge, in battle.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ab_1_A2">
					<p><span class="ar long">أَبَّتْ أَبَابَتُهُ</span>, and <span class="ar">إِبَابَتُهُ</span>, <em>His way,</em> or <em>course, of acting,</em> or <em>conduct,</em> or <em>the like, was,</em> or <em>became, rightly directed,</em> or <em>ordered.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ab_1_A3">
					<p><span class="arrow"><span class="ar long">أَبَّ أَبَّهُ↓</span></span> <em>i. q.</em> <span class="ar long">قَصَدَ قَصْدَهُ</span>, <span class="auth">(Ḳ,)</span> which signifies <em>He tended, repaired, betook himself,</em> or <em>directed his course, towards him,</em> or <em>it:</em> <span class="auth">(Ṣ and Mṣb in art. <span class="ar">قصد</span>:)</span> and also, <em>he pursued his</em> <span class="auth">(another's)</span> <em>course, doing as he</em> <span class="auth">(the latter)</span> <em>did.</em> <span class="auth">(L in art. <span class="ar">وكد</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Ab_1_A4">
					<p><span class="ar long">أَبَّ إِلَى وَطَنِهِ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِبُ</span>}</span></add> <span class="auth">(IDrd, M, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُبُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَبٌّ</span> <span class="auth">(AA, Ṣ, M, Ḳ)</span> and <span class="ar">إِبَابَةٌ</span> and <span class="ar">أَبَابَةٌ</span> <span class="auth">(M, Ḳ,)</span> and <span class="ar">أَبَابٌ</span>, <span class="auth">(TA,)</span> <em>He yearned for, longed for,</em> or <em>longed to see, his home.</em> <span class="auth">(AA, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ab_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتبّ</span></h3>
				<div class="sense" id="Ab_8_A1">
					<p><a href="#Ab_1">see 1</a>, first signification.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ab_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأبّ</span></h3>
				<div class="sense" id="Ab_10_A1">
					<p><span class="ar">اِسْتَأَبَّهُ</span> <em>He adopted him as a father;</em> an extr. form; <span class="auth">(IAạr, M;)</span> from <span class="ar">أَبٌّ</span>, <a href="#OabN">a dial. var. of <span class="ar">أَبٌ</span></a>: <span class="auth">(TA:)</span> regularly, <span class="ar">اِسْتَأْبَاهُ</span>. <span class="auth">(M.)</span> And <span class="ar long">استأبّ أَبًا</span> and <span class="ar long">اِسْتَأْبَبَ أَبًا</span> <em>He adopted a father.</em> <span class="auth">(TA in art. <span class="ar">ابو</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabN">
				<h3 class="entry"><span class="ar">أَبٌ</span></h3>
				<div class="sense" id="OabN_A1">
					<p><span class="ar">أَبٌ</span>: <a href="index.php?data=01_A/011_Abw">see art. <span class="ar">ابو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabBN">
				<h3 class="entry"><span class="ar">أَبٌّ</span></h3>
				<div class="sense" id="OabBN_A1">
					<p><span class="ar">أَبٌّ</span> <em>Herbage,</em> <span class="auth">(M, Ḳ,)</span> <em>whether fresh or dry:</em> <span class="auth">(M,* Ḳ,* TA:)</span> or <em>pasture,</em> or <em>herbage which beasts feed upon,</em> <span class="auth">(Fr, AḤn, Zj, T, Ṣ, M, A, Mṣb, Ḳ,)</span> <em>of whatever kind,</em> <span class="auth">(AḤn, Zj,)</span> <span class="add">[or]</span> <em>not sown by men:</em> <span class="auth">(Mṣb:)</span> it is, <em>to cattle and other beasts, what fruit is to men:</em> <span class="auth">(Mujáhid, T, Mṣb:)</span> or <em>whatever grows upon the face of the earth;</em> <span class="auth">(ʼAṭà, Th, T, M;)</span> <em>whatever vegetable the earth produces:</em> <span class="auth">(Ḳ,* TA:)</span> and also, <em>green herbage,</em> or <em>plants:</em> <span class="auth">(Ḳ,* TA:)</span> and, as some say, <em>straw,</em> <span class="auth">(Jel in lxxx. 31, and TA,)</span> because cattle eat it: <span class="auth">(TA:)</span> or <em>herbage prepared for pasture and for cutting:</em> <span class="auth">(TA:)</span> accord. to IF, <span class="auth">(Mṣb,)</span> <em>dried fruits;</em> because prepared for winter <span class="auth">(Bḍ in lxxx. 31, and Mṣb)</span> and for journeying: <span class="auth">(Mṣb:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَوُبٌّ</span>, originally <span class="ar">أَأْبُبٌ</span>. <span class="auth">(I’Aḳ p. 367.)</span> You say, <span class="ar long">فُلَانٌ رَاعَ لَهُ الحَبُّ وَطَاعَ لَهُ الأَبُّ</span>, meaning <em>Such a one's seed-produce</em> <span class="add">[or <em>grain</em>]</span> <em>increased, and his pasture became ample.</em> <span class="auth">(A.)</span></p>
				</div>
				<span class="pb" id="Page_0004"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اب</span> - Entry: <span class="ar">أَبٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabBN_B1">
					<p><a href="#OabN">Also a dial. var. of <span class="ar">أَبٌ</span></a>, <em>A father.</em> <span class="auth">(T, and MF from the Tes-heel of Ibn-Málik.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اب</span> - Entry: <span class="ar">أَبٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OabBN_C1">
					<p><span class="ar long">أَبَّ أَبَّهُ</span>: <a href="#Ab_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabaAbapN">
				<h3 class="entry"><span class="ar">أَبَابَةٌ</span> / <span class="ar">إِبَابَةٌ</span></h3>
				<div class="sense" id="OabaAbapN_A1">
					<p><span class="ar">أَبَابَةٌ</span> and <span class="ar">إِبَابَةٌ</span> <em>A way,</em> or <em>course, of acting,</em> or <em>conduct,</em> or <em>the like.</em> <span class="auth">(M, Ḳ.)</span><span class="add">[<a href="#Ab_1">See 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibBaAnN">
				<h3 class="entry"><span class="ar">إِبَّانٌ</span></h3>
				<div class="sense" id="IibBaAnN_A1">
					<p><span class="ar">إِبَّانٌ</span> The <em>time,</em> or <em>season,</em> of a thing: <span class="auth">(Mṣb:)</span> or the <em>time of preparing,</em> or <em>making ready,</em> of a thing: <span class="auth">(Mgh:)</span> as, for instance, of fruit: <span class="auth">(Mgh, Mṣb:)</span> it is of the measure <span class="ar">فِعْلَانٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> from <span class="ar">أَبَّ</span> in the first of the senses assigned to it above, <span class="auth">(Mgh,)</span> the <span class="ar">ن</span> being augmentative; <span class="auth">(Mṣb;)</span> or of the measure <span class="ar">فِعَّالٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> from <span class="ar">أَبَّنَ</span> “he watched” or “observed” a thing, <span class="auth">(Mgh,)</span> the <span class="ar">ن</span> being radical: <span class="auth">(Mṣb:)</span> but the former derivation is the more correct. <span class="auth">(Mgh.)</span> <span class="add">[<a href="index.php?data=01_A/009_Abn">See also art. <span class="ar">ابن</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0003.pdf" target="pdf">
							<span>Lanes Lexicon Page 3</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0004.pdf" target="pdf">
							<span>Lanes Lexicon Page 4</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
