<article class="root" id="Root_AqHwAn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/107_Afywn">افيون</a></span>
				<span class="ar">اقحوان</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/109_AqT">اقط</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="OuqoHuwaAnN">
				<h3 class="entry"><span class="ar">أُقْحُوَانٌ</span></h3>
				<div class="sense" id="OuqoHuwaAnN_A1">
					<p><span class="ar">أُقْحُوَانٌ</span>: <a href="index.php?data=21_q/033_qHw">see art. <span class="ar">قحو</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
