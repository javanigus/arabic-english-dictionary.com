<article class="root" id="Root_Ate">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/016_Atw">اتو</a></span>
				<span class="ar">اتى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/018_Av">اث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ate_1">
				<h3 class="entry">1. ⇒ <span class="ar">أتى</span></h3>
				<div class="sense" id="Ate_1_A1">
					<p><span class="ar">أَتَى</span>, aor. <span class="ar">يَأْتِى</span>, <span class="auth">(Mṣb,)</span> and, in the dial. of Hudheyl, <span class="ar">يَأْت</span>, without <span class="ar">ى</span>; <span class="auth">(Ṣ;)</span> and <span class="ar">أَتَيْتُهُ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> <span class="add">[aor. <span class="ar">آتِيهِ</span>;]</span> and in the imperative, some of the Arabs say, <span class="ar">تِ</span>, suppressing the <span class="ar">ا</span>, like as is done in <span class="ar">خُذْ</span> and <span class="ar">كُلْ</span> and <span class="ar">مُرْ</span>; <span class="auth">(IJ, M;)</span> inf. n. <span class="ar">إِتْيَانٌ</span>, <span class="auth">(T, Ṣ,* M, Mgh, Mṣb, Ḳ,)</span> or this is a simple subst., <span class="auth">(Mṣb.)</span> and <span class="ar">إِتْيَانَةٌ</span>, <span class="auth">(M, Ḳ,)</span> which should not be used as an inf. n. of un., unless by a bad poetic licence, <span class="auth">(Lth, T,)</span> and <span class="ar">أَتْىٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أُتِىٌ</span> and <span class="ar">إِتِىٌ</span> and <span class="ar">مَأْتَاةٌ</span>; <span class="auth">(M, Ḳ;)</span> <em>He</em> <span class="add">[or <em>it</em>]</span> <em>came;</em> <span class="auth">(Mṣb;)</span> and <em>I came to him,</em> or <em>it;</em> <span class="auth">(Ṣ, M, Mgh,* Mṣb, Ḳ;)</span> or <em>was,</em> or <em>became, present at it,</em> namely, a place: <span class="auth">(Mgh:)</span> as also <span class="ar">أَتَا</span>, aor. <span class="ar">يَأْتُو</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">أَتَوْتُهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ)</span>, aor. <span class="ar">آتُوهُ</span>: <span class="auth">(Ṣ:)</span> for which reason, we assign the generality of the words <a href="index.php?data=01_A/016_Atw">mentioned in art. <span class="ar">اتو</span></a> to the present art. also. <span class="auth">(M.)</span> <span class="add">[Accord. to the authorities here indicated for the signification of <span class="ar">أَتَى</span>, this verb and <span class="ar">جَآءَ</span> are syn.: some attempt to distinguish them; but contradict one another in so doing: the slight distinctions that exist between them will be best seen by a comparison of the exs. in this art. <a href="../">with those in art. <span class="ar">جيأ</span></a>:]</span> accord. to Er-Rághib, the proper <span class="add">[or primary]</span> signification of <span class="ar">الإِتْيَانُ</span> is <em>The coming with ease.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ate_1_A2">
					<p><span class="ar">أَتَاهَا</span>, <span class="auth">(Mgh, Mṣb,)</span> inf. n. <span class="ar">إِتْيَانٌ</span>, <span class="auth">(Mṣb,)</span> <span class="add">[lit. <em>He came to her,</em>]</span> means † <em>he lay with her;</em> syn. <span class="ar">جَامَعَهَا</span>; <span class="auth">(Mgh, Mṣb;)</span> namely, a woman, <span class="auth">(Mgh,)</span> or his wife. <span class="auth">(Mṣb.)</span> Hence an expression in the Ḳur xxvi. 165. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ate_1_A3">
					<p><span class="ar long">أَتَى القَوْمَ</span> <span class="add">[<em>He came to the people:</em> and hence,]</span> <em>he asserted his relationship to the people, not being of them.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#OatieBu">See <span class="ar">أَتِىُّ</span></a> <a href="index.php?data=01_A/016_Atw">in art. <span class="ar">اتو</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Ate_1_A4">
					<p><span class="ar long">أَتَى بِهِ</span> <span class="add">[<em>He came with,</em> or <em>brought, him,</em> and <em>it;</em> or]</span> <em>he made him</em> <span class="auth">(a man)</span>, and <em>it</em> <span class="auth">(a thing, such, for instance, as property)</span>, <em>to come.</em> <span class="auth">(Kull.)</span> <span class="add">[<a href="#Ate_4">See also 4</a>: and see, in what follows, other significations of <span class="ar">أَتَى</span> trans. by means of <span class="ar">بِ</span>. Hence, <span class="ar long">أَتَى بِوَلَدٍ</span> <em>He begot a child,</em> or <em>children.</em> And <span class="ar long">أَتَتْ بِهِ</span> <em>She brought him forth; gave birth to him.</em>]</span> Accord. to Aboo-Is-ḥáḳ, the meaning of the words in the Ḳur <span class="add">[ii. 143]</span> <span class="ar long">أَيْنَمَا تَكُونُوا يَأْتِ بِكُمُ ٱللّٰهُ جَمِيعًا</span> is, <em>Wherever ye be, God will bring you all back unto Himself.</em> <span class="auth">(M.)</span> <span class="add">[You say also, <span class="ar long">أَتَى بِبَيِّنَةٍ</span> <em>He adduced a proof.</em>]</span> <a href="#Ate_3">See also 3</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Ate_1_A5">
					<p><span class="ar long">أَتَى الأَمْرَ</span> <span class="add">[<em>He entered into, engaged in,</em> or <em>occupied himself with, the thing,</em> or <em>affair:</em> and, as also <span class="ar long">أَتَى بِهِ</span>,]</span> <em>he did, executed,</em> or <em>performed, the thing,</em> or <em>affair;</em> <span class="auth">(M. Ḳ;)</span> and in like manner, <span class="ar">الذَّنْبَ</span>, <span class="add">[and <span class="ar">بَالذَّنْبِ</span>,]</span> <em>the crime, sin,</em> or <em>offence.</em> <span class="auth">(M.)</span> It is said in the Ḳur <span class="add">[ix. 54]</span>, <span class="ar long">وَلَا يَأْتُونَ الصَّلَاةَ إِلَّا وَهُمْ كُسَالَى</span>, meaning <em>And they do not enter into,</em> or <em>engage in, prayer, unless when they are heavy,</em> or <em>sluggish.</em> <span class="auth">(TA.)</span> And you say, <span class="ar long">أَتَى الفَاحِشَهَ</span>, <span class="add">[and <span class="ar">بِالفَاحِشَةِ</span>, <span class="auth">(see Ḳur iv. 23 and lxv. 1,)</span>]</span> <span class="pb" id="Page_0016"></span><em>He entered into, engaged in,</em> or <em>occupied himself with,</em> <span class="add">[or <em>he did,</em> or <em>committed,</em>]</span> <em>that which was excessively foul</em> or <em>evil.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَتَى بِالجَيِّدِ مِنْ قَوْلٍ أَوْ فِعْلٍ</span> <span class="add">[<em>He said, gave utterance to, uttered,</em> or <em>expressed,</em> or <em>he brought to pass, did,</em> or <em>effected, what was good,</em> or <em>excellent; he said,</em> or <em>did, well,</em> or <em>excel-lently</em>]</span>. <span class="auth">(Mṣb in art. <span class="ar">جود</span>.)</span> And <span class="ar long">أَتَى بِجَرْىِ بَعْدَ جَرْىٍ</span> <span class="add">[<em>He</em> <span class="auth">(a horse)</span> <em>performed,</em> or <em>fetched, run after run</em>]</span>. <span class="auth">(Ṣ in art. <span class="ar">تأم</span>, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Ate_1_A6">
					<p><span class="ar long">وَلَا يُفْلِحُ السَّاحِرُ حَيْثُ أَتَى</span><span class="add">[in the Ḳur xx. 72]</span> means <span class="ar long">حَيْثُ كَانَ</span> <span class="add">[<em>And the enchanter shall not prosper where he is,</em> or <em>wherever he may be</em>]</span>; <span class="auth">(M, Bḍ, Ḳ;)</span> and <em>where he cometh:</em> <span class="auth">(Bḍ:)</span> or <span class="ar long">حَيْثُ أَتَى بِسِحْرِهِ</span> <span class="add">[<em>where he cometh with his enchantment;</em> or <em>where he performeth his enchantment</em>]</span>: <span class="auth">(Jel:)</span> and it is said to mean that where the enchanter is, he must be slain: such is the doctrine of the lawyers. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Ate_1_A7">
					<p>Z mentions that <span class="ar">أَتَى</span> occurs in the sense of <span class="ar">صَارَ</span> <span class="add">[<em>He,</em> or <em>it, became;</em> like as we sometimes say, <em>he,</em> or <em>it, came,</em> or <em>came to be</em>]</span>; like <span class="ar">جَآءَ</span> in the saying, <span class="ar long">جَآءَ البِنَآءُ مُحْكَمًا</span>. <span class="auth">(Kull.)</span> <span class="add">[So you say, <span class="ar long">البِنَآءُ مُحْكَمًا</span> <em>The building became,</em> or <em>came to be, firm, strong,</em> or <em>compact.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Ate_1_A8">
					<p>The saying, in the Ḳur <span class="add">[xvi. 1]</span>, <span class="ar long">أَتَى أَمْرُ آللّٰهِ فَلَا تَسْتَعْجِلُوهُ</span> means <span class="add">[<em>The threatened punishment ordained of God hath approached: therefore desire not ye to hasten it:</em>]</span> <em>its coming hath approached.</em> <span class="auth">(TA.)</span> <span class="add">[And in like manner,]</span> <span class="ar long">أُتِىَ فُلَانٌ</span>, like <span class="ar">عُنِىَ</span>, means <em>Such a one was approached by the enemy come in sight of him.</em> <span class="auth">(Ḳ.)</span> <span class="ar long">أُتِيتَ يَا فُلَانٌ</span> <span class="add">[<em>Thou art approached</em>, &amp;c., <em>O such a one,</em>]</span> is said when one is warned of an enemy that has come in sight of him. <span class="auth">(Ṣgh, TA.)</span> And <span class="ar long">أَتَى عَلَيْهِمُ العَدُوُّ</span> means <em>The enemy came to them,</em> <span class="add">[or <em>came down upon them,</em> for, as MF observes, <span class="ar">أَتَى</span> when trans. by means of <span class="ar">عَلَى</span> seems to imply the meaning of <span class="ar">نَزَلَ</span>,]</span> <em>overcoming,</em> or <em>overpowering, them.</em> <span class="auth">(Bḍ in xviii. 40.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Ate_1_A9">
					<p>Hence, <span class="ar long">أَتَى عَلَيْهِ</span><span class="add">[and <span class="ar">أَتَاهُ</span>, as will be seen by what follows,]</span> † <em>He destroyed him,</em> or <em>it.</em> <span class="auth">(Bḍ ubi suprà.)</span> And hence, from <span class="ar long">إِتْيَانُ العَدُوِّ</span>, <span class="auth">(Mgh,)</span> <span class="ar long">أَتَى عَلَيْهِ الدَّهْرُ</span>‡ <em>Time,</em> or <em>fortune, destroyed him.</em> <span class="auth">(M, Mgh, Mṣb, Ḳ.)</span> Destruction is meant in the Ḳur <span class="add">[lix. 2]</span>, where it is said, <span class="ar long">فأَتاهُمُ ٱللّٰهُ مِنْ حيْثُ لَمْ يَحْتَسِبُوا</span>† <span class="add">[<em>But God brought destruction upon them whence they did not reckon,</em> or <em>expect</em>]</span>. <span class="auth">(Es-Semeen, TA.)</span> And it is said in the Ḳur <span class="add">[xvi. 28]</span>, <span class="ar long">فَأَتَى ٱللّٰهُ بُنْيَانَهُمْ مِنَ القَوَاعِدِ</span>, i. e. † <em>But God removed their building from the foundations, and demolished it</em> upon them, so that He destroyed them. <span class="auth">(TA.)</span> <span class="ar long">أَتَى عَلَيْهِ</span> also signifies † <em>He caused it to come to an end; made an end of it; consumed it;</em> <span class="add">[<em>devoured it;</em>]</span> <em>exhausted it; came to,</em> or <em>reached, the end of it;</em> namely, a thing; <span class="auth">(Kull;)</span> as, for instance, what was in a bowl; <span class="auth">(Ḳ in art. <span class="ar">جردم</span>;)</span> and what was in a vessel; <span class="auth">(Ḳ in art. <span class="ar">جرجب</span>;)</span> like <span class="ar long">فَرَغَ مِنْهُ</span>: <span class="auth">(ISd cited in the TA in art. <span class="ar">نكش</span>:)</span> or <em>i. q.</em> <span class="ar long">مَرَّ بِهِ</span><span class="add">[which may be rendered <em>he went away with it;</em> but this, as an explanation of <span class="ar long">أَتَى عَلَيْهِ</span>, has another meaning, which see in what follows]</span>. <span class="auth">(Kull.)</span> And one says, <span class="ar long">أُتِىَ فُلَانٌ مِنْ مَأْمَنِهِ</span>† <em>Destruction came to such a one from the quarter whence he felt secure.</em> <span class="auth">(TA.)</span> And <span class="ar long">أُتِىَ عَلَى يَدِ فُلَانٍ</span>† <em>Property belonging to such a one perished.</em> <span class="auth">(T.)</span> And <span class="ar long">يُؤْتَى دُونَهُ</span>† <em>He is taken away,</em> or <em>carried off, and overcome.</em> <span class="auth">(TA.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَتَى دُونَ حُلْوِالعَيْشِ حَتَّى أَمَرَّهُ</span> *</div> 
						<div class="star">* <span class="ar long">نُكُوبٌ عَلَى آثَارِهِنَّ نُكُوبُ</span> *</div> 
					</blockquote>
					<p>meaning † <span class="add">[<em>Misfortunes, in the footsteps of which were misfortunes,</em>]</span> <em>took away</em> <span class="add">[<em>what was sweet, of life, and rendered it bitter</em>]</span>. <span class="auth">(TA.)</span> One says also, <span class="ar long">مِنْ هٰهُنَا أُتِيَتْ</span>, <span class="add">[so I find it written, but I think that the last word should be <span class="ar">أُتِيتَ</span>, agreeably with a preceding phrase from the T,]</span> † <em>Hence the trial,</em> or <em>affliction, came in upon thee.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">أُتِىَ مِنْ جِهَةِ كَذَا</span>, with the verb in the passive form, † <em>He missed</em> <span class="add">[<em>his object in respect of such a thing</em>]</span> <em>by laying hold upon it when it was not fit to be laid hold upon.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أُتِىَ الرَّجُلُ</span>, <span class="add">[also]</span> like <span class="ar">عُنِىَ</span>, † <em>The man was deceived,</em> or <em>deluded, and his faculty of sense became altered to him, so that he imagined that to be true which was not true.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Ate_1_A10">
					<p><span class="ar long">أَتَى عَلَيْهِ</span> is also <em>syn. with</em> <span class="ar long">مَرَّ بِهِ</span><span class="add">[meaning <em>He,</em> or <em>it,</em> <span class="auth">(as, for instance, a period of time,)</span> <em>passed by him,</em> or <em>over him</em>]</span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَتَ عَلَيْهِ حَوْلٌ</span> <span class="add">[<em>A year passed over him;</em> or <em>he became a year old</em>]</span>. <span class="auth">(Ṣ, Ḳ, Mṣb, in art. <span class="ar">حول</span>;, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Ate_1_A11">
					<p><span class="ar long">أَتَتِ النَّاقَهُ</span>, and <span class="ar long">مَا أَحْسَنَ أَتْىَ يَدَى هذِهِ النّاقَةِ</span>: <a href="index.php?data=01_A/016_Atw">see art. <span class="ar">اتو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ate_2">
				<h3 class="entry">2. ⇒ <span class="ar">أتّى</span></h3>
				<div class="sense" id="Ate_2_A1">
					<p><span class="ar long">أتّى لِلْمَآءِ</span>, <span class="auth">(T, Ṣ, M,)</span> or <span class="ar">المَآءَ</span>, <span class="auth">(Ḳ,)</span> or both, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَأْتِيَةٌ</span> and <span class="ar">تَأْتِىٌّ</span>, <em>He smoothed, made easy,</em> or <em>prepared,</em> (<span class="ar">سَهَّلَ</span>, Ṣ, Ḳ, or <span class="ar">هَيَّأَ</span>, T,) <em>the way, course, passage,</em> or <em>channel, of the water,</em> <span class="auth">(T, Ṣ, Ḳ,)</span> <em>in order that it might pass forth to a place;</em> <span class="auth">(Ṣ;)</span> <em>he directed a channel for it</em> <span class="auth">(M, TA)</span> <em>so that it ran to the places wherein it rested</em> or <em>remained.</em> <span class="auth">(TA.)</span> And <span class="ar long">أتّى لِأَرْضِهِ أَتِيَّا</span> <em>He made a rivulet,</em> or <em>a channel for water, to run to his land.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ate_2_A2">
					<p><span class="ar long">أتّى ٱللّٰهُ لِفُلَانٍ أَمْرَهُ</span>, inf. n. <span class="ar">تَأْتِيَةٌ</span>, <span class="auth">(T, M,* TA,)</span> <em>God prepared, disposed, arranged,</em> or <em>put into a good</em> or <em>right state,</em> <span class="add">[and thus <em>rendered feasible</em> or <em>practicable</em> or <em>easy,</em>]</span> <em>for such a one, his affair.</em> <span class="auth">(M,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ate_3">
				<h3 class="entry">3. ⇒ <span class="ar">آتى</span></h3>
				<div class="sense" id="Ate_3_A1">
					<p><span class="ar">آتَاهُ</span>, <span class="add">[inf. n. as below,]</span> <em>He requited, compensated,</em> or <em>recompensed, him.</em> <span class="auth">(M, Ḳ.)</span> The saying, in the Ḳur <span class="add">[xxi. 48]</span>, <span class="arrow"><span class="ar long">وَإِنْ كَانَ مِثْقَالَ حَبَّةٍ مِنْ خَرْدَلٍ أَتَيْنَا↓ بِهَا</span></span>, some read thus, <span class="auth">(M,* TA,)</span> meaning <span class="add">[<em>Though it be the weight of a grain of mustard,</em>]</span> <em>we will bring it</em> <span class="add">[forward for requital]</span>: others read<span class="arrow"><span class="ar long">آتَيْنَا↓ بها</span></span>, meaning <em>we will give</em> <span class="add">[a recompense]</span> <em>for it;</em> in which case the verb is of the measure <span class="ar">أَفْعَلَ</span>: or <em>we will requite for it;</em> in which case the verb is of the measure <span class="ar">فَاعَلَ</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ate_3_A2">
					<p><span class="ar long">آتَيْتُهُ عَلَى الأَمْرِ</span>, <span class="auth">(T, Ṣ, M, Mṣb,)</span> inf. n. <span class="ar">مُؤَاتَاةٌ</span>, <span class="auth">(T, Ṣ,)</span> <em>I agreed with him,</em> or <em>was of one mind</em> or <em>opinion with him, upon,</em> or <em>respecting, the thing,</em> or <em>affair; I complied with him respecting it;</em> <span class="auth">(T, Ṣ, M, Mṣb;)</span> <em>in a good manner:</em> <span class="auth">(T:)</span> the vulgar say, <span class="ar">وَاتَيْتُهُ</span>: <span class="auth">(Ṣ:)</span> this is of the dial. of the people of El-Yemen, inf. n. <span class="ar">مُوَاتَاةٌ</span>; and is the form commonly current: <span class="auth">(Mṣb:)</span> but it should not be used, except in the dial. of the people of El-Yemen. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ate_3_A3">
					<p><span class="add">[Hence, app., <span class="ar">آتَى</span> as meaning <em>He aided;</em> a signification mentioned by Golius, on the authority of Z and Ibn-Maạroof.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ate_4">
				<h3 class="entry">4. ⇒ <span class="ar">آتى</span></h3>
				<div class="sense" id="Ate_4_A1">
					<p><span class="ar">آتَاهُ</span>, <span class="auth">(Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">إِيتَآءٌ</span>, <span class="auth">(TA,)</span> <em>i. q.</em> <span class="ar">أَتَى</span> <span class="add">[<em>He came with,</em> or <em>brought, him,</em> or <em>it</em>]</span>; <span class="auth">(Ṣ;)</span> <em>he made it</em> <span class="auth">(a thing)</span> <em>to come,</em> <span class="ar">إِلَيْهِ</span> <em>to him;</em> <span class="auth">(TA;)</span> <em>he made,</em> or <em>caused, him,</em> or <em>it, to be present;</em> <span class="auth">(Ksh, TA;)</span> <em>he made,</em> or <em>caused, it</em> <span class="auth">(a thing)</span> <em>to go, pass,</em> or <em>be conveyed</em> or <em>transmitted,</em> <span class="auth">(syn. <span class="ar">سَاقَهُ</span>,)</span> <span class="ar">إِلَيْهِ</span> <em>to him.</em> <span class="auth">(M, Ḳ.)</span> It is said in the Ḳur <span class="add">[xviii. 61]</span>, <span class="ar long">آتِنَا غَدآءَ نَا</span>, i. e. <span class="ar">اِيتِنَا</span> <span class="add">[<em>Come thou to us with,</em> or <em>bring thou to us, our morningmeal</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ate_4_A2">
					<p>Hence, <span class="auth">(Ksh, TA,)</span> inf. n. as above, <span class="auth">(T, Ṣ,)</span> <em>He gave him</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> a thing, <span class="auth">(M, Ḳ,)</span> or property: <span class="auth">(Mṣb:)</span> and you say, <span class="ar">هَاتِ</span> in the sense of the <span class="add">[imperative]</span> <span class="ar">آتِ</span> <span class="add">[<em>give thou</em>]</span>. <span class="auth">(T.)</span> We read in the Ḳur. <span class="add">[v. 60, &amp;c.]</span> <span class="ar long">وَيُؤْتُونَ الزَّكَاةَ</span> <span class="add">[<em>And they give the portion of property which is the due of the poor</em>]</span>. <span class="auth">(TA.)</span> And in <span class="add">[xxvii. 23 of]</span> the same, <span class="ar long">وَأُوتِيَتْ مِنْ كُلِّ شَىْءٍ</span>, meaning <em>And she hath been given</em> somewhat <em>of everything.</em> <span class="auth">(M, TA.)</span> <span class="add">[You say also, <span class="ar long">أُوتِىَ كَذَا</span> as meaning <em>He was gifted,</em> or <em>endowed, with such a thing;</em> as, for instance, a faculty.]</span> <a href="#Ate_3">See also 3</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ate_4_A3">
					<p><span class="ar long">آتَيْتُ المُكَاتَبَ</span> <em>I made a gift to the slave between whom and me was a contract that he should become free on payment of a certain sum:</em> or <em>I abated,</em> or <em>took off, somewhat of his appointed part-payments,</em> or <em>instalments.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Ate_4_A4">
					<p><span class="ar long">مَا آتَاكُمُ الرَّسُولُ</span>, in the Ḳur lix. 7, means <em>What the Apostle giveth you,</em> of the <span class="add">[spoil termed]</span> <span class="ar">فَىْء</span>, <span class="auth">(Bḍ, Jel,)</span>, &amp;c.: <span class="auth">(Jel:)</span> or <em>what command he giveth you:</em> <span class="auth">(Bḍ:)</span> or <em>what he commandeth you</em> <span class="add">[<em>to receive</em>]</span>. <span class="auth">(Kull.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Ate_4_A5">
					<p><span class="ar long">أُوتِىَ فِى شَىْءٍ</span> <em>A dispute,</em> or <em>an altercation, was held before him, respecting the meaning of a thing:</em> <span class="add">[perhaps more properly signifying <em>he was given authority to decide respecting a thing:</em>]</span> occurring in a trad. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ate_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأتّى</span></h3>
				<div class="sense" id="Ate_5_A1">
					<p><span class="ar long">تأتّى لَهُ</span> <em>It</em> <span class="auth">(an affair, T, Mgh, Mṣb, Ḳ, or a thing, Ṣ, M)</span> <em>was,</em> or <em>became, prepared, disposed, arranged,</em> or <em>put into a good</em> or <em>right state, for him;</em> <span class="auth">(T,* Ṣ, M, Mgh, Mṣb, Ḳ;)</span> and hence, <em>it</em> <span class="auth">(a thing)</span> <em>was,</em> or <em>became, feasible</em> or <em>practicable, and easy, to him;</em> <span class="auth">(Mgh;)</span> <em>it</em> <span class="auth">(an affair)</span> <em>was,</em> or <em>became, facilitated,</em> or <em>easy, to him;</em> <span class="auth">(Mṣb;)</span> <em>the way thereof</em> <span class="auth">(i. e. of an affair)</span> <em>was,</em> or <em>became, facilitated,</em> or <em>easy, to him.</em> <span class="auth">(TA.)</span> The following is an ex.:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَأَتَّى لَهُ الدَّهْرُ حَتَّى انْجَبَرْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Fortune became well,</em> or <em>rightly, disposed for him, so that he became restored to wealth,</em> or <em>competence</em>]</span>: <span class="auth">(T:)</span> or <span class="ar long">تَأَتَّى لَهُ الخَيْرُ الخ</span> <span class="add">[<em>good fortune,</em> or <em>prosperity, became prepared,</em>, &amp;c., <em>for him,</em>, &amp;c.]</span>. <span class="auth">(So in the TA.)</span> And hence the saying, <span class="ar long">هٰذَا مِمَّا يَتَأَتَّى لِىَ المَضْغُ</span> <em>This is of the things which it is feasible</em> or <em>practicable, and easy, to me to chew.</em> <span class="auth">(Mgh)</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ate_5_A2">
					<p><em>He applied himself to it with gentleness,</em> <span class="auth">(Aṣ, Ṣ, Ḳ,)</span> and so <span class="ar long">تأتّى لَهَا</span>, meaning <span class="ar">لِحَاجَتِهِ</span>, <em>to his needful affair</em> or <em>business,</em> <span class="auth">(T,)</span> <em>and entered into it, engaged in it, occupied himself with it, did it, executed it,</em> or <em>performed it, by the way,</em> or <em>manner, proper,</em> or <em>suitable, to it.</em> <span class="pb" id="Page_0017"></span><span class="auth">(Aṣ, T, Ṣ, Ḳ. <span class="add">[In the CK, for <span class="ar long">أَتَاهُ مِنْ وَجْهِهِ</span>, we find <span class="ar long">اتاهُ عن وَجْهِه</span>.]</span>)</span> And <span class="ar long">تأتّى فِى أَمرِهِ</span> <em>He used gentleness,</em> or <em>acted gently, in his affair.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ate_5_A3">
					<p><span class="ar long">تأتّى لَهُ بِسَهْمٍ حَتَّى أَصَابَهُ</span> <em>He sought him leisurely</em> or <em>repeatedly</em> <span class="add">[<em>with an arrow,</em> app. <em>taking aim in one direction and then in another, until he hit him</em>]</span>. <span class="auth">(Z, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Ate_5_A4">
					<p><span class="ar long">جَآءَ فُلَانٌ يَتَأَتَّى</span> is explained by Fr as meaning <span class="ar long">يَتَعَرَّضُ لِمَعْرُوفِكَ</span> <span class="add">[<em>Such a one came,</em> or <em>has come, addressing,</em> or <em>applying,</em> or <em>directing, himself,</em> or <em>his regard,</em> or <em>attention,</em> or <em>mind, to obtain thy favour,</em> or <em>bounty</em>]</span>. <span class="auth">(Ṣ.)</span> And you say, <span class="ar long">تأتّى لِمَعرُوفِهِ</span>, meaning <span class="ar long">تَعَرَّضَ لَهُ</span> <span class="add">[<em>He addressed, applied,</em> or <em>directed, himself,</em>, &amp;c., <em>to obtain his favour,</em> or <em>bounty</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Ate_5_A5">
					<p>Some say that <span class="ar">تأتّى</span> signifies <em>He prepared himself to rise,</em> or <em>stand.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ate_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأتى</span></h3>
				<div class="sense" id="Ate_10_A1">
					<p><span class="ar long">استأتى فلَانًا</span> <em>He asked such a one to come, deeming him slow,</em> or <em>tardy.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ate_10_A2">
					<p><span class="ar long">استأتت النَّاقَةُ</span> <em>The she-camel desired to be covered;</em> <span class="auth">(A, TA;)</span>IE <em>desired the stallion;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>being excited by lust.</em> <span class="auth">(Ṣ, A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IitBae">
				<h3 class="entry"><span class="ar">إِتَّى</span></h3>
				<div class="sense" id="IitBae_A1">
					<p><span class="ar">إِتَّى</span>: <a href="#OatieBN">see <span class="ar">أَتِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatoyapN">
				<h3 class="entry"><span class="ar">أَتْيَةٌ</span></h3>
				<div class="sense" id="OatoyapN_A1">
					<p><span class="ar">أَتْيَةٌ</span> <em>A single coming;</em> as also <span class="ar">أَتْوَةٌ</span>; but not <span class="arrow"><span class="ar">إِتْيَانَةٌ↓</span></span>, unless by a bad poetic licence. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">أَتْيَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OatoyapN_A2">
					<p><a href="#OutiyBapu">See also <span class="ar long">أُتِيَّةُ الجُرحِ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IitoyaAnN">
				<h3 class="entry"><span class="ar">إِتْيَانٌ</span></h3>
				<div class="sense" id="IitoyaAnN_A1">
					<p><span class="ar">إِتْيَانٌ</span> <a href="#Ate_1">is either an inf. n. of <span class="ar">أَتَى</span></a>, or a simple subst. <span class="add">[signifying <em>A coming</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IitoyaAnapN">
				<h3 class="entry"><span class="ar">إِتْيَانَةٌ</span></h3>
				<div class="sense" id="IitoyaAnapN_A1">
					<p><span class="ar">إِتْيَانَةٌ</span> <a href="#Ate_1">an inf. n. of 1 <span class="add">[q. v.]</span></a>: <span class="auth">(M, Ḳ:)</span> <a href="#OatoyapN">see also <span class="ar">أَتْيَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OataMCN.1">
				<h3 class="entry"><span class="ar">أَتَآءٌ</span> / <span class="ar">إِتَآءٌ</span></h3>
				<div class="sense" id="OataMCN.1_A1">
					<p><span class="ar">أَتَآءٌ</span> or <span class="ar">إِتَآءٌ</span>: <a href="#AtieBN">see <span class="ar">أتِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatieBN.1">
				<h3 class="entry"><span class="ar">أَتِىٌّ</span></h3>
				<div class="sense" id="OatieBN.1_A1">
					<p><span class="ar">أَتِىٌّ</span> as syn. with <span class="ar">أتَاوِىٌّ</span>: <a href="index.php?data=01_A/016_Atw">see art. <span class="ar">اتو</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">أَتِىٌّ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OatieBN.1_A2">
					<p>Also, <span class="auth">(M, and so in some copies of the Ḳ, where it is said to be like <span class="ar">رَضِىٌّ</span>,)</span> or<span class="arrow"><span class="ar">إِتًى↓</span></span>, like <span class="ar">رِضًى</span>, <span class="auth">(so in other copies of the Ḳ,)</span> and<span class="arrow"><span class="ar">أَتَآءٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> written by some <span class="ar">إِتَآءٌ</span>, <span class="auth">(TA,)</span> <em>What falls, of wood</em> or <em>leaves, into a river:</em> <span class="auth">(M, Ḳ:)</span> from <span class="ar">الإِتْيَانُ</span>: <span class="auth">(M:)</span> pl. <span class="ar">آتَآءٌ</span><span class="add">[in the CK <span class="ar">اِتاء</span>]</span> and <span class="ar">أُتِىٌّ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">أَتِىٌّ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OatieBN.1_A3">
					<p><span class="ar long">رَجُلٌ أَتِىٌّ</span> <em>A man who is sharp, energetic, vigorous, and effective, in affairs; who applies himself to them with gentleness, and enters into them,</em> or <em>performs them, by the way,</em> or <em>manner, proper,</em> or <em>suitable, to them.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">أَتِىٌّ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OatieBN.1_A4">
					<p><span class="ar long">فَرَسٌ أَتِىٌّ</span>: <a href="#musotaOotK">see <span class="ar">مُسْتَأْتٍ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OutiyBapu">
				<h3 class="entry"><span class="ar">أُتِيَّةُ</span></h3>
				<div class="sense" id="OutiyBapu_A1">
					<p><span class="ar long">أُتِيَّةُ الجُرْحِ</span>, <span class="auth">(so in a copy of the M,)</span> or<span class="arrow"><span class="ar">أُتِّيَّتُهُ↓</span></span>, <span class="auth">(so in some copies of the Ḳ, and accord. to the TA,)</span> or<span class="arrow"><span class="ar">أَتْيَتُهُ↓</span></span>, <span class="auth">(so in other copies of the Ḳ,)</span> and<span class="arrow"><span class="ar">آتِيَتُهُ↓</span></span>, <span class="auth">(so in the M, and in some copies of the Ḳ,)</span> or<span class="arrow"><span class="ar">إِتِّيَتُهُ↓</span></span>, <span class="auth">(so in some copies of the Ḳ, and accord. to the TA,)</span> or <span class="ar">أَتِيَّتُهُ</span>, <span class="auth">(so in a copy of the Ḳ,)</span> <em>The matter which comes from the wound:</em> <span class="auth">(M, Ḳ:)</span> from Aboo-ʼAlee. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatBae">
				<h3 class="entry"><span class="ar">أَتَّى</span></h3>
				<div class="sense" id="OatBae_A1">
					<p><span class="ar">أَتَّى</span> <em>i. q.</em> <span class="ar">حَتَّى</span>; <span class="auth">(Ḳ;)</span> a dial. var. of the latter. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IitBiyahu">
				<h3 class="entry"><span class="ar">إِتِّيَتُهُ</span> / <span class="ar">أُتِّيَّتُهُ</span></h3>
				<div class="sense" id="IitBiyahu_A1">
					<p><span class="ar long">إِتِّيَهُ الجُرحِ</span> and <span class="ar">أُتِّيَّتُهُ</span>: <a href="#OutiyBapu">see <span class="ar long">أُتِيَّةُ الآجُرْحِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MtK">
				<h3 class="entry"><span class="ar">آتٍ</span></h3>
				<div class="sense" id="MtK_A1">
					<p><span class="ar">آتٍ</span> <span class="add">[<em>Coming;</em> (<a href="#maOotieBN">see also <span class="ar">مَأْتِىٌّ</span></a>;) applied to a man, &amp;c.; and to time, meaning <em>future:</em> also <em>a comer:</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">آتٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MtK_A2">
					<p><span class="add">[and hence,]</span> <em>An angel.</em> <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mtiyapu">
				<h3 class="entry"><span class="ar">آتِيَةُ</span></h3>
				<div class="sense" id="Mtiyapu_A1">
					<p><span class="ar long">آتِيَةُ الجُرحِ</span>: <a href="#OutiyBapu">see <span class="ar long">أُتِيَّةُ الجُرْحِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOotFe">
				<h3 class="entry"><span class="ar">مَأْتًى</span></h3>
				<div class="sense" id="maOotFe_A1">
					<p><span class="ar">مَأْتًى</span> <em>A place of coming.</em> <span class="auth">(Mṣb.)</span> <span class="add">[And<span class="arrow"><span class="ar">مَأْتَاةً↓</span></span> signifies the same: or <em>A road,</em> or <em>way, by which one comes; a way of access; an approach;</em> as also <span class="ar">مَأْتًى</span>: or, more properly, <em>a means of coming.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مَأْتًى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOotFe_A2">
					<p><span class="ar long">مَأْتَى المَرْأَةِ</span> <span class="add">[<em>The place of access of the woman;</em> i. e. <em>the meatus of her vagina;</em> or <em>her vagina</em> itself;]</span> <em>the</em> <span class="ar">مَحِيض</span>, or <em>place of menstruation, of the woman.</em> <span class="auth">(Zj in the TA in art. <span class="ar">حيض</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مَأْتًى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOotFe_A3">
					<p><span class="ar long">مَأْتَىِ الأَمرِ</span> and<span class="arrow"><span class="ar">مَأْتَاتُهُ↓</span></span> <em>The way,</em> or <em>manner,</em> (<span class="ar">وَجْه</span>, Ṣ, or <span class="ar">جِهَة</span>, M, Ḳ,) <em>of the affair,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>by which it is,</em> or <em>is to be, entered into, engaged in, done, executed,</em> or <em>performed;</em> like as you say <span class="ar long">مَعْنَى الكَلَامِ</span> and <span class="ar">مَعْنَاتُهُ</span>, meaning the same by both. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">أَتَيْتُ الأَمْرَ مِنْ مَأْتاهُ</span> and<span class="arrow"><span class="ar">مَأْتَاتِهِ↓</span></span>, <span class="auth">(Ṣ, M,)</span> i. e., <span class="ar long">مِنْ وَجْهِهِ الَّذِى يُؤُتَى مِنْهُ</span> <span class="add">[<em>I entered into, engaged in, did, executed,</em> or <em>performed, the affair by the way,</em> or <em>manner, whereby it should be entered into,</em>, &amp;c.]</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">مِنْ جِهَتِهِ</span> <span class="add">[which means the same]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWotFe">
				<h3 class="entry"><span class="ar">مُؤْتًى</span></h3>
				<div class="sense" id="muWotFe_A1">
					<p><span class="ar">مُؤْتًى</span>: <a href="#musotaOotK">see <span class="ar">مُسْتَأْتٍ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOotaApN">
				<h3 class="entry"><span class="ar">مَأْتَاةٌ</span></h3>
				<div class="sense" id="maOotaApN_A1">
					<p><span class="ar">مَأْتَاةٌ</span>: <a href="#maOotFe">see <span class="ar">مَأْتًى</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOotieBN">
				<h3 class="entry"><span class="ar">مَأْتِىٌّ</span></h3>
				<div class="sense" id="maOotieBN_A1">
					<p><span class="ar">مَأْتِىٌّ</span> <span class="add">[pass. part. n. of 1; <em>Come: come to:</em>]</span> is of the measure <span class="ar">مَفْعُولٌ</span>; the <span class="ar">و</span> being changed into <span class="ar">ى</span> and incorporated into the <span class="ar">ى</span> which is the final radical letter. <span class="auth">(Ṣ.)</span> In the saying, in the Ḳur <span class="add">[xix. 62]</span>, <span class="ar long">إِنَّهُ كَانَ وَعْدُهُ مَأْتِيًّا</span>, the meaning is <span class="arrow"><span class="ar">آتِيًا↓</span></span> <span class="add">[<em>Verily that which He hath promised,</em> or <em>the fulfilment of his promise, is coming</em>]</span>; like as, in the phrase <span class="ar long">حِجَابًا مَسْتُورًا</span>, in the Ḳur <span class="add">[xvii. 47]</span>, <span class="ar">سَاتِرًا</span> is meant: or it may be a pass. part. n. <span class="add">[in signification as well as form]</span>; for what cometh to thee, of that which God commandeth, thou comest thereto. <span class="auth">(Ṣ.)</span> It is said in a prov., <span class="ar long">مَأْتِىٌّ أَنْتَ أَيُّهَا السَّوَادُ</span><span class="add">[lit. <em>Thou art come to, O thou person</em>]</span>, meaning <em>there is no escape for thee from this event.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مَأْتِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOotieBN_A2">
					<p>Applied to a man, it also signifies <span class="ar long">أُتِىَ فِيهِ</span><span class="add">[in a sense indicated in the Ḳur xxvi. 165]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYotaMCN">
				<h3 class="entry"><span class="ar">مِئْتَآءٌ</span></h3>
				<div class="sense" id="miYotaMCN_A1">
					<p><span class="ar long">طَرِيقٌ مِئْتَآءٌ</span> <em>A road to which people come</em> <span class="auth">(Th, M, Mgh, Mṣb)</span> <em>much,</em> or <em>often;</em> <span class="auth">(Mgh, Mṣb;)</span> the latter word being of the measure <span class="ar">مِفْعَال</span>, <span class="auth">(Th, M, Mgh, Mṣb,)</span> originally <span class="ar">مِئْتَاىٌ</span> or <span class="ar">مِئْتَاوٌ</span>; <span class="auth">(Mṣb;)</span> from <span class="ar">أَتَيْتُ</span>, <span class="auth">(Th, M,)</span> or <span class="ar">الإِتْيَانُ</span>; <span class="add">[or from <span class="ar">أَتَوْتُ</span>;]</span> like <span class="ar long">دَارٌ مِحْلاَلٌ</span>, i. e. a house where people alight or abide much, or often: <span class="auth">(Mgh, Mṣb:)</span> <em>a road that is frequented</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>and conspicuous:</em> <span class="auth">(M, Ḳ:)</span> in <span class="add">[some of]</span> the copies of the Ḳ, incorrectly, <span class="ar">مِئْتَآءَةٌ</span>: <span class="auth">(TA:)</span> AʼObeyd has inadvertently written it without <span class="add">[the radical]</span> <span class="ar">ء</span>, and in the category of <span class="ar">فِعْلَآءٌ</span>. <span class="auth">(M.)</span> Death is thus termed in a trad., as being a way which every one travels: <span class="auth">(TA:)</span> and as that trad. is related, it is without <span class="add">[the radical]</span> <span class="ar">ء</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مِئْتَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="miYotaMCN_A2">
					<p><span class="ar long">مئْتَآءٌ الطَّرِيقِ</span> <em>The main part,</em> or <em>middle, of the road;</em> or <em>the part of the road along which one travels:</em> <span class="auth">(Sh, TA:)</span> or <em>the space within which the road is comprised;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also <span class="ar long">مِيدَآءُ الطريقِ</span>: <span class="auth">(TA:)</span> or this last, as also <span class="ar long">مِيتَآءُ الطريقِ</span>, signifies <em>the measure of the two sides, and the distance, of the road.</em> <span class="auth">(L in art. <span class="ar">ميت</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مِئْتَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="miYotaMCN_A3">
					<p><span class="ar">مِئْتَآءٌ</span> also signifies <em>The extreme limit of the distance to which horses run;</em> <span class="auth">(Ṣ, Mṣb;)</span> and so <span class="ar">مِيدَآءٌ</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مِئْتَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="miYotaMCN_A4">
					<p>And <em>i. q.</em> <span class="ar">تِلْقَآءٌ</span><span class="auth">(Ḳ.)</span> You say, <span class="ar long">دَارِى بِمئْتَآءِ دَارِ فُلَانٍ</span> <em>My house is opposite to the house of such a one; facing it,</em> or <em>fronting it;</em> and so <span class="ar long">بِمِيدَآءِ دِارِهِ</span>; <span class="auth">(Ṣ;)</span> and <span class="ar long">بِمِيتَآءِ دَارِهِ</span>. <span class="auth">(L in art. <span class="ar">ميت</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مِئْتَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="miYotaMCN_A5">
					<p>And <span class="ar long">بَنَى القَوْمُ بُيُوتَهُمْ عَلَى مِئْتَآءٍ وَاحِدٍ</span><span class="auth">(Ṣ)</span> and <span class="ar long">مِيدَآءٍ وَاحِدٍ</span><span class="auth">(Ṣ, and L in art. <span class="ar">ميد</span>,)</span> <em>The people built their houses,</em> or <em>constructed their tents, after one mode, manner, fashion,</em> or <em>form.</em> <span class="auth">(L in art. <span class="ar">ميد</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتى</span> - Entry: <span class="ar">مِئْتَآءٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="miYotaMCN_B1">
					<p><span class="ar long">رَجُلٌ مِئتَآءٌ</span> <em>A man who requites, compensates,</em> or <em>recompenses; who gives much,</em> or <em>largely.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaOotK">
				<h3 class="entry"><span class="ar">مُسْتَأْتٍ</span></h3>
				<div class="sense" id="musotaOotK_A1">
					<p><span class="ar long">فَرَسٌ مُسْتَأْتٍ</span>, and<span class="arrow"><span class="ar">أَتِىٌّ↓</span></span>, and<span class="arrow"><span class="ar">مُؤْتًى↓</span></span>, and <span class="ar">مستوتى</span>, <span class="add">[so I find it written, perhaps for <span class="ar">مُسْتَوْتٍ</span>, which may be a dial. van. of <span class="ar">مُسْتأْتٍ</span>, like as <span class="ar">وَاتَيْتُهُ</span> is of <span class="ar">آتَيْتُهُ</span>,]</span> <em>A mare desiring the stallion.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0015.pdf" target="pdf">
							<span>Lanes Lexicon Page 15</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0016.pdf" target="pdf">
							<span>Lanes Lexicon Page 16</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0017.pdf" target="pdf">
							<span>Lanes Lexicon Page 17</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
