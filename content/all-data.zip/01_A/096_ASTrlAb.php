<article class="root" id="Root_ASTrlAb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/095_ASTbl">اصطبل</a></span>
				<span class="ar">اصطرلاب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/097_ASl">اصل</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="OaSoTurolaAbN">
				<h3 class="entry"><span class="ar">أَصْطُرْلَابٌ</span> / <span class="ar">أُصْطُرْلَابٌ</span></h3>
				<div class="sense" id="OaSoTurolaAbN_A1">
					<p><span class="ar">أَصْطُرْلَابٌ</span> or <span class="ar">أُصْطُرْلَابٌ</span>: <a href="#AsTrlAb">see <span class="ar">اسطرلاب</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0064.pdf" target="pdf">
							<span>Lanes Lexicon Page 64</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
