<article class="root" id="Root_Azf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/066_Azr">ازر</a></span>
				<span class="ar">ازف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/068_Azq">ازق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azf_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزف</span></h3>
				<div class="sense" id="Azf_1_A1">
					<p><span class="ar">أَزِفَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْزَفُ</span>}</span></add>, inf. n. <span class="ar">أَزَفٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">أُزُوفٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <em>It</em> <span class="auth">(departure)</span> <em>was,</em> or <em>became,</em> or <em>drew, near:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> and in like manner, a time. <span class="auth">(TA.)</span> Hence, in the Ḳur <span class="add">[liii. 58]</span>, <span class="ar long">أَزِفَتِ الآزِفَةُ</span> <em>The resurrection draweth near.</em> <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Azf_1_A2">
					<p><em>He</em> <span class="auth">(a man)</span> <em>hastened,</em> or <em>was quick:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>he drew near, and hastened,</em> or <em>was quick.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azf_4">
				<h3 class="entry">4. ⇒ <span class="ar">آزف</span></h3>
				<div class="sense" id="Azf_4_A1">
					<p><span class="ar">آزَفَنِى</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>incited me,</em> or <em>urged me, to hasten,</em> or <em>be quick:</em> <span class="auth">(Ḳ, TA:)</span> it is of the measure <span class="ar">أَفْعَلَنِى</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azf_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأزّف</span></h3>
				<div class="sense" id="Azf_5_A1">
					<p><span class="ar">تَأَزُّفٌ</span> The <em>stepping with contracted steps.</em> <span class="auth">(Ḳ.)</span> <a href="#mutaAzifN">But see <span class="ar long">خَطْوٌ مُتَآزِفٌ</span>, below</a>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azf_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآزف</span></h3>
				<div class="sense" id="Azf_6_A1">
					<p><span class="ar">تآزفوا</span> <em>They drew near together, one to another.</em> <span class="auth">(IF, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MzifN">
				<h3 class="entry"><span class="ar">آزِفٌ</span></h3>
				<div class="sense" id="MzifN_A1">
					<p><span class="ar">آزِفٌ</span>, applied to a man, <em>Hastening,</em> or <em>quick:</em> <span class="auth">(Ṣ, TA:)</span> and <em>endeavouring to hasten,</em> or <em>be quick.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlMzifapu">
				<h3 class="entry"><span class="ar">الآزِفَةُ</span></h3>
				<div class="sense" id="AlMzifapu_A1">
					<p><span class="ar">الآزِفَةُ</span> <em>The resurrection:</em> so in the Ḳur liii. 58, <span class="auth">(Ṣ, Mṣb,)</span> and xl. 18: <span class="auth">(Bḍ:)</span> or in the latter place it means <em>the near event,</em> or <em>case, of being on the brink of the fire</em> <span class="add">[<em>of Hell</em>]</span>: or, as some say, <em>death.</em> <span class="auth">(Bḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaMzifN">
				<h3 class="entry"><span class="ar">مُتَآزِفٌ</span></h3>
				<div class="sense" id="mutaMzifN_A1">
					<p><span class="ar">مُتَآزِفٌ</span>, of the measure <span class="ar">مُتَفَاعِلٌ</span>, applied to a man, <span class="auth">(TA,)</span> <em>Short;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> as being contracted in make; <span class="auth">(A, TA;)</span> <em>having his several parts near together.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[In the CK it is written <span class="ar">مُتَأزِّف</span>, in this sense and others, following.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازف</span> - Entry: <span class="ar">مُتَآزِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutaMzifN_A2">
					<p>A <em>strait,</em> or <em>narrow,</em> place. <span class="auth">(O, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازف</span> - Entry: <span class="ar">مُتَآزِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mutaMzifN_A3">
					<p>A <em>contracted</em> stepping: you say, <span class="ar long">خَطْوٌ مُتَآزِفٌ</span>: so in the O and L. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازف</span> - Entry: <span class="ar">مُتَآزِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="mutaMzifN_A4">
					<p>‡ A man <span class="auth">(Ṣgh, TA)</span> <em>evil in disposition; narrow-minded:</em> <span class="auth">(Ṣgh, Ḳ, TA:)</span> <em>weak; cowardly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0053.pdf" target="pdf">
							<span>Lanes Lexicon Page 53</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
