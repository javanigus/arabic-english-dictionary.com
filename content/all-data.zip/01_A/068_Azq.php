<article class="root" id="Root_Azq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/067_Azf">ازف</a></span>
				<span class="ar">ازق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/069_Azl">ازل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azq_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزق</span></h3>
				<div class="sense" id="Azq_1_A1">
					<p><span class="ar">أَزَقَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِقُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> and <span class="ar">أَزِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْزَقُ</span>}</span></add>; <span class="auth">(IDrd, Ḳ;)</span> inf. n. <span class="auth">(of the former, TA)</span> <span class="ar">أَزْقٌ</span>, <span class="auth">(Ṣ, O, Ḳ,)</span> and <span class="auth">(of the latter, TA)</span> <span class="ar">أَزَقٌ</span>, <span class="auth">(IDrd, Ḳ,)</span> or the latter is used by poetic licence for the former; <span class="auth">(Aṣ, Ṣgh;)</span> <em>He,</em> or <em>it,</em> <span class="auth">(said of a man, MF, or of a man's bosom or mind, Ḳ,)</span> <em>became strait,</em> or <em>straitened;</em> <span class="auth">(IDrd, Ṣ,* O,* Ḳ, MF;)</span> <span class="ar">أَزْقٌ</span> being thus <em>syn. with</em> <span class="ar">أَزْلٌ</span>: <span class="auth">(Ṣ, O:)</span> or <em>it</em> <span class="auth">(a man's bosom or mind)</span> <em>became straitened in war</em> or <em>fight;</em> <span class="auth">(Ḳ;)</span> or <em>he</em> <span class="auth">(a man)</span> <em>became straitened in his bosom</em> or <em>mind, in war</em> or <em>fight:</em> <span class="auth">(TA:)</span> as also<span class="arrow"><span class="ar">تأزّق↓</span></span>, with respect to both these significations; <span class="auth">(Ḳ;)</span> or this signifies <em>it</em> <span class="auth">(a man's bosom or mind)</span> <em>became strait,</em> or <em>straitened;</em> like <span class="ar">تأزّل</span>; <span class="auth">(Fr, Ṣ;)</span> and<span class="arrow"><span class="ar">تآزق↓</span></span> signifies the same as <span class="ar">تأزّق</span>. <span class="auth">(Z, in Golius.)</span> <span class="add">[<a href="#Azq_10">See also 10</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازق</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Azq_1_B1">
					<p><span class="ar">أَزَقَهُ</span>, inf. n. <span class="ar">أَزْقٌ</span>, <em>He straitened him:</em> the verb being trans. and intrans. <span class="auth">(MF.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Azq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأزّق</span></h3>
				<div class="sense" id="Azq_5_A1">
					<p><a href="#Azq_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Azq_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآزق</span></h3>
				<div class="sense" id="Azq_6_A1">
					<p><a href="#Azq_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azq_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأزق</span></h3>
				<div class="sense" id="Azq_10_A1">
					<p><span class="ar long">ٱسْتُؤْزِقَ عَلَى فُلَانٍ</span> <em>The place became strait to such a one,</em> <span class="auth">(Ḳ, TA,)</span> <em>so that he was unable to go forth</em> <span class="add">[<em>into it, to war</em> or <em>fight</em>]</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoziqN">
				<h3 class="entry"><span class="ar">مَأْزِقٌ</span></h3>
				<div class="sense" id="maOoziqN_A1">
					<p><span class="ar">مَأْزِقٌ</span> <em>A place of straitness,</em> or <em>a strait place,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>in which people fight.</em> <span class="auth">(TA.)</span> And hence, <em>A place of war</em> or <em>fight.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">مَأْزِقُ العَيْشِ</span> <em>The place of straitness of life,</em> or <em>living.</em> <span class="auth">(Lḥ.)</span> Pl. <span class="ar">مَآزِقُ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0053.pdf" target="pdf">
							<span>Lanes Lexicon Page 53</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
