<article class="root" id="Root_Anq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/145_Anf">انف</a></span>
				<span class="ar">انق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/147_Ank">انك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Anq_1">
				<h3 class="entry">1. ⇒ <span class="ar">أنق</span></h3>
				<div class="sense" id="Anq_1_A1">
					<p><span class="ar">أَنِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْنَقُ</span>}</span></add>, inf. n. <span class="ar">أَنَقٌ</span>, <em>It excited admiration and approval by its beauty</em> or <em>goodliness; it pleased,</em> or <em>rejoiced.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anq_1_A2">
					<p>Also, aor. and inf. n. as above, <em>He rejoiced; was joyful, happy,</em> or <em>pleased.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">أَنِقْتُ بِهِ</span>, <span class="auth">(Lth, JK, Mṣb, Ḳ,)</span> aor. and inf. n. as above, <span class="auth">(Lth, JK,)</span> <em>I was pleased with it,</em> or <em>by it;</em> or <em>was rejoiced by it.</em> <span class="auth">(Lth, JK, Mṣb, Ḳ. <span class="add">[In the CK <span class="ar">اَعْجَبَ</span> is erroneously put for <span class="ar">أُعْجِبَ</span>.]</span>)</span> It is said in a trad., <span class="ar long">مَا مِنْ عَاشِيَةٍ أَشَدُّ أَنَقًا وَلَا أَبْعَدُ شِبَعًا مِنْ طَالِبِ عِلْمٍ</span> <em>There is not any eater by night</em> <span class="add">[i. e. any man]</span> <em>who hath more pleasure and approval and desire and love</em> <span class="add">[in his pursuit, <em>nor any who is further from satiation</em> therein, <em>than the student,</em> or <em>pursuer, of science</em>]</span>; meaning that the man of learning is excessively greedy and insatiable, persevering in vehement desire. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Anq_1_A3">
					<p>And <span class="ar long">أَنَقَ الشَّىْءَ</span>, <span class="auth">(AZ, Ḳ,)</span> inf. n. as above, <span class="auth">(AZ,)</span> <em>He loved the thing.</em> <span class="auth">(AZ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anq_2">
				<h3 class="entry">2. ⇒ <span class="ar">أنّق</span></h3>
				<div class="sense" id="Anq_2_A1">
					<p><span class="ar">أنّق</span>, inf. n. <span class="ar">تَأْنِيقٌ</span>, <em>He made,</em> or <em>caused, to wonder.</em> <span class="auth">(Ḳ, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anq_4">
				<h3 class="entry">4. ⇒ <span class="ar">آنق</span></h3>
				<div class="sense" id="Anq_4_A1">
					<p><span class="ar">آنَقَنِى</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِيْنَاقٌ</span> and <span class="ar">نِيقٌ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[but the latter is properly a quasi-inf. n.,]</span> <em>It excited my admiration and approval; pleased me;</em> or <em>rejoiced me.</em> <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انق</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anq_4_A2">
					<p><span class="ar long">مَا آنَقَهُ فِى كَذَا</span> <em>How vehemently does he seek,</em> or <em>pursue,</em> or <em>desire, such a thing!</em> or <em>how vehement is he in seeking, pursuit,</em> or <em>desire, with respect to such a thing!</em> <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأنّق</span></h3>
				<div class="sense" id="Anq_5_A1">
					<p><span class="ar">تأنّق</span> <em>He sought, pursued,</em> or <em>desired, the most pleasing of things;</em> <span class="auth">(TA;)</span> <span class="add">[<em>he affected nicety,</em> or <em>refinement; he was dainty, nice, exquisite, refined,</em> or <em>scrupulously nice and exact;</em> or <em>chose what was excellent,</em> or <em>best;</em> and <em>he exceeded the usual bounds;</em> as also <span class="ar">تَنَوَّقَ</span> and <span class="ar">تَنَيَّقَ</span>, in all these senses;]</span> <span class="ar long">فِى المَطْعَمِ</span>, <em>in respect of food, never eating anything but what was clean</em> <span class="add">[<em>and choice</em>]</span>; and <span class="ar long">فِى المَلْبَسِ</span>, <em>in respect of apparel, never dressing otherwise than well;</em> and <span class="ar long">فِى الكَلَامِ</span>, <em>in respect of speech, never speaking otherwise than chastely;</em> and <span class="ar long">فِى جَمِيعِ الأُمُورِ</span>, <em>in respect of all affairs.</em> <span class="auth">(TA in art. <span class="ar">نطس</span>.)</span> <span class="ar long">تأنّق فِيهِ</span> is like <span class="ar">تَنَوَّقَ</span>; <span class="auth">(JK, Ṣ, Ḳ;)</span> i. e. <em>He did it,</em> or <em>performed it</em> <span class="auth">(namely, a thing, or an affair,)</span> <em>with</em> <span class="ar">نِيقَة</span> <span class="add">[i. e. <em>daintiness, nicety, exquisiteness, refinement, neatness,</em> or <em>scrupulous nicety and exactness;</em> or <em>in a manner exceeding what is usual</em>]</span>: <span class="auth">(Ṣ:)</span> or <em>he chose what was excellent,</em> or <em>best, to be done in it, and did it admirably:</em> <span class="auth">(TA:)</span> or <em>he did it</em> <span class="auth">(namely, his work, Mṣb)</span> <em>firmly, solidly, soundly,</em> or <em>thoroughly,</em> <span class="auth">(Mṣb, Ḳ,)</span> <em>and skilfully.</em> <span class="auth">(Ḳ: <span class="add">[but in this last sense, ʼAlee Ibn-Hamzeh allows only the latter of these two verbs. TA in art. <span class="ar">نوق</span>.]</span>)</span> You say also, <span class="ar long">تأنّق فُلَانٌ فِى الَّرَّوْضَةِ</span> <em>Such a one found himself in the meadow,</em> or <em>garden,</em> (<span class="ar long">وَقَعَ فِيهَا</span>,) <em>pleased,</em> or <em>rejoiced, therewith:</em> <span class="auth">(Ṣ:)</span> or <em>he found it pleasant</em> or <em>delightful, delighted in it,</em> or <em>took pleasure or delight in it, and enjoyed its beauties:</em> and <em>he sought after its beauties, step by step, and was pleased,</em> or <em>rejoiced, therewith, and enjoyed it.</em> <span class="auth">(TA.)</span> And <span class="ar long">تأنّق المَكَانَ</span> <em>He was pleased,</em> or <em>rejoiced, with the place, and attached to it, not quitting it:</em> <span class="auth">(L:)</span> <em>he loved the place.</em> <span class="auth">(Fr, Ḳ.)</span> It is said in a trad. of Ibn-Mesʼood, <span class="ar long">إِذَا وَقَعْتُ فِى آلِ حٓمٓ وَقَعْتُ فِى رَوْضَاتٍ أَتَأَنَّقُهُنَّ</span>, or, as in the T, <span class="ar long">أَتَأَنَّقُ فِيهِنَّ</span>, meaning <span class="add">[<em>When I find myself in the chapters of the Ḳur-án commencing with Há Meem,</em>]</span> <em>I find myself in meadows,</em> or <em>gardens, the beauties of which I seek after step by step, and with which I am pleased,</em> or <em>rejoiced, and which I enjoy:</em> i. e., I find pleasure, or delight, in reading them, or reciting them, and enjoy their beauties. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanaqN">
				<h3 class="entry"><span class="ar">أَنَقٌ</span></h3>
				<div class="sense" id="OanaqN_A1">
					<p><span class="ar">أَنَقٌ</span> <a href="#Anq_1">inf. n. of 1 <span class="add">[q. v.]</span></a> <span class="auth">(Lth, JK, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انق</span> - Entry: <span class="ar">أَنَقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanaqN_A2">
					<p><span class="add">[Hence, <em>A pleasing,</em> or <em>rejoicing, state,</em> or <em>condition.</em>]</span> You say, <span class="ar long">هُوَ فِى أَنَقٍ مِنْ عَيْشِهِ وَخِصْبٍ</span> <span class="add">[<em>He is in a pleasing,</em> or <em>rejoicing, state,</em> or <em>condition, in respect of his life, and in a state of plenty</em>]</span>. <span class="auth">(JK.)</span></p>
				</div>
				<span class="pb" id="Page_0118"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">انق</span> - Entry: <span class="ar">أَنَقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OanaqN_A3">
					<p><em>Goodliness, or beauty, and pleasingness, of aspect,</em> or <em>outward appearance:</em> or, as some say, <em>a uniform and uninterrupted state of verdure before the eye;</em> because it pleases, or rejoices, its beholder. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انق</span> - Entry: <span class="ar">أَنَقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OanaqN_A4">
					<p><em>Herbage,</em> or <em>pasturage,</em> <span class="auth">(Ḳ, TA,)</span> <em>that is goodly, or beautiful, and pleasing,</em> or <em>rejoicing:</em> an inf. n. used as a subst. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaniqN">
				<h3 class="entry"><span class="ar">أَنِقٌ</span></h3>
				<div class="sense" id="OaniqN_A1">
					<p><span class="ar">أَنِقٌ</span>: <a href="#OaniyqN">see <span class="ar">أَنِيقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaniqapN">
				<h3 class="entry"><span class="ar">أَنِقَةٌ</span></h3>
				<div class="sense" id="OaniqapN_A1">
					<p><span class="ar long">مَا لَهُ فِى الشَّىْءِ أَنِقَةٌ</span> <em>He has no pleasure,</em> or <em>pride, in the thing.</em> <span class="auth">(JK.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanuwqN">
				<h3 class="entry"><span class="ar">أَنُوقٌ</span></h3>
				<div class="sense" id="OanuwqN_A1">
					<p><span class="ar">أَنُوقٌ</span> <em>A certain bird;</em> <span class="auth">(Ṣ;)</span> i. e. the <span class="ar">رَخَمَة</span> <span class="add">[or <em>female of the vultur percnopterus</em>]</span>; <span class="auth">(IAạr, Ṣ;)</span> called by Kumeyt <span class="ar long">ذَاتُ ٱسْمَيْنِ</span> <span class="add">[<em>possessor of two names</em>]</span> because having these two appellations: <span class="auth">(Ṣ:)</span> or the <em>eagle:</em> and also the <em>former bird:</em> <span class="auth">(Ḳ:)</span> ISk cites 'Omárah as saying that it is in his opinion the eagle; but that people say it is the <span class="ar">رخمة</span>; and he adds, <span class="add">[alluding to a prov., which see below,]</span> that the eggs of the <span class="ar">رخمة</span> are found in ruins, and in plain country: <span class="auth">(TA:)</span> or the <em>male of the</em> <span class="ar">رَخَم</span>: <span class="auth">(JK, TA:)</span> or <em>a certain black bird, having what resembles the</em> <span class="ar">عُرْف</span> <span class="add">[or <em>comb of the cock</em>]</span>, <span class="auth">(AA, Ḳ,)</span> <em>that deposits its eggs in remote places:</em> <span class="auth">(AA:)</span> or <em>a certain black bird,</em> <span class="auth">(AA, Ḳ,)</span> <em>like a great hen,</em> <span class="auth">(AA,)</span> <em>bald in the fore part of the head,</em> <span class="auth">(AA, Ḳ,)</span> <em>having a yellow bill,</em> <span class="auth">(Ḳ,)</span> or <em>having a long bill:</em> <span class="auth">(AA:)</span> she guards her eggs, and defends her young one, and keeps with her offspring, and submits not herself to any but her mate, and migrates among the first of the migrating birds, and returns among the first of the returning birds, and will not fly while moulting, and will not be deceived by her small feathers but waits until they become quills and then flies, and will not remain constantly in the nests, and will not alight upon the quiver <span class="auth">(Ḳ)</span> knowing it to contain arrows: <span class="auth">(TA:)</span> the word is sing. and pl.: <span class="auth">(TA:)</span> or its pl. is <span class="ar">أُنُقٌ</span>. <span class="auth">(JK.)</span> Hence the prov., <span class="auth">(JK, Ṣ,)</span> <span class="ar long">أَعَزُّ مِنْ بَيْضِ الأَنُوقِ</span> <span class="add">[<em>More rare than the eggs of the anook</em>]</span>: <span class="auth">(JK, Ṣ, Ḳ:)</span> because this bird guards its eggs, so that they are hardly ever, or never, found; for its nests are on the tops of mountains, and in difficult and distant places; <span class="auth">(Ṣ, Ḳ;)</span> notwithstanding which, it is said to be stupid: <span class="auth">(Ṣ:)</span> ISd says that the female bird called <span class="ar">رخمة</span> may be meant thereby; or the male, because the eggs of the male exist not; or the eggs of the latter may be meant because he often guards them, like as does the male ostrich. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaniyqN">
				<h3 class="entry"><span class="ar">أَنِيقٌ</span></h3>
				<div class="sense" id="OaniyqN_A1">
					<p><span class="ar">أَنِيقٌ</span> <em>Goodly,</em> or <em>beautiful;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>pleasing,</em> or <em>rejoicing;</em> <span class="auth">(JK, Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَنَقٌ↓</span></span>: <span class="auth">(JK, TA:)</span> and <em>loved.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">رَوْضَةٌ أَنِيقٌ</span> <em>A meadow,</em> or <em>garden, that is loved:</em> and <span class="ar long">رَوْضَةٌ أَنِيقَةٌ</span> <em>a meadow,</em> or <em>garden, that is pleasing,</em> or <em>rejoicing.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinaAqapN">
				<h3 class="entry"><span class="ar">إِنَاقَةٌ</span> / <span class="ar">أَنَاقَةٌ</span></h3>
				<div class="sense" id="IinaAqapN_A1">
					<p><span class="ar long">لَهُ إِنَاقَةٌ</span> and <span class="ar">أَنَاقَةٌ</span> <span class="auth">(Ḳ, and so in some copies of the Ṣ,)</span> <em>He has goodliness,</em> or <em>beauty,</em> and <em>pleasingness:</em> but in the L, <span class="add">[and in some copies of the Ṣ,]</span> <span class="ar long">لَهُ إِنَاقَةٌ وَلَبَاقةٌ</span>; and what precedes it indicates that the meaning is <em>he has a faculty of doing well</em> or <em>excellently</em> <span class="add">[<em>and of nice</em> or <em>refined skilfulness</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mnaqu">
				<h3 class="entry"><span class="ar">آنَقُ</span></h3>
				<div class="sense" id="Mnaqu_A1">
					<p><span class="ar">آنَقُ</span> <span class="add">[originally <span class="ar">أأْنَقُ</span>]</span> <em>More,</em> or <em>most, pleasing</em> or <em>rejoicing.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOanBiqN">
				<h3 class="entry"><span class="ar">مُتَأَنِّقٌ</span></h3>
				<div class="sense" id="mutaOanBiqN_A1">
					<p><span class="ar">مُتَأَنِّقٌ</span> <span class="add">[part. n. of 5; <em>Seeking, pursuing,</em> or <em>desiring, the most pleasing of things; affecting nicety,</em> or <em>refinement; dainty, nice, exquisite, refined,</em>, &amp;c.; in respect of food, apparel, speech, &amp;c.:]</span> one <em>who is in a pleasing condition</em> (<span class="ar long">فِى أَنَقٍ</span>) <em>in respect of his life, and in a state of plenty.</em> <span class="auth">(JK.)</span> It is said in a prov., <span class="ar long">لَيْسَ المُتَعَلِّقُ كَالمُتَأَنِّقِ</span>, <span class="auth">(JK, TA,)</span> i. e. <em>He who is content with what is little,</em> <span class="auth">(Ṣ, Ḳ, in art. <span class="ar">علق</span>,)</span> or <em>what is barely sufficient, of sustenance,</em> <span class="auth">(TA in the present art.,)</span> <em>is not like him who seeks, pursues,</em> or <em>desires, the most pleasing of things,</em> or <em>who is dainty,</em>, &amp;c., (<span class="ar long">مَنْ يَتَأَنَّقُ</span>,) <em>and eats what he pleases,</em> <span class="auth">(Ṣ, Ḳ, in art. <span class="ar">علق</span>,)</span> or <em>him who is not content save with the most pleasing of things.</em> <span class="auth">(TA in the present art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0117.pdf" target="pdf">
							<span>Lanes Lexicon Page 117</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0118.pdf" target="pdf">
							<span>Lanes Lexicon Page 118</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
