<article class="root" id="Root_Awn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/166_Awm">اوم</a></span>
				<span class="ar">اون</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/168_Awh">اوه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Awn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أون</span> ⇒ <span class="ar">آن</span></h3>
				<div class="sense" id="Awn_1_A1">
					<p><span class="ar">آنَ</span>, aor. <span class="ar">يَؤُونُ</span>, inf. n. <span class="ar">أَوْنٌ</span>, <em>He was,</em> or <em>became, at rest,</em> or <em>at ease; he rested</em> in a journey. <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awn_1_A2">
					<p><span class="ar">أُنْتُ</span>, aor. and inf. n. as above, <em>I enjoyed a life of ease and plenty; a state of freedom from trouble</em> or <em>inconvenience, and toil</em> or <em>fatigue; a state of ease, repose,</em> or <em>tranquillity.</em> <span class="auth">(AZ, T, Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Awn_1_A3">
					<p><em>I was,</em> or <em>became, grave, staid, steady, sedate,</em> or <em>calm.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Awn_1_A4">
					<p><em>I was,</em> or <em>became, gentle;</em> or <em>I acted gently:</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ:)</span> and <em>I acted,</em> or <em>proceeded, with moderation, without haste</em> or <em>hurry,</em> in pace or journeying: <span class="auth">(M:)</span> <em>I went gently, softly,</em> or <em>in a leisurely manner:</em> <span class="auth">(Ṣ, Ḳ:)</span> <span class="ar">أَوْنٌ</span> <span class="add">[the inf. n.]</span> is formed by substitution <span class="add">[of <span class="ar">أ</span> for <span class="ar">ه</span>]</span> from <span class="ar">هَوْنٌ</span>. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">أُنْتُ بِالشَّىْءِ</span>, and <span class="ar long">عَلَى الشَّىْءِ</span>, <em>I was gentle,</em> or <em>I acted gently, with the thing;</em> <span class="auth">(M;)</span> and <span class="ar long">فِى الأَمْرِ</span> <em>in the affair.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أُنْ عَلَى نَفْسِكَ</span> <em>Act thou gently with thyself,</em> or <em>be thou gentle, in pace</em> or <em>journeying:</em> and <em>proceed thou with moderation, without haste</em> or <em>hurry:</em> <span class="auth">(T, Ṣ:)</span> said in the latter sense to one who has become unsteady, or irresolute. <span class="auth">(T.)</span> <span class="add">[In like manner,]</span> you say,<span class="arrow"><span class="ar long">أَوِّنْ↓ عَلَى قَدْرِكَ</span></span>, meaning <span class="ar long">اِتَّئِدْ عَلَى نَحْوِكَ</span> <span class="add">[app. <em>Act thou with moderation, gentleness, deliberation,</em> or <em>in a leisurely manner, according to thine ability,</em> or <em>to the measure of thine ability;</em> for <span class="ar">قَدْرٌ</span> and <span class="ar">نَحْوٌ</span> are both syn. with <span class="ar">مِقْدَارٌ</span>]</span>. <span class="auth">(T, Ḳ.)</span> And<span class="arrow"><span class="ar long">أَوِّنُوا↓ فِى سَيْرِكُمْ</span></span> <em>Proceed ye with moderation in your course</em> or <em>pace</em> or <em>journeying.</em> <span class="auth">(ISk, T.)</span> And<span class="arrow"><span class="ar long">تَأَوَّنَ↓ فِى الأَمْرِ</span></span> <em>He paused,</em> or <em>was patient, in the affair.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اون</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awn_1_B1">
					<p><span class="ar">أَوْنٌ</span> also signifies The <em>being weary,</em> or <em>fatigued;</em> like <span class="ar">أَيْنٌ</span>. <span class="auth">(M.)</span> <span class="add">[Whether, in this sense, it have a verb, is doubtful: see its syn. here mentioned.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Awn_1_B2">
					<p>Also The <em>putting oneself to trouble,</em> or <em>inconvenience, for the sake of what one may expend upon himself and his family.</em> <span class="auth">(M.)</span> And hence, accord. to one <span class="add">[whose name is imperfectly written in the TA]</span>, the word <span class="arrow"><span class="ar">مَؤُونَةٌ↓</span></span>, <span class="add">[as being originally <span class="ar">مَأْوُنَةٌ</span>,]</span> of the measure <span class="ar">مَفْعُلَةٌ</span>: but others say that it is of the measure <span class="ar">فَعُولَةٌ</span>, from <span class="ar">مَأَنْتُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اون</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Awn_1_C1">
					<p><span class="arrow"><span class="ar long">آنَ أَوْنُكَ↓</span></span> and <span class="ar">أَوَانُكَ</span> <span class="add">[and <span class="ar">أَيْنُكَ</span>]</span> signify the same. <span class="auth">(M.)</span> <span class="add">[<a href="index.php?data=01_A/181_Ayn">See art. <span class="ar">اين</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awn_2">
				<h3 class="entry">2. ⇒ <span class="ar">أوّن</span></h3>
				<div class="sense" id="Awn_2_A1">
					<p><a href="#Awn_1">see 1</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأوّن</span></h3>
				<div class="sense" id="Awn_5_A1">
					<p><a href="#Awn_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlMna">
				<h3 class="entry"><span class="ar">الآنَ</span></h3>
				<div class="sense" id="AlMna_A1">
					<p><a href="#AnN"><span class="ar">الآنَ</span> and its vars.</a>: <a href="index.php?data=01_A/181_Ayn">see art. <span class="ar">اين</span></a>. <span class="add">[Accord. to some, it belongs to the present art., in which it is mentioned in the Mṣb.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawonN">
				<h3 class="entry"><span class="ar">أَوْنٌ</span></h3>
				<div class="sense" id="OawonN_A1">
					<p><span class="ar">أَوْنٌ</span>: <a href="#Awn_1">see 1</a> <span class="add">[of which it is the inf. n.]</span>: <a href="#OawaAnN">and see also what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawaAnN">
				<h3 class="entry"><span class="ar">أَوَانٌ</span></h3>
				<div class="sense" id="OawaAnN_A1">
					<p><span class="ar">أَوَانٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">إِوَانٌ↓</span></span>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> the latter mentioned by Ks on the authority of Aboo-Jámiʼ, but the former is the usual mode of pronouncing it, <span class="auth">(T,)</span> and<span class="arrow"><span class="ar">أَوْنٌ↓</span></span>, <span class="auth">(M,)</span> <em>A time; a season:</em> pl. <span class="ar">آوِنَةٌ</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> but Sb says <span class="ar">آوناتٌ</span>; <span class="auth">(M; <span class="add">[so in a copy of that work; app. <span class="ar">آوِنَاتٌ</span>, as though <a href="#AwinapN">pl. of <span class="ar">آوِنَةٌ</span></a>;]</span>)</span> and <span class="ar">آيِنَةٌ</span> is syn. with <span class="ar">آوِنَةٌ</span>. <span class="auth">(AA, T, Ḳ.)</span> You say, <span class="ar long">جَآءَ أَوَانُ البَرْدِ</span> <span class="add">[<em>The time,</em> or <em>season, of cold came</em>]</span>. <span class="auth">(T.)</span> And <span class="ar long">فُلَانٌ يَصْنَعُ ذٰلِكَ الأَمْرَ آوِنَةً</span>, <span class="auth">(Ṣ, Ḳ,*)</span> and <span class="ar">آيِنَةً</span>, <span class="auth">(Ḳ, <span class="add">[in the CK <span class="ar">آئِنَةً</span>,]</span>)</span> <em>Such a one does that thing sometimes, leaving it undone sometimes.</em> <span class="auth">(Ṣ, Ḳ.*)</span> And <span class="ar long">أَتَيْتُهُ آينَةً بَعْدَ آيِنَةٍ</span> <em>I came to him times after times.</em> <span class="auth">(AA, T.)</span> And <span class="ar">آوِنَةً</span> signifies <em>Time after time.</em> <span class="auth">(TA, from a trad.)</span> In the saying <span class="auth">(of Aboo-Zubeyd, L)</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">طَلَبُوا صُلْحَنَا وَلَاتَ أَوَانٍ</span> *</div> 
					</blockquote>
					<p><span class="auth">(M,)</span> or <span class="ar">إِوَانٍ</span>, <span class="auth">(L,)</span> <span class="add">[<em>They sought our reconciliation</em> with them, <em>but it was not the time</em> that reconciliation should be sought]</span>, accord. to Abu-l- ʼAbbás, the tenween of the last word is not a sign of the genitive case, but is, as in the instance of <span class="ar">إِذٍ</span>, because of the suppression of a proposition to which the word should be prefixed, as when you say, <span class="ar long">جِئْتُ أَوَانَ قَامَ زَيْدٌ</span> <em>I came at the time that Zeyd stood.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: <span class="ar">أَوَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OawaAnN_A2">
					<p><span class="add">[Hence, <span class="ar">أَوَانَئِذٍ</span> <em>At that time</em> or <em>season; then;</em> like <span class="ar">حِينَئِذٍ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiwaAnN">
				<h3 class="entry"><span class="ar">إِوَانٌ</span></h3>
				<div class="sense" id="IiwaAnN_A1">
					<p><span class="ar">إِوَانٌ</span>: <a href="#OawaAnN">see <span class="ar">أَوَانٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اون</span> - Entry: <span class="ar">إِوَانٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IiwaAnN_B1">
					<p><a href="#IiyawaAnN">and see also <span class="ar">إِيَوَانٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYinN">
				<h3 class="entry"><span class="ar">آئِنٌ</span></h3>
				<div class="sense" id="MYinN_A1">
					<p><span class="ar">آئِنٌ</span> <span class="add">[part. n. of 1:]</span> A man <em>enjoying a life of ease and plenty; a state of freedom from trouble</em> or <em>inconvenience, and toil</em> or <em>fatigue; a state of ease, repose,</em> or <em>tranquillity.</em> <span class="auth">(AZ, T, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: <span class="ar">آئِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MYinN_A2">
					<p><span class="add">[Hence the saying,]</span> <span class="ar long">رِبْعٌ آئِن خَيْرٌ مِنْ غِبٍّ حَصْحَاصٍ</span> <span class="add">[<em>An easy,</em> or <em>a gentle, journey in which the camels are watered only on the first and fourth days is better than a laborious,</em> or <em>quick, journey in which they are watered only on the first and third days</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[The fem. is <span class="ar">آئِنَةٌ</span>: the pl. of which is <span class="ar">أَوَائِنُ</span> and <span class="ar">آئِنَاتٌ</span>.]</span> You say, <span class="ar long">بَيْنَنَا وَبَيْنَ مَكًّةَ ثَلَاثُ لَيَالٍ أَوَائِنُ</span> <em>Between us and Mekkeh are three nights of easy,</em> or <em>gentle, journeying:</em> <span class="auth">(Ṣ, Ḳ:*)</span> and <span class="ar long">عَشْرُلَيَال آئِنَاتٌ</span> <em>ten nights of easy journeying.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiywaAnN">
				<h3 class="entry"><span class="ar">إِيوَانٌ</span></h3>
				<div class="sense" id="IiywaAnN_A1">
					<p><span class="ar">إِيوَانٌ</span> and<span class="arrow"><span class="ar">إِوَانٌ↓</span></span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> <span class="add">[each]</span> a foreign word, <span class="add">[i. e. Persian,]</span> <span class="auth">(M,)</span> <em>A chamber,</em> or <em>an apartment,</em> <span class="auth">(T, Mṣb,)</span> or <em>a large</em> <span class="ar">صُفَّة</span> <span class="add">[i. e. <em>porch,</em> or <em>roofed vestibule,</em> or <em>the like</em>]</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>similar to an</em> <span class="ar">أَزَج</span> <span class="add">[or <em>oblong arched</em> or <em>vaulted structure,</em> or <em>a portico</em>]</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> or <em>built in the form of an</em> <span class="ar">أَزَج</span>, <span class="auth">(Mṣb,)</span> <em>not closed in the front,</em> or <em>face:</em> <span class="auth">(T, M, Mṣb:*)</span> <span class="add">[and <em>a palace;</em> often used in this sense in Arabic as well as in Persian: and in the present day, the former, and more commonly <span class="ar">لِيوَان</span>, which is Persian, is also applied to <em>an estrade; a slightly-raised portion of the floor, generally extending nearly from the door to the end,</em> or <em>to each end, of a room:</em>]</span> pl. of the former, <span class="ar">أَوَاوِينُ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> because the sing. is originally <span class="ar">إِوْوَانٌ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar">إِيوَانَاتٌ</span>; and pl. of the latter, <span class="ar">أُونٌ</span>. <span class="auth">(T, Ṣ, Ḳ.)</span> Hence, <span class="ar long">إِيوَانُ كِسْرَى</span> <span class="add">[<em>The great porch,</em> or <em>the palace, of Kisrà,</em> or <em>Chosroes,</em> who is called <span class="ar long">صَاحِبُ الإِيوَانِ</span>]</span>. <span class="auth">(T, Ṣ, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: <span class="ar">إِيوَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiywaAnN_A2">
					<p>Also the latter, <span class="add">[and app., accord. to the Mṣb, the former also,]</span> <em>Any prop,</em> or <em>support,</em> of a thing: <span class="auth">(T, Mṣb:)</span> particularly, <em>a pole of a</em> <span class="add">[<em>tent of the kind called</em>]</span> <span class="ar">خِبَآء</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اون</span> - Entry: <span class="ar">إِيوَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiywaAnN_A3">
					<p>The <span class="ar">إِيوَان</span> of the <span class="ar">لِجَام</span> <span class="add">[is The <em>headstall of the bridle;</em> and]</span> has for its pl. <span class="ar">إِيوَانَاتٌ</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maWuwnapN">
				<h3 class="entry"><span class="ar">مَؤُونَةٌ</span></h3>
				<div class="sense" id="maWuwnapN_A1">
					<p><span class="ar">مَؤُونَةٌ</span>: <a href="#Awn_1">see 1</a>, <a href="../">and see art. <span class="ar">مأن</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0129.pdf" target="pdf">
							<span>Lanes Lexicon Page 129</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
