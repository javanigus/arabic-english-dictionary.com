<article class="root" id="Root_Ayr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/173_Ayd">ايد</a></span>
				<span class="ar">اير</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/175_Ays">ايس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ayr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أير</span> ⇒ <span class="ar">آر</span></h3>
				<div class="sense" id="Ayr_1_A1">
					<p><span class="ar">آرَهَا</span>, aor. <span class="ar">يَئِيرُ</span>, <span class="auth">(T, Ṣ, and Ḳ in art. <span class="ar">اور</span>,)</span> inf. n. <span class="ar">أَيْرٌ</span>; <span class="auth">(T, TA;)</span> or <span class="ar">آرَهَا</span>, aor. <span class="ar">يَؤُورُ</span>; <span class="auth">(ISk, T;)</span> or <em>both;</em> <span class="auth">(Ḳ ubi suprà;)</span> <em>Inivit eam; he compressed her.</em> <span class="auth">(ISk, T, Ṣ, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayorN">
				<h3 class="entry"><span class="ar">أَيْرٌ</span></h3>
				<div class="sense" id="OayorN_A1">
					<p><span class="ar">أَيْرٌ</span> The <em>membrum virile; penis; veretrum:</em> <span class="auth">(TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آيُرٌ</span> and <span class="ar">آيَارٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="add">[of mult.]</span> <span class="ar">أُيُورٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أُيُرٌ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اير</span> - Entry: <span class="ar">أَيْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OayorN_A2">
					<p><span class="ar long">كَانَ أَيْرُهُ طَويلًا</span> is a phrase meaning ‡ <em>He had many male children.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuyaArieBN">
				<h3 class="entry"><span class="ar">أُيَارِىٌّ</span></h3>
				<div class="sense" id="OuyaArieBN_A1">
					<p><span class="ar">أُيَارِىٌّ</span> <em>Having a large membrum virile,</em> or <em>penis;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> like <span class="ar">أُنَافِىٌّ</span> signifying “having a large nose.” <span class="auth">(T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBaAru">
				<h3 class="entry"><span class="ar">أَيَّارُ</span></h3>
				<div class="sense" id="OayBaAru_A1">
					<p><span class="ar">أَيَّارُ</span> <em>The</em> <span class="add">[<em>Syrian</em>]</span> <em>month</em> <span class="add">[<em>corresponding to May, O. Ṣ.;</em>]</span> preceding <span class="ar">حَزِيرَانُ</span>, or <span class="auth">(as written by Saadee Efendee, TA)</span> <span class="ar">حُزَيْرَانُ</span>. <span class="auth">(So in different copies of the Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYirN">
				<h3 class="entry"><span class="ar">آئِرٌ</span></h3>
				<div class="sense" id="MYirN_A1">
					<p><span class="ar">آئِرٌ</span> <em>Iniens.</em> <span class="auth">(T, Ṣ, TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="maYiyrN">
				<span class="pb" id="Page_0137"></span>
				<h3 class="entry"><span class="ar">مَئِيرٌ</span></h3>
				<div class="sense" id="maYiyrN_A1">
					<p><span class="ar">مَئِيرٌ</span> pass. part. n. of 1, <span class="auth">(T, Ṣ, TA,)</span> of the same measure as <span class="ar">مَصِيرٌ</span>; <em>i. q.</em> <span class="ar">مَنْيُوكٌ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYoyarN">
				<h3 class="entry"><span class="ar">مِئْيَرٌ</span></h3>
				<div class="sense" id="miYoyarN_A1">
					<p><span class="ar">مِئْيَرٌ</span> <span class="auth">(Ḳ, TA, <span class="add">[in the CK <span class="ar">مَئِير</span>, and in Gol. Lex. <span class="ar">مِئْيَرٌ</span>,]</span>)</span> <em>Qui multum coit.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0136.pdf" target="pdf">
							<span>Lanes Lexicon Page 136</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
