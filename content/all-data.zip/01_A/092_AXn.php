<article class="root" id="Root_AXn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/091_AXk">اشك</a></span>
				<span class="ar">اشن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/093_ASd">اصد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AXn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأشّن</span></h3>
				<div class="sense" id="AXn_5_A1">
					<p><span class="ar">تأشّن</span> <em>He washed his hands with</em> <span class="ar">أُشْنَان</span> <span class="add">[q. v. infrà]</span>. <span class="auth">(Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuXonapN">
				<h3 class="entry"><span class="ar">أُشْنَةٌ</span></h3>
				<div class="sense" id="OuXonapN_A1">
					<p><span class="ar">أُشْنَةٌ</span> <span class="add">[applied in the present day to <em>Moss:</em> and particularly, <em>tree-moss:</em> in Persian <span class="ar">أُشْنَهْ</span>: but]</span> Lth says, <span class="auth">(TA,)</span> it is <em>a thing that winds itself upon the trees called</em> <span class="ar">بَلُّوط</span> <em>and</em> <span class="ar">صَنَوْبَر</span> <span class="add">[<em>oak and pine</em>]</span> <em>as though it were pared off from a root</em> (<span class="ar long">كَأَنَّهُ مَقْشُورٌ مِنْ عِرْقِ</span>); and it is <em>sweet in odour, and white:</em> <span class="auth">(Ḳ, TA:)</span> Az says, I do not think it to be <span class="add">[genuine]</span> Arabic. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuXonaAnN">
				<h3 class="entry"><span class="ar">أُشْنَانٌ</span></h3>
				<div class="sense" id="OuXonaAnN_A1">
					<p><span class="ar">أُشْنَانٌ</span> and <span class="ar">إِشْنَانٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> but the former is of higher authority than the latter, <span class="auth">(TA,)</span> <em>i. q.</em> <span class="ar">حُرْضٌ</span> <span class="add">[<em>Kali,</em> or <em>glasswort</em>]</span>: <span class="auth">(Mṣb in the present art.; and Ṣ, A, Mgh, Mṣb, Ḳ, in art. <span class="ar">حرض</span>:)</span> <span class="add">[and also <em>potash,</em> which is thence prepared;]</span> <em>a thing,</em> or <em>substance, well known,</em> <span class="auth">(Ḳ, TA,)</span> <em>with which clothes and the hands are washed;</em> <span class="auth">(TA; <span class="add">[<a href="#qiloeN">see <span class="ar">قِلْىٌ</span></a>;]</span>)</span> <em>good,</em> or <em>profitable,</em> <span class="add">[<em>as a remedy</em>]</span> <em>for the mange,</em> or <em>scab, and the itch; clearing to the complexion, cleansing, emmenagogue, and abortive.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuXonaAnapN">
				<h3 class="entry"><span class="ar">أُشْنَانَةٌ</span></h3>
				<div class="sense" id="OuXonaAnapN_A1">
					<p><span class="ar">أُشْنَانَةٌ</span> <em>A vessel for</em> <span class="ar">حُرْض</span> <span class="add">[or <em>for</em> <span class="ar">أُشْنَان</span> as meaning <em>potash</em>]</span>; syn. <span class="ar">مِحْرَضَةٌ</span>. <span class="auth">(A in art. <span class="ar">حرض</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuXonaAnieBN">
				<h3 class="entry"><span class="ar">أُشْنَانِىٌّ</span></h3>
				<div class="sense" id="OuXonaAnieBN_A1">
					<p><span class="ar">أُشْنَانِىٌّ</span> <em>A seller of</em> <span class="ar">أُشْنَان</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0062.pdf" target="pdf">
							<span>Lanes Lexicon Page 62</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
