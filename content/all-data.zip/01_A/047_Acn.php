<article class="root" id="Root_Acn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/046_Acr">اذر</a></span>
				<span class="ar">اذن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/048_Ace">اذى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Acn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أذن</span></h3>
				<div class="sense" id="Acn_1_A1">
					<p><span class="ar long">أَذِنَ لَهْ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">إِلَيْهِ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْذَنُ</span>}</span></add>, <span class="auth">(T, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَذَنٌ</span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> <em>He</em> <span class="add">[<em>gave ear</em> or]</span> <em>listened to it,</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> or <em>him:</em> <span class="auth">(T, Ṣ, M, Ḳ:*)</span> or it signifies, <span class="auth">(Ḳ,)</span> or signifies also, <span class="auth">(M,)</span> <em>he listened to it,</em> or <em>him, pleased,</em> or <em>being pleased.</em> <span class="auth">(M, Ḳ.)</span> It is said in a trad., <span class="auth">(T,)</span> <span class="ar long">مَا أَذِنَ ٱللّٰهِ لِشَىْءٍ لِنَبِىٍّ يَتَغَنَّى بالقُرآنِ</span> <span class="auth">(T, Ṣ)</span> <em>God hath not listened to anything</em> <span class="add">[in a manner]</span> <em>like his listening</em> <span class="add">[<em>to a prophet chanting the Ḳur-án</em>]</span>. <span class="auth">(T.)</span> And in the Ḳur <span class="add">[lxxxiv. 2 and 5]</span>, <span class="ar long">وَأَذِنَتْ لِرَبِّها</span> <em>And shall listen to its Lord,</em> <span class="auth">(M, Bḍ, Jel,)</span> <em>and obey;</em> <span class="auth">(Jel;)</span> i. e., shall submit to the influence of his power as one listens to the commander and submits to him. <span class="auth">(Bḍ.)</span> And you say, <span class="ar long">أَذِنَ لِلَّهْوِ</span> <em>He listened and inclined to sport,</em> or <em>play.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Acn_1_A2">
					<p><span class="add">[Hence, perhaps,]</span> <span class="ar long">أَذِنَ لِرَائِحَةِ الطَّعَامِ</span> † <em>He desired eagerly,</em> or <em>longed for, the food,</em> <span class="add">[<em>perceiving its odour,</em>]</span> <span class="auth">(ISh, Ḳ,)</span> and <em>inclined to it.</em> <span class="auth">(ISh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Acn_1_A3">
					<p><span class="add">[Hence also, app.,]</span> <span class="ar long">أَذِنَ لَهُ فِى الشَّىْءِ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> or <span class="ar long">فِى أَمْرِ كَذَا</span>, <span class="auth">(T,)</span> or <span class="ar long">فِى كَذَا</span>, <span class="auth">(Mṣb,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْذَنُ</span>}</span></add>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">إِذْنٌ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> or this is a simple subst., <span class="auth">(Mṣb,)</span> and <span class="ar">أَذِينٌ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[as though originally signifying <em>He gave ear to him in respect of such a thing;</em> and then]</span> <em>he permitted him, allowed him,</em> or <em>gave him permission</em> or <em>leave, to do the thing, or such a thing.</em> <span class="auth">(M, Mṣb, Ḳ.)</span> <span class="add">[<a href="#IiconN">See also <span class="ar">إِذْنٌ</span>, below</a>.]</span> You say, <span class="ar long">أَذِنْتُ لِلْعَبْدِ فَى التِّجَارَةِ</span> <span class="add">[<em>I gave permission,</em> or <em>leave, to the slave to traffic</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<span class="pb" id="Page_0042"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Acn_1_A4">
					<p><span class="ar long">أَذِنَ لَهُ عَلَيْهِ</span> <em>He took,</em> or <em>got, permission,</em> or <em>leave, for him from him.</em> <span class="auth">(M.)</span> You say, <span class="ar long">اِيذَنْ لِى عَلَى الأَمِيرِ</span> <span class="auth">(Ṣ, TA)</span> <em>Take thou,</em> or <em>get thou, permission for me from the commander,</em> or <em>governor,</em> or <em>prince.</em> <span class="auth">(TA.)</span> El-A'azz Ibn-ʼAbdAllah says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَإِنِّى إِذَا ضَنَّ الأَمِيرُ بإِذْنِهِ</span> *</div> 
						<div class="star">* <span class="ar long">عَلَى الإِذنِ مِنْ نَفْسِى إِذا شِئْتٌ قَادِرٌ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And verily I, when the prince is niggardly of his permission, am able to take permission of myself when I will</em>]</span>. <span class="auth">(TA.)</span> And a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قُلْتُ لِبَوَّابٍ لَدَيْهِ دَارُهَا</span> *</div> 
						<div class="star">* <span class="ar long">تِئْذَنْ فَإِنِّى حَيْؤُهَا وَجَارُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>I said to a door-keeper, near by whom was her house, take thou,</em> or <em>get thou, permission</em> for me to enter, <em>for I am her husband's father, and her neighbour</em>]</span>: meaning, says Aboo-Jaạfar, <span class="ar">لِتَأْذَنْ</span>; for the suppression of the <span class="ar">ل</span> is allowable in poetry, and the pronunciation with kesr to the <span class="ar">ت</span> is accord. to the dial. of him who says <span class="ar long">أَنْتَ تِعْلَمُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Acn_1_A5">
					<p><span class="ar long">أَذِنَ بِالشَّىْءِ</span>, <span class="auth">(Ṣ,* M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْذَنُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">إِذْنٌ</span> and <span class="ar">أَذَنٌ</span> and <span class="ar">أَذَانٌ</span> and <span class="ar">أَذَانَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>He knew the thing; knew of it; had knowledge of it; became informed,</em> or <em>apprized, of it.</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span> It is said in the Ḳur <span class="add">[ii. 279]</span>, <span class="ar long">فَأْذَنُوا بِحَرْبٍ مِنَ ٱللّٰهِ وَرَسُولِهِ</span> <span class="auth">(Ṣ, M, Ḳ)</span> <em>Then be ye informed,</em> or <em>apprized, of war</em> <span class="add">[that shall come upon you]</span> <em>from God and his apostle:</em> <span class="auth">(M, Ḳ:)</span> or <em>then be ye sure,</em> or <em>assured,</em>, &amp;c. <span class="auth">(T.)</span> <span class="add">[<a href="#IiconN">See also <span class="ar">إِذْنٌ</span>, below</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Acn_1_B1">
					<p><span class="ar">أَذَنَهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَذْنٌ</span>, <span class="auth">(T,)</span> <em>He hit,</em> or <em>hurt, his ear;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> or <em>struck his ear;</em> <span class="auth">(so in some copies of the Ṣ;)</span> and<span class="arrow"><span class="ar">آذَنَهُ↓</span></span> signifies the same, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">إِيذَانٌ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#Acn_2">See also 2</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Acn_1_B2">
					<p><span class="ar">أُذِنَ</span> <span class="add">[as though originally signifying <em>He had his ear hit</em> or <em>hurt;</em>]</span> <em>he complained,</em> or <em>had a complaint, of his ear;</em> <span class="auth">(Ḳ;)</span> said of a man. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Acn_2">
				<h3 class="entry">2. ⇒ <span class="ar">أذّن</span></h3>
				<div class="sense" id="Acn_2_A1">
					<p><span class="ar">أذّنهُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَأْذِينٌ</span>, <span class="auth">(Ḳ,)</span> <em>He wrung,</em> or <em>twisted,</em> (<span class="ar">عَرَكَ</span>,) <em>his</em> <span class="auth">(a boy's, Ṣ)</span> <em>ear:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>he struck,</em> (<span class="ar">ضَرَبَ</span>, TA,) or <em>struck with his finger,</em> or <em>fillipped,</em> (<span class="ar">نَقَرَ</span>, M, TA,) <em>his ear.</em> <span class="auth">(M, TA.)</span><span class="add">[<a href="#Acn_1">See also <span class="ar">أَذَنَهُ</span></a>.]</span> They say, <span class="auth">(in a prov., TA in art. <span class="ar">جوز</span>,)</span> <span class="ar long">لِكُلِّ جَابِهٍ جَوْزَةٌ ثُمَّ يُؤْذَّنُ</span>, <span class="auth">(M, TA,)</span> i. e. <em>For every one that comes to water is a single watering</em> for his family and his cattle; <em>then his ear is struck,</em> to apprize him that he has nothing more to receive from them: <span class="auth">(TA in the present art., and the like is said in the same in art. <span class="ar">جوز</span>:)</span> or, † <em>then he is repelled from the water:</em> <span class="auth">(TA in art. <span class="ar">جوز</span>:)</span> <span class="add">[for <span class="ar">أذّنهُ</span> signifies also]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Acn_2_A2">
					<p>† <em>He repelled him,</em> <span class="auth">(IAạr, T, M, Ḳ,)</span> namely, a man, <span class="auth">(IAạr, T, M,)</span> <em>from drinking,</em> <span class="auth">(Ḳ,)</span> <em>and did not give him to drink.</em> <span class="auth">(M, Ḳ.)</span> You say also, <span class="ar long">أَذِّنُوا عَنِّى أُوَلَهَا</span>, <span class="add">[in which the pronoun appears, from the context, to relate to camels,]</span> † <em>Send ye away from me the first ones of them.</em> <span class="auth">(En-Naḍr, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Acn_2_B1">
					<p><span class="ar long">أذّن النَّعْلَ</span>, <span class="auth">(inf. n. as above, Ṣ,)</span> <em>He put to the sandal what is termed</em> <span class="ar">أُذُنٌ</span>, q. v. infrà: <span class="auth">(Ṣ, M, Ḳ:)</span> and in like manner one says with respect to other things. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Acn_2_C1">
					<p><span class="ar">أذّن</span>, <span class="auth">(M, Ḳ,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> also signifies <em>He made known,</em> or <em>notified,</em> a thing (<span class="ar">بِشَىْءٍ</span>) <em>much;</em> <span class="auth">(M, Ḳ;*)</span> <em>he proclaimed,</em> or <em>made proclamation;</em> syn. <span class="ar">نَادَى</span>: <span class="auth">(Jel in vii. 42, and Bḍ and Jel in xii. 70 and xxii. 28:)</span> Sb says that some of the Arabs make <span class="ar">أَذَّنَ</span> and<span class="arrow"><span class="ar">آذَنَ↓</span></span> to be syn.: but some say that the former signifies <em>he called out publickly;</em> and the latter, <em>i. q.</em> <span class="ar">أَعْلَمَ</span> <span class="add">[<em>he made to know,</em>, &amp;c.: <a href="#Acn_4">see 4</a>]</span>. <span class="auth">(M, TA.)</span> It is said in the Ḳur <span class="add">[xxii. 28]</span>, <span class="ar long">وَأَذِّنْ فِى النَّاسِ بِالحَجِّ</span> <span class="auth">(M)</span> <em>And proclaim thou, among the people, the pilgrimage.</em> <span class="auth">(Bḍ, Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Acn_2_C2">
					<p>Also, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">أذّن بِالصَّلَاةِ</span>, <span class="auth">(Mṣb,)</span> inf. n. as above, <span class="auth">(M, Ḳ,)</span> or <span class="ar">أَذَانٌ</span>, <span class="auth">(Ṣ,)</span> or both, <span class="auth">(TA,)</span> or the latter is <span class="add">[properly speaking]</span> a simple subst. <span class="add">[used as an inf. n.]</span>, as in the instances of <span class="ar long">وَدَّعَ وَدَاعَّا</span> and <span class="ar long">سَلَّمَ سَلَامًا</span> and <span class="ar long">كَلَّمَ كَلَامًا</span>, &amp;c., <span class="auth">(Mṣb,)</span> <em>He called to prayer;</em> <span class="auth">(M, Ḳ;)</span> <em>he notified,</em> or <em>made known,</em> or <em>proclaimed,</em> <span class="add">[i. e., <em>chanted,</em> from the <span class="ar">مِئْذَنَة</span>,]</span> <em>the time of prayer;</em> <span class="auth">(Ṣ,* Mṣb,* TA;)</span> and<span class="arrow"><span class="ar">آذَنَ↓</span></span> signifies the same, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">إِيذَانٌ</span>. <span class="auth">(TA.)</span> IB says, the phrase <span class="ar long">أَذَّنَ العَصْرُ</span>, with the verb in the act. form, <span class="add">[a phrase commonly obtaining in the present day,]</span> is wrong; the correct expression being <span class="ar long">أُذِّنَ بِالعَصْرِ</span> <span class="add">[<em>The time of the prayer of afternoon was proclaimed,</em> i. e., <em>chanted</em>]</span>, with the verb in the pass. form, and with the preposition to connect it with its subject. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="Acn_2_C3">
					<p>You say also, <span class="ar long">أَذَّنَ بِإِرْسَالِ إِبِلِهِ</span> <em>He spoke of sending away his camels.</em> <span class="auth">(En-Naḍr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Acn_4">
				<h3 class="entry">4. ⇒ <span class="ar">آذن</span></h3>
				<div class="sense" id="Acn_4_A1">
					<p><span class="ar">آذنهُ</span>: <a href="#Acn_1">see 1</a>, last sentence but one.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Acn_4_A2">
					<p><span class="add">[Hence, app.,]</span> inf. n. <span class="ar">إِيذَانٌ</span>, † <em>He prevented him,</em> or <em>forbade him;</em> <span class="auth">(Ḳ;)</span> and <em>repelled him.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#Acn_2">See also 2</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Acn_4_A3">
					<p>And † <em>It</em> <span class="auth">(a thing, M)</span> <em>pleased,</em> or <em>rejoiced, him,</em> <span class="auth">(M, Ḳ,)</span> <em>and he therefore listened to it.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Acn_4_B1">
					<p><span class="ar">آذَنْتُهُ</span>, inf. n. <span class="ar">إِيذَانٌ</span>, <span class="auth">(T, Mṣb,)</span> in the place of which the subst. <span class="ar">أَذَانٌ</span> is also used, <span class="auth">(T,)</span> signifies <span class="ar">أَعْلَمْتُهُ</span> <span class="add">[<em>I made him to know,</em> or <em>have knowledge; informed, apprized, advertised,</em> or <em>advised, him; gave him information, intelligence, notice,</em> or <em>advice:</em> and <em>I made it known, notified it,</em> or <em>announced it</em>]</span>: <span class="auth">(T, Mṣb:)</span> and<span class="arrow"><span class="ar">تَأَذَّنْتُ↓</span></span>, also, signifies <span class="ar">أَعْلَمْتُ</span> <span class="add">[as meaning <em>I made to know,</em>, &amp;c.: and <em>I made known,</em>, &amp;c.]</span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">آذنهُ بِالأَمْرِ</span>, <span class="auth">(T, Ḳ,<span class="add">[in the CK, erroneously, <span class="ar">اَذَنَهُ</span>,]</span>)</span> or <span class="ar">بِالشَّىْءِ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar long">آذنهُ الأَمْرَ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">إِيذَانٌ</span>, <span class="auth">(T,)</span> meaning <span class="ar">أَعْلَمَهُ</span> <span class="add">[<em>He made him to know,</em> or <em>have knowledge of, the thing; informed, apprized, advertised,</em> or <em>advised, him of it; gave him information, intelligence, notice,</em> or <em>advice, of it; made it known, notified it,</em> or <em>announced it, to him</em>]</span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar long">تأذّنهُ↓ الأَمْرَ</span></span>. <span class="auth">(M.)</span> So, accord. to one reading, in the Ḳur <span class="add">[ii. 279]</span>, <span class="ar long">فَآذِنُوا بِحَرْبٍ مِنَ ٱللّٰهِ</span> <em>Then make ye known,</em> or <em>notify ye,</em> or <em>announce ye, war from God.</em> <span class="auth">(M. <span class="add">[For the more common reading, <a href="#Acn_1">see 1</a>, latter part.]</span>)</span> And so in the Ḳur <span class="add">[vii. 166]</span>,<span class="arrow"><span class="ar long">وَإِذْ تَأَذَّنَ↓ رَبُّكَ</span></span> <em>And when thy Lord made known,</em> or <em>notified,</em> or <em>announced:</em> <span class="auth">(Zj, Ṣ, M, Ḳ:*)</span> or the meaning here is, <em>swore:</em> <span class="auth">(M, Ḳ:*)</span> <span class="add">[for]</span> you say,<span class="arrow"><span class="ar long">تَأَذَّنَ↓ لَيَفْعَدَنَ</span></span>, meaning <em>he swore that he would assuredly do</em> <span class="add">[such a thing]</span>: <span class="auth">(M:)</span> Lth says that<span class="arrow"><span class="ar long">تَأَذَّنْتُ↓ لَأَفْعَلَنَّ كَذَا وَكَذَا</span></span> signifies the making the action obligatory. <span class="auth">(T.)</span> You say also,<span class="arrow"><span class="ar long">تَأَذَّنَ↓ الأَمِيرُ فِى النَّاسِ</span></span> <em>The commander,</em> or <em>governor,</em> or <em>prince, proclaimed</em> (<span class="ar">نَادَى</span>) <em>among the people, with threatening</em> <span class="auth">(Ṣ, Ḳ)</span> <em>and prohibition;</em> i. e. <span class="ar">تَقَدَّمَ</span> and <span class="ar">أَعْلَمَ</span>. <span class="auth">(Ṣ.)</span> And you say of a building that has cracked in its sides, <span class="ar long">آذَنَ بِٱلْإِنْهِدَامِ وَالسُّقُوطِ</span> † <span class="add">[<em>It gave notice of becoming a ruin and of falling down</em>]</span>. <span class="auth">(Mṣb in art. <span class="ar">دعو</span>.)</span> <span class="add">[See also a similar ex. in a verse cited voce <span class="ar">أَلَا</span>. And hence,]</span> <span class="ar long">آذَنَ العُشْبُ</span> <span class="add">[in the CK <span class="auth">(erroneously)</span> <span class="ar">اَذَنَ</span>]</span> ‡ <em>The herbage began to dry up; part of it being still succulent, and part already dried up.</em> <span class="auth">(M, Ḳ, TA.)</span> And <span class="ar long">آذَنَ الحُبُّ</span> <em>The grain put forth its</em> <span class="ar">أَذَنَة</span>, or <em>leaves.</em> <span class="auth">(TA.)</span> <a href="#Acn_2">See also 2</a>, latter half, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Acn_4_C1">
					<p><span class="ar">آذَنَ</span> and<span class="arrow"><span class="ar">تأذّن↓</span></span> are <span class="add">[also]</span> used in one and the same sense <span class="add">[as meaning <em>He knew; had knowledge;</em> or <em>became informed, apprized, advertised,</em> or <em>advised,</em> of a thing]</span>; like as one says <span class="ar">أَيْقَنَ</span> and <span class="ar">تَيَقَّنَ</span>. <span class="auth">(Ṣ, TA.)</span> You say,<span class="arrow"><span class="ar">تَأَذَّنْ↓</span></span>, meaning <span class="ar">اِعْلَمْ</span> <span class="add">[<em>Know thou</em>]</span>; like as you say <span class="ar">تَعَلَّمْ</span>, meaning <span class="ar">اِعْلَمْ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Acn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأذّن</span></h3>
				<div class="sense" id="Acn_5_A1">
					<p><a href="#Acn_4">see 4</a>, in eight places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Acn_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأذن</span></h3>
				<div class="sense" id="Acn_10_A1">
					<p><span class="ar">استأذنهُ</span> <em>He asked,</em> or <em>demanded, of him permission,</em> or <em>leave,</em> <span class="auth">(M, Mṣb, Ḳ,)</span> <span class="ar long">فِى كَذَا</span> <em>to do such a thing.</em> <span class="auth">(Mṣb.)</span> <span class="add">[You say, <span class="ar">استأذن</span> meaning <em>He asked,</em> or <em>demanded, permission,</em> or <em>leave, to enter,</em> or <em>to come into the presence of another;</em> and <em>to go.</em> And <span class="ar long">استأذن فِى الدُّخُولِ عليه</span>, and, elliptically, <span class="ar long">استأذن عليه</span>, <em>He asked,</em> or <em>demanded, permission,</em> or <em>leave, to go in to him.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuconN">
				<h3 class="entry"><span class="ar">أُذْنٌ</span></h3>
				<div class="sense" id="OuconN_A1">
					<p><span class="ar">أُذْنٌ</span>: <a href="#OucunN">see <span class="ar">أُذُنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiconN">
				<h3 class="entry"><span class="ar">إِذْنٌ</span></h3>
				<div class="sense" id="IiconN_A1">
					<p><span class="ar">إِذْنٌ</span> <span class="add">[is held by some to be an inf. n., like<span class="arrow"><span class="ar">أَذَيِنٌ↓</span></span>: (<a href="#Acn_1">see 1</a>:) by others, to be]</span> a simple subst.; <span class="auth">(Mṣb;)</span> signifying <em>Permission; leave;</em> or <em>concession of liberty,</em> to do a thing: and sometimes <em>command:</em> and likewise <em>will;</em> <span class="auth">(Mṣb, TA;)</span> as in the phrase <span class="ar long">بِإِذْنِ ٱللّٰهِ</span> <em>by the will of God:</em> <span class="auth">(Mṣb:)</span> or, accord. to El-Harállee, the <em>withdrawal,</em> or <em>removal, of prevention</em> or <em>prohibition,</em> and the <em>giving of power</em> or <em>ability, in respect of being and creation:</em> or, accord. to Ibn-El-Kemál, the <em>rescission of prohibition, and concession of freedom of action, to him who has been prohibited by law:</em> or, accord. to Er-Rághib, the <em>notification of the allowance</em> or <em>permission of a thing, and of indulgence in respect of it;</em> as in <span class="ar long">إِلَّا لِيُطَاعَ بِإِذْنِ ٱللّٰهِ</span>, <span class="add">[in the Ḳur iv. 67,]</span> meaning <span class="add">[<em>but that he may be obeyed</em>]</span> <em>by the will of God,</em> and <span class="add">[also]</span> <em>by his command:</em> <span class="auth">(TA:)</span> or, as explained in the Ksh, <em>facilitation;</em> an explanation founded upon the opinion that the actions of men are by their own effective power, but facilitated by God; and in this sense, Esh-Shiháb regards it as a metaphor, or a non-metaphorical trope: <span class="auth">(MF:)</span> and <em>accommodation;</em> syn. <span class="ar">تَوْفِيقٌ</span>; <span class="auth">(Hr in explanation of a clause of iii. 139 of the Ḳur <span class="add">[which see below]</span>;)</span> but Es-Semeen says that this requires consideration. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">إِذْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiconN_A2">
					<p>Also <em>Knowledge;</em> syn. <span class="ar">عِلْمٌ</span>; <span class="auth">(T, M, Ḳ;)</span> and so<span class="arrow"><span class="ar">أَذِينٌ↓</span></span>; <span class="auth">(M, Ḳ;)</span> as in the saying <span class="ar long">فَعَلَهُ بِإِذْنِى</span> <span class="auth">(T,* M, Ḳ)</span> and<span class="arrow"><span class="ar">بِأَذِينى↓</span></span> <span class="auth">(M, Ḳ)</span> <span class="add">[<em>He did it with my knowledge</em>]</span>: <span class="pb" id="Page_0043"></span>or <span class="ar">إِذْنٌ</span> has amore particular signification than <span class="ar">عِلْمٌ</span>, being scarcely ever, or never, used save of that <span class="add">[<em>knowledge</em>]</span> <em>wherein is will, conjoined with command</em> or <em>not conjoined therewith;</em> for in the saying <span class="add">[in the Ḳur iii. 139, referred to above,]</span> <span class="ar long">وَمَا كَانَ لِنَفْسٍ أَنْ تَمُوتَ إِلَّا بِإِذْنِ ٱللّٰهِ</span> <span class="add">[<em>And it is not for a soul to die save with the knowledge of God</em>]</span>, it is known that there are will and command; and in the saying <span class="add">[in the Ḳur ii. 96]</span>, <span class="ar long">وَمَا هُمْ بِضَّارِينَ بِهِ مِنْ أَحَدٍ إِلَّا بإِذْنِ ٱللّٰهِ</span> <span class="add">[<em>But they do not injure thereby any one save with the knowledge of God</em>]</span>, there is will in one respect, for there is no difference of opinion as to the fact that God hath made to exist in man a faculty wherein is the power of injuring another: <span class="auth">(Er-Rághib:)</span> but Es-Semeen says that this plea is adduced by Er-Rághib because of his inclining to the persuasion of the Moatezileh. <span class="auth">(TA.)</span> You say also, <span class="ar long">فَعَلْتُ كَذَا بِإِذْنِهِ</span> meaning <em>I did thus by his command.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OacanN">
				<h3 class="entry"><span class="ar">أَذَنٌ</span></h3>
				<div class="sense" id="OacanN_A1">
					<p><span class="ar">أَذَنٌ</span>: <a href="#OacanapN">see <span class="ar">أَذَنَةٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OucunN">
				<h3 class="entry"><span class="ar">أُذُنٌ</span></h3>
				<div class="sense" id="OucunN_A1">
					<p><span class="ar">أُذُنٌ</span> and<span class="arrow"><span class="ar">أُذْنٌ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> the latter a contraction of the former, <span class="add">[which is the more common,]</span> <span class="auth">(Mṣb,)</span> <span class="add">[The <em>ear;</em>]</span> <em>one of the organs of sense;</em> <span class="auth">(M, TA;)</span> <em>well known:</em> <span class="auth">(M:)</span> of the fem. gender: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> as also<span class="arrow"><span class="ar">أَذِينٌ↓</span></span>: <span class="auth">(Ḳ:)</span> pl. <span class="ar">آذَانٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> its only pl. form: <span class="auth">(M:)</span> dim. <span class="arrow"><span class="ar">أُذَيْنَةٌ↓</span></span>; but when used as a proper name of a man, <span class="ar">أُذَيْنُ</span>, though <span class="ar">أُذَيْنَةُ</span> has been heard. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">جَآءَ نَاشِرَّا أُذُنَيْهِ</span> <span class="add">[<em>He came spreading,</em> or, as we say, <em>pricking up, his ears:</em> meaning]</span> ‡ <em>he came in a state of covetousness,</em> or <em>eagerness.</em> <span class="auth">(T, Ḳ, TA. <span class="add">[<a href="#naXara">See also <span class="ar">نَشَرَ</span></a>.]</span>)</span> And <span class="ar long">وَجَدْتُ فُلَانًا لَا بِسًا أُذُنَيْهِ</span> ‡ <em>I found such a one feigning himself inattentive,</em> or <em>heedless.</em> <span class="auth">(T, TA.)</span> And <span class="ar long">لَبِسْتُ أُذُنَىَّ لَهُ</span> ‡ <em>I turned away from him, avoided him,</em> or <em>shunned him:</em> or <em>I feigned myself inattentive,</em> or <em>heedless, to him.</em> <span class="auth">(Ḳ, TA. <span class="add">[<a href="#labisa">See also <span class="ar">لَبِسَ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أُذُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OucunN_A2">
					<p>‡ A man <em>who listens to what is said to him:</em> <span class="auth">(M, Ḳ, TA:)</span> or a man <em>who hears the speech of every one:</em> <span class="auth">(Ṣ:)</span> or <em>who relies upon what is said to him;</em> as also <span class="ar long">وَابِصَةُ السَّمْعِ</span>: <span class="auth">(M in art. <span class="ar">وبص</span>:)</span> applied as an epithet to one and to a pl. number, <span class="auth">(Ṣ, M, Ḳ,)</span> alike, <span class="auth">(Ṣ, M,)</span> and to two, and to a woman; not being pluralized nor dualized <span class="add">[nor having the fem. form given to it]</span>: <span class="auth">(IB:)</span> you say <span class="ar long">رَجُلٌ أُذْنٌ</span> <span class="auth">(AZ, Ṣ, M)</span> and <span class="ar">أُذْنٌ</span>, and <span class="ar long">رِجَالٌ أُذُنٌ</span> and <span class="ar">أُذْنٌ</span> <span class="add">[&amp;c.]</span>: <span class="auth">(AZ, M:)</span> and sometimes it is applied to a man as a name of evil import. <span class="auth">(M.)</span> It is said in the Ḳur <span class="add">[ix. 61]</span>, <span class="ar long">وَيَقُولُونَ هُوَ أُذُنٌ قُلْ أُذُنُ خَيْرٍ لَكُمْ</span> <span class="auth">(T, M)</span> <em>And they say, “He is one who hears and believes everything that is said to him:”</em> as though, by reason of the excess of his listening, he were altogether the organ of hearing; like as a spy is termed <span class="ar">عَيْنٌ</span>; or <span class="ar">أُذُن</span> is here from <span class="ar">أَذِنَ</span> “he listened,” and is like <span class="ar">أُنُفٌ</span> and <span class="ar">شُلُلٌ</span> in its derivation: <span class="auth">(Bḍ:)</span> for among the hypocrites was he who found fault with the Prophet, saying, “If anything be told him from me, I swear to him, and he receives it from me, because he is an <span class="ar">أُذُن</span>:” <span class="auth">(M:)</span> therefore he is commanded to answer, <em>Say, “A hearer of good for you.”</em> <span class="auth">(T, M, Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أُذُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OucunN_A3">
					<p>† <em>A sincere,</em> or <em>faithful, adviser</em> of a people, <em>who counsels to obedience:</em> <span class="auth">(Mṣb:)</span> a man's <em>intimate, and special,</em> or <em>particular, friend.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أُذُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OucunN_A4">
					<p>† <em>A certain appertenance</em> of the heart; <span class="auth">(M;)</span> <span class="add">[i. e. either <em>auricle</em> thereof;]</span> <span class="ar long">أُذُنَا القَلْبِ</span> signifying <em>two appendages</em> (<span class="ar">زَنَمَتَانِ</span>) <em>in the upper part of the heart:</em> <span class="auth">(Ḳ:)</span> and ‡ of a <span class="ar">نَصْل</span> <span class="add">[or arrow-head or the like; i. e. either <em>wing</em> thereof]</span>: and ‡ of an arrow; <span class="ar long">آذَانُ السَّهْمِ</span> signifying <em>the feathers of the arrow,</em> as AḤn says, when they are attached thereon; and <span class="ar long">ذُو ثَلَاثِ آذَانٍ</span> <span class="add">[<em>a thing having three such feathers</em>]</span> meaning <em>an arrow:</em> all so called by way of comparison: <span class="auth">(M:)</span> and † of a sandal; <span class="auth">(Ṣ, M, Ḳ;)</span> i. e. the <em>part</em> thereof <em>that surrounds the</em> <span class="ar">قِبَال</span> <span class="add">[q. v.]</span>: <span class="auth">(M:)</span> or <span class="ar long">أُذُنَا النَّعْلِ</span> signifies <em>the two parts,</em> <span class="add">[or <em>loops,</em>]</span> <em>of the sandal, to which are tied the</em> <span class="ar">عَضُدَانِ</span> <em>of the</em> <span class="ar">شِرَاك</span>, <span class="add">[or <em>two branches of the thong that is attached to another thong between two of the toes, which two branches, however, sometimes pass through the</em> <span class="ar">أُذُنَانِ</span>, <em>encompassing the heel,</em>]</span> <em>behind the narrow part</em> (<span class="ar">خَصْر</span>) <em>of the sole.</em> <span class="auth">(AO in an anonymous MṢ in my possession. <a href="#xaSorN">See also <span class="ar">خَصْرٌ</span></a>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أُذُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OucunN_A5">
					<p>‡ <em>A handle,</em> <span class="auth">(M,)</span> or <span class="add">[<em>a loopshaped,</em> or <em>an ear-shaped, handle, such as is termed</em>]</span> <span class="ar">عُرْوَة</span>, <span class="auth">(T, Ḳ,)</span> of anything; <span class="auth">(M, Ḳ)</span> as, for instance, <span class="auth">(M,)</span> of a <span class="ar">كُوز</span> <span class="add">[or mug]</span>; <span class="auth">(T, M;)</span> and of a <span class="ar">دَلْو</span> <span class="add">[or bucket]</span>: so called by way of comparison: and in all cases fem.: <span class="auth">(M:)</span> pl. as above. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أُذُنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OucunN_A6">
					<p>† <em>What becomes sharp,</em> or <em>pointed, and then falls off,</em> or <em>out,</em> of the plants called <span class="ar">عَرْفَج</span> and <span class="ar">ثُمَام</span> when they put forth their <span class="ar">خُوص</span> <span class="add">[q. v.]</span>, or when their <span class="ar">خوص</span> become perfect; because it has the shape of an ear. <span class="auth">(AḤn, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Iicano">
				<h3 class="entry"><span class="ar">إِذَنْ</span> / <span class="ar">إِذًا</span></h3>
				<div class="sense" id="Iicano_A1">
					<p><span class="ar">إِذَنْ</span>, also written <span class="ar">إِذًا</span>: <a href="index.php?data=01_A/045_AcA">see art. <span class="ar">اذا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OacanapN">
				<h3 class="entry"><span class="ar">أَذَنَةٌ</span></h3>
				<div class="sense" id="OacanapN_A1">
					<p><span class="ar">أَذَنَةٌ</span> The <em>leaves of trees,</em> <span class="auth">(En-Naḍr, T,)</span> or <em>of grain.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OacanapN_A2">
					<p><span class="add">[The <em>kind of leaf called</em> <span class="ar">خُوصَة</span> of the <span class="ar">ثُمَام</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OacanapN_A3">
					<p>‡ The <em>young ones of camels</em> and <em>of sheep</em> or <em>goats;</em> <span class="auth">(En-Naḍr, T, Ḳ;)</span> as being likened to the <span class="ar">خُوصَة</span> of the <span class="ar">ثُمَام</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OacanapN_A4">
					<p><em>A piece of straw:</em> pl. <span class="add">[or rather coll. gen. n.]</span> <span class="arrow"><span class="ar">أَذَنٌ↓</span></span> <span class="add">[in the CK <span class="ar">أُذُنٌ</span>]</span>. <span class="auth">(IAạr, T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَنَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OacanapN_B1">
					<p><em>Appetite, appetency, longing, yearning,</em> or <em>strong desire.</em> <span class="auth">(En-Naḍr, T.)</span> You say, <span class="ar long">هٰذِهِ بَقْلَةٌ تَجِدُ بِهَا الإِبِلُ أَذَنَةَ شَدِيدَةً</span> <em>This is a herb for which the camels feel a strong appetite, &amp;c.</em> <span class="auth">(En-Naḍr, T.)</span> And <span class="ar long">هٰذَا طَعَامٌ لَا أَذَنَةَ لَهُ</span> <em>This is food for the odour of which there is no appetite.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OacaAnN">
				<h3 class="entry"><span class="ar">أَذَانٌ</span></h3>
				<div class="sense" id="OacaAnN_A1">
					<p><span class="ar">أَذَانٌ</span> <em>A making known; a notification; an announcement.</em> <span class="auth">(T, Ṣ, Mgh.)</span><span class="add">[<a href="#Acn_4">See 4</a>.]</span> So in the Ḳur <span class="add">[ix. 3]</span>, <span class="ar long">وَأَذَانٌ مِنَ ٱللّٰهِ وَرَسُولِهِ إِلَى النَّاسِ</span> <span class="add">[<em>And a notification,</em> or <em>an announcement, from God and his apostle to men,</em> or <em>the people</em>]</span>. <span class="auth">(T, Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OacaAnN_A2">
					<p>Also, and<span class="arrow"><span class="ar">أَذِينٌ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar">تَأْذِينٌ</span>, <span class="add">[<a href="#Acn_2">the last an inf. n. of 2, and the second a quasi-inf. n. of the same, which see</a>,]</span> <span class="auth">(M, Ḳ,)</span> The <em>notification,</em> or <em>announcement, of prayer,</em> and <em>of the time thereof;</em> <span class="auth">(T, Ṣ;)</span> the <em>call to prayer.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[The words of this call <span class="auth">(which is usually chanted from the <span class="ar">مِئْذَنَة</span>, or turret of the mosque,)</span> are <span class="ar long">اَللّٰهُ أَكْبَرْ</span> <span class="auth">(four times)</span> <span class="ar long">أَشْهَدُ أنْ لَا إِلٰهَ إِلَّا ٱللّٰهْ</span> <span class="auth">(twice)</span> <span class="ar long">أَشْهَدُ أَنَّ مُحَمَّدًا رَّسُولُ ٱللّٰهُ</span> <span class="auth">(twice)</span> <span class="ar long">حَيَّ عَلَى الصَّلَاهٌ</span> <span class="auth">(twice)</span> <span class="ar long">حَىَّ عَلَى الفَلَاحْ</span> <span class="auth">(twice)</span> <span class="ar long">اَللّٰهُ أَكْبَرٌ</span> <span class="auth">(twice)</span> <span class="ar long">لَا إِلٰهَ إِلَّا ٱللّٰهٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OacaAnN_A3">
					<p><span class="ar">الأَذَانُ</span> also signifies <em>The</em> <span class="add">[<em>notification,</em> or <em>announcement, called</em>]</span> <span class="ar">إِقَامَة</span>; <span class="auth">(M, Ḳ;)</span> because it is a notification to be present at the performance of the divinelyordained prayers. <span class="auth">(TA.)</span> <span class="add">[This <span class="auth">(which is chanted in the mosque)</span> consists of the words of the former <span class="ar">أَذَان</span> with the addition of <span class="ar long">قَدْ قَامَتِ الصَّلَاهْ</span> pronounced twice after <span class="ar long">حَىَ عَلَى الفَلَاحْ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OacaAnN_A4">
					<p><span class="ar">الأَذَانَانِ</span> signifies <em>The</em> <span class="ar">أَذَانِ</span> <span class="add">[<em>more commonly so called</em>]</span> <em>and the</em> <span class="ar">إِقَامَة</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OacuwnN">
				<h3 class="entry"><span class="ar">أَذُونٌ</span></h3>
				<div class="sense" id="OacuwnN_A1">
					<p><span class="ar">أَذُونٌ</span> <span class="add">[An animal <em>having an ear;</em> as distinguished from <span class="ar">صَمُوخٌ</span>, which means “having merely an ear-hole”]</span>. <span class="auth">(Mṣb in art. <span class="ar">بيض</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaciynN">
				<h3 class="entry"><span class="ar">أَذِينٌ</span></h3>
				<div class="sense" id="OaciynN_A1">
					<p><span class="ar">أَذِينٌ</span>: <a href="#OucunN">see <span class="ar">أُذُنٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذِينٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaciynN_B1">
					<p><a href="#IiconN">See also <span class="ar">إِذْنٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OaciynN_B2">
					<p><a href="#OacaAnN">And see <span class="ar">أَذَانٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذِينٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OaciynN_C1">
					<p><em>I. q.</em> <span class="arrow"><span class="ar">مُؤْذِنٌ↓</span></span> <span class="add">[<em>Making to know</em> or <em>have knowledge,</em> <span class="ar">بِأَمْرٍ</span> <em>of a thing; informing, apprizing, advertising,</em> or <em>advising; giving information, intelligence, notice,</em> or <em>advice; making known, notifying,</em> or <em>announcing</em>]</span>: like <span class="ar">أَلِيمٌ</span> and <span class="ar">وَجِيعٌ</span> as meaning <span class="ar">مُؤْلِمٌ</span> and <span class="ar">مُوجِعٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذِينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="OaciynN_C2">
					<p><a href="#muwacBinN">See also <span class="ar">مُؤَذِّنٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذِينٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="OaciynN_D1">
					<p>One who is <em>responsible, answerable, amenable,</em> or <em>a surety;</em> <span class="add">[<span class="ar">بِأَمْرٍ</span> <em>for a thing;</em> and perhaps also <span class="ar">بِغَيْرِهِ</span> <em>for another person;</em>]</span> syn. <span class="ar">كَفِيلٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">زَعِيمٌ</span> <span class="add">[which signifies the same as <span class="ar">كَفِيلٌ</span>, and is plainly shown in the M to be here used as a syn. of this latter; but SM assigns to it here another meaning, namely <span class="ar">رَئِيسٌ</span>, in which sense I find no instance of the use of <span class="ar">أَذِينٌ</span>]</span>; <span class="auth">(AO, M;)</span> and<span class="arrow"><span class="ar">آذِنٌ↓</span></span> also is syn. with <span class="ar">أَذِينٌ</span> in the sense of <span class="ar">كَفِيلٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">أَذِينٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="OaciynN_E1">
					<p>Also <em>A place to which the</em> <span class="ar">أَذَان</span> <span class="add">[or <em>call to prayer</em>]</span> <em>comes</em> <span class="add">[or <em>reaches</em>]</span> <em>from</em> <span class="add">[or <em>on</em>]</span> <em>every side.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OucayonapN">
				<h3 class="entry"><span class="ar">أُذَيْنَةٌ</span></h3>
				<div class="sense" id="OucayonapN_A1">
					<p><span class="ar">أُذَيْنَةٌ</span> <a href="#OucunN">dim. of <span class="ar">أُذُنٌ</span>, q. v.</a> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OucaAnieBN">
				<h3 class="entry"><span class="ar">أُذَانِىٌّ</span></h3>
				<div class="sense" id="OucaAnieBN_A1">
					<p><span class="ar">أُذَانِىٌّ</span> <span class="auth">(Ṣ, M, Mgh, Ḳ)</span> and<span class="arrow"><span class="ar">آذَنُ↓</span></span> <span class="auth">(M, Ḳ)</span> <em>Largeeared;</em> <span class="auth">(Ṣ, M, Mgh, Ḳ;)</span> <em>long-eared;</em> <span class="auth">(M;)</span> applied to a man, <span class="auth">(Ṣ, M, Ḳ,)</span> and to a camel, and to a sheep or goat: <span class="auth">(M:)</span> <span class="add">[or]</span> the latter epithet is applied to a ram; and its fem. <span class="ar">أَذْنَآءُ</span> to a ewe. <span class="auth">(T, Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OucayonieBN">
				<h3 class="entry"><span class="ar">أُذَيْنِىٌّ</span></h3>
				<div class="sense" id="OucayonieBN_A1">
					<p><span class="ar">أُذَيْنِىٌّ</span> One <em>who hears everything that is said:</em> but this is a vulgar word. <span class="auth">(TA.)</span><span class="add">[<a href="#OucunN">See <span class="ar">أُذُنٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mcanu">
				<h3 class="entry"><span class="ar">آذَنُ</span></h3>
				<div class="sense" id="Mcanu_A1">
					<p><span class="ar">آذَنُ</span>: <a href="#OucaAnieBN">see <span class="ar">أُذَانِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="McinN">
				<h3 class="entry"><span class="ar">آذِنٌ</span></h3>
				<div class="sense" id="McinN_A1">
					<p><span class="ar">آذِنٌ</span> <span class="add">[act. part. n. of 1. As such, <em>Permitting,</em> or <em>allowing;</em> one <em>who permits,</em> or <em>allows.</em> And hence,]</span> <em>A doorkeeper,</em> or <em>chamberlain.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">آذِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="McinN_A2">
					<p><a href="#OaciynN">See also <span class="ar">أَذِينٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWocanN">
				<h3 class="entry"><span class="ar">مُؤْذَنٌ</span></h3>
				<div class="sense" id="muWocanN_A1">
					<p><span class="ar">مُؤْذَنٌ</span>: <a href="#maOocuwnN">see <span class="ar">مَأْذُونٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWocinN">
				<h3 class="entry"><span class="ar">مُؤْذِنٌ</span></h3>
				<div class="sense" id="muWocinN_A1">
					<p><span class="ar">مُؤْذِنٌ</span>: <a href="#OaciynN">see <span class="ar">أَذِينٌ</span></a>. You say, <span class="ar long">سِيمَاهُ بِالخَيْرِ مُؤْذِنَةٌ</span> <em>His impress notifies</em> <span class="add">[or <em>is indicative of</em>]</span> <em>goodness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">مُؤْذِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWocinN_A2">
					<p><span class="ar">مُؤْذِنَاتٌ</span>, signifying The <em>women who notify,</em> or <em>announce, the times of festivity and rejoicing,</em> <span class="add">[<em>particularly on the occasions of weddings,</em>]</span> is a vulgar word. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">مُؤْذِنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWocinN_B1">
					<p>Herbage <em>beginning to dry up; part of it being still succulent, and part already dried up:</em> and a branch, or wood, <em>that has dried, but has in it some succulency.</em> <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOocanapN">
				<span class="pb" id="Page_0044"></span>
				<h3 class="entry"><span class="ar">مَأْذَنَةٌ</span></h3>
				<div class="sense" id="maOocanapN_A1">
					<p><span class="ar">مَأْذَنَةٌ</span>: <a href="#muWocanapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWocanapN">
				<h3 class="entry"><span class="ar">مُؤْذَنَةٌ</span></h3>
				<div class="sense" id="muWocanapN_A1">
					<p><span class="ar">مُؤْذَنَةٌ</span>: <a href="#miYocanapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYocanapN">
				<h3 class="entry"><span class="ar">مِئْذَنَةٌ</span></h3>
				<div class="sense" id="miYocanapN_A1">
					<p><span class="ar">مِئْذَنَةٌ</span> <span class="auth">(which may also be pronounced <span class="ar">مِيذَنَةٌ</span>, Mṣb)</span> The <em>place</em> <span class="add">[generally <em>a turret of a mosque</em>]</span> <em>upon which the time of prayer is notified, made known,</em> or <em>proclaimed;</em> <span class="auth">(T, M,* Ḳ;*)</span> <em>i. q.</em> <span class="ar">مَنَارَةٌ</span> <span class="add">[which has this meaning and others also]</span>; <span class="auth">(AZ, T, Ṣ, Mṣb;)</span> as also<span class="arrow"><span class="ar">مُؤْذَنَةٌ↓</span></span>: <span class="auth">(AZ, T:)</span> or it signifies, <span class="auth">(as in some copies of the Ḳ,)</span> or signifies also, <span class="auth">(as in other copies of the same,)</span> <em>i. q.</em> <span class="ar">مَنَارَةٌ</span>: and <span class="ar">صَوْمَعَةٌ</span>: <span class="add">[see these two words:]</span> <span class="auth">(Ḳ:)</span> or <em>i. q.</em> <span class="ar">مَنَارَةٌ</span>, meaning <span class="ar">صَوْمَعَةٌ</span>; <span class="auth">(Lḥ, M, TA;)</span> by way of comparison <span class="add">[to the turret first mentioned]</span>: but as to <span class="arrow"><span class="ar">مَأْذَنَةٌ↓</span></span>, it is a vulgar word: <span class="auth">(TA:)</span> the pl. is <span class="ar">مَآذِنُ</span>, agreeably with the original form of the sing. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWacBinN">
				<h3 class="entry"><span class="ar">مُؤَذِّنٌ</span></h3>
				<div class="sense" id="muWacBinN_A1">
					<p><span class="ar">مُؤَذِّنٌ</span> <em>One who notifies, makes known,</em> or <em>proclaims,</em> <span class="add">[by a chant,]</span> <em>the time of prayer;</em> <span class="auth">(M,* Mṣb, Ḳ;*)</span> <span class="add">[i. e., <em>who chants the call to prayer;</em>]</span> as also<span class="arrow"><span class="ar">أَذِينٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOocuwnN">
				<h3 class="entry"><span class="ar">مَأْذُونٌ</span></h3>
				<div class="sense" id="maOocuwnN_A1">
					<p><span class="ar">مَأْذُونٌ</span>, as meaning A slave <em>permitted,</em> or <em>having leave given him, by his master, to traffic,</em> is used for <span class="ar long">مَأْذُونٌ لَهُ</span>, <span class="auth">(Mṣb, TA,)</span> by the lawyers. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اذن</span> - Entry: <span class="ar">مَأْذُونٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maOocuwnN_B1">
					<p>Also <em>Having his ear hit,</em> or <em>hurt;</em> and so<span class="arrow"><span class="ar">مُؤْذَنٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0041.pdf" target="pdf">
							<span>Lanes Lexicon Page 41</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0042.pdf" target="pdf">
							<span>Lanes Lexicon Page 42</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0043.pdf" target="pdf">
							<span>Lanes Lexicon Page 43</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0044.pdf" target="pdf">
							<span>Lanes Lexicon Page 44</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
