<article class="root" id="Root_Ase">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/086_Asw">اسو</a></span>
				<span class="ar">اسى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/088_AXb">اشب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ase_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسى</span></h3>
				<div class="sense" id="Ase_1_A1">
					<p><span class="ar">أَسِىَ</span>, aor. <span class="ar">يَأْسَى</span>, inf. n. <span class="ar">أَسًى</span> or <span class="ar">أَسًا</span>, <em>He grieved,</em> or <em>mourned,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <span class="ar">عَلَيْهِ</span> <span class="add">[<em>for him</em> or <em>it</em>]</span>. <span class="auth">(M, Ḳ.)</span> <a href="index.php?data=01_A/086_Asw">See art. <span class="ar">اسو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasK.1">
				<h3 class="entry"><span class="ar">أَسٍ</span></h3>
				<div class="sense" id="OasK.1_A1">
					<p><span class="ar">أَسٍ</span>, <span class="add">[agreeably with analogy, as part. n. of <span class="ar">أَسِىَ</span>,]</span> <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">آسٍ↓</span></span> <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">أَسِىٌّ↓</span></span> <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar">أَسْيَانُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <a href="#OasowaAnu">a dial. var. of <span class="ar">أَسْوَانُ</span></a>, <span class="auth">(TA, <span class="add">[<a href="index.php?data=01_A/086_Asw">see art. <span class="ar">اسو</span></a>]</span>)</span> <em>Grieving, mourning,</em> or <em>sorrowful:</em> <span class="auth">(M, Mṣb, Ḳ:)</span> fem. <span class="add">[of the first, or second,]</span> <span class="ar">أَسِيَةٌ</span> <span class="auth">(M,)</span> or <span class="ar">آسِيَةٌ</span>, <span class="auth">(Ḳ,)</span> and <span class="add">[of <span class="ar">اسيان</span>]</span> <span class="ar">أَسْيَانَةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أَسَيْى</span>: <span class="auth">(TA:)</span> pl. <span class="add">[of <span class="ar">اسيان</span>]</span> <span class="ar">أَسْيَانُونَ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أَسَايُونَ</span> <span class="add">[which is extr. and somewhat doubtful]</span> <span class="auth">(Ḳ)</span> and <span class="add">[of <span class="ar">اسيانة</span>]</span> <span class="ar">أَسْيَانَاتٌ</span> and <span class="add">[of <span class="ar">اسيى</span> <a href="#OasiyapN">or of <span class="ar">أَسِيَةٌ</span></a>]</span> <span class="ar">أَسَايَا</span> <span class="auth">(M, Ḳ)</span> and <span class="add">[of <span class="ar">اسيى</span>]</span> <span class="ar">أَسْيَيَاتٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasoyaAnu">
				<h3 class="entry"><span class="ar">أَسْيَانُ</span></h3>
				<div class="sense" id="OasoyaAnu_A1">
					<p><span class="ar">أَسْيَانُ</span> <a href="#OasK">see above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasieBN.1">
				<h3 class="entry"><span class="ar">أَسِىٌّ</span></h3>
				<div class="sense" id="OasieBN.1_A1">
					<p><span class="ar">أَسِىٌّ</span> <a href="#OasK">see above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MsK.1">
				<h3 class="entry"><span class="ar">آسٍ</span></h3>
				<div class="sense" id="MsK.1_A1">
					<p><span class="ar">آسٍ</span> <a href="#OasK">see above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MsiyapN">
				<h3 class="entry"><span class="ar">آسِيَةٌ</span></h3>
				<div class="sense" id="MsiyapN_A1">
					<p><span class="ar">آسِيَةٌ</span> mentioned in this art. in the Ḳ: <a href="#AsK">see <span class="ar">آسٍ</span></a> <a href="index.php?data=01_A/082_Ask">in art. <span class="ar">اسك</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0061.pdf" target="pdf">
							<span>Lanes Lexicon Page 61</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
