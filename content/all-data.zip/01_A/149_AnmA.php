<article class="root" id="Root_AnmA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/148_Anm">انم</a></span>
				<span class="ar">انما</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/150_Anw">انو</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="IinBamaA">
				<h3 class="entry"><span class="ar">إِنَّمَا</span></h3>
				<div class="sense" id="IinBamaA_A1">
					<p><span class="ar">إِنَّمَا</span>: <a href="#IinBa">see <span class="ar">إِنَّ</span></a>, <a href="index.php?data=01_A/138_An">in art. <span class="ar">ان</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0118.pdf" target="pdf">
							<span>Lanes Lexicon Page 118</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
