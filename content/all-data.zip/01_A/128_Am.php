<article class="root" id="Root_Am">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/127_Ale">الى</a></span>
				<span class="ar">ام</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/129_AmA">اما</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Am_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمّ</span></h3>
				<div class="sense" id="Am_1_A1">
					<p><span class="ar">أَمَّهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor <span class="ar">ـُ</span>, <span class="auth">(T, M, Mṣb,)</span> inf. n. <span class="ar">أَمٌّ</span>, <span class="auth">(T, Ṣ, M, Mṣb,)</span> <em>He tended, repaired, betook himself,</em> or <em>directed his course, to,</em> or <em>towards, him,</em> or <em>it; aimed at, sought, endeavoured after, pursued,</em> or <em>endeavoured to reach</em> or <em>attain</em> or <em>obtain, him,</em> or <em>it; intended it,</em> or <em>purposed it;</em> syn. <span class="ar">قَصَدَهُ</span>, <span class="auth">(Lth, T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> and <span class="ar">تَوَخَّاهُ</span>, <span class="auth">(T,)</span> and <span class="ar">تَعَمَّدَهُ</span>, <span class="auth">(Mgh,)</span> and <span class="ar long">تَوَجَّهَ إِلَيْهِ</span>; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">أَمَّمَهُ↓</span></span>, and<span class="arrow"><span class="ar">تأمّمهُ↓</span></span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">ائتمّهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">يَمَّمّهُ↓</span></span>, <span class="auth">(T, M, Ḳ,)</span> and<span class="arrow"><span class="ar">تَيَمَّمَهُ↓</span></span>; <span class="auth">(T, M, Mgh, Ḳ;)</span> the last two being formed by substitution <span class="add">[of <span class="ar">ى</span> for <span class="ar">أ</span>]</span>. <span class="auth">(M.)</span> Hence, <span class="ar long">يَااَللّٰهُ أُمَّنَا بِخَيْرٍ</span> <span class="add">[<em>O God, bring us good</em>]</span>. <span class="auth">(JK in art. <span class="ar">اله</span>, and Bḍ in iii. 25.)</span> And <span class="ar long">لَأَمَّ مَا هُوَ</span>, occurring in a trad., meaning <em>He has indeed betaken himself to,</em> or <em>pursued, the right way:</em> or it is used in a pass. sense, as meaning <em>he is in the way which ought to be pursued.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">انْطَلَقْتُ أَتَأَمَّمُ↓ رَسُولَ ٱللّٰهِ</span></span>, in another trad., <em>I went away, betaking myself to the Apostle of God.</em> <span class="auth">(TA.)</span> Hence, also,<span class="arrow"><span class="ar long">تَيَمَّمَ↓ الصَّعِيدَ لِلصَّلَاهِ</span></span> <span class="add">[<em>He betook himself to dust,</em> or <em>pure dust,</em> to wipe his face and his hands and arms therewith, <em>for prayer</em>]</span>: <span class="auth">(T,* M,* Mgh, TA:)</span> as in the Ḳur iv. 46 and v. 9: <span class="auth">(ISk, M, TA:)</span> whence <span class="ar">الَّتَّيَمُّمُ</span> as meaning <em>the wiping the face and the hands and arms with dust;</em> <span class="auth">(ISk, T,* M,* Mgh, TA;)</span> i. e. <em>the performing the act termed</em> <span class="ar">تَوَضُّؤٌ</span> <em>with dust:</em> formed by substitution <span class="add">[of <span class="ar">ى</span> for <span class="ar">آ</span>]</span>: <span class="auth">(M, Ḳ:)</span> originally <span class="ar">التَّأَمُّمُ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Am_1_A2">
					<p><a href="#Am_8">See also 8</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Am_1_B1">
					<p><span class="ar">أَمَّهُ</span>, <span class="auth">(Ṣ, M, Mgh, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُمُ</span>}</span></add>, <span class="auth">(M, Mgh,)</span> inf. n. <span class="ar">أَمٌّ</span>, <span class="auth">(M, Mgh, Ḳ,)</span> <em>He broke his head, so as to cleave the skin,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>inflicting a wound such as is termed</em> <span class="ar">آمَّة</span> <span class="add">[q. v.]</span>; <span class="auth">(Ṣ;)</span> <span class="add">[i. e.]</span> <em>he struck,</em> <span class="auth">(M, Mgh, Ḳ,)</span> or <em>wounded,</em> <span class="auth">(M, Ḳ,)</span> the <span class="ar">أُمّ</span> <span class="add">[q. v.]</span> <em>of his head,</em> <span class="auth">(M, Mgh, Ḳ,)</span> with a staff, or stick. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Am_1_C1">
					<p><span class="ar">أَمَّهُمْ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar long">أَمَّ بِهِمْ</span>, <span class="auth">(M, Ḳ,)</span>) <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُمُ</span>}</span></add>,]</span> inf. n. <span class="ar">إِمَامَةٌ</span>, <span class="auth">(Ṣ, <span class="add">[but in the M and Ḳ it seems to be indicated that this is a simple subst.,]</span>)</span> <em>He preceded them; went before them; took precedence of them;</em> or <em>led them, so as to serve as an example,</em> or <em>object of imitation;</em> syn. <span class="ar">تَقَدَّمَهُمْ</span>; <span class="auth">(M, Ḳ;)</span> <span class="add">[and particularly]</span> <span class="ar long">فِى الصَّلَاةِ</span> <span class="add">[<em>in prayer</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar">أَمَّهُ</span> and <span class="ar long">بِهِ أَمَّ</span> <em>He prayed as</em> <span class="ar">إِمَام</span> <span class="add">[q. v.]</span> <em>with him.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أَمَّ الصُّفُوفَ</span> <em>He became</em> <span class="add">[or <em>acted as</em>]</span> <span class="ar">إِمَام</span> <em>to the people composing the ranks</em> <span class="add">[in a mosque, &amp;c.]</span>. <span class="auth">(Ḥar p. 680.)</span> You say also, <span class="ar long">لَا يَؤُمُّ الرَّجُلُ الرَّجُلَ فِى سُلْطَانِهِ</span> <span class="add">[<em>A man shall not take precedence of a man in his authority</em>]</span>; meaning, in his house, and where he has predominance, or superior power, or authority; nor shall he sit upon his cushion; for in doing so he would show him contempt. <span class="auth">(Mgh in art. <span class="ar">سلط</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Am_1_D1">
					<p><span class="ar">أَمَّت0</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <span class="add">[first pers. <span class="ar">أَمُمْتُ</span>,]</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْمُمُ</span>}</span></add>, <span class="auth">(M,)</span> inf. n. <span class="ar">أُمُومَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>She</em> <span class="auth">(a woman, Ṣ)</span> <em>became a mother;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <span class="add">[as also <span class="ar">أَمَّتٌ</span> having for its first pers. <span class="ar">أَمِمْتُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَمُ</span>}</span></add>; for]</span> you say, <span class="ar long">مَا كُنْتِ أُمَّا وَلَقَدْ أَمِمْتِ</span> <span class="add">[<em>Thou wast not a mother, and thou hast become a mother</em>]</span>, <span class="auth">(Ṣ, M, Ḳ, <span class="add">[in the last <span class="ar">فَأَمِمْتِ</span>,]</span>)</span> with kesr, <span class="auth">(Ḳ,)</span> inf. n.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: D2</span>
				</div>
				<div class="sense" id="Am_1_D2">
					<p><span class="ar">أَمَمْتُهُ</span> <em>I was to him a mother.</em> <span class="auth">(A in art. <span class="ar">ربض</span>.)</span> IAạr, speaking of a woman, said, <span class="ar long">كَانَتْ لَهَا عَمَّةٌ تَؤُمُّهَا</span>, meaning <span class="add">[<em>She had,</em> lit. <em>there was to her, a paternal aunt</em>]</span> <em>who was to her like the mother.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Am_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّم</span></h3>
				<div class="sense" id="Am_2_A1">
					<p><span class="ar">أَمَّمَهُ</span> and <span class="ar">يَمَّمَهُ</span>: <a href="#Am_1">see 1</a>, first sentence, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Am_3">
				<h3 class="entry">3. ⇒ <span class="ar">آمّ</span></h3>
				<div class="sense" id="Am_3_A1">
					<p><span class="ar">آمّهُ</span> <em>It agreed with it, neither exceeding nor falling short.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Am_3_A2">
					<p><span class="add">[See also the part. n. <span class="ar">مُؤَامٌّ</span>, voce <span class="ar">أَمَمٌ</span>; whence it seems that there are other senses in which <span class="ar">آمَّ</span> may be used, intransitively.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Am_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأمّم</span></h3>
				<div class="sense" id="Am_5_A1">
					<p><span class="ar">تَأَمَّمَ</span> and <span class="ar">تَيَمَّمَ</span><a href="#Am_1">see 1</a>, former part, in four places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Am_5_B1">
					<p><span class="ar long">تأمّم بِهِ</span>: <a href="#Am_8">see 8</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Am_5_C1">
					<p><span class="ar">تَأَمَّمْتُ</span> <em>I took for myself,</em> or <em>adopted, a mother.</em> <span class="auth">(Ṣ.)</span> And <span class="ar">تَأَمَّمَهَا</span> <em>He took her for himself,</em> or <em>adopted her, as a mother;</em> <span class="auth">(Ṣ,* M, Ḳ;)</span> as also<span class="arrow"><span class="ar">استآمّها↓</span></span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar">تَأَمَّهَهَا</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Am_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتمّ</span></h3>
				<div class="sense" id="Am_8_A1">
					<p><span class="ar">ائتمّهُ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَمَّهُ</span>]</span>: <a href="#Am_1">see 1</a>, first sentence.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Am_8_B1">
					<p><span class="ar long">ائتمّ بِهِ</span> <em>He followed his example; he imitated him; he did as he did, following his example;</em> or <em>taking him as an example, an exemplar, a pattern,</em> or <em>an object of imitation;</em> <span class="auth">(Ṣ, Mgh, Mṣb;)</span> as also<span class="arrow"><span class="ar">أَمَّهُ↓</span></span>: <span class="auth">(Bḍ in xvi. 121:)</span> the object of the verb is termed <span class="ar">إِمَامٌ</span>; <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ;)</span> applied to a learned man, <span class="auth">(Mṣb,)</span> or a head, chief, or leader, or some other person. <span class="auth">(M, Ḳ.)</span> <em>He made it an</em> <span class="ar">أُمَّة</span> or <span class="ar">إِمَّة</span> <span class="add">[i. e. <em>a way, course,</em> or <em>rule, of life</em> or <em>conduct;</em> as explained immediately before in the work whence this is taken]</span>; as also<span class="arrow"><span class="ar long">تأمّم↓ به</span></span>. <span class="auth">(M.)</span> You say, <span class="ar long">ائتمّ بِالشَّيْءِ</span> and <span class="ar long">ائْتَمَى به</span>, by substitution <span class="add">[of <span class="ar">ى</span> for <span class="ar">م</span>]</span>, <span class="auth">(M, Ḳ,)</span> disapproving of the doubling <span class="add">[of the <span class="ar">م</span>]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Am_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأمّ</span></h3>
				<div class="sense" id="Am_10_A1">
					<p><a href="#Am_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oamo">
				<h3 class="entry"><span class="ar">أَمْ</span></h3>
				<div class="sense" id="Oamo_A1">
					<p><span class="ar">أَمْ</span> is a conjunction, <span class="auth">(Ṣ, M, Ḳ,)</span> connected with what precedes it <span class="auth">(Mṣb, Mughnee)</span> so that neither what precedes it nor what follows it is independent, the one of the other. <span class="auth">(Mughnee.)</span> It denotes interrogation; <span class="auth">(M, Ḳ;)</span> or is used in a case of interrogation, <span class="auth">(Ṣ, Mṣb,)</span> corresponding to the interrogative <span class="ar">أَ</span>, and meaning <span class="ar">أَىّ</span>, <span class="auth">(Ṣ,)</span> or, as Z says, <span class="ar long">أَىُّ الأَمْرَيْنِ كَائِنٌ</span>; <span class="add">[for an explanation of which, see what follows;]</span> <span class="auth">(Mughnee;)</span> or, <span class="add">[in other words,]</span> corresponding to the interrogative <span class="ar">أَ</span>, whereby, and by <span class="ar">أَمْ</span>, one seeks, or desires, particularization: <span class="auth">(Mughnee:)</span> it is as though it were an interrogative after an interrogative. <span class="auth">(Lth, T.)</span> Thus you say, <span class="ar long">أَزَيُدٌ فِى الدَّارِ أَمْ عَمْرٌو</span> <span class="add">[<em>Is Zeyd in the house, or ʼAmr?</em>]</span>; <span class="auth">(Ṣ, Mughnee;)</span> i. e. which of them two (<span class="ar">أَيُّهُمَا</span>) is in the house? <span class="auth">(Ṣ;)</span> therefore what follows <span class="ar">ام</span> and what precedes it compose one sentence; and it is not used in commanding nor in forbidding; and what follows it must correspond to what precedes it in the quality of noun and of verb; so that you say, <span class="ar long">أَزَيْدٌ قَائِمٌ أَمع قَاعِدٌ</span> <span class="add">[<em>Is Zeyd standing, or sitting?</em>]</span> and <span class="ar long">أَقَامَ زَيْدٌ أَمْ قَعَدَ</span> <span class="add">[<em>Did Zeyd stand, or sit?</em>]</span>. <span class="auth">(Mṣb.)</span> It is not to be coupled with <span class="ar">أَ</span> after it: you may not say, <span class="ar long">أَعِنْدَكَ زَيْدٌ أَمْ أَعِنْدَكَ عَمْرٌو</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oamo_A2">
					<p>As connected in like manner with what goes before, it is preceded by <span class="ar">أَ</span> denoting equality <span class="add">[by occurring after <span class="ar">سَوَآءٌ</span>, &amp;c.]</span>, and corresponds thereto, as in <span class="add">[the Ḳur lxiii. 6,]</span> <span class="ar long">سَوَآءُ عَلَيْهِمْ أَسْتَغْفَرْتَ لَهُمٌ لَمٌ تَسْتَغُفِرْ لَهُمٌ</span> <span class="add">[It will be <em>equal to them whether thou beg forgiveness for them or do not beg forgiveness for them</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oamo_A3">
					<p>It is also unconnected with what precedes it, <span class="auth">(Ṣ, Mṣb, Mughnee,)</span> implying always digression, <span class="auth">(Mughnee,)</span> preceded by an enunciative, or an interrogative, <span class="auth">(Ṣ, Mṣb, Mughnee,)</span> other than <span class="ar">أَ</span>, <span class="auth">(Mughnee,)</span> or by <span class="ar">أَ</span> not meant <span class="add">[really]</span> as an interrogative but to denote disapproval, <span class="auth">(Mughnee,)</span> and signifies <span class="ar">بَلْ</span>, <span class="auth">(Lth, Zj, T, Ṣ, M, Mughnee, Ḳ,)</span> or <span class="ar">بَلْ</span> and <span class="ar">أَ</span> together, <span class="auth">(Mṣb,)</span> and this is its meaning always accord. to all the Basrees, but the Koofees deny this. <span class="auth">(Mughnee.)</span> Thus, using it after an enunciative, you say, <span class="ar long">إِنَّهَا لَإِبِلٌ أَمْ شَآءٌ</span> <span class="add">[<em>Verily they are camels: nay,</em> or <em>nay but, they are sheep,</em> or <em>goats:</em> or <em>nay, are they sheep,</em> or <em>goats?</em>]</span>: <span class="auth">(Ṣ Mṣb, Mughnee:)</span> this being said when one looks at a bodily form, and imagines it to be a number of camels, and says what first occurs to him; then the opinion that it is a number of sheep or goats suggests itself to him, and he turns from the first idea, and says, <span class="ar long">أَمْ شَآءٌ</span>, meaning <span class="ar">بَلْ</span>, because it is a digression from what precedes it; though what follows <span class="ar">بل</span> is <span class="add">[properly]</span> a thing known certainly, and what follows <span class="ar">ام</span> is opined. <span class="auth">(Ṣ, TA.)</span> And using it after an interrogative in this case, you say, <span class="ar long">هَلْ زيْدٌ مُنْطَلِقٌ أَمْ عَمْرٌو</span> <span class="add">[<em>Is Zeyd going away? Nay rather,</em> or, <em>or rather, is ʼAmr?</em>]</span>: you digress from the question respecting Zeyd's going away, and make the question to relate to ʼAmr; so that <span class="ar">ام</span> implies indecisive opinion, and interrogation, and digression. <span class="auth">(Ṣ.)</span> And thus using it, you say, <span class="ar long">هَلْ زَيْدٌ قَامَ أَمْ عَمْرٌو</span> <span class="add">[<em>Did Zeyd stand? Nay rather,</em> or <em>or rather, did ʼAmr?</em>]</span>. <span class="auth">(Mṣb.)</span> And an ex. of the same is the saying <span class="add">[in the Ḳur xiii. 17]</span>, <span class="ar long">هَلْ يَسْتَوِى الْأَعْمَى وَالْبَصِيرُ أَمْ هَلْ تَسْتَوِى الظُّلُمَاتُ وَالنُّورُ</span> <span class="add">[<em>Are the blind and the seeing equal? Or rather are darkness and light equal?</em>]</span>. <span class="auth">(Mughnee.)</span> And an ex. of it preceded by <span class="ar">أَ</span> used to denote disapproval is the saying <span class="add">[in the Ḳur vii. 194]</span>, <span class="ar long">أَلَهُمْ أَرْجُلٌ يَمْشُونَ بِهَا أَمْ لَهُمْ أَيْدٍ يَبْطِشُونَ بِهَا</span> <span class="add">[<em>Have they feet, to walk therewith? Or have they hands to assault therewith?</em>]</span>: for <span class="ar">أَ</span> is here equivalent to a negation. <span class="auth">(Mughnee.)</span> <span class="add">[It has been shown above that]</span> <span class="ar">أَمْ</span> is sometimes introduced immediately before <span class="ar">هَلْ</span>: <span class="auth">(Ṣ, Ḳ:)</span> but IB says that this is when <span class="ar">هل</span> occurs in a phrase next before it; <span class="add">[as in the ex. from the Ḳur xiii. 17, cited above;]</span> and in this case, the interrogative meaning of <span class="ar">ام</span> is annulled; it being introduced only to denote a digression. <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0089"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oamo_A4">
					<p>It is also used as a simple interrogative; accord. to the assertion of AO; in the sense of <span class="ar">هَلْ</span>; <span class="auth">(Mughnee;)</span> or in the sense of the interrogative <span class="ar">أَ</span>; <span class="auth">(Lth, T, Ḳ)</span> as in the saying, <span class="ar long">أَمْ عِنْدَكَ غَدَآءِ حَاضِرٌ</span>, meaning <em>Hast thou a morning-meal ready?</em> a good form of speech used by the Arabs; <span class="auth">(Lth, T;)</span> and allowable when preceded by another phrase. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oamo_A5">
					<p>And sometimes it is redundant; <span class="auth">(AZ, T, Ṣ, Mughnee, Ḳ)</span> in the dial. of the people of El-Yemen; <span class="auth">(T;)</span> as in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا دَهْنَ أَمْ مَا كَانَ مَشْيِى رقَصَا</span> *</div> 
						<div class="star">* <span class="ar long">بَلْ قَدْ تَكُونُ مِشْيَتِى تَوَقُّصَا</span> *</div> 
					</blockquote>
					<p><span class="auth">(T, Ṣ,* <span class="add">[in the latter, <span class="ar long">يا هِنْدُ</span>, and only the former hemistich is given,]</span>)</span> meaning <em>O Dahnà,</em> <span class="auth">(the curtailed form <span class="ar">دَهْنَ</span> being used for <span class="ar">دَهْنَآء</span>,)</span> <em>my walking was not,</em> as now in my age, <span class="add">[a feeble movement like]</span> <em>dancing: but</em> in my youth, <em>my manner of walking used to be a bounding:</em> <span class="auth">(T:)</span> this is accord. to the opinion of AZ: but accord. to another opinion, <span class="ar">ام</span> is here <span class="add">[virtually]</span> conjoined with a preceding clause which is suppressed; as though the speaker had said, <span class="ar long">يَا دَهْنَ أَكَانَ مَشْيِى رَقَصَّا أَمْ مَا كَانَ كَذلِكَ</span>. <span class="auth">(AḤát, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oamo_B1">
					<p>It is also used <span class="auth">(T, Mughnee)</span> in the dial. of the people of El-Yemen, <span class="auth">(T,)</span> or of Teiyi and Himyer, <span class="auth">(Mughnee,)</span> in the sense of <span class="ar">ال</span>, <span class="auth">(T,)</span> to render a noun determinate. <span class="auth">(Mughnee.)</span> So in the trad., <span class="ar long">لَيْسَ مِنَ امْبِرّ امْصِيامُ فِى امْسَفَرِ</span>, <span class="auth">(T, Mughnee,)</span> i. e. <span class="ar long">الَيْسَ مِنَ البِرِّ الصِّيَامُ فِى السَّفَرِ</span> <span class="add">[<em>Fasting in journeying is not</em> an act <em>of obedience</em> to God]</span>. <span class="auth">(T, and M in art. <span class="ar">بر</span>.)</span> So too in the trad., <span class="ar long">اَلْآنَ طَابَ امْضَرْبُ</span> <em>Now fighting has become lawful;</em> as related accord. to the dial. of Himyer, for <span class="ar">الضَّرْبُ</span>. <span class="auth">(TA in art. <span class="ar">طيب</span>.)</span> It has been said that this form <span class="ar">ام</span> is only used in those cases in which the <span class="ar">ل</span> of the article does not become incorporated into the first letter of the noun to which it is prefixed; as in the phrase, <span class="ar long">خُذِ الرُّمْحَ وَارْكَبِ امْفَرَسَ</span> <span class="add">[<em>Take thou the spear, and mount the mare,</em> or <em>horse</em>]</span>, related as heard in El-Yemen; but this usage may be peculiar to some of the people of that country; not common to all of them; as appears from what we have cited above. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Oamo_C1">
					<p><span class="ar">أَمَ</span> for <span class="ar">أَمَا</span>, before an oath: <a href="index.php?data=01_A/129_AmA">see art. <span class="ar">اما</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Oamo_D1">
					<p>And <span class="ar long">أَمَ ٱللّٰهِ</span> and <span class="ar long">أَمُ ٱللّٰهِ</span>, &amp;c.: <a href="#OaYomunu">see <span class="ar long">أَيْمُنُ ٱللّٰهِ</span></a>, <a href="index.php?data=28_e/027_ymn">in art. <span class="ar">يمن</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumBN">
				<h3 class="entry"><span class="ar">أُمٌّ</span></h3>
				<div class="sense" id="OumBN_A1">
					<p><span class="ar">أُمٌّ</span> <em>A mother</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ, &amp;c.)</span> <span class="add">[of a human being and]</span> of any animal; <span class="auth">(IAạr, T;)</span> as also↓<span class="ar">إِمٌّ</span>, <span class="auth">(Sb, M, Mṣb, Ḳ)</span> and↓<span class="ar">إُمَّةٌ</span>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">أُمَّهَةٌ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> which last is the original form <span class="auth">(Ṣ, Mṣb)</span> accord. to some, <span class="auth">(Mṣb,)</span> or the <span class="ar">ه</span> in this is augmentative <span class="auth">(M, Mṣb)</span> accord. to others: <span class="auth">(Mṣb:)</span> the pl. is <span class="ar">أُمَّهَاتٌ</span> <span class="auth">(Lth, T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أُمَّاتٌ</span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> or the former is applied to human beings, and the latter to beasts; <span class="auth">(T, Ṣ;)</span> or the former to rational beings, and the latter to irrational; <span class="auth">(M, Ḳ;)</span> or the former is much applied to human beings, and the latter to others, for the sake of distinction; <span class="auth">(Mṣb;)</span> but the reverse is sometimes the case: <span class="auth">(IB:)</span> IDrst and others hold the latter to be of weak authority: <span class="auth">(TA:)</span> <a href="#OumBN">the dim. of <span class="ar">أُمٌّ</span></a> is <span class="arrow"><span class="ar">أُمَيْمَةٌ↓</span></span> <span class="auth">(T, Ṣ, Ḳ)</span> accord. to some of the Arabs; but correctly, <span class="add">[accord. to those who hold <a href="#OumBN">the original form of <span class="ar">أُمٌّ</span></a> to be <span class="ar">أُمَّهَةٌ</span>,]</span> it is <span class="arrow"><span class="ar">أُمَيْمِهَةٌ↓</span></span>. <span class="auth">(Lth, T, TA. <span class="add">[In a copy of the T, I find this latter form of the dim. written <span class="ar">اميهة</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OumBN_A2">
					<p><span class="ar long">أُمَّ لَكَ</span> denotes dispraise; <span class="auth">(Ṣ;)</span> being used by the Arabs as meaning <em>Thou hast no</em> free, or ingenuous, <em>mother;</em> because the sons of female slaves are objects of dispraise with the Arabs; and is only said in anger and reviling: <span class="auth">(AHeyth, T:)</span> or, as some say, it means <em>thou art one</em> who has been picked up as a foundling, <em>having no</em> Known <em>mother:</em> <span class="auth">(TA:)</span> <span class="add">[or]</span> it is also sometimes used in praise; <span class="auth">(AʼObeyd, T, Ṣ, Ḳ;)</span> and is used as an imprecation without the desire of its being fulfilled upon the person addressed, being said in vehemence of love; <span class="add">[lit. meaning <em>mayest thou have no mother!</em>]</span>, like <span class="ar long">ثَكِلَتْكَ أُمُّكَ</span>, and <span class="ar long">لَا أَبَا لَكَ</span>, <span class="add">[and <span class="ar long">قَاتَلَكَ ٱللّٰهُ</span>,]</span>, &amp;c. <span class="auth">(Ḥar p. 165.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OumBN_A3">
					<p>Some elide the <span class="ar">ا</span> of <span class="ar">أُمّ</span>; as in the saying of 'Adee Ibn-Zeyd.</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَيُّهَا العَائِبُ عِنْدِمَّ زَيْدٍ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O thou who art blaming in my presence the mother of Zeyd</em>]</span>; meaning, <span class="ar long">عِنْدِى أُمَّ زَيْدٍ</span>; the <span class="ar">ى</span> of <span class="ar">عندى</span> being also elided on account of the occurrence of two quiescent letters <span class="add">[after the elision of the <span class="ar">ا</span> of <span class="ar">أُمّ</span>]</span>: <span class="auth">(Lth, T, Ṣ:)</span> and as in the phrase <span class="ar">وَيْلُمِّهِ</span>, <span class="auth">(Ṣ,)</span> which means <span class="ar long">وَيْلٌ لِأُمِّهِ</span>. <span class="auth">(Ṣ, and Ḳ in art. <span class="ar">ويل</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OumBN_A4">
					<p><span class="ar long">هُمَا أُمَّاكّ</span> means <em>They two are thy two parents:</em> or <em>thy mother and thy maternal aunt.</em> <span class="auth">(Ḳ.)</span> <span class="add">[But]</span> <span class="ar long">فَدَّاهُ بِأُمَّيْهِ</span> is said to mean <span class="add">[<em>He expressed a wish that he</em> <span class="auth">(another)</span> <em>might be ransomed with</em>]</span> <em>his mother and his grandmother.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OumBN_A5">
					<p>One says also,<span class="arrow"><span class="ar long">يَا أُمَّتِ↓ لَا تَفْعَلِى</span></span> <span class="add">[<em>O my mother, do not thou</em> such a thing]</span>, and <span class="add">[in like manner]</span> <span class="ar long">يَا أَبَتِ افْعَلْ</span>; making the sign of the fem. gender a substitute for the <span class="add">[pronominal]</span> affix <span class="ar">ى</span>; and in a case of pause, you say <span class="ar long">يَا أُمَّهْ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OumBN_A6">
					<p>And one says, <span class="ar long">مَا أُمِّى وَأُمُّهُ</span>, and <span class="ar long">مَا شَكْلِى وَشَكْلُهُ</span>, meaning <span class="add">[<em>What relationship have I to him,</em> or <em>it?</em> or <em>what concern have I with him,</em> or <em>it?</em> or]</span> <em>what is my case and</em> <span class="add">[what is]</span> <em>his</em> or <em>its, case?</em> because of his, or its, remoteness from me: whence, <span class="auth">(T,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمَا أُمِّى وَأُمُّ الوَحْشِ لَمَّا</span> *</div> 
						<div class="star">* <span class="ar long">تَفَرَّعَ فِى مَفَارِقِىَ الْمَشِيبُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And what concern have I with the wild animals when hoariness hath spread in the places where my hair parts?</em>]</span>; <span class="auth">(T, Ṣ;)</span> i. e. <span class="ar long">مَا أَنَاوَطَلَبُ الوَحْشِ بَعْدَ مَا كَبِرْتُ</span> <span class="add">[i. e. <span class="ar long">مَا أمْرِى وَطَلَبُ الوَحْشِ</span>: in one copy of the Ṣ, <span class="ar">وَطَلَبَ</span>, i. e. with <span class="ar">وَ</span> as a prep. denoting concomitance, and therefore governing the accus. case: both readings virtually meaning <em>what concern have I with the pursuing of the wild animals after I have grown old?</em>]</span>: he means, the girls: and the mention of <span class="ar">أُمّ</span> in the verse is superfluous. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OumBN_A7">
					<p><span class="ar">أُمٌّ</span> also relates to inanimate things that have growth; as in <span class="ar long">أُمُّ الشَّجَرَةِ</span> <span class="add">[<em>The mother of the tree</em>]</span>; and <span class="ar long">أُمُّ النَّخْلَةِ</span> <span class="add">[<em>the mother of the palm-tree</em>]</span>; and <span class="ar long">أُمُّ المَوْزِةَ</span> <span class="add">[<em>the mother of the banana-tree;</em> <a href="#AlmaWozipa">of which see an ex</a>. <a href="index.php?data=24_m/195_mwz">in art. <span class="ar">موز</span></a>]</span>; and the like. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OumBN_A8">
					<p>And it signifies also The <em>source, origin, foundation,</em> or <em>basis,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> of a thing, <span class="auth">(Ṣ, Mṣb, <span class="add">[in the former of which, this is the first of the meanings assigned to the word,]</span>)</span> or of anything; <span class="auth">(M, Ḳ)</span> its <em>stay, support,</em> or <em>efficient cause of subsistence.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OumBN_A9">
					<p><em>Anything to which other things are collected together,</em> or <em>adjoined:</em> <span class="auth">(IDrd, M, Ḳ:)</span> <em>anything to which the other things that are next thereto are collected together,</em> or <em>adjoined:</em> <span class="auth">(Lth, T:)</span> the <em>main,</em> or <em>chief, part</em> of a thing; the <em>main body</em> thereof: and that which is <em>a compriser,</em> or <em>comprehender,</em> of <span class="add">[other]</span> things: <span class="auth">(Ḥam p. 44:)</span> the <em>place of collection, comprisal,</em> or <em>comprehension,</em> of a thing; the <em>place of combination</em> thereof. <span class="auth">(En-Naḍr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="OumBN_A10">
					<p>And hence, <span class="auth">(IDrd, M,)</span> The <em>head,</em> or <em>chief,</em> of a people, or company of men; <span class="auth">(IDrd, Ṣ, M, Ḳ;)</span> because others collect themselves together to him: <span class="auth">(IDrd, TA:)</span> so in the phrase <span class="ar long">أُمُّ عِيَالٍ</span> <span class="add">[lit. <em>the mother of a household</em>]</span>, in a poem of Esh-Shenfarà: <span class="auth">(IDrd, M:)</span> or in this instance, it has the signification next following, accord. to Esh-Sháfiʼee. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="OumBN_A11">
					<p><em>A man who has the charge of the food and service</em> of a people, or company of men; accord. to EshSháfi'ee: <span class="auth">(T:)</span> or their <em>servant.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="OumBN_A12">
					<p>A man's <em>aged wife.</em> <span class="auth">(IAạr, T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="OumBN_A13">
					<p><em>A place of habitation</em> or <em>abode.</em> <span class="auth">(Ḳ.)</span> So in the Ḳur <span class="add">[ci. 6]</span>, <span class="ar long">فَأُمُّهُ هَاوِيَةٌ</span> <em>His place of habitation</em> or <em>abode</em> <span class="add">[shall be]</span> <em>the fire</em> <span class="add">[of Hell]</span>: <span class="auth">(Bḍ, Jel, TA:)</span> or, as some say, the meaning is <span class="ar long">أُمُّ رَأْسِهِ هَاوِيَةٌ فِيهَا</span> <span class="add">[<em>his brain shall fall into it,</em> namely, the fire of Hell]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="OumBN_A14">
					<p>The <em>ensign,</em> or <em>standard, which an army follows.</em> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#OumBu">See <span class="ar long">أُمُّ الرُّمْحِ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="OumBN_A15">
					<p>It is said in a trad., respecting the prophets, <span class="ar long">أُمَّهَا تُهُمْ شَتَّى</span>, meaning that, though their religion is one, <em>their laws,</em> or <em>ordinances,</em> or <em>statutes, are various,</em> or <em>different:</em> or the meaning is, <em>their times are various,</em> or <em>different.</em> <span class="auth">(TA in art. <span class="ar">شت</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="OumBN_A16">
					<p><a href="#OumBapN">See also <span class="ar">أُمَّةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A17</span>
				</div>
				<div class="sense" id="OumBN_A17">
					<p><span class="ar">أُمّ</span> is also prefixed to nouns significant of many things. <span class="auth">(M.)</span> <span class="add">[Most of the compounds thus formed will be found explained in the arts. to which belong the nouns that occupy the second place. The following are among the more common, and are therefore here mentioned, with the meanings assigned to them in lexicons in the present art., and arranged in distinct classes.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A18</span>
				</div>
				<div class="sense" id="OumBN_A18">
					<p><span class="ar long">أُمُّ الرَّجُلِ</span> <em>The man's wife;</em> and <em>the person who manages the affairs of his house</em> or <em>tent.</em> <span class="auth">(TA.)</span> And <span class="ar long">أُمُّ مَثْوَى الرَّجُلِ</span> <em>The man's wife, to whom he betakes himself for lodging,</em> or <em>abode:</em> <span class="auth">(T:)</span> <em> the mistress of the man's place of abode.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A19</span>
				</div>
				<div class="sense" id="OumBN_A19">
					<p><span class="ar long">أُمُّ عَامِرٍ</span> <em>The hyena,</em> or <em>female hyena;</em> as also <span class="ar long">أُمُّ عَمْرٍو</span>; <span class="auth">(TA;)</span> and <span class="ar long">أُمُّ الطَّرِيقِ</span>. <span class="auth">(Ṣ, TA. <span class="add">[See also other significations of the first and last below.]</span>)</span> <span class="ar long">أُمُّ حِلْسٍ</span> <span class="add">[or <span class="ar long">أُمُّ الحِلْسِ</span> <span class="auth">(as in the Ṣ and Ḳ in art. <span class="ar">حلَس</span>)</span>]</span> <em>The she-ass.</em> <span class="auth">(TA.)</span> <span class="ar long">أُمُّ البَيْضِ</span> <em>The female ostrich.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A20</span>
				</div>
				<div class="sense" id="OumBN_A20">
					<p><span class="ar long">أُمُّ الرَّأُسِ</span> <em>The brain:</em> <span class="auth">(T, M, Ḳ:)</span> or <em> the thin skin that is upon it:</em> <span class="auth">(IDrd, M, Ḳ:)</span> or <em>the bag in which is the brain:</em> <span class="auth">(T:)</span> or <em>the skin that comprises the brain;</em> <span class="add">[<em>the meninx,</em> or <em>dura mater and pia mater;</em>]</span> <span class="auth">(Ṣ, Mgh;)</span> which is called <span class="ar long">أُمُّ الدِّمَاغِ</span> <span class="auth">(Ṣ, Mṣb)</span> likewise. <span class="auth">(Ṣ.)</span></p>
				</div>
				<span class="pb" id="Page_0090"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A21</span>
				</div>
				<div class="sense" id="OumBN_A21">
					<p><span class="ar long">أُمُّ النُّجُومِ</span> <em>The Milky way;</em> <span class="auth">(Ṣ, M, Ḳ)</span> because it is the place where the stars are collected together <span class="add">[in great multitude]</span>: <span class="auth">(M:)</span> or, as some say, <em>the sun;</em> which is the greatest of the stars. <span class="auth">(Ḥam pp. 43 and 44.)</span> Because of the multitude of the stars in the Milky way, one says, <span class="ar long">مَا أَشْبَهَ مَجْلِسَكَ بِأُمِّ النُّجُومِ</span> † <span class="add">[<em>How like is thine assembly to the Milky way!</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A22</span>
				</div>
				<div class="sense" id="OumBN_A22">
					<p><span class="ar long">أُمُّ القُرَى</span> <span class="add">[<em>The mother of the towns; the metropolis:</em> particularly]</span> <em>Mekkeh;</em> <span class="auth">(T, Ṣ, M, Ḳ)</span> because asserted to be in the middle of the earth; <span class="auth">(M, Ḳ;)</span> or because it is the Kibleh of all men, and thither they repair; <span class="auth">(M, Ḳ;*)</span> or because it is the greatest of towns in dignity: <span class="auth">(M, Ḳ:)</span> and every city is the <span class="ar">أُمّ</span> of the towns around it. <span class="auth">(T.)</span> <span class="ar long">أُمُّ التَّنَائِفِ</span> <em>The most difficult of deserts</em> or <em>of waterless deserts:</em> <span class="auth">(T:)</span> or <em>a desert,</em> or <em>waterless desert,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>far extending.</em> <span class="auth">(Ṣ.)</span> <span class="ar long">أُمُّ الطَّرِيقِ</span> <span class="auth">(T, Ṣ, M)</span> and<span class="arrow"><span class="ar long">أُمَّةٌ↓ الطَّرِيقِ</span></span> <span class="auth">(M, Ḳ)</span> <em>The main part</em> <span class="add">[or <em>track</em>]</span> <em>of the road:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> <em>when it is a great road</em> or <em>track, with small roads</em> or <em>tracks around it</em> <span class="add">[or <em>on either side</em>]</span>, <em>the greatest is so called.</em> <span class="auth">(T. <span class="add">[The former has also another signification, mentioned above.]</span>)</span> <span class="ar long">أُمُّ عَامِرٍ</span> <em>The cemetery,</em> or <em>place of graves.</em> <span class="auth">(T. <span class="add">[This, also, has another signification, mentioned before.]</span>)</span> <span class="ar long">أُمُّ الرُّمْحِ</span> <em>The ensign,</em> or <em>standard;</em> <span class="auth">(M, Ḳ;)</span> also called <span class="ar long">أُمُّ الحَرْبِ</span>; <span class="auth">(TA;)</span> <span class="add">[and simply <span class="ar">الأُمُّ</span>, as shown above;]</span> and <em>the piece of cloth which is wound upon the spear.</em> <span class="auth">(T, M.*)</span> <span class="ar long">أُمُّ جَابِرٍ</span> <em>Bread:</em> and also <em>the ear of corn.</em> <span class="auth">(T.)</span> <span class="ar long">أُمُّ الخَبَائِثِ</span> <span class="add">[<em>The mother of evil qualities</em> or <em>dispositions;</em> i. e.]</span> <em>wine.</em> <span class="auth">(T.)</span> <span class="ar long">أُمُّ الكِتَابِ</span> <span class="add">[in the Ḳur iii. 5 and xiii. 39]</span> <span class="auth">(Ṣ, M, &amp;c.)</span> <em>The original of the book</em> or <em>scripture</em> <span class="add">[i. e. <em>of the Ḳur-án</em>]</span>: <span class="auth">(Zj, M, Ḳ:)</span> or <em> the Preserved Tablet,</em> <span class="ar long">اللَّوْحُ المَحْفُوظُ</span>: <span class="auth">(M, Mṣb, Ḳ:)</span> or it signifies, <span class="auth">(M, Ḳ,)</span> or signifies also, <span class="auth">(Mṣb,)</span> <em>the opening chapter of the Ḳur-án; the</em> <span class="ar">فَاتِحَة</span>; <span class="auth">(M, Mṣb, Ḳ;)</span> because every prayer begins therewith; <span class="auth">(M;)</span> as also <span class="ar long">أُمُّ القُرْآنِ</span>: <span class="auth">(Mṣb, Ḳ:)</span> or the former, <em>the whole of the Ḳur-án,</em> <span class="auth">(I’Ab, Ḳ,)</span> <em>from its beginning to its end:</em> <span class="auth">(TA:)</span> and the latter, <em>every plain,</em> or <em>explicit, verse of the Ḳur-án, of those which relate to laws and statutes and obligatory ordinances.</em> <span class="auth">(T, Ḳ.)</span> <span class="ar long">أُمُّ الشَّرِّ</span> <em>Every evil upon the face of the earth:</em> and <span class="ar long">أُمُّ الخَيْرِ</span> <em>every good upon the face of the earth.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimBN">
				<h3 class="entry"><span class="ar">إِمٌّ</span></h3>
				<div class="sense" id="IimBN_A1">
					<p><span class="ar">إِمٌّ</span>: <a href="#OumBN">see <span class="ar">أُمٌّ</span></a>, first sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OamBapN">
				<h3 class="entry"><span class="ar">أَمَّةٌ</span></h3>
				<div class="sense" id="OamBapN_A1">
					<p><span class="ar">أَمَّةٌ</span>: <a href="#AmBapN">see <span class="ar">آمَّةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumBapN">
				<h3 class="entry"><span class="ar">أُمَّةٌ</span></h3>
				<div class="sense" id="OumBapN_A1">
					<p><span class="ar">أُمَّةٌ</span> <em>A way, course, mode,</em> or <em>manner, of acting,</em> or <em>conduct,</em> or <em> the like;</em> <span class="auth">(AZ, Ṣ;)</span> as also<span class="arrow"><span class="ar">إِمَّةٌ↓</span></span>: <span class="auth">(AZ, Ṣ, Ḳ:)</span> Fr assigns this meaning to the latter, and that next following to the former: <span class="auth">(T:)</span> <em>a way, course,</em> or <em>rule, of life,</em> or <em>conduct;</em> <span class="auth">(Fr, T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِمَّةٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OumBapN_A2">
					<p><em>Religion;</em> as also<span class="arrow"><span class="ar">إِمَّةٌ↓</span></span>: <span class="auth">(AZ, Ṣ, M, Ḳ: <span class="add">[one of the words by which this meaning is expressed in the M and Ḳ is <span class="ar">شِرْعَة</span>; for which Golius found in the Ḳ <span class="ar">سرعة</span>:]</span>)</span> <em>one course, which people follow, in religion.</em> <span class="auth">(T.)</span> You say, <span class="ar long">فُلَانٌ لَا أُمَّةَ لَهُ</span> <em>Such a one has no religion; no religious persuasion.</em> <span class="auth">(Ṣ.)</span> And a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَهَلْ يَسْتَوِى ذُو أُمَّةٍ وَكَفُورُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And are one who has religion and one who is an infidel equal?</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OumBapN_A3">
					<p><em>Obedience</em> <span class="add">[app. <em>to God</em>]</span>. <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OumBapN_B1">
					<p>The <em>people of a</em> <span class="add">[<em>particular</em>]</span> <em>religion:</em> <span class="auth">(Akh, Ṣ:)</span> <em>a people to whom an apostle is sent,</em> <span class="auth">(M, Ḳ,)</span> <em>unbelievers and believers;</em> such being called his <span class="ar">أُمَّة</span>: <span class="auth">(M:)</span> <em>any people called after a prophet</em> are said to be his <span class="ar">أُمَّة</span>: <span class="auth">(Lth, T:)</span> the <em>followers of the prophet:</em> pl. <span class="ar">أُمَمٌ</span>. <span class="auth">(T, Mṣb.)</span> It is said in the Ḳur <span class="add">[ii. 209]</span>, <span class="ar long">كَانَ النَّاسُ أُمَّةٍ واحِدَةً</span>, meaning <em>Mankind was</em> <span class="add">[<em>a people</em>]</span> <em>of one religion.</em> <span class="auth">(Zj, T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OumBapN_B2">
					<p><em>A nation; a people; a race; a tribe, distinct body,</em> or <em>family;</em> <span class="auth">(Lth, T, M, Ḳ;)</span> of mankind; <span class="auth">(Lth, T;)</span> or of any living beings; as also<span class="arrow"><span class="ar">أُمٌّ↓</span></span>: <span class="auth">(M, Ḳ:)</span> <em>a collective body</em> <span class="add">[of men or other living beings]</span>; <span class="auth">(T, Ṣ;)</span> a sing. word with a pl. meaning: <span class="auth">(Akh, Ṣ:)</span> <em>a kind, genus,</em> or <em>generical class,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> <em>by itself,</em> <span class="auth">(T,)</span> of any animals, or living beings, <span class="auth">(T, Ṣ, M, TA,)</span> others than the sons of Adam, <span class="auth">(T,)</span> as of dogs, <span class="auth">(T, Ṣ, M,)</span> and of other beasts, and of birds; <span class="auth">(T, M,* TA;)</span> as also<span class="arrow"><span class="ar">أُمٌّ↓</span></span>; <span class="auth">(M, Ḳ;)</span> pl. of the former <span class="ar">أُمَمٌ</span>; <span class="auth">(Ṣ, M;)</span> which occurs in a trad. as relating to dogs; <span class="auth">(Ṣ;)</span> and in the Ḳur vi. 38, as relating to beasts and birds. <span class="auth">(T, M,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OumBapN_B3">
					<p>A man's <em>people, community, tribe, kinsfolk,</em> or <em>party;</em> <span class="auth">(M, Ḳ, TA;)</span> his <em>company.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="OumBapN_B4">
					<p><em>A generation of men;</em> or <em>people of one time:</em> pl. <span class="ar">أُمَمٌ</span>: as in the saying, <span class="ar long">قَدْ مَضَتْ أُمَمٌ</span> <em>Generations of men have passed away.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="OumBapN_B5">
					<p>The <em>creatures</em> of God. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">مَا رَأَيْتُ مِنْ أُمَّةِ ٱللّٰهِ أَحْسَنَ مِنْهُ</span> <span class="add">[<em>I have not seen, of the creatures of God, one more beautiful than he</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OumBapN_C1">
					<p><em>I. q.</em> <span class="ar">إِمَامٌ</span>; <span class="auth">(T, M, Ḳ;)</span> accord. to AʼObeyd, applied in this sense to Abraham, in the Ḳur xvi. 121. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="OumBapN_C2">
					<p><em>A righteous man who is an object of imitation.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="OumBapN_C3">
					<p><em>One who follows the true religion, holding,</em> or <em>doing, what is different from,</em> or <em>contrary to, all other religions:</em> <span class="auth">(M, Ḳ:)</span> <span class="add">[said to be]</span> thus applied to Abraham, ubi suprà. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C4</span>
				</div>
				<div class="sense" id="OumBapN_C4">
					<p><em>One who is known for goodness:</em> <span class="auth">(Fr, T:)</span> and so explained by Ibn-Mesʼood as applied to Abraham: <span class="auth">(TA:)</span> or, so applied, it has the signification next following: <span class="auth">(TA:)</span> <em>a man combining all kinds of good qualities:</em> <span class="auth">(T, M, Ḳ:)</span> or, as some say, <em>repaired to:</em> or <em>imitated.</em> <span class="auth">(Bḍ:)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C5</span>
				</div>
				<div class="sense" id="OumBapN_C5">
					<p><em>A learned man:</em> <span class="auth">(T, M, Ḳ:)</span> <em>one who has no equal:</em> <span class="auth">(T:)</span> the <em>learned man of his age,</em> or <em>time, who is singular in his learning:</em> <span class="auth">(Mṣb:)</span> and <em>one who is alone in respect of religion.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="OumBapN_D1">
					<p><a href="#OumBN">See also <span class="ar">إُمٌّ</span></a>, first sentence. Hence, <span class="ar">يَاأُمَّتِ</span> which see in the same paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="OumBapN_E1">
					<p>The <em>stature of a man; tallness, and beauty of stature;</em> or <em>justness of stature;</em> syn. <span class="ar">قَامَةٌ</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> and <span class="ar">شَطَاطً</span>: <span class="auth">(M, TA: <span class="add">[in the Ḳ, the signification of <span class="ar">نَشَاطٌ</span> is assigned to it; but this is evidently a mistake for <span class="ar">شَطَاطٍ</span>; for the next three significations before the former of these words in the Ḳ are the same as the next three before the latter of them in the M; and the next five after the former word in the Ḳ are the same as the next five after the latter in the M, with only this difference, that one of these five is the first of them in the M and the third of them in the Ḳ:]</span>)</span> pl. <span class="ar">أُمَمٌ</span>. <span class="auth">(T, Ṣ, M.*)</span> You say, <span class="ar long">إِنَّهُ لَحَسَنُ الأُمَّةِ</span>, i. e. <span class="ar">الشَّطَاطِ</span> <span class="add">[<em>Verily he is beautiful in justness of stature</em>]</span>. <span class="auth">(M.)</span> And El-Aạshà says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حِسَانُ الوُجُوهِ طِوَالُ الأُمَمْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Beautiful in respect of the faces,</em>]</span> <em>tall in respect of the statures.</em> <span class="auth">(T, Ṣ, M.* <span class="add">[In the last, <span class="ar long">بيضُ الوُجُوهِ</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E2</span>
				</div>
				<div class="sense" id="OumBapN_E2">
					<p>The <em>face.</em> <span class="auth">(T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E3</span>
				</div>
				<div class="sense" id="OumBapN_E3">
					<p><span class="ar long">أُمَّةُ الآوَجْهِ</span> <em>The form of the face:</em> <span class="auth">(AZ, T:)</span> or <em>the principal part thereof;</em> <span class="auth">(M, Ḳ;)</span> <em>the part thereof in which beauty is usually known to lie.</em> <span class="auth">(M)</span> You say, <span class="ar long">إِنَّهُ لَحَسَنُ أُمَّةِ الآوَجْهِ</span> <em>Verily he is beautiful in the form of the face:</em> and <span class="ar long">إِنَّهُ لآَقَبِيحُ أُمَّةِ الآوَجْهِ</span> <em>verily he is ugly in the form of the face.</em> <span class="auth">(AZ, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E4</span>
				</div>
				<div class="sense" id="OumBapN_E4">
					<p><span class="ar long">أُمَّةُ الطَّرِيقِ</span>: <a href="#OumBN">see <span class="ar">أُمٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="OumBapN_F1">
					<p><em>A time; a period of time; a while.</em> <span class="auth">(T, Ṣ, M, Ḳ.)</span> So in the Ḳur <span class="add">[xii. 45]</span>, <span class="ar long">وَادَّكَرَ بَعْدَ أُمَّةٍ</span> <span class="add">[<em>And he remembered,</em> or <em>became reminded, after a time</em>]</span>: <span class="auth">(Ṣ, M:)</span> or, <em>after a long period of time:</em> but some read<span class="arrow"><span class="ar">إِمَّةٍ↓</span></span>, i. e., after <em>favour</em> had been shown him, in his escape: and some read <span class="ar">أَمَةٍ</span>, i. e., forgetting. <span class="auth">(Bḍ.)</span> And so in the same <span class="add">[xi. 11]</span>, <span class="ar long">وَلَئِنْ أخَّرْنَا عَنْهُمُ العَذَابَ إِلآَى أُمَّةٍ مَعْدُودَة</span> <span class="add">[<em>And verily, if we kept back from them the punishment</em>]</span> <em>until a short period of time.</em> <span class="auth">(Ṣ,* Bḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimBapN">
				<h3 class="entry"><span class="ar">إِمَّةٌ</span></h3>
				<div class="sense" id="IimBapN_A1">
					<p><span class="ar">إِمَّةٌ</span>: <a href="#OumBapN">see <span class="ar">أُمَّةٌ</span></a>, in three places; first and second sentences.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IimBapN_A2">
					<p><em>I. q.</em> <span class="arrow"><span class="ar">إِمَامَةٌ↓</span></span> <span class="auth">(Ḳ)</span> <span class="add">[i. e. The <em>office of</em> <span class="ar">إِمَام</span>, q. v.: or]</span> the <em>acting as,</em> or <em>performing the office of,</em> <span class="ar">إِمَام</span>: <span class="auth">(T in explanation of <span class="ar">إِمَّةٌ</span>, and M and Mṣb in explanation of <span class="ar">إِمَامَةٌ</span>:)</span> and the <em>mode,</em> or <em>manner, of performing that office.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IimBapN_A3">
					<p><em>I. q.</em> <span class="ar">هَيْئَةٌ</span> <span class="auth">(Lḥ, M, Ḳ)</span> and <span class="ar">شَأْنٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">حَالٌ</span> <span class="auth">(M)</span> and <span class="ar">حَالَةٌ</span> <span class="auth">(M, Ḳ)</span> <span class="add">[all as meaning <em>State, condition,</em> or <em>case:</em> or by the first may be here meant <em>external state</em> or <em>condition; form,</em> or <em>appearance;</em> or <em>state with respect to apparel and the like</em>]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IimBapN_A4">
					<p><em>An easy and ample state of life;</em> <span class="auth">(T;)</span> <em>easiness,</em> or <em>pleasantness of life; ampleness of the conveniences of life, or of the means of subsistence; ease and enjoyment; plenty; prosperity; welfare.</em> <span class="auth">(IAạr, M, Ḳ.*)</span> You say of an old man when he has strength remaining, <span class="ar long">فُلَانٌ بِإِمَّةٍ</span>, meaning <em>Such a one is returning to a state of well-being and ease and enjoyment.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IimBapN_A5">
					<p><em>Dominion; mastership; authority.</em> <span class="auth">(Fr, T, IḲṭṭ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IimBapN_A6">
					<p><em>A blessing,</em> or <em>what God bestows upon one; a benefit, benefaction, favour,</em> or <em>boon; a cause of happiness;</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> as being that which men aim at, pursue, or endeavour to obtain, <span class="auth">(T.)</span> <a href="#OumBapN">See <span class="ar">أُمَّةٌ</span></a>, last sentence but one.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IimBapN_B1">
					<p>Accord. to IḲṭṭ, it signifies also <em>i. q.</em> <span class="ar">أَمَمٌ</span> <span class="add">[but in what sense is not said]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamamN">
				<h3 class="entry"><span class="ar">أَمَمٌ</span></h3>
				<div class="sense" id="OamamN_A1">
					<p><span class="ar">أَمَمٌ</span> <em>Nearness.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamamN_A2">
					<p><span class="add">[<em>Near; nigh.</em>]</span> You say, <span class="ar long">أَخَذْتُ ذلِكَ مِنْ أَمَمٍ</span> <em>I took that from near; from nigh.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">دَارُكُمْ أَمَمٌ</span> <em>Your house is near,</em> or <em>nigh.</em> <span class="auth">(M, TA.)</span> And <span class="ar long">هُوَ أَمَمٌ مِنْكَ</span> <em>He,</em> or <em>it, is near to thee:</em> and in like manner you say of two: <span class="auth">(M, TA:)</span> and of a pl. number. <span class="auth">(Ṣ, M, TA.)</span> <span class="pb" id="Page_0091"></span>And <span class="ar long">دَارِى أَمَمَ دَارِهِ</span> <em>My house is opposite to, facing,</em> or <em>in front of, his house.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamamN_A3">
					<p><em>Easy:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> <em>near at hand; near to be reached,</em> or <em>laid hold of.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OamamN_A4">
					<p><em>Between near and distant.</em> <span class="auth">(ISk, T, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OamamN_A5">
					<p><em>Conforming,</em> or <em>conformable, to the just mean:</em> <span class="auth">(M, Ḳ:*)</span> and<span class="arrow"><span class="ar">مُؤَامٌّ↓</span></span>, <span class="auth">(AA, T, Ṣ, M, Ḳ,)</span> <span class="add">[in form]</span> like <span class="ar">مُضَارٌّ</span>, <span class="auth">(Ṣ,)</span> originally <span class="ar">مُؤَامِمٌ</span>, <span class="auth">(TA,)</span> <em>the same;</em> <span class="auth">(T;)</span> <em>of a middle,</em> or <em>middling, kind </em> or <em>sort; neither exceeding, nor falling short of, what is right;</em> <span class="auth">(AA, T, Ṣ, M;)</span> applied to an affair, or a case, <span class="auth">(T, Ṣ,)</span> and a thing <span class="add">[of any kind]</span>; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">مُؤَمٌّ↓</span></span>; <span class="auth">(TA;)</span> and <em>convenient,</em> or <em>suitable:</em> <span class="auth">(M, Ḳ:)</span> and <span class="ar">أَمَمٌ</span> and<span class="arrow"><span class="ar">مُؤَامٌّ↓</span></span> both signify an affair, or a case, that is <em>manifest, clear,</em> or <em>plain,</em> <span class="auth">(M, Ḳ,)</span> <em>not exceeding the due bounds</em> or <em>limits.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlOamaAmu">
				<h3 class="entry"><span class="ar">الأَمَامُ</span></h3>
				<div class="sense" id="AlOamaAmu_A1">
					<p><span class="ar">الأَمَامُ</span> <em>The location that is before;</em> <span class="auth">(M, Mṣb,* Ḳ;)</span> <em>contr. of</em> <span class="ar">الوَرَآءُ</span>. <span class="auth">(M, Ḳ.)</span> It is used <span class="add">[absolutely]</span> as a noun, and adverbially, <span class="auth">(M, Mṣb,* Ḳ,)</span> necessarily prefixed to another noun: <span class="auth">(Mgh:)</span> and is fem., <span class="auth">(Ks, M,)</span> and sometimes masc.: <span class="auth">(M, Ḳ:)</span> or it is masc., and sometimes fem. as meaning the <span class="ar">جِهَة</span>: or, as Zj says, they differ as to making it masc. and making it fem. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">كُنْتُ أَمَامَهُ</span> <em>I was before him, in respect of place.</em> <span class="auth">(Ṣ.)</span> In the saying of Moḥammad, to Usámeh, <span class="ar long">الصلَاةُ أَمَامَكَ</span>, the meaning is <em>The time of prayer</em> <span class="add">[<em>is before thee</em>]</span>, or <em>the place thereof;</em> and by the prayer is meant the prayer of sunset. <span class="auth">(Mgh.)</span> You also say, <span class="ar">أَمَامَكَ</span> <span class="add">[i. c. Look <em>before thee;</em> meaning <em>beware thou;</em> or <em>take thou note;</em>]</span> when you caution another, <span class="auth">(M, Ḳ,)</span> or notify him, of a thing. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IimaAmN">
				<h3 class="entry"><span class="ar">إِمَامٌ</span> / <span class="ar">إِمَامَةٌ</span></h3>
				<div class="sense" id="IimaAmN_A1">
					<p><span class="ar">إِمَامٌ</span> <em>A person,</em> <span class="auth">(Ṣ, Mgh,)</span> or <em>learned man,</em> <span class="auth">(Mṣb,)</span> <em>whose example is followed,</em> or <em>who is imitated;</em> <span class="auth">(Ṣ, Mgh, Mṣb;)</span> <em>any exemplar,</em> or <em>object of imitation,</em> <span class="auth">(T, M, Ḳ,)</span> <em>to a people,</em> or <em>company of men,</em> <span class="auth">(T,)</span> <em>such as a head, chief,</em> or <em>leader,</em> or <em>some other person,</em> <span class="auth">(M, Ḳ,)</span> <em>whether they be following the right way or be erring therefrom:</em> <span class="auth">(T:)</span> applied alike to a male and to a female: <span class="auth">(Mgh, Mṣb:)</span> applied to a female, it occurs in a phrase in which it is written by some with <span class="ar">ة</span>: <span class="auth">(Mgh:)</span> but this is said to be a mistake: <span class="auth">(Mṣb:)</span> it is correctly without <span class="ar">ة</span>, because it is a subst., not an epithet: <span class="auth">(Mgh, Mṣb:)</span> or it is allowable with <span class="ar">ة</span>, because it implies the meaning of an epithet: <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">أُمَّةٌ↓</span></span> signifies the same: <span class="auth">(T, M, Ḳ:)</span> the pl. of the former is <span class="ar">أَيِمَّةْ</span>, <span class="auth">(T, Ṣ, M, Ḳ, <span class="add">[but omitted in the CK,]</span>)</span> originally <span class="ar">أَأْمِمَةٌ</span>, <span class="auth">(T, Ṣ,)</span> of the measure <span class="ar">أَفعِلَةٌ</span>, like <span class="ar">أَمْثِلَةٌ</span>, <a href="#mivaAlN">pl. of <span class="ar">مِثَالٌ</span></a>, <span class="auth">(T,)</span> but as two meems come together, the former is incorporated into the latter, and its vowel is transferred to the hemzeh before it, which hemzeh, being thus pronounced with kesr, is changed into <span class="ar">ى</span>; <span class="auth">(T, Ṣ;*)</span> or it is thus changed because difficult to pronounce; <span class="auth">(M;)</span> or, as Akh says, because it is with kesr and is preceded by another hemzeh with fet-ḥ: <span class="auth">(Ṣ:)</span> but some pronounce it <span class="ar">أَئِمَّةٌ</span>, <span class="auth">(Akh, T, Ṣ, M, Ḳ,)</span> namely, those who hold that two hemzehs may occur together; <span class="auth">(Akh, Ṣ;)</span> the Koofees reading it thus in the Ḳur ix. 12; <span class="auth">(M;)</span> but this is anomalous: <span class="auth">(M, Ḳ:)</span> it is mentioned as on the authority of Aboo-Is-ḥáḳ, and <span class="add">[Az says,]</span> I do not say that it is not allowable, but the former is the preferable: <span class="auth">(T:)</span> or the pl. is <span class="ar">أَئِمَّةٌ</span>, originally <span class="ar">أَأْمِمَةٌ</span> like <span class="ar">أَمْثِلَةٌ</span>: one of the two meems being incorporated into the other after the transfer of its vowel to the hemzeh <span class="add">[next before it]</span>; some of the readers of the Ḳur pronouncing the <span class="add">[said]</span> hemzeh with its true sound; some softening it, agreeably with analogy, in the manner termed <span class="ar long">بَيْنَ بَيْنَ</span>; and some of the grammarians changing it into <span class="ar">ى</span>; but some of them reckon this incorrect, saying that there is no analogical reason for it: <span class="auth">(Mṣb:)</span> and accord. to some, <span class="auth">(M,)</span> its pl. is also <span class="ar">إِمَامُ</span>, <span class="auth">(M, Ḳ,)</span> like the sing., <span class="auth">(Ḳ,)</span> occurring in the Ḳur xxv. 74; <span class="auth">(M;)</span> not of the same category as <span class="ar">عَدْلٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">رِضَّى</span>, <span class="auth">(M,)</span> because they sometimes said <span class="ar">إِمَامَانِ</span>, but a broken pl.: <span class="auth">(M, Ḳ:*)</span> or, accord. to AʼObeyd, it is in this instance a sing. denoting a pl.: <span class="auth">(M, Ṣ:*)</span> or it <a href="#AmBN">is pl. of <span class="ar">آمٌّ</span></a>, <span class="add">[which is originally <span class="ar">آمِمْ</span>,]</span> like as <span class="ar">صِحَابٌ</span> <a href="#SaAHibN">is pl. of <span class="ar">صَاحِبٌ</span></a>: <span class="auth">(M:)</span> <a href="#OayimBapN">the dim. of <span class="ar">أَيِمَّةٌ</span></a> is <span class="arrow"><span class="ar">أُوَيْمَّةْ↓</span></span>; or, as El-Mázinee says, <span class="arrow"><span class="ar">أُيَيْمَّةٌ↓</span></span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IimaAmN_A2">
					<p><span class="ar">الإمَامُ</span> also signifies <em>The Prophet:</em> <span class="auth">(Ḳ:)</span> he is called <span class="ar">إِمَامُ</span> <span class="add">[<em>the exemplar, object of imitation, leader,</em> or <em>head, of his nation,</em> or <em>people</em>]</span>; <span class="auth">(T;)</span> or <span class="ar long">إِمَامُ الأمَّةِ</span> <span class="add">[<em>the exemplar,</em>, &amp;c., <em>of the nation,</em> or <em>people</em>]</span>; <span class="auth">(M;)</span> it being incumbent on all to imitate his rule of life or conduct. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IimaAmN_A3">
					<p><em>The Khaleefeh:</em> <span class="auth">(Mṣb, Ḳ:)</span> he is called <span class="ar long">إمَامُ الرَّعِيَّةِ</span> <span class="add">[<em>the exemplar,</em>, &amp;c., <em>of the people,</em> or <em>subjects</em>]</span>. <span class="auth">(M.)</span> The title of <span class="ar">الإمَامُ</span> is still applied to the Kings of El-Yemen: Aboo-Bekr says, you say, <span class="ar long">فُلَانٌ إِمَامُ القَوْمِ</span>, meaning <em>such a one is the first in authority over the people,</em> or <em>company of men:</em> and <span class="ar long">إِمَامُ المَسْلِمِينَ</span> means <em>the head, chief,</em> or <em>leader, of the Muslims.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IimaAmN_A4">
					<p><em>The person whose example is followed,</em> or <em>who is imitated,</em> <span class="add">[i. e. <em>the leader,</em>]</span> <em>in prayer.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IimaAmN_A5">
					<p><span class="add">[<em>The leading authority</em>, or <em>head, of a persuasion,</em> or <em>sect.</em> The four <span class="ar">أيِمَّة</span> or <span class="ar">أَئِمَّة</span> are the heads of the four principal persuasions, or sects, of the Sunnees; namely, the Hanafees, Sháfi'ees, Málikees, and Hambelees. And the Hanafees call the two chief doctors of their persuasion, after Aboo-Ḥaneefeh, namely, Aboo-Yoosuf and Moḥammad, <span class="ar">الإِمَامَانِ</span> <em>The two Imáms.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IimaAmN_A6">
					<p><em>The leader</em> of an army. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="IimaAmN_A7">
					<p><em>The guide:</em> <span class="auth">(Ḳ:)</span> he is called <span class="ar long">إِمَامُ الإِبِلِ</span> <span class="add">[<em>the leader of the travellers</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="IimaAmN_A8">
					<p><em>The conductor,</em> or <em>driver, of camels</em> <span class="auth">(M, Ḳ)</span> is called <span class="ar long">إِمَامُ الإِبِلِ</span>, though he be behind them, because he guides them. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="IimaAmN_A9">
					<p><em>The manager,</em> or <em>conductor,</em> and <em>right disposer, orderer,</em> or <em>rectifier,</em> of anything. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="IimaAmN_A10">
					<p><em>The Ḳur-án</em> <span class="auth">(M, Ḳ)</span> is called <span class="ar long">إِمَامُ المُسْلِمينَ</span> <span class="add">[<em>the guide of the Muslims</em>]</span>; <span class="auth">(M;)</span> because it is an exemplar. <span class="auth">(TA.)</span> <span class="add">[<em>The model-copy,</em> or <em>standard-copy, of the Ḳur-án,</em> namely the copy of the Khaleefeh ʼOthmán, is particularly called <span class="ar">الإِمَامُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="IimaAmN_A11">
					<p><span class="add">[<em>The scripture</em> of any people: and, without the article, <em>a book,</em> or <em>written record.</em>]</span> It is said in the Ḳur <span class="add">[xvii. 73]</span>, <span class="ar long">يَوْمَ نَدْعُو كُلَّ أُنَاسٍ بِإمَامِهِمْ</span> <em>The day when we shall call every one of mankind with their scripture:</em> or, as some say, <em>with their prophet and their law:</em> or, as some say, <em>with their book in which their deeds are recorded.</em> <span class="auth">(T.)</span> It is also said in the Ḳur <span class="add">[xxxvi. 11]</span>, <span class="ar long">كُلَّ شَيْءٍ أَحْصَيْنَاهُ فِى إِمَامٍ مُبِينٍ</span>, meaning, says El-Ḥasan, <span class="add">[<em>And everything have we recorded</em>]</span> <em>in a perspicuous book,</em> or <em>writing;</em> <span class="auth">(Ṣ, Jel;)</span> i. e., <em>on the Preserved Tablet.</em> <span class="auth">(Bḍ, Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="IimaAmN_A12">
					<p><em>The lesson</em> of a boy, <em>that is learned each day</em> <span class="auth">(T, M, Ḳ)</span> <em>in the school:</em> <span class="auth">(T:)</span> also called <span class="ar">السَّبَقُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="IimaAmN_A13">
					<p><em>The model,</em> or <em>pattern,</em> of a semblance, or shape. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="IimaAmN_A14">
					<p><em>The builder's wooden instrument</em> <span class="add">[or <em>rule</em>]</span> <em>whereby he makes the building even.</em> <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="IimaAmN_A15">
					<p><em>The cord which the builder extends to make even, thereby, the row of stones or bricks of the building;</em> also called <span class="ar">التُّرُّ</span> and <span class="ar">المِطْهَرُ</span>; <span class="auth">(T;)</span> <em>the string which is extended upon,</em> or <em>against, a building, and according to which one builds.</em> <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="IimaAmN_A16">
					<p><span class="ar">إِمَامٌ</span> signifies also <em>A road,</em> or <em>way:</em> <span class="auth">(Ṣ, <span class="add">[but omitted in some copies,]</span> M, Ḳ:)</span> or <em>a manifest road,</em> or <em>way.</em> <span class="auth">(TA.)</span> It is said in the Ḳur <span class="add">[xv. 79]</span>, <span class="ar long">وَإِنَّهُمَا لَبِإمَامٍ مُبِينٍ</span> <span class="auth">(Ṣ, M)</span> <em>And they were both, indeed, in a way pursued and manifest:</em> <span class="auth">(M:)</span> or <em>in a way which they travelled in their journeys.</em> <span class="auth">(Fr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A17</span>
				</div>
				<div class="sense" id="IimaAmN_A17">
					<p>The <em>direction</em> (<span class="ar">تَلْقَآء</span>) of the Kibleh. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A18</span>
				</div>
				<div class="sense" id="IimaAmN_A18">
					<p><em>A tract, quarter,</em> or <em>region, of land,</em> or <em>of the earth.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">إِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A19</span>
				</div>
				<div class="sense" id="IimaAmN_A19">
					<p><em>A string</em> <span class="add">[of a bow or lute, &amp;c.]</span>; syn. <span class="ar">وَتَرٌ</span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamiymN">
				<h3 class="entry"><span class="ar">أَمِيمٌ</span></h3>
				<div class="sense" id="OamiymN_A1">
					<p><span class="ar">أَمِيمٌ</span> <em>Beautiful in stature;</em> <span class="auth">(Ḳ;)</span> applied to a man. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمِيمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamiymN_B1">
					<p><em>I. q.</em> <span class="arrow"><span class="ar">مَأْمُومٌ↓</span></span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> i. e. one <em>who raves,</em> or <em>is delirious,</em> (<span class="ar">يَهْذِى</span>, <span class="add">[in two copies of the Ṣ <span class="ar">يَهْدِى</span>, but the former appears, from a remark made voce <span class="ar">آمَّةٌ</span>, to be the right reading,]</span>) <em>from</em> <span class="add">[<em>a wound in</em>]</span> <em>what is termed</em> <span class="ar long">أُمُّ رَأْسِهِ</span> <span class="add">[<a href="#OumBN">see <span class="ar">أُمٌّ</span></a>]</span>: <span class="auth">(Ṣ:)</span> or <em>wounded in what is so termed;</em> <span class="auth">(M, Ḳ;)</span> <em>having a wound such as is termed</em> <span class="ar">آمَّة</span>, q. v. <span class="auth">(Mṣb.)</span> It is also used, metaphorically, in relation to other parts than that named above; as in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَحَشَاىَ مِنْ حَرِّ الفِرَاقِ أَمِيمُ</span> *</div> 
					</blockquote>
					<p>‡ <span class="add">[<em>And my bowels are wounded by reason of the burning pain of separation</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمِيمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OamiymN_C1">
					<p><em>A stone with which the head is broken:</em> <span class="auth">(Ṣ, O:)</span> but in the M and Ḳ <span class="arrow"><span class="ar">أمَيْمَةٌ↓</span></span>, <span class="add">[in a copy of the M, however, I find it without any syll. signs, so that it would seem to be <span class="arrow"><span class="ar">أَمِيمَةٌ↓</span></span>,]</span> explained as signifying <em>stones with which heads are broken</em>: <span class="auth">(TA:)</span> pl. <span class="ar">أَمَائِمُ</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumaAmapN">
				<h3 class="entry"><span class="ar">أُمَامَةٌ</span></h3>
				<div class="sense" id="OumaAmapN_A1">
					<p><span class="ar">أُمَامَةٌ</span> <em>Three hundred camels:</em> <span class="auth">(M, Ḳ:)</span> so explained by Abu-l-ʼAlà. <span class="auth">(M.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IimamapN">
				<h3 class="entry"><span class="ar">إِمَمَةٌ</span></h3>
				<div class="sense" id="IimamapN_A1">
					<p><span class="ar">إِمَمَةٌ</span>: <a href="#IimBapN">see <span class="ar">إِمَّةٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamiymapN">
				<h3 class="entry"><span class="ar">أَمِيمَةٌ</span></h3>
				<div class="sense" id="OamiymapN_A1">
					<p><span class="ar">أَمِيمَةٌ</span>: <a href="#OamiymN">see <span class="ar">أَمِيمٌ</span></a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أَمِيمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamiymapN_A2">
					<p>Also, <span class="auth">(Ṣgh,)</span> or<span class="arrow"><span class="ar">أُمَيْمَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> <em>A blacksmith's hammer.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumayomapN">
				<h3 class="entry"><span class="ar">أُمَيْمَةٌ</span></h3>
				<div class="sense" id="OumayomapN_A1">
					<p><span class="ar">أُمَيْمَةٌ</span> <a href="#OumBN">dim. of <span class="ar">أُمٌّ</span>, q. v.</a> <span class="auth">(T, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَيْمَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OumayomapN_B1">
					<p><a href="#OamiymN">See also <span class="ar">أَمِيمٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمَيْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OumayomapN_B2">
					<p><a href="#OamiymapN">and <span class="ar">أَمِيمَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlIimaAmiyBapu">
				<h3 class="entry"><span class="ar">الإِمَامِيَّةُ</span></h3>
				<div class="sense" id="AlIimaAmiyBapu_A1">
					<p><span class="ar">الإِمَامِيَّةُ</span> <em>One of the exorbitant sects of the Shee'ah,</em> <span class="auth">(TA,)</span> <em>who asserted that ʼAlee was expressly appointed by Moḥammad to be his successor.</em> <span class="auth">(Esh-Shahrastánee p. 122, and KT.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumayomihapN">
				<h3 class="entry"><span class="ar">أُمَيْمِهَةٌ</span></h3>
				<div class="sense" id="OumayomihapN_A1">
					<p><span class="ar">أُمَيْمِهَةٌ</span> <span class="add">[<a href="#OumBahpN">dim. of <span class="ar">أُمَّهةٌ</span></a>]</span>: <a href="#OumBN">see <span class="ar">أُمٌّ</span></a>, first sentence.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumBieBN">
				<span class="pb" id="Page_0092"></span>
				<h3 class="entry"><span class="ar">أُمِّىٌّ</span></h3>
				<div class="sense" id="OumBieBN_A1">
					<p><span class="ar">أُمِّىٌّ</span> <span class="auth">(T, M, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أُمَّانٌ↓</span></span> <span class="auth">(Ḳ)</span> <span class="add">[the former a rel. n. from <span class="ar">أُمَّةٌ</span>, and thus properly meaning <em>Gentile:</em> whence, in a secondary, or tropical, sense,† <em>a heathen;</em>]</span> † one <em>not having a revealed scripture;</em> <span class="auth">(Bḍ in iii. 19 and 69;)</span> so applied by those having a revealed scripture: <span class="auth">(Bḍ in iii.69:)</span> <span class="add">[and particularly]</span> an <em>Arab:</em> <span class="auth">(Jel in iii. 69, and Bḍ and Jel in lxii. 2:)</span> <span class="add">[or]</span> in the proper language <span class="add">[of the Arabs]</span>, <em>of,</em> or <em>belonging to</em>, or <em>relating to, the nation</em> (<span class="ar">أُمَّة</span>) <em>of the Arabs,</em> who did not write nor read: and therefore metaphorically applied to ‡ any one <em>not knowing the art of writing nor that of reading:</em> <span class="auth">(Mgh:)</span> or † one <em>who does not write;</em> <span class="auth">(T, M, Ḳ;)</span> because the art of writing is acquired; as though he were thus called in relation to the condition in which his mother (<span class="ar">أُمَّهُ</span>) brought him forth: <span class="auth">(T:)</span> or † one <em>who is in the natural condition of the nation</em> (<span class="ar">الأُمَّة</span>) <em>to which he belongs,</em> <span class="auth">(Zj,* T, M,* Ḳ,*)</span> <em>in respect of not writing,</em> <span class="auth">(T,)</span> or <em>not having learned writing; thus remaining in his natural state:</em> <span class="auth">(M, Ḳ:)</span> or † one <em>who does not write well;</em> said to be a rel. n. from <span class="ar">أمٌّ</span>; because the art of writing is acquired, and such a person is as his mother brought him forth, in respect of ignorance of that art; or, as some say, from <span class="ar long">أُمَّةُ العَرَبِ</span>; because most of the Arabs were of this description: <span class="auth">(Mṣb:)</span> the art of writing was known among the Arabs <span class="add">[in the time of Moḥammad]</span> by the people of Et-Táïf, who learned it from a man of the people of El-Heereh, and these had it from the people of El-Ambár. <span class="auth">(T.)</span> <span class="ar long">أُمِّيُّون لَا يَعْلَمُونَ الكِتَابَ</span>, in the Ḳur ii. 73, means <em>Vulgar persons,</em> <span class="add">[or <em>heathen,</em>]</span> <em>who know not the Book of the Law revealed to Moses:</em> <span class="auth">(Jel:)</span> or <em>ignorant persons, who know not writing,</em> so that they may read that book; or, <em>who know not the Book of the Law revealed to Moses.</em> <span class="auth">(Bḍ.)</span> Moḥammad was termed <span class="ar">أُمِّىّ</span> <span class="add">[meaning <em>A Gentile,</em> as distinguished from an Israelite: or, accord. to most of his followers, meaning <em>illiterate;</em>]</span> because the nation (<span class="ar">أُمَّة</span>) of the Arabs did not write, nor read writing; and <span class="add">[they say that]</span> God sent him as an apostle when he did not write, nor read from a book; and this natural condition of his was one of his miraculous signs, to which reference is made in the Ḳur <span class="add">[xxix. 47]</span>, where it is said, “thou didst not read, before it, from a book, nor didst thou write it with thy right hand:” <span class="auth">(T, TA:)</span> but accord. to the more correct opinion, he was not well acquainted with written characters nor with poetry, but he discriminated between good and bad poetry: or, as some assert, he became acquainted with writing after he had been unacquainted therewith, on account of the expression “before it” in the verse of the Ḳur mentioned above: or, as some say, this may mean that he wrote though ignorant of the art of writing, like as some of the kings, being <span class="ar">أُمِّيُّون</span>, write their signs, or marks: <span class="auth">(TA:)</span> or, accord. to Jaạfar Es-Sádik, he used to read from the book, or scripture, if he did not write. <span class="auth">(Kull p. 73.)</span> <span class="add">[Some judicious observations on this word are comprised in Dr. Sprenger's Life of Moḥammad <span class="auth">(pp. 101-2)</span>; a work which, in the portion already published <span class="auth">(Part I.)</span>, contains much very valuable information.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">أُمِّىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OumBieBN_A2">
					<p>Also, <span class="auth">(Ḳ,)</span> or <span class="add">[only]</span> <span class="ar">أُمِّىٌّ</span>, <span class="auth">(AZ, T, M,)</span> applied to a man, <span class="auth">(AZ, T,)</span> <em>Impotent in speech,</em> (<span class="ar">عَيِىّ</span>, in the Ḳ incorrectly written <span class="ar">غَبِىّ</span>, TA,) <em>of few words, and rude, churlish, uncivil,</em> or <em>surly.</em> <span class="auth">(AZ, T, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumBiyBapN">
				<h3 class="entry"><span class="ar">أُمِّيَّةٌ</span></h3>
				<div class="sense" id="OumBiyBapN_A1">
					<p><span class="ar">أُمِّيَّةٌ</span> The <em>quality denoted by the epithet</em> <span class="ar">أُمِّىٌّ</span>: <span class="auth">(TA:)</span> <span class="add">[<em>gentilism: † heathenism:</em>, &amp;c.:]</span> † the <em>quality of being</em> <span class="add">[<em>in the natural condition of the nation to which one belongs,</em> or]</span> <em>as brought forth by one's mother, in respect of not having learned the art of writing nor the reading thereof.</em> <span class="auth">(Kull p. 73.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OumBaAnN">
				<h3 class="entry"><span class="ar">أُمَّانٌ</span></h3>
				<div class="sense" id="OumBaAnN_A1">
					<p><span class="ar">أُمَّانٌ</span>: <a href="#Oum~ieBN">see <span class="ar">أُمِّىٌّ</span></a>: <a href="index.php?data=01_A/135_Amn">and see also art. <span class="ar">امن</span></a>:</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OumBahapN">
				<h3 class="entry"><span class="ar">أُمَّهَةٌ</span></h3>
				<div class="sense" id="OumBahapN_A1">
					<p><span class="ar">أُمَّهَةٌ</span>: <a href="#OumBN">see <span class="ar">أُمٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MmBN">
				<h3 class="entry"><span class="ar">آمٌّ</span></h3>
				<div class="sense" id="MmBN_A1">
					<p><span class="ar">آمٌّ</span> <span class="add">[act. part. n. of 1;]</span> <em>i. q.</em> <span class="ar">قَاصِدٌ</span>: <span class="add">[<a href="#Am_1">see 1</a>, first sentence:]</span> <span class="auth">(TA:)</span> pl. <span class="ar">إِمَامٌ</span>, like as <span class="ar">صِحَابٌّ</span> <a href="#SaAHibN">is pl. of <span class="ar">صَاحِبٌ</span></a>, <span class="auth">(M, Ḳ,)</span> accord. to some, but others say that this <a href="#IimaAmN">is pl. of <span class="ar">إِمَامٌ</span></a> <span class="add">[q. v.; the sing. and pl. being alike]</span>; <span class="auth">(M;)</span> and <span class="ar">آمُّونَ</span>. <span class="auth">(TA.)</span> Hence, in the Ḳur <span class="add">[v. 2]</span>, <span class="ar long">وَلَا آمِّينَ الْبَيْتَ الْحَرَامَ</span> <span class="add">[<em>Nor those repairing to the Sacred House</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MmBapN">
				<h3 class="entry"><span class="ar">آمَّةٌ</span></h3>
				<div class="sense" id="MmBapN_A1">
					<p><span class="ar">آمَّةٌ</span> <span class="auth">(Ṣ, Mṣb)</span> and<span class="arrow"><span class="ar">مَأْمُومَةٌ↓</span></span>, as some of the Arabs say, <span class="auth">(IB, Mṣb,)</span> because it implies the meaning of a pass. part. n., originally; <span class="auth">(Mṣb;)</span> but ʼAlee Ibn-Hamzeh says that this is a mistake; for the latter word is an epithet applied to the part called <span class="ar long">أُمُّ الدِّمَاغِ</span> when it is broken; <span class="auth">(IB;)</span> or <span class="ar long">شَجَّةٌ آمَّةٌ</span> and<span class="arrow"><span class="ar">مَأْمُومَةٌ↓</span></span>; <span class="auth">(M, Mgh, Ḳ;)</span> <em>A wound by which the head is broken,</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>reaching to the part called</em> <span class="ar long">أُمُّ الدِّمَاغِ</span>, <span class="auth">(Ṣ, Mṣb,)</span> or, <span class="add">[which means the same,]</span> <span class="ar long">أُمُّ الرَّأْسِ</span>, <span class="auth">(M, Ḳ,)</span> <em>so that there remains between it and the brain</em> <span class="add">[<em>only</em>]</span> <em>a thin skin:</em> <span class="auth">(Ṣ:)</span> it is the most severe of <span class="ar">شِجَاج</span> <span class="add">[except that which reaches the brain (<a href="#XajBapN">see <span class="ar">شَجَّةٌ</span></a>)]</span>: ISk says that the person suffering from it roars, or bellows, (<span class="ar">يَصْعَقُ</span>,) like thunder, and like the braying of camels, and is unable to go forth into the sun: <span class="auth">(Mṣb:)</span> the mulct for it is one third of the whole price of blood: <span class="auth">(TA:)</span> IAạr assigns the meaning of <span class="add">[this kind of]</span> <span class="ar">شَجَّة</span> to <span class="arrow"><span class="ar">أَمَّةٌ↓</span></span>; which seems, therefore, to be either a dial. var. or a contraction of <span class="ar">آمَّةٌ</span>: <span class="auth">(Mṣb:)</span> <a href="#AmBapN">the pl. of <span class="ar">آمَّةٌ</span></a> is <span class="ar">أَوَامُّ</span> <span class="auth">(Mgh, Mṣb)</span> and<span class="arrow"><span class="ar">مآئِمُ↓</span></span>; or this latter has no proper sing.: <span class="auth">(M, TA:)</span> the pl. of<span class="arrow"><span class="ar">مأْمُومَةٌ↓</span></span> is <span class="ar">مَأْمُومَاتٌ</span>. <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawamBu">
				<h3 class="entry"><span class="ar">أَوَمُّ</span> / <span class="ar">أَيَمُّ</span></h3>
				<div class="sense" id="OawamBu_A1">
					<p><span class="ar">أَوَمُّ</span> and <span class="ar">أَيَمُّ</span> <em>Better in the performance of the office termed</em> <span class="ar">إِمَامَةٌ</span>; followed by <span class="ar">مِنْ</span>: <span class="auth">(Zj, T, M, Ḳ:)</span> originally <span class="ar">أَأَمُّ</span>: the second hemzeh being changed by some into <span class="ar">و</span> and by some <em>into</em> <span class="ar">ى</span>. <span class="auth">(Zj, T, M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuwayomBapN">
				<h3 class="entry"><span class="ar">أُوَيْمَّةٌ</span> / <span class="ar">أُيَيْمَّةٌ</span></h3>
				<div class="sense" id="OuwayomBapN_A1">
					<p><span class="ar">أُوَيْمَّةٌ</span>, or <span class="ar">أُيَيْمَّةٌ</span>, <a href="#OayimBapN">dim. of <span class="ar">أَيِمَّةٌ</span></a>, <a href="#IimaAmN">pl. of <span class="ar">إِمَامٌ</span>, q. v.</a> <span class="auth">(Ṣ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWamBN">
				<h3 class="entry"><span class="ar">مُؤَمٌّ</span></h3>
				<div class="sense" id="muWamBN_A1">
					<p><span class="ar">مُؤَمٌّ</span>: <a href="#OamamN">see <span class="ar">أَمَمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYamBN">
				<h3 class="entry"><span class="ar">مِئَمٌّ</span> / <span class="ar">مِئَمَّةٌ</span></h3>
				<div class="sense" id="miYamBN_A1">
					<p><span class="ar">مِئَمٌّ</span> A camel <em>that leads and guides:</em> <span class="auth">(M:)</span> or <em>a guide that shows the right way:</em> and a camel <em>that goes before the other camels:</em> <span class="auth">(Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مِئَمَّةٌ</span>}</span></add>; <span class="auth">(M, Ḳ;)</span> applied to a she-camel <span class="auth">(M, TA)</span> <em>that goes before the other she-camels, and is followed by them.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mOomuwmN">
				<h3 class="entry"><span class="ar">مأْمُومٌ</span></h3>
				<div class="sense" id="mOomuwmN_A1">
					<p><span class="ar">مأْمُومٌ</span>: <a href="#OamiymN">see <span class="ar">أَمِيمٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">مأْمُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mOomuwmN_A2">
					<p>Also A camel <em>having his hump bruised internally by his being much ridden,</em> or <em>having his hump swollen in consequence of the galling of the saddle and the cloth beneath it, and bruised, and having his hump corroded:</em> <span class="auth">(Ṣ:)</span> or <em>whose fur has gone from his back in consequence of beating,</em> or <em>of galls,</em> or <em>sores, produced by the saddle or the like.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">مأْمُومٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mOomuwmN_A3">
					<p><span class="ar">مأْمُومَةٌ</span>: <a href="#AmBapN">see <span class="ar">آمَّةٌ</span></a>, in three places.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaAmBN">
				<h3 class="entry"><span class="ar">مُؤَامٌّ</span></h3>
				<div class="sense" id="muWaAmBN_A1">
					<p><span class="ar">مُؤَامٌّ</span>: <a href="#OamamN">see <span class="ar">أَمَمٌ</span></a>, in two places.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWotamBN">
				<h3 class="entry"><span class="ar">مُؤْتَمٌّ</span></h3>
				<div class="sense" id="muWotamBN_A1">
					<p><span class="ar">مُؤْتَمٌّ</span> act. part. n. of <span class="ar long">ائْتَمَّ بِهِ</span>; <em>Following as an example; imitating; taking as an example, an exemplar, a pattern,</em> or <em>an object of imitation.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ام</span> - Entry: <span class="ar">مُؤْتَمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWotamBN_A2">
					<p><span class="ar long">مُؤْتَمٌّ بِهِ</span> pass. part. n. of the same; <em>Followed as an example; imitated;</em>, &amp;c.: thus distinguished from the former by the preposition with the object of its government. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maMYimu">
				<h3 class="entry"><span class="ar">مَآئِمُ</span></h3>
				<div class="sense" id="maMYimu_A1">
					<p><span class="ar">مَآئِمُ</span>: <a href="#AmBapN">see <span class="ar">آمَّةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0088.pdf" target="pdf">
							<span>Lanes Lexicon Page 88</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0089.pdf" target="pdf">
							<span>Lanes Lexicon Page 89</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0090.pdf" target="pdf">
							<span>Lanes Lexicon Page 90</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0091.pdf" target="pdf">
							<span>Lanes Lexicon Page 91</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0092.pdf" target="pdf">
							<span>Lanes Lexicon Page 92</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
