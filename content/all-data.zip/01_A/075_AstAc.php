<article class="root" id="Root_AstAc">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/074_Ast">است</a></span>
				<span class="ar">استاذ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/076_Astbrq">استبرق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OusotaAcN">
				<h3 class="entry"><span class="ar">أُسْتَاذٌ</span></h3>
				<div class="sense" id="OusotaAcN_A1">
					<p><span class="ar">أُسْتَاذٌ</span> a foreign word, pronounced to be such because <span class="ar">س</span> and <span class="ar">ذ</span> do not occur in any one Arabic word, <span class="auth">(Mṣb,)</span> not found in the poetry of the pagan times, <span class="auth">(Ibn-Diḥyeh in TA art. <span class="ar">ستذ</span>,)</span> nor in the language of those times, <span class="auth">(Shifá el-Ghaleel, ibid.,)</span> <span class="add">[arabicized from the Persian <span class="ar">أُسْتَادْ</span>,]</span> <em>A master:</em> <span class="auth">(MF:)</span> <em>a skilful man, who is held in high estimation:</em> <span class="auth">(Mṣb:)</span> <em>a preceptor; a tutor; a teacher: a craftmaster:</em> <span class="auth">(Ibn-Diḥyeh; and Golius on the authority of Meyd:)</span> <span class="add">[and so in the present day; as also <span class="ar">أُسْتَا</span> and <span class="ar">أُسْطَا</span>:]</span> also applied by the vulgar to <em>a eunuch;</em> because he generally tutors children: <span class="auth">(Shifá el-Ghaleel, and Ibn-Diḥyeh:)</span> pl. <span class="ar">أُسْتَاذُونَ</span> <span class="auth">(Ḥar p. 377)</span> <span class="add">[and <span class="ar">أَسَاتِيذُ</span> and <span class="ar">أَسَاتِذَةٌ</span>; and vulgarly, in the present day, <span class="ar">أُسْتَوَاتٌ</span> and <span class="ar">أُسْطَوَاتٌ</span>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
