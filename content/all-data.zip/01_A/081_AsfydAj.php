<article class="root" id="Root_AsfydAj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/080_Asf">اسف</a></span>
				<span class="ar">اسفيداج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/082_Ask">اسك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IisofiydaAjN">
				<h3 class="entry"><span class="ar">إِسْفِيدَاجٌ</span></h3>
				<div class="sense" id="IisofiydaAjN_A1">
					<p><span class="ar">إِسْفِيدَاجٌ</span> <span class="add">[<em>Ceruse; or white lead;</em>]</span> <em>ashes of lead</em> (<span class="ar long">رَمَادُ الرَّصَاصِ والآنُكِ</span>, Ḳ, which last word is as though it were added to explain that immediately preceding, TA): when subjected to a fierce heat, it becomes what is termed <span class="ar">إِسْرَنْجٌ</span>: <span class="add">[so in the CK: more probably <span class="ar">إِسْرِنْجٌ</span>:]</span> it has clearing and mitigating properties, <span class="auth">(Ḳ,)</span> and other useful qualities: <span class="auth">(TA:)</span> an arabicized word <span class="add">[from the Persian <span class="ar">اسفيداج</span> isfédáj]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0059.pdf" target="pdf">
							<span>Lanes Lexicon Page 59</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
