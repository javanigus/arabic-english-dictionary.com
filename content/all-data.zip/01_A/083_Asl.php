<article class="root" id="Root_Asl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/082_Ask">اسك</a></span>
				<span class="ar">اسل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/084_Asm">اسم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Osl">
				<h3 class="entry">1. ⇒ <span class="ar">أسل</span></h3>
				<div class="sense" id="Osl_A1">
					<p><span class="ar">أَسُلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْسُلُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَسَالَةٌ</span>, <span class="auth">(Ṣ, M, IAth,)</span> <em>It was smooth and even:</em> <span class="auth">(M:)</span> <em>it</em> <span class="auth">(anything)</span> <em>was lank:</em> <span class="auth">(Ṣ:)</span> <em>it</em> <span class="auth">(a cheek, M, IAth, Ḳ)</span> <em>was smooth and long:</em> <span class="auth">(M:)</span> or <em>long,</em> or <em>oblong, and not high in its ball:</em> <span class="auth">(IAth:)</span> or <em>long,</em> <span class="auth">(Ḳ, TA,)</span> <em>soft in make,</em> <span class="auth">(TA,)</span> <em>and lank.</em> <span class="auth">(Ḳ, TA.)</span> <span class="ar">أَسَالَةٌ</span> in the cheek of a horse is approved, and is an indication of generous quality: you say, <span class="ar long">تُنْبِئُ أَسَالَةُ خَدِّهِ عَنْ أَصَالَةِ جَدِّهِ</span> <span class="add">[<em>The smoothness and longness,</em>, &amp;c., <em>of his cheek tells of the generous origin of his ancestor</em>]</span>. <span class="auth">(AO, Z.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أسل</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Osl_B1">
					<p><a href="#Asl_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أسّل</span></h3>
				<div class="sense" id="Asl_2_A1">
					<p><span class="ar">أسّلهُ</span> <em>He made it</em> <span class="auth">(an iron thing)</span> <em>thin.</em> <span class="auth">(TA.)</span> <span class="add">[<em>He made it</em> <span class="auth">(anything)</span> <em>sharp,</em> or <em>pointed.</em> <span class="auth">(See the pass. part. n., below.)</span>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asl_2_A2">
					<p><span class="ar long">أسّل المَطَرَ</span>, inf. n. <span class="ar">تَأْسِيلٌ</span>, <em>The rain moistened to the measure of the</em> <span class="ar">أَسَلَة</span> <span class="add">[or <em>thin part</em>]</span> <em>of the arm.</em> <span class="auth">(Ḳ.)</span> When it has moistened to the measure of the <span class="ar">عَظَمَة</span> <span class="add">[or thick part]</span> of the arm, you say of it <span class="ar">عَظَّمَ</span>, inf. n. <span class="ar">تَعْظِيمٌ</span>: one says, <span class="ar long">كَيفَ كَانَتْ مَطْرَتُكُمْ أَسَّلَتْ أَمْ عَظَّمَتْ</span> <span class="add">[<em>How was your rain? Did it moisten to the measure of the thin part of the arm, or did it moisten to the measure of the thick part thereof?</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">أسّل الثَّرَى</span>, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">أَسَلَ↓</span></span>, <span class="auth">(M, <span class="add">[so in a copy of that work, but probably a mistranscription,]</span>)</span> <em>The moisture reached to the measure of the</em> <span class="ar">أَسَلَة</span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأسّل</span></h3>
				<div class="sense" id="Asl_5_A1">
					<p><span class="ar long">تأسّل أَبَاهُ</span>, <span class="auth">(M, Ḳ,)</span> as also <span class="ar">تأسّنهُ</span>, <span class="auth">(M, TA,)</span> <em>He resembled his father,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>and assumed his natural dispositions;</em> and so <span class="ar">تَقَيَّلَهُ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#AsaAlu">See <span class="ar">آسَالُ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasalN">
				<h3 class="entry"><span class="ar">أَسَلٌ</span></h3>
				<div class="sense" id="OasalN_A1">
					<p><span class="ar">أَسَلٌ</span> <span class="add">[<em>Rush,</em> or <em>rushes:</em> so called in the present day:]</span> <em>a kind of trees:</em> <span class="auth">(Ṣ:)</span> or <span class="add">[rather]</span> <em>a kind of plant,</em> <span class="auth">(M, Mgh, TA,)</span> <em>having shoots</em> <span class="auth">(M, Mgh)</span> <em>which are slender,</em> <span class="auth">(Mgh,)</span> <em>without leaves;</em> <span class="auth">(M, Mgh;)</span> or <em>of which the shoot is slender, and of which sieves are made;</em> as is said in the A; and Ṣgh adds, <span class="add">[<em>growing</em>]</span> <em>in El-'Irák:</em> <span class="auth">(TA:)</span> AḤn says, <span class="auth">(TA,)</span> accord. to Aboo-Ziyád, <em>it is of the kind called</em> <span class="ar">أَغْلَاث</span>, <em>and comes forth in slender shoots, not having branches growing out from them, nor wood,</em> <span class="auth">(M, TA,)</span> <em>and sometimes men beat them, and make of them well-ropes and other cords,</em> <span class="auth">(TA,)</span> <em>and it seldom or never grows but in a place wherein is water, or near to water:</em> <span class="auth">(M, TA:)</span> AḤn says <span class="add">[also]</span>, it signifies <em>shoots, or twigs, growing</em> <span class="auth">(M, Ḳ)</span> <em>long and slender and straight,</em> <span class="auth">(M,)</span> <em>without leaves; of which mats are made:</em> <span class="auth">(M, Ḳ:)</span> or <span class="ar">أَسَلَةٌ</span>, <span class="auth">(Ḳ,)</span> which <a href="#OasalN">is the n. un. of <span class="ar">أَسَلٌ</span></a> applied to the plant mentioned above, <span class="auth">(M, Ḳ,)</span> signifies <em>any shoot, or twig, in which is no crookedness.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasalN_A2">
					<p>Hence, <span class="auth">(M,)</span> ‡ <em>Spears;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as being likened to the plant mentioned above, in respect of its evenness and length and straightness and the slenderness of its extremities: n. un. as above: <span class="auth">(M:)</span> and † <em>arrows, or Arabian arrows;</em> syn. <span class="ar">نَبْلٌ</span>; <span class="auth">(M, Ḳ:)</span> applied to both of these in a trad. of ʼOmar, which refutes an assertion that it is peculiarly applied to spears, or long spears, and not to <span class="ar">نبل</span>: <span class="auth">(AʼObeyd, TA:)</span> Sh says that it is applied to spears because of the points of the heads fixed upon them. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OasalN_A3">
					<p>† <em>Any thin thing of iron, such as a spear-head,</em> and <em>a sword,</em> and <em>a knife.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OasalN_A4">
					<p>‡ The <em>prickles of palm-trees:</em> <span class="auth">(M, Ḳ:)</span> n. un. as above: <span class="auth">(M:)</span> by way of comparison <span class="add">[to the plant mentioned above]</span>: <span class="auth">(TA:)</span> or <em>any long thorns,</em> or <em>prickles, of a tree.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OasalN_A5">
					<p><span class="add">[<a href="#OasalapN">See also what next follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasalapN">
				<h3 class="entry"><span class="ar">أَسَلَةٌ</span></h3>
				<div class="sense" id="OasalapN_A1">
					<p><span class="ar">أَسَلَةٌ</span> <a href="#OasalN">n. un. of <span class="ar">أَسَلٌ</span>, q. v.</a> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasalapN_A2">
					<p>Hence, by way of comparison, the significations here following from the Ḳ. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OasalapN_A3">
					<p>‡ <em>Anything in which is no crookedness.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OasalapN_A4">
					<p>‡ The <em>thin part of</em> a blade of iron, such as that of an arrow, &amp;c.: <span class="auth">(M, Ḳ:)</span> and of the fore arm; <span class="auth">(Ṣ, M, Ḳ;)</span> i. e. the <em>half</em> thereof <em>next the hand;</em> the half next the elbow being called the <span class="ar">عَظَمَة</span>. <span class="auth">(Ḳ in art. <span class="ar">عظم</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OasalapN_A5">
					<p>‡ The <em>thin part,</em>, <span class="auth">(Ṣ,)</span> or <em>extremity,</em> or <em>tip,</em> <span class="auth">(M, Ḳ,)</span> of the tongue; <span class="auth">(Ṣ, M, Ḳ;)</span> the thick part thereof being called the <span class="ar">عَظَمَة</span>. <span class="auth">(Ḳ in art. <span class="ar">عظم</span>.)</span> One says, <span class="ar long">أَسَلَاتُ أَلْسِنَتِهِمْ أَمْضَى مِنْ أَسِنَّةِ أَسَلِهِمْ</span> ‡ <span class="add">[<em>The tips of their tongues are sharper than the heads of their spears</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OasalapN_A6">
					<p>‡ The <em>nervus,</em> <span class="auth">(Ḳ,)</span> or the <em>extremity thereof,</em> <span class="auth">(M,)</span> of a camel. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسل</span> - Entry: <span class="ar">أَسَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OasalapN_A7">
					<p>‡ The <em>head,</em> <span class="add">[or what we tern the <em>toe,</em> or <em>foremost extremity,</em> also called <span class="ar">أَنْفٌ</span> and <span class="ar">ذُنَابَةٌ</span>,]</span> of a sandal; <span class="auth">(M, Ḳ;)</span> <em>which is tapering.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasaliyBapN">
				<h3 class="entry"><span class="ar">أَسَلِيَّةٌ</span></h3>
				<div class="sense" id="OasaliyBapN_A1">
					<p><span class="ar">أَسَلِيَّةٌ</span> an epithet applied to the letters <span class="ar">ز</span> and <span class="ar">س</span> and <span class="ar">ص</span> because <em>Pronounced with the tip of the tongue.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasiylN">
				<h3 class="entry"><span class="ar">أَسِيلٌ</span></h3>
				<div class="sense" id="OasiylN_A1">
					<p><span class="ar">أَسِيلٌ</span> <em>Smooth and even:</em> <span class="auth">(M, Ḳ:)</span> anything <em>lank;</em> <span class="auth">(Ṣ, A;)</span> syn. <span class="ar">سَبْطٌ</span>, <span class="auth">(A,)</span> <span class="add">[i. e.]</span> <span class="ar">مُسْتَرْسِلٌ</span>: <span class="auth">(Ṣ, A:)</span> applied to a cheek, <span class="auth">(AZ, Ḳ, TA,)</span> <span class="add">[<em>smooth and long:</em> or <em>long,</em> or <em>oblong, and not high in its ball:</em> (<a href="#Asl_1">see 1</a>:) or]</span> <em>soft, tender, thin, and even:</em> <span class="auth">(AZ:)</span> or <em>long,</em> <span class="auth">(Ḳ, TA,)</span> <em>soft in make,</em> <span class="auth">(TA,)</span> <em>and lank.</em> <span class="auth">(Ḳ, TA.)</span> You say <span class="ar long">رَجُلٌ أَسِيلُ الخَدِّ</span> <em>A man having the cheek soft and long:</em> <span class="auth">(Ṣ:)</span> and in like manner, <span class="ar">فَرَسَ</span> <em>a horse.</em> <span class="auth">(TA.)</span> And <span class="ar long">كَفٌّ أَسِيلَةُ الأَصَابِعِ</span> <em>A hand small and slender, and lank,</em> or <em>long, in the fingers.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MsaAlN">
				<h3 class="entry"><span class="ar">آسَالٌ</span></h3>
				<div class="sense" id="MsaAlN_A1">
					<p><span class="ar">آسَالٌ</span> a pl. having no sing.: <span class="auth">(Ḳ:)</span> mentioned by ISk as a word of which he had not heard any sing. <span class="auth">(Ṣ.)</span> You say, <span class="ar long">هُوَ عَلَى آسَالٍ مِنْ أَبِيهِ</span> <span class="add">[in the CK, erroneously, <span class="ar">اَسالٍ</span>,]</span> <em>He is of a semblance and of characteristics and natural dispositions which are those of his father;</em> <span class="auth">(Ṣ, Ḳ;)</span> like <span class="ar">آسَانٍ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWasBalN">
				<h3 class="entry"><span class="ar">مُؤَسَّلٌ</span></h3>
				<div class="sense" id="muWasBalN_A1">
					<p><span class="ar">مُؤَسَّلٌ</span> Anything <em>sharpened,</em> or <em>pointed.</em> <span class="auth">(M, Ḳ.)</span> You say <span class="ar long">أُذُنٌ مُؤَسَّلَةٌ</span> <em>An ear</em> <span class="add">[of a horse or the like]</span> <em>slender, pointed, and erect.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0059.pdf" target="pdf">
							<span>Lanes Lexicon Page 59</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
