<article class="root" id="Root_Alq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/120_Alf">الف</a></span>
				<span class="ar">الق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/122_Alk">الك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alq_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألق</span></h3>
				<div class="sense" id="Alq_1_A1">
					<p><span class="ar">أَلَقَ</span>, <span class="auth">(JK, Ḳ, TA,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِقُ</span>}</span></add>; <span class="auth">(Ḳ, TA;)</span> or <span class="ar">أَلِقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَقُ</span>}</span></add> <span class="auth">(CK; <span class="add">[in which it would seem, from what follows in this paragraph and the next, that the pret. is wrong, but that the aor. is right;]</span>)</span> inf. n. <span class="ar">أَلْقٌ</span> and <span class="ar">إِلَاقٌ</span>; <span class="auth">(JK, Ḳ;)</span> <em>It</em> <span class="auth">(lightning)</span> <em>lied;</em> <span class="auth">(AHeyth, Ḳ;)</span> <span class="add">[i. e.]</span> <em>it was without rain.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alq_1_A2">
					<p><a href="#Alq_5">See also 5</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الق</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Alq_1_A3">
					<p>Also, <span class="ar">أَلَقَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَقُ</span>}</span></add>, inf. n. <span class="ar">أَلْقٌ</span>, <em>He lied; spoke falsely:</em> whence the reading of Aboo-Jaạfar and Zeyd Ibn-Aslam, <span class="add">[in the Ḳur xxiv. 14,]</span> <span class="ar long">إِذْ تَأْلَقُونَهُ تألّق</span> <span class="add">[<em>When ye spoke it falsely with your tongues</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alq_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّق</span></h3>
				<div class="sense" id="Alq_5_A1">
					<p><span class="ar">تألّق</span> <em>It</em> <span class="auth">(lightning)</span> <em>shone, gleamed,</em> or <em>glistened;</em> as also<span class="arrow"><span class="ar">ائتلق↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَلَقَ</span>]</span>; <span class="auth">(JK, Ṣ, IJ, Ḳ;)</span> and so<span class="arrow"><span class="ar">أَلَقَ↓</span></span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَقُ</span>}</span></add>. <span class="auth">(TA.)</span> Ibn-Aḥmar has made the second trans., using the phrase<span class="arrow"><span class="ar long">تَأْتَلِقُ↓ العُيُونَ</span></span>, either by suppressing a prep., <span class="add">[meaning <em>She shines to the eyes,</em>]</span> or meaning thereby <em>she ravishes the eyes.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الق</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alq_5_A2">
					<p>And <span class="ar">تَأَلَّقَتٌ</span>, said of a woman, <em>She adorned herself:</em> <span class="auth">(Ṣgh, Ḳ:)</span> or <em>she became active and quick to engage in contention</em> or <em>altercation, and prepared herself for evil</em> or <em>mischief, and raised her head:</em> <span class="auth">(IF, Ḳ:)</span> or <em>she became like the</em> <span class="ar">إِلْقَة</span> <span class="add">[<a href="#IiloqN">fem. of <span class="ar">إِلْقٌ</span>, q. v.</a>]</span>. <span class="auth">(IAạr.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alq_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتلق</span></h3>
				<div class="sense" id="Alq_8_A1">
					<p><a href="#Alq_5">see 5</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiloqN">
				<h3 class="entry"><span class="ar">إِلْقٌ</span> / <span class="ar">إِلْقَةٌ</span></h3>
				<div class="sense" id="IiloqN_A1">
					<p><span class="ar">إِلْقٌ</span> <em>A he-wolf:</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">إِلْقَةٌ</span>}</span></add>: <span class="auth">(IAạr, Ṣ, Ḳ:)</span> and the fem. is also applied to <em>a she-ape</em> or <em>monkey;</em> the male of which is not called <span class="ar">إِلْقٌ</span>, but <span class="ar">قِرْدٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">رُبَّاحٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الق</span> - Entry: <span class="ar">إِلْقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiloqN_A2">
					<p>† <em>Evil in disposition,</em> applied to a man; and so with <span class="ar">ة</span> <add><span class="new">{<span class="ar">إِلْقَةٌ</span>}</span></add> applied to a woman: and the latter, <em>a</em> <span class="add">[<em>demon of the kind called</em>]</span> <span class="ar">سِعْلَاة</span>; because of its evil, or malignant, nature: <span class="auth">(TA:)</span> and a <em>bold</em> woman; <span class="auth">(Lth, Ḳ;)</span> for the same reason. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilaAqN">
				<h3 class="entry"><span class="ar">إِلَاقٌ</span></h3>
				<div class="sense" id="IilaAqN_A1">
					<p><span class="ar">إِلَاقٌ</span> <span class="add">[an inf. n. (<a href="#Alq_1">see 1</a>) used as an epithet;]</span> <em>Lying,</em> or <em>fallacious,</em> lightning; <span class="auth">(Ḳ;)</span> <em>that has no rain;</em> <span class="auth">(JK, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَلَّاقٌ↓</span></span>: <span class="auth">(Ḳ,* TA:)</span> <span class="arrow"><span class="ar">آلِقٌ↓</span></span>, likewise, is an epithet applied to lightning <span class="add">[in the same sense; or as signifying <em>shining, gleaming,</em> or <em>glistening:</em> <a href="#Alq_1">see 1</a> <a href="#Alq_5">and 5</a>]</span>: and so is <span class="arrow"><span class="ar">أُلَّقٌ↓</span></span>, as <em>syn. with</em> <span class="ar">خُلَّبٌ</span> <span class="add">[<em>that excites hope of rain, but deceives the expectation</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الق</span> - Entry: <span class="ar">إِلَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IilaAqN_A2">
					<p>Also, applied to a man, <em>Lying:</em> <span class="auth">(JK:)</span> or <em>lying much,</em> or <em>often,</em> or <em>habitually:</em> <span class="auth">(TA:)</span> and <em>very deceitful, and variable in disposition.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaliyqN">
				<h3 class="entry"><span class="ar">أَلِيقٌ</span></h3>
				<div class="sense" id="OaliyqN_A1">
					<p><span class="ar">أَلِيقٌ</span> <span class="add">[<a href="#Alq_1">app. an inf. n. of <span class="ar">أَلَقَ</span></a>; (<a href="#Alq_5">see 5</a>;)]</span> The <em>shining, gleaming,</em> or <em>glistening,</em> of lightning. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OulBaqN">
				<h3 class="entry"><span class="ar">أُلَّقٌ</span></h3>
				<div class="sense" id="OulBaqN_A1">
					<p><span class="ar">أُلَّقٌ</span>: <a href="#IilaAqN">see <span class="ar">إِلَاقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilBaqN">
				<h3 class="entry"><span class="ar">إِلَّقٌ</span></h3>
				<div class="sense" id="IilBaqN_A1">
					<p><span class="ar">إِلَّقٌ</span>, like <span class="ar">إِمَّعٌ</span>, <span class="add">[in a copy of the JK incorrectly written <span class="ar">أَلِقٌ</span>,]</span> <em>i. q.</em> <span class="ar">مُتَأَلِّقٌ</span> <span class="add">[<em>Shining, gleaming,</em> or <em>glistening</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> applied to lightning. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الق</span> - Entry: <span class="ar">إِلَّقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IilBaqN_A2">
					<p>Also † An <em>inconstant</em> man; from <span class="ar">التَّأَلُّقُ</span> as relating to lightning. <span class="auth">(JK: there, in this instance, written <span class="ar">إِلَّقٌ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalBaAqN">
				<h3 class="entry"><span class="ar">أَلَّاقٌ</span></h3>
				<div class="sense" id="OalBaAqN_A1">
					<p><span class="ar">أَلَّاقٌ</span>: <a href="#IilaAqN">see <span class="ar">إِلَاقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MliqN">
				<h3 class="entry"><span class="ar">آلِقٌ</span></h3>
				<div class="sense" id="MliqN_A1">
					<p><span class="ar">آلِقٌ</span>: <a href="#IilaAqN">see <span class="ar">إِلَاقٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0081.pdf" target="pdf">
							<span>Lanes Lexicon Page 81</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
