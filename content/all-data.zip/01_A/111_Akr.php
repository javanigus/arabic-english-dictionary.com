<article class="root" id="Root_Akr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/110_Akd">اكد</a></span>
				<span class="ar">اكر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/112_Akf">اكف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Akr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أكر</span></h3>
				<div class="sense" id="Akr_1_A1">
					<p><span class="ar">أَكَرَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْكِرُ</span>}</span></add>, inf. n. <span class="ar">أَكْرٌ</span>, <em>He tilled</em> the ground; <em>ploughed</em> it <em>up for sowing.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Akr_1_A2">
					<p><em>He dug</em> the ground. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Akr_1_A3">
					<p><em>He cut,</em> or <em>dug,</em> a river, or canal, or rivulet. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اكر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Akr_1_A4">
					<p>And <span class="ar">أَكَرَ</span>, aor <span class="ar">ـُ</span>, <span class="auth">(TA,)</span> inf. n. as above; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">تأكّر↓</span></span>; <span class="auth">(Ḳ;)</span> <em>He dug a hollow,</em> or <em>cavity, in the ground, for water to collect therein and to be baled out therefrom clear:</em> <span class="auth">(Ḳ, TA:)</span> or<span class="arrow"><span class="ar long">تأكّر↓ أُكَرَّا</span></span> signifies <em>he dug hollows,</em> or <em>cavities, in the ground.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akr_3">
				<h3 class="entry">3. ⇒ <span class="ar">آكر</span></h3>
				<div class="sense" id="Akr_3_A1">
					<p><span class="ar">آكرهُ</span>, <span class="auth">(TḲ.)</span> inf. n. <span class="ar">مُؤَاكَرَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He made a contract,</em> or <em>bargain, with him to till and sow and cultivate land for a share of its produce;</em> syn. of the inf. n. <span class="ar">مُخَابَرَةٌ</span>. <span class="auth">(Ṣ, Ḳ, TA.)</span> The doing of this is forbidden. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Akr_5">
				<span class="pb" id="Page_0071"></span>
				<h3 class="entry">5. ⇒ <span class="ar">تأكّر</span></h3>
				<div class="sense" id="Akr_5_A1">
					<p><a href="#Akr_1">see 1</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OukorapN">
				<h3 class="entry"><span class="ar">أُكْرَةٌ</span></h3>
				<div class="sense" id="OukorapN_A1">
					<p><span class="ar">أُكْرَةٌ</span> <em>A hollow,</em> or <em>cavity, dug in the ground,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>in which water collects, and from which it is baled out clear:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">أُكَرٌ</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اكر</span> - Entry: <span class="ar">أُكْرَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OukorapN_B1">
					<p><a href="#kurapN">Also a dial. var. of <span class="ar">كُرَةٌ</span></a>, <span class="auth">(Ḳ,)</span> <span class="add">[<em>A ball</em>]</span> <em>with which one plays:</em> <span class="auth">(TA:)</span> <span class="add">[and <em>a sphere,</em> or <em>globe:</em>]</span> but it is of weak authority. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IikaArapN">
				<h3 class="entry"><span class="ar">إِكَارَةٌ</span></h3>
				<div class="sense" id="IikaArapN_A1">
					<p><span class="ar">إِكَارَةٌ</span>, as used in practical law, <em>Land which is given by its owners to men who sow and cultivate it</em> <span class="add">[app. <em>for a certain share of its produce:</em> <a href="#Akr_3">see 3</a>]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakBaArN">
				<h3 class="entry"><span class="ar">أَكَّارٌ</span></h3>
				<div class="sense" id="OakBaArN_A1">
					<p><span class="ar">أَكَّارٌ</span> <em>A tiller,</em> or <em>cultivator, of land:</em> <span class="auth">(Mṣb, Ḳ:)</span> pl. <span class="ar">أَكَرَةٌ</span>; as though it were <a href="#AkirN">pl. of <span class="ar">آكِرٌ</span></a>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> like as <span class="ar">كَفَرَةٌ</span> <a href="#kaAfirN">is pl. of <span class="ar">كَافِرٌ</span></a>. <span class="auth">(Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0071.pdf" target="pdf">
							<span>Lanes Lexicon Page 71</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
