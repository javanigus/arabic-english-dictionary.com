<article class="root" id="Root_Abe">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/011_Abw">ابو</a></span>
				<span class="ar">ابى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/013_Atb">اتب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abe_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبى</span></h3>
				<div class="sense" id="Abe_1_A1">
					<p><span class="ar">أَبَى</span>, aor. <span class="ar">يَأْبَى</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> which is anomalous, <span class="auth">(Ṣ, M, Mṣb,)</span> because it has no faucial letter <span class="auth">(Ṣ, Mṣb)</span> for its second or third radical, <span class="auth">(Mṣb,)</span> and <span class="ar">يَأْبِى</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> mentioned by IJ as sometimes said, <span class="auth">(M,)</span> agreeably with analogy, <span class="auth">(TA,)</span> and <span class="ar">يِئْبَى</span>, which is doubly anomalous, first because the pret. is of the measure <span class="ar">فَعَلَ</span>, and this pronunciation of the <span class="ar">ى</span> of the aor. is <span class="add">[regularly allowable only]</span> in the case of a verb of the measure <span class="ar">فَعِلَ</span>, aor. <span class="ar">يَفْعَلُ</span>, and secondly because it is only in an aor. like <span class="ar">يِيْجَلُ</span>, <span class="auth">(Sb, M,)</span> i. e., of a verb of which the first radical letter is <span class="ar">و</span> or <span class="ar">ى</span>, <span class="auth">(TA in art. <span class="ar">وجل</span>,)</span> and <span class="ar">يِئْبِى</span>, <span class="auth">(IB, <span class="add">[who cites as an ex. a verse ending with the phrase <span class="ar long">حَتَّى تِئْبِيَهْ</span>,]</span>)</span> inf. n. <span class="ar">إِبَآءٌ</span> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar long">إِبَآءَ ةٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">إِبَاةٌ</span>, <span class="auth">(so in a copy of the M,)</span> or <span class="ar">إِبَايَةٌ</span>, <span class="auth">(so in the Mṣb,)</span> <em>He refused;</em> or <em>refrained, forbore, abstained,</em> or <em>held back;</em> syn. <span class="ar">اِمْتَنَعَ</span>; <span class="auth">(Ṣ, Mṣb, MF, Bḍ in ii. 32, Kull p. 8,)</span> <em>voluntarily,</em> or <em>of his own free will</em> or <em>choice:</em> <span class="auth">(Bḍ ubi suprà, Kull:)</span> <span class="add">[thus when used intransitively: and it is also used transitively:]</span> you say, <span class="ar long">أَبَى الأَمْرَ</span> <em>he refused assent,</em> or <em>consent, to the thing,</em> or <em>affair; disagreed to it;</em> and <em>did not desire</em> <span class="add">[<em>to do</em>]</span> <em>it:</em> <span class="auth">(Mṭr in Ḥar p. 483:)</span> <em>he did not assent to, consent to, approve,</em> or <em>choose, it; he disallowed it; rejected it:</em> <span class="auth">(Mgh:)</span> and <span class="ar long">أَبَى الشَّىْءَ</span> <em>he disliked, was displeased with, disapproved of,</em> or <em>hated, the thing.</em> <span class="auth">(M, Ḳ.)</span> Fr says that there is no verb with fet-ḥ to its medial radical letter in the pret. and fut. <span class="add">[or aor.]</span> unless its second or third radical is a faucial letter, except <span class="ar">أَبَى</span>: that AA adds <span class="ar">رَكَنَ</span>: but that one says <span class="ar">رَكَنَ</span> with <span class="ar">يَرْكُنُ</span> for its fut., and <span class="ar">رَكِنَ</span> with <span class="ar">يَرْكَنُ</span> for its fut.: <span class="auth">(T:)</span> so that the instance mentioned by AA is one of an intermixture of two dial. vars.: <span class="auth">(TA:)</span> Th adds <span class="ar">قَلَى</span> and <span class="ar">غَسَا</span> and <span class="ar">شَجَا</span>; and Mbr adds <span class="ar">جَبَا</span>: but most of the Arabs say <span class="ar">يَقْلِى</span> and <span class="ar">يَغْسُو</span> and <span class="ar">يَشْجُو</span> and <span class="ar">يَجْبِى</span>. <span class="auth">(T.)</span> <span class="add">[Some other instances are mentioned by other authors; but these are verbs of which the aors. are rarely with fet-ḥ, or are instances of the intermixture of two dial. vars.]</span> <span class="ar long">أَبَيْتَ اللَّعْنَ</span> is a greeting which was addressed to kings in the time of ignorance; meaning <em>Mayest thou refuse,</em> or <em>dislike,</em> <span class="auth">(ISk,* Ṣ,* M,* Ḥar p. 491,)</span> to do a thing that would occasion thy <em>being cursed!</em> <span class="auth">(ISk, Ṣ, M;)</span> or, to do that for which thou wouldst deserve <em>the being cursed!</em> for it implies the meaning of a prayer; i. e., may God make thee to be of those who dislike the being cursed! and hence it occurs parenthetically. <span class="auth">(Ḥar ubi suprà.)</span> You say also, <span class="ar long">أَبَى أَنْ يُضَامَ</span> <span class="add">[<em>He refused,</em> or <em>did not submit, to be harmed,</em> or <em>injured</em>]</span>. <span class="auth">(T.)</span> <span class="add">[And sometimes <span class="ar">لَا</span> is inserted after <span class="ar">أَنْ</span>, and is either redundant, or corroborative of the meaning of the verb, as in the case of <span class="ar long">أَنَ لَا</span> or <span class="ar">أَلَّا</span> after <span class="ar">مَنَعَ</span>.]</span> It is said in the Ḳur ix. 32, <span class="ar long">وَيَأْبَى ٱللّٰهُ إِلَّا أَنْ يُتِمَّ نَورَهُ</span>, meaning <em>But God will not consent</em> or <em>choose</em> <span class="add">[<em>save to complete,</em> or <em>perfect, his light</em>]</span>. <span class="auth">(Bḍ.)</span> And in the same xvii. 91, <span class="ar long">فَأَبَى أَكْثَرُ النَاسَ إِلَّا كُفُورًا</span>, i. e. <span class="add">[<em>But the greater number of men have not consented to,</em> or <em>chosen,</em> aught]</span> <em>save denying</em> <span class="add">[its truth, or <em>disbelieving</em> it]</span>; this phrase with <span class="ar">إِلَّا</span> being allowable because it is rendered by means of a negative. <span class="auth">(Bḍ.)</span> You also say, <span class="ar long">كَانَ يَأْبَى اللَّحْمَ</span> <span class="add">[<em>He used to refuse,</em> or <em>dislike, flesh-meat</em>]</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">أَكْلَ اللَّحْمِ</span> <span class="add">[<em>the eating of flesh-meat</em>]</span>. <span class="auth">(Mgh.)</span> And <span class="ar long">أَبَى فَلَانٌ المَآءِ</span> <span class="add">[<em>Such a one refused,</em> or <em>disliked, water,</em> or <em>the water</em>]</span>: <span class="auth">(Ṣ:)</span> or <span class="ar long">أَبَى مِنْ شُرْبِ المَآءِ</span> <span class="add">[<em>he refused,</em> or <em>voluntarily refrained from, the drinking of water,</em> or <em>the water</em>]</span>. <span class="auth">(AAF, M.)</span> And <span class="ar long">أَبَى عَلَيْهِ الأَمَرَ</span>, <span class="auth">(Mgh, and Mṭr. <span class="add">[author of the Mgh]</span> in Ḥar p. 483,)</span> and<span class="arrow"><span class="ar long">تَأَبَّاهُ↓ عَلَيْهِ</span></span>, both signify <em>He refused him his assent,</em> or <em>consent, to the thing,</em> or <em>affair.</em> <span class="auth">(Mṭr ubi suprà, in Ḥar.)</span> Hence, <span class="auth">(Mṭr ubi suprà,)</span> <span class="ar long">أَبَى عَلَيْهِ</span>, <span class="auth">(Mgh, and Mṭr ubi suprà,)</span> and<span class="arrow"><span class="ar long">تَأَبَّى↓ عَلَيْهِ</span></span>, <span class="auth">(T, Ṣ, and Mṭr ubi suprà,)</span> <em>He was incompliant,</em> or <em>unyielding, to him; he resisted him, withstood him,</em> or <em>repugned him;</em> syn. <span class="ar">اِمْتَنَعَ</span> <span class="auth">(T, Ṣ, Mgh, and Mṭr ubi suprà)</span> <span class="ar">عَلَيْهِ</span>: <span class="auth">(T:)</span> thus explained because the objective complement (<span class="ar">الأَمْرَ</span>) is suppressed. <span class="auth">(Mṭr ubi suprà.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abe_1_B1">
					<p><span class="ar long">أَبِيْتُ الطَّعَامَ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">مِنَ الطَّعَامِ</span>, and <span class="ar">اللَّبَنِ</span>, <span class="auth">(M, TA, <span class="add">[in a copy of the former of which the verb is written <span class="ar">ابَيْتُ</span>, but this I suppose to be a mistranscription, on account of what here follows,]</span>)</span> like <span class="ar">رَضِيْتُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَبَّى</span>, <span class="auth">(M, and so in some copies of the Ḳ,)</span> or <span class="ar">إِبَّى</span>, <span class="auth">(so in some copies of the Ḳ,)</span> with kesr, and with the short final alif, <span class="auth">(TA, <span class="add">[i.e. like <span class="ar">رِضَّى</span>, but perhaps this may have been supposed to be the right reading only because the verb is likened to <span class="ar">رَضِيتُ</span>, of which <span class="ar">رِضَّى</span> is the most common inf. n.,]</span>)</span> <em>I left,</em> or <em>relinquished, the food,</em> <span class="auth">(M, Ḳ,)</span> and <em>the milk,</em> <span class="auth">(M, TA,)</span> <em>without being satiated,</em> or <em>satisfied.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Abe_1_B2">
					<p><span class="ar long">أَبِىَ الفَصِيلُ</span>, and <span class="ar">أُبِىَ</span>, inf. n. <span class="ar">أَبَّى</span>, <em>The young camel,</em> or <em>young weaned camel, suffered indigestion from the milk, and became affected with a dislike of food.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Abe_1_C1">
					<p><span class="ar">أَبَيْتُ</span> as <em>syn. with</em> <span class="ar">أَبَوْتُ</span>: <a href="#Abw_1">see the latter <span class="new">{1}</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abe_4">
				<h3 class="entry">4. ⇒ <span class="ar">آبى</span></h3>
				<div class="sense" id="Abe_4_A1">
					<p><span class="ar long">آبَيْتُهُ إِيَّاهُ</span> <span class="add">[in the CK, erroneously, <span class="ar">أَبَيْتُهُ</span>]</span> <em>I made him to refuse it;</em> or <em>to refrain, forbear, abstain,</em> or <em>hold back, from it, voluntarily,</em> or <em>of his own free will</em> or <em>choice:</em> <span class="auth">(Ṣ: <span class="add">[this meaning being there implied, though not expressed:]</span>)</span> or <em>I made him to dislike it, to be displeased with it, to disapprove of it,</em> or <em>to hate it:</em> <span class="auth">(M, Ḳ:)</span> namely, water <span class="add">[&amp;c.]</span>. <span class="auth">(Ṣ, M.)</span> One says, <span class="ar long">فُلَانٌ بَحْرٌ لَا بُؤْبِى</span>, <span class="auth">(ISk, Ṣ, Ḳ,* <span class="add">[in the CK, erroneously, <span class="ar long">لا يُؤْبى</span>,]</span>)</span> i. e., <span class="ar long">لَا يَجْعَلُكَ تَأْبَاهُ</span> <span class="add">[<em>Such a one is</em> like <em>a sea,</em> or <em>great river, that will not make thee to refuse it,</em> or <em>dislike it,</em>, &amp;c.]</span>; <span class="auth">(Ḳ;)</span> i. e., <em>that will not fail,</em> or <em>come to an end,</em> <span class="auth">(ISk, Ṣ, Ḳ,)</span> <em>by reason of its abundance.</em> <span class="auth">(ISk, Ṣ.)</span> In like manner one says, of any water, <span class="ar long">مَآءٌ لَا يُؤْبِى</span> <span class="add">[<em>Water that will not fail,</em> or <em>come to an end</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">عِنْدَنَا مَآءٌ مَا يُؤْبِى</span> <em>With us,</em> or <em>at our abode, is water that does not become scanty,</em> or <em>little in quantity.</em> <span class="auth">(Lḥ, T, M.)</span> And <span class="ar long">آبَى المَآءُ</span> <em>The water decreased,</em> or <em>became deficient.</em> <span class="auth">(AA, from El-Mufaddal.)</span> And <span class="ar long">قَلِيبٌ لَا يُؤْبِى</span> <em>A well that will not become exhausted:</em> <span class="auth">(IAạr, M:)</span> one should not say, <span class="ar">يُؤْبَى</span>. <span class="auth">(M, TA.)</span> In like manner, also, one says, <span class="ar long">كَلَأَ لَا يُؤْبَى</span> <em>Herbage,</em> or <em>pasture, that will not fail,</em> or <em>come to an end.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">عِنْدَهُ دَرَاهِمُ لَا تُؤْبِى</span> <em>He has dirhems,</em> or <em>money, that will not fail,</em> or <em>come to an end.</em> <span class="auth">(TA.)</span> And <span class="ar long">آبَى المَآءُ</span> signifies also <em>The water</em> <span class="add">[in a well]</span> <em>was,</em> or <em>became, difficult of access</em> (<span class="ar">اِمْتَنَعَ</span>), <em>so that no one was able to descend to it but by exposing himself to peril</em> or <em>destruction:</em> <span class="auth">(M:)</span> if a drawer of water descend into the well, <span class="auth">(T, TA,)</span> and the water be altered for the worse in odour, <span class="auth">(TA,)</span> he expose himself to peril, or destruction. <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Abe_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّى</span></h3>
				<div class="sense" id="Abe_5_A1">
					<p><span class="ar long">تَأَبَّى عَلَيْهِ الأَمْرَ</span> and <span class="ar long">تأبّى عَلَيْهِ</span> alone: <a href="#Abe_1">see 1</a>, latter half of the paragraph.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiboyapN">
				<h3 class="entry"><span class="ar">إِبْيَةٌ</span></h3>
				<div class="sense" id="IiboyapN_A1">
					<p><span class="ar">إِبْيَةٌ</span> <em>A paucity,</em> or <em>deficiency, and revulsion, of the milk in the breast:</em> <span class="auth">(Fr, TṢ:)</span> or <em>a revulsion of the milk in the udder;</em> <span class="auth">(Ḳ;)</span> but the saying “in the udder” requires consideration. <span class="auth">(TA:)</span> You say to a woman, when she has a fever on the occasion of childbirth, <span class="ar long">إِنَّمَا هذِهِ الحُمَّى إِبْيَةٌ ثَدْيِكَ</span> <span class="add">[<em>This fever is only</em> occasioned by <em>the paucity,</em> or <em>deficiency, and revulsion, of the milk in thy breast.</em>]</span> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaboyaAnN">
				<h3 class="entry"><span class="ar">أَبْيَانٌ</span> / 
							<span class="ar">أَبْيَانُ</span> / 
							<span class="ar">أَبَيَانٌ</span></h3>
				<div class="sense" id="OaboyaAnN_A1">
					<p><span class="ar">أَبْيَانٌ</span> and <span class="ar">أَبْيَانُ</span> and <span class="ar">أَبَيَانٌ</span>: <a href="#AbK">see <span class="ar">آبٍ</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubaMCN">
				<h3 class="entry"><span class="ar">أُبَآءٌ</span></h3>
				<div class="sense" id="OubaMCN_A1">
					<p><span class="ar">أُبَآءٌ</span>, <span class="auth">(T, Ṣ, M,)</span> or <span class="ar long">أُبَآءٌ مِنَ الطَّعَامِ</span>, <span class="auth">(Ḳ,)</span> <em>A dislike,</em> or <em>loathing, of food:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> of the measure <span class="ar">فُعَالٌ</span>, <span class="auth">(Ṣ, M,)</span> with damm, <span class="auth">(Ṣ, Ḳ,)</span> because it is like a disease, and nouns significant of diseases are generally of that measure. <span class="auth">(M.)</span> You say, <span class="ar long">أَخَذَهُ أُبَآءٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> <span class="ar long">مِنَ الطَّعَامِ</span> <span class="auth">(Ḳ)</span> <em>He was,</em> or <em>became, taken,</em> or <em>affected, with a dislike,</em> or <em>loathing, of food.</em> <span class="auth">(T, Ṣ, M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibaMCN">
				<h3 class="entry"><span class="ar">إِبَآءٌ</span></h3>
				<div class="sense" id="IibaMCN_A1">
					<p><span class="ar">إِبَآءٌ</span> <a href="#Abe_1">inf. n. of <span class="ar">أَبَى</span>, q. v.</a> <span class="auth">(Ṣ, M, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: <span class="ar">إِبَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IibaMCN_A2">
					<p><a href="#Oub~iyBapN">See also <span class="ar">أُبِّيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabieBN">
				<h3 class="entry"><span class="ar">أَبِىٌّ</span> / <span class="ar">أَبِيَّةٌ</span></h3>
				<div class="sense" id="OabieBN_A1">
					<p><span class="ar">أَبِىٌّ</span> and <span class="ar">أَبِيَّةٌ</span>: <a href="#AbK">see <span class="ar">آبٍ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: <span class="ar">أَبِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabieBN_A2">
					<p>Also, the former (<span class="ar">أَبِىٌّ</span>), She <span class="add">[app. a camel, or any beast,]</span> <em>that refuses,</em> or <em>refrains from, fodder, by reason of her suffering from indigestion:</em> and she <em>that refuses,</em> or <em>refrains from, the stallion, by reason of her having little appetency.</em> <span class="auth">(AA.)</span> <span class="add">[<a href="#OawaAbK">See also <span class="ar">أَوَابٍ</span></a>, voce <span class="ar">آبٍ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabBaMCN">
				<h3 class="entry"><span class="ar">أَبَّآءٌ</span></h3>
				<div class="sense" id="OabBaMCN_A1">
					<p><span class="ar">أَبَّآءٌ</span> A man <em>who refuses,</em> or <em>does not submit, to be harmed,</em> or <em>injured.</em> <span class="auth">(T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubBiyBapN">
				<h3 class="entry"><span class="ar">أُبِّيَّةٌ</span></h3>
				<div class="sense" id="OubBiyBapN_A1">
					<p><span class="ar">أُبِّيَّةٌ</span>, with damm, <span class="auth">(Ḳ,)</span> and kesr to the <span class="ar">ب</span>, and with teshdeed of this letter and of the <span class="ar">ى</span>, <span class="auth">(TA,)</span> <span class="add">[in the CK <span class="ar">اُبْيَة</span>,]</span> <em>Pride; self-magnification,</em> or <em>greatness,</em> or <em>majesty:</em> <span class="auth">(Ḳ:)</span> and<span class="arrow"><span class="ar">إِبَآءٌ↓</span></span> <span class="add">[also]</span> signifies <em>pride, self-magnification,</em> or <em>haughtiness.</em> <span class="auth">(Ḥam p. 118.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbK">
				<h3 class="entry"><span class="ar">آبٍ</span></h3>
				<div class="sense" id="MbK_A1">
					<p><span class="ar">آبٍ</span>, and<span class="arrow"><span class="ar">أَبِىٌّ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ, TA,)</span> and<span class="arrow"><span class="ar">أَبَيَانٌ↓</span></span>, <span class="auth">(Ṣ, TA,)</span> <span class="pb" id="Page_0013"></span>part. ns. of <span class="ar">أَبَى</span>, signifying <em>Refusing;</em> or <em>refraining, forbearing, abstaining,</em> or <em>holding back</em> <span class="add">[<em>voluntarily,</em> or <em>of his own free will</em> or <em>choice</em>]</span>: <span class="auth">(Ṣ, Mṣb, TA:*)</span> <span class="add">[<em>refusing assent</em> or <em>consent;</em>, &amp;c.:]</span> <em>disliking, being displeased</em> with a thing, <em>disapproving</em> of it, or <em>hating</em> it: <span class="auth">(M,* Ḳ,* TA:)</span> or the first and second, a man <em>disliking,</em> or <em>loathing, food:</em> <span class="auth">(M, Ḳ, TA:)</span> and the third, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">أَبْيَانٌ↓</span></span>, <span class="auth">(so in a copy of the M,)</span> or <span class="ar">أبَيَانٌ</span>, <span class="auth">(Ḳ,)</span> a man <em>who refuses,</em> or <em>refrains from,</em> or <em>dislikes,</em> or <em>hates,</em> (<span class="ar">يَأْبَى</span>,) <em>food;</em> or, <em>things that are base</em> or <em>mean,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>and causes of dispraise</em> or <em>blame:</em> <span class="auth">(TA:)</span> or the second (<span class="ar">أَبِىٌّ</span>), a man <em>who refuses,</em> or <em>refrains,</em>, &amp;c., <em>vehemently,</em> or <em>much; incompliant, unyielding, resisting, withstanding,</em> or <em>repugning:</em> <span class="auth">(T:)</span> and<span class="arrow"><span class="ar">أَبْيَانُ↓</span></span> and <span class="ar">أَبْيَانٌ</span>, a man <em>having vehement</em> <span class="ar">ابآء</span> <span class="add">[app. <span class="ar">أُبَآء</span>, i. e. <em>dislike,</em> or <em>loathing, of food;</em> agreeably with a common quality of words of the measure <span class="ar">فَعْلَان</span>]</span>: <span class="auth">(T, TA: <span class="add">[but in copy of the T, accord. to the TT, <span class="ar">ابآء</span> in this last explanation is written <span class="ar">اِبآء</span>: in the TA it is without any vowel-sign:]</span>)</span> <a href="#AbK">the pl. of <span class="ar">آبٍ</span></a> is <span class="ar">آبُونَ</span> and <span class="ar">أُبَاةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أُبِىٌّ</span>, <span class="auth">(Ḳ,)</span> with damm, then kesr, and then teshdeed, <span class="auth">(TA, <span class="add">[in the CK <span class="ar">اُبَىّ</span>, and in a copy of the M <span class="ar">اُبِين</span>,]</span>)</span> and <span class="ar">أُبَّآءٌ</span>, <span class="auth">(M, TA,)</span> or <span class="ar">إِبآءٌ</span>, <span class="auth">(Ḳ, TA,)</span> like <span class="ar">رِجَالٌ</span>: <span class="auth">(TA: <span class="add">[in the CK <span class="ar">اُباء</span>:]</span>)</span> the pl. of<span class="arrow"><span class="ar">أَبِىٌّ↓</span></span> is <span class="ar">أَبِيُّونَ</span>; <span class="auth">(M, Ḳ;)</span> of which an instance occurs wherein the pl. <span class="ar">ن</span> is likened to a radical <span class="ar">ن</span>; the gen. case being written, at the end of a verse, <span class="ar">أَبيِينِ</span>: <span class="auth">(M:)</span> the pl. of<span class="arrow"><span class="ar">أَبْيَانٌ↓</span></span>, <span class="auth">(M,)</span> or <span class="ar">أَبَيَانٌ</span>, <span class="auth">(Ḳ,)</span> is <span class="ar">إِبْيَانٌ</span>. <span class="auth">(Kr, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: <span class="ar">آبٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MbK_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">الآبِى</span> <em>The lion.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابى</span> - Entry: <span class="ar">آبٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MbK_A3">
					<p>And <span class="ar">آبِيَةٌ</span>, <span class="auth">(M,)</span> so in some copies of the Ḳ, but in others <span class="arrow"><span class="ar">أَبِيَّةٌ↓</span></span>, <span class="auth">(TA,)</span> She <span class="add">[app. a camel]</span> <em>that dislikes,</em> or <em>loathes, and will not drink, water:</em> and she <em>that desires not the evening-food:</em> and she <span class="auth">(a camel)</span> <em>that is covered and does not conceive,</em> or <em>become pregnant:</em> <span class="auth">(M, Ḳ:)</span> and <span class="ar">أَوَابٍ</span>, <span class="add">[its pl.,]</span> she-camels <em>that refuse,</em> or <em>refrain from, the stallion.</em> <span class="auth">(TA. <span class="add">[<a href="#OabieBN">See also <span class="ar">أَبِىٌّ</span></a>.]</span>)</span> It is said in a prov., <span class="ar long">العَاشِيَةٌ تَهِيجُ الآبِيَةَ</span> <span class="add">[<em>She that is eating her eveningfood,</em> or <em>pasturing in the evening, excites her that has no desire for that food</em>]</span>; i. e., when the camels that desire not the evening-food see the camels eating that food, they follow them, and pasture with them. <span class="auth">(M, and so in the Ṣ in art. <span class="ar">عشو</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWobK">
				<h3 class="entry"><span class="ar">مُؤْبٍ</span></h3>
				<div class="sense" id="muWobK_A1">
					<p><span class="ar">مُؤْبٍ</span> <span class="add">[act. part. n. of 4, q. v.]</span> Water <em>failing,</em> or <em>coming to an end:</em> <span class="auth">(TA:)</span> or water that is <em>scanty,</em> or <em>little in quantity.</em> <span class="auth">(Lḥ, M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOobaApN">
				<h3 class="entry"><span class="ar">مَأْبَاةٌ</span></h3>
				<div class="sense" id="maOobaApN_A1">
					<p><span class="ar long">مَآءٌ مَأْبَاةٌ</span>, <span class="auth">(M,)</span> or <span class="ar long">مَآءَةٌ مَأْبَاةٌ</span>, <span class="auth">(Ḳ,)</span> <em>Water which the camels refuse,</em> or <em>dislike.</em> <span class="auth">(M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0012.pdf" target="pdf">
							<span>Lanes Lexicon Page 12</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0013.pdf" target="pdf">
							<span>Lanes Lexicon Page 13</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
