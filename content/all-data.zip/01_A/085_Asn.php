<article class="root" id="Root_Asn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/084_Asm">اسم</a></span>
				<span class="ar">اسن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/086_Asw">اسو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسن</span></h3>
				<div class="sense" id="Asn_1_A1">
					<p><span class="ar">أَسَنَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْسُنُ</span>}</span></add> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْسِنُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أُسُونٌ</span> <span class="auth">(Ṣ, M, Mṣb)</span> and <span class="ar">أَسْنٌ</span>; <span class="auth">(M;)</span> and <span class="ar">أَسِنَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْسَنُ</span>}</span></add>, <span class="auth">(Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">أَسَنٌ</span>; <span class="auth">(Ṣ, M, Mṣb;)</span> said of water, <em>i. q.</em> <span class="ar">أَجَنَ</span> <em>and</em> <span class="ar">أَجِنَ</span>; <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[i. e.]</span> <em>It became altered for the worse</em> <span class="auth">(M, Mgh, Mṣb)</span> <em>in odour,</em> <span class="auth">(M,)</span> <span class="add">[or <em>in taste and colour, from some such cause as long standing,</em> (<a href="#Oajana">see <span class="ar">أَجَنَ</span></a>,)]</span> <em>but was drinkable;</em> <span class="auth">(M;)</span> or <em>so as not to be drunk,</em> <span class="auth">(Mṣb, TA,)</span> thus differing from <span class="ar">أَجَنَ</span> and <span class="ar">أَجِنَ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#OaSila">See also <span class="ar">أَصِلَ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasinN">
				<h3 class="entry"><span class="ar">أَسِنٌ</span></h3>
				<div class="sense" id="OasinN_A1">
					<p><span class="ar">أَسِنٌ</span>: <a href="#AsinN">see what follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MsinN">
				<h3 class="entry"><span class="ar">آسِنٌ</span></h3>
				<div class="sense" id="MsinN_A1">
					<p><span class="ar">آسِنٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَسِنٌ↓</span></span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> applied to water, <span class="auth">(Ṣ, Mgh, &amp;c.,)</span> <em>i. q.</em> <span class="ar">آجِنٌ</span> <span class="add">[and <span class="ar">أَجِنٌ</span>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[i. e.]</span> <em>Altered for the worse</em> <span class="auth">(Mgh, Mṣb)</span> <em>in odour,</em> <span class="auth">(Mgh,)</span> <span class="add">[or <em>in taste and colour, from some such cause as long standing but drinkable;</em> <span class="auth">(see above, <a href="#AjinN">and see <span class="ar">آجِنٌ</span></a>;)</span>]</span> or <em>so as not to be drunk,</em> <span class="auth">(Mṣb, TA,)</span> thus differing from <span class="ar">آجِنٌ</span> and <span class="ar">أَجِنٌ</span>: <span class="auth">(TA:)</span> pl. <span class="add">[of the former]</span> <span class="ar">آسَانٌ</span> <span class="add">[like as <span class="ar">أَطْهَارٌ</span> <a href="#TaAhirN">is pl. of <span class="ar">طَاهِرٌ</span></a>, or perhaps it may have for its sing. <span class="ar">أَسْنٌ</span>, like <span class="ar">أَجْنٌ</span>]</span>. <span class="auth">(M, TA.)</span> <span class="ar long">مَنْ مَآءٍ غَيْرِ آسِنٍ</span>, in the Ḳur <span class="add">[xlvii. 16]</span>, is explained by Fr as meaning <em>Of water not altered for the worse; not</em> <span class="ar">آجِن</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0060.pdf" target="pdf">
							<span>Lanes Lexicon Page 60</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
