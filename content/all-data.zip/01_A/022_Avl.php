<article class="root" id="Root_Avl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/021_Avkl">اثكل</a></span>
				<span class="ar">اثل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/023_Avm">اثم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Avl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أثل</span></h3>
				<div class="sense" id="Avl_1_A1">
					<p><span class="ar">أَثَلَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِلُ</span>}</span></add>, inf. n. <span class="ar">أُثُولٌ</span>, <em>It</em> <span class="auth">(anything, M)</span> <em>had,</em> or <em>came to have, root,</em> or <em>a foundation;</em> or <em>it was,</em> or <em>became, firm,</em> or <em>established,</em> and <em>firmly rooted</em> or <em>founded;</em> as also<span class="arrow"><span class="ar">تأثّل↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avl_1_A2">
					<p>Also, inf. n. as above, <em>It</em> <span class="auth">(dominion)</span> <em>was,</em> or <em>became, great;</em> <span class="auth">(TA;)</span> and so<span class="arrow">↓</span> the latter verb. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Avl_1_A3">
					<p>And <span class="ar">أَثُلَ</span>, inf. n. <span class="ar">أَثَالَةٌ</span>, said of high rank, or nobility, <em>It was,</em> or <em>became, old, of ancient origin,</em> or <em>of long standing.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avl_1_B1">
					<p><a href="#Avl_5">See also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أثّل</span></h3>
				<div class="sense" id="Avl_2_A1">
					<p><span class="ar">أثّلهُ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَأْثِيلٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He made it</em> <span class="auth">(his wealth, or property, M, Ḳ, and so applied it is tropical, TA)</span> <em>to have root,</em> or <em>a foundation;</em> or <em>to become firm,</em> or <em>established,</em> and <em>firmly rooted</em> or <em>founded;</em> syn. <span class="ar">أَصَّلَهُ</span> <span class="auth">(Ṣ,* M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avl_2_A2">
					<p><em>He</em> <span class="auth">(God, T, M,* TA)</span> <em>made it</em> <span class="auth">(a man's dominion, T, M, Ḳ)</span> <em>to be,</em> or <em>become, firm, firmly established, stable,</em> or <em>permanent:</em> <span class="auth">(T:)</span> or <em>great:</em> <span class="auth">(M, Ḳ:)</span> and <em>he</em> <span class="auth">(a man)</span> <em>made it</em> <span class="auth">(a thing)</span> <em>lasting,</em> or <em>permanent.</em> <span class="auth">(TA.)</span> IAạr the following verse,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تُؤَثِّلُ كَعْبٌ عَلَىَّ القَضَا</span> *</div> 
						<div class="star">* <span class="ar long">فَرَبِّى يُغَيِّرُ أَعْمَالَهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[app. meaning <em>Kaab would oblige me to make payment,</em> or <em>the like,</em> <span class="auth">(as though establishing against me the duty of doing so,)</span> <em>but my Lord changes their actions,</em>]</span> explaining it by saying, i. e. <span class="ar">تُلْزِمُنِى</span>; but <span class="auth">(ISd says,)</span> I know not how this is. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Avl_2_A3">
					<p><em>He</em> <span class="auth">(God, M)</span> <em>made it</em> <span class="auth">(a man's wealth, or property,)</span> <em>to increase;</em> or <em>put it into a good,</em> or <em>right, state,</em> or <em>condition;</em> syn. <span class="ar">زَكَّاةَ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Avl_2_A4">
					<p><span class="ar long">أَتَّلْتُهُ بِرِجِالٍ</span> <em>I multiplied him</em> <span class="add">[meaning his party]</span> <em>by men.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Avl_2_A5">
					<p><span class="ar long">أَثَّلْتُ عَلَيْهِ الدُّيُونَ</span> <em>I collected against him the debts.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Avl_2_A6">
					<p><span class="ar long">أثّل أَهْلَهُ</span> <em>He clad his family with the most excel-lent of clothing:</em> <span class="auth">(M:)</span> or <em>he clad them</em> <span class="auth">(M, Ḳ)</span> <em>with the most excellent of clothing,</em> <span class="auth">(Ḳ,)</span> <em>and did good to them,</em> or <em>acted well towards them.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avl_2_B1">
					<p><span class="ar">أثّل</span>, <span class="add">[used intransitively,]</span> <span class="auth">(M, Ḳ,)</span> inf. n. as above, <span class="auth">(TA,)</span> <em>He</em> <span class="auth">(a man, Ḳ)</span> <em>became abundant in his wealth,</em> or <em>property.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأثّل</span></h3>
				<div class="sense" id="Avl_5_A1">
					<p><span class="ar">تأثّل</span>: <a href="#Avl_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avl_5_A2">
					<p>Also <em>It</em> <span class="auth">(a thing)</span> <em>became collected together.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Avl_5_A3">
					<p><em>He took for himself, got,</em> or <em>acquired, what is termed</em> <span class="ar">أَثْلَة</span>, i. e. <span class="ar">مِيرة</span> <span class="add">[meaning <em>victuals,</em> or <em>provision</em>]</span>; <span class="auth">(M, Ḳ;)</span> <span class="ar long">بَعْدَ حَاجَةٍ</span> <span class="add">[<em>after want</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Avl_5_A4">
					<p><em>He took for himself, got,</em> or <em>acquired, a source, stock,</em> or <em>fund,</em> (<span class="ar">أَصْلٍ</span>,) <em>of wealth,</em> or <em>property.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Avl_5_A5">
					<p>And <span class="ar long">تأثّل مَالًا</span> <em>He collected,</em> or <em>gained,</em> or <em>acquired, wealth,</em> or <em>property,</em> <span class="auth">(M, Ḳ,)</span> <em>and took it for himself:</em> <span class="auth">(M:)</span> <span class="add">[said in the TA to be tropical:]</span> or <em>he collected wealth,</em> or <em>property, and took it for himself,</em> or <em>got it,</em> or <em>acquired it, as a source, stock,</em> or <em>fund:</em> <span class="auth">(Mgh:)</span> and<span class="arrow"><span class="ar long">أَثَلَ↓ مَالاً</span></span>, inf. n. <span class="ar">أُثُولٌ</span>, signifies the same as <span class="ar">تأثّلهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Avl_5_A6">
					<p><span class="ar long">هُمة يَتَأَثَّلُونَ النَّاسَ</span> <em>They take</em> <span class="ar">أُثَال</span>, i. e. <em>wealth,</em> or <em>property, from men.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Avl_5_A7">
					<p><span class="ar long">تأثّل بِئْراً</span> <em>He dug a well</em> <span class="auth">(T, Ṣ, M, Ḳ)</span> <em>for himself.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavolN">
				<h3 class="entry"><span class="ar">أَثْلٌ</span></h3>
				<div class="sense" id="OavolN_A1">
					<p><span class="ar">أَثْلٌ</span> <em>A kind of trees;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>a species of the</em> <span class="ar">طَرْفَآء</span> <span class="add">[or <em>tamarisk;</em> so applied in the present day; termed by Forskål <span class="auth">(Flora Aeg. Arab. p. lxiv.)</span> <em>tamarix orientalis</em>]</span>; <span class="auth">(Ṣ, TA;)</span> or <em>a kind of trees,</em> <span class="auth">(T, M,)</span> or <em>a certain tree,</em> <span class="auth">(Mgh,)</span> <em>resembling the</em> <span class="ar">طرفآء</span>, <span class="auth">(T, M, Mgh,)</span> <em>except that it is of a better kind,</em> <span class="auth">(T,)</span> or <em>except that it is larger, and better in its wood,</em> <span class="auth">(M,)</span> <em>of which are made yellow and excellent</em> <span class="add">[<em>vessels of the kind called</em>]</span> <span class="ar">أَقْدَاح</span>, <em>and of which was made the Prophet's pulpit; it has thick stems, of which are made doors and other things; and its leaves are of the kind called</em> <span class="ar">عَبَل</span>, <em>like those of the</em> <span class="ar">طرفآء</span>: <span class="auth">(TA:)</span> AḤn says, on the authority of Aboo-Ziyád, that <em>it is of the kind termed</em> <span class="ar">عِضَاه</span>, <em>tail, and long in its wood, which is excellent, and is carried to the towns and villages, and the clay houses of these are built upon it;</em> <span class="add">[app. meaning that its wood is used in forming the foundations of the walls;]</span> <em>its leaves are of the kind called</em> <span class="ar">هَدَب</span>, <span class="add">[syn. with <span class="ar">عَبَل</span>,]</span> <em>long and slender, and it has no thorns; of it are made</em> <span class="add">[<em>bowls of the kinds called</em>]</span> <span class="ar">قِصَاع</span> <em>and</em> <span class="ar">جِفَان</span>; <em>and it has a red fruit, like a knot of a rope:</em> <span class="auth">(M:)</span> or <em>a kind of large trees, having no fruit:</em> <span class="auth">(Mṣb:)</span> or <em>i. q.</em> <span class="ar">طرفآء</span>, <em>having no fruit:</em> <span class="auth">(Bḍ in xxxiv. 15:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَثْلَةٌ</span>}</span></add>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> explained in the A as the <span class="ar">سَمُرَة</span> <span class="add">[or <em>gum-acacia tree</em>]</span>: or <em>a tall, straight</em> <span class="add">[<em>tree such as is termed</em>]</span> <span class="ar">عِضَاهَة</span>, <em>of which are made the like of</em> <span class="ar">أَقْدَاح</span>: <span class="auth">(TA:)</span> the pl. <span class="add">[of <span class="ar">أَثْلٌ</span>]</span> is <span class="ar">أُثُولٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="add">[of <span class="ar">أَثْلَةٌ</span>]</span> <span class="ar">أَثَلَاثٌ</span>. <span class="auth">(Ṣ, Ḳ, TA <span class="add">[in the CK <span class="ar">اَثْلاتٌ</span>]</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavolN_A2">
					<p><span class="add">[<a href="#OavolapN">See also <span class="ar">أَثْلَةٌ</span>, below</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OavolN_B1">
					<p><span class="ar long">فُلَانٌ أَثْلُ مَالٍ</span> <em>Such a one is a collector of wealth,</em> or <em>property.</em> <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavolapN">
				<h3 class="entry"><span class="ar">أَثْلَةٌ</span></h3>
				<div class="sense" id="OavolapN_A1">
					<p><span class="ar">أَثْلَةٌ</span> <a href="#OavolN">n. un. of <span class="ar">أَثْلٌ</span>, q. v.</a> <span class="auth">(Ṣ, M, &amp;c.)</span> Because of the tallness of the tree thus called, and its erectness, and beauty of proportion, the poets liken thereto a woman of perfect stature and erect form. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavolapN_A2">
					<p>Metaphorically, <span class="auth">(Mṣb,)</span> ‡ <em>Honour,</em> or <em>reputation;</em> or <em>grounds of pretension to respect on account of the honourable deeds or qualities of one's ancestors,</em>, &amp;c.; syn. <span class="ar">عِرْضٌ</span>; <span class="auth">(Mṣb, TA;)</span> or <span class="ar">حَسَبٌ</span> <span class="auth">(Ṣ, O, Ḳ, TA.)</span> So in the saying, <span class="ar long">فُلَانٌ يَنْحِتُ أَثْلَتَنَا</span>, or <span class="ar">يَنْحَتُ</span>, <span class="auth">(Ṣ accord. to different copies, and so in the O, but in the copies of the Ḳ, incorrectly, <span class="ar long">يَنْحَتُ فِى أَثْلَتِنَا</span>, TA,)</span> ‡ <em>Such a one speaks evil of,</em> <span class="auth">(Ṣ, O,)</span> or <em>impugns,</em> or <em>speaks against,</em> <span class="auth">(Ḳ,)</span> <em>our honour,</em> or <em>reputation,</em>, &amp;c. <span class="auth">(Ṣ, O, Ḳ.)</span> And <span class="ar long">نَحَتَ أَثْلَتَهُ</span> ‡ <em>He detracted from his reputation; spoke against him; impugned his character; censured him; blamed him.</em> <span class="auth">(A, Mṣb.)</span> And <span class="ar long">فُلَانٌ تُنْحَتُ أَثَلَاتُهُ</span> ‡ <span class="add">[<em>Such a one's grounds of pretension to respect,</em>, &amp;c., <em>are impugned</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">هُوَ لَا تُنْحَتُ أَثْلَتُهُ</span> ‡ <em>He has not any vice,</em> or <em>fault, nor any imperfection,</em> or <em>defect.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OavolapN_A3">
					<p>The <em>root, foundation, origin, source, stock,</em> or <em>the like,</em> syn. <span class="ar">أصْلٌ</span>; <span class="auth">(T, Ṣ, M, Mgh, Ḳ;)</span> of a thing, and of a man; <span class="auth">(T;)</span> of anything; <span class="auth">(M;)</span> <span class="add">[<em>a source, stock,</em> or <em>fund,</em>]</span> of wealth, or property: <span class="auth">(Mgh, TA:)</span> pl. <span class="ar">إِثَالٌ</span>. <span class="auth">(Ḳ.)</span> So in the saying, <span class="ar long">لَهُ أَثلَةُ مَالٍ</span> <span class="add">[<em>He has a source,</em> or <em>stock,</em> or <em>fund, of wealth,</em> or <em>property</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OavolapN_A4">
					<p><em>Victuals,</em> or <em>provision;</em> syn. <span class="ar">مِيرَةٌ</span> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OavolapN_A5">
					<p>The <em>goods, furniture, and utensils, of a house</em> or <em>tent;</em> as also<span class="arrow"><span class="ar">أَثَلَةٌ↓</span></span>. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثْلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OavolapN_A6">
					<p><em>Apparatus, accoutrements, implements,</em> or <em>the like.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> So in the saying, <span class="ar long">أَخَذْتُ أَثْلَةَ الشِّتَآءِ</span> <span class="add">[<em>I took the apparatus,</em>, &amp;c., <em>of,</em> i. e. <em>for, the winter</em>]</span>. <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OavalapN">
				<h3 class="entry"><span class="ar">أَثَلَةٌ</span></h3>
				<div class="sense" id="OavalapN_A1">
					<p><span class="ar">أَثَلَةٌ</span>: <a href="#OavolapN">see <span class="ar">أَثْلَةٌ</span></a>, near the end.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavaAlN">
				<h3 class="entry"><span class="ar">أَثَالٌ</span></h3>
				<div class="sense" id="OavaAlN_A1">
					<p><span class="ar">أَثَالٌ</span>, <span class="auth">(T, Ṣ, M,)</span> with fet-ḥ, <span class="auth">(Ṣ,)</span> or <span class="ar">أُثَالٌ</span>, with damm, <span class="auth">(Mgh,)</span> or both, <span class="auth">(Ḳ,)</span> ‡ <em>Glory, honour, dignity, nobility,</em> or <em>high rank.</em> <span class="auth">(AA, T, Ṣ, M, Mgh, Ḳ.)</span> You say, <span class="ar long">لَهُ أُثَالٌ كَأَنَّهُ أُثَالٌ</span> ‡ <em>He has glory,</em> or <em>honour,</em>, &amp;c., <em>as though it were</em> the mountain called <em>Othál.</em> <span class="auth">(TA.)</span> <span class="add">[But the next signification seems to be here more appropriate.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثَالٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavaAlN_A2">
					<p>‡ <em>Wealth,</em> or <em>property.</em> <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaviylN">
				<h3 class="entry"><span class="ar">أَثِيلٌ</span></h3>
				<div class="sense" id="OaviylN_A1">
					<p><span class="ar">أَثِيلٌ</span> <em>A place of growth of trees of the kind called</em> <span class="ar">أَرَاك</span> <span class="add">[perhaps a mistranscription for <span class="ar">أَثْل</span>]</span>: mentioned by Th, from IAạr. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaviylN_B1">
					<p><em>Abundant, and luxuriant,</em> or <em>long,</em> hair. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">أَثِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OaviylN_B2">
					<p><a href="#mawavBalN">See also <span class="ar">مَؤَثَّلٌ</span></a> in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MvilN">
				<h3 class="entry"><span class="ar">آثِلٌ</span></h3>
				<div class="sense" id="MvilN_A1">
					<p><span class="ar">آثِلٌ</span>: <a href="#muwavBalN">see <span class="ar">مُؤَثَّلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWavBalN">
				<h3 class="entry"><span class="ar">مُؤَثَّلٌ</span></h3>
				<div class="sense" id="muWavBalN_A1">
					<p><span class="ar">مُؤَثَّلٌ</span> <em>Having root,</em> or <em>a foundation;</em> or <em>firm,</em> or <em>established,</em> and <em>firmly rooted</em> or <em>founded:</em> <span class="auth">(Ṣ:)</span> or <em>having a permanent source,</em> or <em>firm foundation:</em> <span class="auth">(Munjid of Kr:)</span> or <em>of old foundation</em> or <em>origin:</em> or <em>collected together so as to</em> <span class="add">[<em>become stable</em> or <em>permanent,</em> or]</span> <em>have root</em> or <em>a foundation:</em> <span class="auth">(T:)</span> or <em>old; of ancient origin;</em> or <em>of long standing:</em> <span class="auth">(M, TA:)</span> or <em>permanent:</em> <span class="auth">(IAạr:)</span> ‡ applied to glory, honour, dignity, nobility, or high rank; <span class="auth">(T, Kr, Ṣ, M, TA;)</span> and so<span class="arrow"><span class="ar">أَثِيلٌ↓</span></span>: <span class="auth">(Ṣ, TA:)</span> and to wealth, or property: <span class="auth">(Kr, Ṣ:)</span> and to anything; <span class="auth">(T, M;)</span> and so<span class="arrow"><span class="ar">أَثِيلٌ↓</span></span>, and<span class="arrow"><span class="ar">مُتَأَثِّلٌ↓</span></span>: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar">آثِلٌ↓</span></span>, also, has the first of these significations, applied to dominion. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">مُؤَثَّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWavBalN_A2">
					<p><em>Prepared, disposed, arranged,</em> or <em>put into a right</em> or <em>good state.</em> <span class="auth">(AA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOavBilN">
				<h3 class="entry"><span class="ar">مُتَأَثِّلٌ</span></h3>
				<div class="sense" id="mutaOavBilN_A1">
					<p><span class="ar">مُتَأَثِّلٌ</span>: <a href="#muwavalN">see <span class="ar">مُؤَثَلٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثل</span> - Entry: <span class="ar">مُتَأَثِّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutaOavBilN_A2">
					<p>Also <em>Taking for oneself, getting,</em> or <em>acquiring, a source, stock,</em> or <em>fund,</em> (<span class="ar">أَصْل</span>,) <em>of wealth,</em> or <em>property:</em> <span class="auth">(Ṣ, TA:)</span> or <em>collecting</em> wealth, or property, <span class="auth">(T, Mgh,)</span> <em>and taking</em> it <em>for oneself,</em> or <em>getting</em> it, or <em>acquiring</em> it, <em>as a source, stock,</em> or <em>fund.</em> <span class="auth">(Mgh.)</span> So in a trad. on the subject of a charge respecting the orphan, <span class="ar long">يَأْكُلُ مِنْ مَالِهِ غَيْرَ مُتَأَثِّلٍ مَالًا</span> <span class="add">[<em>He may eat of his wealth,</em> or <em>property, not taking for himself a source, stock,</em> or <em>fund, of wealth,</em> or <em>property:</em> or, <em>not collecting</em>, &amp;c.]</span>: <span class="auth">(T, Ṣ, Mgh:*)</span> or, accord. to Bkh, <em>not acquiring abundance of wealth:</em> but the former explanation is more correct lexically. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0021.pdf" target="pdf">
							<span>Lanes Lexicon Page 21</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
