<article class="root" id="Root_Abh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/009_Abn">ابن</a></span>
				<span class="ar">ابه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/011_Abw">ابو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abh_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبه</span></h3>
				<div class="sense" id="Abh_1_A1">
					<p><span class="ar long">أَبَهَ لَهُ</span>, <span class="auth">(JK, Ḳ,)</span> and <span class="ar">بِهِ</span>; <span class="auth">(Ḳ;)</span> and <span class="ar">أَبِهَ</span>; aor. <span class="add">[of both]</span> <span class="ar">يَأْبَهُ</span>; inf. n. <span class="ar">أَبْهٌ</span>, <span class="auth">(JK, Ḳ,)</span> of the former, <span class="auth">(TA,)</span> and <span class="ar">أُبُوهٌ</span>, <span class="add">[also of the former,]</span> <span class="auth">(JK,)</span> and <span class="ar">أَبَهٌ</span>, <span class="auth">(JK, Ḳ,)</span> which is of the latter; <span class="auth">(TA;)</span> <em>He knew it;</em> or <em>understood it;</em> or <em>knew it,</em> or <em>understood it, instinctively:</em> or <em>he recognised it readily; knew it,</em> or <em>understood it, readily, after he had forgotten it.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">مَا أَبَهْتُ لَهُ</span>, <span class="auth">(AZ, JK, Ṣ, Mgh,)</span> aor. <span class="ar">آبَهُ</span>, inf. n. <span class="ar">أَبْهٌ</span>; <span class="auth">(AZ, Ṣ)</span> and <span class="ar long">مَا أَبِهْتُ لَهُ</span>, <span class="auth">(JK, Ṣ,)</span> aor. as above, inf. n. <span class="ar">أَبَهٌ</span>; <span class="auth">(Ṣ;)</span> <em>I did not know it,</em> or <em>understand it;</em> or <em>did not know of it; was not cognizant of it:</em> <span class="auth">(JK, Mgh:)</span> or <em>I did not have my attention roused to it after I had forgotten it:</em> <span class="auth">(AZ, Ṣ:)</span> the former is like <span class="ar">وَبَهْتُ</span>; <span class="auth">(Mgh;)</span> and the latter, like <span class="add">[<span class="ar">وَبِهْتُ</span> and]</span> <span class="ar">نَبِهْتُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابه</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abh_1_A2">
					<p><span class="ar long">لَا يُؤْبَهُ لَهُ</span> <span class="auth">(Mgh, Ḳ, TA)</span> <em>He will not be cared for, minded,</em> or <em>regarded,</em> because of his lowness of condition, or abjectness. <span class="auth">(Mgh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابه</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abh_1_A3">
					<p><span class="ar long">أَبَهْتُهُ بِكَذَا</span> <em>I imputed to him,</em> or <em>suspected him of, such a thing.</em> <span class="auth">(JK, Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abh_2">
				<h3 class="entry">2. ⇒ <span class="ar">أبّه</span></h3>
				<div class="sense" id="Abh_2_A1">
					<p><span class="ar">أَبَّهْتُهُ</span>, inf. n. <span class="ar">تَأْبِيهِ</span>, <em>I roused his attention:</em> and <em>I made him to know,</em> or <em>understand.</em> <span class="auth">(Kr, Ḳ.)</span> The two meanings are nearly alike. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar">آبَهْتُهُ↓</span></span> <em>I made him to know; informed, apprized, advertised,</em> or <em>advised, him; gave him information, intelligence, notice,</em> or <em>advice.</em> <span class="auth">(IB.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Abh_4">
				<h3 class="entry">4. ⇒ <span class="ar">آبه</span></h3>
				<div class="sense" id="Abh_4_A1">
					<p><a href="#Abh_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abh_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّه</span></h3>
				<div class="sense" id="Abh_5_A1">
					<p><span class="ar">تأبّه</span> <em>He magnified himself; behaved proudly,</em> or <em>haughtily.</em> <span class="auth">(JK, Ṣ, Ḳ.)</span> You say, <span class="ar long">تَأَبَّهَ الرَّجُلُ عَلَى فُلَانٍ</span> <em>The man magnified himself against such a one, and held himself above him.</em> <span class="auth">(JK,* TA.)</span> And <span class="ar long">تَأَبَّهُ عَنْ كَذَا</span> <em>He shunned, avoided,</em> or <em>kept himself far from, such a thing;</em> <span class="auth">(JK, Z, Ḳ;)</span> <em>he was disdainful of it, he disdained it,</em> or <em>held himself above it.</em> <span class="auth">(Z, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubBahapN">
				<h3 class="entry"><span class="ar">أُبَّهَةٌ</span></h3>
				<div class="sense" id="OubBahapN_A1">
					<p><span class="ar">أُبَّهَةٌ</span> <em>Greatness,</em> or <em>majesty;</em> <span class="auth">(JK, Ṣ, Ḳ;)</span> <em>a quality inspiring reverence</em> or <em>veneration;</em> <span class="auth">(TA;)</span> <em>goodliness and splendour;</em> <span class="auth">(Ḳ;)</span> and <em>goodliness of aspect:</em> <span class="auth">(TA:)</span> and <em>pride, self-magnification,</em> or <em>haughtiness.</em> <span class="auth">(JK,* Ṣ,* Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0010.pdf" target="pdf">
							<span>Lanes Lexicon Page 10</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
