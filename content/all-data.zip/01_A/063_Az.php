<article class="root" id="Root_Az">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/062_Are">ارى</a></span>
				<span class="ar">از</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/064_Azb">ازب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Az_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزّ</span></h3>
				<div class="sense" id="Az_1_A1">
					<p><span class="ar long">أَزَّتِ القِدْرُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">البُرْمَةُ</span>, <span class="auth">(A,)</span> aor <span class="ar">ـُ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">ـِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَزِيزٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and <span class="ar">أَزٌّ</span> and <span class="ar">أَزَازٌ</span>, <span class="auth">(Ḳ,)</span> <em>The cooking-pot made a sound in boiling:</em> <span class="auth">(Ṣ, accord. to an explanation there given of the inf. n.; and A:)</span> or <em>boiled:</em> <span class="auth">(Ṣ:)</span> or <em>boiled vehemently;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">ائتزّت↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَّزَّت</span>]</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">ٱئْتِزَازٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">تأزّت↓</span></span>, <span class="auth">(Ḳ,)</span> inf. N. <span class="ar">تَأَزُّزٌ</span>: <span class="auth">(TA:)</span> or all signify <em>it boiled not vehemently.</em> <span class="auth">(Ḳ.)</span> It is said in a trad., <span class="ar long">كَانَ يُصَلِّى وَلِجَوْفِهِ أَزِيز كَأَزِيزِ ٱلْمِرْجَلِ مِنَ ٱلْبُكَآءِ</span> ‡ <span class="add">[<em>He used to pray, his inside making a sound like the sound of the boiling of the cooking-pot, by reason of weeping</em>]</span>: <span class="auth">(Ṣ, A, Mgh:)</span> this is said of Moḥammad: <span class="ar">ازيز</span> meaning <em>boiling,</em> or the <em>sound thereof.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">از</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Az_1_A2">
					<p><span class="ar long">أَزَّتِ السَّحَابَةُ</span> <em>The cloud made a sound from afar.</em> <span class="auth">(Ḳ.)</span> <span class="add">[In this instance, the TA assigns only one form to the aor., namely <span class="ar">ـِ</span>, and gives only <span class="ar">أَزٌّ</span> and <span class="ar">أَزِيزٌ</span> as inf. ns.]</span> <span class="ar">أَزِيزٌ</span> signifies The <em>sounding</em> of thunder; <span class="auth">(Ṣ, A;*)</span> and of a millstone. <span class="auth">(A.)</span> You say, <span class="ar long">هَالَنِى أَزِيزُ الرَّعْدِ</span> <span class="add">[<em>The sounding of the thunder terrified me</em>]</span>: and <span class="ar long">صَدَّعَنِى أَزِيزُ الرَّحَى</span> <span class="add">[<em>The sounding of the mill-stone made my head to ache</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">از</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Az_1_A3">
					<p>Also, inf. n. <span class="ar">أَزِيزٌ</span>, <em>It flamed,</em> or <em>blazed, like fire in firewood, and was in motion, or in a state of commotion.</em> <span class="auth">(AO.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">از</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Az_1_B1">
					<p><span class="ar">أَزَّبِالقِدْرِ</span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْزُزُ</span>}</span></add>,]</span> inf. n. <span class="ar">أَزٌّ</span>, <em>He kindled a fire,</em> or <em>made it to burn</em> or <em>to burn fiercely, beneath the cooking-pot, in order that it might boil:</em> or you say, <span class="ar long">أَزَّ القِدْرَ</span>, inf. n. as above, meaning <em>he collected firewood beneath the cooking-pot so that the fire flamed,</em> or <em>blazed:</em> and <em>he made the fire to flame,</em> or <em>blaze, beneath the cooking-pot.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَزَّ النَّارَ</span>, <span class="auth">(Ḳ,)</span>) aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْزُزُ</span>}</span></add>, inf. n. <span class="ar">أَزٌّ</span>, <span class="auth">(TA,)</span> <em>He kindled the fire,</em> or <em>made it to burn</em> or <em>to burn fiercely.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">از</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Az_1_B2">
					<p><span class="ar long">أَزَّ الشَّىْءَ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْزُزُ</span>}</span></add>, inf. n. <span class="ar">أَزٌّ</span> and <span class="ar">أَزِيزٌ</span>, <span class="auth">(TA,)</span> <em>He put the thing into a state of violent motion</em> or <em>commotion:</em> <span class="auth">(ISd, Ḳ:)</span> so accord. to IDrd: <span class="auth">(ISd:)</span> but Ibráheem El-Ḥarbee explains <span class="ar">أَزٌّ</span> only as signifying the act of <em>moving.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">از</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Az_1_B3">
					<p><span class="ar">أَزَّهُ</span>, <span class="auth">(A, TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْزُزُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">أَزٌّ</span>, <span class="auth">(Ṣ, TA,)</span> <em>He put him in motion; disquieted him;</em> <span class="auth">(A,* TA;)</span> <em>stirred up, roused,</em> or <em>provoked, him;</em> and <em>incited, urged,</em> or <em>instigated, him;</em> <span class="auth">(Ṣ,* A,* TA;)</span> <span class="ar long">عَلَى كَذَا</span> <em>to do such a thing.</em> <span class="auth">(A, TA.*)</span> It is said in the Ḳur <span class="add">[xix. 86]</span>, <span class="ar long">أَلَمْ تَرَ أَنّا أَرْسَلْنَا الشَّيَاطِينَ عَلَى الكَافِرِينَ تَؤُزُّهُمْ أَزَّا</span> <em>Seest thou not that we have sent the devils against the unbelievers inciting them strongly</em> to acts of disobedience? <span class="auth">(Ṣ, TA.)</span> Or <span class="ar">أَزٌّ</span> signifies The <em>inciting</em> a man to do a thing <em>by artifice,</em> or <em>cunning,</em> and <em>gentleness.</em> <span class="auth">(El-Ḥarbee.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Az_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأزّ</span></h3>
				<div class="sense" id="Az_5_A1">
					<p><span class="ar long">تأزّت القِدْرُ</span>: <a href="#Az_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Az_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتزّ</span></h3>
				<div class="sense" id="Az_8_A1">
					<p><span class="ar long">ائتزّت القِدْرُ</span>: <a href="#Az_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">از</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Az_8_A2">
					<p><span class="ar long">هُوَ يَأْتَزُّ مِنْ كَذَا</span> <em>He becomes angry, and distressed, and disquieted</em> or <em>disturbed, by reason of such a thing.</em> <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazBapN">
				<h3 class="entry"><span class="ar">أَزَّةٌ</span></h3>
				<div class="sense" id="OazBapN_A1">
					<p><span class="ar">أَزَّةٌ</span> <em>A sound,</em> or <em>noise.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaziyzN">
				<h3 class="entry"><span class="ar">أَزِيزٌ</span></h3>
				<div class="sense" id="OaziyzN_A1">
					<p><span class="ar">أَزِيزٌ</span> <a href="#Az_1">inf. n. of 1</a>.</p>	
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">از</span> - Entry: <span class="ar">أَزِيزٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaziyzN_A2">
					<p><em>Sharpness;</em> syn. <span class="ar">حِدَّةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0052.pdf" target="pdf">
							<span>Lanes Lexicon Page 52</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
