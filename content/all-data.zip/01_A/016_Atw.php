<article class="root" id="Root_Atw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/015_Atn">اتن</a></span>
				<span class="ar">اتو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/017_Ate">اتى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Atw_1">
				<h3 class="entry">1. ⇒ <span class="ar">أتو</span> ⇒ <span class="ar">أتى</span></h3>
				<div class="sense" id="Atw_1_A1">
					<p><span class="ar">أَتَا</span>, aor. <span class="ar">يَأْتُو</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">أَتَوْتُهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">آتُوهُ</span>; <span class="auth">(Ṣ;)</span> inf. n. <span class="ar">أَتْوٌ</span>, <span class="auth">(M, Mṣb,)</span> or <span class="ar">أَتْوَةٌ</span>, <span class="auth">(Ṣ,)</span> or the latter is an inf. n. of un.; <span class="auth">(T, TA;)</span> <em>He came;</em> <span class="auth">(Mṣb;)</span> and <em>I came to him,</em> or <em>it;</em> <span class="auth">(Ṣ;)</span> the former <a href="#Oatae">a dial. var. of <span class="ar">أَتَى</span></a>, aor. <span class="ar">يَأْتِى</span>; <span class="auth">(Mṣb;)</span> and the latter, of <span class="ar">أَتَيْتُهُ</span>. <span class="auth">(T, Ṣ, M, Ḳ.)</span> <span class="add">[<a href="index.php?data=01_A/017_Ate">See art. <span class="ar">اتى</span></a>, to which, as well as to the present art., belong several words mentioned in this.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Atw_1_B1">
					<p><span class="ar">أَتَا</span>, aor. as above, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">أَتْوٌ</span>, <span class="auth">(M, Ḳ, TḲ,)</span> also signifies <em>He pursued a right, direct, straight,</em> or <em>even, course,</em> in going, or pace. <span class="auth">(M, Ḳ, TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Atw_1_B2">
					<p>And <em>He</em> <span class="auth">(a man, TḲ)</span> <em>hastened, made haste,</em> or <em>sped;</em> or <em>he was quick, hasty, speedy, rapid, swift,</em> or <em>fleet.</em> <span class="auth">(M, Ḳ, TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Atw_1_B3">
					<p>And <span class="ar long">أَتَتِ النَاقَةُ</span>, inf. n. as above, <em>The she-camel returned her fore legs,</em> <span class="add">[<em>drawing the feet back towards the body, and lifting them high,</em>]</span> <em>in her going.</em> <span class="auth">(M.)</span> You say, <span class="ar long">مَا أَحْسَنَ أَتْوَ يَدَىْ هذِهِ النَّاقَةِ</span>, and <span class="ar long">أَتْىَ يَدَيْهَا</span>, <em>How good,</em> or <em>beautiful, is this she-camel's returning of her fore legs in her going!</em> i. e. <span class="ar long">رَجْعَ يَدَيْهَا فِى سَيْرِهَا</span>. <span class="auth">(T,* Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Atw_1_B4">
					<p>And <span class="ar">أَتْوٌ</span> signifies also The act of <em>impelling,</em> or <em>propelling;</em> particularly, of an arrow from a bow. <span class="auth">(TA.)</span> See also this word below.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Atw_1_C1">
					<p><span class="ar">أَتَوْتُهُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">آتُوهُ</span>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">إِتَاوَةٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> so accord. to AʼObeyd, <span class="auth">(M,)</span> and mentioned by Ṣgh on the authority of AZ, <span class="auth">(TA,)</span> and <span class="ar">أَتْوٌ</span>, <span class="auth">(Ṣ, TA,)</span> <span class="add">[<em>I gave him what is termed</em> <span class="ar">إِتَاوَة</span>, as meaning <em>the tax called</em> <span class="ar">خَرَاج</span>: this is the signification which seems to be indicated in the Ṣ: or]</span> <em>I bribed him; gave him a bribe.</em> <span class="auth">(M, Mṣb, Ḳ.)</span> <span class="add">[<a href="#IitaAwapN">See also <span class="ar">إِتَاوَةٌ</span> below</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Atw_1_D1">
					<p><span class="ar long">أَتَتِ النَّخْلَةُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar">الشَّجَرَةُ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">تَأْتُو</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">إِتَآءٌ</span>, with kesr, <span class="auth">(Kr, M, Ḳ,)</span> <span class="add">[in a copy of the T, and in two copies of the Ṣ, <span class="ar">أَتَآءٌ</span>, but this is said in the M to be a subst.,]</span> and <span class="ar">أَتْوٌ</span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar long">آتَتِ↓ النخلة</span></span>, inf. n. <span class="ar">إِيتَآءٌ</span>; <span class="auth">(T;)</span> <span class="pb" id="Page_0015"></span><em>The palm-tree</em> <span class="add">[and <em>the tree</em>]</span> <em>bore:</em> <span class="auth">(Ṣ:)</span> or <em>put forth its fruit:</em> or <em>showed its being in a good state:</em> <span class="auth">(M, Ḳ:)</span> or <em>bore much:</em> <span class="auth">(T, M, Ḳ:)</span> and <span class="ar">اتآء</span> signifies also the <em>increasing,</em> or <em>thriving,</em> of seed-produce. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: D2</span>
				</div>
				<div class="sense" id="Atw_1_D2">
					<p>And <span class="ar long">أَتَتِ المَاشِيَةٌ</span>, inf. n. <span class="ar">إِتَآءٌ</span>, <span class="add">[in a copy of the M <span class="ar">أَتَآءٌ</span>,]</span> <em>The cattle,</em> or <em>camels, &amp;c., increased,</em> or <em>yielded increase.</em> <span class="auth">(M, Ḳ. <span class="add">[In the CK, immediately before this phrase, <span class="ar">والثِّمارِ</span> is erroneously put for <span class="ar">وَالنَّمَآءُ</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="Atw_1_E1">
					<p><span class="ar">تَأْتَى</span> for <span class="ar">تأْتَوِى</span>: <a href="#Abw_1">see 1</a> <a href="#Abw">in art. <span class="ar">ابو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Atw_4">
				<h3 class="entry">4. ⇒ <span class="ar">آتَتِ</span></h3>
				<div class="sense" id="Atw_4_A1">
					<p><a href="#Atw_1">see 1</a>, near the end of the paragraph.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatowN">
				<h3 class="entry"><span class="ar">أَتْوٌ</span></h3>
				<div class="sense" id="OatowN_A1">
					<p><span class="ar">أَتْوٌ</span> <a href="#Atw_1">an inf. n. of 1, q. v.</a></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OatowN_B1">
					<p><em>A way, course, mode,</em> or <em>manner.</em> <span class="auth">(M, Ḳ.)</span> You say, of speech, or language, <span class="auth">(M,)</span> and of a speaker, or reciter of a <span class="ar">خُطْبَة</span>, <span class="auth">(IAạr, M,)</span> <span class="ar long">مَا زَالَ عَلَى أَتْو وَاحد</span> <em>It,</em> and <em>he, ceased not to follow one</em> <span class="add">[<em>uniform</em>]</span> <em>way,</em>, &amp;c. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OatowN_C1">
					<p><em>An impulsion; a propulsion;</em> particularly <em>an act of shooting</em> an arrow from a bow: so in a trad., where it is said, <span class="ar long">كُنَّا نَرْمِى الأَتْوَيْنِ</span> <em>We used to shoot one shooting and two shootings;</em> meaning, of arrows from bows, after the prayer of sunset. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="OatowN_D1">
					<p><em>Death:</em> or <span class="add">[so in the T, but in the Ḳ “and,”]</span> <em>a trial;</em> or <em>an affliction.</em> <span class="auth">(T, Ḳ.)</span> You say, <span class="ar long">أَتَى عَلَى فُلَانٍ أَتْوٌ</span> <em>Death came upon such a one:</em> or <em>a trial;</em> or <em>an affliction.</em> <span class="auth">(ISh, T.)</span> And <span class="ar long">إِنْ أَتَى عَلَّى أَتْوٌ فَغُلامِى حُرٌّ</span> <em>If I die,</em> <span class="add">[or <em>if death befall me,</em>]</span> <em>my slave shall be free.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: D2</span>
				</div>
				<div class="sense" id="OatowN_D2">
					<p><em>A vehement sickness</em> or <em>disease:</em> <span class="auth">(T, Ḳ:)</span> or the <em>fracture of an arm,</em> or <em>of a leg.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="OatowN_E1">
					<p><em>A gift.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E2</span>
				</div>
				<div class="sense" id="OatowN_E2">
					<p><em>Butter;</em> <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">أَتَآءٌ↓</span></span>, <span class="auth">(A,)</span> or<span class="arrow"><span class="ar">إِتَآءٌ↓</span></span>. <span class="auth">(TA: <span class="add">[in which it is said to be like <span class="ar">كِتَابٌ</span>; but this I think a mistake: <a href="#OataACN">see <span class="ar">أَتَآءٌ</span> below</a>.]</span>)</span> You say, when a skin of milk is agitated, and its butter comes, <span class="ar long">قَدْ جَآءَ أَتْوُهُ</span> <span class="add">[<em>Its butter has come</em>]</span>. <span class="auth">(Ṣ, TA.)</span> And you say,<span class="arrow"><span class="ar long">لَبَنٌ ذُو اتآءٍ↓</span></span> <em>Milk having butter.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="OatowN_F1">
					<p><em>A great body</em> or <em>corporeal form</em> or <em>person</em> (<span class="ar long">شَخْصٌ عَظِيمٌ</span>). <span class="auth">(AZ, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatowapN">
				<h3 class="entry"><span class="ar">أَتْوَةٌ</span></h3>
				<div class="sense" id="OatowapN_A1">
					<p><span class="ar">أَتْوَةٌ</span> <em>A single coming;</em> as also <span class="ar">أَتْيَةٌ</span>. <span class="auth">(T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatowaAnu">
				<h3 class="entry"><span class="ar">أَتْوَانُ</span></h3>
				<div class="sense" id="OatowaAnu_A1">
					<p><span class="ar">أَتْوَانُ</span> a corroborative <span class="add">[or imitative sequent]</span> of <span class="ar">أَسْوَانُ</span>, which signifies <em>grieving mourning,</em> or <em>sorrowful:</em> <span class="auth">(TA:)</span> or <em>i. q.</em> <span class="ar">حَرِيصٌ</span> <span class="add">[<em>vehemently desirous; eager;</em>, &amp;c.]</span>. <span class="auth">(Mirḳát el-Loghah, cited by Golius.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OataMCN">
				<h3 class="entry"><span class="ar">أَتَآءٌ</span></h3>
				<div class="sense" id="OataMCN_A1">
					<p><span class="ar">أَتَآءٌ</span>, <span class="auth">(T, Ṣ, M,)</span> or <span class="ar">إِتَآءٌ</span>, like <span class="ar">كِتَابٌ</span>, <span class="auth">(Ḳ, <span class="add">[but it is said in the M that the former is a subst. and the latter an inf. n.,]</span>)</span> <em>Increase;</em> syn. <span class="ar">نَمَآءٌ</span>, <span class="auth">(Ṣ, M, Ḳ, <span class="add">[in the CK <span class="ar">والثِّمَارِ</span> is erroneously put for <span class="ar">وَالنَّمَآءُ</span>,]</span>)</span> and <span class="ar">بَرَكَةٌ</span>: <span class="auth">(Ṣ:)</span> <em>increase, and produce,</em> or <em>net produce,</em> of land; as though from <span class="ar">الإِتَاوَةٌ</span> <a href="#xaraAjN">signifying <span class="ar">الخَرَاجُ</span></a>: <span class="auth">(TA:)</span> <em>gain,</em> or <em>revenue, arising from the increase of land,</em> or <em>from the rent thereof,</em> or <em>the like:</em> <span class="auth">(TA, and so in a copy of the Ṣ:)</span> the <em>produce of land,</em> and <em>fruits, &amp;c.:</em> <span class="auth">(Aṣ, T:)</span> <em>what is produced of the fruits</em> (<span class="ar">آكَال</span> <span class="add">[in the CK <span class="ar">اُكال</span>]</span>) <em>of trees:</em> <span class="auth">(M, Ḳ:)</span> the <em>fruit of palm-trees.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OataMCN_A2">
					<p><a href="#OatowN">See also <span class="ar">أَتْوٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatieBN">
				<h3 class="entry"><span class="ar">أَتِىٌّ</span></h3>
				<div class="sense" id="OatieBN_A1">
					<p><span class="ar">أَتِىٌّ</span> <span class="auth">(Ṣ, M, Ṣgh, Ḳ)</span> and <span class="ar">أُتِىٌّ</span> <span class="add">[respecting which see what follows]</span> and <span class="ar">إِتِىٌّ</span>, <span class="auth">(Ṣgh, Ḳ,)</span> of all which, the first is said by AʼObeyd to be the form used by the Arabs, <span class="auth">(TA,)</span> <span class="add">[and all belong to <a href="index.php?data=01_A/017_Ate">art. <span class="ar">اتى</span></a>, as well as to the present art.,]</span> and<span class="arrow"><span class="ar">أَتَاوِىٌّ↓</span></span> <span class="auth">(M, Ṣgh, Ḳ)</span> and <span class="ar">أُتَاوِىٌّ</span> and <span class="ar">إِتَاوِىٌّ</span>, <span class="auth">(Ṣgh, Ḳ,)</span> all these, and the three preceding them, mentioned by Ṣgh on the authority of AA, but the last of all said by him to be strange, <span class="auth">(TA,)</span> <em>A rivulet for which a man makes a way</em> or <em>channel,</em> or <em>an easy course</em> or <em>passage, to his land:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or a <em>torrent,</em> or <em>flow of water, from another region</em> or <em>quarter:</em> <span class="auth">(M, Ḳ: <span class="add">[both these meanings mentioned in the M in art. <span class="ar">اتو</span>, and the former in art. <span class="ar">اتى</span> also, of that work:]</span>)</span> or <span class="ar">أَتِىٌّ</span> signifies <em>a conduit of water;</em> and <em>any channel in which water is made to have an easy course;</em> as also <span class="ar">أُتِىٌّ</span>, mentioned by Sb; or, as some say, this is a pl.: <span class="auth">(M:)</span> or <em>any rivulet:</em> <span class="auth">(Aṣ, T:)</span> or <em>a rivulet less than the</em> <span class="add">[<em>trench called</em>]</span> <span class="ar">نُؤْى</span>: <span class="auth">(IB:)</span> and <span class="ar long">سَيْلٌ أَتىٌّ</span> <span class="auth">(Lḥ, T, Ṣ, M)</span> and <span class="ar">أَتَاوِىٌّ</span>, <span class="auth">(Lḥ, Ṣ, M,)</span> <em>a torrent,</em> or <em>flow of water, that comes one knows not whence:</em> <span class="auth">(M:)</span> or <em>that comes when the rain that has produced it has not fallen upon the people to whom it comes:</em> <span class="auth">(Lḥ, Ṣ, M:)</span> or <em>that comes from a land upon which rain has fallen to a land upon which rain has not fallen.</em> <span class="auth">(T, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتو</span> - Entry: <span class="ar">أَتِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OatieBN_A2">
					<p>Hence, <span class="auth">(T, M,)</span> or the reverse is the case, <span class="auth">(T, M, Mṣb,)</span> all the words above, <span class="auth">(AA, T, Ḳ,)</span> or <span class="ar">أَتِىَ</span> and <span class="ar">أَتَاوِىُّ</span>, <span class="auth">(Ṣ, M, Mgh, Mṣb, <span class="add">[the last said in the T to be the most approved,]</span>)</span> <em>A stranger;</em> or a man <em>not of one's own people,</em> or <em>not of one's own kindred:</em> <span class="auth">(AA, T, Ṣ, M, Mgh:)</span> or a man <em>who asserts his relation to a people of whom he is not:</em> <span class="auth">(Mṣb:)</span> or <span class="ar">أَتِىٌّ</span> signifies <em>one who is among a people of whom he is not:</em> <span class="auth">(Aṣ, T:)</span> and <span class="ar">أَتَاوِىٌّ</span>, <em>a stranger, who is not in his own country;</em> or, accord. to Ks, <em>a stranger, who is not in his own home:</em> <span class="auth">(T:)</span> the pl. of this last is <span class="ar">أَتَاوِيُّونَ</span>: <span class="auth">(Ṣ:)</span> <span class="add">[the fem. sing. is <span class="ar">أَتَاويَّةٌ</span>:]</span> and the pl. fem. <span class="ar">أَتَاويَّاتٌ</span>. <span class="auth">(T, Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IitaAwapN">
				<h3 class="entry"><span class="ar">إِتَاوَةٌ</span></h3>
				<div class="sense" id="IitaAwapN_A1">
					<p><span class="ar">إِتَاوَةٌ</span> <em>i. q.</em> <span class="ar">خَرَاجٌ</span> <span class="add">[i. e. <em>A tax, a tribute,</em> or <em>an impost</em>]</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> <em>such, for instance, as is levied on land,</em> <span class="auth">(TA in the present art.,)</span> and <em>such as is imposed on a slave;</em> <span class="auth">(TA in art. <span class="ar">ضرب</span>;)</span> and <em>any tax or other exaction that is taken by compulsion,</em> or <em>against the will,</em> or <em>that is apportioned to a people:</em> <span class="auth">(M: <span class="add">[in the TA “to a place” instead of “to a people:”]</span>)</span> and also, <em>a bribe:</em> or, <span class="auth">(accord. to some, M,)</span> particularly, <em>a bribe for water:</em> <span class="auth">(M, Ḳ:)</span> the pl. is <span class="ar">أَتَاوَى</span>, <span class="auth">(T, M, Ḳ, TA, <span class="add">[but in some copies of the Ḳ <span class="ar">أَتَاوِىُّ</span>, and accord. to copies of the Ṣ it is <span class="ar">أَتَاوٍ</span>, being written, with the article, <span class="ar">الأَتَاوِى</span>; both of which appear to be wrong; for it is said to be]</span>)</span> like <span class="ar">عَلَاوَى</span> and <span class="ar">هَرَاوَى</span>, pls. of <span class="ar">عِلَاوَةٌ</span> and <span class="ar">هِرَاوَةٌ</span>, <span class="auth">(M, TA,)</span> and like <span class="ar">سَكَارَى</span>; <span class="auth">(TA;)</span> changed, <span class="add">[in the accus. case, with the article prefixed,]</span> at the end of a verse, into <span class="ar">الأَتَاوِيَا</span>, for the sake of the rhyme: <span class="auth">(M, TA:)</span> this occurs in a verse of El-Jaadee: <span class="auth">(Ṣ:)</span> it has also for a pl. <span class="ar">إِتَاوَاتٌ</span>, <span class="auth">(T,)</span> and <span class="ar">أُتَّى</span>, <span class="add">[in the CK, erroneously, <span class="ar">اَتِىٌّ</span>,]</span> which is extr., <span class="auth">(M, Ḳ,)</span> as though its sing. were <span class="ar">أُتْوَةٌ</span>, being like <span class="ar">رُشَّى</span>, <a href="#ruXowapN">pl. of <span class="ar">رُشْوَةٌ</span></a>, <span class="auth">(M,)</span> and like <span class="ar">عُرَّى</span>, <a href="#EurowapN">pl. of <span class="ar">عُرْوَةٌ</span></a>. <span class="auth">(TA.)</span> You say, <span class="ar long">أَدَّى إِتَاوَةَ أَرْضِهِ</span> <span class="add">[<em>He payed the tax of his land</em>]</span>; i. e. <span class="ar">خَرَاجَهَا</span>: and <span class="ar long">ضُرِبَتْ عَلَيْهِمُ الإِتَاوَةُ</span> <span class="add">[<em>The tax,</em> or <em>tribute,</em> or <em>impost, was imposed upon them</em>]</span>; i. e. <span class="ar">الجِبَايَةُ</span>: and some assert it to be tropical. <span class="auth">(TA.)</span> You say also, <span class="ar long">شَكَمَ فَاهُ بِالْإِتَاوَةِ</span> <span class="add">[<em>He stopped</em> <span class="auth">(lit. <em>bitted</em>)</span> <em>his mouth with the bribe</em>]</span>; i. e. <span class="ar">بَالّرِشْوَةِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OataAwieBN">
				<h3 class="entry"><span class="ar">أَتَاوِىٌّ</span></h3>
				<div class="sense" id="OataAwieBN_A1">
					<p><span class="ar">أَتَاوِىٌّ</span> and its vars.: <a href="#OateBN">see <span class="ar">أَتىٌّ</span>, above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0014.pdf" target="pdf">
							<span>Lanes Lexicon Page 14</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0015.pdf" target="pdf">
							<span>Lanes Lexicon Page 15</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
