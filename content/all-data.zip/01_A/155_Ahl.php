<article class="root" id="Root_Ahl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/154_Ahb">اهب</a></span>
				<span class="ar">اهل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/156_Aw">او</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ahl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أهل</span></h3>
				<div class="sense" id="Ahl_1_A1">
					<p><span class="ar">أَهَلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْهُلُ</span>}</span></add>, inf. n. <span class="ar">أُهُولٌ</span>; <span class="auth">(Mṣb;)</span> or <span class="ar">أُهِلَ</span>, like <span class="ar">عُنِىَ</span>; <span class="auth">(Ḳ, TA;)</span> <em>It</em> <span class="auth">(a place, Mṣb, TA)</span> <em>was,</em> or <em>became, peopled,</em> or <em>inhabited.</em> <span class="auth">(Mṣb, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ahl_1_A2">
					<p><span class="ar">أَهَلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْهُلُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْهِلُ</span>}</span></add>, inf. n. as above, <em>He married,</em> or <em>took a wife;</em> <span class="auth">(Yoo, Ṣ, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">تأهّل↓</span></span>; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">ٱتَّهَلَ↓</span></span>, <span class="add">[written with the disjunctive alif <span class="ar">اِتَّهَلَ</span>, like <span class="ar">ٱتَّخَذَ</span> and <span class="ar">ٱتَّزَرَ</span> and <span class="ar">ٱتَمَنَ</span>, &amp;c.]</span>, <span class="auth">(Ḳ,)</span> of the measure <span class="ar">افتعل</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ahl_1_A3">
					<p><span class="ar">أَهَلَ</span>; <span class="auth">(Ks, Ṣ, Mṣb;)</span> or <span class="ar">أَهِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْهَلُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> or both; <span class="auth">(JK;)</span> <span class="ar">بِهِ</span>, <span class="auth">(JK,)</span> i. e. <span class="ar">بِالرَّجُلِ</span>, <span class="auth">(Ks, Ṣ,)</span> or <span class="ar">بِالشَّىْءِ</span>; <span class="auth">(Mṣb;)</span> <em>i. q.</em> <span class="ar">أَنِسَ</span> <span class="add">[<em>He was,</em> or <em>became, sociable, companionable, friendly, amicable,</em> or <em>familiar, with him,</em> i. e. <em>the man;</em> or <em>he was,</em> or <em>became, cheered,</em> or <em>gladdened, by his company</em> or <em>converse,</em> or <em>by his,</em> or <em>its</em> (<em>the thing's</em>) <em>presence</em>]</span>. <span class="auth">(JK, Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ahl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أهّل</span></h3>
				<div class="sense" id="Ahl_2_A1">
					<p><span class="ar long">أهّل بِهِ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">أهّلهُ</span>, <span class="auth">(Ḥam p. 184,)</span> inf. n. <span class="ar">تَأْهِيلٌ</span> <span class="auth">(Ḥam, Ḳ,)</span> <em>He said to him</em> <span class="ar">أَهْلًا</span>: <span class="auth">(Ḥam:)</span> or <em>he said to him</em> <span class="ar long">مَرْحَبًا وَأَهْلًا</span>: <span class="auth">(Ḳ:)</span> like <span class="ar long">رَحَّبَ بِهِ</span>: <span class="auth">(TA:)</span> <span class="add">[<a href="#OaholN">see <span class="ar">أَهْلٌ</span></a>:]</span> IB says that <span class="add">[the first pers. of]</span> the aor. of this verb is with fet-ḥ to the <span class="ar">ه</span> <span class="add">[contr. to rule: a strange assertion]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ahl_2_A2">
					<p><span class="ar long">أهّلهُ لِذٰلِكَ</span>, inf. n. as above; and<span class="arrow"><span class="ar">آهلهُ↓</span></span>; <em>He saw him, judged him, thought him,</em> or <em>held him, to be worthy,</em> or <em>deserving, of that; to merit it; to have a right,</em> or <em>just title</em> or <em>claim, to it:</em> <span class="auth">(Ḳ,* TA:)</span> or <em>he made him to be worthy,</em> or <em>deserving, of that;</em>, &amp;c. <span class="auth">(TA.)</span> You say, <span class="ar long">أَهَّلَكَ ٱللّٰهُ لِلْخَيْرِ</span> <span class="add">[<em>May God make thee worthy,</em> or <em>deserving, of good, good fortune, prosperity,</em> or <em>the like</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ahl_4">
				<h3 class="entry">4. ⇒ <span class="ar">آهل</span></h3>
				<div class="sense" id="Ahl_4_A1">
					<p><span class="ar long">آهَلَكَ ٱللّٰهُ فِى الجَنَّةِ</span>, inf. n. <span class="ar">إِيهَالٌ</span>, <em>May God make thee to enter with thy wife into Paradise:</em> <span class="auth">(AZ, Ṣ, TA:)</span> or <em>may God make thee to have a family in Paradise, and unite thee with them</em> <span class="add">[<em>therein</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ahl_4_A2">
					<p><a href="#Ahl_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ahl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأهّل</span></h3>
				<div class="sense" id="Ahl_5_A1">
					<p><a href="#Ahl_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ahl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتهل</span></h3>
				<div class="sense" id="Ahl_8_A1">
					<p><a href="#Ahl_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ahl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأهل</span></h3>
				<div class="sense" id="Ahl_10_A1">
					<p><span class="ar">استأهلهُ</span> as signifying <em>He was,</em> or <em>became, worthy,</em> or <em>deserving, of it,</em> or <em>he merited it,</em> or <em>he had a right,</em> or <em>just title</em> or <em>claim, to it,</em> is not allowable: <span class="auth">(Mṣb,* MF:)</span> not only does J disallow it, but the generality of those before him do so; saying that it is not chaste: in the Fṣ it is said to be of weak authority; and the expositors thereof confirm this assertion, saying that it occurs, but is inferior to other words in chasteness; and El-Ḥareeree asserts it to be erroneous: <span class="auth">(MF:)</span> or it is good in this sense; and J's disallowance of it is of no account: <span class="auth">(Ḳ:)</span> Az and Z and Ṣgh and others assert it to be good: and Az says, in the T, some have asserted the saying <span class="ar long">فُلَانٌ يَسْتَأْهِلُ أَنْ يُكْرَمَ أَوْ يُهَانَ</span>, as meaning <span class="add">[<em>Such a one</em>]</span> <em>is worthy,</em> or <em>deserving,</em> <span class="add">[<em>of being treated with honour, or of being held in light estimation,</em>]</span> to be erroneous; and <span class="ar">الاِسْتِئْهَالُ</span> to be only from <span class="ar">الإِهَالَةُ</span>; but I do not disallow it, nor charge with error him who says thus; for I have heard the verb thus used by a chaste Arab of the desert, of the BenooAsad, and there was present a number of Arabs of the desert who did not disapprove his saying: and this is confirmed by the saying in the Kur <span class="add">[lxxiv. 55]</span>,<span class="ar long">هُوَ أَهْلُ التَّقْوَى وَأَهْلُ المَغْفِرَةِ</span> <span class="add">[explained below: <a href="#Oaholu">see <span class="ar">أَهْلُ</span></a>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<span class="pb" id="Page_0121"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ahl_10_B1">
					<p><span class="ar">استأهل</span>, <span class="auth">(JK, Ḳ,)</span> or <span class="ar long">استأهل الأَهَالَةَ</span>, <span class="auth">(Mṣb,)</span> <em>He took the</em> <span class="ar">إِهَالَةَ</span>: <span class="auth">(JK, Ḳ:)</span> or <em>he ate the</em> <span class="ar">اهالة</span>: see this word below. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaholN">
				<h3 class="entry"><span class="ar">أَهْلٌ</span></h3>
				<div class="sense" id="OaholN_A1">
					<p><span class="ar">أَهْلٌ</span> <span class="add">[The <em>people</em> of a house or dwelling, and of a town or village, and of a country: and the <em>family</em> of a man:]</span> a man's <em>cohabitants of one dwelling</em> or <em>place of abode,</em> <span class="auth">(Er-Rághib, Kull p. 84,)</span> and <em>of one town</em> or <em>country:</em> <span class="auth">(Er-Rághib:)</span> afterwards applied to a man's <em>fellow-members of one family</em> or <em>race,</em> and <em>of one religion,</em> and <em>of one craft</em> or <em>art</em> or <em>the like:</em> <span class="auth">(Er-Rághib, Kull:)</span> or, as some say, <em>relations, whether they have followers</em> or <em>dependents, or not;</em> whereas <span class="ar">آلٌ</span> signifies relations with their followers or dependents: <span class="auth">(Kull:)</span> or it originally signifies <em>relations:</em> and sometimes is applied to <em>followers</em> or <em>dependents:</em> and signifies also the <span class="ar">أَهْل</span> <span class="add">[i. e. <em>people,</em> or <em>inhabitants,</em> or <em>family,</em>]</span> <em>of a house</em> or <em>tent:</em> <span class="auth">(Mṣb:)</span> or a man's <em>nearer,</em> or <em>nearest, relations by descent from the same father or ancestor;</em> or his <em>kinsfolk;</em> his <em>relations:</em> <span class="auth">(Ḳ:)</span> or, accord. to <span class="add">[the Imám]</span> Moḥammad, a man's <em>wife</em> <span class="add">[or <em>wives</em>]</span> <em>and</em> his <em>children and household who are the objects of</em> his <em>expenditure;</em> and thus, <em>any brother and sister,</em> or <em>paternal uncle and son of a paternal uncle,</em> or <em>strange</em> or <em>distantly-related child, whom a man feeds or sustains in his abode:</em> the <em>most particular,</em> or <em>most special, dependents,</em> or <em>the like,</em> of a man: on the authority of El-Ghooree: <span class="auth">(Mgh:)</span> <span class="add">[J indicates some of these meanings merely by saying that it signifies]</span> the <span class="ar">أَهْل</span> of a man, and the <span class="ar">أَهْل</span> of a house; as also<span class="arrow"><span class="ar">أَهْلَةٌ↓</span></span>: <span class="auth">(Ṣ:)</span> <span class="add">[<a href="#AlN">see also <span class="ar">آلٌ</span></a>; in the explanations of which, certain distinctions between it and <span class="ar">أَهْلٌ</span> will be found mentioned:]</span> the pl. is <span class="ar">أَهْلُونَ</span>, <span class="add">[like <span class="ar">أَرْضُونَ</span>, a form sometimes used for <span class="ar">أَرَضُونَ</span>]</span> <span class="auth">(Mgh, Mṣb, Ḳ,)</span> and <span class="ar">أَهَالٍ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> with an additional <span class="ar">ى</span> <span class="add">[implied by the tenween, and expressed in the accus. case, and when the word is determinate, as in <span class="ar">الأَهَالِى</span>,]</span> <span class="auth">(Ṣ,)</span> contr. to rule, <span class="auth">(Ṣ, Mgh,)</span> like <span class="ar">لَيَالٍ</span>, <a href="#laYolN">pl. of <span class="ar">لَيْلٌ</span></a>, <span class="auth">(Ṣ,)</span> <span class="add">[and like <span class="ar">أَرَاض</span>, respecting which and <span class="ar">ليَالٍ</span> and <span class="ar">أَهَالٍ</span>, <a href="#OaroDN">see <span class="ar">أَرْضٌ</span></a>,]</span> and <span class="ar">آهَالٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> a pl. <span class="add">[of pauc.]</span> sometimes occurring in poetry, <span class="auth">(Ṣ,)</span> <span class="add">[like <span class="ar">آرَاضٌ</span>,]</span> and <span class="ar">أَهْلَاتٌ</span> and <span class="ar">أَهَلَاتٌ</span> <span class="add">[as though pls. of <span class="ar">أَهْلَةٌ</span>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaholN_A2">
					<p><span class="ar long">أَهْلُ البَيْتِ</span> The <span class="add">[<em>people</em> or]</span> <em>inhabitants</em> <span class="add">[or <em>family</em>]</span> <em>of the house</em> or <em>tent.</em> <span class="auth">(Mgh, Ḳ.)</span> But <span class="ar long">أَوْصَى لأَهْلِ بَيْتِهِ</span> means the same as <span class="ar long">اوصى لِجِنْسِهِ</span>, i. e. <em>He left by will,</em> of his property, <em>to the children of his father,</em> <span class="add">[or <em>his kindred by the father's side,</em>]</span> <em>exclusively of all relations of the mother.</em> <span class="auth">(Mgh in art. <span class="ar">جنس</span>.)</span> <span class="add">[<a href="#OaholN_A13">See also <span class="ar long">أَهْلُ الرَّجُلِ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaholN_A3">
					<p><span class="ar long">أَهْلَ القُرَى</span> <em>The</em> <span class="add">[<em>people</em> or]</span> <em>inhabitants of the towns</em> or <em>villages.</em> <span class="auth">(TA.)</span> And <span class="ar long">أَهْلُ البَلَدِ</span> <em>The settled,</em> or <em>constant, inhabitants of the country</em> or <em>town.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أَهْلُ الحَضَرِ</span> <em>The people of the region,</em> or <em>regions, of cities, towns,</em> or <em>villages, and of cultivated land.</em> <span class="auth">(A in art. <span class="ar">حضر</span>.)</span> And <span class="ar long">أَهْلُ المَدَرِ وَالوَبَرِ</span> <span class="auth">(Ṣ in art. <span class="ar">مدر</span>, &amp;c.)</span> <span class="add">[<em>The people of the towns</em> or <em>villages,</em> or]</span> <em>the inhabitants of the buildings, and of the tents,</em> <span class="auth">(Kull,)</span> or <em>deserts.</em> <span class="auth">(TA in art. <span class="ar">وبر</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaholN_A4">
					<p><span class="add">[<span class="ar long">أَهْلُ القُبُورِ</span>, and <span class="ar">المَقَابِرِ</span>, <em>The people of the graces,</em> and <em>of the places of graves;</em> i. e., <em>those buried therein.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaholN_A5">
					<p><span class="add">[<span class="ar long">أَهْلُ الجَنَّةِ</span> <em>The people of Paradise.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaholN_A6">
					<p><span class="add">[<span class="ar long">أَهْلُ النَّارِ</span> <em>The people of the fire,</em> i. e., <em>of Hell.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaholN_A7">
					<p><a href="#OahilapN">See also <span class="ar">أَهِلَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaholN_A8">
					<p>The following is an ex. of <span class="ar">اهل</span> as explained above in the first sentence on the authority of the Ḳ: <span class="ar long">الأَهْلُ إِلَى الأَهْلِ أَسْرَعُ مِنَ السِّيلِ إِلَى السَّهْلِ</span> a prov. <span class="add">[meaning <em>Kinsfolk are quicker of tendency to kinsfolk than the torrent to the plain</em>]</span>. <span class="auth">(TA.)</span> So, too, a saying of a poet cited voce <span class="ar">خَفْضٌ</span>. <span class="auth">(TA.)</span> <span class="add">[And]</span> <span class="ar long">أَهْلَكَ وَاللَّيْلَ</span> a prov. meaning <span class="ar long">بَادِر أَهْلَكَ وَٱحْذَرِ اللَّيْلَ وَظُلْمَتَهُ</span> <span class="add">[<em>Betake thyself early to thy family, and beware of the night and its darkness</em>]</span>. <span class="auth">(Ḥar p. 175.)</span> <span class="add">[And]</span> <span class="ar long">مَرْحَبًا وَأَهْلًا</span> <span class="auth">(Ṣ, Ḳ)</span> a saying meaning <em>Thou hast come to an ample,</em> or <em>a spacious,</em> or <em>roomy, place, and to</em> <span class="add">[people like thine own]</span> <em>kinsfolk;</em> therefore be cheerful, or sociable, not sad, or shy: <span class="auth">(Ṣ:)</span> or <em>thou hast found,</em> or <em>met with,</em> <span class="add">[<em>an ample,</em> or <em>a spacious,</em> or <em>roomy, place, and</em>]</span> <em>kinsfolk, not strangers.</em> <span class="auth">(Ḳ.)</span> <span class="add">[And]</span> <span class="ar long">أَهْلًا وَسَهْلًا وَمَرْحَبًا</span> <em>Thou hast come to a people who are</em> <span class="add">[like]</span> <em>kinsfolk, and to a place that is plain, even, not rugged, and that is ample, spacious,</em> or <em>roomy;</em> therefore rejoice thyself, and be not sad, or shy. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaholN_A9">
					<p><span class="ar long">أَهْلُ النَّبِىِّ</span> <em>The</em> <span class="add">[<em>family</em> or]</span> <em>wives and daughters of the Prophet, and his son-in-law ʼAlee:</em> or <em>his women; and</em> <span class="auth">(as some say, TA)</span> <em>the men who are his</em> <span class="ar">آل</span>; <span class="auth">(Ḳ, TA;)</span> <em>comprising the grandchildren</em> (<span class="ar">أَحْفَاد</span>) <em>and</em> <span class="add">[<em>other</em>]</span> <em>progeny:</em> and so <span class="ar long">أَهْلُ البَيْتِ</span> as used in the Ḳur xxxiii. 33, occurring also <span class="add">[in a like sense]</span> in xi. 76: <span class="auth">(TA:)</span> and <span class="ar">الأَهْلُ</span> is conventionally applied to <em>the nearer,</em> or <em>nearest, kinsfolk of the Prophet.</em> <span class="auth">(Er-Rághib.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="OaholN_A10">
					<p><span class="ar long">أَهْلُ كُلِّ نَبِىٍّ</span> also means <em>The people to whom any prophet is sent;</em> <span class="auth">(Ḳ, TA;)</span> and <em>those who are of his religion.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="OaholN_A11">
					<p>In the phrase <span class="ar long">آلٌ ٱللّٰهِ وَرَسُولِهِ</span>, meaning <em>The friends,</em> or <em>the like,</em> (<span class="ar">أَوْلِيَآء</span> Ḳ, TA,) and <em>the assistants,</em> <span class="auth">(TA,)</span> <em>of God and of his apostle,</em> the first word is originally <span class="ar">أَهْل</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="OaholN_A12">
					<p><span class="ar long">أَهْلُ ٱللّٰهِ</span> is also an appellation which used to be applied to <em>The readers</em> or <em>reciters</em> <span class="add">[<em>of the Ḳur-án</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="OaholN_A13">
					<p><span class="ar long">أَهْلُ الرَّجُلِ</span> also signifies ‡ <em>The man's wife;</em> <span class="auth">(Mgh,* Mṣb,* Ḳ;)</span> as well as <em>his wife and children;</em> <span class="auth">(TA;)</span> <span class="add">[so, too, in the present day, <span class="ar long">أَهْلُ بَيْتِ الرَّجُلِ</span>;]</span> and so, too, <span class="arrow"><span class="ar">أَهْلَتُهُ↓</span></span>. <span class="auth">(Ḳ.)</span> Hence the phrase <span class="ar long">بَنَى عَلَى أَهْلِهِ</span> <span class="add">[<a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>]</span>: <span class="auth">(Kull:)</span> and <span class="ar long">دَخَلَ بِأَهْلِهِ</span> and <span class="ar long">دَخَلَ عَلَى أَهْلِهِ</span> <span class="add">[<a href="index.php?data=08_d/034_dxl">see art. <span class="ar">دخل</span></a>]</span>. <span class="auth">(Ḥar p. 502;, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="OaholN_A14">
					<p><span class="ar long">أَهْلُ مَذْهَبٍ</span> <span class="add">[<em>The people of,</em> or]</span> <em>those who follow,</em> <span class="auth">(Ḳ, TA,)</span> <em>and believe,</em> <span class="auth">(TA,)</span> <em>a certain persuasion,</em> or <em>body of tenets.</em> <span class="auth">(Ḳ, TA.)</span> <span class="add">[Hence,]</span> <span class="ar long">أَهْلُ السُّنَةِ</span> <span class="add">[<em>Those who conform to the institutes of Moḥammad</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[And]</span> <span class="ar long">أَهْلُ الأَهْوَآءِ</span> <span class="add">[<em>The people of erroneous opinions;</em>]</span> <em>those whose belief is not that of the class termed</em> <span class="ar long">أَهْلُ السُّنَّةِ</span>, <em>but who hare the same</em> <span class="ar">قِبْلَة</span>. <span class="auth">(TA.)</span> <span class="add">[And]</span> <span class="ar long">أَهْلُ الإِسْلَامِ</span> <em>Those who follow the religion of El-Islám.</em> <span class="auth">(Mgh.)</span> <span class="add">[And]</span> <span class="ar long">أَهْلُ القُرْآنِ</span> <em>Those who read,</em> or <em>recite, the Ḳur-án, and perform the duties enjoined thereby.</em> <span class="auth">(Mgh.)</span> <span class="add">[And]</span> <span class="ar long">أَهْلُ الكِتَابِ</span> <span class="add">[<em>The people of the Scripture,</em> or <em>Bible:</em> and]</span> <em>the readers,</em> or <em>reciters, of the Mosaic Law, and of the Gospel.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="OaholN_A15">
					<p><span class="ar long">أَهْلُ العِلْمِ</span> <span class="add">[<em>The people of knowledge,</em> or <em>science;</em>]</span> <em>those who are characterized by knowledge,</em> or <em>science.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="OaholN_A16">
					<p><span class="ar long">أَهْلُ الأَمْرِ</span> <span class="add">[<em>The possessors of command:</em> or]</span> <em>those who superintend the affairs</em> <span class="add">[<em>of others</em>]</span>; <span class="auth">(Ḳ, TA;)</span> like <span class="ar">أُلُوالأَمرِ</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A17</span>
				</div>
				<div class="sense" id="OaholN_A17">
					<p><span class="ar long">أَهْلُ المَرَاتِبِ</span> <span class="add">[<em>The people of exalted stations, posts of honour,</em> or <em>dignities</em>]</span>. <span class="auth">(TA in art. <span class="ar">رتب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A18</span>
				</div>
				<div class="sense" id="OaholN_A18">
					<p><span class="ar long">أَهْلُ الذِّمَّةِ</span> <span class="auth">(Mgh in art. <span class="ar">ذم</span>)</span> and <span class="ar long">أَهْلُ العَهْدِ</span> <span class="auth">(TA in art. <span class="ar">عهد</span>)</span> <em>Those persons,</em> <span class="auth">(Mgh, TA,)</span> <em>of the unbelievers,</em> <span class="auth">(Mgh,)</span> <span class="add">[namely, <em>Christians, Jews,</em> and <em>Sabians,</em> but no others,]</span> <em>who have a compact,</em> or <em>covenant, with the Muslims,</em> <span class="auth">(Mgh, TA,)</span> <em>paying a poll-tax, whereby they are secure of their property and blood,</em> <span class="auth">(Mgh,)</span> or <em>whereby the Muslims are responsible for their security</em> <span class="add">[<em>and freedom and toleration</em>]</span> <em>as long as they act agreeably to the compact.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A19</span>
				</div>
				<div class="sense" id="OaholN_A19">
					<p><span class="ar">أَهْلٌ</span> also signifies The <em>possessors,</em> or <em>owners,</em> of property: as in the Ḳur iv. 61. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A20</span>
				</div>
				<div class="sense" id="OaholN_A20">
					<p><span class="ar long">أَهْلٌ لِكَذَا</span> A person, <span class="auth">(Ṣ, Ḳ,)</span> and persons, for it is used as a sing. and as a pl., <span class="auth">(Ḳ,)</span> <em>having a right,</em> or <em>just title, to such a thing; entitled thereto; worthy,</em> or <em>deserving, thereof; meet,</em> or <em>fit, for it:</em> <span class="auth">(Ṣ, Ḳ:)</span> the vulgar say <span class="arrow"><span class="ar">مُسْتَأْهِلٌ↓</span></span>, which is not allowable: <span class="auth">(Ṣ:)</span> or this assertion of J's is of no account. <span class="auth">(Ḳ: <a href="#Ahl_10">see 10</a>.)</span> You say, <span class="ar long">هُو أَهْلٌ لِإِكْرَامِ</span> <em>He is entitled to be,</em> or <em>worthy of being, treated with honour.</em> <span class="auth">(Mṣb.)</span> And<span class="arrow"><span class="ar long">هُوَ أَهْلَةٌ↓ لِكُّلِ خَيْر</span></span> <span class="add">[<em>He is entitled to,</em> or <em>worthy of, all that is good</em>]</span>. <span class="auth">(Ibn-ʼAbbád.)</span> And<span class="arrow"><span class="ar long">أَهلَةٌ↓ وُدٍّ</span></span> <em>He who is,</em> or <em>they who are, entitled to,</em> or <em>worthy of, love,</em> or <em>affection.</em> <span class="auth">(Ṣ, Ṣgh.)</span> And hence, in the Ḳur <span class="add">[lxxiv. last verse]</span>, <span class="ar long">هُوَ أَهْلُ التَّقْوَى وَأَهْلُ المَغْفِرَةِ</span> <span class="auth">(TA)</span> <em>He is the Being entitled to be regarded with pious fear, and the Being entitled to forgive</em> those who so regard Him. <span class="auth">(Jel.)</span> In the phrase <span class="ar long">أهْلَ الثَنَآءِ وَالمَجْدِ</span> <span class="add">[<em>0 Thou who art the Being entitled to praise and glory</em>]</span>, occurring in a form of prayer, the first word is mansoob as a vocative: and it may be marfooa, as the enunciative of an inchoative suppressed; i. e. <span class="ar long">أَنْتَ أَهْلُ</span> <span class="add">[<em>Thou art the Being entitled</em>, &amp;c.]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A21</span>
				</div>
				<div class="sense" id="OaholN_A21">
					<p><span class="add">[Frequently, also, <span class="ar">أَهْلٌ</span> signifies The <em>author,</em> or, more commonly, <em>authors,</em> of a thing; like <span class="ar">صَاحِبٌ</span> and <span class="ar">أَصْحَابٌ</span>; as in <span class="ar long">أَهْلُ البِدَعِ</span> <em>The author,</em> or <em>authors, of innovations;</em> and <span class="ar long">أَهْلُ الظُّلْمِ</span> <em>The author,</em> or <em>authors, of wrong.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OahilN">
				<h3 class="entry"><span class="ar">أَهِلٌ</span></h3>
				<div class="sense" id="OahilN_A1">
					<p><span class="ar">أَهِلٌ</span>: <a href="#OaholiyeN">see <span class="ar">أَهْلِيىٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaholapN">
				<h3 class="entry"><span class="ar">أَهْلَةٌ</span></h3>
				<div class="sense" id="OaholapN_A1">
					<p><span class="ar">أَهْلَةٌ</span>: <a href="#OaholN">see <span class="ar">أَهْلٌ</span></a>, in four places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">أَهْلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaholapN_B1">
					<p><a href="#OahlapN">and see <span class="ar">أَهلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OahilapN">
				<h3 class="entry"><span class="ar">أَهِلَةٌ</span></h3>
				<div class="sense" id="OahilapN_A1">
					<p><span class="ar">أَهِلَةٌ</span> <em>i. q.</em> <span class="ar">مَالٌ</span> <span class="add">[<em>Property;</em> or <em>cattle</em>]</span>: so in the saying <span class="ar long">إِنَّهُمْ لَأَهْلُ أَهِلَةٍ</span> <span class="auth">(JK, Ḳ)</span> <span class="add">[app. meaning <em>Verily they are sojourners,</em> or <em>settlers, possessed of property,</em> or <em>cattle</em>]</span>: <span class="arrow"><span class="ar">أَهْلٌ↓</span></span> here signifying <span class="ar">حُلُولٌ</span> <span class="add">[<a href="#HaAlBN">pl. of <span class="ar">حَالٌّ</span></a>]</span>. <span class="auth">(JK, TA.)</span> <span class="add">[But]</span> Yoo says that <span class="arrow"><span class="ar long">هُمْ أَهْلُ أَهْلَةِ↓</span></span> and <span class="ar">أَهِلَةٍ</span> means <em>They are people of the distinguished sort.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaholieBN">
				<h3 class="entry"><span class="ar">أَهْلِىٌّ</span></h3>
				<div class="sense" id="OaholieBN_A1">
					<p><span class="ar">أَهْلِىٌّ</span> A <em>domestic</em> beast <span class="add">[or bird]</span>; a beast <span class="add">[or bird]</span> <em>that keeps to the dwelling</em> <span class="add">[<em>of its owner</em>]</span>; <span class="auth">(JK, Mṣb, Ḳ, TA;)</span> <span class="pb" id="Page_0122"></span><em>contr. of</em> <span class="ar">وَحْشِىٌّ</span>; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">أَهِلٌ↓</span></span>. <span class="auth">(Ḳ.)</span> You say <span class="ar long">حُمُرٌ أَهْلِيَّةٌ</span> <span class="add">[<em>Domestic asses</em>]</span>: <span class="auth">(JK, TA:)</span> occurring in a trad., in which their flesh is forbidden to be eaten. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaholiyBapN">
				<h3 class="entry"><span class="ar">أَهْلِيَّةٌ</span></h3>
				<div class="sense" id="OaholiyBapN_A1">
					<p><span class="ar">أَهْلِيَّةٌ</span> The <em>quality of having a right,</em> or <em>just title,</em> to a thing; <em>worthiness,</em> or <em>desert; meetness,</em> or <em>fitness;</em> in Pers. <span class="ar">سَزَوَارِى</span>: <span class="auth">(Golius, app. from a gloss. in a copy of the KL:)</span> the <em>state,</em> or <em>quality, of meetness,</em> or <em>fitness,</em> <span class="add">[of a person,]</span> <em>for the bindingness of the rights which the law imposes for one</em> or <em>upon him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IihaAlapN">
				<h3 class="entry"><span class="ar">إِهَالَةٌ</span></h3>
				<div class="sense" id="IihaAlapN_A1">
					<p><span class="ar">إِهَالَةٌ</span> <em>Grease:</em> <span class="auth">(Ṣ:)</span> or <em>melted grease:</em> <span class="auth">(Mṣb:)</span> or <em>fat:</em> or <em>melted fat:</em> or <em>olive-oil:</em> and <em>anything that is used as a seasoning</em> or <em>condiment:</em> <span class="auth">(Ḳ:)</span> <em>such as fresh butter,</em> and <em>fat,</em> and <em>oil of sesame:</em> <span class="auth">(TA:)</span> or <em>melted fat of a sheep's tail</em> and <em>the like.</em> <span class="auth">(JK.)</span> <a href="#saroEaAna">Hence, <span class="ar long">سَرْعَانَ ذَا إِهَالَةٌ</span></a>, a prov., <a href="index.php?data=12_s/094_srE">mentioned in art. <span class="ar">سرع</span></a>; <span class="auth">(Ḳ,* TA;)</span> or, as some say, <span class="ar">وَشْكَانَ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MhilN">
				<h3 class="entry"><span class="ar">آهِلٌ</span></h3>
				<div class="sense" id="MhilN_A1">
					<p><span class="ar">آهِلٌ</span>, <span class="auth">(JK, Ṣ, Mṣb, Ḳ,)</span> <span class="add">[said by those unacquainted with the verb <span class="ar">أَهَلَ</span> in the first of the senses explained in this art. to be]</span> a kind of rel. n., <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">مَأْهُولٌ↓</span></span>, <span class="auth">(JK, Ḳ,)</span> A place <em>peopled,</em> or <em>inhabited:</em> <span class="auth">(Mṣb:)</span> or a place <em>having people:</em> <span class="auth">(JK:)</span> or the former has this signification; and the latter signifies <em>having its people in it:</em> <span class="auth">(ISk, Ḳ:)</span> or the former has this last signification: <span class="auth">(Yoo, Ṣ:)</span> pl. of the latter <span class="ar">مَآهِلُ</span>, occurring in a poem of Ru-beh <span class="add">[app. by poetic licence for <span class="ar">مَآهِيلُ</span>]</span>. <span class="auth">(TA.)</span> You say <span class="ar long">قَرْيَةٌ آهِلَةٌ</span> <em>A peopled,</em> or <em>inhabited, town</em> or <em>village.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">أَمْسَتْ نِيرَانُهُمْ آهِلَةٌ</span> <em>Their fires became in the evening attended by many people.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOohuwlN">
				<h3 class="entry"><span class="ar">مَأْهُولٌ</span></h3>
				<div class="sense" id="maOohuwlN_A1">
					<p><span class="ar">مَأْهُولٌ</span>: <a href="#AhilN">see <span class="ar">آهِلٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">مَأْهُولٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maOohuwlN_B1">
					<p><span class="ar long">ثَرِيدَةٌ مَأْهُولَةٌ</span> <span class="add">[<em>A mess of crumbled bread</em>]</span> <em>having much</em> <span class="ar">إِهَالَة</span>, q. v. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOahBilN">
				<h3 class="entry"><span class="ar">مُتَأَهِّلٌ</span></h3>
				<div class="sense" id="mutaOahBilN_A1">
					<p><span class="ar">مُتَأَهِّلٌ</span> <em>Having a wife.</em> <span class="auth">(Ḥar p. 571.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotaOohilN">
				<h3 class="entry"><span class="ar">مُسْتَأْهِلٌ</span></h3>
				<div class="sense" id="musotaOohilN_A1">
					<p><span class="ar">مُسْتَأْهِلٌ</span>: <a href="#OaholN">see <span class="ar">أَهْلٌ</span></a>; latter part of the paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اهل</span> - Entry: <span class="ar">مُسْتَأْهِلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="musotaOohilN_B1">
					<p>Also <em>Taking,</em> or <em>eating,</em> <span class="ar">إِهَالَة</span>, q. v. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0120.pdf" target="pdf">
							<span>Lanes Lexicon Page 120</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0121.pdf" target="pdf">
							<span>Lanes Lexicon Page 121</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0122.pdf" target="pdf">
							<span>Lanes Lexicon Page 122</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
