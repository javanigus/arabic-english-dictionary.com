<article class="root" id="Root_Amt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/129_AmA">اما</a></span>
				<span class="ar">امت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/131_Amd">امد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Amt_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمت</span></h3>
				<div class="sense" id="Amt_1_A1">
					<p><span class="ar">أَمَتَهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْمِتُ</span>}</span></add>, <span class="auth">(T, M, Ḳ,)</span> inf. N. <span class="ar">أَمْتٌ</span>, <span class="auth">(T, Ṣ, M,)</span> <em>He measured it; determined its measure, quantity,</em> or <em>the like; computed,</em> or <em>conjectured, its measure, quantity,</em>, &amp;c.; <span class="auth">(T, Ṣ,* M, Ḳ;)</span> as also<span class="arrow"><span class="ar">امّتهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَأْمِيتٌ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">اِيمِتْ يَا فُلَانُ هٰذَا لِى كَمْ هُوَ</span> <em>Compute thou, O such a one, this, for me, how many it is.</em> <span class="auth">(T.)</span> And <span class="ar long">أَمَتَ القَوْمَ</span> <em>He computer,</em> or <em>conjectured, the number of the people,</em> or <em>company of men.</em> <span class="auth">(T.)</span> And <span class="ar long">أَمَتَ المَآءَ</span> <em>He measured,</em> or <em>computed, the distance between him and the water.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امت</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amt_1_A2">
					<p>Also, <span class="auth">(Ṣ, Ḳ,)</span> aor. as above, <span class="auth">(Ḳ,)</span> and so the inf. n., <span class="auth">(Ṣ,)</span> <em>i. q.</em> <span class="ar">قَصَدَهُ</span> <span class="add">[<em>He tended, repaired, betook himself,</em> or <em>directed his course, to it,</em> or <em>towards it; aimed at it; sought after it;</em> or <em>intended,</em> or <em>purposed, it</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> namely, a thing. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amt_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّت</span></h3>
				<div class="sense" id="Amt_2_A1">
					<p><span class="ar">أمّتهُ</span>: <a href="#Amt_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امت</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amt_2_A2">
					<p><span class="ar long">أُمِّتَ بِالشَّرِّ</span> <em>He was suspected of evil.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamotN">
				<h3 class="entry"><span class="ar">أَمْتٌ</span></h3>
				<div class="sense" id="OamotN_A1">
					<p><span class="ar">أَمْتٌ</span> <em>A measure of distance</em> <span class="add">[&amp;c.]</span>; as in the saying, <span class="ar long">كَمْ أَمْتُ بَيْنَكَ مَا بَيْنَ الكُوفَةِ</span> <em>What is the measure of the distance between thee and El-Koofeh?</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">أَمْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OamotN_B1">
					<p><em>Doubt:</em> <span class="auth">(Th, T, M:)</span> said to be so termed because this word signifies the “computing, or conjecturing, measure, quantity, and the like,” in which there is doubt. <span class="auth">(T, TA.)</span> <span class="add">[<a href="#Amt_1">See 1</a>.]</span> So in the following ex.: <span class="ar long">الخَمْرُ حَرُمَتْ لَا أَمْتَ فِيهَا</span> <em>Wine is unlawful: there is no doubt respecting</em> the unlawfulness of <em>it:</em> <span class="auth">(Sh, Th, T, Ḳ:)</span> or the meaning is, <em>there is no indulgence,</em> or <em>lenity, with respect to it;</em> from <span class="ar">أَمْتٌ</span> as signifying “feebleness, or weakness,” in a journey, or pace. <span class="auth">(T, TA.)</span> <span class="pb" id="Page_0095"></span>And in the saying, <span class="ar long">لَيْسَ فى الخَمْرِ أَمْتٌ</span> <em>There is no doubt respecting wine,</em> that it is unlawful. <span class="auth">(Th, M.)</span> <span class="add">[Or in the like of these two instances it signifies]</span> <em>Disagreement,</em> or <em>diversity of opinion,</em> (<span class="ar">اِخْتِلَافٌ</span>,) respecting a thing (<span class="ar long">فِى شَىْءٍ</span>). <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">أَمْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="OamotN_C1">
					<p><em>Curvity, crookedness, distortion,</em> or <em>unevenness:</em> <span class="auth">(M, Ḳ:)</span> <em>ruggedness in one place and smoothness in another;</em> <span class="auth">(Ḳ;)</span> <span class="add">[<em>inequality of surface;</em>]</span> <em>one part being higher,</em> or <em>more prominent, than another:</em> <span class="auth">(TA:)</span> <em>an elevated place:</em> <span class="auth">(T, Ṣ, Ḳ:)</span> <em>small mounds:</em> <span class="auth">(Fr, Th, T, Ṣ, M, Ḳ:)</span> or <em>what is elevated, of ground:</em> or, as some say, <em>water-courses of valleys, such as are low,</em> or <em>depressed:</em> <span class="auth">(Fr, T, TA:)</span> <em>small hills; hillocks:</em> <span class="auth">(M, TA:)</span> <em>a hollow,</em> or <em>depressed place, between any two elevated portions of ground</em>, &amp;c.: <span class="auth">(IAạr, T, M:)</span> <em>depression and elevation,</em> or <em>lowness and highness,</em> <span class="auth">(Ṣ, M, A, Ḳ,)</span> in the ground; <span class="auth">(A;)</span> used in this sense in the Ḳur xx. 106; <span class="auth">(Ṣ;)</span> and the same in a water-skin not completely filled: <span class="auth">(Ṣ, A:*)</span> or <em>laxity in a water-skin when it is not well filled so as to overflow:</em> <span class="auth">(T,* TA:)</span> or <em>a</em> <span class="add">[<em>consequence of</em>]</span> <em>pouring</em> <span class="add">[<em>water</em>]</span> <em>into a skin until it doubles,</em> or <em>creases, and not filling it; so that one part of it is higher,</em> or <em>more prominent, than another:</em> <span class="auth">(M, TA:)</span> pl. <span class="ar">إِمَاتٌ</span> <span class="auth">(M, Ḳ, TA, but in some copies of the Ḳ <span class="ar">آمَاتٌ</span>, and in the CK <span class="ar">اَماتٌ</span>,)</span> and <span class="ar">أُمُوتٌ</span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">اسْتَوَتِ الأَرْضُ فَمَا بَهَا أَمْتٌ</span> <em>The earth,</em> or <em>ground, was even, so that there was not in it any depression and elevation.</em> <span class="auth">(A, TA.)</span> And <span class="ar long">اِمْتَلَأَ السِّقَآءُ فَمَا بِهِ أَمْتٌ</span> <em>The skin became full, so that there was not in it any depression </em> <span class="add">[<em>of one part of its surface</em>]</span> <em>and elevation</em> <span class="add">[<em>of another part</em>]</span>. <span class="auth">(Ṣ, A.*)</span> Az says, <span class="auth">(TA,)</span> I have heard the Arabs say, <span class="ar long">قَدْ مَلَأَ القِرْبَةَ مَلْأً لَا أَمْتَ فِيهِ</span> <em>He had filled the water-skin so full that there was no laxity in it.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">أَمْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="OamotN_C2">
					<p><em>A fault, a defect, an imperfection, a blemish,</em> or <em>the like,</em> <span class="auth">(T, M, Ḳ,)</span> in the mouth, and in a garment, or piece of cloth, and in a stone. <span class="auth">(M, Ḳ.)</span> <span class="add">[Hence the saying,]</span> <span class="ar long">أَمْتٌ فِى الحَجَرِ لَا فِيكَ</span> i. e. <span class="add">[<em>May there be a defect,</em> or <em>the like,</em>]</span> <em>in stones; not in thee:</em> meaning, may God preserve thee when the stones shall have perished: <span class="auth">(Sb, M:)</span> <span class="ar">امت</span> is here put in the nom. case, though the phrase is significant of a prayer, because it is not a verbal word: the phrase is like <span class="ar long">التُّرابُ لَهْ</span>: and the commencing the sentence with an indeterminate noun is approvable because it is virtually a prayer. <span class="auth">(M.)</span> This prov. is mentioned by the expositors of the Tes-heel: not by Meyd. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">أَمْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="OamotN_C3">
					<p><em>Weakness; feebleness;</em> <span class="auth">(T, Ḳ;)</span> <em>langour; remissness.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">سِرْنَا سَيْرًا لَا أَمْتَ فِيهِ</span> <em>We performed a journey,</em> or <em>went a pace, in which was no weakness,</em> or <em>feebleness</em> <span class="add">[&amp;c.]</span>. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">أَمْتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="OamotN_D1">
					<p><em>A good way, course, mode,</em> or <em>manner, of acting,</em> or <em>conduct,</em> or <em>the like.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWamBatN">
				<h3 class="entry"><span class="ar">مُؤَمَّتٌ</span></h3>
				<div class="sense" id="muWamBatN_A1">
					<p><span class="ar">مُؤَمَّتٌ</span> <em>Suspected</em> of evil and the like. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#Amt_2">See 2</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">مُؤَمَّتٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWamBatN_B1">
					<p><span class="add">[A water-skin]</span> <em>filled</em> <span class="add">[<em>so as to be equally distended:</em> <a href="#OamotN">see <span class="ar">أَمْتٌ</span></a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomuwtN">
				<h3 class="entry"><span class="ar">مَأْمُوتٌ</span></h3>
				<div class="sense" id="maOomuwtN_A1">
					<p><span class="ar long">مَآءٌ مَأْمُوتٌ</span> <em>A water of which the distance is computed,</em> or <em>conjectured.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">مَأْمُوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOomuwtN_A2">
					<p><span class="ar long">هُوَ إِلَى أَجَلٍ مَأْمُوتٍ</span> <em>It is until a determined, defined,</em> or <em>definite, period.</em> <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امت</span> - Entry: <span class="ar">مَأْمُوتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOomuwtN_A3">
					<p><span class="ar long">شَىْءٌ مَأْمُوتٌ</span> <em>A thing that is known.</em> <span class="auth">(M, TA.)</span> <span class="add">[And so <span class="ar">مَوْمُوتٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0094.pdf" target="pdf">
							<span>Lanes Lexicon Page 94</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0095.pdf" target="pdf">
							<span>Lanes Lexicon Page 95</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
