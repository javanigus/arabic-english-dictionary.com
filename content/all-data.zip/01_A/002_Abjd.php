<article class="root" id="Root_Abjd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/001_Ab">اب</a></span>
				<span class="ar">ابجد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/003_Abd">ابد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Oabojado">
				<h3 class="entry"><span class="ar">أَبْجَدْ</span></h3>
				<div class="sense" id="Oabojado_A1">
					<p><span class="ar">أَبْجَدْ</span> <em>The first of a series of eight words comprising the letters of the Arabic alphabet</em> <span class="add">[<em>in the order in which they were originally disposed,</em> agreeing with that of the Hebrew and Aramaic, but with six additional letters: they are variously written and pronounced; generally as follows: <span class="ar long">أَبْجَدَ هَوَّزْ حُطِّى كَلَمَنْ سَعْفَصْ قَرَشَتْ ثَخَذْ ضَظَغْ</span>: but the Arabs of Western Africa write the latter four thus: <span class="ar long">صعفض قرست ثخذ ظغش</span>]</span>: <span class="auth">(Ḳ and TA in art. <span class="ar">بجد</span>: <span class="add">[in both of which are related several fables concerning the origin of these words:]</span>)</span> accord. to the general opinion, the word <span class="ar">ابجد</span> is of foreign origin, <span class="add">[like each of the words following it,]</span> and therefore its first letter <span class="add">[as well as each of the others]</span> is a radical. <span class="auth">(TA.)</span> <span class="add">[Hence, <span class="ar">الأَبْجَدُ</span> signifies <em>The alphabet.</em> You say <span class="ar long">حُرُوفُ الأَبْجَدِ</span> <em>The letters of the alphabet.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابجد</span> - Entry: <span class="ar">أَبْجَدْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oabojado_A2">
					<p><span class="add">[It is probable <span class="auth">(as De Sacy has observed in his Ar. Gram., 2nd ed., i. 8,)</span> that the Arabic alphabet originally consisted of only twenty-two letters: for some of the ancient Arabs called Saturday <span class="ar">ابجد</span>, Sunday <span class="ar">هوزّ</span>, and so on to <span class="ar">قرشت</span> inclusive; calling Friday <span class="ar">عَرُوبَةُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابجد</span> - Entry: <span class="ar">أَبْجَدْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oabojado_A3">
					<p><span class="add">[In the lexicon entitled “El-ʼEyn,” the letters of the alphabet are arranged nearly according to their places of utterance; as follows: <span class="ar">ع</span>, <span class="ar">ح</span>, <span class="ar">ه</span>, <span class="ar">خ</span>, <span class="ar">غ</span>, <span class="ar">ق</span>, <span class="ar">ك</span>, <span class="ar">ج</span>, <span class="ar">ش</span>, <span class="ar">ض</span>, <span class="ar">ص</span>, <span class="ar">س</span>, <span class="ar">ز</span>, <span class="ar">ط</span>, <span class="ar">د</span>, <span class="ar">ت</span>, <span class="ar">ظ</span>, <span class="ar">ذ</span>, <span class="ar">ث</span>, <span class="ar">ر</span>, <span class="ar">ل</span>, <span class="ar">ن</span>, <span class="ar">ف</span>, <span class="ar">ب</span>, <span class="ar">م</span>, <span class="ar">و</span>, <span class="ar">ا</span>, <span class="ar">ى</span>: and this order has been followed in the Tahdheeb and Moḥkam and some other lexicons.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0004.pdf" target="pdf">
							<span>Lanes Lexicon Page 4</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
