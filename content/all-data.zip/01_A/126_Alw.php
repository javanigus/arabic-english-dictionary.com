<article class="root" id="Root_Alw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/125_Alh">اله</a></span>
				<span class="ar">الو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/127_Ale">الى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alw_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألو</span> ⇒ <span class="ar">ألى</span></h3>
				<div class="sense" id="Alw_1_A1">
					<p><span class="ar">أَلَا</span>, <span class="auth">(Ṣ, M, Mgh, Ḳ,)</span> aor. <span class="ar">يَأْلُو</span>, <span class="auth">(Ṣ, Mgh,)</span> inf. n. <span class="ar">أَلْوٌ</span> <span class="auth">(T, M, Mgh, Ḳ)</span> and <span class="ar">أُلُوُّ</span> <span class="auth">(Ḳ, TA <span class="add">[in a copy of the M <span class="ar">أَلُوٌّ</span>]</span>)</span> and <span class="ar">أُلِىٌّ</span>; <span class="auth">(Ḳ, TA; <span class="add">[in a copy of the M <span class="ar">أَلِىٌّ</span>, and in a copy of the Mgh written with fet-ḥ and damm to the <span class="ar">أ</span>;]</span>)</span> and<span class="arrow"><span class="ar">أَلَّى↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> aor. <span class="ar">يُؤَلّى</span>, inf. n. <span class="ar">تَأْلِيَةٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">ائتلى↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَلَى</span>]</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> <span class="add">[and<span class="arrow"><span class="ar">تَأَلّى↓</span></span>, <a href="index.php?data=25_n/129_nXb">as appears from an ex. in a verse cited in art. <span class="ar">نشب</span>, q. v.</a>;]</span> <em>He fell short;</em> or <em>he fell short of doing what was requisite,</em> or <em>what he ought to have done;</em> or <em>he flagged,</em> or <em>was remiss;</em> <span class="pb" id="Page_0084"></span>syn. <span class="ar">قَصَّرَ</span>: <span class="auth">(Ṣ, M, Ḳ; and Fr, IAạr, T, Mgh, in explanation of the first of these verbs:)</span> and <em>he was slow,</em> or <em>tardy:</em> <span class="auth">(M, Ḳ; and AA, T, Ṣ, in explanation of the second verb:)</span> or <em>he flagged,</em> or <em>was remiss,</em> or <em>languid, and weak.</em> <span class="auth">(AHeyth and T in explanation of all of the above-mentioned verbs except the last.)</span> You say, <span class="ar long">أَلَا فِى الأَمْرِ</span>, <span class="auth">(Mgh,)</span> and<span class="arrow"><span class="ar long">ائتلى↓ فِيهِ</span></span>, <span class="auth">(Ṣ,)</span> <em>He fell short,</em>, &amp;c., (<span class="ar">قَصَّرَ</span>,) <em>in the affair.</em> <span class="auth">(Ṣ, Mgh.)</span> In the saying, <span class="ar long">لَم يَأْلُ أَنْ يَعْدِلَ فِى ذلِكَ</span>, i. e. <em>He did not fall short,</em>, &amp;c., (<span class="ar long">لَمْ يُقَصَّرْ</span>,) <em>in acting equitably and equally in that,</em> <span class="ar">فِى</span> is suppressed before <span class="ar">ان</span>: but in the phrase, <span class="ar long">لَمْ يَأْلُو مِنَ العَدْلِ</span>, as some relate it, <span class="add">[the meaning intended seems to be, <em>They did not hold back,</em> or the like, <em>from acting equitably;</em> for here]</span> the verb is made to imply the meaning of another verb: and such is the case in the saying, <span class="ar long">لَا آلُوكَ نُصْحًا</span>, meaning <em>I will not refuse to thee, nor partially</em> or <em>wholly deprive thee of, sincere, honest,</em> or <em>faithful, advice:</em> <span class="auth">(Mgh:)</span> or this last signifies <em>I will not flag,</em> or <em>be remiss, nor fall short, to thee in giving sincere, honest,</em> or <em>faithful, advice.</em> <span class="auth">(T, Ṣ.*)</span> It is said in the Ḳur <span class="add">[iii. 114]</span>, <span class="ar long">لَا يَإْلُونَكُمْ خَبَالًا</span>, meaning <em>They will not fall short,</em> or <em>flag,</em> or <em>be remiss, in corrupting you.</em> <span class="auth">(IAạr, T.)</span> And the same meaning is assigned to the verb in the saying <span class="arrow"><span class="ar long">وَلَا يَأْتَلِ↓ أُولُو الْفَضْلِ مِنْكُمْ</span></span>, in the Ḳur <span class="add">[xxiv. 22]</span>, by AʼObeyd: but the preferable rendering in this case is that of AHeyth, which will be found below: <a href="#Alw_4">see 4</a>. <span class="auth">(T.)</span> Ks mentions the phrase, <span class="ar long">أَقْبَلَ بِضَرْبَةٍ لَا يَأْلُ</span> <span class="add">[<em>He came with a blow, not falling short,</em>, &amp;c.]</span>, for <span class="ar long">لا يَأْلُو</span>; like <span class="ar long">لَا أَدْرِ</span> <span class="add">[for <span class="ar long">لا أَدْرِى</span>]</span>. <span class="auth">(Ṣ, M: <span class="add">[but in the copies of the former in my hands, for <span class="ar">بِضَرْبَةٍ</span>, I find <span class="ar">يَضْرِبُهُ</span>.]</span>)</span> <span class="arrow"><span class="ar">أَلَّى↓</span></span> <span class="add">[with teshdeed]</span> is also said of a dog, and of a hawk, meaning <em>He fell short of attaining the game that he pursued.</em> <span class="auth">(TA.)</span> And of a cake of bread, meaning <em>It was slow in becoming thoroughly baked.</em> <span class="auth">(IAạr, IB.)</span> <span class="add">[See also the phrase <span class="ar long">لَا دَريْتَ وَلَا ائْتَليْتَ</span> in a later part of this paragraph.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alw_1_A2">
					<p>You say also, <span class="ar long">مَا أَلَوْتُ الشَّيْءَ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">مَا أَلَوْتُ أَنْ أَفْعَلَهُ</span>, <span class="auth">(M,)</span> inf. n <span class="ar">أَلوٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أُلُوٌّ</span>, <span class="auth">(Ḳ, TA, <span class="add">[in a copy of the M <span class="ar">أُلْوٌ</span>,]</span>)</span> meaning <em>I did not leave, quit, cease from, omit,</em> or <em>neglect,</em> <span class="auth">(M, Ḳ,)</span> <em>the thing,</em> <span class="auth">(Ḳ,)</span> or <em>doing it.</em> <span class="auth">(M.)</span> And <span class="ar long">فُلَانٌ لَا يَأْلُو خَيْرًا</span> <em>Such a one does not leave, quit,</em> or <em>cease from, doing good.</em> <span class="auth">(M.)</span> And <span class="ar long">مَا أَلَوْتُ جَهْدًا</span> <em>I did not leave, omit,</em> or <em>neglect, labour, exertion, effort,</em> or <em>endeavour:</em> and the vulgar say, <span class="ar long">مَا آلُوكَ جَهْدًا</span>; but this is wrong: so says Aṣ. <span class="auth">(T. <span class="add">[See, however, similar phrases mentioned above.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alw_1_B1">
					<p><span class="ar">أَلَا</span>, aor. as above, <span class="auth">(TA,)</span> inf. n. <span class="ar">أَلْوٌ</span>, <span class="auth">(IAạr, T, TA,)</span> also signifies <em>He strove,</em> or <em>laboured; he exerted himself,</em> or <em>his power</em> or <em>ability;</em> <span class="auth">(IAạr, T, TA;)</span> as also<span class="arrow"><span class="ar">تَأَلَّى↓</span></span>: <span class="auth">(T, TA:)</span> the contr. of a signification before mentioned; i. e. “he flagged;,” or “was remiss, or languid, and weak.” <span class="auth">(TA.)</span> You say, <span class="ar long">أَتَانِى فِى حَاجَةٍ فَأَلَوْتُ فِيهَا</span> <em>He came to me respecting a want, and I strove,</em> or <em>laboured,</em>, &amp;c., <em>to accomplish it.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Alw_1_B2">
					<p>And <span class="ar">أَلَاهُ</span>, aor. as above, <span class="auth">(T, Ṣ,)</span> inf. n. <span class="ar">أَلْوٌ</span>, <span class="auth">(IAạr, T, Ṣ,)</span> <em>He was,</em> or <em>became, able to do it:</em> <span class="auth">(IAạr, T, Ṣ:)</span> and<span class="arrow"><span class="ar">ألّى↓</span></span>, inf. n. <span class="ar">تَأْلِيَةٌ</span>, also signifies <em>he was,</em> or <em>became, able;</em> <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">ائتلى↓</span></span>. <span class="auth">(ISk, Ṣ, TA.)</span> You say, <span class="ar long">هُوَ يَأْلُو هذَا الأَمْرَ</span> <em>He is able to perform,</em> or <em>accomplish, this affair.</em> <span class="auth">(T.)</span> And <span class="ar long">مَا أَلَوْتُهُ</span> <em>I was not able to do it.</em> <span class="auth">(T, M, Ḳ.)</span> And <span class="ar long">أَتَانِى فُلَانٌ فِى حَاجَةٍ فَمَا أَلَوْتُ رَدَّهُ</span> <em>Such a one came to me respecting a want, and I was not able to rebuff him.</em> <span class="auth">(T.)</span> It is said in a trad.,<span class="arrow"><span class="ar long">مَنْ صَامَ الدَّهْرَ فَلَا صَامَ وَلَا أَلَّى↓</span></span> <span class="add">[<em>He who fasts ever,</em> or <em>always, may he neither fast</em>]</span> <em>nor be able</em> to fast: as though it were an imprecation: or it may be enunciative: another reading is <span class="ar long">وَلَا آلَ</span>, explained as meaning <span class="ar long">وَلَا رَجَعَ</span>: <span class="add">[<a href="index.php?data=01_A/163_Awl">See art. <span class="ar">اول</span></a>:]</span> but El-Khaṭṭábee says that it is correctly <span class="ar">أَلَّى</span> and <span class="ar">أَلَا</span>. <span class="auth">(TA.)</span> And the Arabs used to say, <span class="auth">(Ṣ, M,)</span> <span class="add">[and]</span> accord. to a trad. it will be said to the hypocrite <span class="add">[in his grave]</span>, on his being asked respecting Moḥammad and what he brought, and answering “I know not,” <span class="auth">(T in art. <span class="ar">تلو</span>,)</span> <span class="arrow"><span class="ar long">لَا دَرَيْتَ وَلَا ائتَلَيْتَ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> meaning, accord. to Aṣ, <span class="auth">(T,)</span> or ISk, <span class="auth">(Ṣ,)</span> <em>Mayest thou not know, nor be able</em> to know: <span class="auth">(T, Ṣ:*)</span> or, accord. to Fr, <em>nor fall short,</em> or <em>flag,</em> in seeking to know; that the case may be the more miserable to thee: <span class="auth">(T:)</span> or <span class="ar long">وَلَا أَلَيْتَ</span>, as an imitative sequent <span class="add">[for <span class="ar long">ولا أَلَوْتَ</span>, to which the same explanations are applicable]</span>: <span class="auth">(M, Ḳ:)</span> or <span class="ar long">لَا دَرَيْتَ وَلَا تَلَيْتَ</span>, the latter verb being assimilated to the former, <span class="auth">(ISk, T in art. <span class="ar">تلو</span>, Ṣ,)</span> said to mean <span class="ar long">وَلَا تَلَوْتَ</span>, i. e. <em>nor mayest thou read nor study:</em> <span class="auth">(T in art. <span class="ar">تلو</span>:)</span> or <span class="ar long">لَا دَرَيْتَ وَلَا أَتْليْتَ</span>, i. e. <span class="add">[<em>mayest thou not know,</em>]</span> <em>nor mayest thou have camels followed by young ones.</em> <span class="auth">(Yoo, ISk, T, Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Alw_1_B3">
					<p>Also, <span class="auth">(IAạr, T,)</span> inf. n. <span class="ar">أَلْوٌ</span>, <span class="auth">(IAạr, T, Ḳ,)</span> <em>He gave him</em> a thing: <span class="auth">(IAạr, T, Ḳ:*)</span> <span class="add">[doubly trans.:]</span> the contr. of a signification before mentioned, <span class="auth">(also given by IAạr, T and TA,)</span> which is that of “refusing” <span class="add">[a person anything: see, above, <span class="ar long">لَا آلُوكَ نُصْحًا</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alw_2">
				<h3 class="entry">2. ⇒ <span class="ar">ألّو</span> ⇒ <span class="ar">ألّى</span></h3>
				<div class="sense" id="Alw_2_A1">
					<p><a href="#Alw_1">see 1</a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alw_4">
				<h3 class="entry">4. ⇒ <span class="ar">آلو</span> ⇒ <span class="ar">آلى</span></h3>
				<div class="sense" id="Alw_4_A1">
					<p><span class="ar">آلى</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">يُؤْلِى</span>, inf. n. <span class="ar">إِيلَآءٌ</span>, <span class="auth">(T, Ṣ, Mgh,)</span> <span class="add">[and in poetry <span class="ar">إِلَآءٌ</span>, <span class="auth">(see a reading of a verse cited voce <span class="ar">أَلِيّةٌ</span>,)</span>]</span> <em>He swore;</em> <span class="auth">(T, Ṣ, M, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">تألّى↓</span></span>, and<span class="arrow"><span class="ar">ائتلى↓</span></span>. <span class="auth">(T, Ṣ, M, Ḳ.)</span> You say, <span class="ar long">آلَيْتُ عَلَى الشَّىْءِ</span> and <span class="ar">آلَيْتُهُ</span> <span class="add">[<em>I swore to do the thing</em>]</span>. <span class="auth">(M.)</span> <span class="add">[And <span class="ar long">آلَيْتُ لَا أَفْعَلُ كَذَا</span> <em>I swore that I would not do such a thing;</em> and, emphatically, <em>I swear that I will not do such a thing.</em> And <span class="ar long">آلَى يَمِينًا</span> <em>He swore an oath.</em>]</span> It is said in the Ḳur <span class="add">[xxiv. 22]</span>,<span class="arrow"><span class="ar long">وَلَا يَأْتَلِ↓ أُولُو ٱلْفَضْلِ مِنْكُمْ</span></span>, meaning, accord. to AHeyth and Fr, <em>And let not those of you who possess superabundance swear</em> <span class="add">[that they will not give to relations, &amp;c.]</span>; for Aboo-Bekr <span class="add">[is particularly alluded to thereby, because he]</span> had sworn that he would not expend upon Mistah and his relations who had made mention of <span class="add">[the scandal respecting]</span> ʼÁïsheh: and some of the people of El-Medeeneh read <span class="arrow"><span class="ar long">وَلَا يَتَأَلَّ↓</span></span>, but this disagrees with the written text: AʼObeyd explains it differently: <a href="#Alw_1">see 1</a>: but the preferable meaning is that here given. <span class="auth">(T.)</span> And it is said in a trad., <span class="ar long">آلَى مِنْ نِسَائِهِ شَهْرًا</span> <em>He swore that he would not go in to his wives for a month:</em> the verb being here made trans. by means of <span class="ar">من</span> because it implies the meaning of <span class="ar">اِمْتِنَاع</span>, which is thus trans. <span class="auth">(TA.)</span> <span class="add">[See also an ex. of the verb thus used in the Ḳur ii. 226.]</span> <span class="arrow"><span class="ar long">التَّأَلِّى↓ عَلَى ٱللّٰهِ</span></span> is said to mean One's <em>saying, By God, such a one will assuredly enter the fire</em> <span class="add">[<em>of Hell</em>]</span>, <em>and God will assuredly make to have a good issue the work of such a one:</em> but see the act. part. n. below. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alw_4_B1">
					<p><span class="ar">آلَتْ</span>, inf. n. as above, <em>She</em> <span class="auth">(a woman)</span> <em>took for herself,</em> or <em>made,</em> or <em>prepared, a</em> <span class="ar">مِئْلَاة</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّو</span> ⇒ <span class="ar">تألّى</span></h3>
				<div class="sense" id="Alw_5_A1">
					<p><a href="#Alw_1">see 1</a>, in two places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alw_5_B1">
					<p><a href="#Alw_4">and see 4</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alw_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتلو</span> ⇒ <span class="ar">ائتلى</span></h3>
				<div class="sense" id="Alw_8_A1">
					<p><a href="#Alw_1">see 1</a>, in five places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الو</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alw_8_B1">
					<p><a href="#Alw_4">and see 4</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalowN">
				<h3 class="entry"><span class="ar">أَلْوٌ</span> / <span class="ar">إِلْوٌ</span></h3>
				<div class="sense" id="OalowN_A1">
					<p><span class="ar">أَلْوٌ</span>, or <span class="ar">إِلْوٌ</span>: <a href="#IilFe">see <span class="ar">إِلًى</span></a> <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ouluw">
				<h3 class="entry"><span class="ar">أُلُو</span></h3>
				<div class="sense" id="Ouluw_A1">
					<p><span class="ar">أُلُو</span>, <span class="auth">(so in some copies of the Ṣ, and so in the Ḳ in the last division of that work, and in the CK in art. <span class="ar">ال</span>, <span class="add">[and thus it is always pronounced,]</span> but in some copies of the Ḳ in art. <span class="ar">ال</span> it is written <span class="ar">أُلُونَ</span>, <span class="add">[as though to show the original form of its termination,]</span>)</span> or <span class="ar">أُولُو</span>, <span class="auth">(so in the M, and in some copies of the Ṣ, <span class="add">[and thus it is generally written,]</span>)</span> <em>i. q.</em> <span class="ar">ذَوُو</span> <span class="add">[<em>Possessors</em> of; <em>possessed</em> of; <em>possessing; having</em>]</span>; a pl. which has no sing. <span class="auth">(Ṣ, M, Ḳ)</span> of its own proper letters, <span class="auth">(Ṣ, Ḳ,)</span> its sing. being <span class="ar">ذُو</span>: <span class="auth">(Ṣ:)</span> or, as some say, a quasi-pl. n., of which the sing. is <span class="ar">ذُو</span>: <span class="auth">(Ḳ:)</span> the fem. is <span class="ar">أُلَاتُ</span>, <span class="auth">(so in some copies of the Ṣ and Ḳ, <span class="add">[and thus it is always pronounced,]</span>)</span> or <span class="ar">أُولَاتُ</span>, <span class="auth">(so in other copies of the Ṣ and Ḳ, <span class="add">[and thus it is generally written,]</span>)</span> of which the sing. is <span class="ar">ذَاتُ</span>: <span class="auth">(Ṣ, Ḳ:)</span> it is as though its sing. were <span class="ar">أُلٌ</span>, <span class="auth">(M, Ḳ, <span class="add">[in the CK <span class="ar">الٌ</span>,]</span>)</span> the <span class="add">[final]</span> <span class="ar">و</span> <span class="add">[in the masc.]</span> being the sign of the pl., <span class="auth">(M,)</span> for it has <span class="ar">و</span> <span class="add">[for its termination]</span> in the nom. case, and <span class="ar">ى</span> in the accus. and gen. <span class="auth">(M, Ḳ.)</span> It is never used but as a prefixed noun. <span class="auth">(M, Ḳ.)</span> The following are exs. of the nom. case: <span class="ar long">نَحْنُ أُولُو قُوَّةٍ وَأُولُو بَأْسٍ شَدِيدٍ</span> <span class="add">[<em>We are possessors of strength, and possessors of vehement courage</em>]</span>, in the Ḳur <span class="add">[xxvii. 23]</span>; and <span class="ar long">أُولُو الْأَرْحَامِ بَعْضُهُمْ أَوْلَى بِبَعْضٍ</span> <span class="add">[<em>The possessors of relationships, these have the best title</em> to inheritance, <em>one with respect to another</em>]</span>, in the same <span class="add">[viii. last verse and xxxiii. 6]</span>; <span class="auth">(TA;)</span> and <span class="ar long">جَآءَ نِى أُولُو الأَلْبَابِ</span> <span class="add">[<em>The persons of understandings came to me</em>]</span>; and <span class="ar long">أُولَاتُ الأَحْمَالِ</span> <span class="add">[<em>Those who are with child;</em> occurring in the Ḳur lxv. 4]</span>: <span class="auth">(Ṣ:)</span> and the following are exs. of the accus. and gen. cases: <span class="ar long">وَذَرْنِى وَالْمُكَذَّبِينَ أُولِى النَّعْمَةِ</span> <span class="add">[<em>And leave thou me,</em> or <em>let me alone, with the beliers,</em> or <em>discrediters,</em> <span class="auth">(i. e., commit their case to me,)</span> <em>the possessors of ease and plenty</em>]</span>, in the Ḳur <span class="add">[lxxiii. 11]</span>; and <span class="ar long">لَتَنُوءُ بِالْعُصْبَةِ أُولِى القُوَّةِ</span> <span class="add">[<em>Would weigh down the company of men possessing strength</em>]</span>, in the same <span class="add">[xxviii. 76]</span>. <span class="auth">(TA.)</span> <span class="pb" id="Page_0085"></span><span class="ar long">وَأُولِى الْأَمْرِ مِنْكُمْ</span>, in the Ḳur <span class="add">[iv. 62]</span>, <span class="add">[<em>And those, of you, who are possessors of command</em>]</span>, <span class="auth">(M, Ḳ,*)</span> accord. to Aboo-Is-ḥáḳ, <span class="auth">(M,)</span> means <em>the companions of the Prophet, and the men of knowledge their followers,</em> <span class="auth">(M, Ḳ,)</span> <em>and the possessors of command, who are their followers, when also possessors of knowledge and religion:</em> <span class="auth">(Ḳ:)</span> or, as some say, <span class="add">[simply]</span> <em>the possessors of command;</em> for when these are possessors of knowledge and religion, and take, or adopt and maintain, and follow, what the men of knowledge say, to obey them is of divine obligation: and in general those who are termed <span class="ar long">أُولُو الأَمْرِ</span>, of the Muslims, are <em>those who superintend the affairs</em> of such <em>with respect to religion, and everything conducing to the right disposal of</em> their <em>affairs.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iilae">
				<h3 class="entry"><span class="ar">إِلَى</span></h3>
				<div class="sense" id="Iilae_A1">
					<p><span class="ar">إِلَى</span>, accord. to Sb, is originally with <span class="ar">و</span> in the place of the <span class="add">[<span class="ar">ى</span>, i. e. the final]</span> alif; and so is <span class="ar">عَلَى</span>; for the alifs <span class="add">[in these two particles]</span> are not susceptible of imáleh; <span class="add">[i. e., they may not be pronounced ilè and 'alè;]</span> and if either be used as the proper name of a man, the dual <span class="add">[of the former]</span> is <span class="ar">إِلَوَانِ</span> and <span class="add">[that of the latter]</span> <span class="ar">عَلَوَانِ</span>; but when a pronoun is affixed to it, the alif is changed into yé, so that you say <span class="ar">إِلَيْكَ</span> and <span class="ar">عَلَيْكَ</span>; though some of the Arabs leave it as it was, saying <span class="ar">إِلَاكَ</span> and <span class="ar">عَلَاكَ</span>. <span class="auth">(Ṣ.)</span> It is a prep., or particle governing a noun in the gen. case, <span class="auth">(Ṣ, Mughnee, Ḳ,)</span> and denotes the end, as opposed to <span class="add">[<span class="ar">مِنْ</span>, which denotes]</span> the beginning, of an extent, or of the space between two points or limits; <span class="auth">(Ṣ, M;)</span> or the end of an extent <span class="auth">(T, Mughnee, Ḳ)</span> of place; <span class="add">[signifying <em>To,</em> or <em>as far as;</em>]</span> as in the phrase <span class="add">[in the Ḳur xvii. 1]</span>, <span class="ar long">مِنَ المَسْجِدِ الحَرَامِ إِلَى المَسْجِدِ الأَقْصَى</span> <span class="add">[<em>From the Sacred Mosque to,</em> or <em>as far as, the Furthest Mosque;</em> meaning from the mosque of Mekkeh to that of Jerusalem]</span>; <span class="auth">(Mughnee, Ḳ;)</span> or in the saying, <span class="ar long">خَرَجْتُ مِنَ الكُوفَةِ إِلَى مَكَّةَ</span> <span class="add">[<em>I went forth from El-Koofeh to Mekkeh</em>]</span>, which may mean that you entered it, <span class="add">[namely, the latter place,]</span> or that you reached it without entering it, for the end includes the beginning of the limit and the furthest part thereof, but does not extend beyond it. <span class="auth">(Ṣ.)</span> <span class="add">[In some respects it agrees with <span class="ar">حَتَّى</span>, q. v. And sometimes it signifies <em>Towards;</em> as in <span class="ar long">نَظَرَ إِلَىَّ</span> <em>He looked towards me;</em> and <span class="ar long">مَالَ إِلَيْهِ</span> <em>He,</em> or <em>it, inclined towards him,</em> or <em>it.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Iilae_A2">
					<p>It also denotes the end of a space of time; <span class="add">[signifying <em>To, till,</em> or <em>until;</em>]</span> as in the saying <span class="add">[in the Ḳur ii. 183]</span>, <span class="ar long">ثُمَّ أَتِمُّوا الصِّيَامَ إِلَى اللَّيْلِ</span> <span class="add">[<em>Then complets ye the fasting to,</em> or <em>till,</em> or <em>until, the night</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span> <span class="add">[Hence, <span class="ar long">إِلَى أَنْ</span> <span class="auth">(followed by a mansoob aor.)</span> <em>Till,</em> or <em>until:</em> and <span class="ar long">إِلَى مَتَى</span> <em>Till,</em> or <em>until, what time,</em> or <em>when?</em> i. e. <em>how long?</em> and also <em>to, till,</em> or <em>until, the time when.</em> See also the last sentence in this paragraph.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Iilae_A3">
					<p><span class="add">[In like manner it is used in the phrases <span class="ar long">إِلَى غَيْرِ ذلِكَ</span>, and <span class="ar long">إِلَى آخِرِهِ</span>, meaning, (<em>And so on,</em>) <em>to other things,</em> and <em>to the end thereof;</em> equivalent to <em>et cœtera.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Iilae_A4">
					<p>Sometimes, <span class="auth">(Ṣ,)</span> it occurs in the sense of <span class="ar">مَعَ</span>, <span class="auth">(T, Ṣ, M, Mughnee, Ḳ,)</span> when a thing is joined to another thing; <span class="auth">(Mughnee, Ḳ;)</span> as in the phrase <span class="add">[in the Ḳur iii. 45 and lxi. 14]</span>, <span class="ar long">مَنْ أَنْصَارِى إِلَى ٱللّٰهِ</span> <span class="add">[<em>Who will be my aiders with,</em> or <em>in addition to, God?</em>]</span>, <span class="auth">(Ṣ, Mughnee, Ḳ,)</span> accord. to the Koofees and some of the Basrees; <span class="auth">(Mughnee;)</span> i. e. <em>who will be joined to God in aiding me?</em> <span class="auth">(M, TA;)</span> and as in the saying <span class="add">[in the Ḳur iv. 2]</span>, <span class="ar long">وَلَا تَأْكُلُوا أَمْوَالَهُمْ إِلَى أَمْوَالِكُمْ</span> <span class="add">[<em>And devour not ye their possessions with,</em> or <em>in addition to, your possessions</em>]</span>; <span class="auth">(T, Ṣ;)</span> and <span class="add">[in the same, ii. 13,]</span> <span class="ar long">وَإِذَا خَلَوْا إِلَى شَيَا طِينِهِمْ</span> <span class="add">[<em>And when they are alone with their devils</em>]</span>; <span class="auth">(Ṣ;)</span> and in the saying, <span class="ar long">الذَّوْدُ إِلَى الذَّوْدِ إِبِلٌ</span> <span class="add">[<em>A few she-camels with,</em> or <em>added to, a few she-camels are a herd of camels</em>]</span>, <span class="auth">(Ṣ, Mughnee, Ḳ,)</span> a prov., meaning † <em>a little with a little makes much;</em> <span class="auth">(Ṣ and A in art. <span class="ar">ذود</span>, q. v.;)</span> though one may not say, <span class="ar long">إِلَى زَيْدٍ مَالٌ</span> meaning <span class="ar long">مَعَ زَيْدٍ مَالٌ</span>: <span class="auth">(Mughnee:)</span> so too in the saying, <span class="ar long">فُلَانٌ حَلِيمٌ إِلَى أَدَبٍ وَفِقْهٍ</span> <span class="add">[<em>Such a one is clement,</em> or <em>forbearing, with good education,</em> or <em>polite accomplishments, and intelligence,</em> or <em>knowledge of the law</em>]</span>; <span class="auth">(M, TA;)</span> and so, accord. to Kh, in the phrase, <span class="ar long">أَحْمَدُ ٱللّٰهَ إِلَيْكَ</span> <span class="add">[<em>I praise God with thee:</em> but see another rendering of this phrase below]</span>. <span class="auth">(ISh.)</span> In the saying in the Ḳur <span class="add">[v. 8]</span>, <span class="ar long">فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى المَرَافِقِ</span>, it is disputed whether <span class="add">[the meaning be <em>Then wash ye your faces, and your arms with the elbows,</em> or, <em>and your arms as far as the elbows;</em> i. e., whether]</span> the elbows be meant to be included among the parts to be washed, or excluded therefrom. <span class="auth">(T.)</span> A context sometimes shows that what follows it is included in what precedes it; as in <span class="ar long">قَرَأْتُ القُرْآنَ مِنْ أَوَّلِهِ إِلَى آخِرِهِ</span> <span class="add">[<em>I read,</em> or <em>recited, the Kurán, from the beginning thereof to the end thereof</em>]</span>: or that it is excluded; as in <span class="ar long">ثُمَّ أَتِمُّوا الصِّيَامَ إِلَى اللَّيْلِ</span> <span class="add">[explained above]</span>: when this is not the case, some say that it is included if it be of the same kind <span class="add">[as that which precedes]</span>; some, that it is included absolutely; and some, that it is excluded absolutely; and this is the right assertion; for with the context it is in most instances excluded. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Iilae_A5">
					<p>It is also used to show the grammatical agency of the noun governed by it, after a verb of wonder; or after a noun of excess importing love or hatred; <span class="add">[as in <span class="ar long">مَا أَحَبَّهُ إِلَىَّ</span> <em>How lovely,</em> or <em>pleasing, is he to me!</em> <span class="auth">(TA in art. <span class="ar">حب</span>,)</span> and <span class="ar long">مَا أَبْغَضَهُ إِلَىَّ</span> <em>How hateful,</em> or <em>odious, is he to me!</em> <span class="auth">(Ṣ in art. <span class="ar">بغض</span>;)</span> and]</span> as in the saying <span class="add">[in the Ḳur xii. 33]</span>, <span class="ar long">رَبِّ السِّجْنُ أَحَبُّ إِلَىَّ</span> <span class="add">[<em>O my Lord, the prison is more pleasing to me</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span> <span class="add">[This usage is similar to that explained in the next sentence.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Iilae_A6">
					<p>It is <em>syn. with</em> <span class="ar">عِنْدَ</span>; <span class="auth">(Ṣ, M, Mughnee, Mṣb, Ḳ;)</span> as in the phrase, <span class="ar long">هُوَ أَشْهَى إِلَىَّ مِنْ كَذَا</span> <span class="add">[<em>It is more desirable,</em> or <em>pleasant, in my estimation than such a thing</em>]</span>; <span class="auth">(Mṣb;)</span> and in the saying of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَمْ لَا سَبِيلَ إِلَى الشَّبَابِ وَذِكْرُهُ</span> *</div> 
						<div class="star">* <span class="ar long">أَشْهَى إِلَىَّ مِنَ الرَّحِيقِ السَّلْسَلِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Is there no way </em> of return <em>to youth, seeing that the remembrance thereof is more pleasant to me,</em> or <em>in my estimation, than mellow wine?</em>]</span> <span class="auth">(Mughnee, Ḳ:)</span> and accord. to this usage of <span class="ar">إِلَى</span> in the sense of <span class="ar">عِنْدَ</span> may be explained the saying, <span class="ar long">أَنْتِ طَالِقٌ إِلَى سَنَةٍ</span>, meaning <em>Thou art divorced at</em> the commencement of <em>a year.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Iilae_A7">
					<p>It is also <em>syn.</em> with <span class="ar">لِ</span>; as in the phrase, <span class="ar long">وَالأَمْرُ إِلَيْكَ</span> <span class="add">[<em>And command,</em> or <em>to command, belongeth unto Thee,</em> meaning God, as in the Ḳur xiii. 30, and xxx. 3]</span>, <span class="auth">(Mughnee, Ḳ,)</span> in a trad. respecting supplication: <span class="auth">(TA:)</span> or, as some say, it is here used in the manner first explained above, meaning, <em>is ultimately referrible to Thee:</em> and they say, <span class="ar long">أَحْمَدُ ٱللّٰهَ إِلَيْكَ</span>, meaning, <em>I tell the praise of God unto thee:</em> <span class="auth">(Mughnee:)</span> <span class="add">[but see another rendering of this last phrase above:]</span> you say also, <span class="ar long">ذَاكَ إِلَيْكَ</span> <em>That is committed to thee,</em> or <em>to thy arbitration.</em> <span class="auth">(Ḥar p. 329.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Iilae_A8">
					<p>It also occurs as <em>syn. with</em> <span class="ar">عَلَى</span>; as in the saying in the Ḳur <span class="add">[xvii. 4]</span>, <span class="ar long">وَقَضَيْنَا إِلَى بَنِى إِسْرَائِيلَ</span> <span class="add">[<em>And we decreed against the children of Israel</em>]</span>: <span class="auth">(Mṣb:)</span> or this means <em>and we revealed to the children of Israel</em> <span class="auth">(Bḍ, Jel)</span> <em>decisively.</em> <span class="auth">(Bḍ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Iilae_A9">
					<p>It is also syn. with <span class="ar">فِى</span>; <span class="auth">(M, Mughnee, Ḳ;)</span> as in the saying <span class="add">[in the Ḳur iv. 89 and vi.12]</span>, <span class="ar long">لَيَجْمَعَنَّكُمْ إِلَى يَوْمِ القِيَامَةِ</span> <span class="add">[<em>He will assuredly collect you together on the day of resurrection</em>]</span>: <span class="auth">(Ḳ:)</span> thus it may be used in this instance accord. to Ibn-Málik: <span class="auth">(Mughnee:)</span> and it is said to be so used in the saying <span class="add">[of En-Nábighah, <span class="auth">(M, TA,)</span>]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَلَا تَتْرُكَنِّى بِالوَعِيدِ كَأَنَّنِى</span> *</div> 
						<div class="star">* <span class="ar long">إِلَى النَّاسِ مَطْلِىٌّ بِهِ القَارُ أَجْرَبُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Then do not thou leave me with threatening, as though I were, among men, smeared with tar,</em> being like a <em>mangy</em> camel]</span>; <span class="auth">(M, Mughnee;)</span> or, accord. to some, there is an ellipsis and inversion in this verse; <span class="ar">الى</span> being here in dependence upon a word suppressed, and the meaning being, <em>smeared with pitch,</em> <span class="add">[like a camel,]</span> <em>yet being united to men:</em> or, accord. to Ibn-ʼOsfoor, <span class="ar">مطلىّ</span> is here considered as made to import the meaning of <em>rendered hateful,</em> or <em>odious;</em> for he says that if <span class="ar">الى</span> were correctly used in the sense of <span class="ar">فى</span>, it it would be allowable to say, <span class="ar long">زَيْدٌإِلَى الكُوفَةِ</span>: <span class="auth">(Mughnee:)</span> <span class="add">[or the meaning may be, <em>as though I were, compared to men, a mangy</em> camel, <em>smeared with pitch:</em> for]</span> I’Ab said, after mentioning ʼAlee, <span class="ar long">عِلْمِى إِلَى عِلْمِهِ كَالقَرَارَةِ فِى المُثُعَنْجَرِ</span>, meaning <em>My knowledge compared to his knowledge is like the</em> <span class="ar">قرارة</span> <span class="add">[or <em>small pool of water left by a torrent</em>]</span> <em>placed by the side of the middle of the sea</em> <span class="add">[or <em>the main deep</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">ثعجر</span>.)</span> It is also <span class="add">[said to be]</span> used in the sense of <span class="ar">فى</span> in the saying in the Ḳur <span class="add">[1xxix. 18]</span>, <span class="ar long">هَلْ لَكَ إِلَى أَنْ تَزَكَّى</span> <span class="add">[<em>Wilt thou purify thyself</em> from infidelity?]</span> because it imports the meaning of invitation. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Iilae_A10">
					<p>It is also used <span class="add">[in a manner contr. to its primitive application, i. e.,]</span> to denote beginning, <span class="add">[or origination,]</span> being <em>syn. with</em> <span class="ar">مِنْ</span>; as in the saying <span class="add">[of a poet]</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَقُولُ وَقَدْ عَالَيْتُ بِالكُورِ فَوْقَهَا</span> *</div> 
						<div class="star">* <span class="ar long">أَيُسْقَى فَلَا يَرْوَى إِلَىَّ ابْنُ أَحْمَرَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>She says,</em> <span class="auth">(namely my camel,)</span> <em>when I have raised the saddle upon her, Will Ibn-Aḥmar be supplied with drink and not satisfy his thirst from me?</em> i. e., will he never be satisfied with drawing forth my sweat?]</span>. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Iilae_A11">
					<p>It is also used as a corroborative, and is thus <span class="add">[syntactically]</span> redundant; as in the saying in the Ḳur <span class="add">[xiv. 40]</span>, <span class="ar long">فَاجْعَلْ أَفْئِدَةً مِنَ النَّاسِ تَهْوَى إِلَيْهِمْ</span>, with fet-ḥ to the <span class="ar">و</span> <span class="add">[in <span class="ar">تهوى</span>]</span>, <span class="auth">(Mughnee, Ḳ,)</span> <span class="pb" id="Page_0086"></span>accord. to one reading, <span class="auth">(Mughnee,)</span> meaning <span class="ar">تَهْوَاهُمْ</span> <span class="add">[i. e. <em>And make Thou hearts of men to love them</em>]</span>: <span class="auth">(Ḳ:)</span> so says Fr: but some explain it by saying that <span class="ar">تهوى</span> imports the meaning of <span class="ar">تَمِيلُ</span>; or that it is originally <span class="ar">تَهْوِى</span>, with kesr, the kesreh being changed to a fet-ḥah, and the yé to an alif, as when one says <span class="ar">رَضَا</span> for <span class="ar">رَضِىَ</span>, and <span class="ar">نَاصَاةٌ</span> for <span class="ar">نَاصِيَةٌ</span>: so says Ibn-Málik; but this requires consideration; for it is a condition in such cases that the <span class="ar">ى</span> in the original form must be movent. <span class="auth">(Mughnee.)</span> <span class="add">[<a href="index.php?data=26_h/159_hwe">See art. <span class="ar">هوى</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="Iilae_A12">
					<p><span class="ar long">اَللّٰهُمَّ إِلَيْكَ</span>, occurring in a trad., <span class="add">[is elliptical, and]</span> means <em>O God, I complain unto Thee:</em> or <em>take Thou me unto Thee.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="Iilae_A13">
					<p>And <span class="ar long">أَنَا مِنْكَ وَإِلَيْكَ</span> means <em>I am of thee, and related to thee.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="Iilae_A14">
					<p>You say also, <span class="ar long">اِذْهَبْ إِلَيْكَ</span>, meaning <em>Betake,</em> or <em>apply, thyself to,</em> or <em>occupy thyself with, thine own affairs.</em> <span class="auth">(T, Ḳ.*)</span> And similar to this is the phrase used by El-Aạshà, <span class="ar long">فَاذْهَبِى مَا إِلَيْكِ</span>. <span class="auth">(TA.)</span> And <span class="ar">إِلَيْكُمْ</span> <span class="add">[alone is used in a similar manner, elliptically, or as an imperative verbal noun, and]</span> means <em>Betake,</em> or <em>apply, yourselves to,</em> or <em>occupy yourselves with, your own affairs,</em> (<span class="ar long">اِذْهَبُوا إِلَيْكُمْ</span>,) <em>and retire ye,</em> or <em>withdraw ye, to a distance,</em> or <em>far away, from us.</em> <span class="auth">(ISk.)</span> And <span class="ar long">إِلَيْكَ عَنِّى</span> means <em>Hold,</em> or <em>refrain, thou from me:</em> <span class="auth">(T, Ḳ:)</span> or <em>remove, withdraw,</em> or <em>retire, thou to a distance from me:</em> <span class="ar">اليك</span> used in this sense is an imperative verbal noun. <span class="auth">(Ḥar p. 508.)</span> Sb says, <span class="auth">(M,)</span> or Akh, <span class="auth">(Ḥar ubi suprà,)</span> I heard an Arab of the desert, on its being said to him <span class="ar">إِلَيْكَ</span>, reply, <span class="ar">إِلَىَّ</span>; as though it were said to him <em>Remove, withdraw,</em> or <em>retire, thou to a distance,</em> and he replied, <em>I will remove,</em>, &amp;c. <span class="auth">(M.)</span> Aboo-Fir' own says, satirizing a Nabathæan woman of whom he asked for water to drink,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَا طَلَبْتَ المَآءِ قَالَتْ لَيْكَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When thou shalt demand water, she will say, Retire thou to a distance</em>]</span>; meaning, <span class="add">[by <span class="ar">ليكا</span>, i. e. <span class="ar">لَيْكَ</span> with an adjunct alif for the sake of the rhyme,]</span> <span class="ar">إِلَيْكَ</span>, in the sense last explained above. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="Iilae_A15">
					<p>One also says, <span class="ar long">إِلَيْكَ كَذَا</span>, meaning, <em>Take thou such a thing.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">إِلَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A16</span>
				</div>
				<div class="sense" id="Iilae_A16">
					<p>When <span class="ar">إِلَى</span> is immediately followed by the interrogative <span class="ar">مَا</span>, both together are written <span class="ar">إِلَامَ</span> <span class="add">[meaning, <em>To what? whither?</em> and <em>till,</em> or <em>until, what time,</em> or <em>when?</em> i. e. <em>how long?</em>]</span>; and in like manner one writes <span class="ar">عَلَامَ</span> for <span class="ar long">عَلَى مَا</span>, <span class="auth">(Ṣ* and Ḳ voce <span class="ar">ما</span>,)</span> and <span class="ar">حَتَّامَ</span> for <span class="ar">حَتَّى</span>. <span class="auth">(Ṣ voce <span class="ar">حَتَّى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OalowapN">
				<h3 class="entry"><span class="ar">أَلْوَةٌ</span> / 
							<span class="ar">أُلْوَةٌ</span> / 
							<span class="ar">إِلْوَةٌ</span></h3>
				<div class="sense" id="OalowapN_A1">
					<p><span class="ar">أَلْوَةٌ</span> and <span class="ar">أُلْوَةٌ</span> and <span class="ar">إِلْوَةٌ</span>: <a href="#OaliyBapN">see <span class="ar">أَلِيَّةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalieBu">
				<h3 class="entry"><span class="ar">أَلِىُّ</span></h3>
				<div class="sense" id="OalieBu_A1">
					<p><span class="ar">أَلِىُّ</span> One <em>who swears much; who utters many oaths:</em> <span class="auth">(IAạr, T, Ḳ:)</span> mentioned in the Ḳ in art. <span class="ar">الى</span>; but the present is its proper art. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaliyBapN">
				<h3 class="entry"><span class="ar">أَلِيَّةٌ</span></h3>
				<div class="sense" id="OaliyBapN_A1">
					<p><span class="ar">أَلِيَّةٌ</span> <span class="add">[<em>A falling short;</em> or <em>a falling short of what is requisite,</em> or <em>what one ought to do;</em> or <em>a flagging,</em> or <em>remissness;</em> and <em>slowness,</em> or <em>tardiness:</em>]</span> a subst. from <span class="ar">أَلَا</span> as signifying <span class="ar">قَصَّرَ</span> and <span class="ar">أَلِيَّةً</span>. <span class="auth">(M.)</span> Hence the prov., <span class="auth">(M,)</span> <span class="ar long">إِلَّا حَضِيَّةً فَلَا أَلِيَّةً</span>, i. e. <em>If I be not in favour, and high estimation, I will not cease seeking, and labouring, and wearying myself, to become so:</em> <span class="auth">(M, Ḳ:*)</span> or <em>if thou fail of good fortune in that which thou seekest, fall not short,</em> or <em>flag not,</em> or <em>be not remiss, in showing love,</em> or <em>affection, to men;</em> may-be thou wilt attain somewhat of that which thou wishest: originally relating to a woman who becomes displeasing to her husband: <span class="auth">(Ṣ in art. <span class="ar">حظو</span>:)</span> it is one of the proverbs of women: one says, <em>if I be not in favour, and high estimation, with my husband, I will not fall short,</em> or <em>flag,</em> or <em>be remiss, in that which may render me so, by betaking myself to that which he loveth:</em> <span class="auth">(T and TA in art. <span class="ar">حظو</span>:)</span> Meyd says that the two nouns are in the accus. case because the implied meaning is <span class="ar long">إِلَّا أَكُنْ حَظِيَّةً فَلَا أَكُنْ أَلِيَّةً</span>; the latter noun being <span class="add">[accord. to him]</span> for<span class="arrow"><span class="ar">آلِيَةٌ↓</span></span>, for which it may be put for the sake of conformity <span class="add">[with the former]</span>; and the former having the signification of the pass. part. n. of <span class="ar">أَحْظَى</span>, or that of the part. n. of <span class="ar">حَظِىَ</span> <span class="add">[or <span class="ar">حَظِيَتْ</span>]</span>. <span class="auth">(Ḥar p. 78.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">أَلِيَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaliyBapN_B1">
					<p><em>An oath;</em> <span class="auth">(T, Ṣ, M, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَلِيَّا↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">أَلْوَةٌ↓</span></span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أُلْوَةً↓</span></span> and<span class="arrow"><span class="ar">إِلِيوَةٌ↓</span></span>: <span class="auth">(Ṣ, M, Ḳ: <span class="add">[in the CK, <span class="ar long">والاُلُوَّةُ مُثَلَّثَةً</span> is erroneously put for <span class="ar long">والِأَلْوَةُ مثلّثةً</span>:]</span>)</span> it is <span class="add">[originally <span class="ar">أَلِيوَةٌ</span>,]</span> of the measure <span class="ar">فَعِيلَةٌ</span>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">أَلَايَا</span>. <span class="auth">(Ṣ, Mgh.)</span> A poet says, <span class="auth">(namely, Kutheiyir, TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَلِيلُا الأَلَايَا حَافِظٌ لِيَمِينِهِ</span> *</div> 
						<div class="star">* <span class="ar long">وَإِنْ سَبَقَتْ مِنْهُ الأَلِيَّةُ بَرَّتِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>A person of few oaths, who keeps his oath from being uttered on ordinary</em> or <em>mean occasions; but if the oath has proceeded from him at any former time,</em> or <em>hastily, it proves true</em>]</span>: <span class="auth">(Ṣ, TA:)</span> or, as IKh relates it, <span class="ar long">قَلِيلُ الإِلَآءِ</span>; meaning, he says, <span class="ar long">قَلِيلُ الإيلَآءِ</span>; the <span class="ar">ى</span> being suppressed: <a href="#Alw_4">see 4</a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaliyBaA">
				<h3 class="entry"><span class="ar">أَلِيَّا</span></h3>
				<div class="sense" id="OaliyBaA_A1">
					<p><span class="ar">أَلِيَّا</span>: see the latter part of the paragraph next preceding.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MlK">
				<h3 class="entry"><span class="ar">آلٍ</span> / <span class="ar">آلَةٍ</span></h3>
				<div class="sense" id="MlK_A1">
					<p><span class="ar">آلٍ</span> <em>Falling short;</em> or <em>falling short of what is requisite,</em> or <em>what one ought to do;</em> or <em>flagging,</em> or <em>remiss:</em> <span class="add">[and <em>slow,</em> or <em>tardy:</em>, &amp;c.: <a href="#Alw_1">see 1</a>:]</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">آلَةٍ</span>}</span></add>: and pl. of this latter <span class="ar">أَوَالٍ</span>. <span class="auth">(Ṣ, TA.)</span> <a href="#OaliyBapN">See <span class="ar">أَلِيَّةٌ</span></a>, used, accord. to Meyd, for <span class="ar">آلِيَة</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الو</span> - Entry: <span class="ar">آلٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MlK_A2">
					<p><em>Niggardly, penurious,</em> or <em>avaricious; impotent to fulfil duties</em> or <em>obligations,</em> or <em>to pay debts.</em> <span class="auth">(Ḥar p. 78.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYolaApN">
				<h3 class="entry"><span class="ar">مِئْلَاةٌ</span></h3>
				<div class="sense" id="miYolaApN_A1">
					<p><span class="ar">مِئْلَاةٌ</span> The <em>piece of rag which a woman holds in wailing,</em> <span class="auth">(Ṣ, TA,)</span> <em>and with which she makes signs:</em> <span class="auth">(TA:)</span> <span class="add">[it is generally dyed blue, the colour of mourning; and the woman sometimes holds it over her shoulders, and sometimes twirls it with both hands over her head, or before her face:]</span> pl. <span class="ar">مَآلٍ</span>: <span class="auth">(Ṣ, TA:)</span> which also signifies <em>rags used for the menses.</em> <span class="auth">(TA in art. <span class="ar">غبر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOalB">
				<h3 class="entry"><span class="ar">مُتَأَلّ</span></h3>
				<div class="sense" id="mutaOalB_A1">
					<p><span class="ar">مُتَأَلّ</span> <span class="add">[part. n. of 5]</span>. It is said in a trad., <span class="ar long">وَيْلٌ لِلْمُتَأَلِّينَ مِنْ أُمَّتِى</span>, explained as meaning <em>Woe to those of my people who pronounce sentence against God, saying, Such a one is in Paradise, and such a one is in the fire</em> <span class="add">[<em>of Hell</em>]</span>: but see the verb. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0083.pdf" target="pdf">
							<span>Lanes Lexicon Page 83</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0084.pdf" target="pdf">
							<span>Lanes Lexicon Page 84</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0085.pdf" target="pdf">
							<span>Lanes Lexicon Page 85</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0086.pdf" target="pdf">
							<span>Lanes Lexicon Page 86</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
