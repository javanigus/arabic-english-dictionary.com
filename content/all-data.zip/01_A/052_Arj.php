<article class="root" id="Root_Arj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/051_Arv">ارث</a></span>
				<span class="ar">ارج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/053_Arx">ارخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Arj_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرج</span></h3>
				<div class="sense" id="Arj_1_A1">
					<p><span class="ar">أَرِجَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَجُ</span>}</span></add>, inf. n. <span class="ar">أَرَجٌ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ)</span> and <span class="ar">أَرِيجٌ</span> <span class="auth">(Ṣ, A, Ḳ)</span> and <span class="ar">أَرِيجَةٌ</span>, <span class="auth">(Ḳ, <span class="add">[in which it is only mentioned as syn. with the first and second of these ns., so that it may be a simple subst.,]</span>)</span> <em>It</em> <span class="auth">(perfume)</span> <em>diffused,</em> or <em>exhaled, its odour;</em> <span class="auth">(Ṣ, A;)</span> as also<span class="arrow"><span class="ar">تآرّج↓</span></span>: <span class="auth">(A:)</span> <em>it had a hot,</em> or <em>strong, odour;</em> syn. <span class="ar long">تَوَهَّجَ رِيحُهُ</span>. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارج</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Arj_1_A2">
					<p><em>It</em> <span class="auth">(a place)</span> <em>was,</em> or <em>became, strongly fragrant.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارج</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Arj_1_B1">
					<p><span class="ar">أَرَجَ</span>: <a href="#Arj_2">see 2</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arj_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّج</span></h3>
				<div class="sense" id="Arj_2_A1">
					<p><span class="ar">أرّج</span>, <span class="add">[and app.<span class="arrow"><span class="ar">أَرَجَ↓</span></span> also,]</span> <em>He perfumed</em> a thing; <em>made</em> it <em>fragrant.</em> <span class="auth">(Ḥam p. 135.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارج</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Arj_2_A2">
					<p><span class="add">[Both also app. signify <em>He made</em> perfume <em>to diffuse,</em> or <em>exhale, its odour:</em> or <em>made</em> it <em>to have a hot,</em> or <em>strong, odour.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارج</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Arj_2_A3">
					<p><span class="add">[And hence,]</span> <span class="ar">أرّج</span>, inf. n. <span class="ar">تَأْرِيجٌ</span>; <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">أَرَجَ↓</span></span>, <span class="auth">(TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُجُ</span>}</span></add>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">أَرْجٌ</span>; <span class="auth">(Ḳ, TA;)</span> † <em>He excited discord, dissension, disorder, strife, quarrelling,</em> or <em>animosity,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <span class="ar long">بَيْنَ القَوْمِ</span> <em>between,</em> or <em>among, the people,</em> or <em>company of men,</em> like <span class="ar">أَرَّشَ</span>, <span class="auth">(Ṣ, TA,)</span> and <span class="ar long">فِى الحَرْبِ</span> <em>in war.</em> <span class="auth">(TA.)</span> And <span class="ar long">أرّج الحَرْبَ</span>, <span class="auth">(Ṣ, Ḳ, TA, and Ḥam ubi suprà,)</span> and<span class="arrow"><span class="ar">أَرَجَهَا↓</span></span>, <span class="auth">(TA,)</span> † <em>He kindled war,</em> or <em>the war;</em> <span class="auth">(Ṣ, TA, and Ḥam ubi suprà;)</span> and in like manner, <span class="ar">النَّارَ</span> <em>the fire.</em> <span class="auth">(IAạr, Ḥam.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Arj_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأرّج</span></h3>
				<div class="sense" id="Arj_5_A1">
					<p><a href="#Arj_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarajN">
				<h3 class="entry"><span class="ar">أَرَجٌ</span></h3>
				<div class="sense" id="OarajN_A1">
					<p><span class="ar">أَرَجٌ</span> <span class="auth">(L)</span> and<span class="arrow"><span class="ar">أَرِيجٌ↓</span></span> and<span class="arrow"><span class="ar">أَرِيجَةٌ↓</span></span> <span class="auth">(ISd, TA)</span> <em>A sweet odour:</em> <span class="auth">(ISd, L, TA:)</span> pl. of the last, <span class="ar">أَرَائِجُ</span>. <span class="auth">(ISd, TA.)</span> <span class="add">[<a href="#Arj_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarijN">
				<h3 class="entry"><span class="ar">أَرِجٌ</span></h3>
				<div class="sense" id="OarijN_A1">
					<p><span class="ar">أَرِجٌ</span> Perfume <em>diffusing,</em> or <em>exhaling, its odour: having a hot,</em> or <em>strong, odour.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارج</span> - Entry: <span class="ar">أَرِجٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OarijN_A2">
					<p>Applied also to a place: you say, <span class="ar long">مَكَانٌ أَرِجٌ</span> <em>A strongly fragrant place:</em> <span class="auth">(Mṣb:)</span> and <span class="ar long">بَيْتٌ أَرِجٌ بِالِّيبِ</span> <span class="add">[<em>a house,</em> or <em>chamber, fragrant,</em> or <em>strongly fragrant, with perfume</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OariyjN">
				<h3 class="entry"><span class="ar">أَرِيجٌ</span></h3>
				<div class="sense" id="OariyjN_A1">
					<p><span class="ar">أَرِيجٌ</span>: <a href="#OarajN">see <span class="ar">أَرَجٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OariyjapN">
				<h3 class="entry"><span class="ar">أَرِيجَةٌ</span></h3>
				<div class="sense" id="OariyjapN_A1">
					<p><span class="ar">أَرِيجَةٌ</span>: <a href="#OarajN">see <span class="ar">أَرَجٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarBaAjN">
				<h3 class="entry"><span class="ar">أَرَّاجٌ</span></h3>
				<div class="sense" id="OarBaAjN_A1">
					<p><span class="ar">أَرَّاجٌ</span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">مِئْرَجٌ↓</span></span> <span class="auth">(TA)</span> † <em>A liar:</em> and one <em>who excites discord, dissension, disorder, strife, quarrelling,</em> or <em>animosity, among people.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miYorajN">
				<h3 class="entry"><span class="ar">مِئْرَجٌ</span></h3>
				<div class="sense" id="miYorajN_A1">
					<p><span class="ar">مِئْرَجٌ</span>: <a href="#OarBaAjN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmuWarBaju">
				<h3 class="entry"><span class="ar">المُؤَرَّجُ</span></h3>
				<div class="sense" id="AlmuWarBaju_A1">
					<p><span class="ar">المُؤَرَّجُ</span> † <em>The lion.</em> <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0046.pdf" target="pdf">
							<span>Lanes Lexicon Page 46</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
