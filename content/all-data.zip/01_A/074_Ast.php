<article class="root" id="Root_Ast">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/073_Asb">اسب</a></span>
				<span class="ar">است</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/075_AstAc">استاذ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AisotN">
				<h3 class="entry"><span class="ar">اِسْتٌ</span></h3>
				<div class="sense" id="AisotN_A1">
					<p><span class="ar">اِسْتٌ</span>, signifying The <em>podex,</em> or the <em>anus,</em> <span class="auth">(Ḳ,)</span> or signifying the former, and sometimes used as meaning the latter, <span class="auth">(Ṣ in art. <span class="ar">سته</span>,)</span> is with a conjunctive hemzeh, <span class="add">[written <span class="ar">ٱسْتٌ</span>, when not immediately preceded by a quiescence,]</span> and its final radical letter is clided; <a href="#satahN">for the original form is <span class="ar">سَتَهٌ</span></a>; <span class="auth">(Mṣb;)</span> <a href="index.php?data=12_s/030_sth">and it is mentioned in art. <span class="ar">سته</span></a>. <span class="auth">(Ḳ.)</span> <span class="add">[It is of the fem. gender.]</span> It is said in a prov., applied to him who fails of attaining the object that he seeks, <span class="ar long">أَخْطَأَتِ ٱسْتُهُ الحُفْرَةَ</span> <span class="add">[<em>His anus missed the hole in the ground</em>]</span>. <span class="auth">(Meyd.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">است</span> - Entry: <span class="ar">اِسْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AisotN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">اِسْتُ الدَّهْرِ</span> ‡ <em>The first,</em> or <em>beginning, of time;</em> <span class="auth">(A;)</span> <em>old,</em> or <em>ancient, time.</em> <span class="auth">(IB, A,* Ḳ.*)</span> One says, <span class="ar long">مَا زَالَ عَلَى ٱسْتِ الدَّهْرِ مَجْنُونًا</span> ‡ <span class="add">[<em>He ceased not,</em> or <em>has not ceased, from the beginning of time,</em> or <em>from old time, to be insane,</em> or <em>mad;</em> or]</span> <em>he always was,</em> or <em>always has been, known as being insane,</em> or <em>mad:</em> like as one says, <span class="ar long">عَلَى إِسِّ الدَّهْرِ</span>. <span class="auth">(AZ, Ṣ.)</span> And Aboo-Nukheyleh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَا زَالَ مُذْ كَانَ عَلَى ٱ سْتِ الدَّهْرِ</span> *</div> 
						<div class="star">* <span class="ar long">ذَا حُمُقٍ يَنْمِى وَعَقْلٍ يَحْرشى</span> *</div> 
					</blockquote>
					<p>‡ <span class="add">[<em>He ceased not,</em> or <em>has not ceased, to be, since he was in the beginning of time,</em> or <em>in old time,</em> i. e., <em>from the first of his existence, a person of increasing foolishness, and of decreasing intellect</em>]</span>. <span class="auth">(AZ, Ṣ.)</span> IB says, J has erred in mentioning <span class="ar">است</span> in this section <span class="add">[of the Ṣ]</span>; its proper place being in art. <span class="ar">سته</span>, where he has also mentioned it; for its hemzeh is conjunctive, by common consent; and if conjunctive, it is augmentative: also, his saying that they have changed the <span class="add">[final]</span> <span class="ar">س</span> in <span class="ar">إِسٌّ</span> into <span class="ar">ت</span>, like as they have changed the <span class="add">[final]</span> <span class="ar">س</span> of <span class="ar">طَسٌّ</span> into <span class="ar">ت</span>, making this word <span class="ar">طَسْتٌ</span>, is a mistake; for, were it so, the hemzeh of <span class="ar">است</span> would be disjunctive <span class="add">[in every case; whereas it is always conjunctive except after a pause, when it is pronounced with kesr]</span>: moreover, he has attributed this assertion to AZ, who never made it, but only mentioned <span class="ar long">است الدهر</span> with <span class="ar long">اسّ الدهر</span> because of their agreement in meaning. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">است</span> - Entry: <span class="ar">اِسْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AisotN_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar long">اِسْتُ الكَلْبَةِ</span> † <em>Calamity,</em> or <em>misfortune:</em> <span class="auth">(Ḳ:)</span> <em>adversity; difficulty; distress; affliction:</em> <span class="auth">(TA:)</span> <em>what is hated, disliked, disapproved, foul, abominable,</em> or <em>evil.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">است</span> - Entry: <span class="ar">اِسْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="AisotN_A4">
					<p>And <span class="ar long">اِسْتُ المَتْنِ</span> † <em>The desert:</em> <span class="auth">(Ḳ:)</span> or <em>the wide desert.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">است</span> - Entry: <span class="ar">اِسْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="AisotN_A5">
					<p><a href="index.php?data=12_s/030_sth">See also art. <span class="ar">سته</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusotieBN">
				<h3 class="entry"><span class="ar">أُسْتِىٌّ</span></h3>
				<div class="sense" id="OusotieBN_A1">
					<p><span class="ar">أُسْتِىٌّ</span> The <em>warp</em> of cloth; <span class="auth">(Ḳ;)</span> as also <span class="ar">أُسْدِىٌّ</span> and <span class="ar">أُزْدِىٌّ</span>: <span class="auth">(TA:)</span> but it is improperly mentioned in this art.; for it is <span class="add">[originally <span class="ar">أُسْتُوىٌ</span>,]</span> of the measure <span class="ar">أُفْعُولٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AisotieBN">
				<h3 class="entry"><span class="ar">اِسْتِىٌّ</span></h3>
				<div class="sense" id="AisotieBN_A1">
					<p><span class="ar">اِسْتِىٌّ</span> <em>Of,</em> or <em>relating to, the</em> <span class="ar">اِسْت</span>. <span class="auth">(TA in art. <span class="ar">سته</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
