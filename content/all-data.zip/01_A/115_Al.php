<article class="root" id="Root_Al">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/114_Akm">اكم</a></span>
				<span class="ar">ال</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/116_AlA">الا</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Aalo">
				<span class="pb" id="Page_0074"></span>
				<h3 class="entry"><span class="ar">اَلْ</span></h3>
				<div class="sense" id="Aalo_A1">
					<p><span class="ar">اَلْ</span> is a particle of determination: <span class="auth">(Mughnee, &amp;c.:)</span> or, accord. to some, it is a conjunct noun, and this is the correct opinion; but some say it is a conjunct particle; and some, a particle of determination: <span class="auth">(I'AK p. 40:)</span> <span class="add">[it is equivalent to our article <em>The</em>;]</span> as in <span class="ar">الرَّجُلُ</span> <span class="add">[<em>The man</em>]</span>: <span class="auth">(Ṣ and Ḳ in art. <span class="ar">لوم</span>, and I’Aḳ p. 48:)</span> accord. to Kh, <span class="add">[what is termed]</span> the determinative is <span class="ar">اَلْ</span> <span class="add">[altogether, and therefore it is called by some “the determinative alif and lám“]</span>; but accord. to Sb, it is the <span class="ar">ل</span> alone; <span class="add">[wherefore it is called by some, as in the Ṣ, &amp;c., “the lám of determination;”;]</span> so that accord. to Kh, the hemzeh is a hemzeh of disjunction; but accord. to Sb, it is a hemzeh of conjunction: <span class="auth">(I’Aḳ ubi suprà:)</span> <span class="add">[J says,]</span> the <span class="ar">ل</span> being quiescent, the conjunctive <span class="ar">ا</span> is prefixed to it in order that it may commence therewith; but when it is conjoined with what precedes it, the <span class="ar">ا</span> is dropped, as in <span class="ar">لِلرَّجُلِ</span>. <span class="auth">(Ṣ in art. <span class="ar">لوم</span>.)</span> Sometimes the Arabs suppress hemzeh after it; and sometimes they also suppress the <span class="ar">ا</span> of the article itself: thus, for <span class="ar">الأَحْمَرُ</span>, they say <span class="ar">الَحْمَرُ</span>, and <span class="ar">لَحْمَرُ</span>. <span class="auth">(Zj, cited in TA in art. <span class="ar">ايك</span>.)</span> In the dial. of some of the people of El-Yemen, <span class="auth">(TA in art. <span class="ar">ام</span>, q. v.,)</span> or in the dial. of Himyer, <span class="auth">(TA in art. <span class="ar">طيب</span>,)</span> <span class="ar">امْ</span> is used in the sense of <span class="ar">ال</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Aalo_A2">
					<p>It is used to distinguish a noun as known <span class="add">[to the hearer or reader in a particular and definite sense]</span>: <span class="auth">(Mughnee, I’Aḳ ubi suprà:)</span> first, by its being mentioned <span class="add">[before]</span>; <span class="auth">(Mughnee;)</span> as in <span class="add">[the words of the Ḳur lxxiii. 15 and 16,]</span> <span class="ar long">كَمَ أَرْسَلْنَا إِلَى فِرْعَوْنَ رَسُولًا فَعَصَى فِرْعَوْنُ الرَّسُولَ</span> <span class="add">[<em>Like as we sent unto Pharaoh an apostle, and Pharaoh disobeyed the apostle</em>]</span>; <span class="auth">(Mughnee, I’Aḳ;)</span> in which case, the pronoun may supply the place which it and the noun that it accompanies occupies: secondly, by its being conceived in the mind; as in <span class="add">[the Ḳur ix. 40,]</span> <span class="ar long">إِذْ هُمَا فِى الغَارِ</span> <span class="add">[<em>When they two were in the cave</em>]</span>: and thirdly, by its being applied to a thing present; and accord. to Ibn-ʼOsfoor, this does not occur except after nouns of indication, as in <span class="ar long">جَآءَ نِى هٰذَا الرَّجُلُ</span> <span class="add">[<em>This man</em> <span class="auth">(lit. <em>this, the man,</em>)</span> <em>came to me</em>]</span>; or after <span class="ar">أَىّ</span> in calling, as in <span class="ar long">يَا أَيُّهَا الرَّجُلُ</span> <span class="add">[<em>O man</em>]</span>; or after <span class="ar">إِذَا</span> denoting a thing's happening suddenly, or unexpectedly, as in <span class="ar long">خَرَجْتُ فَإِذَا الأَسَدُ</span> <span class="add">[<em>I went forth, and lo, there was the lion</em>]</span>; or after the noun denoting the present time, as <span class="ar">اَلْآنَ</span> <span class="add">[<em>Now</em>]</span>: but this requires consideration; for you say to the reviler of a man in you presence, <span class="ar long">لَا تَشْتِمِ الرَّجُلَ</span> <span class="add">[<em>Revile not thou the man</em>]</span>; and because that which is after <span class="ar">إِذَا</span> does not render determinate anything present at the time of speaking; and because that in <span class="ar">الآن</span> is really redundant, being inseparable, which the determinative is never known to be: the good example in this case is the saying in the Ḳur <span class="add">[v. 5]</span>, <span class="ar long">اَلْيَوْمَ أَكْمَلْتُ لَكُمْ دِيْنَكُمْ</span> <span class="add">[<em>This day I have completed for you your religion</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Aalo_A3">
					<p>It is also used to denote the species: first, to denote the totality of the individuals of the species; and this may have its place supplied by <span class="ar">كُلّ</span> used in its proper sense; <span class="auth">(Mughnee, I’Aḳ* ubi suprà;)</span> as in <span class="add">[the Ḳur iv. 32,]</span> <span class="ar long">وَخُلِقَ الإِنْسَانُ ضَعِيفًا</span> <span class="add">[<em>For man was created weak</em>]</span>: secondly, to denote the totality of the properties of the individuals, or the combination of all those properties in one thing; and this may have its place supplied by <span class="ar">كُلّ</span> used in a tropical sense; as in <span class="ar long">زَيْدٌ الرَّجُلُ عِلْمًا</span> <span class="add">[<em>Zeyd is the man in respect of knowledge;</em> as though he combined in himself the knowledge of all the individuals of his species]</span>; i. e., he is the complete, or perfect, <span class="add">[or we would rather say, preeminent,]</span> in knowledge; and hence, <span class="add">[in the Ḳur ii. 1,]</span> <span class="ar long">ذٰلِكَ الكِتَابُ</span> <span class="add">[<em>That is the book,</em> or <em>scripture;</em> as though combining in itself the excellences of all other books or scriptures; or meaning that is preeminently the book, or scripture]</span>: and thirdly, to denote the quiddity, or essence; and this may not have its place supplied by <span class="ar">كُلّ</span> used either properly or tropically; as in the saying, <span class="add">[in the Ḳur xxi. 31,]</span> <span class="ar long">وَجَعَلْنَا مِنَ المَآءِ كُلَّ شَىْءٍ حَىٍّ</span> <span class="add">[<em>And we have made of water</em> <span class="auth">(meaning, accord. to common opinion, sperma genitale,)</span> <em>everything living</em>]</span>; or, accord. to some, it is used in this case to distinguish a thing as known <span class="add">[in a particular sense]</span> by its being conceived in the mind. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Aalo_A4">
					<p>It is also used to denote predominance of application; as in <span class="ar">المَدِينَةُ</span> <span class="add">[<em>The city</em>]</span>, meaning the city of the Apostle; and <span class="ar">الكِتَابُ</span> <span class="add">[<em>The book</em>]</span>, meaning the book of Seebaweyh: and in this case, it may not be suppressed, except when the noun is used vocatively, or when it is prefixed to another noun which it governs in the gen. case; and in some anomalous instances, as in <span class="ar long">هٰذَا عَيُّوقٌ طَالِعًا</span> <span class="add">[<em>This is the star Capella, rising</em>]</span>, originally <span class="ar">العَيُّوقٌ</span>. <span class="auth">(I’Aḳ p. 51.)</span> <span class="add">[In a case of this kind, it is said in the Mughnee to be redundant; but I think it is clearly not so in any of the instances here mentioned, except the last; and this I would rather assign to a category yet to be noticed, in which <span class="ar">ال</span> is certainly redundant, and, by rule, inseparable.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Aalo_A5">
					<p>It is also prefixed to a noun transferred from its original application to that of a proper name; it being so prefixed to convey an allusion to the original signification; and such noun being generally an epithet, as <span class="ar">حَارِثٌ</span>; but sometimes an inf. n., as <span class="ar">فَضْلٌ</span>; and sometimes a generic noun, as <span class="ar">نُعْمَانٌ</span>; so that in any of these cases you may prefix <span class="ar">ال</span>, saying <span class="ar">الحَارِثُ</span> and <span class="ar">الفَضْلُ</span> and <span class="ar">النُّعْمَانُ</span>, with a view to the original signification; and you may suppress it, with a view to the actual state <span class="add">[which is that of a proper name]</span>: for when you mean that a name of this kind is given as one ominous of good, you prefix the <span class="ar">ال</span> in order to indicate this; as when you say <span class="ar">الحَارِثُ</span> with a view to a person's being thus named to prognosticate that he will live and be a tiller, or cultivator; but when you only consider it as a proper name, you do not prefix the <span class="ar">ال</span>: thus the prefix <span class="ar">ال</span> conveys a meaning not obtained without it; and therefore it is not redundant, as some assert it to be. <span class="auth">(I’Aḳ p. 50.)</span> <span class="add">[The author of the Mughnee is one of those who consider <span class="ar">ال</span> redundant in this case.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Aalo_A6">
					<p>It is in some cases redundant: and in some of these, it is inseparable; as in <span class="add">[a proper name which cannot be used with a view to an original application from which it has been transferred to that of a proper name though it may have been so transferred, such as]</span> <span class="ar">اللَّاتُ</span>, which is the name of a certain idol that was at Mekkeh <span class="add">[so called because a man used to moisten <span class="ar">سَوِيق</span> with clarified butter, for the pilgrims, at the place thereof]</span>; and, accord. to some, <span class="add">[as before mentioned,]</span> in <span class="ar">الآنِ</span>; and in the conjunct nouns <span class="ar">الَّذِى</span> and its variations, accord. to those who hold that a noun of this kind is rendered determinate by its complement: in other cases, where it is redundant, it is separable; and this is when it is prefixed to a proper name by poetic licence, as in <span class="ar long">بَنَاتُ الأَوْبَرِ</span> for <span class="ar long">بَنَاتُ أَوْبَرَ</span>, a species of truffle; or, accord. to Mbr, this is not a proper name, and the <span class="ar">ال</span> is not redundant; and when it is prefixed to a specificative, as in <span class="ar long">طِبْتَ النَّفْسَ</span> for <span class="ar long">طِبْتَ نَفْسًا</span>, accord. to the Basrees, who hold, in opposition to the Koofees, that the specificative may only be indeterminate; <span class="auth">(I’Aḳ p. 49;)</span> <span class="add">[and, in like manner, as redundant and separable,]</span> it is irregularly prefixed <span class="add">[by poetic licence]</span> in <span class="ar">الأَمْسِ</span> <span class="add">[q. v.]</span>, when it is left in its original form with kesr. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Aalo_A7">
					<p>Accord. to the Koofees, and some of the Basrees, and many of the later authors, it may also supply the place of the affixed pronoun; and such they hold to be the case in the saying in the Ḳur <span class="add">[lxxix. 41]</span>, <span class="ar long">فَإِنَّ ٱلْجَنَّةَ هِىَ ٱلْمَأوِى</span> <span class="add">[<em>Verily Paradise, it shall be his place of abode</em>]</span>; and in <span class="ar long">مَرَرْتُ بِرَجُلٍ حَسَنٍ الوَجْهُ</span> <span class="add">[<em>I passed by a man beautiful in his face</em>]</span>; and <span class="ar long">ضُرِبَ زَيْدٌ الظَّهْرُ وَالبَطْنُ</span> <span class="add">[<em>Zeyd was beaten, his back and his belly</em>]</span>; when <span class="ar">الوجه</span> and <span class="ar">الظهر</span> and <span class="ar">البطن</span> are thus in the nom. case: but those who deny its being used in this manner hold that <span class="ar">لَهُ</span> is to be understood in the verse of the Ḳur, and <span class="ar">مِنْهُ</span> in the other examples: and Ibn-Málik restricts the licence to cases not including the <span class="ar">صِلَة</span> <span class="add">[or complement of <span class="ar">ال</span> used in the manner which is here next to be explained]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Aalo_A8">
					<p>It is also a conjunct noun in the sense of <span class="ar">الَّذِى</span> and its variations; and as such is prefixed to an act. part. n., and to a pass. part. n., and, as some say, to a simple epithet; <span class="auth">(Mughnee, and I’Aḳ p. 43;)</span> as <span class="ar">الضَّارِبُ</span> <span class="add">[which is equivalent to <span class="ar long">الَّذِى يَضْرِبُ</span>]</span>, and <span class="ar">المَضْرُوبُ</span> <span class="add">[which is equivalent to <span class="ar long">الَّذِى ضُرِبَ</span>]</span>, and <span class="ar long">الحَسَنُ الوَجْهِ</span>: <span class="auth">(I’Aḳ:)</span> but this last not to be regarded, as it cannot be rendered by means of a verb. <span class="auth">(Mughnee.)</span> As such, also, it is sometimes prefixed to an adverbial noun, <span class="auth">(Mughnee and I’Aḳ,)</span> extraordinarily; <span class="auth">(I’Aḳ;)</span> as in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَنْ لَا يَزَالُ شَاكِرًا عَلَى يلْمَعَهْ</span> *</div> 
						<div class="star">* <span class="ar long">فَهْوَ حَرٍ بِعِيشَةٍ ذَاتِ سَعَهْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Whoso ceases not to be grateful,</em> or <em>thankful, for what is with him,</em> or <em>what he has, he is worthy of a state of life such as is attended with plenty.</em>]</span> <span class="auth">(Mughnee and I’Aḳ.)</span> As such it is also sometimes prefixed to a nominal proposition; as in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَنَ القَوْمِ الرَّسُولُ ٱللّٰهِ مِنْهُمْ</span> *</div> 
						<div class="star">* <span class="ar long">لَهُمْ دَانَتْ رِقَابُ بِنَى مَعَدِّ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Of the people of whom is the apostle of God,</em> of those <em>to whom the necks of the sons of Ma' add have become abased</em>]</span>. <span class="auth">(Mughnee and I’Aḳ.)</span> <span class="pb" id="Page_0075"></span>And as such it is also sometimes prefixed to a verbal proposition, of which the verb is an aor.; which shows that it is not <span class="add">[in this case]</span> a particle of determination; <span class="auth">(Mughnee;)</span> as in the phrase, <span class="ar long">صَوْتُ الحِمَارِ اليُجَدَّعُ</span> <span class="add">[<em>The voice of the ass that has his ear,</em> or <em>ears, cut off</em>]</span>. <span class="auth">(T and Mughnee.)</span> But all these three cases are peculiar to poetry; contrary to the opinion of Akh, and, with respect to the last case, to that of Ibn-Málik. <span class="auth">(Mughnee.)</span> <span class="add">[Respecting the last instance, <a href="index.php?data=05_j/041_jdE">see also art. <span class="ar"></span>jdE</a>.]</span> Another instance of its usage prefixed in this sense to an aor. is the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَا أَنْتَ بِالْحَكَمَ التُرْضَى حُكُومَتُهُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Thou art not the judge whose judgment is approved</em>]</span>; <span class="auth">(IAmb, T, I’Aḳ)</span> a saying of El-Farezdaḳ: <span class="auth">(IAmb, T:)</span> it is an extraordinary case; <span class="auth">(I’Aḳ;)</span> and is <span class="add">[said to be]</span> an instance of a bad poetic license, the like of which in prose would be an error by common consent. <span class="auth">(Expos. of the Shudhoor edh-Dhahab.)</span> In like manner, one says, accord. to AZ, <span class="ar long">هٰذَا اليَضْرِبُكَ</span>, meaning <em>This is he who beats thee;</em> and <span class="ar long">رَأَيْتُ اليَضْرِبُكَ</span> <em>I saw him who beats thee;</em> and <span class="ar long">هٰذَا الوُضِعَ لِلشِّعْرِ</span> <em>This is what is appropriated to poetry.</em> <span class="auth">(T: <span class="add">[in which this last ex. is perhaps intended to intimate that the prefixing of <span class="ar">ال</span> in this manner to a verb is allowable only in poetry.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Aalo_A9">
					<p>The Arabs also say, <span class="ar long">هَوَ الحَصِينُ أَنْ يُرَامَ وَهُوَ العَزِيزُ أَنْ يُضَامَ</span>, meaning <span class="ar long">أَحْصَنُ مِنْ أَنْ يُرَام وَأَعَزُّ مِنْ ذَنْ يُضَام</span> <span class="add">[<em>He is more strongly fortified,</em> or <em>protected against attack, than that he will be sought,</em> or <em>desired, and he is more mighty than that he will be injured;</em> i. e., <em>too strongly fortified,</em> or <em>protected against attack, to be sought,</em> or <em>desired, and too mighty to be injured:</em> <a href="#min">see <span class="ar">مِن</span></a>.]</span> <span class="auth">(TA in art. <span class="ar">لوم</span>. <span class="add">[But <span class="ar">الحِصْنُ</span> is there erroneously put for <span class="ar">الحَصِينُ</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">اَلْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Aalo_B1">
					<p>Among strange usages, <a href="#Oalo">is that of <span class="ar">أَلْ</span></a> as an interrogative, mentioned by Ḳṭr; as in <span class="ar long">أَلْ فَعَلْتَ</span> in the sense of <span class="ar long">هَلْ فَعَلْتَ</span> <span class="add">[<em>Didst thou do?</em> or <em>hast thou done?</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilBN">
				<h3 class="entry"><span class="ar">إِلٌّ</span></h3>
				<div class="sense" id="IilBN_A1">
					<p><span class="ar">إِلٌّ</span> <em>Anything which has a quality requiring it to be regarded as sacred,</em> or <em>inviolable; which has some right pertaining to it:</em> and thus used in particular senses here following. <span class="auth">(R, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IilBN_A2">
					<p><em>Relationship;</em> or <em>nearness with respect to kindred;</em> <span class="auth">(Fr, T, Ṣ, M, R, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِلَّةٌ↓</span></span>, <span class="auth">(Fr, T, Ḳ,)</span> of which the pl. is <span class="ar">إِلَلٌ</span>. <span class="auth">(Ḳ.)</span> So in the Ḳur <span class="add">[ix. 8]</span>, <span class="ar long">لَا يَرْقُبُوا فِيكُمْ إِلَّا</span> <span class="auth">(Fr, T)</span> <em>They will not regard, with respect to you, relationship;</em> <span class="auth">(Bḍ, Jel;)</span> accord. to some. <span class="auth">(Bḍ.)</span> And so in a trad. of ʼAlee, <span class="ar long">يَخُونُ العَهْدَ وَيَقْطَعُ الإِلَّ</span> <span class="add">[<em>He is unfaithful to the covenant, and cuts the tie of relationship</em>]</span>. <span class="auth">(TA.)</span> Hassán Ibn-Thábit says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَعَمْرُكَ إِنَّ إِلَّكَ مِنْ قُرَيْشٍ</span> *</div> 
						<div class="star">* <span class="ar long">كَإِلِّ السَّقْبِ مِنْ رَأْلِ النَّعَامِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>By thy life, thy relationship to Kureysh is like the relationship of the young camel to the young of the ostrich</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IilBN_A3">
					<p><em>Good origin.</em> <span class="auth">(Ḳ.)</span> So, accord. to some, in a saying of Aboo-Bekr, which see below. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IilBN_A4">
					<p><em>I. q.</em> <span class="ar">مَعْدِنٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">مَعْدِنٌ صَحِيحٌ</span> <span class="add">[as meaning <em>A place,</em> or <em>person, whence a thing,</em> or <em>person, originates, free from imperfection,</em> or <em>from everything that would induce doubt or suspicion or evil opinion</em>]</span>. <span class="auth">(El-Muärrij, TA: <span class="add">[in which the verse of Hassán cited above is given as an ex. of this signification.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IilBN_A5">
					<p><em>A compact,</em> or <em>covenant;</em> or <em>one by which a person becomes responsible for the safety, or safe-keeping, of a person or thing;</em> syn. <span class="ar">عَهْدٌ</span>: <span class="auth">(AO, Aboo-Is- hák, T, Ṣ, M, R, Ḳ:)</span> <em>a confederacy,</em> or <em>league;</em> syn. <span class="ar">حِلْفٌ</span>; <span class="auth">(Aboo-Is-ḥáḳ, T, M, Ḳ;)</span> and so, accord. to some, in the Ḳur ubi suprà: <span class="auth">(Bḍ:)</span> <em>a covenant between two parties by which either is bound to protect the other;</em> syn. <span class="ar">جُوَارٌ</span>: <span class="auth">(Aboo-Is-ḥáḳ, T, R:)</span> <em>a promise,</em> or <em>an assurance, of security</em> or <em>safety;</em> or <em>indemnity;</em> syn. <span class="ar">أَمَانٌ</span>; <span class="auth">(Ḳ;)</span> a meaning which it has, accord. to some, in the verse of the Ḳur cited above. <span class="auth">(TA.)</span> Hence, <span class="ar long">وَفِىُّ الإِلِ</span> <em>A fulfiller, performer,</em> or <em>keeper, of the compact,</em> or <em>covenant.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IilBN_A6">
					<p><em>Lordship;</em> syn. <span class="ar">رُبُوبِيَّةٌ</span>. <span class="auth">(M, Ḳ.)</span> So in the Ḳur ubi suprà, accord. to some. <span class="auth">(Bḍ.)</span> And so in the saying of Aboo-Bekr, above referred to, when he heard the rhyming prose of Museylimeh, <span class="ar long">هٰذَا كَلَامٌ لَمْ يَخْرُجْ مِنْ إِلٍّ</span> <span class="add">[<em>This is language which did not proceed from lordship</em>]</span>: so explained by AʼObeyd: <span class="auth">(Suh, TA:)</span> or it has here another signification, mentioned before; the meaning being, which did not come from the origin whence came the Ḳur-án: or, accord. to some, it has here the signification next following. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="IilBN_A7">
					<p><em>Revelation,</em> or <em>inspiration.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="IilBN_A8">
					<p><span class="ar">الإِلُّ</span> also signifies <em>God:</em> <span class="add">[like the word <span class="he">אֵל</span> or rather <span class="he">הָאֵל</span> as used in Hebrew:]</span> <span class="auth">(T, Ṣ, M, Ḳ:)</span> so say Mujáhid and Esh-Shaabee: <span class="auth">(T:)</span> and so it is said to signify in the verse of the Ḳur cited above: <span class="auth">(T, TA:)</span> <span class="add">[and so it seems to signify in the saying of Aboo-Bekr, also cited above, accord. to the M:]</span> but Aboo-Is- hák disallows this; and so does Suh, in the R. <span class="auth">(TA.)</span> Ibn-El-Kelbee says, <span class="auth">(M,)</span> when <span class="ar">إِلُّ</span> ends any name, it has this meaning, and is the complement of a prefixed noun; and so <span class="ar">إِيلُ</span>; <span class="auth">(M, Ḳ;)</span> as in <span class="ar">جَبْرَئِلُّ</span> <span class="add">[and <span class="ar">جَبْرَئِيلُ</span>, &amp;c.]</span>; and so say most of the learned: <span class="auth">(TA:)</span> but this is not a valid assertion; for were it so, <span class="ar">جَبْرَئِلُّ</span> and the like would be perfectly decl.: <span class="auth">(M:)</span> some say that these names are constructed inversely, after the manner of the language of the 'Ajam; <span class="ar">ال</span> and <span class="ar">ايل</span> meaning <em>servant,</em> and the first part of the name being a name of God. <span class="auth">(Suh, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IilBN_B1">
					<p><em>I. q.</em> <span class="ar">شَخْصٌ</span> <span class="add">[used in a pl. sense]</span>. <span class="auth">(Mughnee in art. <span class="ar">إِلَّا</span>. <span class="add">[<a href="index.php?data=01_A/116_AlA">See what is said to be an ex. of this meaning in a verse of Dhu-r-Rummeh cited in art. <span class="ar">الا</span></a> in the present work.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ال</span> - Entry: <span class="ar">إِلٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="IilBN_B2">
					<p><span class="add">[It is said that]</span> <span class="ar">إِلٌّ</span> is also <em>syn. with</em> <span class="ar">جَارٌ</span> <span class="add">[<em>A neighbour;</em>, &amp;c.]</span>. <span class="auth">(Ḳ: <span class="add">[and so, accord. to the TA, in the M; but I have consulted the M without finding this explanation, and think it to be probably a mistranscription for <span class="ar">جُوَارٌ</span>, (<a href="#IilBN_A5">see above</a>,)</span> as in the T and R.]</span>)</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IilBapN">
				<h3 class="entry"><span class="ar">إِلَّةٌ</span></h3>
				<div class="sense" id="IilBapN_A1">
					<p><span class="ar">إِلَّةٌ</span>: <a href="#IilBN">see <span class="ar">إِلٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilBieBN">
				<h3 class="entry"><span class="ar">إِلِّىٌّ</span></h3>
				<div class="sense" id="IilBieBN_A1">
					<p><span class="ar long">أَمْرٌ إِلّلىٌّ</span> <em>A thing,</em> or <em>an affair, relating,</em> or <em>attributable, to</em> <span class="ar">الإِل</span>, meaning either <em>God,</em> or <em>revelation</em> or <em>inspiration.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0074.pdf" target="pdf">
							<span>Lanes Lexicon Page 74</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0075.pdf" target="pdf">
							<span>Lanes Lexicon Page 75</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
