<article class="root" id="Root_Adb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/038_Ad">اد</a></span>
				<span class="ar">ادب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/040_Adr">ادر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Adb_1">
				<h3 class="entry">1. ⇒ <span class="ar">أدب</span></h3>
				<div class="sense" id="Adb_1_A1">
					<p><span class="ar">أَدَبَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِبُ</span>}</span></add>, inf. n. <span class="ar">أِدْبٌ</span>, <em>He invited</em> <span class="auth">(people, Ṣ, or a man, Ḳ)</span> <em>to his repast,</em> or <em>banquet;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">آدَبَ↓</span></span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">آدَبَ إِلَى طَعَامِهِ</span> aor <span class="ar">يُودِبُ</span> <span class="add">[or <span class="ar">يُؤْدِبُ</span>]</span>, <span class="auth">(AZ, Ṣ,)</span> inf. n. <span class="ar">إِيدَابٌ</span> <span class="add">[originally <span class="ar">إِئْدَابٌ</span>]</span>. <span class="auth">(AZ, Ṣ, Ḳ.)</span> You say, <span class="ar long">أَدَبَ القَوْمَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">أَدَبَ عَلَى القَوْمِ</span>, aor. as above, <span class="auth">(T,)</span> <em>He invited the people to his repast.</em> <span class="auth">(T, Ṣ.)</span> And <span class="ar long">أَدَبَهُمْ عَلَى الأَمرِ</span> <em>He collected them together for the affair.</em> <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">أُودِبُ↓ جِيرَانَكَ لِتُشَاوِرَهُمْ</span></span> <span class="add">[<em>I will collect thy neighbours in order that thou mayest consult with them</em>]</span>. <span class="auth">(A.)</span> The primary signification of <span class="ar">أَدْبٌ</span> is The act of <em>inviting.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Adb_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">أَدَبٌ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِبُ</span>}</span></add>; <span class="auth">(Mṣb, Ḳ;)</span> or <span class="ar">أَدِبَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْدَبُ</span>}</span></add>; <span class="auth">(so in a copy of the M;)</span> inf. n. <span class="ar">أَدْبٌ</span>, <span class="auth">(M, Mgh, Mṣb,)</span> or <span class="ar">أَدَبٌ</span>; <span class="auth">(Ḳ;)</span> <em>He made a repast,</em> or <em>banquet,</em> <span class="auth">(M, Mṣb, Ḳ,)</span> <em>and invited people to it;</em> <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">آدَبَ↓</span></span>, <span class="auth">(M,)</span> aor. and inf. n. as above: <span class="auth">(TA:)</span> or <em>he collected and invited people to his repast.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Adb_1_A3">
					<p><span class="add">[Hence also, as will be seen below, voce <span class="ar">أَدَبٌ</span>]</span> <span class="ar">أَدَبَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِبُ</span>}</span></add>, inf. n. <span class="ar">أَدْبٌ</span>, <em>He taught him the discipline of the mind, and the acquisition of good qualities and attributes of the mind</em> or <em>soul;</em> <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">أدّبهُ↓</span></span>, <span class="add">[inf. n. <span class="ar">تَأْدِيبٌ</span>, signifies <em>the same;</em>]</span> <em>he taught him what is termed</em> <span class="ar">أَدَب</span> <span class="add">[or <em>good discipline of the mind and manners,</em>, &amp;c.; i. e. <em>he disciplined him,</em> or <em>educated him, well; rendered him well-bred, wellmannered, polite; instructed him in polite accomplishments;</em>, &amp;c.]</span>: <span class="auth">(Ṣ, M, A, Mgh, Ḳ:)</span> or the latter verb, inf. n. <span class="ar">تَأْدِيبُ</span>, signifies <em>he taught him well,</em> or <em>much, the discipline of the mind, and the acquisition of good qualities and attributes of the mind</em> or <em>soul:</em> and hence, this latter also signifies <em>he disciplined him, chastised him, corrected him,</em> or <em>punished him, for his evil conduct;</em> because discipline, or chastisement, is a means of inviting a person to what is properly termed <span class="ar">الأَدَبُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Adb_1_B1">
					<p><span class="ar">أَدُبَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْدُبُ</span>}</span></add>, <span class="auth">(AZ, T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَدَبٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>He was</em> or <em>became, characterized by what is termed</em> <span class="ar">أَدَب</span> <span class="add">[or <em>good discipline of the mind and manners,</em>, &amp;c.; i. e., <em>well disciplined, well-educated, well-bred,</em> or <em>well-mannered, polite, instructed in polite accomplishments,</em>, &amp;c.]</span>. <span class="auth">(AZ, T, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Adb_2">
				<h3 class="entry">2. ⇒ <span class="ar">ادّبهُ</span></h3>
				<div class="sense" id="Adb_2_A1">
					<p><a href="#Adb_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Adb_4">
				<h3 class="entry">4. ⇒ <span class="ar">آَدَب</span></h3>
				<div class="sense" id="Adb_4_A1">
					<p><a href="#Adb_1">see 1</a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Adb_4_A2">
					<p><span class="ar long">آدَبَ البِلَادَ</span>, aor. and inf. n. as above, † <em>He filled the provinces,</em> or <em>country, with justice,</em> or <em>equity.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Adb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأدّب</span></h3>
				<div class="sense" id="Adb_5_A1">
					<p><span class="ar">تأدّب</span> <em>He learned,</em> or <em>was taught, what is termed</em> <span class="ar">أَدَب</span> <span class="add">[or <em>good discipline of the mind and manners,</em>, &amp;c.; i. e. <em>he became,</em> or <em>was rendered, well-disciplined, well-educated, well-bred, wellmannered, polite, instructed in polite accomplishments,</em>, &amp;c.]</span>; as also<span class="arrow"><span class="ar">استأدب↓</span></span>. <span class="auth">(Ṣ, Mgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Adb_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأدب</span></h3>
				<div class="sense" id="Adb_10_A1">
					<p><a href="#Adb_5">see 5</a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadobN">
				<span class="pb" id="Page_0035"></span>
				<h3 class="entry"><span class="ar">أَدْبٌ</span></h3>
				<div class="sense" id="OadobN_A1">
					<p><span class="ar">أَدْبٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> or, accord. to some, <span class="arrow"><span class="ar">إِدْبٌ↓</span></span>, <span class="auth">(TA,)</span> <em>Wonderful;</em> or <em>a wonderful thing;</em> syn. <span class="ar">عَجَبٌ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أُدْبَةٌ↓</span></span> <span class="add">[used in the latter sense]</span>. <span class="auth">(Ḳ.)</span> You say,<span class="arrow"><span class="ar long">جَآءَ فُلَانٌ بِأَمْرٍ إِدْبٍ↓</span></span> <em>Such a one did a wonderful thing.</em> <span class="auth">(Aṣ, T.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: <span class="ar">أَدْبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OadobN_B1">
					<p><a href="#OadabN">See also <span class="ar">أَدَبٌ</span></a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IidobN">
				<h3 class="entry"><span class="ar">إِدْبٌ</span></h3>
				<div class="sense" id="IidobN_A1">
					<p><span class="ar">إِدْبٌ</span>: <a href="#OadabN">see <span class="ar">أَدَبٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadabN">
				<h3 class="entry"><span class="ar">أَدَبٌ</span></h3>
				<div class="sense" id="OadabN_A1">
					<p><span class="ar">أَدَبٌ</span>, so termed because it invites men to the acquisition of praiseworthy qualities and dispositions, and forbids them from acquiring such as are evil, <span class="auth">(T, Mgh,)</span> signifies <em>Discipline of the mind;</em> and <em>good qualities and attributes of the mind</em> or <em>soul:</em> <span class="auth">(Mṣb:)</span> or <em>every praiseworthy discipline by which a man is trained in any excellence:</em> <span class="auth">(AZ, Mgh, Mṣb:)</span> <span class="add">[<em>good discipline of the mind and manners; good education; good breeding; good manners; politeness; polite accomplishments:</em>]</span> <em>i. q.</em> <span class="ar">ظَرْفٌ</span> <span class="add">[as meaning <em>excellence,</em> or <em>elegance, of mind, manners, address, and speech</em>]</span>: and <em>a good manner of taking</em> or <em>receiving</em> <span class="add">[what is given or offered or imparted, or what is to be acquired]</span>: <span class="auth">(M, A, Ḳ:)</span> or <em>good qualities and attributes of the mind</em> or <em>soul,</em> and the <em>doing of generous</em> or <em>honourable actions:</em> <span class="auth">(El-Jawáleeḳee:)</span> or the <em>practice of what is praiseworthy both in words and actions:</em> or the <em>holding,</em> or <em>keeping, to those things which are approved,</em> or <em>deemed good:</em> or the <em>honouring of those who are above one, and being gentle, courteous,</em> or <em>civil, to those who are below one:</em> <span class="auth">(Towsheeh:)</span> or <em>a faculty which preserves him in whom it exists from what would disgrace him:</em> <span class="auth">(MF:)</span> it is of two kinds, <span class="ar long">أَدَبُ النَّفْسِ</span> <span class="add">[which embraces all the significations explained above]</span>, and <span class="ar long">أَدَبُ الدَّرْسِ</span> <span class="add">[which signifies <em>the discipline to be observed in the prosecution of study, by the disciple with respect to the preceptor, and by the preceptor with respect to the disciple:</em> see ‘Haji Khalfæ Lexicon,’ Vol. I. p. 212]</span>: <span class="auth">(Ṣ, Bṭl, Mgh:)</span> <span class="add">[also <em>deportment,</em> or <em>a mode of conduct</em> or <em>behaviour,</em> absolutely; for one speaks of good <span class="ar">أَدَب</span> and bad <span class="ar">أَدَب</span>:]</span> the pl. is <span class="ar">آدَابٌ</span> <span class="add">[which is often employed, and so is the sing. also, as signifying the <em>rules of discipline to be observed in the exercise of a function,</em> such as that of a judge, and of a governor; and <em>in the exercise of an art,</em> such as that of the disputer, and the orator, and the poet, and the scribe;, &amp;c.]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: <span class="ar">أَدَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadabN_A2">
					<p><span class="ar long">عِلْمُ الأَدَبِ</span> signifies <span class="add">[<em>The science of philology;</em> or]</span> <em>the science by which one guards against error in the language of the Arabs, with respect to words and with respect to writing;</em> <span class="auth">(‘Haji Khalfæ Lexicon,’ Vol. I. p. 215;)</span> <span class="add">[and so, simply, <span class="ar">الأَدَبُ</span>: which is also used to signify <em>polite literature:</em> but in this sense, and like wise]</span> as applied to <em>the sciences relating to the Arabic language,</em> <span class="add">[or <em>the philological sciences,</em> which are also termed<span class="arrow"><span class="ar long">العُلُومُ الأَدَبِيَّاتُ↓</span></span>,]</span> <span class="ar">الأَدَبُ</span> is a post-classical term, innovated in the time of El-Islám. <span class="auth">(El-Jawáleeḳee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: <span class="ar">أَدَبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OadabN_B1">
					<p><span class="ar long">أَدَبُ البَحْرِ</span>, <span class="auth">(A, Ḳ,)</span> or<span class="arrow"><span class="ar long">أَدْبُ↓ البَحْرِ</span></span>, <span class="auth">(T, L,)</span> ‡ <em>The abundance of the water of the sea.</em> <span class="auth">(T, A, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OudobapN">
				<h3 class="entry"><span class="ar">أُدْبَةٌ</span></h3>
				<div class="sense" id="OudobapN_A1">
					<p><span class="ar">أُدْبَةٌ</span>: <a href="#maOodubapN">see <span class="ar">مَأْدُبَةٌ</span></a>:</p>						
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: <span class="ar">أُدْبَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OudobapN_B1">
					<p><a href="#OadobN">and see also <span class="ar">أَدْبٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadabieBN">
				<h3 class="entry"><span class="add">[<span class="ar">أَدَبِىٌّ</span>]</span></h3>
				<div class="sense" id="OadabieBN_A1">
					<p><span class="add">[<span class="ar">أَدَبِىٌّ</span> <em>Of, or relating to, what is termed</em> <span class="ar">أَدَب</span>, or <span class="ar">الأَدَب</span>. Hence <span class="ar long">العُلُومُ الأَدَبِيَّاتُ</span> <a href="#OadabN">see: <span class="ar">"أَدَبٌ"</span></a>, last sentence but one.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadiybN">
				<h3 class="entry"><span class="ar">أَدِيبٌ</span></h3>
				<div class="sense" id="OadiybN_A1">
					<p><span class="ar">أَدِيبٌ</span> <em>Characterized by what is termed</em> <span class="ar">أَدَب</span> <span class="add">[or <em>good discipline of the mind and manners,</em>, &amp;c.; i. e. <em>well-disciplined, well-educated, well-bred,</em> or <em>well-mannered; polite; instructed in polite accomplishments,</em> or <em>an elegant scholar;</em>, &amp;c.]</span>: <span class="auth">(T, Ṣ, M, Mgh, Ḳ:)</span> pl. <span class="ar">أُدَبَآءٍ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادب</span> - Entry: <span class="ar">أَدِيبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadiybN_A2">
					<p><a href="#mawadBabN">See also <span class="ar">مَؤَدَّبٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mdabu">
				<h3 class="entry"><span class="ar">آدَبُ</span></h3>
				<div class="sense" id="Mdabu_A1">
					<p><span class="ar">آدَبُ</span> <span class="add">[originally <span class="ar">أَأْدَبُ</span>, <em>More,</em> or <em>most, characterized by what is termed</em> <span class="ar">أَدَب</span>; i. e. <em>better,</em> or <em>best, disciplined, educated, bred,</em> or <em>mannered; more,</em> or <em>most, polite;</em>, &amp;c.]</span>. You say, <span class="ar long">هُوَمِنْ آدَبِ النَّاسِ</span> <span class="add">[<em>He is of the best disciplined,</em>, &amp;c., <em>of men</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MdibN">
				<h3 class="entry"><span class="ar">آدِبٌ</span></h3>
				<div class="sense" id="MdibN_A1">
					<p><span class="ar">آدِبٌ</span> One <em>who invites people to a repast,</em> or <em>banquet:</em> <span class="auth">(T, Ṣ, Mṣb:)</span> pl. <span class="ar">أَدَبَةٌ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOodabapN">
				<h3 class="entry"><span class="ar">مَأْدَبَةٌ</span></h3>
				<div class="sense" id="maOodabapN_A1">
					<p><span class="ar">مَأْدَبَةٌ</span>: <a href="#maOodubapN">see what next follows</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOodubapN">
				<h3 class="entry"><span class="ar">مَأْدُبَةٌ</span></h3>
				<div class="sense" id="maOodubapN_A1">
					<p><span class="ar">مَأْدُبَةٌ</span> <em>A repast,</em> or <em>banquet, to which guests are invited;</em> <span class="auth">(AʼObeyd, T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> or <em>made on account of a wedding:</em> <span class="auth">(M, Ḳ:)</span> as also<span class="arrow"><span class="ar">مَأْدُبَةٌ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> or, accord. to AʼObeyd, this latter has a different signification, as will be seen below, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">مَأْدُبَةُ↓</span></span>, <span class="auth">(IJ,)</span> and<span class="arrow"><span class="ar">أُدْبَةٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> pl. <span class="ar">مَآدِبُ</span>. <span class="auth">(Ṣ.)</span> In a trad., the Ḳur-án is called <span class="ar long">مَأْدُبَةُ ٱللّٰهِ فِى الأَرْضِ</span>, or<span class="arrow"><span class="ar">مَأْدَبَة↓</span></span>; and AʼObeyd says that, if we read <span class="ar">مأدُبة</span>, the meaning is, <em>God's repast which He has made in the earth, and to which He has invited mankind;</em> but if we read <span class="ar">مأدَبة</span>, this word is of the measure <span class="ar">مَفْعَلَةٌ</span> from <span class="ar">الأَدَبُ</span>, <span class="add">[and the meaning is, <em>a means which God has prepared in the earth for men's learning good discipline of the mind,</em>, &amp;c.; it being a noun similar to <span class="ar">مَثْرَاةٌ</span> and <span class="ar">مَكْثَرَةٌ</span>, &amp;c.:]</span> El-Aḥmar, however, makes both words synonymous. <span class="auth">(T, M,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOodibapN">
				<h3 class="entry"><span class="ar">مَأْدِبَةٌ</span></h3>
				<div class="sense" id="maOodibapN_A1">
					<p><span class="ar">مَأْدِبَةٌ</span>: <a href="#maOodubapN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWadBabN">
				<h3 class="entry"><span class="ar">مُؤَدَّبٌ</span></h3>
				<div class="sense" id="muWadBabN_A1">
					<p><span class="arrow"><span class="ar long">أَدِيبٌ↓ مُؤَدَّبٌ</span></span> A camel <em>well-trained and broken.</em> <span class="auth">(T, L.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoduwbapN">
				<h3 class="entry"><span class="ar">مَأْدُوبَةٌ</span></h3>
				<div class="sense" id="maOoduwbapN_A1">
					<p><span class="ar">مَأْدُوبَةٌ</span>, occurring in a verse of 'Adee, <span class="add">[which I do not anywhere find quoted,]</span> She <span class="add">[app. a bride]</span> <em>for whom a repast,</em> or <em>banquet, has been made.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0034.pdf" target="pdf">
							<span>Lanes Lexicon Page 34</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0035.pdf" target="pdf">
							<span>Lanes Lexicon Page 35</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
