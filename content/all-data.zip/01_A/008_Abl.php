<article class="root" id="Root_Abl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/007_Abq">ابق</a></span>
				<span class="ar">ابل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/009_Abn">ابن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبل</span></h3>
				<div class="sense" id="Abl_1_A1">
					<p><span class="ar">أَبِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْبَلُ</span>}</span></add>; <span class="auth">(Ṣ, M, Ḳ;)</span> and <span class="ar">أَبَلَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُلُ</span>}</span></add>; <span class="auth">(Ḳ;)</span>, inf. n. <span class="ar">أَبَالَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> of the former verb, <span class="auth">(Ṣ, M, TA,)</span> or, accord. to Sb, <span class="ar">إِبَالَةٌ</span>, because it denotes an office, and, if so, of the latter verb, <span class="auth">(TA,)</span> and <span class="ar">أَبَلٌ</span>, <span class="auth">(M, Ḳ,)</span> which is of the former verb, <span class="auth">(M, TA,)</span> and <span class="ar">أَبَلَةٌ</span> <span class="add">[like <span class="ar">غَلَبَةٌ</span>]</span>; <span class="auth">(T;)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>was,</em> or <em>became, skilled in the good management of camels</em> <span class="auth">(Ṣ, M, Ḳ)</span> and <em>of sheep</em> or <em>goats.</em> <span class="auth">(M, Ḳ.)</span> <span class="ar">إِبَالَةٌ</span>, like <span class="ar">كِتَابَةٌ</span> <span class="add">[in measure]</span>, signifies The <em>management,</em> or <em>tending,</em> <span class="auth">(A, Ḳ, TA,)</span> <em>of</em> <span class="ar">مَال</span> <span class="add">[meaning <em>camels</em> or <em>other beasts</em>]</span>. <span class="auth">(A, TA.)</span> You say, <span class="ar long">هُوَ حَسَنُ الإِبَالَةِ</span> <em>He is good in the management,</em> or <em>tending, of his</em> <span class="ar">مال</span> <span class="add">[or <em>camels, &amp;c.</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abl_1_A2">
					<p><span class="ar">أَبَلَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِلُ</span>}</span></add>: <a href="#Abl_2">see 2</a>, second signification.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abl_1_A3">
					<p><span class="ar long">أُبِلَتِ الإِبِلُ</span> <em>The camels were gotten,</em> or <em>acquired, as permanent property.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Abl_1_A4">
					<p><span class="ar long">أَبِلَتِ الإِبِلُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْبَلُ</span>}</span></add>; and <span class="ar">أَبَلَت</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُلُ</span>}</span></add>; <span class="auth">(Ḳ;)</span>, inf. n. <span class="add">[of the former]</span> <span class="ar">أَبَلٌ</span> and <span class="add">[of the latter]</span> <span class="ar">أُبُولٌ</span>; <span class="auth">(TA;)</span> <em>The camels became many,</em> or <em>numerous.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Abl_1_A5">
					<p>Also <span class="ar long">أُبَلَتِ الإِبِلُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and the like is said of wild animals, <span class="auth">(Ṣ, M,)</span> or others, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُلُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِلُ</span>}</span></add>, inf. n. <span class="ar">أُبُولٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">أَبْلٌ</span>; <span class="auth">(M, Ḳ;)</span> and <span class="ar">أَبِلَت</span>; and<span class="arrow">↓<span class="ar">تأبّلت</span></span>; <span class="auth">(M, Ḳ;)</span> <em>The camels were content,</em> or <em>satisfied, with green pasture, so as to be in no need of water:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> the last verb is mentioned by Z, and he says that it is tropical, and hence <span class="ar">أَبِيلٌ</span> applied to “a monk.“<span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Abl_1_A6">
					<p><span class="add">[Hence,]</span> <span class="ar long">أَبَلَ الرَّجُلُ عَنِ ٱمْرَأَتِهِ</span>, and<span class="arrow">↓<span class="ar">تأبّل</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>The man was content to abstain from conjugal intercourse with his wife;</em> syn. <span class="ar">اِجْتَزَأَعَنْهَا</span>; <span class="auth">(M;)</span> <em>the man abstained from conjugal,</em> or <em>carnal, intercourse with his wife.</em> <span class="auth">(Ṣ, Ḳ, TA.)</span></p>
				</div>
				<span class="pb" id="Page_0008"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Abl_1_A7">
					<p><span class="add">[Hence also]</span> <span class="ar">أَبَلَ</span>, <span class="auth">(Ḳ,)</span>inf. n. <span class="ar">أَبْلٌ</span>, <span class="auth">(TA,)</span> ‡ <em>He devoted himself to religious exercises;</em> or <em>became a devotee;</em> <span class="auth">(Ḳ, TA;)</span> as also <span class="ar">أَبُلَ</span>, like <span class="ar">فَقُهَ</span>, inf. n. <span class="ar">أَبَالَةٌ</span>: or this signifies <em>he became a monk.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Abl_1_A8">
					<p>And <span class="ar">أَبَلَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِلُ</span>}</span></add>, <span class="auth">(Kr, M, Ḳ,)</span>, inf. n. <span class="ar">أَبْلٌ</span>, <span class="auth">(Kr, M,)</span> † <em>He overcame,</em> and <em>resisted,</em> or <em>withstood;</em> <span class="auth">(Kr, M, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">أبّل</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَأْبِيلٌ</span>; <span class="auth">(TA;)</span> but the word commonly known is <span class="ar">أَبَلَّ</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Abl_1_A9">
					<p>Also <span class="auth">(Ḳ, TA, but in the CK “or”)</span> <span class="ar long">أَبَلَتِ الإِبِلُ</span> signifies <em>The camels were left to pasture at liberty, and went away, having with them no pastor:</em> <span class="auth">(Ḳ:)</span> or <em>they became wild,</em> or <em>shy.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Abl_1_A10">
					<p>And <em>The camels sought by degrees,</em> or <em>step by step,</em> or <em>bit by bit, after the</em> <span class="ar">أُبُل</span> <span class="add">[q. v.]</span>, i. e. <em>the</em> <span class="ar">خِلْفَة</span> <em>of the herbage</em> or <em>pasture.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Abl_1_A11">
					<p>And, inf. n. <span class="ar">أُبُولٌ</span>, <em>The camels remained,</em> or <em>abode,</em> in the place: <span class="auth">(M, Ḳ:)</span> or <em>remained,</em> or <em>abode, long</em> in the pasturage, and in the place. <span class="auth">(El-Moḥeeṭ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="Abl_1_A12">
					<p><span class="ar long">أَبَلَ العُشْبٌ</span>, inf. n. <span class="ar">أُبُولٌ</span>, <em>The herbage became tall, so that the camels were able to feed upon it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="Abl_1_A13">
					<p><span class="ar long">أَبَلَ الشَّجَرُ</span>, inf. n. <span class="ar">أُبُولٌ</span>, <em>The trees had green</em> <span class="add">[<em>such,</em> app., <em>as is termed</em> <span class="ar">أُبُلٌ</span>]</span> <em>growing in its dried parts, mixing therewith, upon which camels,</em> or <em>the like, fatten.</em> <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abl_1_B1">
					<p><span class="ar">أَبَلَهُ</span>, inf. n. <span class="ar">أَبْلٌ</span>, <em>He assigned to him,</em> or <em>gave him,</em> (<span class="ar long">جَعَلَ لَهُ</span>) <em>pasturing camels,</em> or <em>camels pasturing by themselves.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أبّل</span></h3>
				<div class="sense" id="Abl_2_A1">
					<p><span class="ar">أبّل</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَأْبِيلٌ</span>, <span class="auth">(Ḳ,)</span> <em>He took for himself, got, gained,</em> or <em>acquired, camels; he acquired them as permanent property.</em> <span class="auth">(Ṣ, Ḳ.)</span><span class="add">[<a href="#Abl_5">See also 5</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abl_2_A2">
					<p><em>He was one whose camels had become numerous;</em> <span class="auth">(T, M, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">آبل</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">إِيبَالٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow">↓<span class="ar">أَبَلَ</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span>, inf. n. <span class="ar">أَبْلٌ</span>. <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Abl_2_A3">
					<p><span class="ar long">تَأْبِيلٌ الإِبِلِ</span> <em>The managing,</em> or <em>taking good care, of camels;</em> <span class="auth">(M;)</span> and <em>the fattening of them:</em> <span class="auth">(M, Ḳ:)</span> mentioned by AḤn, on the authority of Aboo-Ziyád El-Kilábee. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abl_2_B1">
					<p><a href="#Abl_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Abl_4">
				<h3 class="entry">4. ⇒ <span class="ar">آبل</span></h3>
				<div class="sense" id="Abl_4_A1">
					<p><a href="#Abl_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّل</span></h3>
				<div class="sense" id="Abl_5_A1">
					<p><a href="#Abl_1">see 1</a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abl_5_A2">
					<p><a href="#Abl_8">and see 8</a>.</p> 
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abl_5_B1">
					<p><span class="ar long">تأبّل إِبِلًا</span> <em>He took for himself, got, gained,</em> or <em>acquired, camels;</em> <span class="auth">(AZ, T, M, Ḳ;)</span> like <span class="ar long">تغنّم غَنَمًا</span>. <span class="auth">(AZ, T.)</span> <span class="add">[<a href="#Abl_2">See also 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتبل</span></h3>
				<div class="sense" id="Abl_8_A1">
					<p><span class="ar long">لَا يَأْتَبِلُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> in the O <span class="arrow">↓<span class="ar long">لا يَتَأَبِّلُ</span></span>, <span class="auth">(TA,)</span> <em>He does not,</em> or <em>will not, keep firmly,</em> or <em>steadily, to the pasturing of camels, nor tend them well;</em> <span class="auth">(M, Ḳ;)</span> <em>he does not,</em> or <em>will not, manage them,</em> or <em>take care of them, in such manner as to put them in good condition:</em> <span class="auth">(Aṣ, AʼObeyd, T, Ṣ:)</span> or it signifies, <span class="auth">(M, Ḳ,)</span> or signifies also, <span class="auth">(Ṣ,)</span> <em>he does not,</em> or <em>will not, keep firmly,</em> or <em>steadily, upon them when riding them;</em> <span class="auth">(T, Ṣ, M, Ḳ, TA;)</span> used in this sense by a man excusing himself for not putting on a camel his aged father who was walking. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibolN">
				<h3 class="entry"><span class="ar">إِبْلٌ</span></h3>
				<div class="sense" id="IibolN_A1">
					<p><span class="ar">إِبْلٌ</span>: <a href="#IibilN">see <span class="ar">إِبِلٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِبْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IibolN_A2">
					<p><a href="#OabilN">and <span class="ar">أَبِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabalN">
				<h3 class="entry"><span class="ar">أَبَلٌ</span></h3>
				<div class="sense" id="OabalN_A1">
					<p><span class="ar">أَبَلٌ</span>: <a href="#OabalapN">see <span class="ar">أَبَلَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabilN">
				<h3 class="entry"><span class="ar">أَبِلٌ</span></h3>
				<div class="sense" id="OabilN_A1">
					<p><span class="ar">أَبِلٌ</span> <em>Skilled in the good management of camels</em> <span class="auth">(Ṣ, M, Ḳ)</span> and <em>of sheep</em> or <em>goats;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">آبِلٌ</span></span>: <span class="auth">(Ṣ, M, Ḳ:)</span> and <span class="ar long">أَبِلٌ بِالإِبِلِ</span>, and in poetry <span class="arrow">↓<span class="ar">إِبْلٌ</span></span>, <em>skilled in the management,</em> or <em>care, of camels.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabilN_A2">
					<p>A man <em>possessing camels;</em> <span class="auth">(Fr, M, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">آبِلٌ</span></span>, <span class="auth">(M, Ḳ,)</span> similar to <span class="ar">تَامِرٌ</span> and <span class="ar">لَابِنٌ</span>, <span class="auth">(Ḥam p. 714,)</span> but this is disapproved by Fr; <span class="auth">(TA;)</span> and<span class="arrow">↓<span class="ar">إِبَلِىٌّ</span></span>, <span class="auth">(Ṣ, M, O,)</span> with fet-ḥ to the <span class="ar">ب</span> <span class="auth">(Ṣ, O,)</span> because several kesrehs together are deemed uncouth; <span class="auth">(O;)</span> in the Ḳ, erroneously, <span class="arrow">↓<span class="ar">أَبَلِىٌّ</span></span>, with two fet-ḥahs; <span class="auth">(TA;)</span> and<span class="arrow">↓<span class="ar">إِبِلِىٌّ</span></span> also, <span class="auth">(M, Ḳ,)</span> with two kesrehs. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OabilN_A3">
					<p><span class="ar long">بَعِيرٌ أَبِلٌ</span> <em>A fleshy he-camel.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OabilN_A4">
					<p><span class="ar long">نَاقَةٌ أبِلَةٌ</span> <em>A she-camel blessed, prospered,</em> or <em>made to have increase, in respect of offspring.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span> In one place in the Ḳ, <span class="ar long">مِنَ الوَلَدِ</span> is put for <span class="ar long">فِى الوَلَدِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubulN">
				<h3 class="entry"><span class="ar">أُبُلٌ</span></h3>
				<div class="sense" id="OubulN_A1">
					<p><span class="ar">أُبُلٌ</span> <span class="add">[mentioned in two places in the latter part of the first paragraph,]</span> The <span class="ar">خِلْفَة</span> <em>of herbage,</em> <span class="auth">(Ḳ,)</span> i. e., <em>of dry herbage;</em> <span class="add">[app. meaning <em>what grows in the season called</em> <span class="ar">الصَّيْف</span>, or <em>summer, among herbage that has dried up;</em>]</span> <em>growing after a year; upon which camels, or the like, fatten.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibilN">
				<h3 class="entry"><span class="ar">إِبِلٌ</span></h3>
				<div class="sense" id="IibilN_A1">
					<p><span class="ar">إِبِلٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ, &amp;c.,)</span> said by Sb to be the only subst. of this form except <span class="ar">حِبِرٌ</span>, and to have none like it among epithets except <span class="ar">بِلِزٌ</span>; for though other instances are mentioned, they are not of established authority; <span class="auth">(Mṣb;)</span> but IJ mentions, with these, <span class="ar">حِبِكٌ</span> and <span class="ar">إِطِلٌ</span> <span class="add">[which may be of established authority]</span>; <span class="auth">(TA;)</span> <span class="add">[and to these may be added <span class="ar">إِبِطٌ</span> and <span class="ar">إِبِدٌ</span>, and perhaps <span class="ar">نِكِحٌ</span> and <span class="ar">خِطِبٌ</span>; respecting which <a href="#IibidN">see <span class="ar">إِبِدٌ</span></a>;]</span> and for <span class="ar">إِبِلٌ</span> one says also <span class="arrow">↓<span class="ar">إِبْلٌ</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> sometimes, by way of contraction; <span class="auth">(Ṣ, Mṣb;)</span> or this may be a dial. var. of the former; <span class="auth">(Kr, MF;)</span> <span class="add">[<em>Camels:</em> and <em>a herd of camels:</em> or]</span> <em>at the least,</em> applied to <em>a</em> <span class="ar">صِرْمَة</span>; i. e. <em>a number</em> <span class="add">[<em>of camels</em>]</span> <em>more than a</em> <span class="ar">ذَوْد</span> <span class="add">[<em>which is at least nine,</em>]</span> <em>up to thirty;</em> after which is the <span class="ar">هَجْمَة</span>, i. e. forty and upwards; and then, <span class="ar">هُنَيْدَةُ</span>, which is a hundred of <span class="ar">إِبِل</span>: <span class="auth">(T:)</span> or, accord. to Ibn-ʼAbbád, <em>a hundred of</em> <span class="ar">إِبِل</span>: <span class="auth">(TA:)</span> it is a quasi-pl. n.; <span class="auth">(Az, Ṣ, ISd, Z, O, Mṣb, &amp;c.;)</span> a word having no proper sing.; <span class="auth">(Ṣ, M, O, Mṣb;)</span> and is of the fem. gender, because the quasi-pl. n. that has no proper sing. is necessarily fem. <span class="auth">(Ṣ, O, Mṣb)</span> when not applied to human beings, <span class="auth">(Ṣ, O,)</span> or when applied to irrational beings, <span class="auth">(Mṣb,)</span> and has <span class="ar">ة</span> added in the dim.; <span class="auth">(Ṣ, Mṣb;)</span> <a href="#IibilN">the dim. of <span class="ar">إِبِلٌ</span></a> being <span class="arrow">↓<span class="ar">أُبَيْلَةٌ</span></span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> it is said in the Ḳ that it is a sing. applied to a pl. number, and is not a pl., nor a quasi-pl. n.; but in this assertion together with the saying that the dim. is as above is a kind of contradiction; for if it be a sing., and not a quasi-pl. n., what is the reason of its being fem.? <span class="auth">(TA:)</span> the pl. is <span class="ar">آبَالٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَبِيلٌ</span> <span class="add">[like <span class="ar">عَبِيدٌ</span> <a href="#EabodN">pl. of <span class="ar">عَبْدٌ</span>, q. v.</a>]</span>; <span class="auth">(Mṣb, TA;)</span> the pl. meaning <em>herds</em> <span class="add">[<em>of camels</em>]</span>; and in like manner <span class="ar">أَغْنَامٌ</span> and <span class="ar">أَبْقَارٌ</span> mean flocks of sheep or goats and herds of bulls or cows: <span class="auth">(Mṣb, TA:)</span> and the dual, <span class="ar">إِبلَانِ</span>, means <em>two herds</em> <span class="add">[<em>of camels</em>]</span>, <span class="auth">(Sb, T, Ṣ, M, Mṣb,)</span> each with its pastor; <span class="auth">(T;)</span> like as <span class="ar">غَنَمَانِ</span> means two flocks of sheep or goats: <span class="auth">(Ṣ:)</span> or, accord. to Ibn-ʼAbbád, the dual means <em>two hundreds of</em> <span class="ar">إِبِل</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IibilN_A2">
					<p><span class="ar long">الإِبِلُ الصُّغْرَى</span> <span class="add">[<em>The smaller camels</em>]</span> is an appellation applied to <em>sheep;</em> because they eat more than goats. <span class="auth">(IAạr in TA art. <span class="ar">ضبط</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IibilN_A3">
					<p>It is said in the Ḳur <span class="add">[lxxxviii. 17]</span>, <span class="ar long">أَفَلَا يَنْظُرُونَ إِلَى ٱلْإِبِلِ كَيْفَ خُلِقَتْ</span>, meaning, accord. to 'Aboo-Amr Ibn-El-ʼAlà, <span class="auth">(T, TA,)</span> ‡ <span class="add">[<em>Will they not then consider</em>]</span> <em>the clouds that bear the water for rain,</em> <span class="add">[<em>how they are created?</em>]</span> <span class="auth">(T, Ḳ, TA:)</span> but accord. to him who reads <span class="ar">الإِبْلِ</span>, the meaning is, <em>the camels.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubolapN">
				<h3 class="entry"><span class="ar">أُبْلَةٌ</span></h3>
				<div class="sense" id="OubolapN_A1">
					<p><span class="ar">أُبْلَةٌ</span> <em>A blight, blast, taint,</em> or <em>the like:</em> <span class="auth">(T, Ḳ:)</span> thus written by IAth, agreeably with the authority of Aboo-Moosà; <span class="auth">(TA;)</span> occurring in a trad., in which it is said that one should not sell dates until he is secure from <span class="ar">الاُبْلَةٌ</span>; <span class="auth">(T, TA;)</span> but accord. to a commentary on the Nh, it is correctly written <span class="arrow">↓<span class="ar">أَبَلَةٌ</span></span> <span class="add">[q. v.]</span> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibolapN">
				<h3 class="entry"><span class="ar">إِبْلَةٌ</span></h3>
				<div class="sense" id="IibolapN_A1">
					<p><span class="ar">إِبْلَةٌ</span> <em>Enmity; hostility.</em> <span class="auth">(Kr, M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabalapN">
				<h3 class="entry"><span class="ar">أَبَلَةٌ</span></h3>
				<div class="sense" id="OabalapN_A1">
					<p><span class="ar">أَبَلَةٌ</span> <em>Unwholesomeness and heaviness of food;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> originally <span class="ar">وَبَلَةٌ</span>, like as <span class="ar">أَحَدٌ</span> is originally <span class="ar">وَحَدٌ</span>; <span class="auth">(Ṣ;)</span> as also<span class="arrow">↓<span class="ar">أَبَلٌ</span></span>. <span class="auth">(Ḳ.)</span> It is said in a trad. that this departs from every property for which the poor-rate has been paid. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabalapN_A2">
					<p><a href="#OubolapN">See also <span class="ar">أُبْلَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OabalapN_A3">
					<p><em>An evil quality</em> of herbage or pasture. <span class="auth">(AḤn, TA in art. <span class="ar">نشر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OabalapN_A4">
					<p><em>A cause of harm</em> or <em>injury; evil; mischief.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OabalapN_A5">
					<p><em>A consequence</em> of an action, or <em>a claim which one seeks to obtain for an injury;</em> and <em>a cause of blame</em> or <em>dispraise:</em> having these meanings in the saying, <span class="ar long">إِنْ فَعَلْتَ ذَاكَ فَقَدْ خَرَجْتَ مِنْ أَبَلَتِهِ</span> <span class="add">[<em>If thou do that, thou wilt escape from its consequence,</em>, &amp;c.]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OabalapN_A6">
					<p><em>A fault, vice,</em> or <em>the like.</em> <span class="auth">(Aboo-Málik, T.)</span> So in the saying, <span class="ar long">مَا عَلَيْكَ فِى هٰذَا الأَمْرِ أَبَلَةٌ</span> <span class="add">[<em>There is not to be charged against thee, in this affair, any fault,</em>, &amp;c.]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OabalapN_A7">
					<p><em>A crime; a sin; an unlawful action.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OabalapN_A8">
					<p><em>Rancour, malevolence, malice,</em> or <em>spite.</em> <span class="auth">(IB.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabalieBN">
				<h3 class="entry"><span class="ar">أَبَلِىٌّ</span></h3>
				<div class="sense" id="OabalieBN_A1">
					<p><span class="ar">أَبَلِىٌّ</span>: <a href="#OabilN">see <span class="ar">أَبِلٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabulieBN">
				<h3 class="entry"><span class="ar">أَبُلِىٌّ</span></h3>
				<div class="sense" id="OabulieBN_A1">
					<p><span class="ar">أَبُلِىٌّ</span>: <a href="#OabiylN">see <span class="ar">أَبِيلٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibalieBN">
				<h3 class="entry"><span class="ar">إِبَلِىٌّ</span></h3>
				<div class="sense" id="IibalieBN_A1">
					<p><span class="ar">إِبَلِىٌّ</span>, with fet-ḥ to the <span class="ar">ب</span> because several kesrehs together are deemed uncouth, <em>Of,</em> or <em>relating to, camels.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِبَلِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IibalieBN_A2">
					<p><a href="#OabilN">See also <span class="ar">أَبِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibilieBN">
				<h3 class="entry"><span class="ar">إِبِلِىٌّ</span></h3>
				<div class="sense" id="IibilieBN_A1">
					<p><span class="ar">إِبِلِىٌّ</span>: <a href="#OabilN">see <span class="ar">أَبِلٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabiylN">
				<h3 class="entry"><span class="ar">أَبِيلٌ</span></h3>
				<div class="sense" id="OabiylN_A1">
					<p><span class="ar">أَبِيلٌ</span> † <em>A Christian monk;</em> <span class="auth">(Ṣ M, Mṣb, Ḳ;)</span> so called because of his abstaining (<span class="ar">لِتَأَبُلِهِ</span>) from women: <span class="auth">(TA:)</span> or the <em>chief monk:</em> <span class="auth">(T:)</span> or <em>a derotee:</em> <span class="auth">(TA:)</span> or <em>an old man,</em> or <em>elder:</em> <span class="auth">(M:)</span> or the <em>chief,</em> or <em>head-man, of the Christians:</em> <span class="auth">(M, Ḳ:)</span> or the <em>man who calls them to prayer by means of the</em> <span class="ar">نَاقُوس</span>; <span class="auth">(AHeyth, M,* Ḳ;)</span> the <em>beater of the</em> <span class="ar">ناقوس</span>: <span class="auth">(IDrd:)</span> as also<span class="arrow">↓<span class="ar">أَيْبَلِىٌّ</span></span>, <span class="auth">(M and Ḳ, but according to the M as meaning “a monk,”)</span> which is either a foreign word, or changed by the relative <span class="ar">ى</span>, or of the same class as <span class="ar">إِنْقَحْلٌ</span> <span class="add">[in which the first letter as well as th second is augmentative]</span>, for Sb says that there is not in the language an instance of the measure <span class="ar">فَيْعَلٌ</span>; <span class="auth">(M;)</span> and<span class="arrow">↓<span class="ar">أَيْبُلِىٌّ</span></span>, and <span class="ar">هَيْبَلِىٌّ</span>, and<span class="arrow">↓<span class="ar">أَبُلِىٌّ</span></span> and<span class="arrow">↓<span class="ar">أَيْبَلٌ</span></span>, <span class="auth">(Ḳ,)</span> which last is disallowed by Sb for the reason stated above; <span class="auth">(TA;)</span> and<span class="arrow">↓<span class="ar">أَيْبُلٌ</span></span> like <span class="ar">أَيْنُقٌ</span>; and<span class="arrow">↓<span class="ar">أَيْبِلِىٌّ</span></span>; <span class="auth">(Ḳ;)</span> the last with fet-ḥ to the hemzeh, and kesr to the <span class="ar">ب</span>, and with the <span class="add">[first]</span> <span class="ar">ى</span> quiescent; <span class="pb" id="Page_0009"></span>or <span class="ar">أَيْبَلِىٌّ</span> <span class="add">[app. a mistranscription for <span class="ar">أَيْبِلِىٌّ</span>]</span> is used by poetic licence for<span class="arrow">↓<span class="ar">أَبِيلِىٌّ</span></span>, like <span class="ar">أَيْنُقٌ</span> for <span class="ar">أَنْوُقٌ</span>: <span class="auth">(TA:)</span> pl. <span class="ar">آبَالٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أُبْلٌ</span>, or <span class="ar">أُبُلٌ</span>, <span class="add">[accord. to different copies of the Ḳ,]</span> with damm <span class="add">[which indicates that the former is meant, though it is irregular]</span>. <span class="auth">(Ḳ.)</span> By <span class="ar long">أَبِيلٌ الأَبِيلِينَ</span> is meant <em>ʼEesà</em> <span class="add">[or <em>Jesus</em>]</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>the Messiah.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabiylN_A2">
					<p>In the Syriac language it signifies <em>Mourning,</em> or <em>sorrowing.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OabiylN_B1">
					<p>Also <em>A staff,</em> or <em>stick.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">أَبِيلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OabiylN_B2">
					<p><a href="#IibaAlapN">See also <span class="ar">إِبَالَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OubaAlapN">
				<h3 class="entry"><span class="ar">أُبَالَةٌ</span></h3>
				<div class="sense" id="OubaAlapN_A1">
					<p><span class="ar">أُبَالَةٌ</span>: <a href="#IibaAlapN">see the next paragraph</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibaAlapN">
				<h3 class="entry"><span class="ar">إِبَالَةٌ</span></h3>
				<div class="sense" id="IibaAlapN_A1">
					<p><span class="ar">إِبَالَةٌ</span>: <a href="#IibBaWolN">see <span class="ar">إِبَّوْلٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِبَالَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IibaAlapN_B1">
					<p>Also <em>A bundle of firewood;</em> <span class="auth">(T, Ṣ, Mṣb;)</span> and so<span class="arrow">↓<span class="ar">إِبَّالَةٌ</span></span>: <span class="auth">(T, Ṣ:)</span> or <em>a great bundle of firewood;</em> and so<span class="arrow">↓<span class="ar">أُبَالَةٌ</span></span> and <span class="ar">بُلَةٌ</span> <span class="auth">(Ḳ)</span> and<span class="arrow">↓<span class="ar">إِبَّالَةٌ</span></span>: <span class="auth">(Bḍ in cv. 3; but there explained only as signifying <em>a great bundle:</em>)</span> or <em>a bundle of dry herbage;</em> <span class="auth">(M, TA;)</span> and so<span class="arrow">↓<span class="ar">إِبَّالَةٌ</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow">↓<span class="ar">أَبِيلٌ</span></span> and<span class="arrow">↓<span class="ar">أَبِيلَةٌ</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow">↓<span class="ar">إِيبَالَةٌ</span></span>, <span class="auth">(Ḳ, <span class="add">[in the CK <span class="ar">اَيْبَالَة</span>,]</span>)</span> with one of the two <span class="ar">ب</span> s changed into <span class="ar">ى</span>, and mentioned by Az, but it is said in the Ṣ and O that this is not allowable, because this change may not be made in a word of the measure <span class="ar">فِعَّالَةٌ</span>, with <span class="ar">ة</span>, but only in one without <span class="ar">ة</span>, as in the cases of <span class="ar">دِينَارٌ</span> and <span class="ar">قِيرَاطٌ</span>; <span class="auth">(TA;)</span> and <span class="ar">وَبِيلَةٌ</span> signifies the same, <span class="auth">(Ḳ,)</span> belonging to <a href="index.php?data=27_w/016_wbl">art. <span class="ar">وبل</span></a>. <span class="auth">(TA.)</span> Hence the prov., <span class="auth">(Ṣ, TA,)</span> <span class="ar long">صِغْثٌ عَلَى إِبَالَةٍ</span> and<span class="arrow">↓<span class="ar">إِبَّالَةٍ</span></span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> but the former is the more common, and<span class="arrow">↓<span class="ar">إِيبَالَةٍ</span></span>, which is allowed by Az but disallowed by J; <span class="auth">(TA;)</span> <span class="add">[lit. <em>A handful of herbage,</em> or <em>the like, upon a bundle,</em> or <em>great bundle, of firewood,</em> or <em>a bundle of dry herbage;</em>]</span> meaning † <em>a trial,</em> or <em>trying event, upon another</em> <span class="auth">(Ṣ, O, Ḳ)</span> <em>that had happened before:</em> <span class="auth">(Ṣ, O:)</span> or <em>plenty</em> (<span class="ar">خِصْبٌ</span>) <em>upon plenty;</em> as though bearing two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabiylapN">
				<h3 class="entry"><span class="ar">أَبِيلَةٌ</span></h3>
				<div class="sense" id="OabiylapN_A1">
					<p><span class="ar">أَبِيلَةٌ</span>: <a href="#IibaAlapN">see <span class="ar">إِبَالَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OubayolapN">
				<h3 class="entry"><span class="ar">أُبَيْلَةٌ</span></h3>
				<div class="sense" id="OubayolapN_A1">
					<p><span class="ar">أُبَيْلَةٌ</span> <a href="#IibilN"><span class="ar long">دِم. ْف إِبِلٌ</span>, q. v.</a> <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabiylieBN">
				<h3 class="entry"><span class="ar">أَبِيلِىٌّ</span></h3>
				<div class="sense" id="OabiylieBN_A1">
					<p><span class="ar">أَبِيلِىٌّ</span>: <a href="#OabiylN">see <span class="ar">أَبِيلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabaAbiylN">
				<h3 class="entry"><span class="ar">أَبَابِيلٌ</span></h3>
				<div class="sense" id="OabaAbiylN_A1">
					<p><span class="ar">أَبَابِيلٌ</span>: <a href="#IibBaWolN">see <span class="ar">إِبَّوْلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabBaAlN">
				<h3 class="entry"><span class="ar">أَبَّالٌ</span></h3>
				<div class="sense" id="OabBaAlN_A1">
					<p><span class="ar">أَبَّالٌ</span> <em>A pastor of camels,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>who manages them,</em> or <em>takes care of them, well.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibBaAlN">
				<h3 class="entry"><span class="ar">إِبَّالٌ</span></h3>
				<div class="sense" id="IibBaAlN_A1">
					<p><span class="ar">إِبَّالٌ</span>: <a href="#IibBaWolN">see the next paragraph</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibBawolN">
				<h3 class="entry"><span class="ar">إِبَّوْلٌ</span></h3>
				<div class="sense" id="IibBawolN_A1">
					<p><span class="ar">إِبَّوْلٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> like <span class="ar">عِجَّوْلٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, <span class="add">[in the CK, erroneously, <span class="ar">عَجُول</span>,]</span>)</span> <em>A separate,</em> or <em>distinct, portion</em> of a number of birds, and of horses, and of camels, <span class="auth">(M, Ḳ,)</span> and of such following one another; <span class="auth">(Ḳ;)</span> as also<span class="arrow">↓<span class="ar">إِبِّيلٌ</span></span> and<span class="arrow">↓<span class="ar">إِبَّالَةٌ</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow">↓<span class="ar">إِبَالَةٌ</span></span>, and<span class="arrow">↓<span class="ar">إِيْبَالٌ</span></span>: <span class="auth">(Ḳ:)</span> or it signifies <em>a bird separating itself from the row of other birds;</em> <span class="auth">(T, TA;)</span> accord. to IAạr. <span class="auth">(TA.)</span> It is said to be the sing. of <span class="arrow">↓<span class="ar">أَبَابِيلٌ</span></span>: <span class="auth">(T, Ṣ, M, and Jel in cv. 3:)</span> Ks says, I used to hear the grammarians say that this latter has for its sing. <span class="ar">إِبَّوْلٌ</span>, like <span class="ar">عِجَّوْلٌ</span>, of which the pl. is <span class="ar">عَجَاجِيلٌ</span>: <span class="auth">(Mṣb:)</span> or its sing. is <span class="arrow">↓<span class="ar">إِبِّيلٌ</span></span>; <span class="auth">(Ṣ, Mṣb;)</span> but he who says this adds, I have not found the Arabs to know a sing. to it: <span class="auth">(Ṣ:)</span> or each of these is its sing.; <span class="auth">(M, Jel;)</span> and so is <span class="arrow">↓<span class="ar">إِبَّالٌ</span></span>: <span class="auth">(Jel:)</span> or its sing. is <span class="arrow">↓<span class="ar">إِبَّالَةٌ</span></span>, <span class="auth">(Bḍ in cv. 3, and Mṣb,)</span> originally signifying “a great bundle:” <span class="auth">(Bḍ:)</span> it is said that this seems to be its sing.; and so<span class="arrow">↓<span class="ar">أَبَّالَةٌ</span></span>: or the sing. may be <span class="arrow">↓<span class="ar">إِيبَالَةٌ</span></span>, like as <span class="ar">دِينَارٌ</span> is sing of <span class="ar">دَنَانِيرٌ</span>: <span class="auth">(T:)</span> or it has no sing., <span class="auth">(T, Ṣ, M, Bḍ, Mṣb, Ḳ,)</span> accord. to Fr <span class="auth">(T, Mṣb)</span> and Akh <span class="auth">(Ṣ)</span> and AO, <span class="auth">(T, M,)</span> like <span class="ar">شَمَاطِيطُ</span> <span class="auth">(Fr, T, Bḍ)</span> and <span class="ar">عَبَادِيدٌ</span>. <span class="auth">(AO, M, Bḍ.)</span> <span class="ar">أَبَابِيلٌ</span> signifies, accord. to some, <em>A company in a state of dispersion:</em> <span class="auth">(M:)</span> or <em>dispersed companies, one following another:</em> <span class="auth">(Mṣb:)</span> or <em>distinct,</em> or <em>separate, companies,</em> <span class="auth">(Akh, Ṣ, Mṣb, Ḳ,)</span> <em>like leaning camels:</em> <span class="auth">(Mṣb:)</span> or <em>companies in a state of dispersion.</em> <span class="auth">(AO, Mṣb.)</span> One says, <span class="ar long">جَآءَتْ إِبِلُكَ أَبَابِيلَ</span> <em>Thy camels came in distinct,</em> or <em>separate, companies.</em> <span class="auth">(Akh, Ṣ.)</span> And <span class="ar long">طَيْرٌ أَبَابِيلُ</span> <span class="add">[in the Ḳur cv. 3 means <em>Birds in distinct,</em> or <em>separate, flocks</em> or <em>bevies</em>]</span>: <span class="auth">(Akh, Ṣ:)</span> <span class="add">[or]</span> <em>birds in companies from this and that quarter:</em> or <em>following one another, flock after flock:</em> <span class="auth">(Zj, T:)</span> or † <em>birds in companies;</em> <span class="auth">(Bḍ, Jel;)</span> likened to great bundles, in respect of their compactness. <span class="auth">(Bḍ.)</span> <span class="add">[Respecting these birds, Fei, in the Mṣb, quotes many fanciful descriptions, which I omit, as absurd.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibBiylN">
				<h3 class="entry"><span class="ar">إِبِّيلٌ</span></h3>
				<div class="sense" id="IibBiylN_A1">
					<p><span class="ar">إِبِّيلٌ</span>: <a href="#IibBaWolN">see <span class="ar">إِبَّوْلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabBaAlapN">
				<h3 class="entry"><span class="ar">أَبَّالَةٌ</span></h3>
				<div class="sense" id="OabBaAlapN_A1">
					<p><span class="ar">أَبَّالَةٌ</span>: <a href="#IibBaWolN">see <span class="ar">إِبَّوْلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibBaAlapN">
				<h3 class="entry"><span class="ar">إِبَّالَةٌ</span></h3>
				<div class="sense" id="IibBaAlapN_A1">
					<p><span class="ar">إِبَّالَةٌ</span>: <a href="#IibaAlapN">see <span class="ar">إِبَالَةٌ</span></a>, in four places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِبَّالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IibBaAlapN_A2">
					<p><a href="#IibBaWolN_A1">and <span class="ar">إِبَّوْلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbalN">
				<h3 class="entry"><span class="ar">آبَلٌ</span></h3>
				<div class="sense" id="MbalN_A1">
					<p><span class="ar">آبَلٌ</span> <em>More,</em> and most, skilled in the good management of camels. <span class="auth">(Ṣ, M, Ḳ, TA.)</span> Hence the prov., <span class="ar long">آبَلُ مِنْ حُنَيْفِ الحَنَاتِمِ</span> <span class="add">[<em>More skilled</em>, &amp;c. <em>than Honeyf-el-Hanátim</em>]</span>. <span class="auth">(TA.)</span> And the phrase, <span class="ar long">هُوَ مِنْ آبِلَ النَّاسِ</span> <span class="add">[<em>He is of the most skilled</em>, &amp;c. <em>of men</em>]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span> Mentioned by Sb, who says that there is no verb corresponding to it. <span class="auth">(M.)</span> <span class="add">[<a href="#Abl_1">But see 1</a>, first signification.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbilN">
				<h3 class="entry"><span class="ar">آبِلٌ</span></h3>
				<div class="sense" id="MbilN_A1">
					<p><span class="ar">آبِلٌ</span>: <a href="#OabilN">see <span class="ar">أَبِلٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">آبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MbilN_A2">
					<p><span class="ar long">إِبِلٌ أَوَابِلٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">أُبَّلٌ</span>, and <span class="ar">أُبَّالٌ</span>, <span class="auth">(M,)</span> <span class="add">[all pls. of <span class="ar">آبِلٌ</span> or <span class="ar">آبِلَةٌ</span>,]</span> and<span class="arrow">↓<span class="ar">مُؤَبَّلَةٌ</span></span>, <span class="auth">(M,)</span> <em>Many,</em> or <em>numerous, camels:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> or this, <span class="add">[app. meaning the last,]</span> as some say, <em>put in distinct herds;</em> <span class="auth">(M;)</span> and so <span class="ar">أُبَّالٌ</span>: <span class="auth">(TA:)</span> or <em>gotten, gained,</em> or <em>acquired, for permanent possession:</em> <span class="auth">(M:)</span> this last is the meaning of the last of the epithets above. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">آبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MbilN_A3">
					<p><span class="ar">آبِلٌ</span>, applied to a camel, also signifies <em>Content,</em> or <em>satisfied, with green pasture, so as to be in no need of water:</em> pl. <span class="ar">أُبَّالٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> and so <span class="ar">أَوَابِلُ</span>, applied to she-camels, <span class="auth">(T,* TA,)</span> and to wild animals. <span class="auth">(Ṣ in art. <span class="ar">بل</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">آبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MbilN_A4">
					<p>And <span class="ar long">إِبِلٌ آبِلَةٌ</span> <em>Camels seeking by degrees,</em> or <em>step by step,</em> or <em>bit by bit,</em> after the <span class="ar">أُبُل</span> <span class="add">[q. v.]</span>, i. e. <em>the</em> <span class="ar">خِلْفَة</span> <em>of the herbage</em> or <em>pasture.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">آبِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="MbilN_A5">
					<p>And <span class="ar long">إِبِّلٌ أُبَّلٌ</span> <em>Camels left to themselves,</em> <span class="auth">(Ṣ, M, Ḳ, TA,)</span> <em>without a pastor.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayobalN">
				<h3 class="entry"><span class="ar">أَيْبَلٌ</span> / <span class="ar">أَيْبُلٌ</span></h3>
				<div class="sense" id="OayobalN_A1">
					<p><span class="ar">أَيْبَلٌ</span> and <span class="ar">أَيْبُلٌ</span>: <a href="#OabiylN">see <span class="ar">أَبِيلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayobalieBN">
				<h3 class="entry"><span class="ar">أَيْبَلِىٌّ</span> / 
							<span class="ar">أَيْبُلِىٌّ</span> / 
							<span class="ar">أَيْبِلِىٌّ</span></h3>
				<div class="sense" id="OayobalieBN_A1">
					<p><span class="ar">أَيْبَلِىٌّ</span> and <span class="ar">أَيْبُلِىٌّ</span> and <span class="ar">أَيْبِلِىٌّ</span>: <a href="#OabiylN">see <span class="ar">أَبِيلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiybaAlN">
				<h3 class="entry"><span class="ar">إِيبَالٌ</span></h3>
				<div class="sense" id="IiybaAlN_A1">
					<p><span class="ar">إِيبَالٌ</span>: <a href="#IibBaWolN">see <span class="ar">إِبَّوْلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiybaAlapN">
				<h3 class="entry"><span class="ar">إِيبَالَةٌ</span></h3>
				<div class="sense" id="IiybaAlapN_A1">
					<p><span class="ar">إِيبَالَةٌ</span>: <a href="#IibaAlapN">see <span class="ar">إِبَالَةٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابل</span> - Entry: <span class="ar">إِيبَالَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiybaAlapN_A2">
					<p><a href="#IibBaWolN">and see <span class="ar">إِبَّوْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOobalapN">
				<h3 class="entry"><span class="ar">مَأْبَلَةٌ</span></h3>
				<div class="sense" id="maOobalapN_A1">
					<p><span class="ar long">أَرْضٌ مَأْبَلَةٌ</span>: <em>A land having camels.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWabBalapN">
				<h3 class="entry"><span class="ar">مُؤَبَّلَةٌ</span></h3>
				<div class="sense" id="muWabBalapN_A1">
					<p><span class="ar long">إِبِلٌ مُؤَبَّلَةٌ</span>: <a href="#AbilN">see <span class="ar">آبِلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0007.pdf" target="pdf">
							<span>Lanes Lexicon Page 7</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0008.pdf" target="pdf">
							<span>Lanes Lexicon Page 8</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0009.pdf" target="pdf">
							<span>Lanes Lexicon Page 9</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
