<article class="root" id="Root_Awl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/162_Awq">اوق</a></span>
				<span class="ar">اول</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/164_Awlw">اولو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Awl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أول</span> ⇒ <span class="ar">آل</span></h3>
				<div class="sense" id="Awl_1_A1">
					<p><span class="ar">آلَ</span>, aor. <span class="ar">يَؤُولُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">أَوْلٌ</span> <span class="auth">(T, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">مَآلٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">إِيَالٌ</span>, which last is used as a subst. in relation to objects of the mind, <span class="auth">(Mṣb,)</span> and <span class="ar">أَيْلُولَةٌ</span> <span class="add">[like <span class="ar">دَيْمُومَةٌ</span>]</span>, <span class="auth">(TA,)</span> <em>He,</em> or <em>it, returned;</em> syn. <span class="ar">رَجَعَ</span>; <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> and <span class="ar">عَادَ</span>; <span class="auth">(T;)</span> <span class="add">[and <em>he resorted;</em> <span class="auth">(see an instance voce <span class="ar">إِيَّلٌ</span>;)</span>]</span> <span class="ar">إِلَيْهِ</span> <em>to it;</em> <span class="auth">(M, Ḳ;)</span> namely a thing <span class="add">[of any kind; the thing, or place, whence he, or it, originated, or came; his, or its, origin, or source; his, or its, original state, condition, quantity, weight, &amp;c.; any place; and a former action, or saying, or the like: <a href="#rajaEa">see <span class="ar">رَجَعَ</span></a>, by which, as the explanation of <span class="ar">آلَ</span>, may be meant to be implied some other significations, here following, which these two verbs have in common]</span>: <span class="auth">(M:)</span> and <span class="ar long">آلَ عَنْهُ</span> <em>he</em> <span class="auth">(a man, M)</span> <em>returned,</em> or <em>reverted, from it.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awl_1_A2">
					<p>From <span class="ar">آلَ</span> as syn. with <span class="ar">رَجَعَ</span> is the phrase, <span class="ar long">فُلَانٌ يَؤُولُ إِلَى كَرَمٍ</span> <span class="add">[meaning either <em>Such a one returns to generosity,</em> or, as <span class="ar">كَرَمٌ</span> is used in the sense of <span class="ar">كِرَامٌ</span>, <em>is referable to generous,</em> or <em>noble, ancestors</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[And hence the phrase,]</span> <span class="ar long">آلَ إِلَيْهِ بِنَسَبٍ</span> <span class="add">[<em>He bore a relation to him, as a member to a head, by kindred</em>]</span>, and <span class="ar">بِدِينٍ</span> <span class="add">[<em>by religion</em>]</span>. <span class="auth">(Ibn-ʼArafeh.)</span> And the saying, in a trad., <span class="ar long">مَنْ صَامَ الدَّهْرَ فَلَا صَامَ وَلَا آلَ</span>, i. e. ‡ <span class="add">[<em>He who fasts ever,</em> or <em>always, may he neither fast</em>]</span> <em>nor return to what is good.</em> <span class="auth">(TA. <span class="add">[In the Mgh, art. <span class="ar">دهر</span>, for <span class="ar">آل</span> I find <span class="ar">أَفْطَرَ</span>; and it is there said that this is an imprecation uttered by the Prophet, lest a man should believe this kind of fasting to be ordained by God; or, through impotence, should become insincere; or because, by fasting all the days of the year, he would do so on the days on which fasting is forbidden. <a href="#OalaA">See other readings voce <span class="ar">أَلَا</span></a> <a href="index.php?data=01_A/126_Alw">in art. <span class="ar">الو</span></a>.]</span>)</span></p>
				</div>
				<span class="pb" id="Page_0126"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Awl_1_A3">
					<p>Hence also the saying, <span class="ar long">آلتِ الضَّرْبَهُ إِلَى النَّفْسِ</span>, meaning † <em>The blow,</em> or <em>stroke, resulted in destroying life; in slaying,</em> or <em>killing.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Awl_1_A4">
					<p>Hence also, <span class="ar long">آلَ الأَمْرُ إِلَى كَذَا</span> <span class="add">[<em>The affair,</em> or <em>case, became ultimately reduced to such a state,</em> or <em>condition; came to such a result; came to be thus</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Awl_1_A5">
					<p>Hence also, <span class="ar long">طَبَخْتُ الشَّرَابَ فَآلَ إِلَى قَدْرِ كَذَا</span> <em>I cooked the wine,</em> or <em>beverage, and it became reduced</em> (<span class="ar">رَجَعَ</span>) <em>to such a quantity.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">طَبَخَهُ حَتَّى آلَ إِلَى الثُّلُثِ أَوِالرُّبعِ</span> <em>He cooked it</em> <span class="auth">(namely <span class="ar">نَبِيذ</span> <span class="add">[i. e. must, or mead, or wort,]</span>)</span> <em>until it became reduced</em> (<span class="ar">رَجَعَ</span>) <em>to the third, or to the fourth:</em> <span class="auth">(T:)</span> or, said of the same, <span class="auth">(Mgh,)</span> or of medicine, <span class="auth">(TA,)</span> <span class="ar long">حَتَّى آلَ المَنَّانِ مَنَّا وَاحِدًا</span>, <span class="auth">(Mgh,)</span> or <span class="ar long">إِلَى مَنٍّ وَاحِدٍ</span>, <span class="auth">(TA,)</span> <em>until twice the quantity,</em> or <em>weight, of a</em> <span class="ar">مَنّ</span> <em>became</em> <span class="add">[<em>reduced to</em>]</span> (<span class="ar">صَارَ</span>) <em>one</em> <span class="ar">مَنّ</span>. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Awl_1_A6">
					<p><span class="add">[Hence also, <span class="ar long">مَجَازُ الأَوْلِ</span> <em>The proleptic,</em> or <em>anticipative, trope;</em> as <span class="ar">فَصِيلٌ</span> applied to “a young camel” before it is weaned, because it is to be weaned.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Awl_1_A7">
					<p><span class="add">[And hence also, app.,]</span> <span class="ar long">آلَ الشَّىْءُ</span>, inf. n. <span class="ar">مَآلٌ</span>, <em>The thing</em> <span class="add">[<em>became reduced in quantity</em> or <em>size;</em>]</span> <em>decreased; diminished;</em> or <em>became defective,</em> or <em>deficient.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">آلَ لَحْمُ النَّاقَةِ</span> <em>The flesh of the she-camel went away, so that she became lean,</em> or <em>slender and lean,</em> or <em>lean and lank in the belly.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Awl_1_A8">
					<p><span class="ar">آلَ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَوْلٌ</span> <span class="auth">(T, M, Ḳ)</span> and <span class="ar">إِيَالٌ</span>, <span class="auth">(M, Ḳ,)</span> is also said of tar, <span class="auth">(T, Ṣ, M,)</span> and of honey, <span class="auth">(Ṣ,)</span> and of milk, <span class="auth">(M,)</span> and of wine, or beverage, <span class="auth">(TA,)</span> and of urine, <span class="auth">(M,)</span> or of the urine of camels that have been contented with green pasture instead of water, at the end of their being in that state, <span class="auth">(T,)</span> and of oil, <span class="auth">(M, Ḳ,)</span> and other things, <span class="auth">(Ḳ,)</span> as meaning <em>It became thick:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> said of milk, <em>it thickened and coagulated:</em> <span class="auth">(M:)</span> said of wine, or beverage, <em>it thickened, and became intoxicating in its utmost degree:</em> <span class="auth">(Az, TA:)</span> and said of oil, <em>it attained its full perfume,</em> or <em>sweetness of odour, by being well prepared</em> or <em>compounded.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Awl_1_A9">
					<p><span class="ar long">مَا لَكَ تَؤُولُ إِلَى كَتِفَيْكَ</span> <span class="add">[written in the TA without any vowel-signs, app. meaning ‡ <em>What aileth thee that thou shruggest thy shoulders?</em> lit., <em>drawest thyself together to thy two shoulder-blades?</em>]</span> is said <span class="add">[to a man]</span> <span class="ar long">إِذَا ٱنْضَمَّ إِلَيْهِمَا وَٱجْتَمَعَ</span> <span class="add">[when he draws himself together to them, and contracts himself]</span>; and is a tropical phrase: so says Z. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Awl_1_A10">
					<p><span class="ar long">آلَ مِنْ فُلَانٍ</span> <em>He escaped,</em> or <em>became safe</em> or <em>secure, from such a one:</em> <a href="#waOala">a dial. var. of <span class="ar">وَأَلَ</span></a>: <span class="auth">(T, Ḳ:)</span> of the dial. of the Ansár. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Awl_1_A11">
					<p>You say also, <span class="ar">آلَ</span>, aor. <span class="ar">يَؤُولُ</span>; <span class="auth">(T, Mṣb;)</span> or <span class="ar">أَوِلَ</span>, aor. <span class="ar">يَأْوَلُ</span>; <span class="auth">(Ḳ;)</span> meaning <em>He,</em> or <em>it, preceded; went before; was,</em> or <em>became, before, beforehand, first,</em> or <em>foremost;</em> <span class="auth">(T, Mṣb, Ḳ;)</span> <em>and came:</em> <span class="auth">(Mṣb:)</span> with this, also, <span class="ar">وَأَلَ</span> is syn.; and from it <span class="add">[says Az]</span> is most probably derived <span class="ar">أَوَّلُ</span>, so that its original form is <span class="ar">أَأْوَلُ</span>: <span class="add">[or, as Fei says,]</span> hence is derived the phrase, used by the vulgar, <span class="ar long">العَشْرُ الأَوَّلُ</span> with fet-ḥ to the hemzeh <span class="add">[as meaning “the first, or preceding, ten <span class="auth">(nights of the month)</span>,” for <span class="ar">الأُوَلُ</span>, <a href="#AlOuwlae">pl. of <span class="ar">الأُولَى</span></a>, <a href="#AlOawBalu">fem. of <span class="ar">الأَوَّلُ</span></a>; but this is generally regarded as being originally <span class="ar">الأَوْأَلُ</span>, from <span class="ar">وَأَلَ</span>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awl_1_B1">
					<p><span class="ar">آلَهُ</span>: <a href="#Awl_2">see 2</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Awl_1_B2">
					<p>Accord. to Lth, <span class="auth">(TA,)</span> <span class="ar">أُلْتُهُ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">أَؤُولُهُ</span>, inf. n. <span class="ar">أَوْلٌ</span>, <span class="auth">(TA,)</span> signifies <em>I made it</em> <span class="auth">(namely, milk, M, or oil, &amp;c., Ḳ)</span> <em>to thicken,</em> <span class="auth">(M, Ḳ,)</span> <em>and to coagulate;</em> <span class="auth">(M;)</span> the verb being both intrans. and trans.: <span class="auth">(Ḳ:)</span> but Az says that it is not known as trans., in this sense, in the language of the Arabs <span class="add">[of the classical ages]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Awl_1_C1">
					<p><span class="ar long">آلَ رَعِيّتَهُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">يُؤُولُ</span>, inf. n. <span class="ar">أَوْلٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">إِيَالٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> of which the simple subst. is <span class="ar">إِيَالَةٌ</span>, <span class="auth">(Ṣ,* Mṣb,)</span> <em>He</em> <span class="auth">(a prince or commander, Ṣ, or a king, M, Ḳ)</span> <em>ruled,</em> or <em>governed, his subjects; presided over their affairs, as commander</em> or <em>governor;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> <em>and did so well:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">آلَ عَلَيْهِمْ</span>, inf. n. <span class="ar">أَوْلٌ</span> and <span class="ar">إِيَالٌ</span> and <span class="ar">إِيَالَةٌ</span>, <span class="add">[or this last, as said above, is a simple subst.,]</span> <em>he presided over them; held command,</em> or <em>authority, over them;</em> <span class="auth">(M, Ḳ;)</span> namely, a people, or company of men; <span class="auth">(Ḳ;)</span> or, <em>over their affairs.</em> <span class="auth">(TA.)</span> It is said in a prov., <span class="auth">(M,)</span> <span class="ar long">قَدْ أُلْنَا وَإِيلَ عَلَيْنَا</span> <span class="auth">(T, Ṣ, M)</span> <em>We have ruled and been ruled;</em> <span class="auth">(T;)</span> <em>we have presided and been presided over.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Awl_1_C2">
					<p><span class="ar long">آلَ مَالهُ</span>, <span class="auth">(T, Ṣ, M,* Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِيَالَةٌ</span>, <span class="auth">(T, Mṣb,)</span> <em>He put into a good,</em> or <em>right, state,</em> or <em>condition, and managed,</em> or <em>tended, his</em> <span class="ar">مال</span> <span class="add">[meaning <em>cattle</em>]</span>; <span class="auth">(T, Ṣ, M,* Ḳ;)</span> as also<span class="arrow"><span class="ar">ائتالهُ↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَالَهُ</span>]</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">اِيتِيَالٌ</span>: <span class="auth">(Ṣ:)</span> or <em>he managed his camels, and his sheep</em> or <em>goats, in such a manner that they throve,</em> or <em>became in a good state</em> or <em>condition, by his management.</em> <span class="auth">(Mṣb.)</span> Lebeed describes a female singer</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">بِمُوَتَّرٍ تَأْتَالُهُ↓ إِبْهَامُهَا</span></span> *</div> 
					</blockquote>
					<p><span class="auth">(T, Ṣ,)</span> meaning <em>with a stringed lute,</em> <span class="auth">(EM p. 169,)</span> <em>which her thumb adjusts;</em> <span class="auth">(Ṣ, EM;)</span> from <span class="ar">أُلْتُ</span>, <span class="auth">(T, Ṣ,)</span> signifying <em>I put into a good, right,</em> or <em>proper, state,</em> or <em>condition.</em> <span class="auth">(T. <span class="add">[<a href="#Awe_1">But see another reading in the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=01_A/169_Awe">of art. <span class="ar">اوى</span></a>.]</span>)</span> You say also, <span class="ar long">أُلْتُ الشَّىْءَ</span> meaning <em>I composed,</em> or <em>collected together, the thing, and put it into a good, right,</em> or <em>proper, state,</em> or <em>condition:</em> and some of the Arabs say,<span class="arrow"><span class="ar long">أَوَّلَ↓ ٱللّٰهُ عَلَيْكَ أَمْرَكَ</span></span>, i. e. <em>May God compose for thee thine affair:</em> and, by way of imprecation, <span class="arrow"><span class="ar long">لَا أَوَّلَ↓ ٱللّٰهُ عَلَيْهِ شَمْلَهُ</span></span> <span class="add">[<em>May God not compose for him his discomposed, disorganized, deranged,</em> or <em>unsettled, affair,</em> or <em>affairs</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C3</span>
				</div>
				<div class="sense" id="Awl_1_C3">
					<p><span class="ar long">أُلْتُ الإِبلَ</span>, inf. n. <span class="ar">أَوْلٌ</span> and <span class="ar">إِيَالٌ</span>, also signifies <em>I drove the camels:</em> <span class="auth">(M:)</span> or, accord. to the T, <em>I bound the camels' udders with the</em> <span class="ar">أَصِرَّة</span> (<span class="ar">صَرَرْتُهَا</span>) <em>until the time of milking, when I loosed them.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awl_2">
				<h3 class="entry">2. ⇒ <span class="ar">أوّل</span></h3>
				<div class="sense" id="Awl_2_A1">
					<p><span class="ar long">أوّلهُ إِلَيْهِ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَأْوِيلٌ</span>, <span class="auth">(TA,)</span> <em>He returned it</em> <span class="auth">(namely, a thing, M)</span> <em>to him,</em> or <em>it; he made it,</em> or <em>caused it, to return to him,</em> or <em>it;</em> syn. <span class="ar">رَجَعَهُ</span>: <span class="auth">(M, Ḳ: in the CK <span class="ar">رَجَّعَهُ</span>:)</span> and<span class="arrow"><span class="ar">آلَهُ↓</span></span> also signifies the same; syn. <span class="ar">رَدَّهُ</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">أَوَّلَ ٱللّٰهُ عَلَيْكَ ضَالَّتَكَ</span> <em>May God restore to thee thy stray;</em> <span class="auth">(T,* TA;)</span> <em>cause it to return to thee;</em> <span class="auth">(TA;)</span> <em>bring together thee and it.</em> <span class="auth">(T.)</span> And <span class="ar long">أَوَّلْتُهُ إِلَى كَذَا</span> <em>I caused him,</em> or <em>it, to come to such a state</em> or <em>condition; brought,</em> or <em>reduced, him,</em> or <em>it, thereto;</em> syn. <span class="ar long">صَيَّرْتُهُ إِلَيْهِ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awl_2_A2">
					<p><a href="#Awl_1">See also 1</a>, near the end of the paragraph, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Awl_2_A3">
					<p><span class="ar">تَأْوِيلٌ</span> also signifies The <em>discovering, detecting, revealing, developing,</em> or <em>disclosing,</em> or the <em>explaining, expounding,</em> or <em>interpreting, that to which a thing is,</em> or <em>may be, reduced,</em> or <em>that which it comes,</em> or <em>may come, to be:</em> <span class="auth">(Ṣ, O, TA:)</span> you say, <span class="ar">أَوَّلْتُهُ</span>, inf. n. <span class="ar">تَأْوِيلٌ</span>; and<span class="arrow"><span class="ar">تَأَوَّلْتُهُ↓</span></span>, inf. n. <span class="ar">تَأَوُّلٌ</span>; in one and the same sense: and hence the saying of El-Aạshà:</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">عَلَى أَنَّهَا كَانَتْ تَأَوُّلُ↓ حُبِّهَا</span></span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">تَأَوُّلَ↓ رِبْعِىِّ السِّقَابِ فَأَصْحَبَا</span></span> *</div> 
					</blockquote>
					<p><span class="auth">(Ṣ:)</span> or<span class="arrow"><span class="ar long">تاوَّل↓ حُبَّها</span></span>: <span class="auth">(so in a copy of the T: <span class="add">[the former word being, accord. to this reading, a contraction of <span class="ar">تَتَأَوَّلُ</span>; but this does not altogether agree with what here follows:]</span>)</span> AO says, <span class="ar long">تَأَوُّلُ حُبِّهَا</span> means <span class="ar long">تَفْسِيرُهُ وَمَرْجِعُهُ</span>: <span class="add">[i. e., the explanation of her love, or of the <span class="auth">(poet's)</span> love of her, and the state, or condition, to which it eventually came, is this:]</span> <span class="auth">(Ṣ:)</span> it was small in his heart, and ceased not to grow until it became great; like as the little young camel <span class="add">[born in the season called <span class="ar">ربيع</span>, or in the beginning of the breeding-time,]</span> ceases not to grow until he becomes great like his mother, <span class="auth">(T,* Ṣ,)</span> and has a son accompanying him: <span class="auth">(Ṣ:)</span> <span class="add">[or]</span> <span class="ar">أوّلهُ</span> and<span class="arrow"><span class="ar">تأوّلهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. of the former as above, <span class="auth">(Ḳ,)</span> when said of language, signify <span class="ar long">دَبَّرَهُ وَقَدَّرَهُ وَفَسَّرَهُ</span> <span class="add">[<em>he considered its end,</em> or <em>what it might be to which it led or pointed, and compared one part of it with another, and</em> then <em>explained,</em> or <em>expounded,</em> or <em>interpreted, it</em>]</span>: <span class="auth">(M, Ḳ:)</span> hence, <span class="add">[if the explanation in the M and Ḳ be meant to denote three distinct meanings, which I do not think to be the case,]</span> it would seem as though <span class="ar">تَأْوِيلٌ</span> and <span class="ar">تَفْسِيرٌ</span> were syn.; but accord. to other authorities, they differ: <span class="auth">(TA:)</span> <span class="add">[Az says,]</span> accord. to Aḥmad Ibn-Yaḥyà, these two words and <span class="ar">مَعْنًى</span> are all one: but <span class="ar">تأويل</span> seems to me to signify the <em>collecting the meanings of dubious expressions by such expression as is clear,</em> or <em>plain, without dubiousness:</em> or, accord. to Lth, it is the <em>interpreting of language that has different meanings; and this cannot be rightly done but by an explanation which changes the expression;</em> as also<span class="arrow"><span class="ar">تأَوُّلٌ↓</span></span>: <span class="auth">(T:)</span> or the <em>turning a verse of the Ḳur-án from its apparent meaning to a meaning which it bears,</em> or <em>admits, when the latter is agreeable with the Scripture and the Sunneh:</em> for instance, in the words of the Ḳur <span class="add">[vi. 95, &amp;c.]</span>, <span class="ar long">يُخْرِجُ ٱلْحَىَّ مِنَ المَيِّتِ</span>, if the meaning be <span class="add">[thus explained]</span> “He produceth the bird from the egg,” this is <span class="ar">تفسير</span>: and if <span class="add">[it be explained as meaning]</span> “He produceth the believer from the unbeliever,” or “the knowing from the ignorant,” this is <span class="ar">تأويل</span>: so says Ibn-El-Kemál: <span class="auth">(TA:)</span> <span class="add">[hence, although it may often be rendered by <em>interpretation,</em> like <span class="ar">تفسير</span>, it more properly signifies the <em>rendering in a manner not according to the letter,</em> or <em>overt sense; explaining the covert,</em> or <em>virtual, meaning; interpreting in a manner not according to the obvious meaning:</em>]</span> <span class="pb" id="Page_0127"></span>or the <em>reducing a thing to its ultimate intent, whether it be a saying or an action:</em> <span class="auth">(Er-Rághib, TA:)</span> or <span class="ar">تفسير</span> signifies the “discovering, detecting, revealing, or disclosing, what is meant by a dubious expression;” and <span class="ar">تأويل</span>, the <em>reducing one of two senses,</em> or <em>interpretations, which an expression bears,</em> or <em>admits, to that which suits the apparent meaning:</em> <span class="auth">(L and Ḳ in art. <span class="ar">فسر</span>, and TA in that and in the present art.:)</span> or the former signifies the “expounding, explaining, or interpreting, the narratives which occur collected without discrimination in the Ḳur-án, and making known the significations of the strange words or expressions, and explaining the occasions on which the verses were revealed;” and the latter, the <em>explaining the meaning of that which is</em> <span class="ar">مُتَشَابِهِ</span>, <span class="add">[or <em>what is equivocal,</em> or <em>ambiguous,</em>]</span> i. e., <em>what is not understood without repeated consideration.</em> <span class="auth">(TA: <span class="add">[in which are some further explanations; but these add nothing of importance.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Awl_2_A4">
					<p><span class="add">[Hence, <span class="ar long">أوّل لَفْظًا</span>, in grammar, <em>He rendered a word,</em> or <em>an expression,</em> or <em>a phrase, in grammatical analysis, by another word,</em> or <em>expression,</em> or <em>phrase.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Awl_2_A5">
					<p>And <span class="add">[hence likewise,]</span> <span class="ar">تَأْوِيلٌ</span> signifies also The <em>interpretation,</em> or <em>explanation,</em> of a dream; the <em>telling the final sequel,</em> or <em>result,</em> thereof: <span class="auth">(M, Ḳ:)</span> as in the Ḳur xii. 101. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Awl_2_A6">
					<p>It is also used <span class="add">[as a simple subst.]</span> to signify The <em>end, issue, result,</em> or <em>final sequel,</em> of a thing; syn. <span class="ar">عَاقِبَةٌ</span>; <span class="auth">(Bḍ in iv. 62 and xvii. 37;)</span> or<span class="arrow"><span class="ar">مَآلٌ↓</span></span>; <span class="auth">(Jel in the same places;)</span> or <span class="ar">مَرْجِعٌ</span>, and <span class="ar">مَصِيرٌ</span>; as in the Ḳur <span class="add">[iii. 5]</span>, <span class="ar long">وَمَا يعْلَمُ تَأْوِيلَهُ إِلَّا ٱللّٰهُ</span> <span class="add">[<em>But none knoweth the end,</em>, &amp;c., <em>thereof, except God</em>]</span>: <span class="auth">(AʼObeyd, T:)</span> or this phrase means, <em>but none knoweth when will be the resurrection, and to what the case will eventually come,</em> <span class="auth">(T, M,)</span> <em>when the hour shall arrive,</em> <span class="auth">(TA,)</span> <em>except God:</em> <span class="auth">(T, M:)</span> so says Aboo-Is-ḥáḳ: <span class="auth">(T:)</span> and in like manner, <span class="add">[in the Ḳur vii. 51,]</span> <span class="ar long">هَلْ يَنْظُرُونَ إِلَّا تَأْوِيلَهُ</span> means <em>Do they wait for aught save the result to which their case will come by the resurrection?</em> <span class="auth">(Aboo-Is-ḥáḳ, T, M:)</span> or, <em>the result to which it will come</em> <span class="auth">(Bḍ, Jel)</span> <em>in the manifestation of its truth by the appearance of the promises and threats of which it has told?</em> <span class="auth">(Bḍ:)</span> in like manner, also, the saying, <span class="ar long">تَقْوى ٱللّٰهِ أَحْسَنُ تَأْوِيلًا</span> means <em>The fear of God is best in respect of result;</em> syn. <span class="ar">عَاقِبَةً</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأوّل</span></h3>
				<div class="sense" id="Awl_5_A1">
					<p><a href="#Awl_2">see 2</a>, in the former half of the paragraph, in six places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awl_5_A2">
					<p><span class="ar long">تأوّل فِيهِ الخَيْرَ</span> <em>He discovered in him the existence of good,</em> or <em>goodness, from its outward signs:</em> and <em>he sought,</em> or <em>looked for, good,</em> or <em>goodness, in him.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">تَأَوَّلْتُ فِى فُلَانٍ الأَجْرَ</span> <em>I sought,</em> or <em>looked for, recompense in</em> <span class="auth">(or <em>of</em> or <em>from</em>)</span> <em>such a one.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awl_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتول</span> ⇒ <span class="ar">ائتال</span></h3>
				<div class="sense" id="Awl_8_A1">
					<p><a href="#Awl_1">see 1</a>, near the end of the paragraph, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awl_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأول</span> ⇒ <span class="ar">استآل</span></h3>
				<div class="sense" id="Awl_10_A1">
					<p><span class="ar long">استآل الرُّؤْيَا</span> <em>He sought the interpretation of the dream, by consideration.</em> <span class="auth">(TA in art. <span class="ar">سوأ</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MlN.1">
				<h3 class="entry"><span class="ar">آلٌ</span></h3>
				<div class="sense" id="MlN.1_A1">
					<p><span class="ar">آلٌ</span> A man's <span class="ar">أَهْل</span> <span class="add">[or <em>family</em>]</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> i. e. his <em>relations:</em> <span class="auth">(Mṣb:)</span> his <span class="ar">عَشِيرَة</span> <span class="add">[or <em>kinsfolk;</em> or <em>nearer,</em> or <em>nearest, relations by descent from the same father or ancestor;</em>, &amp;c.]</span>; from <span class="ar">أَوْلٌ</span> as signifying <span class="ar">رُجُوعٌ</span>, because recourse is had to them in all affairs: <span class="auth">(Ḥar p. 578:)</span> and his <em>household;</em> <span class="auth">(Ṣ, TA;)</span> the <em>people of</em> his <em>house:</em> <span class="auth">(Mṣb:)</span> and his <em>followers;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> including <em>soldiers:</em> <span class="auth">(Ṣ, TA:)</span> and his <span class="ar">أَوْلِيَآء</span> <span class="add">[i. e. <em>friends,</em> and <em>the like</em>]</span>: <span class="auth">(Ḳ:)</span> <em>those who bear a relation</em> to him, <em>as members to a head,</em> (<span class="ar long">مَنْ آلَ إِلَيْهِ</span>,) <em>by religion</em> or <em>persuasion</em> or <em>kindred;</em> as in the Ḳur iii. 9 and viii. 54 and 56, &amp;c.: <span class="auth">(Ibn-ʼArafeh:)</span> <span class="add">[or in these and many other instances, it may be rendered <em>people:</em>]</span> but in general it is not used save in relation to that in which is eminence, or nobility; so that one does not say, <span class="ar long">آلُ الإِسْكَافِ</span>, like as one says <span class="ar">أَهْلُهُ</span>: <span class="auth">(Ḳ:)</span> and it is peculiarly used as a prefix to the proper names of rational beings; not to indeterminate nouns, nor to nouns of places or of times; so that one says, <span class="ar long">آلُ فُلَانٍ</span>; but not <span class="ar long">آلُ رَجُلٍ</span>, nor <span class="ar long">آلُ زَمَانِ كَذَا</span>, nor <span class="ar long">آلُ مَوْضَعِ كَذَا</span>, like as one says, <span class="add">[<span class="ar long">أَهْلُ رَجُلٍ</span>, and <span class="ar long">أَهْلُ زَمَانِ كَذَا</span>, and]</span> <span class="ar long">أَهْلُ بَلَدِ كَذَا</span> and <span class="ar long">مَوْضِعِ كَذَا</span>: <span class="auth">(TA:)</span> Ks disallows its being prefixed to a pronoun; so that one should not say, <span class="ar">آلُهُ</span>, but <span class="ar">أَهْلُهُ</span>; but his opinion in this matter is not correct: it is originally <span class="ar">أَوَلٌ</span>; the <span class="ar">و</span> being changed into <span class="ar">ا</span>, <span class="auth">(M,* Mṣb,)</span> as in <span class="ar">قَالَ</span> <span class="add">[which is originally <span class="ar">قَوَلَ</span>]</span>: so say some: <span class="auth">(Mṣb:)</span> or it is originally <span class="ar">أَهْلٌ</span>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> then <span class="ar">أَأْلٌ</span>, and then <span class="ar">آلٌ</span>: <span class="auth">(Ḳ:)</span> so say some, arguing thus from its having <span class="ar">أُهَيْلٌ</span> for its dim.: <span class="auth">(T, Mṣb:)</span> but accord. to Ks, it assumes the form <span class="arrow"><span class="ar">أُوَيْلٌ↓</span></span> as a dim.: <span class="auth">(T:)</span> or each of these is its dim. <span class="auth">(M, Ḳ.)</span> By the <span class="ar">آل</span> of the Prophet are meant, accord. to some persons, <em>His followers, whether relations or others:</em> and <em>his relations, whether followers or not:</em> <span class="auth">(Aḥmad Ibn-Yaḥyà, T:)</span> or, as some say, <em>his family</em> (<span class="ar">أَهْلُهُ</span> <span class="add">[q. v.]</span>) <em>and his wives:</em> <span class="add">[but it seems to be indicated that what I have rendered “and his wives” is meant as an explicative adjunct to <span class="ar">اهله</span>:]</span> or, as some say, <em>the people of his religion:</em> <span class="auth">(Esh-Sháfiʼee, T:)</span> being himself asked who were his <span class="ar">آل</span>, he answered <em>all pious persons:</em> <span class="auth">(Anas, TA:)</span> but in a trad. in which it is said that the poor-rates are prohibited to him and to his <span class="ar">آل</span>, by this is meant those to whom was appropriated the fifth <span class="add">[of the spoils]</span> instead of the poor-rates; and these were the genuine descendants of Háshim and El-Muttalib. <span class="auth">(Esh-Sháfiʼee, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MlN.1_A2">
					<p><span class="ar long">يَا لَزَيْدٍ</span> and <span class="ar long">يَالَ زَيْدٍ</span>, accord. to the Koofees, are contractions of <span class="ar long">يَا آلَ زَيْدٍ</span> <span class="add">[<em>O family of Zeyd</em>]</span>. <span class="auth">(Mughnee, on the letter <span class="ar">ل</span>; and El-Ashmoonee on the Alfeeyeh of Ibn-Málik, section <span class="ar">الاستغاثة</span>. <span class="add">[<a href="index.php?data=23_l/000_l">See the letter <span class="ar">ل</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MlN.1_A3">
					<p><span class="add">[<a href="#IiylapN">See also <span class="ar">إِيلَةٌ</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MlN.1_B1">
					<p>‡ <em>I. q.</em> <span class="ar">شَخْصٌ</span> <span class="add">[meaning The <em>body,</em> or <em>corporeal form</em> or <em>figure</em> or <em>substance,</em> <span class="auth">(of anything, as is said in the T,)</span> <em>which one sees from a distance;</em> or, in this case, often, though not always, the <em>person,</em> or <em>self</em>]</span>; <span class="auth">(AA, T, Ṣ, M, Ḳ;)</span> of a man: a metaphorical application, from <span class="ar">آلٌ</span> as signifying <span class="ar">أَهْلٌ</span> and <span class="ar">عَشِيرَةٌ</span>; because comprising the members and the senses. <span class="auth">(Ḥar p. 578.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="MlN.1_B2">
					<p>Sometimes, it is redundant, or pleonastic; <span class="add">[being only used for the sake of metre in verse, or to give more force to an expression;]</span> as in the following instance:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أُلَاقِى مِنْ تَذَكُّرِ آلِ لَيْلَى</span> *</div> 
						<div class="star">* <span class="ar long">كَمَا يَلْقَى السَّلِيمُ مِنَ العِدَادِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>I experience, from remembrance of Leylà,</em> or <em>of Leylà's person</em> or <em>self, the like of what the person bitten</em> or <em>stung</em> by a venomous reptile <em>experiences from the paroxysm of pain occasioned by the bits</em> or <em>sting</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[See also another ex., voce <span class="ar">جَأْبٌ</span>; and another, voce <span class="ar">مِزْمَارٌ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="MlN.1_B3">
					<p><span class="add">[Like <span class="ar">شَخْصٌ</span>, it seems to be sometimes applied to <em>Any material thing that is somewhat high, and conspicuous:</em> and hence, perhaps, the signification next following.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="MlN.1_B4">
					<p><span class="ar long">مَا أَشْرَفَ مِنَ البَعِيرِ</span> <span class="add">[app. meaning The <em>overtopping,</em> or <em>higher, part,</em> or <em>parts, of the camel</em>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="MlN.1_B5">
					<p><em>A</em> <span class="add">[<em>tent of the kind called</em>]</span> <span class="ar">خَيْمَة</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B6</span>
				</div>
				<div class="sense" id="MlN.1_B6">
					<p>The <em>poles of the</em> <span class="ar">خَيْمَة</span>; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">آلَةٌ↓</span></span>; of which the pl. is <span class="ar">آلاتٌ</span>: <span class="auth">(Ḳ:)</span> or<span class="arrow"><span class="ar">آلَةٌ↓</span></span> <a href="#AlN">is the sing. of <span class="ar">آلٌ</span></a> and <span class="ar">آلَاتٌ</span>, <span class="add">[or n. un. of the former and pl. of the latter,]</span> which signify the <em>pieces of wood</em> (<span class="ar">خَشَبَات</span>) <em>upon which the</em> <span class="ar">خيمة</span> <em>is raised,</em> or <em>constructed:</em> and hence Kutheiyir likens the legs of his she-camel to four <span class="ar">آلات</span> of the <span class="add">[wood of the tree called]</span> <span class="ar">طَلْح</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B7</span>
				</div>
				<div class="sense" id="MlN.1_B7">
					<p>The <em>pieces of wood</em> (<span class="ar">خَشَب</span>, T, M, Ḳ) of <span class="ar">خَيْم</span> <span class="add">[or tents]</span>, <span class="auth">(M,)</span> <em>stripped</em> <span class="add">[<em>of the tent-cloths</em>]</span>. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B8</span>
				</div>
				<div class="sense" id="MlN.1_B8">
					<p>Also, <span class="add">[app. because rising from the general surface of the ground,]</span> The <em>extremities and sides</em> of a mountain. <span class="auth">(M, Ḳ.*)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="MlN.1_C1">
					<p>The <span class="ar">سَرَاب</span> <span class="add">[or <em>mirage</em>]</span>: <span class="auth">(Aṣ, T, M, Ḳ:)</span> or peculiarly applied to <em>that which is in the first part of the day,</em> <span class="auth">(Ḳ,)</span> <em>as though raising figures seen from a distance</em> (<span class="ar">شُخُوص</span>), <em>and making them to quiver:</em> <span class="auth">(TA:)</span> or <em>that which one sees in the first part of the day, and in the last part thereof, as though raising figures seen from a distance</em> (<span class="ar">شخوص</span>); <em>not the same as the</em> <span class="ar">سراب</span>: <span class="auth">(Ṣ:)</span> or <em>what resembles the</em> <span class="ar">سراب</span>: <span class="auth">(Mṣb:)</span> or, as some say, <em>that which is in the</em> <span class="ar">ضُحَى</span> <span class="add">[or <em>early part of the day when the sun is yet low</em>]</span>, <em>like water between the sky and the earth,</em> <span class="add">[<em>in appearance</em>]</span> <em>raising figures seen from a distance</em> (<span class="ar">شخوص</span>), <em>and making them to quiver;</em> whereas the <span class="ar">سراب</span> is that which is at mid-day, <span class="add">[apparently]</span> cleaving to the ground, as though it were running water: Th says, <em>the</em> <span class="ar">آل</span> <em>is in the first part of the day:</em> <span class="auth">(M:)</span> Aṣ says that <em>the</em> <span class="ar">آل</span> <em>and the</em> <span class="ar">سراب</span> <em>are one:</em> but others say that <em>the former is from the</em> <span class="ar">ضُحَى</span> <span class="add">[see above]</span> <em>to the declining of the sun from the meridian;</em> whereas the <span class="ar">سراب</span> is after the declining of the sun from the meridian to the prayer of the <span class="ar">عَصْر</span>; and in favour of their assertion they urge, that <em>the former</em> <span class="add">[<em>in appearance</em>]</span> <em>raises everything so that it becomes what is termed</em> <span class="ar">آل</span>, <em>i. e.</em> <span class="ar">شَخْص</span>; for the <span class="ar">آل</span> of everything is its <span class="ar">شخص</span>; and that the <span class="ar">سراب</span> <span class="add">[in appearance]</span> lowers every <span class="ar">شخص</span> in it so that it becomes <span class="add">[as though it were]</span> cleaving to the ground, having no <span class="ar">شخص</span>: Yoo says, the Arabs say that <em>the</em> <span class="ar">آل</span> <em>is from the</em> <span class="ar">غُدْوَة</span> <span class="add">[or <em>period between the prayer of daybreak and sunrise</em>]</span> <em>to the time when the sun is very high,</em> or <em>near the meridian;</em> then it is called <span class="ar">سراب</span> for the rest of the day: ISk says, <em>the</em> <span class="ar">آل</span> <em>is that which</em> <span class="add">[<em>in appearance</em>]</span> <em>raises figures seen from a distance</em> (<span class="ar">شخوص</span>),<em>and is in the</em> <span class="ar">ضُحَى</span> <span class="add">[explained above]</span>; <span class="pb" id="Page_0128"></span>and the <span class="ar">سراب</span> is that which is upon the surface of the ground, as though it were water, and is at midday: and this, I <span class="add">[namely Az]</span> say, is what I have found the Arabs in the desert to say: <span class="auth">(T:)</span> El-Ḥareeree speaks of the glistening of the <span class="ar">آل</span>; app. using this word in the sense of <span class="ar">سراب</span>; for it is the latter that glistens; not the former: <span class="auth">(Ḥar p. 363:)</span> the word is masc. and fem. <span class="auth">(Mṣb, Ḳ.)</span> The phrase <span class="ar long">يَرفَعُ ٱلْآلَا</span>, ending a verse <span class="auth">(Ṣ, M)</span> of En-Nábighah, <span class="auth">(M, TA,)</span> i. e. Edh-Dhubyánee, <span class="auth">(TA,)</span> or El-Jaadee, <span class="auth">(Ṣ,)</span> <span class="add">[variously cited in the Ṣ and M and TA,]</span> is an instance of inversion; the meaning being <span class="ar long">يَرْفَعُهُ ٱلْآلُ</span> <span class="add">[<em>The</em> <span class="ar">آل</span> <em>raising it</em>]</span>: <span class="auth">(Ṣ, TA:)</span> or the meaning is, <em>making the</em> <span class="ar">آل</span> <em>conspicuous</em> more than it would otherwise be; the agent of the verb being a prominent portion of a mountain, which, being itself raised <span class="add">[in appearance]</span> by the <span class="ar">آل</span>, has the effect of doing this. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="MlN.1_D1">
					<p><a href="#AlapN">See also the next paragraph</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلٌ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="MlN.1_E1">
					<p><a href="#OalayaAnN">And see <span class="ar">أَلَيَانٌ</span></a>, <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MlapN">
				<h3 class="entry"><span class="ar">آلَةٌ</span></h3>
				<div class="sense" id="MlapN_A1">
					<p><span class="ar">آلَةٌ</span> <em>i. q.</em> <span class="ar">أَدَاةٌ</span> <span class="add">[i. e. <em>An instrument; a tool; an implement; a utensil:</em> and <em>instruments; tools; implements; utensils; apparatus; equipments; equipage; accoutrements; furniture; gear; tackling;</em>]</span> <span class="auth">(Ṣ, M, Ḳ)</span> <em>with which one works, for himself</em> or <em>for another:</em> it is both sing. and pl.: <span class="auth">(M, Ḳ:)</span> or, <span class="auth">(Ḳ,)</span> as some say, <span class="auth">(M,)</span> it is a pl. having no sing. <span class="auth">(M, Ḳ)</span> as to the letter: <span class="auth">(M:)</span> <span class="add">[but it is very often used as a sing.:]</span> and the pl. is <span class="ar">آلَاتٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> In the saying of ʼAlee, <span class="ar long">يَسْتَعْمِلُ آلَةَ الدِّينِ فِى طَلَبِ الدُّنيَا</span> <span class="add">[lit. <em>He makes use of the instrument of religion in seeking the goods of the present world</em>]</span>, † <em>science,</em> or <em>knowledge,</em> is meant; because thereby only is religion. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MlapN_A2">
					<p><span class="add">[<em>A musical instrument;</em>]</span> <em>a lute; a musical reed,</em> or <em>pipe;</em> the <span class="add">[<em>kind of mandoline called</em>]</span> <span class="ar">طُنْبُور</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MlapN_A3">
					<p>The <em>male organ of generation.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MlapN_A4">
					<p>The <em>bier of a corpse.</em> <span class="auth">(Abu-l-ʼOmeythil, Ṣ, M, Ḳ.)</span> Thus, accord. to some, in the following verse, <span class="auth">(Ṣ,* M,)</span> of Kaab Ibn-Zuheyr:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">كُلُّ ٱبْنِ أُنْثَى وَإِنْ طَالتْ سَلَامَتُهُ</span> *</div> 
						<div class="star">* <span class="ar long">يَوْمًا عَلَى آلَةٍ حَدْبَآءَ مَحْمُولُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Every son of a female, though his health,</em> or <em>safety, long continue, is one day borne upon a gibbous bier:</em> for the bier of the Arabs of the desert was generally composed of two poles connected by a net-work of cords upon which the corpse lay depressed]</span>: <span class="auth">(Ṣ, M:)</span> or, as some say, <span class="add">[<em>in a distressing state,</em> or <em>condition;</em> for, they say,]</span> <span class="ar">آلَة</span> here signifies <span class="ar">حَلَة</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="MlapN_A5">
					<p><a href="#AlN">See also <span class="ar">آلٌ</span></a>, in two places, near the middle of the paragraph.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MlapN_B1">
					<p><em>A state,</em> or <em>condition; i. q.</em> <span class="ar">حَالَةٌ</span> <span class="add">[as mentioned above]</span>: <span class="auth">(T, Ṣ, M, Ḳ:)</span> pl. <span class="add">[or rather coll. gen. n.]</span> <span class="arrow"><span class="ar">آلٌ↓</span></span>. <span class="auth">(T, Ṣ.)</span> You say, <span class="ar long">هُوَبِآلةِ سَوْءٍ</span> <span class="add">[<em>He is in an evil state</em> or <em>condition</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="MlapN_B2">
					<p><em>I. q.</em> <span class="ar">شِذَّةٌ</span> <span class="add">[<em>Straitness; difficulty; distress;</em>, &amp;c.]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiylapN">
				<h3 class="entry"><span class="ar">إِيلَةٌ</span></h3>
				<div class="sense" id="IiylapN_A1">
					<p><span class="ar">إِيلَةٌ</span> sometimes signifies The <em>relations to whom one goes</em> <span class="add">[or <em>is traced</em>]</span> <em>back in genealogy.</em> <span class="auth">(Ibn-ʼAbbád.)</span> <span class="add">[<a href="#AlN">See also <span class="ar">آلٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">إِيلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiylapN_A2">
					<p>You say also, <span class="ar long">رَدَدْتُهُ إِلَى إِيلَتِهِ</span> <em>I made him to go back,</em> or <em>revert, to his natural disposition:</em> or, <em>to his</em> <span class="add">[<em>original</em>]</span> <em>state</em> or <em>condition.</em> <span class="auth">(Ibn-ʼAbbád.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ouwluw">
				<h3 class="entry"><span class="ar">أُولُو</span></h3>
				<div class="sense" id="Ouwluw_A1">
					<p><span class="ar">أُولُو</span>, in the gen. and accus. <span class="ar">أُولِى</span>: <a href="#Ouluw">see <span class="ar">أُلُو</span></a>, <a href="index.php?data=01_A/126_Alw">in art. <span class="ar">الو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ouwlae">
				<h3 class="entry"><span class="ar">أُولَى</span> / 
							<span class="ar">أُولَآءِ</span> / 
							<span class="ar">أُولٰئِكَ</span> / 
							<span class="ar">أُولَآئِكَ</span></h3>
				<div class="sense" id="Ouwlae_A1">
					<p><span class="ar">أُولَى</span> <a href="#OawBalu">fem. of <span class="ar">أَوَّلُ</span></a>: <a href="#OawBalu">see the latter</a> <a href="../">in art. <span class="ar">وأل</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">أُولَى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ouwlae_B1">
					<p><span class="ar">أُولَى</span> as a pl., and its var. <span class="ar">أُولَآءِ</span>; and <span class="ar">أُولٰئِكَ</span>, or <span class="ar">أُولَآئِكَ</span>;, &amp;c.: <a href="#Oulae">see <span class="ar">أُلَى</span></a>, <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawaAlN">
				<h3 class="entry"><span class="ar">أَوَالٌ</span></h3>
				<div class="sense" id="OawaAlN_A1">
					<p><span class="ar">أَوَالٌ</span> <em>A certain idol of</em> <span class="add">[<em>the tribes of</em>]</span> <em>Bekr and Teghlib,</em> <span class="auth">(Ḳ, TA,)</span> <em>the two sons of Wáïl.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuwayolN">
				<h3 class="entry"><span class="ar">أُوَيْلٌ</span></h3>
				<div class="sense" id="OuwayolN_A1">
					<p><span class="ar">أُوَيْلٌ</span> <a href="#AlN">dim. of <span class="ar">آلٌ</span>, q. v.</a> <span class="auth">(Ks, T, M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyaAlN">
				<h3 class="entry"><span class="ar">إِيَالٌ</span></h3>
				<div class="sense" id="IiyaAlN_A1">
					<p><span class="ar">إِيَالٌ</span> The <em>vessel,</em> or <em>receptacle, of thickening,</em> or <em>thick, milk:</em> <span class="auth">(M:)</span> <span class="add">[or, accord. to the Ḳ, this seems to be termed <span class="arrow"><span class="ar">أُيَّلٌ↓</span></span>: <a href="#AyilN">see <span class="ar">آئِلٌ</span></a>:]</span> or, <em>in which wine</em> (<span class="ar">شَرَاب</span>), or <em>expressed juice,</em> or <em>what is pressed,</em> or <em>squeezed, so that its juice is forced out,</em> or <em>the like thereof, is made to thicken.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">إِيَالٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IiyaAlN_B1">
					<p><span class="add">[<a href="#Awl_1">Also an inf. n. of 1, which see</a> throughout.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyaAlapN">
				<h3 class="entry"><span class="ar">إِيَالَةٌ</span></h3>
				<div class="sense" id="IiyaAlapN_A1">
					<p><span class="ar">إِيَالَةٌ</span> <em>Rule,</em> or <em>government:</em> <span class="auth">(Ṣ, Mṣb:)</span> <span class="add">[<a href="#Awl_1">accord. to some, an inf. n. of <span class="ar">آلَ</span> as a trans. verb</a>: accord. to others,]</span> a simple subst. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawBalu">
				<h3 class="entry"><span class="ar">أَوَّلُ</span></h3>
				<div class="sense" id="OawBalu_A1">
					<p><span class="ar">أَوَّلُ</span> and its variations, &amp;c., <a href="../">see art. <span class="ar">وأل</span></a>: some, on account of difference of opinion from others respecting its radical letters, have mentioned this word in the present art. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayBilN">
				<h3 class="entry"><span class="ar">أَيِّلٌ</span></h3>
				<div class="sense" id="OayBilN_A1">
					<p><span class="ar">أَيِّلٌ</span>: <a href="#IiyBalN">see <span class="ar">إِيَّلٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">أَيِّلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OayBilN_B1">
					<p><a href="#AyilN">and see also <span class="ar">آئِلٌ</span></a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuyBalN">
				<h3 class="entry"><span class="ar">أُيَّلٌ</span></h3>
				<div class="sense" id="OuyBalN_A1">
					<p><span class="ar">أُيَّلٌ</span>: <a href="#IiyBalN">see <span class="ar">إِيَّلٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">أُيَّلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OuyBalN_B1">
					<p><a href="#AylNi">and see also <span class="ar">آئِلٌ</span></a>, in four places; <a href="#IiyaAlN">and <span class="ar">إِيَالٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyBalN">
				<h3 class="entry"><span class="ar">إِيَّلٌ</span> / <span class="ar">إِيَّلَةٌ</span></h3>
				<div class="sense" id="IiyBalN_A1">
					<p><span class="ar">إِيَّلٌ</span> and<span class="arrow"><span class="ar">أُيَّلٌ↓</span></span> <span class="auth">(T, Ṣ, Mgh, Mṣb, Ḳ, the first and third and fourth in art. <span class="ar">ايل</span>)</span> and<span class="arrow"><span class="ar">أيِّلٌ↓</span></span>, <span class="auth">(T, Ḳ,)</span> the last on the authority of IAạr, <span class="auth">(TA,)</span> but AʼObeyd says that it is <span class="ar">إِيَّلٌ</span>, with kesr, <span class="auth">(T,)</span> and this is the approved form, <span class="auth">(TA,)</span> The <span class="add">[<em>animal called</em>]</span> <span class="ar">وَعْل</span>: <span class="auth">(Ḳ:)</span> or the <em>male</em> <span class="ar">وَعْل</span>; <span class="auth">(ISh, T, Ṣ, Mgh, Mṣb;)</span> i. e. the <em>mountain-goat:</em> <span class="auth">(Mṣb:)</span> accord. to some, <span class="auth">(Ṣ,)</span> what is called in Persian <span class="fa">كَوَزْن</span>; <span class="auth">(Ṣ, Mgh;)</span> by which word Sh explains the word <span class="ar">إِيَّلٌ</span>: ISh says, it is the <em>animal that is very wide between the horns, and bulky, like the domestic bull:</em> <span class="auth">(T:)</span> <span class="add">[<a href="#AlwaHoXi">see <span class="ar long">بَقَرُ الوَحْشِ</span></a> <a href="index.php?data=02_b/155_bqr">in art. <span class="ar">بقر</span></a>:]</span> and Lth says, it is called thus because it resorts (<span class="ar">يَؤُولُ</span>) to the mountains: sometimes the <span class="ar">ى</span> is changed into <span class="ar">ج</span>: the fem. is of the same three forms with <span class="ar">ة</span>: <span class="auth">(TA:)</span> and the pl. is <span class="ar">أَيَائِلُ</span> <span class="add">[like <span class="ar">سَيَائِدُ</span> <a href="#sayBidN">pl. of <span class="ar">سَيِّدٌ</span></a>]</span>. <span class="auth">(Lth, T, Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">إِيَّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiyBalN_A2">
					<p><a href="#AyilN">See also <span class="ar">آئِلٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYilN">
				<h3 class="entry"><span class="ar">آئِلٌ</span></h3>
				<div class="sense" id="MYilN_A1">
					<p><span class="ar">آئِلٌ</span> <span class="add">[act. part. n. of 1 in all its senses: and thus, particularly,]</span> <em>Thickening,</em> or <em>thick;</em> <span class="auth">(T, Ṣ, M, TA;)</span> applied to the urine of camels that have been contented with green pasture instead of water, at the end of their being in that state; <span class="auth">(T;)</span> or to milk, <span class="auth">(Ṣ, M, TA,)</span> and to oil, and other things, such as tar, and honey, and wine, or beverage: <span class="auth">(TA:)</span> pl. <span class="arrow"><span class="ar">أُيَّلٌ↓</span></span>: <span class="auth">(Ṣ, M:)</span> which last word <span class="add">[in one copy of the M written <span class="ar">إِيلٌ</span>, but this I think a mistranscription,]</span> signifies also the <em>remains of thickening,</em> or <em>thick, milk;</em> or, as some say, the <span class="add">[<em>seminal</em>]</span> <em>water in the womb:</em> <span class="auth">(M:)</span> or this same word (<span class="ar">أُيَّلٌ</span>) has the last of these significations; and also, <span class="add">[as a sing. epithet,]</span> the first of the meanings explained in this paragraph; as also <span class="ar">آئِلٌ</span>, applied to milk; <span class="auth">(Ḳ;)</span> or to milk <em>thickening,</em> or <em>thick, and mixed; not excessively thick, but in a somewhat good degree, and changed in its flavour:</em> <span class="auth">(AḤát, TA:)</span> or it <span class="add">[app. <span class="ar">أُيَّلٌ</span>, as in the TḲ,]</span> signifies the <em>vessel,</em> or <em>receptacle, thereof;</em> <span class="auth">(Ḳ;)</span> <span class="add">[a meaning assigned in the M to <span class="ar">إِيَالٌ</span>;]</span> <em>in which milk thickens:</em> <span class="auth">(TA:)</span> Sh says that <span class="arrow"><span class="ar">إِيَّلٌ↓</span></span> signifies the <em>milk of the</em> <span class="ar">أَيَائِل</span> <span class="add">[<a href="#IiyBalN">pl. of <span class="ar">إِيَّلٌ</span></a>]</span>; and so says AA: but AHeyth says that this is absurd; and that the right word is <span class="arrow"><span class="ar">أُيَّلٌ↓</span></span>, having the signification first explained in this paragraph, i. e. <em>thickening,</em> or <em>thick,</em> milk: En-Naḍr says that <span class="arrow"><span class="ar">إِيَّلٌ↓</span></span> signifies <em>thick urine of she-goats of the mountain;</em> which, when drunk by a woman, excites her venereal faculty: <span class="auth">(T:)</span> or this last word is used to signify <em>milk of an</em> <span class="ar">إِيَّل</span>, which is said to strengthen in the venereal faculty, and to fatten, as Ibn-Ḥabeeb asserts; and<span class="arrow"><span class="ar">أُيَّلٌ↓</span></span>, which he affirms to be wrong, is a dial. var. thereof; and it may also be a quasi-pl. n. thereof: <span class="auth">(M:)</span> as a pl. <span class="add">[of <span class="ar">آئِلٌ</span>]</span>, applied to milk, <span class="arrow"><span class="ar">آُيَّلٌ↓</span></span> is extr. in two respects; as a pl., of this form, of an epithet not applied to an animal; and as being regularly <span class="ar">أُوَّلٌ</span>. <span class="auth">(IJ, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">آئِلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MYilN_B1">
					<p><span class="ar long">إِنَّهُ لَآئِلُ مَالٍ</span> and<span class="arrow"><span class="ar long">أَيِّلُ↓ مَالٍ</span></span> <em>Verily he is a good manager,</em> or <em>tender, of cattle,</em> or <em>camels,</em> or <em>the like.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOowiylN">
				<h3 class="entry"><span class="ar">تَأْوِيلٌ</span></h3>
				<div class="sense" id="taOowiylN_A1">
					<p><span class="ar">تَأْوِيلٌ</span> used as a simple subst. in the sense of <span class="ar">عَاقِبَةٌ</span>, &amp;c.: <a href="#Awl_2">see 2</a>, last sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maMlN">
				<h3 class="entry"><span class="ar">مَآلٌ</span></h3>
				<div class="sense" id="maMlN_A1">
					<p><span class="ar">مَآلٌ</span> <a href="#Awl_1">inf. n. of <span class="ar">آلَ</span></a>, in two senses pointed out above. <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">مَآلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maMlN_A2">
					<p><span class="add">[Hence, <span class="ar long">مَآلُهُ إِلَى كَذَا</span> <em>His,</em> or <em>its, return,</em> or <em>course,</em> or <em>transition, is to such a state</em> or <em>condition.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">مَآلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maMlN_B1">
					<p>Also, <span class="add">[as a noun of place, &amp;c.,]</span> <em>i. q.</em> <span class="ar">مَرْجِعٌ</span> <span class="add">[as signifying <em>A place,</em> and <em>a state,</em> or <em>condition, to which a person,</em> or <em>thing, returns;</em> and, <em>to which he,</em> or <em>it, ultimately,</em> or <em>eventually, comes</em>]</span>. <span class="auth">(TA, <span class="add">[where this is given as a signification not mentioned in the Ḳ; so that <span class="ar">مرجع</span> is not here used as an inf. n.: it is, moreover, a signification well known.]</span>)</span> <a href="#Awl_2">See also 2</a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">مَآلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="maMlN_B2">
					<p><em>A refuge:</em> applied in this sense to God. <span class="auth">(Ḥar p. 361.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotaAlN">
				<h3 class="entry"><span class="ar">مُؤْتَالٌ</span></h3>
				<div class="sense" id="muWotaAlN_A1">
					<p><span class="ar long">هُوَ مُؤْتَالٌ لِقَوْمِهِ مُقْتَالٌ عَلَيْهِمْ</span> <em>He is ruler,</em> or <em>governor, of his people; a possessor of dictatorship over them,</em> or <em>of authority over them to judge</em> or <em>give judgment</em> or <em>pass sentence</em> or <em>decide judicially.</em> <span class="auth">(A, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOawBalN">
				<h3 class="entry"><span class="ar">مُتَأَوَّلٌ</span></h3>
				<div class="sense" id="mutaOawBalN_A1">
					<p><span class="ar long">هٰذَا مُتَأَوَّلٌ حَسَنٌ</span> <span class="add">[app. <em>This is a good discovery made from outward signs</em>]</span>. <span class="auth">(TA, where it immediately follows <span class="ar long">تَأَوَّلَ فِيهِ الخَيْرَ</span> with its explanations given above.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOawBilN">
				<h3 class="entry"><span class="ar">مُتَأَوِّلٌ</span></h3>
				<div class="sense" id="mutaOawBilN_A1">
					<p><span class="ar">مُتَأَوِّلٌ</span>: see its verb.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اول</span> - Entry: <span class="ar">مُتَأَوِّلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutaOawBilN_A2">
					<p><span class="add">[Sometimes it signifies]</span> <em>Veracious:</em> opposed to <span class="ar">مُتَقَوِّلٌ</span>. <span class="auth">(Ḥar p. 256.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0125.pdf" target="pdf">
							<span>Lanes Lexicon Page 125</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0126.pdf" target="pdf">
							<span>Lanes Lexicon Page 126</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0127.pdf" target="pdf">
							<span>Lanes Lexicon Page 127</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0128.pdf" target="pdf">
							<span>Lanes Lexicon Page 128</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
