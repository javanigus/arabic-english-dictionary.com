<article class="root" id="Root_Anyh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/151_Ane">انى</a></span>
				<span class="ar">انيه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/153_Ah">اه</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Iiniyho.1">
				<h3 class="entry"><span class="ar">إِنِيهْ</span></h3>
				<div class="sense" id="Iiniyho.1_A1">
					<p><span class="ar">إِنِيهْ</span>: <a href="index.php?data=01_A/151_Ane">see art. <span class="ar">انى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0120.pdf" target="pdf">
							<span>Lanes Lexicon Page 120</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
