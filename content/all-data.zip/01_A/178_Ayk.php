<article class="root" id="Root_Ayk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/177_AyD">ايض</a></span>
				<span class="ar">ايك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/179_Ayl">ايل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ayk_1">
				<h3 class="entry">1. ⇒ <span class="ar">أيك</span></h3>
				<div class="sense" id="Ayk_1_A1">
					<p><span class="ar long">أَيِكَ الأَرَاكُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْيَكُ</span>}</span></add>, <em>The</em> <span class="add">[<em>trees called</em>]</span> <span class="ar">اراك</span> <em>became what is termed</em> <span class="ar">أَيْكَة</span> <span class="add">[<a href="#OaYokN">n. un. of <span class="ar">أَيْكٌ</span>, q. v.</a>]</span>; as also<span class="arrow"><span class="ar">استأيك↓</span></span>. <span class="auth">(Ḳ.)</span> The former occurs in poetry contracted into <span class="ar">أَيْكَ</span>. <span class="auth">(ISd, Ṣgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ayk_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأيك</span></h3>
				<div class="sense" id="Ayk_10_A1">
					<p><a href="#Ayk_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayokN">
				<h3 class="entry"><span class="ar">أَيْكٌ</span> / <span class="ar">أَيْكَةٌ</span></h3>
				<div class="sense" id="OayokN_A1">
					<p><span class="ar">أَيْكٌ</span> <em>Numerous, luxuriant</em> or <em>tangled</em> or <em>dense, trees:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>a place where water collects and sinks into the ground</em> (<span class="ar">غَيْضَةٌ</span>) <em>producing</em> <span class="add">[<em>trees of the kinds called</em>]</span> <span class="ar">سِدْر</span> and <span class="ar">أَرَاك</span> <span class="auth">(Lth, Ḳ)</span> <em>and similar soft trees:</em> <span class="auth">(Lth:)</span> or <em>a collection of any trees;</em> even, <em>of palm-trees:</em> <span class="auth">(Ḳ:)</span> or, as some say, <em>a place where</em> <span class="add">[<em>trees of the kind called</em>]</span> <span class="ar">أَثْل</span> <em>grow, and where is a collection of them:</em> or, accord. to AḤn, <em>an abundant collection of</em> <span class="ar">أَرَاك</span> <em>in one place:</em> <span class="auth">(TA:)</span> or <em>trees;</em> said to be <em>of the</em> <span class="add">[<em>kind called</em>]</span> <span class="ar">أَرَاك</span>: <span class="auth">(Mṣb:)</span> n. un. with <span class="ar">ة</span>: <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.:)</span> IAạr says, <span class="add">[you say,]</span> <span class="ar long">أَيْكَةٌ أَثْلٍ</span> and <span class="ar">رَهْطٌ</span>, and <span class="ar">قَصِيمَةٌ</span>. <span class="auth">(Sh.)</span> <span class="ar long">أَصْحَابُ ٱلْأَيْكَةِ</span> occurs in the Ḳur in four chapters: <span class="add">[xv. 78 and xxvi. 176 and xxxviii. 12 and 1.13:]</span> <span class="auth">(Ṣgh:)</span> he who reads thus means, by the latter word, <span class="ar">الغَيْضَة</span> <span class="add">[explained above, and also signifying <em>the thicket,</em> or <em>collection of tangled trees,</em>, &amp;c.]</span>; <span class="auth">(Ṣ, Ḳ;)</span> or <em>the tangled,</em> or <em>luxuriant,</em> or <em>abundant and dense, trees:</em> <span class="auth">(TA:)</span> another reading is <span class="ar">لَيْكَةَ</span>; accord. to which, this is the name of the town <span class="add">[in which the people here mentioned dwelt]</span>: <span class="auth">(Ṣ, Ḳ:)</span> or, as some say, the two words are <span class="add">[applied to the same place,]</span> like <span class="ar">بَكَّةُ</span> and <span class="ar">مَكَّةُ</span>: <span class="auth">(Ṣ:)</span> but Zj says that another reading is allowable, and very good; i. e. <span class="ar long">أَصْحَابُ لَيْكَةِ</span>, as being originally <span class="ar">الأيْكَةِ</span>; for the Arabs say, <span class="ar long">اَلَحْمَرُ قَدْ جَآءَنِى</span> and <span class="ar long">لَحْمَرُ جَآإَنِى</span> for <span class="ar">الأَحْمَرُ</span>; so that <span class="ar">لَيْكَة</span> is like <span class="ar">لَحْمَر</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayikN">
				<h3 class="entry"><span class="ar">أَيِكٌ</span></h3>
				<div class="sense" id="OayikN_A1">
					<p><span class="ar long">أَيْكٌ أَيِكٌ</span>, <span class="auth">(Ḳ, TA,)</span> like <span class="ar">كَتِفْ</span>, <span class="auth">(TA, <span class="add">[agreeably with the verb, but in the CK <span class="ar">اٰيِكٌ</span>,]</span>)</span> is a phrase in which the latter word signifies <span class="ar">مُثْمِرٌ</span> <span class="add">[<em>Putting forth fruit;</em>, &amp;c.]</span>: <span class="auth">(Ḳ, TA:)</span> or, as some say, it is an intensive epithet <span class="add">[signifying <em>very abundant</em> or <em>luxuriant</em> or <em>tangled</em>, &amp;c.]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
