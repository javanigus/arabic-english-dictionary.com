<article class="root" id="Root_Asf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/079_AsTrlAb">اسطرلاب</a></span>
				<span class="ar">اسف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/081_AsfydAj">اسفيداج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asf_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسف</span></h3>
				<div class="sense" id="Asf_1_A1">
					<p><span class="ar">أَسِفَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْسَفُ</span>}</span></add>, inf. n. <span class="ar">أَسَفٌ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> <em>He grieved, lamented,</em> or <em>regretted:</em> and <em>he was angry:</em> <span class="auth">(Mṣb:)</span> or <em>he grieved exceedingly:</em> and <em>he was exceedingly angry:</em> <span class="auth">(M:)</span> or <em>he grieved most intensely:</em> <span class="auth">(Ḳ:)</span> some say that <span class="ar">أَسَفٌ</span> signifies the <em>grieving</em> for a thing that has escaped; not in an absolute sense: <span class="auth">(MF:)</span> or it properly signifies the <em>rising,</em> or <em>swelling,</em> or <em>mantling, of the blood of the heart,</em> from desire of vengeance; and when this is against an inferior, it is <em>anger;</em> but when against a superior, it is <em>grief.</em> <span class="auth">(Er-Rághib.)</span> Moḥammad, being asked respecting sudden death, answered, saying, <span class="ar long">رَاحَةٌ لِلْمُؤْمِنِ وَأَخْذَةُ أَسَفٍ لِلْكَافِرِ</span>, or accord. to one recital, <span class="arrow"><span class="ar">أَسِفٍ↓</span></span>, i. e. <span class="add">[<em>Rest,</em> or <em>ease, to the believer, and an act of punishment</em>]</span> <em>of anger</em> <span class="add">[<em>to the unbeliever</em>]</span>, or <em>of one who is angry.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">أَسِفَ عَلَى مَا فَاتَهُ</span>, inf. n. as above; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">تأسّف↓</span></span>; <span class="auth">(Ṣ, M,* Ḳ;*)</span> <em>He grieved,</em> or <em>lamented, for,</em> or <em>at,</em> or <em>regretted, most intensely, what had escaped him:</em> <span class="auth">(Ṣ, M,* Ḳ:)</span> and <span class="ar long">أَسِفَ عَلَيْهِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> <em>he was angry with him,</em> or <em>at it:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <span class="ar long">أَسِفَ فُلَانٌ عَلَى كَذَا وَكَذَا</span> and<span class="arrow"><span class="ar">تأسّف↓</span></span>, signify, accord. to some, <em>such a one grieved,</em> or <em>lamented, for,</em> or <em>at, such and such things</em> which had escaped him: or, accord. to others, <em>grieved,</em> or <em>lamented, most intensely.</em> <span class="auth">(IAmb.)</span> <span class="ar">أَسَفًا</span> in the Ḳur xviii. 5 means, accord. to Eḍ-Ḍaḥḥák, <span class="ar">جَزَعًا</span> <span class="add">[i.e. <em>In grief,</em> or <em>in most violent grief,</em>, &amp;c.]</span>: or, accord. to Ḳatádeh, <em>in anger.</em> <span class="auth">(TA.)</span> And <span class="ar long">يَا أَسَفَا عَلَى يُوسُفِ</span>, in the Ḳur <span class="add">[xii. 84]</span>, means <span class="ar long">يَا جَزَعَاهُ</span> <span class="add">[<em>O my grief for Joseph:</em> or <em>O my most violent grief</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asf_4">
				<h3 class="entry">4. ⇒ <span class="ar">آسف</span></h3>
				<div class="sense" id="Asf_4_A1">
					<p><span class="ar">آسفهُ</span> <span class="auth">(in <span class="add">[some of]</span> the copies of the Ḳ, erroneously, <span class="ar">أَسَفَهُ</span>, TA)</span> <em>He angered him; made him angry:</em> <span class="auth">(Ṣ, M,* O, L, Mṣb, Ḳ:)</span> and <em>he grieved him; made him to grieve,</em> or <em>lament.</em> <span class="auth">(M,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asf_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأسّف</span></h3>
				<div class="sense" id="Asf_5_A1">
					<p><a href="#Asf_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asf_5_A2">
					<p><span class="ar long">تَأَسَّفَتْ يَدَهُ</span> ‡ <em>i. q.</em> <span class="ar">تَشَعَّثَتْ</span> <span class="add">[app. meaning <em>His hand became bruised,</em> or <em>mangled;</em> or <em>became cracked,</em> or <em>chapped</em>]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasafN">
				<h3 class="entry"><span class="ar">أَسَفٌ</span></h3>
				<div class="sense" id="OasafN_A1">
					<p><span class="ar">أَسَفٌ</span> <a href="#Asf_1">inf. n. of 1, which see</a> throughout. <span class="add">[Used as a subst., <em>i. q.</em> <span class="ar">أَسَافةٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasifN">
				<h3 class="entry"><span class="ar">أَسِفٌ</span></h3>
				<div class="sense" id="OasifN_A1">
					<p><span class="ar">أَسِفٌ</span> <span class="auth">(M, Mgh, Mṣb)</span> and<span class="arrow"><span class="ar">اسِفٌ↓</span></span> and<span class="arrow"><span class="ar">أَسْفَانُ↓</span></span> and<span class="arrow"><span class="ar">أَسِيفٌ↓</span></span> <span class="auth">(M, TA)</span> and<span class="arrow"><span class="ar">أَسُوفٌ↓</span></span> <span class="auth">(M)</span> <em>Angry:</em> <span class="auth">(Mgh, Mṣb, TA:)</span> or <em>exceedingly angry.</em> <span class="auth">(M.)</span> For an ex. of the first, <a href="#Asf_1">see 1</a>. <a href="#OasiyfN">See also <span class="ar">أَسِيفٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasofaAnu">
				<h3 class="entry"><span class="ar">أَسْفَانُ</span></h3>
				<div class="sense" id="OasofaAnu_A1">
					<p><span class="ar">أَسْفَانُ</span>: <a href="#OasifN">see <span class="ar">أَسِفٌ</span></a>: <a href="#OasiyfN">and <span class="ar">أَسِيفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisaAfN">
				<h3 class="entry"><span class="ar">إِسَافٌ</span></h3>
				<div class="sense" id="IisaAfN_A1">
					<p><span class="ar">إِسَافٌ</span> <span class="auth">(Ṣ, M, Ṣgh, &amp;c.)</span> and <span class="ar">أَسَافٌ</span> <span class="auth">(IAth, Ḳ)</span> <em>A certain idol,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>belonging to Kureysh,</em> <span class="auth">(Ṣ, M,)</span> <em>as was also</em> <span class="ar">نَائِلَةُ</span>; <span class="auth">(Ṣ;)</span> <em>the former of which was placed, by ʼAmr Ibn-Loheí, upon Es-Safà, and the latter upon El-Marweh; and he used to sacrifice to them, in front of the Kaabeh:</em> <span class="auth">(Ṣ, Ḳ:)</span> or, <span class="auth">(Ṣ, M, Ḳ,)</span> as some assert, <span class="auth">(Ṣ,)</span> <em>these two were two persons of Jurhum,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>a man and a woman,</em> <span class="auth">(M,)</span> <span class="ar">اساف</span> <em>the son of ʼAmr, and</em> <span class="ar">نائلة</span> <em>the daughter of Sahl,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>who committed fornication in the Kaabeh, and were therefore changed into two stones,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>which Kureysh afterwards worshipped.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[Other accounts of them are also given, slightly differing from the latter above.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasuwfN">
				<h3 class="entry"><span class="ar">أَسُوفٌ</span></h3>
				<div class="sense" id="OasuwfN_A1">
					<p><span class="ar">أَسُوفٌ</span>: <a href="#OasiyfN">see <span class="ar">أَسِيفٌ</span></a>, in two places: <a href="#OasifN">and see <span class="ar">أَسِفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasiyfN">
				<h3 class="entry"><span class="ar">أَسِيفٌ</span> / <span class="ar">أَسِيفَةٌ</span></h3>
				<div class="sense" id="OasiyfN_A1">
					<p><span class="ar">أَسِيفٌ</span> <em>Grieving, lamenting,</em> or <em>regretting,</em> <span class="auth">(Ḳ,* TA,)</span> <em>most intensely, on account of a thing that has escaped:</em> <span class="auth">(M, TA:)</span> and <em>quickly affected with grief,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <em>and tender-hearted;</em> as also<span class="arrow"><span class="ar">أَسُوفٌ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> or, as also<span class="arrow"><span class="ar">أَسُوفٌ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">أَسْفَانُ↓</span></span> and<span class="arrow"><span class="ar">آسِفٌ↓</span></span> <span class="auth">(M, TA)</span> and<span class="arrow"><span class="ar">أَسِفٌ↓</span></span>, <span class="auth">(M,)</span> <em>grieving exceedingly:</em> <span class="auth">(M:)</span> or <em>grieved:</em> <span class="auth">(TA:)</span> and sometimes the first signifies <em>angry, and at the same time grieving,</em> or <em>lamenting:</em> <span class="auth">(Ṣ:)</span> pl. <span class="ar">أُسَفَآءُ</span>. <span class="auth">(M.)</span> <a href="#OasifN">See also <span class="ar">أَسِفٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسِيفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasiyfN_A2">
					<p><em>A slave:</em> <span class="auth">(ISk, Ṣ, M, Ḳ:)</span> and <em>a hired man:</em> <span class="auth">(ISk, M, Ḳ:)</span> because of their state of abasement and subjection: fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَسِيفَةٌ</span>}</span></add>: <span class="auth">(M:)</span> and pl. as above. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسِيفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OasiyfN_A3">
					<p><em>A captive.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسِيفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OasiyfN_A4">
					<p><em>A very old man:</em> <span class="auth">(Ḳ:)</span> pl. as above: so in a trad., in which the slaying of such is forbidden. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسِيفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OasiyfN_A5">
					<p>One <em>who scarcely,</em> or <em>never, becomes fat.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسِيفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OasiyfN_A6">
					<p>† <em>A region,</em> or <em>country, that does not give growth to anything,</em> or <em>produce any vegetation;</em> as also <span class="ar">أَسِيفَةٌ</span> and<span class="arrow"><span class="ar">أُسَافَةٌ↓</span></span> and<span class="arrow"><span class="ar">أَسَافَةٌ↓</span></span>: <span class="auth">(M:)</span> and<span class="arrow"><span class="ar">أَسَافَةٌ↓</span></span> also signifies † <em>thin,</em> or <em>shallow, earth:</em> <span class="auth">(AḤn, M:)</span> and <span class="ar long">أَرْضٌ أَسِيفَةٌ</span>, ‡ <em>thin,</em> or <em>shallow, earth, which scarcely,</em> or <em>never, gives growth to anything,</em> or <em>produces any vegetation:</em> <span class="auth">(Ṣ:)</span> or <em>which is not commended for its vegetation:</em> <span class="auth">(A, TA:)</span> or, as also<span class="arrow"><span class="ar">أُسَافَةٌ↓</span></span> <span class="pb" id="Page_0059"></span>and<span class="arrow"><span class="ar">أَسَافَةٌ↓</span></span>, † <em>thin,</em> or <em>shallow, earth:</em> or <em>such as does not produce vegetation:</em> and †<span class="arrow"><span class="ar long">أَرْضٌ أَسِفَةٌ↓</span></span> <em>land which scarcely,</em> or <em>never, produces vegetation.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasaAfapN">
				<h3 class="entry"><span class="ar">أَسَافَةٌ</span></h3>
				<div class="sense" id="OasaAfapN_A1">
					<p><span class="ar">أَسَافَةٌ</span> <span class="add">[<em>Grief, lamentation,</em> or <em>regret:</em> and <em>anger:</em> (<a href="#Asf_1">see 1</a>:) or]</span> <em>excessive grief:</em> and <em>excessive anger:</em> <span class="auth">(M:)</span> or <em>most intense grief:</em> <span class="auth">(Ḳ:)</span> a subst. from <span class="ar">أَسِفَ</span>. <span class="auth">(M, Ḳ.)</span></p>	
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسَافَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasaAfapN_A2">
					<p>The <em>state,</em> or <em>condition, of a slave:</em> <span class="auth">(M, Ḳ:)</span> and, <em>of a hired man.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسَافَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OasaAfapN_A3">
					<p>‡ The <em>state,</em> or <em>condition, of land which scarcely,</em> or <em>never, produces vegetation.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسف</span> - Entry: <span class="ar">أَسَافَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OasaAfapN_B1">
					<p><a href="#OasiyfN">See <span class="ar">أَسِيفٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OusaAfapN">
				<h3 class="entry"><span class="ar">أُسَافَةٌ</span></h3>
				<div class="sense" id="OusaAfapN_A1">
					<p><span class="ar">أُسَافَةٌ</span>: <a href="#OasiyfN">see <span class="ar">أَسِيفٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MsifN">
				<h3 class="entry"><span class="ar">آسِفٌ</span></h3>
				<div class="sense" id="MsifN_A1">
					<p><span class="ar">آسِفٌ</span>: <a href="#OasiyfN">see <span class="ar">أَسِيفٌ</span></a>: <a href="#OasifN">and <span class="ar">أَسِفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0058.pdf" target="pdf">
							<span>Lanes Lexicon Page 58</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0059.pdf" target="pdf">
							<span>Lanes Lexicon Page 59</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
