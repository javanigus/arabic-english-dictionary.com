<article class="root" id="Root_Avm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/022_Avl">اثل</a></span>
				<span class="ar">اثم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/024_Avn">اثن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Avm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أثم</span></h3>
				<div class="sense" id="Avm_1_A1">
					<p><span class="ar">أَثِمَ</span>, <span class="auth">(Lth, Ṣ, M, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْثَمُ</span>}</span></add>, <span class="auth">(Lth, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِثْمٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">أَثَمٌ</span>, the former being a simple subst., <span class="auth">(Mṣb,)</span> and <span class="ar">مَأْثَمٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="pb" id="Page_0022"></span><em>He fell into what is termed</em> <span class="ar">إِثْمٌ</span><span class="add">[i. e. <em>a sin,</em> or <em>crime,</em>, &amp;c.]</span>; <span class="auth">(Lth, T, Ṣ, M, Mṣb,* Ḳ *;)</span> <span class="add">[<em>he sinned; committed a sin,</em> or <em>crime;</em>]</span> <em>he did what was unlawful:</em> <span class="auth">(M,* Ḳ:)</span> and<span class="arrow"><span class="ar">تَأْثِيمٌ↓</span></span> signifies the same as <span class="ar">إِثْمٌ</span>: <span class="auth">(Ḳ:)</span> it may be either an inf. n. of<span class="arrow"><span class="ar">أَثَمَ↓</span></span>, which <span class="add">[says ISd]</span> I have not heard, or, as Sb holds it to be, a simple subst. like <span class="ar">تَنْبِيتٌ</span>: <span class="auth">(M:)</span> and is said to be used in the sense of <span class="ar">إِثْم</span> in the Ḳur lii. 23 <span class="add">[and lvi. 24]</span>. <span class="auth">(TA.)</span> <span class="add">[It should be added also, that<span class="arrow"><span class="ar">تأْثَامٌ↓</span></span>, like <span class="ar">تَكْذَابٌ</span>, is syn. with <span class="ar">تأْثِيمٌ</span> and <span class="ar">إِثْمٌ</span>; and, like <span class="ar">تأثيم</span>, may be an inf. n. of<span class="arrow"><span class="ar">أَثَّمَ↓</span></span>, or a simple subst.: <a href="#baruwqN">see an ex. voce <span class="ar">بَرُوقٌ</span></a>.]</span> In the dial. of some of the Arabs, the first letter of the aor. is with kesr, as in <span class="ar">تِعْلَمُ</span> and <span class="ar">نِعْلَمُ</span>; and as the hemzeh in <span class="ar">إِثْمٌ</span> is with kesr, the radical hemzeh <span class="add">[in the aor.]</span> is changed into <span class="ar">ى</span>; so that they say <span class="ar">إِيثَمُ</span> and <span class="ar">تِيثَمُ</span> <span class="add">[for <span class="ar">آثَمُ</span> and <span class="ar">تَأْثَمُ</span>.]</span> <span class="auth">(TA.)</span> In the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَوْ قُلْتَ مَا فِى قَوْمَهَا لَمْ تِيثَمِ</span> *</div> 
						<div class="star">* <span class="ar long">يَفْضُلَهَا فِى حَسَبٍ وَمِيسَمِ</span> *</div> 
					</blockquote>
					<p>the meaning is, <span class="add">[<em>Shouldst thou say, thou wouldst not sin,</em> or <em>do wrong,</em> in so saying,]</span> <em>There is not, among her people,</em> any one <em>who excels her</em> <span class="add">[<em>in grounds of pretension to respect, and in impress,</em> or <em>character, of beauty</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avm_1_B1">
					<p><span class="ar long">أَثَمَهُ ٱللّٰهُ فِى كَذَا</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُمُ</span>}</span></add> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِمُ</span>}</span></add>, <span class="auth">(Ṣ,)</span> or <span class="ar">ـَ</span>, <span class="auth">(Ḳ,)</span> but there is no other authority than the Ḳ for this last, nor is there any reason for it, as the medial radical letter is not faucial, nor is the final, and in the Iktitáf el-Azáhir the aor. is said to be <span class="ar">ـِ</span> and <span class="ar">ـُ</span>, <span class="auth">(MF, TA,)</span> <span class="add">[<em>God reckoned him to have sinned,</em> or <em>committed a crime</em> or <em>the like, in such a thing;</em> or]</span> <em>God reckoned such a thing against him as an</em> <span class="ar">إِثْم</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <span class="ar">أَثَمَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِمُ</span>}</span></add> <span class="auth">(Fr, T, M, Mṣb)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْثُمُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">أَثْمٌ</span> <span class="auth">(Fr, T, Mṣb)</span> and <span class="ar">أَثَامٌ</span> <span class="auth">(Fr, T, TA)</span> and <span class="ar">إِثَامٌ</span>, <span class="auth">(Fr, TA,)</span> <em>He</em> <span class="auth">(God)</span> <em>requited him,</em> <span class="auth">(Fr, T,)</span> or <em>punished him,</em> <span class="auth">(M,)</span> <em>for what is termed</em> <span class="ar">إِثْمٌ</span> <span class="add">[i. e. <em>sin,</em> or <em>crime,</em>, &amp;c.]</span>: <span class="auth">(Fr, T, M:)</span> <span class="add">[<a href="#OavaAmN">see also <span class="ar">أَثَامٌ</span> below</a>:]</span> or <em>he</em> <span class="auth">(a man)</span> <em>pronounced him to be</em> <span class="ar">آثم</span> <span class="add">[i. e. <em>a sinner,</em> or <em>the like</em>]</span>: <span class="auth">(Mṣb:)</span> <span class="add">[or]</span> <span class="arrow"><span class="ar">آثَمَهُ↓</span></span>, aor. <span class="ar">يَؤْثِمُهُ</span>, has this last signification, said of God; and also signifies <em>He found him to be so.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Avm_1_B2">
					<p>You say also, <span class="ar long">أَثَمَتِ النَّاقَةُ المَشْىَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِمُ</span>}</span></add>, inf. n. <span class="ar">أَثْمٌ</span>, <em>The she-camel was slow.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avm_2">
				<h3 class="entry">2. ⇒ <span class="ar">أثّم</span></h3>
				<div class="sense" id="Avm_2_A1">
					<p><span class="ar">أثّمهُ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَأْثِيمٌ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <em>He said to him</em> <span class="ar">أَثِمْتَ</span> <span class="add">[<em>Thou hast fallen into a sin,</em> or <em>crime,</em>, &amp;c.; <em>hast sinned,</em>, &amp;c.]</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avm_2_B1">
					<p><a href="#Avm_1">See also 1</a>, first and second sentences.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avm_4">
				<h3 class="entry">4. ⇒ <span class="ar">آثم</span></h3>
				<div class="sense" id="Avm_4_A1">
					<p><span class="ar">آثمهُ</span> <em>He made him,</em> or <em>caused him, to fall into what is termed</em> <span class="ar">إِثْمٌ</span> <span class="add">[i. e. <em>a sin,</em> or <em>crime,</em>, &amp;c.]</span>, <span class="auth">(Zj, Ṣ, M, Ḳ,)</span> or <em>what is termed</em> <span class="ar">ذَنْبٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Avm_4_A2">
					<p><a href="#Avm_1">See also 1</a>, last sentence but one.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأثّم</span></h3>
				<div class="sense" id="Avm_5_A1">
					<p><span class="ar">تأثّم</span> <em>He abstained from what is termed</em> <span class="ar">إِثْمٌ</span> <span class="add">[i. e. <em>sin,</em> or <em>crime,</em>, &amp;c.]</span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> like <span class="ar">تَحَرَّجَ</span> meaning “he preserved himself from what is termed <span class="ar">حَرَجٌ</span>:” <span class="auth">(Mṣb:)</span> or <em>he did a work,</em> or <em>deed, whereby he escaped from what is termed</em> <span class="ar">إِثْمٌ</span>: <span class="auth">(TA:)</span> and <em>he repented of what is so termed,</em> <span class="auth">(M, Ḳ,)</span> <em>and begged forgiveness of it;</em> as though he removed the <span class="ar">إِثْم</span> itself by repentance and by begging forgiveness; or sought to do so by those two means. <span class="auth">(M.)</span> You say also, <span class="ar long">تأثّم مِنْ كَذَا</span> <em>He abstained from such a thing as a sin,</em> or <em>crime;</em> syn. <span class="ar">تَحَّنَثَ</span>, q. v. <span class="auth">(Ṣ, Ḳ, in art. <span class="ar">حنث</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IivomN">
				<h3 class="entry"><span class="ar">إِثْمٌ</span></h3>
				<div class="sense" id="IivomN_A1">
					<p><span class="ar">إِثْمٌ</span> <span class="add">[accord. to some, an inf. n.; <a href="#Oavima">see <span class="ar">أَثِمَ</span></a>: accord. to others, only a simple subst., signifying]</span> <em>A sin, a crime, a fault, an offence,</em> or <em>an act of disobedience,</em> syn. <span class="ar">ذَنْبٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <em>for which one deserves punishment;</em> differing from <span class="ar">ذَنْبٌ</span> inasmuch as this signifies both what is intentional and what is unintentional: <span class="auth">(Kull:)</span> or <span class="add">[so accord. to the M, but in the Ḳ “and,”]</span> <em>an unlawful deed:</em> <span class="auth">(M, Ḳ:)</span> or <em>a deed which retards from recompense:</em> or, accord. to Fr, <em>what is exclusive of the</em> <span class="add">[<em>punishment termed</em>]</span> <span class="ar">حَدّ</span>: accord. to Er-Rághib, it is a term of more general import than <span class="ar">عُدَوانٌ</span>: <span class="auth">(TA:)</span> <span class="arrow"><span class="ar">مَأْثَمٌ↓</span></span> <span class="add">[<a href="#Avm_1">which is originally an inf. n. of <span class="ar">أَثِمَ</span></a>]</span> is syn. with <span class="ar">إِثْمٌ</span>; <span class="auth">(T,* Mgh;)</span> and so, too, is <span class="arrow"><span class="ar">أَثَامٌ↓</span></span>, <span class="auth">(Mṣb,)</span> or<span class="arrow"><span class="ar">إِثَامٌ↓</span></span>, signifying <em>a deed retarding recompense:</em> <span class="auth">(TA:)</span> <a href="#IivomN">the pl. of <span class="ar">إِثْمٌ</span></a> is <span class="ar">آثَامٌ</span>: <span class="auth">(M:)</span> and the pl. of<span class="arrow"><span class="ar">مَأْثَمٌ↓</span></span> is <span class="ar">مَآثِمُ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">إِثْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IivomN_A2">
					<p><span class="add">[Sometimes it is prefixed to a noun or pronoun denoting its object:]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">إِثْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IivomN_A3">
					<p><span class="add">[and sometimes it means † The <em>punishment of a sin</em>, &amp;c.: see explanations of a passage in the Ḳur v. 32, voce <span class="ar">بَآءَ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">إِثْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IivomN_A4">
					<p><em>Wine:</em> <span class="auth">(Aboo-Bekr El-Iyádee, T, Ṣ, M, Ḳ:)</span> sometimes used in this sense; <span class="auth">(Ṣ;)</span> but tropically; not properly: <span class="auth">(IAmb:)</span> I think, <span class="add">[says ISd,]</span> because the drinking thereof is what is thus termed. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">إِثْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IivomN_A5">
					<p><span class="add">[And for a like reason,]</span> † <em>Contention for stakes,</em> or <em>wagers, in a game of hazard;</em> syn. <span class="ar">قِمَارٌ</span>; <span class="auth">(M, Ḳ;)</span> which is a man's destruction of his property. <span class="auth">(M.)</span> It is said in the Ḳur <span class="add">[ii. 216, respecting wine and the game called <span class="ar">المَيْسِر</span>]</span>, <span class="ar long">قُلْ فِهِيمَا إِثْمٌ كَبِيرٌ وَمَنَافِعُ لِلنَّاسِ</span> <span class="add">[<em>Say thou, In them both are great sin and means of profit to men</em>]</span>: and Th says, when they contended in a game of this kind, and won, they gave food and alms, and these were means of profit. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavaAmN">
				<h3 class="entry"><span class="ar">أَثَامٌ</span></h3>
				<div class="sense" id="OavaAmN_A1">
					<p><span class="ar">أَثَامٌ</span>: <a href="#IivomN">see <span class="ar">إِثْمٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">أَثَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavaAmN_A2">
					<p>Also The <em>requital,</em> or <em>recompense,</em> of <span class="ar">إِثّم</span> <span class="add">[i. e. <em>sin,</em> or <em>crime,</em>, &amp;c.]</span>: <span class="auth">(T, Ṣ, M, Mṣb:)</span> so says Zj, <span class="auth">(T, M,)</span> and in like manner say Kh and Sb: <span class="auth">(T:)</span> or <em>punishment</em> <span class="auth">(Yoo, Lth, T, M, Ḳ)</span> <em>thereof:</em> <span class="auth">(Lth, T, M:)</span> and<span class="arrow"><span class="ar">إِثَامٌ↓</span></span> and<span class="arrow"><span class="ar">مَأْثَمٌ↓</span></span> signify the same; <span class="auth">(M, Ḳ;)</span> the latter like <span class="ar">مَقْعَدٌ</span>. <span class="auth">(TA. <span class="add">[In the CK this is written <span class="ar">مَأثِم</span>.]</span>)</span> So in the Ḳur <span class="add">[xxv. 68]</span>, <span class="ar long">يَلْقَ أَثَامَا</span> <span class="add">[<em>He shall find a requital,</em> or <em>recompense,</em> or <em>a punishment, of sin</em>]</span>: <span class="auth">(T, Ṣ, M:)</span> in my opinion, <span class="add">[says ISd,]</span> the correct meaning is, <em>he shall find the punishment of</em> <span class="ar">آثَام</span> <span class="add">[or <em>sins</em>]</span>: but some say, the meaning is that which here follows. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">أَثَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OavaAmN_A3">
					<p><em>A valley in Hell.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IivaAmN">
				<h3 class="entry"><span class="ar">إِثَامٌ</span></h3>
				<div class="sense" id="IivaAmN_A1">
					<p><span class="ar">إِثَامٌ</span>: <a href="#IivomN">see <span class="ar">إِثْمٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">إِثَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IivaAmN_A2">
					<p><a href="#OavaAmN">and <span class="ar">أَثَامٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OavuwmN">
				<h3 class="entry"><span class="ar">أَثُومٌ</span></h3>
				<div class="sense" id="OavuwmN_A1">
					<p><span class="ar">أَثُومٌ</span>: <a href="#AvimN">see <span class="ar">آثِمٌ</span></a>; <a href="#OaviymN">and <span class="ar">أَثِيمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaviymN">
				<h3 class="entry"><span class="ar">أَثِيمٌ</span></h3>
				<div class="sense" id="OaviymN_A1">
					<p><span class="ar">أَثِيمٌ</span>: <a href="#AvimN">see <span class="ar">آثِمٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">أَثِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaviymN_A2">
					<p>Also <em>A great,</em> or <em>habitual, liar;</em> or one <em>who lies much;</em> and so<span class="arrow"><span class="ar">أَثُومٌ↓</span></span>. <span class="auth">(Ḳ.)</span> So in the Ḳur ii. 277: or it there signifies <em>Burdened with</em> <span class="ar">إثْم</span> <span class="add">[or <em>sin,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span> In the Ḳur xliv. 44, it means, accord. to Fr, The <em>unrighteous,</em> or <em>sinning;</em> like<span class="arrow"><span class="ar">آثِمٌ↓</span></span>: <span class="auth">(T:)</span> or the <em>unbeliever:</em> <span class="auth">(TA:)</span> or, accord. to Zj, in this instance, <span class="auth">(M,)</span> by the <span class="ar">اثيم</span> is meant <em>Aboo-Jahl.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">أَثِيمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaviymN_B1">
					<p>Also The <em>commission of</em> <span class="ar">إِثْم</span> <span class="add">[<em>sin,</em> or <em>crime,</em>, &amp;c.,]</span> <em>much,</em> or <em>frequently;</em> and so<span class="arrow"><span class="ar">أَثِيمَةٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaviymapN">
				<h3 class="entry"><span class="ar">أَثِيمَةٌ</span></h3>
				<div class="sense" id="OaviymapN_A1">
					<p><span class="ar">أَثِيمَةٌ</span>: <a href="#OaviymN">see <span class="ar">أَثِيمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OavaAmN.1">
				<h3 class="entry"><span class="ar">أَثَامٌ</span></h3>
				<div class="sense" id="OavaAmN.1_A1">
					<p><span class="ar">أَثَامٌ</span>: <a href="#AvimN">see <span class="ar">آثِمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MvimN">
				<h3 class="entry"><span class="ar">آثِمٌ</span></h3>
				<div class="sense" id="MvimN_A1">
					<p><span class="ar">آثِمٌ</span> <em>Falling into what is termed</em> <span class="ar">إِثمٌ</span> <span class="add">[i. e. <em>a sin,</em> or <em>crime,</em>, &amp;c.]</span>; <span class="auth">(Ṣ, Mṣb,* Ḳ;*)</span> <span class="add">[<em>sinning; committing a sin,</em> or <em>crime;</em>]</span> <em>doing what is unlawful:</em> <span class="auth">(Ḳ:)</span> and in like manner, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> but having an intensive signification, <span class="auth">(Mṣb,)</span> <span class="arrow"><span class="ar">أَثِيمٌ↓</span></span>, and<span class="arrow"><span class="ar">أَثُومٌ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">أَثَّامٌ↓</span></span>: <span class="auth">(M, Mṣb, Ḳ: <span class="add">[in the CK, erroneously, without teshdeed:]</span>)</span> the pl. of the first of these three is <span class="ar">أُثَمَآءُ</span>; that of the second, <span class="ar">أُثُمٌ</span>; and that of the third, <span class="ar">أَثَّامُونَ</span>. <span class="auth">(M.)</span> <a href="#OaviymN">See also <span class="ar">أَثِيمٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">آثِمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MvimN_A2">
					<p><span class="ar">آثِمَةٌ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar">آثِمَاتٌ</span>, <span class="auth">(Ṣ, M, Ḳ, <span class="add">[in the CK, erroneously, <span class="ar">اَثِماتٌ</span>.]</span>)</span> A she-camel, <span class="auth">(Ṣ,)</span> and she-camels, <em>slow,</em> or <em>tardy;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>weary, fatigued,</em> or <em>jaded.</em> <span class="auth">(Ḳ. <span class="add">[In the CK, we find <span class="ar">مُعِيْباتٌ</span> erroneously put for <span class="ar">مُعْيِيَاتٌ</span>.]</span>)</span> Some pronounce it with <span class="ar">ت</span>. <span class="auth">(Ṣgh.)</span> <span class="add">[In like manner,]</span> <span class="arrow"><span class="ar">مُؤَاثِمٌ↓</span></span> signifies That is <em>slack,</em> or <em>slow, in pace,</em> or <em>going;</em> <span class="ar long">اَلَّذِى يَكْذِبُ فِى السَّيْرِ</span>. <span class="auth">(Ṣgh, Ḳ. <span class="add">[In Golius's Lex., as from the Ḳ, <span class="ar long">اَلَّذِى يُكَذِّبُ السَّيْرَ</span>. Both are correct, signifying the same.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOovaAmN">
				<h3 class="entry"><span class="ar">تَأْثَامٌ</span></h3>
				<div class="sense" id="taOovaAmN_A1">
					<p><span class="ar">تَأْثَامٌ</span>: <a href="#Avm_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOoviymN">
				<h3 class="entry"><span class="ar">تَأْثِيمٌ</span></h3>
				<div class="sense" id="taOoviymN_A1">
					<p><span class="ar">تَأْثِيمٌ</span>: <a href="#Avm_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOovamN">
				<h3 class="entry"><span class="ar">مَأْثَمٌ</span></h3>
				<div class="sense" id="maOovamN_A1">
					<p><span class="ar">مَأْثَمٌ</span>: <a href="#IivomN">see <span class="ar">إِثْمٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثم</span> - Entry: <span class="ar">مَأْثَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOovamN_A2">
					<p><a href="#OavaAmN">and see <span class="ar">أَثَامٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOovuwmN">
				<h3 class="entry"><span class="ar">مَأْثُومٌ</span></h3>
				<div class="sense" id="maOovuwmN_A1">
					<p><span class="ar">مَأْثُومٌ</span> <span class="add">[<em>Reckoned to have sinned,</em> or <em>the like;</em>]</span> <em>having a thing reckoned against him as an</em> <span class="ar">إِثْم</span>: <span class="auth">(Ṣ:)</span> or <em>requited for what is termed</em> <span class="ar">إِثْمٌ</span>. <span class="auth">(Fr, T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaAvimN">
				<h3 class="entry"><span class="ar">مُؤَاثِمٌ</span></h3>
				<div class="sense" id="muWaAvimN_A1">
					<p><span class="ar">مُؤَاثِمٌ</span>: <a href="#AvimN">see <span class="ar">آثِمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0021.pdf" target="pdf">
							<span>Lanes Lexicon Page 21</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0022.pdf" target="pdf">
							<span>Lanes Lexicon Page 22</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
