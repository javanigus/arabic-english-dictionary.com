<article class="root" id="Root_Ank">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/146_Anq">انق</a></span>
				<span class="ar">انك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/148_Anm">انم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="MnukN">
				<h3 class="entry"><span class="ar">آنُكٌ</span></h3>
				<div class="sense" id="MnukN_A1">
					<p><span class="ar">آنُكٌ</span> <em>pure</em> <span class="ar">رَصَاص</span> <span class="add">[or <em>lead</em>]</span>: or <em>black</em> <span class="ar">رِصِاص</span>: <span class="auth">(Mṣb:)</span> <em>i. q.</em> <span class="ar">أُسْرُبُّ</span>; <span class="auth">(Ṣ, Ḳ;)</span> i. e. <span class="ar long">رَصَاصٌ قَلْعِىٌّ</span>; so says Ḳṭ; and Az says, I think it is an arabicized word: <span class="auth">(TA:)</span> or <em>white</em> <span class="ar">اسربّ</span>: or <em>black</em> <span class="ar">اسربّ</span>: or <em>pure</em> <span class="ar">اسربّ</span>: <span class="auth">(Ḳ:)</span> or <em>i. q.</em> <span class="ar">قَزْدِيرٌ</span> <span class="add">[which is applied in the present day to <em>tin,</em> and <em>pewter</em>]</span>: <span class="auth">(Kr:)</span> El-Kásim Ibn-Maan says, I heard an Arab of the desert say, <span class="ar long">هٰذَا رَصَاصٌ آنُكٌ</span>, i. e. <span class="add">[<em>this is</em>]</span> <em>pure</em> <span class="add">[<em>lead</em>]</span>: <span class="auth">(TA:)</span> it is of the measure <span class="ar">أَفْعُلٌ</span>, <span class="add">[originally <span class="ar">أَأْنُكٌ</span>,]</span> <span class="auth">(Ṣ, Ḳ,)</span> which is one of the forms of pls., <span class="auth">(Ṣ,)</span> like <span class="ar">أَفْلُسٌ</span>; <span class="auth">(Mṣb;)</span> and there is no other word of this measure, <span class="auth">(Az, Ṣ, Ḳ,)</span> among sing. nouns, <span class="auth">(Az, Ṣ,)</span> except <span class="ar">أَشُدٌّ</span> <span class="add">[originally <span class="ar">أَشْدُدٌ</span>]</span>, <span class="auth">(Ṣ, Ṣgh, Ḳ,)</span> and <span class="ar">آجُرٌ</span> in the dial. of those who pronounce it without teshdeed: <span class="auth">(Ṣgh:)</span> it is disputed, however, whether <span class="ar">أَشُدٌّ</span> be a sing. or a pl.: <span class="auth">(Az, TA:)</span> <span class="add">[and as to <span class="ar">آجُرٌ</span>, see what follows:]</span> or, accord. to some, <span class="auth">(Mṣb,)</span> <span class="ar">آنُكٌ</span> is of the measure <span class="ar">فَاعُلٌ</span>, <span class="auth">(Kr, Mṣb,)</span> and is the only word of that measure in Arabic: <span class="auth">(Kr:)</span> or it is a foreign word; and so are <span class="ar">آجُرٌ</span> and <span class="add">[the proper names]</span> <span class="ar">آمُلُ</span> and <span class="ar">كَابُلُ</span>. <span class="auth">(Mṣb.)</span> It is said, in a trad., that he who listens to a singing female slave, <span class="ar">آنُك</span> shall be poured into his ears <span class="auth">(Ṣ, TA)</span> on the day of resurrection. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0118.pdf" target="pdf">
							<span>Lanes Lexicon Page 118</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
