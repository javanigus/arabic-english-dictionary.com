<article class="root" id="Root_AcA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/044_Ac">اذ</a></span>
				<span class="ar">اذا</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/046_Acr">اذر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IicaA">
				<h3 class="entry"><span class="ar">إِذَا</span></h3>
				<div class="sense" id="IicaA_A1">
					<p><span class="ar">إِذَا</span> denotes a thing's happening suddenly, or unexpectedly; <span class="auth">(Mughnee, Ḳ;)</span> or one's experiencing the occurrence of a thing when he is in a particular state; <span class="auth">(Ṣ;)</span> like <span class="ar">إِذٌ</span>: <span class="auth">(Ṣ voce <span class="ar">إِذٌ</span>:)</span> <span class="pb" id="Page_0040"></span>it pertains only to nominal phrases; does not require tobe followed by a reply, or the complement of a condition; does not occur at the commencement of a sentence; and signifies the present time, <span class="auth">(Mughnee, Ḳ,)</span> not the future; <span class="auth">(Mughnee;)</span> as in <span class="ar long">خَرَجْتُ فَإِذَا الأَسَدُ بالبَابِ</span> <span class="add">[<em>I went forth, and lo,</em> or <em>behold,</em> or <em>there,</em> or <em>then, at that present time,</em> <span class="auth">(accord. to different authorities, as will be seen below,)</span> <em>the lion was at the door</em>]</span>; and <span class="auth">(in the saying in the Ḳur <span class="add">[xx. 21]</span>, TA,)</span> <span class="ar long">فَإِذَا هِىَ حَيَّةٌ تَسْعَى</span> <span class="add">[<em>And lo,</em> or <em>behold,</em>, &amp;c., <em>it was a serpent running</em>]</span>; <span class="auth">(Mughnee, Ḳ;)</span> and in the saying, <span class="ar long">خَرَجْتُ فَإِذَا زَيْدٌ قَائِمٌ</span>, which means <em>I went forth, and Zeyd presented himself to me suddenly,</em> or <em>unexpectedly, at the time, by standing.</em> <span class="auth">(Ṣ, TA.)</span> Accord. to Akh, it is a particle, <span class="auth">(Mughnee, Ḳ,)</span> and his opinion is rendered preferable by their saying, <span class="ar long">خَرَجْتُ فَإِذَا إِنَّ زِيْداً بِالبَابِ</span> <span class="add">[<em>I went forth, and lo,</em> or <em>behold, verily Zeyd was at the door</em>]</span>; for <span class="add">[<span class="ar">اذا</span> cannot here be a noun governed in the accus. case, as]</span> what follows <span class="ar">إِنَّ</span>, which is with kesr, does not govern what precedes it: <span class="auth">(Mughnee:)</span> accord. to Mbr, it is an adverbial noun of place: accord. to Zj, an adverbial noun of time. <span class="auth">(Mughnee, Ḳ.)</span> Ibn-Málik adopts the first of these opinions; Ibn-ʼOsfoor, the second; <span class="auth">(Mughnee;)</span> and so El-Fenjedeehee; <span class="auth">(TA;)</span> and Z, the third; and he asserts that its governing word is a verb understood, derived from <span class="ar">المُفَاجَأَةُ</span>; <span class="add">[agreeably with the explanation cited above from the Ṣ;]</span> but others hold that the word which governs it in the accus. case is the enunciative, which is either expressed, as in <span class="ar long">خَرَجْتُ فَإِذَا زَيْدٌ جَالِسٌ</span> <span class="add">[<em>I went forth, and there, in that place,</em> or <em>then, at that time, Zeyd was sitting</em>]</span>, or meant to be understood, as in <span class="ar long">فَإِذَا الأَسَدُ</span>, i. e. <span class="ar">حَاضِرٌ</span> <span class="add">[<em>And there,</em> or <em>then, the lion was present</em>]</span>; or if it be supposed to be <span class="add">[itself]</span> the enunciative, its governing word is <span class="ar">مُسْتَقِرُّ</span> or <span class="ar">اِسْتَقَرَّ</span> <span class="add">[understood]</span>: and in the last of the phrases here mentioned, it may be an enunciative accord. to the opinion of Mbr, the meaning being <span class="ar long">فَبِٱلْحَاضِرَةِ الأَسَدُ</span> <span class="add">[<em>And among the things present was the lion</em>]</span>; but not accord. to the opinion of Zj, because a noun signifying time cannot be the enunciative of one signifying a corporeal thing; nor accord to the opinion of Akh, because a particle cannot be used to denote the enunciative of such a thing; or, as signifying time, it may be the enunciative of such a thing if we suppose a prefixed noun to be suppressed, the meaning of <span class="ar long">فَإِذَا الأَسَدُ</span> being <span class="ar long">فَإِذاَ حُضُورُ الأَسَدِ</span> <span class="add">[<em>And then was the presence of the lion</em>]</span>. <span class="auth">(Mughnee.)</span> You may say either <span class="ar long">خَرَجْتُ فَإِذَا زَيْدٌ جَالِسٌ</span> or <span class="ar">جَالِساً</span> <span class="add">[<em>I went forth, and lo,</em> or <em>behold,</em>, &amp;c., <em>Zeyd was sitting</em> or <em>Zeyd</em> was there <em>sitting</em>]</span>, with the nom. as an enunciative and with the accus. as a denotative of state. <span class="auth">(Mughnee.)</span> The Arabs said, <span class="ar long">قَدْ كُنْتُ أَظُنُّ أَنَّ العَقْرَبَ أَشَدُّ لَسْعَةً مِنَ الزُّنْبُورِ فَإِذاَ هُوَ هِى</span> <span class="add">[<em>I used to think that the scorpion was more vehement in stinging than the hornet, and lo, he is</em> <span class="auth">(as vehement as)</span> <em>she</em>]</span>, and also, <span class="ar long">فَإِذاَ هُوَ إِيَّاهَا</span>, which Sb disallowed, in contending with Ks, who allowed it, and appealed for confirmation thereof to certain Arabs, whose judgment was pronounced in his favour; but it is said that they were bribed to give this judgment, or that they knew the place which Ks held in the estimation of Er-Rasheed; and if the latter expression be of established authority, it is irregular and unchaste. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IicaA_A2">
					<p>It also denotes the complement of a condition, like <span class="ar">فَ</span>, <span class="auth">(Ṣ, Mṣb,)</span> with which it is in this case syn., <span class="auth">(Mṣb,)</span> as in the words of the Ḳur <span class="add">[xxx. 35]</span>, <span class="ar long">وَإِنْ تُصِبْهُمْ سَيِّئَةٌ بِمَا قَدَّمَتْ أَيْدِيهِمْ إِذَا هُمُ يَقْنَطُون</span> <span class="add">[<em>And if an evil befall them for that which their hands have sent before,</em> <span class="auth">(i. e. for sins which they have committed,)</span> <em>then they despair</em>]</span>. <span class="auth">(Ṣ, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IicaA_A3">
					<p>It is also an adverbial noun denoting future time, <span class="auth">(Ṣ, Mṣb, Mughnee, Ḳ,*)</span> and implying the meaning of a condition, <span class="auth">(Mṣb, Mughnee,)</span> and this is generally the case when it is not used in the manner first explained above. <span class="auth">(Mughnee.)</span> In this case it is not used otherwise than as prefixed to a proposition, <span class="auth">(Ṣ, Mughnee,)</span> which is always verbal, as in the words of the Ḳur <span class="add">[xxx. 24]</span>, <span class="ar long">ثُمَّ إِذَا دَعَاكُمَ دَعْوَةً مِنَ الأَرْضِ إذَا أَنْتُمْ تَخْرُجُونَ</span> <span class="add">[<em>Then, when He shall call you,</em> or <em>when He calleth you,</em> <span class="auth">(for, as in Arabic, so in English, a verb which is properly present is often tropically future,)</span> <em>with a single call from out the earth, lo,</em> or <em>behold,</em> or <em>then, ye shall come forth</em>]</span>, in which occur both the usages of <span class="ar">اذا</span> here mentioned; <span class="auth">(Mughnee;)</span> and in the phrase, <span class="ar long">إِذَا جِئْتَ أَكْرَمْتُكَ</span> <span class="add">[<em>When thou shalt come, I will treat thee with honour</em>]</span>; <span class="auth">(Mṣb;)</span> and in the phrase, <span class="ar long">أَجِيْؤُكَ إِذَا ٱحْمَرَّالبُسْرُ</span> <span class="add">[<em>I will come to thee when the fullgrown unripe dates shall become red</em>]</span>, and <span class="ar long">إِذَا قَدِمَ فُلَانٌ</span> <span class="add">[<em>when such a one shall arrive</em>]</span>, which shows it to be a noun because this is equivalent to <span class="ar long">يَوْمَ يَقْدَمُ فُلَانٌ</span> <span class="add">[on the day when such a one shall arrive]</span>: <span class="auth">(Ṣ:)</span> or in the phrase <span class="ar long">قُمْ إِذَا ٱحْمَرَّ البُسْرُ</span> <span class="add">[and in many other cases]</span> it denotes time divested of any accessory idea, the meaning being <span class="add">[<em>Arise thou</em>]</span> <em>at the time of the full-grown unripe dates' becoming red:</em> and so in the saying of EshSháfi'ee, If a man were to say, <span class="ar long">أَنْتِ طَالِقٌ إِذَا لَمْ أُطَلِّقْكِ</span>, or <span class="ar long">مَتَى لم اطلّقك</span>, <span class="add">[<em>Thou art divorced when I do not divorce thee,</em>]</span> and then be silent for a time sufficient for the divorce to be pronounced therein, she would be divorced; but should he make it dependent upon a thing in the future, the divorce would be delayed to that time, as if he said, <span class="ar long">اذا احمرّ البسر</span> <span class="add">[using it in the sense first assigned to this phrase above]</span>. <span class="auth">(Mṣb.)</span> The verb after it is in most cases a pret.: in other cases, an aor.: both occur in the saying of Aboo-Dhu-eyb,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَالنَّفْسُ رَاغِبَةٌ إِذَا رَغَّبْتَهَا</span> *</div> 
						<div class="star">* <span class="ar long">وَإِذَا تُرَدُّ إِلَى قَلِيلٍ تَقْنَعُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And the soul is desirous when thou makest it desirous; and when thou reducest it,</em> or <em>restrictest it, to little, it is content</em>]</span>. <span class="auth">(Mughnee.)</span> When it is immediately followed by a noun, as in <span class="add">[the phrase in the Ḳur lxxxiv. 1,]</span> <span class="ar long">إذَا ٱلسَّمَآءُ ٱنْشَقَّتْ</span>, the noun is an agent with a verb suppressed, explained by what follows it; contr. to the opinion of Akh; <span class="auth">(Mughnee;)</span> the complete phrase being <span class="ar long">إِذَا ٱنْشَقَّتِ السَّمَآءُ ٱنْشَقَّتْ</span> <span class="add">[<em>When the heaven shall be cleft,</em> <span class="auth">(when)</span> <em>it shall be cleft</em>]</span>; and in like manner, <span class="ar">إِنْ</span>, as in the saying, in the Ḳur <span class="add">[ix. 6]</span>, <span class="ar long">وَإِنْ أَحَدٌ مِنَ المُشْرِكِينَ ٱسْتَجَارَكَ</span>. <span class="auth">(I'Akp. 123.)</span> And in the saying of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَا بَاهِلِىٌّ تَحْتَهُ حَنْظَلِيَّةٌ</span> *</div> 
						<div class="star">* <span class="ar long">لَهُ وَلَدٌ مِنْهَا فَذَاكَ المُدَرَّعُ</span> *</div> 
					</blockquote>
					<p><span class="ar">كَانَ</span> is meant to be understood after <span class="ar">اذا</span> <span class="add">[so that the meaning is, <em>When a Báhilee</em> <span class="auth">(a man of the tribe of Báhileh)</span> <em>has,</em> or <em>shall have, as his wife a Handhaleeyeh</em> <span class="auth">(a woman of the tribe of Handhaleh, who were renowned for generosity)</span>, <em>he having offspring from her, that</em> <span class="auth">(offspring)</span> <em>is,</em> or <em>will be, the mail-clad</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IicaA_A4">
					<p>Sometimes it denotes past time, <span class="auth">(Mughnee, Ḳ,)</span> like as <span class="ar">إِذْ</span> sometimes denotes future time, <span class="auth">(Mughnee,)</span> as in <span class="add">[the saying in the Ḳur lxii. 11,]</span> <span class="ar long">وَإِذَا رَأَوْا تِجَارَةً أَوْ لَهْواً ٱنْفَضُّوا إِلَيْهَا</span> <span class="add">[<em>And when they saw merchandise or sport, they dispersed themselves to it</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span> <span class="add">[Thus]</span> it occurs in the place of <span class="ar">إِذْ</span>, like as <span class="ar">إِذْ</span> occurs in the place of <span class="ar">إِذَا</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IicaA_A5">
					<p>And sometimes it denotes the present time; and this is after an oath, as in <span class="add">[the phrase in the Ḳur xcii. 1,]</span> <span class="ar long">وَاللَّيْلِ إِذَا يَغْشَى</span> <span class="add">[<em>By the night when it covereth</em> with its darkness]</span>. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IicaA_A6">
					<p>It also occurs in the sense of the conditional <span class="ar">إِنْ</span>, as in the saying, <span class="ar long">أُكْرِمُكَ إِذَا أَكْرَمْتَنِى</span>, meaning <span class="ar long">إِنْ أَكْرَمْتَنِى</span> <span class="add">[<em>I will treat thee with honour if thou treat me with honour</em>]</span>: <span class="auth">(T:)</span> <span class="add">[for]</span> what is possible is made dependent upon it as well as what is known to be certain, as in the phrases, <span class="ar long">إِذَا جَآءَ زَيْدٌ</span> <span class="add">[<em>If Zeyd come</em>]</span> and <span class="ar long">إِذَا جَآءَ رَأْسُ الشَّهْرِ</span> <span class="add">[<em>When the beginning of the month shall come</em>]</span>; or, accord. to Th, there is a difference between <span class="ar">إِذَا</span> and <span class="ar">إِنْ</span>; <span class="auth">(Mṣb;)</span> the latter being held by him to denote what is possible, and the former to denote what is ascertained; so that one says, <span class="ar long">إِنْ جَآءَ زَيْدٌ</span> and <span class="ar long">إذَا جَآءَ رَأْسُ الشَّهرِ</span>. <span class="auth">(Mṣb in art. <span class="ar">ان</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="IicaA_A7">
					<p>When a verb in the first person sing. of the pret. is explained by another verb after it immediately preceded by <span class="ar">إِذَا</span>, <span class="add">[<span class="ar">تَقُولُ</span> is understood before the former verb, and therefore]</span> the latter verb must be in the second pers. sing., as in <span class="ar long">لُجْتُهُ إِذَا أَدَرْتَهُ فِى فيِكَ</span> <span class="add">[meaning Thou sayest <span class="auth">(of a thing)</span> <span class="ar">لُجْتُهُ</span> <em>when,</em> or <em>if, thou hast turned it about in thy mouth</em>]</span>. <span class="auth">(MF in art. <span class="ar">لوج</span>. <a href="#Oaeo">See also <span class="ar">أَىْ</span></a>; last sentence but one.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="IicaA_A8">
					<p>It is sometimes redundant, like as <span class="ar">إِذْ</span> is sometimes <span class="add">[accord. to some]</span>, as in the saying of ʼAbd-Menáf Ibn-Riba El-Hudhalee,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">حَتَّى إِذَا أَسْلَكُوهُم فِى قُتَائِدَةٍ</span> *</div> 
						<div class="star">* <span class="ar long">شَلَّا كَمَا تَطْرُدُ الجَمَّالَةُ الشُّرُدَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Until they made them to pass along Kutáïdeh,</em> <span class="auth">(here meaning a certain mountain-road so named, Ṣ in art. <span class="ar">قتد</span>,)</span> <em>urging on, like as the owners,</em> or <em>attendants, of camels drive those that take fright and run away</em>]</span>; for it is the end of the poem: or he may have abstained from mentioning the enunciative because of its being known to the hearer. <span class="auth">(Ṣ.)</span> When <span class="ar">إِذَا</span> is preceded by <span class="ar">حَتَّى</span>, <span class="add">[as in this instance,]</span> it is generally held that <span class="ar">اذا</span> is not governed by <span class="ar">حتّى</span> in the gen. case, but is still an adverbial noun, <span class="ar">حتّى</span> being an inceptive particle without government. <span class="auth">(Mughnee.)</span></p>
				</div>
				<span class="pb" id="Page_0041"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="IicaA_A9">
					<p>As to what it is that governs <span class="ar">إِذَا</span> in the accus. case, there are two opinions; that it is its conditional proposition; or a verb, or the like, in the complement thereof: <span class="auth">(Mughnee, Ḳ:)</span> the former is the opinion of the critical judges; so that it is in the predicament of <span class="ar">مَتَى</span> and <span class="ar">حَيْثُمَا</span> and <span class="ar">أَيَّانَ</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="IicaA_A10">
					<p>Sometimes it is used so as not to denote a condition, as in the words of the Ḳur <span class="add">[xlii. 35]</span>, <span class="ar long">وَإِذَا مَا غَضِبُوا هُم يَغفِرُونَ</span> <span class="add">[<em>And when,</em> or <em>whenever, they are angry, they forgive</em>]</span>, in which it is an adverbial noun relating to the enunciative of the inchoative after it; for if it denoted a condition, and the nominal proposition were a complement, it would be connected by <span class="ar">فَ</span>: and the same is the case when it is used after an oath, as in an ex. given above. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="IicaA_A11">
					<p><a href="#IicFA">See also what follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IicFA">
				<h3 class="entry"><span class="ar">إِذًا</span></h3>
				<div class="sense" id="IicFA_A1">
					<p><span class="ar">إِذًا</span>, <span class="auth">(Mṣb, TA, the latter as on the authority of Lth,)</span> with tenween, <span class="auth">(TA,)</span> or <span class="ar">إِذَن</span>, <span class="auth">(T, Ṣ, M, Mṣb, Mughnee, Ḳ, the first as on the authority of Lth,)</span> written in the former manner, <span class="auth">(TA,)</span> or in the latter, <span class="auth">(T,)</span> when connected with a following proposition, <span class="auth">(T, TA,)</span> and in a case of pause written <span class="arrow"><span class="ar">إِذًا↓</span></span>, <span class="auth">(T, Ṣ, M, Mṣb, Mughnee, Ḳ, TA,)</span> and therefore the Basrees hold that in other cases it should be written <span class="ar">إِذًا</span>, <span class="auth">(Mṣb,)</span> though El-Má- zinee and Mbr hold that it should be in this case also with <span class="ar">ن</span>, while Fr holds that it should be written with <span class="ar">ا</span>; when it governs, and otherwise with <span class="ar">ن</span>, in order to distinguish between it and <span class="add">[the adverbial noun]</span> <span class="ar">إِذَا</span>: <span class="auth">(Mughnee:)</span> a particle, <span class="auth">(Ṣ, Mṣb, Mughnee, TA,)</span> accord. to the general opinion; and accord. to this opinion, it is a simple word, not compounded of <span class="ar">إِذْ</span> and <span class="ar">أَنْ</span>; and as being simple, it is that which renders an aor. mansoob, not <span class="ar">أَنْ</span> suppressed and meant to be understood after it: some say that it is a noun: <span class="auth">(Mughnee:)</span> <span class="add">[but a knowledge of its meaning is necessary to the understanding of the reason given for asserting it to be a noun.]</span> It denotes a response, or reply, corroborating a condition; <span class="auth">(Lth, T, TA;)</span> or compensation, or the complement of a condition; <span class="auth">(Mṣb;)</span> or a response, or reply, <span class="auth">(Sb, Ṣ, Mughnee, Ḳ,)</span> in every instance; <span class="auth">(TA;)</span> and compensation, or the complement of a condition, <span class="auth">(Sb, Ṣ, M, Mughnee, Ḳ,)</span> though not always: <span class="auth">(Mughnee, TA:)</span> and its virtual meaning is <span class="add">[<em>Then;</em> i. e., <em>in that case;</em> or]</span> <em>if the case,</em> or <em>affair, be as thou hast mentioned,</em> <span class="auth">(M, Ḳ, TA,)</span> or <em>as has happened:</em> <span class="auth">(M, TA:)</span> <span class="add">[and hence,]</span> accord. to those who say that it is a noun, the original form of the phrase <span class="ar long">إِذَنْ أُكْرِمَكَ</span> <span class="add">[<em>Then,</em> or <em>in that case,</em> or <em>if the case be so, I will treat thee with honour,</em> said in reply to one who says “I will come to thee,”]</span> is <span class="ar long">إِذَا جِئْتَنِى أُكرِمُكَ</span> <span class="add">[<em>When thou shalt come to me, I will treat thee with honour</em>]</span>; then the proposition <span class="add">[<span class="ar">جئتنى</span>]</span> is thrown out, and tenween <span class="add">[or <span class="ar">ن</span>]</span> is substituted for it, <span class="auth">(Mughnee,)</span> for which reason, and to distinguish between it and <span class="add">[the adverbial]</span> <span class="ar">ن</span>, the Koofees hold that it should be written with <span class="ar">إِذَا</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">أَنْ</span> <span class="add">[preceded by <span class="ar long">يَجِبُ عَلَىَّ</span> or the like]</span> is suppressed and meant to be understood <span class="add">[as that which renders the aor. mansoob; so that when one says <span class="ar long">إِذَنْ أُكْرِمَكَ</span>, it is as though he said <span class="ar long">إِذَا جِئْتَنِى</span> <em>When thou shalt come to me, it will be incumbent,</em> or <em>obligatory, on me to treat thee with honour</em>]</span>. <span class="auth">(Mughnee.)</span> It renders an aor. following it mansoob on certain conditions: <span class="auth">(Mughnee, TA:)</span> to have this effect, the aor. must have a future signification, <span class="auth">(T, Ṣ, Mughnee, TA,)</span> not present: <span class="auth">(TA:)</span> <span class="ar long">يَجِبُ عَلَىَّ أَنْ أُكُرِمَكَ</span> must commence the phrase in which the aor. occurs; <span class="auth">(Mughnee, TA;)</span> <span class="add">[or, in other words,]</span> the aor. must not be syntactically dependent upon what precedes <span class="ar">اذا</span>: <span class="auth">(TA:)</span> and there must be nothing intervening between <span class="ar">اذا</span> and the aor., <span class="auth">(T, Mughnee, TA,)</span> unless it is a particle, <span class="auth">(T,)</span> or an oath, <span class="auth">(T, Mughnee,)</span> or the negative <span class="ar">لَا</span>: <span class="auth">(Mughnee:)</span> therefore, to a person who says, “To-night I will visit thee,” <span class="auth">(Ṣ,)</span> or who says, “I will come to thee,” <span class="auth">(Mughnee,)</span> you say, <span class="ar long">إِذَنْ أُكْرِمَكَ</span> <span class="add">[<em>Then,</em> or <em>in that case, &amp;c., I will treat thee with honour</em>]</span>; <span class="auth">(T, Ṣ, Mughnee;)</span> and to one who says, “I will treat thee with honour,” you say, <span class="ar long">إِذًا أَجِيْئَكَ</span> <span class="add">[<em>Then,</em> or <em>if the case be so, I will come to thee</em>]</span>. <span class="auth">(TA.)</span> When the verb after <span class="ar">اذن</span> has the present signification, it does not govern: <span class="auth">(Ṣ, Mughnee, TA:)</span> therefore, to a person who says, “I love thee,” you say, <span class="ar long">إِذَنْ أَظُنُّكَ</span> <span class="add">[<em>Then,</em> or <em>if the case be so, I think thee veracious</em>]</span>; for this is a mere reply: <span class="auth">(Mughnee:)</span> and to one talking to thee, <span class="ar long">إِذًا أَظُنُّكَ كَاذبًا</span> <span class="add">[<em>Then I think thee to be lying</em>]</span>. <span class="auth">(TA.)</span> When it is put in a middle place, <span class="auth">(Ṣ,)</span> not commencing the phrase, <span class="auth">(Mughnee,)</span> the verb after it not being syntactically dependent upon what is before it, <span class="auth">(Ṣ, TA,)</span> it does not govern: <span class="auth">(Ṣ, Mughnee, TA:)</span> therefore, to one who says, “I will come to thee,” <span class="auth">(Mughnee, TA,)</span> you say, <span class="ar long">أَنَا إِذَنْ أُكْرِمُكَ</span> <span class="add">[<em>I, in that case, will treat thee with honour</em>]</span>: <span class="auth">(Ṣ, Mughnee, TA:)</span> for <span class="ar">اذن</span> among the words which govern verbs is likened to <span class="ar">الظَّنُّ</span> among those which govern nouns: <span class="auth">(Ṣ:)</span> and when it is put at the end, it does not govern; as when you say, <span class="ar">أُكْرِمُكَ</span> <span class="add">[<em>I will treat thee with honour in that case</em>]</span>. <span class="auth">(Ṣ.)</span> The saying <span class="add">[of the poet, or rájiz]</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَا تَتْرُكَنِّى فِيهِمُ شَطِيرَا</span> *</div> 
						<div class="star">* <span class="ar long">إِنِّى إِذًا أَهْلِكَ أَوْ أَطِيرَا</span> *</div> 
					</blockquote>
					<p>is explained by regarding it as an instance of the suppression of the enunciative of <span class="ar">إِنّ</span>, so that the meaning is, <span class="ar long">إِنِّى لاَ أَقْدِرُ عَلَى ذٰلِكَ</span>, and then a new phrase commences <span class="add">[wherefore the verse means <em>Do not thou leave me among them remote,</em> or <em>a stranger: verily</em> I cannot endure that: <em>in that case I should perish, or I should flee</em>]</span>. <span class="auth">(Mughnee.)</span> When it is immediately preceded by a conjunction such as <span class="ar">وَ</span> or <span class="ar">فَ</span>, the aor. may be either marfooa or mansoob. <span class="auth">(Ṣ, Mughnee.)</span> When a noun is introduced between it and the aor., the latter is marfooa, <span class="auth">(T, Mughnee,)</span> as in the saying, <span class="ar long">إِذَنْ أَخُوكَ يُكْرِمُكَ</span> <span class="add">[<em>Then,</em> or <em>in that case, thy brother will treat thee with honour</em>]</span>, <span class="auth">(T,)</span> or <span class="ar long">إِذًا يَا عَبْدَ ٱللّٰهِ أُكُرِمُكَ</span> <span class="add">[<em>Then,</em> or <em>in that case, O ’Abd-Allah, I will treat thee with honour</em>]</span>; but Ibn-’Osfoor allows the intervention of an adverbial noun <span class="add">[without annulling the government]</span>; and Ibn-Bábshádh, that of the vocative, and of a prayer; and Ks and Hishám, that of a word governed by the verb; but Ks in this case prefers nasb; and Hishám, refa. <span class="auth">(Mughnee.)</span> When you put an oath in the place of the noun, you make the aor. mansoob, as in the saying, <span class="ar long">إِذًا وَٱللّٰهِ تَنَامَ</span> <span class="add">[<em>Then,</em> or <em>if the case be so, by God, thou wilt sleep</em>]</span>: but if you prefix <span class="ar">ل</span> to the verb with the oath, you make the aor. marfooa, saying, <span class="ar long">إذَنْ وَٱللّٰهِ لَتَنْدَهُم</span> <span class="add">[<em>Then,</em> or <em>if the case be so, by God, assuredly thou wilt regret,</em> or <em>repent</em>]</span>. <span class="auth">(T.)</span> When you introduce a particle between it and the aor., you make the latter either marfooa or mansoob, saying, <span class="ar long">إِذَنْ لَا أُكْرِمُكَ</span> and <span class="ar long">لَا أُكُرِمَكَ</span> <span class="add">[<em>Then, or in that case, I will not treat thee with honour</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذًا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IicFA_A2">
					<p>Sometimes the <span class="ar">ا</span> is rejected, and they say, <span class="ar long">ذَنْ لَا أَفُعَلُ</span> <span class="add">[<em>Then,</em> <span class="auth">(a word exactly agreeing with <span class="ar">ذَنْ</span> in sound as well as in meaning,)</span> or <em>in that case, I will not do</em> such a thing]</span>. <span class="auth">(M, Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذًا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IicFA_A3">
					<p>IJ relates, on the authority of Khálid, that <span class="ar">إِذًا</span> is used in the dial. of Hudheyl for <span class="ar">إِذًا</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذا</span> - Entry: <span class="ar">إِذًا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IicFA_A4">
					<p><span class="add">[<span class="ar">إِذَنْ</span> or <span class="ar">إِذًا</span> is mentioned and explained in the Ṣ and Ḳ and TA in art. <span class="ar">اذن</span>, and in the TA in <span class="ar long">باب الالف الليّنة</span> also.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0039.pdf" target="pdf">
							<span>Lanes Lexicon Page 39</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0040.pdf" target="pdf">
							<span>Lanes Lexicon Page 40</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0041.pdf" target="pdf">
							<span>Lanes Lexicon Page 41</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
