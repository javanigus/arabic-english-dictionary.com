<article class="root" id="Root_Ajn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/029_Ajm">اجم</a></span>
				<span class="ar">اجن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/031_AHd">احد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ajn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أجن</span></h3>
				<div class="sense" id="Ajn_1_A1">
					<p><span class="ar">أَجَنَ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِنُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُنُ</span>}</span></add>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and <span class="ar">أَجِنَ</span>, <span class="auth">(Ṣ, Mgh, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْجَنُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb,)</span> mentioned by Yz; <span class="auth">(Ṣ;)</span> inf. n. of the former <span class="ar">أُجُونٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ *)</span> and <span class="ar">أَجْنٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;*)</span> and of the latter <span class="ar">أَجَنٌ</span>; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> <em>It</em> <span class="auth">(water)</span> <em>became altered for the worse</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> <em>in taste and colour,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <em>from some such cause as long standing,</em> <span class="auth">(TA,)</span> <em>but was drinkable:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>became altered for the worse in its odour by oldness:</em> or <em>became covered with</em> <span class="add">[<em>the green substance called</em>]</span> <span class="ar">طُحْلُب</span> <em>and with leaves:</em> <span class="auth">(Mgh:)</span> <span class="ar">أَجُنَ</span>, also, said of water, signifies <em>it became altered for the worse:</em> <span class="auth">(Th:)</span> and in the Iktitáf occurs <span class="ar">أَجَنَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْجَنُ</span>}</span></add> which is unknown, but may be a mixture of two dial. vars. <span class="add">[namely of <span class="ar">أَجَنَ</span> having for its aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِنُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْجُنُ</span>}</span></add> and <span class="ar">يَأْجَنُ</span> having for its pret. <span class="ar">أَجِنَ</span>]</span>. <span class="auth">(MF)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجن</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ajn_1_B1">
					<p><span class="ar">أَجَنَ</span> <em>He</em> <span class="auth">(a <span class="ar">قَصَّارَ</span>, or whitener of cloth)</span> <em>beat</em> a piece of cloth or a garment <span class="add">[in washing it]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajonN">
				<h3 class="entry"><span class="ar">أَجْنٌ</span></h3>
				<div class="sense" id="OajonN_A1">
					<p><span class="ar">أَجْنٌ</span>: <a href="#AjinN">see <span class="ar">آجِنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajinN">
				<h3 class="entry"><span class="ar">أَجِنٌ</span></h3>
				<div class="sense" id="OajinN_A1">
					<p><span class="ar">أَجِنٌ</span>: <a href="#AjinN">see <span class="ar">آجِنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OujonapN">
				<h3 class="entry"><span class="ar">أُجْنَةٌ</span></h3>
				<div class="sense" id="OujonapN_A1">
					<p><span class="ar">أُجْنَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أَجْنَةٌ</span> and <span class="ar">إِجْنَةٌ</span> <span class="auth">(Ḳ)</span> <em>i. q.</em> <span class="ar">وَجْنَةٌ</span> <span class="add">[The <em>ball,</em> or <em>elevated part, of the cheek</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajiynN">
				<h3 class="entry"><span class="ar">أَجِينٌ</span></h3>
				<div class="sense" id="OajiynN_A1">
					<p><span class="ar">أَجِينٌ</span>: <a href="#AjinN">see <span class="ar">آجِنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IijBaAnapN">
				<h3 class="entry"><span class="ar">إِجَّانَةٌ</span></h3>
				<div class="sense" id="IijBaAnapN_A1">
					<p><span class="ar">إِجَّانَةٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">إِنْجِانَةُ↓</span></span>, <span class="auth">(Lḥ, Ḳ,)</span> the latter of the dial. of Teiyi, <span class="auth">(Lḥ, TA,)</span> or this is a vulgar form, <span class="auth">(Mgh,)</span> not allowable, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">إِنْجَانَةٌ↓</span></span>, <span class="auth">(Ḳ,)</span> with <span class="ar">ى</span>, <span class="auth">(TA,)</span> <em>A thing well known;</em> <span class="auth">(Ḳ;)</span> <em>a vessel in which clothes are washed;</em> <span class="auth">(Mṣb;)</span> <em>a</em> <span class="add">[<em>vessel also called</em>]</span> <span class="ar">مِرْكَن</span>, <em>resembling a</em> <span class="ar">لَقَن</span> <span class="add">[which is a <em>kind of basin</em>]</span>, <em>in which clothes are washed:</em> <span class="auth">(Mgh:)</span> or <em>what is called in Persian</em> <span class="fa">پنگان</span> <span class="add">[i. e. <span class="fa">پِنْگانْ</span> <em>a small cup</em>]</span>: <span class="auth">(PṢ:)</span> <span class="add">[it probably received this last meaning, and some others, in post-classical times: Golius explains it as meaning “<em>lagena, phiala, crater:</em>” adding, “hinc vulgo Fingiána <span class="auth">(i. e. <span class="ar">فِنْجَانَة</span>)</span> <em>calix</em> vocatur: item <em>Urceus: hydria:</em>: <span class="auth">(referring to John ii. 6:)</span> <em>Vas dimidiœ seriœ simile, in quo aqua et similia ponuntur:</em>” on the authority of Ibn-Maạroof: and, on the same authority, “<em>Labrum</em> seu <em>vas lapideum instar pelvis, in quo lavantur vestes:</em>”]</span> pl. <span class="ar">أَجَاجِينُ</span>: <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> meaning <span class="add">[also]</span> <em>what resemble troughs, surrounding trees.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MjinN">
				<h3 class="entry"><span class="ar">آجِنٌ</span></h3>
				<div class="sense" id="MjinN_A1">
					<p><span class="ar">آجِنٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَجِنٌ↓</span></span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَجْنٌ↓</span></span> <span class="auth">(ISd, TA)</span> and<span class="arrow"><span class="ar">أَجِينٌ↓</span></span> <span class="auth">(TA)</span> Water <em>altered for the worse</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ)</span> <em>in taste and colour,</em> <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <em>from some such cause as long standing,</em> <span class="auth">(TA,)</span> <em>but still drinkable:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>altered for the worse in its odour by oldness:</em> or <em>covered with</em> <span class="add">[<em>the green substance called</em>]</span> <span class="ar">طُحْلُب</span> <em>and with leaves:</em> <span class="auth">(Mgh:)</span> pl. <span class="ar">أُجُونٌ</span>; thought by ISd to be <a href="#OajonN">pl. of <span class="ar">أَجْنٌ</span></a> and <span class="ar">آجِنٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IinojaAnapN">
				<h3 class="entry"><span class="ar">إِنْجَانَةٌ</span></h3>
				<div class="sense" id="IinojaAnapN_A1">
					<p><span class="ar">إِنْجَانَةٌ</span>: <a href="#IijBaAnapN">see <span class="ar">إِجَّانَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyjaAnapN">
				<h3 class="entry"><span class="ar">إِيجَانَةٌ</span></h3>
				<div class="sense" id="IiyjaAnapN_A1">
					<p><span class="ar">إِيجَانَةٌ</span>: <a href="#IijBaAnapN">see <span class="ar">إِجَّانَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYojanapN">
				<h3 class="entry"><span class="ar">مِئْجَنَةٌ</span></h3>
				<div class="sense" id="miYojanapN_A1">
					<p><span class="ar">مِئْجَنَةٌ</span> <span class="add">[in Golius's Lex. <span class="ar">مِئْجَنٌ</span>]</span> The <em>instrument for beating used by the</em> <span class="ar">قَصَّار</span> <span class="add">[or <em>whitener of cloth, in washing</em>]</span>: but better without <span class="ar">ء</span>, <span class="add">[written <span class="ar">مِيجَنةٌ</span>,]</span> because the pl. is <span class="ar">مَوَاجِنُ</span>; or, accord. to IB, the pl. is <span class="ar">مَآجِنُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0026.pdf" target="pdf">
							<span>Lanes Lexicon Page 26</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
