<article class="root" id="Root_Abn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/008_Abl">ابل</a></span>
				<span class="ar">ابن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/010_Abh">ابه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبن</span></h3>
				<div class="sense" id="Abn_1_A1">
					<p><span class="ar">أَبَنَهُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُنُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِنُ</span>}</span></add>, inf. n. <span class="ar">أَبْنٌ</span>, <em>He made him an object of imputation,</em> or <em>suspected him:</em> and <em>he found fault with him,</em> or <em>blamed him:</em> <span class="auth">(M:)</span> or <em>he cast a foul,</em> or <em>an evil, imputation upon him.</em> <span class="auth">(IAạr, T.)</span> You say, <span class="ar long">أَبَنَهُ بِشَىْءٍ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">بِشَّرٍ</span> <span class="auth">(as in one copy of the Ṣ,)</span> or <span class="ar">بِخَيْرٍوَشَّرٍ</span>, <span class="auth">(Lḥ, M,)</span> aor. as above, <span class="auth">(Lḥ, Ṣ, M, Ḳ,)</span> and so the inf. n., <span class="auth">(Lḥ, M,)</span> <em>He made him an object of imputation,</em> or <em>suspected him,</em> <span class="auth">(Lḥ, Ṣ, M, Ḳ,)</span> <em>of a thing,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>of evil,</em> <span class="auth">(Ṣ, accord. to one copy,)</span> or <em>of good, and evil:</em> <span class="auth">(Lḥ, M:)</span> and<span class="arrow"><span class="ar">أبّنهُ↓</span></span> signifies the same. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">فُلَانٌ يُؤَبَّنُ↓ بِخَيْرٍ</span></span>, or <span class="ar">بِشَّرٍ</span>, <em>Such a one is made an object of imputation,</em> or <em>suspected, of good,</em> or <em>of evil:</em> <span class="auth">(AA,* Lḥ, T <span class="add">[as in the TT; but perhaps <span class="ar">يُؤَبَّنُ</span> is a mistranscription for <span class="ar">يُؤْبَنُ</span>; for it is immediately added, <span class="ar long">فَهُوَ مَأْبُونٌ</span>:]</span>)</span> when, however, you say <span class="ar">يؤبن</span> <span class="add">[i. e. <span class="ar">يُؤْبَنُ</span> or<span class="arrow"><span class="ar">يُؤَبَّنٌ↓</span></span>]</span> alone, it relates to evil only. <span class="auth">(AA, T.<span class="add">[<a href="#Abn_2">But see 2</a>.]</span>)</span> And <span class="ar long">فُلَانٌ يَؤَبَنُ بِكَذَا</span>, or<span class="arrow"><span class="ar">يُؤَبَّنُ↓</span></span>, <em>Such a one is evil spoken of by the imputation of such a thing.</em> <span class="auth">(Ṣ, accord. to different copies.)</span> And it is said respecting the assembly of the Prophet, <span class="arrow"><span class="ar long">لَا تُؤَبَّنُ↓ فِيهِ الحُرَمُ</span></span>, <span class="auth">(T, and so in a copy of the Ṣ,)</span> or <span class="ar long">لا تُؤْبَنُ</span>, <span class="auth">(so in some copies of the Ṣ,)</span> i. e. <em>Women</em> <span class="auth">(T)</span> <em>shall not be mentioned in an evil manner therein:</em> <span class="auth">(T, Ṣ:)</span> or <em>shall not have evil imputations cast upon them, nor be found fault with, nor shall that which is foul be said of them, nor that which ought not, of things whereof one should be ashamed.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abn_1_A2">
					<p>Also, and<span class="arrow"><span class="ar">أبّنهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَأْبِينٌ</span>, <span class="auth">(Ḳ,)</span> <em>He found fault with him,</em> or <em>blamed him, to his face;</em> <span class="auth">(M, Ḳ;)</span> and <em>he upbraided him,</em> or <em>reproached him.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abn_2">
				<h3 class="entry">2. ⇒ <span class="ar">أبّن</span></h3>
				<div class="sense" id="Abn_2_A1">
					<p><span class="ar long">أبّن الشَّىْءَ</span>, <span class="auth">(AZ, Ṣ,)</span> inf. n. <span class="ar">تَأْبِينٌ</span>, <span class="auth">(Ḳ,)</span> <em>He watched,</em> or <em>observed, the thing; or he expected it,</em> or <em>waited for it.</em> <span class="auth">(AZ, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Abn_2_A2">
					<p><span class="ar long">أبّن الأَثَرَ</span>, <span class="auth">(M,)</span> inf. n. as above, <span class="auth">(Aṣ, T, Ṣ, Ḳ,)</span> <em>He followed the traces,</em> or <em>footprints,</em> or <em>footsteps,</em> <span class="auth">(Aṣ, T, Ṣ, M, Ḳ,)</span> of a thing; <span class="auth">(Aṣ, Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">تأبّن↓</span></span>. <span class="auth">(Ḳ.)</span> And hence the next signification. <span class="auth">(Aṣ, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abn_2_B1">
					<p><span class="ar long">أبّن الرَّجُلَ</span>, <span class="auth">(Ṣ, M,)</span> inf. n. as above, <span class="auth">(Sh, T, Ṣ, Ḳ,)</span> <em>He praised the man,</em> or <em>spoke well of him,</em> <span class="auth">(Sh, Th, T, Ṣ, M, Ḳ,)</span> <em>after his death,</em> <span class="auth">(Th, Ṣ, M, Ḳ,)</span> or <em>in death</em> and <em>in life,</em> <span class="auth">(Sh, T,)</span> used in poetry to signify praise of the living; <span class="auth">(M;)</span> and <em>wept for him:</em> <span class="auth">(Ṣ:)</span> <em>he praised him; and enumerated,</em> or <em>recounted, his good qualities</em> or <em>actions:</em> you say, <span class="ar long">لَمْ يَزَلَ يُقَرِّظُ أَحْيَاكُمْ وَيُؤَبِّنُ مَوْتَاكُمْ</span> <span class="add">[<em>He ceased not to eulogize your living and to praise your dead</em>]</span>: <span class="auth">(Z, TA:)</span> for he who praises the dead traces his <span class="add">[good]</span> deeds. <span class="auth">(Aṣ, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Abn_2_B2">
					<p><a href="#Abn_1">See also 1</a>, in six places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Abn_5">
				<h3 class="entry">5. ⇒ <span class="ar">تَأبّن</span></h3>
				<div class="sense" id="Abn_5_A1">
					<p><a href="#Abn_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AibonN">
				<h3 class="entry"><span class="ar">اِبْنٌ</span></h3>
				<div class="sense" id="AibonN_A1">
					<p><span class="ar">اِبْنٌ</span>: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubonapN">
				<h3 class="entry"><span class="ar">أُبْنَةٌ</span></h3>
				<div class="sense" id="OubonapN_A1">
					<p><span class="ar">أُبْنَةٌ</span> <em>A knot in wood,</em> or <em>in a branch;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> or <em>in a staff,</em> or <em>stick;</em> <span class="auth">(T;)</span> and <em>in a bow,</em> <span class="auth">(TA,)</span> <span class="add">[i. e.]</span> the <em>place of the shooting forth of a branch in a bow,</em> <span class="auth">(M,)</span> which is a fault therein; <span class="auth">(TA;)</span> and <em>in a rope, or cord:</em> <span class="auth">(M in art. <span class="ar">اثل</span>:)</span>pl. <span class="ar">أُبَنٌ</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
				<span class="pb" id="Page_0010"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: <span class="ar">أُبْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OubonapN_A2">
					<p>Hence, <span class="auth">(M,)</span> ‡ <em>A fault, defect,</em> or <em>blemish,</em> <span class="auth">(T, M, Ḳ, TA,)</span> in one's grounds of pretension to respect, <span class="auth">(T, TA,)</span> and in speech, or language. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: <span class="ar">أُبْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OubonapN_A3">
					<p>† Particularly The <em>enormity that is committed with one who is termed</em> <span class="ar">مَأْبُون</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: <span class="ar">أُبْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OubonapN_A4">
					<p>And ‡ <em>Rancour, malevolence, malice,</em> or <em>spite:</em> <span class="auth">(Ḳ, TA:)</span> and <em>enmity:</em> pl. as above. <span class="auth">(TA.)</span> You say, <span class="ar long">بَيْنَهُمْ أُبَنٌ</span> ‡ <span class="auth">(Ṣ, TA)</span> <em>Between them are enmities.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: <span class="ar">أُبْنَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OubonapN_A5">
					<p>Also The <span class="add">[<em>part called</em>]</span> <span class="ar">غَلْصَمَة</span> <span class="add">[meaning the <em>epiglottis</em>]</span> of a camel. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AibonapN">
				<h3 class="entry"><span class="ar">اِبْنَةٌ</span></h3>
				<div class="sense" id="AibonapN_A1">
					<p><span class="ar">اِبْنَةٌ</span>: <a href="index.php?data=02_b/198_bne">see art. <span class="ar">بنى</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibBaAnN.1">
				<h3 class="entry"><span class="ar">إِبَّانٌ</span></h3>
				<div class="sense" id="IibBaAnN.1_A1">
					<p><span class="ar">إِبَّانٌ</span> The <em>time</em> of a thing; <span class="auth">(T, Ṣ, M, Ḳ, and Mṣb in art. <span class="ar">اب</span>;)</span> the <em>season</em> of a thing; <span class="auth">(Mṣb in that art.;)</span> the <em>time of the preparing,</em> or <em>making ready,</em> of a thing; <span class="auth">(Mgh in that art.;)</span> as, for instance, of fruit, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> of the fresh ripe dates, and of the gathering of fruits, and of heat or cold: <span class="auth">(T.:)</span> or the <em>first</em> of a thing. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">أَخَذَ الشَّىْءَ بِإِبَّانِهِ</span> <em>He took the thing in its time:</em> or <em>in,</em> or <em>with, the first thereof.</em> <span class="auth">(M.)</span> The <span class="ar">ن</span> is radical, so that it is of the measure <span class="ar">فِعَّالٌ</span>; or, as some say, augmentative, so that it is of the measure <span class="ar">فِعْلَانٌ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=01_A/001_Ab">See art. <span class="ar">اب</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWabBanN">
				<h3 class="entry"><span class="ar">مُؤَبَّنٌ</span></h3>
				<div class="sense" id="muWabBanN_A1">
					<p><span class="ar">مُؤَبَّنٌ</span> occurs as meaning <em>Dead,</em> or <em>dying;</em> i. e., <span class="add">[properly,]</span> <em>wept for.</em> <span class="auth">(Ṣ.)</span> <span class="add">[<a href="#Abn_2">See 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWabBinN">
				<h3 class="entry"><span class="ar">مُؤَبِّنٌ</span></h3>
				<div class="sense" id="muWabBinN_A1">
					<p><span class="ar">مُؤَبِّنٌ</span> <em>A praiser of the dead;</em> because he traces his <span class="add">[good]</span> deeds. <span class="auth">(Aṣ, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOobuwnN">
				<h3 class="entry"><span class="ar">مَأْبُونٌ</span></h3>
				<div class="sense" id="maOobuwnN_A1">
					<p><span class="ar">مَأْبُونٌ</span> <em>Made an object of imputation,</em> or <em>suspected, of evil:</em> thus when used alone: otherwise you add <span class="ar">بِخَيْرٍ</span> <span class="add">[of good]</span>, and <span class="ar">بِشَّرٍ</span> <span class="add">[of evil]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: <span class="ar">مَأْبُونٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOobuwnN_A2">
					<p>Hence, <span class="add">[<em>A catamite;</em>]</span> <em>one with whom enormous wickedness is committed;</em> <span class="auth">(TA;)</span> <em>i. q.</em> <span class="ar">مُخَنَّثٌ</span>. <span class="auth">(Idem, voce <span class="ar">دُعْبُوثٌ</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابن</span> - Entry: <span class="ar">مَأْبُونٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOobuwnN_A3">
					<p>Also One who is <em>imprisoned;</em> because suspected of a foul fault, or crime. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abns">
				<h3 class="entry"><span class="ar">ابنس</span></h3>
				<div class="sense" id="Abns_A1">
					<p><span class="ar">ابنس</span>, accord. to the Mṣb; or <span class="ar">بنس</span>, accord. to the TA.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MbinuwsN">
				<h3 class="entry"><span class="ar">آبِنُوسٌ</span></h3>
				<div class="sense" id="MbinuwsN_A1">
					<p><span class="ar">آبِنُوسٌ</span>, with medd to the <span class="ar">ا</span> and kesr to the <span class="ar">ب</span>, <span class="auth">(TA,)</span> or with damm to the <span class="ar">ب</span>, <span class="add">[i. e. <span class="ar">آبُنُوسٌ</span>, and by some written <span class="ar">آبَنُوسٌ</span>,]</span> or with the <span class="ar">ب</span> quiescent, <span class="add">[i. e. <span class="ar">أَبْنُوسٌ</span>,]</span> and without <span class="ar">و</span>, <span class="add">[app. <span class="ar">أَبْنُسٌ</span>,]</span> <span class="auth">(Mṣb,)</span> <span class="add">[<em>Ebony;</em>]</span> <em>a thing well known, which is brought from India:</em> an arabicized word: <span class="auth">(Mṣb <span class="add">[in which is added the proper Arabic appellation; but the word in my copy of that work is imperfectly written; app. <span class="ar">جعفر</span>; which, however, does not seem to be the word intended:]</span>)</span> some say that it is the <em>same as</em> <span class="ar">سَاسَم</span>: others, that it is <em>different therefrom:</em> and respecting the measure of the word, authors differ. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0009.pdf" target="pdf">
							<span>Lanes Lexicon Page 9</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0010.pdf" target="pdf">
							<span>Lanes Lexicon Page 10</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
