<article class="root" id="Root_Azb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/063_Az">از</a></span>
				<span class="ar">ازب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/065_Azj">ازج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azb_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزب</span></h3>
				<div class="sense" id="Azb_1_A1">
					<p><span class="ar">أَزَبَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِبُ</span>}</span></add>, <span class="auth">(A, Ḳ,)</span> inf. n. <span class="ar">أَزْبٌ</span>, <span class="auth">(TḲ,)</span> <em>It</em> <span class="auth">(water)</span> <em>flowed</em> or <em>ran;</em> <span class="auth">(A, Ḳ;)</span> like <span class="ar">وَزَبَ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYozaAbN">
				<h3 class="entry"><span class="ar">مِئْزَابٌ</span></h3>
				<div class="sense" id="miYozaAbN_A1">
					<p><span class="ar">مِئْزَابٌ</span>, <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ,)</span> and <span class="ar">مِيزَابٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>A water-spout; a pipe,</em> or <em>channel, that spouts forth water:</em> <span class="auth">(Mgh, TA:)</span> or <em>that by which water pours down from a high place:</em> <span class="auth">(Towsheeh:)</span> or <em>a water-spout of wood,</em> or <em>the like, to convey away the water from the roof of a house:</em> <span class="auth">(MF in art. <span class="ar">زوب</span>:)</span> the former is from the verb above mentioned: <span class="auth">(A, Ḳ:)</span> or it is arabicized, <span class="auth">(A, Mgh, Ḳ,)</span> from the Persian, <span class="auth">(Mgh, Ḳ,)</span> signifying “make water:” <span class="auth">(Ḳ:)</span> its pl. is <span class="ar">مَآزِيبُ</span>: <span class="auth">(ISk, Ṣ, Mgh, Mṣb:)</span> and <a href="#myzAb">the pl. of <span class="ar">ميزاب</span></a> is <span class="ar">مَيَازِيبُ</span> and <span class="ar">مَوَازِيبُ</span>, from <span class="ar">وَزَبَ</span>, said of water, meaning “it flowed,” <span class="auth">(Mgh, Mṣb,)</span> accord. to IAạr; <span class="auth">(Mgh;)</span> or this is arabicized; or post-classical: <span class="auth">(Mṣb:)</span> but <span class="ar">ميزاب</span>, without <span class="ar">ء</span>, is altogether disallowed by Yaạḳoob <span class="add">[i. e. ISk]</span>: <span class="auth">(Mgh:)</span> it is also called <span class="ar">مِرْزَابٌ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> accord. to IAạr; <span class="auth">(T, Mṣb;)</span> but this is disallowed by ISk, Fr, and AḤát, <span class="auth">(Mṣb,)</span> and by Az <span class="add">[the author of the T]</span>; <span class="auth">(Mgh;)</span> and <span class="ar">مِزْرَابٌ</span> also, accord. to IAạr and Lth and others, as is mentioned in the T. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0052.pdf" target="pdf">
							<span>Lanes Lexicon Page 52</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
