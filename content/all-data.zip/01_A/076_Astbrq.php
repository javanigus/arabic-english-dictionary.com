<article class="root" id="Root_Astbrq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/075_AstAc">استاذ</a></span>
				<span class="ar">استبرق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/077_Asd">اسد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IisotaboraqN">
				<h3 class="entry"><span class="ar">إِسْتَبْرَقٌ</span></h3>
				<div class="sense" id="IisotaboraqN_A1">
					<p><span class="ar">إِسْتَبْرَقٌ</span>: <a href="index.php?data=02_b/078_brq">see art. <span class="ar">برق</span></a>, in which, <a href="index.php?data=12_s/097_srq">and in art. <span class="ar">سرق</span></a>, it is mentioned: but this is its proper place, if it be an arabicized word: in the T it is mentioned in art. <span class="ar">ستبرق</span>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
