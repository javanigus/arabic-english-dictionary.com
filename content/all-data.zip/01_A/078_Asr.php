<article class="root" id="Root_Asr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/077_Asd">اسد</a></span>
				<span class="ar">اسر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/079_AsTrlAb">اسطرلاب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Asr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسر</span></h3>
				<div class="sense" id="Asr_1_A1">
					<p><span class="ar">أَسَرَهُ</span> <span class="auth">(Ṣ, M, A,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْسِرُ</span>}</span></add>, inf. n. <span class="ar">أَسْرٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">إِسَارٌ</span>, <span class="auth">(M, TA,)</span> <em>He bound, braced,</em> or <em>tied, him,</em> <span class="add">[namely, his captive,]</span> or <em>it,</em> <span class="auth">(Ṣ, M, A, Ḳ,)</span> namely, his <span class="ar">قَتَب</span> <span class="add">[or camel's saddle]</span>, <span class="auth">(Ṣ, A,)</span> or his horse's saddle, <span class="auth">(A,)</span> <em>with an</em> <span class="ar">إِسَار</span>, i. e. <em>a thong of untanned hide,</em> <span class="auth">(Ṣ, A,)</span> <em>by tying the two extremities of the</em> <span class="ar">عَرْقُوْتَانِ</span> <em>of the camel's saddle, or of the curved pieces of wood of the horse's saddle.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Asr_1_A2">
					<p>Also, aor. as above, and so the inf. n., i. e. <span class="ar">أَسْرٌ</span> <span class="auth">(Ṣ, Mṣb)</span> and <span class="ar">إِسَارٌ</span>, <span class="auth">(Lth, Ṣ,)</span> <em>He made him a captive; captived him;</em> or <em>took him a prisoner; whether he bound him with an</em> <span class="ar">إِسَار</span> or <em>did not;</em> <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">آسرهُ↓</span></span>, of the same form as <span class="ar">أَكْرَمَ</span>; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">استأسرهُ↓</span></span>, accord. to a trad., in which it occurs thus used, transitively: <span class="auth">(Mgh:)</span> and <em>he imprisoned him.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Asr_1_A3">
					<p>Also, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">أَسْرٌ</span>, <span class="auth">(Mṣb,)</span> † <em>He</em> <span class="auth">(God)</span> <em>created him,</em> or <em>formed him,</em> <span class="auth">(Ṣ, Mṣb,)</span> <em>in a goodly manner.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَسَرَهُ ٱللّٰهُ أَحْسَنَ الأَسْرِ</span> <em>God created him,</em> or <em>formed him, in the best manner.</em> <span class="auth">(Fr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Asr_1_A4">
					<p><span class="ar">أُسِرَ</span>, <span class="auth">(Ṣ, A,)</span> aor. <span class="ar">يُؤْسَرُ</span>; <span class="auth">(Ṣ;)</span> or <span class="ar">أَسِرَ</span>, aor. <span class="ar">يَأْسَرُ</span>; <span class="auth">(IḲṭṭ;)</span> or <span class="ar long">أُسِرَ بَوْلُهُ</span>; <span class="auth">(M;)</span> inf. n. <span class="ar">أَسْرٌ</span>, <span class="auth">(M, and so in a copy of the Ṣ,)</span> or the latter is a simple subst.; <span class="auth">(M, IḲṭṭ;)</span> <em>He</em> <span class="auth">(a man, Ṣ, A)</span> <em>suffered suppression of his urine.</em> <span class="auth">(Ṣ, M, IḲṭṭ, A.)</span> <span class="add">[<a href="#OusorN">See <span class="ar">أُسْرٌ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asr_2">
				<h3 class="entry"><span class="add">[<itype>2.</itype> <span class="new">{<span class="ar">أسّر</span>}</span>]</span></h3>
				<div class="sense" id="Asr_2_A1">
					<p><span class="add">[<span class="ar">أسّر</span> <em>He bound,</em> or <em>tied, tight, fast,</em> or <em>firmly.</em> <span class="auth">(So accord. to Golius; but for this he names no authority.)</span>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Asr_4">
				<h3 class="entry">4. ⇒ <span class="ar">آسر</span></h3>
				<div class="sense" id="Asr_4_A1">
					<p><a href="#Asr_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأسّر</span></h3>
				<div class="sense" id="Asr_5_A1">
					<p><span class="ar long">تأسّر عَلَيْهِ فُلَانٌ</span> † <em>Such a one excused himself to him, and was slow,</em> or <em>tardy:</em> <span class="auth">(AZ, T, Ḳ:*)</span> thus as related by Ibn-Hánee from AZ: as AʼObeyd relates it from him, <span class="ar">تأسن</span>; but this is a mistake: it is correctly with <span class="ar">ر</span>. <span class="auth">(T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asr_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتسر</span></h3>
				<div class="sense" id="Asr_8_A1">
					<p><span class="ar">يَأْتَسِرُ</span>, inf. n. <span class="ar">ٱئْتِسَارٌ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتِسَارٌ</span>]</span>; for <span class="ar">يَتَّسِرُ</span>, inf. N. <span class="ar">ٱتِّسَارٌ</span>: <a href="index.php?data=02_b/101_bsr">see art. <span class="ar">بسر</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Asr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأسر</span></h3>
				<div class="sense" id="Asr_10_A1">
					<p><span class="ar long">استأسر لِلْعَدُوِ</span> <em>He submitted himself as a captive to the enemy.</em> <span class="auth">(Mgh.)</span> You say, <span class="ar">اِسْتَأْسِرْ</span>, meaning <em>Be thou a captive to me.</em> <span class="auth">(Ṣ,)</span></p>	
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Asr_10_B1">
					<p><a href="#Asr_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasorN">
				<h3 class="entry"><span class="ar">أَسْرٌ</span></h3>
				<div class="sense" id="OasorN_A1">
					<p><span class="ar">أَسْرٌ</span> <em>i. q.</em> <span class="ar">إِسَارٌ</span>, q. v. <span class="auth">(Ṣ.)</span> Hence the saying, <span class="ar long">هٰذَا الشَّىْءُ لَكَ بِأَسْرِهِ</span> <em>This thing is for thee,</em> or <em>is thine,</em><span class="add">[lit.]</span> <em>with its thong of untanned hide</em> <span class="add">[wherewith it is bound]</span>; meaning, <em>altogether;</em> like as one says, <span class="ar">بِرُمَّتِهِ</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">خُذْهُ بِأَسْرِهِ</span> <em>Take thou it all,</em> or <em>altogether.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">جَآءَ القَوْمُ بِأَسْرِهِمْ</span> <em>The people came altogether.</em> <span class="auth">(Aboo-Bekr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: <span class="ar">أَسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OasorN_A2">
					<p><em>Strength of make,</em> or <em>form.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[Accord. to the copies of the Ḳ in my hands, it also signifies <em>Strength of natural disposition;</em> but instead of <span class="ar">وَالخُلُق</span>, in those copies, we should read <span class="ar">وَالخَلْقُ</span>, agreeably with other lexicons, as is implied in the TA: <a href="#Asr_1">see 1</a>.]</span> <span class="pb" id="Page_0058"></span>You say, <span class="ar long">فُلَانٌ شَدِيدٌ أَسْرٍ الخَلْقِ</span> ‡ <em>Such a one is of strong, firm,</em> or <em>compact, make,</em> or <em>form.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: <span class="ar">أَسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OasorN_A3">
					<p><span class="ar long">شَدَدْنَا أَسْرَهُمْ</span>, in the Ḳur <span class="add">[lxxvi. 28]</span>, means ‡ <em>We have strengthened their make,</em> or <em>form:</em> <span class="auth">(Ṣ, A, Mṣb:)</span> or, <em>their joints:</em> or, <em>their two sphincters which serve as repressers of the urine and feces</em> (<span class="ar long">مَصَرَّتَىِ البَوْلِ وَالغَائِطِ</span>), which contract when the excrement has passed forth; or the meaning is, that these two things do not become relaxed before one desires. <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusorN">
				<h3 class="entry"><span class="ar">أُسْرٌ</span></h3>
				<div class="sense" id="OusorN_A1">
					<p><span class="ar">أُسْرٌ</span>, <span class="auth">(Ṣ, M, IḲṭṭ, A,)</span> a subst., <span class="auth">(M, IḲṭṭ,)</span> as also<span class="arrow"><span class="ar">أُسُرٌ↓</span></span>, <span class="auth">(M, Lb,)</span> meaning <em>Suppression of the urine:</em> <span class="auth">(Ṣ, M, &amp;c.:)</span> suppression of the feces is termed <span class="ar">حُصْرٌ</span>: <span class="auth">(Ṣ:)</span> or <em>a dribbling of the urine, with a cutting pain in the bladder, and pangs like those of a female in the time of parturition.</em> <span class="auth">(IAạr.)</span> You say, <span class="ar long">أَخَذَهُ الأَسْرُ</span> <span class="add">[<em>Suppression of urine,</em>, &amp;c., <em>took him,</em> or <em>affected him</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">أَنَالَهُ ٱللّٰهُ أُسْراً</span> <span class="add">[<em>May God give him a suppression of urine,</em>, &amp;c.]</span>: a form of imprecation. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: <span class="ar">أُسْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OusorN_A2">
					<p>Hence, <span class="auth">(M,)</span> <span class="ar long">عُودُ أُسْرٍ</span> <span class="auth">(IAạr, Ṣ, M, A, Ḳ)</span> and <span class="ar long">عُودٌ أُسْرٌ</span> and <span class="ar long">عُودُ الأُسْرِ</span> <span class="auth">(Expositions of the Fṣ)</span> and <span class="ar long">عُودُ يُسْرِ</span>, <span class="auth">(IAạr, Ḳ,)</span> or this is a corruption, <span class="auth">(Ḳ,)</span> or a vulgar mistake, <span class="auth">(A,)</span> and should not be said, <span class="auth">(Fr, Ṣ, A,)</span> unless meant to be used as ominous of good, <span class="auth">(A,)</span> <em>A stick,</em> or <em>piece of wood, which is put upon the belly of a man affected by a suppression of his urine,</em> <span class="auth">(Ṣ, A, Ḳ, &amp;c.,)</span> <em>and which cures him.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OusurN">
				<h3 class="entry"><span class="ar">أُسُرٌ</span></h3>
				<div class="sense" id="OusurN_A1">
					<p><span class="ar">أُسُرٌ</span>: <a href="#OusorN">see <span class="ar">أُسْرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusorapN">
				<h3 class="entry"><span class="ar">أُسْرَةٌ</span></h3>
				<div class="sense" id="OusorapN_A1">
					<p><span class="ar">أُسْرَةٌ</span> † A man's <em>kinsmen that are more,</em> or <em> most, nearly related to him;</em> his <em>near kinsmen:</em> <span class="auth">(Ṣ,* M, A,* Mṣb,* Ḳ:)</span> or a man's <em>nearer,</em> or <em>nearest, relations on his father's side:</em> <span class="auth">(Aboo-Jaạfar En-Naḥḥás:)</span> so called because he is strengthened by them. <span class="auth">(Ṣ, A.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisaArN">
				<h3 class="entry"><span class="ar">إِسَارٌ</span></h3>
				<div class="sense" id="IisaArN_A1">
					<p><span class="ar">إِسَارٌ</span> <em>A thing with which one binds;</em> <span class="auth">(M, Ḳ;)</span> <em>a thong of untanned hide,</em> <span class="auth">(Ṣ, A, Mṣb,)</span> <em>with which one binds a camel's saddle,</em> <span class="auth">(Aṣ, Ṣ,)</span> <span class="add">[as also <span class="ar">إِصَارٌ</span>,]</span> <em>and a captive;</em> and so <span class="ar">أَسْرٌ</span>, q. v.: <span class="auth">(Ṣ:)</span> and <em>a rope,</em> or <em>cord, with which a captive is bound:</em> and <em>a pair of shackles:</em> <span class="auth">(TA:)</span> pl. <span class="ar">أُسُرٌ</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#Asr_1">See also 1</a>.]</span> You say, <span class="ar long">حَلَّ إِسَارَهُ فَأَطْلَقَهُ</span> <em>He untied his thong of untanned hide wherewith he was bound, and released him.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: <span class="ar">إِسَارٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IisaArN_B1">
					<p><a href="#OasiyrN">See also <span class="ar">أَسِيرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OasiyrN">
				<h3 class="entry"><span class="ar">أَسِيرٌ</span></h3>
				<div class="sense" id="OasiyrN_A1">
					<p><span class="ar">أَسِيرٌ</span> <em>i. q.</em><span class="arrow"><span class="ar">مَأْسُورٌ↓</span></span>; <span class="auth">(Ṣ, TA;)</span> <em>Bound with an</em> <span class="ar">إِسَار</span>: <span class="auth">(M, TA:)</span> <em>shackled:</em> <span class="auth">(Ḳ:)</span> <em>imprisoned:</em> <span class="auth">(Mujáhid, M, Ḳ:)</span> <em>captived,</em> or <em>a captive;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>absolutely,</em> <span class="auth">(TA,)</span> <em>although not bound with an</em> <span class="ar">اسار</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar">إِسَارٌ↓</span></span> is sometimes used in the same sense. <span class="auth">(Mṣb.)</span> <span class="ar">اسير</span> is also applied as an epithet to a woman, <span class="auth">(Mgh, Mṣb,)</span> when the woman is mentioned; but otherwise <span class="ar">أَسِيرَةٌ</span> is used as the fem.: you say, <span class="ar long">قَتَلْتُ الأَسِيرَةَ</span> <span class="add">[<em>I slew the female captive</em>]</span>, like as you say, <span class="ar long">رَأَيْتُ القَتِيلَةَ</span>. <span class="auth">(Mṣb.)</span> The pl. is <span class="ar">أَسْرَى</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَسَرَآءُ</span> <span class="auth">(M, Ḳ)</span> and <span class="auth">(accord. to several authors, pls. of <span class="ar">أَسْرَى</span>, TA)</span> <span class="ar">أُسَارَى</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَسَارَى</span>: <span class="auth">(M, Ḳ:)</span> the first of these forms of pl. is proper to epithets applied to those who are hurt or afflicted in their bodies or their intellects: <span class="auth">(Aboo-Is-ḥáḳ:)</span> it is used in this instance because a captive is like one wounded or stung. <span class="auth">(Th, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlsBaroji">
				<h3 class="entry"><span class="ar">السَّرْجِ</span></h3>
				<div class="sense" id="AlsBaroji_A1">
					<p><span class="ar long">تَآسِيرُ السَّرْجِ</span> <span class="add">[in the CK, erroneously, <span class="ar">تَأْسِير</span>]</span> <em>The thongs of the horse's saddle, whereby it is bound:</em> <span class="auth">(Ḳ:)</span> accord. to the more correct opinion, a pl. without a sing. <span class="auth">(MF.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOosuwrN">
				<h3 class="entry"><span class="ar">مَأْسُورٌ</span></h3>
				<div class="sense" id="maOosuwrN_A1">
					<p><span class="ar">مَأْسُورٌ</span>: <a href="#OasiyrN">see <span class="ar">أَسِيرٌ</span></a>. A camel's saddle <em>bound with an</em> <span class="ar">إِسَار</span>: pl. <span class="ar">مَآسِيرُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: <span class="ar">مَأْسُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOosuwrN_A2">
					<p>† A man, and a beast, <em>having strongly-knit joints.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسر</span> - Entry: <span class="ar">مَأْسُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maOosuwrN_A3">
					<p>A man <em>suffering suppression of his urine.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0057.pdf" target="pdf">
							<span>Lanes Lexicon Page 57</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0058.pdf" target="pdf">
							<span>Lanes Lexicon Page 58</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
