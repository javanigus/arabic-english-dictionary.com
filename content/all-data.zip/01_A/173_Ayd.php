<article class="root" id="Root_Ayd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/172_Ayb">ايب</a></span>
				<span class="ar">ايد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/174_Ayr">اير</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ayd_1">
				<h3 class="entry">1. ⇒ <span class="ar">أيد</span> ⇒ <span class="ar">آد</span></h3>
				<div class="sense" id="Ayd_1_A1">
					<p><span class="ar">آدَ</span>, aor. <span class="ar">يَئِيدُ</span>, inf. n. <span class="ar">أَيْدٌ</span>, <em>He,</em> <span class="auth">(a man, AZ, T, &amp;c.,)</span> or <em>it,</em> <span class="auth">(a thing, L,)</span> <em>was,</em> or <em>became, strong:</em> <span class="auth">(AZ, T, Ṣ, M, Ḳ, &amp;c.:)</span> and<span class="arrow"><span class="ar">آيد↓</span></span>, inf. n. <span class="ar">إِيَادٌ</span>, <em>he became possessed of strength.</em> <span class="auth">(AHeyth, T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ayd_1_A2">
					<p><span class="ar long">آدَتٌ ضِيَافَتُهُ</span> ‡ <em>His coming as a guest was,</em> or <em>became, frequent.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#OayBidN">See <span class="ar">أَيِّدٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ayd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أيّد</span></h3>
				<div class="sense" id="Ayd_2_A1">
					<p><span class="ar">أيّد</span>, inf. n. <span class="ar">تَأْيِيدٌ</span>; <span class="auth">(T, Ṣ, M, &amp;c.;)</span> and<span class="arrow"><span class="ar">آيد↓</span></span>, <span class="auth">(T, Ṣ, Ḳ,)</span> of the measure <span class="ar">فَاعَلَ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">مُؤَايَدَةٌ</span>; <span class="auth">(Ḳ;)</span> or <em>He strengthened:</em> <span class="auth">(Ṣ, M, L, Mṣb, Ḳ:)</span> <em>he aided,</em> or <em>rendered victorious.</em> <span class="auth">(L.)</span> You say, <span class="ar long">أيّدهُ عَلَى الأَمْرِ</span> <em>He strengthened him to accomplish the affair.</em> <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ayd_3">
				<h3 class="entry">3. ⇒ <span class="ar">آيد</span></h3>
				<div class="sense" id="Ayd_3_A1">
					<p><a href="#Ayd_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ayd_4">
				<h3 class="entry">4. ⇒ <span class="ar">آيد</span></h3>
				<div class="sense" id="Ayd_4_A1">
					<p><a href="#Ayd_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ayd_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأيّد</span></h3>
				<div class="sense" id="Ayd_5_A1">
					<p><span class="ar">تأيّد</span> <em>He,</em> or <em>it,</em> <span class="auth">(a thing, Ṣ,)</span> <em>became strengthened.</em> <span class="auth">(T, Ṣ, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MdN">
				<h3 class="entry"><span class="ar">آدٌ</span></h3>
				<div class="sense" id="MdN_A1">
					<p><span class="ar">آدٌ</span> <em>Strength;</em> syn. <span class="ar">صُلْبٌ</span>, <span class="auth">(M, L, Ḳ,)</span> and <span class="ar">قُوَّةٌ</span> <span class="add">[which is one of the significations of <span class="ar">صُلْبٌ</span>, and that which is here meant]</span>; as also<span class="arrow"><span class="ar">أَيْدٌ↓</span></span> <span class="add">[which is an inf. n.: <a href="#Ayd_1">see 1</a>]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayodN">
				<h3 class="entry"><span class="ar">أَيْدٌ</span></h3>
				<div class="sense" id="OayodN_A1">
					<p><span class="ar">أَيْدٌ</span>: <a href="#AdN">see <span class="ar">آدٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBidN">
				<h3 class="entry"><span class="ar">أَيِّدٌ</span></h3>
				<div class="sense" id="OayBidN_A1">
					<p><span class="ar">أَيِّدٌ</span> <em>Strong:</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ:)</span> an epithet applied <span class="add">[to God, and]</span> to a man. <span class="auth">(Ṣ.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِذَا القَوْسُ وَتَّرَهَا أَيِّدٌ</span> *</div> 
						<div class="star">* <span class="ar long">رَمَى فَأَصَابَ الكُلَى وَالذُّرَى</span> *</div> 
					</blockquote>
					<p><span class="add">[lit. <em>When a strong one strings the bow, he shoots, and hits the kidneys, and the tops of the humps of the camels</em>]</span>; meaning, when God strings <span class="add">[or stretches]</span> the bow that is in the clouds, He casts fat into the kidneys and humps of the camels, by means of the herbage that is produced by the rain. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايد</span> - Entry: <span class="ar">أَيِّدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OayBidN_A2">
					<p><span class="ar long">إِنَّهُ لَأَيِّدُ الغَدَآءِ وَالعَشَآءِ</span> means ‡ <em>Verily he is often present at the morning and evening meals.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyaAdN">
				<h3 class="entry"><span class="ar">إِيَادٌ</span></h3>
				<div class="sense" id="IiyaAdN_A1">
					<p><span class="ar">إِيَادٌ</span> <em>Anything by which a person or thing is strengthened,</em> <span class="auth">(M, L, Ḳ,)</span> or <em>guarded, defended,</em> or <em>protected:</em> <span class="auth">(T, L:)</span> <em>a thing by which one is protected,</em> or <em>veiled,</em> or <em>concealed:</em> the <em>side; shade,</em> or <em>shadow;</em> or <em>protection: a place of refuge:</em> <span class="auth">(M, L, Ḳ:)</span> <em>either side</em> of anything, <em>that strengthens</em> it: <span class="auth">(Lth, T:)</span> <em>anything that is in the vicinity</em> of a thing: <span class="auth">(T:)</span> <em>each wing</em> of an army: <span class="auth">(Ṣ, M, L, Ḳ:)</span> <em>earth that is put round a watering-trough</em> or <em>tank,</em> or <em>round a tent,</em> <span class="auth">(Ṣ, M, L, Ḳ,)</span> <em>to strengthen it,</em> or <em>to keep away from it the rain-water:</em> <span class="auth">(Ṣ, L:)</span> <em>any fortification: a fortified mountain:</em> <span class="auth">(M, L, Ḳ:)</span> <em>a mountain that is inaccessible,</em> or <em>difficult of access.</em> <span class="auth">(IAạr, T.)</span> <span class="add">[In the place of one signification, Golius gives “cortex;” having found <span class="ar">لحاه</span> in the place of <span class="ar">لَجَأ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايد</span> - Entry: <span class="ar">إِيَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiyaAdN_A2">
					<p><em>An elevated tract,</em> or <em>a heap, of sand.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايد</span> - Entry: <span class="ar">إِيَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiyaAdN_A3">
					<p><em>Abundance of camels</em> <span class="add">[because they strengthen their owner]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايد</span> - Entry: <span class="ar">إِيَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiyaAdN_A4">
					<p>The <em>air;</em> syn. <span class="ar">هَوَآء</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWoyadN">
				<h3 class="entry"><span class="ar">مُؤْيَدٌ</span></h3>
				<div class="sense" id="muWoyadN_A1">
					<p><span class="ar">مُؤْيَدٌ</span>: <a href="#muwayBadN">see <span class="ar">مُؤَيَّدٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ايد</span> - Entry: <span class="ar">مُؤْيَدٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWoyadN_B1">
					<p><a href="#muWoyidN">and see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWoyidN">
				<h3 class="entry"><span class="ar">مُؤْيِدٌ</span></h3>
				<div class="sense" id="muWoyidN_A1">
					<p><span class="ar">مُؤْيِدٌ</span>, of the same measure as <span class="ar">مُؤْمِنٌ</span>, <em>A great, mighty,</em> or <em>severe, thing;</em> <span class="auth">(Ṣ, L, Ḳ;)</span> <em>a calamity:</em> <span class="auth">(T, Ṣ, M, L, Ḳ:)</span> or, accord. to Aṣ, it is <span class="arrow"><span class="ar">مُؤْيَدٌ↓</span></span>, with fet-ḥ to the <span class="ar">ى</span>, and signifies <em>anything rendered strong,</em> or <em>hard,</em> or <em>severe.</em> <span class="auth">(L.)</span> <span class="add">[<a href="#maAwidu">See <span class="ar">مَآوِدُ</span></a>, <a href="index.php?data=01_A/158_Awd">in art. <span class="ar">اود</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWayBadN">
				<h3 class="entry"><span class="ar">مُؤَيَّدٌ</span></h3>
				<div class="sense" id="muWayBadN_A1">
					<p><span class="ar">مُؤَيَّدٌ</span> and<span class="arrow"><span class="ar">مُؤْيَدٌ↓</span></span> <span class="auth">(the latter irreg., by rule being <span class="ar">مُؤَايَدٌ</span>, TḲ,)</span> <em>Strengthened:</em> <span class="auth">(Ṣ, L, Ḳ:)</span> <em>aided;</em> or <em>rendered victorious:</em> <span class="auth">(L:)</span> and the former, <em>strong,</em> applied to a building. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWayBidN">
				<h3 class="entry"><span class="ar">مُؤَيِّدٌ</span></h3>
				<div class="sense" id="muWayBidN_A1">
					<p><span class="ar">مُؤَيِّدٌ</span> <em>Strengthening:</em> <span class="auth">(Ṣ, L:)</span> <em>aiding;</em> or <em>rendering victorious.</em> <span class="auth">(L.)</span> The dim. also has this form. <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0136.pdf" target="pdf">
							<span>Lanes Lexicon Page 136</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
