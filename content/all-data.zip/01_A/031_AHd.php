<article class="root" id="Root_AHd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/030_Ajn">اجن</a></span>
				<span class="ar">احد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/032_AHn">احن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AHd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أحّد</span></h3>
				<div class="sense" id="AHd_2_A1">
					<p><span class="ar">أحّدهُ</span>, <span class="add">[inf. n. <span class="ar">تَأْحِيدٌ</span>,]</span> <em>He made it one;</em> or <em>called it one:</em> as also <span class="ar">وحّدهُ</span>. <span class="auth">(TA in art. <span class="ar">وحد</span>.)</span> You say, <span class="ar long">أَحِّدِ الِاثْنَيْنِ</span> <em>Make thou the two to become one.</em> <span class="auth">(Ḳ.)</span> It is related in a trad., that Moḥammad said to a man who was making a sign with his two fore fingers in repeating the testimony of the faith, <span class="add">[There is no deity but God, &amp;c.,]</span> <span class="ar">أَحِّدْأَحِّدْ</span> <span class="add">[meaning that he should make the sign with one finger only]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَحَدَّ ٱللّٰهَ</span> means <em>He declared God to be one; he declared,</em> or <em>professed, the unity of God;</em> as also <span class="ar">وحّدهُ</span>. <span class="auth">(T and L in art. <span class="ar">وحد</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AHd_2_A2">
					<p><span class="ar long">أَحِّدِ العَشَرَةَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَأْحِيدٌ</span>, <span class="auth">(Ḳ,)</span> <em>Make thou the ten to become eleven,</em> <span class="auth">(Ṣ, Ḳ,)</span> is a phrase mentioned by Fr on the authority of an Arab of the desert. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AHd_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتحد</span></h3>
				<div class="sense" id="AHd_8_A1">
					<p><span class="ar">اِتَّحَدَ</span>: <a href="index.php?data=27_w/053_wHd">see art. <span class="ar">وحد</span></a>: <a href="#AHd_10">and see what here next follows <span class="new">{10}</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AHd_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأحد</span></h3>
				<div class="sense" id="AHd_10_A1">
					<p><span class="ar">استأحد</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>was,</em> or <em>became, alone, by himself, apart from others,</em> or <em>solitary;</em> <span class="pb" id="Page_0027"></span>syn. <span class="ar">اِنْفَرَدَ</span>; <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">ٱتَّحَدَ↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِتَّحَدَ</span>, originally <span class="ar">اِئْتَحَدَ</span> or <span class="ar">اِوتَحَدَ</span>]</span>, <span class="auth">(Ḳ, TA,)</span> or <span class="ar">تَوَحَّدَ</span>. <span class="auth">(CK.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">احد</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AHd_10_B1">
					<p><span class="ar long">مَا ٱسْتَأْحَدَ بِهِ</span> <em>He did not know it; did not know,</em> or <em>had not knowledge, of it; did not understand it; did not know the minute circumstances of it;</em> or <em>did not perceive it by any of the senses;</em> syn. <span class="ar long">لَمْ يَشْعُرْ بِهِ</span>; <span class="auth">(L, Ḳ;)</span> i. e., a thing, or an affair: of the dial. of El-Yemen. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaHadN">
				<h3 class="entry"><span class="ar">أَحَدٌ</span></h3>
				<div class="sense" id="OaHadN_A1">
					<p><span class="ar">أَحَدٌ</span>, originally <span class="ar">وَحَدٌ</span>, the <span class="ar">و</span> being changed into <span class="ar">أ</span>, <span class="auth">(Mṣb,)</span> <em>One;</em> the <em>first of the numbers;</em> <span class="auth">(Ṣ;)</span> syn. <span class="add">[in many cases]</span> with <span class="ar">وَاحِدٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> with which it is interchangeable in two cases, to be explained below: <span class="auth">(Mṣb:)</span> pl. <span class="ar">آحَادٌ</span> and <span class="ar">أُحْدَانٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">أَحَدُونَ</span>, which last occurs in a phrase hereafter to be mentioned; <span class="auth">(TA;)</span> or it has no pl. in this sense; <span class="auth">(Mṣb, Ḳ,* TA;)</span> and as to <span class="ar">آحَادٌ</span>, it may be <a href="#waAHidN">pl. of <span class="ar">وَاحِدٌ</span></a>, <span class="add">[and originally <span class="ar">أَوْحَادٌ</span>,]</span> like <span class="ar">أَشْهَادٌ</span> <a href="#XaAhidN">as pl. of <span class="ar">شَاهِدٌ</span></a>, <span class="auth">(Th, Mṣb,)</span> a pl. of pauc. <span class="auth">(Mṣb.)</span> The fem. is <span class="arrow"><span class="ar">إِحْدَى↓</span></span> only; and this is only used in particular cases, to be shown below: <span class="auth">(Mṣb:)</span> most agree that the <span class="ar">ى</span> in this word is the characteristic of the fem. gender: but some say that it is to render it quasi-coordinate to the quadriliteral-radical class: <span class="add">[this, however, is inconsistent with its pronunciation, which is invariably <span class="ar">إِحْدَى</span>, not <span class="ar">إِحْدَّى</span>:]</span> <span class="auth">(TA:)</span> its pl. is <span class="ar">إِحَدٌ</span>, as though the sing. were <span class="ar">إِحْدَةٌ</span>, like as is said of <span class="ar">ذِكَرٌ</span> <a href="#cikorae">as pl. of <span class="ar">ذِكْرَى</span></a>: one of the expositors of the Tes-heel writes it <span class="ar">أُحَدٌ</span>, with damm and then fet-ḥ; but a pl. of this measure is not applicable to a sing. of the measure <span class="ar">فِعْلَى</span>, with kesr. <span class="auth">(MF.)</span> <a href="#OaHadN">The dim. of <span class="ar">أَحَدٌ</span></a> is <span class="arrow"><span class="ar">أُحَيْدٌ↓</span></span>; <a href="#IiHodae">and that of <span class="ar">إِحْدَى</span></a> is <span class="arrow"><span class="ar">أُحَيْدَى↓</span></span>. <span class="auth">(L in art. <span class="ar">وحد</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaHadN_A2">
					<p>It is interchangeable with <span class="ar">وَاحِدٌ</span> in two cases: first, when it is used as an epithet applied to God: <span class="auth">(Mṣb:)</span> for <span class="ar">الأَحَدُ</span>, as an epithet, is applied to God alone, <span class="auth">(Mṣb, Ḳ,)</span> and signifies <em>The One; the Sole; He who has ever been one and alone:</em> or <em>the Indivisible:</em> or <em>He who has no second</em> <span class="add">[<em>to share</em>]</span> <em>in his lordship, nor in his essence, nor in his attributes:</em> <span class="auth">(TA:)</span> you say, <span class="ar long">هُوَ الوَاحِدُ</span> and <span class="ar long">هُوَ الأَحَدُ</span>: and in like manner, <span class="ar">أَحَدٌ</span>, without the article, is used as an epithet specially in relation to God, and is interchangeable in this case <span class="add">[but not in other cases]</span> with <span class="ar">وَاحِدٌ</span>: therefore you do not say <span class="ar long">رَجُلٌ أَحَدٌ</span> nor <span class="ar long">دِرْهَمٌ أَحَدٌ</span> and the like <span class="add">[but <span class="ar long">رَجُلٌ وَاحدٌ</span> and <span class="ar long">دِرهَمٌ وَاحِدٌ</span>, &amp;c.]</span> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#waAHidN">See also <span class="ar">وَاحِدٌ</span></a>, <a href="index.php?data=27_w/053_wHd">in art. <span class="ar">وحد</span></a>.]</span> In the phrase in the Ḳur <span class="add">[cxii. 1]</span>, <span class="ar long">قُلْ هُوَ ٱللّٰهُ أَحَدٌ</span> <span class="add">[<em>Say, He is God, One</em> God]</span>, <span class="ar">أَحَدٌ</span> is a substitute for <span class="ar">ٱللّٰهُ</span>; for an indeterminate noun is sometimes a substitute for a determinate noun, as in another passage in the Ḳur, xcvi. 15 and 16. <span class="auth">(Ṣ.)</span> Secondly, it is interchangeable with <span class="ar">وَاحِدٌ</span> in certain nouns of number: <span class="auth">(Mṣb:)</span> you say <span class="ar long">أَحَدَ عَشَرَ</span> <span class="add">[masc.]</span> and <span class="ar long">إِحْدَى عَشْرَةَ</span> <span class="add">[fem.]</span> <span class="auth">(Ṣ)</span> <span class="add">[meaning <em>Eleven:</em> and in these two cases you may not substitute <span class="ar">وَاحِدٌ</span> and <span class="ar">وَاحِدَةٌ</span> for <span class="ar">أَحَدٌ</span> and <span class="ar">إِحْدَى</span>: but]</span> in <span class="ar long">أَحَدٌ وَعِشْرُونَ</span> <span class="add">[<em>One and twenty,</em> and the like,]</span> <span class="ar">أَحَدٌ</span> is interchangeable with <span class="ar">وَاحِدٌ</span>. <span class="auth">(Mṣb.)</span> Ks says, When you prefix the article <span class="ar">ال</span> to a number, prefix it to every number; therefore you should say, <span class="ar long">مَا فَعَلَتِ الأَحَدَ العَشَرَ الأَلْفَ الدِّرْهَمَ</span> <span class="add">[<em>What did the eleven thousand dirhems?</em>]</span>: but the Basrees prefix it to the first only, and say, <span class="ar long">ما فعلت الأَحَدَ عَشَرَ أَلْفَ دِرْهَمٍ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaHadN_A3">
					<p>In <span class="add">[most]</span> cases differing from these two, there is a difference in usage between <span class="ar">أَحَدٌ</span> and <span class="ar">وَاحِدٌ</span>: the former is used in affirmative phrases as a prefixed noun only, governing the noun which follows it in the gen. case; <span class="add">[as in exs. which will be found below;]</span> and is used absolutely in negative phrases; <span class="add">[as will also be seen in exs. below;]</span> whereas <span class="ar">وَاحِدٌ</span> is used in affirmative phrases as a prefixed noun and otherwise: the fem. <span class="ar">إِحْدَى</span>, also, is only used as a prefixed noun, except in numbers <span class="auth">(Mṣb)</span> <span class="add">[and in one other instance, which see below]</span>. Using <span class="ar">أَحَدٌ</span> and its fem. in affirmative phrases as prefixed nouns, you say, <span class="ar long">قَامَ أَحَدُ الثَّلَاثَةِ</span> <span class="add">[<em>One of the three stood</em>]</span>; and <span class="ar long">قَالَتْ إِحْدَا هُمَا</span> <span class="add">[<em>One of them two</em> <span class="auth">(females)</span> <em>said</em>]</span>; and <span class="ar long">خُذْ إِحْدَى الثَّلَاثَةِ</span> <span class="add">[<em>Take thou one of the three</em>]</span>. <span class="auth">(TA.)</span> The phrase <span class="ar long">إِحْدَى بَنَاتِ طَبَقٍ</span> means <em>A calamity:</em> <span class="auth">(Ḳ:)</span> or, as some say, <span class="auth">(TA, but in the Ḳ “and,”)</span> <em>a serpent;</em> <span class="auth">(Ḳ, TA;)</span> so called because it twists itself round so as to become like a <span class="ar">طَبَق</span>. <span class="auth">(TA.)</span> And the phrase <span class="ar long">إِحْدَى الإِحَدِ</span>, <span class="auth">(L, Ḳ, TA,)</span> in which the latter word has kesr to the <span class="ar">إ</span> and fet-ḥ to the <span class="ar">ح</span>, and is pl. of the former, also written <span class="ar">الأُحَدِ</span>, but this form is disapproved by MF, as has been shown above, <span class="auth">(TA, <span class="add">[in several copies of the Ḳ incorrectly written <span class="ar">الأَحَدِ</span>,]</span>)</span> <span class="add">[lit. means <em>One of the ones;</em> and]</span> is applied to <em>a great,</em> or <em>mighty, event;</em> <span class="auth">(L, Ḳ, TA;)</span> <em>one that is difficult, distressing, grievous,</em> or <em>terrible.</em> <span class="auth">(L, TA.)</span> You say, <span class="ar long">أَتَى بِإِحْدَى الإِحَدِ</span> <span class="add">[the last of which words is here again written in several copies of the Ḳ <span class="ar">الأَحَدِ</span>]</span> <em>He brought to pass a grievous, and great,</em> or <em>mighty, event,</em> <span class="auth">(Ḳ, TA,)</span> when you desire to express the greatness and terribleness of an event. <span class="auth">(TA.)</span> You also say, <span class="ar long">فُلَانُ أَحَدُ الأَحَدِينَ</span>, and <span class="ar long">وَاحِدُ الأَحَدِينَ</span>, <span class="auth">(Ḳ, TA,)</span> the latter in one copy of the Ḳ written <span class="ar long">وَاحِدُ الوَاحِدِينَ</span>, in which the latter word is pl. of the former, <span class="auth">(TA,)</span> and <span class="ar long">وَاحِدُ الآحَادِ</span>, and <span class="ar long">إِحْدَى الإِحَدِ</span>, <span class="auth">(Ḳ, TA,)</span> like a phrase before mentioned, only the former is applied to a calamity, and this to an intelligent being, and written in the two manners before mentioned, the difference being only in application, <span class="auth">(TA, <span class="add">[in several copies of the Ḳ here again written <span class="ar">إِحْدَى</span>, <span class="ar">الأَحَدِ</span>, and in the CK <span class="ar long">اَحَدِىُّ الاَحَدِ</span>,]</span>)</span> and <span class="ar long">إِحْدَى الأَحَدِينَ</span>, <span class="auth">(Et-Tes-heel,)</span> and <span class="ar long">إِحْدَى الآحَادِ</span>, <span class="auth">(TA,)</span> which are expressions of the utmost praise, <span class="auth">(IAạr, AHeyth, Ḳ,)</span> <span class="add">[lit. <em>Such a man is one of the ones;</em> meaning]</span> <em>such a one is unique among the uniques;</em> <span class="auth">(TA;)</span> <em>one who has no equal; unequalled; incomparable.</em> <span class="auth">(IAạr, Tes-heel.)</span> It seems that the form of pl. used in the phrase <span class="ar long">أَحَدُ الأَحَدِينَ</span> is used only as applied to rational beings; but it is said in the Expositions of the Tes-heel that this phrase signifies <em>One of the calamities;</em> the form of the rational pl. being given to nouns significant of things deemed great, mighty, or grievous. <span class="auth">(AHeyth.)</span> In the phrase <span class="ar long">إِحْدَى الإِحَدِ</span>, the fem. forms are said to be used for the purpose of giving intensiveness to the signification, as though the meaning were <span class="ar long">دَاهِيَةُ الدَّوَاهِى</span>, the word <span class="ar">داهية</span> being <span class="add">[an intensive epithet]</span> from <span class="ar">دَهَآءٌ</span> as signifying intelligence, or intelligence mixed with craft or cunning and forecast; or by <span class="ar">داهية</span> being meant a calamity. <span class="auth">(Expositions of the Fṣ, TA.)</span> AḤei thought <span class="ar long">أَحَدُ الأَحَدِينَ</span> to be an epithet applied to a male, and <span class="ar long">إِحْدَى الإِحَدِ</span> to be applied to a female: but his opinion has been refuted by Ed-Demámeenee in the Expos. of the Tes-heel: and this latter author there remarks, that in expressions meant to denote praise <span class="add">[of a man]</span>, <span class="ar">أَحَدٌ</span> and <span class="ar">إِحْدَى</span> are prefixed to their own proper pls., as <span class="ar">أَحَدُونَ</span> and <span class="ar">إِحَدٌ</span>; or to an epithet, as in the case of <span class="ar long">أَحَدُ العُلَمَآءِ</span> <span class="add">[<em>One of the learned</em>]</span>; but that they have not been heard prefixed to generic nouns. <span class="auth">(TA.)</span> You say likewise, <span class="ar long">هُوَ ٱبْنُ إِحْدَاهَا</span> <em>He is born of noble,</em> or <em>generous, ancestors, both on the father's and the mother's side;</em> speaking of a man and of a camel. <span class="auth">(L and Ḳ in art. <span class="ar">وحد</span>.)</span> And <span class="ar long">لَا يَقُومُ بِهٰذَا الأَمْرِ إِلَّا ٱبْنُ إِحْدَاهَا</span> <em>None will manage this thing,</em> or <em>affair, but a noble,</em> or <em>generous, man.</em> <span class="auth">(AZ, L in art. <span class="ar">وحد</span>.)</span> And<span class="arrow"><span class="ar long">لَا يَسْتَطِيعُهَا↓ ٱبْنُ إِحْداتِهَا</span></span> <span class="add">[<em>None will be able to perform it but a noble,</em> or <em>generous, man</em>]</span>. <span class="auth">(L in art. <span class="ar">وحد</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaHadN_A4">
					<p>One instance is mentioned, of the occurrence, in a trad., of <span class="ar">إِحْدَى</span> not used as a part of a number <span class="add">[i. e. not as a part of the compound <span class="ar long">إِحْدَى عَشْرَةَ</span>]</span> nor as a prefixed noun; viz., <span class="ar long">إِحْدَى مِنْ سَبْعٍ</span> <span class="add">[<em>One of seven</em>]</span>; in which <span class="ar">سبع</span> is said to mean the nights of 'Ád <span class="add">[during which that tribe was destroyed]</span>, or the years of Joseph <span class="add">[during which Egypt was afflicted with dearth]</span>. <span class="auth">(MF, from the Fáïk, &amp;c.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaHadN_A5">
					<p>Used in a negative phrase, <span class="ar">أَحَدٌ</span> signifies <em>Any one with whom one may talk or speak:</em> and in this manner it is used without variation as sing. and pl. and fem. <span class="auth">(Ṣ)</span> as well as masc. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">لَا أَحَدَ فِى الدَّارِ</span> <span class="add">[<em>There is not any one in the house</em>]</span>: but you do not say, <span class="ar long">فِيهَا أَحَدٌ</span> <span class="add">[as meaning the contrary]</span>. <span class="auth">(Ṣ.)</span> We read in the Ḳur <span class="add">[lxix. 47, this ex. of its use as a masc. pl.]</span>, <span class="ar long">فَمَا مِنْكُمْ مِنْ أَحَدٍ عَنْهُ حَاجِزِينَ</span> <span class="add">[<em>And not any persons of you should have withheld me from</em> punishing <em>him</em>]</span>. <span class="auth">(Ṣ.)</span> And in the same <span class="add">[xxxiii. 32, we find this ex. of its use as a fem. pl.]</span>, <span class="ar long">لَسْتُنَّ كَأَحَدٍ مِنَ النِّسَآءِ</span> <span class="add">[<em>Ye are not like any</em> others <em>of women</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaHadN_A6">
					<p>It is also used in interrogative phrases; as in the saying, <span class="ar long">هَلْ أَحَدٌ رَأَى مِثْلَ هٰذَا</span> <span class="add">[<em>Has any one seen the like of this?</em>]</span>; <span class="auth">(AʼObeyd, L;)</span> and in the saying, <span class="ar long">يَا حَدْ رَآهَا</span> <span class="add">[for <span class="ar long">يَا أَحَدٌ</span>, <em>O, has any one seen her,</em> or <em>it?</em>]</span>. <span class="auth">(L, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaHadN_A7">
					<p>It is <span class="add">[said to be]</span> also used in the sense of <span class="ar">شَىْءٌ</span> <span class="add">[meaning <em>Anything</em>]</span>, applied to an irrational being; as in the saying, <span class="ar long">مَا بِا لدَّارِ مِنْ أَحَدٍ إِلَّا حِمَارًا</span> <em>There is not in the house anything,</em> rational or irrational, <em>except an ass:</em> so that the thing excepted is united in kind to that from which the exception is made <span class="add">[accord. to this rendering; but this instance is generally regarded as one in which the thing excepted is disunited in kind from that from which the exception is made]</span>. <span class="auth">(Mṣb.)</span> <span class="pb" id="Page_0028"></span>So too in the Ḳur lx. 11, accord. to the reading of Ibn-Mesʼood: <span class="auth">(Mṣb:)</span> but others there read <span class="ar">شَىْءٌ</span>, which may mean any one or any thing. <span class="auth">(Bḍ, Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaHadN_A8">
					<p><span class="ar">الأَحَدٌ</span>, <span class="auth">(Ḳ,)</span> as also <span class="ar long">يَوْمَ الأَحَدِ</span>, <span class="auth">(Ṣ, Mṣb,)</span> as a proper name, <span class="auth">(Mṣb,)</span> is applied to <em>A certain day;</em> <span class="auth">(Ḳ;)</span> <span class="add">[<em>Sunday;</em>]</span> <em>the first day of the week;</em> or, as some say, <span class="add">[i. e. as some term it,]</span> <em>the second of the week;</em> <span class="auth">(TA;)</span> for the Arabs are said, by IAạr, to have reckoned the Sabbath, or Saturday, as the first, though they called Sunday the first of the days: <span class="auth">(Mṣb in art. <span class="ar">جمع</span>:)</span> it is sing., and masc.: <span class="auth">(Lḥ:)</span> pl. <span class="add">[as above, i. e.]</span> <span class="ar">آحَادٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">أُحْدَانٌ</span>: <span class="auth">(Ḳ:)</span> or it has no pl. <span class="auth">(Ḳ: <span class="add">[but in the TA this last observation is very properly restricted, as relating only to <span class="ar">أَحَدٌ</span> as syn. with <span class="ar">وَاحِدٌ</span>, and as applied to any unknown person.]</span>)</span> In this sense, it has no dim. <span class="auth">(Sb, in Ṣ, art. <span class="ar">امس</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">احد</span> - Entry: <span class="ar">أَحَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaHadN_A9">
					<p><span class="ar">الآحَادُ</span> in lexicology signifies <em>What have been transmitted by some of the lexicologists, but not by such a number of them as cannot be supposed to have agreed to a falsehood:</em> what has been transmitted by this larger number is termed <span class="ar">مُتَوَاتِرُ</span>. <span class="auth">(Mz 3rd <span class="ar">نوع</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiHodae">
				<h3 class="entry"><span class="ar">إِحْدَى</span></h3>
				<div class="sense" id="IiHodae_A1">
					<p><span class="ar">إِحْدَى</span>: <a href="#OaHadN">fem. of <span class="ar">أَحَدٌ</span>, q. v.</a></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiHodaApN">
				<h3 class="entry"><span class="ar">إِحْدَاةٌ</span></h3>
				<div class="sense" id="IiHodaApN_A1">
					<p><span class="ar">إِحْدَاةٌ</span>: <a href="#OaHadN">fem. of <span class="ar">أَحَدٌ</span>, q. v.</a></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaHadiyBapN">
				<h3 class="entry"><span class="ar">أَحَدِيَّةٌ</span></h3>
				<div class="sense" id="OaHadiyBapN_A1">
					<p><span class="ar">أَحَدِيَّةٌ</span> The <em>unity</em> of God; <span class="auth">(Mṣb;)</span> as also <span class="ar">وَحْدَانِيَّةٌ</span>. <span class="auth">(L and Ḳ in art. <span class="ar">وحد</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuHaAda">
				<h3 class="entry"><span class="ar">أُحَادَ</span></h3>
				<div class="sense" id="OuHaAda_A1">
					<p><span class="ar">أُحَادَ</span> <span class="add">[accus. of <span class="ar">أُحَادُ</span>]</span> is imperfectly decl., because of its deviation from its original, <span class="auth">(Ṣ, Ḳ,)</span> both in form and in meaning; <span class="auth">(Ṣ;)</span> <span class="add">[being changed in form from <span class="ar">وَاحِدًا</span>, and in meaning from <span class="ar">ٱوَاحِدًا</span>: (<a href="#vulaAva">see <span class="ar">ثُلَاثَ</span></a>:)]</span> you say, <span class="ar long">جَاؤُوا أُحَادَ أُحَادَ</span>, <span class="add">[<span class="ar">احاد</span> being repeated for the purpose of corroboration,]</span> meaning, <em>They came one</em> <span class="add">[<em>and</em>]</span> <em>one, one</em> <span class="add">[<em>and</em>]</span> <em>one;</em> or <em>one</em> <span class="add">[<em>by</em>]</span> <em>one, one</em> <span class="add">[<em>by</em>]</span> <em>one.</em> <span class="auth">(Ṣ, Ḳ.)</span> <a href="#OuHaAdu">The dim. of <span class="ar">أُحَادُ</span></a> is <span class="arrow"><span class="ar">أُحَيِّدٌ↓</span></span>, perfectly decl., like <span class="ar">ثُلَيِّثٌ</span> <span class="add">[q. v.]</span>, &amp;c. <span class="auth">(Ṣ, in art. <span class="ar">ثلث</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuHayodN">
				<h3 class="entry"><span class="ar">أُحَيْدٌ</span></h3>
				<div class="sense" id="OuHayodN_A1">
					<p><span class="ar">أُحَيْدٌ</span> <a href="#OaHadN">dim. of <span class="ar">أَحَدٌ</span>, q. v.</a></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuHayBidN">
				<h3 class="entry"><span class="ar">أُحَيِّدٌ</span></h3>
				<div class="sense" id="OuHayBidN_A1">
					<p><span class="ar">أُحَيِّدٌ</span>: <a href="#OaHaAda">see <span class="ar">أَحَادَ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuHayodae">
				<h3 class="entry"><span class="ar">أُحَيْدَى</span></h3>
				<div class="sense" id="OuHayodae_A1">
					<p><span class="ar">أُحَيْدَى</span> <a href="#_iHodae">dim. of <span class="ar">إِحْدَى</span></a> <a href="#OaHadN">fem. of <span class="ar">أَحَدٌ</span>, q. v.</a></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0026.pdf" target="pdf">
							<span>Lanes Lexicon Page 26</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0027.pdf" target="pdf">
							<span>Lanes Lexicon Page 27</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0028.pdf" target="pdf">
							<span>Lanes Lexicon Page 28</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
