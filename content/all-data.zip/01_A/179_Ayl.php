<article class="root" id="Root_Ayl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/178_Ayk">ايك</a></span>
				<span class="ar">ايل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/180_Aym">ايم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Iiylu">
				<h3 class="entry"><span class="ar">إِيلُ</span></h3>
				<div class="sense" id="Iiylu_A1">
					<p><span class="ar">إِيلُ</span> a name of <em>God;</em> <span class="auth">(Lth, T, Ṣ, M, Ḳ;)</span> a Hebrew word; <span class="auth">(Lth, Ṣ;)</span> or Syriac: <span class="auth">(Ṣ:)</span> it <a href="#IilBu">is a dial. var. of <span class="ar">إِلُّ</span> <span class="add">[q. v.]</span></a>: or the latter may be an arabicized form of the former: <span class="auth">(Az, TA:)</span> Ibn-El-Kelbee says that <span class="ar">جَبْرَئِيلُ</span> and <span class="ar">مِيكَائِيلُ</span> and the like are similar to <span class="ar long">عَبْدُ ٱللّٰهِ</span> and <span class="ar long">عَبْدَ الرَّحْمَانِ</span>; <span class="auth">(M;)</span> <span class="add">[and J says,]</span> they are like <span class="ar long">عَبْدُ ٱللّٰهِ</span> and <span class="ar long">تَيْمُ ٱللّٰهِ</span>: <span class="auth">(Ṣ:)</span> so that <span class="ar">جَبْر</span> signifies “servant,” and is prefixed to <span class="ar">ايل</span>, governing it in the gen. case: <span class="auth">(M:)</span> but this is not a valid assertion; for were it so, such names would be perfectly decl.: <span class="auth">(M in art. <span class="ar">ال</span>:)</span> Suh says, in the R, that <span class="ar">جِبرئيل</span> is Syriac, and means <span class="ar long">عَبْدُ الرَّحْمَانِ</span>, or <span class="ar long">عَبْدُ العزِيزِ</span>, as is related on the anthority of I’Ab: that most persons hold <span class="ar">ايل</span> in this case to be a name of God: but that some hold names of this kind to be constructed inversely, after the manner of the language of the 'Ajam; <span class="ar">ايل</span> meaning <em>servant.</em> <span class="auth">(TA. <span class="add">[See what is said of <span class="ar">إِلُّ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiylapN.1">
				<h3 class="entry"><span class="ar">إِيلَةٌ</span></h3>
				<div class="sense" id="IiylapN.1_A1">
					<p><span class="ar">إِيلَةٌ</span>: <a href="index.php?data=01_A/163_Awl">see art. <span class="ar">اول</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oayoluwlu">
				<h3 class="entry"><span class="ar">أَيْلُولُ</span></h3>
				<div class="sense" id="Oayoluwlu_A1">
					<p><span class="ar">أَيْلُولُ</span> <span class="add">[written by some <span class="ar">إِيلُولُ</span>]</span> <em>One of the Greek</em> <span class="add">[or <em>Syrian</em>]</span> <em>months;</em> <span class="auth">(T,* M, Ḳzw;)</span> <em>the last thereof</em> <span class="add">[<em>corresponding with September, O. Ṣ.</em>]</span>. <span class="auth">(Ḳzw.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyaAlN.1">
				<h3 class="entry"><span class="ar">إِيَالٌ</span> / 
							<span class="ar">إِيَالَةٌ</span> / 
							<span class="ar">أَيِّلٌ</span> / 
							<span class="ar">أُيَّلٌ</span> / 
							<span class="ar">إِيَّلٌ</span></h3>
				<div class="sense" id="IiyaAlN.1_A1">
					<p><span class="ar">إِيَالٌ</span>: <span class="ar">إِيَالَةٌ</span>: <span class="ar">أَيِّلٌ</span>: <span class="ar">أُيَّلٌ</span>: <span class="ar">إِيَّلٌ</span>:<a href="index.php?data=01_A/163_Awl">see art. <span class="ar"></span>Awl</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
