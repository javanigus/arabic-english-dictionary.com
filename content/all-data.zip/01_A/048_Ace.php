<article class="root" id="Root_Ace">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/047_Acn">اذن</a></span>
				<span class="ar">اذى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/049_Ar">ار</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ace_1">
				<h3 class="entry">1. ⇒ <span class="ar">أذى</span></h3>
				<div class="sense" id="Ace_1_A1">
					<p><span class="ar">أَذِىَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْذَىُ</span>}</span></add>, inf. n. <span class="ar">أَذًى</span>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> in <span class="add">[some of]</span> the copies of the Ḳ written <span class="ar">أَذًا</span>, and so by IB, <span class="auth">(TA,)</span> and <span class="ar">أَذَآءٌ</span>, <span class="auth">(CK, <span class="add">[but not found by me in any MṢ. copy of the Ḳ nor in any other lexicon,]</span>)</span> and, accord. to IB, <span class="ar">أَذَاةٌ</span> and <span class="ar">أَذِيَّةٌ</span>, <span class="auth">(TA,)</span> or these two are simple substs.; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar">تأذّى↓</span></span>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> <span class="add">[<em>He was,</em> or <em>became, annoyed, molested, harmed,</em> or <em>hurt;</em>]</span> <em>he experienced,</em> or <em>suffered, slight evil,</em> <span class="add">[i. e., <em>annoyance, molestation, harm,</em> or <em>hurt,</em>]</span> <em>less than what is termed</em> <span class="ar">ضَرَر</span>; <span class="auth">(El-Khaṭṭábee;)</span> or <em>he experienced,</em> or <em>suffered, what was disagreeable,</em> or <em>hateful,</em> or <em>evil,</em> <span class="auth">(Mṣb, Ḳ,)</span> <em>in a small degree;</em> <span class="auth">(Ḳ;)</span> <span class="ar">بِهِ</span> <span class="add">[<em>by him,</em> or <em>it</em>]</span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> <span class="add">[and <span class="ar">مِنْهُ</span> <em>from him,</em> or <em>it:</em>]</span> <span class="arrow"><span class="ar">التَّأَذِّى↓</span></span> signifies <em>the being affected by what is termed</em> <span class="ar">الأَذَى</span> <span class="add">[i. e. <em>what annoys, molests, harms,</em> or <em>hurts, one</em>]</span>: and also <em>the showing the effect thereof;</em> which is forbidden by the saying of ʼOmar, <span class="arrow"><span class="ar long">إِيَّاكَ وَالتَّأَذِّى↓ بِالنَّاسِ</span></span> <span class="add">[<em>Avoid thou,</em> or <em>beware thou of, showing the being annoyed, molested, harmed,</em> or <em>hurt, by men</em>]</span>; for this is what is within one's power. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ace_1_A2">
					<p>Also, aor. and inf. n. as above, <em>It</em> <span class="auth">(a thing)</span> <em>was unclean, dirty,</em> or <em>filthy.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ace_4">
				<h3 class="entry">4. ⇒ <span class="ar">آذى</span></h3>
				<div class="sense" id="Ace_4_A1">
					<p><span class="ar">آذى</span> signifies <span class="ar long">فَعَلَ الأَذَى</span> <span class="add">[<em>He did what annoyed, molested, harmed,</em> or <em>hurt</em>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ace_4_A2">
					<p>And <span class="ar">آذَاهُ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">يُؤْذِيهِ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">إِيذَآءٌ</span> <span class="auth">(T, IB, Mṣb)</span> and <span class="add">[quasi-inf. n.]</span> <span class="ar">أَذِيَّةٌ</span>, <span class="auth">(T,)</span> or <span class="ar">أَذَّى</span> and <span class="ar">أَذَاةٌ</span> and <span class="ar">أَذِيَّةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> but IB refuses his assent to this, saying that these three are inf. ns. of <span class="ar">أَذِىَ</span>, and MF says of <span class="ar">إِيذَآءٌ</span>, which is expressly disallowed by the author of the Ḳ, though he himself uses it, that others assert it to have been heard and transmitted, and to be required by rule, but he adds that he had searched for examples of it in the language of the Arabs, and investigated their prose and their poetry, without finding this word; <span class="auth">(TA;)</span> <span class="add">[<em>He,</em> or <em>it, annoyed him, molested him, harmed him,</em> or <em>hurt him;</em> or]</span> <em>he did what was disagreeable,</em> or <em>hateful,</em> or <em>evil, to him.</em> <span class="auth">(Bḍ in xxxiii. 53, Mṣb.)</span> It is said in the Ḳur <span class="add">[xxxiii. 47]</span>, <span class="ar long">وَدَعْ أَذَاهُمْ</span>, meaning <em>And leave thou the requiting of them</em> until thou receive a command respecting them; <span class="auth">(M, Bḍ, Jel;)</span> namely, the hypocrites: <span class="auth">(M:)</span> or <em>leave thou unregarded their doing to thee what is</em> <span class="add">[<em>annoying, molesting, harmful, hurtful,</em> or]</span> <em>disagreeable,</em>, &amp;c., <em>to thee.</em> <span class="auth">(Bḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ace_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأذّى</span></h3>
				<div class="sense" id="Ace_5_A1">
					<p><a href="#Ace_1">see 1</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OacBae">
				<h3 class="entry"><span class="ar">أَذَّى</span></h3>
				<div class="sense" id="OacBae_A1">
					<p><span class="ar">أَذَّى</span> <a href="#Ace_1">inf. n. of 1</a>. <span class="auth">(T, M, Mṣb, Ḳ.)</span> <span class="add">[As a simple subst., <em>A state of annoyance</em> or <em>molestation.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذَّى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OacBae_A2">
					<p>And <span class="add">[<em>Annoyance, molestation, harm,</em> or <em>hurt:</em> quasi-]</span> <a href="#Ace_4">inf. n. of <span class="ar">آذَاهُ</span></a>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذَّى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OacBae_A3">
					<p>It signifies also, <span class="add">[like<span class="arrow"><span class="ar">أَذِيَّةٌ↓</span></span> and<span class="arrow"><span class="ar">أَذَاةٌ↓</span></span>,]</span> <span class="ar long">كُلُّ مَا تَأْذَّيْتَ</span> <span class="add">[<em>Anything by which thou art annoyed, molested, harmed,</em> or <em>hurt</em>]</span>; <span class="auth">(T;)</span> or <span class="ar long">مَا يُؤْذِيكَ</span> <span class="add">[<em>a thing that annoys, molests, harms,</em> or <em>hurts thee</em>]</span>: <span class="auth">(Mgh:)</span> or <em>a slight evil; less than what is termed</em> <span class="ar">ضَرَر</span>. <span class="auth">(El-Khaṭṭábee.)</span> You say, <span class="ar long">أَمَاطَ الأَذَى عَنِ الطَّرِيقِ</span> <em>He removed,</em> or <em>put away,</em> or <em>put at a distance, what was hurtful from the road,</em> or <em>way.</em> <span class="auth">(Mgh and TA in art. <span class="ar">ميط</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذَّى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OacBae_A4">
					<p>Also <em>A thing held to be unclean, dirty,</em> or <em>filthy:</em> so in the Ḳur ii. 222. <span class="auth">(Mgh, Mṣb.)</span> <span class="add">[<em>Filth; impurity:</em> often used in this sense in books on practical law.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OacK">
				<h3 class="entry"><span class="ar">أَذٍ</span></h3>
				<div class="sense" id="OacK_A1">
					<p><span class="ar">أَذٍ</span> <em>Experiencing,</em> or <em>suffering,</em> <span class="add">[<em>annoyance, molestation, harm, hurt,</em> or]</span> <em>what is disagreeable,</em> or <em>hateful,</em> or <em>evil,</em> <span class="auth">(M,* Ḳ,* Mṣb,)</span> <em>in a great,</em> or <em>vehement, degree;</em> <span class="auth">(M, Ḳ;)</span> applied to a man; <span class="auth">(M, Mṣb;)</span> as also<span class="arrow"><span class="ar">أَذِىٌّ↓</span></span>: <span class="auth">(M, Ḳ:)</span> and both signify <em>the contr.;</em> i. e. <em>doing what is disagreeable,</em> or <em>hateful,</em> or <em>evil, in a great,</em> or <em>vehement, degree.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OacK_A2">
					<p>Also, applied to a camel, <em>That will not remain still in one place, by reason of a natural disposition, not from pain,</em> <span class="auth">(El-Umawee, AʼObeyd, Ṣ, M, Ḳ,)</span> <em>nor disease;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">أَذىٌّ↓</span></span>: <span class="auth">(M:)</span> fem. of the former <span class="ar">أَذِيَةٌ</span>; <span class="auth">(El-Umawee, &amp;c.;)</span> and of the latter <span class="arrow"><span class="ar">أَذِيَّةٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IicaA.1">
				<h3 class="entry"><span class="ar">إِذَا</span> / <span class="ar">إِذًا</span></h3>
				<div class="sense" id="IicaA.1_A1">
					<p><span class="ar">إِذَا</span> and <span class="ar">إِذًا</span>: <a href="index.php?data=01_A/045_AcA">see art. <span class="ar">اذا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OacaApN">
				<h3 class="entry"><span class="ar">أَذَاةٌ</span></h3>
				<div class="sense" id="OacaApN_A1">
					<p><span class="ar">أَذَاةٌ</span> <a href="#Ace_1">an inf. n. of 1</a>. <span class="auth">(IB.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OacaApN_A2">
					<p><a href="#Ace_4">And <span class="add">[quasi-]</span> inf. n. of <span class="ar">آذَاهُ</span></a>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OacaApN_A3">
					<p><a href="#OacBae">See also <span class="ar">أَذَّى</span></a> <a href="#OaciyBapN">and <span class="ar">أَذِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaciyBN">
				<h3 class="entry"><span class="ar">أَذِيٌّ</span> / <span class="ar">أَذِيَّةٌ</span></h3>
				<div class="sense" id="OaciyBN_A1">
					<p><span class="ar">أَذِيٌّ</span>, and <span class="ar">أَذِيَّةٌ</span> as its fem.: <a href="#OacK">see <span class="ar">أَذٍ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaciyBapN">
				<h3 class="entry"><span class="ar">أَذِيَّةٌ</span></h3>
				<div class="sense" id="OaciyBapN_A1">
					<p><span class="ar">أَذِيَّةٌ</span> <a href="#Ace_1">an inf. n. of 1</a>. <span class="auth">(IB.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaciyBapN_A2">
					<p><a href="#Ace_4">And <span class="add">[quasi-]</span> inf. n. of <span class="ar">آذَاهُ</span></a>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اذى</span> - Entry: <span class="ar">أَذِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaciyBapN_A3">
					<p>And a subst. from <span class="ar">آذَاهُ</span>; <span class="auth">(Mṣb;)</span> or, as also<span class="arrow"><span class="ar">أَذَاةٌ↓</span></span>, a subst. from <span class="ar">أَذِىَ</span> and <span class="ar">تَأَذَّى</span>; <span class="auth">(M, Ḳ;)</span> signifying <em>A thing that is disagreeable,</em> or <em>hateful,</em> or <em>evil, in a small degree.</em> <span class="auth">(Ḳ.)</span> <a href="#OacFe">See also <span class="ar">أَذًى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="McieBN">
				<h3 class="entry"><span class="ar">آذِىٌّ</span></h3>
				<div class="sense" id="McieBN_A1">
					<p><span class="ar">آذِىٌّ</span>, <span class="auth">(Ṣ, M, Ḳ, &amp;c.,)</span> with medd and teshdeed, <span class="auth">(TA, <span class="add">[in the CK, erroneously, <span class="ar">اَذِىّ</span>,]</span>)</span> <em>Waves</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>of the sea:</em> <span class="auth">(Ṣ:)</span> or <em>vehement waves:</em> <span class="auth">(TA:)</span> or the <span class="ar">أَطْبَاق</span> <span class="add">[app. meaning <em>rollers,</em> because they fall over like folds,]</span> <em>which the wind raises from the surface of the water, less than</em> (<span class="ar">دُونَ</span> <span class="add">[but this sometimes signifies <em>above</em>]</span>) <em>what are termed</em> <span class="ar">مَوْج</span>: <span class="auth">(ISh, TA:)</span> pl. <span class="ar">أَوَاذِىُّ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0044.pdf" target="pdf">
							<span>Lanes Lexicon Page 44</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
