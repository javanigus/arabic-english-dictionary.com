<article class="root" id="Root_Awf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/160_Aws">اوس</a></span>
				<span class="ar">اوف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/162_Awq">اوق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Awf_1">
				<h3 class="entry">1. ⇒ <span class="ar">أوف</span> ⇒ <span class="ar">آف</span></h3>
				<div class="sense" id="Awf_1_A1">
					<p><span class="ar long">آفَتِ البِلَادُ</span>, aor. <span class="ar">تَؤُوفُ</span>, inf. n. <span class="ar">أَوْفٌ</span> and <span class="ar">آفَةٌ</span> <span class="auth">(M, TA)</span> and <span class="ar">أُوُوفٌ</span>, <span class="auth">(M,)</span> or <span class="ar">أُؤُوفٌ</span>, <span class="auth">(TA,)</span> <em>The country,</em> or <em>countries, had therein what is termed</em> <span class="ar">آفَة</span> <span class="add">[i. e. <em>a blight</em> or <em>blast</em> or <em>the like,</em> or <em>a pest</em> or <em>plague</em> or <em>the like</em>]</span>. <span class="auth">(M, TA.)</span> And <span class="ar long">إِيفَ الطَّعَامُ</span>, <span class="auth">(Ibn Buzurj, T,)</span> or <span class="ar">الزَّرْعُ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">الشَّىْءُ</span>, with the verb in the pass. form, <span class="auth">(Mṣb,)</span> like <span class="ar">قِيلَ</span>, <span class="auth">(Ḳ,)</span> <em>The wheat,</em> or <em>seed-produce,</em> or <em>thing, became affected,</em> or <em>smitten, with what is termed</em> <span class="ar">آفَة</span> <span class="add">[i. e. <em>a blight, blast, taint, canker,</em> or <em>the like</em>]</span>. <span class="auth">(T, Ḳ, Mṣb.)</span> And <span class="ar long">آفَ القَوْمُ</span>, <span class="auth">(M, TA,)</span> and <span class="ar">أُوفُوا</span>, <span class="auth">(Ḳ,)</span> thus in a correct copy of the ʼEyn, <span class="auth">(TA,)</span> and <span class="ar">إِيفُوا</span>, <span class="auth">(Lth, T, Ḳ,)</span> and <span class="ar">أُفُوا</span>, <span class="auth">(Ḳ, TA, <span class="add">[in the CK <span class="ar">اُفِّفُوا</span>,]</span>)</span> and <span class="ar">إِفُوا</span>, <span class="auth">(Lth, T, Ḳ, <span class="add">[in the CK <span class="ar">اُفُوا</span>,]</span>)</span> the last, namely, <span class="ar">إِفُوا</span>, with the <span class="ar">ا</span> termed <span class="ar">مُمَالَة</span>, having a quiescent letter <span class="add">[i. e. <span class="ar">ى</span>]</span> rendered apparent by utterance but not by writing, between it and the <span class="ar">ف</span>, <span class="auth">(T, Ḳ,* <span class="add">[in which is a strange omission, of the words <span class="ar long">سَاكِنٌ بَيَّنَهُ اللَّفْظُ لَا الخَطُّ</span> as in the T, or <span class="ar long">سَاكِنَةٌ يُبَيِّنُهَا الخ</span> as in the TA,]</span> TA,)</span> <em>The people became affected,</em> or <em>smitten, with what is termed</em> <span class="ar">آفَة</span> <span class="add">[i. e. <em>a pest</em> or <em>plague</em> or <em>the like</em>]</span>. <span class="auth">(Lth, T, M, Ḳ.)</span> Lth says, in this case one says <span class="ar">إِفُوا</span>, and in one dial. <span class="ar">إِيفُوا</span>: <span class="auth">(T:)</span> in several copies of his book, in one dial. <span class="ar">أُفِّفُوا</span>, with two distinct <span class="ar">ف</span> s, of which the former is with teshdeed: but in some copies as mentioned just before. <span class="auth">(Ṣgh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MfapN">
				<h3 class="entry"><span class="ar">آفَةٌ</span></h3>
				<div class="sense" id="MfapN_A1">
					<p><span class="ar">آفَةٌ</span> <span class="add">[<em>A blight, blast, taint, canker, disease, bane, pest, plague,</em> or <em>the like; any evil affection; an evil; a cause of mischief</em> or <em>harm</em> or <em>injury; anything that is noxious</em> or <em>destructive; a calamity;</em>]</span> <em>i. q.</em> <span class="ar">عَاهَةٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> i. e. <span class="auth">(Mṣb, <span class="add">[in the Ḳ “or,”]</span>)</span> <em>an accident that mars,</em> or <em>corrupts, that which it affects,</em> or <em>befalls,</em> or <em>smites:</em> <span class="auth">(T, M, O, Mṣb, Ḳ:)</span> pl. <span class="ar">آفَاتٌ</span>. <span class="auth">(Mṣb, Ḳ.)</span> <span class="add">[<a href="#Awf_1">See 1</a>.]</span> One says, <span class="ar long">آفَهُ الظَّرْفِ الصَّلَفُ وَآفَةُ العِلْمِ النِّسعيَانُ</span> <span class="add">[<em>The bane of elegance in manners,</em> or <em>the like, is the overpassing the due limits therein, and arrogating to oneself superiority therein, through pride; and the bane of science is forgetfulness</em>]</span>. <span class="auth">(T.)</span> And it is said in a trad., <span class="ar long">آفَةُ الحَدِيثِ الكَذِبُ وَآفَةُ العِلْمِ النِّسْيَانُ</span> <span class="add">[<em>The bane of discourse is lying; and the bane of science is forgetfulness</em>]</span>. <span class="auth">(TA.)</span> And hence the saying, <span class="ar long">لِكُلِّ شَىْءٍ آفَةٌ وَلِلْعِلْم آفَاتٌ</span> <span class="add">[<em>To everything there is a bane; and to science there are banes</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maWuwfN">
				<h3 class="entry"><span class="ar">مَؤُوفٌ</span></h3>
				<div class="sense" id="maWuwfN_A1">
					<p><span class="ar">مَؤُوفٌ</span>, <span class="auth">(Ks, T, Ṣ, M, Mṣb, Ḳ,)</span> originally <span class="ar">مَأْوُوفٌ</span>, <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar">مَئِيفٌ↓</span></span>, <span class="auth">(Ibn-Buzurj, T, Ḳ,)</span> <em>Affected,</em> or <em>smitten, with what is termed</em> <span class="ar">آفَة</span>; <span class="auth">(T, Ṣ, M, &amp;c.;)</span> applied to wheat, <span class="auth">(Ks, Ibn-Buzurj, T, M,)</span> or seed-produce, <span class="auth">(Ṣ, Ḳ,)</span>, &amp;c. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maYiyfN">
				<h3 class="entry"><span class="ar">مَئِيفٌ</span></h3>
				<div class="sense" id="maYiyfN_A1">
					<p><span class="ar">مَئِيفٌ</span>: <a href="#maWuwfN">see <span class="ar">مَؤُوفٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0125.pdf" target="pdf">
							<span>Lanes Lexicon Page 125</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
