<article class="root" id="Root_AXr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/088_AXb">اشب</a></span>
				<span class="ar">اشر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/090_AXf">اشف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AXr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أشر</span></h3>
				<div class="sense" id="AXr_1_A1">
					<p><span class="ar">أَشَرَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْشِرُ</span>}</span></add>, <span class="auth">(ISk, MṢ,)</span> or <span class="ar">ـَ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">أَشْرٌ</span>, <span class="auth">(Mṣb,)</span> <em>He divided</em> <span class="add">[or <em>sawed</em>]</span> a piece of wood <span class="auth">(ISk, Mṣb, Ḳ)</span> with the <span class="ar">مِئْشَار</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> as also <span class="ar">وَشَرَ</span> and <span class="ar">نَشَرَ</span>. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AXr_1_A2">
					<p><span class="ar long">أَشَرَتْ أَسْنَانَهَا</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْشِرُ</span>}</span></add> <span class="add">[or, accord. to the Mṣb, it seems to be <span class="ar">ـُ</span>,]</span> inf. n. <span class="ar">أَشْرٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">أَشَّرَتْهَا↓</span></span> <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَأْشِيرٌ</span>; <span class="auth">(Ṣ;)</span> <em>She</em> <span class="auth">(a woman, TA)</span> <em>made her teeth serrated,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and sharpened their extremities,</em> <span class="auth">(Ṣ,)</span> to render them like those of a young person: but a curse is denounced in a trad. against her who does this. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=27_w/124_wXr">See also art. <span class="ar">وشر</span></a>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AXr_1_B1">
					<p>, <span class="ar">أَشِرَ</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْشَرُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَشَرٌ</span> <span class="auth">(Ṣ, A, Mṣb,)</span> <em>He exulted,</em> or <em>exulted greatly,</em> or <em>excessively; and behaved insolently and unthankfully,</em> or <em>ungratefully:</em> <span class="auth">(Ṣ,* A,* Mṣb, Ḳ,* TA:)</span> or <em>he exulted by reason of wealth, and behaved with pride, and self-conceitedness, and boastfulness, and want of thankfulness:</em> or <em>he behaved with the utmost exultation, &amp;c.: or he rejoiced, and rested his mind upon things agreeable with natural desire.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#baTira">See <span class="ar">بَطِرَ</span></a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AXr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أشّر</span></h3>
				<div class="sense" id="AXr_2_A1">
					<p><a href="#AXr_1">see 1</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AXr_8">
				<h3 class="entry"><span class="add">[<itype>8.</itype> <span class="new">{<span class="ar">ائتشر</span>}</span>]</span></h3>
				<div class="sense" id="AXr_8_A1">
					<p><span class="add">[<span class="ar">ٱئْتَشَرَتْ</span>, written with the disjunctive alif <span class="ar">ايتَشَرَتْ</span> <em>She invited another to make her teeth serrated and to sharpen their extremities;</em> as also<span class="arrow"><span class="ar">استأشرت↓</span></span> See the act. part. ns. below: <a href="#AstwXrt">and see also <span class="ar">استوشرت</span></a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AXr_10">
				<span class="pb" id="Page_0062"></span>
				<h3 class="entry">10. ⇒ <span class="ar">استأشر</span></h3>
				<div class="sense" id="AXr_10_A1">
					<p><a href="#AXr_8">see 8</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaXorN">
				<h3 class="entry"><span class="ar">أَشْرٌ</span></h3>
				<div class="sense" id="OaXorN_A1">
					<p><span class="ar">أَشْرٌ</span> <a href="#OaXirN">see <span class="ar">أَشِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaXarN">
				<h3 class="entry"><span class="ar">أَشَرٌ</span></h3>
				<div class="sense" id="OaXarN_A1">
					<p><span class="ar">أَشَرٌ</span> <a href="#OaXirN">see <span class="ar">أَشِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaXurN">
				<h3 class="entry"><span class="ar">أَشُرٌ</span></h3>
				<div class="sense" id="OaXurN_A1">
					<p><span class="ar">أَشُرٌ</span> <a href="#OaXirN">see <span class="ar">أَشِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaXirN">
				<h3 class="entry"><span class="ar">أَشِرٌ</span></h3>
				<div class="sense" id="OaXirN_A1">
					<p><span class="ar">أَشِرٌ</span> <span class="auth">(Ṣ, A, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَشُرٌ↓</span></span> and<span class="arrow"><span class="ar">أَشْرٌ↓</span></span> and<span class="arrow"><span class="ar">أَشَرٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">أَشْرَانُ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> <em>Exulting,</em> or <em>exulting greatly,</em> or <em>excessively; and behaving insolently and unthankfully,</em> or <em>ungratefully:</em> <span class="auth">(Ṣ,* A,* Mṣb, Ḳ,* TA:)</span> or <em>exulting by reason of wealth, and behaving with pride, and self-conceitedness, and boastfulness, and want of thankfulness:</em> or <em>behaving with the utmost exultation, &amp;c.:</em> or <em>rejoicing, and resting the mind upon things agreeable with natural desire:</em> <span class="auth">(TA:)</span> pl. <span class="add">[of the first]</span> <span class="ar">أَشِرُونَ</span> and <span class="add">[of the second]</span> <span class="ar">أَشُرُونَ</span> <span class="auth">(L, Ḳ)</span> and <span class="add">[of the first four]</span> <span class="ar">أُشُرٌ</span> <span class="auth">(Ḳ <span class="add">[accord. to the TA, but not in the copies of the Ḳ in my hands,]</span>)</span> and <span class="auth">(of <span class="ar">أَشْرَانُ</span> TA)</span> <span class="ar">أَشْرَى</span> <span class="auth">(Ḳ)</span> and <span class="ar">أُشَارَى</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">أَشَارَى</span> <span class="auth">(Ḳ.)</span> One says, <span class="ar long">أَشِرٌ أَفِرٌ</span> and<span class="arrow"><span class="ar long">أَشْرَانُ↓ أَفْرَانُ</span></span>, using the latter word in each instance as an imitative sequent. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">أَشِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaXirN_A2">
					<p><span class="ar long">بَرْقٌ أَشِرٌ</span> ‡ <em>Lightning flashing repeatedly to and fro.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">أَشِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaXirN_A3">
					<p><span class="ar long">نَبْتٌ أَشِرٌ</span> ‡ <em>A plant,</em> or <em>herbage, extending beyond its proper bounds.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuXarN">
				<h3 class="entry"><span class="ar">أُشَرٌ</span></h3>
				<div class="sense" id="OuXarN_A1">
					<p><span class="ar">أُشَرٌ</span>: <a href="#OuXurN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuXurN">
				<h3 class="entry"><span class="ar">أُشُرٌ</span></h3>
				<div class="sense" id="OuXurN_A1">
					<p><span class="ar long">بِأَسْنَانِهِ أُشُرٌ</span> and<span class="arrow"><span class="ar">أُشَرٌ↓</span></span> and<span class="arrow"><span class="ar">أُشُورٌ↓</span></span> <span class="auth">(Ṣ, Ḳ,)</span> which last is a pl., <span class="auth">(Ḳ,)</span> <em>In his teeth is a serration,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and a sharpness of the extremities</em> <span class="add">[such as is seen in the teeth of young persons]</span>; <span class="auth">(Ṣ;)</span> which is sometimes natural and sometimes artificial; <span class="auth">(Ḳ;)</span> and <span class="add">[naturally]</span> only in the teeth of young persons. <span class="auth">(TA.)</span> Hence the prov., <span class="ar long">أَعْيَيْتَنِى بِأُشُرِ فَكَيْفَ بِدُرْدُرٍ</span>. <span class="auth">(Ṣ.)</span> <span class="add">[<a href="index.php?data=08_d/039_dr">See art. <span class="ar">در</span></a>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">أُشُرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuXurN_A2">
					<p><span class="ar long">أُشُرُ المِنْجَلِ</span> ‡ <em>The teeth of the reaping-hook,</em> or <em>sickle.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuXorapN">
				<h3 class="entry"><span class="ar">أُشْرَةٌ</span> / <span class="ar">أُشْرَتَانِ</span></h3>
				<div class="sense" id="OuXorapN_A1">
					<p><span class="ar">أُشْرَةٌ</span> and its dual (<span class="ar">أُشْرَتَانِ</span>): <a href="#AXirN">see <span class="ar">آشِرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaXoraMCu">
				<h3 class="entry"><span class="ar">أَشْرَآءُ</span></h3>
				<div class="sense" id="OaXoraMCu_A1">
					<p><span class="ar long">أُمْنِيَّةٌ أَشْرَآءُ</span> <em>A very exulting wish:</em> occurring in the Mo'allakah of El-Hárith Ibn-Hillizeh. <span class="auth">(EM p. 272.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaXoraAnu">
				<h3 class="entry"><span class="ar">أَشْرَانُ</span></h3>
				<div class="sense" id="OaXoraAnu_A1">
					<p><span class="ar">أَشْرَانُ</span>: <a href="#OaXirN">see <span class="ar">أَشِرٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuXuwrN">
				<h3 class="entry"><span class="ar">أُشُورٌ</span></h3>
				<div class="sense" id="OuXuwrN_A1">
					<p><span class="ar">أُشُورٌ</span> <a href="#OuXurN">see <span class="ar">أُشُرٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="MXirN">
				<h3 class="entry"><span class="ar">آشِرٌ</span></h3>
				<div class="sense" id="MXirN_A1">
					<p><span class="ar">آشِرٌ</span> <em>Dividing</em> <span class="add">[or <em>sawing</em>]</span>, or one <em>who divides</em> <span class="add">[or <em>saws</em>]</span>, wood, with the <span class="ar">مِئْشَار</span> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">آشِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MXirN_A2">
					<p><span class="add">[Hence,]</span> The <em>prickles</em> <span class="add">[or <em>serrated parts</em>]</span> of the shanks of the locust; <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">تَآشِيرُ↓</span></span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">آشِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MXirN_A3">
					<p>Also, and<span class="arrow"><span class="ar">أُشْرَةٌ↓</span></span> and<span class="arrow"><span class="ar">مِئْشَارٌ↓</span></span>, <em>A joint</em> (<span class="ar">عُقْدَةٌ</span>) <em>at the extremity of the tail of the locust, like two claws;</em> <span class="auth">(Ḳ;)</span> which two things are also called <span class="arrow"><span class="ar">أُشْرَتَانِ↓</span></span> and<span class="arrow"><span class="ar">مِئْشَارَانِ↓</span></span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">آشِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MXirN_A4">
					<p><span class="ar">آشِرَةٌ</span> A woman <em>who sharpens the extremities of her teeth</em> <span class="add">[<em>and makes them serrated:</em> <a href="#AXr_1">see 1</a>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">آشِرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MXirN_B1">
					<p><span class="ar long">يَدٌ آشِرَةٌ</span> <em>An arm,</em> or <em>a hand, sawn off; i. q.</em> <span class="arrow"><span class="ar">مَأْشُورَةٌ↓</span></span>: <span class="auth">(ISk, Ṣ, Mṣb, Ḳ:*)</span> like <span class="ar long">عِيشَةٌ رَاضِيَةٌ</span> in the sense of <span class="ar">مَرْضِيَةٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOoXiyrN">
				<h3 class="entry"><span class="ar">تَأْشِيرٌ</span> / <span class="ar">تَأْشِيرَةٌ</span></h3>
				<div class="sense" id="taOoXiyrN_A1">
					<p><span class="ar">تَأْشِيرٌ</span> or <span class="ar">تَأْشِيرَةٌ</span>, as in different Lexicons, <span class="auth">(TA,)</span> <span class="add">[the former in the Ḳ,]</span> The <em>thing with which the locust bites:</em> pl. <span class="ar">تَآشِيرُ</span> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">تَأْشِيرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taOoXiyrN_A2">
					<p><a href="#AXirN">See also the pl. voce <span class="ar">آشِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaXBarN">
				<h3 class="entry"><span class="ar">مُؤَشَّرٌ</span></h3>
				<div class="sense" id="muWaXBarN_A1">
					<p><span class="ar">مُؤَشَّرٌ</span> Anything <span class="auth">(TA)</span> <em>made thin</em> <span class="add">[<em>and serrated</em>]</span>. <span class="auth">(Ḳ.)</span> <span class="add">[Hence,]</span> <span class="ar long">ثَغْرٌ مُؤَشَّرٌ</span> <em>A front tooth serrated and sharpened at the extremity.</em> <span class="auth">(TA.)</span> And hence, <span class="auth">(TA,)</span> <span class="ar long">مُؤَشَّرُ العَضُدَيْنِ</span> is applied to the beetle <span class="add">[as meaning <em>Having the fore shanks formed thin, and serrated</em>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYoXaArN">
				<h3 class="entry"><span class="ar">مِئْشَارٌ</span></h3>
				<div class="sense" id="miYoXaArN_A1">
					<p><span class="ar">مِئْشَارٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.)</span> <span class="add">[<em>A saw;</em>]</span> <em>an instrument with which wood is divided;</em> <span class="auth">(Mṣb, Ḳ)</span> as also <span class="ar">مِيشَارٌ</span>, from <span class="ar">وَشَرَ</span>; <span class="auth">(Mṣb, TA;)</span> and <span class="ar">مِنْشَارٌ</span>: <span class="auth">(TA:)</span> pl. <span class="ar">مَآشِيرُ</span>. <span class="auth">(ISk, Mṣb, TA.)</span></p>	
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">مِئْشَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="miYoXaArN_A2">
					<p><a href="#AXirN">See also this word and its dual voce <span class="ar">آشِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoXuwrN">
				<h3 class="entry"><span class="ar">مَأْشُورٌ</span></h3>
				<div class="sense" id="maOoXuwrN_A1">
					<p><span class="ar">مَأْشُورٌ</span> Wood <em>divided</em> <span class="add">[or <em>sawn</em>]</span> with the <span class="ar">مِئْشَار</span> <span class="auth">(Mṣb.)</span> <a href="#AXirN">See also <span class="ar">آشِرٌ</span></a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشر</span> - Entry: <span class="ar">مَأْشُورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOoXuwrN_A2">
					<p><span class="ar">مَأْشُورَةٌ</span> A woman <em>who has the extremities of her teeth sharpened</em> <span class="add">[<em>and serrated artificially:</em> <a href="#AXr_1">see 1</a>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYoXiyrN">
				<h3 class="entry"><span class="ar">مِئْشِيرٌ</span></h3>
				<div class="sense" id="miYoXiyrN_A1">
					<p><span class="ar">مِئْشِيرٌ</span>, applied alike to the male and the female, <span class="auth">(Ṣ,)</span> to a she-camel and a courser, <span class="auth">(Ṣ, Ḳ,)</span> and a man and a woman, <span class="auth">(TA,)</span> <em>Brisk; lively; sprightly.</em> <span class="auth">(Ṣ,* Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotaXirapN">
				<h3 class="entry"><span class="ar">مُؤْتَشِرَةٌ</span></h3>
				<div class="sense" id="muWotaXirapN_A1">
					<p><span class="ar">مُؤْتَشِرَةٌ</span> and<span class="arrow"><span class="ar">مُسْتَأْشِرَةٌ↓</span></span> A woman <em>who invites</em> <span class="add">[<em>another</em> ]</span> <em>to make her teeth serrated</em> <span class="add">[<em>and to sharpen their extremities:</em> <a href="#AXr_1">see 1</a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="musotaOoXirapN">
				<h3 class="entry"><span class="ar">مُسْتَأْشِرَةٌ</span></h3>
				<div class="sense" id="musotaOoXirapN_A1">
					<p><span class="ar">مُسْتَأْشِرَةٌ</span>: <a href="#muWotaXirapN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0061.pdf" target="pdf">
							<span>Lanes Lexicon Page 61</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0062.pdf" target="pdf">
							<span>Lanes Lexicon Page 62</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
