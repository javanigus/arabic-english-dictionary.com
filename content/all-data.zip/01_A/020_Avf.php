<article class="root" id="Root_Avf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/019_Avr">اثر</a></span>
				<span class="ar">اثف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/021_Avkl">اثكل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Avf_1">
				<h3 class="entry">1. ⇒ <span class="ar">أثف</span></h3>
				<div class="sense" id="Avf_1_A1">
					<p><span class="ar long">أَثَفَ القِدْرَ</span>: <a href="#Avf_2">see 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avf_1_B1">
					<p><span class="ar">أَثَفَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْثِفُ</span>}</span></add>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَثْفٌ</span>, <span class="auth">(T, M,)</span> <em>He followed him.</em> <span class="auth">(Ks, T, Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Avf_1_B2">
					<p><em>He drove away,</em> or <em>drove away and pursued closely,</em> or <em>hunted, him;</em> syn. <span class="ar">طَرَدَهُ</span>. <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Avf_1_B3">
					<p><em>He sought,</em> or <em>sought after,</em> or <em>pursued after, him,</em> or <em>it:</em> in which sense the aor. is <span class="ar long">اثّف القِدٌرَ</span>, <span class="auth">(AA, Ḳ)</span> and <span class="ar">تَأْثِيفٌ</span> also. <span class="auth">(So in some copies of the Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avf_2">
				<h3 class="entry">2. ⇒ <span class="ar">أثّف</span></h3>
				<div class="sense" id="Avf_2_A1">
					<p><span class="ar long">اثّف القِدْرَ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَأْثِيفٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He put the cooking-pot upon the</em> <span class="ar">أَثَافِى</span><span class="add">[<a href="#OuvofiyBapN">pl. of <span class="ar">أُثْفِيَّةٌ</span>, q. v.</a>]</span>; <span class="auth">(T,* Ṣ, M,* Ḳ;)</span> as also<span class="arrow"><span class="ar">أَثَفَهَا↓</span></span>, <span class="auth">(M, TA,)</span> inf. n. <span class="ar">أَثْفٌ</span>; <span class="auth">(TA;)</span> or<span class="arrow"><span class="ar">آثَفَهَا↓</span></span>, <span class="auth">(so in some copies of the Ḳ in art. <span class="ar">ثفى</span>,)</span> inf. n. <span class="ar">إِيثَافٌ</span>; <span class="auth">(TA in that art.;)</span> the first of which <a href="#vafBaAhaA">is a dial. var. of <span class="ar">ثَفَّاهَا</span></a>, inf. n. <span class="ar">تَثْفِيَةٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">أَثْفَاهَا↓</span></span>, whence <span class="ar long">قِدْرٌ مُؤَثْفَاةٌ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Avf_4">
				<h3 class="entry">4. ⇒ <span class="ar">آثف</span></h3>
				<div class="sense" id="Avf_4_A1">
					<p><a href="#Avf_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avf_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأثّف</span></h3>
				<div class="sense" id="Avf_5_A1">
					<p><span class="ar long">تَأَثّفَتِ القِدْرُ</span> <em>The cooking-pot was put upon the</em> <span class="ar">أَثَافِى</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Avf_5_B1">
					<p><span class="ar">تَأَثَّفُوهُ</span> <em>They surrounded him,</em> or <em>it:</em> <span class="auth">(Ṣ, Ḳ:*)</span> <em>they became around him,</em> or <em>it, like the</em> <span class="ar">أُثْفِيَّة</span><span class="add">[or rather <em>like the</em> <span class="ar">أَثَافِى</span>]</span>: <span class="auth">(M:)</span> <em>they collected themselves together around him,</em> or <em>it.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Avf_5_B2">
					<p><span class="ar long">تأثّف المَكَانَ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> or <span class="ar">بِالمَكَانِ</span>, <span class="auth">(M,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>kept to the place;</em> <span class="auth">(T, Ḳ;)</span> <em>remained in it;</em> <span class="auth">(M;)</span> <em>did not quit it.</em> <span class="auth">(AZ, T, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Avf_5_B3">
					<p><span class="ar">تأثّفهُ</span> also signifies <em>He followed after him, and pressed</em> or <em>importuned him, and ceased not to incite him.</em> <span class="auth">(T, Ḳ.)</span> In my opinion, <span class="add">[says Az,]</span> this is not in any way derived from <span class="ar">الأُثْفِيَّةُ</span>; but from <span class="ar long">أَثَفْتُ الرَّجُلَ</span>, meaning “I followed the man.” <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Avf_5_B4">
					<p>And <span class="ar long">تأثّفوا عَلَى الأَمْرِ</span> <em>They aided,</em> or <em>assisted, one another to do,</em> or <em>accomplish, the thing,</em> or <em>affair.</em> <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Avf_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">أَثْفَى</span></h3>
				<div class="sense" id="Avf_QQ1_A1">
					<p><span class="ar long">أَثْفَى القِدْرَ</span>: <a href="#Avf_2">see 2</a>. <span class="add">[But accord. to Az, in the T, <span class="ar">يُؤَثْفِى</span>, as aor. of <span class="ar">أَثْفَى</span>, is <span class="ar">يُثْفِى</span> reduced to its original form; and the like is said in the Ṣ and M in art. <span class="ar">ثفى</span>. If this be the case, <span class="ar">مُؤَثْفَاةٌ</span>, q. v., may be <span class="ar">مُثْفَاةٌ</span> reduced in the same manner, i. e., to its original form.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OavifN">
				<h3 class="entry"><span class="ar">أَثِفٌ</span></h3>
				<div class="sense" id="OavifN_A1">
					<p><span class="ar">أَثِفٌ</span> <span class="add">[probably a mistake for<span class="arrow"><span class="ar">آثِفٌ↓</span></span>]</span> <em>Continuing, permanent, constant, firm,</em> or <em>established:</em> <span class="auth">(Ḳ, TA:)</span> so in the Moḥeeṭ. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: <span class="ar">أَثِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OavifN_A2">
					<p>Also, <span class="auth">(Ḳ, and so in a copy of the Ṣ,)</span> or<span class="arrow"><span class="ar">آثِفٌ↓</span></span>, <span class="add">[agreeably with analogy, and therefore more probably the correct form,]</span> <span class="auth">(so in other copies of the Ṣ and in the T,)</span> <em>Following.</em> <span class="auth">(Ks, T, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuvofiyBapN">
				<h3 class="entry"><span class="ar">أُثْفِيَّةٌ</span> / <span class="ar">إِثْفِيَّةٌ</span></h3>
				<div class="sense" id="OuvofiyBapN_A1">
					<p><span class="ar">أُثْفِيَّةٌ</span> and <span class="ar">إِثْفِيَّةٌ</span> <span class="add">[the former of which is the more common, and this only I find in copies of the T,]</span> The <em>stone</em> <span class="add">[<em>which is one of the three</em>]</span> <em>whereon the cooking-pot is placed:</em> <span class="auth">(AʼObeyd, M, Ḳ:)</span> it is, with the Arabs, <em>a stone like the head of a man:</em> <span class="auth">(T:)</span> the pl. is <span class="ar">أَثَافِيُّ</span> and <span class="ar">أَثَافٍ</span>; <span class="auth">(T, Ṣ, <span class="add">[in which latter it is written differently in different copies, with the article prefixed, <span class="ar">الأَثَافِيُّ</span> and <span class="ar">الأَثَافِى</span>, but in both manners in art. <span class="ar">ثفى</span>,]</span> M, Ḳ;)</span> the latter being allowable; <span class="auth">(T,)</span> or, accord. to Akh, the latter only is used by the Arabs; <span class="auth">(M;)</span> applied to the <em>three stones mentioned above:</em> <span class="auth">(TA in art. <span class="ar">سفع</span>;, &amp;c.:)</span> upon these the cooking-pot is set up; but what is of iron, having three legs, is not called <span class="ar">اثفيّة</span>, but <span class="ar">مِنْصَبٌ</span>; <span class="auth">(T;)</span> <span class="add">[and this is what is meant by <span class="ar long">أَثْفِيَّةٌ مِنْ حَدِيدٍ</span> in art. <span class="ar">سفع</span> in the Ḳ;]</span> i. e. an iron trivet upon which a cooking-pot is set up. <span class="auth">(TA in art. <span class="ar">نصب</span>.)</span> <span class="ar">أُثْفيَّةٌ</span> may be of the measure <span class="ar">فُعْلُويَةٌ</span><span class="add">[from <span class="ar">اثف</span>]</span>, and it may be of the measure <span class="ar">أُفْعُولَةٌ</span><span class="add">[from <span class="ar">ثفى</span>; in either case originally <span class="ar">أُثْفُويَةٌ</span>]</span>. <span class="auth">(A, L.)</span> <span class="ar long">ثَالِثَةُ الأَثَافِى</span> signifies <em>The part, not detached, of a mountain; by the side of which, two pieces are put</em> <span class="add">[<em>for the cookingpot to be set thereon</em>]</span>. <span class="auth">(AʼObeyd, T, Ḳ.)</span> And hence the saying, <span class="auth">(AʼObeyd, T,)</span> <span class="ar long">رَمَاهُ ٱللّٰهُ بثَالِثَةِ الأَثَافِى</span> <span class="auth">(AʼObeyd, T, Ḳ)</span> <em>May God smite him with the mountain; meaning, with a calamity;</em> <span class="auth">(Th, TA, Ḳ in art. <span class="ar">ثفى</span>;)</span> <em>with a calamity like the mountain</em> <span class="add">[<em>in greatness</em>]</span>; <span class="auth">(Th, M;)</span> for when they do not find the third of the <span class="ar">اثافى</span>, they rest the cooking-pot <span class="add">[partly]</span> upon the <em>mountain:</em> <span class="auth">(M, Ḳ, in art. <span class="ar">ثفى</span>:)</span> or, <em>with difficulties,</em> or <em>troubles,</em> or <em>calamities:</em> <span class="auth">(Aṣ, T:)</span> or, <em>with all evil;</em> evils being likened to one <span class="ar">اثفيّة</span> after another, and the third being the last: <span class="auth">(T, Ḳ:)</span> so says Aboo-Saʼeed: <span class="auth">(T:)</span> or, <em>with the last of evil;</em> and <em>the last of everything hateful:</em> <span class="auth">(AO in Ḥar p. 84:)</span> <em>or, with a great calamity.</em> <span class="auth">(Ḥar ib.)</span> One says also, <span class="ar long">الأَثَافِى فُلَانٌ ثَالِثَةُ</span>, meaning ‡ <em>Such a one is the heaviest, most burdensome,</em> or <em>most troublesome, of the people.</em> <span class="auth">(Ḥar ubi suprà.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: <span class="ar">أُثْفِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuvofiyBapN_A2">
					<p><span class="add">[Hence also,]</span> <span class="ar">الأَثَافِى</span> is a name applied to † <em>certain stars</em> <span class="add">[accord. to Ideler, as mentioned by Freytag in his Lex., <em>the stars</em> <span class="gr">σ</span> and <span class="gr">τ</span> and <span class="gr">υ</span> <em>Draconis</em>]</span> <em>over against the head of the</em> <span class="ar">قِدْر</span>; which is the name of certain stars disposed in a round form. <span class="auth">(AḤát, Ḳ.)</span> <span class="add">[Also]</span> a name given by the vulgar to † <span class="add">[<em>The three chief stars in the constellation called</em>]</span> <span class="ar">الشَّلْيَاقُ</span><span class="add">[i. e. <em>Lyra</em>]</span>. <span class="auth">(Ḳzw.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: <span class="ar">أُثْفِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OuvofiyBapN_A3">
					<p>The sing., <span class="auth">(Ḳ,)</span> i. e. each of the two forms thereof, but written in the copies of the Ṣ with damm <span class="add">[only]</span>, <span class="auth">(TA in art. <span class="ar">ثفى</span>,)</span> or <span class="add">[only]</span> the latter, with kesr, <span class="auth">(M, and so in the Ḳ in art. <span class="ar">ثفى</span>,)</span> also signifies † <em>A number,</em> <span class="auth">(M,)</span> or <em>a great number,</em> <span class="auth">(Ḳ, and so in the Ṣ in art. <span class="ar">ثفى</span>,)</span> and <em>a company,</em> or <em>congregated body, of men:</em> <span class="auth">(M, Ḳ:)</span> pl. as above. <span class="auth">(M.)</span> You say, <span class="ar long">هُمْ عَلَيْهِ أُثْفِيَّةٌ وَاحِدَةٌ</span>† <span class="add">[<em>They are against him one band</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بَقِيَتْ مِنْ بَنِى فُلَانٍ أُثْفِيَّةٌ خَشْنَآءُ</span> <em>There remained of the sons of such a one a great number.</em> <span class="auth">(Ṣ in art. <span class="ar">ثفى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MvifN">
				<h3 class="entry"><span class="ar">آثِفٌ</span></h3>
				<div class="sense" id="MvifN_A1">
					<p><span class="ar">آثِفٌ</span>: <a href="#OavifN">see <span class="ar">أَثِفٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWavBafN">
				<h3 class="entry"><span class="ar">مُؤَثَّفٌ</span> / <span class="ar">مُؤَثَّفَةٌ</span></h3>
				<div class="sense" id="muWavBafN_A1">
					<p><span class="ar">مُؤَثَّفٌ</span> † <em>Short, broad, plump, and fleshy.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اثف</span> - Entry: <span class="ar">مُؤَثَّفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWavBafN_A2">
					<p>And, with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُؤَثَّفَةٌ</span>}</span></add>, ‡ A woman <em>whose husband has two wives beside her; she being the third of them:</em> they being likened to the <span class="ar">أَثَافِى</span> of the cookingpot. <span class="auth">(M.)</span> <span class="add">[<a href="#muvafBaApN">See also <span class="ar">مُثَفَّاةٌ</span></a>, <a href="index.php?data=04_v/038_vfe">in art. <span class="ar">ثفى</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWavofaApN">
				<h3 class="entry"><span class="ar">مُؤَثْفَاةٌ</span></h3>
				<div class="sense" id="muWavofaApN_A1">
					<p><span class="ar long">قِدْرٌ مُؤَثْفَاةٌ</span> <em>A cooking-pot put upon the</em> <span class="ar">أَثَافِى</span> <span class="pb" id="Page_0021"></span><span class="add">[<a href="#OuvofiyBapN">pl. of <span class="ar">أُثْفِيَّةٌ</span>, q. v.</a>]</span>. <span class="auth">(M, and Ḳ in art. <span class="ar">ثفى</span>: in some copies of the latter, <span class="ar">مؤْثَفَاةٌ</span>.)</span> <span class="add">[<a href="#Avf_QQ1">See Q. Q. 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0020.pdf" target="pdf">
							<span>Lanes Lexicon Page 20</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0021.pdf" target="pdf">
							<span>Lanes Lexicon Page 21</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
