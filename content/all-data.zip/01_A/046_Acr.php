<article class="root" id="Root_Acr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/045_AcA">اذا</a></span>
				<span class="ar">اذر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/047_Acn">اذن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="McaAru">
				<h3 class="entry"><span class="ar">آذَارُ</span></h3>
				<div class="sense" id="McaAru_A1">
					<p><span class="ar">آذَارُ</span> <em>The sixth of the Greek</em> <span class="add">[or <em>Syrian</em>]</span> <em>months</em> <span class="add">[<em>corresponding to March O. Ṣ.</em>]</span>. <span class="auth">(Ḳ.)</span> <span class="add">[This is not to be confounded with <span class="ar">آذَرْ</span> or <span class="ar">آذُرْ</span>, which is the ninth month of the Persian calendar.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0041.pdf" target="pdf">
							<span>Lanes Lexicon Page 41</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
