<article class="root" id="Root_Alf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/119_Ald">الد</a></span>
				<span class="ar">الف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/121_Alq">الق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alf_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألف</span></h3>
				<div class="sense" id="Alf_1_A1">
					<p><span class="ar">أَلِفَهُ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْلَفُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِلُفٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَلْفٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">إِلَافٌ</span> and <span class="ar">وِلَافٌ</span>, which is anomalous, and <span class="ar">أَلَفَانٌ</span>, <span class="auth">(M, TA,)</span> <em>He kept,</em> or <em>clave, to it;</em> <span class="auth">(AʼObeyd, T, M, Mṣb,* TA;)</span> namely, a thing, <span class="auth">(AʼObeyd, T, M, TA,)</span> or a place; <span class="auth">(Ṣ, Mṣb, TA;)</span> as also <span class="ar">أَلَفَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِفُ</span>}</span></add>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">آلفهُ↓</span></span>, <span class="auth">(AʼObeyd, T, Ṣ, M, Mṣb,)</span> aor. <span class="ar">يُؤْلِفُ</span> <span class="auth">(Ṣ, TA,)</span> inf. n. <span class="ar">إِيلَافٌ</span>; <span class="auth">(Ṣ, Mṣb, TA;)</span> and<span class="arrow"><span class="ar">آلفهُ↓</span></span>, aor. <span class="ar">يُؤَالِفُ</span>, inf. n. <span class="ar">مُؤَالَفَةٌ</span> and <span class="ar">إِلَافٌ</span>: <span class="auth">(Ṣ, Mṣb, TA:)</span> <span class="add">[<em>he frequented it, or resorted to it habitually;</em> namely, a place:]</span> <em>he became familiar with it; or accustomed,</em> or <em>habituated, to it;</em> namely, a thing: <span class="auth">(AZ, T:)</span> <em>he became familiar, sociable, companionable, friendly,</em> or <em>amicable, with him:</em> <span class="auth">(AZ, T, Mṣb:)</span> <em>he loved,</em> or <em>affected, him; liked, approved,</em> or <em>took pleasure in, him.</em> <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَلِفَتِ الطَّيْرُ الحَرَمَ</span> <span class="add">[<em>The birds kept to the sacred territory</em>]</span>, and <span class="ar">البُيُوتَ</span> <span class="add">[<em>the houses</em>]</span>: and<span class="arrow"><span class="ar long">آلَفَتِ↓ الظِّبَآءُ الرَّمْلِ</span></span> <em>The gazelles kept to the sands.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alf_1_A2">
					<p>There are three manners of reading the passage in the Ḳur <span class="add">[evi. 1 and 2]</span>, <span class="arrow"><span class="ar long">لِإِيلَافِ↓ قُرَيْشٍ إِيلَافِهِمْ رِحْلَةَ الشِّتَآءِ وَالصَّيْفِ</span></span>; the second and third being <span class="ar">لِإِلَافِ</span> and <span class="ar">لِإِلْفِ</span>; the first and second of which have been adopted; <span class="auth">(Aboo-Is-ḥáḳ, T, TA;)</span> and the third also; this being the reading of the Prophet <span class="add">[himself]</span>: <span class="auth">(TA:)</span> <span class="add">[accord. to all these readings, the passage may be rendered, <em>For the keeping of Kureysh, for their keeping to the journey of the winter and of the summer,</em> or <em>spring;</em> the chapter going on to say, for this reason “let them worship the Lord of this House,”, &amp;c.: or]</span> the second and third readings are from <span class="ar">أَلِفَ</span>, aor. <span class="ar">يَأْلَفُ</span>; <span class="add">[and accord. to these readings, the passage may be rendered as above;]</span> but accord. to the first reading, the meaning is, <em>for the preparing and fitting out</em> <span class="add">[&amp;c.; i. e., <em>preparing and fitting out men and beasts in the journey of the winter</em>, &amp;c.]</span>: so says IAmb; and Fr explains in the same manner the third reading: but IAạr says that, accord. to this reading, the meaning is, <em>the protecting</em> <span class="add">[&amp;c.]</span>: he says that the persons who protected were four brothers, Háshim and ʼAbd-Shems and El-Muttalib and Nowfal, the sons of ʼAbd-Menáf: these gave protection to Kureysh in their procuring of corn: <span class="auth">(T:)</span> Háshim obtained a grant of security from the king of the Greeks, and Nowfal from Kisrà, and ʼAbd-Shems from the Nejáshee, and El-Muttalib from the kings of Himyer; and the merchants of Kureysh used to go to and from the great towns of these kings with the grants of security of these brothers, and none opposed them: Háshim used to give protection (<span class="ar">يُؤْلِفُ</span> <span class="add">[in the copies of the Ḳ <span class="ar">يُؤَلِّفُ</span>]</span>) <span class="add">[to those journeying]</span> to Syria, and ʼAbd-Shems to Abyssinia, and El-Muttalib to El-Yemen, and Nowfal to Persia: <span class="auth">(T, Ḳ:*)</span> or<span class="arrow"><span class="ar">إِيلَاف↓</span></span> in the Ḳur signifies <em>a covenant,</em> or <em>an obligation;</em> and <em>what resembles permission,</em> (<span class="ar">إِجَازَة</span>, as in some copies of the Ḳ and in the TA,) or <em>protection,</em> (<span class="ar">إِجَارَة</span>, as in the CK,) <em>with an obligation involving responsibility for safety;</em> first obtained by Háshim, from the kings of Syria; <span class="auth">(Ḳ,* TA;)</span> and the explanation is, that Kureysh were dwelling in the sacred territory, <span class="auth">(Ḳ,)</span> having neither seed-produce nor udders <span class="add">[to yield them milk]</span>, <span class="auth">(TA,)</span> secure in the procuring of their provisions from other parts, and in their changes of place, in winter and summer, or spring; the people around them having their property seized; whereas, when any cause of mischief occurred to them, they said, “We are people of the sacred territory,” and then no one opposed them: <span class="auth">(Ḳ:)</span> so in the O: <span class="auth">(TA:)</span> or the <span class="ar">ل</span> is to denote wonder; and the meaning is, <em>wonder ye at the</em> <span class="ar">ايلاف</span> <em>of Kureysh</em> <span class="add">[&amp;c.]</span>: <span class="auth">(Ḳ:)</span> some say that the meaning is connected with what follows; i. e., let them worship the Lord of this House for the <span class="ar">ايلاف</span> <span class="add">[&amp;c., agreeably with the first explanation which we have given]</span>: others, that it is connected with what precedes; as J says; <span class="auth">(TA;)</span> the meaning being, I have destroyed the masters of the elephant <em>to make Kureysh remain</em> at Mekkeh, and <em>for their uniting the journey of the winter and of the summer,</em> or <em>spring;</em> that when they finished one, they should commence the other; <span class="auth">(T, Ṣ;)</span> and this is like the saying, <span class="ar long">ضَرَبْتُهُ لِكَذَا ضَرَبْتُهُ لِكَذَا َ لِكَذَا</span>, with suppression of the <span class="add">[conjunctive]</span> <span class="ar">و</span>: <span class="auth">(Ṣ:)</span> but Ibn-ʼArafeh disapproves of this, for two reasons: first, because the phrase “In the name of God”, &amp;c. occurs between the two chapters: <span class="add">[Bḍ, however, mentions that in Ubeí's copy, the two compose one chapter:]</span> secondly, because <span class="ar">ايلاف</span> signifies the <em>covenants,</em> or <em>obligations, which they obtained when they went forth on mercantile expeditions, and whereby they became secure.</em> <span class="auth">(TA.)</span> <span class="arrow"><span class="ar">إِلَافٌ↓</span></span> <span class="add">[in like manner]</span> signifies <em>A writing of security, written by the king for people, that they may be secure in his territory:</em> and is used by Musáwir Ibn-Hind in the sense of <span class="ar">اِيتِلَافٌ</span> <span class="add">[as is also <span class="ar">إِلْفٌ</span>,]</span> when he says, in satirizing Benoo-Asad,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">زَعَمْتُمْ أَنَّ إِخْوَتَكُمْ قُرَيْشٌ</span> *</div> 
						<div class="star">* <span class="ar long">لَهُمْ إِلْفٌ وَلَيْسَ لَكُمْ إِلَافُ</span> *</div> 
					</blockquote>
					<p>meaning <em>Ye asserted</em> <span class="add">[<em>that your brothers are Kureysh;</em> i. e.,]</span> <em>that ye are like Kureysh:</em> but how should ye be like them? for <em>they have</em> <span class="add">[an <em>alliance whereby they are protected in</em>]</span> the <em>trade</em> of El-Yemen and Syria; <em>and ye have not</em> that <span class="add">[<em>alliance</em>]</span>. <span class="auth">(Ḥam p. 636.)</span> <span class="add">[Hence,]</span> <span class="ar long">إِلَافُ ٱللّٰهِ</span> <span class="add">[a phrase used in the manner of an oath,]</span> accord. to some, signifies <em>The safeguard,</em> or <em>protection, of God:</em> or, accord. to others, <em>an honourable station from God.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alf_1_B1">
					<p><span class="ar">أَلَفَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِفُ</span>}</span></add>, <em>He gave him a thousand;</em> <span class="auth">(Ṣ, Ḳ)</span> of articles of property, and of camels. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alf_2">
				<span class="pb" id="Page_0080"></span>
				<h3 class="entry">2. ⇒ <span class="ar">ألّف</span></h3>
				<div class="sense" id="Alf_2_A1">
					<p><span class="ar long">ٱلّف بَيْنَهُمْ</span>, inf. n. <span class="ar">تَأْلِيفٌ</span>, <span class="auth">(T, Mṣb, Ḳ,)</span> <em>He united them,</em> or <em>brought them together,</em> <span class="auth">(T, Mṣb, TA,)</span> <em>after separation;</em> <span class="auth">(T, TA;)</span> <em>and made them to love one another;</em> <span class="auth">(Mṣb;)</span> <em>he caused union,</em> or <em>companionship,</em> (<span class="ar">أُلْفَة</span>,) <em>to take place between them.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">أَلَّفْتُ بَيْنَ الشَّيْئَيْنِ</span>, inf. n. as above, <span class="add">[<em>I united,</em> or <em>put together, the two things.</em>]</span> <span class="auth">(Ṣ.)</span> And <span class="ar long">ألّف الشَّىْءَ</span> <em>He united,</em> or <em>connected,</em> <span class="auth">(T,)</span> or <em>gathered</em> or <em>collected</em> or <em>brought together,</em> <span class="auth">(M,)</span> <em>the several parts of the thing.</em> <span class="auth">(T, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alf_2_A2">
					<p>Hence, <span class="ar long">تَأْلِيفُ الكُتُبِ</span> <span class="add">[<em>The composition of books</em>]</span>. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Alf_2_A3">
					<p><span class="ar">تَأْلِيفٌ</span> is The <em>putting many things into such a state that one name becomes applicable to them, whether there be to some of the parts a relation to others by precedence and sequence, or not:</em> so that it is a more general term than <span class="ar">تَرْتِيبٌ</span>: <span class="auth">(KT:)</span> or the <em>collecting together,</em> or <em>putting together, suitable things;</em> from <span class="ar">الالفة</span> <span class="add">[i. e. <span class="ar">الأُلْفَةُ</span>]</span>; and is a more particular term than <span class="ar">تَرْكِيبٌ</span>, which is the putting together things, whether suitable or not, or placed in order or not. <span class="auth">(Kull p. 118.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alf_2_B1">
					<p><span class="ar long">أَلَّفُوا إِلَى كَذَا</span>: <a href="#Alf_5">see 5</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Alf_2_C1">
					<p><span class="ar long">ألّف أَلِفًا</span> <em>He wrote an alif;</em> <span class="auth">(Ḳ;)</span> like as one says <span class="ar long">جَيَّمَ جِيمًا</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Alf_2_D1">
					<p><a href="#Alf_4">See also 4</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alf_3">
				<h3 class="entry">3. ⇒ <span class="ar">آلف</span></h3>
				<div class="sense" id="Alf_3_A1">
					<p><span class="ar">آلفهُ</span>: <a href="#Alf_1">see 1</a>, first sentence.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alf_3_B1">
					<p><span class="ar">آلف</span>, <span class="auth">(M, TA,)</span> inf. n. <span class="ar">مُؤَالَفَةٌ</span>, <span class="auth">(TA,)</span> <span class="add">[app., <em>He made a covenant with another to be protected during a journey for the purpose of trade,</em> or <em>traffic:</em> (<a href="#Alf_1">see 1</a>:) and hence,]</span> <em>he</em> <span class="auth">(a man)</span> <em>traded,</em> or <em>trafficked.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Alf_3_C1">
					<p><span class="ar long">شَاَرَةٌ مُؤَالَفَةً</span> <em>He made a condition with him for a thousand:</em> <span class="auth">(IAạr, M:)</span> like as one says, <span class="ar long">شَارَطْتُهُ مُمَا آةً</span>, meaning, for a hundred. <span class="auth">(IAạr, M, Ḳ, in art. <span class="ar">مأى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alf_4">
				<h3 class="entry">4. ⇒ <span class="ar">آلف</span></h3>
				<div class="sense" id="Alf_4_A1">
					<p><span class="ar">آلفهُ</span>, inf. n. <span class="ar">إِيلَافٌ</span>: <a href="#Alf_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alf_4_B1">
					<p><span class="ar long">آلفهُ الشَّىْءَ</span>, <span class="auth">(T, M,)</span> or <span class="ar">المَوْضِعَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">مَكَانَ كَذَا</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(T,)</span> <em>He made him to keep,</em> or <em>cleave, to the thing,</em> or <em>to the place,</em> or <em>to such a place.</em> <span class="auth">(T, Ṣ,* M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Alf_4_B2">
					<p><span class="ar long">آلَفْتُ الشَّىْءَ</span> <em>I joined, conjoined</em> or <em>united, the thing.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Alf_4_C1">
					<p><span class="ar long">آلَفْتُ القَوْمَ</span>, <span class="auth">(T,* Ṣ, Ḳ,*)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> <em>I made the people,</em> or <em>company of men, to be a thousand complete</em> <span class="add">[<em>by adding to them myself</em>]</span>; <span class="auth">(T, Ṣ, Ḳ, TA;)</span> they being before nine hundred and ninety-nine. <span class="auth">(T, TA.)</span> And <span class="ar long">آلف العَدَدَ</span> <em>He made the number to be a thousand;</em> as also<span class="arrow"><span class="ar">أَلَّفَهُ↓</span></span>: <span class="auth">(M:)</span> or<span class="arrow"><span class="ar long">ألّف↓ الأَلْفَ</span></span> <em>he completed the thousand.</em> <span class="auth">(Ḳ.)</span> And in like manner, <span class="auth">(Ṣ,)</span> <span class="ar long">آلَفْتُ الدَّرَاهِمَ</span> <em>I made the dirhems to be a thousand</em> <span class="auth">(Ṣ, Ḳ)</span> <em>complete.</em> <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">أَلَّفُو↓ لَهُمُ الأَعْمَارَ</span></span> <em>They said to them, May you live a thousand years.</em> <span class="auth">(A in art. <span class="ar">عمر</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Alf_4_D1">
					<p><span class="ar">آلَفُوا</span> <em>They became a thousand</em> <span class="auth">(T, Ṣ, M)</span> <em>complete.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">آلَفَتِ الدَّارَهِمُ</span> <em>The dirhems became a thousand</em> <span class="auth">(Ṣ Ḳ)</span> <em>complete.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alf_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّف</span></h3>
				<div class="sense" id="Alf_5_A1">
					<p><span class="ar long">تألّف القَوْمُ</span>, <span class="auth">(Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">ٱئْتَلَفُوا↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيْتَلَفُوا</span>]</span>, <span class="auth">(T, Ḳ,)</span> <em>The people,</em> or <em>party, became united,</em> or <em>came together,</em> <span class="auth">(Mṣb, Ḳ,)</span> <span class="add">[<em>after separation,</em> (<a href="#Alf_2">see 2</a>, of which each is said in the TA to be quasi-pass.,)]</span> <em>and loved one another:</em> <span class="auth">(Mṣb:)</span> or the meaning of <span class="arrow"><span class="ar">ٱئْتِلَافٌ↓</span></span> <span class="add">[and <span class="ar">تَأَلُّفٌ</span> also]</span> is the <em>being in a state of union, alliance, agreement, congruity,</em> or <em>congregation:</em> <span class="auth">(Mṣb:)</span> and the <em>being familiar, sociable, companionable, friendly,</em> or <em>amicable, one with another.</em> <span class="auth">(TA.)</span> And <span class="ar">تَأَلَّفَا</span> is said of two things; <span class="add">[meaning <em>They became united,</em> or <em>put together;</em> (<a href="#Alf_2">see 2</a>;)]</span> as also<span class="arrow"><span class="ar">ائتلفا↓</span></span>. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">ائتلف↓ الشَّىْءُ</span></span> signifies <em>The several parts of the thing kept,</em> or <em>clave, together.</em> <span class="auth">(M.)</span> And <span class="ar">تألّف</span> <em>It became put together in order.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alf_5_A2">
					<p><span class="ar">تألّفوا</span> <em>They sought, desired,</em> or <em>asked,</em> <span class="add">[<em>a covenant to ensure them</em>]</span> <em>protection,</em> <span class="auth">(IAạr, T, M,)</span> <span class="ar long">إِلَى كَذَا</span> <span class="add">[meaning in a journey for the purpose of trade, or traffic, <em>to such a place,</em> as is shown in the T by an explanation of the words of IAạr, <span class="ar long">كَانَ هَاشِمٌ يُؤْلِفُ إِلَى الشَّامِ</span>, in a passage in which the foregoing signification is assigned to <span class="ar">تألّفوا</span>]</span>; <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar long">أَلَّفُوا↓ الى كذا</span></span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alf_5_B1">
					<p><span class="ar">تألّفهُ</span> <em>He treated him with gentleness</em> or <em>blandishment, coaxed him,</em> or <em>wheedled him;</em> <span class="auth">(Ḳ;)</span> <em>behaved in a sociable, friendly, or familiar, manner with him;</em> <span class="auth">(TA;)</span> <em>attracted him,</em> or <em>allured him; and gave him a gift,</em> or <em>gifts;</em> <span class="auth">(T, Ḳ;*)</span> <em>in order to incline him to him:</em> <span class="auth">(Ḳ:)</span> or <em>he affected sociableness, friendliness,</em> or <em>familiarity, with him.</em> <span class="auth">(Mgh.)</span> You say, <span class="ar long">تَأَلَّفْتُهُ عَلَى الإِسْلَامِ</span> <span class="add">[<em>I attracted him,</em> or <em>allured him; and gave him a gift,</em> or <em>gifts, in order to incline him; to embrace El-Islám</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Alf_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتلف</span></h3>
				<div class="sense" id="Alf_8_A1">
					<p><a href="#Alf_5">see 5</a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalofN">
				<h3 class="entry"><span class="ar">أَلْفٌ</span></h3>
				<div class="sense" id="OalofN_A1">
					<p><span class="ar">أَلْفٌ</span>, meaning <em>A certain number,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>well known,</em> <span class="auth">(M,)</span> i. e. <em>a certain round number,</em> <span class="auth">(Mṣb,)</span> <span class="add">[namely <em>a thousand,</em>]</span> is of the masc. gender: <span class="auth">(T, Ṣ, Mṣb, Ḳ:)</span> you say <span class="ar long">ثَلَاثَةُ آلَافٍ</span> <span class="add">[<em>Three thousand</em>]</span>, not <span class="ar long">ثَلَاثَ آلَافٍ</span>; <span class="auth">(TA;)</span> and <span class="ar long">هٰذَا أَلْفٌ وَاحِدٌ</span> <span class="add">[<em>This is one thousand</em>]</span>, not <span class="ar">وَاحِدَةٌ</span>; <span class="auth">(Ṣ;)</span> and <span class="ar long">أَلْفٌ أَقْرَعُ</span>, <span class="add">[<em>A complete thousand</em>]</span>, <span class="auth">(T, Ṣ,)</span> not <span class="ar">قَرْعَآءُ</span>: <span class="auth">(Ṣ:)</span> it is not allowable to make it fem.: so say IAmb and others: <span class="auth">(Mṣb:)</span> or it is allowable to make it fem. as being a pl.: <span class="auth">(T:)</span> or, accord. to ISK, it is allowable to say, <span class="ar long">هٰذِهِ أَلْفٌ</span> as meaning <span class="ar long">هٰذِهِ الدَّرَاهِمُ أَلْفٌ</span> <span class="add">[<em>These dirhems are a thousand</em>]</span>; <span class="auth">(Ṣ, Ḳ;*)</span> and Fr and Zj say the like: <span class="auth">(Mṣb:)</span> the pl. is <span class="ar">آلُفٌ</span>, applied to three, <span class="auth">(M,)</span> and <span class="ar">آلَافٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> applied to a number from three to ten, inclusively, <span class="auth">(TA,)</span> and <span class="ar">أُلُوفٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> used to denote more than ten; <span class="auth">(T;)</span> and <span class="ar">الأَافُ</span> <span class="add">[in the TA <span class="ar">الأَلَفُ</span>]</span> is used by poetic licence for <span class="ar">الآلَافُ</span>, by suppression of the <span class="add">[radical]</span> <span class="ar">ل</span> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IilofN">
				<h3 class="entry"><span class="ar">إِلْفٌ</span></h3>
				<div class="sense" id="IilofN_A1">
					<p><span class="ar">إِلْفٌ</span> <span class="add">[<a href="#Alf_1">originally an inf. n. of <span class="ar">أَلِفَهُ</span>, q. v.</a>,]</span> He <em>with whom one is familiar, sociable, companionable, friendly,</em> or <em>amicable;</em> he <em>to whom one keeps or cleaves;</em> <span class="add">[<em>a constant companion</em> or <em>associate; a mate; a fellow; a yoke-fellow; one who is familiar, &amp;c., with another</em> or <em>others;</em> (<a href="#muwalBafN">see <span class="ar">مُؤَلَّفٌ</span></a>;)]</span> <span class="auth">(M;)</span> <em>i. q.</em><span class="arrow"><span class="ar">أَلِيفٌ↓</span></span>; <span class="auth">(T, Ṣ, M, Ḳ;)</span> which is an act. part. n. of <span class="ar">أَلِفَهُ</span>; <span class="auth">(Mṣb;)</span> as is also <span class="arrow"><span class="ar">آلِفٌ↓</span></span>; <span class="auth">(Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">أَلِفٌ↓</span></span> also is syn. with <span class="ar">أَلِيفٌ</span>: <span class="auth">(Ḳ:)</span> the female is termed <span class="ar">إِلْفَةٌ</span> and <span class="ar">إِلْفٌ</span>; <span class="auth">(M;)</span> both of these signifying a woman <em>with whom thou art familiar, &amp;c., and who is familiar, &amp;c., with thee:</em> <span class="auth">(Ḳ:)</span> and the fem. of <span class="arrow"><span class="ar">آلِفٌ↓</span></span> is <span class="ar">آلِفَةٌ</span>: <span class="auth">(Ḳ:)</span> <a href="#IilofN">the pl. of <span class="ar">إِلْفٌ</span></a> is <span class="ar">آلَافٌ</span>; <span class="auth">(T, M;)</span> which is also pl. of<span class="arrow"><span class="ar">أَلِفٌ↓</span></span>: <span class="auth">(TA:)</span> and that of<span class="arrow"><span class="ar">أَلِيفٌ↓</span></span> is <span class="ar">أَلَائِفُ</span> <span class="auth">(Ṣ, Ḳ, TA)</span> and <span class="ar">أُلَفَآءُ</span>: <span class="auth">(M, TA:)</span> and that of<span class="arrow"><span class="ar">آلِفٌ↓</span></span> is <span class="ar">أُلَّافٌ</span> <span class="auth">(T, Ṣ, Mṣb, Ḳ)</span> and <span class="ar">آلَافٌ</span>, like as <span class="ar">أَنْصَارٌ</span> <a href="#naASirN">is pl. of <span class="ar">نَاصِرٌ</span></a>, <span class="auth">(TA,)</span> and so, <span class="auth">(M, TA,)</span> in my opinion, <span class="add">[says ISd,]</span> <span class="auth">(M,)</span> is <span class="ar">أُلُوفٌ</span>, like as <span class="ar">شُهُودٌ</span> <a href="#XaAhidN">is pl. of <span class="ar">شَاهِدٌ</span></a>, <span class="auth">(M, TA,)</span> though some say that it <a href="#IilofN">is pl. of <span class="ar">إِلْفٌ</span></a>: <span class="auth">(M:)</span> and the pl. of<span class="arrow"><span class="ar">آلِفَةٌ↓</span></span> is <span class="ar">أَوَالِفُ</span> and <span class="ar">آلِفَاتٌ</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">فثلَانٌ إِلْفِى</span> and<span class="arrow"><span class="ar">أَلِيفِى↓</span></span> <span class="add">[<em>Such a one is my constant companion or associate,</em>, &amp;c.]</span> <span class="auth">(T.)</span> And <span class="ar long">حَنَّتِ الإِلْفُ إِلَى إِلْفِ</span> <span class="add">[<em>The female mate yearned towards the mate</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">نَزَعَ البَعِيرُ إِلَى آلَافِهِ</span> <span class="add">[<em>The camel yearned towards his mates</em>]</span>. <span class="auth">(T.)</span> <span class="ar">أُلَّافٌ</span>, <span class="auth">(T,)</span> or <span class="ar">آلَافٌ</span> <span class="auth">(TA,)</span> is said by IAạr to mean Persons <em>who keep to the large towns,</em> or <em>cities.</em> <span class="auth">(T, TA.)</span> <span class="ar">أُلُوفٌ</span> in the Ḳur ii. 244 is said by some to be <a href="#IilofN">pl. of <span class="ar">إِلْفٌ</span></a> or of<span class="arrow"><span class="ar">آلِفٌ↓</span></span>: but by others, to signify “thousands.” <span class="auth">(Bḍ, L, TA.)</span> <span class="arrow"><span class="ar long">أَوَالِفُ↓ الطَّيْرِ</span></span> signifies <em>The birds that keep to Mekkeh and the sacred territory:</em> and<span class="arrow"><span class="ar long">أَوَالِفُ↓ الحَمَامِ</span></span> <em>Domestic pigeons.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalifN">
				<h3 class="entry"><span class="ar">أَلِفٌ</span></h3>
				<div class="sense" id="OalifN_A1">
					<p><span class="ar">أَلِفٌ</span>: <a href="#IilofN">see <span class="ar">إِلْفٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">أَلِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OalifN_A2">
					<p>As some say, <span class="auth">(O,)</span> it also signifies A man <em>having no wife.</em> <span class="auth">(O, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">أَلِفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OalifN_B1">
					<p><em>One of the letters of the alphabet;</em> <span class="auth">(M;)</span> the <em>first thereof;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">أَلِيفٌ↓</span></span>: <span class="auth">(M:)</span> Ks says that, accord. to the usage of the Arabs, it is fem., and so are all the other letters of the alphabet; <span class="add">[and hence its pl. is <span class="ar">أَلِفَاتٌ</span>;]</span> but it is allowable to make it masc.: Sb says that every one of them is masc. and fem., like as is <span class="ar">لِسَانٌ</span>. <span class="auth">(M.)</span> <a href="index.php?data=01_A/000_A">See art. <span class="ar">ا</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">أَلِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OalifN_B2">
					<p>‡ <em>A certain vein lying in the interior of the upper arm,</em> <span class="add">[<em>extending</em>]</span> <em>to the fore arm:</em> <span class="auth">(Ḳ, TA:)</span> so called as being likened to an <span class="ar">ا</span>: <span class="auth">(TA:)</span> the two are called <span class="ar">الأَلِفَانِ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">أَلِفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OalifN_B3">
					<p>† <em>One</em> of any kind of things: <span class="auth">(Ḳ, TA:)</span> as being likened to the <span class="ar">ا</span>; for it denotes the <em>number one.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OulofapN">
				<h3 class="entry"><span class="ar">أُلْفَةٌ</span></h3>
				<div class="sense" id="OulofapN_A1">
					<p><span class="ar">أُلْفَةٌ</span> <em>A state of keeping</em> or <em>cleaving</em> <span class="add">[to a person or thing]</span>: <span class="auth">(M:)</span> <em>a state of union, alliance, agreement, congruity,</em> or <em>congregation;</em> <span class="auth">(Mṣb;)</span> a subst. from <span class="ar">الاِئْتِلَافُ</span>: <span class="auth">(Mṣb, Ḳ, TA:)</span> and, as such, <span class="auth">(TA,)</span> signifying also <em>familiarity, sociableness, socialness, companionableness, friendliness, fellowship, companionship, friendship,</em> and <em>amity.</em> <span class="auth">(Mṣb, TA.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalofieBN">
				<h3 class="entry"><span class="ar">أَلْفِىٌّ</span></h3>
				<div class="sense" id="OalofieBN_A1">
					<p><span class="ar">أَلْفِىٌّ</span> <em>Of,</em> or <em>relating to,</em> or <em>belonging to, the number termed</em> <span class="ar">أَلْفٌ</span> <span class="add">[<em>a thousand</em>]</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalifiyBapN">
				<h3 class="entry"><span class="add">[<span class="ar">أَلِفِيَّةٌ</span>]</span></h3>
				<div class="sense" id="OalifiyBapN_A1">
					<p><span class="add">[<span class="ar long">قَامَةٌ أَلِفِيَّةٌ</span> <em>A stature resembling the letter alif.</em> Often occurring in late works.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IilaAfN">
				<h3 class="entry"><span class="ar">إِلَافٌ</span></h3>
				<div class="sense" id="IilaAfN_A1">
					<p><span class="ar">إِلَافٌ</span> <a href="#Alf_1">an inf. n. of <span class="ar">أَلِفَهُ</span></a>: <a href="#Alf_1"> and used as a subst.: see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">إِلَافٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IilaAfN_A2">
					<p><span class="ar long">بَرْقٌ إِلَافٌ</span> <em>Lightning of which the flashes are consecutive</em> or <em>continuous.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaluwfN">
				<h3 class="entry"><span class="ar">أَلُوفٌ</span></h3>
				<div class="sense" id="OaluwfN_A1">
					<p><span class="ar">أَلُوفٌ</span> <em>Having much</em> <span class="ar">أُلْفَةٌ</span> <span class="add">[meaning <em>familiarity, sociableness,</em>, &amp;c.]</span>: pl. <span class="ar">أُلُفٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaliyfN">
				<h3 class="entry"><span class="ar">أَلِيفٌ</span></h3>
				<div class="sense" id="OaliyfN_A1">
					<p><span class="ar">أَلِيفٌ</span>: <a href="#IilofN">see <span class="ar">إِلْفٌ</span></a>, in three places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">أَلِيفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaliyfN_B1">
					<p><a href="#OalifN">and see <span class="ar">أَلِفٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MlifN">
				<h3 class="entry"><span class="ar">آلِفٌ</span> / 
							<span class="ar">آلِفَةٌ</span> / 
							<span class="ar">أَوَالِفُ</span></h3>
				<div class="sense" id="MlifN_A1">
					<p><span class="ar">آلِفٌ</span> and <span class="ar">آلِفَةٌ</span> and <span class="ar">أَوَالِفُ</span>, the pl. of the latter: <a href="#IilofN">see <span class="ar">إِلْفٌ</span></a>, in seven places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyolaAfN">
				<h3 class="entry"><span class="ar">إِيْلَافٌ</span></h3>
				<div class="sense" id="IiyolaAfN_A1">
					<p><span class="ar">إِيْلَافٌ</span> an inf. n.: and used as a subst.: <a href="#Alf_1">see 1</a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOolafN">
				<span class="pb" id="Page_0081"></span>
				<h3 class="entry"><span class="ar">مَأْلَفٌ</span></h3>
				<div class="sense" id="maOolafN_A1">
					<p><span class="ar">مَأْلَفٌ</span> <span class="add">[<em>An accustomed place;</em>]</span> <em>a place to which a man keeps</em> or <em>cleaves;</em> <span class="add">[<em>which he frequents,</em> or <em>to which he habitually resorts;</em>]</span> <em>with which he is familiar,</em> or <em>to which he is accustomed;</em> <span class="auth">(Mṣb;)</span> <em>a place with which men</em> or <em>camels</em> <span class="add">[or <em>birds</em> and <em>the like</em>]</span> <em>are familiar,</em>, &amp;c. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">مَأْلَفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOolafN_A2">
					<p>And hence, <em>Leafy trees to which animals of the chase draw near.</em> <span class="auth">(AZ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mWlfwn">
				<h3 class="entry"><span class="ar">مؤلفون</span></h3>
				<div class="sense" id="mWlfwn_A1">
					<p><span class="ar">مؤلفون</span>, with fet-ḥ, <span class="add">[i. e. <span class="ar">مُؤْلَفُونَ</span> or<span class="arrow"><span class="ar">مُؤَلَّفُونَ↓</span></span>,]</span> <em>Possessors of thousands;</em> or <em>men whose camels have become, to each, a thousand.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWalBafN">
				<h3 class="entry"><span class="ar">مُؤَلَّفٌ</span></h3>
				<div class="sense" id="muWalBafN_A1">
					<p><span class="ar">مُؤَلَّفٌ</span> and<span class="arrow"><span class="ar">مَأْلُوفٌ↓</span></span> <em>Kept to,</em> or <em>clove to;</em> applied to a thing <span class="add">[and to a person; and meaning when applied to the latter, <em>with whom one is familiar, sociable,</em>, &amp;c.]</span>. <span class="auth">(T.)</span> It is said in a trad.,<span class="arrow"><span class="ar long">المُؤْمِنُ إِلْفٌ مَأْلُوفٌ↓</span></span> <span class="add">[<em>The believer is one who is familiar,</em> or <em>sociable,</em>, &amp;c., <em>with others,</em> and <em>with whom others are familiar,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">مُؤَلَّفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWalBafN_A2">
					<p><span class="ar long">المُؤَلَّفَةُ قُلُوبُهُمْ</span> <em>Those whose hearts are made to incline,</em> or <em>are conciliated, by beneficence and love</em> or <em>affection:</em> <span class="auth">(Ṣ,* Mṣb:)</span> as used in the Ḳur <span class="add">[ix. 60]</span>, it is applied to <em>certain chief persons of the Arabs, whom the Prophet was commanded to attract,</em> or <em>allure, and to present with gifts,</em> <span class="auth">(T, Ḳ,)</span> <em>from the poor-rates,</em> <span class="auth">(TA,)</span> <em>in order that they might make those after them desirous of becoming Muslims,</em> <span class="auth">(T, Ḳ,)</span> <em>and lest care for things which they deemed sacred,</em> or <em>inviolable, together with the weakness of their intentions, should induce them to combine in hostility with the unbelievers against the Muslims; for which purpose, he gave them, on the day of Honeyn, eighty</em> <span class="add">[in the TA <em>two hundred</em>]</span> <em>camels:</em> <span class="auth">(T:)</span> they were <em>certain men of eminence, of the Arabs, to whom the Prophet used to give gifts from the poor-rates; to some of them, to prevent their acting injuriously; and to some, from a desire of their becoming Muslims,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>and their followers also;</em> <span class="auth">(Mṣb;)</span> <em>and to some, in order that they might remain stedfast as Muslims, because of their having recently become such;</em> but when Aboo-Bekr became appointed to the government, he forbade this practice. <span class="auth">(Mgh, Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">مُؤَلَّفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWalBafN_B1">
					<p><span class="ar long">أَلْفٌ مُؤَلَّفَةٌ</span> <span class="add">[These are <em>a thousand</em>]</span> <em>made complete.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الف</span> - Entry: <span class="ar">مُؤَلَّفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="muWalBafN_B2">
					<p><a href="#mwlfwn">See also <span class="ar">مؤلفون</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWalBifN">
				<h3 class="entry"><span class="add">[<span class="ar">مُؤَلِّفٌ</span>]</span></h3>
				<div class="sense" id="muWalBifN_A1">
					<p><span class="add">[<span class="ar">مُؤَلِّفٌ</span> <em>A composer of a book</em> or <em>books; an author.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOoluwfN">
				<h3 class="entry"><span class="ar">مَأْلُوفٌ</span></h3>
				<div class="sense" id="maOoluwfN_A1">
					<p><span class="ar">مَأْلُوفٌ</span>: <a href="#muwalBafN">see <span class="ar">مُؤَلَّفٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0079.pdf" target="pdf">
							<span>Lanes Lexicon Page 79</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0080.pdf" target="pdf">
							<span>Lanes Lexicon Page 80</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0081.pdf" target="pdf">
							<span>Lanes Lexicon Page 81</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
