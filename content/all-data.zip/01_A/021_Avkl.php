<article class="root" id="Root_Avkl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/020_Avf">اثف</a></span>
				<span class="ar">اثكل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/022_Avl">اثل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IivokaAlN">
				<h3 class="entry"><span class="ar">إِثْكَالٌ</span> / <span class="ar">أُثْكُولٌ</span></h3>
				<div class="sense" id="IivokaAlN_A1">
					<p><span class="ar">إِثْكَالٌ</span> and <span class="ar">أُثْكُولٌ</span> <em>i. q.</em> <span class="ar">شِمْرَاخٌ</span> <span class="add">[<em>A fruit-stalk of the raceme of a palm-tree, upon which are the dates</em>]</span>; like <span class="ar">عِثْكَالٌ</span> and <span class="ar">عُثْكُولٌ</span>: the hemzeh in each is a substitute for <span class="ar">ع</span>; but by J <span class="add">[and others]</span> it is held to be augmentative, and the words are mentioned in art. <span class="ar">شكل</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0021.pdf" target="pdf">
							<span>Lanes Lexicon Page 21</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
