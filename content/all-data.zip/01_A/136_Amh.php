<article class="root" id="Root_Amh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/135_Amn">امن</a></span>
				<span class="ar">امه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/137_Amw">امو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Amh_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمه</span></h3>
				<div class="sense" id="Amh_1_A1">
					<p><span class="ar">أَمِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَهُ</span>}</span></add>, inf. n. <span class="ar">أَمَهٌ</span>, <em>He forgot.</em> <span class="auth">(Ṣ, Ḳ.)</span> Hence the reading of I’Ab, <span class="add">[in the Ḳur xii. 45,]</span> <span class="ar long">وَادَّكَرَ بَعْدَ أَمَهٍ</span> <span class="add">[<em>And he remembered,</em> or <em>became reminded, after forgetting</em>]</span>. <span class="auth">(Ṣ.)</span> AHeyth is said to have read <span class="ar long">بَعْدَ أَمْهٍ</span>; and accord. to AO, <span class="ar">أَمْهٌ</span> signifies <span class="ar">نِسْيَانٌ</span> <span class="add">[like <span class="ar">أَمَهٌ</span>]</span>; but this is not correct. <span class="auth">(Az, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امه</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Amh_1_A2">
					<p><em>He confessed,</em> or <em>acknowledged:</em> <span class="auth">(Ṣ, Ḳ:)</span> occurring in this sense in a trad. of Ez-Zuhree; but not well known. <span class="auth">(Ṣ.)</span> The reading of I’Ab, mentioned above, <span class="ar long">بَعْدَ أَمَهٍ</span>, is explained by AʼObeyd as meaning <em>after confessing,</em> or <em>acknowledging.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amh_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأمّه</span></h3>
				<div class="sense" id="Amh_5_A1">
					<p><span class="ar long">تأمّه أُمًّا</span> <em>He adopted a mother;</em> <span class="auth">(M, Ḳ;)</span> as also <span class="ar">تَأَمَّمَهَا</span>. <span class="auth">(M in art. <span class="ar">ام</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumBahapN.1">
				<h3 class="entry"><span class="ar">أُمَّهَةٌ</span></h3>
				<div class="sense" id="OumBahapN.1_A1">
					<p><span class="ar">أُمَّهَةٌ</span> <em>i. q.</em> <span class="ar">أُمٌّ</span> <span class="add">[<em>A mother</em> of a human being and of any animal]</span>: <span class="auth">(M, Ḳ:)</span> the former is <span class="add">[said by some to be]</span> the original of the latter: <span class="auth">(Ṣ:)</span> Aboo-Bekr says that the <span class="ar">ه</span> in the former is a radical letter: <span class="auth">(TA:)</span> or the former applies to a rational creature; and the latter, to <span class="add">[a rational and]</span> an irrational: <span class="auth">(Ḳ:)</span> or, accord. to Az, the pl. of the former applies to the rational; and that of the latter, to the irrational: <span class="auth">(TA:)</span> the former sing. sometimes applies to an irrational creature: <span class="auth">(IJ, TA:)</span> <span class="add">[for some further remarks on both of these words and their pls., see the latter of them:]</span> the pl. <span class="add">[of the former]</span> is <span class="ar">أُمَّهَاتٌ</span> and <span class="add">[that of the latter is]</span> <span class="ar">أُمَّاتٌ</span>: <span class="auth">(T, Ṣ:)</span> Az says that the <span class="ar">امو</span> is added in the former for the purpose of distinguishing between the daughters of Adam <span class="add">[to whom it is generally applied]</span> and other animate beings. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0103.pdf" target="pdf">
							<span>Lanes Lexicon Page 103</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
