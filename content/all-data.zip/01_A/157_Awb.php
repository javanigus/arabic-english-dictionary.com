<article class="root" id="Root_Awb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/156_Aw">او</a></span>
				<span class="ar">اوب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/158_Awd">اود</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Awb_1">
				<h3 class="entry">1. ⇒ <span class="ar">أوب</span> ⇒ <span class="ar">آب</span></h3>
				<div class="sense" id="Awb_1_A1">
					<p><span class="ar">آبَ</span>, aor. <span class="ar">يَؤُوبُ</span>, <span class="auth">(T, Ṣ, &amp;c.,)</span> inf. n. <span class="ar">أَوْبٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">إِيَابٌ</span> and <span class="ar">أَوْبَةٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">أَيْبَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <span class="ar">ى</span> taking the place of <span class="ar">و</span>, <span class="auth">(M,)</span> and <span class="ar">إِيبَةٌ</span> <span class="auth">(Lḥ, M, Ḳ)</span> and <span class="ar">مَآبٌ</span> <span class="add">[like <span class="ar">مَآلٌ</span>]</span>, <span class="auth">(Mṣb, TA,)</span> <em>He</em> <span class="auth">(an absent person, T)</span> <em>returned</em> <span class="auth">(T, Ṣ, M, A, Mgh, Mṣb, Ḳ)</span> to his place, <span class="auth">(Sh,)</span> or to a thing, <span class="auth">(M,)</span> or from his journey; <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">أوّب↓</span></span>, <span class="auth">(M,)</span> inf. n. <span class="ar">تَأْوِيبٌ</span> and <span class="ar">تَأْيِيبٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">تأوّب↓</span></span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar">ائتاب↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَابَ</span>]</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar">أَيَّبَ↓</span></span>, <span class="add">[a quasi-quadriliteral-radical verb, originally <span class="ar">أَيْوَبَ</span>,]</span> of the measure <span class="ar">فَيْعَلَ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">إيَّابٌ</span>, <span class="auth">(M, Ḳ,)</span> originally <span class="ar">إيوَابٌ</span>, of the measure <span class="ar">فِيعَالٌ</span>, <span class="auth">(M, TA,)</span> or, accord. to Fr, <span class="ar">إِيَّابٌ</span> is incorrect, and the right word is <span class="ar">إِيَابٌ</span>: <span class="auth">(TA:)</span> <span class="add">[and if so, <span class="ar">أَيَّبَ</span> is perhaps changed from <span class="ar">أَوَّبَ</span>, like as <span class="ar">أَيْبَةٌ</span> is from <span class="ar">أَوْبَةٌ</span>; and <span class="ar">تَأْيِيبٌ</span> is perhaps its inf. n., changed from <span class="ar">تَأْوِيبٌ</span>:]</span> or, as some say, <span class="ar">إِيَابٌ</span> signifies only the <em>returning</em> to one's family <em>at night:</em> <span class="auth">(M, TA:)</span> and<span class="arrow"><span class="ar long">تأوّب↓ أَهْلَهُ</span></span> and<span class="arrow"><span class="ar long">ائتاب↓ اهله</span></span> <span class="add">[as well as <span class="ar long">آبَ إِلَى أَهْلِهِ</span>]</span> signify <em>he returned to his family at,</em> or <em>in, the night:</em> <span class="auth">(T, TA:)</span> or <span class="ar long">آبَ إِلَيْهِمْ</span>, <span class="auth">(Ṣ,)</span> <span class="add">[or <span class="ar">آبَهُمْ</span>, accord. to a copy of the A, where we find <span class="ar long">أُبْتُ بَنِى فُلَانٍ</span>,]</span> aor. as above; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">تَأَوَّبَهُمْ↓</span></span> <span class="auth">(Ṣ, A, Ḳ)</span> and<span class="arrow"><span class="ar">تَأَيَّبَهُمْ↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="ar">ى</span> taking the place of <span class="ar">و</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">مُتَأَوَّبٌ</span> and <span class="ar">مُتَأَيَّبٌ</span>, <span class="auth">(M,* <span class="add">[in which the two forms of the verb are also given, but with the sing. pronoun of the third pers. instead of the pl.,]</span> and Ḳ,)</span> each in the form of a pass. part. n.; <span class="auth">(TA;)</span> <em>he came to them at night:</em> <span class="auth">(Ṣ, M,* A, Ḳ:)</span> and <span class="ar long">آبَ المَآءَ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">أَوْبٌ</span>, <span class="auth">(Ḳ,)</span> signifies <em>he came to the water, to drink, at night;</em> as also<span class="arrow"><span class="ar">ائتابهُ↓</span></span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar">تأوّبهُ↓</span></span>: <span class="auth">(M:)</span> or, accord. to AZ, <span class="ar">تَأَوَّبتُ</span> signifies <em>I came in the beginning of the night.</em> <span class="auth">(Ṣ.)</span> You say also, <span class="ar long">آبَتِ الشَّمْسُ</span>, <span class="auth">(T, Ṣ, &amp;c.,)</span> aor. <span class="ar">تَؤُوبُ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">مَآبٌ</span>, <span class="auth">(T,)</span> or <span class="ar">إِيَابٌ</span> <span class="add">[in the CK <span class="ar">اَياب</span>]</span> and <span class="ar">أُيُوبٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>The sun returned from its place of rising, and set:</em> <span class="auth">(Mṣb:)</span> or <em>the sun set;</em> <span class="auth">(T, Ṣ, M, A, Ḳ;)</span> as though it returned to the place whence it commenced its course; <span class="auth">(M;)</span> <span class="add">[or]</span> it <a href="#gaAbat">is a dial. var. of <span class="ar">غَابَت</span></a>. <span class="auth">(Ṣ.)</span> And <span class="ar long">آبَ إِلَيْهِ</span> <em>People came to him from every direction,</em> or <em>quarter.</em> <span class="auth">(TA, from a trad.)</span> The poet Sáideh Ibn-El-'Ajlán uses the expression, <span class="ar long">لَآبَكَ مُرْهَفٌ</span>, meaning <em>A thin sword would have come to thee;</em> in which the verb may be trans. by itself, or the prep. <span class="ar">إِلَى</span> may be understood. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awb_1_A2">
					<p><em>He returned from disobedience to obedience; he repented.</em> <span class="auth">(TA.)</span> And <span class="ar long">آبَ إِلَى ٱللّٰهِ</span> <em>He returned unto God from his sin,</em> or <em>offence, and repented.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Awb_1_A3">
					<p><span class="ar long">آبَ بِهِ إِلَيْهِ</span> <em>He made him to return to him,</em> or <em>it;</em> as also<span class="arrow"><span class="ar long">اوّبهُ↓ إِلَيْهِ</span></span>. <span class="auth">(M.)</span> And <span class="ar long">آبَ يَدَهُ إِلَى سَيْفِهِ</span>, <span class="auth">(as in a copy of the T,)</span> or <span class="ar">بِيَدِهِ</span>, <span class="auth">(as in a copy of the A, <span class="add">[which is probably here the more correct]</span>,)</span> <em>He put back his hand to his sword</em> to draw it: <span class="auth">(Lth, T, A:)</span> and <span class="ar long">الى قَوْسِهِ</span> <span class="add">[<em>to his bow</em>]</span> to draw it: and <span class="ar long">الى سَهْمِهِ</span> <span class="add">[<em>to his arrow</em>]</span> to shoot it. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Awb_1_A4">
					<p><a href="#Awb_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awb_2">
				<h3 class="entry">2. ⇒ <span class="ar">أوّب</span></h3>
				<div class="sense" id="Awb_2_A1">
					<p><span class="ar">أوّب</span>: <a href="#Awb_1">see 1</a>, first sentence:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awb_2_A2">
					<p>and the same again, near the end.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Awb_2_A3">
					<p><em>He repeated,</em> or <em>echoed, the praises of God:</em> thus in the saying <span class="add">[in the Ḳur xxxiv. 10]</span>, <span class="ar long">يَا جِبَالُ أَوِّبِى مَعَهُ</span> <em>0 mountains, repeat ye,</em> or <em>echo ye, the praises of God with him;</em> <span class="add">[i. e., with David;]</span> <span class="auth">(Ṣ,* M, TA;)</span> but some read<span class="arrow"><span class="ar long">اُوبِى↓ معه</span></span>, meaning <em>return ye with him in praising as often as he returneth therein:</em> <span class="auth">(M, TA:)</span> or, accord. to the former reading, the meaning is, <em>0 mountains, labour ye with him in praising God all the day, until the night:</em> <span class="auth">(T:)</span> for</p>
				</div>
				<span class="pb" id="Page_0124"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Awb_2_A4">
					<p><span class="ar">أوّب</span>, <span class="auth">(T, A,)</span> inf. n. <span class="ar">تَأْوِيبٌ</span>, <span class="auth">(T, A, Ḳ)</span> also signifies <em>It</em> <span class="auth">(a company of men)</span> <em>journeyed by day:</em> <span class="auth">(Aboo-Málik, T:)</span> or <em>all the day,</em> <span class="auth">(T, A, Ḳ,)</span> <em>to the night,</em> <span class="auth">(T,)</span> <em>without alighting to rest:</em> <span class="auth">(TA:)</span> <span class="ar">تأويب</span> being the same kind of day-journeying as <span class="ar">إِسْآدٌ</span> is of night-journeying: <span class="auth">(T, M:)</span> or <em>he journeyed all the day, and alighted at night:</em> <span class="auth">(T, Ṣ:)</span> or <em>he journeyed by night:</em> <span class="auth">(Mṣb:)</span> or <span class="ar">تأويب</span> <span class="auth">(M, L, Ḳ)</span> and<span class="arrow"><span class="ar">مُؤَاوَبَةٌ↓</span></span> <span class="auth">(Lth, T, L, Ḳ)</span> signify the <em>vying, one with another,</em> of travellingcamels, <em>in pace,</em> or <em>going.</em> <span class="auth">(Lth, T, M, L, Ḳ.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">وَإِنْ تُؤَاوِبْهُ↓ تَجِدْهُ مِئْوَبَا↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And if thou,</em> or <em>they,</em> <span class="auth">(meaning camels,)</span> <em>vie with him in pace,</em> or <em>going, thou wilt,</em> or <em>they will, find him to be one that overcomes therein</em>]</span>: so as related by Lth: but as related by others, <span class="ar">تُؤَوِّبْهُ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awb_3">
				<h3 class="entry">3. ⇒ <span class="ar">آوب</span></h3>
				<div class="sense" id="Awb_3_A1">
					<p><span class="ar">آوب</span>, inf. n. <span class="ar">مُؤَاوَبَةٌ</span>: <a href="#Awb_2">see 2</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأوّب</span></h3>
				<div class="sense" id="Awb_5_A1">
					<p><span class="ar">تأوّب</span> and <span class="ar">تأيّب</span>:<a href="#Awb_1">see 1</a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awb_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتوب</span> ⇒ <span class="ar">ائتاب</span></h3>
				<div class="sense" id="Awb_8_A1">
					<p><span class="ar">ائتاب</span>: <a href="#Awb_1">see 1</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awb_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">أَيَّبَ</span></h3>
				<div class="sense" id="Awb_QQ1_A1">
					<p><span class="ar">أَيَّبَ</span>, originally <span class="ar">أَيْوَبَ</span>: <a href="#Awb_1">see 1</a>, first sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mbu">
				<h3 class="entry"><span class="ar">آبُ</span></h3>
				<div class="sense" id="Mbu_A1">
					<p><span class="ar">آبُ</span> <em>The name of a</em> <span class="add">[<em>Syrian</em>]</span> <em>month</em> <span class="add">[<em>corresponding to August, O. Ṣ.</em>]</span>: an arabicized word. <span class="auth">(IAạr, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawobN">
				<h3 class="entry"><span class="ar">أَوْبٌ</span></h3>
				<div class="sense" id="OawobN_A1">
					<p><span class="ar">أَوْبٌ</span> <a href="#Awb_1">an inf. n. of 1</a>. <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OawobN_A2">
					<p>Also The <em>returning of the fore and hind legs</em> of a beast <em>in going along:</em> <span class="auth">(T, M, A,* Ḳ:)</span> or <em>quickness in the changing,</em> or <em>shifting, of the fore and hind legs in going along:</em> <span class="auth">(Ṣ:)</span> and simply <em>quickness,</em> or <em>swiftness.</em> <span class="auth">(M, Ḳ.)</span> One says, <span class="ar long">مَا أَعْجَبَ أَوْبَ يَدَيْهَا</span> <em>How wonderful is the returning</em> <span class="add">[or <em>quick shifting</em>]</span> <em>of her fore legs!</em> <span class="auth">(A.)</span> And to one going at a quick pace, one says, <span class="ar long">الأَوْبَ الأَوْبَ</span> <span class="add">[meaning <em>Keep to the quick changing,</em> or <em>shifting, of the legs;</em> a verb being understood: or <em>Trot on! Trot on!</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OawobN_A3">
					<p><em>A right,</em> or <em>direct, way, course,</em> or <em>tendency;</em> syn. <span class="ar">قَصْدٌ</span> and <span class="ar">اِسْتِقَامَةٌ</span>. <span class="auth">(M <span class="add">[in which these two syns. are mentioned together]</span> and Ḳ <span class="add">[in which another explanation intervenes between them, namely <span class="ar">عادة</span>, as though they were meant to be understood in different senses, which I do not think to be the case]</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OawobN_A4">
					<p><em>A direction:</em> as in the saying, <span class="ar long">رَمَى أَوبًا أَوْ أَوْبَيْنِ</span> <span class="add">[<em>He shot,</em> or <em>cast, in one direction, or in two directions</em>]</span>. <span class="auth">(M, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OawobN_A5">
					<p><em>A course, way, mode,</em> or <em>manner, of acting,</em> or <em>conduct,</em> or <em>the like:</em> <span class="auth">(A:)</span> <em>custom.</em> <span class="auth">(Lḥ, M, A, Ḳ.)</span> You say, <span class="ar long">كُنْتُ عَلَى صَوْبِ فُلَانٍ وَأَوْبِهِ</span> <em>I was</em> <span class="add">[proceeding]</span> <em>in the course, way, mode,</em> or <em>manner, of acting, &amp;c., of such a one.</em> <span class="auth">(A.)</span> And <span class="ar long">مَا زَالَ هٰذَا أَوْبَهُ</span> <em>This ceased not to be his course, way, mode,</em> or <em>manner,</em>, &amp;c.: <span class="auth">(A:)</span> or <em>his custom.</em> <span class="auth">(Lḥ, M, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OawobN_A6">
					<p><em>A way,</em> or <em>road:</em> <span class="auth">(M, Mṣb, Ḳ:)</span> <em>a quarter:</em> <span class="auth">(ʼEyn, M, A, Ḳ:)</span> <em>a tract,</em> or <em>side:</em> <span class="auth">(ʼEyn, Ṣ:)</span> <em>a place:</em> <span class="auth">(Ṣ:)</span> <em>a place to which one returns</em> <span class="add">[like <span class="ar">مَآبٌ</span>]</span>. <span class="auth">(A, Mṣb.)</span> You say, <span class="ar long">جَاؤُوا مِنْ كُلِّ أَوْبٍ</span> <em>They came from every way,</em> or <em>road,</em> <span class="auth">(M, Mṣb,)</span> or <em>quarter,</em> <span class="auth">(ʼEyn, M, A,)</span> or <em>tract,</em> or <em>side,</em> <span class="auth">(ʼEyn, Ṣ,)</span> <em>and place,</em> <span class="auth">(Ṣ,)</span> or <em>place to which one returns.</em> <span class="auth">(A, Mṣb.)</span> And <span class="ar long">أَوْبَا الوَادِى</span> signifies <em>The two sides of the valley.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OawobN_B1">
					<p><em>Bees:</em> <span class="auth">(M, Ḳ:)</span> a quasi-pl. n.: as though the sing. were <span class="ar">آئِبٌ</span>: AḤn says that they are so called because of their returning to the <span class="ar">مَبَآءَة</span>, i. e. the place where they hive for the night. <span class="auth">(M, TA.)</span> <a href="#AyibN">See <span class="ar">آئِبٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OawobN_B2">
					<p>The <em>clouds.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OawobN_B3">
					<p>The <em>wind.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawobapN">
				<h3 class="entry"><span class="ar">أَوْبَةٌ</span></h3>
				<div class="sense" id="OawobapN_A1">
					<p><span class="ar">أَوْبَةٌ</span> and<span class="arrow"><span class="ar">أَيْبَةٌ↓</span></span> <em>Return;</em> <span class="auth">(T, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِيَابَةٌ↓</span></span>, a subst. from <span class="ar">آبَ</span>. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">لِيَهْنِئْكَ أَوْبَةُ الغَائِبِ</span> <span class="add">[<em>May the return of the absent give thee joy</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">فُلانٌ سَرِيعُ الأَوْبَةِ</span> and<span class="arrow"><span class="ar">الأَيْبَةِ↓</span></span> <em>Such a one is quick in return.</em> <span class="auth">(AʼObeyd, T, Ṣ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OawobapN_A2">
					<p><em>Return from disobedience to obedience; repentance.</em> <span class="auth">(TA in art. <span class="ar">ايب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OawobapN_A3">
					<p><span class="ar long">كَلَامٌ لَا أَوْبَةَ لَهُ</span> <em>Speech,</em> or <em>language, without profit.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوْبَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OawobapN_B1">
					<p><span class="ar">أَوْبَةٌ</span> is also <a href="#OaWobaAtN">the sing. of <span class="ar">أَوْبَاتٌ</span></a>, which signifies The <em>legs</em> of a beast. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayobapN">
				<h3 class="entry"><span class="ar">أَيْبَةٌ</span></h3>
				<div class="sense" id="OayobapN_A1">
					<p><span class="ar">أَيْبَةٌ</span>: <a href="#OaWobapN">see <span class="ar">أَوْبَةٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَيْبَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OayobapN_B1">
					<p>Also, <span class="auth">(as in some copies of the Ḳ,)</span> or<span class="arrow"><span class="ar">إِيبَةٌ↓</span></span>, <span class="auth">(accord. to the CK,)</span> or<span class="arrow"><span class="ar">آئِبَةٌ↓</span></span>, <span class="auth">(accord. to the TḲ,)</span> <em>A noon-day draught</em> or <em>drink.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiybapN">
				<h3 class="entry"><span class="ar">إِيبَةٌ</span></h3>
				<div class="sense" id="IiybapN_A1">
					<p><span class="ar">إِيبَةٌ</span>: <a href="#OaYobapN">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawuwbN">
				<h3 class="entry"><span class="ar">أَوُوبٌ</span></h3>
				<div class="sense" id="OawuwbN_A1">
					<p><span class="ar">أَوُوبٌ</span> A she-camel <em>quick in the changing,</em> or <em>shifting, of her fore and kind legs in going along.</em> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyaAbapN">
				<h3 class="entry"><span class="ar">إِيَابَةٌ</span></h3>
				<div class="sense" id="IiyaAbapN_A1">
					<p><span class="ar">إِيَابَةٌ</span>: <a href="#OaWobapN">see <span class="ar">أَوْبَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawBaAbN">
				<h3 class="entry"><span class="ar">أَوَّابٌ</span></h3>
				<div class="sense" id="OawBaAbN_A1">
					<p><span class="ar">أَوَّابٌ</span> <em>Frequent in returning.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">أَوَّابٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OawBaAbN_A2">
					<p><em>Frequent in returning unto God, from one's sins;</em> <span class="auth">(M, TA;)</span> <em>wont to repent,</em> or <em>frequent in repenting:</em> <span class="auth">(Zj, T, A, Mgh, Mṣb:)</span> or <em>turning from disobedience to obedience:</em> or <span class="auth">(Ṣ, L:)</span> or <em>a praiser of God;</em> <span class="auth">(Saʼeed Ibn-Jubeyr, TA;)</span> by which is here meant, in the prayer of the period of the forenoon called <span class="ar">الضُّحَى</span>, when the sun is high, and the heat violent; hence termed <span class="ar long">صَلَاةُ الأَوَّابِينَ</span>; which is performed when the young camels feel the heat of the sun from the parched ground: <span class="auth">(TA:)</span> or <em>obedient:</em> <span class="auth">(Ḳatádeh, TA:)</span> or <em>one who reflects upon his sins in solitude, and prays God to forgive them:</em> <span class="auth">(TA:)</span> or one <em>who keeps,</em> or <em>is mindful of, the ordinances prescribed by God,</em> (<span class="ar">حَفِيظٌ</span>, <span class="add">[which is thus explained by Bḍ and Jel as occurring in the Ḳur l. 31,]</span>) <em>and does not rise from his sitting-place until he begs forgiveness of God:</em> <span class="auth">(ʼObeyd Ibn-ʼOmeyr, T, TA:* <span class="add">[but this is evidently meant as an explanation of <span class="ar">أَوَّابٌ</span> together with <span class="ar">حَفِيظٌ</span>: see the Ḳur ubi suprà:]</span>)</span> or one <em>who sins, and then returns to obedience, and then sins, and then returns to obedience.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYibN">
				<h3 class="entry"><span class="ar">آئِبٌ</span></h3>
				<div class="sense" id="MYibN_A1">
					<p><span class="ar">آئِبٌ</span> act. part. n. of <span class="ar">آبَ</span>; <em>Returning:</em> <span class="add">[&amp;c.:]</span> <span class="auth">(M, Mṣb:)</span> pl. <span class="ar">أُوَّابٌ</span> and <span class="ar">أُيَّابٌ</span> and<span class="arrow"><span class="ar">أَوْبٌ↓</span></span> <span class="add">[q. v.]</span>: <span class="auth">(M, Ḳ:)</span> or, accord. to some, the last is a quasi-pl. n. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYibapN">
				<h3 class="entry"><span class="ar">آئِبَةٌ</span></h3>
				<div class="sense" id="MYibapN_A1">
					<p><span class="ar">آئِبَةٌ</span> The <em>coming</em> of camels <em>to water, to drink, every night:</em> whence the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَا تَرِدَنَّ المَآءَ إِلَّا آئِبَهْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Do not thou come to the water, to drink, unless coming to it every night</em>]</span>. <span class="auth">(IAạr, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">آئِبَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MYibapN_A2">
					<p><a href="#OaYobapN">See also <span class="ar">أَيْبَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maMbN">
				<h3 class="entry"><span class="ar">مَآبٌ</span></h3>
				<div class="sense" id="maMbN_A1">
					<p><span class="ar">مَآبٌ</span> <em>A place to which one returns:</em> <span class="auth">(T, Ṣ, Ḳ:)</span> <em>a settled,</em> or <em>fixed, abode,</em> or <em>dwelling-place:</em> <span class="auth">(TA:)</span> the <em>place to which one is translated,</em> or <em>removed, by death:</em> <span class="auth">(Ḳ, TA:)</span> the <em>goal to which the course of life ultimately leads one;</em> or <em>place to which one returns in the ultimate state,</em> or <em>world to come.</em> <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">مَآبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maMbN_A2">
					<p>The <em>place where the sun sets.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوب</span> - Entry: <span class="ar">مَآبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="maMbN_A3">
					<p><span class="add">[<em>A day-journey:</em> pl. <span class="ar">مَآوِبُ</span>; as in the saying,]</span> <span class="ar long">بَيْنَهُمَ ثَلَاثُ مَآوِبَ</span> <em>Between them two are three day-journeys.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYowabN">
				<h3 class="entry"><span class="ar">مِئْوَبٌ</span></h3>
				<div class="sense" id="miYowabN_A1">
					<p><span class="ar">مِئْوَبٌ</span> <span class="add">[A camel <em>that overcomes in vying with another,</em> or <em>others, in pace,</em> or <em>going</em>]</span>: see an ex. voce <span class="ar">أَوَّبَ</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maMbapu">
				<h3 class="entry"><span class="ar">مَآبَةُ</span></h3>
				<div class="sense" id="maMbapu_A1">
					<p><span class="ar long">مَآبَةُ البِئْرِ</span> <span class="add">[<em>The place where the water flows again into the well to supply the deficiency occasioned by drawing;</em>]</span> <em>the</em> <span class="ar">مَبَآءَة</span> <em>of the well;</em> i. e. <em>the place where the water collects in the well.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWawBibapN">
				<h3 class="entry"><span class="ar">مُؤَوِّبَةٌ</span></h3>
				<div class="sense" id="muWawBibapN_A1">
					<p><span class="ar long">رِيحٌ مُؤَوِّبَةٌ</span>, <span class="auth">(IB, CK,)</span> or <span class="ar">مُؤَوَّبَةٌ</span>, <span class="auth">(as in a copy of the M, and in some copies of the Ḳ,)</span> <em>A wind blowing throughout the whole day:</em> <span class="auth">(M, Ḳ:)</span> or <em>a wind that comes at night.</em> <span class="auth">(IB.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWotaAbN">
				<h3 class="entry"><span class="ar">مُؤْتَابٌ</span></h3>
				<div class="sense" id="muWotaAbN_A1">
					<p><span class="ar">مُؤْتَابٌ</span>: <a href="#mutaOawBibN">see <span class="ar">مُتَأَوِّبٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOawBabN">
				<h3 class="entry"><span class="ar">مُتَأَوَّبٌ</span></h3>
				<div class="sense" id="mutaOawBabN_A1">
					<p><span class="ar">مُتَأَوَّبٌ</span> <a href="#Awb_5">an inf. n. of 5, q. v.</a>; as also<span class="arrow"><span class="ar">مُتَأَيَّبٌ↓</span></span>. <span class="auth">(M,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOawBibN">
				<h3 class="entry"><span class="ar">مُتَأَوِّبٌ</span></h3>
				<div class="sense" id="mutaOawBibN_A1">
					<p><span class="ar">مُتَأَوِّبٌ</span> <em>Returning to one's family at,</em> or <em>in, the night;</em> as also<span class="arrow"><span class="ar">مُؤْتَابٌ↓</span></span>: <span class="auth">(TA:)</span> or, as also<span class="arrow"><span class="ar">مُتَأَيِبٌ↓</span></span>, <em>coming at night:</em> or <em>coming in the beginning of the night:</em> <span class="auth">(Ṣ:)</span> <span class="add">[and so<span class="arrow"><span class="ar">مُؤْتَابٌ↓</span></span>, as in the following ex.:]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَمَنْ يَتَّقْ فَإِنَّ ٱللّٰهَ مَعْهُ</span> *</div> 
						<div class="star">* <span class="ar long">وَرِزْقُ ٱللّٰهِ مُؤْتَابٌ وَغَادِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And whoso feareth God, verily God is with him; and the supply of God cometh</em> to him <em>at night,</em> or <em>in the beginning of the night, and cometh early in the morning:</em> <span class="ar">يَتَّقْ</span> being here put for <span class="ar">يَتَّقِ</span>, by a necessary poetical licence: <a href="index.php?data=27_w/189_wqe">see art. <span class="ar">وقى</span></a>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOayBabN">
				<h3 class="entry"><span class="ar">مُتَأَيَّبٌ</span></h3>
				<div class="sense" id="mutaOayBabN_A1">
					<p><span class="ar">مُتَأَيَّبٌ</span>: <a href="#mutaOawBabN">see <span class="ar">مُتَأَوَّبٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOayBibN">
				<h3 class="entry"><span class="ar">مُتَأَيِّبٌ</span></h3>
				<div class="sense" id="mutaOayBibN_A1">
					<p><span class="ar">مُتَأَيِّبٌ</span>: <a href="#mutaOawBibN">see <span class="ar">مُتَأَوِّبٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0123.pdf" target="pdf">
							<span>Lanes Lexicon Page 123</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0124.pdf" target="pdf">
							<span>Lanes Lexicon Page 124</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
