<article class="root" id="Root_Anm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/147_Ank">انك</a></span>
				<span class="ar">انم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/149_AnmA">انما</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AlOanaAmu">
				<h3 class="entry"><span class="ar">الأَنَامُ</span></h3>
				<div class="sense" id="AlOanaAmu_A1">
					<p><span class="ar">الأَنَامُ</span> <span class="auth">(T, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">الآنَامُ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">الأَنِيمُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> the last allowable in poetry, <span class="auth">(M,)</span> <em>i. q.</em> <span class="ar">الخَلْقُ</span>; <span class="auth">(M, Ḳ, and Bḍ and Jel in lv. 9;)</span> i. e. <span class="add">[<em>Mankind;</em> for such is the general meaning of <span class="ar">الخَلْقُ</span>, or]</span> <em>mankind and the jinn</em> <span class="auth">(or <em>genii</em>)</span> <em>and others:</em> <span class="auth">(Jel ubi suprà:)</span> or <em>the jinn and mankind:</em> <span class="auth">(T, Mṣb, Ḳ:)</span> or <em>what are on the face of the earth of all that are termed</em> <span class="ar">الخَلْق</span> <span class="add">[or <em>created beings</em>]</span>: <span class="auth">(Lth, T, Mṣb:)</span> or <em>all that is on the face of the earth:</em> <span class="auth">(Ḳ:)</span> or <em>everything having a</em> <span class="ar">رُوح</span> <span class="add">[i. e. <em>soul,</em> or <em>spirit</em>]</span>: <span class="auth">(Bḍ ubi suprà:)</span> or <em>every one who is subject to sleep.</em> <span class="auth">(TA <span class="add">[as though it were derived from <span class="ar">النَّوْمُ</span>.]</span>)</span> <span class="ar">الانام</span> is not mentioned by J, though occurring in the Ḳur-án. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlOaniymu">
				<h3 class="entry"><span class="ar">الأَنِيمُ</span></h3>
				<div class="sense" id="AlOaniymu_A1">
					<p><span class="ar">الأَنِيمُ</span>: <a href="#AlOanaAmu">see above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlMnaAmu">
				<h3 class="entry"><span class="ar">الآنَامُ</span></h3>
				<div class="sense" id="AlMnaAmu_A1">
					<p><span class="ar">الآنَامُ</span>: <a href="#AlOanaAmu">see above</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0118.pdf" target="pdf">
							<span>Lanes Lexicon Page 118</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
