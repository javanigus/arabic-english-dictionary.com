<article class="root" id="Root_Adm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/040_Adr">ادر</a></span>
				<span class="ar">ادم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/042_Adw">ادو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Adm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أدم</span></h3>
				<div class="sense" id="Adm_1_A1">
					<p><span class="ar long">أَدَمَ الخُبْزَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِمُ</span>}</span></add>, <span class="auth">(M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَدْمٌ</span>; <span class="auth">(M, Mṣb;)</span> and<span class="arrow"><span class="ar">آدمهُ↓</span></span>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِيدَامٌ</span>; <span class="auth">(TḲ;)</span> <em>He mixed the bread with</em> <span class="ar">أُدْم</span> <span class="add">[or <em>seasoning;</em> i. e. <em>he seasoned it</em>]</span>; <span class="auth">(M, Ḳ;)</span> <em>he made the swallowing of the bread to be good,</em> or <em>agreeable, by means of</em> <span class="ar">إِدَام</span> <span class="add">[or <em>seasoning</em>]</span>. <span class="auth">(Mṣb.)</span> You say also, <span class="ar long">أَدَمَ الخُبْزَ بِاللَّحْمِ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِمُ</span>}</span></add>, <span class="add">[<em>he seasoned the bread,</em> or <em>rendered it savoury, with flesh-meat,</em>]</span> from <span class="ar">أُدْمٌ</span> and <span class="ar">إِدَامٌ</span>, signifying <span class="ar long">مَا يُؤْتَدمُ بِهِ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Adm_1_A2">
					<p><span class="ar long">أَدَمَ القَوْمَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِمُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَدْمٌ</span>; <span class="auth">(TA;)</span> or<span class="arrow"><span class="ar">آدَمَهُمْ↓</span></span>; <span class="auth">(M;)</span> or both; <span class="auth">(TA;)</span> <em>He seasoned for the people,</em> or <em>company of men,</em> (<span class="ar long">أَدَمَ لَهُمْ</span>, <span class="add">[in the CK, erroneously, <span class="ar long">اَدامَ لهم</span>,]</span>) <em>their bread;</em> <span class="auth">(M, Ḳ, TA;)</span> i. e., <em>mixed it</em> <span class="add">[<em>for them</em>]</span> <em>with</em> <span class="ar">إِدَام</span> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Adm_1_A3">
					<p><span class="add">[From <span class="ar">أَدَمَ</span> in the first of the senses explained above, is app. derived the phrase,]</span> <span class="ar long">أَدَمَهُ بِأَهْلِهِ</span> <em>He mixed him, associated him,</em> or <em>united him in company, with his family.</em> <span class="auth">(M.)</span> <span class="add">[And in like manner,]</span> <span class="ar long">أَدَمَ بَيْنَهُمَا</span>, <span class="auth">(T, Ṣ,)</span> or <span class="ar">بَيْنَهُمْ</span>, <span class="auth">(M, Mṣb,* Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِمُ</span>}</span></add>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَدْمٌ</span>; <span class="auth">(T, M, M$sudot;b;)</span> and<span class="arrow"><span class="ar">آدم↓</span></span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إِيَدامٌ</span>; <span class="auth">(T, TA;)</span> <em>He</em> <span class="auth">(God, T, Ṣ, M, or a man, Mṣb)</span> <em>effected a reconciliation between them; brought them together;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ; <span class="add">[expl. in the M and Ḳ by <span class="ar long">لَاءَ مَ</span>, for which we find in the CK <span class="ar">لَاُمَ</span>;]</span>)</span> <em>made them sociable</em>, or <em>familiar, one with another;</em> <span class="auth">(Ṣ, Mṣb, TA;)</span> <em>and made them to agree:</em> <span class="auth">(TA:)</span> or <em>induced love and agreement between them:</em> held by AʼObeyd to be from <span class="ar">أُدْمٌ</span>, because thereby food is made good and pleasant. <span class="auth">(T.)</span> It is said in a trad., <span class="ar long">فَإِنَّهُ أَحْرَى أَنْ يُؤْدَمَ بَيْنَكُمَا</span>, meaning <em>For it is most fit,</em> or <em>meet, that there should be, between you two, love and agreement:</em> <span class="auth">(T, Ṣ:)</span> or, <em>that peace,</em> or <em>reconciliation, and friendship, should continue between you two.</em> <span class="auth">(Mṣb.)</span> And a poet says,</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">وَالبِيضُ لَا يُؤْدِمْنَ↓ إِلَّا مُؤْدَمَا↓</span></span> *</div> 
					</blockquote>
					<p>i. e. <span class="add">[<em>And the pure,</em> or <em>free from faults,</em> among women,]</span> <em>do not love</em> any <em>save one who is made an object of love</em> <span class="add">[by his good qualities]</span>, <span class="auth">(T, Ṣ,)</span> <em>a proper object of love.</em> <span class="auth">(T.)</span></p>
				</div>
				<span class="pb" id="Page_0036"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Adm_1_B1">
					<p><span class="ar">أَدَمَهُمْ</span>, <span class="auth">(T, M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْدِمُ</span>}</span></add>, <span class="auth">(T,)</span> or <span class="ar">ـُ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">أَدْمٌ</span>, <span class="auth">(M,)</span> ‡ <em>He was,</em> or <em>became, to them, what is termed</em> <span class="ar">أَدَمَة</span>; <span class="auth">(T, M, Ḳ;)</span> i. e., <em>one who made people to know them;</em> <span class="auth">(T;)</span> or <em>a pattern, an exemplar, an example,</em> or <em>one who was imitated,</em> or <em>to be imitated; and one by means of whom they were known:</em> <span class="auth">(M, Ḳ:)</span> so says IAạr. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Adm_1_C1">
					<p><span class="ar long">أَدَمَ الأَدِيمَ</span> <em>He pared,</em> or <em>removed the superficial part of, the hide:</em> <span class="auth">(T,* TA:)</span> and<span class="arrow"><span class="ar long">آدَمَ↓ الأَدِيمَ</span></span>, with medd, <em>he pared off the</em> <span class="ar">أَدَمَة</span> <span class="add">[q. v.]</span> <em>of the hide:</em> <span class="auth">(TA:)</span> or the latter signifies <em>he exposed to view the</em> <span class="ar">أَدَمَة</span> <span class="add">[in the CK, erroneously, the <span class="ar">اُدْمَة</span>]</span> <em>of the hide.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Adm_1_D1">
					<p><span class="ar">أَدِمَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْدَمُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">أَدَمٌ</span>; <span class="auth">(TḲ;)</span> and <span class="ar">أَدُمَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْدُمُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">أُدُومَةٌ</span> <span class="auth">(T, Ḳ)</span> <span class="add">[or, more probably, <span class="ar">أُدْمَةٌ</span>, like <span class="ar">سُمْرَةٌ</span>, &amp;c.]</span>; <em>He</em> <span class="auth">(a camel, and a gazelle, and a man,)</span> <em>was,</em> or <em>became, of the colour termed</em> <span class="ar">أُدْمَة</span>, q. v. infrà. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Adm_2">
				<h3 class="entry">2. ⇒ <span class="ar">أدّم</span></h3>
				<div class="sense" id="Adm_2_A1">
					<p><span class="ar">أدّمهُ</span>, inf. n. <span class="ar">تَأْدِيمٌ</span>, <em>He put much</em> <span class="ar">إِدَام</span> <span class="add">[or <em>seasoning</em>]</span> <em>into it.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Adm_4">
				<h3 class="entry">4. ⇒ <span class="ar">آدَمَ</span></h3>
				<div class="sense" id="Adm_4_A1">
					<p><a href="#Adm_1">see 1</a>, in five places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Adm_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتدم</span></h3>
				<div class="sense" id="Adm_8_A1">
					<p><span class="ar long">ائتدم بِهِ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَدَمَ</span>]</span> <em>He made use of it</em> <span class="add">[<em>to render his bread pleasant,</em> or <em>savoury</em>]</span>; namely <span class="ar">أُدْم</span>, <span class="auth">(M,* TA,)</span> or <span class="ar">إِدَام</span>. <span class="auth">(M.)</span><span class="add">[<span class="ar">إِدَامٌ</span> is explained in the T and Ṣ, &amp;c. by the words <span class="ar long">مَا يُؤْتَدَمُ بِهِ</span>, meaning <em>That which is used for seasoning</em> bread.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Adm_8_A2">
					<p><span class="ar long">ائتدم العُودُ</span> ‡ <em>The wood,</em> or <em>branch, had the sap</em> (<span class="ar">المَآء</span>) <em>flowing in it.</em> <span class="auth">(Z, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Adm_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأدم</span></h3>
				<div class="sense" id="Adm_10_A1">
					<p><span class="ar">استأدمهُ</span> <em>He sought,</em> or <em>demanded, of him</em> <span class="ar">إِدَام</span> <span class="add">[or <em>seasoning</em>]</span>. <span class="auth">(Z, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OadomN">
				<h3 class="entry"><span class="ar">أَدْمٌ</span></h3>
				<div class="sense" id="OadomN_A1">
					<p><span class="ar">أَدْمٌ</span>: <a href="#OudomapN">see <span class="ar">أُدْمَةٌ</span></a></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدْمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OadomN_B1">
					<p><span class="ar long">هُوَ أَدْمُ أَهْلِهِ</span>: <a href="#OadamapN">see <span class="ar">أَدَمَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OudomN">
				<h3 class="entry"><span class="ar">أُدْمٌ</span></h3>
				<div class="sense" id="OudomN_A1">
					<p><span class="ar">أُدْمٌ</span>: <a href="#IidaAmN">see <span class="ar">إِدَامٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OudomN_A2">
					<p><span class="ar long">هُوَ أُدْمُ أَهْلِهِ</span> and <span class="ar long">أُدْمُ بَنِى أَبِيهِ</span>: <a href="#OadamapN">see <span class="ar">أَدَمَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OadamN">
				<h3 class="entry"><span class="ar">أَدَمٌ</span></h3>
				<div class="sense" id="OadamN_A1">
					<p><span class="ar">أَدَمٌ</span>: <a href="#OadiymN">see <span class="ar">أَدِيمٌ</span></a>, in two places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadamN_A2">
					<p><a href="#OadamapN">and <span class="ar">أَدَمَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدَمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OadamN_B1">
					<p><span class="ar">أَدَمُ</span>: <a href="#Adamu">see <span class="ar">آدَمُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oadomapu">
				<h3 class="entry"><span class="ar">أَدْمَةُ</span></h3>
				<div class="sense" id="Oadomapu_A1">
					<p><span class="ar long">هُوَ أَدْمَةُ أَهْلِهِ</span>: <a href="#OadamapN">see <span class="ar">أَدَمَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OudomapN">
				<h3 class="entry"><span class="ar">أُدْمَةٌ</span></h3>
				<div class="sense" id="OudomapN_A1">
					<p><span class="ar">أُدْمَةٌ</span> <em>A state of mixing,</em> or <em>mingling, together</em> <span class="add">[<em>in familiar,</em> or <em>social, intercourse</em>]</span>. <span class="auth">(Lth, T, M, Ḳ.)</span> You say, <span class="ar long">بَيْنَهُمَا أُدْمَةٌ</span> <em>Between them two is a mixing,</em>, &amp;c. <span class="auth">(Lth, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OudomapN_A2">
					<p>Also, <span class="auth">(M, Ḳ,)</span> or<span class="arrow"><span class="ar">أَدْمٌ↓</span></span>, <span class="auth">(Ṣ,)</span> <em>Agreement:</em> <span class="auth">(Ṣ, M, Ḳ, TA:)</span> and <em>familiarity, sociableness, companionship,</em> or <em>friendship.</em> <span class="auth">(Ṣ, TA. <span class="add">[The meanings in this sentence are assigned in the Ṣ only to the latter word: in the TA, only to the former.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OudomapN_A3">
					<p>And the former, <em>Relationship.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OudomapN_A4">
					<p>And <em>A means of access</em> (<span class="ar">وَسِيلَةٌ</span>, Fr, T, Ṣ, M, Ḳ) to a thing, <span class="auth">(Fr, T, Ṣ,)</span> and to a person; <span class="auth">(Fr, T;)</span> as also<span class="arrow"><span class="ar">أَدَمَةٌ↓</span></span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">فُلَانٌ أُدْمَتِى إِلَيْكَ</span> <em>Such a one is my means of access to thee.</em> <span class="auth">(Fr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OudomapN_A5">
					<p>And <span class="add">[hence,]</span> <em>A present which one takes with him in visiting a friend or a great man;</em> in Peraian <span class="ar long">دَسْت آوِيز</span>. <span class="auth">(Ḳ, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OudomapN_A6">
					<p><span class="ar long">هُوَ أُدْمَةُ أَهْلِهِ</span> and <span class="ar long">هُوَ أُدْمَةٌ لِفُلَانٍ</span>: <a href="#OadamapN">see <span class="ar">أَدَمَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أُدْمَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OudomapN_B1">
					<p>In camels, <em>A colour intermixed,</em> or <em>tinged, with blackness,</em> or <em>with whiteness;</em> or <em>clear whiteness;</em> <span class="auth">(M, Ḳ;)</span> or, as some say, <span class="auth">(TA,)</span> <em>intense whiteness;</em> <span class="auth">(Ṣ, TA;)</span> or <em>whiteness, with blackness of the eyeballs:</em> <span class="auth">(Nh, TA:)</span> and in gazelles, <em>a colour intermixed,</em> or <em>tinged, with whiteness:</em> <span class="auth">(M, Ḳ:)</span> or in gazelles and in camels, <em>whiteness:</em> <span class="auth">(T:)</span> and in human beings, <span class="auth">(M, Ḳ,)</span> <em>a tawny colour;</em> or <em>darkness of complexion;</em> syn. <span class="ar">سُمْرَةٌ</span> <span class="add">[q. v.]</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> or <em>an intermixture,</em> or <em>a tinge, of blackness;</em> <span class="auth">(Lth, T;)</span> or <em>intense</em> <span class="ar">سُمْرَة</span> <span class="add">[or <em>tawniness</em>]</span>; and it is said to be from <span class="ar long">أُدْمَةُ الأَرْضِ</span>, meaning <em>the colour of the earth:</em> <span class="auth">(Nh, TA:)</span> or <span class="add">[in men,]</span> <em>i. q.</em> <span class="ar">حُمْرَةٌ</span> <span class="add">[which, in this case, signifies <em>whiteness</em> of complexion]</span>: <span class="auth">(TA:)</span> accord. to AḤn, it signifies <em>whiteness;</em> syn. <span class="ar">بَيَاضٌ</span>. <span class="auth">(M.)</span> <span class="add">[<a href="#Adamu">See also <span class="ar">آدَمُ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadamapN">
				<h3 class="entry"><span class="ar">أَدَمَةٌ</span></h3>
				<div class="sense" id="OadamapN_A1">
					<p><span class="ar">أَدَمَةٌ</span>: <a href="#OudomapN">see <span class="ar">أُدْمَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadamapN_A2">
					<p><span class="ar long">هُوَ أَدَمَةُ أَهْلِهِ</span>,and<span class="arrow"><span class="ar">أُدْمَةُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">أُدْمَتُهُمْ↓</span></span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">أَدْمَتُهُمْ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">أُدْمُهُمْ↓</span></span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">أَدْمُهُمْ↓</span></span>, and<span class="arrow"><span class="ar">إِدَامُهُمْ↓</span></span>, <span class="auth">(Ḳ,)</span> ‡ <em>He is the pattern, exemplar, example,</em> or <em>object of imitation, of his people,</em> or <em>family, by means of whom they are known:</em> <span class="auth">(M, Ḳ:)</span> so says IAạr. <span class="auth">(M.)</span> And <span class="ar long">جَعَلْتُ فُلَانًا أَدَمَةَ أَهْلِى</span> ‡ <em>I made such a one to be the pattern, exemplar, example,</em> or <em>object of imitation, of my people,</em> or <em>family.</em> <span class="auth">(T, Ṣ.)</span> And <span class="ar long">هُوَ أَدَمَةٌ لِفُلَانٍ</span>, and<span class="arrow"><span class="ar">أُدْمَةٌ↓</span></span>, ‡ <em>He is a pattern,</em>, &amp;c., <em>to such a one.</em> <span class="auth">(Fr, TA.)</span> And <span class="ar long">فُلَانٌ أَدَمَةُ بَنِى فُلَانٍ</span> ‡ <em>Such a one is he who makes people to know the sons of such a one.</em> <span class="auth">(T.)</span> And <span class="ar long">هُوَ أَدَمَةُ قَوْمِهِ</span> ‡ <em>He is the chief,</em> and <em>provost, of his people.</em> <span class="auth">(A, TA.)</span> And<span class="arrow"><span class="ar long">فُلَانٌ إِدَامُ↓ قَوْمِهِ</span></span>, and<span class="arrow"><span class="ar long">أُدْمُ↓ بَنى أَبِيهِ</span></span>, ‡ <em>Such a one is the aider, and manager of the affairs,</em> and <em>the support,</em> and <em>right orderer of the affairs, of his people,</em> and <em>of the sons of his father.</em> <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدَمَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OadamapN_B1">
					<p><span class="add">[The <em>inner skin;</em> the <em>cutis,</em> or <em>derma;</em>]</span> the <em>interior of the skin, which is next to the flesh;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> the exterior thereof being called the <span class="ar">بَشَرَة</span>: <span class="auth">(Ṣ:)</span> or <span class="auth">(as some say, M)</span> the <em>exterior thereof, upon which is the hair;</em> the interior thereof being called the <span class="ar">بَشَرَة</span>: <span class="auth">(M, Ḳ:)</span> and<span class="arrow"><span class="ar">أَدَمٌ↓</span></span> may be its pl.; <span class="add">[or rather, a coll. gen. n.;]</span> or, accord. to Sb, it is a quasi-pl. n. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OadamapN_B2">
					<p>Accord. to some, <span class="auth">(M,)</span> <em>What appears of the skin of the head.</em> <span class="auth">(M, Ḳ. <span class="add">[<a href="#baXarapN">See <span class="ar">بَشَرَةٌ</span></a>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OadamapN_B3">
					<p>And † The <em>interior</em> of the earth or ground; <span class="auth">(M, Ḳ;)</span> the surface thereof being called its <span class="ar">أَدِيم</span>: <span class="auth">(M, TA:)</span> or, as some say, its <em>surface.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadamieBN">
				<h3 class="entry"><span class="ar">أَدَمِىٌّ</span></h3>
				<div class="sense" id="OadamieBN_A1">
					<p><span class="ar">أَدَمِىٌّ</span> <em>A seller of</em><span class="add">[<span class="ar">أَدَم</span>, or]</span> <em>skins,</em> or <em>hides:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">أَدَّامٌ↓</span></span> signifies the same; and particularly <em>a seller of goats' skins.</em> <span class="auth">(Golius, from the larger work entitled Mirḳát el-Loghah.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OudomAanN">
				<h3 class="entry"><span class="ar">أُدْماَنٌ</span> / <span class="ar">أُدْمَانَةٌ</span></h3>
				<div class="sense" id="OudomAanN_A1">
					<p><span class="ar">أُدْماَنٌ</span> and <span class="ar">أُدْمَانَةٌ</span>: <a href="#Adamu">see <span class="ar">آدَمُ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IidaAmN">
				<h3 class="entry"><span class="ar">إِدَامٌ</span></h3>
				<div class="sense" id="IidaAmN_A1">
					<p><span class="ar">إِدَامٌ</span> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أُدْمٌ↓</span></span> <span class="auth">(the same except the Ḳ)</span> <span class="add">[<em>Seasoning,</em> or <em>condiment,</em> for bread; and <em>any savoury food;</em>]</span> <em>what is used for seasoniny</em> (<span class="ar long">مَا يُؤْتَدَمُ بِهِ</span>, T, Ṣ, M,* Mgh, Mṣb, Ḳ) <em>with bread;</em> <span class="auth">(T, TA;)</span> <em>that which renders bread pleasant and good and savoury;</em> <span class="auth">(IAmb, Mgh;)</span> <em>whether fluid or not fluid;</em> <span class="auth">(Mgh, Mṣb;)</span> <span class="ar">صِبْغٌ</span> and <span class="ar">صِبَاغٌ</span> being peculiarly applied to that which is fluid: <span class="auth">(Mgh:)</span> or <span class="ar">أُدْمٌ</span> is <em>anything that is eaten with bread:</em> <span class="auth">(TA:)</span> the pl. <span class="add">[of mult.]</span> of <span class="ar">إِدَامٌ</span> is <span class="ar">أُدُمٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> and, by contraction, <span class="ar">أُدْمٌ</span>, which is also used as the sing., <span class="auth">(Mṣb,)</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">آدِمَةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">آدَامٌ</span>; <span class="auth">(Ḳ;)</span> or this last <a href="#OudomN">is pl. of <span class="ar">أُدْمٌ</span></a>. <span class="auth">(M, Mgh, Mṣb, TA.)</span> It is said in a trad., <span class="ar long">نِعْمَ الإِدَامُ الخَلُّ</span> <span class="add">[<em>Excellent,</em> or <em>most excel-lent, is the seasoning, vinegar!</em>]</span>. <span class="auth">(T, TA.)</span> And in another, <span class="ar long">سَيِّدُ آدَامِ الدُّنْيَا وَالآخِرَةِ اللَّحْمُ</span> <span class="add">[<em>The prince of the seasonings of the present world and of the world to come is flesh-meat</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">إِدَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IidaAmN_A2">
					<p><span class="ar long">هُوَ إِدَامُ أَهْلِهِ</span>, and <span class="ar long">إِدَامُ قَوْمِهِ</span>: <a href="#OadamapN">see <span class="ar">أَدَمَةٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">إِدَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IidaAmN_A3">
					<p>Anything <em>conforming,</em> or <em>conformable; agreeing,</em> or <em>agreeable; suiting,</em> or <em>suitable.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[Used also as a pl.: thus,]</span> 'Ádiyeh Ed-Dubeyreeyeh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">كَانُوا لِمَنْ خَالَطَهُمْ إِدَامَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>They were, to those who mixed with them in social intercourse, conformable,</em> or <em>agreeable.</em>]</span> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadiymN">
				<h3 class="entry"><span class="ar">أَدِيمٌ</span></h3>
				<div class="sense" id="OadiymN_A1">
					<p><span class="ar">أَدِيمٌ</span> <em>i. q.</em><span class="arrow"><span class="ar">مَأْدُومٌ↓</span></span> <span class="add">[<em>Seasoned</em>]</span>: <span class="auth">(T:)</span> or<span class="arrow"><span class="ar long">طَعَامٌ مَأْدُومٌ↓</span></span> <span class="add">[<em>seasoned food</em>]</span>; <span class="auth">(M, Ḳ;)</span> <em>food in which is</em> <span class="ar">إِدَام</span>. <span class="auth">(TA.)</span> Hence the prov., <span class="ar long">سَمْنُكُمْ هُرِيقَ فِى أَدِيمِكُمْ</span> <span class="add">[<em>Your clarified butter is poured into your seasoned food</em>]</span>; <span class="auth">(T, TA;)</span> applied to a niggardly man; <span class="auth">(Ḥar p. 462;)</span> meaning, your good, or wealth, returns unto you: <span class="auth">(TA:)</span> or, as some say, the meaning is, <em>into your</em> <span class="ar">سِقَآء</span> <span class="add">[or <em>skin</em>]</span>: <span class="auth">(T, Ḥar * ubi suprà:)</span> and the vulgar say, <span class="ar long">فِى دَقِيقِكُمْ</span> <span class="add">[<em>into your flour</em>]</span>. <span class="auth">(TA.)</span> And the saying, <span class="ar long">سَمْنُهُمْ فِى أَدِيمِهِمْ</span> <span class="add">[<em>Their clarified butter is in their seasoned food</em>]</span>; meaning, their good, or wealth, returns unto them. <span class="auth">(M.)</span> And the saying of Khadeejeh to the Prophet,<span class="arrow"><span class="ar long">إِنَّكَ لَتَكْسِبُ المَعْدُومَ↓ وَتُطْعِمُ المَأْدُومَ</span></span> <span class="auth">(M, TA)</span> <em>Verily thou gainest what is denied to others,</em> or <em>makest</em> others <em>to gain what they have not, of the things they want,</em> or <em>makest the poor to gain,</em> <span class="auth">(TA in art. <span class="ar">عدم</span>,)</span> <em>and givest to eat food in which is</em> <span class="ar">إِدَام</span>. <span class="auth">(TA in the present art.)</span> <span class="add">[Hence also,]</span><span class="arrow"><span class="ar long">أَطْعَمْتُكَ مَأْدُومِى↓</span></span> <span class="auth">(M, Ḳ)</span> meaning <span class="ar long">أَتَيْتُكَ بِعُذْرِى</span> <span class="add">[<em>I gave thee my excuse;</em> or, perhaps, <em>my virginity;</em> <a href="#EucorapN">see <span class="ar">عُذْرَةٌ</span></a>]</span>: <span class="auth">(Ḳ:)</span> <span class="add">[or,]</span> as some say, the meaning is, <em>my good manners:</em> said by the wife of Dureyd Ibn-Eṣ-Ṣimmeh, on the occasion of his divorcing her. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadiymN_A2">
					<p>And hence, <span class="auth">(Ḥam p. 205, Mgh,)</span> <em>Tanned skin</em> or <em>hide; leather:</em> <span class="auth">(M, Ḥam, Mgh, Mṣb:)</span> or <em>skin,</em> or <em>hide,</em> <span class="auth">(M, Ḳ,)</span> <em>in whatever state it be:</em> <span class="auth">(M:)</span> or <em>red skin</em> or <em>hide:</em> <span class="auth">(M, Ḳ:)</span> or <em>skin,</em> or <em>hide, in the state after that in which it is termed</em> <span class="ar">أَفِيقٌ</span>; <em>that is, when it is complete</em> <span class="add">[<em>in its tanning</em>]</span> <em>and has become red:</em> <span class="auth">(M:)</span> or the <em>exterior of the skin</em> of anything: <span class="auth">(T:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آدِمَةٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">آدَامٌ</span> and <span class="add">[of mult.]</span> <span class="ar">أُدُمٌ</span>, <span class="auth">(M, Ḳ,)</span> the last from Lḥ, and <span class="add">[says ISd]</span> I hold that he who says <span class="ar">رُسْلٌ</span> says <span class="ar">أُدْمٌ</span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">أَدَمٌ↓</span></span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> or this is a quasi-pl. n., <span class="auth">(Sb, M, Mgh,)</span> <span class="add">[often used as a gen. n.,]</span> of which <span class="ar">آدَامٌ</span> may be pl. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OadiymN_A3">
					<p><span class="ar long">اِبْنِ أَدِيمٍ</span> and <span class="ar long">اِبْنُ أَدِيمَيْنِ</span> and <span class="ar long">اِبْنُ ثَلَاثَةِ آدِمَةٍ</span>: <a href="#IibonN">see <span class="ar">اِبْنٌ</span></a> <a href="index.php?data=02_b/198_bne">in art. <span class="ar">بنى</span></a>. One says, <span class="ar long">إِنَّمَا يُعَاتَبُ الأَدِيمُ ذُو البَشَرَةِ</span> <span class="add">[lit.]</span> <em>Only the hide that has the exterior part, upon which the hair grows, is put again into the tan:</em> <span class="auth">(T:)</span> <span class="pb" id="Page_0037"></span>a prov.; <span class="auth">(TA;)</span> meaning, only he is disciplined, or reproved, who is an object of hope, and in whom is full intelligence, and strength; <span class="auth">(T, TA, and AḤn in TA, art. <span class="ar">بشر</span> <span class="add">[where, however, in the TA, <span class="ar">دُونَ</span> is erroneously put for <span class="ar">ذو</span>]</span>;)</span> and only he is disputed with in whom is place for dispute. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OadiymN_A4">
					<p><span class="ar long">أَدِيمُ الحَرْبِ</span> is used metaphorically for <span class="ar long">أَدِيمُ أَهْلِ الحَرْبِ</span> ‡ <span class="add">[<em>The skin of the warriors,</em> or <em>of the people engaged in war</em> or <em>fight</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OadiymN_A5">
					<p><span class="ar long">فُلَانٌ صَحِيحُ الأَدِيمِ</span> <span class="add">[lit. <em>Such a one is sound of skin</em>]</span> means ‡ <em>such a one is sound in respect of origin,</em> and <em>of honour,</em> or <em>reputation.</em> <span class="auth">(Ḥar p. 135.)</span> You say also, <span class="ar long">فُلَانٌ بَرِىْءُ الأَدِيمِ مِمَّا لُطِخَ بِهِ</span> <span class="add">[meaning ‡ <em>Such a one is clear in honour,</em> or <em>reputation, of that with which he has been aspersed</em>]</span>. <span class="auth">(M,* TA.)</span> And<span class="arrow"><span class="ar long">مَزَّقَ أَدَمِى↓</span></span> ‡ <em>He rent my honour,</em> or <em>reputation.</em> <span class="auth">(Ḥar ubi suprà.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OadiymN_A6">
					<p><span class="ar">أَدِيمٌ</span> also signifies ‡ The <em>surface</em> of the earth or ground: <span class="auth">(Ṣ, M:)</span> <span class="add">[<a href="#OadamapN">see also <span class="ar">أَدَمَةٌ</span></a>, last sentence:]</span> or <em>what appears</em> thereof, <span class="auth">(Ḳ,)</span> and of the sky. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OadiymN_A7">
					<p>And ‡ The <em>first part</em> of the period called <span class="ar">الضُّحَى</span>. <span class="auth">(M, Ḳ, TA.)</span> You say, <span class="ar long">جِئْتُكَ أَدِيمَ الضُّحَى</span> ‡ <em>I came to thee in the first part of the</em> <span class="ar">ضحى</span>; <span class="auth">(Lḥ, M;)</span> app. meaning, <span class="ar long">عِنْدَ ٱرْتِفَاعِ الضُّحَى</span> <span class="add">[<em>when the morning was becoming advanced; when the sun was becoming high</em>]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">أَدِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OadiymN_A8">
					<p>And ‡ The <em>whiteness</em> of day: <span class="auth">(IAạr, M, Ḳ, TA:)</span> and ‡ the <em>darkness</em> of night: <span class="auth">(IAạr, M, TA:)</span> or ‡ the <em>whole</em> of the day, <span class="auth">(M, A, Ḳ, TA,)</span> and of the night. <span class="auth">(A, TA.)</span> You say, <span class="ar long">ظَلَّ أَدِيمَ النَّهَارِ صَائِمًا وَأَدِيمَ اللَّيْلِ قَائِمًا</span> ‡ <em>He continued the whole of the day fasting, and the whole of the night standing</em> <span class="add">[in prayer, &amp;c.]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OadBaAmN">
				<h3 class="entry"><span class="ar">أَدَّامٌ</span></h3>
				<div class="sense" id="OadBaAmN_A1">
					<p><span class="ar">أَدَّامٌ</span>: <a href="#OadamieBN">see <span class="ar">أَدَمِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mdamu">
				<h3 class="entry"><span class="ar">آدَمُ</span></h3>
				<div class="sense" id="Mdamu_A1">
					<p><span class="ar">آدَمُ</span> <em>Of the colour termed</em> <span class="ar">أُدْمَةٌ</span>: pl. <span class="ar">أُدْمٌ</span> and<span class="arrow"><span class="ar">أُدْمَانٌ↓</span></span>; <span class="auth">(Ṣ, M, Ḳ;)</span> the latter like <span class="ar">حُمْرَانٌ</span> <a href="#OaHomaru">as a pl. of <span class="ar">أَحْمَرُ</span></a>: <span class="auth">(M:)</span> the fem. sing. is <span class="ar">أَدْمَآءُ</span> and<span class="arrow"><span class="ar">أُدْمَانَةٌ↓</span></span>; <span class="auth">(Ṣ M, Ḳ;)</span> the latter anomalous; <span class="auth">(Ḳ;)</span> occurring in poetry, but disapproved <span class="auth">(Ṣ, M)</span> by Aṣ; <span class="auth">(Ṣ;)</span> said by Aboo-ʼAlee to be like <span class="ar">خُمْصَانَةٌ</span>; <span class="auth">(M;)</span> and the fem. pl. is <span class="ar">أُدْمٌ</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> applied to a camel, <em>of a colour intermixed,</em> or <em>tinged, with blackness,</em> or <em>with whiteness;</em> or <em>of a clear white;</em> <span class="auth">(M, Ḳ;)</span> or, as some say, <em>intensely white;</em> <span class="auth">(TA;)</span> or <em>white, and black in the eyeballs;</em> <span class="auth">(Ṣ;)</span> or <em>white;</em> <span class="auth">(Aṣ, T;)</span> and so applied to a gazelle: <span class="auth">(T:)</span> or, applied to a gazelle, <em>of a colour intermixed,</em> or <em>tinged, with whiteness;</em> <span class="auth">(M, Ḳ;)</span> Lth, however, says that <span class="ar">أَدْمَآءُ</span> is applied to a female gazelle, but he had not heard <span class="ar">آدَمُ</span> applied to the male gazelle; <span class="auth">(TA;)</span> and Aṣ says, <span class="auth">(Ṣ,)</span> <span class="ar">أُدْمٌ</span> applied to gazelles signifies <em>white, having upon them streaks in which is a dust-colour,</em> <span class="auth">(Ṣ, M,)</span> <em>inhabiting the mountains,</em> and <em>of the colour of the mountains;</em> <span class="auth">(Ṣ;)</span> if of a pure white colour, they are termed <span class="ar">آرَامٌ</span>: <span class="auth">(T, TA:)</span> or, accord. to ISk, <em>white in the bellies, tawny in the backs, and having the colour of the bellies and of the backs divided by two streaks of the colour of musk;</em> and in like manner explained by IAạr: <span class="auth">(T:)</span> applied to a human being, <span class="ar">آدَمُ</span> signifies <em>tawny;</em> or <em>dark-complexioned;</em> syn. <span class="ar">أَسْمَرُ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> or, thus applied, it signifies <span class="ar long">أحْمَرُ اللَّوْنِ</span> <span class="add">[which, in this case, means <em>white of complexion</em>]</span>; <span class="auth">(TA;)</span> and the pl. is <span class="ar">أُدْمِانٌ</span>. <span class="auth">(Ṣ.)</span> The Arabs say, <span class="ar long">قُرَيْشُ الإِبِلِ أُدْمُهَا وَصُهْبُهَا</span>, meaning <em>The best of camels are those of them which are</em> <span class="ar">أُدْم</span> <em>and those of them which are</em> <span class="ar">صُهْب</span>; <span class="add">[<a href="#OaSohabu">see <span class="ar">أَصْهَبُ</span></a>;]</span> like as Kureysh are the best of men. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">آدَمُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Mdamu_A2">
					<p>Also <span class="add">[<em>Adam,</em>]</span> <em>the father of mankind;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> and likewise <span class="arrow"><span class="ar">أَدَمُ↓</span></span>; but this is extr.: <span class="auth">(Ḳ:)</span> there are various opinions respecting its derivation; but <span class="add">[these it is unnecessary to mention, for]</span> the truth is that it is a foreign word, <span class="add">[i. e. Hebrew,]</span> of the measure <span class="ar">فَاعَلُ</span>, like <span class="ar">آزَرُ</span>: <span class="auth">(MF:)</span> and <span class="add">[therefore]</span> its pl. is <span class="ar">أَوَادِمُ</span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MdamieBN">
				<h3 class="entry"><span class="ar">آدَمِىٌّ</span></h3>
				<div class="sense" id="MdamieBN_A1">
					<p><span class="ar">آدَمِىٌّ</span> <span class="add">[<em>Of,</em> or <em>relating to, Adam:</em> and hence, <em>human:</em> and <em>a human being:</em>]</span> a rel. n. from <span class="ar">آدَمُ</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiydaAmapN">
				<h3 class="entry"><span class="ar">إِيدَامَةٌ</span></h3>
				<div class="sense" id="IiydaAmapN_A1">
					<p><span class="ar">إِيدَامَةٌ</span> † <em>Level, hard, but not rugged, ground:</em> <span class="auth">(Aṣ:)</span> or <em>hard ground without stones;</em> <span class="auth">(Ḳ;)</span> from <span class="ar">أَدِيمٌ</span> signifying the “surface” of the earth or ground: <span class="auth">(TA:)</span> or <em>ground somewhat elevated; not much so; only found in plains, and producing vegetation, which, however, is disapproved, because its situation is rugged, and little water remains in it:</em> <span class="auth">(ISh:)</span> pl. <span class="ar">أَيَادِيمُ</span>, <span class="auth">(Aṣ, Esh-Sheybánee, IB, Ḳ,)</span> which J erroneously says has no sing.: <span class="auth">(Ḳ:)</span> for he says, <span class="add">[in the Ṣ,]</span> <span class="ar">أَيَادِيمُ</span> signifies <em>hard and elevated tracts</em> (<span class="ar">مُتُون</span>) <em>of ground;</em> and has no sing. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWodamN">
				<h3 class="entry"><span class="ar">مُؤْدَمٌ</span> / <span class="ar">مُؤْدَمَةٌ</span></h3>
				<div class="sense" id="muWodamN_A1">
					<p><span class="ar">مُؤْدَمٌ</span>, as in an ex. cited above, (<a href="#Adm_1">see 1</a>,) <em>Made an object of love;</em> <span class="auth">(T, Ṣ;)</span> <em>a proper object of love.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادم</span> - Entry: <span class="ar">مُؤْدَمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWodamN_B1">
					<p><span class="ar long">رَجُلٌ مُؤْدَمٌ مُبْشَرٌ</span> ‡ <em>A man who is skilful, and experienced in affairs,</em> <span class="auth">(M, Ḳ,)</span> <em>who combines</em> <span class="add">[<em>qualities like</em>]</span> <em>softness of the interior skin and roughness of the exterior skin:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> or <em>who combines softness and hardness,</em> or <em>gentleness and force, with knowledge of affairs:</em> <span class="auth">(T:)</span> or <em>who combines such qualities that he is suited to hardship and to easiness of circumstances:</em> <span class="auth">(Aṣ, T:)</span> or, accord. to IAạr, <em>having a thick and good skin:</em> <span class="auth">(M:)</span> or <em>beloved:</em> <span class="auth">(TA:)</span> the fem. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">مُؤْدَمَةٌ</span>}</span></add>: <span class="auth">(M, Ḳ:)</span> you say, <span class="ar long">اِمْرَأَةٌ مُؤْدَمَةٌ مُبْشَرَةٌ</span>, meaning ‡ <em>a woman goodly in her aspect and faultless in her intrinsic qualities:</em> and sometimes the former epithet, with and without <span class="ar">ة</span>, as applied to a woman and to a man respectively, is put after the latter. <span class="auth">(M.)</span> <a href="index.php?data=02_b/109_bXr">See also art. <span class="ar">بشر</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOoduwmN">
				<h3 class="entry"><span class="ar">مَأْدُومٌ</span></h3>
				<div class="sense" id="maOoduwmN_A1">
					<p><span class="ar">مَأْدُومٌ</span>: <a href="#OadiymN">see <span class="ar">أَدِيمٌ</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0035.pdf" target="pdf">
							<span>Lanes Lexicon Page 35</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0036.pdf" target="pdf">
							<span>Lanes Lexicon Page 36</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0037.pdf" target="pdf">
							<span>Lanes Lexicon Page 37</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
