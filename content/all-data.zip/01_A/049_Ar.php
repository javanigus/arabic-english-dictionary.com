<article class="root" id="Root_Ar">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/048_Ace">اذى</a></span>
				<span class="ar">ار</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/050_Arb">ارب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ar_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرّ</span></h3>
				<div class="sense" id="Ar_1_A1">
					<p><span class="ar">أَرَّهَا</span>, aor. <span class="ar">يَؤُرُّ</span> <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">أَرٌّ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>Inivit eam; he compressed her.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IirBa">
				<h3 class="entry"><span class="ar long">إِرَّ إِرَّ</span></h3>
				<div class="sense" id="IirBa_A1">
					<p><span class="ar long">إِرَّ إِرَّ</span>, <span class="auth">(M, TT, L, <span class="add">[and so in the present day,]</span>)</span> or <span class="ar long">أَرْ أَرْ</span>, <span class="auth">(Ḳ,)</span> <em>A cry by which sheep or goats are called.</em> <span class="auth">(M, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYarBN">
				<h3 class="entry"><span class="ar">مِئَرٌّ</span></h3>
				<div class="sense" id="miYarBN_A1">
					<p><span class="ar">مِئَرٌّ</span> A man <span class="auth">(Ṣ,)</span> <em>much addicted to venery:</em> <span class="auth">(Ṣ, Ḳ:)</span> so accord. to AʼObeyd, as related by Sh and El-Iyádee, but thought by Az to be <span class="ar">مَئِيرٌ</span>, of the same measure as <span class="ar">مَعِيرٌ</span>, i. e., <span class="ar">مَفْعِلٌ</span>, <span class="add">[originally <span class="ar">مَأْيِرٌ</span>,]</span> from <span class="ar">آرَهَا</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0044.pdf" target="pdf">
							<span>Lanes Lexicon Page 44</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
