<article class="root" id="Root_Abw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/010_Abh">ابه</a></span>
				<span class="ar">ابو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/012_Abe">ابى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Abw_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبو</span> ⇒ <span class="ar">أبى</span></h3>
				<div class="sense" id="Abw_1_A1">
					<p><span class="ar">أَبَوْتُ</span>, <span class="add">[third pers. <span class="ar">أَبَا</span>,]</span> <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar">أَبَيْتُ</span>, <span class="add">[third pers. <span class="ar">أَبَى</span>,]</span> <span class="auth">(T, M, Ḳ,)</span> the latter accord. to Yz, <span class="auth">(T,)</span> aor. <span class="ar">آبُو</span>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">أُبُوَّةٌ</span>, <span class="auth">(Yz, T, Ṣ, Mṣb,)</span> or this is a simple subst., <span class="auth">(M,)</span> <em>I became a father.</em> <span class="auth">(T,* Ṣ,* M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Abw_1_B1">
					<p><span class="ar">أَبَوْتُهُ</span>, <span class="auth">(ISk, T, M, Ḳ,)</span> aor. <span class="ar">آبُوهُ</span>, <span class="auth">(IAạr, ISk, T,)</span> inf. n. <span class="ar">إِبَاوَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>I was,</em> <span class="auth">(IAạr, ISk, T,)</span> or <em>became,</em> <span class="auth">(M, Ḳ,)</span> <em>a father to him.</em> <span class="auth">(IAạr, ISk, T, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Abw_1_B2">
					<p><span class="add">[Hence, <em>I fed him,</em> or <em>nourished him;</em> and <em>reared him,</em> or <em>brought him up.</em>]</span> You say, <span class="ar long">فُلَانٌ يَأْبُو هٰذَا اليَتِيمَ</span>, inf. n. <span class="ar">إِبَاوَةٌ</span>, <em>Such a one feeds,</em> or <em>nourishes, this orphan, like as the father does his children.</em> <span class="auth">(Lth, T.)</span> And <span class="ar long">مَالَهُ أَبٌ يَأْبُوهُ</span> <span class="auth">(ISk, T, Ṣ)</span> <em>He has not a father to feed him,</em> or <em>nourish him, and to rear him,</em> or <em>bring him up.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abw_2">
				<h3 class="entry">2. ⇒ <span class="ar">أبّو</span> ⇒ <span class="ar">أبّى</span></h3>
				<div class="sense" id="Abw_2_A1">
					<p><span class="ar">أَبَّيْتُهُ</span>, inf. n. <span class="ar">تَأْبِيَةٌ</span>, <em>I said to him</em> <span class="ar">بِأَبِى</span> <span class="add">[meaning <span class="ar long">فُدِيَتِ بِأَبِى</span> <em>Mayest thou be ransomed with my father!</em> or the like: <a href="#OabN">see <span class="ar">أَبٌ</span>, below</a>]</span>. <span class="auth">(Ḳ, TA. <span class="add">[In the CK, erroneously, <span class="ar long">يا اَبِى</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Abw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّو</span> ⇒ <span class="ar">تأبّى</span></h3>
				<div class="sense" id="Abw_5_A1">
					<p><span class="ar">تأبّاهُ</span> <em>He adopted him as a father;</em> <span class="auth">(M, Ḳ, TA;)</span> as also<span class="arrow"><span class="ar">استأباهُ↓</span></span>; <span class="auth">(M in art. <span class="ar">اب</span>;)</span> and so <span class="ar long">تأبّاهُ أَبًا</span>, accord. to AʼObeyd: <span class="auth">(TA:)</span> <span class="add">[or,]</span> accord. to AʼObeyd, you say, <span class="ar long">تَأَبَّيْتُ أَبًا</span> <em>I adopted a father:</em> <span class="auth">(T:)</span> and you say also, <span class="ar long">اِسْتَأَبَّ أَبًا</span> and <span class="ar long">اِسْتَأْبَبَ أَبًا</span> <em>he adopted a father.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Abw_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأباه</span></h3>
				<div class="sense" id="Abw_10_A1">
					<p><a href="#Abw_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabN.1">
				<h3 class="entry"><span class="ar">أَبٌ</span></h3>
				<div class="sense" id="OabN.1_A1">
					<p><span class="ar">أَبٌ</span> is originally <span class="ar">أَبَوٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> as is shown by the first of its dual forms and of its pl. forms mentioned below; <span class="auth">(Ṣ, Mṣb;)</span> and signifies <em>A father</em> <span class="add">[in the ordinary sense: and also as meaning † <em>an ancestor</em>]</span>: <span class="auth">(M:)</span> as also<span class="arrow"><span class="ar">أَبًا↓</span></span>, a dial. var., <span class="auth">(M, Ḳ,)</span> the same in the nom. and accus. and gen. cases, like <span class="ar">قَفًا</span>: <span class="auth">(M:)</span> and <span class="ar">أَبٌّ</span> is a dial. var. of the same, <span class="add">[the second letter being doubled to compensate for the <span class="ar">و</span> suppressed, as is the case in <span class="ar">أَخٌّ</span>, <span class="auth">(TA voce <span class="ar">أَخٌ</span>)</span>]</span> but is rare. <span class="auth">(Mṣb.)</span> Accord. to the dial. commonly obtaining, when you use it as a prefixed noun, you decline it with the letters <span class="ar">و</span> and <span class="ar">ا</span> and <span class="ar">ى</span>, saying, <span class="ar">هٰذَاأَبُوهُ</span> <span class="add">[<em>This is his father</em>]</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">أَبُوكَ</span> <span class="add">[<em>thy father</em>]</span>; <span class="auth">(M;)</span> and <span class="ar long">رَأَيْتُ أَبَاهُ</span> <span class="add">[<em>I saw his father</em>]</span>; and <span class="ar long">مَرَرْتُ بِأَبِيهِ</span> <span class="add">[<em>I passed by his father</em>]</span>: <span class="auth">(Mṣb:)</span> but accord. to one dial., you say, <span class="ar long">هٰذَا أَبَاهُ</span>, <span class="auth">(Mṣb:)</span> and <span class="ar">أَبَاكَ</span>; <span class="auth">(M;)</span> and <span class="ar long">رَأَيْتُ أَبَاهُ</span>; and <span class="ar long">مَرَرْتُ بِأَبَاهُ</span>: <span class="auth">(Mṣb:)</span> and accord. to one dial., which is the rarest of all, it is defective in every case, like <span class="ar">يَدٌ</span> and <span class="ar">دَمٌ</span>; <span class="auth">(Mṣb;)</span> and <span class="add">[thus]</span> you say, <span class="ar long">هٰذَا أَبُوكَ</span> <span class="add">[&amp;c.]</span>. <span class="auth">(M.)</span> The dual is <span class="ar">أَبَوَانِ</span>, <span class="auth">(Ṣ, M, Mṣb,)</span> meaning <span class="add">[<em>two fathers,</em> and]</span> <em>father and mother;</em> and some say <span class="ar">أَبَانِ</span>: <span class="auth">(Ṣ, M:)</span> you say, <span class="ar">هُمَاأَبَوَاهُ</span>, meaning <em>They two are his father and mother;</em> and in poetry you may say, <span class="ar long">هُمَا أَبَاهُ</span>; and in like manner, <span class="ar long">رَأَيْتُ أَبَيْهِ</span> <span class="add">[<em>I saw his father and mother</em>]</span>, <span class="auth">(T,)</span> and <span class="ar">أَبَيْكَ</span> <span class="add">[<em>thy father and mother</em>]</span>; <span class="auth">(Ṣ;)</span> but the usual, or chaste, form is <span class="ar long">رَأَيْتُ أَبَوَيْهِ</span>. <span class="auth">(T.)</span> The pl. is <span class="ar">آبَآءٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> the best form, <span class="auth">(T,)</span> and <span class="ar">أَبُونَ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar">أُبُوٌّ</span> <span class="auth">(M, Ḳ, <span class="add">[in the CK <span class="ar">الاَبْوٌ</span> is erroneously put for <span class="ar">الأُبُوٌّ</span>,]</span>)</span> and <span class="ar">أُبُوَّةٌ</span>, <span class="auth">(Lḥ, T, Ṣ, M, Ḳ,*)</span> like <span class="ar">عُمُومَةٌ</span> and <span class="ar">خُؤُولَةٌ</span>: <span class="auth">(T, Ṣ:)</span> you say, <span class="ar long">هٰؤُلَآءِ أَبُوكُمْ</span>, meaning <span class="ar">آبَاؤُكُمْ</span> <span class="add">[<em>These are your fathers</em>]</span>; <span class="auth">(T;)</span> and hence, in the Ḳur <span class="add">[ii. 127]</span>, accord. to one reading, <span class="ar long">وَإِلٰهَ أَبِيكَ إِبرٰهِيمَ وَإِسْمٰعِيلَ وَإِسْحٰقَ</span> <span class="add">[<em>And the God of thy fathers, Abraham and Ishmael and Isaac</em>]</span>, meaning <a href="#AbN">the pl. of <span class="ar">أبٌ</span></a>, i. e. <span class="ar">أَبِينَكَ</span>, of which the <span class="ar">ن</span> is suppressed because the noun is prefixed <span class="add">[to the pronoun]</span>; <span class="auth">(Ṣ;)</span> and some of the Arabs say, <span class="ar long">أَبُوَّتُنَا أَكْرَمُ الآبَآءِ</span> <span class="add">[<em>Our fathers are the most generous of fathers</em>]</span>. <span class="auth">(T.)</span> The dim. is<span class="arrow"><span class="ar">أُبَّىٌّ↓</span></span>; originally <span class="ar">أُبَيْوٌ</span>, with the final radical letter restored. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OabN.1_A2">
					<p><span class="ar long">مَا يَدْرِى لَهُ مِنْ أَبٍ</span>, and <span class="ar long">مَا أَبٌ</span>, mean- <em>ing He knows not who is his father,</em> and <em>what is his father,</em> are sayings mentioned by Lḥ on the authority of Ks. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OabN.1_A3">
					<p><span class="ar long">لَا أَبَا لِكَ</span>, <span class="auth">(T, Ṣ, M, Ḳ, &amp;c.,)</span> <span class="add">[accord. to the dial. of him who says <span class="ar">أَبًا</span> instead of <span class="ar">أَبٌ</span>,]</span> as also <span class="ar long">لَا أَبَ لَكَ</span>, and <span class="ar long">لَا أَبَاكَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <span class="add">[the last, accord. to J, because the <span class="ar">ل</span> <span class="auth">(meaning the <span class="ar">ل</span> in <span class="ar">لك</span> in the preceding phrases)</span> is as though it were redundant, but he seems not to have known the dial. var. <span class="ar">أَبًا</span>, and I rather think that <span class="ar long">لَا أَبَاكَ</span>, is for <span class="ar long">لَا أَبْقَى ٱللّٰهُ أَبَاكَ</span>, or the like,]</span> and <span class="ar long">لَا أَبَكَ</span>, <span class="auth">(Mbr, Ṣgh, Ḳ,)</span> and <span class="ar long">لَابَ لَكَ</span>, <span class="auth">(Ḳ,)</span> which is for <span class="ar long">لَا أَبَ لَكَ</span>, <span class="auth">(M,)</span> means Thou art, in my estimation, one deserving of its being said to him, <em>Mayest thou have no father!</em> it is used in the manner of a proverb, is of frequent occurrence in poetry, <span class="auth">(M,)</span> is said to him who has a father and to him who has not a father, and is an imprecation as to the meaning, of necessity, though enunciative as to the letter; <span class="auth">(M, Ḳ;)</span> and hence the saying of Jereer,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا تَيْمُ تَيْمَ عَدِىٍّ لَا أَبَا لَكُمْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O Teym, Teym of 'Ades, may ye have no father!</em>]</span>; <span class="pb" id="Page_0011"></span>which is the strongest evidence of its being a proverb, and not having a literal meaning; for all of <span class="add">[the tribe of]</span> Teym could not have one father, but all of them were fit objects of imprecation and rough speech: <span class="auth">(M:)</span> it is an expression of praise: <span class="auth">(Ṣ:)</span> <span class="add">[i. e.]</span> it is an imprecation against him to whom it is addressed, not, however, said with the desire of its having effect, but on an occasion of intense love, like <span class="ar long">لَا أُمَّ لَكَ</span>, &amp;c.: <span class="auth">(Ḥar p. 165:)</span> and sometimes in dispraise, like <span class="ar long">لَا أُمَّ لَكَ</span>: and in wonder, like <span class="ar long">لِلّهِ دَرُّكَ</span>: <span class="auth">(TA:)</span> or, as AHeyth says, on the authority of Aboo-Saʼeed Ed-Dareer, it expresses the utmost degree of reviling; <span class="add">[meaning <em>Thou hast no</em> known <em>father;</em>]</span> and <span class="ar long">لَا أُمَّ لَكَ</span> expresses reviling also, but means Thou hast no free, or ingenuous, mother: <span class="auth">(Meyd in Ḥar p. 165: <span class="add">[<a href="#OumBa">see <span class="ar">أُمَّ</span></a>:]</span>)</span> sometimes it means <em>Strive,</em> or <em>exert thyself, in thine affair;</em> for he who has a father relies upon him in some circumstances of his case: <span class="auth">(TA:)</span> accord. to Kh, it means <em>Thou hast none to stand thee in stead of thyself:</em> <span class="auth">(ISh, TA:)</span> Fr says that it is a phrase used by the Arabs <span class="add">[parenthetically, i.e.,]</span> to divide their speech: <span class="auth">(TA:)</span> <span class="add">[thus, for instance,]</span> Zufar Ibn-El-Hárith says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَرِينِى سِلَاحِى لَا أَبَا لَكَ إِنَّنِى</span> *</div> 
						<div class="star">* <span class="ar long">أَرَى الحَرْبَ لَا تَزْدَادُ إِلَّا تَمَادِيَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Show thou me my weapons:</em> (<em>mayest thou have no father!</em> or <em>thou hast no father:</em>, &amp;c.:) <em>verily I see the war,</em> or <em>battle, increases not save in perseverance</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[Aboo-ʼAlee, as cited in the M, observes that the <span class="ar">ا</span> <span class="auth">(meaning the final <span class="ar">ا</span>)</span> in <span class="ar">أَبَا</span>, in the phrase <span class="ar long">لَا أَبَا لَكَ</span>, indicates that it is a prefixed noun, and determinate; whereas the <span class="ar">ل</span> in <span class="ar">لك</span> together with the government exercised upon the noun by <span class="ar">لا</span> indicates that it is, on the contrary, indeterminate, and separate from what follows it: but it seems that he was unacquainted with the dial. var. <span class="ar">أَبَّا</span>; for <span class="ar long">لَا أَبَا لَكَ</span> in the dial. of him who uses the form <span class="ar">أَبَّا</span> instead of <span class="ar">أَبٌ</span> is the same grammatically as <span class="ar long">لَا أَبَ لَكَ</span> in the dial. of him who uses the form <span class="ar">أَبٌ</span>.]</span> Suleymán Ibn-ʼAbd-El-Melik heard an Arab of the desert, in a year of drought, say, <span class="ar long">أَنْزِلْ عَلَيْنَا الغَيْثَ لَا أَبَا لَكَ</span>, and Suleymán put the best construction upon it, <span class="add">[as though it meant, <em>Send down upon us rain: Thou hast no father</em>]</span>, and said, I testify that He hath no father nor female companion nor offspring. <span class="auth">(TA.)</span> They say also, in paying honour <span class="add">[to a person]</span>, <span class="ar long">لَا أَبَ لِشَانِئِكَ</span>, and <span class="ar long">لَا أَبَ لِشَانِئِكَ</span>, <span class="auth">(TA,)</span> i. e. <em>May thy hater have no father!</em> or, accord. to ISk, each is a metonymical expression for <span class="ar long">لَا أَبَا لَكَ</span>. <span class="auth">(Ṣ in art. <span class="ar">شنأ</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OabN.1_A4">
					<p>One also says, on the occasion of an occurrence that is approved and commended, by way of expressing wonder and praise, <span class="ar long">لَلِّهِ أَبُوكَ</span>, meaning <em>To God, purely, is attributable</em> <span class="add">[<em>the excellence of</em>]</span> <em>thy father, seeing that he begat thee a generous son, and produced the like of thee!</em> <span class="auth">(TA;)</span> <span class="add">[or <em>to God be attributed</em> (<em>the excellence of</em>) <em>thy father!</em>]</span> it means that to God <span class="add">[alone]</span> belongs the power to create the like of this man <span class="add">[to whom it relates]</span>, from whom has proceeded this wonderful action. <span class="auth">(Ḥar p. 44.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OabN.1_A5">
					<p>And <span class="ar long">هِىَ بِنْتُ أَبِيهَا</span>, meaning <em>She resembles her father in strength of mind,</em> or <em>spirit, and sharpness of disposition, and in hastening,</em> or <em>striving to be first, to do things:</em> said of Hafsah, by ʼÁïsheh. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OabN.1_A6">
					<p><span class="ar">بِأَبِى</span>, <span class="auth">(TA,)</span> or <span class="ar long">بِأَبِى أَنْتَ</span>, <span class="auth">(T in art. <span class="ar">بأ</span>,)</span> <span class="add">[said to a person,]</span> means <span class="add">[<span class="ar long">فُدِيتَ بِأَبِى</span> <em>Mayest thou be ransomed with my father!</em> <span class="auth">(see the next sentence but one;)</span> or]</span> <span class="ar long">أَفْدِيكَ بِأَبِى</span> <span class="add">[<em>I will ransom thee with my father</em>]</span>; <span class="auth">(T ubi suprà;)</span> or <span class="ar long">أَنْتَ مَفْدِىٌّ بِأَبِى</span> <span class="add">[<em>Thou art,</em> or <em>shalt be, ransomed with my father</em>]</span>; or <span class="ar long">فَدَيُتُكَ بِأَبِى</span> <span class="add">[<em>I have</em> in my heart <em>ransomed thee,</em> or <em>I would ransom thee, with my father</em>]</span>; the <span class="ar">ب</span> being dependent upon a word suppressed, which, accord. to some, is a <span class="add">[pass. participial]</span> noun, and accord. to others, a verb; and this word is suppressed because of the frequent usage of the phrase. <span class="auth">(TA.)</span> You say also, <span class="ar long">بِأَبِى أَنْتَ وَأُمِّى</span> <span class="add">[<em>With my father mayest thou be ransomed, and</em> with <em>my mother!</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">بِأَبِى مَنْ وَدَدتُّهُ</span>, i. e. <span class="ar long">فُدِىَ بِأَبِى مَنْ وَدَدتُّهُ</span> <span class="add">[<em>May he whom I love be ransomed with my father!</em>]</span>, meaning <em>may he</em> <span class="add">[<em>my father</em>]</span> <em>be made a ransom for him</em> <span class="add">[<em>whom I love</em>]</span>! <span class="auth">(El-Wáḥidee on the Deewán of El-Mutanebbee, in De Sacy's Chrest. Arabe, sec. ed. vol. iii. p. 35 of the Arabic text.)</span> Sometimes they change the <span class="ar">ى</span> into <span class="ar">ا</span>: a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَقَدْ زَعَمُوا أَنِّى جَزِعْتُ عَلَيْهِمَا</span> *</div> 
						<div class="star">* <span class="ar long">وَهَلْ جَزَعٌ أَنْ قُلْتُ وَا بِأَبَا هُمَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And they have asserted that I have become impatient on account of them two: but is it</em> an evidence of <em>impatience that I said, Alas, with my father may they two be ransomed?</em>]</span>; meaning <span class="ar long">وَا بِأَبِى هُمَا</span>. <span class="auth">(Ṣ.)</span> And some of the Arabs used to say, <span class="ar long">وَا بِأَبَا أَنْتَ</span> <span class="add">[<em>Alas, with my father mayest thou be ransomed!</em>]</span>: this, says AM, being like <span class="ar long">يَا وَيْلَتَا</span> for <span class="ar long">يَا وَيْلَتِى</span>; as also <span class="ar long">يَا بَيْبَا</span>, with the hemzeh changed into <span class="ar">ى</span>, originally <span class="ar long">يَا بِأَبَا</span>, meaning <span class="ar">يَابِأَبِى</span>: and hence what is related, in a trad., of Umm- 'Ateeyeh; that she used not to mention the Prophet without saying, <span class="ar">بِيَبَا</span> <span class="add">[for <span class="ar long">بِأَبِ هُوَ</span>]</span>. <span class="auth">(TA in art. <span class="ar">بأ</span>.)</span> A woman said,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا بِأَبِى أَنْتَ وَيَا فَوْقَ البِيَبْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O</em> thou to whom I would say, <em>With my father mayest thou be ransomed! and O</em> thou who art <em>above</em> him to whom I would address <em>the saying, With my father mayest thou be ransomed!</em>]</span>; respecting which Fr observes that the two words <span class="add">[<span class="ar">بِ</span> and <span class="ar">أَب</span>]</span> are made as one <span class="add">[by prefixing the article]</span> because of their frequent occurrence; <span class="auth">(Ṣ;)</span> and Aboo-ʼAlee says that the <span class="ar">ى</span> in <span class="ar">بِيَب</span> is substituted for <span class="ar">ء</span>, not necessarily; but ISk quotes the words as commencing with <span class="ar long">يَا بِيَبَا</span>, which is the right reading, in order that this expression may agree with <span class="ar">البِئَبْ</span>, which is derived from it: Et-Tebreezee, however, relates Abu-l-ʼAlà's reciting the words as ending with <span class="ar">البِئَبْ</span>; saying that this is compounded from the phrase <span class="ar">بِأَبِى</span>, and that therefore the <span class="ar">ء</span> is preserved. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=02_b/001_bA">See also the first paragraph in art. <span class="ar">بأ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OabN.1_A7">
					<p>You say also, <span class="ar long">يَا أَبَتِ</span> <span class="add">[meaning <em>O my father</em>]</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> as in <span class="ar long">يَا أَبَتِ افْعَلْ</span> <span class="add">[<em>O my father, do thou</em> such a thing]</span>; <span class="auth">(Ṣ;)</span> and <span class="ar long">يَا أَبَتَ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> and <span class="ar">يَاأَبَتُ</span>; <span class="auth">(Z in the Ksh xii. 4;)</span> and <span class="ar long">يَا أَبَهْ</span> <span class="auth">(Ṣ, M, Ḳ)</span> when you pause after it. <span class="auth">(Ṣ, M.)</span> The <span class="ar">ة</span>, <span class="add">[here written <span class="ar">ت</span>,]</span> <span class="auth">(Kh, M,)</span> the sign of the fem. gender, <span class="auth">(Ṣ, Z,)</span> is substituted for the <span class="add">[pronominal]</span> affix <span class="ar">ى</span>, <span class="auth">(Kh, Ṣ, M, Z,)</span> as in <span class="ar">يَاأُمَّتِ</span>; <span class="auth">(Ṣ;)</span> and is like the <span class="ar">ة</span> in <span class="ar">عَمَةٌ</span> and <span class="ar">خَالَةٌ</span>, as is shown by your saying, in pausing, <span class="ar long">يَا أَبَهٌ</span>, like as you say, <span class="ar long">يَا خَالَةٌ</span>: <span class="auth">(Kh, M:)</span> the annexing of the fem. <span class="ar">ت</span> to a masc. noun in this case is allowable, like as it is in <span class="ar long">حَمَامَةٌ ذَكَرٌ</span> and <span class="ar long">شَاةٌ ذَكَرٌ</span> and <span class="ar long">رَجُلٌ رَبْعَةٌ</span> and <span class="ar long">غَلَامٌ يَفَعَةٌ</span>: its being made a substitute for the affix <span class="ar">ى</span> is allowable because each of these is an augmentative added at the end of a noun: and the kesreh is the same that is in the phrase <span class="ar long">يَا أَبِى</span>: <span class="auth">(Z ubi suprà:)</span> the <span class="ar">ت</span> does not fall from <span class="ar">اب</span> in the phrase <span class="ar long">يَا أَبَتِ</span> when there is no pause after it, though it <span class="add">[sometimes]</span> does from <span class="ar">أُمّ</span> in the like phrase in that case, because the former word, being of <span class="add">[only]</span> two letters, is as though it were defective. <span class="auth">(Ṣ.)</span> <span class="ar long">يَا أَبَتَ</span> is for <span class="ar long">يَا أَبَتَا</span>, <span class="auth">(Aboo-ʼOthmán El-Mázinee, Ṣ,* M, <span class="add">[the latter expression mentioned also in the Ḳ, but not as being the original of the former,]</span>)</span> the <span class="ar">ا</span> <span class="add">[and <span class="ar">ه</span>]</span> being suppressed; <span class="auth">(the same Aboo-ʼOthmán and M;)</span> or for <span class="ar long">يَا أَبَتَا</span>, the <span class="ar">ا</span> being suppressed, like as the <span class="ar">ى</span> is in <span class="ar long">يَا غُلَامِ</span>; or it may be after the manner of <span class="ar">يَاأَبِىَ</span>. <span class="auth">(Z ubi suprà.)</span> <span class="ar long">يَا أَبَتُ</span> is thus pronounced after the usual manner of a noun ending with the fem. <span class="ar">ة</span>, without regard to the fact that the <span class="ar">ت</span> is in the former a substitute for the suffix <span class="ar">ى</span>. <span class="auth">(Z ubi suprà.)</span> <span class="ar long">يَا أَبَهْ</span> is said in a case of pause, except in the Ḳur-án, in which, in this case, you say, <span class="ar long">يَا أَبَهْ</span>, following the written text; and some of the Arabs pronounce the fem. <span class="ar">ة</span>, in a case of pause, <span class="ar">ت</span> <span class="add">[in other instances]</span>, thus saying, <span class="ar long">يَا طَلْحَتُ</span>. <span class="auth">(Ṣ.)</span> <span class="ar long">يَا أَبَاهُ</span> is also said; <span class="auth">(M, Ḳ;)</span> though scarcely ever. <span class="auth">(M.)</span> A poet uses the expression <span class="ar long">يَا أَبَاتَ</span>, for <span class="ar long">يَا أَبَتَاهْ</span>: <span class="auth">(Ṣ, M:)</span> IB says that this is used only by poetic license, in a case of necessity in verse. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OabN.1_A8">
					<p><span class="ar">أَبٌ</span> is tropically applied to signify ‡ <em>A grandfather,</em> or <em>any ancestor.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OabN.1_A9">
					<p>It is also applied to signify † <em>A paternal uncle;</em> as in the Ḳur ii. 127, quoted before. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="OabN.1_A10">
					<p><span class="add">[It is also <span class="auth">(like <span class="ar">أُمّ</span> and <span class="ar">اِبْن</span> and <span class="ar">بِنْت</span>)</span> prefixed to nouns of various significations. Most of the compounds thus formed will be found explained in the arts. to which belong the nouns that occupy the second place. The following are among the more common, and are therefore here mentioned, as exs. of different kinds.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="OabN.1_A11">
					<p><span class="ar long">أَبُو المَرْأَةِ</span> † <em>The woman's husband:</em> <span class="auth">(Ibn-Ḥabeeb, M:)</span> it is said in the TṢ that <span class="ar">الأَبُ</span>, in certain of the dials., signifies <em>the husband:</em> MF deems this meaning strange. <span class="auth">(TA.)</span> <span class="ar long">أَبُو المَثْوَى</span> † <em>The master of the dwelling,</em> or <em>of the place of abode:</em> <span class="auth">(TA:)</span> and † <em>the guest.</em> <span class="auth">(Ḳ in art. <span class="ar">ثوى</span>.)</span> <span class="ar long">أَبُو الأَضْيَافِ</span> † <em>The very hospitable man.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="OabN.1_A12">
					<p><span class="ar long">أَبُو الحَارِثِ</span> † <em>The lion.</em> <span class="auth">(TA.)</span> <span class="ar long">أَبُو جَعْدَةَ</span> † <em>The wolf.</em> <span class="auth">(TA.)</span> <span class="ar long">أَبُو الحُصَيْنِ</span> † <em>The fox.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="OabN.1_A13">
					<p><span class="ar long">أَبُو جَابِر</span> † <em>Bread.</em> <span class="auth">(Ṣ and Ḳ in art. <span class="ar">جبر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابو</span> - Entry: <span class="ar">أَبٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="OabN.1_A14">
					<p><span class="ar long">أَبُو مَالِكٍ</span> † <em>Extreme old age:</em> <span class="auth">(TA:)</span> and † <em>hunger.</em> <span class="auth">(MF in art. <span class="ar">جبر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OabBaA">
				<h3 class="entry"><span class="ar">أَبَّا</span></h3>
				<div class="sense" id="OabBaA_A1">
					<p><span class="ar">أَبَّا</span>: <a href="#OabN">see <span class="ar">أَبٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IibowaMCN">
				<h3 class="entry"><span class="ar">إِبْوَآءٌ</span> / <span class="ar">أَبْوَآءٌ</span></h3>
				<div class="sense" id="IibowaMCN_A1">
					<p><span class="ar">إِبْوَآءٌ</span> or <span class="ar">أَبْوَآءٌ</span>: <a href="#OubuwBapN">see <span class="ar">أُبُوَّةٌ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabawieBN">
				<span class="pb" id="Page_0012"></span>
				<h3 class="entry"><span class="ar">أَبَوِىٌّ</span></h3>
				<div class="sense" id="OabawieBN_A1">
					<p><span class="ar">أَبَوِىٌّ</span> <em>Of,</em> or <em>relating</em> or <em>belonging to, a father; paternal.</em> <span class="auth">(Ṣ, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabaeBN">
				<h3 class="entry"><span class="ar">أَبَىٌّ</span></h3>
				<div class="sense" id="OabaeBN_A1">
					<p><span class="ar">أَبَىٌّ</span> <a href="#OabN">dim, of <span class="ar">أَبٌ</span>, q. v.</a> <span class="auth">(Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OubuwBapN">
				<h3 class="entry"><span class="ar">أُبُوَّةٌ</span></h3>
				<div class="sense" id="OubuwBapN_A1">
					<p><span class="ar">أُبُوَّةٌ</span> <span class="add">[in copies of the Ḳ<span class="arrow"><span class="ar">إِبْوَآء↓</span></span>, and in the CK<span class="arrow"><span class="ar">اَبْواء↓</span></span>, both app. mistranscriptions for <span class="ar">أُبُوَّة</span>, which is well known,]</span> <em>Fathership; paternity;</em> the <em>relation of a father.</em> <span class="auth">(Ṣ,* M.)</span> You say, <span class="ar long">بَيْنِى وَبَيْنَ فَلَانٍ أُبُوَةٌ</span> <span class="add">[<em>Between me and such a one is a tie of fathership</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0010.pdf" target="pdf">
							<span>Lanes Lexicon Page 10</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0011.pdf" target="pdf">
							<span>Lanes Lexicon Page 11</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0012.pdf" target="pdf">
							<span>Lanes Lexicon Page 12</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
