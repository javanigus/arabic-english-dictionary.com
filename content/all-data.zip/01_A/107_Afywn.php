<article class="root" id="Root_Afywn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/106_Afh">افه</a></span>
				<span class="ar">افيون</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/108_AqHwAn">اقحوان</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OafoyuwnN">
				<h3 class="entry"><span class="ar">أَفْيُونٌ</span></h3>
				<div class="sense" id="OafoyuwnN_A1">
					<p><span class="ar">أَفْيُونٌ</span>, <span class="add">[like <span class="ar">صَعْفُوقٌ</span>, but this is of a very extr. measure; or, as some write it, <span class="ar">أُفْيُونٌ</span>, like <span class="ar">عُصْفُورٌ</span>, &amp;c.;]</span> or <span class="ar">إِفْيَوْنٌ</span>, <span class="add">[like <span class="ar">بِرْذَوْنٌ</span>;]</span> <span class="auth">(accord. to different copies of the Ḳ, art. <span class="ar">فين</span>;)</span> <span class="add">[an arabicized word, from the Greek <span class="ar">أَپْيُونْ</span>, either immediately or through the Persian <span class="ar">خَشْخَاش</span>; meaning <em>Opium:</em>]</span> the <em>milk</em> <span class="add">[or <em>juice</em>]</span> <em>of the black Egyptian</em> <span class="ar">خشخاش</span> <span class="add">[or <em>poppy,</em> or <em>papaver somniferum</em>]</span>; <span class="auth">(Ḳ;)</span> or the <em>milk of the</em> <span class="ar">خشخاش</span>, <em>the best of which is the black Egyptian;</em> <span class="auth">(TA;)</span> or the <em>expressed juice of the black Egyptian</em> <span class="ar">خشخاش</span>, <em>dried in the sun: cold and dry in the fourth degree:</em> <span class="auth">(Ibn-Seenà, or Avicenna, i. 133:)</span> <em>beneficial for hot tumours, especially in the eye; torporific</em> (<em>to the intellect,</em> TA): <em>in a small quantity, beneficial, and soporific: in a large quantity, a poison:</em> <span class="auth">(Ḳ:)</span> <span class="add">[the lexicographers regard the word as Arabic:]</span> some, among whom is the author of the Ḳ, hold that it belongs to art. <span class="ar">فين</span>: others, that it belongs to art. <span class="ar">افن</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
