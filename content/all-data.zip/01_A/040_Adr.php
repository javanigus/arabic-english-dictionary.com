<article class="root" id="Root_Adr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/039_Adb">ادب</a></span>
				<span class="ar">ادر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/041_Adm">ادم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Adr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أدر</span></h3>
				<div class="sense" id="Adr_1_A1">
					<p><span class="ar">أَدِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْدَرُ</span>}</span></add>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَدَرٌ</span> <span class="auth">(Lth, T, Ṣ, Mgh)</span> and <span class="ar">أَدَرَةٌ</span>, <span class="auth">(Lth, TA,)</span> or <span class="ar">أُدْرَةٌ</span>, <span class="auth">(as in the TT,)</span> or <span class="ar">أُدْرَةٌ</span> is a simple subst., <span class="auth">(M, Ḳ,)</span> and so is <span class="ar">أُدْرَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>had the disorder termed</em> <span class="ar">أُدْرَةٌ</span>. <span class="auth">(T, Ṣ, M, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OudorapN">
				<h3 class="entry"><span class="ar">أُدْرَةٌ</span></h3>
				<div class="sense" id="OudorapN_A1">
					<p><span class="ar">أُدْرَةٌ</span> a subst. from <span class="ar">أَدِرَ</span>;<span class="add">[<a href="#Adaru">see <span class="ar">آدَرُ</span>, below</a>;]</span> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">أَدَرَةٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> the former signifies <span class="add">[<em>A scrotal hernia;</em>]</span> <em>an inflation in the</em> <span class="ar">خُصْيَة</span> <span class="add">[or the <em>testicle,</em> or the <em>scrotum</em>]</span>: <span class="auth">(T,* Ṣ:)</span> or <em>an inflation of the</em> <span class="ar">خُصْيَة</span>: <span class="auth">(Mṣb:)</span> or <em>a disorder consisting in an inflation,</em> or <em>a swelling, of the</em> <span class="ar">خُصْيَتَانِ</span>, <em>and their becoming greatly enlarged with matter</em> or <em>wind therein:</em> <span class="auth">(Esh-Shiháb, on the Soorat el-Ahzáb:)</span> or <em>a largeness of the</em> <span class="ar">خُصَ</span>: <span class="auth">(Mgh:)</span> and<span class="arrow"><span class="ar">أَدَرَةٌ↓</span></span> also signifies what is vulgarly termed <span class="ar">قَيْلَةٌ</span> <span class="add">[meaning in the present day <em>a scrotal hernia</em>]</span>: or, accord. to some, <em>i. q.</em> <span class="ar">خُصْيَةٌ</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#Adr_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OadarapN">
				<h3 class="entry"><span class="ar">أَدَرَةٌ</span></h3>
				<div class="sense" id="OadarapN_A1">
					<p><span class="ar">أَدَرَةٌ</span>: <a href="#OudorapN">see <span class="ar">أُدْرَةٌ</span></a>, in two places. <span class="add">[<a href="#Adr_1">See also 1</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mdaru">
				<h3 class="entry"><span class="ar">آدَرُ</span></h3>
				<div class="sense" id="Mdaru_A1">
					<p><span class="ar">آدَرُ</span> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">مَأْدُورٌ↓</span></span> <span class="auth">(M, Ḳ)</span> A man <span class="auth">(Ṣ)</span> <span class="add">[<em>having a scrotal hernia;</em> or]</span> <em>having an inflation in the</em> <span class="ar">خُصْيَة</span> <span class="add">[or the <em>testicle,</em> or the <em>scrotum</em>]</span>: <span class="auth">(T,* Ṣ:)</span> or <em>having an inflation of the</em> <span class="ar">خُصْيَة</span>: <span class="auth">(Mṣb:)</span> or <em>having his</em> <span class="ar">صِفَاق</span> <span class="add">[or <em>inner skin</em>]</span> <em>ruptured, so that</em> <span class="add">[<em>some of</em>]</span> <em>his intestines fall into his scrotum; the rupture being in every instance only in the left side:</em> or <em>afflicted by a rupture in one of his</em> <span class="ar">خُصْيَانِ</span> <span class="add">[or <em>in either half of the scrotum</em>]</span>: <span class="auth">(M, Ḳ:)</span> or <em>having a largeness of the</em> <span class="ar">خُصَى</span> <span class="auth">(Mgh:)</span> pl. of the former, <span class="ar">أُدُرٌ</span>; <span class="auth">(Mṣb, Ḳ;)</span> and of the latter, <span class="ar">مَآدِيرُ</span>. <span class="auth">(Ḳ.)</span> Accord. to some, <span class="auth">(M,)</span> <span class="ar long">أَدْرَآءُ خُصْيَةٌ</span> signifies <span class="add">[<em>A testicle,</em> or <em>scrotum,</em>]</span> <em>large, without rupture.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOoduwrN">
				<h3 class="entry"><span class="ar">مَأْدُورٌ</span></h3>
				<div class="sense" id="maOoduwrN_A1">
					<p><span class="ar">مَأْدُورٌ</span>: <a href="#Adaru">see <span class="ar">آدَرُ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0035.pdf" target="pdf">
							<span>Lanes Lexicon Page 35</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
