<article class="root" id="Root_Axr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/035_Axc">اخذ</a></span>
				<span class="ar">اخر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/037_Axw">اخو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Axr_2">
				<h3 class="entry">2. ⇒ <span class="ar">أخّر</span></h3>
				<div class="sense" id="Axr_2_A1">
					<p><span class="ar">أخّر</span>, <span class="auth">(Ṣ, Ḳ, &amp;c.,)</span> inf. n. <span class="ar">تَأْخِيرٌ</span>, <span class="auth">(Ḳ,)</span> is trans. <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> and intrans.: <span class="auth">(Ḳ:)</span> as a trans. verb it signifies <em>He made to go back</em> or <em>backwards, to recede, retreat, retire,</em> or <em>retrograde: he put,</em> or <em>drove, back: he put,</em> or <em>placed, behind,</em> or <em>after; back,</em> or <em>backward: he made to be behind,</em> or <em>posterior,</em> or <em>last: he made to remain behind, hold back, hang back,</em> or <em>lag behind: he kept,</em> or <em>held, back: he postponed, put off, procrastinated, deferred, delayed,</em> or <em>retarded: he made backward,</em> or <em>late: contr. of</em> <span class="ar">قَدَّمَ</span>. <span class="auth">(Mṣb, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Axr_2_A2">
					<p><span class="ar long">أَخَّرَنِى إِلَى مُدَّةٍ</span> <em>He granted me a delay,</em> or <em>postponement, to a certain term,</em> or <em>period.</em> <span class="auth">(TA in art. <span class="ar">اجل</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Axr_2_B1">
					<p>For its significations as an intrans. verb, <a href="#Axr_5">see 5</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأخّر</span></h3>
				<div class="sense" id="Axr_5_A1">
					<p><span class="ar">تأخّر</span> <a href="#Axr_2">is quasi-pass. of the trans. verb <span class="ar">أخّر</span> <span class="new">{2}</span></a>; <span class="auth">(Ṣ, A, Mṣb;)</span> i. e. <em>He,</em> or <em>it, went back or backwards, drew back, receded, retreated, retired,</em> or <em>retrograded: became put,</em> or <em>driven, back: became put,</em> or <em>placed, behind,</em> or <em>after: became behind, posterior,</em> or <em>last: he remained behind,</em> or <em>in the rear; held back, hung back, lagged behind,</em> or <em>delayed; was,</em> or <em>became, backward,</em> or <em>late: it was,</em> or <em>became, kept back, postponed, put off, procrastinated, deferred, delayed,</em> or <em>retarded: contr. of</em> <span class="ar">تَقَدَّمَ</span>: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">استأخَر↓</span></span> is syn. therewith; <span class="auth">(Ṣ, Ḳ:)</span> and<span class="arrow"><span class="ar">أخّر↓</span></span>, inf. n. <span class="ar">تَأْخِيرٌ</span>, signifies the same, being intrans. as well as trans. <span class="auth">(Ḳ.)</span> An ex. of the latter occurs in a saying of Moḥammad to ʼOmar: <span class="arrow"><span class="ar long">أَخِّرْ↓ عَنّىِ</span></span> <em>Retire thou from me:</em> or the meaning is, <span class="ar long">أَخِّرْعَنِّى رَأْيَكَ</span> <span class="add">[<em>hold thou back from me thine opinion;</em> or <em>reserve thou thine opinion until after mine shall have been given</em>]</span>. <span class="auth">(TA.)</span> You say, <span class="ar long">تَأَخِّرَ عَنْهُ تَأَخُّرَةً وَاحِدَةً</span> <span class="add">[<em>He went back,</em>, &amp;c., <em>from him,</em> or <em>it, once</em>]</span>. <span class="auth">(Lḥ.)</span> And <span class="ar long">تأخّر عَنِ الشَّىْءِ</span>, or <span class="ar">الأَمْرِ</span>, <em>He went back,</em>, &amp;c., <em>from the thing,</em> or <em>the affair: he was,</em> or <em>became, behind, behindhand,</em> or <em>backward, with respect to it: he held back, hung back, refrained,</em> or <em>abstained, from it;</em> and<span class="arrow"><span class="ar long">استأخر↓ عَنْهُ</span></span> signifies the same. <span class="auth">(The Lexicons in many places.)</span> <span class="arrow"><span class="ar long">فَإِذَا جَآءَ أَجَلُهُمْ لَا يَسْتَأْخِرُونَ↓ سَاعَةً</span></span>, in the Ḳur vii. 32 and other places, means <em>And when their time is come,</em> for punishment, <em>they will not remain behind,</em> or be respited, <span class="add">[<em>any while,</em> or]</span> <em>the shortest time:</em> or <em>they shall not seek to remain behind,</em> by reason of intense terror. <span class="auth">(Bḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Axr_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأخر</span></h3>
				<div class="sense" id="Axr_10_A1">
					<p><a href="#Axr_5">see 5</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxirN">
				<h3 class="entry"><span class="ar">أَخِرٌ</span></h3>
				<div class="sense" id="OaxirN_A1">
					<p><span class="ar">أَخِرٌ</span> <span class="add">[an epithet variously explained]</span>. One says, in reviling, <span class="auth">(Ṣ, TA,)</span> but not when the object is a female, <span class="auth">(TA,)</span> <span class="ar long">أَبْعَدَ اَللّٰهُ الأَخِرَ</span>, <span class="auth">(Th, Ṣ, A, &amp;c.,)</span> and<span class="arrow"><span class="ar">الآخِرَ↓</span></span> <span class="auth">(M, &amp;c.,)</span> or this latter is wrong, <span class="auth">(Mesháriḳ of ʼIyáḍ, Mgh, Mṣb,)</span> as is also <span class="arrow"><span class="ar">الآخَرَ↓</span></span>, <span class="auth">(Mesháriḳ of ʼIyáḍ,)</span> meaning ‡ <em>May God alienate,</em> or <em>estrange, from good,</em> or <em>prosperity,</em> or <em>may God curse, him who is absent from us,</em> <span class="auth">(A, Mṣb, TA,)</span> <em>distant,</em> or <em>remote:</em> <span class="auth">(A, Mṣb:)</span> or <em>the outcast; the alienated:</em> <span class="auth">(Mṣb:)</span> or <em>him who is put back,</em> and <em>cast away:</em> so says Sh: or, accord. to ISh, <em>him who is put back, and remote from good:</em> and he adds, I think that <span class="arrow"><span class="ar">الأَخِير↓</span></span> is meant: <span class="auth">(L:)</span> or <em>the base fellow:</em> or <em>the most ignoble:</em> or <em>the miserable wretch:</em> <span class="auth">(Et-Tedmuree and others:)</span> or <em>the last speaker:</em> <span class="auth">(Nawádir of Th:)</span> or <span class="ar">الاخر</span> is here a metonymy for <em>the devil:</em> <span class="auth">(Lb:)</span> it is a word used <span class="add">[for the reason explained voce <span class="ar">أَبْعَدُ</span>]</span> in relating what has been said by one of two persons cursing each other, to the other; <span class="auth">(Expositions of the Fṣ;)</span> and the phrase above mentioned is meant to imply a prayer for those who are present <span class="add">[by its contrasting them with the person to whom it directly applies]</span>. <span class="auth">(A.)</span> One also says, <span class="ar long">لَا مَرْحَبًا بِالْأَخِرِ</span>, <span class="add">[alluding to a particular person,]</span> meaning <span class="add">[<em>May the place,</em> or <em>land, not be ample,</em> or <em>spacious,</em> or <em>roomy,</em>]</span> <em>to the remote from good.</em> <span class="auth">(TA.)</span> It is said in a trad. of Mázin, <span class="ar long">إِنَّ الأَخِرَقَدْ زَنَى</span> <em>Verily the outcast,</em> <span class="auth">(Mgh, Mṣb,)</span> or <em>he who is remote, and held back, from good,</em>, <span class="auth">(Mgh,* TA,)</span> <em>hath committed adultery,</em> or <em>fornication:</em> the speaker meaning himself; <span class="auth">(Mgh, Mṣb;)</span> as though he were an outcast. <span class="auth">(Mṣb.)</span> And in another trad. it is said, <span class="ar long">المَسْأَلَةُ أَخِرُ كَسْبِ المَرْءِ</span> <em>Begging is the most ignoble</em> <span class="add">[mode of]</span> <em>gain of man:</em> but El-Khaṭṭábee relates it with medd, <span class="add">[i. e.<span class="arrow"><span class="ar">آخِرُ↓</span></span>,]</span> explaining it as meaning <em>begging is the last thing whereby man seeks sustenance</em> when unable to gain <span class="add">[by other means]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxurN">
				<h3 class="entry"><span class="ar">أُخُرٌ</span></h3>
				<div class="sense" id="OuxurN_A1">
					<p><span class="ar">أُخُرٌ</span> The <em>back, hinder,</em> or <em>latter, part:</em> the <em>hindermost,</em> or <em>last, part: contr. of</em> <span class="ar">قُدُمٌ</span>. <span class="auth">(Ḳ.)</span><span class="add">[<a href="#muwaxBarN">See also <span class="ar">مُؤَخَّرٌ</span></a>; from which it appears to be distinguished by its being used only adverbially, or with a preposition: <a href="#AxirN">and see <span class="ar">آخِرٌ</span></a>.]</span> You say, <span class="ar long">شُقَّ ثَوْبُهُ أُخُرًا</span>, and <span class="ar long">مِنْ أُخُرٍ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> <em>His garment was rent,</em> or <em>slit, in its back,</em> or <em>hinder, part,</em> <span class="auth">(Ṣ,)</span> or <em>behind.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">تَأَخَّرَ أُخُرًا</span> <span class="add">[<em>He retired backwards</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">جَآءِ أُخُرًا</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuxorapF">
				<h3 class="entry"><span class="ar">أُخْرَةً</span> / <span class="ar">بِأُخْرَةٍ</span></h3>
				<div class="sense" id="OuxorapF_A1">
					<p><span class="ar">أُخْرَةً</span> and <span class="ar">بِأُخْرَةٍ</span>: <a href="#AxirF">see <span class="ar">آخِرً</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaxarapF">
				<h3 class="entry"><span class="ar">أَخَرَةً</span> / <span class="ar">بِأَخَرَةٍ</span></h3>
				<div class="sense" id="OaxarapF_A1">
					<p><span class="ar">أَخَرَةً</span> and <span class="ar">بِأَخَرَةٍ</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>, in five places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="biOaxirapK">
				<h3 class="entry"><span class="ar">بِأَخِرَةٍ</span></h3>
				<div class="sense" id="biOaxirapK_A1">
					<p><span class="ar long">بِعْتُهُ بِأَخِرَةٍ</span> <em>I sold it</em> <span class="auth">(namely the article of merchandise, TA)</span> <em>with postponement of the payment; upon credit; for payment to be made at a future period;</em> syn. <span class="ar">بِنَظِرةٍ</span>; <span class="auth">(Ṣ, A, Ḳ;)</span> i. e. <span class="ar">بِنَسِئَةٍ</span>. <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuxarapF">
				<h3 class="entry"><span class="ar">أُخَرَةً</span> / <span class="ar">بِأُخَرَةٍ</span></h3>
				<div class="sense" id="OuxarapF_A1">
					<p><span class="ar">أُخَرَةً</span> and <span class="ar">بِأُخَرَةٍ</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ouxorae">
				<h3 class="entry"><span class="ar">أُخْرَى</span></h3>
				<div class="sense" id="Ouxorae_A1">
					<p><span class="ar">أُخْرَى</span>: <a href="#Axaru">see <span class="ar">آخَرُ</span></a>, of which it is the fem.: <a href="#AxirN">and see also <span class="ar">آخِرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxoraApN">
				<h3 class="entry"><span class="ar">أُخْرَاةٌ</span></h3>
				<div class="sense" id="OuxoraApN_A1">
					<p><span class="ar">أُخْرَاةٌ</span> another <a href="#Axaru">fem. of <span class="ar">آخَرُ</span></a>. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuxoriyBaA">
				<h3 class="entry"><span class="ar">أُخْرِيَّا</span> / 
							<span class="ar">إِخْرِيَّا</span> / 
							<span class="ar">إِخِرِيَّا</span></h3>
				<div class="sense" id="OuxoriyBaA_A1">
					<p><span class="ar">أُخْرِيَّا</span> and <span class="ar">إِخْرِيَّا</span> and <span class="ar">إِخِرِيَّا</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxorawieBN">
				<h3 class="entry"><span class="add">[<span class="ar">أُخْرَوِىٌّ</span> / <span class="ar">أُخْرَاوِىٌّ</span>]</span></h3>
				<div class="sense" id="OuxorawieBN_A1">
					<p><span class="add">[<span class="ar">أُخْرَوِىٌّ</span> and <span class="ar">أُخْرَاوِىٌّ</span> <em>Relating to the other state of existence,</em> or <em>the world to come.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaxiyrN">
				<h3 class="entry"><span class="ar">أَخِيرٌ</span> / <span class="ar">أَخِيرًا</span></h3>
				<div class="sense" id="OaxiyrN_A1">
					<p><span class="ar">أَخِيرٌ</span> and <span class="ar">أَخِيرًا</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>, in five places. <a href="#OaxirN">See also <span class="ar">أَخِرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ouxayorae">
				<h3 class="entry"><span class="ar">أُخَيْرَى</span></h3>
				<div class="sense" id="Ouxayorae_A1">
					<p><span class="ar">أُخَيْرَى</span> <a href="#Ouxorae">dim. of <span class="ar">أُخْرَى</span></a>, <a href="#Axaru">fem. of <span class="ar">آخَرُ</span>, q. v.</a> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mxaru">
				<h3 class="entry"><span class="ar">آخَرُ</span></h3>
				<div class="sense" id="Mxaru_A1">
					<p><span class="ar">آخَرُ</span> a subst., of the measure <span class="ar">أَفْعَلُ</span>, but implying the meaning of an epithet, <span class="auth">(Ṣ,)</span> from <span class="ar">أَخَّرَ</span> in the sense of <span class="ar">تَأَخَّرَ</span>, <span class="auth">(TA,)</span> <em>Another;</em> the <em>other; a thing</em> <span class="add">[or <em>person</em>]</span> <em>other than the former</em> or <em>first;</em> <span class="auth">(L;)</span> <em>i. q.</em> <span class="ar">غَيْرٌ</span>; <span class="auth">(Ḳ;)</span> as in the phrases, <span class="ar long">رَجُلٌ آخَرُ</span> <em>another man,</em> and <span class="ar long">ثَوْبٌ آخَرُ</span> <em>another garment</em> or <em>piece of cloth:</em> <span class="auth">(TA:)</span> or <em>one of two things</em> <span class="add">[or <em>persons</em>]</span>; <span class="auth">(Ṣ, Ṣgh, Mṣb;)</span> as when you say, <span class="ar long">جَآءَ القَوْمُ فَوَاحِدٌ يَفْعَلُ كَذَا وَآخَرُ كَذَا</span> <em>The people came, and one was doing thus, and one</em> <span class="add">[i. e. <em>another</em>]</span> <em>thus:</em> <span class="auth">(Ṣgh, Mṣb:)</span> originally meaning <em>more backward:</em> <span class="auth">(TA:)</span> fem. <span class="arrow"><span class="ar">أُخْرَى↓</span></span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أُخْرَاةٌ↓</span></span>; <span class="auth">(Ḳ)</span> which latter is not well known: <span class="auth">(MF:)</span> pl. masc. <span class="ar">آخَرُونَ</span> and <span class="ar">أُخَرُ</span>; <span class="auth">(Ṣ, Ḳ;)</span> <span class="add">[the latter irreg. as such;]</span> and, applied to irrational things, <span class="ar">أَوَاخِرُ</span>, like as <span class="ar">أَفَاضِلُ</span> <a href="#OafoDalu">is pl. of <span class="ar">أَفْضَلُ</span></a>: <span class="auth">(Mṣb:)</span> and pl. fem. <span class="ar">إُخْرَيَاتٌ</span> and <span class="ar">إُخَرُ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> which latter is imperfectly decl.; for an epithet of the measure <span class="ar">أَفْعَلُ</span> which is accompanied by <span class="ar">مِنْ</span> has no <span class="add">[dual nor]</span> pl. nor fem. as long as it is indeterminate; but when it has the article <span class="ar">ال</span> prefixed to it, or is itself prefixed to another noun which it governs in the gen. case, it has a dual and a pl. and a fem.; but it is not so with <span class="ar">آخَرُ</span>; for it has a fem. <span class="add">[and dual]</span> and pl. without <span class="ar">مِنْ</span> and without the article <span class="ar">ال</span> and without its being prefixed to another noun: you say, <span class="ar long">مَرَرْتُ بِرَخُلٍ آخَرَ</span>, and <span class="ar long">بِرِجَالٍ أُخَرَ</span> and <span class="ar">آخَرِينَ</span>, and <span class="ar">بِاٌمْرَأَةٍ</span>, and <span class="ar">بِنِسْوَةٍ</span> <span class="add">[<em>I passed by another man,</em> and <em>by other men,</em> and <em>by another woman,</em> and <em>by other women;</em>]</span> therefore, as it <span class="add">[namely <span class="ar">إُخَرُ</span>]</span> is thus made to deviate from its original form, <span class="add">[i. e. <span class="ar">آخَرُ</span>, <span class="auth">(I’Aḳ p. 287,)</span> which is of a class of words used, when indeterminate, alike as sing. and dual and pl.,]</span> and is <span class="add">[essentially and originally]</span> an epithet, it is imperfectly decl., though a pl.: <span class="pb" id="Page_0032"></span>but when you name thereby a man, it is perfectly decl., when inderminate, accord. to Akh, or imperfectly decl. accord. to Sb. <span class="auth">(Ṣ, L.)</span> <a href="#Axaru">The dim. of <span class="ar">آخَرُ</span></a> is <span class="arrow"><span class="ar">أُوَيْخِرُ↓</span></span>; the <span class="ar">ا</span> with the <span class="ar">ء</span> suppressed following the same rule as the <span class="ar">ا</span> in <span class="ar">ضَارِبٌ</span>: <span class="auth">(TA:)</span> and <a href="#Ouxorae">the dim. of <span class="ar">إُخْرَى</span></a> is <span class="arrow"><span class="ar">أُخَيْرَى↓</span></span>. <span class="auth">(Ṣ.)</span> <a href="#AlOuxorae">See also <span class="ar">الأُخْرَى</span></a> voce <span class="ar">آخِرٌ</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Mxaru_A2">
					<p><span class="ar long">لَا أَفْعَلُهُ أُخْرَى اللَّيَالِى</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar long">اخرى المَنُونِ</span>, <span class="auth">(Ḳ,)</span> means <em>I will not do it ever:</em> <span class="auth">(Ṣ, Ḳ:)</span> or the latter, <em>I will not do it to the end of time.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">أُخْرَى القَوْمِ</span>, <em>The last of the people.</em> <span class="auth">(Ṣ, Ḳ.)</span> One says, <span class="ar long">جَآءَ فِى أُخْرَى القَوْمِ</span> <em>He came among the last of the people.</em> <span class="auth">(TA.)</span> And <span class="ar long">جَآءِ فِى أُخْرَيَاتِ النَّاسِ</span> <em>He came among those who were the last of the people.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> <span class="add">[<a href="#AxirN">See also <span class="ar">آخِرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخَرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Mxaru_A3">
					<p>In <span class="ar long">أَبْعَدَ ٱللّٰهُ الآخَرَ</span>, the last word is a mistake for <span class="ar">الأَخِرَ</span> q. v. <span class="auth">(Mesháriḳ of ʼIyáḍ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MxirN">
				<h3 class="entry"><span class="ar">آخِرٌ</span></h3>
				<div class="sense" id="MxirN_A1">
					<p><span class="ar">آخِرٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> an epithet, of the measure <span class="ar">فَاعِلٌ</span>, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">أَخِيرٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb,)</span> The <em>last; aftermost; hindmost:</em> and the <em>latter; after; hinder:</em> and <span class="add">[as a subst.]</span> the <em>end: contr. of</em> <span class="ar">أَوَّلُ</span>: <span class="add">[or <em>of</em> <span class="ar">أَوَّلٌ</span> when used as a subst.:]</span> <span class="auth">(A, Mṣb, Ḳ:)</span> or <em>of</em> <span class="ar">مُتَقَدِّمٌ</span>: <span class="auth">(Lth, Mṣb:)</span> or what is <em>after the first</em> or <em>former:</em> <span class="auth">(Ṣ:)</span> fem. of the former <span class="ar">آخِرَةٌ</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> pl. <span class="add">[masc.]</span> <span class="ar">آخِرُونَ</span> <span class="auth">(Ḳur xxvi. 84, &amp;c.,)</span> and <span class="auth">(masc. and fem., Mṣb)</span> <span class="ar">أَوَاخِرُ</span> <span class="auth">(Ṣ, Mṣb)</span> and fem. <span class="ar">آخِرَاتٌ</span> also: <span class="auth">(Th:)</span> and<span class="arrow"><span class="ar">مَآخِيرُ↓</span></span> is syn. with <span class="ar">أَوَاخِرُ</span>; as in <span class="ar">مَآخِيرُاللَّيْلِ</span> <span class="add">[occurring in the Ṣ and Ḳ in art. <span class="ar">جهم</span>, meaning <em>The last,</em> or <em>latter, parts,</em> or <em>portions, of the night</em>]</span>. <span class="auth">(TḲ in art. <span class="ar">جهم</span>.)</span> You say, <span class="ar long">جَآءِ آخِرًا</span> and<span class="arrow"><span class="ar">أَخِيرًا↓</span></span> and<span class="arrow"><span class="ar">أُخُرًا↓</span></span> and<span class="arrow"><span class="ar">بِأَخَرَةٍ↓</span></span>, all meaning the same <span class="add">[<em>He came lastly,</em> or <em>latterly</em>]</span>: and in like manner,<span class="arrow"><span class="ar long">مَا عَرَفْتُهُ إِلَّا أَخِيرًا↓</span></span> and<span class="arrow"><span class="ar long">الّا بِأَخَرَةٍ↓</span></span> <span class="add">[<em>I did not know it save at the last,</em> or <em>lastly,</em> or <em>latterly</em>]</span>: <span class="auth">(Ṣ:)</span> or<span class="arrow"><span class="ar long">جَآءِ أَخِيرًا↓</span></span> and<span class="arrow"><span class="ar">أُخُرًا↓</span></span> and<span class="arrow"><span class="ar">أَخْرَةٌ↓</span></span> and<span class="arrow"><span class="ar">بِأُخْرَةٍ↓</span></span> and<span class="arrow"><span class="ar">أُخَرَةٍ↓</span></span> and<span class="arrow"><span class="ar">بِأُخَرَةٍ↓</span></span> <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">أُخْرَةٌ↓</span></span> and<span class="arrow"><span class="ar">بِأُخْرَةٍ↓</span></span> <span class="auth">(Lḥ, L,)</span> and <span class="ar">بِآخِرَةٍ</span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">إِخْرِيَّا↓</span></span> and<span class="arrow"><span class="ar">أُخْرِيَّا↓</span></span> and<span class="arrow"><span class="ar">إِخِرِيَّا↓</span></span> and<span class="arrow"><span class="ar">آخِرِيَّا↓</span></span> <span class="auth">(Ḳ)</span> mean <em>he came lastly of everything.</em> <span class="auth">(Ḳ.)</span> It is said in a trad., respecting Moḥammad, <span class="arrow"><span class="ar long">كَانَ يَقُولُ بِأَخَرَةٍ↓ إِذَا أَرَادَ أَنْ يَقُومَ مِنَ المَجْلِسِ كَذَا وَكَذَا</span></span> <em>He used to say, at the end of his sitting, when he desired to rise from the place of assembly, thus and thus:</em> or, accord. to IAth, it may mean, <em>in the last,</em> or <em>latter, part of his life.</em> <span class="auth">(TA.)</span> And you say, <span class="ar long">أَتَيْتُكَ آخِرَ مَرَّتَيْنِ</span> and <span class="ar long">آخِرَ مَرَّتَيْنِ</span> <span class="auth">(IAạr, M, Ḳ.*)</span> And <span class="ar long">لَا أُكَلِّمُهُ آخِرَ الدَّهْرِ</span> <em>I will not speak to him</em> <span class="add">[<em>to the end of time,</em> or]</span> <em>ever.</em> <span class="auth">(A.)</span> <span class="add">[<a href="#Axaru">See a similar phrase above, voce <span class="ar">آخَرُ</span></a>.]</span> And <span class="ar long">جَاؤُوا عَنْ آخِرِهِمْ</span> <span class="add">[<em>They came with the last of them;</em> <span class="ar">عن</span> being here syn. with <span class="ar">بِ</span>; meaning <em>they came all, without exception</em>]</span>. <span class="auth">(A.)</span> <span class="add">[And <span class="ar long">كَانَ ذلِكَ فِى آخِرِ الشَّهْرِ</span>, and <span class="ar">السَّنَةِ</span>; and <span class="ar long">فى أَوَاخِرِ هِمَا</span>, <em>That was in the end of the month, and of the year;</em> and <em>in the last days thereof.</em>]</span> And <span class="ar long">النَّهَارُ يَجُرٌ عَنْ آخِرٍ فَآخِرٍ</span> <span class="add">[<em>The day lengthens</em>]</span> <em>hour by hour</em>. <span class="auth">(A.)</span> <a href="#OaxirN">See also <span class="ar">أَخِرٌ</span></a>, last sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MxirN_A2">
					<p><span class="ar">الآخِرُ</span> is a name of God, signifying <span class="add">[<em>The last;</em> or]</span> <em>He who remaineth after all his creatures, both vocal and mute, have perished.</em> <span class="auth">(Nh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MxirN_A3">
					<p><span class="ar">الآخِرَانِ</span> <em>The two hinder dugs</em> of the she-camel; opposed to the <span class="ar">قَادِمَانِ</span>; <span class="auth">(TA;)</span> <em>the two dugs that are next the thighs.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MxirN_A4">
					<p><span class="ar">الآخِرَةٌ</span>, <span class="auth">(Ḳ,)</span> for <span class="ar long">الدّارُ الآخِرَةُ</span>, <span class="auth">(Bḍ in ii. 3,)</span> <span class="add">[and <span class="ar long">الحَيَاةُ الآخِرَةُ</span>,]</span> and<span class="arrow"><span class="ar">الأُخْرَى↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="add">[<em>The latter, ultimate,</em> or <em>last,</em> and <em>the other, dwelling,</em> or <em>abode,</em> and <em>life;</em> i. e. <em>the latter, ultimate,</em> or <em>last,</em> and <em>the other, world; the world,</em> or <em>life, to come;</em> and <em>the ultimate state of existence, in the world to come;</em>]</span> <em>the dwelling,</em> or <em>abode,</em> <span class="add">[and <em>life,</em>]</span> <em>of everlasting duration:</em> <span class="auth">(Ḳ:)</span> <span class="add">[each]</span> an epithet in which the quality of a subst. predominates. <span class="auth">(Z, and Bḍ ubi suprà.)</span> <span class="add">[Opposed to <span class="ar">الدُّنْيَا</span>. And <span class="ar">آخِرَةٌ</span> also signifies The <em>enjoyments, blessings,</em> or <em>good, of the ultimate state; of the other world;</em> or <em>of the world,</em> or <em>life, to come:</em> in which sense likewise it is opposed to <span class="ar">دُنْيَا</span>: (<a href="#baAEa">see an ex. of both voce <span class="ar">بَاعَ</span></a>, <a href="index.php?data=02_b/236_byE">in art. <span class="ar">بيع</span></a>: so too<span class="arrow"><span class="ar">أُخْرَى↓</span></span>.)]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="MxirN_A5">
					<p><span class="ar long">آخِرَةُ الرَّحْلِ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">السَّرْجِ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">آخِرُهُ</span>, <span class="auth">(Ṣ in art. <span class="ar">قدم</span>, and Ḳ,)</span> and<span class="arrow"><span class="ar">مُؤْخِرَتُهُ↓</span></span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> which is a rare form, or, accord. to Yaạḳoob, not allowable, <span class="auth">(Ṣ,)</span> and<span class="arrow"><span class="ar">مُؤخِرُهُ↓</span></span>, and <span class="ar">مُؤَخَّرَتُهُ</span>, and<span class="arrow"><span class="ar">مُؤَخَّرُهُ↓</span></span>, <span class="auth">(Ṣ in art. <span class="ar">قدم</span>, and Ḳ,)</span> and<span class="arrow"><span class="ar">مُؤَخِّرَتُهُ↓</span></span>, <span class="auth">(Mṣb, Ḳ,)</span> or this is a mistake, <span class="auth">(Mgh, Mṣb,)</span> and<span class="arrow"><span class="ar">مُؤَخِّرُهُ↓</span></span>, <span class="auth">(Ḳ,)</span> but the first of all is the most chaste, <span class="auth">(Mṣb,)</span> <em>The thing,</em> <span class="auth">(Ṣ,)</span> or <em>piece of wood,</em> <span class="auth">(Mṣb,)</span> <em>of the camel's saddle,</em> <span class="auth">(Ṣ, Mṣb,)</span> and <em>of the horse's,</em> <span class="auth">(Mṣb,)</span> <em>against which the rider leans</em> <span class="add">[<em>his back</em>]</span>; <span class="auth">(Ṣ, Mṣb;)</span> <em>the contr. of its</em> <span class="ar">قَادِمَة</span> <span class="add">[by which term <span class="ar">قادمة</span> is meant the <span class="ar">وَاسِط</span>]</span>: <span class="auth">(Ḳ:)</span> the <span class="ar">واسط</span> of the camel's saddle is the tall fore part which is next to the breast of the rider; and its <span class="ar">آخرة</span> is <em>its hinder part;</em> <span class="auth">(Az, L;)</span> i. e. <em>its broad piece of wood,</em> <span class="auth">(Mgh,)</span> or <em>its tall and broad piece of wood,</em> <span class="auth">(Az, L,)</span> <em>which is against,</em> or <em>opposite to,</em> (<span class="ar">تُحَاذِى</span>,) <em>the head</em> <span class="add">[<em>and back</em>]</span> <em>of the rider:</em> <span class="auth">(Az, Mgh, L:)</span> <span class="add">[for]</span> the <span class="ar">آخرة</span> and the <span class="ar">واسط</span> are the <span class="ar">شَرْخَانِ</span>, between which the rider sits: this is the description given by En-Naḍr <span class="add">[ISh]</span>; and all of it is correct: there is no doubt respecting it: <span class="auth">(Az, L:)</span> <a href="#Axrp">the pl. of <span class="ar">آخرة</span></a> is is <span class="ar">أَوَاخِرُ</span>. <span class="auth">(Mṣb.)</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="MxirN_A6">
					<p><span class="ar long">آخِرَةُ العَيْنِ</span>: <a href="#muWoxiruAlEaYoni">see <span class="ar">مُؤْخِرُالعَيْنِ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">آخِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="MxirN_A7">
					<p><span class="ar">آخِرٌ</span> and<span class="arrow"><span class="ar">أَخِيرٌ↓</span></span> <span class="add">[accord. to some]</span> also signify <em>Absent.</em> <span class="auth">(Ḳ.)</span> <a href="#OaxirN">But see <span class="ar">أَخِرٌ</span></a>, second sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MxiriyBFA">
				<h3 class="entry"><span class="ar">آخِرِيًّا</span></h3>
				<div class="sense" id="MxiriyBFA_A1">
					<p><span class="ar">آخِرِيًّا</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ouwayoxiru">
				<h3 class="entry"><span class="ar">أُوَيْخِرُ</span></h3>
				<div class="sense" id="Ouwayoxiru_A1">
					<p><span class="ar">أُوَيْخِرُ</span> <a href="#Axaru">dim. of <span class="ar">آخَرُ</span>, q. v.</a> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWoxiru">
				<h3 class="entry"><span class="ar">مُؤْخِرُ</span></h3>
				<div class="sense" id="muWoxiru_A1">
					<p><span class="ar long">مُؤْخِرُ العَيْنِ</span>, <span class="auth">(T, Ṣ, A, Mgh, Mṣb, Ḳ, <span class="add">[in the CK <span class="ar">مُؤَخَّرها</span>,]</span>)</span> said by AO, <span class="auth">(Mṣb,)</span> or AʼObeyd, <span class="auth">(TA,)</span> to be better without teshdeed, from which observation it is to be understood that teshdeed in this case is allowable, though rare, but Az disallows it, <span class="auth">(Mṣb, TA,)</span> and <span class="ar">مُؤْخِرَتُهَا</span>, and<span class="arrow"><span class="ar">آخِرَتُهَا↓</span></span>, <span class="auth">(Ḳ,)</span> <span class="add">[<em>The outer angle of the eye;</em>]</span> <em>the part of the eye next the temple;</em> <span class="auth">(Ṣ, A, Mgh, Mṣb;)</span> <em>the part next the</em> <span class="ar">لَحَاظ</span>: <span class="auth">(Ḳ:)</span> opposed to its <span class="ar">مُقْدِم</span>, which is the extremity thereof next the nose: <span class="auth">(Ṣ, Mgh, Mṣb:)</span> pl. <span class="ar">مَآخِرُ</span>. <span class="auth">(Mgh.)</span> You say, <span class="ar long">إَلَيَّ بِمُؤْخِرِ</span> <span class="add">[<em>He looked at,</em> or <em>towards, me from</em> <span class="auth">(lit. <em>with</em>)</span> <em>the outer angle of his eye</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">مُؤْخِرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWoxiru_A2">
					<p><span class="ar long">مُؤْخِرُ الرَّحْلِ</span>, and <span class="ar">مُؤْخِرَتُهُ</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaxBarN">
				<h3 class="entry"><span class="ar">مُؤَخَّرٌ</span></h3>
				<div class="sense" id="muWaxBarN_A1">
					<p><span class="ar">مُؤَخَّرٌ</span> The <em>back, hinder,</em> or <em>latter, part</em> of anything: its <em>hindermost,</em> or <em>last, part: contr. of</em> <span class="ar">مُقَدَّمٌ</span>: as in the phrase, <span class="ar long">ضَرَبَ مُؤَخَّرَ رَأْسِهِ</span> <span class="add">[<em>He struck the back,</em> or <em>hinder part, of his head</em>]</span>. <span class="auth">(Ṣ, Mṣb.)</span><span class="add">[<a href="#OuxurN">See also <span class="ar">أُخُرٌ</span></a> <a href="#AxirN">and <span class="ar">آخِرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">مُؤَخَّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWaxBarN_A2">
					<p><span class="ar">مُؤَخَّرُالرَّحْلِ</span>, and <span class="ar">مُؤَخَّرَتُهُ</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmuWaxBiru">
				<h3 class="entry"><span class="ar">المُؤَخِّرُ</span></h3>
				<div class="sense" id="AlmuWaxBiru_A1">
					<p><span class="ar">المُؤَخِّرُ</span> a name of God, <span class="add">[<em>The Postponer,</em> or <em>Delayer;</em>]</span> <em>He who postpones,</em> or <em>delays, things, and puts them in their places:</em> <span class="add">[or <em>He who puts,</em> or <em>keeps, back,</em> or <em>backward:</em> or <em>He who degrades:</em>]</span> contr. <em>of</em> <span class="ar">المُقَدِّمُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">المُؤَخِّرُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlmuWaxBiru_A2">
					<p><span class="ar long">مُؤَخِّرُ الَّرحْلِ</span>, and <span class="ar">مُؤَخِّرَتُهُ</span>: <a href="#AxirN">see <span class="ar">آخِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYoxaArN">
				<h3 class="entry"><span class="ar">مِئْخَارٌ</span></h3>
				<div class="sense" id="miYoxaArN_A1">
					<p><span class="ar long">نَخْلَةٌ مِئْخَارٌ</span> <em>A palm-tree of which the fruit remains until the end of winter:</em> <span class="auth">(AḤn, Ḳ:)</span> and <em>until the end of the time of cutting off the fruit of palm-trees:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> <em>contr. of</em> <span class="ar">مِبْكَارٌ</span> and <span class="ar">بَكُورٌ</span>: pl. <span class="ar">مَآخِيرُ</span>. <span class="auth">(A.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maMxiyru">
				<h3 class="entry"><span class="ar">مَآخِيرُ</span></h3>
				<div class="sense" id="maMxiyru_A1">
					<p><span class="ar">مَآخِيرُ</span> <span class="add">[<a href="#miYoxaArN">reg. pl. of <span class="ar">مِئْخَارٌ</span></a>]</span>: <a href="#Axiru">see <span class="ar">آخِرُ</span></a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOaxBirN">
				<h3 class="entry"><span class="ar">مُتَأَخِّرٌ</span></h3>
				<div class="sense" id="mutaOaxBirN_A1">
					<p><span class="ar">مُتَأَخِّرٌ</span>: see its verb.</p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخر</span> - Entry: <span class="ar">مُتَأَخِّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutaOaxBirN_A2">
					<p><span class="add">[An author, or other person, <em>of the later,</em> or <em>more modern, times.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmustaOoxiriyna">
				<h3 class="entry"><span class="ar">المُستَأْخِرِينَ</span></h3>
				<div class="sense" id="AlmustaOoxiriyna_A1">
					<p><span class="ar">المُستَأْخِرِينَ</span> in the Ḳur xv. 24 is said by Th to mean <em>Those who come</em> to the mosque <em>after others,</em> or <em>late:</em> <span class="auth">(TA:)</span> or it means <em>those who are later in birth and death:</em> or <em>those who have not yet come forth from the loins of men:</em> or <em>those who are late,</em> or <em>backward, in adopting the Muslim religion and in fighting against unbelievers and in obedience.</em> <span class="auth">(Bḍ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0031.pdf" target="pdf">
							<span>Lanes Lexicon Page 31</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0032.pdf" target="pdf">
							<span>Lanes Lexicon Page 32</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
