<article class="root" id="Root_Ad">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/037_Axw">اخو</a></span>
				<span class="ar">اد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/039_Adb">ادب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ad_1">
				<h3 class="entry">1. ⇒ <span class="ar">أدّ</span></h3>
				<div class="sense" id="Ad_1_A1">
					<p><span class="ar long">أَدَّتْةُ دَاهِيَةٌ</span>, aor <span class="ar">ـُ</span> <span class="auth">(T, Ṣ; M, Ḳ)</span> and <span class="ar">ـِ</span>, <span class="auth">(M, Ḳ,)</span> but this latter is strange, <span class="add">[anomalous,]</span> and unknown, <span class="auth">(TA,)</span> and <span class="ar">ـَ</span>, <span class="auth">(M, Ḳ,)</span> mentioned by Lḥ, whence it seems that he made the pret. to be of the measure <span class="ar">فَعِلَ</span>, or that it is co-ordinate to <span class="ar">أَبَى</span>, aor <span class="ar">يَأْبَى</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">أَدُّ</span>, <span class="auth">(T, Ṣ, M,)</span> <em>A calamity befell him.</em> <span class="auth">(M, Ḳ.)</span> And in like manner, <span class="ar long">أَدَّهُ أَمْرٌ</span>, aor. and inf. n. as above, <em>An event befell him:</em> <span class="auth">(M:)</span> or <em>oppressed him, distressed him,</em> or <em>afflicted him.</em> <span class="auth">(Bḍ in xix. 91.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ad_1_B1">
					<p><a href="#Ad_5">See also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ad_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأدّد</span></h3>
				<div class="sense" id="Ad_5_A1">
					<p><span class="ar">تأدّد</span>; <span class="auth">(T, Ḳ;)</span> and<span class="arrow"><span class="ar">أَدَّ↓</span></span>, inf. n. <span class="ar">أَدُّ</span>; <span class="auth">(TA;)</span> <em>i. q.</em> <span class="ar">تَشَدَّدَ</span> <span class="add">[<em>He acted,</em> or <em>behaved, with forced hardness, firmness, strength, vigour, &amp;c.</em>]</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadBu">
				<h3 class="entry"><span class="ar">أَدُّ</span></h3>
				<div class="sense" id="OadBu_A1">
					<p><span class="ar">أَدُّ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">إِدُّ↓</span></span> <span class="auth">(T, Ḳ)</span> and<span class="arrow"><span class="ar">آدُّ↓</span></span> <span class="auth">(Ḳ)</span> <em>Strength; power; force:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> <em>superior power or force or influence; mastery; conquest; predominance.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اد</span> - Entry: <span class="ar">أَدُّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadBu_A2">
					<p><a href="#IidBu">See also <span class="ar">إِدُّ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اد</span> - Entry: <span class="ar">أَدُّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OadBu_A3">
					<p>Also, the first, The <em>sound of treading.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IidBu">
				<h3 class="entry"><span class="ar">إِدُّ</span></h3>
				<div class="sense" id="IidBu_A1">
					<p><span class="ar">إِدُّ</span>: <a href="#OadBu">see <span class="ar">أَدُّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اد</span> - Entry: <span class="ar">إِدُّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IidBu_A2">
					<p>Also, and<span class="arrow"><span class="ar">إِدَّةٌ↓</span></span>, <em>A wonder,</em> or <em>wonderful thing:</em> <span class="auth">(M, L, Ḳ:)</span> <em>a very evil, abominable, severe, thing,</em> or <em>affair:</em> <span class="auth">(Ṣ, M, A, L, Ḳ:)</span> <em>a calamity;</em> <span class="auth">(Ṣ, A, L, Ḳ,)</span> or thus the former word signifies; <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar">أَدُّ↓</span></span>, <span class="auth">(as in the copies of the Ḳ,)</span> or<span class="arrow"><span class="ar">آدُّ↓</span></span>, <span class="add">[originally <span class="ar">آدِدً</span>]</span> of the measure <span class="ar">فَاعِلْ</span>: <span class="auth">(so in the Ṣ and L:)</span> pl. <span class="auth">(of <span class="ar">إِدُّ</span> M, TA)</span> <span class="ar">إِدادُ</span> <span class="auth">(Ḳ, TA,)</span> or <span class="ar">أَدَادُ</span> <span class="auth">(T, CK, <span class="add">[but this, if correct, is a quasi-pl. n.,]</span>)</span> or <span class="ar">آدَادُ</span> <span class="auth">(M,)</span> and <span class="auth">(of <span class="ar">إِدَّةٌ</span>, Ṣ, M)</span> <span class="ar">إِدَدٌ</span> <span class="auth">(T, Ṣ, M, Ḳ.)</span> You say also <span class="ar long">أَمْرٌ إِدٌّ</span> <span class="add">[meaning as above]</span>, using <span class="ar">إِدٌّ</span> as an epithet, accord. to Lḥ. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">دَاهِيَةٌ إِدَّةٌ↓</span></span> <span class="add">[<em>A very evil, abominable,</em> or <em>severe, calamity</em>]</span>. <span class="auth">(A.)</span> Hence the saying in the Ḳur <span class="add">[xix. 91]</span>, <span class="ar long">لَقَدْ جِئْتُمْ شَيْئًا إِدًّا</span> <em>Verily ye have done a very evil,</em> or <em>abominable, thing:</em> <span class="auth">(Ṣ, M:*)</span> or, accord. to one reading, <span class="arrow"><span class="ar">أَدُّا↓</span></span>; both meaning <em>great,</em> or <em>grievous:</em> and some of the Arabs say, <span class="arrow"><span class="ar long">بِشَىْءٍ آدٍّ↓</span></span>, which means the same. <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IidBapN">
				<h3 class="entry"><span class="ar">إِدَّةٌ</span></h3>
				<div class="sense" id="IidBapN_A1">
					<p><span class="ar">إِدَّةٌ</span>: <a href="#IidBu">see <span class="ar">إِدُّ</span></a> in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MdBu">
				<h3 class="entry"><span class="ar">آدُّ</span></h3>
				<div class="sense" id="MdBu_A1">
					<p><span class="ar">آدُّ</span>: <a href="#OadBu">see <span class="ar">أَدُّ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اد</span> - Entry: <span class="ar">آدُّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MdBu_A2">
					<p><a href="#IidBu">and see <span class="ar">إِدُّ</span></a> in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0034.pdf" target="pdf">
							<span>Lanes Lexicon Page 34</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
