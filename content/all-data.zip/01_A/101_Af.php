<article class="root" id="Root_Af">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/100_ATm">اطم</a></span>
				<span class="ar">اف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/102_Afx">افخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Af_1">
				<h3 class="entry">1. ⇒ <span class="ar">أفّ</span></h3>
				<div class="sense" id="Af_1_A1">
					<p><span class="ar">أَفَّ</span>, aor. <span class="ar">يَؤُفٌّ</span> <span class="auth">(IDrd, M, Mgh, Ḳ,)</span> and <span class="ar">يَئِفُّ</span>, <span class="auth">(IDrd, M, Ḳ,)</span> the latter agreeable with analogy, <span class="auth">(TA,)</span> <span class="add">[but the former, though irregular, is the more common,]</span> inf. n. <span class="ar">أَفٌّ</span>; <span class="auth">(M, Mgh;)</span> and<span class="arrow"><span class="ar">أفّف↓</span></span>, inf. n. <span class="ar">تأْفِيفٌ</span>; <span class="auth">(Ṣ, Mgh, Ḳ;)</span> and<span class="arrow"><span class="ar">تأفّف↓</span></span>; <span class="auth">(M, Ḳ;)</span> <em>He said</em> <span class="ar">أُفِّ</span> <span class="add">[q. v.]</span>, <span class="auth">(IDrd, Ṣ, M, Mgh, Ḳ,)</span> by reason of anxiety, or disquietude of mind, or by reason of vexation, distress of mind, or disgust: <span class="auth">(IDrd, M, Ḳ:)</span> held by Sb to be of the same class as <span class="ar">سَبَّحَ</span> and <span class="ar">هَلَّلَ</span> meaning “he said <span class="ar long">سُبْحَانَ ٱللّٰهِ</span>” and “he said <span class="ar long">لَا إِلٰهَ إِلَّا ٱللّٰهُ</span>.” <span class="auth">(M.)</span> You say also,<span class="arrow"><span class="ar">أَفَّفَهُ↓</span></span>, and<span class="arrow"><span class="ar long">أَفَّفَ↓ بِهِ</span></span>, and<span class="arrow"><span class="ar long">تَأَفَّفَ↓ بِهِ</span></span>, meaning <em>He said to him</em> <span class="ar">أُفِّ</span>. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">جَعَلَ فُلَانٌ يَتَأَفَّفُ↓ مِنْ رِيحٍ وَجَدَهَا</span></span> <em>Such a one began to say</em> <span class="ar long">أُفِّ أُفِّ</span> <em>by reason of a smell which he perceived.</em> <span class="auth">(T.)</span> And<span class="arrow"><span class="ar long">إِنَّهُ يَتَأَفَّفُ↓ عَلَيْهِ</span></span> <em>Verily he is angry with him,</em> or <em>enraged against him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Af_2">
				<h3 class="entry">2. ⇒ <span class="ar">أفّف</span></h3>
				<div class="sense" id="Af_2_A1">
					<p><a href="#Af_1">see 1</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Af_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأفّف</span></h3>
				<div class="sense" id="Af_5_A1">
					<p><a href="#Af_2">see 2</a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oafo">
				<h3 class="entry"><span class="ar">أَفْ</span> / 
							<span class="ar">أَفِّ</span> / 
							<span class="ar">أَفٍّ</span> / 
							<span class="ar">أَفٍ</span></h3>
				<div class="sense" id="Oafo_A1">
					<p><span class="ar">أَفْ</span> and <span class="ar">أَفِّ</span> and <span class="ar">أَفٍّ</span>, or <span class="ar">أَفٍ</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Iifo">
				<h3 class="entry"><span class="ar">إِفْ</span> / 
							<span class="ar">إِفِ</span> / 
							<span class="ar">إِفٍ</span> / 
							<span class="ar">إِفًا</span> / 
							<span class="ar">إِفٌ</span></h3>
				<div class="sense" id="Iifo_A1">
					<p><span class="ar">إِفْ</span> and its vars. <span class="auth">(differing only in having the <span class="ar">ف</span> movent)</span>: <a href="#OufBN">see the next paragraph</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OufBN">
				<h3 class="entry"><span class="ar">أُفٌّ</span></h3>
				<div class="sense" id="OufBN_A1">
					<p><span class="ar">أُفٌّ</span> <em>Dirt,</em> or <em>filth;</em> as also<span class="arrow"><span class="ar">أُفَّةٌ↓</span></span>: <span class="auth">(Ṣ:)</span> you say, <span class="ar long">أُفَّا لَهُ</span>, and<span class="arrow"><span class="ar">أُفَّةً↓</span></span>, <em>Dirt,</em> or <em>filth, to him;</em> in which the tenween is for the purpose of rendering them indeterminate; <span class="auth">(Ṣ;)</span> and <span class="ar long">أُفَّ لَهُ وَتُفٌّ</span>; <span class="auth">(T;)</span> and<span class="arrow"><span class="ar long">أُفَّةً↓ وَتُفَّةً</span></span>; and <span class="ar long">أُفَّا وَتُفَّا</span>; <span class="auth">(T, Ṣ;)</span> the latter of which is an imitative sequent: <span class="auth">(Ṣ:)</span> or <span class="ar">أُفٌّ</span> signifies the <em>dirt of the ear;</em> and <span class="ar">تُفٌّ</span>, the <em>dirt of the nails;</em> <span class="auth">(Aṣ, T, M, Ḳ; but in the last, <em>of the nail;</em>)</span> the phrases mentioned above being used on the occasion of deeming a thing dirty or filthy, and afterwards on the occasion of experiencing annoyance or disgust at anything; <span class="auth">(Aṣ, T, M,* TA;)</span> and<span class="arrow"><span class="ar">أَفَفٌ↓</span></span>, also, has the former of these two meanings: <span class="auth">(TA:)</span> or <span class="ar">أُفٌّ</span> signifies the <em>dirt around the nail;</em> <span class="auth">(M;)</span> or the <em>dirt of the nail;</em> <span class="auth">(Ḳ;)</span> and <span class="ar">تُفٌّ</span>, the <em>dirt in the nail:</em> <span class="auth">(M:)</span> or the former, <em>a paring of the nail:</em> and <em>a piece of stick,</em> or <em>a reed, which one takes up from the ground:</em> <span class="auth">(Ḳ:)</span> in these various senses they are explained as used in the saying, <span class="ar long">أُفَّا لَهُ وَتُفَّا</span>: <span class="auth">(TA:)</span> or the former signifies <em>stink:</em> <span class="auth">(Zj, TA:)</span> or <em>paucity;</em> <span class="auth">(T, M, Ḳ)</span> as also<span class="arrow"><span class="ar">أَفَفٌ↓</span></span>; <span class="auth">(M;)</span> or from <span class="arrow"><span class="ar">أَفَفٌ↓</span></span> signifying <em>a thing little in quantity;</em> <span class="auth">(T; and the same meaning is assigned to this word in the Ḳ;)</span> and <span class="ar">تُفٌّ</span> is an imitative sequent, <span class="auth">(T, M, Ḳ,)</span> of the same meaning. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">أُفٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OufBN_A2">
					<p><span class="ar">أُفِّ</span>, also, is a word expressive of vexation, distress of mind, or disgust; <span class="auth">(M, Mgh;)</span> or of dislike, displeasure, or hatred; <span class="auth">(Ḳ;)</span> and has six forms; <span class="auth">(T, Ṣ;)</span> mentioned by Akh; <span class="auth">(Ṣ;)</span> or ten; <span class="auth">(M;)</span> or forty; <span class="auth">(Ḳ;)</span> or more; <span class="auth">(TA;)</span> as follow: <span class="ar">أُفِّ</span> and <span class="ar">أُفَّ</span> and <span class="ar">أُفُّ</span> and <span class="ar">أُفٍّ</span> and <span class="ar">أُفَّا</span> and <span class="ar">أُفٌّ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">أُفِّ</span> and <span class="ar">أُفَ</span> and <span class="ar">أُفُ</span> and <span class="ar">أُفٍ</span> and <span class="ar">أُفًا</span> and <span class="ar">أُفٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">أُفْ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">أُفّْ</span> and<span class="arrow"><span class="ar">أُفَّى↓</span></span>, pronounced with imáleh, <span class="auth">(M, Ḳ,)</span> i. e. with pure imáleh, and<span class="arrow"><span class="ar">أُفَّى↓</span></span> with intermediate imáleh, and<span class="arrow"><span class="ar">أُفَّى↓</span></span> without imáleh, the alif <span class="add">[written <span class="ar">ى</span>]</span> in these three denoting the fem. gender, and<span class="arrow"><span class="ar">أُفِّى↓</span></span>, with kesr to the <span class="ar">ف</span>, <span class="auth">(Ḳ,)</span> i. e., as a prefixed noun with its complement, <span class="add">[the latter being the pronoun of the first pers.,]</span> <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">أُفُّوْهْ↓</span></span>, <span class="auth">(Ḳ,)</span> with damm to the <span class="ar">أ</span> and <span class="ar">ف</span>, which latter is with teshdeed, and with the <span class="ar">و</span> and <span class="ar">ه</span> quiescent, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">أُفَّةْ↓</span></span> <span class="add">[in a copy of the M<span class="arrow"><span class="ar">أُفَّةً↓</span></span>]</span> and<span class="arrow"><span class="ar">أُفِهْ↓</span></span> and<span class="arrow"><span class="ar">أُفُّهْ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">إِفْ↓</span></span> and<span class="arrow"><span class="ar">إِفّْ↓</span></span> and<span class="arrow"><span class="ar">إِفِ↓</span></span> and<span class="arrow"><span class="ar">إِفٍ↓</span></span> and<span class="arrow"><span class="ar">إِفًا↓</span></span> and<span class="arrow"><span class="ar">إِفٌ↓</span></span> and<span class="arrow"><span class="ar">إِفٍّ↓</span></span> and<span class="arrow"><span class="ar">إِفًّ↓</span></span> and<span class="arrow"><span class="ar">إِفٌّ↓</span></span> and<span class="arrow"><span class="ar">إِفُّ↓</span></span>, with damm to the <span class="ar">ف</span>, which is with teshdeed, <span class="add">[in a copy of the M<span class="arrow"><span class="ar">إِفَّ↓</span></span>,]</span> and<span class="arrow"><span class="ar">إِفَّا↓</span></span>, like <span class="ar">إِنَّا</span>, and<span class="arrow"><span class="ar">إِفَّى↓</span></span>, pronounced with imáleh, and<span class="arrow"><span class="ar">إِفِّى↓</span></span>, with kesr, <span class="auth">(Ḳ,)</span> i. e., prefixed to the pronoun of the first person, <span class="auth">(IAmb,)</span> and<span class="arrow"><span class="ar">أَفْ↓</span></span> and<span class="arrow"><span class="ar">أَفِّ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">أَفٍّ↓</span></span> or<span class="arrow"><span class="ar">أَفٍ↓</span></span> and<span class="arrow"><span class="ar">آفِ↓</span></span>, or<span class="arrow"><span class="ar">آفِّ↓</span></span>, and<span class="arrow"><span class="ar">آفٍ↓</span></span>, or<span class="arrow"><span class="ar">آفٍّ↓</span></span>, <span class="auth">(accord. to different copies of the Ḳ,)</span> <span class="add">[all these forms, making the number <span class="auth">(forty)</span> mentioned by the author of the Ḳ, I have drawn from a comparison of three copies of that work, and I believe them to be correct: some other forms are mentioned by SM as perhaps indicated in the Ḳ; but I see no good reason for this: he then adds,]</span> and<span class="arrow"><span class="ar">أَفَهْ↓</span></span> and<span class="arrow"><span class="ar">أَفُوهْ↓</span></span> and<span class="arrow"><span class="ar">أَفَّهْ↓</span></span>, the last mentioned by IB on the authority of IḲṭṭ. <span class="auth">(TA.)</span> <span class="ar">أُفِّ</span>, <span class="add">[with its variants,]</span> in its primary sense, denotes one's blowing at a thing that falls upon him, such as dust or ashes; or at the place, to remove therefrom what is annoying; therefore people say, at anything that they deem troublesome, or displeasing, or hateful, <span class="ar long">أُفِّ لَهُ</span> <span class="add">[as though meaning <em>A puff,</em> or <em>blast of breath, to it</em>]</span>: <span class="auth">(Ḳṭ, T:)</span> or <span class="add">[rather]</span> it is a word imitative of a sound; <span class="add">[like <em>ugh</em> in English, both in sound and meaning; and in meaning like our interjections <em>foh</em> and <em>faugh;</em>]</span> <span class="auth">(Bḍ on the ex. in the Ḳur which will be found below, and TA;)</span> denoting vexation, or distress of mind, or disgust; <span class="auth">(Bḍ ubi suprà)</span> or denoting contempt: <span class="auth">(TA:)</span> or it is a verbal noun, meaning <em>I am vexed,</em> or <em>distressed in mind,</em> or <em>disgusted:</em> <span class="auth">(Bḍ ubi suprà:)</span> or it is an imperative verbal noun <span class="add">[denoting disgust or abhorrence, like <em>out,</em> and <em>away</em>]</span>: <span class="auth">(IJ, M:)</span> or he who says <span class="ar long">أُفَّا لَكَ</span> uses it in the manner of an imprecation, like as one says <span class="ar long">وَيْلًا لِلْكَافِرِينَ</span>; and he who says <span class="ar long">أُفٌّ لَكَ</span> puts it in the nom. case because of the <span class="ar">ل</span>, like as one says <span class="ar long">وَيْلٌ لِلْكَافِرِينَ</span>; and he who says <span class="ar long">أُفٍّ لَكَ</span> puts it in the gen. case likening it to words imitative of sounds. <span class="auth">(IAmb.)</span> It is said in the Ḳur <span class="add">[xvii. 24]</span>, <span class="ar long">وَلَا تَقُلْ لَهُمَا أُفِّ</span>, <span class="auth">(T, Ṣ, TA,)</span> or <span class="ar">أُفٍّ</span>, <span class="auth">(TA, <span class="add">[in which other readings also are mentioned,]</span>)</span> <span class="add">[<em>And say not thou to them</em> <span class="auth">(i. e. to thy father and mother)</span> <em>Ugh,</em>, &amp;c.,]</span> meaning, do not thou deem anything of their affairs burdensome, nor be contracted in bosom thereby, nor be rough, or harsh, or coarse, to them: <span class="auth">(Ḳṭ, T:)</span> or do not thou say to them anything expressive of the least disgust, when they have become old, but take upon thyself their service; <span class="ar">أُفِّ</span> signifying <em>stink.</em> <span class="auth">(Zj, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IifBo">
				<h3 class="entry"><span class="ar">إِفّْ</span> / 
							<span class="ar">إِفٍّ</span> / 
							<span class="ar">إِفًّ</span> / 
							<span class="ar">إِفٌّ</span> / 
							<span class="ar">إِفُّ</span> / 
							<span class="ar">إِفَّا</span> / 
							<span class="ar">إِفَّى</span> / 
							<span class="ar">إِفِّى</span></h3>
				<div class="sense" id="IifBo_A1">
					<p><span class="ar">إِفّْ</span> and its vars. <span class="auth">(differing only in having the <span class="ar">ف</span> movent)</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">إِفّْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IifBo_B1">
					<p>For <span class="ar">إِفٌّ</span>, <a href="#IifBaAnN">see also <span class="ar">إِفَّانٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OafBapN">
				<h3 class="entry"><span class="ar">أَفَّةٌ</span></h3>
				<div class="sense" id="OafBapN_A1">
					<p><span class="ar">أَفَّةٌ</span>: <a href="#IifBaAnN">see <span class="ar">إِفَّانٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OufBapN">
				<h3 class="entry"><span class="ar">أُفَّةٌ</span></h3>
				<div class="sense" id="OufBapN_A1">
					<p><span class="ar">أُفَّةٌ</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>, in four places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">أُفَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OufBapN_B1">
					<p>Also A <em>dirty, a filthy, an unclean,</em> man: <span class="auth">(Ḳ:)</span> from <span class="ar">أُفٌّ</span> signifying the “dirt of the nail.” <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">أُفَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OufBapN_B2">
					<p>One <em>in want; poor; possessing little:</em> <span class="auth">(Ḳ:)</span> from <span class="ar">أَفَفٌ</span> signifying “a thing little in quantity.” <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0068"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">أُفَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OufBapN_B3">
					<p><em>A coward:</em> <span class="auth">(Ḳ:)</span> as though originally <span class="ar long">ذُو أُفَّةٍ</span>, i. e. <em>holding back, by reason of disgust,</em> (<span class="ar">مُتَأَفِّفٌ</span>,) <em>from fight:</em> <span class="auth">(TA:)</span> or <em>experiencing vexation</em> or <em>disgust,</em> and <em>languid</em> or <em>sluggish, in war:</em> <span class="auth">(IAạr:)</span> also <em>heavy,</em> or <em>sluggish.</em> <span class="auth">(IAth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IifBapN">
				<h3 class="entry"><span class="ar">إِفَّةٌ</span></h3>
				<div class="sense" id="IifBapN_A1">
					<p><span class="ar">إِفَّةٌ</span>: <a href="#IifBaAnN">see <span class="ar">إِفَّانٌ</span></a> in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafafN">
				<h3 class="entry"><span class="ar">أَفَفٌ</span></h3>
				<div class="sense" id="OafafN_A1">
					<p><span class="ar">أَفَفٌ</span> <em>Vexation, distress of mind,</em> or <em>disgust.</em> <span class="auth">(T, IAth, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">أَفَفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OafafN_A2">
					<p><a href="#OufBN">See also <span class="ar">أُفٌّ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اف</span> - Entry: <span class="ar">أَفَفٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OafafN_B1">
					<p><a href="#IifBaAnN">And see <span class="ar">إِفَّانٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oafaho">
				<h3 class="entry"><span class="ar">أَفَهْ</span> / 
							<span class="ar">أَفَّهْ</span> / 
							<span class="ar">أُفَّهْ</span> / 
							<span class="ar">أُفِّهْ</span> / 
							<span class="ar">أُفُّهْ</span></h3>
				<div class="sense" id="Oafaho_A1">
					<p><span class="ar">أَفَهْ</span> and <span class="ar">أَفَّهْ</span> and <span class="ar">أُفَّهْ</span> and <span class="ar">أُفِّهْ</span> and <span class="ar">أُفُّهْ</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OufBae">
				<h3 class="entry"><span class="ar">أُفَّى</span> /<span class="ar">أُفِّى</span></h3>
				<div class="sense" id="OufBae_A1">
					<p><span class="ar">أُفَّى</span>, pronounced in three different ways; and <span class="ar">أُفِّى</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IifBaA">
				<h3 class="entry"><span class="ar">إِفَّا</span> / 
							<span class="ar">إِفَّى</span> / 
							<span class="ar">إِفِّى</span></h3>
				<div class="sense" id="IifBaA_A1">
					<p><span class="ar">إِفَّا</span> and <span class="ar">إِفَّى</span> and <span class="ar">إِفِّى</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oafuwho">
				<h3 class="entry"><span class="ar">أَفُوهْ</span></h3>
				<div class="sense" id="Oafuwho_A1">
					<p><span class="ar">أَفُوهْ</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OufuwfapN">
				<h3 class="entry"><span class="ar">أُفُوفَةٌ</span></h3>
				<div class="sense" id="OufuwfapN_A1">
					<p><span class="ar">أُفُوفَةٌ</span>: <a href="#OafBaAfN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafBaAfN">
				<h3 class="entry"><span class="ar">أَفَّافٌ</span></h3>
				<div class="sense" id="OafBaAfN_A1">
					<p><span class="ar">أَفَّافٌ</span> A man <em>who says</em> <span class="ar">أُفِّ</span> <em>much</em> or <em>often;</em> <span class="auth">(M, TA;)</span> as also<span class="arrow"><span class="ar">أُوفُوفَةٌ↓</span></span>, accord. to the copies of the O and TṢ and Ḳ; but in other lexicons <span class="arrow"><span class="ar">أُوفُوفَةٌ↓</span></span>: in the O, one <em>who ceases not to say to another</em> <span class="ar long">أُفِّ لَكَ</span>: in the Jm, the last of these three words is explained as meaning one <em>who ceases no to say this at some of his affairs.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IifBaAnN">
				<h3 class="entry"><span class="ar">إِفَّانٌ</span></h3>
				<div class="sense" id="IifBaAnN_A1">
					<p><span class="ar">إِفَّانٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">أَفَّانٌ</span> <span class="auth">(T, TṢ, L, Ḳ)</span> and<span class="arrow"><span class="ar">إِفٌّ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">أَفَفٌ↓</span></span> <span class="auth">(T, L, Ḳ)</span> and<span class="arrow"><span class="ar">إِفَّةق↓</span></span> <span class="auth">(L, M)</span> and<span class="arrow"><span class="ar">أَفَّةٌ↓</span></span> <span class="auth">(M)</span> and<span class="arrow"><span class="ar">تِئِفَّةٌ↓</span></span>, <span class="auth">(T, M, Ṣ, Ḳ, &amp;c.,)</span> of the measure <span class="ar">تَفْعِلَةٌ</span>, <span class="add">[being originally <span class="ar">تَأْفِفَةٌ</span>,]</span> accord. to J, who appears to be right in saying so, <span class="auth">(IB,)</span> and so accord. to Aboo-ʼAlee, who states, on authority of Aboo-Bekr, that it is thus in some of the copies of the Book of Sb, <span class="auth">(L,)</span> though in other copies of that book said to be of the measure <span class="ar">فَعِلَّةٌ</span>, <span class="auth">(IB, L,)</span> <em>A time;</em> <span class="auth">(T, Ṣ, M, Ḳ;)</span> as in the sayings,<span class="arrow"><span class="ar long">كَانَ ذٰلِكَ عَلَى إِفِّ↓ ذٰلِكَ</span></span>, and <span class="ar">إِفَّانِهِ</span> <span class="auth">(Ṣ, TA)</span> and<span class="arrow"><span class="ar">أَفَفِهِ↓</span></span>, and<span class="arrow"><span class="ar">إِفَّتِهِ↓</span></span>, and<span class="arrow"><span class="ar">تَئِفَّتِهِ↓</span></span>, <span class="auth">(TA,)</span> <em>That was at the time of that;</em> <span class="auth">(Ṣ, TA;)</span> and <span class="ar long">أَتَانِى فِى إِفَّانِ ذٰلِكَ</span>, <span class="auth">(IAạr, L,)</span> and <span class="ar long">عَلَى إِفَّانِ ذٰلِكَ</span>, <span class="auth">(IAạr, T, M, L,)</span> and <span class="ar">أَفَّانِهِ</span>, <span class="auth">(T, L,)</span> and<span class="arrow"><span class="ar">إِفِّهِ↓</span></span>, <span class="auth">(M, L,)</span> and<span class="arrow"><span class="ar">أَفَفِهِ↓</span></span>, <span class="auth">(IAạr, T, L,)</span> and<span class="arrow"><span class="ar">إِفَّتِهِ↓</span></span>, <span class="auth">(M, L,)</span> and<span class="arrow"><span class="ar">أَفَّتِهِ↓</span></span>, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">تَئِفَّتِهِ↓</span></span>, <span class="auth">(IAạr, T, Ṣ, M, L,)</span> preceded by <span class="ar">على</span>, <span class="auth">(IAạr, T, Ṣ, &amp;c.,)</span> and by <span class="ar">فى</span>, <span class="auth">(L,)</span> <em>He came to me at the time of that.</em> <span class="auth">(IAạr, T, &amp;c.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OufBuwoho">
				<h3 class="entry"><span class="ar">أُفُّوْهْ</span></h3>
				<div class="sense" id="OufBuwoho_A1">
					<p><span class="ar">أُفُّوْهْ</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mfi">
				<h3 class="entry"><span class="ar">آفِ</span> / 
							<span class="ar">آفِّ</span> / 
							<span class="ar">آفٍ</span> / 
							<span class="ar">آفٍّ</span></h3>
				<div class="sense" id="Mfi_A1">
					<p><span class="ar">آفِ</span> and <span class="ar">آفِّ</span> and <span class="ar">آفٍ</span> and <span class="ar">آفٍّ</span>: <a href="#OufBN">see <span class="ar">أُفٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuwfuwfapN">
				<h3 class="entry"><span class="ar">أُوفُوفَةٌ</span></h3>
				<div class="sense" id="OuwfuwfapN_A1">
					<p><span class="ar">أُوفُوفَةٌ</span>: <a href="#OafBaAfN">see <span class="ar">أَفَّافٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taYifBapN">
				<h3 class="entry"><span class="ar">تَئِفَّةٌ</span></h3>
				<div class="sense" id="taYifBapN_A1">
					<p><span class="ar">تَئِفَّةٌ</span>: <a href="#IifBAnN">see <span class="ar">إِفّانٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOafBifN">
				<h3 class="entry"><span class="ar">مُتَأَفِّفٌ</span></h3>
				<div class="sense" id="mutaOafBifN_A1">
					<p><span class="ar long">مُتَأَفِّفٌ عَنِ القِتَالِ</span> <span class="add">[app. <em>Holding back, by reason of disgust, from fight;</em> as though saying <span class="ar">أُفّ</span> at the mention thereof: <a href="#OufBapN">see <span class="ar">أُفَّةٌ</span></a>]</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0067.pdf" target="pdf">
							<span>Lanes Lexicon Page 67</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0068.pdf" target="pdf">
							<span>Lanes Lexicon Page 68</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
