<article class="root" id="Root_As">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/071_Aze">ازى</a></span>
				<span class="ar">اس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/073_Asb">اسب</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="As_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسّ</span></h3>
				<div class="sense" id="As_1_A1">
					<p><a href="#As_2">see 2</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="As_2">
				<h3 class="entry">2. ⇒ <span class="ar">أسّس</span></h3>
				<div class="sense" id="As_2_A1">
					<p><span class="ar">أسّسهُ</span>, <span class="auth">(Ṣ, M, Mṣb,)</span> inf. n. <span class="ar">تَأْسِيسٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>He founded it;</em> or <em>made,</em> or <em>laid, a foundation,</em> or <em>basis, for it;</em> <span class="auth">(Ṣ,* Mṣb;)</span> namely, a building, <span class="auth">(Ṣ,)</span> or a wall: <span class="auth">(Mṣb:)</span> <em>he marked out the limits of it,</em> <span class="auth">(namely, of a house,)</span> <em>and raised its foundations: he built its foundation,</em> or <em>basis:</em> <span class="auth">(Ḳ:)</span> <em>he commenced it;</em> namely, a building; as also<span class="arrow"><span class="ar">أَسَّهُ↓</span></span>, aor. <span class="ar">يَؤُسُّهُ</span>, inf. n. <span class="ar">أَسَّ</span>: <span class="auth">(M:)</span> <em>he built it;</em> namely, a house; <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">أَسَّهُ↓</span></span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">هٰذَا تَأْسِيسٌ حَسَنٌ</span> <span class="add">[<em>This is a good founding,</em> or <em>foundation</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">مَنْ لَمْ يُؤَسِّسْ مِلْكَهُ بِالعَدْلِ هَدَمَهُ</span> ‡ <span class="add">[<em>He who does not lay the foundation of his property with equity,</em> or <em>justice, destroys it</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اس</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="As_2_A2">
					<p><span class="ar long">أسّس زَادًا</span>: <a href="#zaAda">see <span class="ar">زَادَ</span></a> <a href="index.php?data=11_z/122_zwd">in art. <span class="ar">زود</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasBN">
				<h3 class="entry"><span class="ar">أَسٌّ</span></h3>
				<div class="sense" id="OasBN_A1">
					<p><span class="ar">أَسٌّ</span>: <a href="#OusBN">see what next follows</a>, in six places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OusBN">
				<h3 class="entry"><span class="ar">أُسٌّ</span></h3>
				<div class="sense" id="OusBN_A1">
					<p><span class="ar">أُسٌّ</span> The <em>foundation, basis,</em> or <em>lowest part,</em> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ,)</span> of a building, <span class="auth">(Ṣ, A, Ḳ,)</span> or of a wall; <span class="auth">(Mgh, Mṣb;)</span> as also<span class="arrow"><span class="ar">أَسٌّ↓</span></span> and<span class="arrow"><span class="ar">إِسٌّ↓</span></span> <span class="auth">(A, Ḳ)</span> and<span class="arrow"><span class="ar">أَسَاسٌ↓</span></span> <span class="auth">(Ṣ, A, Mgh, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">أَسَسٌ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> which is a contraction of <span class="ar">أَسَاسٌ</span>: <span class="auth">(Ṣ:)</span> or the <em>commencement</em> of a building: and <em>any commencement</em> of a thing; as also<span class="arrow"><span class="ar">أَسٌّ↓</span></span> and<span class="arrow"><span class="ar">أَسَاسٌ↓</span></span> and<span class="arrow"><span class="ar">أَسَسٌ↓</span></span>: <span class="auth">(M:)</span> and the <em>origin, source, stock,</em> or <em>root,</em> (<span class="ar">أَصْل</span>,) of a man; as also<span class="arrow"><span class="ar">أَسٌّ↓</span></span>: or of anything; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَسٌّ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">إِسٌّ↓</span></span> and<span class="arrow"><span class="ar">أَسِيسٌ↓</span></span>: <span class="auth">(Ḳ:)</span> and the <em>heart</em> of a man; because <span class="add">[the Arabs believe that]</span> it is the first thing that comes into existence in the womb: <span class="auth">(M, Ḳ:)</span> pl. <span class="ar">آسَاسٌ</span> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">إِسَاسٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">أُسُسٌ</span>; <span class="auth">(M, Mgh, Mṣb, Ḳ;)</span> the first of which is pl. of <span class="ar">أُسٌّ</span>, <span class="auth">(Mgh, Mṣb,)</span> like as <span class="ar">أَقْفَالٌ</span> is of <span class="ar">قُفْلٌ</span>; <span class="auth">(Mṣb;)</span> <a href="#OasasN">or of <span class="ar">أَسَسٌ</span></a>, like as <span class="ar">أَسْبَابٌ</span> is of <span class="ar">سَبَبٌ</span>; <span class="auth">(Ṣ;)</span> or, as some say, of <span class="ar">أُسُسٌ</span>, <span class="add">[like as <span class="ar">أَعْنَاقٌ</span> is of <span class="ar">عُنُقٌ</span>,]</span> so that it is a pl. pl.; <span class="auth">(TA;)</span> and the second, of <span class="ar">أَسٌّ</span>, like as <span class="ar">عِسَاسٌ</span> is of <span class="ar">عُسٌّ</span>; <span class="auth">(Mṣb;)</span> and the third, of <span class="ar">أَسَاسٌ</span>, <span class="auth">(Mgh, Mṣb,)</span> like as <span class="ar">عُنُقٌ</span> is of <span class="ar">عَنَاقٌ</span>. <span class="auth">(Mṣb.)</span> You say,<span class="arrow"><span class="ar long">بَنَى بَيْتَهُ عَلَى أَسَاسِهِ↓ الأَوَّلِ</span></span> <span class="add">[<em>He built his house upon its first foundation.</em>]</span> <span class="auth">(A.)</span> And <span class="ar long">قَلَعَهُ مِنْ أُسِّهِ</span> <span class="add">[<em>He uprooted it from its foundation</em>]</span>. <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">فُلَانٌ أَسَاسُ↓ أَمْرِهِ الكَذِبُ</span></span> ‡ <span class="add">[<em>Such a one, the foundation of his affair,</em> or <em>case, is falsehood</em>]</span>. <span class="auth">(A, TA.)</span> And <span class="ar long">كَانَ ذٰلَكَ عَلَى أُسِّ الدَّهْرِ</span>, <span class="auth">(Ṣ, M, A, Ḳ,)</span> and<span class="arrow"><span class="ar">أَسِهِ↓</span></span>, and<span class="arrow"><span class="ar">إِسِهِ↓</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> ‡ <em>That was in old,</em> or <em>ancient, time;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>at the beginning of time;</em> <span class="auth">(Ṣ, A,* Ḳ;)</span> and in like manner, <span class="ar long">عَلَى ٱسْتِ الدَّهْرِ</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اس</span> - Entry: <span class="ar">أُسٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OusBN_A2">
					<p>Also <em>A remain, relic, trace, vestige, sign, mark,</em> or <em>track,</em> of anything. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">خُذْ أُسَّ الطَّرِيقِ</span>, or<span class="arrow"><span class="ar long">أَسَّ↓ الطَّرِيقِ</span></span>, <span class="add">[accord. to different copies of the Ḳ, meaning, <em>Take thou to the track of the way,</em>]</span> when one guides himself by any mark or track, or by camels' dung: but when the way is manifest, you say, <span class="ar long">خُذْ شَرَكَ الطَّرِيقِ</span>. <span class="auth">(Ḳ.)</span> <span class="ar">أُسٌّ</span> also signifies The <em>remains of ashes</em> <span class="auth">(M, Ḳ)</span> <em>between the</em> <span class="ar">أَثَافِى</span>, q.v.: <span class="auth">(M:)</span> occurring in a verse of En-Nábighah Edh-Dhubyánee; but accord. to most relates of this verse, it is <span class="ar">آسٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IisBN">
				<h3 class="entry"><span class="ar">إِسٌّ</span></h3>
				<div class="sense" id="IisBN_A1">
					<p><span class="ar">إِسٌّ</span>: <a href="#OusBN">see <span class="ar">أُسٌّ</span></a>, in several places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasasN">
				<h3 class="entry"><span class="ar">أَسَسٌ</span></h3>
				<div class="sense" id="OasasN_A1">
					<p><span class="ar">أَسَسٌ</span>: <a href="#OusBN">see <span class="ar">أُسٌّ</span></a>, in several places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasaAsN">
				<h3 class="entry"><span class="ar">أَسَاسٌ</span></h3>
				<div class="sense" id="OasaAsN_A1">
					<p><span class="ar">أَسَاسٌ</span>: <a href="#OusBN">see <span class="ar">أُسٌّ</span></a>, in several places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasiysN">
				<h3 class="entry"><span class="ar">أَسِيسٌ</span></h3>
				<div class="sense" id="OasiysN_A1">
					<p><span class="ar">أَسِيسٌ</span>: <a href="#OusBN">see <span class="ar">أُسٌّ</span></a>, in several places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
