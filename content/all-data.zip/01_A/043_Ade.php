<article class="root" id="Root_Ade">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/042_Adw">ادو</a></span>
				<span class="ar">ادى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/044_Ac">اذ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ade_2">
				<h3 class="entry">2. ⇒ <span class="ar">أدّى</span></h3>
				<div class="sense" id="Ade_2_A1">
					<p><span class="ar">أدّاهُ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">تأُدِيَةٌ</span> <span class="auth">(T, Ṣ, Ḳ)</span> and <span class="ar">أَدَآءٌ</span>, <span class="auth">(T,)</span> or the latter is a simple subst., <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <span class="add">[and so, accord. to the Mṣb, is the former also, but this is a mistake,]</span> <em>He made it,</em> or <em>caused it, to reach, arrive,</em> or <em>come</em> <span class="add">[to the appointed person or place, &amp;c.]</span>; <em>he brought, conveyed,</em> or <em>delivered, it;</em> syn. <span class="ar">أَوْصَلَهُ</span>; <span class="auth">(M, Mṣb, Ḳ;)</span> namely, a thing; <span class="auth">(M;)</span> as, for instance, <span class="ar long">الأَمَانَةَ إِلَى أهْلِهَا</span> <span class="add">[<em>the thing committed to his trust and care, to its owner</em>]</span>: <span class="auth">(Mṣb:)</span> <em>he delivered it, gave it up,</em> or <em>surrendered it:</em> <span class="auth">(T:)</span> <em>he payed it,</em> or <em>discharged it;</em> <span class="auth">(Ṣ, Ḳ;)</span> namely, his debt, <span class="auth">(Ṣ,)</span> a bloodwit, a responsibility, and the like; <span class="auth">(Mṣb in art. <span class="ar">غرم</span>;)</span> <span class="add">[and hence,]</span> <span class="ar long">أَدَّى مَا عَلَيْهِ</span> <span class="add">[<em>he acquitted himself of that which was incumbent on him;</em> or <em>payed,</em> or <em>discharged, what he owed</em>]</span>: <span class="auth">(T:)</span> <em>he performed, fulfilled,</em> or <em>accomplished, it;</em> namely, <span class="add">[for instance,]</span> <span class="ar">الحَجَّ</span> <span class="add">[<em>the pilgrimage</em>]</span>; <span class="auth">(Mṣb in art. <span class="ar">قضى</span>;)</span> and in like manner, <span class="ar">المَنَاسِكَ</span> <span class="add">[<em>the religious rites and ceremonies of the pilgrimage</em>]</span>. <span class="auth">(Jel in ii. 196, and Mṣb ubi suprà.)</span> It is said in the Ḳur <span class="add">[xliv. 17]</span>, <span class="ar long">أَنْ أَدُّوا إلَىَّ عِبَادَ ٱللّٰهِ</span>, meaning <em>Deliver ye to me</em> <span class="add">[<em>the servants of God,</em>]</span> the children of Israel: or, as some say, the meaning is, <span class="ar long">أَدُّوا إِلَىَّ مَا أَمَرَكُمُ ٱللّٰهُ بِهِ يَا عِبَادَٱللّٰهِ</span> <span class="add">[<em>perform ye to me that which God hath commanded you</em> to do, <em>O servants of God</em>]</span>: or it may mean <em>listen ye,</em> or <em>give ye ear, to me;</em> as though the speaker said, <span class="ar long">أَدُّوا إِلَىَّ سَمْعَكُمْ</span>; the verb being used in this sense by the Arabs. <span class="auth">(T.)</span> And one says,<span class="arrow"><span class="ar long">تأَدَّيْتُ↓ لَهُ</span></span>, <span class="ar long">مِنْ حَقِّهِ</span>, <span class="auth">(Ḳ, TA,)</span> and <span class="ar">إلَيْهِ</span>, in the place of <span class="ar">لَهُ</span>, meaning <span class="ar">أَدَّيْتُهُ</span>; <span class="auth">(TA;)</span> i. e. <em>I payed him his due,</em> or <em>right.</em> <span class="auth">(Ḳ, TA.)</span> And a man says,<span class="arrow"><span class="ar long">مَا أَدْرِى كَيْفَ أَتَأَدَّى↓</span></span> <span class="add">[<em>I know not how to pay</em>]</span>. <span class="auth">(TA.)</span> One says also, <span class="ar long">أدّى عَنْهُ</span> <span class="add">[meaning <em>He payed,</em> or <em>made satisfaction, for him</em>]</span>: and <span class="ar long">أدّى عَنْهُ الخَرَاجَ</span> <span class="add">[<em>He payed for him,</em> or <em>in his stead, the land-tax</em>]</span>. <span class="auth">(Mgh in art. <span class="ar">جزأ</span>.)</span> <span class="add">[Hence,]</span> El-Akhnas says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَأَدَّيْتُ عَنِّى مَا ٱسْتَعَرتُ مِنَ الصِّبَا</span> *</div> 
						<div class="star">* <span class="ar long">وَلِلْمَالِ عِنْدِىِ اليَوْمَ رَاعٍ وَكَاسِبُ</span> *</div> 
					</blockquote>
					<p>i. e. <em>But I have put away from me</em> <span class="add">[<em>what I had borrowed,</em> or <em>assumed, of the folishness of youth, and amorous dalliance,</em>]</span> <em>and now I am</em> <span class="add">[or <em>there is at my abode</em>]</span> <em>a keeper and collector to the camels,</em> or <em>cattle,</em> or <em>property.</em> <span class="auth">(Ḥam p. 346.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادى</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ade_2_A2">
					<p><span class="add">[<span class="ar long">أَدَّى إِلى كَذَا</span> is a phrase often used as meaning <em>It brought, conducted, led,</em> or <em>conduced, to such a thing</em> or <em>state;</em> as, for instance, crime to punishment or to ignominy.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ade_4">
				<h3 class="entry">4. ⇒ <span class="ar">آدى</span></h3>
				<div class="sense" id="Ade_4_A1">
					<p><span class="ar">آدى</span>, intrans. and trans.: <a href="index.php?data=01_A/042_Adw">see art. <span class="ar">ادو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ade_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأدّى</span></h3>
				<div class="sense" id="Ade_5_A1">
					<p><span class="ar long">تأدّى إِلَيْهِ الخَبَرُ</span> <em>The information,</em> or <em>news, reached him.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادى</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ade_5_B1">
					<p><a href="#Ade_2">See also 2</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ade_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأدى</span></h3>
				<div class="sense" id="Ade_10_A1">
					<p><span class="ar long">استأداهُ مَالًا</span> <em>He desired,</em> or <em>sought, to obtain from him property,</em> or <em>sued,</em> or <em>prosecuted, him for it,</em> or <em>demanded it of him,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>and extracted it,</em> <span class="auth">(Ṣ,)</span> or <em>took it,</em> or <em>received it,</em> <span class="auth">(Ḳ,)</span> <em>from him.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادى</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ade_10_B1">
					<p><a href="index.php?data=01_A/042_Adw">See also art. <span class="ar">ادو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadaMCN">
				<h3 class="entry"><span class="ar">أَدَآءٌ</span></h3>
				<div class="sense" id="OadaMCN_A1">
					<p><span class="ar">أَدَآءٌ</span> a subst. from 2 <span class="add">[signifying The <em>act of making,</em> or <em>causing, to reach, arrive,</em> or <em>come</em> to the appointed person or place, &amp;c.; <em>of bringing, conveying,</em> or <em>delivering; of giving up,</em> or <em>surrendering; payment,</em> or <em>discharge,</em> of a debt, &amp;c.; the <em>act of acquitting oneself</em> of that which is incumbent on him; <em>performance, fulfilment,</em> or <em>accomplishment</em>]</span>. <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادى</span> - Entry: <span class="ar">أَدَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadaMCN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">هُوَ حَسَنُ الأَدَآءِ</span> <em>He has a good manner of pronouncing,</em> or <em>uttering, the letters.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادى</span> - Entry: <span class="ar">أَدَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OadaMCN_A3">
					<p><span class="ar">أَدَآءٌ</span> as a term of the law signifies The <em>performance</em> of an act of religious service <span class="add">[such as prayer, &amp;c.]</span> <em>at the appointed time:</em> opposed to <span class="ar">قَضَآءٌ</span>, performance at a time other than that which is appointed. <span class="auth">(Mṣb and TA in art. <span class="ar">قضى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OadieBN.1">
				<h3 class="entry"><span class="ar">أَدِىٌّ</span></h3>
				<div class="sense" id="OadieBN.1_A1">
					<p><span class="ar">أَدِىٌّ</span>: <a href="index.php?data=01_A/042_Adw">see art. <span class="ar">ادو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mdae.1">
				<h3 class="entry"><span class="ar">آدَى</span></h3>
				<div class="sense" id="Mdae.1_A1">
					<p><span class="ar">آدَى</span> <span class="add">[a noun denoting the comparative and superlative degrees, irregularly formed from the verb <span class="ar">أَدّى</span>; <a href="#Adae.1">like as the noun <span class="ar">آدَى</span></a> mentioned <a href="index.php?data=01_A/042_Adw">in art. <span class="ar">ادو</span></a> is irregularly formed from the verb <span class="ar">آدَى</span>]</span>. You say, <span class="ar long">هُوَ آدَى لِلأَمَانةِ</span> <span class="add">[<em>He is more,</em> or <em>better, disposed to deliver, give up,</em> or <em>surrender, the thing committed to his trust and care</em>]</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> <span class="ar">مِنْكَ</span> <span class="add">[<em>than thou</em>]</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">مِنْ غَيْرِهِ</span> <span class="add">[<em>than another than he</em>]</span>. <span class="auth">(M,* Ḳ.)</span> <span class="add">[Az says,]</span> the vulgar say, <span class="ar long">أَدَّى لِلْأَمَانَةِ</span>; but this is incorrect, and not allowable; and I have not known any one of the grammarians allow <span class="ar">آدَى</span>, because <span class="ar">أَفْعَل</span> denoting wonder <span class="add">[and the comparative and superlative degrees]</span> is not formed but from the triliteral <span class="add">[verb]</span>, and one does not say, <span class="ar">أَدَى</span> in the sense of <span class="ar">أَدَّى</span>: the proper phrase is <span class="ar long">أَحْسَنُ أَدَآءً</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادى</span> - Entry: <span class="ar">آدَى.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Mdae.1_B1">
					<p><a href="index.php?data=01_A/042_Adw">See also art. <span class="ar">ادو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWodK.1">
				<h3 class="entry"><span class="ar">مُؤْدٍ</span></h3>
				<div class="sense" id="muWodK.1_A1">
					<p><span class="ar">مُؤْدٍ</span>: <a href="index.php?data=01_A/042_Adw">see art. <span class="ar">ادو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0038.pdf" target="pdf">
							<span>Lanes Lexicon Page 38</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
