<article class="root" id="Root_AyD">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/176_AyX">ايش</a></span>
				<span class="ar">ايض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/178_Ayk">ايك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AyD_1">
				<h3 class="entry">1. ⇒ <span class="ar">أيض</span> ⇒ <span class="ar">آض</span></h3>
				<div class="sense" id="AyD_1_A1">
					<p><span class="ar">آضَ</span>, aor. <span class="ar">يَئِيضُ</span>, inf. n. <span class="ar">أَيْضٌ</span>, <em>i. q.</em> <span class="ar">عَادَ</span>; <span class="auth">(ISk, Ṣ, M, Mṣb,* Ḳ;)</span> as in the phrase <span class="ar long">آضَ إِلَى الشَّىْءِ</span> <span class="add">[<em>He returned to the thing,</em> i. e. <em>to the doing of the thing; he did the thing again,</em> or <em>a second time</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AyD_1_A2">
					<p>And <em>i. q.</em> <span class="ar">رَجَعَ</span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> as in the phrase <span class="ar long">آضَ إِلَى أَهْلِهِ</span> <span class="add">[<em>He returned to his family</em>]</span>. <span class="auth">(Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AyD_1_A3">
					<p>In the phrase<span class="arrow"><span class="ar long">فَعَلْتُ كَذَا أَيْضًا↓</span></span>, the last word is the inf. n. of <span class="ar">آضَ</span> in the sense of <span class="ar">عَادَ</span>, <span class="auth">(ISK, IDrd, Ṣ, M, Mṣb,*)</span> and in the sense of <span class="ar">رَجَعَ</span>: <span class="auth">(IDrd, M:)</span> and the meaning is, <span class="add">[<em>I did such a thing again,</em> or <em>a second time;</em>]</span> <em>I returned to the doing of such a thing:</em> <span class="auth">(IDrd, M:)</span> or <em>I did such a thing returning to what had preceded.</em> <span class="auth">(Mṣb, Ḳ.*)</span> <span class="add">[It also, and more commonly, signifies <em>I did such a thing also.</em>]</span> When one says, <span class="arrow"><span class="ar long">فَعَلْتُ ذٰلِكَ أَيْضًا↓</span></span> <span class="add">[<em>I did that again,</em>, &amp;c.]</span>, you say,<span class="arrow"><span class="ar long">قَدْ أَكْيَرْتَ مِنْ أَيْضٍ↓</span></span> <span class="add">[<em>Thou hast made much use of the expression</em> <span class="ar">أَيْضًا</span>]</span>, and<span class="arrow"><span class="ar long">دَعْنِى مِنْ أَيْضٍ↓</span></span> <span class="add">[<em>Let me alone and cease from using the expression</em> <span class="ar">أَيْضًا</span>]</span>. <span class="auth">(ISk, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ايض</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="AyD_1_A4">
					<p><span class="ar">أَيْضٌ</span> also signifies ‡ A thing's <em>becoming another,</em> or <em>a different, thing;</em> and <em>being changed from its state</em> or <em>condition</em> <span class="add">[<em>to another and a different state</em> or <em>condition</em>]</span>: <span class="auth">(Lth, Ḳ:*)</span> so says Kh. <span class="auth">(Ḥam p. 356.)</span> And <span class="ar long">آضَ كَذَا</span> ‡ <em>He,</em> or <em>it, became such a thing.</em> <span class="auth">(Lth, Ṣ, M,* Ḳ.)</span> You say, <span class="ar long">آضَ سَوَادُ شَعَرِهِ بَيَاضًا</span> <span class="auth">(A, TA)</span> ‡ <em>The blackness of his hair became whiteness.</em> <span class="auth">(TA.)</span> And Zuheyr says, speaking of a land which he traversed,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَطَعْتُ إِذَامَاالآلُ آضَ كَأَنَّهُ</span> *</div> 
						<div class="star">* <span class="ar long">سُيُوفٌ تُنَحَّى سَاعَةً ثُمَّ تَلْتَقِى</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>I traversed, when the mirage,</em> or <em>the mirage of the morning, became as though it were swords which were removed a while, then met</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayoDN">
				<h3 class="entry"><span class="ar">أَيْضٌ</span> / <span class="ar">أَيْضًا</span></h3>
				<div class="sense" id="OayoDN_A1">
					<p><span class="ar">أَيْضٌ</span> and <span class="ar">أَيْضًا</span>: <a href="#AyD_1">see above <span class="new">{1}</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0137.pdf" target="pdf">
							<span>Lanes Lexicon Page 137</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
