<article class="root" id="Root_Aws">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/159_Awz">اوز</a></span>
				<span class="ar">اوس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/161_Awf">اوف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="MsN">
				<h3 class="entry"><span class="ar">آسٌ</span> / <span class="ar">آسَةٌ</span></h3>
				<div class="sense" id="MsN_A1">
					<p><span class="ar">آسٌ</span> <span class="add">[<em>The myrtle;</em>]</span> <em>a certain kind of tree,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>well known,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>fragrant,</em> <span class="auth">(IDrd, M, Mṣb,)</span> <em>and evergreen, abundant in the land of the Arabs, growing in the plains and mountains, and increasing so as to become a great tree:</em> <span class="auth">(AḤn, M, TA:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">آسَةٌ</span>}</span></add>: <span class="auth">(AḤn, M, Mṣb, Ḳ:)</span> IDrd says, I think it an adventitious word, although used by the Arabs, and occurring in chaste poetry. <span class="auth">(M, TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0125.pdf" target="pdf">
							<span>Lanes Lexicon Page 125</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
