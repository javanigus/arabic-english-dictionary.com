<article class="root" id="Root_Alms">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/123_Alm">الم</a></span>
				<span class="ar">المس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/125_Alh">اله</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OalomaAsN">
				<h3 class="entry"><span class="ar">أَلْمَاسٌ</span> / <span class="ar">ٱلْمَاسُ</span></h3>
				<div class="sense" id="OalomaAsN_A1">
					<p><span class="ar">أَلْمَاسٌ</span>, or <span class="ar">ٱلْمَاسُ</span>: <a href="index.php?data=24_m/196_mws">see art. <span class="ar">موس</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0082.pdf" target="pdf">
							<span>Lanes Lexicon Page 82</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
