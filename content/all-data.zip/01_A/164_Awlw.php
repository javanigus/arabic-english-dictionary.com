<article class="root" id="Root_Awlw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/163_Awl">اول</a></span>
				<span class="ar">اولو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/165_Awle">اولى</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Ouwluw.1">
				<h3 class="entry"><span class="ar">أُولُو</span> / <span class="ar">أُولِى</span></h3>
				<div class="sense" id="Ouwluw.1_A1">
					<p><span class="ar">أُولُو</span>, in the gen. and accus. <span class="ar">أُولِى</span>: <a href="#Ouluw">see <span class="ar">أُلُو</span></a> <a href="index.php?data=01_A/126_Alw">in art. <span class="ar">الو</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0128.pdf" target="pdf">
							<span>Lanes Lexicon Page 128</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
