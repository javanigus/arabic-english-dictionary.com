<article class="root" id="Root_Ark">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/059_Arq">ارق</a></span>
				<span class="ar">ارك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/061_Arm">ارم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ark_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرك</span></h3>
				<div class="sense" id="Ark_1_A1">
					<p><span class="ar long">أَرَكَتِ الإِبِلُ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُكُ</span>}</span></add> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْرِكُ</span>}</span></add>, inf. n. <span class="ar">أُرُوكٌ</span>, <em>The camels fed upon the kind of tree called</em> <span class="ar">أَرَاك</span>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or <em>remained,</em> or <em>continued, among trees of that kind,</em> <span class="auth">(ISk, Ṣ, Ḳ,)</span> i. e., <em>what are termed</em> <span class="ar">حَمْض</span>, <span class="auth">(ISk, Ṣ,)</span> <em>eating them:</em> <span class="auth">(Ḳ:)</span> or <em>found,</em> or <em>lighted on, any trees whatever, and remained,</em> or <em>continued. among them:</em> <span class="auth">(Ḳ:)</span> or, accord. to Aṣ, <em>kept</em> in a place (<span class="ar">بِمَكَانٍ</span>), <em>not removing</em> therefrom: <span class="auth">(ISk, Ṣ:)</span> or <em>remained,</em> or <em>continued,</em> in a place <em>for the purpose of feeding upon the</em> <span class="ar">اراك</span>: and hence the signification next following, which is tropical. <span class="auth">(Er-Rághib.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ark_1_A2">
					<p><span class="ar long">أَرَكَ بِالمَكَانِ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> aor. and inf. n. as above, <span class="auth">(Mṣb, TA,)</span> ‡ <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>remained, continued,</em> or <em>abode, in the place,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>not quitting it;</em> <span class="auth">(TA;)</span> as also <span class="ar">أَرِكَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَكُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَرَكٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ark_1_A3">
					<p>And <span class="ar">أَرَكَ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَرْكٌ</span> and <span class="ar">أُرُوكٌ</span> <span class="auth">(TA,)</span> † <em>He persisted,</em> or <em>persevered,</em> syn. <span class="ar">لَجَّ</span>, <span class="auth">(Ḳ,)</span> i. e. <span class="ar">أَصَرَّ</span>, <span class="auth">(T, Ḳ,)</span> in an affair. <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Ark_1_A4">
					<p>And, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أُرُوِكٌ</span>, <span class="auth">(TA,)</span> † <em>He held back,</em> or <em>drew back,</em> (<span class="ar">تَأَخَّرَ</span>,) in an affair. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ark_1_B1">
					<p><span class="ar long">أَرَكَ الإِبِلَ</span>, <span class="auth">(Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُكُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">أَرْكٌ</span>, <span class="auth">(Ḳ,)</span> <em>He fed the camels,</em> or <em>made them to feed, upon the kind of the tree called</em> <span class="ar">أَرَاك</span>: or <em>made them to remain,</em> or <em>continue, among trees of that kind:</em> or <em>brought them to any trees whatever, and made them to remain,</em> or <em>continue, among them.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Ark_1_B2">
					<p><span class="ar long">أَرَكَ الأَمْرَفِى عُنُقِهِ</span>, <span class="auth">(L, Ḳ,)</span> inf. n. <span class="ar">أُرُوكٌ</span>, so in the L, <span class="auth">(TA,)</span> † <em>He compelled him,</em> or <em>constrained him, to do the thing,</em> or <em>affair;</em> or <em>made him to keep,</em> or <em>cleave, to it.</em> <span class="auth">(L, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Ark_1_C1">
					<p><span class="ar long">أَرَكَت الإِبِلُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْرَكُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">أَرَكٌ</span>; <span class="auth">(Ṣ;)</span> and <span class="ar">أَرَكَت</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُكُ</span>}</span></add>; and <span class="ar">أُرِكَت</span>; <span class="auth">(Ḳ;)</span> <em>The camels had a complaint,</em> or <em>suffered pain,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>of,</em> or <em>in, their bellies,</em> <span class="auth">(Ṣ,)</span> <em>from eating the</em> <span class="ar">أَرَاك</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ark_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّك</span></h3>
				<div class="sense" id="Ark_2_A1">
					<p><span class="ar">أَرَّكَهَا</span>, inf. n. <span class="ar">تَأْرِيكٌ</span>, <em>He concealed her</em> <span class="auth">(namely a woman, TA)</span> <em>by means of an</em> <span class="ar">أَرِيكَة</span>, q. v. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ark_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائترك</span></h3>
				<div class="sense" id="Ark_8_A1">
					<p><span class="ar">ائترك</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَرَكَ</span>]</span> <em>It</em> <span class="auth">(the kind of tree called <span class="ar">أَرَاك</span>)</span> <em>became firm, strong,</em> or <em>compact, and big:</em> <span class="auth">(O, Ḳ:)</span> or <em>attained to maturity:</em> <span class="auth">(Ḳ:)</span> or <em>became tangled,</em> or <em>luxuriant, and abundant.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IirokN">
				<h3 class="entry"><span class="ar">إِرْكٌ</span></h3>
				<div class="sense" id="IirokN_A1">
					<p><span class="ar">إِرْكٌ</span>: <a href="#OaraAkN">see <span class="ar">أَرَاكٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: <span class="ar">إِرْكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IirokN_A2">
					<p><span class="ar long">عُشْبٌ لَهُ إِرْكٌ</span> <em>Herbage in which the camels remain,</em> or <em>continue.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarikN">
				<h3 class="entry"><span class="ar">أَرِكٌ</span></h3>
				<div class="sense" id="OarikN_A1">
					<p><span class="ar long">أَرَاكٌ أَرِكٌ</span> <em>Abundant, and tangled,</em> or <em>luxuriant, trees of the kind called</em> <span class="ar">اراك</span>; <span class="auth">(Ḳ, TA; <span class="add">[in the CK <span class="ar">آرِكٌ</span>, but said in the TA to be like <span class="ar">كَتِفٌ</span>;]</span>)</span> as also<span class="arrow"><span class="ar">مُؤْتَرِكٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: <span class="ar">أَرِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OarikN_A2">
					<p><span class="ar long">أَرْضٌ أَرِكَةٌ</span> <em>Land abounding with the kind of trees called</em> <span class="ar">اراك</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: <span class="ar">أَرِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OarikN_A3">
					<p><span class="ar long">إِبِلٌ أَرِكَةٌ</span> and <span class="ar">أَرَاكَى</span>, <span class="add">[the latter being the pl.,]</span> <em>Camels having a complaint,</em> or <em>suffering pain,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>of,</em> or <em>in, their bellies,</em> <span class="auth">(Ṣ,)</span> <em>from eating the</em> <span class="ar">اراك</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaraAkN">
				<h3 class="entry"><span class="ar">أَرَاكٌ</span> / <span class="ar">أَرَاكَةٌ</span></h3>
				<div class="sense" id="OaraAkN_A1">
					<p><span class="ar">أَرَاكٌ</span> The <span class="add">[<em>kind of trees termed</em>]</span> <span class="ar">حَمْض</span>; <span class="auth">(AḤn, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِرْكٌ↓</span></span>: <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> and <span class="auth">(Ḳ)</span> <em>certain trees of the kind termed</em> <span class="ar">حَيْض</span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> <em>well known, bearing what resemble bunches of grapes,</em> <span class="auth">(T, TA,)</span> <em>and of which sticks for cleaning the teeth are made,</em> <span class="auth">(AḤn, Aboo-Ziyád, Mṣb, Ḳ,)</span> <em>that is, of its branches,</em> <span class="auth">(AḤn, Aboo-Ziyád, Mṣb,)</span> <em>and of its roots, which latter are more esteemed for this purpose:</em> <span class="auth">(Aboo-Ziyád:)</span> <em>it is the best of the trees of which the branches are used for this purpose, and the best of those upon which beasts feed with respect to the odour of the milk</em> <span class="add">[<em>yielded by those beasts</em>]</span>: <span class="auth">(AḤn:)</span> or <em>one of the large thorny trees, upon which camels feed: the milk of</em> <span class="add">[<em>the camels that feed upon</em>]</span> <em>it is the best of milk: and it is not allowable to prohibit the public from feeding their beasts upon it:</em> <span class="auth">(Mgh:)</span> or <em>a kind of tall, smooth,</em> or <em>soft, tree, abounding with leaves and branches, the wood of which is weak, and which has a fruit in bunches, or racemes, called</em> <span class="ar">بَرِير</span>, <em>one</em> <span class="add">[<em>bunch</em>]</span> <em>of which will fill the hand:</em> <span class="auth">(Mṣb:)</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَرَاكَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mṣb:)</span> pl. <span class="auth">(of the n. un., T)</span> <span class="ar">أُرُكٌ</span> <span class="auth">(T, Ḳ)</span> and <span class="ar">أَرَائِكُ</span>, <span class="auth">(IB, Ḳ,)</span> which is a form sometimes used, and is also pl. of the n. un. <span class="auth">(IB.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارك</span> - Entry: <span class="ar">أَرَاكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaraAkN_A2">
					<p><em>A piece of land</em> <span class="auth">(Ḳ, TA)</span> <em>in which are trees of the kind thus called.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OariykN">
				<h3 class="entry"><span class="ar">أَرِيكٌ</span></h3>
				<div class="sense" id="OariykN_A1">
					<p><span class="ar">أَرِيكٌ</span>: <a href="#OariykapN">see the end of the next paragraph</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OariykapN">
				<h3 class="entry"><span class="ar">أَرِيكَةٌ</span></h3>
				<div class="sense" id="OariykapN_A1">
					<p><span class="ar">أَرِيكَةٌ</span> <em>A raised couch</em> (<span class="ar">سَرِير</span>) <em>in a</em> <span class="ar">حَجَلَة</span>, <span class="auth">(Ḳ, and Jel in xviii. 30,)</span> <em>which is a tent,</em> or <em>pavilion,</em> or <em>chamber,</em> (<span class="ar">بيت</span>,) <em>adorned with cloths and curtains,</em> <span class="add">[or <em>a kind of curtained canopy</em> or <em>alcove</em> or <em>the like,</em>]</span> <em>for a bride;</em> <span class="auth">(Jel ubi suprà;)</span> <em>a raised couch</em> (<span class="ar">سرير</span>) <em>in a</em> <span class="ar">حَجَلَة</span>, <em>and having before it a curtain;</em> when alone, not thus called: <span class="auth">(TA:)</span> or <em>a bed,</em> or <em>thing spread upon the ground to sit or lie upon, in a</em> <span class="ar">حَجَلَة</span>: <span class="auth">(Zj, TA:)</span> or <em>a raised couch</em> (<span class="ar">سرير</span>), <em>absolutely, whether in a</em> <span class="ar">حجلة</span> or <em>not:</em> <span class="auth">(TA:)</span> or <span class="add">[in the CK “and”]</span> <em>anything upon which one reclines such as is termed</em> <span class="ar">سَرِير</span> <em>or</em> <span class="ar">منَصَّة</span> <em>or</em> <span class="ar">فِرَاش</span>: <span class="auth">(Ḳ, TA:)</span> or <span class="add">[in some copies of the Ḳ “and”]</span> <em>a raised couch</em> (<span class="ar">سرير</span>) <em>ornamentally furnished and decorated, in a</em> <span class="add">[<em>tent,</em> or <em>pavilion,</em> or <em>the like, such as is termed</em>]</span> <span class="ar">قُبَّة</span>, or <em>in a chamber,</em> or <em>an apartment,</em> <span class="ar">بَيْت</span>, <span class="add">[or by this may be meant here <em>a tent of any kind,</em> though I think that in this instance it more probably denotes <em>an inner apartment,</em> or <em>an alcove,</em>]</span> <em>which, when there is not in it a</em> <span class="ar">سرير</span>, <em>is termed</em> <span class="ar">حَجَلَة</span>: <span class="auth">(Ṣ, Ṣgh, Ḳ:)</span> <span class="pb" id="Page_0051"></span>accord. to Er-Rághib, so named because originally made of <span class="add">[the wood of]</span> the <span class="ar">أَرَاك</span>; or because it is a place of abode; from <span class="ar long">أَرَك بِالمَكَانِ</span> “be abode in the place:” <span class="auth">(TA:)</span> pl <span class="ar">أَرَائِكُ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="add">[coll. gen. n.]</span> <span class="arrow"><span class="ar">أَرِيكٌ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaraAkiyBapN">
				<h3 class="entry"><span class="ar">أَرَاكِيَّةٌ</span></h3>
				<div class="sense" id="OaraAkiyBapN_A1">
					<p><span class="ar long">إِبِلٌ أَرَاكِيَّةٌ</span>: <a href="#OarikapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OarikapN">
				<h3 class="entry"><span class="ar">أَرِكَةٌ</span></h3>
				<div class="sense" id="OarikapN_A1">
					<p><span class="ar long">إِبِلٌ أَرِكَةٌ</span> <em>Camels feeding upon the kind of tree called</em> <span class="ar">أَرَاك</span>; <span class="auth">(Ṣ, Mṣb;)</span> as also<span class="arrow"><span class="ar">أَرَاكِيَّةٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or <em>remaining,</em> or <em>continuing, among trees of that kind,</em> i. e., <em>what are termed</em> <span class="ar">حَمْض</span>: or <em>keeping</em> in a place, <em>not removing</em> therefrom: <span class="auth">(Ṣ:)</span> pl. <span class="ar">أَوَارِكُ</span>. <span class="auth">(Ṣ, Mṣb.)</span> Their milk is said to be the best of milk. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWorikuwna">
				<h3 class="entry"><span class="ar">مُؤْرِكُونَ</span></h3>
				<div class="sense" id="muWorikuwna_A1">
					<p><span class="ar long">قَوْمٌ مُؤْرِكُونَ</span> <em>A people,</em> or <em>company of men, alighting and abiding by trees of the kind called</em> <span class="ar">أَرَاك</span>, <span class="auth">(Ḳ,)</span> <em>feeding their camels upon those trees.</em> <span class="auth">(AḤn, Ḳ.*)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWotarikN">
				<h3 class="entry"><span class="ar">مُؤْتَرِكٌ</span></h3>
				<div class="sense" id="muWotarikN_A1">
					<p><span class="ar long">أَرَاكٌ مُؤْتَرِكٌ</span>: <a href="#OarikN">see <span class="ar">أَرِكٌ</span></a></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0050.pdf" target="pdf">
							<span>Lanes Lexicon Page 50</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0051.pdf" target="pdf">
							<span>Lanes Lexicon Page 51</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
