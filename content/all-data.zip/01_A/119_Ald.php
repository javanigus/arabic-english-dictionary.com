<article class="root" id="Root_Ald">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/118_Alt">الت</a></span>
				<span class="ar">الد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/120_Alf">الف</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="IilaAdapN">
				<h3 class="entry"><span class="ar">إِلَادَةٌ</span></h3>
				<div class="sense" id="IilaAdapN_A1">
					<p><ref target="#wld_1"><span class="ar">إِلَادَةٌ</span>, &amp;c. for <span class="ar">وِلَادَةٌ</span>, &amp;c.</ref>: <a href="index.php?data=27_w/212_wld">see art. <span class="ar">ولد</span></a></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0079.pdf" target="pdf">
							<span>Lanes Lexicon Page 79</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
