<article class="root" id="Root_Aw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/155_Ahl">اهل</a></span>
				<span class="ar">او</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/157_Awb">اوب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Oawo">
				<h3 class="entry"><span class="ar">أَوْ</span></h3>
				<div class="sense" id="Oawo_A1">
					<p><span class="ar">أَوْ</span> a conjunction, <span class="auth">(M, Mughnee, Ḳ,)</span> to which the later authors have ascribed meanings amounting to twelve: <span class="auth">(Mughnee:)</span> a particle which, when occurring in an enunciative phrase, <span class="add">[generally]</span> denotes doubt, and vagueness of meaning; and when occurring in an imperative or a prohibitive phrase, <span class="add">[generally]</span> denotes the giving of option, or choice, and the allowing a thing, or making it allowable. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oawo_A2">
					<p>First, <span class="auth">(Mughnee,)</span> it denotes doubt. <span class="auth">(T, Ṣ, M, Mṣb, Mughnee, Ḳ.)</span> So in the saying, <span class="ar long">رَأَيْتُ زَيْدًا أَوْ عَمْرًا</span> <span class="add">[<em>I saw Zeyd or ʼAmr</em>]</span>. <span class="auth">(T,* Ṣ, Mṣb.)</span> And <span class="ar long">جَآءَنِى رَجُلٌ أَوِ ٱمْرَأَةٌ</span> <span class="add">[<em>A man or a woman came to me</em>]</span>. <span class="auth">(Mbr, T.)</span> And <span class="ar long">لَبِئْنَا يَوْمًا أَوْ بَعْضَ يَوْمٍ</span> <span class="add">[in the Ḳur xviii. 18 and xxiii. 115, <em>We have remained a day or part of a day</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oawo_A3">
					<p>Secondly, <span class="auth">(Mughnee,)</span> it denotes vagueness of meaning. <span class="auth">(Ṣ, Mṣb, Mughnee, Ḳ.)</span> Ṣ <span class="add">[it may be used]</span> in the first of the exs. given above. <span class="auth">(Mṣb.)</span> And so in the saying, <span class="ar long">وَأَنَّا أَوْ إِيَّاكُمْ لَعَلَى هُدًى أَوْ فِى ضَلَالٍ مُبِينٍ</span> <span class="add">[<em>And verily we or ye are following a right direction or in manifest error</em>]</span>, <span class="auth">(Ṣ, Mughnee,)</span> in the Ḳur <span class="add">[xxxiv. 23]</span>; <span class="auth">(Ṣ;)</span> the ex. being in the former <span class="ar">او</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Oawo_A4">
					<p>Thirdly, <span class="auth">(Mughnee,)</span> it denotes the giving of option, or choice. <span class="auth">(T, Ṣ, M, Mughnee, Ḳ.)</span> So in the saying, <span class="ar long">كُلِ السَّمَكَ أَوِ ٱشْرَبِ اللَّبَنَ</span> <span class="add">[<em>Eat thou the fish, or drink thou the milk</em>]</span>; i. e. do not thou both of these actions; <span class="auth">(Mbr, T, Ṣ;)</span> but choose which of them thou wilt. <span class="auth">(Mbr, T.)</span> And <span class="ar long">تَزَوَّجْ هِنْدًا أَوْ أُخْتَهَا</span> <span class="add">[<em>Take thou as wife Hind or her sister</em>]</span>. <span class="auth">(Mughnee.)</span> And <span class="add">[in like manner]</span> it denotes the making choice. <span class="auth">(T.)</span> <span class="add">[So when you say, <span class="ar long">سَأَتَزَوَّجُ هِنْدًا أَوْ أُخْتَهَا</span>, meaning <em>I will take as wife Hind or her sister;</em> whichever of them I choose.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Oawo_A5">
					<p>Fourthly, <span class="auth">(Mughnee,)</span> it denotes the allowing a thing, or making it allowable. <span class="auth">(T, Ṣ, Mṣb, Mughnee, Ḳ.)</span> So in the saying, <span class="ar long">جَالِسِ حَسَنَ أَوِ ٱبْنَ سِيرِينَ</span> <span class="add">[<em>Sit thou with El-Ḥasan or Ibn-Seereen</em>]</span>. <span class="auth">(Mbr, T, Ṣ.)</span> And <span class="ar long">قُمْ أَوِ ٱقْعُدْ</span> <span class="add">[<em>Stand thou or sit</em>]</span>: and the person to whom this is said may do <span class="add">[one or]</span> both of the se actions. <span class="auth">(Mṣb. <span class="add">[And similar exs. are given in the Mughnee.]</span>)</span> But <span class="ar long">وَلَا تُطِعْ مِنْهُمْ آثِمًا أَو كَفُورًا</span> <span class="add">[in the Ḳur lxxvi. 24, <em>And obey not thou, of them, a sinner or a person very ungrateful to God,</em>]</span> means that thou shalt not obey either of such persons: <span class="auth">(Mbr, T, Mughnee:)</span> in which case <span class="ar">او</span> is more forcible than <span class="ar">وَ</span>; for when you say to a person, <span class="ar long">لَا تُطِعْ زَيْدًا وَعَمْرًا</span> <span class="add">[<em>Obey not thou Zeyd and ʼAmr</em>]</span>, he may obey one of them, since the command is that he shall not obey the two. <span class="auth">(Zj, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Oawo_A6">
					<p>Fifthly, <span class="auth">(Mughnee,)</span> it denotes unrestricted conjunction. <span class="auth">(Mughnee, Ḳ.)</span> So in the saying, in the Ḳur <span class="add">[iv. 46 and v. 9]</span>, <span class="ar long">أَوْ جَآءَ أَحَدٌ مِنْكُمْ مِنَ الغَائِطِ</span> <span class="add">[<em>And</em> if <em>any one of you cometh from the privy</em>]</span>; <span class="auth">(TA;)</span> <span class="add">[where, however, it may also be rendered <em>or,</em> though]</span> meaning <span class="ar">وَجَآءَ</span>; <span class="auth">(T, TA;)</span> the <span class="ar">و</span> in this explanation being what is termed a denotative of state. <span class="auth">(T.)</span> So, too, accord. to AZ, in the expression <span class="ar long">أَوْ يَزِيدُونَ</span> <span class="add">[<em>And they exceeded</em> that number]</span>, in the Ḳur <span class="add">[xxxvii. 147]</span>: but see below. <span class="auth">(TA.)</span> And so in the words, <span class="ar long">أَوْ أَنْ نَفْعَلَ فِى أَمْوَالِنَا مَا نَشَآءُ</span> <span class="add">[<em>And our doing, in respect of our possessions, what we will</em>]</span>, in the Ḳur <span class="add">[xi. 89]</span>. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Oawo_A7">
					<p>Sixthly, it denotes transition, <span class="auth">(Mughnee,)</span> used in the sense of <span class="add">[the adversative particle]</span> <span class="ar">بَلْ</span>, <span class="auth">(T, Ṣ, M, Mughnee, Ḳ,)</span> in a case of amplification of speech; <span class="auth">(Ṣ;)</span> accord. to Sb, on two conditions; that it shall be preceded by a negation or a prohibition, and that the agent shall be mentioned a second time; as in <span class="ar long">مَا قَامَ زَيْدٌ أَوْ مَا قَامَ عَمْرٌو</span> <span class="add">[<em>Zeyd did not stand: nay, rather ʼAmr did not stand</em>]</span>; and <span class="ar long">لَا يَقْمٌ زَيدٌ أَوْ لَا يَقُمْ عَمْرُو</span> <span class="add">[<em>Let not Zeyd stand: nay, rather let not ʼAmr stand</em>]</span>. <span class="auth">(Mughnee.)</span> Accord. to Fr, <span class="auth">(Th, M, Mughnee,)</span> it has this meaning in <span class="ar long">أَوْ يَزِيدُونَ</span> <span class="add">[<em>Nay, rather they exceeded</em> that number]</span>, <span class="auth">(Th, Ṣ, M, Mughnee,)</span> in the Ḳur <span class="add">[xxxvii. 147, cited above]</span>: <span class="auth">(Ṣ:)</span> or the meaning is, <em>or they would exceed</em> <span class="add">[that number]</span> in your estimation: or these words with those preceding them in the same verse mean, we sent him to a multitude of whom, if ye saw them, ye would say, They are a hundred thousand, <em>or they exceed</em> <span class="add">[that number]</span>; <span class="auth">(M, Mughnee;*)</span> so that it denotes doubt on the part of men, not of God, for He is not subject to doubt: <span class="auth">(M:)</span> or we sent him to a hundred thousand in the estimation of men, <em>or they exceeded</em> <span class="add">[that number]</span> in the estimation of men; for God does not doubt: <span class="auth">(Ṣ:)</span> or <span class="ar">او</span> is here used to denote vagueness of meaning: <span class="auth">(IB, Mughnee:)</span> or, it is said, to denote that a person might choose between saying, “they are a hundred thousand,“and saying, “they are more;“but this may not be when one of the two things is the fact: or, accord. to some of the Koofees, it has the meaning of <span class="ar">وَ</span>: and each of these meanings, except the last, has been assigned to <span class="ar">او</span> as occurring in the Ḳur ii. 69 and xvi. 79. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Oawo_A8">
					<p>Seventhly, it denotes division; <span class="auth">(Mughnee, Ḳ;*)</span> as in the saying, <span class="ar long">الكَلِمَةُ ٱسْمٌ أَوْ فِعْلٌ أَوْ حَرْفٌ</span> <span class="add">[<em>The word is a noun or a verb or a particle</em>]</span>: so said Ibn-Málik: or, as he afterwards said, in preference, it denotes separation (<span class="ar">التَّفرِيق</span>) divested of the attribute of denoting doubt and vagueness of meaning and the giving of option or choice; adducing as one of his exs. of this meaning the saying, <span class="ar long">وَقَالُوا كُونُوا هُودًا أَوْ نَصَارَى</span> <span class="add">[in the Ḳur ii. 129, <em>And they said, “Be ye Jews” or “Christians”</em>]</span>; because the use of <span class="ar">و</span> in division is better; as when you say, <span class="ar long">الكَلِمَةُ ٱسْمٌ وَفِعْلٌ وَحَرْفٌ</span>: or it denotes, accord. to some, distinction (<span class="ar">التَّفْصِيل</span>); and the meaning of the ex. last cited, say they, is, <em>and the Jews said, “Be ye Jews,” and the Christians said, “Be ye Christians.”</em> <span class="auth">(Mughnee.)</span> It is <span class="add">[said to be]</span> used in this last sense (<a href="#AltfDyl">that of <span class="ar">التفضيل</span></a>) in the saying, <span class="ar long">كُنْتُ آكُلُ اللَّحْمَ أَوِ العَسَلَ</span> <span class="add">[<em>I used to eat flesh-meat or honey</em>]</span>; i. e. <em>I used to eat flesh-meat one time and honey another time:</em> and so in the Ḳur vii. 3 and x. 13.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Oawo_A9">
					<p>Eighthly, <span class="auth">(Mughnee,)</span> it is used in the sense of the exceptive <span class="ar">إِلَّا</span>, <span class="auth">(Mughnee, Ḳ,)</span> or <span class="ar long">إِلَّا أَنْ</span> <span class="auth">(M;)</span> and in this case the aor. after it is mansoob, because of <span class="ar">أَنْ</span> suppressed. <span class="auth">(Mughnee, Ḳ.)</span> So in the saying, <span class="ar long">لَأَقْتُلَنَّهُ أَوْ يُسْلِمَ</span> <span class="add">[<em>I will assuredly slay him or he shall become a Muslim;</em> i. e., <em>unless he become a Muslim</em>]</span>. <span class="auth">(Mughnee.<span class="add">[And a similar ex. is given in the M.]</span>)</span> So, too, in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَكُنْتُ إِذَا غَمَزْتُ قَنَاةَ قَوْمٍ</span> *</div> 
						<div class="star">* <span class="ar long">كَسَرْتُ كُعُوبَهَا أَوْ تَسْتَقِيمَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And I used, when I pinched and pressed the spear of a people, to break its knots,</em> or <em>joints,</em> or <em>its internodal portions,</em> <span class="auth">(the shaft being a cane,)</span> <em>or,</em> i. e. <em>unless, it became straight</em>]</span>: <span class="auth">(Mughnee, Ḳ:*)</span> a prov., of which the author is Ziyád El-Aajam; meaning, when a people behaved with hardness to me, I endeavoured to soften them: <span class="auth">(TA in art. <span class="ar">غمز</span>:)</span> thus related by Sb, the verb ending it being rendered mansoob by <span class="ar">او</span>; and thus he heard it from some one or more of the Arabs; but in the original verses, which are but three, it is <span class="ar">تَسْتَقِيمُ</span>, with refa. <span class="auth">(IB and TA in art. <span class="ar">غمز</span>.)</span> <span class="add">[And similar to these above are the sayings,]</span> <span class="ar long">إنَّهُ لِفُلَانٍ أَوْمَا بِنَجْدٍ قَرظَهُ</span> <span class="add">[<em>Verily it belongs to such a one or there is not,</em> i. e. <em>unless there be not, in Nejd, a</em> <span class="ar">قَرَظَة</span> (<a href="index.php?data=21_q/066_qrZ">see art. <span class="ar">قرظ</span></a>)]</span>: <span class="pb" id="Page_0123"></span>and <span class="ar long">لَآتِيَنَّكَ أَوْ مَا بِنَجْدٍ قَرَظَةٌ</span> <span class="add">[<em>I will assuredly come to thee or there is not,</em> i. e. <em>unless there be not, in Nejd, a</em> <span class="ar">قَرَظَة</span>]</span>; meaning <em>I will assuredly come to thee, in truth.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A10</span>
				</div>
				<div class="sense" id="Oawo_A10">
					<p>Ninthly, <span class="auth">(Mughnee,)</span> it is used in the sense of <span class="ar">إِلَى</span>, <span class="auth">(Mughnee, Ḳ,)</span> or <span class="ar long">إِلَى أَنْ</span>; <span class="auth">(Ṣ;)</span> in which case also the aor. after it is mansoob, because of <span class="ar">أَنْ</span> suppressed: <span class="auth">(Mughnee:)</span> and in the sense of <span class="ar">حَتَّى</span> <span class="add">[which is also syn. with <span class="ar">إِتَى</span>]</span>. <span class="auth">(Fr, T, M, Ḳ.)</span> So in the saying, <span class="ar long">لَأَضْرِبَنَّهُ أَوْ يَتُوبَ</span> <span class="add">[<em>I will assuredly beat him until he repent</em>]</span>. <span class="auth">(Ṣ. <span class="add">[And similar exs. of <span class="ar">او</span> as explained by <span class="ar">حَتَّى</span> are given in the T (from Fr)</span> and in the M and in the Mughnee.]</span>) And so in the saying of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَأَسْتَسْهِلَنَّ الصَّعْبَ أَوْ أُدْرِكَ المُنَى</span> *</div> 
						<div class="star">* <span class="ar long">فَمَا ٱنْقَادَتِ الآمَالُ إِلَّا لِصَابِرِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>I will assuredly deem easy what is difficult until I attain the objects of wish; for hopes become not easy of accomplishment save to one who is patient</em>]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A11</span>
				</div>
				<div class="sense" id="Oawo_A11">
					<p>Tenthly, some say, <span class="auth">(Mughnee,)</span> it denotes nearness <span class="add">[of one event or thing to another]</span>; as in the saying, <span class="ar long">مَا أَدْرِى أَسَلَّمَ أَوْ وَدَّعَ</span> <span class="add">[<em>I know not whether he saluted or bade farewell</em>]</span>: <span class="auth">(Mughnee, Ḳ: <span class="add">[but in the CK this ex. is misplaced:]</span>)</span> this, however, is manifestly wrong; <span class="ar">او</span> being here used to denote doubt, and the denoting of nearness being only inferred from the fact of the saluting being confounded in the mind with the bidding farewell, since this is impossible or improbable when the two times are far apart. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A12</span>
				</div>
				<div class="sense" id="Oawo_A12">
					<p>Eleventhly, <span class="auth">(Mughnee,)</span> it occurs as a conditional, <span class="auth">(T, Mughnee, Ḳ,)</span> accord. to Ks alone; <span class="auth">(T;)</span> or rather as a conjunctive and conditional; <span class="ar">وَإِنْ</span> being meant to be understood in its place; though in truth the verb that precedes it indicates that the conditional particle <span class="add">[<span class="ar">إِنْ</span>]</span> is meant to be understood <span class="add">[before that verb]</span>, and <span class="ar">او</span> retains its proper character, but forms part of that which has a conditional meaning because conjoined with a preceding conditional phrase. <span class="auth">(Mughnee.)</span> So in the saying, <span class="ar long">لَأَضْرِبَنَّهُ عَاشَ أَوْ مَاتَ</span>, <span class="auth">(Mughnee, Ḳ,)</span> i. e., <span class="ar long">إِنْ عَاِض بَعْدَ الضَّرْبِ وَإِنْ مَاتَ</span> <span class="add">[<em>I will assuredly beat him if he live</em> <span class="auth">(after the beating)</span> <em>or if he die</em>]</span>: so says Ibn-Esh-Shejeree. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A13</span>
				</div>
				<div class="sense" id="Oawo_A13">
					<p>Twelfthly, accord. to Ibn-Esh-Shejeree, on the authority of some one or more of the Koofees, <span class="auth">(Mughnee,)</span> it denotes division into parts, or portions; as in the saying <span class="add">[in the Ḳur ii. 129, before cited,]</span> <span class="ar long">وَقَالُوا كُونُوا هُودًا أَو نَصَارَى</span>, <span class="auth">(Mughnee, Ḳ,)</span> i. e. <em>And they said, “Be ye, some of you, Jews, and, some of you, Christians:</em>” <span class="auth">(TA:)</span> but <span class="add">[IHsh says,]</span> it appears to me that the meaning here <a href="#AltBafoSiyl">is that of <span class="ar">التَّفْصِيل</span></a> mentioned before. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A14</span>
				</div>
				<div class="sense" id="Oawo_A14">
					<p><span class="add">[In the Ḳ it is said to occur also in the sense of <span class="ar">أَنْ</span>: but this is evidently a mistake, app. originating in one of the two principal sources of the Ḳ, namely, the M, in which the same is said, but is exemplified by a phrase in which it is explained by <span class="ar long">إِلَّا أَنْ</span>, the eighth of the meanings of <span class="ar">أَوْ</span> mentioned above.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوْ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A15</span>
				</div>
				<div class="sense" id="Oawo_A15">
					<p><a href="#OawBN">See also <span class="ar">أَوٌّ</span> below</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oawa">
				<h3 class="entry"><span class="ar">أَوَ</span></h3>
				<div class="sense" id="Oawa_A1">
					<p><span class="ar">أَوَ</span> in <span class="ar long">أَوَ لَمْ يَرَوْا</span>, &amp;c. is <span class="add">[the conjunction]</span> <span class="ar">وَ</span> with the interrogative <span class="ar">ا</span> prefixed to it. <span class="auth">(Fr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawBi">
				<h3 class="entry"><span class="ar">أَوِّ</span> / <span class="ar">أَوَّ</span></h3>
				<div class="sense" id="OawBi_A1">
					<p><span class="ar long">أَوِّ مِنْ كَذَا</span> <span class="auth">(T, M)</span> and <span class="ar">أَوَّ</span> <span class="auth">(M)</span> <span class="add">[<em>Alas, on account of,</em> or <em>for, such a thing!</em>]</span> an expression denoting complaint of distress, or of anxiety, or of grief or sorrow; <span class="auth">(T;)</span> or an expression of grief or sorrow; <span class="auth">(M;)</span> like<span class="arrow"><span class="ar">آوِ↓</span></span> and<span class="arrow"><span class="ar">آوٍ↓</span></span> and<span class="arrow"><span class="ar">أَوَتَاه↓</span></span> <span class="auth">(Ḳ and TA in art. <span class="ar">اوه</span>,)</span> or<span class="arrow"><span class="ar">أَوَتَاهُ↓</span></span> <span class="auth">(CK in that art.,)</span> or<span class="arrow"><span class="ar">أَوَّتَاه↓</span></span>, or<span class="arrow"><span class="ar">آوَّتَاه↓</span></span>, <span class="auth">(Ṣ in that art., <span class="add">[the <span class="ar">ه</span> in one copy of which is marked as quiescent,]</span>)</span> and like <span class="ar">آهِ</span> and <span class="ar">أَوْهِ</span>, &amp;c. <span class="auth">(Ṣ and Mṣb and Ḳ <a href="index.php?data=01_A/168_Awh">in art. <span class="ar">اوه</span></a>: <a href="#Ahi">see <span class="ar">آهِ</span></a> in that art.)</span> AZ says, one says, <span class="ar long">أَوْهِ عَلَى زَيْدٍ</span> <span class="add">[meaning <em>Alas, for Zeyd!</em>]</span> with kesr to the <span class="ar">ه</span>, and<span class="arrow"><span class="ar long">أَوَّتَا↓ عَلَيْكَ</span></span> <span class="add">[thus without <span class="ar">ه</span>, meaning <em>Alas, for thee!</em>]</span> with <span class="ar">ت</span>; an expression of regret for a thing, whether of great or mean account. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawBN">
				<h3 class="entry"><span class="ar">أَوٌّ</span></h3>
				<div class="sense" id="OawBN_A1">
					<p><span class="ar">أَوٌّ</span> The <em>word</em> <span class="arrow"><span class="ar">أَوْ↓</span></span> <em>when made a noun.</em> <span class="auth">(T, Ḳ.)</span> So say the grammarians. <span class="auth">(T.)</span> You say, <span class="ar long">هٰذهِ أَوٌّحَسَنَةٌ</span> <span class="add">[<em>This is a good</em> <span class="ar">أَوْ</span>]</span>. <span class="auth">(T.)</span> And to one who uses the phrase <span class="ar long">أَفْعَلُ كَذَا أَوْ كَذَا</span>, <span class="auth">(T,)</span> you say, <span class="ar long">دَعِ الأَوَّجَانِبًا</span> <span class="add">[<em>Let thou,</em> or <em>leave thou, the word</em> <span class="ar">أَوْ</span> <em>alone</em>]</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OawBapN">
				<h3 class="entry"><span class="ar">أَوَّةٌ</span></h3>
				<div class="sense" id="OawBapN_A1">
					<p><span class="ar">أَوَّةٌ</span> <span class="add">[<em>A moaning</em> (<a href="#AhapN">see its syn. <span class="ar">آهَةٌ</span></a> <a href="index.php?data=01_A/168_Awh">in art. <span class="ar">اوه</span></a>)]</span> is said by some to be of the measure <span class="ar">فَعْلَةٌ</span>, in which the <span class="ar">ة</span> is the sign of the fem. gender; for they say, <span class="ar long">سَمِعْتُ أَوَّتَكَ</span> <span class="add">[<em>I heard thy moaning</em>]</span>, making it <span class="ar">ت</span>: and so says Lth; <span class="ar">أَوَّةٌ</span> is after the manner of <span class="ar">فَعْلَةٌ</span>: <span class="auth">(T:)</span> you say, <span class="ar long">أَوَّةً لَكَ</span> <span class="add">[May God cause <em>moaning to thee!</em>]</span>, <span class="auth">(Lth, T, and Ṣ in art. <span class="ar">اوه</span>,)</span> and <span class="ar long">آهَةً لَكَ</span>: <span class="add">[but accord. to J, the former of these is cognate with the latter; for he says that]</span> the former is with the <span class="ar">ه</span> suppressed, and with teshdeed to the <span class="ar">و</span>. <span class="auth">(Ṣ in art. <span class="ar">اوه</span>, where <a href="#AhapN">see <span class="ar">آهَةٌ</span></a>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">او</span> - Entry: <span class="ar">أَوَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OawBapN_A2">
					<p><span class="ar long">أَوَّتَا عَلَيكَ</span>; and <span class="ar">أَوَّتَاه</span>, or <span class="ar">آوَّتَاه</span>, or <span class="ar">أَوَتَاه</span>, or <span class="ar">أَوَتَاهُ</span>: <a href="#OawBi">see <span class="ar long">أَوِّ مِنْ كَذَا</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuwBapN">
				<h3 class="entry"><span class="ar">أُوَّةٌ</span></h3>
				<div class="sense" id="OuwBapN_A1">
					<p><span class="ar">أُوَّةٌ</span> <em>i. q.</em> <span class="ar">دَاهِيَةٌ</span> <span class="add">[<em>A calamity, a misfortune,</em>, &amp;c.: or, perhaps, <em>very cunning,</em> applied to a man]</span>: pl. <span class="ar">أُوَوْ</span>; <span class="auth">(AA, T, Ḳ, TA; <span class="add">[but in copies of the Ḳ, written <span class="ar">أُوَوٌ</span>;]</span>)</span> which is one of the strangest of the things transmitted from the Arabs; the regular form being <span class="ar">أُوَّى</span>, like <span class="ar">قُوَّى</span>, <a href="#quwapN">pl. of <span class="ar">قُوَةٌ</span></a>; but the word occurring as above in the saying of the Arabs, <span class="ar long">مَا هُوَ إِلَّا أُوَّةٌ مِنَ الأُوَوْ</span> <span class="add">[<em>It is no other thing than a calamity of the calamities:</em> or, perhaps, <em>he is no other than a very cunning man of the very cunning</em>]</span>. <span class="auth">(AA, T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Mwi">
				<h3 class="entry"><span class="ar">آوِ</span> / <span class="ar">آوٍ</span></h3>
				<div class="sense" id="Mwi_A1">
					<p><span class="ar">آوِ</span> and <span class="ar">آوٍ</span>: <a href="#OawBi">see <span class="ar">أَوِّ</span></a>: <a href="#Ahi">and see <span class="ar">آهِ</span></a> <a href="index.php?data=01_A/168_Awh">in art. <span class="ar">اوه</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OawawieBN">
				<h3 class="entry"><span class="ar">أَوَوِىٌّ</span> / <span class="ar">آوِىٌّ</span></h3>
				<div class="sense" id="OawawieBN_A1">
					<p><span class="ar">أَوَوِىٌّ</span> and <span class="ar">آوِىٌّ</span>: <a href="#AyapN">see <span class="ar">آيَةٌ</span></a>, <a href="index.php?data=01_A/170_Ae">in art. <span class="ar">اى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MwBataAh">
				<h3 class="entry"><span class="ar">آوَّتَاه</span></h3>
				<div class="sense" id="MwBataAh_A1">
					<p><span class="ar">آوَّتَاه</span>: <a href="#OawBi">see <span class="ar">أَوِّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0122.pdf" target="pdf">
							<span>Lanes Lexicon Page 122</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0123.pdf" target="pdf">
							<span>Lanes Lexicon Page 123</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
