<article class="root" id="Root_Axw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/036_Axr">اخر</a></span>
				<span class="ar">اخو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/038_Ad">اد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Axw_1">
				<h3 class="entry">1. ⇒ <span class="ar">أخو</span> ⇒ <span class="ar">أخى</span></h3>
				<div class="sense" id="Axw_1_A1">
					<p><span class="ar">أَخَوْتَ</span>, <span class="add">[third pers. <span class="ar">أَخَا</span>,]</span> <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">تَأْخُو</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">أُخُوَّةٌ</span>; <span class="auth">(Ṣ, Ḳ, &amp;c.;)</span> and<span class="arrow"><span class="ar">آخَيْتَ↓</span></span>, <span class="auth">(Ḳ, TA,)</span> <span class="add">[in the CK <span class="ar">اَخَيْتُ</span>, which is wrong in respect of the pers., and otherwise, for it is correctly]</span> with medd, <span class="auth">(TA,)</span> inf. n. <span class="ar">إِخَآءٌ</span> and <span class="ar">مُؤَاخَاةٌ</span>; <span class="auth">(Lth;)</span> and<span class="arrow"><span class="ar">تَأَخَّيْتَ↓</span></span>; <span class="auth">(Ḳ;)</span> <em>Thou becamest a brother</em> <span class="add">[in the proper sense of this word, and also as meaning a <em>friend,</em> or <em>companion,</em> or <em>the like</em>]</span>. <span class="auth">(Ṣ,* Ḳ,* TA.)</span> <span class="arrow"><span class="ar">أُخُوَّةٌ↓</span></span> is also <span class="add">[used as]</span> a simple subst., <span class="auth">(TA,)</span> signifying <em>Brotherhood; fraternity;</em> the <em>relation of brother;</em> as also↓<span class="ar">إِخَآءٌ</span> and <span class="ar">مُؤَاخاةٌ</span>; and<span class="arrow"><span class="ar">تَأَخٍ↓</span></span>: <span class="auth">(Lth, TA:)</span> and the <em>relation of sister.</em> <span class="auth">(Ṣ.)</span> You say, <span class="ar long">بَيْنِى وَبَيْنَهُ أُخُوَّةٌ</span> and<span class="arrow"><span class="ar">إِخَآءٌ↓</span></span> <span class="add">[&amp;c., meaning]</span> <em>Between me and him is brotherhood.</em> <span class="auth">(JK, TA.)</span> And<span class="arrow"><span class="ar long">بَيْنَ السَّمَاحَةِ وَالحَمَاسَةِ تَأَخٍ↓</span></span> † <span class="add">[<em>Between liberality and courage is a relation like that of brothers</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar">خُوَّةٌ</span> <a href="#OuxuwBapN">is a dial. var. of <span class="ar">أُخُوَّةٌ</span></a>, occurring in a trad. <span class="auth">(IAth, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Axw_1_B1">
					<p><span class="add">[It is also trans.]</span> You say, <span class="ar long">أَخَوْتُ عَشَرَةً</span> <em>I was, or became, a brother to ten.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axw_2">
				<h3 class="entry">2. ⇒ <span class="ar">أخّو</span> ⇒ <span class="ar">أخّى</span></h3>
				<div class="sense" id="Axw_2_A1">
					<p><span class="ar long">أَخَّيْتُ لِلدَّابَّةِ</span>, <span class="auth">(Ṣ, Ḳ,)</span> or <span class="ar">الدَّابَّةَ</span>, <span class="auth">(Mṣb, <span class="add">[so accord. to a copy of that work, but probably this is a mistranscription,]</span>)</span> inf. n. <span class="ar">تَأْخِيَةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <em>I made an</em> <span class="ar">آخِيَّة</span> <span class="add">[q. v.]</span> <em>for the beast,</em> <span class="auth">(Mṣb, Ḳ,)</span> <em>and tied the beast therewith;</em> <span class="auth">(Mṣb;)</span> <span class="pb" id="Page_0033"></span><span class="add">[and so, app.,<span class="arrow"><span class="ar">آخَيْتُ↓</span></span> <span class="auth">(which, if correct, is probably of the measure <span class="ar">أَفْعَلْتُ</span>)</span>; for it is related that]</span> an Arab of the desert said to another,<span class="arrow"><span class="ar long">آخِ↓ لِى آخِيَّةً أَرْبِطُ إَلَيْهَا مُهْرِى</span></span> <span class="add">[<em>Make thou for me an</em> <span class="ar">آخيّة</span> <em>to which I shall tie my colt</em>]</span>. <span class="auth">(TA.)</span> And you say,<span class="arrow"><span class="ar long">آخِى↓ فُلَانٌ فِى فُلَانٍ آخِيَّةً فَكَفَرَهَا</span></span> † <em>Such a one did a benefit to such a one, and he was ungrateful for it.</em> <span class="auth">(TA.)</span> <span class="add">[But perhaps <span class="ar">آخِ</span> and <span class="ar">آخَى</span> in these two exs. are mistranscriptions for <span class="ar">أَخِّ</span> and <span class="ar">أَخَّى</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axw_3">
				<h3 class="entry">3. ⇒ <span class="ar">آخو</span> ⇒ <span class="ar">آخى</span></h3>
				<div class="sense" id="Axw_3_A1">
					<p><span class="ar">آخاهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> vulgarly <span class="ar">وَاخَاهُ</span>, <span class="auth">(Ṣ,)</span> or the latter is a dial. var. of weak authority, <span class="auth">(Ḳ,* TA,)</span> said by some to be of the dial. of Teiyi, <span class="auth">(TA,)</span> inf. n. <span class="ar">مُؤَاخَاةٌ</span> and <span class="ar">إِخآءٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">وِخَآءٌ</span>, <span class="auth">(Ḳ)</span> and <span class="add">[quasi-inf. n.]</span> <span class="arrow"><span class="ar">إِخَاوَةٌ↓</span></span> <span class="auth">(Fr, Ḳ)</span> and <span class="ar">وِخَاوَةٌ</span>, <span class="auth">(CK,)</span> <em>He fraternized with him; acted with him in a brotherly manner:</em> <span class="auth">(Ṣ,* Ḳ,* PṢ, TḲ:)</span> AʼObeyd mentions, on the authority of Yz, <span class="ar">آخَيْتُ</span> and <span class="ar">وَاخَيْتُ</span>, and <span class="ar">آسَيْتُ</span> and <span class="ar">وَاسَيْتُ</span>, and <span class="ar">آكَلْتُ</span> and <span class="ar">وَاكَلْتُ</span>: the pret. is said to be thus assimilated to <span class="add">[a form of]</span> the fut.; for they used <span class="add">[sometimes]</span> to say, <span class="ar">يُوَاخِى</span>, changing the hemzeh into <span class="ar">و</span>. <span class="auth">(IB, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Axw_3_A2">
					<p>It is said in a trad., <span class="ar long">آخَى بَيْنَ المُهَاجِرِينَ وَالأَنْصَارِ</span>, meaning <em>He united the emigrants</em> <span class="add">[to El-Medeeneh]</span> <em>with the assistants</em> <span class="add">[previously dwel-ling there]</span> <em>by the brotherhood of El-Islám and of the faith.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">آخَيْتُ بَيْنَ الشَّيْئَنْنِ</span> <span class="add">[<em>I united the two things as fellows, or pairs</em>]</span>; and sometimes one says, <span class="ar">وَاخَيْتُ</span>, like as one says, <span class="ar">وَاسَيْتُ</span>, for <span class="ar">آسَيْتُ</span>; mentioned by ISk. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Axw_3_A3">
					<p><a href="#Axw_1">See also 1</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Axw_4">
				<h3 class="entry">4. ⇒ <span class="ar">آخى</span></h3>
				<div class="sense" id="Axw_4_A1">
					<p><a href="#Axw_2">see 2</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأخّو</span> ⇒ <span class="ar">تأخّى</span></h3>
				<div class="sense" id="Axw_5_A1">
					<p><span class="ar">تَأَخَّيْتَ</span>, and the inf.n. <span class="ar">تَأَخٍ</span>: <a href="#Axw_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Axw_5_B1">
					<p><span class="ar long">تَأَخَّيْتُ أَخًا</span> <em>I adopted a brother:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <span class="add">[<span class="ar">تَأَخَّيْتُهُ</span> signifies]</span> <em>I called him brother.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Axw_5_B2">
					<p><span class="ar long">تَأَخَّيْتُ الشَّىْءَ</span>, <span class="auth">(Ṣ, Ḳ, TA,)</span> or <span class="ar">بِالشَّىْ</span>, <span class="auth">(Mṣb,)</span> <em>I sought, endeavoured after, pursued, or endeavoured to reach or attain or obtain, the thing;</em> <span class="auth">(Ṣ, Mṣb, Ḳ, TA;)</span> <em>as the brother does the brother;</em> and in the same manner the verb is used with a man for its object: but <span class="ar">تَوَخَّيْتُ</span>, in the same sense, is more common. <span class="auth">(TA.)</span> You say, <span class="ar long">تَأَخَّيْتُ مَحَبَّتَكَ</span> <em>I sought,</em>, &amp;c., <em>thy love,</em> or <em>affection.</em> <span class="auth">(TA in art. <span class="ar">وخى</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Axw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآخو</span> ⇒ <span class="ar">تآخى</span></h3>
				<div class="sense" id="Axw_6_A1">
					<p><span class="ar">تَآخَيَا</span> <em>They became brothers, or friends or companions or the like, to each other.</em> <span class="auth">(Ṣ,* TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxN.1">
				<h3 class="entry"><span class="ar">أَخٌ</span></h3>
				<div class="sense" id="OaxN.1_A1">
					<p><span class="ar">أَخٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> originally <span class="ar">أَخَوٌ</span>, <span class="auth">(Kh, Ṣ, Mṣb,)</span> as is shown by the first of its dual forms mentioned below, and by its having a pl. like <span class="ar">آبَآءٍ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar">أَخٌّ</span>, <span class="auth">(Ḳ,)</span> with the second letter doubled to compensate for the <span class="ar">و</span> suppressed, as is the case in <span class="ar">أَبٌّ</span>, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">أَخًا↓</span></span>, <span class="add">[like <span class="ar">أَبًا</span>,]</span> and<span class="arrow"><span class="ar">أَخُو↓</span></span>, <span class="auth">(IAạr, Ḳ, TA,<span class="add">[the last, with the article prefixed to it, erroneously written in the CK <span class="ar">الاُخُوٌّ</span>,]</span>)</span> and<span class="arrow"><span class="ar">أَخْوٌ↓</span></span>, like <span class="ar">دَلْوٌ</span>, <span class="auth">(Kr, Ḳ,)</span> a well-known term of relationship, <span class="auth">(Ḳ, TA,)</span> i. e. <em>A brother; the son of one's father and mother, or of either of them:</em> and also applied to <em>a foster-brother:</em> <span class="auth">(TA:)</span> and † <em>a friend; and a companion, an associate, or a fellow:</em> <span class="auth">(Ḳ:)</span> derived from <span class="ar">آخِيَّةٌ</span> <span class="add">[q. v.]</span>; as though one <span class="ar">أَخ</span> were tied and attached to another like as the horse is tied to the <span class="ar">آخيّة</span>: <span class="auth">(Ḥar p. 42:)</span> or, accord. to some of the grammarians, it is from <span class="ar">وَخَى</span> meaning <span class="ar">قَصَدَ</span>; because the <span class="ar">أَخ</span> has the same aim, endeavour, or desire, as his <span class="ar">أَخ</span>: <span class="auth">(TA:)</span> when <span class="ar">أَخ</span> is prefixed to another noun, its final vowel is prolonged: <span class="auth">(Kh:)</span> you say, <span class="ar long">هذَا أَخُوكَ</span> <span class="add">[<em>This is thy brother,</em>, &amp;c.]</span>, and <span class="ar long">مَرَرْتُ بِأَخِيكَ</span> <span class="add">[<em>I passed by thy brother,</em>, &amp;c.]</span>, and <span class="ar long">رَأَيْتُ أَخَاكَ</span> <span class="add">[<em>I saw thy brother,</em>, &amp;c.]</span>: <span class="auth">(Ṣ: <span class="add">[in which it is also asserted that one does not say <span class="ar">أَخُو</span> without prefixing it to another noun; but this is inconsistent with the assertion of IAạr and F, that <span class="ar">الأَخُو</span> is a syn. of <span class="ar">الأَخُ</span>:]</span>)</span> the dual is <span class="ar">أَخَوَانِ</span>, <span class="auth">(Ṣ, Mṣb, Ḳur xlix. 10, Ḥam p. 434,)</span> or <span class="ar">أَخْوَانِ</span>, with the <span class="ar">خ</span> quiescent, <span class="auth">(TA, <span class="add">[but this I have found nowhere else,]</span>)</span> and some of the Arabs say <span class="ar">أَخَانِ</span>, <span class="auth">(Ṣ, Mṣb,)</span> and Kr mentions <span class="ar">أَخُوَانِ</span>, with damm to the <span class="ar">خ</span>, said by IB to occur in poetry, and held by ISd to be dual of <span class="ar">أَخُو</span>, with damm to the <span class="ar">خ</span>: <span class="auth">(TA:)</span> the pl. is <span class="ar">إِخْوَةٌ</span> and <span class="ar">إِخْوَانٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> the former generally applied to <em>brothers,</em> and the latter to <em>friends</em> <span class="add">[or <em>the like</em>]</span>, <span class="auth">(T, Ṣ,*)</span> but not always, as in the Ḳur xlix. 10, where the former does not denote relationship, and in xxiv. 60 of the same, where the latter does denote relationship, <span class="auth">(T, TA,)</span> and sometimes the former is applied to a <span class="add">[single]</span> man, as in the Ḳur iv. 12, <span class="auth">(Ṣ,)</span> and <span class="ar">أُخْوَةٌ</span>, <span class="auth">(Fr, Ṣ, Mṣb, Ḳ, <span class="add">[in the CK <span class="ar">اَخْوَةٌ</span>,]</span>)</span> or this is a quasi-pl. n., <span class="auth">(Sb, TA,)</span> and <span class="ar">أُخْوَانٌ</span>, <span class="auth">(Kr, Mṣb, Ḳ,)</span> and <span class="ar">آخَآءٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> like <span class="ar">آبَآءٌ</span>, <span class="auth">(Ṣ,)</span> and <span class="ar">أُخُوٌّ</span>, and <span class="ar">أُخُوَّةٌ</span>, <span class="auth">(ISd, Ḳ,)</span> the last mentioned by Lḥ, and thought by ISd to be formed from the next preceding by the addition of <span class="ar">ة</span> characterizing the pl. as fem., <span class="auth">(TA,)</span> and <span class="ar">أَخُونَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">اخاوون</span>. <span class="auth">(Mṣb: <span class="add">[there written without any syll. signs, and I have not found it elsewhere.]</span>)</span> The fem. of <span class="ar">أَخٌ</span> is <span class="arrow"><span class="ar">أُخْتٌ↓</span></span> <span class="add">[meaning <em>A sister:</em> and † <em>a female friend,</em>, &amp;c.]</span>: <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.:)</span> written with damm to show that the letter which has gone from it is <span class="ar">و</span>; <span class="auth">(Ṣ;)</span> the <span class="ar">ت</span> being a substitute for the <span class="ar">و</span>; <span class="auth">(TA;)</span> not to denote the fem. gender, <span class="auth">(Ḳ, TA,)</span> because the letter next before it is quiescent: this is the opinion of Sb, and <span class="add">[accord. to SM]</span> it is the correct opinion: for Sb says that if you were to use it as a proper name of a man, you would make it perfectly decl.; and if the <span class="ar">ت</span> were to denote the fem. gender, the name would not be perfectly decl.; though in one place he incidentally says that it is the sign of the fem. gender, through inadvertence: Kh, however, says that its <span class="ar">ت</span> is <span class="add">[originally]</span> <span class="ar">ه</span> <span class="add">[meaning <span class="ar">ة</span>]</span>: and Lth, that <span class="ar">أُخْتٌ</span> is originally <span class="ar">أَخَةٌ</span>: and some say that it is originally <span class="ar">أَخْوَةٌ</span>: <span class="auth">(TA:)</span> the dual. is <span class="ar">أُخْتَانِ</span>: <span class="auth">(Kh:)</span> and the pl. is <span class="ar">أَخَوَاتٌ</span>. <span class="auth">(Kh, Ṣ, Mṣb, Ḳ.)</span> The saying <span class="ar long">لَا أَخَالَكَ بِفُلَانٍ</span> <span class="add">[<em>Thou hast no brother,</em> or † <em>friend, in such a one</em>]</span> means <span class="ar long">لَيْسَ لَكَ بِأَخٍ</span> <span class="add">[<em>such a one is not a brother,</em> or <em>friend, to thee</em>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> It is said in a prov., <span class="ar long">مَنْ لَكَ بِأَخِيكَ كُلِّهِ</span> <span class="add">[<em>Who will be responsible to thee for thy brother,</em> or † <em>thy friend, altogether?</em> i. e., for his always acting to thee as a brother, or friend]</span>. <span class="auth">(JK.)</span> And in another, <span class="ar long">رُبَّ أَخٍ لَكَ لَمْ تَلِدْهُ أُمُّكَ</span> <span class="add">[† <em>There is many a brother to thee whom thy mother has not brought forth</em>]</span>. <span class="auth">(TA.)</span> And in another, <span class="ar long">أَخُوكَ أَمِ الذَّئْبُ</span> <span class="add">[<em>Is it thy brother,</em> or <em>the wolf?</em>]</span>; said in suspecting a thing: as also <span class="ar long">أَخُوكَ أَمِ اللَّيْلُ</span> <span class="add">[<em>Is it thy brother, or is it the night</em> that deceives thee?]</span>. <span class="auth">(Ḥar p. 554.)</span> And another saying is, <span class="ar long">الرُّمْحُ أَخُوكَ وَرُبَّمَا خَانَكَ</span> <span class="add">[† <em>The spear is thy brother, but sometimes, or often, it is unfaithful to thee</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaxN.1_A2">
					<p>Ibn-ʼArafeh says that when <span class="ar">أُخُوَّةٌ</span> does not relate to birth, it means conformity, or similarity; and combination, agreement, or unison, in action: hence the saying, <span class="ar long">هذَا الثَّوْبُ أَخُو هذَا</span> <span class="add">[† <em>This garment, or piece of cloth, is the like, or fellow, of this</em>]</span>: and hence the saying in the Ḳur <span class="add">[xvii. 29]</span>, <span class="ar long">كَانُوا إِخْوَانَ الشَّيَاطِينِ</span> † <em>They are the likes, or fellows, of the devils:</em> and in the same <span class="add">[xliii. 47]</span>, <span class="arrow"><span class="ar long">إِلَّا هِىَ أَكْبَرُ مِنْ أُخْتِهَا↓</span></span> † <em>But it was greater than its like, or fellow;</em> i. e., than what was like to it in truth, &amp;c. <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">النَّوْمُ أَخُ المَوْتِ</span> <span class="add">[<em>Sleep is the like of death</em>]</span>. <span class="auth">(El-Jámiʼ eṣ-Ṣagheer.)</span> One says also, <span class="ar long">لَقِىَ فُلَانٌ أَخَا المَوْتِ</span> † <em>Such a one met with the like of death.</em> <span class="auth">(Mṣb, TA.)</span> And they said,<span class="arrow"><span class="ar long">وَمَاهُ آللّٰهُ بِلَيْلَپٍ لَا أُخْتَ↓ لَهَا</span></span> <span class="add">[† <em>God afflicted him with a night having none like to it</em>]</span>, i. e., a night in which he should die. <span class="auth">(TA.)</span> And <span class="ar long">لَا أُكَلِّمُهُ إِلَّا أَخَا السِّرارِ</span> † <em>I will not speak to him save the like of secret discourse.</em> <span class="auth">(Aṣ, TA.)</span> <span class="add">[And hence,]</span><span class="arrow"><span class="ar long">أُخْتَا↓ سُهَيْلٍ</span></span> <span class="add">[† <em>The two sisters of Canopus;</em>]</span> <em>the two stars called</em> <span class="ar long">الشّعْرَى العَبُورُ</span> and <span class="ar long">الشّعْرَى الغُمَيْصَآءُ</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">شعر</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaxN.1_A3">
					<p><span class="ar long">يَاَ أَخَا بَكْرٍ</span>, or <span class="ar">تَمِيمٍ</span>, means † <em>O thou of</em> <span class="add">[the tribe of]</span> <em>Bekr,</em> or <em>Temeem.</em> <span class="auth">(Ḥam p. 284.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaxN.1_A4">
					<p>Lh mentions, on the authority of Abu-d-Deenár and Ibn-Ziyád, the saying, <span class="ar long">القُمْمُ بِأَخِى الشَّرَّ</span>, as meaning † <em>The people, or company of men, are in an evil state or condition.</em> <span class="auth">(TA.)</span> <span class="add">[But accord. to others,]</span> one says, <span class="ar long">تَرَكْتُهُ بِأَخِى الخَيْرِ</span>, meaning ‡ <em>I left him in an evil state or condition:</em> <span class="auth">(JK,* Mṣb, Ḳ, TA:)</span> and <span class="ar long">بِأَخِى الشَّرِّ</span> ‡ <em>in a good state or condition.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaxN.1_A5">
					<p>You say also, <span class="ar long">هُوَأَخُو الصَّدْقِ</span> † <em>He is one who cleaves,</em> or <em>keeps, to veracity.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaxN.1_A6">
					<p><span class="add">[<span class="ar">أِخُو</span>, as a prefixed noun, is also used in the sense of <span class="ar">أَهْلُ</span>, meaning † <em>Worthy, or deserving,</em> of a thing: and <em>meet, fit,</em> or <em>fitted,</em> for it. So in the phrase <span class="ar long">أَخُو ثِقَةٍ</span> † <em>Worthy,</em> or <em>deserving, of trust,</em> or <em>confidence;</em> expl. by W <span class="auth">(p. 91)</span> as meaning <em>a person in whom one trusts,</em> or <em>confides.</em> And so in the prov., <span class="ar long">لَيْسَ أَخُو الكِظَاظِ مَنْ يَسْأَمُهُ</span> † <em>He who is fit,</em> or <em>fitted, for vehement striving for the mastery is not he who turns away from it with disgust:</em> <a href="index.php?data=22_k/109_kZ">see art. <span class="ar">كظ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaxN.1_A7">
					<p>It is also used in the sense of <span class="ar">ذُو</span>: as in the phrase, <span class="ar long">هُوَأَخُو الغِنَى</span> <span class="add">[† <em>He is possessed,</em> or <em>a possessor, of wealth,</em> or <em>competence,</em> or <em>sufficiency</em>]</span>. <span class="auth">(Mṣb.)</span> <span class="add">[So too in the phrase, <span class="ar long">أَخُو الخَيْرِ</span> † <em>Possessed,</em> or <em>a possessor, of good,</em> or <em>of what is good.</em> And in like manner,]</span> <span class="ar long">أَخُو الخَنَعِ</span> means <span class="add">[<span class="ar long">ذُو الخَنَعِ</span>, i. e. <span class="ar long">ذُو الذِّلَّةِ</span>, i. e.]</span> <span class="ar">الّذَّلِيلُ</span> <span class="add">[† <em>The low, base,</em> or <em>abject</em>]</span>. <span class="auth">(Ḥam p. 44.)</span> <span class="add">[So too]</span> <span class="ar long">سَيْرُنَا أَخُو الجِيْدِ</span> means <span class="add">[<span class="ar long">سَيْرُنَا ذُوالجَيْدِ</span>, i. e.]</span> <span class="ar long">سَيْرُنَا جَاهِدٌ</span> <span class="pb" id="Page_0034"></span><span class="add">[† <em>Our journeying is laborious:</em> see an ex. in the first paragraph of <a href="../">art. <span class="ar">عدر</span></a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="OaxN.1_A8">
					<p><span class="ar long">حُمَّى الأَخَوَيْنِ</span> † <em>A fever that affects the patient two days, and quits him two days; or that attacks on Saturday, and quits for three days, and comes</em> <span class="add">[<em>again</em>]</span> <em>on Thursday; and so on.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أَخٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="OaxN.1_A9">
					<p><span class="ar long">دَمُ الأَخَوَيْنِ</span>: <a href="#damN">see <span class="ar">دَمٌ</span></a>, <a href="../">in art. <span class="ar">دمى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaxFA">
				<h3 class="entry"><span class="ar">أَخًا</span></h3>
				<div class="sense" id="OaxFA_A1">
					<p><span class="ar">أَخًا</span>: <a href="#OaxN">see <span class="ar">أَخٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaxowN">
				<h3 class="entry"><span class="ar">أَخْوٌ</span></h3>
				<div class="sense" id="OaxowN_A1">
					<p><span class="ar">أَخْوٌ</span>: <a href="#OaxN">see <span class="ar">أَخٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oaxuw">
				<h3 class="entry"><span class="ar">أَخُو</span></h3>
				<div class="sense" id="Oaxuw_A1">
					<p><span class="ar">أَخُو</span>: <a href="#OaxN">see <span class="ar">أَخٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuxotN.1">
				<h3 class="entry"><span class="ar">أُخْتٌ</span></h3>
				<div class="sense" id="OuxotN.1_A1">
					<p><span class="ar">أُخْتٌ</span>: <a href="#OaxN">see <span class="ar">أَخٌ</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxayBN">
				<h3 class="entry"><span class="add">[<span class="ar">أُخَيٌّ</span> / <span class="ar">أُخَيَّةٌ</span>]</span></h3>
				<div class="sense" id="OuxayBN_A1">
					<p><span class="add">[<span class="ar">أُخَيٌّ</span> and <span class="ar">أُخَيَّةٌ</span> dims. of <span class="ar">أَخٌ</span> and <span class="ar">أُخْتٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaxawieBN">
				<h3 class="entry"><span class="ar">أَخَوِىٌّ</span></h3>
				<div class="sense" id="OaxawieBN_A1">
					<p><span class="ar">أَخَوِىٌّ</span> <em>Brotherly; fraternal; of,</em> or <em>relating to, a brother,</em> and <em>a friend</em> or <em>companion:</em> and also, <em>sisterly; of, or relating to, a sister;</em> because you say <span class="ar">أَخَوَاتٌ</span> <span class="add">[meaning “sisters”]</span>; but Yoo used to say <span class="arrow"><span class="ar">أُخْتِىُّ↓</span></span>, which is not agreeable with analogy. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuxotieBu">
				<h3 class="entry"><span class="ar">أُخْتِىُّ</span></h3>
				<div class="sense" id="OuxotieBu_A1">
					<p><span class="ar">أُخْتِىُّ</span>: <a href="#OaxawieBu">see <span class="ar">أَخَوِىُّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IixowaAnN">
				<h3 class="entry"><span class="ar">إِخْوَانٌ</span></h3>
				<div class="sense" id="IixowaAnN_A1">
					<p><span class="ar">إِخْوَانٌ</span>, besides being <a href="#OaxN">a pl. of <span class="ar">أَخٌ</span>, q. v.</a>, <a href="#xiwaAnN">is a dial. var. of <span class="ar">خِوَانٌ</span></a>. <span class="auth">(TA. <span class="add">[<a href="index.php?data=07_x/176_xwn">See art. <span class="ar">خون</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IixaAwapN">
				<h3 class="entry"><span class="ar">إِخَاوَةٌ</span></h3>
				<div class="sense" id="IixaAwapN_A1">
					<p><span class="ar">إِخَاوَةٌ</span>: <a href="#Axw_3">see 3</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuxuwBapN">
				<h3 class="entry"><span class="ar">أُخُوَّةٌ</span></h3>
				<div class="sense" id="OuxuwBapN_A1">
					<p><span class="ar">أُخُوَّةٌ</span> <a href="#Axw_1">an inf. n. of 1</a>: and also <span class="add">[used as]</span> a simple subst. <span class="auth">(TA.)</span> <a href="#Axw_1">See 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">أُخُوَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuxuwBapN_A2">
					<p>When it does not relate to birth, it means † <em>Conformity,</em> or <em>similarity;</em> and <em>combination, agreement,</em> or <em>unison, in action.</em> <span class="auth">(Ibn-ʼArafeh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MxiyBapN">
				<h3 class="entry"><span class="ar">آخِيَّةٌ</span></h3>
				<div class="sense" id="MxiyBapN_A1">
					<p><span class="ar">آخِيَّةٌ</span>, <span class="auth">(Lth, Ṣ, Mṣb, Ḳ, &amp;c.,)</span> originally of the measure <span class="ar">فَاعُولَةٌ</span>, <span class="add">[i. e. <span class="ar">آخُويَةٌ</span>,]</span> <span class="auth">(Mṣb,)</span> and <span class="ar">آخِيَةٌ</span>, <span class="auth">(Lth, Mṣb, Ḳ,)</span> and <span class="ar">أَخِيَّةٌ</span>, <span class="auth">(JK, Ḳ, TA, <span class="add">[but in the Ḳ the orthography of these three words is differently expressed in different copies, and somewhat obscurely in all that I have seen,]</span>)</span> <em>A piece of rope of which the two ends are buried in the ground,</em> <span class="auth">(ISk, JK, Ṣ,)</span> <em>with a small staff</em> or <em>stick, or a small stone, attached thereto,</em> <span class="auth">(ISK, Ṣ,)</span> <em>a portion thereof, resembling a loop, being apparent, or exposed, to which the beast is tied;</em> <span class="auth">(ISk, JK, Ṣ;)</span> it is made in soft ground, as being more commodious to horses than pegs, or stakes, protruding from the ground, and more firm in soft ground than the peg, or stake: <span class="auth">(TA:)</span> or <em>a loop tied to a peg,</em> or <em>stake, driven</em> <span class="add">[<em>into the ground</em>]</span>, <em>to which the beast is attached:</em> <span class="auth">(Mṣb:)</span> or <em>a stick, or piece of wood,</em> <span class="auth">(Ḳ, TA,)</span> <em>placed crosswise</em> <span class="auth">(TA)</span> <em>in a wall,</em> or <em>in a rope of which the two ends are buried in the ground, the</em> <span class="add">[<em>other</em>]</span> <em>end</em> <span class="add">[<em>or portion</em>]</span> <em>protruding, like a ring, to which the beast is tied:</em> <span class="auth">(Ḳ, TA:)</span> or <em>a peg, or stake, to which horses are tied:</em> <span class="auth">(Ḥar p. 42:)</span> <span class="add">[<a href="#ArieBu">see also <span class="ar">آرِىُّ</span></a>:]</span> the pl. of the first is <span class="ar">أَوَاخِىُّ</span>; <span class="auth">(JK, Ṣ, Mṣb, Ḳ;*)</span> and of the second, <span class="ar">أوَاخٍ</span>; <span class="auth">(Mṣb;)</span> and of the third, <span class="ar">أَخَايَا</span>, <span class="auth">(JK, Ḳ,*)</span> like as <span class="ar">خَطَايَا</span> <a href="#xaTiyBapN">is pl. of <span class="ar">خَطِيَّةٌ</span></a>. <span class="auth">(TA.)</span> In a trad., the believer and belief are likened to a horse attached to his <span class="ar">آخيّة</span>; because the horse wheels about, and then returns to his <span class="ar">آخيّة</span>; and the believer is heedless, and then returns to believe. <span class="auth">(TA.)</span> And in another, men are forbidden to make their backs like the <span class="ar">أَخَايَا</span> of beasts; i. e., in prayer; meaning that they should not arch them therein, so as to make them like the loops thus called. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">آخِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MxiyBapN_A2">
					<p>Also <em>i. q.</em> <span class="ar">طُنُبٌ</span>; <span class="auth">(Ḳ;)</span> i. e. The <em>kind of tent-rope thus called.</em> <span class="auth">(TA in art. <span class="ar">طنب</span>, q. v.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">آخِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MxiyBapN_A3">
					<p>And † <em>A sacred, or an inviolable, right</em> or <em>the like;</em> syn. <span class="ar">حُرْمَةٌ</span> and <span class="ar">ذِمَّةٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">لِفُلَانٍ أَوَاخِىُّ وَأَسْبَابٌ تُرْعَى</span> <span class="add">[† <em>To such a one belong sacred, or inviolable, rights, and ties of relationship and love, to be regarded</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">لَهُ عِنْدِى آجِيَّةٌ</span> † <em>He has, with me,</em> or <em>in my estimation, a strong, sacred, or inviolable, right;</em> and <em>a near tie</em> or <em>connexion,</em> or <em>means of access</em> or <em>intimacy</em> or <em>ingratiation.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اخو</span> - Entry: <span class="ar">آخِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MxiyBapN_A4">
					<p>In a trad. of ʼOmar, in which it is related that he said to El-ʼAbbás, <span class="ar long">أَنْتَ آخِيَّةُ آبَآءِ رَسُولِ اَللّٰهِ</span>, it is used in the sense of <span class="ar">بَقِيَّةَ</span>; <span class="add">[and the words may therefore be rendered <em>Thou art the most excellent of the ancestors of the Apostle of God;</em>]</span> as though he meant, thou art he upon whom one stays himself, and to whom one clings, of the stock of the Apostle of God. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0032.pdf" target="pdf">
							<span>Lanes Lexicon Page 32</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0033.pdf" target="pdf">
							<span>Lanes Lexicon Page 33</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0034.pdf" target="pdf">
							<span>Lanes Lexicon Page 34</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
