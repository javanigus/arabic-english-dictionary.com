<article class="root" id="Root_AHn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/031_AHd">احد</a></span>
				<span class="ar">احن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/033_Ax">اخ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AHn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أحن</span></h3>
				<div class="sense" id="AHn_1_A1">
					<p><span class="ar">أَحِنَ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> <span class="ar">عَلَيْهِ</span>, <span class="auth">(Ṣ, TA,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْحَنُ</span>}</span></add>, <span class="auth">(Mṣb, Ḳ,)</span> inf. n. <span class="ar">أَحَنٌ</span>, <span class="auth">(Mṣb,)</span> or <span class="ar">أَحْنٌ</span>, and <span class="ar">إِحْنَةٌ</span>, <span class="auth">(TA,)</span> or this last is a simple subst.; <span class="auth">(Mṣb;)</span> and <span class="ar long">أَحَنَ عَلَيْهِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْحَنُ</span>}</span></add>, inf. n. <span class="ar">أَحْنٌ</span>; <span class="auth">(Kr, TA;)</span> <em>He retained enmity against him in his bosom, watching for an opportunity to indulge it,</em> or <em>exercise it;</em> or <em>hid enmity against him in his bosom;</em> or <em>bore rancour, malevolence, malice,</em> or <em>spite, against him:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:*)</span> and <em>he was affected with anger</em> <span class="auth">(Ḳ, TA)</span> <em>against him, such as came upon him suddenly from the retention</em> or <em>hiding of enmity in the bosom,</em> or <em>from rancour, malevolence, malice,</em> or <em>spite.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AHn_3">
				<h3 class="entry">3. ⇒ <span class="ar">آحن</span></h3>
				<div class="sense" id="AHn_3_A1">
					<p><span class="ar">آحَنَهُ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">مُؤَاحَنَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He treated him,</em> or <em>regarded him, with enmity,</em> or <em>hostility.</em> <span class="auth">(Ṣ,* Ḳ,* TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiHonapN">
				<h3 class="entry"><span class="ar">إِحْنَةٌ</span></h3>
				<div class="sense" id="IiHonapN_A1">
					<p><span class="ar">إِحْنَةٌ</span> <em>Retention of enmity in the bosom, with watchfulness for an opportunity to indulge it,</em> or <em>exercise it;</em> or <em>concealment of enmity in the bosom;</em> or <em>rancour, malevolence, malice,</em> or <em>spite:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> and <em>anger</em> <span class="auth">(Ḳ, TA)</span> <em>coming upon one suddenly therefrom:</em> <span class="auth">(TA:)</span> pl. <span class="ar">إِحَنٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span> It is said in the Ṣ that one should not say <span class="ar">حِنَةٌ</span>; and this is disallowed by Aṣ and Fr and Ibn-El-Faraj: in the T it is said that it is not of the language of the Arabs; and Aṣ is related to have disapproved of Et-Tirimmáh for using its pl. in poetry: but it is said in a trad., <span class="ar long">مَا بَيْنِى وبَيْنَ العَرَبِ حِنَةٌ</span> <span class="add">[<em>There is not between me and the Arabs retention of enmity in the bosom,</em>, &amp;c.]</span>; and it occurs in another trad., in a similar phrase; and the pl., in a third trad.; therefore we say that it is a dial. var. of rare occurrence. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0028.pdf" target="pdf">
							<span>Lanes Lexicon Page 28</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
