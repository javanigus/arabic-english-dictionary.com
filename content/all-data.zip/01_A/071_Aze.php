<article class="root" id="Root_Aze">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/070_Azm">ازم</a></span>
				<span class="ar">ازى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/072_As">اس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Aze_2">
				<h3 class="entry">2. ⇒ <span class="ar">أزّى</span></h3>
				<div class="sense" id="Aze_2_A1">
					<p><span class="ar long">أزّى الحَوْضَ</span>, inf. n. <span class="ar">تَأْزِيَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">تَأْزِىْءٌ</span>, or <span class="ar">تَوْزِىْءٌ</span>, <span class="auth">(accord. to different copies of the Ṣ, <span class="add">[the latter irregular,]</span>)</span> or both, <span class="auth">(accord. to the TA,)</span> <em>He put,</em> or <em>made, an</em> <span class="ar">إِزَآء</span> <span class="add">[q. v.]</span>, <em>to the watering-trough</em> or <em>tank;</em> <span class="auth">(Ṣ, Ḳ;)</span> i. e. <em>he put upon its mouth a stone,</em> or <em>a</em> <span class="ar">جُلَّة</span> <span class="add">[explained below, voce <span class="ar">إِزَآء</span>]</span>, or <em>the like;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">آزاهُ↓</span></span>, inf. n. <span class="ar">إِيزَآءٌ</span>; <span class="auth">(Ṣ, TA;)</span> or<span class="arrow"><span class="ar">تأزّاهُ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aze_3">
				<h3 class="entry">3. ⇒ <span class="ar">آزى</span></h3>
				<div class="sense" id="Aze_3_A1">
					<p><span class="ar">آزاهُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">مُؤَازَاةٌ</span>, <span class="auth">(Mṣb in art. <span class="ar">حذو</span>, and TA in art. <span class="ar">وزى</span>, &amp;c., <span class="add">[though it would seem from the Ḳ to be <span class="ar">إِيزَآءٌ</span>,]</span>)</span> <em>He</em> <span class="auth">(a man, Ṣ)</span> <em>was,</em> or <em>became, over against it,</em> or <em>opposite to it; he faced,</em> or <em>fronted, him,</em> or <em>it.</em> <span class="auth">(Ṣ,* Ḳ,* TA in art. <span class="ar">وزى</span>.)</span> Accord. to the Ṣ, one should not say, <span class="ar">وَازَاهُ</span>: but it is said in a trad. respecting the prayer of fear, <span class="ar long">فَوَازَيْنَا العَدُوَّ</span>, i. e. <em>And we faced,</em> or <em>fronted, the enemy:</em> <span class="auth">(TA:)</span> and the inf. n. is <span class="ar">مُوَازَاةٌ</span>. <span class="auth">(TA in art. <span class="ar">وزى</span>.)</span> <span class="add">[Its syn. <span class="ar">حَاذَاهُ</span> is more common.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Aze_3_B1">
					<p><span class="add">[Hence <span class="ar">مُؤَازَأْق</span> signifying <em>A conformity, a mutual resemblance,</em> or <em>a correspondence, with regard to sound, of two words occurring near together;</em> like <span class="ar">اِزْدِوَاجٌ</span>, &amp;c.: <a href="index.php?data=11_z/121_zwj">see art. <span class="ar">زوج</span></a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: 3.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Aze_3_C1">
					<p><span class="add">[Hence, likewise,]</span> <span class="ar">آزِاهُ</span> also signifies <em>He contended with him,</em> syn. <span class="ar">جَارَاهُ</span>; <span class="auth">(Ḳ, TA;)</span> and <em>opposed,</em> or <em>withstood, him,</em> syn. <span class="ar">قَاوَمَهُ</span>. <span class="auth">(TA.)</span> Whence the saying in a trad., <span class="ar long">وَفِرْقَةٌ آزَتِ ٱلْمُلُوكَ فَقَاتَلَتْهُمْ عَلَى دِينِ ٱللّٰهِ</span> <span class="add">[<em>And a party contended with, and opposed,</em> or <em>withstood, the kings, and fought with them for the religion of God</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aze_4">
				<h3 class="entry">4. ⇒ <span class="ar">آزى</span></h3>
				<div class="sense" id="Aze_4_A1">
					<p><span class="ar long">آزى الحَوْضَ</span> <em>i. q.</em> <span class="ar">أَزَّاهُ</span>, q. v. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Aze_4_A2">
					<p>And <em>He repaired,</em> or <em>put into a right</em> or <em>proper state, the</em> <span class="ar">إِزَآء</span> <span class="add">[q. v.]</span> <em>of the watering-trough</em> or <em>tank.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Aze_4_A3">
					<p>And <em>He poured forth the water from its</em> <span class="ar">إِزَآء</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Aze_4_A4">
					<p>And <span class="ar long">آزى فِيهِ</span> <em>He poured forth upon its</em> <span class="ar">إِزَاء</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Aze_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأزّى</span></h3>
				<div class="sense" id="Aze_5_A1">
					<p><a href="#Aze_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaziyapN">
				<h3 class="entry"><span class="ar">أَزِيَةٌ</span></h3>
				<div class="sense" id="OaziyapN_A1">
					<p><span class="ar long">نَاقَةٌ أَزِيَةٌ</span>, <span class="auth">(accord. to some copies of the Ṣ,)</span> or<span class="arrow"><span class="ar">آزِيَةٌ↓</span></span>, <span class="auth">(accord. to other copies of the Ṣ,)</span> or both, <span class="auth">(IAạr, TA,)</span> each after the manner of a relative noun, <span class="add">[having no verb,]</span> <span class="auth">(TA,)</span> <em>A she-camel that drinks from the</em> <span class="ar">إِزَآء</span> <span class="add">[q. v.]</span>: <span class="auth">(TA:)</span> or <em>that will not drink save from the</em> <span class="ar">إِزَآء</span> <em>of the trough</em> or <em>tank;</em> and <span class="ar">عَقِرَةٌ</span> signifies one “that will not drink save from the <span class="ar">عُقْر</span> <span class="add">[thereof]</span>:” <span class="auth">(Ṣ, TA, and IAạr in art. <span class="ar">عقر</span> in the TA:)</span> or, accord. to IAạr, <em>that will not come to the watering-trough</em> or <em>tank, to drink, until they leave it unoccupied for her;</em> as also <span class="ar">قَذُورٌ</span>. <span class="auth">(TA in the present art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlIizaMCu">
				<h3 class="entry"><span class="ar">الإِزَآءُ</span></h3>
				<div class="sense" id="AlIizaMCu_A1">
					<p><span class="ar">الإِزَآءُ</span> <em>i. q.</em> <span class="ar">الحِذَآءُ</span> <span class="add">[<em>The front,</em> as meaning the <em>part, place,</em> or <em>location, that is over against, opposite, facing, fronting,</em> or <em>in front</em>]</span>. <span class="auth">(Mṣb, and Ḳ, &amp;c. in art. <span class="ar">حذو</span>.)</span> You say, <span class="ar">هُوَبِإِزَائِهِ</span> <em>He is over against, opposite to, facing, fronting,</em> or <em>in front of, him;</em> syn. <span class="ar">بِحِذَائِهِ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">مُحَاذِيهِ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: <span class="ar">الإِزَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AlIizaMCu_A2">
					<p><span class="add">[Hence, <span class="ar">بِإِزَآئِهِ</span> signifies also <em>Corresponding to it;</em> as when one says,]</span> <span class="ar long">الأَبْجَلُ عِرْقٌ مِنَ الفَرَسِ وَالبَعِيرِ بِإِزَآءِ الأَكْحَلِ مِنَ الإِنْسَانِ</span> <span class="add">[<em>The</em> <span class="ar">ابجل</span> <em>is a vein of the horse and the camel, corresponding to the</em> <span class="ar">اكحل</span> <em>of man</em>]</span>. <span class="auth">(TA in art. <span class="ar">بجل</span>.)</span> <span class="add">[You say also, <span class="ar long">وَضَعَ لَفْظًا بِإِزَآءِ مَعْنَّى</span> <em>He applied a word,</em> or <em>phrase, as correspondent to an idea,</em> or <em>a meaning.</em>]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: <span class="ar">الإِزَآءُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AlIizaMCu_B1">
					<p><span class="ar">إِزَآءٌ</span> is also applied to a man, and to a woman, and to a number of persons, in senses here following. <span class="auth">(TA.)</span> You say, <span class="ar long">هُوَ إِزَآءُ الأَمْرِ</span> <em>He is the manager, conductor, orderer, regulator,</em> or <em>superintendent, of the affair.</em> <span class="auth">(Ṣ, Mṣb, TA.)</span> And in the same sense the word is used by Homeyd, in the phrase <span class="ar long">إِزَآءُ مَعَاشٍ</span> <span class="add">[<em>The manager,</em> or <em>orderer, of the means of subsistence</em>]</span>, applied to a woman. <span class="auth">(TA.)</span> And in an instance in which a poet likens the <span class="ar">إِزَآء</span> of a watering-trough or tank to the <span class="add">[stinking animal called]</span> <span class="ar">ظَرِبَان</span>: <span class="auth">(Ṣ, TA:)</span> in this case it means The <em>water-drawer</em> <span class="add">[of the trough or tank]</span>. <span class="auth">(Aṣ, IB, TA.)</span> <span class="add">[But in relation to a watering-trough or tank, it generally has another meaning, which see below.]</span> You say also, <span class="ar long">فُلَانٌ إِزَآءٌ مَالٍ</span> <span class="auth">(Ṣ)</span> <span class="add">[<em>Such a one is</em>]</span> <em>a manager, tender,</em> or <em>superintendent, of cattle,</em> or <em>camels</em>, &amp;c.; <span class="auth">(Ḳ,* TA;)</span> <em>a good pastor thereof.</em> <span class="auth">(TA.)</span> And <span class="ar long">إِزَآءُ الحَرْبِ</span> <em>The vigorous wager,</em> or <em>prosecutor, of war.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">فُلَانٌ إِزَآءُ فُلَانٍ</span> <em>Such a one is the fellow and assistant of such a one.</em> <span class="auth">(TA.)</span> And <span class="ar long">هُمْ إِزَاؤُهُمْ</span> <em>They are their fellows,</em> <span class="auth">(Ḳ, TA,)</span> <em>who assist them, and order,</em> or <em>set in order, their affairs:</em> <span class="auth">(TA:)</span> or <em>they are those who order,</em> or <em>set in order, their affairs.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">إِنَّهُ لَإِ زَآءُ خَيْرٍ</span>, and <span class="ar">شَّرٍ</span>, <em>Verily he is a possessor of goodness,</em> and <em>of evilness.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: <span class="ar">الإِزَآءُ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="AlIizaMCu_B2">
					<p>Also, <span class="ar">الإِزَآءُ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">إِزَآءُ العيش</span>, <span class="auth">(TḲ,)</span> <em>The means of sustenance:</em> or <em>what has been caused,</em> or <em>occasioned, of plentifulness and easiness, and of superabundance, of sustenance.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازى</span> - Entry: <span class="ar">الإِزَآءُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="AlIizaMCu_C1">
					<p>Also The <em>place where the water is poured into the wateringtrough</em> or <em>tank;</em> <span class="auth">(Aṣ, Ṣ, Ḳ;)</span> i. e. <em>its fore part;</em> <span class="add">[the <em>part next to the well or other source whence it is filled;</em>]</span> the hinder part, where the camels stand when they come to water, being called the <span class="ar">عُقْر</span>: <span class="auth">(Ṣ in art. <span class="ar">عقر</span>:)</span> or, accord. to AZ, <em>a mass of stone, and what is put for protection</em> <span class="add">[<em>of the brink of the trough</em> or <em>tank</em> <span class="auth">(as it is generally constructed of stones cemented and plastered with mud)</span>]</span> <span class="pb" id="Page_0056"></span><em>upon the place where the water is poured when the bucket is emptied:</em> <span class="auth">(Ṣ in the present art.:)</span> or the <em>whole</em> (<span class="ar">جَمِيع</span> <span class="add">[said in the TA to be a mistake for <span class="ar">جمع</span>, but this I think extremely improbable,]</span>) <em>of what is between the wateringtrough</em> or <em>tank and the cavity of the well,</em> <span class="add">[namely,]</span> <em>of the</em> <span class="add">[<em>casing of stones,</em> or <em>bricks, called</em>]</span> <span class="ar">طَّى</span>: <span class="auth">(Ḳ:)</span> or <em>a stone,</em> or <em>skin,</em> or <span class="ar">جُلَّة</span> <span class="add">[i. e. a <em>thing made of palm-leaves woven together,</em> generally used as a receptacle for dates]</span>, <em>put</em> <span class="add">[<em>for protection</em>]</span> <em>upon the mouth</em> <span class="add">[or <em>part of the border where the water is poured in</em>]</span> <em>of the wateringtrough</em> or <em>tank:</em> <span class="auth">(Ḳ,* TA:)</span> in the Ḳ, <span class="ar long">يُوضَعُ عَلَيْهَا الحَوْضُ</span> is erroneously put for <span class="ar long">يوضع عَلَى فَمِ الحَوْضِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MziyapN">
				<h3 class="entry"><span class="ar">آزِيَةٌ</span></h3>
				<div class="sense" id="MziyapN_A1">
					<p><span class="ar long">نَاقَةٌ آزِيَةٌ</span>: <a href="#OaziyapN">see <span class="ar">أَزِيَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0055.pdf" target="pdf">
							<span>Lanes Lexicon Page 55</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0056.pdf" target="pdf">
							<span>Lanes Lexicon Page 56</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
