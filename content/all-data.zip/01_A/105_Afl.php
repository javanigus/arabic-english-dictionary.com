<article class="root" id="Root_Afl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/104_Afk">افك</a></span>
				<span class="ar">افل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/106_Afh">افه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Afl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أفل</span></h3>
				<div class="sense" id="Afl_1_A1">
					<p><span class="ar">أَفَلَ</span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> said of a thing, <span class="auth">(Mṣb,)</span> or of the moon, <span class="auth">(T,)</span> and <span class="ar">أَفَلَتْ</span>, said of the sun, <span class="auth">(T, Ṣ, M,)</span> and of the stars, <span class="auth">(M,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِلُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْفُلُ</span>}</span></add>, inf. n. <span class="ar">أُفُولٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أفْلٌ</span>, <span class="auth">(M, Mṣb,)</span> <em>It was,</em> or <em>became, absent,</em> or <em>hidden,</em> or <em>concealed;</em> <span class="auth">(T, Ṣ, Mṣb, Ḳ;)</span> <em>it set;</em> <span class="auth">(T, Ṣ, M, &amp;c.;)</span> and so <span class="ar">أَفِلَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْفَلُ</span>}</span></add>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Afl_1_A2">
					<p>Hence, <span class="ar long">أَفَلَ فُلَانٌ عَنِ البَلَدِ</span> <em>Such a one became absent,</em> or <em>went away, from the country,</em> or <em>town.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OafiylN">
				<h3 class="entry"><span class="ar">أَفِيلٌ</span> / <span class="ar">أَفِيلَةٌ</span></h3>
				<div class="sense" id="OafiylN_A1">
					<p><span class="ar">أَفِيلٌ</span> <em>A young camel such as is termed</em> <span class="ar long">اِبْنُ مَخَاضٍ</span> <span class="add">[i. e. <em>that has entered its second year</em>]</span>; <span class="auth">(Aṣ, El-Fárábee, Ṣ, M, Mṣb, Ḳ;)</span> and <em>the like;</em> <span class="auth">(Ṣ;)</span> or, and also <em>such as is above this</em> <span class="add">[<em>in age</em>]</span>; <span class="auth">(El-Fárábee, M, Mṣb, Ḳ;)</span> or, and also <em>such as is termed</em> <span class="ar long">اِبْنُ لَبُونٍ</span> <span class="add">[i. e. <em>that has entered the third year</em>]</span>; beyond which it is not so called: <span class="auth">(Aṣ, TA:)</span> or <em>that is seven months old,</em> or <em>eight:</em> <span class="auth">(Aṣ, Mṣb:)</span> or <em>a youthful camel:</em> <span class="auth">(AZ, Mṣb:)</span> and also <span class="auth">(M, Ḳ)</span> <em> a young weaned camel;</em> syn. <span class="ar">فَصِيلٌّ</span>: <span class="auth">(T, M, Mṣb, Ḳ:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">أَفِيلَةٌ</span>}</span></add>: <span class="auth">(Aṣ, Ṣ:)</span> pl. <span class="ar">إِفَالٌ</span> <span class="auth">(T, Ṣ, M, Ḳ)</span> and <span class="ar">أَفَائِلُ</span>, <span class="auth">(Sb, Ṣ, M, Ḳ,)</span> which latter they liken to <span class="ar">ذَنَائِبُ</span> <a href="#cnuwbN">as pl. of <span class="ar">ذنُوبٌ</span></a>. <span class="auth">(M.)</span> <span class="add">[In my copy of the Mṣb, the pl. is said to be <span class="ar">إفالة</span>: and it is also there said, on the authority of IF, that <span class="ar">افالة</span> signifies the <em>young ones of sheep.</em>]</span> It is said in a prov., <span class="ar long">إِنَّمَا القَرْمِ مِنَ الأَفِيلِ</span> <span class="add">[<em>The stallion-camel is only</em> that which has increased in growth <em>from the young one in its second year,</em>, &amp;c.]</span>; i. e. what is great has begun small. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MfilN">
				<h3 class="entry"><span class="ar">آفِلٌ</span> / <span class="ar">آفِلَةٌ</span></h3>
				<div class="sense" id="MfilN_A1">
					<p><span class="ar">آفِلٌ</span> <a href="#Afl_1">part. n. of 1</a>, <span class="auth">(T, TA,)</span> applied to the moon, and to any star: <span class="auth">(TA:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">آفِلَةٌ</span>}</span></add>: <span class="auth">(T, TA:)</span> pl. <span class="ar">آفِلُونَ</span> <span class="auth">(Ḳur vi. 76 <span class="add">[the rational form of the pl. being there used because it is applied to stars as being likened to gods]</span>)</span> and <span class="ar">أُفَّلٌ</span> and <span class="ar">أُفُولٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0070.pdf" target="pdf">
							<span>Lanes Lexicon Page 70</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
