<article class="root" id="Root_Amd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/130_Amt">امت</a></span>
				<span class="ar">امد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/132_Amr">امر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Amd_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمد</span></h3>
				<div class="sense" id="Amd_1_A1">
					<p><span class="ar long">أَمِدَ عَلَيْهِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْمَدُ</span>}</span></add>, inf. n. <span class="ar">أَمَدٌ</span>, <em>He was angry with him:</em> <span class="auth">(Ṣ, M, Mṣb,* Ḳ:)</span> like <span class="ar">أَبِدَ</span> <span class="auth">(Ṣ)</span> and <span class="ar">وَمَد</span> and <span class="ar">وَبِدَ</span> and <span class="ar">عَبِدَ</span>. <span class="auth">(T in art. <span class="ar">ابد</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amd_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّد</span></h3>
				<div class="sense" id="Amd_2_A1">
					<p><span class="ar">أمّد</span>, inf. n. <span class="ar">تَأْمِيدٌ</span>, <em>He declared the time, considered with regard to its end;</em> or <em>the utmost,</em> or <em>extreme, extent, term, limit, point,</em> or <em>reach;</em> expl. by <span class="ar long">بَيَّنَ الأَمَدَ</span>. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamadN">
				<h3 class="entry"><span class="ar">أَمَدٌ</span></h3>
				<div class="sense" id="OamadN_A1">
					<p><span class="ar">أَمَدٌ</span> <em>Time, considered with regard to its end:</em> <span class="ar">زَمَانٌ</span> being time considered with regard to its end and its beginning: <span class="auth">(Er-Rághib:)</span> <span class="add">[but sometimes it is interchangeable with <span class="ar">زَمَانٌ</span>, as will be seen in what follows:]</span> or the <em>utmost,</em> or <em>extreme, extent, term, limit, point,</em> or <em>reach.</em> <span class="auth">(Ṣ, M, A, Mṣb, Ḳ.)</span> You say, <span class="ar long">بَلَغَ أَمَدَهُ</span> <em>He,</em> or <em>it, reached,</em> or <em>attained, his,</em> or <em>its, utmost,</em> or <em>extreme, extent, term,</em>, &amp;c. <span class="auth">(Mṣb.)</span> And <span class="ar long">ضَرَبَ لَهُ أَمَدًا</span> <span class="add">[<em>He assigned,</em> or <em>appointed, for him,</em> or <em>it, a term,</em> or <em>limit</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">هُوَ بَعِيدُ الآمَادِ</span> <span class="add">[<em>He is one whose limits are remote:</em> <span class="ar">آمَادٌ</span> being the pl.]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امد</span> - Entry: <span class="ar">أَمَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OamadN_A2">
					<p>The <em>period of life which one has reached;</em> as in the saying, <span class="ar long">مَا أَمَدُكَ</span> <em>What is thy period of life which thou hast reached?</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امد</span> - Entry: <span class="ar">أَمَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OamadN_A3">
					<p><em>Each of the two terms of the life</em> of a man; i. e. the <em>time of</em> his <em>birth,</em> and the <em>time of</em> his <em>death.</em> <span class="auth">(Sh, T.)</span> El-Ḥasan <span class="add">[El-Basree]</span>, being asked by El-Hajjáj, <span class="ar long">مَا أَمَدُكَ</span>, meaning <em>What was the time of thy birth?</em> answered by saying that it was two years before the expiration of ʼOmar's reign as Khaleefeh. <span class="auth">(T, L, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امد</span> - Entry: <span class="ar">أَمَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OamadN_A4">
					<p>The <em>startingplace,</em> and the <em>goal,</em> of horses in a race. <span class="auth">(Sh, T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امد</span> - Entry: <span class="ar">أَمَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OamadN_A5">
					<p>‡ <em>Any space of time:</em> <span class="auth">(Er-Rághib:)</span> <em>a space of time of unknown limit.</em> <span class="auth">(Kull pp. 9 and 10.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امد</span> - Entry: <span class="ar">أَمَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OamadN_A6">
					<p>Sometimes, † <em>A particular time;</em> as in the phrase <span class="ar long">أَمَدُ كَذَا</span> <em>The time of such a thing;</em> like <span class="ar long">زَمَانُ أَمَدٌ</span>. <span class="auth">(Kull p. 10.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">امد</span> - Entry: <span class="ar">أَمَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OamadN_A7">
					<p><span class="add">[It is also used for <span class="ar long">ذو أَمَدٌ</span>, and <span class="auth">(applied to a fem. n.)</span> <span class="ar long">ذَات أَمَدٍ</span>, <em>Having a term,</em> or <em>limit; limited in duration;</em> as in the saying,]</span> <span class="ar long">الدُّنْيَا أَمَدٌ والآخِرةُ أَبَدٌ</span> <span class="add">[<em>The present state of existence is limited in duration, but the final state of existence is everlasting</em>]</span>. <span class="auth">(ʼObeyd Ibn-ʼOmeyr, L in art. <span class="ar">ابد</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumodapN">
				<h3 class="entry"><span class="ar">أُمْدَةٌ</span></h3>
				<div class="sense" id="OumodapN_A1">
					<p><span class="ar">أُمْدَةٌ</span> <em>A remainder,</em> or <em>what remains,</em> <span class="auth">(Ḳ,)</span> of anything. <span class="auth">(TA)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWamBadN">
				<h3 class="entry"><span class="ar">مُؤَمَّدٌ</span></h3>
				<div class="sense" id="muWamBadN_A1">
					<p><span class="ar long">سِقَآءٌ مُؤَمَّدٌ</span> <em>A skin</em> <span class="add">[<em>exhausted;</em>]</span> <em>in which there remains not a gulp,</em> or <em>as much as is swallowed at once, of water.</em> <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOomuwdN">
				<h3 class="entry"><span class="ar">مَأْمُودٌ</span></h3>
				<div class="sense" id="maOomuwdN_A1">
					<p><span class="ar long">أَمَدٌ مَأْمُودٌ</span> <em>An extreme term, limit,</em> or <em>point, reached,</em> or <em>attained.</em> <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0095.pdf" target="pdf">
							<span>Lanes Lexicon Page 95</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
