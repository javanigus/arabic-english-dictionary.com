<article class="root" id="Root_Awz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/158_Awd">اود</a></span>
				<span class="ar">اوز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/160_Aws">اوس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="IiwazBN">
				<h3 class="entry"><span class="ar">إِوَزٌّ</span> / <span class="ar">إِوَزَّةٌ</span></h3>
				<div class="sense" id="IiwazBN_A1">
					<p><span class="ar">إِوَزٌّ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">إِوَزَّةٌ</span>, <span class="auth">(Ṣ,)</span> or the latter is the n. un. of the former, <span class="add">[which is a coll. gen. n.,]</span> <span class="auth">(Mṣb,)</span> <em>i. q.</em> <span class="ar">بَطٌّ</span> <span class="add">[The <em>goose,</em> or <em>geese;</em> and the <em>duck,</em> or <em>ducks;</em> but <span class="ar">اوزّ</span> is generally applied to the former of these birds; and <span class="ar">بطّ</span>, to the latter; agreeably with a statement in the Jm, that <span class="ar">بَطٌّ</span> is applied by the Arabs to the <em>small,</em> and <span class="ar">إِوَزٌّ</span> to the <em>large</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> as also <span class="ar">وَزٌّ</span>, of which the n. un. is <span class="ar">وَزَّةٌ</span>: <span class="auth">(Mṣb:)</span> <span class="ar">إِوَزٌّ</span> is of the measure <span class="ar">فِعَلٌّ</span>: <span class="auth">(Mṣb:)</span> <span class="add">[but see what follows:]</span> the pl. is <span class="ar">إِوَزُّونَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> a form which is sometimes used, <span class="auth">(Ṣ, Mṣb,)</span> and which is anomalous. <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#kurokieBN">See also <span class="ar">كُرْكِىٌّ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوز</span> - Entry: <span class="ar">إِوَزٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiwazBN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">إِوَزٌّ</span> also signifies † <em>Short and thick:</em> <span class="auth">(Ḳ:)</span> <em>fleshy without being tall:</em> <span class="auth">(Lth, TA:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">إِوَزَّةٌ</span>}</span></add>. <span class="auth">(TA.)</span> El-'Okberee asserts that the <span class="ar">أ</span> is augmentative, because it is followed by three radical letters: <span class="auth">(MF, TA:)</span> but ISd says that it is of the measure <span class="ar">فِعَلٌّ</span>, and may not be of the measure <span class="ar">إِفْعَلٌ</span>, <span class="add">[i. e., originally <span class="ar">إِوْزَزٌ</span>,]</span> because this does not occur as the measure of an epithet. <span class="auth">(TA.)</span> <span class="add">[It seems, however, that <span class="ar">اوزّ</span> is in this case a subst. used tropically as an epithet, after the manner of many nicknames.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوز</span> - Entry: <span class="ar">إِوَزٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiwazBN_A3">
					<p>Also, applied to a man, and to a horse, and to a camel, <em>Firm in make:</em> <span class="auth">(AḤei in the Expos. of the Tes-heel, and TA:)</span> or, applied to a horse, <em>compact and strong in make.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiwazBae">
				<h3 class="entry"><span class="ar">إِوَزَّى</span></h3>
				<div class="sense" id="IiwazBae_A1">
					<p><span class="ar">إِوَزَّى</span> <em>A manner of walking in which is a moving up and down:</em> or <em>leaning on one side;</em> <span class="auth">(Ḳ;)</span> <span class="add">[the latter omitted in the CK;]</span> <em>at one time on the right and at another on the left</em> <span class="add">[<em>like a goose or duck</em>]</span>: <span class="auth">(TA:)</span> and the <em>walk of a sprightly horse.</em> <span class="auth">(TA.)</span> Az says that it may be of the measure <span class="ar">إِفْعَلَى</span>, <span class="add">[i. e., originally <span class="ar">إِوْزَزَّى</span>,]</span> or <span class="ar">فِعَلَّى</span>; but Abu-l-Ḥasan holds the latter to be the more correct, because it is the measure of many words relating to walking; as <span class="ar">جِيَضَّى</span>, and <span class="ar">دِفَقَّى</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOowazapN">
				<h3 class="entry"><span class="ar">مَأْوَزَةٌ</span></h3>
				<div class="sense" id="maOowazapN_A1">
					<p><span class="ar long">أَرْضٌ مَأْوَزَةٌ</span> <em>A land abounding with the birds called</em> <span class="ar">إِوَزّ</span>. <span class="auth">(Ṣgh, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0125.pdf" target="pdf">
							<span>Lanes Lexicon Page 125</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
