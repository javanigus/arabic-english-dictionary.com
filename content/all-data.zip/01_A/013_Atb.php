<article class="root" id="Root_Atb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/012_Abe">ابى</a></span>
				<span class="ar">اتب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/014_Atm">اتم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Atb_2">
				<h3 class="entry">2. ⇒ <span class="ar">أتّب</span></h3>
				<div class="sense" id="Atb_2_A1">
					<p><span class="ar long">أَتَّبَهَا إِتْبًا</span>, <span class="auth">(M, Ḳ, <span class="add">[but in the latter the pronoun is masc.,]</span>)</span> and <span class="ar">بِإتْبٍ</span>, <span class="auth">(M,)</span> or simply <span class="ar">أتّبها</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">تَأْتِيبٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He put on her,</em> or <em>clad her with, an</em> <span class="ar">إِتْب</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> or <span class="ar">أتّبها</span> signifies <em>he put on her,</em> or <em>clad her with, a shift.</em> <span class="auth">(AZ, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Atb_2_A2">
					<p><span class="ar">أُتِّبَ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. as above, <span class="auth">(Ḳ,)</span> <em>It</em> <span class="auth">(a garment, or piece of cloth,)</span> <em>was made into an</em> <span class="ar">اتْب</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Atb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأتّب</span></h3>
				<div class="sense" id="Atb_5_A1">
					<p><span class="ar long">تأتّب بِإِتْبٍ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">ائتتب↓</span></span>, <span class="add">[written with the disjunctive alif <span class="ar">اِيتَتَبَ</span>]</span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">ائتبّ↓</span></span>, <span class="auth">(Ḳ, <span class="add">[but this I think a mistranscription,]</span>)</span> <em>He put on himself,</em> or <em>clad himself with, an</em> <span class="ar">إِتْب</span>: <span class="auth">(M, Ḳ:)</span> or<span class="arrow"><span class="ar">ائتتبت↓</span></span>, alone, <em>she put on herself,</em> or <em>clad herself with, an</em> <span class="ar">إِتْب</span>. <span class="auth">(AZ, T, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتب</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Atb_5_A2">
					<p><span class="ar long">تأتّب الدِّرْعَ وَالسِّلَاحَ</span> † <em>He put on</em> <span class="auth">(i. e. on himself)</span> <em>the coat of mail, and the arms,</em> or <em>weapons.</em> <span class="auth">(A.)</span> And <span class="ar long">تأتّب القَوْسَ</span> † <em>He put forth his shoulderjoints from the belt of the bow,</em> <span class="add">[<em>the belt being across his breast,</em>]</span> <em>so that the bow was on his shoulder-blades:</em> <span class="auth">(A:)</span> accord. to AḤn, <span class="auth">(M,)</span> <span class="ar">تَأَتُّبٌ</span> signifies † a man's <em>putting the suspensory of the bow across the breast, and putting forth the shoulder-joints from it,</em> <span class="auth">(M, Ḳ,)</span> <em>so that the bow is on the shoulder-joints:</em> <span class="auth">(M:)</span> and you say also, <span class="ar long">تأتّب قَوْسَهُ عَلَى ظَهْرِه</span> † <span class="add">[<em>he put his bow in the manner above described upon his back</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتب</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Atb_5_A3">
					<p><span class="add">[And hence,]</span> <span class="ar">تأتّب</span> signifies also † <em>He prepared himself,</em> or <em>made himself ready,</em> <span class="auth">(Ḳ,)</span> <span class="ar">لِلأَمْرِ</span> <span class="add">[<em>for the affair</em>]</span>. <span class="auth">(TḲ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتب</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Atb_5_A4">
					<p>And † <em>He acted,</em> or <em>behaved, with forced hardness, firmness, strength, hardiness, courage,</em> or <em>vehemence.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Atb_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتتب</span></h3>
				<div class="sense" id="Atb_8_A1">
					<p><a href="#Atb_5">see 5</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Atb_9">
				<h3 class="entry">9. ⇒ <span class="ar">ائتبّ</span></h3>
				<div class="sense" id="Atb_9_A1">
					<p><a href="#Atb_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IitobN">
				<h3 class="entry"><span class="ar">إِتْبٌ</span></h3>
				<div class="sense" id="IitobN_A1">
					<p><span class="ar">إِتْبٌ</span> <span class="auth">(T, Ṣ, M, A, Ḳ)</span> and<span class="arrow"><span class="ar">مِئْتَبَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <em>A</em> <span class="ar">بَقِير</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">بَقِيرَة</span>, <span class="auth">(M, Ḳ,)</span> i. e., <span class="auth">(Ṣ, M, <span class="add">[but in the Ḳ what here follows is given as a meaning distinct from <a href="#bqyrp">that of <span class="ar">بقيرة</span></a>,]</span>)</span> <em>a</em> <span class="ar">بُرْد</span> <span class="add">[q. v.]</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> or <em>piece of cloth,</em> <span class="auth">(Ṣ, A,)</span> <em>which is slit</em> <span class="auth">(Ṣ, M, A, Ḳ)</span> <em>in the middle,</em> <span class="auth">(Ṣ,)</span> <em>and worn by a woman,</em> <span class="auth">(A, Ḳ,)</span> <em>who throws it upon her neck,</em> <span class="auth">(Ṣ, M,)</span> <span class="add">[<em>putting her head through the slit;</em>]</span> <em>having neither an opening at the bosom</em> <span class="auth">(a <span class="ar">جَيْب</span>)</span>, <em>nor sleeves:</em> <span class="auth">(Ṣ, M, A, Ḳ:)</span> and <em>a woman's shift:</em> <span class="auth">(T, M, Ḳ:)</span> and, <span class="auth">(Ḳ,)</span> or accord. to some, <span class="auth">(M,)</span> <em>a garment that is short, reaching half-way down the shank:</em> <span class="auth">(M, Ḳ:)</span> or <span class="add">[<em>a garment like</em>]</span> <em>drawers,</em> or <em>trousers, without legs;</em> <span class="auth">(M, Ḳ;)</span> <em>i. q.</em> <span class="ar">نُقْبَهٌ</span>: <span class="auth">(M:)</span> or <em>a shirt without sleeves,</em> <span class="auth">(Ṣ voce <span class="ar">بَقِيرٌ</span>, M, Ḳ,)</span> <em>worn by women:</em> <span class="auth">(Ṣ ubi suprà:)</span> the first explanation alone is given in most lexicons: <span class="auth">(TA:)</span> some say that <em>it is different from the</em> <span class="ar">إِزَار</span>; that it <em>has no band like that of drawers</em> or <em>trousers, and is not sewed together after the manner of drawers</em> or <em>trousers, but is a shirt of which the two sides are not sewed together:</em> <span class="auth">(M:)</span> or <em>i. q.</em> <span class="ar">عِلْقَةٌ</span> and <span class="ar">صِدَارٌ</span> and <span class="ar">شَوْذَرٌ</span>; all signifying one and the same thing: <span class="auth">(T:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">آتَابٌ</span> <span class="auth">(M, Ḳ <span class="add">[in the CK and a MṢ. copy of the Ḳ written <span class="ar">اَتابٌ</span>]</span>)</span> <span class="add">[originally <span class="ar">أَأْتَابٌ</span> which is mentioned as one of the pls. by MF]</span> and <span class="ar">آتُبٌ</span> <span class="add">[originally <span class="ar">أَأْتُبٌ</span> which is also mentioned as one of the pls. by MF]</span> and by transposition <span class="ar">أَتْؤُبٌ</span>, <span class="auth">(MF,)</span> and <span class="add">[of mult.]</span> <span class="ar">أُتُوبٌ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">إِتَابٌ</span>, <span class="auth">(M,)</span> or both. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتب</span> - Entry: <span class="ar">إِتْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IitobN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">إتْبٌ</span> also signifies † The <em>husk</em> of barley. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYotabN">
				<h3 class="entry"><span class="ar">مِئْتَبٌ</span></h3>
				<div class="sense" id="miYotabN_A1">
					<p><span class="ar">مِئْتَبٌ</span> <em>A</em> <span class="add">[<em>wrapper,</em> or <em>wrapping garment, such as is called</em>]</span> <span class="ar">مِشْمَلٌ</span>. <span class="auth">(T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miYotabapN">
				<h3 class="entry"><span class="ar">مِئْتَبَةٌ</span></h3>
				<div class="sense" id="miYotabapN_A1">
					<p><span class="ar">مِئْتَبَةٌ</span>: <a href="#IitobN">see <span class="ar">إِتْبٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWatBabu">
				<h3 class="entry"><span class="ar">مُؤَتَّبُ</span></h3>
				<div class="sense" id="muWatBabu_A1">
					<p><span class="ar long">مُؤَتَّبُ الظُّفُرِ</span> † A man <em>whose nail is crooked.</em> <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0013.pdf" target="pdf">
							<span>Lanes Lexicon Page 13</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
