<article class="root" id="Root_Ayn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/180_Aym">ايم</a></span>
				<span class="ar">اين</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/182_Ayh">ايه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ayn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أين</span> ⇒ <span class="ar">آن</span></h3>
				<div class="sense" id="Ayn_1_A1">
					<p><span class="ar">آنَ</span>, <span class="add">[aor. <span class="ar">يَئِينُ</span>,]</span> inf. n. <span class="ar">أَيْنٌ</span>, <span class="add">[in a copy of the Mṣb, <span class="ar">أَيِنَ</span>, aor. <span class="ar">يَاءَنُ</span>, inf. n. <span class="ar">أَيَنٌ</span>, but as this is at variance with all other authorities known to me, I regard it as a mistranscription,]</span> <em>He was,</em> or <em>became, fatigued,</em> or <em>tired:</em> <span class="auth">(T, M:)</span> so says IAạr: <span class="auth">(T:)</span> and Aṣ says the like: <span class="auth">(TA, from a marginal note in a copy of the Ṣ:)</span> <span class="add">[see also what I have cited from the Mughnee voce <span class="ar">إِنَّ</span>, last sentence:]</span> in proof of this, IAạr cites the following ex., from a poet:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">إِنَّا وَرَبِّ القُلُصِ الضَّوَامِرِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>We were,</em> or <em>have become, fatigued, by the Lord of the lean and lank-bellied youthful she-camels</em>]</span>: but Lth says that there is no verb derived from <span class="ar">أَيْنٌ</span>, in this sense, except in poetry: <span class="auth">(T:)</span> Aboo-Moḥammad says that the only instance is that cited above: <span class="auth">(TA:)</span> <span class="add">[it is not disputed that]</span> <span class="ar">أَيْنٌ</span> signifies <em>fatigue,</em> or the <em>being fatigued</em> or <em>tired:</em> <span class="auth">(Ṣ, Ḳ:)</span> AZ says that it has no verb formed from it; but on this point he has been contradicted: <span class="auth">(Ṣ:)</span> AʼObeyd also says that it has no verb. <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اين</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ayn_1_B1">
					<p><span class="ar">آنَ</span>, aor. <span class="ar">يَئِينُ</span>, inf. n. <span class="ar">أَيْنٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ, &amp;c., <span class="add">[but see what follows,]</span>)</span> also signifies <em>Its time came;</em> (<span class="ar long">أَتَى وَقْتُهُ</span>;) as also <span class="ar">أَنَى</span>: <span class="auth">(Bḍ lvii. 15:)</span> <em>it was,</em> or <em>became, present: it came,</em> or <em>attained, to its time; to its full,</em> or <em>final, time,</em> or <em>state; to maturity: it was,</em> or <em>became,</em> or <em>drew, near:</em> syn. <span class="ar">أَنَى</span>: <span class="auth">(M:)</span> and <span class="ar">أَدْرَكَ</span>; like <span class="ar">أَنَى</span>: <span class="auth">(Ḥam p. 455:)</span> and <span class="ar">حَانَ</span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> and <span class="ar">قَرُبَ</span>. <span class="auth">(Mughnee voce <span class="ar">إِنَّ</span>.)</span> You say, <span class="ar long">آنَ لَكَ أَنْ تَفْعَلَ كَذَا</span>, aor. and inf. n. as above, <span class="auth">(AZ, Ṣ,)</span> i. e. <span class="ar">حَانَ</span> <span class="add">[<em>The time has come,</em> or <em>has drawn near, for thee to do,</em> or <em>that thou shouldst do, such a thing</em>]</span>; like <span class="ar">أَنَى</span>: and it is formed from it by transposition: <span class="auth">(Ṣ:)</span> <span class="add">[i. e.]</span> <span class="ar">أَنَى</span> is formed by transposition from <span class="ar">آنَ</span>: <span class="auth">(Mṣb:)</span> or <span class="ar">آنَ</span> <a href="#Oanae">is a dial. var. of <span class="ar">أَنَى</span></a>; not formed from it by transposition, <span class="add">[nor is the reverse the case,]</span> because of the existence of the inf. n. <span class="add">[of each]</span>: <span class="auth">(M:)</span> or <span class="ar">آنَ</span> is formed by transposition from <span class="ar">أَنَى</span>, because the latter has an inf. n. and the former has not: so says Aṣ: for <span class="ar">أَيْنٌ</span> does not belong to this; its meaning being only <span class="ar">إِعْيَآءٌ</span> and <span class="ar">تَعَبٌ</span>: or, accord. to AZ, <span class="ar">آنَ</span> has an inf. n., namely <span class="ar">أَيْنٌ</span>; and if the case be so, the two <span class="add">[verbs]</span> are equal; neither being the original of the other: <span class="auth">(IJ in the Khasáïs:)</span> Suh, in the R, asserts that <span class="ar">آنَ</span> is formed by transposition from <span class="ar">أَنَى</span>: <span class="auth">(TA:)</span> the assertion of El-Bekree, that <span class="ar">آنَ</span> is originally with <span class="ar">و</span> <span class="add">[for its medial radical letter]</span>, and that it is of the class of <span class="ar">وَلِىَ</span>, aor. <span class="ar">يَلِى</span>, requires consideration, and involves what is contrary to rule. <span class="auth">(MF.)</span> You say also, <span class="ar long">آنَ أَيْنُكَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">إِينُكَ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar">آنُكَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> i. e. <span class="ar long">حَانَ حِينُكَ</span> <span class="add">[<em>Thy time,</em> or <em>season, came,</em> or <em>hath come:</em> or <em>drew near,</em> or <em>hath drawn near</em>]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MnN">
				<h3 class="entry"><span class="ar">آنٌ</span></h3>
				<div class="sense" id="MnN_A1">
					<p><span class="ar">آنٌ</span>: <a href="#OaYonN">see <span class="ar">أَيْنٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اين</span> - Entry: <span class="ar">آنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MnN_A2">
					<p><span class="ar">ٱلْآنَ</span> is a noun denoting the present time; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> <span class="add">[signifying <em>At the present time; now;</em> for]</span> it is an adverbial noun; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> one which, in a place where it is fitting to be used as such, may not be used otherwise; occurring in a determinate sense; <span class="auth">(Ṣ, Ḳ;)</span> the <span class="ar">ال</span> being inseparable from it; <span class="auth">(IJ, M, Mṣb;)</span> not prefixed to it for the purpose of rendering it determinate, because it has not that which participates in its meaning: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> as Ibn-Es-Sarráj says, there is not one <span class="ar">آن</span> and another <span class="ar">آن</span>: <span class="auth">(Mṣb:)</span> <span class="add">[accord. to ISd, who quotes a long disquisition by IJ on this word,]</span> the <span class="ar">ال</span> which is expressed in this case is redundant, because the noun is determinate without it, but it is rendered so by another <span class="ar">ال</span>, which is understood, as in the case of <span class="ar">أَمْسِ</span>: so says IJ, following Aboo-ʼAlee; and his is the correct opinion: <span class="auth">(M:)</span> Fr says that it is a particle, compounded with <span class="ar">ال</span>, which is inseparable from it; and that it is originally <span class="ar">أَوَانَ</span> <span class="add">[or <span class="ar">ٱلْأَوَانَ</span>]</span>: or that it may have originated from the phrase <span class="ar long">آنَ لَكَ أَنْ تَفْعَلَ</span> <span class="add">[explained above]</span>, and is therefore mansoob, like <span class="ar">قِيلَ</span> and <span class="ar">قَالَ</span> when used as nouns: but Zj disallows its originating from <span class="ar">آنَ</span>; and says that the right opinion is that of Kh, that <span class="ar">ٱلْآنَ</span> is indecl. with fet-ḥ for its termination, and that the <span class="ar">ال</span> is prefixed because the meaning is <span class="ar long">هٰذَا الوَقْت</span>; and this is the opinion of Sb. <span class="auth">(T.)</span> You say, <span class="ar long">أَنَا ٱلْآنَ أَفْعَلُ كَذَا</span> <span class="add">[<em>I, at the present time,</em> or <em>now, do,</em> or <em>will do, thus,</em> or <em>such a thing</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">كُنْتُ ٱلْآنَ عِنْدَهُ</span>, meaning <em>I was, in this time, of which part is present and some portions have passed, with him,</em> or <em>in his presence.</em> <span class="auth">(IJ, M.)</span> And when you mean the kind of expression which is used in this saying, you say, <span class="ar long">اَلْآنُ حَدُّ الزَّمَانَيْنِ</span> <span class="add">[<em>The term “now” is the limit of the two times;</em> namely the past and the future]</span>; thus pronounced, marfooa: so says IJ: but in the Book of Sb we read, <span class="ar long">الآنَ حَدُّ الزَّمَانَيْنِ</span>, with nasb: and in like manner, in the same, <span class="ar long">الآنَ آنُكَ</span> <span class="add">[<em>Now is thy time</em>]</span>; the former with nasb and the latter with refa. <span class="auth">(M.)</span> <span class="pb" id="Page_0139"></span>You say also, <span class="ar long">هٰذَا أَوَانُ ٱلْآنَ</span> <span class="add">[<em>This is the present time</em>]</span>: and <span class="ar long">مَا جِئْتُ إِلَّا أَوَانَ ٱلْآنَ</span>, meaning <em>I came not save at the present time,</em> or <em>now:</em> with the last word mansoob in both instances. <span class="auth">(ISh, T.)</span> <span class="add">[And <span class="ar long">إِلَى ٱلْآنَ</span> and <span class="ar long">حَتَّى ٱلْآنَ</span> <em>To the present time</em> and <em>until the present time;</em> i. e. <em>hitherto.</em> And <span class="ar long">مِنَ ٱلْآنَ</span> <em>From the present time; henceforward.</em>]</span> Sometimes the hemzeh <span class="add">[after the <span class="ar">ل</span>]</span> is suppressed, and its vowel is transferred to the <span class="ar">ل</span>; so that you say <span class="ar">الَانَ</span>. <span class="auth">(Bḍ ii. 66.)</span> And sometimes also the <span class="ar">ل</span> is pronounced with fet-ḥ and both the hemzehs are suppressed; so that you say <span class="ar">لَانَ</span>. <span class="auth">(Ṣ, Ḳ.)</span> And sometimes <span class="ar">تَ</span> is prefixed to it, like as it is to <span class="ar">حِينَ</span>; so that you say <span class="ar">تَلَانَ</span>, like as you say <span class="ar">تَحِينَ</span>. <span class="auth">(El-Umawee, AʼObeyd. <span class="add">[<a href="../">See art. <span class="ar">تلن</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayonN">
				<h3 class="entry"><span class="ar">أَيْنٌ</span></h3>
				<div class="sense" id="OayonN_A1">
					<p><span class="ar">أَيْنٌ</span> <em>Fatigue.</em> <span class="auth">(Ṣ, Ḳ, &amp;c.)</span> <span class="add">[Whether it be a simple subst., or an inf. n., and, if the latter, whether it be an inf. n. of <span class="ar">آنَ</span> only in the former of the two senses assigned to that verb above, or in both these senses, is doubted: <a href="#Ayn_1">see 1</a>, throughout.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اين</span> - Entry: <span class="ar">أَيْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OayonN_B1">
					<p><em>A time; a season;</em> syn. <span class="ar">حِينٌ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِينٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">آنٌ↓</span></span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<a href="#Ayn_1">See 1</a>, last sentence.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oayona">
				<h3 class="entry"><span class="ar">أَيْنَ</span></h3>
				<div class="sense" id="Oayona_A1">
					<p><span class="ar">أَيْنَ</span> is an adverbial noun, <span class="auth">(Mṣb,)</span> an interrogative respecting a place: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> <span class="add">[signifying <em>Where? in what place?</em>]</span>: Zj says that it is an interrogative particle, like <span class="ar">كَيْفَ</span>: <span class="auth">(T:)</span> <span class="add">[ISd says,]</span> it is a noun, because you say, <span class="ar long">مِنْ أَيْنَ</span> <span class="add">[meaning <em>From what place? whence?</em>]</span>: <span class="auth">(M:)</span> <span class="add">[and you say also, <span class="ar long">إِلَى أَيْنَ</span> <em>To what place? whither?</em>]</span>: it is always mansoob, unless you prefix the article to it, saying <span class="ar">الأَيْنُ</span> <span class="add">[which means <em>The place where</em>]</span>: <span class="auth">(Lth, T:)</span> it is fem.; but may be made masc. <span class="auth">(Lḥ, M.)</span> You say, <span class="ar long">أَيْنَ زَيْدٌ</span> <em>Where,</em> or <em>in what place, is Zeyd?</em> <span class="auth">(Ṣ, Mṣb.)</span> And <span class="ar long">أَيْنَ بَيْتُكَ</span> <span class="add">[<em>Where is thy house,</em> or <em>tent?</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">أَيْنَ يُذْهَبُ بِكَ</span>, which may mean <em>Where,</em> or <em>whither, wilt thou be taken away, and what will be done with thee and made to come to pass with thee,</em> if this be thine intellect? or, accord. to Mṭr, it is a saying of the people of Baghdád, addressed to him whom they charge with foolish judgment or opinion, as meaning <span class="ar long">أَيْنَ يُذْهَبُ بِعَقْلِكَ</span> <span class="add">[<em>Where,</em> or <em>whither, is thine intellect taken away?</em>]</span>. <span class="auth">(Ḥar p. 574.)</span> <span class="add">[And <span class="ar long">أَيْنَ هٰذَا مِنْ ذَاكَ</span> and <span class="ar long">عَنْ ذَاكَ</span> and <span class="ar">وَذَاكَ</span> <em>What place does this hold in relation to that,</em> or <em>in comparison with that? what is this in relation to that,</em> or <em>in comparison with that? what has this to do with that? what has this in common with that?</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اين</span> - Entry: <span class="ar">أَيْنَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Oayona_A2">
					<p>It also denotes a condition: when you say, <span class="ar long">أَيْنَ تَجْلِسْ أَجْلِسْ</span> <span class="add">[<em>Where thou sittest, I will sit</em>]</span>, the sitting must be in one place: and <span class="ar">مَا</span> is added to it; so that you say, <span class="ar long">أَيْنَمَا تَقُمْ أَقُمْ</span> <span class="add">[<em>Wherever thou standest, I will stand</em>]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اين</span> - Entry: <span class="ar">أَيْنَ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Oayona_A3">
					<p>It also occurs used as a proper name of a particular place: thus the poet Homeyd Ibn-Thowr speaks of his companions as being <span class="ar long">بِأَيْنَ وَأَيْنَمَا</span> <span class="add">[app. meaning <em>In certain places: where and wherever those places were,</em> there were my companions]</span>: in which case it is divested of the meaning of an interrogative, and is imperfectly decl. because determinate and of the fem. gender. <span class="auth">(M, L. <span class="add">[In one copy of the former, <span class="ar long">بِأَنَّى وَأَيْنَمَا</span>, which may mean the same; and voce <span class="ar">أَىٌّ</span>, q. v., <span class="ar long">بِأَىَّ وَأَيْنَمَا</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiynN">
				<h3 class="entry"><span class="ar">إِينٌ</span></h3>
				<div class="sense" id="IiynN_A1">
					<p><span class="ar">إِينٌ</span>: <a href="#OaYonN">see <span class="ar">أَيْنٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBaAna.1">
				<h3 class="entry"><span class="ar">أَيَّانَ</span></h3>
				<div class="sense" id="OayBaAna.1_A1">
					<p><span class="ar">أَيَّانَ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> of the measure <span class="ar">فَعَّال</span>, or it may be of the measure <span class="ar">فَعْلَان</span>, <span class="auth">(Mṣb,)</span> also pronounced <span class="arrow"><span class="ar">إِيَّانَ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> the latter of the dial. of Suleym, mentioned by Fr, <span class="auth">(T, Ṣ,)</span> and by Zj, <span class="auth">(M,)</span> is an interrogative respecting a time, <span class="auth">(T, Ṣ, Mṣb,)</span> but only respecting a time not come: <span class="auth">(T:)</span> signifying <em>When?</em> <span class="auth">(Ṣ, M, Mṣb;)</span> <em>at what time?</em> <span class="auth">(Mṣb, Ḳ:)</span> it is fem.; but may be made masc.: <span class="auth">(Lḥ, M:)</span> and it may be pronounced with imáleh, though not belonging to a class of words regularly subject to imáleh. <span class="auth">(TA.)</span> It is said in the Ḳur <span class="add">[xvi. 22 and xxvii. 67]</span>, accord. to different readings, <span class="ar long">أَيَّانَ يُبْعَثُونَ</span> or<span class="arrow"><span class="ar">إِيَّانِ↓</span></span> <span class="add">[<em>When they shall be raised to life</em>]</span>; <span class="auth">(T, Ṣ, M;)</span> i. e. when shall be the resurrection. <span class="auth">(Aboo-Is-ḥáḳ, T.)</span> But you may not say, <span class="ar long">أَيَّانَ فَعَلْتَ ذَاكَ</span> as meaning <em>When didst thou that?</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اين</span> - Entry: <span class="ar">أَيَّانَ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OayBaAna.1_A2">
					<p>IJ says that, were it syn. with <span class="ar">مَتَى</span>, it would be conditional; whereas it was not mentioned by his colleagues among the adverbs used conditionally, as <span class="ar">مَتَى</span> and <span class="ar">أَيْنَ</span>, &amp;c.: but sometimes it has a conditional meaning, though that meaning be not explicit. <span class="auth">(M.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَيَّانَ نُؤْمِنْكَ تَأْمَنْ غَيْرَنَا وَإِذَا</span> *</div> 
						<div class="star">* <span class="ar long">لَمْ تُدْرِكِ الأَمْنَ مِنَّا لَمْ تَزَلْ حَذِرَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>When we grant thee security, thou wilt be secure from others than us; and when thou obtainest not security from us, thou wilt not cease to be in a state of fear</em>]</span>. <span class="auth">(I’Aḳ p. 300.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyBaAna">
				<h3 class="entry"><span class="ar">إِيَّانَ</span></h3>
				<div class="sense" id="IiyBaAna_A1">
					<p><span class="ar">إِيَّانَ</span>: <a href="#OayBaAna">see <span class="ar">أَيَّانَ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MYinN.1">
				<h3 class="entry"><span class="ar">آئِنٌ</span></h3>
				<div class="sense" id="MYinN.1_A1">
					<p><span class="ar">آئِنٌ</span> part. n. of <span class="ar">آنَ</span> in both its senses.</p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MyinapN">
				<h3 class="entry"><span class="ar">آيِنَةٌ</span></h3>
				<div class="sense" id="MyinapN_A1">
					<p><span class="ar">آيِنَةٌ</span>: <a href="#OawaAnN">see <span class="ar">أَوَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0138.pdf" target="pdf">
							<span>Lanes Lexicon Page 138</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0139.pdf" target="pdf">
							<span>Lanes Lexicon Page 139</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
