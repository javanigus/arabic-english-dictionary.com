<article class="root" id="Root_Afx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/101_Af">اف</a></span>
				<span class="ar">افخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/103_Afq">افق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Afx_1">
				<h3 class="entry">1. ⇒ <span class="ar">أفخ</span></h3>
				<div class="sense" id="Afx_1_A1">
					<p><span class="ar">أَفَخَهُ</span>, <span class="auth">(AʼObeyd, Ṣ, L, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْفِخُ</span>}</span></add>, inf. n. <span class="ar">أَفْخٌ</span>, <span class="auth">(L,)</span> <em>He,</em> <span class="add">[or <em>it</em>]</span> <em>struck him,</em> or <em>hit him,</em> <span class="add">[or <em>hurt him,</em>]</span> <em>on the part of his head called the</em> <span class="ar">يَأْفُوخ</span>. <span class="auth">(AʼObeyd, Ṣ, L, Mṣb, Ḳ.)</span> He who pronounces <span class="ar">يافوخ</span> without <span class="ar">ء</span> says <span class="ar">يَفَخَهُ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOofuwxN">
				<h3 class="entry"><span class="ar">مَأْفُوخٌ</span></h3>
				<div class="sense" id="maOofuwxN_A1">
					<p><span class="ar">مَأْفُوخٌ</span> A man <em>having his head broken in the part called the</em> <span class="ar">يَأْفُوخ</span>. <span class="auth">(L.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="yaOofuwxN">
				<h3 class="entry"><span class="ar">يَأْفُوخٌ</span></h3>
				<div class="sense" id="yaOofuwxN_A1">
					<p><span class="ar">يَأْفُوخٌ</span>, <span class="auth">(Lth, Az, Ṣ, Mṣb, Ḳ,)</span> as also <span class="ar">يَافُوخٌ</span>, without <span class="ar">ء</span>, but the former is the more correct and the better, <span class="auth">(Lth, Az, Mṣb,)</span> and is of the measure <span class="ar">يَفْعُولٌ</span>, <span class="auth">(Lth, Az, Ṣ, Mṣb,)</span> whereas the latter is of the measure <span class="ar">فَاعُولٌ</span>, <span class="auth">(Lth, Az, Mṣb,)</span> <span class="add">[The <em>top, vertex,</em> or <em>crown, of the head;</em> or the <em>part of the top of the head which is crossed by the coronal suture, and comprises a portion of the sagittal suture;</em>]</span> the <em>part where the anterior and posterior bones of the head meet;</em> <span class="auth">(Ḳ;)</span> the <em>place that is in a state of commotion in the head of an infant;</em> <span class="auth">(Ṣ;)</span> the <em>place which, in the head of a child, does not close up until after some years;</em> or <em>does not become knit together in its several parts;</em> and this is <em>where the bone of the anterior part of the head and that of its posterior part meet;</em> <span class="auth">(Zj in his “Khalk el-Insán;”)</span> the <em>place that is soft, in a child's head, before the two bones called the</em> <span class="ar">نَمَّاغَة</span> <em>and</em> <span class="ar">رَمَّاعَة</span> <em>meet, between the</em> <span class="ar">هَامَة</span> <span class="add">[or <em>middle of the head</em>]</span> <em>and the forehead:</em> <span class="auth">(L:)</span> or the <em>middle of the head when it has become hard and strong;</em> before which it is not thus called: <span class="auth">(Mṣb:)</span> pl. <span class="ar">يَآفِيخُ</span>; <span class="auth">(Ṣ;)</span> so in the old lexicons <span class="add">[in general]</span>; but in the T and Ḳ <span class="ar">يَوَافِيخُ</span> <span class="add">[which <a href="#yAfwx">is pl. of <span class="ar">يافوخ</span></a> without <span class="ar">ء</span>; or, <a href="#yAfwx">as pl. of <span class="ar">يأفوخ</span></a>, is like <span class="ar">تَوَارِيخُ</span> <a href="#taOoriyxN">as pl. of <span class="ar">تَأْرِيخٌ</span></a>]</span>; and because of this form of the pl., F says that J is in error in mentioning the word in the present art.: it has been shown, however, that J is not in error in this case. <span class="auth">(TA.)</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افخ</span> - Entry: <span class="ar">يَأْفُوخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="yaOofuwxN_A2">
					<p><span class="add">[Hence the saying,]</span> <span class="ar long">أَنْتُمْ يَآفِيخُ الشَّرَفِ</span> ‡ <em>Ye are the centres and summits of the heads of nobility.</em> <span class="auth">(L, from a trad.)</span> And <span class="ar long">يَأْفُوخُ اللَّيْلِ</span> † <em>The main</em> <span class="add">[or <em>middle</em>]</span> <em>part of the night.</em> <span class="auth">(Ṣ, Ḳ.)</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">افخ</span> - Entry: <span class="ar">يَأْفُوخٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="yaOofuwxN_A3">
					<p><span class="add">[<a href="index.php?data=28_e/019_yfx">See also art. <span class="ar">يفخ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0068.pdf" target="pdf">
							<span>Lanes Lexicon Page 68</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
