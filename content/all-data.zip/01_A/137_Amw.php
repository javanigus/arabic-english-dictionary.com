<article class="root" id="Root_Amw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/136_Amh">امه</a></span>
				<span class="ar">امو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/138_An">ان</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Amw_1">
				<h3 class="entry">1. ⇒ <span class="ar">أمو</span> ⇒ <span class="ar">أمى</span></h3>
				<div class="sense" id="Amw_1_A1">
					<p><span class="ar">آمَتْ</span>, <span class="auth">(Ṣ,* M, Ḳ, <span class="add">[in the CK, erroneously, <span class="ar">آمَتْ</span>,]</span>)</span> second pers. <span class="ar">أَمَوْتِ</span>; <span class="auth">(Ṣ;)</span> and <span class="ar">أَمِيَتْ</span>, <span class="auth">(M, Ḳ,)</span> like <span class="ar">سَمِعَتْ</span>; <span class="auth">(Ḳ;)</span> and <span class="ar">أَمُوَتْ</span>, <span class="auth">(Lḥ, M, Ḳ,)</span> like <span class="ar">كَرُمَتٌ</span>; <span class="auth">(Ḳ;)</span> inf. n. <span class="ar">أُمُوَّةٌ</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> <em>She</em> <span class="auth">(a woman)</span> <em>became a slave;</em> <span class="auth">(Ṣ,* M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَأَمَّتْ↓</span></span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amw_1_B1">
					<p><span class="ar long">أَمَتِ السِّنَّوْرُ</span>, aor. <span class="ar">تَأْمُو</span>, inf. n. <span class="ar">أُمَآءٌ</span>, <em>The cat</em> <span class="add">[<em>mewed,</em> or]</span> <em>uttered a cry;</em> <span class="auth">(Ṣ, Ḳ;)</span> like <span class="ar long">مَآءَ تْ</span>, aor. <span class="ar">تَمُوْءُ</span>, inf. n. <span class="ar">مُوَآءٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amw_2">
				<h3 class="entry">2. ⇒ <span class="ar">أمّو</span> ⇒ <span class="ar">أمّى</span></h3>
				<div class="sense" id="Amw_2_A1">
					<p><span class="ar">أَمَّاهَا</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَأْمِيَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>He made her a slave.</em> <span class="auth">(M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأمّو</span> ⇒ <span class="ar">تأمّى</span></h3>
				<div class="sense" id="Amw_5_A1">
					<p><span class="ar">تَأَمَّتْ</span>: <a href="#Amw_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">امو</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Amw_5_B1">
					<p><span class="ar long">تأمّى أَمَةً</span> <em>He took for himself a female slave;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> as also<span class="arrow"><span class="ar">اِسْتَأْمَاهَا↓</span></span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Amw_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتمو</span> ⇒ <span class="ar">ائتمى</span></h3>
				<div class="sense" id="Amw_8_A1">
					<p><span class="ar long">هُوَ يَأْتَمِى بِهِ</span> <em>He follows his</em> <span class="auth">(another person's)</span> <em>example; imitates him; i. q.</em> <span class="ar long">يَأْتَمُّ بِهِ</span> <span class="auth">(TA in the present art.)</span> And <span class="ar long">ائتمى بِالشَّىْءِ</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَمَى</span>]</span> is used for <span class="ar long">ائتَمَّ بِهِ</span> <span class="add">[<em>He made the thing to be a rule of life</em> or <em>conduct</em>]</span>, by substitution <span class="add">[of <span class="ar">ى</span> for <span class="ar">م</span>]</span>, <span class="auth">(M and Ḳ in art. <span class="ar">ام</span>,)</span> the doubling <span class="add">[of the <span class="ar">م</span>]</span> being disapproved. <span class="auth">(M in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Amw_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأمو</span> ⇒ <span class="ar">استأمى</span></h3>
				<div class="sense" id="Amw_10_A1">
					<p><a href="#Amw_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamapN">
				<h3 class="entry"><span class="ar">أَمَةٌ</span></h3>
				<div class="sense" id="OamapN_A1">
					<p><span class="ar">أَمَةٌ</span>, originally <span class="ar">اموة</span>, <span class="auth">(Mṣb,)</span> <span class="add">[but whether <span class="ar">أَمَوَةٌ</span> or <span class="ar">أَمْوَةٌ</span> is disputed, as will be seen in what follows,]</span> <em>A female slave;</em> <span class="auth">(M, Ḳ;)</span> <em>a woman whose condition is that of slavery;</em> <span class="auth">(T;)</span> <em>contr. of</em> <span class="ar">حُرَّةٌ</span>: <span class="auth">(Ṣ:)</span> <span class="add">[in relation to God, best rendered <em>a handmaid:</em>]</span> dual <span class="ar">أَمَتَانِ</span>: <span class="auth">(Mṣb:)</span> pl. <span class="ar">آمٍ</span>, <span class="auth">(Lth, T, Ṣ, M, Mṣb, Ḳ, &amp;c.,)</span> like <span class="ar">قِاضٍ</span>, <span class="auth">(Mṣb,)</span> a pl. of pauc. <span class="add">[respecting which see what follows after the other pls.]</span>, <span class="auth">(Lth, T,)</span> and <span class="ar">إِمَآءٌ</span> <span class="add">[the most common form]</span> <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">إِمْوَانٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أُمْوَانٌ</span> <span class="auth">(Ḳ, and so in some copies of the M)</span> and <span class="ar">أَمْوَانٌ</span> <span class="auth">(Ḳ, and so in some copies of the M)</span> <span class="add">[the last, or last but one, accord. to different copies of the M, on the authority of Lḥ,]</span> and <span class="ar">أَمَوَاتٌ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> for which one may say <span class="ar">أَمَاتٌ</span>. <span class="auth">(Ibn-Keysán, TA.)</span> Accord. to Sb <span class="auth">(M)</span> and Mbr <span class="auth">(TA)</span> it is originally <span class="ar">أَمَوَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> because it has for a pl. <span class="ar">آمٍ</span>, <span class="auth">(Ṣ, M,)</span> which is <span class="add">[originally <span class="ar">أَأْمُوٌ</span>,]</span> of the measure <span class="ar">أَفْعُلٌ</span>, <span class="auth">(Lth, T, Ṣ,)</span> like <span class="ar">آكُمٌ</span>, <a href="#OakamapN">pl. of <span class="ar">أَكَمَةٌ</span></a>, <span class="auth">(Sb, M,)</span> and like <span class="ar">أَيْنُقٌ</span>, <span class="add">[<a href="#naAqpN">pl. of <span class="ar">نَاقةٌ</span></a>, which is originally <span class="ar">نَوَقةٌ</span>,]</span> for a sing. of the measure <span class="ar">فَعْلَةٌ</span> has not a pl. of this form; <span class="auth">(Ṣ;)</span> and Mbr says that there is no noun of two letters but a letter has been dropped from it, which it indicates by its pl. or dual, or by a verb if it is derived therefrom: <span class="auth">(TA:)</span> or it is originally <span class="ar">فَعْلَةٌ</span>: <span class="auth">(AHeyth, T, Ḳ:)</span> AHeyth says that they suppressed its final radical letter, and, forming a pl. from it after the manner of <span class="ar">نَخْلَةٌ</span> and <span class="ar">نَخْلٌ</span>, instead of saying <span class="ar">أَمٌ</span>, which they disliked as being of only two letters, they transposed the suppressed <span class="ar">و</span>, changing it into <span class="ar">ا</span>, and placing it between the <span class="ar">ا</span> and <span class="ar">م</span>. <span class="auth">(T: <span class="add">[in which this opinion, though it does not account for the termination of the pl. <span class="ar">آمٍ</span>, is said to be preferable.]</span>)</span> One says, <span class="ar long">جَآءَ تْنِىً أَمَةُ ٱللّٰهِ</span> <span class="add">[<em>The handmaid of God came to me</em>]</span>: and in the dual, <span class="ar long">جَآءَ تْنِى أمَتَا ٱللّٰهِ</span>: and in the pl., <span class="ar long">جَآءَ نِى إِمَآءُ ٱللّٰهِ</span> and <span class="ar long">إِمْوَانُ ٱللّٰهِ</span> and <span class="ar long">أَمَوَاتُ ٱللّٰهِ</span>; and one may also say, <span class="ar long">أَمَاتُ ٱللّٰه</span>. <span class="auth">(Ibn-Keysán, TA.)</span> <span class="add">[ISd says,]</span> <span class="ar long">وَمَاهُ ٱللّٰهُ مِنْ كُلِّ أَمَةٍ بحَجَرٍ</span> is mentioned by IAạr as said in imprecating evil on a man; but I think it is <span class="ar long">من كلّ أَمْتِ</span> <span class="add">[<em>May God cast a stone at him from every elevated place,</em> or the like]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OamawieBu">
				<h3 class="entry"><span class="ar">أَمَوِىُّ</span></h3>
				<div class="sense" id="OamawieBu_A1">
					<p><span class="ar">أَمَوِىُّ</span> <em>Of,</em> or <em>relating</em> or <em>belonging to, a female slave.</em> <span class="auth">(Ṣ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OumayBapN">
				<h3 class="entry"><span class="ar">أُمَيَّةٌ</span></h3>
				<div class="sense" id="OumayBapN_A1">
					<p><span class="ar">أُمَيَّةٌ</span> <a href="#OamapN">dim. of <span class="ar">أَمَةٌ</span></a>; <span class="auth">(Ṣ, Mṣb;)</span> originally <span class="ar">أُمَيْوَةٌ</span>. <span class="auth">(Mṣb.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0103.pdf" target="pdf">
							<span>Lanes Lexicon Page 103</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
