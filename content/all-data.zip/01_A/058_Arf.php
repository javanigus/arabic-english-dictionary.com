<article class="root" id="Root_Arf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/057_ArT">ارط</a></span>
				<span class="ar">ارف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/059_Arq">ارق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Arf_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّف</span></h3>
				<div class="sense" id="Arf_2_A1">
					<p><span class="ar">أَرَّفَهَا</span>, <span class="auth">(T, M, Mgh,)</span> namely <span class="ar">الدَّارَ</span>, and <span class="ar">الأَرْضَ</span>, <span class="auth">(T, M,)</span> inf. n. <span class="ar">تَأْرِيفٌ</span>, <span class="auth">(T,)</span> <em>He set,</em> or <em>put, limits,</em> or <em>boundaries,</em><span class="add">[<span class="ar">أُرَف</span>,]</span> <em>to it;</em> <span class="auth">(M, Mgh;)</span> <em>and marked it out:</em> <span class="auth">(Mgh:)</span> or <em>he divided it; and set,</em> or <em>put, limits,</em> or <em>boundaries, to it:</em> <span class="auth">(T:)</span> namely <em>the house,</em> and <em>the land.</em> <span class="auth">(T, M.)</span> And <span class="ar long">أُرِّفَ عَلَى المَالِ</span>, <span class="auth">(Ṣ, Mgh, Mṣb,)</span> or <span class="ar long">على الأَرْضِ</span>, inf. n. as above, <span class="auth">(Ḳ,)</span> <em>The property,</em> <span class="auth">(Ṣ, Mgh, Mṣb,)</span> or <em>the land,</em> <span class="auth">(Ḳ,)</span> <em>had limits,</em> or <em>boundaries, set,</em> or <em>put, to it,</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> or <em>around it;</em> <span class="auth">(Mgh;)</span> and <em>was divided.</em> <span class="auth">(Ḳ.)</span> When this is done, it is said that there is no <span class="ar">شُفْغَة</span> <span class="add">[or right of preemption]</span> with respect to the property. <span class="auth">(Ṣ, Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Arf_2_A2">
					<p><span class="ar">تَأْرِيفٌ</span> also signifies The <em>tying</em> a rope, or cord, <em>so as to form a knot</em> or <em>knots.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iirofi">
				<h3 class="entry"><span class="ar">إِرْفِ</span></h3>
				<div class="sense" id="Iirofi_A1">
					<p><span class="ar long">إِنَّهُ لَفِى إِرْفِ مَجْدٍ</span> <em>i. q.</em> <span class="ar long">إرْثِ مَجْدٍ</span> <span class="add">[<em>Verily he is of a glorious origin, race,</em> or <em>stock</em>]</span>: mentioned by Yaạḳoob as an instance of a change of letters. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OurofapN">
				<h3 class="entry"><span class="ar">أُرْفَةٌ</span></h3>
				<div class="sense" id="OurofapN_A1">
					<p><span class="ar">أُرْفَةٌ</span> <em>A limit,</em> or <em>boundary,</em> <span class="auth">(Aṣ, T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> <em>making a separation</em> <span class="auth">(Mṣb)</span> <em>between two pieces of land;</em> <span class="auth">(Mṣb, Ḳ;)</span> <em>a sign,</em> or <em>mark,</em> <span class="auth">(Aṣ, T, Ṣ, Mgh,)</span> <em>of the limits,</em> or <em>boundaries, between two pieces of land:</em> <span class="auth">(Ṣ:)</span> and <em>a separation between houses and estates:</em> <span class="auth">(M:)</span> and <em>a dam between two pieces of land sown or for sowing:</em> <span class="auth">(Th, M:)</span> Yaạḳoob asserts that its <span class="ar">ف</span> is a substitute for the <span class="ar">ث</span> of <span class="ar">أُرْثَةٌ</span> <span class="add">[which is, however, less common]</span>: <span class="auth">(M:)</span> <span class="pb" id="Page_0050"></span>the pl. is <span class="ar">أُرَفٌ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> signifying, accord. to Lḥ, like <span class="ar">أُرَثٌ</span>, <em>limits,</em> or <em>boundaries, between two pieces of land</em> <span class="add">[&amp;c.]</span>; <span class="auth">(T;)</span> and it is said in a trad., that these cut off <span class="ar">الشُّفْعَة</span> <span class="add">[i. e. the right of preemption]</span>; <span class="auth">(T, Ṣ, Mgh;)</span> meaning, in the language of the people of El-Ḥijáz, <em>signs,</em> or <em>marks,</em> and <em>limits,</em> or <em>boundaries.</em> <span class="auth">(T.)</span> Th relates that an Arab woman said, <span class="ar long">جَعَلَ عَلَيَّ زَوْجِى أُرْفَةً لَا أَجُوزُهَا</span>, i. e. <em>My husband set me a sign,</em> or <em>mark,</em> <span class="add">[or <em>limit,</em>]</span> <em>beyond which I should not pass.</em> <span class="auth">(M.)</span> And <span class="ar long">أُرْفَةُ أَجَلٍ</span> signifies <em>An extreme limit of a period of existence.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارف</span> - Entry: <span class="ar">أُرْفَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OurofapN_A2">
					<p>Also <em>A knot.</em> <span class="auth">(Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OurofieBN">
				<h3 class="entry"><span class="ar">أُرْفِىٌّ</span></h3>
				<div class="sense" id="OurofieBN_A1">
					<p><span class="ar">أُرْفِىٌّ</span> <em>A measurer of land,</em> <span class="auth">(Ḳ,* TA,)</span> <em>who marks it with limits,</em> or <em>boundaries.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaArifie">
				<h3 class="entry"><span class="ar">مُؤَارِفِى</span></h3>
				<div class="sense" id="muWaArifie_A1">
					<p><span class="ar long">هُوَ مُؤَارِفِى</span> <em>He has his limit,</em> or <em>boundary, next to mine, in dwelling,</em> and <em>in place:</em> <span class="auth">(Ḳ:)</span> a phrase like <span class="ar">هُوَمُتَاخِمِى</span>. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0049.pdf" target="pdf">
							<span>Lanes Lexicon Page 49</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0050.pdf" target="pdf">
							<span>Lanes Lexicon Page 50</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
