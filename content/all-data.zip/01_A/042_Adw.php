<article class="root" id="Root_Adw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/041_Adm">ادم</a></span>
				<span class="ar">ادو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/043_Ade">ادى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Adw_4">
				<h3 class="entry">4. ⇒ <span class="ar">آدو</span> ⇒ <span class="ar">آدى</span></h3>
				<div class="sense" id="Adw_4_A1">
					<p><span class="ar">آدى</span> <em>He took his</em> <span class="ar">أَدَاةٌ</span> <span class="add">[q. v.]</span>; <span class="auth">(M;)</span> <em>he prepared himself;</em> <span class="auth">(M, Ḳ; <span class="add">[mentioned in the latter in art. <span class="ar">ادى</span>;]</span>)</span> or <em>equipped,</em> or <em>accoutred, himself;</em> or <em>furnished,</em> or <em>provided himself with proper,</em> or <em>necessary, apparatus, equipments,</em> or <em>the like;</em> <span class="auth">(M;)</span> or <em>he was,</em> or <em>became, in a state of preparation;</em> <span class="auth">(Yaạḳoob, T, Ṣ;)</span> <span class="ar">لِلسَّفَرِ</span> <em>for journeying,</em> or <em>the journey:</em> <span class="auth">(Yaạḳoob, T, Ṣ, M, Ḳ:)</span> part. n. <span class="ar">مُؤدٍ</span>. <span class="auth">(Yaạḳoob, T, Ṣ.)</span> And<span class="arrow"><span class="ar">تأدّى↓</span></span> <em>He took his</em> <span class="ar">أَدَاة</span>, <span class="add">[or <em>prepared himself,</em>, &amp;c.,]</span> <span class="ar">لِلْأَمْرِ</span> <em>for the affair:</em> <span class="auth">(M:)</span> or<span class="arrow"><span class="ar">تآدى↓</span></span> <em>he prepared, furnished, equipped,</em> or <em>accoutred, himself</em> for the affair; <span class="auth">(Ibn-Buzurj, Az, TA;)</span> from <span class="ar">الأَداةُ</span>: <span class="auth">(Az, TA:)</span> or<span class="arrow">↓</span> the former of these two verbs, <span class="auth">(so in some copies of the Ṣ and Ḳ,)</span> or<span class="arrow">↓</span> the latter of them, <span class="auth">(so in other copies of the Ṣ and Ḳ, and in the TA,)</span> <em>he took his</em> <span class="ar">أَدَاة</span> <span class="add">[or <em>equipments,</em>, &amp;c., i. e. <em>he prepared himself,</em>]</span> <em>for</em> <span class="add">[<em>the vicissitudes of</em>]</span> <em>fortune:</em> <span class="auth">(Ṣ, Ḳ:)</span> and<span class="arrow"><span class="ar">تَآدَوْا↓</span></span>, inf. n. <span class="ar">تَآدٍ</span>, <em>they took the apparatus, equipments,</em> or <em>the like, that should strengthen,</em> or <em>fortify, them against</em> <span class="add">[<em>the vicissitudes of</em>]</span> <em>fortune, &amp;c.:</em> <span class="auth">(T:)</span> <span class="add">[accord. to some,]</span> <span class="ar">التَّآدِى</span> is <span class="add">[irregularly derived]</span> from <span class="ar">الآدُ</span>, meaning “strength.” <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Adw_4_A2">
					<p><em>He was,</em> or <em>became, completely armed;</em> <span class="auth">(T, TA;)</span> part. n. as above; <span class="auth">(T, Ṣ, M, Mṣb;)</span> from <span class="ar">الأَدَاةُ</span>: <span class="auth">(T, TA:)</span> or <em>he was,</em> or <em>became, strong by means of weapons and the like;</em> part. n. as above: <span class="auth">(Mṣb:)</span> or <em>he was,</em> or <em>became, strong</em> <span class="add">[in an absolute sense]</span>; <span class="auth">(Ṣ, Ḳ; <span class="add">[mentioned in the latter in art. <span class="ar">ادى</span>;]</span>)</span> said of a man; from <span class="ar">الأَدَاةُ</span>; <span class="auth">(Ṣ;)</span> part. n. as above. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Adw_4_B1">
					<p><span class="ar">آداهُ</span> is originally <span class="ar">أَعْدَاهُ</span>; the second <span class="ar">ا</span> <span class="add">[in <span class="ar">آ</span>, for <span class="ar">أَا</span>,]</span> being hemzeh substituted for <span class="ar">ع</span> in the original; meaning <em>He aided,</em> or <em>assisted, him:</em> <span class="add">[or <em>he avenged him:</em>]</span> or it may be from <span class="ar">الأَدَاةُ</span>; meaning <em>he made him to have,</em> or <em>gave him,</em> or <em>assigned to him, weapons,</em> or <em>arms.</em> <span class="auth">(Ḥam p. 387.)</span> <span class="add">[In either case, it should be mentioned in the present art.; as <span class="ar">اعدى</span> <a href="index.php?data=18_E/047_Edw">belongs to art. <span class="ar">عدو</span></a>, and <span class="ar">الاداة</span> has for its pl. <span class="ar">الأَدَوَاتُ</span>.]</span> You say, <span class="ar long">آداهُ عَلَى كَذَا</span>, aor. <span class="ar">يُؤْدِيهِ</span>, inf. n. <span class="ar">إِيدَآءٌ</span>, <em>He strengthened him,</em> and <em>aided him,</em> or <em>assisted him, against such a thing,</em> or <em>to do such a thing.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">آداهُ عَلَى فُلَانٍ</span>, meaning <span class="ar">أَعْدَاهُ</span> and <span class="ar">أَعَانَهُ</span> <span class="add">[<em>He avenged him of such a one;</em> or <em>he aided,</em> or <em>assisted, him against such a one</em>]</span>. <span class="auth">(M and Ḳ in art. <span class="ar">عدى</span>.)</span> And <span class="ar long">مَنْ يُؤدِينِى عَلَى فُلَانٍ</span> <em>Who will aid me,</em> or <em>assist me, against such a one?</em> <span class="auth">(Ṣ.)</span> The people of El-Ḥijáz say,<span class="arrow"><span class="ar long">اسْتَأْدَيْتُهُ↓ عَلَى فُلَانٍ فَآدَانِى عَلَيْهِ</span></span>, meaning <span class="ar long">اِسْتَعْدَيْتُهُ فَأَعْدَانِى</span> <span class="auth">(T, Ṣ)</span> and <span class="ar">أعَانَنِى</span> <span class="auth">(T)</span> <span class="add">[<em>I asked of him</em> <span class="auth">(namely the Sultá, T, or the Emeer, Ṣ)</span> <em>vengeance of such a one,</em> or <em>aid against such a one, and he avenged me of him,</em> or <em>aided me against him</em>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Adw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأدّى</span></h3>
				<div class="sense" id="Adw_5_A1">
					<p><a href="#Adw_4">see 4</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Adw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآدَى</span></h3>
				<div class="sense" id="Adw_6_A1">
					<p><a href="#Adw_4">see 4</a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Adw_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأدو</span> ⇒ <span class="ar">استأدى</span></h3>
				<div class="sense" id="Adw_10_A1">
					<p><span class="ar long">استأداهُ عَلَيْهِ</span> <em>i. q.</em> <span class="ar">اِسْتَعْدَاهُ</span> <span class="add">[<em>He asked of him aid,</em> or <em>assistance, against him;</em> or <em>vengeance of him</em>]</span>: <span class="auth">(T, Ṣ, M, Ḳ:*)</span> or <em>he complained to him of his</em> <span class="auth">(another's)</span> <em>deed to him, in order that he might exact his</em> <span class="auth">(the complainant's)</span> <em>right,</em> or <em>due, from him.</em> <span class="auth">(TA.)</span> <a href="#Adw_4">See also 4</a>, last sentence.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadaApN">
				<h3 class="entry"><span class="ar">أَدَاةٌ</span></h3>
				<div class="sense" id="OadaApN_A1">
					<p><span class="ar">أَدَاةٌ</span> <em>An instrument; a tool; an implement; a utensil:</em> and <em>instruments; tools; implements; utensils; apparatus; equipments; equipage; accoutrements; furniture; gear; tackling:</em> syn. <span class="ar">آلَةٌ</span>: <span class="auth">(T, Ṣ, M, Mṣb, Ḳ:)</span> of any tradesman or craftsman; with which he performs the work of his trade or craft: and of war; <span class="ar long">أَدَاةُ الحَرْبِ</span> signifying <em>weapons,</em> or <em>arms:</em> <span class="auth">(Lth, T:)</span> and for an affair <span class="add">[of any kind]</span>: <span class="auth">(M:)</span> <span class="add">[applied also to the <em>apparatus</em> of a camel, or of a camel's saddle, &amp;c.: (<a href="#HidojN">see <span class="ar">حِدْجٌ</span></a>:)]</span> and<span class="arrow"><span class="ar">إِدَاوَةٌ↓</span></span> signifies the same; <span class="auth">(M, TA;)</span> and<span class="arrow"><span class="ar">أَدَاوَةٌ↓</span></span>: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">أَدِىٌّ↓</span></span>, <span class="auth">(Ṣ, TA,)</span> like <span class="ar">غَنِىٌّ</span>, <span class="auth">(TA,)</span> <span class="add">[in some copies of the Ṣ <span class="ar">آدِىٌّ</span>,]</span> <span class="pb" id="Page_0038"></span>signifies <em>apparatus, equipments, equipage, accoutrements, furniture, gear, tackling, implements, tools,</em> or <em>the like;</em> syn. <span class="ar">أُهْبَةٌ</span>: <span class="auth">(Ṣ, TA:)</span> <a href="#OadaAhN">the pl. of <span class="ar">أَدَاهٌ</span></a> is <span class="ar">أَدَوَاتٌ</span>. <span class="auth">(T, Ṣ, Mṣb, Ḳ.)</span> You say, <span class="ar long">أَخَذَ أَدَاتَهُ</span> <span class="add">[<em>He took his apparatus,</em>, &amp;c.; or <em>prepared, furnished, equipped,</em> or <em>accoutred, himself</em>]</span>; <span class="auth">(Ṣ, M, Ḳ;)</span> <span class="ar">لِلْأَمْرِ</span> <span class="add">[<em>for the affair</em>]</span>, and <span class="ar">لِلسَّفَرِ</span> <span class="add">[<em>for journeying,</em> or <em>the journey</em>]</span>, <span class="auth">(M,)</span> and <span class="ar">لِلدَّهْرِ</span> <span class="add">[<em>for</em> the vicissitudes of <em>fortune</em>]</span>: <span class="auth">(T, Ṣ, Ḳ:)</span> and it is related on the authority of Ks, that they said <span class="ar long">أَخَذَ هَدَاتَهُ</span>; substituting <span class="ar">ه</span> for <span class="ar">أ</span>. <span class="auth">(Lḥ, M)</span>. And<span class="arrow"><span class="ar long">أخَذْتُ لِذٰلِكَ الأَمْر أَدِيَّهُ↓</span></span> i. e. <span class="ar">أُهْبَتَهُ</span> <span class="add">[<em>I took for that affair its apparatus,</em>, &amp;c.]</span>. <span class="auth">(Ṣ, TA.)</span> And<span class="arrow"><span class="ar long">نَحْنُ عَلَى أَدِىٍّ↓ لِلصَّلَاةِ</span></span> <em>We are in a state of preparation for prayer.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: <span class="ar">أَدَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OadaApN_A2">
					<p><span class="add">[Hence, in grammar, <em>A particle;</em> as being a kind of auxiliary; including the article <span class="ar">ال</span>, the preposition, the conjunction, and the interjection; but not the adverbial noun.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OadieBN">
				<h3 class="entry"><span class="ar">أَدِىٌّ</span></h3>
				<div class="sense" id="OadieBN_A1">
					<p><span class="ar">أَدِىٌّ</span>: <a href="#OadaApN">see <span class="ar">أَدَاةٌ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: <span class="ar">أَدِىٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OadieBN_B1">
					<p>Also <em>A journey;</em> or <em>a journeying:</em> from <span class="ar long">آدَى لِلسَّفَرِ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OadaAwapN">
				<h3 class="entry"><span class="ar">أَدَاوَةٌ</span></h3>
				<div class="sense" id="OadaAwapN_A1">
					<p><span class="ar">أَدَاوَةٌ</span>: <a href="#OadaApN">see <span class="ar">أَدَاةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IidaAwapN">
				<h3 class="entry"><span class="ar">إِدَاوَةٌ</span></h3>
				<div class="sense" id="IidaAwapN_A1">
					<p><span class="ar">إِدَاوَةٌ</span> <em>i. q.</em> <span class="ar">مِطهَرَةٌ</span>; <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ;)</span> i. e. <em>A small vessel</em> <span class="add">[or <em>bag</em>]</span> <em>of skin, made for water, like the</em> <span class="ar">سَطِيحَة</span>: <span class="auth">(TA:)</span> or, as some say, only <em>of two skins put face to face:</em> <span class="auth">(M, TA:)</span> pl. <span class="ar">أَدَاوَى</span>; <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> originally, by rule, <span class="ar">أَدَائِىُ</span>; which is changed, as in the cases of <span class="ar">مَطَايَا</span> and <span class="ar">خَطَايَا</span>, from the measure <span class="ar">فَعَائِلُ</span> to the measure <span class="ar">فَعَالَى</span>, so that the <span class="ar">و</span> in <span class="ar">أَدَاوَى</span> is a substitute for the augmentative <span class="ar">ا</span> in the sing., and the final alif <span class="add">[written <span class="ar">ى</span>]</span> in <span class="ar">أَدَاوَى</span> is a substitute for the <span class="ar">و</span> in the sing. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: <span class="ar">إِدَاوَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IidaAwapN_A2">
					<p><a href="#OadaApN">See also <span class="ar">أَدَاةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mdae">
				<h3 class="entry"><span class="ar">آدَى</span></h3>
				<div class="sense" id="Mdae_A1">
					<p><span class="ar">آدَى</span> <span class="add">[a noun denoting the comparative and superlative degrees, irregularly formed from the verb <span class="ar">آدَى</span>; <a href="#Adae">like as the noun <span class="ar">آدَى</span></a> <a href="index.php?data=01_A/043_Ade">in art. <span class="ar">ادى</span></a> <a href="#OadBae">is irregularly formed from the verb <span class="ar">أَدَّى</span></a> in that art.]</span>. You say, <span class="ar long">هُوَ آدَى شَىْءٍ</span>, meaning <span class="ar">أَقْوَاهُ</span> and <span class="ar">أعْدَاهُ</span> <span class="add">[<em>It is the strongest kind of thing,</em> and, app., <em>the most effectual to aid</em> or <em>assist,</em> or <em>to avenge</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: <span class="ar">آدَى</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Mdae_B1">
					<p><a href="index.php?data=01_A/043_Ade">See also art. <span class="ar">ادى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWodK">
				<h3 class="entry"><span class="ar">مُؤْدٍ</span></h3>
				<div class="sense" id="muWodK_A1">
					<p><span class="ar">مُؤْدٍ</span> part. n. of the intrans. verb <span class="ar">آدى</span> <span class="add">[q. v.]</span>. <span class="auth">(T, Ṣ, M, &amp;c.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: <span class="ar">مُؤْدٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="muWodK_B1">
					<p><span class="add">[And act. part. n. of <span class="ar">آدَاهُ</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ادو</span> - Entry: <span class="ar">مُؤْدٍ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="muWodK_C1">
					<p><span class="ar">مُودٍ</span>, without <span class="ar">ء</span>, is from <span class="ar">أَوْدَى</span> signifying “he perished” <span class="add">[&amp;c.]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0037.pdf" target="pdf">
							<span>Lanes Lexicon Page 37</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0038.pdf" target="pdf">
							<span>Lanes Lexicon Page 38</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
