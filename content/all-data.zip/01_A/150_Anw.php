<article class="root" id="Root_Anw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/149_AnmA">انما</a></span>
				<span class="ar">انو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/151_Ane">انى</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="IinowN">
				<h3 class="entry"><span class="ar">إِنْوٌ</span></h3>
				<div class="sense" id="IinowN_A1">
					<p><span class="ar">إِنْوٌ</span>: <a href="#IinoeN">see <span class="ar">إِنْىٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0118.pdf" target="pdf">
							<span>Lanes Lexicon Page 118</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
