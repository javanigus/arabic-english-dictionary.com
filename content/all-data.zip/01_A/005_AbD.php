<article class="root" id="Root_AbD">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/004_Abr">ابر</a></span>
				<span class="ar">ابض</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/006_AbT">ابط</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AbD_1">
				<h3 class="entry">1. ⇒ <span class="ar">أبض</span></h3>
				<div class="sense" id="AbD_1_A1">
					<p><span class="ar">أَبَضَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْبِضُ</span>}</span></add> <span class="auth">(Ṣ, A, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْبُضُ</span>}</span></add> <span class="auth">(L,)</span>, inf. n. <span class="ar">أَبْضٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">أُبُوضٌ</span> <span class="auth">(L,)</span> <em>He tied,</em> or <em>bound, the pastern of his</em> <span class="auth">(a camel's)</span> <em>fore leg to his</em> <span class="auth">(the camel's)</span> <span class="ar">عَضُد</span> <span class="add">[or <em>arm</em>]</span>, <em>so that his fore leg became raised from the ground;</em> <span class="auth">(Ṣ, A, Ḳ;)</span> as also<span class="arrow">↓<span class="ar">تأبّضهُ</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> and accord. to IAạr, <span class="ar">أَبْضٌ</span> signifies <span class="add">[simply]</span> the act of <em>tying,</em> or <em>binding.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AbD_1_B1">
					<p><span class="add">[Also, inf. n. <span class="ar">أَبْضٌ</span>, <em>He loosed him,</em> or <em>it:</em> for]</span> <span class="ar">أَبْضٌ</span> also signifies the act of <em>loosing;</em> syn. <span class="ar">تَخْلِيَةٌ</span>; i. e. <em>contr. of</em> <span class="ar">شَدٌّ</span>: <span class="auth">(IAạr, Ḳ:)</span> thus bearing two contr. significations. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="AbD_1_C1">
					<p>Also, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَبْضٌ</span>, <span class="auth">(TA,)</span> <em>He hit,</em> or <em>hurt, his vein called the</em> <span class="ar">إِبَاض</span>. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="AbD_1_D1">
					<p><span class="ar">أَبَضَ</span> <span class="auth">(Ṣ, L, Ḳ,)</span> inf. n. <span class="ar">أَبْضٌٰ</span>; <span class="auth">(TA;)</span> and <span class="ar">أَبِضَ</span>; <span class="auth">(Ṣ, L, Ḳ;)</span> <em>It</em> <span class="auth">(the vein called <span class="ar">النَّسَا</span>)</span> <em>became contracted,</em> <span class="auth">(Ṣ, L, Ḳ,)</span> <em>and strengthened the hind legs;</em> <span class="auth">(L;)</span> as also<span class="arrow">↓<span class="ar">تأبّض</span></span>: <span class="auth">(Ṣ, L:)</span> and<span class="arrow">↓<span class="ar">تَأَبُّضٌ</span></span> in the hind legs signifies their <em>being contracted</em> <span class="auth">(A, TA)</span> <em>and tense:</em> <span class="auth">(TA:)</span> <span class="ar">تَأَبُّض</span> of the hind legs of a horse, and <span class="ar">تَشَنُّج</span> <span class="add">[or contraction]</span> of the vein above mentioned, are qualities approved; and the latter is known by means of the former. <span class="auth">(AO, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="AbD_1_E1">
					<p><span class="ar">أَبْضٌ</span> also signifies The <em>being in a state of rest,</em> or <em>motionless.</em> <span class="auth">(IAạr, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="AbD_1_F1">
					<p>And The <em>being in a state of motion:</em> <span class="auth">(IAạr, Ḳ:)</span> thus, again, having two contr. significations. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AbD_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأبّض</span></h3>
				<div class="sense" id="AbD_5_A1">
					<p><span class="ar">تأبّض</span> <em>He</em> <span class="auth">(a camel)</span> <em>had his pastern of his fore leg tied,</em> or <em>bound, to his arm, so that his fore leg became raised from the ground.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">تَقَبَّضَ كَأَنَّمَا تَأَبَّضَ</span> <span class="add">[<em>He contracted himself as though he had his leg thus bound</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AbD_5_A2">
					<p><span class="ar">تأبّضت</span> <em>She</em> <span class="auth">(a woman)</span> <em>sat in the posture of the</em> <span class="arrow">↓<span class="ar">مُتَأَبِّض</span></span> <span class="add">[app. meaning <em>having her shanks pressed back against her thighs</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AbD_5_A3">
					<p><a href="#OabaDa">See also <span class="ar">أَبَضَ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AbD_5_B1">
					<p><span class="ar">تأبضهُ</span>: <a href="#AbD_1">see <span class="ar">أَبَضَهُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaboDN">
				<h3 class="entry"><span class="ar">أَبْضٌ</span> / 
							<span class="ar">أُبُضٌ</span> / 
							<span class="ar">إِبِضٌ</span> / 
							<span class="ar">أُبَّضٌ</span></h3>
				<div class="sense" id="OaboDN_A1">
					<p><span class="ar">أَبْضٌ</span>, or <span class="ar">أُبُضٌ</span>, or <span class="ar">إِبِضٌ</span>, or <span class="ar">أُبَّضٌ</span>: <a href="#maOobiDN">see <span class="ar">مَأْبِضٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: <span class="ar">أَبْضٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaboDN_B1">
					<p>Also, the first, <em>i. q.</em> <span class="ar">دَهْرٌ</span> <span class="add">[<em>Time;</em> or a <em>long period of time;</em> or <em>a period of time whether long or short;</em>, &amp;c.]</span>: pl. <span class="ar">آبَاضٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IibaADN">
				<h3 class="entry"><span class="ar">إِبَاضٌ</span></h3>
				<div class="sense" id="IibaADN_A1">
					<p><span class="ar">إِبَاضٌ</span> The <em>cord,</em> or <em>rope, with which the pastern of a camel's fore leg is tied,</em> or <em>bound, to his arm, so that his fore leg is raised from the ground:</em> <span class="auth">(Aṣ, Ṣ, A, Ḳ:)</span> pl. <span class="ar">أُبُضٌ</span>. <span class="auth">(Ḳ.)</span> The dim. is<span class="arrow">↓<span class="ar">أُبَيِّضٌ</span></span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: <span class="ar">إِبَاضٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IibaADN_A2">
					<p><em>A certain vein</em> (<span class="ar">عِرْق</span>) <em>in the hind leg</em> <span class="auth">(AO, Ḳ)</span> <em>of a horse.</em> <span class="auth">(AO.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OabuwDN">
				<h3 class="entry"><span class="ar">أَبُوضٌ</span></h3>
				<div class="sense" id="OabuwDN_A1">
					<p><span class="ar">أَبُوضٌ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">أَبُوضُ النَّسَا</span>, <span class="auth">(ISh,)</span> A <em>very swift</em> horse: <span class="auth">(ISh, Ḳ:)</span> as though he bound up his hind legs by the quickness with which he raised them when he put them down. <span class="auth">(ISh.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OubayBiDN">
				<h3 class="entry"><span class="ar">أُبَيِّضٌ</span></h3>
				<div class="sense" id="OubayBiDN_A1">
					<p><span class="ar">أُبَيِّضٌ</span>: <a href="#IibaADN">see <span class="ar">إِبَاضٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOobiDN">
				<h3 class="entry"><span class="ar">مَأْبِضٌ</span></h3>
				<div class="sense" id="maOobiDN_A1">
					<p><span class="ar">مَأْبِضٌ</span> The <em>inner side of the knee</em> <span class="auth">(Ṣ, A, Ḳ)</span> of any thing: <span class="auth">(Ṣ:)</span> or the inner sides of the two knees are called <span class="ar long">مَأْبِضَا السَّاقَيْنِ</span>: <span class="auth">(T, TA:)</span> or <em>any part upon which a man bends,</em> or <em>folds, his thigh:</em> or what <em>is beneath each thigh, in the prominent places of the lower parts thereof:</em> or the <em>inner side of each thigh, as far as the belly:</em> and also the <em>wrist;</em> the <em>joint of the hand in the fore arm:</em> <span class="auth">(TA:)</span> and in the camel, <span class="auth">(Ḳ,)</span> <span class="add">[i. e.]</span> in each of the fore legs of the camel, <span class="auth">(T, TA,)</span> the <em>inner side of the elbow:</em> <span class="auth">(T, Ḳ, TA:)</span> as also<span class="arrow">↓<span class="ar">أَبْضٌ</span></span>; <span class="auth">(IDrd, Ḳ;)</span> or, as in <span class="add">[some of]</span> the copies of the Ṣ <a href="index.php?data=02_b/235_byD">in art. <span class="ar">بيض</span></a>, <span class="arrow">↓<span class="ar">أُبُضٌ</span></span>; <span class="add">[in one copy of the Ṣ<span class="arrow">↓<span class="ar">أُبَّضٌ</span></span>; and in another, imperfectly written;]</span> but some write it<span class="arrow">↓<span class="ar">إِبِضٌ</span></span>: and one says, <span class="ar long">أَخَذَ بِإِبِضِهِ</span>, meaning <em>He put his hands,</em> or <em>arms, beneath his knees, from behind, and then carried him.</em> <span class="auth">(TA.)</span> <a href="#maOobiDN">The pl. of <span class="ar">مَأْبِضٌ</span></a> is <span class="ar">مَآبِضُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOobuwDN">
				<h3 class="entry"><span class="ar">مَأْبُوضٌ</span></h3>
				<div class="sense" id="maOobuwDN_A1">
					<p><span class="ar">مَأْبُوضٌ</span> A camel <em>having the pastern of his fore leg tied,</em> or <em>bound, to his arm, so that his fore leg is raised from the ground;</em> <span class="auth">(A,* TA;)</span> as also<span class="arrow">↓<span class="ar">مُتَأَبِّضٌ</span></span>: <span class="auth">(Ṣ:)</span> or the latter, <em>having his fore shank bound to his arm with the</em> <span class="ar">إِبَاض</span> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: <span class="ar">مَأْبُوضٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="maOobuwDN_B1">
					<p><em>Hit,</em> or <em>hurt, in the vein called the</em> <span class="ar">إِبَاض</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotabiDu">
				<h3 class="entry"><span class="ar">مُؤْتَبِضُ</span></h3>
				<div class="sense" id="muWotabiDu_A1">
					<p><span class="ar long">مُؤْتَبِضُ النَّسَا</span> <em>The crow:</em> because it hops as though it were <span class="ar">مَأْبُوض</span> <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaOabBiDN">
				<h3 class="entry"><span class="ar">مُتَأَبِّضٌ</span></h3>
				<div class="sense" id="mutaOabBiDN_A1">
					<p><span class="ar">مُتَأَبِّضٌ</span>: <a href="#maOobuwDN">see <span class="ar">مَأْبُوضٌ</span></a>: <a href="#AbD_5">and see 5</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ابض</span> - Entry: <span class="ar">مُتَأَبِّضٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="mutaOabBiDN_B1">
					<p>Also <em>Having the vein called</em> <span class="ar">إِبَاض</span> <em>in a tense state.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0006.pdf" target="pdf">
							<span>Lanes Lexicon Page 6</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
