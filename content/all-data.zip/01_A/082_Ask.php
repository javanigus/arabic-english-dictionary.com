<article class="root" id="Root_Ask">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/081_AsfydAj">اسفيداج</a></span>
				<span class="ar">اسك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/083_Asl">اسل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ask_1">
				<h3 class="entry">1. ⇒ <span class="ar">أسك</span></h3>
				<div class="sense" id="Ask_1_A1">
					<p><span class="ar">أَسَكَهَا</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْسِكُ</span>}</span></add>, inf. n. <span class="ar">أَسْكٌ</span>, <em>He hit, hurt,</em> or <em>wounded, her</em> <span class="auth">(a woman's)</span> <span class="ar">إِسْكَتَانِ</span>. <span class="auth">(TA.)</span> And <span class="ar">أُسِكَتْ</span> <em>She</em> <span class="auth">(a woman)</span> <em>was hurt,</em> or <em>wounded, in a place not that of circumcision,</em> <span class="add">[i.e., <em>in her</em> <span class="ar">إِسْكَتَانِ</span>,]</span> <em>by the circumcising woman's missing the proper place.</em> <span class="auth">(Mṣb.)</span> <span class="add">[<a href="#baZorq">See <span class="ar">بَظْرق</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OasokN">
				<h3 class="entry"><span class="ar">أَسْكٌ</span></h3>
				<div class="sense" id="OasokN_A1">
					<p><span class="ar">أَسْكٌ</span>: <a href="#AlIisokataAni">see <span class="ar">الإِسْكَتَانِ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IisokN">
				<h3 class="entry"><span class="ar">إِسْكٌ</span></h3>
				<div class="sense" id="IisokN_A1">
					<p><span class="ar">إِسْكٌ</span> <a href="#AlIisokataAni">see <span class="ar">الإِسْكَتَانِ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اسك</span> - Entry: <span class="ar">إِسْكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IisokN_A2">
					<p>Also The <em>side of the</em> <span class="ar">اِسْت</span> <span class="add">[i. e., of the <em>podex,</em> or of the <em>anus</em>]</span>. <span class="auth">(Sh, TA.)</span> <span class="add">[Hence,]</span> one says of a man, <span class="ar long">إِنَّمَا هُوَ إِسْكُ أَمَةٍ</span>, meaning <em>He is but a stinking fellow.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlIisokataAni">
				<h3 class="entry"><span class="ar">الإِسْكَتَانِ</span></h3>
				<div class="sense" id="AlIisokataAni_A1">
					<p><span class="ar">الإِسْكَتَانِ</span> <span class="auth">(T, Ṣ, M, Mgh, Ṣgh, Mṣb, Ḳ)</span> and <span class="ar">الأَسْكَتَانِ</span>, <span class="auth">(M, Ḳ,)</span> The <em>two sides</em> <span class="add">[or <em>labia majora</em>]</span> <em>of the vulva,</em> or <em>external portion of the female organs of generation,</em> <span class="auth">(T, Ṣ, Mgh, Mṣb,)</span> i. e., <em>of a woman, above</em> <span class="add">[or rather <em>within</em>]</span> <em>the</em> <span class="ar">شُفْرَانِ</span>; <span class="auth">(Mgh; the <span class="ar">شُفْرَانِ</span> being the two borders thereof; T, Mṣb;)</span> i. e. the <span class="ar">قُذَّتَانِ</span> <em>thereof;</em> <span class="auth">(Ṣ and M and L in art. <span class="ar">قذ</span>;)</span> the <em>two sides, on the right and left, of the vulva,</em> or <em>external portion of the organs of generation, of a woman, between which is the</em> <span class="ar">مَشَقّ</span>: <span class="auth">(Zj in his “Khalk el-Insán”)</span> or <span class="add">[accord. to some, but incorrectly,]</span> the <span class="ar">شُفْرَانِ</span> <span class="add">[in the CK the <span class="ar">شَفْر</span>]</span> <em>of the</em> <span class="ar">رَحِم</span> <span class="add">[here meaning, as in many other instances, the <em>vulva,</em> i. e. <span class="ar">فَرْج</span>]</span>, <span class="auth">(M, Ḳ,)</span> or <em>of the</em> <span class="ar">حَيَآء</span> <span class="add">[which also means the vulva, but seldom that of a woman]</span>: <span class="auth">(El-Khárzenjee:)</span> or <span class="add">[agreeably with general usage, and with the explanations given before this last,]</span> <em>its two sides, next to its</em> <span class="ar">شُفْرَانِ</span>: <span class="auth">(M, Ḳ:)</span> or, <span class="add">[what is the same,]</span> <em>its</em> <span class="ar">قُذَّتَانِ</span>: <span class="auth">(Ḳ:)</span> pl. <span class="ar">إِسَكٌ</span> <span class="auth">(El-Khárzenjee, Ḳ)</span> and <span class="add">[quasi-pl. ns.]</span> <span class="arrow"><span class="ar">إِسْكٌ↓</span></span> and<span class="arrow"><span class="ar">أَسْكٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOosuwkapN">
				<h3 class="entry"><span class="ar">مَأْسُوكَةٌ</span></h3>
				<div class="sense" id="maOosuwkapN_A1">
					<p><span class="ar">مَأْسُوكَةٌ</span> A woman <em>hit, hurt,</em> or <em>wounded, in her</em> <span class="ar">إِسْكَتَانِ</span>: <span class="auth">(TA:)</span> a woman <span class="auth">(Mṣb)</span> <em>hurt,</em> or <em>wounded, in a place not that of circumcision, by the circumcising woman's missing the proper place;</em> <span class="auth">(Ṣ Mṣb, Ḳ;)</span> <span class="add">[i. e.,]</span> <em>hurt,</em> or <em>wounded, by that cause, in her</em> <span class="ar">إِسْكَتَانِ</span>. <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0059.pdf" target="pdf">
							<span>Lanes Lexicon Page 59</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
