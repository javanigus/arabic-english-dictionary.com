<article class="root" id="Root_AXk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/090_AXf">اشف</a></span>
				<span class="ar">اشك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/092_AXn">اشن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AXk_1">
				<h3 class="entry">1. ⇒ <span class="ar">أشك</span></h3>
				<div class="sense" id="AXk_1_A1">
					<p><span class="ar long">أَشُكَ ذَا خُرُوجًا</span> <em>i. q.</em> <span class="ar">وَشُكَ</span>, q. v. <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0062.pdf" target="pdf">
							<span>Lanes Lexicon Page 62</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
