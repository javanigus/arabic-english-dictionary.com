<article class="root" id="Root_Awe">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/168_Awh">اوه</a></span>
				<span class="ar">اوى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/170_Ae">اى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Awe_1">
				<h3 class="entry">1. ⇒ <span class="ar">أوى</span> ⇒ <span class="ar">أوا</span></h3>
				<div class="sense" id="Awe_1_A1">
					<p><span class="ar long">أَوَى إِلَيْهِ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> and <span class="ar">أَوَاهُ</span>, <span class="auth">(M, Mṣb, Ḳ,)</span> aor. <span class="ar">يَأْوِى</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> imperative <span class="ar">اِيوِ</span> <span class="auth">(T,)</span> inf. n. <span class="ar">أُوِىُّ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> with damm, <span class="auth">(Ḳ,)</span> of the measure <span class="ar">فُعُولٌ</span>, <span class="add">[originally <span class="ar">أُوُوىٌ</span>,]</span> <span class="auth">(Ṣ,)</span> and <span class="ar">إِوِىٌّ</span>, <span class="auth">(Fr, M, Ḳ,)</span> with kesr, <span class="auth">(Ḳ,)</span> and <span class="ar">إِوَآءٌ</span>; <span class="auth">(Ṣ;)</span> and<span class="arrow"><span class="ar long">أوّى↓ اليه</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَأْوِيَةٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">تأوّى↓</span></span>; <span class="auth">(M, Ḳ;)</span> and<span class="arrow"><span class="ar">ٱأْتَوَى↓</span></span>, <span class="auth">(thus <span class="add">[more commonly <span class="ar">ائتوى</span>]</span> accord. to a copy of the M,)</span> or<span class="arrow"><span class="ar">ٱتَّوَى↓</span></span>, <span class="auth">(Ḳ,)</span> like <span class="ar">ٱتَّخَذَ</span>, <span class="auth">(TḲ,)</span> and<span class="arrow"><span class="ar">اِيتَوَى↓</span></span>, <span class="auth">(M, Ḳ,)</span> both of the measure <span class="ar">افتعل</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">آوَى↓</span></span> is used by some in the same sense, but rejected, in this sense, by several; <span class="auth">(Mṣb;)</span> the pronoun relating to a place of abode; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> <em>He betook himself to it,</em> or <em>repaired to it, for lodging, covert,</em> or <em>refuge;</em> <span class="auth">(Mgh;)</span> and <span class="add">[simply]</span> <em>he got him</em> or <em>got himself, betook himself, repaired,</em> or <em>resorted, to it;</em> <span class="auth">(T, Mgh;)</span> <em>he returned to it;</em> <span class="auth">(M;)</span> <em>he took up his abode in it; he lodged,</em> or <em>abode,</em> or <em>dwelt, in it.</em> <span class="auth">(Mṣb, Ḳ.)</span> Hence, in the Ḳur <span class="add">[xi. 45]</span>, <span class="ar long">سَآوِى إِلَى جَبَلٍ يَعْصِمُنِى مِنَ المَآءِ</span> <span class="add">[<em>I will betake myself for refuge to a mountain that shall preserve me from the water</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="ar">الأُوِىُّ</span> properly relates to living beings; but is used otherwise, metaphorically. <span class="auth">(M.)</span> In the saying of Lebeed,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بِصَبُوحِ صَافِيَةٍ وَجَذْبِ كَرِينَةٍ</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">بِمُوَترٍ تَأْتَى↓ لَهُ إِبْهَامُهَا</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>With a morning-potation of clear wine</em> (<span class="ar">خَمْرٍ</span> being understood), <em>and a female singer's straining</em> of her chords, <em>with a stringed instrument to which her thumb returns</em> after the straining]</span>, he means <span class="ar long">تَأْتَوِى لَهُ</span>, of the measure <span class="ar">تَفْتَعِلُ</span>, from <span class="ar long">أَوَيْتُ إِلَيْهِ</span> signifying <span class="ar">عُدْتُ</span>; the <span class="ar">و</span> being changed into <span class="ar">ا</span> <span class="add">[written <span class="ar">ى</span>]</span>, and the <span class="ar">ى</span>, which is the final radical, being elided. <span class="auth">(M. <span class="add">[<a href="#Awl_1">But see another reading near the end of the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=01_A/163_Awl">of art. <span class="ar">اول</span></a>.]</span>)</span> <span class="ar">أَوَى</span>, aor. as above, inf. n. <span class="ar">أُوِىٌ</span>, also signifies <em>He turned away:</em> and hence, <span class="add">[it is said,]</span> <span class="ar long">إِذْ أَوَى الفِتْيَةُ إِلَى الكَهْفِ</span> <span class="add">[<em>When the young men turned away to the cave:</em> though the verb may be here well rendered <em>betook themselves for refuge</em>]</span>. <span class="auth">(Ḥar p. 246.)</span> You say also, <span class="ar long">أَوَيْتُ إِلَى فُلَانٍ</span>, <span class="auth">(AʼObeyd, T,)</span> or <span class="ar">لَهُ</span>, <span class="auth">(as afterwards written in a copy of the T,)</span> <span class="add">[<em>I betook myself to such a one,</em> or <em>repaired to him, for lodging, covert,</em> or <em>refuge;</em> or]</span> <em>I joined myself, got myself, betook myself, repaired,</em> or <em>resorted, to such a one:</em> and accord. to AHeyth, <span class="ar long">أَوَيْتُ فُلَانًا</span> signifies the same; but he did not know <span class="ar">أَوَيْتُ</span> to be syn. with <span class="ar">آوَيْتُ</span> as explained below. <span class="auth">(T.)</span> And <span class="ar long">أَوَى إِلَى ٱللّٰهِ</span> <em>He returned unto God.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awe_1_A2">
					<p><span class="ar">أَوَى</span> said of a wound: <a href="#Awe_5">see 5</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awe_1_B1">
					<p><a href="#Awe_4">See also 4</a>, in seven places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Awe_1_C1">
					<p><span class="ar long">أَوَى لَهُ</span>, <span class="auth">(T, Ṣ, M, Mgh, Ḳ,)</span> like <span class="ar">رَوَى</span>, <span class="auth">(Ḳ, TA,)</span> but it would have been more explicit if the author of the Ḳ had said like <span class="ar">رَمَى</span>, <span class="auth">(TA,)</span> <span class="add">[as is shown by the false reading in the CK, <span class="ar long">أوِىَ لَهُ كَرَوِىّ</span>,]</span> aor. <span class="ar">يَأوِى</span>, <span class="auth">(T, Ṣ, Mgh,)</span> inf. n. <span class="ar">أَوْيَةٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">إِيَّةٌ</span>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> with kesr, <span class="auth">(TA,)</span> <span class="add">[originally <span class="ar">إِوْيَةٌ</span>,]</span> the <span class="ar">و</span> being changed into <span class="ar">ى</span> because of the kesreh before it, <span class="auth">(Ṣ,)</span> or because combined with <span class="ar">ى</span> and preceded by sukoon <span class="add">[a mistake for “kesreh”]</span>, <span class="auth">(IB as cited in the TA,)</span> <span class="add">[in a copy of the T written <span class="ar">ايَّة</span>, and in a copy of the M and in the CK <span class="ar">اَيَّة</span>,]</span> and <span class="ar">مَأْوِيَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> without teshdeed, <span class="auth">(Ṣ, TA,)</span> <span class="add">[in my copy of the Mgh written with teshdeed,]</span> and <span class="ar">مَأْوَاهٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>He compassionated him; felt compassion,</em> or <em>pity, for him;</em> <span class="auth">(T, Ṣ, M, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">ائتوى↓</span></span>, <span class="auth">(T, Ḳ,)</span> of the measure <span class="ar">افتعل</span>. <span class="auth">(TA.)</span> In using the imperative form, you say, <span class="ar long">اِوِ لَهُ</span>, <span class="add">[unless this be a mistranscription for <span class="ar long">اِيوِ لَهُ</span>,]</span> meaning <em>Be thou compassionate to him.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awe_2">
				<h3 class="entry">2. ⇒ <span class="ar">أوّى</span></h3>
				<div class="sense" id="Awe_2_A1">
					<p><a href="#Awe_1">see 1</a>, first sentence:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awe_2_B1">
					<p><a href="#Awe_4">and see 4</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Awe_2_C1">
					<p><span class="ar long">أَوَّيْتُ بِالخَيْلِ</span> <span class="auth">(ISh, T)</span> <span class="add">[<em>I drew together the horses:</em> this meaning seems to be indicated in the T, by the context: or]</span> <em>I called out to the horses</em> <span class="ar">آوَّهْ</span>, <em>in order that they should return at hearing my voice:</em> <span class="auth">(ISh:)</span> and in like manner one says to them <span class="arrow"><span class="ar">آوِ↓</span></span> or <span class="ar">آوٍ</span>; <span class="auth">(ISh, T, TA;)</span> a well-known call of the Arabs to horses; and sometimes <span class="ar">آى</span>, with a long meddeh, is said to them from afar. <span class="auth">(T, TA.)</span> <span class="add">[<a href="#Awe_5">See also 5</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awe_4">
				<h3 class="entry">4. ⇒ <span class="ar">آوى</span> ⇒ <span class="ar">آوا</span></h3>
				<div class="sense" id="Awe_4_A1">
					<p><span class="ar">آواهُ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">إيوَآءٌ</span>; <span class="auth">(T, Ṣ, Mgh;)</span> and<span class="arrow"><span class="ar">أوّاهُ↓</span></span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">أَوَاهُ↓</span></span>; <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ;)</span> the first of which is the <span class="add">[most]</span> approved; <span class="auth">(T;)</span> the last used by some; <span class="auth">(T, Mṣb;)</span> both given on the authority of AZ, <span class="auth">(Ṣ,)</span> and of AʼObeyd, accord. to whom you say, <span class="ar long">أَوَيْتُ إِلَيْهِ</span>, with the short <span class="ar">ا</span> only; <span class="auth">(T, M;)</span> <em>He,</em> or <em>it, gave him,</em> or <em>afforded him, lodging, covert,</em> or <em>refuge; harboured him; sheltered him; protected him;</em> <span class="auth">(Mgh;)</span> <em>he lodged him,</em> or <em>lodged him with himself; made him his guest;</em> or <em>gave him refuge</em> or <em>asylum,</em> absolutely, or <em>with himself;</em> syn. <span class="ar">أَنْزَلَهُ</span>; <span class="auth">(Ḳ;)</span> or <span class="ar">أَنْزَلَهُ</span>. <span class="auth">(T, Ṣ, TA.)</span> You say also,<span class="arrow"><span class="ar long">أَوَيْتُ↓ الرَّجُلَ إِلَىَّ</span></span> and <span class="ar">آوَيْتُهُ</span> <span class="add">[<em>I took the man to me to lodge, to be my guest,</em> or <em>to give him refuge</em> or <em>asylum</em>]</span>. <span class="auth">(M.)</span> And <span class="ar long">آوَاهُ سَقْفٌ</span> <span class="add">[<em>A roof shel-tered him</em>]</span>. <span class="auth">(Mgh.)</span> And<span class="arrow"><span class="ar long">أَوَيْتُ↓ الإِبِلَ</span></span> and <span class="ar">آوَيْتُهَا</span> <span class="add">[<em>I lodged the camels in their nightly resting-place</em>]</span>; both meaning the same. <span class="auth">(T.)</span> And it is said in a trad., <span class="ar long">الحَمْدُ لِلّهِ الَّذِى كَفَانَا وَآوَانَا</span> i. e. <span class="add">[<em>Praise be to God who hath sufficed us and</em>]</span> <em>hath brought us to a place of abode for us,</em> and not made us to be scattered like the beasts. <span class="auth">(TA.)</span> AHeyth disallowed <span class="arrow"><span class="ar">أَوَيْتُ↓</span></span> as syn. with <span class="ar">آوَيْتُ</span>; but it is correct. <span class="auth">(T.)</span> It is said in a form of divorce, <span class="arrow"><span class="ar long">لَا يَأْوِينِى↓ وَإِيَّاكِ بَيْتٌ</span></span> <span class="add">[<em>A house,</em> or <em>tent, shall not lodge,</em> or <em>comprise, me with thee</em>]</span>. <span class="auth">(Mgh.)</span> And among other instances, is the saying of the Prophet, <span class="auth">(T,)</span> <span class="arrow"><span class="ar long">لَا يَأْوِى↓ الضَّالَّةٌ إلَّا ضَالٌّ</span></span> <span class="add">[<em>No one will harbour the stray beast but a person straying from the right course of conduct</em>]</span>. <span class="auth">(T, Mgh.)</span> And his saying,<span class="arrow"><span class="ar long">لَا قَطْعَ فِى ثَمَرٍ حَتَّى يَأْوِيِه↓ الجَرِينُ</span></span> i. e. <span class="add">[<em>There shall be no cutting off</em> of the hand <em>in the case of</em> stealing <em>fruit</em>]</span> <em>unless the place where the fruit is dried contain it</em> <span class="add">[at the time of the stealing thereof]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awe_4_A2">
					<p>Hence, <span class="ar long">إِيوَآءُ خَشَبِ الفَحْمِ</span> <em>The throwing of dust,</em> or <em>earth, upon the wood of which charcoal is made, and covering it therewith.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awe_4_B1">
					<p><a href="#Awe_1">See also 1</a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awe_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأوّى</span></h3>
				<div class="sense" id="Awe_5_A1">
					<p><a href="#Awe_1">see 1</a>, first sentence.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Awe_5_A2">
					<p><span class="ar long">تَأَوَّتِ الطَّيْرُ</span> <em>The birds collected,</em> or <em>flocked, together;</em> <span class="auth">(Lth, T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَآوَت↓</span></span>: <span class="auth">(Ḳ:)</span> the latter is allowable. <span class="auth">(T.)</span> And in like manner one says of other things. <span class="auth">(M.)</span> <span class="add">[Thus,]</span> one says, <span class="ar long">تَأَوَّتِ الخَيْلُ</span> <em>The horses drew,</em> or <em>gathered, themselves together:</em> and <span class="ar long">تأوّى النَّاسُ</span> <em>The men did so.</em> <span class="auth">(T.)</span> You say also, of a wound, <span class="arrow"><span class="ar">تآوى↓</span></span>, and<span class="arrow"><span class="ar">أَوَى↓</span></span>, meaning <em>It drew together, for healing;</em> and so <span class="ar">تآزى</span>, and <span class="ar">أَزَى</span>: so in the Nawádir el-Aaráb. <span class="auth">(T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awe_5_B1">
					<p>One may also say, <span class="ar">يَتَأَوَّى</span>, without saying it with <span class="ar">ه</span>, <span class="add">[i. e. <span class="ar">يَتَأَوَّهُ</span>,]</span> meaning <em>He says</em> <span class="ar">أَوْهِ</span>. <span class="auth">(Fr and T in art. <span class="ar">او</span>.)</span> <span class="add">[<a href="#Awe_2">See also 2</a>; <a href="index.php?data=01_A/168_Awh">and see art. <span class="ar"></span>Awh</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Awe_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآوى</span> ⇒ <span class="ar">تآوا</span></h3>
				<div class="sense" id="Awe_6_A1">
					<p><a href="#Awe_5">see 5</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awe_8">
				<span class="pb" id="Page_0131"></span>
				<h3 class="entry">8. ⇒ <span class="ar">ائتوى</span> ⇒ <span class="ar">ائتوا</span></h3>
				<div class="sense" id="Awe_8_A1">
					<p><span class="ar">ٱأْتَوى</span>, or <span class="ar">ائتوى</span>, or <span class="ar">ٱتَّوَى</span>, and <span class="ar">اِيتَوَى</span>, and <span class="ar">تَأْتَى</span> for <span class="ar">تَأْتَوِى</span>: <a href="#Awe_1">see 1</a>, first part of the paragraph, in four places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Awe_8_B1">
					<p>See also the last sentence but one of the same paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Awe_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأوى</span> ⇒ <span class="ar">استأوا</span></h3>
				<div class="sense" id="Awe_10_A1">
					<p><span class="ar">ٱسْتَأْوَيْتُهُ</span> <em>I asked him,</em> or <em>desired him, to compassionate me,</em> or <em>have mercy on me;</em> syn. <span class="ar">ٱسْتَرْحَمْتُهُ</span>. <span class="auth">(T.)</span> A poet <span class="auth">(namely, Dhu-r-Rummeh, TA)</span> says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَلَوْ أَنَّنى ٱسْتَأْوَيْتُهُ مَا أَوَى لِيَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And if I had asked him,</em> or <em>desired him, to compassionate me, he would not have compassionated me</em>]</span>. <span class="auth">(T, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuwayBapN">
				<h3 class="entry"><span class="ar">أُوَيَّةٌ</span></h3>
				<div class="sense" id="OuwayBapN_A1">
					<p><span class="ar">أُوَيَّةٌ</span> <a href="#ACN">dim. of <span class="ar">آءٌ</span></a>: <a href="index.php?data=01_A/000_A">see the letter <span class="ar">ا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mwi.1">
				<h3 class="entry"><span class="ar">آوِ</span> / <span class="ar">آوٍ</span></h3>
				<div class="sense" id="Mwi.1_A1">
					<p><span class="ar">آوِ</span> or <span class="ar">آوٍ</span>: <a href="#Awe_2">see 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اوى</span> - Entry: <span class="ar">آوِ.1</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Mwi.1_B1">
					<p><span class="ar">آوٍ</span> <span class="add">[the part. n. of 1]</span> has for its pl. <span class="ar">أُوِىٌّ</span> <span class="add">[like one of the inf. ns. of 1]</span>. <span class="auth">(T, Ṣ.)</span> The latter is applied to birds, signifying <em>Collecting,</em> or <em>flocking, together;</em> <span class="auth">(T, Ṣ, M,* Ḳ;*)</span> syn.<span class="arrow"><span class="ar">مُتَأَوِّيَةٌ↓</span></span> <span class="auth">(Lth, T)</span> and <span class="ar">مُتَأَوِّيَاتٌ</span>. <span class="auth">(Lth, T, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mwae">
				<h3 class="entry"><span class="ar">آوَى</span></h3>
				<div class="sense" id="Mwae_A1">
					<p><span class="ar long">اِبْنُ آوَى</span>, a determinate noun, <span class="auth">(Ṣ, M,)</span> <span class="add">[<em>The jackal;</em> vulgarly called in the present day <span class="ar">وَاوِى</span>;]</span> <em>a certain small beast,</em> <span class="auth">(M, Ḳ,)</span> <em>called in Persian</em> <span class="fa">شَغَالْ</span>, <span class="auth">(Ṣ,)</span> or <em>in that language</em> <span class="add">[or <em>in Turkish</em>]</span> <span class="ar">چَقَالْ</span>: <span class="auth">(TA:)</span> it has been said to be <em>the offspring of the wolf;</em> but is well known to be not of the wolf-kind: <span class="auth">(Mṣb;)</span> <span class="ar">آوَى</span> is inseparable from <span class="ar">ابن</span>: <span class="auth">(M:)</span> it is imperfectly decl., <span class="auth">(T, Ṣ, Mṣb,)</span> being of the measure <span class="ar">أَفْعَلُ</span>, <span class="auth">(Ṣ,)</span> or regarded as such; <span class="auth">(Lth, T;)</span> or because it has the quality of a proper name and the measure of a verb: <span class="auth">(Mṣb:)</span> the pl. is <span class="ar long">بَنَاتُ آوَى</span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> though applying to males <span class="add">[as well as females]</span>, like <span class="ar long">بَنَاتُ أَعْوَجَ</span> and <span class="ar long">بَنَاتُ لَبُون</span>. <span class="auth">(AHeyth, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MwieN">
				<h3 class="entry"><span class="ar">آوِىٌ</span> / <span class="ar">أَوَوِىٌّ</span></h3>
				<div class="sense" id="MwieN_A1">
					<p><span class="ar">آوِىٌ</span> and <span class="ar">أَوَوِىٌّ</span>, <a href="#AyapN">said to be rel. ns. of <span class="ar">آيَةٌ</span>; which see,</a> <a href="index.php?data=01_A/170_Ae">in art. <span class="ar">اى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MyapN">
				<h3 class="entry"><span class="ar">آيَةٌ</span> / <span class="ar">أَوَيَةٌ</span></h3>
				<div class="sense" id="MyapN_A1">
					<p><span class="ar">آيَةٌ</span>, said by some to be originally <span class="ar">أَوَيَةٌ</span>:<a href="index.php?data=01_A/170_Ae">see art. <span class="ar">اى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOowFe">
				<h3 class="entry"><span class="ar">مَأْوًى</span></h3>
				<div class="sense" id="maOowFe_A1">
					<p><span class="ar">مَأْوًى</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">مَأْوٍ↓</span></span> and<span class="arrow"><span class="ar">مَأْوَاهٌ↓</span></span> <span class="auth">(M, Ḳ <span class="add">[but respecting these two forms see what follows]</span>)</span> nouns of place from the first of the verbs in this art.; <span class="auth">(M, Ḳ;)</span> <span class="add">[<em>A place to which one betakes himself,</em> or <em>repairs, for lodging, covert,</em> or <em>refuge; a refuge; an asylum; a place of resort;</em> (<a href="#Awe_1">see 1</a>;)]</span> <em>any place to which a thing betakes itself,</em>, &amp;c., (<span class="ar long">يَأْوِى إِلَيْهِ</span>,) <em>by night or. by day;</em> <span class="auth">(Ṣ;)</span> the <em>lodging-place,</em> or <em>abode,</em> of any animal; the <em>nightly resting-place</em> of sheep or goats; <span class="auth">(Mṣb;)</span> and of camels: <span class="auth">(Idem in art. <span class="ar">روح</span>:)</span> <span class="arrow"><span class="ar">مَأْوٍ↓</span></span> is used peculiarly in relation to camels: <span class="auth">(Ṣ;)</span> <span class="ar long">مَأْوِى الإِبِلِ</span> being a dial. var. of <span class="ar long">مَأْوَى الإِبِلِ</span>, but anomalous, <span class="auth">(Fr, T, Ṣ, Mṣb,)</span> and the only instance of the kind except <span class="ar long">مَأْقِى العَيْنِ</span>: <span class="auth">(Fr, T, M: <span class="add">[<a href="../">but see art. <span class="ar">مأق</span></a>:]</span>)</span> <span class="ar">مَأْوَى</span> and <span class="ar">مُؤْق</span> and <span class="ar">مَأْق</span> are the forms preferred: <span class="auth">(Fr, T:)</span> <span class="add">[Az also says,]</span> I have heard the chaste in speech of the Benoo-Kiláb use, for <span class="ar long">مَأْوَى الإِبِلِ</span>, the word <span class="arrow"><span class="ar">مَأْوَاة↓</span></span>. <span class="auth">(T.)</span> <span class="ar long">جَنَّةُ المَأْوَى</span>, in the Ḳur <span class="add">[liii. 15]</span>, is said to mean <em>The paradise to which repair the souls of the martyrs,</em> <span class="auth">(M, Bḍ, Jel, TA,)</span> or <em>the pious,</em> <span class="auth">(Bḍ, Jel,)</span> or <em>the angels:</em> <span class="auth">(Jel:)</span> or <em>that in which the night is passed.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOowK">
				<h3 class="entry"><span class="ar">مَأْوٍ</span></h3>
				<div class="sense" id="maOowK_A1">
					<p><span class="ar">مَأْوٍ</span>: <a href="#maOowFe">see <span class="ar">مَأْوًى</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOowaApN">
				<h3 class="entry"><span class="ar">مَأْوَاةٌ</span></h3>
				<div class="sense" id="maOowaApN_A1">
					<p><span class="ar">مَأْوَاةٌ</span>: <a href="#maOowFe">see <span class="ar">مَأْوًى</span></a>, in four places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maAwiyBapN">
				<h3 class="entry"><span class="ar">مَاوِيَّةٌ</span></h3>
				<div class="sense" id="maAwiyBapN_A1">
					<p><span class="ar">مَاوِيَّةٌ</span>: <a href="index.php?data=24_m/201_mwh">see art. <span class="ar">موه</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaOawBiyapN">
				<h3 class="entry"><span class="ar">مُتَأَوِّيَةٌ</span></h3>
				<div class="sense" id="mutaOawBiyapN_A1">
					<p><span class="ar">مُتَأَوِّيَةٌ</span>: <a href="#AwK">see <span class="ar">آوٍ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0130.pdf" target="pdf">
							<span>Lanes Lexicon Page 130</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0131.pdf" target="pdf">
							<span>Lanes Lexicon Page 131</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
