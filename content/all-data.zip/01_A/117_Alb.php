<article class="root" id="Root_Alb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/116_AlA">الا</a></span>
				<span class="ar">الب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/118_Alt">الت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Alb_1">
				<h3 class="entry">1. ⇒ <span class="ar">ألب</span></h3>
				<div class="sense" id="Alb_1_A1">
					<p><span class="ar">أَلَبَ</span>, <span class="auth">(Th, M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِبُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْلُبُ</span>}</span></add>, inf. n. <span class="ar">أَلْبٌ</span>, <span class="auth">(M,)</span> <em>It</em> <span class="auth">(a thing, Th, M)</span> <em>was,</em> or <em>became, collected;</em> or <em>compact;</em> syn. <span class="ar">اِجْتَمَعَ</span>; <span class="auth">(Th, Ḳ;)</span> or <span class="ar">تَجَمَّعَ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alb_1_A2">
					<p><span class="ar long">أَلَبَ إِلَيْهِ القَوْمُ</span> <em>The people came to him from every direction:</em> <span class="auth">(M, Ḳ:)</span> or <span class="ar long">أَلَبَ القَوْمُ</span> <span class="add">[signifies <em>the people multiplied themselves, and hastened;</em> for it]</span> denotes <span class="ar">الإِكْثَارُ</span> and <span class="ar">الإِسْرَاع</span>: <span class="auth">(T in art. <span class="ar">ضهب</span>:)</span> and <span class="ar">أَلَبَ</span>, <span class="auth">(T, Ḳ,)</span> aor. as above, <span class="auth">(T,)</span> signifies <em>he hastened,</em> or <em>went quickly.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Alb_1_A3">
					<p><span class="ar long">أَلَبَتِ الإِبِلُ</span> <em>The camels obeyed the driver, and collected themselves together.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#Alb_5">See also 5</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Alb_1_A4">
					<p><span class="ar long">أَلَبَ إِلَيْهِ</span> <em>He returned to him,</em> or <em>it.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Alb_1_A5">
					<p><span class="ar long">أَلَبَتِ السَّمَآءُ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِبُ</span>}</span></add>, <span class="auth">(M,)</span> <em>The sky rained with long continuance.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Alb_1_B1">
					<p><span class="ar">أَلَبَ</span>, <span class="auth">(Ṣ Mṣb, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِبُ</span>}</span></add>, inf. n. <span class="ar">أَلْبٌ</span>, <span class="auth">(Mṣb,)</span> <em>He collected</em> <span class="auth">(Ṣ Mṣb, Ḳ)</span> an army, <span class="auth">(Ṣ,)</span> or a people; <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">ألّب↓</span></span>, <span class="auth">(M,)</span> inf. n. <span class="ar">تَأْلِيبٌ</span>: <span class="auth">(TA:)</span> and camels also: <span class="auth">(TA:)</span> or <span class="ar long">أَلَبَ الإِبِلَ</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْلِبُ</span>}</span></add> <span class="auth">(T,* Ṣ, M, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْلُبُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">أَلْبٌ</span>, <span class="auth">(T, Ṣ,)</span> signifies <em>he collected the camels, and drove them</em> <span class="auth">(Ṣ, TA)</span> <em>vehemently:</em> <span class="auth">(TA:)</span> or <em>he drove them:</em> <span class="auth">(T,* Ḳ:)</span> or <em>he drove them vehemently.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Alb_1_B2">
					<p><span class="ar">أَلَبَ</span>, <span class="auth">(TA,)</span> inf. n. as above, <span class="auth">(Ḳ, TA,)</span> also signifies <em>He drove, pursued, chased,</em> or <em>hunted, with vehemence:</em> <span class="auth">(Ḳ, TA:)</span> and <em>he drove away</em> a people. <span class="auth">(Mṣb.)</span> You say, <span class="ar long">أَلَبَ الحِمَارُ طَرِيدَتَهُ</span> <em>The</em> <span class="add">[wild]</span> <em>ass chased,</em> or <em>pursued, the object of his chase</em> <span class="add">[i. e. his female, as is shown by MF,]</span> <em>with vehemence;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَلَّبَهَا↓</span></span> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alb_2">
				<h3 class="entry">2. ⇒ <span class="ar">ألّب</span></h3>
				<div class="sense" id="Alb_2_A1">
					<p><a href="#Alb_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Alb_2_A2">
					<p><span class="ar">تَأْلِيبٌ</span> also signifies The act of <em>exciting, instigating;</em> or <em>rousing to ardour:</em> <span class="auth">(Ṣ, Ḳ:)</span> and the <em>exciting of discord,</em> or <em>strife,</em> or the <em>making of mischief.</em> <span class="auth">(Ḳ.)</span> you say, <span class="ar long">ألّب بَيْنَهُمْ</span> <em>He excited discord</em> or <em>strife,</em> or <em>made mischief, between them.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Alb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تألّب</span></h3>
				<div class="sense" id="Alb_5_A1">
					<p><span class="ar">تألّبوا</span> <em>They collected themselves together.</em> <span class="auth">(Ṣ, A, Mṣb.)</span> <span class="add">[<a href="#Alb_1">See also 1</a>.]</span> You say also, <span class="ar long">تألّبوا عَلَيْهِ</span> <em>They leagued together,</em> or <em>collected themselves. together, and aided one another, against him.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalobN">
				<h3 class="entry"><span class="ar">أَلْبٌ</span></h3>
				<div class="sense" id="OalobN_A1">
					<p><span class="ar">أَلْبٌ</span> <span class="auth">(T, Ṣ, Mṣb)</span> and<span class="arrow"><span class="ar">إِلْبٌ↓</span></span> <span class="auth">(Ṣ, Mṣb)</span> <em>Persons, or people, collected together;</em> <span class="auth">(Ṣ;)</span> <em>an assembly; a collected body:</em> <span class="auth">(Mṣb:)</span> or <em>a collection of many people:</em> <span class="auth">(T:)</span> and<span class="arrow"><span class="ar long">أَلْبٌ أَلُوبٌ↓</span></span> a <em>great assembly</em> or <em>congregation.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: <span class="ar">أَلْبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OalobN_A2">
					<p>Also <em>A people,</em> or <em>company of men, combining in hostility</em> against a man. <span class="auth">(TA, from a trad.)</span> You say, <span class="ar long">هُمْ عَلَيْهِ أَلْبٌ وَاحِدٌ</span>, and<span class="arrow"><span class="ar">إِلْبٌ↓</span></span>, <span class="auth">(but the former is the better known, M,)</span> <em>They are</em> <span class="add">[<em>one body of men</em>]</span> <em>assembled against him with injustice and enmity</em> or <em>hostility:</em> <span class="auth">(Lth, T, M, Ḳ:)</span> like <span class="ar long">وَعْلٌ وَاحِدٌ</span> and <span class="ar long">صَدْعٌ وَاحِدٌ</span> and <span class="ar long">ضِلَعٌ وَاحِدٌ</span>. <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IilobN">
				<h3 class="entry"><span class="ar">إِلْبٌ</span></h3>
				<div class="sense" id="IilobN_A1">
					<p><span class="ar">إِلْبٌ</span>: <a href="#OalobN">see <span class="ar">أَلْبٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OalabN">
				<h3 class="entry"><span class="ar">أَلَبٌ</span></h3>
				<div class="sense" id="OalabN_A1">
					<p><span class="ar">أَلَبٌ</span> <a href="#yalabN">a dial. var. of <span class="ar">يَلَبٌ</span></a>; <span class="auth">(M;)</span> <em>Helmets of camels' shins:</em> or, as some say, it signifies <em>steel:</em> <span class="auth">(T:)</span> <span class="ar">أَلَبَةٌ</span> is <span class="add">[its n. un., being]</span> <a href="#yalabapN">a dial. var. of <span class="ar">يَلَبَةٌ</span></a>. <span class="auth">(Ḳ,* TA.)</span> <span class="add">[<a href="#yalabN">See also <span class="ar">يَلَبٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaluwbN">
				<h3 class="entry"><span class="ar">أَلُوبٌ</span></h3>
				<div class="sense" id="OaluwbN_A1">
					<p><span class="ar">أَلُوبٌ</span>: <a href="#OalobN">see <span class="ar">أَلْبٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: <span class="ar">أَلُوبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaluwbN_A2">
					<p>Also One <em>who hastens,</em> or <em>is quick;</em> <span class="auth">(T;)</span> and<span class="arrow"><span class="ar">مِئْلَبٌ↓</span></span> likewise signifies <span class="add">[the same; or]</span> <em>quick,</em> or <em>swift:</em> <span class="auth">(Ibn-Buzurj, T, Ḳ:)</span> or the former signifies <em>quick in drawing forth the bucket:</em> <span class="auth">(IAạr, M, Ḳ:)</span> or <em>brisk, lively, sprightly, active, agile,</em> or <em>prompt, and quick;</em> <span class="auth">(Ḳ, TA;)</span> applied to a man. <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0079"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: <span class="ar">أَلُوبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaluwbN_A3">
					<p><span class="ar long">رِيْحٌ أَلُوبٌ</span> <em>A cold wind,</em> <span class="auth">(M,)</span> <em>that raises and scatters the dust.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">الب</span> - Entry: <span class="ar">أَلُوبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaluwbN_A4">
					<p><span class="ar long">سَمَآءٌ أَلُوبٌ</span> <em>A sky raining with long continuance.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="miYolabN">
				<h3 class="entry"><span class="ar">مِئْلَبٌ</span></h3>
				<div class="sense" id="miYolabN_A1">
					<p><span class="ar">مِئْلَبٌ</span>: <a href="#OaluwbN">see <span class="ar">أَلُوبٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWalBibN">
				<h3 class="entry"><span class="ar">مُؤَلِّبٌ</span></h3>
				<div class="sense" id="muWalBibN_A1">
					<p><span class="ar long">حَسُودٌ مُؤَلِّبٌ</span> <span class="add">[An <em>envious</em> man,]</span> <em>who excites discord</em> or <em>strife,</em> or <em>makes mischief.</em> <span class="auth">(Ṣ,* TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0078.pdf" target="pdf">
							<span>Lanes Lexicon Page 78</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0079.pdf" target="pdf">
							<span>Lanes Lexicon Page 79</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
