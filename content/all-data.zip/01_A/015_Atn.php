<article class="root" id="Root_Atn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/014_Atm">اتم</a></span>
				<span class="ar">اتن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/016_Atw">اتو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Atn_1">
				<h3 class="entry">1. ⇒ <span class="ar">أتن</span></h3>
				<div class="sense" id="Atn_1_A1">
					<p><span class="ar long">أَتَنَ بِالمَكَانِ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,*)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْتُنُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> or <span class="ar">ـِ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أُتُونٌ</span> <span class="auth">(M, Mṣb, Ḳ)</span> and <span class="ar">أَتُنٌ</span>, <span class="auth">(Ḳ,)</span> <em>He remained, continued, stayed,</em> or <em>abode, in the place;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;*)</span> or <em>became fixed,</em> or <em>settled, therein.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Atn_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأتن</span></h3>
				<div class="sense" id="Atn_10_A1">
					<p><span class="ar">استأتن</span> <span class="add">[lit.]</span> <em>He</em> <span class="auth">(an ass)</span> <em>became a she-ass.</em> <span class="auth">(M.)</span> The saying, <span class="ar long">كَانَ حِمَارَّا فَاسْتَأْتَنَ</span>, said of a man, <span class="add">[lit.]</span> signifies <span class="add">[<em>He was a he ass,</em>]</span> <em>and he became a she ass;</em> meaning † <em>he was mighty,</em> or <em>of high condition,</em> <span class="add">[like the wild he-ass,]</span> <em>and he became base, abject,</em> or <em>vile.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتن</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Atn_10_A2">
					<p>Also, <span class="auth">(Ṣ, TA,)</span> or <span class="ar long">استأتن أَتَانَّا</span>, <span class="auth">(M,)</span> <em>He</em> <span class="auth">(a man)</span> <em>purchased a she-ass;</em> <span class="auth">(Ṣ;)</span> <em>he took for himself a she-ass.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OataAnN">
				<h3 class="entry"><span class="ar">أَتَانٌ</span></h3>
				<div class="sense" id="OataAnN_A1">
					<p><span class="ar">أَتَانٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">إِتَانٌ↓</span></span>, <span class="auth">(Ḳ,)</span> but one should not say <span class="ar">أَتَانَةٌ</span>, <span class="auth">(ISk, Ṣ, Mṣb,)</span> or this is of rare occurrence, <span class="auth">(Ḳ,)</span> occurring in certain of the trads., <span class="auth">(IAth,)</span> <em>A she-ass</em> <span class="add">[<em>domestic</em> or <em>wild</em>]</span>: <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> pl. <span class="auth">(of pauc., T, Ṣ, Mṣb)</span> <span class="ar">آتُنٌ</span> and <span class="auth">(of mult., T, Ṣ, Mṣb)</span> <span class="ar">أُتُنٌ</span> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أُتْنٌ</span> and <span class="auth">(quasi-pl. n., M)</span> <span class="arrow"><span class="ar">مَأْتُونَآءُ↓</span></span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتن</span> - Entry: <span class="ar">أَتَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OataAnN_A2">
					<p>Hence, <span class="ar">أَتَانٌ</span> signifies ‡ <em>A foolish and soft</em> or <em>weak woman;</em> as being likened to a she-ass. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتن</span> - Entry: <span class="ar">أَتَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OataAnN_A3">
					<p>Also The <em>station of the drawer of water at the mouth of the well;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> and so<span class="arrow"><span class="ar">إِتَانٌ↓</span></span>. <span class="auth">(M, Ḳ.)</span> And <em>A rock,</em> or <em>great mass of stone,</em> <span class="auth">(AA, T, Ṣ, M,)</span> <em>in water;</em> <span class="auth">(AA, T, M;)</span> or, as some say, <em>at the bottom of the casing of a well, so that it is next the water.</em> <span class="auth">(AA, T.)</span> And <em>A large, round mass of rock, which, when it is in shallow water, is called</em> <span class="ar long">أَتَانُ الضَّحلِ</span>; and a she camel is likened thereto, in respect of her hardness: <span class="auth">(Ṣ:)</span> or <span class="ar long">أَتَانُ الضَّحلِ</span> signifies <em>a large mass of rock projecting from the water.</em> <span class="auth">(T:)</span> or <em>a mass of rock,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>large and round, in the water,</em> <span class="auth">(TA,)</span> <em>at the mouth of the well, overspread with</em> <span class="add">[<em>the green substance called</em>]</span> <span class="ar">طُحْلُب</span>, <em>so that it is smooth,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>more smooth than other parts:</em> <span class="auth">(M, TA:)</span> or <em>a mass of rock, part of which is immerged</em> (<span class="ar">غَامِرٌ</span>, M, Ḳ) <em>in the water,</em> <span class="auth">(Ḳ,)</span> <em>and part apparent.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">أَتَانُ الثَّمِيلِ</span> signifies <em>A large mass of rock in the interior of the water-course, which nothing raises or moves, of the measure of the stature of a man in length and likewise in breadth.</em> <span class="auth">(ISh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اتن</span> - Entry: <span class="ar">أَتَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OataAnN_A4">
					<p>Also The <span class="add">[<em>piece of wood called</em>]</span> <span class="ar">قَاعِدَة</span> <span class="add">[<em>which is one of four forming the support</em>]</span> <em>of the</em> <span class="ar">فَوْدَج</span> <span class="add">[more commonly called <span class="ar">هَوْدَج</span>, q. v.]</span>: pl. <span class="ar">آتُنٌ</span>, <span class="auth">(Ḳ, TA,)</span> with medd. <span class="auth">(TA: <span class="add">[but in the CK <span class="ar">اُتُنٌ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IitaAnN">
				<h3 class="entry"><span class="ar">إِتَانٌ</span></h3>
				<div class="sense" id="IitaAnN_A1">
					<p><span class="ar">إِتَانٌ</span>: <a href="#OataAnN">see <span class="ar">أَتَانٌ</span></a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatuwnN">
				<h3 class="entry"><span class="ar">أَتُونٌ</span></h3>
				<div class="sense" id="OatuwnN_A1">
					<p><span class="ar">أَتُونٌ</span> <span class="auth">(T, M, Mgh, Mṣb, Ḳ)</span> and <span class="ar">أَتُّونٌ</span>, <span class="auth">(Ḳ,)</span> or, accord. to J, <span class="auth">(Mṣb,)</span> it is thus, with teshdeed, but pronounced without teshdeed by the vulgar, <span class="auth">(Ṣ, Mṣb,)</span> <em>A certain place in which fire is kindled,</em> <span class="auth">(Ṣ, Mgh,)</span> <em>called in Persian</em> <span class="fa">كُلَخْن</span> <span class="add">[or <span class="fa">كُلْخَنْ</span>]</span>, <em>pertaining to a bath:</em> and metaphorically applied to ‡ <em>that in which bricks are baked, and called in Persian</em> <span class="fa">تُونَقْ</span> <em>and</em> <span class="fa">دَاشُوزَنْ</span> <span class="add">[or simply <span class="fa">تُونْ</span> and <span class="fa">دَاشْ</span>]</span>: <span class="auth">(Mgh:)</span> accord. to Az, <span class="auth">(Mṣb,)</span> it is <em>that of the bath,</em> and <em>of the place in which gypsum is made:</em> <span class="auth">(T, Mṣb:)</span> or the <em>trench, hollow,</em> or <em>pit, of the</em> <span class="ar">جَيَّارَ</span> <span class="add">[or <em>lime-burner,</em> <span class="auth">(in the CK, erroneously, the <span class="ar">خَبّاز</span>,)</span>]</span> and <em>of the preparer of gypsum;</em> <span class="auth">(M, Ḳ, TA;)</span> and <em>the like:</em> <span class="auth">(Ḳ:)</span> the pl. <span class="add">[said in the TA to be of the latter, but it is implied in the T and M and Mgh that it is of the former,]</span> is <span class="ar">أَتَاتِينُ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ, <span class="add">[in the CK, erroneously, <span class="ar">اَتانِيْنُ</span>,]</span>)</span> by common consent of the Arabs, <span class="auth">(Mgh,)</span> with two <span class="ar">ت</span> s, <span class="auth">(T,)</span> accord. to Fr, who says that they sometimes double a letter in the pl. when they do not double it in the sing., <span class="auth">(T,)</span> and accord. to IJ, who says that it seems as though they changed <span class="ar">أَتُونٌ</span> to <span class="ar">أَتُّونٌ</span>; <span class="auth">(M;)</span> and <span class="add">[of <span class="ar">أَتُونٌ</span>, as is said in the TA and implied in the M,]</span> <span class="ar">أُتُنٌ</span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[J says that]</span> it is said to be post-classical; <span class="auth">(Ṣ;)</span> <span class="add">[and ISd says,]</span> I do not think it to be Arabic. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOotuwnaMCu">
				<h3 class="entry"><span class="ar">مَأْتُونَآءُ</span></h3>
				<div class="sense" id="maOotuwnaMCu_A1">
					<p><span class="ar">مَأْتُونَآءُ</span>: <a href="#OataAnN">see <span class="ar">أَتَانٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0014.pdf" target="pdf">
							<span>Lanes Lexicon Page 14</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
