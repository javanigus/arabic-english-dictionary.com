<article class="root" id="Root_AsTrlAb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/078_Asr">اسر</a></span>
				<span class="ar">اسطرلاب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/080_Asf">اسف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="OasoTurolaAbN">
				<h3 class="entry"><span class="ar">أَسْطُرْلَابٌ</span> / <span class="ar">أُسْطُرْلَابٌ</span></h3>
				<div class="sense" id="OasoTurolaAbN_A1">
					<p><span class="ar">أَسْطُرْلَابٌ</span> or <span class="ar">أُسْطُرْلَابٌ</span>, <span class="add">[accord. to different copies of the Ḳ,]</span> and with <span class="ar">ص</span> in the place of <span class="ar">س</span>, <span class="add">[from the Greek <span class="gr">ἀστρολαβόν</span>, <em>An astrolabe:</em> a word of which F gives the following fanciful derivation:]</span> <span class="ar">لاب</span> was a man who traced some lines, and founded upon them calculations; whence <span class="ar">أَسْطُرُلَابٍ</span> <span class="add">[the lines of Láb]</span>, from which was formed the compound word <span class="ar">اسطرلاب</span>, and <span class="ar">اصطرلاب</span>, the <span class="ar">س</span> being changed into <span class="ar">ص</span> because of the <span class="ar">ط</span> following. <span class="auth">(Ḳ in art. <span class="ar">لوب</span>.)</span> It is either an arabicized or a post-classical word: accord. to the Niháyet el-Adab, the names of all the instruments by which time is known, whether by means of calculation or water or sand, are foreign to the Arabic language. <span class="auth">(MF.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0058.pdf" target="pdf">
							<span>Lanes Lexicon Page 58</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
