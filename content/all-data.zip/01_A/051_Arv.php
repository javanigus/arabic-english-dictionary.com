<article class="root" id="Root_Arv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/050_Arb">ارب</a></span>
				<span class="ar">ارث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/052_Arj">ارج</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Arv_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرث</span></h3>
				<div class="sense" id="Arv_1_A1">
					<p><span class="ar">أَرَثَ</span>: <a href="#Arv_2">see 2</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arv_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّث</span></h3>
				<div class="sense" id="Arv_2_A1">
					<p><span class="ar">أرّث</span>, <span class="auth">(M, A,)</span> inf. n. <span class="ar">تَأْرِيثٌ</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> <em>He kindled,</em> or <em>lighted,</em> a fire; or <em>made</em> it <em>to burn, burn up, burn brightly</em> or <em>fiercely, blaze,</em> or <em>flame;</em> <span class="auth">(T, Ṣ, M, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَرَثَ↓</span></span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُثُ</span>}</span></add>, <span class="auth">(T, Ḳ,)</span> inf. n. <span class="ar">أَرْثٌ</span>; <span class="auth">(Ḳ; in a copy of the A <span class="ar">إِرْثٌ</span>;)</span> but this <span class="add">[says SM]</span> no leading lexicographer has mentioned, nor have I found any example of it. <span class="auth">(TA.)</span> <span class="add">[<a href="#warBava">See also <span class="ar">وَرَّثَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارث</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Arv_2_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">تأريث</span> also signifies ‡ The <em>exciting discord, dissension, disorder, strife, quarrelling,</em> or <em>animosity, between a people.</em> <span class="auth">(Ṣ, Ḳ.)</span> You say, <span class="ar long">أرَث بَيْنَ القَوْمِ</span>, <span class="auth">(M, A,)</span> and <span class="ar long">أرّث بَيْنَهُمُ الشَّرَّ وَالحَرْبَ</span>, <span class="auth">(T, TA,)</span> ‡ <em>He excited discord, dissension, disorder, strife, quarrelling,</em> or <em>animosity, between,</em> or <em>among, the people,</em> or <em>company of men;</em> <span class="auth">(T, M, A;)</span> <em>kindled the fire of discord, dissension,</em>, &amp;c., <span class="add">[or <em>evil,</em> and <em>war,</em>]</span> <em>between them,</em> or <em>among them.</em> <span class="auth">(T,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Arv_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأرّث</span></h3>
				<div class="sense" id="Arv_5_A1">
					<p><span class="ar long">تَأَرَّثَتِ النَّارُ</span> <em>The fire became kindled,</em> or <em>lighted;</em> or <em>it burned, burned up, burned brightly</em> or <em>fiercely, blazed,</em> or <em>flamed.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IirovN">
				<h3 class="entry"><span class="ar">إِرْثٌ</span></h3>
				<div class="sense" id="IirovN_A1">
					<p><span class="ar">إِرْثٌ</span>, originally <span class="ar">وِرْثٌ</span>, <span class="auth">(T, Ṣ,)</span> <em>Inheritance;</em> or a person's <em>obtaining possession of property left to</em> him <em>by one who has died.</em> <span class="auth">(MF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارث</span> - Entry: <span class="ar">إِرْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IirovN_A2">
					<p><em>An inheritance,</em> or <em>a heritage; what is inherited.</em> <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارث</span> - Entry: <span class="ar">إِرْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IirovN_A3">
					<p><em>An old condition, case,</em> or <em>state of things, which the last has inherited from the first.</em> <span class="auth">(Ṣ, A, Ḳ.)</span> So in the phrase, <span class="ar long">هُوَ عَلَى إِرْثٍ مِنْ كَذَا</span> <span class="add">[<em>He is conforming, in respect of such a thing, with an old state of things,</em> or <em>an old usage, which he has inherited from his ancestors</em>]</span>. <span class="auth">(Ṣ.)</span> And in the following ex., from a trad., <span class="ar long">إِنَّكُمْ عَلَى إِرْثٍ مِنْ إِرْثِ أَبِيكُمْ إِبْرَاهِيمَ</span> <span class="add">[<em>Verily ye are conforming with an old state of things,</em> or <em>an old usage, which ye have inherited from your father Abraham</em>]</span>, the meaning is, that his religion was their heritage. <span class="auth">(T,* TA.)</span> <span class="add">[<a href="#wirovN">See also <span class="ar">وِرْثٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارث</span> - Entry: <span class="ar">إِرْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IirovN_A4">
					<p><em>A remainder,</em> or <em>what remains,</em> <span class="auth">(M, L, Ḳ,)</span> of a thing, <span class="auth">(Ḳ,)</span> or <em>of the original</em> of a thing: <span class="auth">(M, L:)</span> pl. <span class="ar">إِرَاثٌ</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارث</span> - Entry: <span class="ar">إِرْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IirovN_A5">
					<p>And <span class="add">[hence, app.,]</span> <em>Ashes.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارث</span> - Entry: <span class="ar">إِرْثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IirovN_A6">
					<p>Also <em>Origin, race,</em> or <em>stock.</em> <span class="auth">(Ṣ, M, A, Ḳ.)</span> You say, <span class="ar long">هُوَ فِى إِرْثِ صِدْقٍ</span> <em>He is of an excellent origin, race,</em> or <em>stock.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">إِنَّهُ لَفِى إِرْثِ مَجْدٍ</span> <span class="add">[<em>Verily he is of a glorious origin, race,</em> or <em>stock</em>]</span>; as also <span class="ar long">إِرْفِ مَجْدٍ</span>, by a change of letters. <span class="auth">(Yaạḳoob, M.)</span> Accord. to IAạr, <span class="ar">إِرْثٌ</span> relates to <span class="ar">حَسَب</span> <span class="add">[or grounds of pretension to respect or honour, on account of one's ancestors' or one's own deeds or qualities, &amp;c.]</span>; and <span class="ar">وِرْثٌ</span>, to property, or wealth. <span class="auth">(M.)</span> <span class="add">[<a href="index.php?data=27_w/087_wrv">See art. <span class="ar">ورث</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OurovapN">
				<h3 class="entry"><span class="ar">أُرْثَةٌ</span></h3>
				<div class="sense" id="OurovapN_A1">
					<p><span class="ar">أُرْثَةٌ</span>: <a href="#IiraAtN">see <span class="ar">إِرَاتٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiraAvN">
				<h3 class="entry"><span class="ar">إِرَاثٌ</span></h3>
				<div class="sense" id="IiraAvN_A1">
					<p><span class="ar">إِرَاثٌ</span> <em>Fire;</em> <span class="auth">(T, M, L, Ḳ;)</span> as also<span class="arrow"><span class="ar">إِرَاثَةٌ↓</span></span> and<span class="arrow"><span class="ar">أَرِيثٌ↓</span></span>: <span class="auth">(TA:)</span> or <span class="auth">(so accord. to the M and <em>L,</em> but in the Ḳ “and”)</span> <em>tinder,</em> and <em>the like, prepared for fire;</em> <span class="auth">(M, L, Ḳ;)</span> <span class="add">[as also<span class="arrow"><span class="ar">إِرَاثَةٌ↓</span></span> and<span class="arrow"><span class="ar">أُرْثَةٌ↓</span></span>; <em>or</em> these two words signify <em>a means of kindling</em> or <em>inflaming;</em> as will be seen from what follows:]</span> or <em>a lump of the dung of a horse or the like,</em> or <em>a similar thing, with which one kindles a fire;</em> as also<span class="arrow"><span class="ar">أُرْثَةٌ↓</span></span>: <span class="auth">(A:)</span> or this last signifies <em>dung of camels or horses or the like,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>wood,</em> or <em>a stick,</em> <span class="auth">(T,)</span> <em>that is prepared,</em> or <em>put in readiness, by the ashes,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>buried in them,</em> <span class="auth">(T,)</span> <em>for the time when it may be wanted</em> <span class="auth">(T, Ṣ, Ḳ)</span> <em>for fuel.</em> <span class="auth">(T.)</span> It is said in a prov., mentioned in the collection of Meyd, <span class="arrow"><span class="ar">النَّمِيمَةُ</span>↓ AlEadaAwapi</span> <span class="add">[<em>Calumny,</em> or <em>slander, is a means of kindling,</em> or <em>inflaming, enmity</em>]</span>. <span class="auth">(TA: but in Freytag's Arab. Prov., ii. 773, in the place of <span class="ar">اراثة</span>, we find<span class="arrow"><span class="ar">أُرْثَة↓</span></span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OariyvN">
				<h3 class="entry"><span class="ar">أَرِيثٌ</span></h3>
				<div class="sense" id="OariyvN_A1">
					<p><span class="ar">أَرِيثٌ</span>: <a href="#IiraAtN">see the paragraph next preceding</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiraAvapN">
				<h3 class="entry"><span class="ar">إِرَاثَةٌ</span></h3>
				<div class="sense" id="IiraAvapN_A1">
					<p><span class="ar">إِرَاثَةٌ</span>: <a href="#IiraAvN">see <span class="ar">إِرَاثٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0046.pdf" target="pdf">
							<span>Lanes Lexicon Page 46</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
