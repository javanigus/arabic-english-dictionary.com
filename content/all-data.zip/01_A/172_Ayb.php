<article class="root" id="Root_Ayb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/171_AyA">ايا</a></span>
				<span class="ar">ايب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/173_Ayd">ايد</a></span>
			</h2>
			<h4 class="root">For words which might be supposed to be properly mentioned under this head, 
							<a href="index.php?data=01_A/157_Awb">see art. <span class="ar">اوب</span></a>.</h4>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0136.pdf" target="pdf">
							<span>Lanes Lexicon Page 136</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
