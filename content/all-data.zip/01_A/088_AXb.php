<article class="root" id="Root_AXb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/087_Ase">اسى</a></span>
				<span class="ar">اشب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/089_AXr">اشر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AXb_1">
				<h3 class="entry">1. ⇒ <span class="ar">أشب</span></h3>
				<div class="sense" id="AXb_1_A1">
					<p><span class="ar">أَشَبَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْشِبُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">أَشْبٌ</span>, <span class="auth">(M, TA,)</span> <em>He mixed it.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">أَشَبْتُ القَوْمَ</span>; <span class="auth">(Ṣ;)</span> or<span class="arrow"><span class="ar">أَشَّبْتُهُمْ↓</span></span>, inf. n. <span class="ar">تَأْشِيبٌ</span>; <span class="auth">(TA;)</span> <em>I mixed the peogle together.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AXb_1_A2">
					<p>Also, aor. as above, <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">ـُ</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> † <em>He charged him with a vice, fault,</em> or <em>the like; blamed, censured,</em> or <em>reprehended, him:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>he aspersed, reviled,</em> or <em>reproached, him, and mixed up falsehood in his aspersion of him.</em> <span class="auth">(TA.)</span> You say also, <span class="ar long">أَشَبَهُ بِشرٍّ</span> <span class="add">[i. e. <span class="ar">بِشَرٍّ</span> or <span class="ar">بِشُرٍّ</span>]</span> † <em>He cast upon him a stigma,</em> or <em>mark of dishonour, by which he became known:</em> <span class="auth">(Lḥ, TA:)</span> or <em>he cast a censure,</em> or <em>reproach, upon him, and involved him in it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="AXb_1_B1">
					<p><span class="ar long">أَشِبَ الشَّجَرُ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْشَبُ</span>}</span></add>, <span class="auth">(A, Ḳ,)</span> inf. n. <span class="ar">أَشَبٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">تأشّب↓</span></span>; <span class="auth">(Ḳ;)</span> or <span class="ar long">أَشِبَتِ الغَيْضَةُ</span>; <span class="auth">(Ṣ;)</span> <em>The collection of trees,</em> or <em>the thicket, was,</em> or <em>became, dense, tangled, confused, intertwined,</em> or <em>complicated:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>very dense,</em> or <em>much tangled</em> or <em>confused, so as to be impassable.</em> <span class="auth">(AḤn, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="AXb_1_B2">
					<p><span class="add">[Hence,]</span> <span class="ar long">أَشِبَ الكَلَامُ بَيْنَهُمْ</span> † <em>Their speech, one with another, became confused,</em> or <em>intricate.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="AXb_1_B3">
					<p>And <span class="ar long">أَشِبَ الشَّرُّ لِلَّئِيمِ</span> <em>Evil clave to the ignoble.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AXb_2">
				<h3 class="entry">2. ⇒ <span class="ar">أشّب</span></h3>
				<div class="sense" id="AXb_2_A1">
					<p><span class="ar">أشّبهُ</span>, inf. n. <span class="ar">تَأْشِيبٌ</span>, <em>He rendered it</em> <span class="auth">(a collection of trees)</span> <em>dense, tangled, confused, intertwined,</em> or <em>complicated.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AXb_2_A2">
					<p><span class="ar long">أَشَبْتُ القَومَ</span>: <a href="#AXb_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AXb_2_A3">
					<p><span class="ar long">أشّب الكَلَامَ بَيْنَهُمْ</span> † <em>He made their speech, one with another, confused,</em> or <em>intricate.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="AXb_2_A4">
					<p><span class="ar long">أشّب الشَّرَّ بَيْنَهُمْ</span> † <em>He occasioned confusion, discord,</em> or <em>mischief, between them.</em> <span class="auth">(Lth.)</span> And hence, <span class="auth">(TA,)</span> <span class="ar">تَأْشِيبٌ</span> signifies also The <em>exciting discord, dissension, disorder, strife, quarrelling,</em> or <em>animosity,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <span class="ar long">بَيْنَ قَومٍ</span> <em>between,</em> or <em>among, a people.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AXb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأشّب</span></h3>
				<div class="sense" id="AXb_5_A1">
					<p><span class="ar">تأشّب</span>: <a href="#AXb_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="AXb_5_A2">
					<p><span class="ar">تأشّبوا</span> † <em>They were,</em> or <em>became, mixed,</em> or <em>confounded together;</em> as also<span class="arrow"><span class="ar">ائتشبوا↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَشَبُوا</span>]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="AXb_5_A3">
					<p>‡ <em>They assembled,</em> or <em>congregated, themselves</em> <span class="auth">(A, Ḳ)</span> <em>from different parts;</em> <span class="auth">(TA;)</span> as also<span class="arrow"><span class="ar">ائتشبوا↓</span></span> <span class="auth">(Ḳ.)</span> And <span class="ar long">تأشّبوا إِلَيْهِ</span> † <em>They drew themselves together to him,</em> <span class="auth">(Ḳ, TA,)</span> <em>and crowded densely upon him;</em> or <em>collected themselves together to him, and surrounded him.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AXb_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائتشب</span></h3>
				<div class="sense" id="AXb_8_A1">
					<p><a href="#AXb_5">see 5</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaXabN">
				<h3 class="entry"><span class="ar">أَشَبٌ</span></h3>
				<div class="sense" id="OaXabN_A1">
					<p><span class="ar">أَشَبٌ</span> <a href="#AXb_1">inf. n. of <span class="ar">أَشِبَ</span></a>. <span class="auth">(TA.)</span></p>	
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: <span class="ar">أَشَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaXabN_A2">
					<p><span class="add">[Hence,]</span> <em>Confusedness; dubiousness:</em> so in the saying, <span class="ar long">ضَرَبَتْ فِيهِ فُلَانَةُ بِعِرْقٍ ذِى أَشَبٍ</span> i. e. <span class="ar long">ذِى ٱلْتِبَاسٍ</span>. <span class="auth">(Ṣ.)</span> <a href="index.php?data=15_D/028_Drb">See art. <span class="ar">ضرب</span></a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: <span class="ar">أَشَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaXabN_A3">
					<p>Also <em>An abundance of trees.</em> <span class="auth">(TA.)</span> In a trad. of Ibn-Umm-Mektoom, <span class="ar long">إِنِّى رَجُلٌ ضَرِيرٌ بَيْنِى وَبَيْنَكَ أَشَبٌ فَرَخِّصْ لِى فِى العِشَآءِ وَالفَجْرِ</span> means <em>Verily I am a blind man,</em> <span class="add">[and]</span> <em>between me and thee are palm-trees confusedly disposed; therefore grant thou me indulgence with respect to</em> <span class="add">[coming to thee to perform the prayers of]</span> <em>the nightfall and the daybreak.</em> <span class="auth">(Ḳ,* MF, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaXibN">
				<h3 class="entry"><span class="ar">أَشِبٌ</span></h3>
				<div class="sense" id="OaXibN_A1">
					<p><span class="ar">أَشِبٌ</span> <em>Dense, tangled, confused, intertwined,</em> or <em>complicated;</em> applied to a collection of trees: <span class="auth">(Ṣ, TA:)</span> or <em>so dense,</em> or <em>so much tangled</em> or <em>confused, as to be impassable;</em> applied to a thicket: <span class="auth">(A:)</span> and a place <em>abounding with trees:</em> <span class="auth">(TA:)</span> applied also to ‡ a collection of clouds, meaning <em>commingled:</em> <span class="auth">(A:)</span> and to † a number, meaning <em>intricate,</em> or <em>confused.</em> <span class="auth">(Ṣ, TA.)</span> It is said in a prov., <span class="ar long">عِيصُكَ مَنْكَ وَإِنْ كَانَ أَشِبًا</span> <span class="auth">(A,)</span> meaning ‡ <span class="add">[<em>Thy stock is an appertenance of thine</em>]</span> <em>although it be thorny and intricate</em> or <em>confused.</em> <span class="auth">(TA. <span class="add">[<a href="index.php?data=18_E/259_EyS">See art. <span class="ar">عيص</span></a>]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OuXaAbapN">
				<h3 class="entry"><span class="ar">أُشَابَةٌ</span></h3>
				<div class="sense" id="OuXaAbapN_A1">
					<p><span class="ar">أُشَابَةٌ</span> ‡ <em>A medley,</em> or <em>mixed</em> or <em>promiscuous multitude</em> or <em>assemblage,</em> of men, or people; <span class="auth">(Ṣ, A, L, Ḳ)</span> <em>congregated from every quarter:</em> <span class="auth">(L:)</span> pl. <span class="ar">أَشَائِبُ</span>. <span class="auth">(Ṣ, Ḳ.*)</span> You say, <span class="ar long">هٰؤُلَآءِ أُشَابَةٌ</span> ‡ <em>These are a collection</em> <span class="add">[of people]</span> <em>from different places.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: <span class="ar">أُشَابَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OuXaAbapN_A2">
					<p>Also ‡ <em>Mixtures of unlawful and lawful kinds</em> of property: <span class="auth">(A:)</span> or <em>what is mixed with that which has been unlawfully acquired;</em> <span class="auth">(Ḳ, TA;)</span> <em>that in which is no good;</em> <span class="auth">(TA;)</span> of gains: pl. as above. <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoXuwbN">
				<h3 class="entry"><span class="ar">مَأْشُوبٌ</span></h3>
				<div class="sense" id="maOoXuwbN_A1">
					<p><span class="ar long">مَأْشُوبٌ الحَسَبِ</span> † <em>Not pure in his grounds of pretension to respect.</em> <span class="auth">(ISd, TA.)</span> <span class="add">[See also what follows.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWotaXabN">
				<h3 class="entry"><span class="ar">مُؤْتَشَبٌ</span></h3>
				<div class="sense" id="muWotaXabN_A1">
					<p><span class="ar long">جَمْعٌ مُؤْتَشَبٌ</span> and <span class="ar">مُؤْتَشِبٌ</span> ‡ <span class="add">[<em>A mixed collection of people</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اشب</span> - Entry: <span class="ar">مُؤْتَشَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWotaXabN_A2">
					<p><span class="ar long">فُلَانٌ مُؤْتَشَبٌ</span>, <span class="auth">(Ṣ, Ḳ,*)</span> with fet-ḥ <span class="add">[to the <span class="ar">ش</span>]</span>, <span class="auth">(Ḳ,)</span> in one copy of the Ḳ, <span class="ar">مُؤَشَّبٌ</span>, <span class="auth">(TA,)</span> † <em>Such a one is of mixed, not of pure, race,</em> or <em>lineage.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0061.pdf" target="pdf">
							<span>Lanes Lexicon Page 61</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
