<article class="root" id="Root_Are">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/061_Arm">ارم</a></span>
				<span class="ar">ارى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/063_Az">از</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Are_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرى</span></h3>
				<div class="sense" id="Are_1_A1">
					<p><span class="ar long">أَرَتِ الدَّابَّةُ مَرْبَطَهَا</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar">مِعْلَفَهَا</span>, <span class="add">[aor. <span class="ar">تَأْرِى</span>,]</span> inf. n. <span class="ar">أَرْىٌ</span>, <span class="auth">(M,)</span> <em>The beast kept to its place where it was tied,</em> <span class="auth">(M, Ḳ,)</span> and <em>to its manger.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارى</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Are_1_A2">
					<p><span class="ar long">أَرَتِ الدَّابِّةُ إِلَى الدَّابَّةِ</span>, <span class="auth">(Ḳ,)</span> aor. as above, <span class="auth">(Ṣ,)</span> and so the inf. n., <span class="auth">(TA,)</span> <em>The beast joined itself,</em> or <em>became joined, to the beast, and kept with it to one manger.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Are_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّى</span></h3>
				<div class="sense" id="Are_2_A1">
					<p><span class="ar long">أَرَّيْتُ لِلدَّابَّةِ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and <span class="ar">الدَّابَّةَ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تأْرِيَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> <em>I made for the beast an</em> <span class="ar">آرِىّ</span> <span class="add">[q. v.]</span>, <span class="auth">(Ṣ,* M,)</span> or <em>an</em> <span class="ar">آرِيَّة</span>. <span class="auth">(Ḳ: <span class="add">[in the CK <span class="ar">اَرِيَّة</span>; but this and <span class="ar">آرِيَّة</span> are probably mistakes of copyists.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارى</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Are_2_A2">
					<p><span class="ar long">أَرَّىَ الشَّىْءَ</span>, inf. n. as above, <em>He rendered the thing permanent,</em> or <em>steadfast; confirmed it; established it.</em> <span class="auth">(M, Ḳ.)</span> Hence, in a trad., <span class="ar long">اَللٰهُمَّ أَرِّمَا بَيْنَهُمْ</span>, i. e. <em>O God, make permanent,</em> or <em>confirm,</em> or <em>establish, what is between them, of love,</em> or <em>affection;</em> said in praying for a man and his wife. <span class="auth">(M, TA.)</span> Moḥammad is also related to have said, with this intention, <span class="ar long">اَللٰهُمَّ أَرِّبَيْنَهُمَا</span>, meaning <em>O God, render permanent,</em> or <em>confirm, the union,</em> or <em>concord,</em> or <em>love, of them tow;</em> <span class="auth">(AʼObeyd, TA;)</span> or <em>cause union to subsist, and render permanent,</em> or <em>confirm, love,</em> or <em>affection, between them two:</em> <span class="auth">(IAth, TA:)</span> or <span class="ar long">اَللٰهُمَّ أَرِّ كُلَّ وَاحِدٍ مِنْهُمَا صَاحِبَهُ</span>, meaning <em>O God, confine each of them two to the other, so that the heart of neither may become turned away to any but that other:</em> the correct form of speech, however, is <span class="ar long">عَلَى صَاحِبِهِ</span>, unless it be like <span class="ar long">تَعَلَّقْتُ فُلَانًا</span> for <span class="ar long">تعلّقت بِفُلَانٍ</span>. <span class="auth">(IAmb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Are_4">
				<h3 class="entry">4. ⇒ <span class="ar">آرى</span></h3>
				<div class="sense" id="Are_4_A1">
					<p><span class="ar long">آرَيْتُ الدَّابَّةَ</span> <em>I joined the beast to another beast, and made it to keep with the other to one manger:</em> <span class="auth">(Ṣ, in the present art.; and Ḳ:)</span> or <span class="ar long">آرَيْتُ الدَّابَّتَيْنِ</span> <em>I joined the two beasts together, and made them both keep to one manger.</em> <span class="auth">(So accord. to the Ṣ in art. <span class="ar">وأر</span>.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Are_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأرّى</span></h3>
				<div class="sense" id="Are_5_A1">
					<p><span class="ar long">تأرّى بِالمَكَانِ</span> <em>He remained, stayed,</em> or <em>abode, in the place:</em> <span class="auth">(Ṣ, Mgh, Mṣb:)</span> or <em>he became confined,</em> or <em>he confined himself, therein;</em> <span class="auth">(T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">ائتري↓</span></span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَرَى</span>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Are_5_A2">
					<p><span class="ar">تأرّىعَنْهُ</span> <em>He remained behind him, not going with him; held back,</em> or <em>hung back, from him.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Are_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائترى</span></h3>
				<div class="sense" id="Are_8_A1">
					<p><a href="#Are_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OarieBN">
				<h3 class="entry"><span class="ar">أَرِىٌّ</span></h3>
				<div class="sense" id="OarieBN_A1">
					<p><span class="ar">أَرِىٌّ</span>: <a href="#ArieBN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OariyBapN">
				<h3 class="entry"><span class="ar">أَرِيَّةٌ</span></h3>
				<div class="sense" id="OariyBapN_A1">
					<p><span class="ar">أَرِيَّةٌ</span>: <a href="#ArieBN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MrK">
				<h3 class="entry"><span class="ar">آرٍ</span></h3>
				<div class="sense" id="MrK_A1">
					<p><span class="ar">آرٍ</span>: <a href="#ArieBN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MrieBN">
				<h3 class="entry"><span class="ar">آرِىٌّ</span></h3>
				<div class="sense" id="MrieBN_A1">
					<p><span class="ar">آرِىٌّ</span>, <span class="auth">(T, Ṣ, M, Mgh, Mṣb, Ḳ,)</span> with medd and teshdeed, <span class="auth">(TA,)</span> <span class="add">[originally <span class="ar">آرُوىٌ</span>,]</span> of the measure <span class="ar">فَاعُولٌ</span>, <span class="auth">(T, Ṣ, Mgh, Mṣb,)</span> from <span class="ar long">تَأَرَّى بِالمَكَانِ</span> as explained above, <span class="auth">(Mgh,)</span> or hence this verb, <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar">أَرِىٌّ↓</span></span>, <span class="auth">(M, Ḳ,* <span class="add">[but accord. to the latter, the second form may be either thus (as it is written in the M)</span> or<span class="arrow"><span class="ar">آرٍ↓</span></span>, <span class="auth">(agreeably with the latter of the two pls. mentioned below,)</span> for the two forms are there expressed by <span class="ar long">الآرِىُّ وَيُخَفَّفُ</span>, <span class="auth">(in the CK, erroneously, <span class="ar long">الاَرىُّ و يُخَفَّفُ</span>,)</span> and in another place in the Ḳ we find it written <span class="arrow"><span class="ar">آرِيَّة↓</span></span>, or, as in the CK, <span class="arrow"><span class="ar">اَرِيَّة↓</span></span>,]</span>) The <em>place of confinement of a beast:</em> <span class="auth">(ISk, T, Ṣ:)</span> or <em>i. q.</em> <span class="ar">آخِيَّةٌ</span>; <span class="auth">(M, Mgh, Mṣb, Ḳ;)</span> used in this sense by the Arabs; <span class="auth">(Mgh, Mṣb,;)</span> or sometimes having this application; meaning <em>a rope to which a beast is tied in its place of confinement;</em>; <span class="auth">(Ṣ;)</span> or <em>a loop of a rope to which a beast is tied in that place:</em> <span class="auth">(Mgh:)</span> so called because it withholds beasts from escaping: <span class="auth">(TA:)</span> sometimes, <span class="auth">(Mṣb,)</span> improperly, <span class="auth">(ISK, T, Ṣ,)</span> by the vulgar, and by the lawyers, <span class="auth">(Mgh,)</span> applied to <em>a manger:</em>:<span class="auth">(ISk, T, Ṣ, Mgh, Mṣb:)</span> pl. <span class="ar">أَوَارِىُّ</span> <span class="auth">(T, Ṣ, Mgh, Mṣb)</span> and <span class="ar">أَوَارٍ</span> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارى</span> - Entry: <span class="ar">آرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MrieBN_A2">
					<p>Hence, <span class="ar">أَوَارِىُّ</span> is metaphorically applied to ‡ The <em>places</em> (<span class="ar">أَحْيَاز</span>) <em>that are made, in shops, for grain and other things:</em> and to ‡ the <em>water-tanks,</em> or <em>troughs, in a bath.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<span class="pb" id="Page_0052"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارى</span> - Entry: <span class="ar">آرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MrieBN_A3">
					<p>El-ʼAjjáj says, describing a <span class="add">[wild]</span> bull, and his covert,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَٱعْتَادَ أَرْبَاضَّا لَهَا آرِىُّ</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>And he frequented lodging-places</em>]</span> <em>having a firm foundation for the quiet of the wild animals therein</em> <span class="add">[as having been from the first occupied by such animals and unfrequented by men]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارى</span> - Entry: <span class="ar">آرِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MrieBN_A4">
					<p><span class="ar">آرِىٌّ</span> is also said to signify <em>Land of a kind between even and rugged.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MriyBapN">
				<h3 class="entry"><span class="ar">آرِيَّةٌ</span></h3>
				<div class="sense" id="MriyBapN_A1">
					<p><span class="ar">آرِيَّةٌ</span>: <a href="#ArieBN">see <span class="ar">آرِىٌّ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0051.pdf" target="pdf">
							<span>Lanes Lexicon Page 51</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0052.pdf" target="pdf">
							<span>Lanes Lexicon Page 52</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
