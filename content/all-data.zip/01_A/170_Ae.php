<article class="root" id="Root_Ae">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/169_Awe">اوى</a></span>
				<span class="ar">اى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/171_AyA">ايا</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ae_2">
				<h3 class="entry">2. ⇒ <span class="ar">أىّى</span></h3>
				<div class="sense" id="Ae_2_A1">
					<p><span class="ar long">أَيَّا آيَةً</span>, <span class="add">[inf. n., by rule, as below,]</span> <em>He put,</em> or <em>set, a sign, token,</em> or <em>mark, by which a person or thing might be known.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ae_2_B1">
					<p><span class="ar long">أَيَّا بِلإِبِلِ</span>, <span class="auth">(inf. n. <span class="ar">تَأْييَةٌ</span>, Lth, T,)</span> <em>He chid the camels, saying to them</em> <span class="ar">أَيَايَا</span>, <span class="auth">(Lth, T, M, and Ḳ in art. <span class="ar">أَيَا</span>,)</span> or <span class="ar">أَيَايَهْ</span>, <span class="auth">(M,)</span> or <span class="ar">يَايَا</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">يَايَهْ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ae_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأىّى</span></h3>
				<div class="sense" id="Ae_5_A1">
					<p><span class="ar">تأيّا</span>, as a trans. verb: <a href="#Ae_6">see 6</a>.</p>	
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ae_5_B1">
					<p><em>He paused, stopped, stayed, remained,</em> or <em>tarried,</em> <span class="auth">(T, Ṣ, M, Ḳ,*)</span> <span class="ar long">بِا لمَكَانِ</span> <em>in the place;</em> <span class="auth">(M, Ḳ;* <span class="add">[in the latter explained by <span class="ar long">تَلَبَّثَ عَلَيْهِ</span>; but this seems to be a mistake, arising from the omission of part of a passage in the M, (one of the chief sources of the Ḳ,)</span> running thus; <span class="ar long">تَأَيَّا بِا لمَكَانِ تَلَبَّثَ وَتَمَكَّثَ وَتَأَيَّا عَلَيْهِ ٱنْصَرَفَ فِى تُؤَدَةٍ</span>;]</span>) and <em>confined, restricted, limited, restrained,</em> or <em>withheld, himself.</em> <span class="auth">(T.)</span> In the sense of its inf. n., <span class="add">[by rule <span class="ar">تَأَىّ</span>, originally <span class="ar">تَأَيُّىٌ</span>,]</span> they said <span class="arrow"><span class="ar">تَأَيَّةٌ↓</span></span>, or <span class="ar">تَإِيَّةٌ</span> or <span class="ar">تَئِيَّةٌ</span>; <span class="add">[thus differently written in different places in copies of the T and Ṣ;]</span> as in the ex. <span class="ar long">لَيْسَ مَنْزِلُكُمْ بِدَارِ تَأَيَّةٍ</span> or <span class="ar">تَإِيَّةٍ</span>, <span class="auth">(IAạr, T,)</span> or <span class="ar long">لَيْسَ مَنْزِلُكُمْ هٰذَا بِمَنْزِلِ تَأَيَّةٍ</span> or <span class="ar">تَإِيَّةٍ</span>, <span class="auth">(Ṣ,)</span> i. e. <em>Your abode,</em> or <em>this your abode, is not an abode of tarriance and confinement.</em> <span class="auth">(IAạr, T, Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Ae_5_B2">
					<p><em>He expected,</em> or <em>waited for, a thing:</em> <span class="auth">(Lth, T:)</span> and <em>he acted with moderation, gently, deliberately,</em> or <em>leisurely; without haste;</em> or <em>with gravity, staidness, sedateness,</em> or <em>calmness;</em> <span class="auth">(Lth, T, Ḳ;)</span> <span class="ar long">فِى الأَمْرِ</span> <em>in the affair;</em> inf. n. <span class="ar">تَأىٍ</span>. <span class="auth">(Lth, T.)</span> <span class="ar long">تَأَيَّيْتُ عَلَيْهِ</span>, in a verse of Lebeed, means <em>I acted with moderation,</em>, &amp;c., as above, <em>and paused, stopped, stayed, remained,</em> or <em>tarried, upon him,</em> i. e., upon my horse: <span class="auth">(T:)</span> or <em>I remained firm upon him:</em> <span class="auth">(TA, as on the authority of Az:)</span> but it is explained by Lth as meaning <em>I turned away,</em> or <em>back, deliberately,</em> or <em>leisurely, upon him.</em> <span class="auth">(T: and the like is said in the M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ae_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآىّ</span></h3>
				<div class="sense" id="Ae_6_A1">
					<p><span class="ar">تَآيَيْتُهُ</span>, <span class="auth">(T, Ṣ, M,* Ḳ,)</span> and<span class="arrow"><span class="ar">تَأَيَّيْتُهُ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>I directed my course,</em> or <em>aim, to,</em> or <em>towards,</em> <span class="auth">(T, Ṣ, M,* Ḳ,)</span> <em>his</em> <span class="ar">آيَة</span>, <span class="auth">(Ṣ, M,)</span> i. e., <span class="auth">(M,)</span> <em>his</em> <span class="ar">شَخْص</span> <span class="add">[or <em>body,</em> or <em>corporeal form</em> or <em>figure</em> or <em>substance, seen from a distance;</em> or <em>person</em>]</span>. <span class="auth">(T, M, Ḳ.)</span> The following is an ex., as some relate it, of the former verb; and as others relate it, of the latter:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">اَلْحُصْنُ أَوْلَى لَوْ تَآيُيْتِهِ</span> *</div> 
						<div class="star">* <span class="ar long">مِنْ حَثْيِكِ التُّرْبَ عَلَى الرَّاكِبِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Modest behaviour were more proper, if thou directedst thy course towards his person, than thy throwing dust upon the rider</em>]</span>: <span class="auth">(Ṣ, TA: <span class="add">[in two copies of the former of which, for <span class="ar">أَوْلَى</span>, I find <span class="ar">أَدْنَى</span>:]</span>)</span> said by a woman to her daughter, on the latter's relating, in a couplet, that a rider, passing along, had seen her, and she had thrown dust in his face, purposely. <span class="auth">(IB.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oaeo">
				<h3 class="entry"><span class="ar">أَىْ</span></h3>
				<div class="sense" id="Oaeo_A1">
					<p><span class="ar">أَىْ</span> a vocative particle, <span class="auth">(Ṣ, M, Mughnee, Ḳ,)</span> addressed to the near, <span class="auth">(Ṣ, Ḳ,)</span> not to the distant: <span class="auth">(Ṣ:)</span> or to the near, or the distant, or the intermediate; accord. to different authorities. <span class="auth">(Mughnee.)</span> You say, <span class="ar long">أَىْ زَيْدُ أَقْبِلْ</span> <span class="add">[<em>O Zeyd, advance:</em> or, if it may be used in addressing one who is distant, <em>ho there, soho,</em> or <em>holla:</em> and if used in addressing one who is between near and distant, <em>ho,</em> or <em>what ho</em>]</span>: <span class="auth">(Ṣ:)</span> and <span class="ar long">أَىْ رَبِّ</span> <span class="add">[<em>O my Lord</em>]</span>; occurring in a trad.: and sometimes it is pronounced <span class="arrow"><span class="ar">آىْ↓</span></span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Oaeo_B1">
					<p>Also an explicative particle. <span class="auth">(Ṣ, M, Mughnee, Ḳ.)</span> You say, <span class="ar long">أَىْ كَذَا</span> in the sense of <span class="ar long">يُرِيدُ كَذَا</span> <span class="add">[<em>He means such a thing,</em> or <span class="ar long">يَعْنِى كَذَا</span>, which has the same signification; or <span class="ar">أُرِيدُ</span>, or <span class="ar">أَعْنِى</span>, <em>I mean;</em> or the like; for all of which, we may say, <em>meaning;</em> or <em>that is</em>]</span>; <span class="auth">(Ṣ;)</span> as in <span class="ar long">عِنْدِى عَسْجِدٌ أَىْ ذَهَبٌ</span> <span class="add">[<em>I have</em> <span class="ar">عَسْجَد</span>, <em>that is,</em> <span class="auth">(I have)</span> <span class="ar">ذَهَبَ</span>, or <em>gold</em>]</span>. <span class="auth">(Mughnee.)</span> What follows it is an adjunct explicative of what precedes it, or a substitute. <span class="auth">(Mughnee.)</span> AA says that he asked Mbr respecting what follows it, and he answered that it may be a substitute for what precedes, and may be a word independent of what precedes it, and may be a noun in the accus. case: and that he asked Th, and he answered that it may be an explicative, or a word independent of what precedes it, or a noun governed in the accus. case by a verb suppressed: you say, <span class="ar long">جَآءَنِى أَخُوكَ أَىْ زَيْدٌ</span> <span class="add">[<em>Thy brother came to me; that is, Zeyd</em>]</span>; and you may say, <span class="ar long">أَىْ زَيْدًا</span> <span class="add">[<em>I mean Zeyd</em>]</span>: and <span class="ar long">رَأَيْتُ أَخَاكَ أَىْ زَيْدًا</span> <span class="add">[<em>I saw thy brother; I mean,</em> or <em>that is, Zeyd</em>]</span>; and you may say, <span class="ar long">أَىْ زَيْدٌ</span> <span class="add">[<em>that is, Zeyd</em>]</span>: and <span class="ar long">مَرَرْتُ بِأَخِيكَ أَىْ زَيْدٍ</span> <span class="add">[<em>I passed by thy brother; that is,</em> by <em>Zeyd</em>]</span>; and you may say, <span class="ar long">أَىْ زَيدًا</span> <span class="add">[<em>I mean, Zeyd</em>]</span>; and <span class="ar long">أَىْ زَيْدٌ</span> <span class="add">[<em>that is, Zeyd</em>]</span>. <span class="auth">(T, TA.)</span> When it occurs after <span class="ar">تَقُولُ</span>, in a case like the following, <span class="add">[i. e., when a verb following it explains a verb preceding it,]</span> one says, <span class="ar long">تَقُولُ اِسْتَكْتَمْتُهُ الحَدِيثَ أَىْ سَأَلْتُهُ كِتْمَانَهُ</span> <span class="add">[<em>Thou sayest,</em> <span class="ar long">استكتمته الحديث</span>, <em>meaning</em> <span class="ar long">سألته كتمانه</span> <em>I asked of him the concealment of it,</em> namely, the discourse, or story; and so when <span class="ar">تَقُولُ</span> is understood, as is often, or generally, the case in lexicons]</span>; with damm to the <span class="ar">ت</span>: but if you put <span class="ar">إِذَا</span> in the place of <span class="ar">أَىْ</span>, you say, <span class="ar long">إِذَا سَأَلْتَهُ</span>, with fet-ḥ, because <span class="ar">أَذا</span> is an adverbial noun relating to <span class="ar">تَقُولُ</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Oaeo_C1">
					<p><a href="#OaeBN">See also <span class="ar">أَىٌّ</span></a>, near the beginning of the paragraph, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Iieo">
				<h3 class="entry"><span class="ar">إِىْ</span></h3>
				<div class="sense" id="Iieo_A1">
					<p><span class="ar">إِىْ</span> is a particle denoting a reply, meaning <span class="ar">نَعَمْ</span> <span class="add">[<em>Yes,</em> or <em>yea</em>]</span>; importing acknowledgment of the truth of an enunciation; and the making a thing known, to him who asks information; and a promise, to him who seeks or demands; therefore it occurs after such sayings as “Zeyd stood” and “Did Zeyd stand.?” and “Beat thou Zeyd,” and the like; as does <span class="ar">نَعَمْ</span>: <span class="pb" id="Page_0132"></span>Ibn-El-Hájib asserts that it occurs only after an interrogation; as in the saying <span class="add">[in the Ḳur x. 54]</span>, <span class="ar long">وَيَسْتَنْبِؤُنَكَ أَحَقٌّ هُوَ قُلٌ إِ ىْ وَرَبِىّ</span> <span class="add">[<em>And they will ask thee to inform them,</em> saying, <em>Is it true? Say, Yea, by my Lord!</em>]</span>: but accord. to all, it does not occur otherwise than before an oath: and when one says, <span class="ar long">إِ ىْ وَٱللّٰهِ</span> <span class="add">[<em>Yea, by God!</em>]</span>, and then drops the <span class="ar">و</span> the <span class="ar">ى</span> may be quiescent, and with fet-ḥ, and elided; <span class="add">[so that you say, <span class="ar long">إِ ىْ ٱللّٰهِ</span>, and <span class="ar long">إِ ىَ ٱللّٰهِ</span>, and <span class="ar long">إِ ٱللّٰهِ</span>;]</span> in the first of which cases, two quiescent letters occur together, irregularly. <span class="auth">(Mughnee.)</span> Lth says, <span class="ar long">إِ ىْ</span> is an oath, as in <span class="ar long">إ ِىْ وَرَبِّى</span> meaning, says Zj, <span class="ar long">نَعَمْ وَرَبِّى</span>: IAạr is also related to have said the like; and this is the correct explanation. <span class="auth">(T.)</span> <span class="add">[J says,]</span> It is a word preceding an oath, meaning <span class="ar">بَلَى</span> <span class="add">[q. v.]</span>; as in <span class="ar long">إِ ىْ وَرَبِّى</span> and <span class="ar long">إِ ىْ وَٱللّٰه</span>. <span class="auth">(Ṣ.)</span> <span class="add">[ISd and F say,]</span> It is syn. with <span class="ar">نَعَمْ</span>, and is conjoined with an oath: and one says also <span class="ar">هِىْ</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaeBN">
				<h3 class="entry"><span class="ar">أَىٌّ</span></h3>
				<div class="sense" id="OaeBN_A1">
					<p><span class="ar">أَىٌّ</span> is a noun, used in five different manners. <span class="auth">(Mughnee.)</span> One of its meanings is that of an interrogative, <span class="auth">(T, Ṣ, M, Mughnee, Ḳ,)</span> relating to intellectual beings and to non-intellectual things; <span class="add">[meaning <em>Who? which?</em> and <em>what?</em>]</span> <span class="auth">(Ṣ, M, Ḳ;)</span> and as such, it is a decl. noun: <span class="auth">(Ṣ:)</span> it is said in the Ḳ to be a particle; <span class="auth">(MF;)</span> and so in the M; <span class="auth">(TA;)</span> but this is wrong: <span class="auth">(MF:)</span> and it is added in the Ḳ that it is indecl.; <span class="auth">(MF;)</span> and it is said to be so in the M, accord. to Sb, in an instance to be explained below; <span class="auth">(TA;)</span> but this is only when it is a conjunct noun <span class="add">[like <span class="ar">الَّذِى</span>]</span>, or denotes the object of a vocative: <span class="auth">(MF:)</span> or, accord. to some, it is decl. as a conjunct noun also. <span class="auth">(Mughnee.)</span> You say, <span class="ar long">أَيُّهُمْ أَخُوكَ</span> <span class="add">[<em>Who,</em> or <em>which, of them, is thy brother?</em>]</span>. <span class="auth">(Ṣ.)</span> Another ex. is the saying <span class="add">[in the Ḳur vii. 184, and last verse of lxxvii.]</span>, <span class="ar long">فَبِأَىِّ حَدِيثٍ بَعْدَهُ يُؤْمِنُونَ</span> <span class="add">[<em>And in what announcement, after it, will they believe?</em>]</span>. <span class="auth">(Mughnee.)</span> Sometimes it is without teshdeed; as in the saying <span class="auth">(of El-Farezdaḳ, M)</span>,</p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">تَنَظَّرْتُ نَصْرًا وَالسِّمَاكَيْنِ أَيْهُمَا↓</span></span> *</div> 
						<div class="star">* <span class="ar long">عَلَىَّ مِنَ الغَيْثِ ٱسْتَهَلَّتْ مَوَاطِرُهْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>I looked for rain,</em> or <em>aid from the clouds, and the two Simáks</em> <span class="auth">(stars so called)</span>. <em>Of which of them two did the rains pour vehemently upon me from the clouds?</em>]</span>: <span class="auth">(M, Mughnee, Ḳ:* <span class="add">[in the last of which, only the former hemistich is given, with <span class="ar">نَسْرًا</span> (meaning the star or asterism so called)</span> instead of <span class="ar">نَصْرًا</span>:]</span>) so by poetic licence: <span class="auth">(M:)</span> IJ says that for this reason the poet has elided the second <span class="ar">ى</span>, but should have restored the first <span class="ar">ى</span> to <span class="ar">و</span>, because it is originally <span class="ar">و</span>. <span class="auth">(TA. <span class="add">[But this assertion, respecting the first <span class="ar">ى</span>, I regard as improbable.]</span>)</span> <span class="arrow"><span class="ar">أَيْمَ↓</span></span>, also, is a contraction of <span class="ar long">أَىُّ مَا</span>, meaning <span class="ar long">أَىُّ شَىْءٍ</span>: so in the saying, <span class="ar long">أَيْمَ هُوَ يَا فُلَانُ</span> <span class="add">[<em>What thing is it, O such a one?</em>]</span>: and <span class="ar long">أَيْمَ تَقُولُ</span> <span class="add">[<em>What thing sayest thou?</em>]</span>. <span class="auth">(TA in art. <span class="ar">ايم</span>.)</span> In like manner, also, <span class="arrow"><span class="ar">أَيْشَ↓</span></span> is used as a contraction of <span class="ar long">أَىُّ شَىْءٍ</span>. <span class="auth">(Ks, TA in art. <span class="ar">جرم</span>.)</span> A poet speaks of his companions as being <span class="ar long">بِأَىَ وَأَيْنَمَا</span>; making <span class="ar">أَىّ</span> the name of the quarter (<span class="ar">جِهَة</span>); so that, being determinate and of the feminine gender, it is imperfectly declinable. <span class="auth">(M. <span class="add">[<a href="#OaynN">See <span class="ar">أَينٌ</span></a>; under which head two other readings are given; and where it is said that the verse in which this occurs is by Homeyd Ibn-Thowr.]</span>)</span> <span class="ar">أَىّ</span> is never without a noun or pronoun to which it is prefixed, except in a vocative expression and when it is made to conform with a word to which it refers, as in cases to be exemplified hereafter. <span class="auth">(Mughnee.)</span> Being so prefixed, it is determinate; but sometimes, <span class="add">[as in the latter of the cases just mentioned,]</span> it is not so prefixed, yet has the meaning of a prefixed noun. <span class="auth">(Ṣ.)</span> When used as an interrogative, it is not governed, as to the letter, though it is as to the meaning, by the verb that precedes it, but by what follows it; as in the saying in the Ḳur <span class="add">[xviii. 11]</span>, <span class="ar long">لِنَعْلَمَ أَىُّ الحِزْبَيْنِ أَحْصَى</span> <span class="add">[<em>That we might know which of the two parties was able to compute</em>]</span>; and in the same <span class="add">[xxvi. last verse]</span>, <span class="ar long">وَسَيَعْلَمُ ٱلَّذَينَ ظَلَمُوا أَىَ مُنْقَلَبٍ يَنْقَلِبُونَ</span> <span class="add">[<em>And they who have acted wrongly shall know with what a translating they shall be translated</em>]</span>: <span class="auth">(Fr,* Th, Mbr, T, Ṣ:*)</span> when it is governed by the verb before it, it has not the interrogative meaning, as will be shown hereafter. <span class="auth">(Fr, T.)</span> In the saying of the poet,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">تَصِيحُ بِنَا حَنِيفَةُ إذْ رَأَتْنَا</span> *</div> 
						<div class="star">* <span class="ar long">وَأَىَّ الأَرْضِ تَذْهَبُ لِلصِّيَاحِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Ḥaneefeh</em> <span class="auth">(the tribe so named)</span> <em>shout to us when they see us. And to what</em> place <em>of the earth,</em> or <em>land, will they go for the shouting?</em>]</span>, <span class="ar">أَىّ</span> is in the accus. case because the prep. <span class="ar">إِلَى</span> is suppressed before it. <span class="auth">(Ṣ.)</span> When they separate it <span class="add">[from what follows it, not prefixing it to another noun]</span>, the Arabs say <span class="ar">أَىٌ</span>, and in the dual <span class="ar">أَيَّانِ</span>, and in the pl. <span class="ar">أَيُّونَ</span>; and they make it fem., saying <span class="ar">أَيَّةٌ</span>, and <span class="add">[in the dual]</span> <span class="ar">أَيَّتَانِ</span>, and <span class="add">[in the pl.]</span> <span class="ar">أَيَّاتٌ</span>: but when they prefix it to a noun, properly so called, not a pronoun, they make it sing. and masc., saying <span class="ar long">أَىُ الرَّجُلَيْنِ</span> <span class="add">[<em>Who,</em> or <em>which, of the two men?</em>]</span>, and <span class="ar long">أَىُ المَرْأَتَيْنِ</span> <span class="add">[<em>Who,</em> or <em>which, of the two women?</em>]</span>, and <span class="ar long">أَىُّ الّرِجَالِ</span> <span class="add">[<em>Who,</em> or <em>which, of the men?</em>]</span>, and <span class="ar long">أَىُّ النِّسَآءِ</span> <span class="add">[<em>Who,</em> or <em>which, of the women?</em>]</span>: and when they prefix it to a fem. pronoun, they make it masc. <span class="add">[as when they prefix it to a masc. pronoun]</span> and fem., saying <span class="ar">أَيُّهُمَا</span> and <span class="ar">أَيَّتُهُمَا</span> <span class="add">[<em>Who,</em> or <em>which, of them two?</em>]</span>, meaning women; <span class="auth">(Fr, T;)</span> <span class="add">[the latter of which seems to be the more common; for ISd says,]</span> sometimes they said <span class="ar">أَيُّهُنَّ</span> <span class="add">[<em>Who,</em> or <em>which, of them?</em> referring to women]</span>, meaning <span class="ar">أَيَّتُهُنَّ</span>. <span class="auth">(M.)</span> It is said in the Ḳur <span class="add">[xxxi. last verse]</span>, <span class="ar long">وَمَا تَدْرِى نَفْسٌ بِأَىِّ أَرضٍ تَمُوتُ</span> <span class="add">[<em>And a person knoweth not in what land he will die</em>]</span>: <span class="auth">(Ṣ:)</span> but some read <span class="ar long">بِأَيَّةِ أَرْضٍ</span>; and Sb compares this fem. form to <span class="ar">كُلَّتُهُنَّ</span>. <span class="auth">(Bḍ.)</span> When it is used as an interrogative relating to an indeterminate noun in a preceding phrase, <span class="ar">أَىّ</span> is made to conform with that indeterminate noun in case-ending and in gender and in number; and this is done <span class="add">[alike, accord. to some,]</span> in the case of its connexion with a following word and in the case of a pause; so that, <span class="add">[in the case of a pause,]</span> to him who says, <span class="ar long">جَآءَنِى رَجُلٌ</span> <span class="add">[A man came to me]</span>, you say, <span class="add">[accord. to the authorities alluded to above,]</span> <span class="ar">أَىٌّ</span> <span class="add">[<em>Who?</em>]</span>; and to him who says, <span class="ar long">رَأَيْتُ رَجُلًا</span> <span class="add">[I saw a man]</span>, <span class="ar">أَيَّا</span> <span class="add">[<em>Whom?</em>]</span>; and to him who says, <span class="ar long">مَرَرْتُ بِرَجلٍ</span> <span class="add">[I passed by a man]</span>, <span class="ar">أَىٍّ</span> <span class="add">[<em>Whom?</em>]</span>: and in like manner, <span class="add">[accord. to all authorities,]</span> in the case of its connexion with a following word; as <span class="ar long">أَىُّ يَا فَتَى</span> <span class="add">[<em>Who, O young man?</em>]</span>, and <span class="ar long">أَيَّا يَا فَتَى</span> <span class="add">[<em>Whom, O young man?</em>]</span>, and <span class="ar long">أَىٍ يَا فَتَى</span> <span class="add">[<em>Whom, O young man?</em>]</span>: and in the case of the fem. you say, <span class="ar">أَيَّةٌ</span> and <span class="ar">أَيَّةً</span> and <span class="ar">أَيَّةٍ</span> <span class="add">[in the nom. and accus. and gen. respectively]</span>; and in the dual, <span class="ar">أَيَّانِ</span> and <span class="ar">أَيَّتَانِ</span> in the nom. case <span class="add">[masc. and fem. respectively]</span>, and <span class="ar">أَيَّيْنِ</span> and <span class="ar">أَيَّتَيْنِ</span> in the accus. and gen. cases <span class="add">[masc. and fem. respectively]</span>; and in the pl., <span class="add">[with the like distinction of genders,]</span> <span class="ar">أَيُّونَ</span> and <span class="ar">أَيَّاتٌ</span> in the nom. case, and <span class="ar">أَيِّينَ</span> and <span class="ar">أَيَّاتٍ</span> in the accus. and gen. cases. <span class="auth">(I’Aḳ p. 319.)</span> <span class="add">[Exs. in cases of pause, agreeing with the foregoing rules, are given in the T; and exs. in cases of connexion with following words, agreeing with the foregoing, are given in the Mughnee: but J gives rules differing from the foregoing in some respects; and IB gives rules differing in some points both from the foregoing and from those of J.]</span> It is said in the Ṣ, <span class="ar">أَىّ</span> is made to conform with indeterminate nouns significant of intellectual beings and of nonintellectual things, and is used as an interrogative; and when it is thus used in reference to an indeterminate noun, you make it to have a caseending like that of the noun respecting which it demands positive information; so that when it is said to you, <span class="ar long">مَرَّبِى رَجُلٌ</span> <span class="add">[A man passed by me]</span>, you say, <span class="ar long">أَىٌّ يَا فَتَى</span> <span class="add">[<em>Who, O young man?</em>]</span>, thus giving it a case-ending <span class="add">[<a href="#rajulN">like that of <span class="ar">رَجُلٌ</span></a>]</span> when it is in connexion with a following word; and you indicate the case-ending <span class="add">[by the pronunciation termed <span class="ar">الرَّوْمُ</span>, saying <span class="ar">أَىُّ</span>, with a somewhat obscure utterance of the final vowel,]</span> in pausing; and if one says, <span class="ar long">رَأَيْتُ رَجُلًا</span> <span class="add">[I saw a man]</span>, you say, <span class="ar long">أَيَّا يَافَتَى</span> <span class="add">[<em>Whom, O young man?</em>]</span>, giving it a case-ending <span class="add">[<a href="#rajulFA">like that of <span class="ar">رَجُلًا</span></a>]</span>, with tenween, when it is <span class="add">[thus]</span> in connexion with a following word; and you pause upon the <span class="ar">ا</span>, saying <span class="ar">أَيَّا</span>; and when one says, <span class="ar long">مَرَرْتُ بِرَجُلٍ</span> <span class="add">[I passed by a man]</span>, you say, <span class="ar long">أَىٍّ يَافَتَى</span> <span class="add">[<em>Whom, O young man?</em> in a case of connexion with a following word; and <span class="ar">أَىِّ</span> in a case of pausing]</span>: you conform with what the other has said, in the nom. and accus. and gen. cases, in the case of connexion with a following word and in that of pausing: but IB says that this is correct only in the case of connexion with a following word; for in the case of a pause, you say only <span class="ar">أَىّْ</span>, in the nom. and gen., with sukoon; and you imitate in both of these cases only when you use the dual form or the pl.: it is added in the Ṣ, you say in the cases of the dual and pl. and fem. like as we have said respecting <span class="ar">مَنْ</span>: when one says, <span class="ar long">جَآءَنِى رِجَالٌ</span> <span class="add">[Men came to me]</span>, you say, <span class="ar">أَيُّونْ</span> <span class="add">[<em>Who?</em>]</span>, with the <span class="ar">ن</span> quiescent; and <span class="ar">أَيِينْ</span> in the accus. and gen.: <span class="pb" id="Page_0133"></span>but IB says, the correct mode is to say, <span class="ar">أَيُّونَ</span> and <span class="ar">أَيِّنَ</span>, with fet-ḥ to the <span class="ar">ن</span> in both; <span class="add">[meaning that this is the only allowable mode in the case of connexion with a following word, and app. that it is the preferable mode in the case of a pause;]</span> the quiescent <span class="ar">ن</span> being allowable only in the case of a pause, and with respect to <span class="ar">مَنْ</span>, for you say <span class="ar">مَنُونْ</span> and <span class="ar">مَنِينْ</span> with the quiescent <span class="ar">ن</span> only: it is then added in the Ṣ, you say, also, <span class="ar">أَيَّهْ</span> <span class="add">[<em>Who?</em> and <em>whom?</em>]</span> in using the fem. <span class="add">[in a case of pause]</span>; but in a case of connexion with a following word, <span class="add">[when referring to a noun in the accus.,]</span> you say, <span class="ar long">أَيَّةً يَا هٰذَا</span> <span class="add">[<em>Whom, O thou?</em> in the sing.]</span>, and <span class="ar">أَيَّاتٍ</span> <span class="add">[in the pl.; and in like manner, <span class="ar">أَيَّةٌ</span> in the nom. sing., and <span class="ar">أَيَّةٍ</span> in the gen. sing.; and <span class="ar">أَيَّاتٌ</span> in the nom. pl., and <span class="ar">أَيَّاتٍ</span> in the gen. pl.]</span>: but when the interrogation refers to a determinate noun, <span class="ar">أَىّ</span> is in the nom. case <span class="auth">(with refa)</span> only. <span class="auth">(TA.)</span> <span class="add">[<a href="#OayBaAna">See also <span class="ar">أَيَّانَ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaeBN_A2">
					<p><span class="add">[In other cases, now to be mentioned, it is used alike as sing., dual, and pl.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaeBN_A3">
					<p>It also denotes a condition; <span class="auth">(T, Ṣ, M, Mughnee;)</span> in which case, also, it is a decl. noun, applied to an intellectual being and to a non-intellectual thing. <span class="auth">(Ṣ.)</span> So in the saying, <span class="ar long">أَيُّهُمْ يُكْرِمْنِى أُكْرِمْهُ</span> <span class="add">[<em>Whichever of them treats me with honour, I will treat him with honour</em>]</span>. <span class="auth">(Ṣ.)</span> So, too, in the saying <span class="add">[in the Ḳur xvii. 110]</span>, <span class="ar long">أَيًّا مَا تَدْعُوا فَلَهُ الأَسْمَآءُ الحُسْنَى</span> <span class="add">[<em>Whichever ye call</em> Him, <em>He hath the best names</em>]</span>. <span class="auth">(T,* Mughnee.)</span> And in the saying <span class="add">[in the same, xxviii. 28]</span>, <span class="ar long">أَيَّمَا ٱلْأَجَلَيْنِ قَضَيْتُ فَلَا عُدْوَانَ عَلَىَّ</span> <span class="add">[<em>Whichever of the two terms I fulfil, there shall be no wrongdoing to me</em>]</span>. <span class="auth">(Mughnee.)</span> One says also, <span class="ar long">صَحِبَهُ ٱللّٰهُ أَيَّا مَا تَوَجَّهَ</span>, meaning <span class="ar">أَيْنَمَاتَوَجَّهَ</span> <span class="add">[<em>May God accompany him wherever he goeth</em>]</span>. <span class="auth">(AZ, T.)</span> And Zuheyr uses the expression <span class="ar long">أَيَّةً سَلَكُوا</span> for <span class="ar long">أَيَّةَ وِجْهَةٍ سَلَكُوا</span> <span class="add">[<em>Whatever tract they travelled,</em> or <em>travel</em>]</span>. <span class="auth">(T.)</span> The saying, <span class="ar long">أَيِّى وَأَيُّكَ كَانَ شَرَّا فَأَخْزَاهُ ٱللّٰهُ</span> <span class="add">[<em>Whichever of me and thee be evil, may God abase him!</em>]</span> was explained by Kh to Sb as meaning <span class="ar long">أَيُّنَا كَانَ شَرًّا</span> <span class="add">[<em>whichever of us two be evil</em>]</span>; and as being like the saying, <span class="ar long">أَخْزَى ٱللّٰهُ الكَاذِبَ مِنِىّ وَمِنْكَ</span>, meaning <span class="ar">مِنَّا</span>. <span class="auth">(M. <span class="add">[And in a similar manner, the former clause of that saying, occurring in a verse, with <span class="ar">مَا</span> after <span class="ar">أَيِّى</span>, is said in the T to have been explained by Kh to Sb.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="OaeBN_A4">
					<p>It is also a conjunct noun; <span class="auth">(Mughnee;)</span> <span class="add">[i. e.]</span> it is sometimes used in the manner of <span class="ar">الَّذِى</span>, and therefore requires a complement; as in the saying, <span class="ar long">أَيُّهُمْ فِى الدَّارِ أَخُوكَ</span> <span class="add">[<em>He, of them, who is in the house is thy brother</em>]</span>: <span class="auth">(Ṣ:)</span> <span class="add">[i. e.]</span> it is syn. with <span class="ar">الَّذِى</span>. <span class="auth">(M, Mughnee.)</span> So in the saying <span class="add">[in the Ḳur xix. 70]</span>, <span class="ar long">ثُمَّ لَنَنْزِعَنَّ مِنْ كُلِّ شِيعَةٍ أَيُّهُمْ أَشَدُّ عَلَى الرَّحْمٰنِ عُتِيَّا</span> <span class="add">[<em>Then we will assuredly draw forth, from every sect, him, of them, who is most exorbitantly rebellious against the Compassionate</em>]</span>: so says Sb: but the Koofees and a number of the Basrees disagree with him, holding that the conjunct noun <span class="ar">أَىّ</span> is always decl., like the conditional and the interrogative: Zj says, “It has not appeared to me that Sb has erred except in two instances, whereof this is one; for he has conceded that it is decl. when separate, and how can he say that it is indecl. when it is a prefixed noun?” and El-Jarmee says, “I have gone forth from El-Basrah, and have not heard, from my leaving the Khandak to Mekkeh, any one say, <span class="ar long">لَأَضْرِبَنَّ أَيُّهُمْ قَائِمٌ</span> <span class="add">[as meaning <em>I will assuredly beat him, of them, who is standing</em>]</span>, with damm:” these assert, that it is, in the verse above, an interrogative, and that it is an inchoative, and <span class="ar">اشد</span> is an enunciative: but they differ as to the objective complement of the verb: Kh says that this is suppressed, and that the implied meaning is, <em>we will assuredly draw forth those of whom it will be said, Which of them is most</em>, &amp;c.? and Yoo says that it is the proposition <span class="add">[<span class="ar">ايهّم</span>, &amp;c.]</span>, and that the verb is suspended from governing, as in the instance in the Ḳur xviii. 11, cited above: and Ks and Akh say that it is <span class="ar long">كلّ شيعة</span>, that <span class="ar">من</span> is redundant, and that the interrogative proposition is independent of what precedes it; this being grounded on their saying that the redundance of <span class="ar">مِنْ</span> is allowable in an affirmative proposition: but these <span class="add">[following]</span> facts refute their sayings; viz. that the suspension of government is peculiar to verbs significant of operations of the mind; and that it is not allowable to say, <span class="ar long">لَأَضْرِبَنَّ الفَاسِقُ</span>, with refa, as meaning by implication “I will assuredly beat him of whom it is said, He is the transgressor;” and that the redundance of <span class="ar">مِنْ</span> in an affirmative proposition is not correct. <span class="auth">(Mughnee. <span class="add">[Some further remarks on the same subject, in that work, mentioning other opinions as erroneous, I omit. Another reading of the passage in the Ḳur cited above (xix. 70)</span> will be found in what here follows.]</span>) <span class="add">[ISd states that]</span> they said, <span class="ar long">لَأَضْربَنَّ أَيُّهُمْ أَفْضَلُ</span> <span class="add">[<em>I will assuredly beat him, of them, who is most excellent</em>]</span>, and <span class="ar long">أَىٌّ أَفْضَلُ</span> <span class="add">[<em>him who is most excel-lent</em>]</span>; <span class="ar">اىّ</span> being indecl., accord. to Sb, and therefore the verb does not govern it <span class="add">[save as to the meaning]</span>. <span class="auth">(M.)</span> And <span class="add">[that]</span> you say, <span class="ar long">اِضْرِبْ أَيُّهُمْ أَفْضَلُ</span> <span class="add">[<em>Beat thou him, of them, who is most excellent</em>]</span>, and <span class="ar long">أَيَّهُمْ أَفْضَلُ</span> <span class="add">[meaning the same, or <em>whichever of them,</em>, &amp;c.]</span>; suppressing the relative <span class="ar">هُوَ</span> after <span class="ar">ايّهم</span>. <span class="auth">(M in a later part of the same art.)</span> Fr says that when <span class="ar">أَىّ</span> is governed by the verb before it, it has not the interrogative meaning; and you may say, <span class="ar long">لَأَضْرِبَنَّ أَيَّهُمْ يَقُولُ ذٰلِكَ</span> <span class="add">[<em>I will assuredly beat him, of them,</em> or <em>whichever of them, says that</em>]</span>: and he says that he who reads <span class="ar">أَيَّهُمْ</span>, in the accus. case, in the passage of the Ḳur cited above <span class="auth">(xix. 70)</span> makes it to be governed by <span class="ar">لَنَنْرِعَنَّ</span>. <span class="auth">(T.)</span> Ks says, you say, <span class="ar long">لَأَضْرِبَنَّ أَيَّهُمْ فِى الدَّارِ</span> <span class="add">[<em>I will assuredly beat him, of them,</em> or <em>whichever of them, is in the house</em>]</span>; but you may not say, <span class="ar long">ضَرَبْتُ أَيَّهُمْ فِى الدَّارِ</span>: thus he distinguishes between the actual occurrence and that which is expected. <span class="auth">(Ṣ.)</span> Akh says, also, that it may be indeterminate and qualified by an epithet; as when one says, <span class="ar long">مَرَرْتُ بِأَىٍّ مُعْجِبٍ لَكَ</span>, like as one says, <span class="ar long">بِمَنْ مُعْجِبٍ لَكَ</span> <span class="add">[<em>I passed by one pleasing to thee</em>]</span>: but this has not been heard <span class="add">[from the Arabs]</span>. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="OaeBN_A5">
					<p>It also denotes perfection, or consummateness: and in this case it is an epithet applying to an indeterminate noun; as in <span class="ar long">زَيْدٌ رَجُلٌ أَىُّ رَجُلٍ</span> ‡ <span class="add">[<em>Zeyd is a man; what a man!</em>]</span>, meaning that he is complete, or consummate, in the qualities of men: and it is a denotative of state relating to a determinate noun; as in <span class="ar long">مَرَرْتُ بِعَبْدِ ٱللّٰهِ أَىَّ رَجُلٍ</span> ‡ <span class="add">[<em>I passed by ʼAbd-Allah; what a man was he!</em>]</span>: <span class="auth">(Mughnee:)</span> and used in this sense, it is tropical. <span class="auth">(Ḥar p. 534.)</span> <span class="add">[J says,]</span> it is sometimes an epithet applying to an indeterminate noun: you say, <span class="ar long">مَرَرْتُ بِرَجُلٍ أَىِّ رَجُلٍ</span> and <span class="ar">أَيِّمَارَجُلٍ</span> † <span class="add">[<em>I passed by a man; what a man!</em>]</span>; and <span class="ar long">مَرَرْتُ بِٱمْرَأَةٍ أَيَّةِ ٱمْرَأَةٍ</span> † <span class="add">[<em>I passed by a woman; what a woman!</em>]</span>, and <span class="ar long">بِٱمْرَأَتَيْنِ أَيَّتِمَا ٱمْرَأَتَيْنِ</span> <span class="add">[<em>by two women; what two women!</em>]</span>; and <span class="ar long">هٰذِهِ ٱمْرَأَةٌ أَيَّةُ ٱمْرَأَةٍ</span> † <span class="add">[<em>This is a woman; what a woman!</em>]</span>: and <span class="ar long">أَيَّتُمَا ٱمْرَأَ أَيَّةُ ٱمْرَأَةٍ</span> † <span class="add">[<em>What two women!</em>]</span>; <span class="ar">ما</span> being redundant: and in the case of a determinate noun, you say, <span class="ar long">هٰذَا زَيْدٌ أَيَّمَا رَجُلٍ</span> † <span class="add">[<em>This is Zeyd; what a man is he!</em>]</span>; putting it in the accus. case as a denotative of state; and <span class="ar long">هٰذِهِ أَمَةُ ٱللّٰهِ أَيَّتَمَا جَارِيّةٍ</span> † <span class="add">[<em>This is the handmaid of God; what a girl,</em> or <em>young woman, is she!</em>]</span>: you say, also, <span class="add">[in using an indeterminate noun,]</span> <span class="ar long">أَىُّ ٱمْرَأَةٍ جَآءَتْكَ</span> and <span class="ar">جَآءَكَ</span>, and <span class="ar long">أَيَّةُ ٱمْرَأَةٍ جَآءَتْكَ</span> † <span class="add">[<em>What a woman came to thee!</em>]</span>; and <span class="ar long">مَرَرْتُ بِجَارِيَةٍ أَىِّ جَارِيَةٍ</span> † <span class="add">[<em>I passed by a girl,</em> or <em>young woman; what a girl,</em> or <em>young woman!</em>]</span>; and <span class="ar long">جِئْتُكَ بِمُلَآءَةٍ أَىِّ مُلَآءَةٍ</span> and <span class="ar long">أَيَّةِ مُلَآءِةٍ</span> † <span class="add">[<em>I brought thee a body-wrapper; what a body-wrapper!</em>]</span>: all are allowable. <span class="auth">(Ṣ.)</span> <span class="add">[In all these it evidently denotes admiration, or wonder, at some good or extraordinary quality in the person or thing to which it relates; notwithstanding that J says afterwards,]</span> and sometimes it is used to denote wonder; as in the saying of Jemeel,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بُثَيْنَ ٱلْزَمِى لَا إَنَّ لَا إِنْ لَزِمْتِهِ</span> *</div> 
						<div class="star">* <span class="ar long">عَلَى كَثْرَةِ الوَاشِينَ أَىُّ مَعُونِ</span> *</div> 
					</blockquote>
					<p>† <span class="add">[<em>O Butheyneh,</em> (<span class="ar">بُثَيْنَ</span> being a curtailed form of <span class="ar">بُثَيْنَة</span>, a woman's name,) <em>adhere thou to “No:” verily “No,” if thou adhere to it, notwithstanding the numbers of the slanderers, what a help</em> will it be!]</span>: <span class="auth">(Ṣ:)</span> i. e., an excellent help will be thy saying “No” in repelling, or rebutting, the slanderers, though they be many. <span class="auth">(TA in art. <span class="ar">عون</span>.)</span> Fr gives as exs. of its use to denote wonder the sayings, <span class="ar long">أَىُّ رَجُلٍ زَيْدٌ</span> <span class="add">[<em>What a man is Zeyd!</em>]</span>, and <span class="ar long">أَىُّ جَارِيَهٍ زَيْنَبُ</span> <span class="add">[<em>What a girl,</em> or <em>young woman, is Zeyneb!</em>]</span>. <span class="auth">(T.)</span> It denotes wonder at the sufficiency, and great degree of competence, of the person <span class="add">[or thing]</span> to whom <span class="add">[or to which]</span> it relates. <span class="auth">(M.)</span> El-Kattál El-Kilábee says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَلَمَّا رَأَيْتُ أَنَّنِى قَدْ قَتَلْتُهُ</span> *</div> 
						<div class="star">* <span class="ar long">نَدِمْتُ عَلَيْهِ أَىَّ سَاعَةِ مَنْدَمِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And when I saw that I had slain him, I repented of it; in what an hour,</em> or <em>time, of repentance!</em>]</span>: i. e., when I slew him, I repented of it, in a time when repentance did not profit: <span class="pb" id="Page_0134"></span><span class="ar">اىّ</span> being here in the accus. case as an adv. n.; for, as it denotes the part of a whole, its predicament is made to be the same as that of the affixed noun, of whatever kind this may be. <span class="auth">(Ḥam p. 95.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="OaeBN_A6">
					<p>It also has <span class="ar">ك</span> prefixed to it; and thus it becomes changed in signification so as to denote numerousness, being <em>syn. with the enunciative</em> <span class="ar">كَمْ</span> <span class="add">[<em>How many!</em>]</span>; <span class="auth">(Ṣ, Ḳ;)</span> or <em>syn. with</em> <span class="ar">رُبَّ</span> <span class="add">[as meaning <em>many</em>]</span>: <span class="auth">(Sb, M:)</span> <span class="add">[and sometimes it is syn. with the interrogative <span class="ar">كَمْ</span>, meaning <em>how many?</em> or <em>how much?</em> as will be shown below:]</span> thus it is written <span class="ar">كَأَىٍّ</span>, <span class="auth">(M,)</span> or <span class="ar">كَأَيِّنْ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> its tenween being written <span class="ar">ن</span>; <span class="auth">(Ṣ, Ḳ;)</span> and <span class="ar">كَآءٍ</span>, <span class="auth">(M,)</span> or <span class="add">[more commonly]</span> <span class="ar">كَائِنْ</span>, <span class="auth">(Ṣ, M, Ḳ, <span class="add">[in some copies of the Ṣ and Ḳ <span class="ar">كَايِنْ</span>,]</span>)</span> like <span class="ar">كَاعِنْ</span>, <span class="auth">(Ṣ,)</span> said by IJ, on the authority of Aboo-ʼAlee, to be formed from <span class="ar">كَأَيِّنْ</span>, by putting the double <span class="ar">ى</span> before the <span class="ar">ء</span>, after the manner of the transposition in <span class="ar">قِسِىٌّ</span> and a number of other words, so that it becomes <span class="ar">كَيَّأٍ</span> <span class="add">[or <span class="ar">كَيَّئِنْ</span>]</span>, then suppressing the second <span class="ar">ى</span>, as is done in <span class="ar">مَيِّتٌ</span> and <span class="ar">هَيِّنٌ</span> and <span class="ar">لَيِّنٌ</span>, so that it becomes <span class="ar">كَىْءٍ</span> <span class="add">[or <span class="ar">كَىْءِنْ</span>]</span>, and then changing the <span class="add">[remaining]</span> <span class="ar">ى</span> into <span class="ar">ا</span>, as in <span class="add">[<span class="ar">طَيْئِىٌّ</span>, which becomes]</span> <span class="ar">طَادِىٌّ</span>, and in <span class="add">[<span class="ar">حِيرِىٌّ</span>, which becomes]</span> <span class="ar">حَارِىٌّ</span>, so that it becomes <span class="ar">كَآءٍ</span> <span class="add">[or <span class="ar">كَائِنْ</span>]</span>; <span class="auth">(M;)</span> and it has other dial. vars.; namely <span class="ar">كَيْئِنٌ</span> <span class="add">[one of the intermediate forms between <span class="ar">كَأَيِّنْ</span> and <span class="ar">كَائِنْ</span> mentioned above]</span>; <span class="auth">(Ḳ; <span class="add">[in one copy of the Ḳ written <span class="ar">كَيَيِّنْ</span>, and so accord. to the TḲ;]</span>)</span> and <span class="ar">كَأْىٍ</span>, <span class="auth">(M, Ḳ,)</span> of the measure of <span class="ar">رَمْىٍ</span>, and most probably formed by transposition from <span class="ar">كَىْءٍ</span>, mentioned above; <span class="auth">(M;)</span> and <span class="ar">كَأ</span>, of the measure of <span class="ar">عَمٍ</span>, <span class="auth">(M, TA,)</span> incorrectly written in the copies of the Ḳ <span class="ar">كَاءٍ</span>, i. e. like <span class="ar">كَاعٍ</span>, <span class="auth">(TA,)</span> formed by the suppression of <span class="ar">ى</span> in <span class="ar">كَىْءٍ</span>; a change not greater than that from <span class="ar long">أَيْمُنُ ٱللّٰهِ</span> to <span class="ar long">مُ ٱللّٰهِ</span> and <span class="ar long">مِ ٱللّٰهِ</span>. <span class="auth">(M.)</span> You say, <span class="ar long">كَأَيِّنْ رَجُلًا لَقِيتُ</span> <span class="add">[<em>How many a man have I met!</em> or <em>many a man</em>, &amp;c.]</span>, <span class="auth">(Ṣ, Ḳ,*)</span> putting the noun following <span class="ar">كأيّن</span> in the accus. case as a specificative; <span class="auth">(Ṣ;)</span> and <span class="ar long">كَأَيِّنْ مِنْ رَجُلٍ لَقِيتُ</span>; <span class="auth">(Ṣ, Ḳ;*)</span> and the introduction of <span class="ar">مِنْ</span> after <span class="ar">كَأيّن</span> is more common, and better. <span class="auth">(Ṣ. <span class="add">[And Sb, as cited in the M, says the like.]</span>)</span> You say also, <span class="ar long">كَأَيِّنْ قَدْ أَتَانِى رَجُلًا</span> <span class="add">[<em>How many a man has come to me!</em> or <em>many a man</em>, &amp;c.]</span>. <span class="auth">(Sb, M.)</span> And <span class="ar long">بِكَأَيِّنْ تَبِيعُ هٰذَا الثَّوْبَ</span>, i. e. <span class="ar long">بِكَمْ تبيع</span> <span class="add">[<em>For how much wilt thou sell this garment,</em> or <em>piece of cloth?</em>]</span>. <span class="auth">(Ṣ.)</span> Kh says that if any one of the Arabs made it to govern the gen. case, perhaps he did so by making <span class="ar">مِنْ</span> to be implied, as is allowable with <span class="ar">كَمْ</span>: <span class="auth">(M:)</span> <span class="add">[so that you may say, <span class="ar long">بِكَأَيِّنْ دِرْهَمٍ ٱشْتَرَيْتَ هٰذَا</span> <em>For how many a dirhem didst thou buy this?</em> for]</span> it is allowable to make the noun that follows <span class="ar">كَمْ</span> to be governed in the gen. case by <span class="ar">منْ</span> implied, when <span class="ar">كم</span> immediately follows a preposition; as in <span class="ar long">بِكضمْ دِرْهَمٍ ٱشْتَرَيْتَ هٰذَا</span>; but when it is not thus preceded by a preposition, the noun after it must be in the accus. case. <span class="auth">(I’Aḳ p. 317.)</span> It always holds the first place in a proposition, like <span class="ar">كَمْ</span>. <span class="auth">(Idem, next p.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="OaeBN_A7">
					<p>It is also a connective of the vocative <span class="ar">يَا</span> with the noun signifying the person or persons or thing called, when this noun has the article <span class="ar">ال</span> prefixed to it; <span class="auth">(Ṣ, M, Mughnee, Ḳ;)</span> and with a noun of indication, as <span class="ar">ذَا</span>; and with a conjunct noun having <span class="ar">ال</span> prefixed to it, as <span class="ar">الذِّى</span>: <span class="auth">(I’Aḳ p. 268:)</span> it is a noun formed for serving as such a connective; <span class="auth">(M, Ḳ;)</span> and has <span class="ar">هَا</span> affixed to it. <span class="auth">(Ṣ, M, &amp;c.)</span> You say, <span class="ar long">يَا أَيُّهَا الرَّجُلُ</span> <span class="add">[which seems to be best rendered <em>O thou man;</em> more agreeably with the original, <em>O thou, the man;</em> or, accord. to Akh, <em>O thou who art the man;</em> lit., <em>O he who is the man;</em> often written <span class="ar">يَأَيُّهَا</span>]</span>; <span class="auth">(T, Ṣ, M, Mughnee, Ḳ;)</span> and <span class="ar long">يَاأَيُّهَا الرَّجُلَانِ</span> <span class="add">[<em>O ye two men</em>]</span>; and <span class="ar long">يَاأَيُّهَا الرِّجَالُ</span> <span class="add">[<em>O ye men</em>]</span>; <span class="auth">(M;)</span> and <span class="ar">يَاأَيَّتُهَاالمَرْأَةُ</span> <span class="add">[<em>O thou woman</em>]</span>; <span class="auth">(Ṣ, M;)</span> and <span class="ar long">يَا أَيَّتُهَا المَرْأَتَانِ</span> <span class="add">[<em>O ye two women</em>]</span>; and <span class="ar long">أَيَّتُهَا النّسْوَةُ</span> <span class="add">[<em>O ye women</em>]</span>; and <span class="ar long">يَاأَيُّهَا المَرْأَةُ</span>, and <span class="ar">المَرْأَتَانِ</span>, and <span class="ar">النِّسْوَةُ</span>; <span class="auth">(M;)</span> and <span class="ar long">يَاأَيُّهَا ذَا</span> <span class="add">[<em>O thou, this</em> person or thing]</span>; and <span class="ar long">يَا أَيُّهَا الَّذِى فَعَلَ كَذَا</span> <span class="add">[<em>O thou who didst,</em> or <em>hast done, thus</em>]</span>. <span class="auth">(I’Aḳ p. 267.)</span> In the first of the exs. here given, <span class="ar">أَىّ</span> is a noun of vague signification, <span class="auth">(Zj, T, Ṣ,)</span> denoting the person called, <span class="auth">(Zj, T,)</span> of the sing. number, <span class="auth">(Zj, T, Ṣ,)</span> rendered determinate by the vocative <span class="add">[<span class="ar">يا</span>]</span>, <span class="auth">(Ṣ,)</span> indecl., with damm for its termination; <span class="auth">(Zj, T, Ṣ;)</span> and <span class="ar">هَا</span> is a particle employed to rouse attention, or to give notice, a substitute for the noun to which <span class="ar">أَىّ</span> is in other cases prefixed; and <span class="ar">الرَّجُلُ</span> is a qualificative to <span class="ar">أَىّ</span>, <span class="auth">(Zj, T, Ṣ,)</span> wherefore it is in the nom. case. <span class="auth">(Ṣ.)</span> Akh asserts, <span class="add">[as we have indicated above,]</span> that <span class="ar">أَىّ</span> is here the conjunct noun, and that the first member of its complement, namely the relative <span class="ar">هُوَ</span>, is suppressed; the meaning being, <span class="ar long">يَا مَنْ هُوَ الرَّجُلُ</span>: but this assertion is refuted by the fact that there is no relative pronoun that must be suppressed, nor any conjunct noun that necessarily requires that its complement should be a nominal proposition: though he might reply to these two objections by arguing that <span class="ar">ما</span> in the saying <span class="ar long">لَا سِيَّمَا زَيْدٌ</span> is in like manner <span class="add">[virtually]</span> in the nom. case <span class="add">[as a conjunct noun syn. with <span class="ar">الَّذِى</span>, and that the first member of its complement, namely <span class="ar">هُوَ</span>, an inchoative of which <span class="ar">زَيْدٌ</span> is the enunciative, is suppressed]</span>. <span class="auth">(Mughnee.)</span> The putting of the qualificative of <span class="ar">أَىّ</span> in the accus. case, as in the saying <span class="ar long">يَا أَيُّهَا الرَّجُلَ أَقْبِلْ</span> <span class="add">[<em>O thou man, advance</em>]</span>, is allowed <span class="auth">(M, Ḳ)</span> by El-Mázinee; but it is not known <span class="add">[as heard from the Arabs]</span>. <span class="auth">(M.)</span> <span class="ar">أَيُّهَا</span> and <span class="ar">أَيَّتُهَا</span> are also used for the purpose of particularizing; <span class="add">[in which case they are not preceded by <span class="ar">يا</span>;]</span> as when one says, <span class="ar long">أَمَّا أَنَا فَأَفْعَلُ كَذَا أَيُّهَا الرَّجُلُ</span> <span class="add">[<em>As for me, I will do thus,</em> or <em>such a thing, thou man</em>]</span>, meaning himself; and as in the saying of Kaab Ibn-Málik, related in a trad., <span class="ar long">فَتَخَلَّفْنَا أَيَّتُهَا الثَّلَاثَهُ</span> <span class="add">[<em>And we remained behind,</em> or <em>held back, ye three</em>]</span>, meaning, by the three, those particularized as remaining behind <span class="add">[with him]</span>, or holding back. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayaA">
				<h3 class="entry"><span class="ar">أَيَا</span></h3>
				<div class="sense" id="OayaA_A1">
					<p><span class="ar">أَيَا</span>: <a href="index.php?data=01_A/171_AyA">see art. <span class="ar">ايا</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">أَيَا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OayaA_B1">
					<p><span class="ar">أَيًا</span>: <a href="#IiyaA">see the next paragraph</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyaA">
				<h3 class="entry"><span class="ar">إِيَا</span></h3>
				<div class="sense" id="IiyaA_A1">
					<p><span class="ar long">إِيَا الشَّمْسِ</span>, <span class="add">[the former word, when alone and indeterminate, perhaps <span class="auth">(as when determinate)</span> without tenween, for it is-explained <span class="auth">(with its dial. vars.)</span> in the Ṣ and Ḳ in <span class="ar long">باب الالف الليّنة</span>, though it is also explained in some copies of the Ṣ in the present art.,]</span> and<span class="arrow"><span class="ar long">أَيَاةُ↓ الشمس</span></span>, <span class="auth">(T, Ṣ, M, Mgh, Ḳ,)</span> and<span class="arrow"><span class="ar long">أَيَاةُ↓ الشمس</span></span>, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar long">أَيَآءُ↓ الشمس</span></span>, <span class="auth">(T, M, Mgh, Ḳ, and in a copy of the Ṣ,)</span> with fet-ḥ and medd, <span class="auth">(T, Mgh, Ḳ, and so in a copy of the Ṣ,)</span> <em>The light of the sun,</em> <span class="auth">(Ṣ, M, Mgh, Ḳ,)</span> and <em>its beauty:</em> <span class="auth">(M, Ḳ:)</span> or <em>its rays,</em> and <em>its light:</em> <span class="auth">(T:)</span> or, as some say,<span class="arrow"><span class="ar long">اياة↓ الشمس</span></span> signifies <em>the halo of the sun; that, with respect to the sun, which is like the</em> <span class="ar">هَالَة</span> <em>with respect to the moon;</em> i. e. <em>the</em> <span class="ar">دَارَة</span> <em>around the sun:</em> <span class="auth">(Ṣ:)</span> the pl. <span class="add">[of <span class="ar">أَيَاةٌ</span>]</span> is <span class="arrow"><span class="ar">أَيًا↓</span></span> and <span class="ar">إِيَآءٌ</span>; <span class="add">[or rather the former is a coll. gen. n.;]</span> like <span class="ar">أَكَمٌ</span> and <span class="ar">إِكَامٌ</span> in relation to <span class="ar">أَكَمَةٌ</span>. <span class="auth">(M.)</span> Tarafeh says, <span class="auth">(T, Ṣ, Mgh,)</span> describing the fore teeth (<span class="ar">ثَغْر</span>) of his beloved, <span class="auth">(EM p. 62,)</span></p> 
					<blockquote class="quote">
						<div class="star">*<span class="arrow"><span class="ar long">سَقَتْهُ إِيَاةُ↓ الشَّمْسِ إِلَّا لِثَاتِهِ</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>The light of the sun has shed its lustre upon them, except their gums</em>]</span>. <span class="auth">(T, Ṣ, Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">إِيَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiyaA_A2">
					<p>And hence, by way of comparison, <span class="auth">(M,)</span> <span class="ar long">إِيَا النَّبَاتِ</span>, and<span class="arrow"><span class="ar">أَيَاؤُهُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">إِيَاتُهُ↓</span></span>, and<span class="arrow"><span class="ar">أَيَاتُهُ↓</span></span>, <span class="auth">(Ḳ,)</span> ‡ <em>The beauty of herbage,</em> <span class="auth">(M, Ḳ,)</span> and <em>its blossoms,</em> <span class="auth">(M,)</span> and <em>brightness,</em> <span class="auth">(Ḳ, TA,)</span> <em>in its verdure and growth.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">إِيَا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IiyaA_B1">
					<p><span class="ar long">أَيَا إِيَاهُ أَقْبِلْ</span>: <a href="#OayaA">see <span class="ar">أَيَا</span></a>, <a href="index.php?data=01_A/171_AyA">in art. <span class="ar">ايا</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayaMC">
				<h3 class="entry"><span class="ar">أَيَآء</span></h3>
				<div class="sense" id="OayaMC_A1">
					<p><span class="ar">أَيَآء</span>: <a href="#IiyaA">see the next preceeding paragraph</a> throughout.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayaApN">
				<h3 class="entry"><span class="ar">أَيَاةٌ</span></h3>
				<div class="sense" id="OayaApN_A1">
					<p><span class="ar">أَيَاةٌ</span>: <a href="#IiyaA">see <span class="ar">إِيَا</span></a> throughout.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiyaApN">
				<h3 class="entry"><span class="ar">إِيَاةٌ</span></h3>
				<div class="sense" id="IiyaApN_A1">
					<p><span class="ar">إِيَاةٌ</span>: <a href="#IiyaA">see <span class="ar">إِيَا</span></a> throughout.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuyayBapN">
				<h3 class="entry"><span class="ar">أُيَيَّةٌ</span></h3>
				<div class="sense" id="OuyayBapN_A1">
					<p><span class="ar">أُيَيَّةٌ</span> <a href="#ACN">dim. of <span class="ar">آءٌ</span></a>:<a href="index.php?data=01_A/000_A">see the letter <span class="ar">ا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyayBapN">
				<h3 class="entry"><span class="ar">إِيَيَّةٌ</span></h3>
				<div class="sense" id="IiyayBapN_A1">
					<p><span class="ar">إِيَيَّةٌ</span> <a href="#AyapN">dim. of <span class="ar">آيَةٌ</span>, q. v.</a> <span class="auth">(T.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayBaA">
				<h3 class="entry"><span class="ar">أَيَّا</span></h3>
				<div class="sense" id="OayBaA_A1">
					<p><span class="ar">أَيَّا</span>: <a href="#IiyBaA">see <span class="ar">إِيَّا</span></a>, <a href="index.php?data=01_A/171_AyA">in art. <span class="ar">ايا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiyBaA">
				<h3 class="entry"><span class="ar">إِيَّا</span></h3>
				<div class="sense" id="IiyBaA_A1">
					<p><span class="ar">إِيَّا</span>: <a href="index.php?data=01_A/171_AyA">see art. <span class="ar">ايا</span></a>. <span class="add">[Az says,]</span> I have not heard any derivation of <span class="ar">إِيَّا</span>; but I think, without being certain, that it is from <span class="ar">تَآيَيْتُهُ</span> as explained above; as though it were a noun from that verb, of the measure <span class="ar">فِعْلَى</span>, like <span class="ar">ذِكْرَى</span> from <span class="ar">ذَكَرْتُ</span>; so that the meaning of <span class="ar">إِيَّاكَ</span> is <em>I direct myself,</em> or <em>my aim, to,</em> or <em>towards, thee,</em> and <em>thy person.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBieBN">
				<h3 class="entry"><span class="ar">أَيِّىٌّ</span></h3>
				<div class="sense" id="OayBieBN_A1">
					<p><span class="ar">أَيِّىٌّ</span> <span class="add">[<a href="#OaeBN">a rel. n. of <span class="ar">أَىٌّ</span></a>]</span>. When you ask a man respecting his <span class="ar">كُورَة</span> <span class="add">[i. e. district, or city, or town]</span>, you say, <span class="ar">اَلْأَيِّىُّ</span> <span class="add">[<em>The person of what district,</em>, &amp;c., art thou?]</span>; like as you say, in asking him respecting his <span class="ar">قَبِيلَة</span> <span class="add">[or tribe]</span>, <span class="ar">اَلْمَنِىُّ</span> <span class="add">[from <span class="ar">مَنْ</span>]</span>: and you say also, <span class="ar long">أَيِّىٌّ أَنْتَ</span> <span class="add">[<em>A person of what district,</em>, &amp;c., <em>art thou?</em>]</span>; and <span class="ar">مَنىٌّ</span> <span class="auth">(T.)</span> <span class="add">[<a href="#manieBN">See also <span class="ar">مَنِىٌّ</span></a>, <a href="index.php?data=24_m/173_mn">in art. <span class="ar">من</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OayBaAna">
				<h3 class="entry"><span class="ar">أَيَّانَ</span></h3>
				<div class="sense" id="OayBaAna_A1">
					<p><span class="ar">أَيَّانَ</span>: <a href="index.php?data=01_A/181_Ayn">see art. <span class="ar">اين</span></a>. Lth says that it is used in the manner of <span class="ar">مَتَى</span>; <span class="add">[signifying <em>When?</em>]</span>; and that some say its <span class="ar">ن</span> is radical; others, that it is augmentative: <span class="auth">(T:)</span> IJ says, it must be from <span class="ar">أَىٌّ</span>, not from <span class="ar">أَيْنَ</span>, for two reasons: first, because <span class="ar">أَيْنَ</span> denotes place; and <span class="ar">أَيَّانَ</span>, time: and secondly, because nouns of the measure <span class="ar">فَعَّال</span> are few; and those of the measure <span class="ar">فَعْلَان</span>, many: <span class="pb" id="Page_0135"></span>so that if you name a man <span class="ar">أَيَّان</span>, it is imperfectly decl.: and he adds, that <span class="ar">أَىٌّ</span> means a part of a whole; so that it applies as properly to times as it does to other things: <span class="auth">(TA:)</span> Fr says that it is originally <span class="ar long">أَىَّ أَوَانٍ</span> <span class="add">[<em>at what time?</em>]</span>. <span class="auth">(T.)</span> One says, of a stupid, or foolish, person, <span class="ar long">لَا يَعْرَفُ أَيَّانَ</span> <span class="add">[<em>He knows not when</em>]</span>. <span class="auth">(IB.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Meo">
				<h3 class="entry"><span class="ar">آىْ</span></h3>
				<div class="sense" id="Meo_A1">
					<p><span class="ar">آىْ</span>: <a href="#Oaeo">see <span class="ar">أَىْ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آىْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Meo_B1">
					<p><a href="#Awe_2">and see also 2</a> <a href="index.php?data=01_A/169_Awe">in art. <span class="ar">اوى</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آىْ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Meo_C1">
					<p><span class="ar">آىٌ</span>: <a href="#AyapN">see what next follows</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MyapN.1">
				<h3 class="entry"><span class="ar">آيَةٌ</span></h3>
				<div class="sense" id="MyapN.1_A1">
					<p><span class="ar">آيَةٌ</span> <em>A sign, token,</em> or <em>mark, by which a person or thing is known;</em> syn. <span class="ar">عَلَامَةٌ</span> <span class="auth">(IAạr, T, Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">أَمَارَةٌ</span>: <span class="auth">(M, Ḳ:)</span> it properly signifies <em>any apparent thing inseparable from a thing not equally apparent, so that when one perceives the former, he knows that he perceives the other, which he cannot perceive by itself, when the two things are of one predicament; and this is apparent in the object of sense and in that of the intellect:</em> <span class="auth">(Er-Rághib, TA:)</span> it is of the measure <span class="ar">فَعْلَةٌ</span>, <span class="auth">(M, Ḳ,)</span> originally <span class="ar">أَيَّةٌ</span>; the <span class="add">[former]</span> <span class="ar">ى</span> being changed to <span class="ar">ا</span> because the letter before it is with fet-ḥ, though this is an extraordinary change: <span class="auth">(M:)</span> this is related as on the authority of Sb: <span class="auth">(TA:)</span> or it is of the measure <span class="ar">فَعَلَةٌ</span>, <span class="auth">(M, Ḳ,)</span> accord. to Kh; <span class="auth">(M;)</span> originally <span class="ar">أَوَيَةٌ</span>; <span class="auth">(Ṣ;)</span> <span class="add">[for, accord. to J and Fei,]</span> Sb said that its medial radical letter is <span class="ar">و</span>, and that the final is <span class="ar">ى</span>, because words of this class are more common than those of which the medial and final radical letters are both <span class="ar">ى</span>; <span class="auth">(Ṣ, Mṣb;)</span> and the rel. n. is <span class="ar">أَوَوِىُّ</span>: <span class="auth">(Ṣ:)</span> but IB says, Sb did not state that the medial radical letter of <span class="ar">آيَةٌ</span> is <span class="ar">و</span>, as J states; but he said that it is originally <span class="ar">أَيَةٌ</span>, and that the quiescent <span class="ar">و</span> is changed into <span class="ar">ا</span>; and he relates of Kh, that he allowed the rel. n. of <span class="ar">آيَةٌ</span> to be<span class="arrow"><span class="ar">آئِىٌّ↓</span></span> and<span class="arrow"><span class="ar">آيِىٌّ↓</span></span> and <span class="ar">آوِىٌّ</span>; but as to <span class="ar">أَوَوِىٌّ</span>, he says, I know not any one who has said it except J: <span class="auth">(TA:)</span> or it is of the measure <span class="ar">فَاعِلَةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> originally <span class="ar">آيَيَةٌ</span>, contracted by the suppression of its final radical letter <span class="add">[with the preceding kesreh]</span>: so accord. to Fr: <span class="add">[but see what follows <span class="auth">(after the pls.)</span>, where this is said to be the opinion of Ks, and disallowed by Fr:]</span> <span class="auth">(Ṣ, Mṣb:)</span> the pl. is <span class="ar">آيَاتٌ</span> and<span class="arrow"><span class="ar">آىٌ↓</span></span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> <span class="add">[or the latter is rather a coll. gen. n.,]</span> and pl. pl. <span class="ar">آيَآءٌ</span>: <span class="auth">(M, Ḳ:)</span> J says that one of its pls. is <span class="ar">آيَاىٌ</span>; <span class="add">[and we find the same also in some copies of the Ḳ;]</span> but this is a mistake for <span class="ar">آيَآءٌ</span>, which <a href="#AeN">is pl. of <span class="ar">آىٌ</span></a>, not of <span class="ar">آيَةٌ</span>: <span class="auth">(IB, TA:)</span> and this pl., being of the measure <span class="ar">أَفْعَالٌ</span>, has been adduced as evidence that the medial radical letter is <span class="ar">ى</span>, not <span class="ar">و</span>: <span class="auth">(TA:)</span> the dim. is <span class="arrow"><span class="ar">إِيَيَّةٌ↓</span></span>, <span class="add">[of the measure <span class="ar">فُعَيلَةٌ</span> changed to <span class="ar">فعَيْلَةٌ</span> because of the medial radical <span class="ar">ى</span>,]</span> which, accord. to Fr, shows the opinion of Ks, that <span class="ar">آيَةٌ</span> is of the measure <span class="ar">فَاعِلَةٌ</span> rendered defective by the suppression of its final radical letter, to be incorrect, because <span class="add">[Fr holds, in opposition to some others, that]</span> a noun of this measure has not its dim. formed on the measure <span class="ar">فُعَيْلَةٌ</span> unless it is a proper name. <span class="auth">(T.)</span> They said, <span class="ar long">اِفْعَلْهُ بِآيَةِ كَذَا</span> <span class="add">[<em>Do thou it at the sign of such a thing</em>]</span>; like as you say, <span class="ar long">بِعَلَامَةِ كَذَا</span> and <span class="ar">بِأَمَارَةِ</span>. <span class="auth">(M.)</span> And <span class="add">[in this sense, as is indicated by the context in the M,]</span> it is one of the nouns that are prefixed to verbs <span class="add">[as virtually governing the gen. case]</span>, <span class="auth">(M, Ḳ,*)</span> because of the nearness of its meaning to the meaning of <em>time:</em> <span class="auth">(Ḳ:)</span> as in the saying <span class="add">[of a poet]</span>,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بِآيَةِ تُقْدِمُونَ الخَيْلَ شُعْثًا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>At the sign of your urging forward the horses, unsmoothed in their coats,</em> or <em>not curried;</em> which means nearly the same as “at the time of your urging”, &amp;c.]</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MyapN.1_A2">
					<p><em>A sign</em> as meaning <em>an indication, an evidence,</em> or <em>a proof.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MyapN.1_A3">
					<p><em>A sign</em> as meaning <em>a miracle;</em> <span class="add">[and <em>a wonder;</em> for]</span> <span class="ar long">آيَاتُ ٱللّٰهِ</span> means <em>the wonders of God.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MyapN.1_A4">
					<p><em>An example,</em> or <em>a warning;</em> <span class="auth">(Fr, T, M, Mṣb, Ḳ;)</span> as, for instance, the case of Joseph and his brethren, related in the Ḳur: <span class="auth">(Fr, T:)</span> pl. <span class="arrow"><span class="ar">آىٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and <span class="ar">آيَاتٌ</span>. <span class="auth">(Fr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="MyapN.1_A5">
					<p><em>A message,</em> or <em>communication sent from one person or party to another;</em> syn. <span class="ar">رِسَالَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="MyapN.1_A6">
					<p>The <em>body,</em> or <em>corporeal form</em> or <em>figure</em> or <em>substance,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> of a man, <span class="auth">(Ṣ,)</span> <em>which one sees from a distance;</em> <span class="add">[as being a kind of sign;]</span> or <em>a person,</em> or <em>an individual;</em> syn. <span class="ar">شَخْصٌ</span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="MyapN.1_A7">
					<p><em>A whole company</em> of people: as in the saying, <span class="ar long">خَرَجَ القَوْمُ بِآيَتِهِمْ</span> <em>The people,</em> or <em>party, went forth with their whole company, not leaving behind them anything.</em> <span class="auth">(AA, Ṣ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اى</span> - Entry: <span class="ar">آيَةٌ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="MyapN.1_A8">
					<p><span class="add">[Hence, accord. to some, <em>A verse</em> of the Ḳur-án; as being]</span> <em>a collection of words</em> of the Book of God: <span class="auth">(Ṣ:)</span> or <em>a connected form of words</em> of the Ḳur-án <em>continued to its breaking off;</em> <span class="auth">(Ḳ, TA;)</span> accord. to Aboo-Bekr, so called because it is a sign of the breaking off: <span class="auth">(TA:)</span> or <em>a portion</em> of the Ḳur-án <em>after which a suspension of speech is approvable:</em> <span class="auth">(Mṣb:)</span> or <em>a portion</em> of the Ḳur-án <em>denoting any statute,</em> or <em>ordinance, of God, whether it be</em> <span class="add">[<em>what is generally termed</em>]</span> <em>an</em> <span class="ar">آيَة</span>, <span class="add">[i. e. <em>a verse,</em>]</span> <em>or a chapter</em> (<span class="ar">سُورَة</span>), <em>or an aggregate</em> <span class="add">[<em>and distinct</em>]</span> <em>portion of the latter.</em> <span class="auth">(Er-Rághib, Kull, TA.*)</span> <span class="add">[<span class="ar">الآيَةَ</span>, written after a quotation of a part of a verse of the Ḳur-án, means <span class="ar long">اِقْرَأِ الآيَةض</span> <em>Read thou the verse.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MyaA">
				<h3 class="entry"><span class="ar">آيَا</span></h3>
				<div class="sense" id="MyaA_A1">
					<p><span class="ar">آيَا</span>: <a href="#OayaA">see <span class="ar">أَيَا</span></a>, <a href="index.php?data=01_A/171_AyA">in art. <span class="ar">ايا</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="MYieBN">
				<h3 class="entry"><span class="ar">آئِىٌّ</span> / <span class="ar">آيِىٌّ</span></h3>
				<div class="sense" id="MYieBN_A1">
					<p><span class="ar">آئِىٌّ</span> and <span class="ar">آيِىٌّ</span>, accord. to Kh, <a href="#AyapN">rel. ns. of <span class="ar">آيَةٌ</span>, q. v.</a> <span class="auth">(IB.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOayBapN">
				<h3 class="entry"><span class="ar">تَأَيَّةٌ</span> / 
							<span class="ar">تَإِيَّةٌ</span> / 
							<span class="ar">تَئِيَّةٌ</span></h3>
				<div class="sense" id="taOayBapN_A1">
					<p><span class="ar">تَأَيَّةٌ</span>, or <span class="ar">تَإِيَّةٌ</span> or <span class="ar">تَئِيَّةٌ</span>: <a href="#Ae_5">see 5</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0131.pdf" target="pdf">
							<span>Lanes Lexicon Page 131</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0132.pdf" target="pdf">
							<span>Lanes Lexicon Page 132</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0133.pdf" target="pdf">
							<span>Lanes Lexicon Page 133</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0134.pdf" target="pdf">
							<span>Lanes Lexicon Page 134</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0135.pdf" target="pdf">
							<span>Lanes Lexicon Page 135</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
