<article class="root" id="Root_Avn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/023_Avm">اثم</a></span>
				<span class="ar">اثن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/025_Aj">اج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AivonaAni">
				<h3 class="entry"><span class="ar">اِثْنَانِ</span> / <span class="ar">اِثْنَتَانِ</span></h3>
				<div class="sense" id="AivonaAni_A1">
					<p><span class="ar">اِثْنَانِ</span> and <span class="ar">اِثْنَتَانِ</span>: <a href="index.php?data=04_v/059_vne">see art. <span class="ar">ثنى</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0022.pdf" target="pdf">
							<span>Lanes Lexicon Page 22</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
