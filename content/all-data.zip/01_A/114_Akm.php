<article class="root" id="Root_Akm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/113_Akl">اكل</a></span>
				<span class="ar">اكم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/115_Al">ال</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Akm_2">
				<h3 class="entry">2. ⇒ <span class="ar">أكّم</span></h3>
				<div class="sense" id="Akm_2_A1">
					<p><span class="ar">تَأْكِيمٌ</span> The <em>being big in the</em> <span class="ar">كَفَل</span> <span class="add">[i. e. the <em>hinder parts,</em> or <em>posteriors,</em> also termed <span class="ar">مَأْكَمَةٌ</span>]</span>. <span class="auth">(O, Ḳ.)</span> You say, <span class="ar long">أَكَّمَتِ المَرْأَةٌ</span> <em>The woman was large in the</em> <span class="ar">كَفَل</span>. <span class="auth">(TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Akm_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأكم</span></h3>
				<div class="sense" id="Akm_10_A1">
					<p><span class="ar">استأكم</span> <em>It</em> <span class="auth">(a place)</span> <em>became what are termed</em> <span class="ar">أَكَم</span>, q. v. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اكم</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Akm_10_B1">
					<p><span class="ar long">استأكم مَجْلِسَهُ</span> <em>He</em> <span class="auth">(a man, TA)</span> <em>found his sitting-place to be plain, smooth, soft,</em> or <em>easy to sit upon.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OakamN">
				<h3 class="entry"><span class="ar">أَكَمٌ</span></h3>
				<div class="sense" id="OakamN_A1">
					<p><span class="ar">أَكَمٌ</span>: <a href="#OakamapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OakamapN">
				<h3 class="entry"><span class="ar">أَكَمَةٌ</span></h3>
				<div class="sense" id="OakamapN_A1">
					<p><span class="ar">أَكَمَةٌ</span> <em>A hill,</em> or <em>mound,</em> syn. <span class="ar">تَلٌّ</span>, <span class="auth">(Mṣb, Ḳ,)</span> <span class="add">[in an absolute sense, or]</span> <em>of what is termed</em> <span class="ar">قُفّ</span> <span class="add">[q. v.]</span>, <span class="auth">(Ḳ,)</span> or, as in the M, <span class="auth">(TA,)</span> <em>of a single collection of stones:</em> or it is <em>inferior to mountains:</em> or <em>a place that is more elevated than what is around it, and is rugged, not to the degree of being stone:</em> <span class="auth">(Ḳ:)</span> or <em>an isolated mountain:</em> <span class="auth">(Ḳ voce <span class="ar">جَبَلٌ</span>:)</span> or <em>an eminence like what is termed</em> <span class="ar">رَابِيَة</span>: <em>a collection of stones in one place, sometimes rugged and sometimes not rugged:</em> <span class="auth">(Mṣb:)</span> or <em>i. q.</em> <span class="ar">قُفٌّ</span>, <em>except that the</em> <span class="ar">اكمة</span> <em>is higher and greater:</em> <span class="auth">(ISh, TA:)</span> or <em>what is higher than the</em> <span class="ar">قُفّ</span>, <em>compact and round, rising into the sky, abounding with stones:</em> <span class="auth">(TA:)</span> pl. <span class="ar">أَكَمَاتٌ</span> <span class="auth">(Ṣ, Mṣb)</span> and<span class="arrow"><span class="ar">أَكَمٌ↓</span></span>, <span class="add">[or this is rather a coll. gen. n. of which <span class="ar">أَكَمَةٌ</span> is the n. un.,]</span> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and <span class="ar">إِكَامٌ</span>, <span class="auth">(Ḳ, TA,)</span> or this <a href="#OakamN">is pl. of <span class="ar">أَكَمٌ</span></a>, <span class="auth">(Ṣ, Mṣb, TA,)</span> and <span class="ar">أُكُمٌ</span>, <span class="auth">(Ḳ, TA,)</span> or this <a href="#IikaAmN">is pl. of <span class="ar">إِكَامٌ</span></a>, <span class="auth">(Ṣ, Mṣb, TA,)</span> and <span class="ar">آكَامٌ</span> <span class="add">[a pl. of pauc.]</span>, <span class="auth">(Ḳ,)</span> or this <a href="#OukumN">is pl. of <span class="ar">أُكُمٌ</span></a>, <span class="auth">(Ṣ, Mṣb, TA,)</span> and <span class="ar">آكُمٌ</span> <span class="add">[which is also a pl. of pauc.]</span>, <span class="auth">(IJ, Ḳ,)</span> or this <a href="#OakamN">is a pl. of <span class="ar">أَكَمٌ</span></a>: <span class="auth">(TA:)</span> IHsh says that <span class="ar">أَكَمٌ</span> is the only word like <span class="ar">ثَمَرٌ</span> in its series of pls.; for its sing. <span class="add">[or n. un.]</span> is <span class="ar">أَكَمَةٌ</span>, and the pl. of this <span class="add">[or the coll. gen. n.]</span> is <span class="ar">أَكَمٌ</span>, and the pl. of this is <span class="ar">إِكَامٌ</span>, and the pl. of this is <span class="ar">أُكُمٌ</span>, and the pl. of this is <span class="ar">آكَامٌ</span>, and the pl. of this is <span class="ar">أَكَامِيمُ</span> <span class="add">[or <span class="ar">أَوَاكِيمُ</span>?]</span>. <span class="auth">(MF in art. <span class="ar">ثمر</span>.)</span> It is said in a prov., used in ridiculing any one who has told of his committing some fault, not desiring to reveal it, <span class="ar long">جُسْتُمُونِى وَوَرَآءَ الأَكَمَةِ مَا وَرَآءَهَا</span> <span class="add">[in which I think the first word to be a mistranscription, for <span class="ar">جِئْتُمُونِى</span>, and the literal meaning to be, <em>Ye have come to me; but behind the hill is what is behind it</em>]</span>: related on the authority of Zeyd Ibn-Kethweh. <span class="auth">(TA.)</span> And one says, <span class="ar long">لَا تَبُلْ عَلَى أَكَمةٍ</span>, meaning ‡ <em>Publish not what is secret of thine affair.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOokamN">
				<h3 class="entry"><span class="ar">مَأْكَمٌ</span> / <span class="ar">مَأْكِمٌ</span></h3>
				<div class="sense" id="maOokamN_A1">
					<p><span class="ar">مَأْكَمٌ</span> and <span class="ar">مَأْكِمٌ</span>: <a href="#maOokamapN">see what next follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOokamapN">
				<h3 class="entry"><span class="ar">مَأْكَمَةٌ</span></h3>
				<div class="sense" id="maOokamapN_A1">
					<p><span class="ar">مَأْكَمَةٌ</span>, <span class="auth">(El-Fárábee,)</span> or <span class="ar">مَأْكِمَةٌ</span>, <span class="auth">(Ṣ,)</span> or both, and<span class="arrow"><span class="ar">مَأْكَمٌ↓</span></span> and<span class="arrow"><span class="ar">مَأْكِمٌ↓</span></span>, <span class="auth">(IAth, Ḳ,)</span> The <em>hinder part, posteriors, buttocks,</em> or <em>rump,</em> of a woman; syn. <span class="ar">عَجِيزَةٌ</span>: <span class="auth">(Ṣ:)</span> or <em>a portion of flesh on the head of the</em> <span class="ar">وَرِك</span> <span class="add">[or <em>haunch</em>]</span>; <em>one of two such portions:</em> <span class="auth">(Zj in his “Khalk el-Insán,“and Ḳ:)</span> or these are <em>two protuberances of flesh on the heads of the upper parts of the</em> <span class="ar">وَرِكَانِ</span> <span class="add">[or <em>haunches</em>]</span>; <em>on the right and left:</em> <span class="auth">(TA:)</span> or they are <em>two portions of flesh conjoining the</em> <span class="ar">عَجُز</span> <span class="add">[or <em>buttocks</em>]</span> <em>and the</em> <span class="ar">مَتْنَانِ</span> <span class="add">[or <em>two portions of flesh and sinew next the back-bone, on each side</em>]</span>; <span class="auth">(Ḳ, TA;)</span> or, as in the Nh, <em>conjoining the</em> <span class="ar">عَجْب</span> <span class="add">[or rump-bone]</span> <em>and the</em> <span class="ar">متنان</span>: or <em>two portions of flesh at the root of the</em> <span class="ar">وَرِكَاِ</span>: <span class="auth">(TA:)</span> pl. <span class="ar">مَآكِمُ</span>. <span class="auth">(Ṣ, Ḳ.)</span> Lḥ mentions the saying, <span class="ar long">إِنَّهُ لَعَظِيمُ المآكِمِ</span> <span class="add">[<em>Verily he is big in the hinder parts</em>]</span>; as though they called every portion thereof <span class="ar">مأكم</span>. <span class="auth">(TA.)</span> And one says in reviling a person, <span class="ar long">يَا ٱبِنَ أَحْمَرِ المَأْكَمَةِ</span>, meaning <em>O son of him who is red in the</em> <span class="ar">سَفِلَةِ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWakBimapN">
				<h3 class="entry"><span class="ar">مُؤَكِّمَةٌ</span></h3>
				<div class="sense" id="muWakBimapN_A1">
					<p><span class="ar">مُؤَكِّمَةٌ</span>: <a href="#muwaAkimapN">see what follows</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaAkimapN">
				<h3 class="entry"><span class="ar">مُؤَاكِمَةٌ</span></h3>
				<div class="sense" id="muWaAkimapN_A1">
					<p><span class="ar">مُؤَاكِمَةٌ</span> <span class="add">[in the CK, erroneously, <span class="ar">مُؤاكَمَة</span>]</span> and<span class="arrow"><span class="ar">مُؤَكِّمَةٌ↓</span></span> She <em>who is large in the</em> <span class="ar">مَأْكَمَتَانِ</span>. <span class="auth">(Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0073.pdf" target="pdf">
							<span>Lanes Lexicon Page 73</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
