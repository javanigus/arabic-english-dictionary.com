<article class="root" id="Root_Ajm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/028_Ajl">اجل</a></span>
				<span class="ar">اجم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/030_Ajn">اجن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ajm_1">
				<h3 class="entry">1. ⇒ <span class="ar">أجم</span></h3>
				<div class="sense" id="Ajm_1_A1">
					<p><span class="ar">أَجِمَهُ</span>, with kesr, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْجَمُ</span>}</span></add>,]</span> <span class="auth">(AZ, Ṣ, O,)</span> inf. n. <span class="ar">أَجَمٌ</span>; <span class="auth">(KL, PṢ;)</span> or <span class="ar">أَجَمَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِمُ</span>}</span></add>, <span class="auth">(so in the Ḳ,)</span> inf. n. <span class="ar">أَجْمٌ</span>; <span class="auth">(TḲ;)</span> <span class="add">[but <span class="ar">أَجِمَ</span> is the form commonly known; and if it were incorrect, the author of the Ḳ would probably, accord. to his usual custom, have charged J with error respecting it;]</span> <em>He loathed it; disliked it; was,</em> or <em>became, disgusted with it;</em> namely, food; <span class="auth">(AZ, Ṣ, O, Ḳ;)</span>, &amp;c.; <span class="auth">(Ḳ;)</span> <em>from constantly keeping to it;</em> <span class="auth">(AZ, Ṣ, O;)</span> or <em>because of its not agreeing with him:</em> <span class="auth">(TA:)</span> <em>he reckoned it bad:</em> <span class="auth">(KL:)</span> and<span class="arrow"><span class="ar">تأجّمهُ↓</span></span> also signifies <em>he disliked, disapproved,</em> or <em>hated, it;</em> or <em>he expressed,</em> or <em>showed, dislike, disapprobation,</em> or <em>hatred, of it;</em> syn. <span class="ar">تَكَرَّهَهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ajm_1_B1">
					<p><span class="ar long">أَجَمَ فَلَانَّا</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْجِمُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">أَجْمٌ</span>, <span class="auth">(TḲ,)</span> <em>He incited,</em> or <em>urged, such a one to do that which he disliked, disapproved,</em> or <em>hated.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ajm_2">
				<h3 class="entry">2. ⇒ <span class="ar">يُؤَجِّمُ</span></h3>
				<div class="sense" id="Ajm_2_A1">
					<p><a href="#Ajm_4">see 4</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajm_4">
				<h3 class="entry">4. ⇒ <span class="ar">آجم</span></h3>
				<div class="sense" id="Ajm_4_A1">
					<p><span class="ar long">يُؤْجِمُ النَّاسَ</span>, or<span class="arrow"><span class="ar long">يُؤَجِّمُ↓ النَّاسَ</span></span>, <span class="add">[accord. to different copies of the Ḳ, the former being the reading in the TA,]</span> <em>He makes men's own selves to be objects of dislike, disapprobation,</em> or <em>hatred, to them.</em> <span class="auth">(Ḳ voce <span class="ar">أَجُومٌ</span>.)</span> <span class="add">[Accord. to the TḲ, you say, <span class="ar long">آجَمَهُ مِنْهُ</span>, inf. n. <span class="ar">إِيجَامٌ</span>, meaning <em>He made him to be an object of dislike, disapprobation,</em> or <em>hatred, to him.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ajm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأجّم</span></h3>
				<div class="sense" id="Ajm_5_A1">
					<p><span class="ar">تأجّم</span> <em>He</em> <span class="auth">(a lion)</span> <em>entered his</em> <span class="ar">أَجَمَة</span> <span class="add">[or <em>thicket</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجم</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ajm_5_B1">
					<p><span class="ar">تأجّمهُ</span>: <a href="#Ajm_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajomN">
				<h3 class="entry"><span class="ar">أَجْمٌ</span></h3>
				<div class="sense" id="OajomN_A1">
					<p><span class="ar">أَجْمٌ</span> <em>Any square, roofed, house:</em> <span class="auth">(Ḳ:)</span> mentioned by ISd as on the authority of Yaạḳoob: but <a href="#OujumN">see <span class="ar">أُجُمٌ</span></a> as explained by J <span class="add">[in the Ṣ]</span> on the same authority. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OujomN">
				<h3 class="entry"><span class="ar">أُجْمٌ</span></h3>
				<div class="sense" id="OujomN_A1">
					<p><span class="ar">أُجْمٌ</span>: <a href="#OujumN">see <span class="ar">أُجُمٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجم</span> - Entry: <span class="ar">أُجْمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OujomN_B1">
					<p><a href="#OajamapN">It is also a pl. of <span class="ar">أَجَمَةٌ</span></a>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OajamN">
				<h3 class="entry"><span class="ar">أَجَمٌ</span></h3>
				<div class="sense" id="OajamN_A1">
					<p><span class="ar">أَجَمٌ</span>: <a href="#OajamapN">see <span class="ar">أَجَمَةٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OujumN">
				<h3 class="entry"><span class="ar">أُجُمٌ</span></h3>
				<div class="sense" id="OujumN_A1">
					<p><span class="ar">أُجُمٌ</span> <em>A fortress;</em> <span class="auth">(Mgh, Mṣb, Ḳ;)</span> like <span class="ar">أُطُمٌ</span>: <span class="auth">(Mgh:)</span> pl. <span class="ar">آجَامٌ</span>. <span class="auth">(Mgh, Mṣb, Ḳ.)</span> <span class="ar">الأُجُمُ</span> <span class="add">[is the name of]</span> <em>A fortress</em> <span class="auth">(Ṣ, Ḳ)</span> <em>in El-Medeeneh,</em> <span class="auth">(Ḳ,)</span> <em>built of stones by the people of that city:</em> and Yaạḳoob says that <span class="ar">أُجُمٌ</span> signifies <em>any square, roofed, house.</em> <span class="auth">(Ṣ, Ṣgh.)</span> Imra-el-Ḳeys says, <span class="add">[describing a vehement rain,]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَتَيْمَآءَ لَمْ يَتْرُكْ بِهَا جِذْعَ نَخْلَةٍ</span> *</div> 
						<div class="star">* <span class="ar long">وَلَا أُجُمَّا إِلَّا مَشِيدًا بِجَنْدَلِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And Teymà,</em> <span class="auth">(a town so called,)</span> <em>it left not therein a trunk of a palm-tree, nor a square, roofed, house, unless raised high with stones:</em> but in the Calc. ed. of the Mo' allakát, <span class="auth">(p. 54,)</span> for <span class="ar">أُجُمَّا</span>, we find <span class="ar">أُطُمَّا</span>, which has the same meaning]</span>. <span class="auth">(Ṣ, Ṣgh.)</span> <a href="#OajomN">See also <span class="ar">أَجْمٌ</span></a>. <span class="auth">(TA.)</span> Accord. to Aṣ, it is also pronounced <span class="arrow"><span class="ar">أُجْمٌ↓</span></span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajamapN">
				<h3 class="entry"><span class="ar">أَجَمَةٌ</span></h3>
				<div class="sense" id="OajamapN_A1">
					<p><span class="ar">أَجَمَةٌ</span> <em>A thicket, wood,</em> or <em>forest; a collection,</em> <span class="auth">(Mgh, Mṣb,)</span> or <em>an abundant collection,</em> <span class="auth">(Ḳ,)</span> <em>of tangled, confused,</em> or <em>dense, trees,</em> or <em>shrubs:</em> <span class="auth">(Mgh, Mṣb, Ḳ:)</span> or it is <em>of reeds,</em> or <em>canes:</em> <span class="auth">(Ṣ:)</span> or <em>a</em> <span class="add">[<em>place such as is termed</em>]</span> <span class="ar">مَغِيض</span> <em>of water collected together, in which, in consequence thereof, trees grow:</em> <span class="auth">(Ṣ in art. <span class="ar">غيض</span>:)</span> <span class="add">[or]</span> it signifies also <em>a bed,</em> or <em>place of growth, of canes</em> or <em>reeds:</em> <span class="auth">(Mgh:)</span> the pl. is <span class="ar">أَجَمَاتٌ</span> and <span class="ar">أُجُمٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="ar">أُجْمٌ</span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">أَجَمٌ↓</span></span>, <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> <span class="add">[or rather this last is a coll. gen. n., of which <span class="ar">أَجَمَةٌ</span> is the n. un.,]</span> and <span class="ar">إِجَامٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> and <span class="add">[pl. of pauc.]</span> <span class="ar">آجَامٌ</span>, <span class="auth">(Ṣ, M, Mgh, Ḳ,)</span> or the last but one <a href="#OajamN">is pl. of <span class="ar">أَجَمٌ</span></a>, <span class="auth">(M,)</span> and so is the last. <span class="auth">(Lḥ, M, Mṣb.)</span> And hence, The <em>haunt of a lion.</em> <span class="auth">(TA in art. <span class="ar">حرب</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اجم</span> - Entry: <span class="ar">أَجَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OajamapN_A2">
					<p><span class="ar">آجَامٌ</span> <span class="add">[in the CK <span class="ar">اَجام</span>]</span> also signifies <em>Frogs.</em> <span class="auth">(Ṣgh, Ḳ.)</span> <span class="add">[App. because frogs are generally found in beds of canes or reeds.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OajuwmN">
				<h3 class="entry"><span class="ar">أَجُومٌ</span></h3>
				<div class="sense" id="OajuwmN_A1">
					<p><span class="ar">أَجُومٌ</span> signifies <span class="ar long">مَنْ يُؤْجِمُ النَّاسَ</span>, or <span class="ar long">يُؤَجِّمُ النَّاسَ</span>; <span class="add">[accord. to different copies of the Ḳ; <a href="#Ajm_4">see 4</a>;]</span> i. e. One <em>who makes men's own selves to be objects of dislike, disapprobation,</em> or <em>hatred, to them.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MjimN">
				<h3 class="entry"><span class="ar">آجِمٌ</span></h3>
				<div class="sense" id="MjimN_A1">
					<p><span class="ar">آجِمٌ</span> <em>Loathing, disliking,</em> or <em>regarding with disgust.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اجم</span> - Entry: <span class="ar">آجِمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="MjimN_B1">
					<p><span class="ar long">مَآءٌ آجِمٌ</span> <em>i. q.</em><span class="arrow"><span class="ar">مَأْجُومٌ↓</span></span> <span class="add">[<em>Water that is loathed, disliked,</em> or <em>regarded with disgust</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="maOojuwmN">
				<h3 class="entry"><span class="ar">مَأْجُومٌ</span></h3>
				<div class="sense" id="maOojuwmN_A1">
					<p><span class="ar">مَأْجُومٌ</span>: <a href="#AjimN">see <span class="ar">آجِمٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0026.pdf" target="pdf">
							<span>Lanes Lexicon Page 26</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
