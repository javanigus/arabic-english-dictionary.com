<article class="root" id="Root_Anv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/141_Ant">انت</a></span>
				<span class="ar">انث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/143_AnH">انح</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="Anv_1">
				<h3 class="entry">1. ⇒ <span class="ar">أنث</span></h3>
				<div class="sense" id="Anv_1_A1">
					<p><span class="add">[<span class="ar">أَنُثَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْنُثُ</span>}</span></add>, inf. n. <span class="ar">أَنَاثَةٌ</span> and <span class="ar">أُنُوثَةٌ</span>, <span class="auth">(see the former of these two ns. below,)</span> <em>It was,</em> or <em>became, female, feminine,</em> or <em>of the feminine gender.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anv_1_A2">
					<p><span class="add">[And hence, <span class="ar">أَنُثَتْ</span>, said of land (<span class="ar">أَرْض</span>), ‡ <em>It was,</em> or <em>became, such as is termed</em> <span class="ar">أَنِيثَة</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Anv_1_A3">
					<p><span class="add">[Hence also,]</span> <span class="ar">أَنُثَ</span>, said of iron, ‡ <em>It was,</em> or <em>became, soft.</em> <span class="auth">(Golius, from the larger of two editions of the lexicon entitled <span class="ar long">مرقاة اللغة</span>.)</span> Accord. to IAạr, softness is the primary signification. <span class="auth">(M.)</span> <span class="add">[But accord. to the A, the second and third of the meanings given above are tropical: (<a href="#OaniyvN">see <span class="ar">أَنِيثٌ</span></a>:) and the verb in the first of the senses here assigned to it, if not proper, is certainly what is termed <span class="ar long">حَقِيقَة عُرْفِيَّة</span>, i. e., conventionally regarded as proper.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anv_2">
				<h3 class="entry">2. ⇒ <span class="ar">أنّث</span></h3>
				<div class="sense" id="Anv_2_A1">
					<p><span class="ar">أنّثهُ</span>, inf. n. <span class="ar">تَأْنِيثٌ</span>, <em>He made it</em> <span class="auth">(namely, a noun <span class="add">[&amp;c.]</span>, S and Mṣb)</span> <em>feminine;</em> <span class="auth">(Ṣ, M, L, Mṣb;)</span> <em>he attached to it,</em> or <em>to that which was syntactically dependent upon it, the sign of the feminine gender.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anv_2_A2">
					<p>† <em>He,</em> or <em>it, rendered him effeminate.</em> <span class="auth">(KL.)</span> <span class="add">[See the pass. part. n., below.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انث</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Anv_2_B1">
					<p><span class="ar long">أنّث لَهُ</span>, inf. n. as above, ‡ <em>He acted gently,</em> <span class="add">[or <em>effeminately</em>]</span> <em>towards him;</em> as also<span class="arrow"><span class="ar long">تأنّث↓ له</span></span>. <span class="auth">(Ḳ, TA.)</span> And <span class="ar long">أنّث فِى أَمْرِهِ</span>, inf. n. as above, <span class="auth">(T, A,)</span> ‡ <em>He acted gently in his affair:</em> <span class="auth">(A:)</span> or <em>he applied himself gently to his affair:</em> <span class="auth">(T:)</span> and some say,<span class="arrow"><span class="ar long">تأنّث↓ فى امره</span></span>, meaning <em>he acted effeminately in his affair.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anv_4">
				<h3 class="entry">4. ⇒ <span class="ar">آنث</span></h3>
				<div class="sense" id="Anv_4_A1">
					<p><span class="ar">آنَثَتْ</span>, <span class="auth">(Ṣ, M, A, Ḳ,)</span> inf. n. <span class="ar">إِينَاثٌ</span>, <span class="auth">(Ḳ,)</span> <em>She</em> <span class="auth">(a woman)</span> <em>brought forth a female,</em> <span class="auth">(Ṣ, A, Ḳ,)</span> or <em>females.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anv_4_A2">
					<p><span class="add">[And hence,]</span> † <em>It</em> <span class="auth">(land, <span class="ar">أَرْض</span>,)</span> <em>was,</em> or <em>became, such as is termed</em> <span class="ar">مِئْنَاث</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Anv_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأنّث</span></h3>
				<div class="sense" id="Anv_5_A1">
					<p><span class="ar">تأنث</span> <em>It</em> <span class="auth">(a noun <span class="add">[&amp;c.]</span>)</span> <em>was,</em> or <em>became,</em> or <em>was made, feminine.</em> <span class="auth">(Ṣ, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Anv_5_A2">
					<p><a href="#Anv_2">See also 2</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ounovae">
				<h3 class="entry"><span class="ar">أُنْثَى</span></h3>
				<div class="sense" id="Ounovae_A1">
					<p><span class="ar">أُنْثَى</span> <em>Female; feminine; of the female,</em> or <em>feminine, sex,</em> or <em>gender; contr. of</em> <span class="ar">ذَكَرٌ</span>: <span class="auth">(T, Ṣ, M:)</span> an epithet applied to anything of that sex or gender: <span class="auth">(T:)</span> IAạr asserts, that a woman is termed <span class="ar">انثى</span> from the phrase <span class="ar long">بَلَدٌ أَنِيثٌ</span>, q. v, because of her softness; she being more soft than a man: <span class="auth">(M, L:)</span> <span class="add">[but see the observation at the end of the first paragraph of this art.:]</span> the pl. is <span class="ar">إِنَاثٌ</span>; <span class="auth">(T, Ṣ, M, A, Mṣb, Ḳ;)</span> and sometimes one says <span class="ar">أُنُثٌ</span>, as though it were <a href="#IinaAvN">pl. of <span class="ar">إِنَاثٌ</span></a>; <span class="auth">(Ṣ;)</span> or it is <span class="add">[truly]</span> <a href="#IinaAvN">pl. of <span class="ar">إِنَاثٌ</span></a>, like as <span class="ar">نُمُرٌ</span> is of <span class="ar">نِمَارٌ</span>; <span class="auth">(T;)</span> and <span class="ar">أَنَاثَى</span>, <span class="auth">(T, A, Mṣb, Ḳ,)</span> which last occurs in poetry. <span class="auth">(T.)</span> You say, <span class="ar long">هٰذَا طَائِرٌ وَأُنْثَاهُ</span> <span class="add">[<em>This is a</em> (<em>male</em>) <em>bird and his female</em>]</span>: not <span class="ar">أُنْثَاتُهُ</span>. <span class="auth">(ISk, T.)</span> In the Ḳur iv. 117, I’Ab reads <span class="ar">أُثُنًا</span> <span class="add">[in the place of <span class="ar">أُنُثًا</span> or <span class="ar">إِنَاثًا</span>]</span>; and Fr says that it <a href="#wavanN">is pl. of <span class="ar">وَثَنٌ</span></a>, the <span class="ar">و</span> in <span class="ar">وُثُنٌ</span> being changed into <span class="ar">أ</span> as in <span class="ar">أُقِّتَتٌ</span> <span class="add">[for <span class="ar">وُقِّتَتٌ</span>]</span>. <span class="auth">(T, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="Ounovae_A2">
					<p><span class="ar long">اِمْرَأَةٌ أَنْثَى</span> ‡ <span class="add">[<em>A feminine woman,</em>]</span> means <em>a perfect woman;</em> <span class="auth">(T, A, Ḳ;)</span> a woman being thus termed in praise; like as a man is termed <span class="ar long">رَجُلٌ ذَكَرٌ</span>. <span class="auth">(T, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="Ounovae_A3">
					<p><span class="add">[The pl.]</span> <span class="ar">إِنَاثٌ</span> also signifies † <em>Inanimate things;</em> <span class="auth">(Lḥ, T, M, Ḳ;)</span> as trees and stones <span class="auth">(T, Ḳ)</span> and wood. <span class="auth">(T.)</span> In the passage of the Ḳur mentioned above, <span class="ar">إِنَاثًا</span> is said to have this meaning: <span class="auth">(T, M:)</span> <span class="add">[or it there means <em>females;</em> for]</span> Fr says that El-Lát and El-'Ozzà and the like were said by the Arabs to be feminine divinities. <span class="auth">(T, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="Ounovae_A4">
					<p>Also † <em>Small stars.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="Ounovae_A5">
					<p>And <span class="add">[the dual]</span> <span class="ar">الأُنْثَيَانِ</span> ‡ <em>The two testicles;</em> syn. <span class="ar">الخُصْيَتَانِ</span>; <span class="auth">(Ṣ, Ḳ;)</span> or <span class="ar">الخُصْيَانِ</span> <span class="add">[which is said by some to mean <em>the scrotum;</em> but the former is generally, though app. not always, meant by <span class="ar">الانثيان</span>]</span>. <span class="auth">(M, Mgh, Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="Ounovae_A6">
					<p>And <em>The two ears:</em> <span class="auth">(Aṣ, T, Ṣ, M, A, Mgh, Ḳ:)</span> because they are of the fem. gender. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="Ounovae_A7">
					<p>And † <em>The two tribes of Bejeeleh and Kudá'ah.</em> <span class="auth">(Ḳ)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="Ounovae_A8">
					<p>And <span class="ar long">أُنْثَيَا الفَرَسِ</span> † <em>The inner parts</em> (<span class="ar">الرَّبَلَتَانِ</span>) <em>of the thighs of the horse.</em> <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أُنْثَى</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A9</span>
				</div>
				<div class="sense" id="Ounovae_A9">
					<p>And <span class="ar">الأُنْثَى</span> is also used to signify † <em>The</em> <span class="add">[<em>engine of war called</em>]</span> <span class="ar">مَنْجَنِيق</span>; because the latter word is <span class="add">[generally]</span> of the feminine gender. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaniyvN">
				<h3 class="entry"><span class="ar">أَنِيثٌ</span></h3>
				<div class="sense" id="OaniyvN_A1">
					<p><span class="ar">أَنِيثٌ</span>: <a href="#muwanBavN">see <span class="ar">مُؤَنَّثٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أَنِيثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaniyvN_A2">
					<p><span class="ar long">أَرْضٌ أَنِيثَةٌ</span>, <span class="auth">(AA,* IAạr, T, Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">مِئْنَاثٌ↓</span></span>, <span class="auth">(ISh, T, M, Ḳ,)</span> ‡ <em>Plain, even,</em> or <em>soft, land,</em> or <em>ground,</em> <span class="auth">(ISh, IAạr, T, M, Ḳ,)</span> <em>that produces many plants,</em> or <em>much herbage;</em> <span class="auth">(AA, T, M, Ḳ;)</span> or <em>that produces herbs,</em> or <em>leguminous plants, and is plain, even,</em> or <em>soft;</em> <span class="auth">(El-Kilábee, Ṣ;)</span> or <em>fitted for producing plants,</em> or <em>herbage; not rugged.</em> <span class="auth">(ISh, T, L.)</span> And <span class="ar long">مَكَانٌ أَنِيثٌ</span> <em>A place in which the herbage grows quickly, and becomes abundant.</em> <span class="auth">(T, L.)</span> And <span class="ar long">بَلَدٌ أَنِيثٌ</span> † <em>A country,</em> or <em>district, of which the soil is soft, and plain,</em> or <em>even.</em> <span class="auth">(IAạr, M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أَنِيثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaniyvN_A3">
					<p><span class="ar long">حَدِيدٌ أَنِيثٌ</span> ‡ <em>Female iron; that which is not what is termed</em> <span class="ar">ذَكَرٌ</span>: <span class="auth">(Ṣ, M, L, Ḳ:)</span> <em>soft iron.</em> <span class="auth">(T and Ḳ in art. <span class="ar">انف</span>.)</span> And <span class="ar long">سَيْفٌ أَنِيثٌ</span> ‡ <em>A sword of female iron:</em> <span class="auth">(M, L:)</span> or <em>a sword that is not sharp,</em> or <em>cutting; a blunt sword:</em> <span class="auth">(T, M,* L:)</span> and<span class="arrow"><span class="ar long">سَيْفٌ مِئْنَاثٌ↓</span></span>, and<span class="arrow"><span class="ar">مِئْنَاثَةٌ↓</span></span>, <span class="auth">(T, M, L, Ḳ,)</span> mentioned by Lḥ, <span class="auth">(T, L,)</span> <em>a blunt sword;</em> <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">مُؤَنَّثٌ↓</span></span>: <span class="auth">(TA:)</span> or <em>a sword of soft iron.</em> <span class="auth">(T, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanaAvapN">
				<h3 class="entry"><span class="ar">أَنَاثَةٌ</span></h3>
				<div class="sense" id="OanaAvapN_A1">
					<p><span class="ar">أَنَاثَةٌ</span> <span class="add">[<a href="#Anv_1">inf. n. of <span class="ar">أَنُثَ</span>, q. v.</a>:]</span> The <em>female,</em> or <em>feminine, nature,</em> or <em>quality,</em> or <em>gender;</em> <span class="auth">(M;)</span> as also<span class="arrow"><span class="ar">أُنُوثَةٌ↓</span></span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أَنَاثَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanaAvapN_A2">
					<p>‡ The <em>quality of land which is termed</em> <span class="ar">أَنِيثَةٌ</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">أَنَاثَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OanaAvapN_A3">
					<p><span class="add">[‡ <em>Softness</em> of iron: <a href="#OanyvN">see <span class="ar">أَنيثٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OunuwvapN">
				<h3 class="entry"><span class="ar">أُنُوثَةٌ</span></h3>
				<div class="sense" id="OunuwvapN_A1">
					<p><span class="ar">أُنُوثَةٌ</span>: <a href="#OanaAvapN">see the paragraph next preceding</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWonivN">
				<h3 class="entry"><span class="ar">مُؤْنِثٌ</span></h3>
				<div class="sense" id="muWonivN_A1">
					<p><span class="ar">مُؤْنِثٌ</span> A woman <em>bringing forth,</em> or <em>who brings forth, a female,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>females.</em> <span class="auth">(M.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="miYonaAvN">
				<h3 class="entry"><span class="ar">مِئْنَاثٌ</span></h3>
				<div class="sense" id="miYonaAvN_A1">
					<p><span class="ar">مِئْنَاثٌ</span> A woman <em>who usually brings forth females:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> and a man <em>who usually begets female children;</em> for the measure <span class="ar">مِفْعَالٌ</span> applies equally to both sexes: <span class="auth">(Ṣ:)</span> the contr. epithet is <span class="ar">مِذْكَارٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">مِئْنَاثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="miYonaAvN_A2">
					<p><a href="#muwanBavN">See also <span class="ar">مُؤَنَّثٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">مِئْنَاثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="miYonaAvN_A3">
					<p><span class="ar long">أَرْضٌ مِئْنَاثٌ</span>: <a href="#OaniyvN">see <span class="ar">أَنِيثٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">مِئْنَاثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="miYonaAvN_A4">
					<p><span class="ar long">سَيْفٌ مِئْنَاثٌ</span>, and <span class="ar">مِئْنَاثَةٌ</span>: <a href="#OaniyvN">see <span class="ar">أَنِيثٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWanBavN">
				<h3 class="entry"><span class="ar">مُؤَنَّثٌ</span></h3>
				<div class="sense" id="muWanBavN_A1">
					<p><span class="ar">مُؤَنَّثٌ</span> <span class="add">[A <em>feminine</em> word; a word <em>made feminine.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">مُؤَنَّثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWanBavN_A2">
					<p><span class="add">[Also,]</span> <span class="auth">(T, A, Ḳ,)</span> and<span class="arrow"><span class="ar">أَنِيثٌ↓</span></span>, <span class="auth">(AA, T,)</span> and<span class="arrow"><span class="ar">مِئْنَاثٌ↓</span></span>, <span class="auth">(Ḳ,)</span> and<span class="arrow"><span class="ar">مِئْنَاثَةٌ↓</span></span>, <span class="auth">(TA,)</span> ‡ <em>i. q.</em> <span class="ar">مُخَنَّثٌ</span>, <span class="auth">(AA, T, A, Ḳ,)</span> i. e. An <em>effeminate</em> man; one <em>who resembles a woman</em> <span class="auth">(AA, T, TA)</span> <em>in gentleness, and in softness of speech, and in an affectation of languor of the limbs:</em> <span class="auth">(TA:)</span> or a man <em>in the form,</em> or <em>make, of a female.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">مُؤَنَّثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="muWanBavN_A3">
					<p><span class="ar long">سَيْفٌ مُؤَنَّثٌ</span>: <a href="#OaniyvN">see <span class="ar">أَنِيثٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انث</span> - Entry: <span class="ar">مُؤَنَّثٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="muWanBavN_A4">
					<p><span class="ar long">طِيبٌ مُؤَنَّثٌ</span> ‡ <em>Perfume that is used by women; such as</em> <span class="ar">خَلُوق</span> <em>and</em> <span class="ar">زَعْفَران</span>, <span class="auth">(Sh, T, L,)</span> <em>and what colours the clothes:</em> <span class="auth">(L:)</span> <span class="ar long">ذُكُورَةُ الطِّيبِ</span> being such perfumes as have no colour; such as <span class="ar">غَالِيَة</span> and <span class="ar">كَافُور</span> and <span class="ar">مِسْك</span> and <span class="ar">عُود</span> and <span class="ar">عَنْبَر</span> and the like, which leave no mark. <span class="auth">(T, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0112.pdf" target="pdf">
							<span>Lanes Lexicon Page 112</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
