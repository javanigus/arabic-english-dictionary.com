<article class="root" id="Root_Ans">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/143_AnH">انح</a></span>
				<span class="ar">انس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/145_Anf">انف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Ans_1">
				<h3 class="entry">1. ⇒ <span class="ar">أنس</span></h3>
				<div class="sense" id="Ans_1_A1">
					<p><span class="ar long">أَنِسَ بِهِ</span>, <span class="auth">(AZ, Ṣ, M, A, Mṣb, Ḳ,)</span> and <span class="ar">إِلَيْهِ</span>, <span class="auth">(A,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَأْنَسُ</span>}</span></add>; <span class="auth">(Mṣb, TA;)</span> and <span class="ar">أَنَسَ</span>, <span class="auth">(Ṣ, M, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْنِسُ</span>}</span></add> <span class="auth">(M, Mṣb, TA)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْنُسُ</span>}</span></add>; <span class="auth">(M;)</span> and <span class="ar">أَنُسَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْنُسُ</span>}</span></add>; <span class="auth">(M, Ṣgh, Ḳ;)</span> inf. n. <span class="ar">أَنَسٌ</span> and <span class="ar">أَنَسَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> both of <span class="ar">أَنِسَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">إِنَسٌ</span>, <span class="auth">(AZ, AḤát, T, M, Mṣb,)</span> also of <span class="ar">أَنِسَ</span>, <span class="auth">(AZ, AḤát, Mṣb, TA,)</span> but this is rare, <span class="auth">(T, TA,)</span> and <span class="ar">أُنْسٌ</span>, <span class="auth">(T, Ṣ, M, A, Ḳ,)</span> which is the more common, <span class="auth">(T, TA,)</span> and is of <span class="ar">أَنَسَ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">أُنْسٌ</span> has a different signification from <span class="ar">إِنْسٌ</span> the inf. n. of <span class="ar">أَنِسَ</span>, <span class="add">[<a href="#OunosN">see <span class="ar">أُنْسٌ</span> below</a>,]</span> <span class="auth">(AZ, AḤát,)</span> or it is a subst. from <span class="ar long">أَنِسَ بِهِ</span>, <span class="auth">(Mṣb,)</span> and <span class="ar">أُنْسَةٌ</span>; <span class="auth">(M;)</span> <span class="add">[but this also is probably a subst.;]</span> one says <span class="ar">أُنْسٌ</span> and <span class="ar">أُنْسَةٌ</span>, like as one says <span class="ar">بُعْدٌ</span> and <span class="ar">بُعْدَة</span>; <span class="auth">(Ḥam p. 768;)</span> <em>He was,</em> or <em>became, sociable, companionable, conversable, inclined to company or converse, friendly, amicable,</em> or <em>familiar, with him,</em> or <em>by means of him,</em> and <em>to him:</em> and <span class="add">[<span class="ar long">انس به</span>]</span> <em>he was,</em> or <em>became, cheered,</em> or <em>gladdened, by his company</em> or <em>converse,</em> or <em>by his,</em> or <em>its, presence;</em> or <em>cheerful, gay,</em> or <em>gladsome:</em> the inf. n. signifying the <em>contr. of</em> <span class="ar">وَحْشَةٌ</span>: <span class="auth">(T, Ṣ, A, Ḳ:)</span> or <em>he was,</em> or <em>became, at ease,</em> or <em>tranquil, with him:</em> <span class="auth">(M:)</span> or <em>his heart was,</em> or <em>became, at ease,</em> or <em>tranquil, with him; without shrinking,</em> or <em>aversion:</em> <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar long">استأنس↓ بِهِ</span></span>, <span class="auth">(Ṣ, M, A, Mṣb,)</span> and <span class="ar">إِلَيْهِ</span>, <span class="auth">(A,)</span> and<span class="arrow"><span class="ar long">تأنّس↓ بِهِ</span></span>, signify the same, <span class="auth">(Ṣ, M, Mṣb,)</span> i. e., the same as <span class="ar">أَنِسَ</span> <span class="auth">(M, A, Mṣb, TA)</span> and <span class="ar">أَنَسَ</span> <span class="auth">(M, Mṣb)</span> and <span class="ar">أُنُسَ</span>: <span class="auth">(M:)</span> <span class="ar long">أَنِسَ بِفُلَانٍ</span> is likewise explained as signifying <em>he delighted,</em> or <em>rejoiced, in such a one; he was happy,</em> or <em>pleased, with him:</em> <span class="auth">(IAạr, TA:)</span> <span class="add">[and<span class="arrow"><span class="ar">آنسهُ↓</span></span>, a form of frequent occurrence, inf. n. <span class="ar">مُؤَانَسَةٌ</span>, which occurs in this art. in the TA, also signifies <em>he was,</em> or <em>became, sociable,</em>, &amp;c., <em>with him;</em> like <span class="ar long">أَنِسَ بِهِ</span>, &amp;c.: it is also said in the TA that <span class="ar long">أَنِسَ بِهِ</span> and<span class="arrow"><span class="ar long">آنَسَ↓ بِهِ</span></span> are syn., meaning, app., like <span class="ar">استأنس</span> and <span class="ar long">تأنّس به</span>, and that <span class="ar">آنس</span> in this case is therefore of the measure <span class="ar">فَاعَلَ</span>; but this admits of some doubt, as it is said immediately after <span class="ar">آنسهُ</span> as meaning <a href="#wHX_4">the contr. of <span class="ar">أَوْحَشَهُ</span></a>:]</span> and<span class="arrow"><span class="ar">استأنس↓</span></span>, <span class="auth">(Ḳ, TA,)</span> said of a wild animal, <span class="auth">(TA,)</span> signifies <span class="add">[<em>he became familiar,</em> or <em>tame,</em> or <em>domesticated;</em> or]</span> <em>his wildness</em> (<span class="ar">تَوَحُّشُهُ</span>) <em>departed:</em> <span class="auth">(Ḳ, TA:)</span> you say <span class="ar long">إِذَا جَآءَ اللَّيْلُ ٱسْتَأْنَسَ كُلُّ وَحْشِىٍّ وَٱسْتَوْحَشَ كُلُّ إِنْسِىٌ</span> <span class="add">[<em>When the night comes, every wild animal becomes familiar with his kind, and every human being becomes shy of his kind,</em> i. e., of such thereof as he does not know, when meeting them in the dark]</span>. <span class="auth">(A, TA, Mṣb in art. <span class="ar">وحش</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ans_2">
				<h3 class="entry">2. ⇒ <span class="ar">أنّس</span></h3>
				<div class="sense" id="Ans_2_A1">
					<p><span class="ar">اَنَّسهُ</span> inf. n. <span class="ar">تَأْنِيسٌ</span>, <em>He rendered him familiar;</em> or <em>tame</em>. <span class="auth">(KL.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ans_2_B1">
					<p><a href="#Ans_4">See also 4</a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Ans_3">
				<h3 class="entry">3. ⇒ <span class="ar">آنس</span></h3>
				<div class="sense" id="Ans_3_A1">
					<p><a href="#Ans_1">see 1</a>, in two places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ans_4">
				<h3 class="entry">4. ⇒ <span class="ar">آنس</span></h3>
				<div class="sense" id="Ans_4_A1">
					<p><span class="ar">آنسهُ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">إِينَاسٌ</span>, <span class="auth">(Ṣ,)</span> <em>He behaved in a sociable, friendly,</em> or <em>familiar, manner with him;</em> <span class="add">[<a href="#Ans_1">see 1</a>, in two places;]</span> <em>he,</em> or <em>it, cheered him,</em> or <em>gladdened him, by his company or converse,</em> or <em>by his,</em> or <em>its, presence; he,</em> or <em>it, solaced,</em> or <em>consoled, him; contr. of</em> <span class="ar">أَوْحَشَهُ</span>; <span class="auth">(Ṣ,* Ḳ;)</span> as also<span class="arrow"><span class="ar">أنّسهُ↓</span></span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَأْنِيسٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> or <em>he,</em> or <em>it, rendered him easy, at ease,</em> or <em>tranquil;</em> as also<span class="arrow">↓</span> the latter verb, occurring in the following ex.: <span class="ar long">سَمَّاهَا بِٱلْمُؤْنِسَاتِ لِأَنَّهُنَّ يُؤَنِّسْنَهُ بِأَقْرَانِهِ فَيُؤَمِّنَّهُ أَوْيُحَسِّنَّ ظَنِّهُ</span> <span class="add">[<em>He has called them</em> <span class="auth">(referring to weapons)</span> <span class="ar">المؤنسات</span> <em>because they render him at ease with his adversaries, and secure, or cause him to have a good opinion</em> of his safety, and thus, cheer him, or solace him, by their presence]</span>. <span class="auth">(M: <span class="add">[and the like is said in the A.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ans_4_B1">
					<p><em>He perceived it;</em> syn. of the inf. n. <span class="ar">إِدْرَاكٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Ans_4_B2">
					<p><em>He saw him,</em> or <em>it,</em> <span class="auth">(Ṣ, M, A,* Mṣb, Ḳ,)</span> and <em>looked at him,</em> or <em>it;</em> <span class="auth">(M, TA;)</span> as also<span class="arrow"><span class="ar">أنّسهُ↓</span></span>, inf. n. <span class="ar">تَأْنِيسٌ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">استأنسهُ↓</span></span>: <span class="auth">(M:)</span> or <em>he saw it so that there was no doubt or uncertainty in it:</em> or <em>he saw it,</em> meaning a thing by the sight or presence of which he was cheered, gladdened, solaced, or consoled; <span class="ar">إِينَاسٌ</span> signifying <span class="ar long">إِبْصَارُ مَا يُؤْنَسُ بِهِ</span>: <span class="auth">(Bḍ in xx. 9:)</span> or <em>he saw it, not having before known it,</em> or <em>been acquainted with it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Ans_4_B3">
					<p><em>He heard it;</em> namely, a sound or voice. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Ans_4_B4">
					<p><em>He felt it; was sensible of it;</em> <span class="auth">(M, Ḳ, TA;)</span> <em>experienced it in himself;</em> <span class="auth">(TA;)</span> namely, <span class="add">[for instance,]</span> fright, or fear. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="Ans_4_B5">
					<p><em>He knew it:</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ:)</span> <em>he was acquainted with it:</em> <span class="auth">(TA:)</span> <em>he had certain knowledge of it; was certain of it.</em> <span class="auth">(M, TA.)</span> You say, <span class="ar long">آنَسْتُ مِنْهُ رُشْدًا</span> <span class="auth">(Ṣ, A, TA)</span> <em>I knew him to be characterized by</em> <span class="ar">رُشْد</span>, <span class="auth">(Ṣ, TA,)</span> i. e., <em>maturity of intel-lect, and rectitude of actions, and good management of affairs.</em> <span class="auth">(TA.)</span> <span class="add">[See Ḳur iv. 5.]</span> And it is said in a prov., <span class="ar long">بَعْدَ ٱطِّلَاعٍ إِينَاسٌ</span>, i. e. <em>After appearance</em> <span class="add">[<em>is knowledge,</em> or <em>certain knowledge</em>]</span>. <span class="auth">(Fr, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ans_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأنّس</span></h3>
				<div class="sense" id="Ans_5_A1">
					<p><span class="ar long">تأنّس بِهِ</span>: <a href="#Ans_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ans_5_B1">
					<p><span class="ar long">تأنّس البَازى</span> <em>The falcon looked, raising his head</em> <span class="auth">(M, A, Ḳ)</span> <em>and his eyes.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Ans_5_B2">
					<p><span class="ar long">تأنّس لَهُ</span>: <a href="#Ans_10">see 10</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Ans_10">
				<h3 class="entry">10. ⇒ <span class="ar">استأنس</span></h3>
				<div class="sense" id="Ans_10_A1">
					<p><span class="ar">استأنس</span>, and <span class="ar long">استأنس بِهِ</span> and <span class="ar">إِلَيْهِ</span>: <a href="#Ans_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Ans_10_B1">
					<p><span class="ar">استأنس</span> signifies also <em>He</em> <span class="auth">(a wild animal)</span> <em>became sensible of the presence or nearness of a human being.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="Ans_10_C1">
					<p><em>He looked;</em> as in the phrase <span class="ar long">اِذْهَبْ فَٱسْتَأْنِسْ هَلْ تَرَى أَحَدًا</span> <span class="add">[<em>Go thou and look if thou see any one</em>]</span>: <span class="auth">(Fr, TA:)</span> <em>he considered,</em> or <em>examined, endeavouring to obtain a clear knowledge of a thing;</em> <span class="auth">(Ḳ, TA;)</span> <em>and looked aside,</em> or <em>about, to ascertain if he could see any one:</em> <span class="auth">(TA:)</span> <em>he sought,</em> or <em>asked for, knowledge,</em> or <em>information; he inquired:</em> <span class="auth">(M, TA:)</span> and hence, <span class="auth">(Bḍ in xxiv. 27,)</span> <em>he asked permission.</em> <span class="auth">(Fr, Zj, Ḳ, TA, and Bḍ ubi suprà.)</span> It is said in the Ḳur <span class="add">[xxiv. 27]</span>, <span class="ar long">لَا تَدْخُلُوا بُيُوتًا غَيْرَ بُيُوتِكُمْ حَتَّى تَسْتَأْنِسُوا وَتُسَلِّمُوا</span> <span class="add">[<em>Enter ye not houses other than your own houses</em>]</span> <em>until ye inquire</em> whether its inhabitants desire that ye should enter or not; <span class="add">[<em>and salute:</em>]</span> <span class="auth">(M:)</span> or <span class="auth">(which is essentially the same, M)</span> <em>until ye ask permission:</em> <span class="auth">(Fr, Zj, M, TA:)</span> but Fr says that the sentence presents an inversion, and that the meaning is, <em>until ye salute, and ask if ye shall enter or not:</em> <span class="auth">(TA:)</span> I’Ab says that <span class="ar">تَستأنسوا</span> is a mistranscription; and he and Ubeí and Ibn-Mesʼood read <span class="ar">تَسْتَأْذِنُوا</span>, which signifies the same: <span class="auth">(Az, TA:)</span> <span class="add">[it is said that]</span> <span class="ar">استأنس</span> also signifies <em>he made a reiterated hemming, like a slight coughing;</em> <span class="add">[as a man does to notify his nearness;]</span> syn. <span class="ar">تَنَحْنَحَ</span>: and so some explain it in the text of the Ḳur quoted above. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="Ans_10_C2">
					<p><span class="ar long">استأنس لَهُ</span> <em>He listened to,</em> or <em>endeavoured</em> or <em>sought to hear, him,</em> or <em>it;</em> as also<span class="arrow"><span class="ar">تأنّس↓</span></span>. <span class="auth">(A.)</span> <span class="add">[See the Ḳur xxxiii. 53.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="Ans_10_D1">
					<p><span class="ar">استأنسهُ</span>: <a href="#Ans_4">see 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OunosN">
				<h3 class="entry"><span class="ar">أُنْسٌ</span></h3>
				<div class="sense" id="OunosN_A1">
					<p><span class="ar">أُنْسٌ</span> <em>Sociableness; companionableness; conversableness; inclination to company</em> or <em>converse; friendliness; amicableness; socialness; familiarity: cheerfulness; gayness; gladsomeness: contr. of</em> <span class="ar">وَحْشَةٌ</span>: <span class="auth">(T, Ṣ, A, Ḳ:)</span> <em>joy; gladness; happiness:</em> <span class="auth">(Ḥar p. 652:)</span> or <em>ease,</em> or <em>tranquillity:</em> <span class="auth">(M:)</span> or <em>ease,</em> or <em>tranquillity, of heart, and freedom from shrinking,</em> or <em>from aversion:</em> <span class="auth">(Mṣb:)</span> <a href="#Ans_1">an inf. n. of 1</a>, <span class="auth">(Ṣ, M,)</span> as are also<span class="arrow"><span class="ar">أَنَسٌ↓</span></span> and<span class="arrow"><span class="ar">أَنَسَةٌ↓</span></span> <span class="auth">(Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">إِنْسٌ↓</span></span>, <span class="auth">(M,)</span> but this is rare as signifying <a href="#waHoXapN">the contr. of <span class="ar">وَحْشَةٌ</span></a>: <span class="auth">(T, TA:)</span> or<span class="arrow"><span class="ar">إِنْسٌ↓</span></span> <a href="#Ans_1">is the inf. n. of <span class="ar long">أَنِسَ بِهِ</span></a>; but <span class="ar">أُنُسٌ</span> is not: <span class="auth">(AZ, AḤát, Mṣb, TA:)</span> this latter is a subst. from that verb <span class="add">[signifying as explained above]</span>: <span class="auth">(Mṣb:)</span> or only signifying <em>converse, and companionship,</em> or <em>familiarity, with women;</em> <span class="auth">(AZ, AḤát, TA;)</span> or <em>amatory conversation and conduct;</em> or the <em>talk of young men and young women:</em> <span class="auth">(Fr, TA:)</span> <span class="add">[but of all the forms above, <span class="ar">أُنْسٌ</span> is that which is most commonly used, at least in post-classical works, as signifying <a href="#waHoXapN">the contr. of <span class="ar">وَحْشَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أُنْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OunosN_A2">
					<p><span class="add">[Also † <em>Delight,</em> as meaning <em>a cause of delight,</em> or <em>thing that gives delight.</em>]</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا سَاكِنِى مَكَّةَ لَا زِلْتُمُ</span> *</div> 
						<div class="star">* <span class="ar long">أُنْسًا لَنَا إِنِّىَ لَمْ أَنْسَكُمْ</span> *</div> 
						<div class="star">* <span class="ar long">مَا فِيكُمُ عَيْبٌ سِوَى قَوْلِكُمْ</span> *</div> 
						<div class="star">* <span class="ar long">عِنْدَ اللِّقَا أَوْحَشَنَا أُنْسُكُمْ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>O inhabitants of Mekkeh, may ye not cease to be a delight to us: verily I have not forgotten you: there is in you no fault beside your saying, at meeting, Your sociableness,</em> or <em>companiableness,</em>, &amp;c., <em>has made us feel lonely and sad;</em> meaning, in your absence]</span>. <span class="auth">(TA in art. <span class="ar">وحش</span>.)</span> <span class="add">[<a href="#OaWoHaXa">See <span class="ar">أَوْحَشَ</span></a>. But this signification, though allowable as tropical, is perhaps post-classical.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أُنْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OunosN_A3">
					<p><span class="ar long">اِبْنُ أُنْس</span>: and <span class="ar long">فُلَانٌ ٱبْنُ أُنْسِ فُلَانٍ</span> and <span class="ar long">كَيْفَ ٱبْنُ أُنْسِكَ</span> and <span class="ar long">كَيْفَ تَرَى ٱبْنَ أُنْسِكَ</span>: <a href="#IinosN">see <span class="ar">إِنْسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinosN">
				<h3 class="entry"><span class="ar">إِنْسٌ</span></h3>
				<div class="sense" id="IinosN_A1">
					<p><span class="ar">إِنْسٌ</span>: <a href="#OunosN">see <span class="ar">أُنْسٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">إِنْسٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IinosN_B1">
					<p>‡ <em>A chosen, select, particular,</em> or <em>special, friend</em> or <em>companion;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also <span class="ar long">اِبْنُ إِنْسٍ</span> <span class="auth">(Ṣ, Ḳ,)</span> or<span class="arrow"><span class="ar long">اِبْنُ أُنْسٍ↓</span></span>. <span class="auth">(So in a copy of the A.)</span> You say, <span class="ar long">هٰذَا إِنْسِى</span>; <span class="auth">(Ṣ;)</span> and <span class="ar">إِنْسُكَ</span>, and <span class="ar long">ٱبْنُ إِنْسِكَ</span>; <span class="auth">(Ḳ;)</span> ‡ <em>This is my chosen,</em> or <em>particular, friend;</em> <span class="auth">(Ṣ;)</span> and <em>thy chosen,</em> or <em>particular, friend.</em> <span class="auth">(Ḳ.)</span> And <span class="ar long">فُلَانٌ ٱبْنُ إِنْسِ فُلَانٍ</span> <span class="auth">(Ṣ,)</span> or<span class="arrow"><span class="ar long">ابن أُنْسِ↓ فلان</span></span> <span class="auth">(A,)</span> <span class="pb" id="Page_0114"></span>‡ <em>Such a one is the chosen,</em> or <em>particular, friend of such a one.</em> <span class="auth">(Ṣ, A.)</span> One also says, <span class="ar long">كَيْفَ ٱبْنُ إِنْسِكَ</span> and<span class="arrow"><span class="ar">أُنْسِكَ↓</span></span>, <span class="auth">(Ṣ, M,)</span> or <span class="ar long">كَيْفَ تَرَى ٱبْنَ إِنْسِكَ</span> <span class="auth">(AZ, Fr, A)</span> and<span class="arrow"><span class="ar">أُنْسِكَ↓</span></span>, <span class="auth">(A,)</span> meaning himself, <span class="auth">(AZ, Fr, Ṣ, Ṣ TA,)</span> i. e., † <em>How dost thou regard me in my companionship with thee?</em> <span class="auth">(Ṣ:)</span> or the meaning is, ‡ <em>how dost thou find thyself?</em> <span class="auth">(A:)</span> or <em>how is thyself?</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">إِنْسٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="IinosN_C1">
					<p><em>Mankind;</em> <span class="auth">(Ṣ, M, A, Ḳ;)</span> the <em>opposite of</em> <span class="ar">جِنٌّ</span>; <span class="auth">(Mṣb;)</span> as also<span class="arrow"><span class="ar">أَنَسٌ↓</span></span>, <span class="auth">(Akh, Ṣ, TA,)</span> and<span class="arrow"><span class="ar">إِنْسَانٌ↓</span></span>; <span class="auth">(A, Ḳ;)</span> the last being a gen. n., <span class="auth">(Mṣb,)</span> but applied to the male <span class="auth">(Ṣ,* Mṣb)</span> and female, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and sing. and pl.: <span class="auth">(Mṣb:)</span> one is <span class="add">[also]</span> termed <span class="arrow"><span class="ar">إِنْسِىٌّ↓</span></span> and<span class="arrow"><span class="ar">أَنَسِىٌّ↓</span></span>; <span class="auth">(Ṣ, Ḳ;)</span> the former of which is a rel. n. from <span class="ar">إِنْسٌ</span>; <span class="auth">(M;)</span> <span class="add">[and the latter, from <span class="ar">أَنَسٌ</span>: the fem. of each is with <span class="ar">ة</span>:]</span> the vulgar apply to a woman, instead of <span class="arrow"><span class="ar">إِنْسَانٌ↓</span></span>, <span class="add">[which is the more approved,]</span> <span class="arrow"><span class="ar">إِنْسَانَةٌ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> this latter <span class="add">[accord. to some]</span> should not be used: <span class="auth">(Ṣ:)</span> but it is correct, though rare: it is said in the Ḳ to occur in poetry, but supposed to be post-classical: it occurs, however, in classical poetry, and has been transmitted by several authors: <span class="auth">(MF:)</span> the pl. <span class="auth">(of <span class="ar">إِنْسٌ</span>, M, TA)</span> is <span class="ar">آنَاسٌ</span>; <span class="auth">(M, Ḳ, TA;)</span> and <span class="auth">(of the same, Ḳ in art. <span class="ar">نوس</span>, or of<span class="arrow"><span class="ar">إِنْسَانٌ↓</span></span>, M)</span> <span class="ar">أُنَاسٌ</span>, <span class="auth">(M, Ḳ ubi suprà,)</span> with which <span class="ar">نَاسٌ</span> is syn., <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> being a contraction thereof; <span class="auth">(Sb, Ṣ, M, Mṣb;)</span> and <span class="auth">(of<span class="arrow"><span class="ar">إِنْسِىٌّ↓</span></span>, Ṣ, M, or<span class="arrow"><span class="ar">أَنَسِىٌّ↓</span></span>, Ṣ, or of<span class="arrow"><span class="ar">إِنْسَانٌ↓</span></span>, Lḥ, Ṣ, M, Mṣb)</span> <span class="ar">أَنَاسِىٌّ</span>, <span class="auth">(Lḥ, Ṣ, M, Mṣb, Ḳ,)</span> like as <span class="ar">كَرَاسِىُّ</span> <a href="#kurosieBN">is pl. of <span class="ar">كُرْسِىٌّ</span></a>, or like as <span class="ar">سَرَاحينُ</span> <a href="#sirHaAnN">is pl. of <span class="ar">سِرحَانٌ</span></a>, but <span class="ar">ى</span> being substituted for <span class="ar">ن</span>, <span class="auth">(M, TA,)</span> after the same manner as they say <span class="ar">أَرَانٍ</span> for <span class="ar">أَرَانِبُ</span>; <span class="auth">(Fr, TA;)</span> and <span class="ar">أَنَاسٍ</span>, <span class="auth">(Lḥ, M,)</span> in the accus. case <span class="ar">أَنَاسِىَ</span>, as the word is read in the Ḳur xxv. 51, by Ks, <span class="auth">(TA,)</span> and by Yaḥyà Ibn-El-Hárith, <span class="auth">(Ḳ, TA,)</span> dropping the <span class="ar">ى</span> between the second and last radical letters, <span class="add">[for, with some others, it seems, they held the word to be derived from the root <span class="ar">نسى</span>,]</span> <span class="auth">(TA,)</span> and <span class="ar">أَنَاسِيَةٌ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> in which the <span class="ar">ة</span> is a substitute for one of the two yás in <span class="ar">أَنَاسِىُّ</span>, <a href="#IinosaAnN">a pl. of <span class="ar">إِنْسَانٌ</span></a>; or, accord. to Mbr, <span class="ar">أَنَاسِيَةٌ</span> <a href="#IinosieBN">is pl. of <span class="ar">إِنْسِىٌّ</span></a>, <span class="add">[in the TA, of <span class="ar">إِنْسِيَّةٌ</span>, which I regard as a mistranscription,]</span> and is like <span class="ar">زَنَادَقَةٌ</span> for <span class="ar">زَنَادِيقُ</span>, and <span class="ar">فَرَازِتَةٌ</span> for <span class="ar">فَرَازِينُ</span>; <span class="auth">(M, TA;)</span> and you say also <span class="ar">إِنْسَيُّونَ</span>. <span class="auth">(TA.)</span> <span class="ar">نَاسٌ</span> is masc., as in the Ḳur ii. 19, &amp;c.; and sometimes fem., as meaning <em>A tribe,</em> or <em>a body of men,</em> <span class="ar">قَبِيلَةٌ</span>, or <span class="ar">طَائِفَةٌ</span>; as in the phrase, mentioned by Th, <span class="ar long">جَآءَتْكَ النَّاسُ</span>, meaning, <em>The tribe,</em> or <em>portion of people</em> (<span class="ar">قِطْعَة</span>), <em>came to thee.</em> <span class="auth">(M, TA.)</span> <span class="arrow"><span class="ar">بَنُوالإِنْسَانِ↓</span></span> means <em>The sons of Adam.</em> <span class="auth">(M.)</span> And <span class="ar long">النَّاسُ النَّاسُ</span>, an expression mentioned by Sb, means, <em>Men in every place and in every state are men:</em> a poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">بِلَادٌ بَهَا كُنَّا وَكُنَّا نُحِبُّهَا</span> *</div> 
						<div class="star">* <span class="ar long">إِذِ النَّاسُ نَاسٌ وَالبِلَادُ بِلَادُ</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>A country in which we were, and which we used to love,</em>]</span> <em>since the men were ingenuous men, and the country was a fruitful country.</em> <span class="auth">(M.)</span> The following trad., <span class="ar long">لَوْ أَطَاعَ ٱللّٰهُ النَّاسَ فِى النَّاسِ لَمْ يَكُنْ نَاسٌ</span> <em>If God complied with the prayer of men with respect to men there would be no men,</em> is said to mean, that men love to have male children born to them, and not females, and if there were no females, or if the females were not, men would cease to be. <span class="auth">(TA.)</span> It is related that a party of the jinn, or genii, came to a company of men, and asked permission to go in to them, whereupon the latter said to them, Who are ye? and they answered, <span class="ar long">نَاسٌ مِنَ الجنِّ</span> <span class="add">[<em>A people of the jinn</em>]</span>, making their answer to accord. with common usage; for it is customary for men, when it is said to them, Who are ye? to answer, <span class="ar long">نَاسٌ مِنْ بَنِى فُلَانٍ</span> <span class="add">[<em>Men of the sons of such a one</em>]</span>. <span class="auth">(IJ, M, L: but in the L, for <span class="ar">ناس</span>, in both instances, we find <span class="ar">أُنَاسٌ</span>.)</span> <span class="add">[<a href="#naAsN">See also <span class="ar">نَاسٌ</span></a> <a href="index.php?data=25_n/291_nws">in art. <span class="ar">نوس</span></a>.]</span> Respecting the derivation of <span class="arrow"><span class="ar">إِنْسَانٌ↓</span></span>, authors differ, though they agree that the final <span class="ar">ن</span> is augmentative: the Basrees say that it is from <span class="ar">الإِنْسُ</span>; <span class="auth">(Mṣb;)</span> and its measure is <span class="ar">فِعْلَانٌ</span>; <span class="auth">(Ṣ, Mṣb;)</span> but an addition, of <span class="ar">ى</span>, is made in its dim., <span class="add">[which is <span class="ar">أُنَيْسِيَانٌ</span>,]</span> like as an addition is made in <span class="ar">رُوَيْجِلٌ</span>, <a href="#rajulN">the dim. of <span class="ar">رَجُلٌ</span></a>: <span class="auth">(Ṣ:)</span> <span class="add">[but it should be observed that <span class="ar">رُوَيْجِلٌ</span> is more probably <a href="#raAjilN">the dim. of <span class="ar">رَاجِلٌ</span></a>:]</span> some say that it is from <span class="ar">إِينَاسٌ</span>, signifying “perception,” or “sight,” and “knowledge,” and “sensation;” because man uses these faculties: <span class="auth">(TA:)</span> and Moḥammad Ibn-ʼArafeh El-Wásitee says that men are called <span class="ar">إِنسِيُّونِ</span> because they are seen (<span class="ar">يُؤْنَسُونَ</span>, i. e. <span class="ar">يُرَوْنَ</span>), and that the jinn are called <span class="ar">جِنّ</span> because they are <span class="add">[ordinarily]</span> concealed (<span class="ar">مُجْتَنُّونَ</span>, i. e. <span class="ar">مُتَوَارُونَ</span>,) from the sight of men: <span class="auth">(TA:)</span> <span class="add">[it is said in the B, as cited in the TA, that the form <span class="ar">أَنِسَان</span> is also used for <span class="ar">إِنْسَانٌ</span>; as though it were a dual, meaning “a double associate,” i. e., an associate with the jinn and with his own kind; for it is added, <span class="ar long">أَنِسَ بِٱلْآْجِنِّ وَأَنِسَ بِٱلْآْخَلْقِ</span>:]</span> some derive the word from <span class="ar">النَّوْسُ</span>, signifying “motion:” <span class="auth">(TA:)</span> some <span class="auth">(namely, the Koofees, Mṣb)</span> say that it is originally <span class="ar">إِنسِيَانٌ</span>, <span class="auth">(Ṣ, Mṣb, TA,)</span> of the measure <span class="ar">إِفْعِلَانٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> from <span class="ar">النِّسْيَانُ</span> <span class="add">[“forgetfulness”]</span>, <span class="auth">(Mṣb,)</span> and contracted to make it more easy of pronunciation, because of its being so often used; <span class="auth">(Ṣ;)</span> but it is restored to its original in forming the dim., <span class="auth">(Ṣ, Mṣb,)</span> which is <span class="ar">أُنَيْسِيَانٌ</span>: <span class="auth">(Mṣb, TA:)</span> this form of the dim., they say, shows the original form of the word which is its source; <span class="auth">(TA;)</span> and they adduce as an indication of its derivation the saying of I’Ab, <span class="ar long">إِنَّمَا سُمِّيَ إِنْسَانًا لِأَنَّهُ عُهِدَ إِلَيْهِ فَنَسِىَ</span> <span class="add">[<em>He</em> <span class="auth">(meaning the first man)</span> <em>was only named</em> <span class="ar">انسان</span> <em>because he was commanded and he forgot</em>]</span>: <span class="auth">(Ṣ, TA:)</span> <span class="add">[in like manner,]</span> it is said that <span class="ar">النَّاسُ</span> is originally <span class="ar">النَّاسِى</span>; the former of these, accord. to one reading, and the latter accord. to another, occurs in the Ḳur ii. 195; the latter referring to Adam, and to the words of the Ḳur in xx. 114: <span class="auth">(TA:)</span> but Az holds that <span class="ar">إِنْسِيَانٌ</span> is of the measure <span class="ar">فِعْلِيَانٌ</span>, from <span class="ar">الإِنْسُ</span>, and similar to <span class="ar">خِرْصِيَانٌ</span>. <span class="auth">(L, TA.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanasN">
				<h3 class="entry"><span class="ar">أَنَسٌ</span></h3>
				<div class="sense" id="OanasN_A1">
					<p><span class="ar">أَنَسٌ</span> <em>i. q.</em> <span class="ar">أُنْسٌ</span>, q. v. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنَسٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OanasN_B1">
					<p>Also <em>i. q.</em> <span class="ar">إِنْسٌ</span>, q. v. <span class="auth">(Akh, Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنَسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OanasN_B2">
					<p>Also <em>A numerous company of men;</em> <span class="auth">(Ḳ,* TA;)</span> <em>many men.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنَسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OanasN_B3">
					<p><em>A tribe</em> (<span class="ar">حَىُّ</span>) <em>staying, residing, dwelling,</em> or <em>abiding:</em> <span class="auth">(Ṣ, Ḳ:)</span> the <em>people of a place of alighting or abode:</em> <span class="auth">(M, TA: <span class="add">[but in the latter, in one place, said to be <span class="ar">إِنْسٌ</span>, with kesr; though a verse cited in both, as an ex., shows it to be <span class="ar">أَنَسٌ</span>:]</span>)</span> the <em>inhabitants of a house:</em> <span class="auth">(AA, TA:)</span> pl. <span class="auth">(of the word in the first sense, of these three, TA, and in the second, M, TA)</span> <span class="ar">آنَاسٌ</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنَسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="OanasN_B4">
					<p><em>One with whom a person is sociable.</em> <span class="auth">(Ḥam p. 136.)</span> You say also, <span class="ar long">هُمْ أَنَسُ فُلَانٍ</span> <em>They are they with whom such a one is sociable</em> (<span class="ar long">اَلَّذِينَ يَسْتَأْنِسُ إِلَيْهِمْ</span>). <span class="auth">(Lḥ, M.)</span> And <span class="ar long">هُوَ أَنَسُ فُلَانٍ</span> <em>He is much accustomed to the serving of him.</em> <span class="auth">(Ḥar p. 472.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanasapN">
				<h3 class="entry"><span class="ar">أَنَسَةٌ</span></h3>
				<div class="sense" id="OanasapN_A1">
					<p><span class="ar">أَنَسَةٌ</span> <em>i. q.</em> <span class="ar">أُنْسٌ</span>, q. v. <span class="auth">(Ṣ, Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinosieBN">
				<h3 class="entry"><span class="ar">إِنْسِىٌّ</span></h3>
				<div class="sense" id="IinosieBN_A1">
					<p><span class="ar">إِنْسِىٌّ</span> <em>Of,</em> or <em>belonging to, mankind; human;</em> <span class="add">[as also<span class="arrow"><span class="ar">أَنَسِىٌّ↓</span></span>, and<span class="arrow"><span class="ar">إِنْسَانِىُّ↓</span></span>;]</span> a rel. n. from <span class="ar">إِنْسٌ</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">إِنْسِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IinosieBN_A2">
					<p><em>A human being; a man;</em> as also<span class="arrow"><span class="ar">أَنَسِىٌّ↓</span></span>, <span class="auth">(Ṣ, Ḳ,)</span> and<span class="arrow"><span class="ar">إِنْسَانٌ↓</span></span>. <span class="auth">(Ṣ, A, Mṣb, Ḳ.)</span> <a href="#IinosN">See <span class="ar">إِنْسٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">إِنْسِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IinosieBN_A3">
					<p><span class="add">[<em>Domestic, as opposed to wild.</em> Ex.]</span> <span class="ar long">حُمُرٌ إِنْسِيَّةٌ</span> <em>Domestic asses; asses that are accustomed to the houses:</em> commonly known as written with kesr to the <span class="ar">أُنْسِيَّةٌ</span>: but in the book of Aboo-Moosà is an indication of its being with damm to the <span class="ar">ء</span> <span class="add">[<span class="ar">أَنَسِيَّةٌ</span>]</span>: and as some relate a trad. in which it occurs, <span class="ar">أَنَسِيَّةٌ</span>, which is said to be of no account. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">إِنْسِىٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IinosieBN_A4">
					<p>The <em>left</em> side <span class="auth">(AZ, Ṣ, M, Mṣb, Ḳ)</span> of an animal, <span class="auth">(Mṣb,)</span> or of a beast and of a man, <span class="auth">(M,)</span> or of anything: <span class="auth">(AZ, Ṣ, Ḳ:)</span> or the <em>right</em> side: <span class="auth">(Aṣ, Ṣ:)</span> <span class="add">[but the latter seems to be a mistake:]</span> Az says that Lth has well explained this term and its contrary <span class="ar">وَحْشِىٌّ</span>, saying that the latter is the right side of every beast; and the former, the <em>left</em> side; agreeably with those of the first authority in sound learning; and <span class="add">[that]</span> it is related of El-Mufaddal and Aṣ and AO, that all of them asserted the latter to be, of every animal except man, <span class="add">[the “far” side, or “off” side,]</span> the side on which it is not milked nor mounted; and the former, <span class="add">[the <em>near</em> side,]</span> the side <em>on which the rider mounts and the milker milks:</em> <span class="auth">(TA in art. <span class="ar">وحش</span>:)</span> <span class="add">[and the like is said, as a citation from Az, in the Mṣb in art. <span class="ar">وحش</span>: but after this, in my copy of the Mṣb, there seems to be an omission; for it is immediately added, “But Az says, This is not correct in my opinion:”]</span> it is said that everything that is frightened declines to its right side; for the beast is approached to be mounted and milked on the left side, and, fearing thereat, runs away from the place of fear, which is the left side, to the place of safety, which is the right side: <span class="auth">(Ṣ,* IAmb in Mṣb; both in art. <span class="ar">وحش</span>:)</span> <span class="add">[accordingly,]</span> Er-Rá'ee describes a beast as declining to the side termed <span class="ar">الوحشى</span> because frightened on the left side: <span class="auth">(Ṣ and Mṣb in art. <span class="ar">وحش</span>:)</span> and 'Antarah alludes to one's shrinking with the side so termed from the whip, <span class="add">[which he likens to a cat,]</span> because the whip of the rider is in his right hand: <span class="auth">(Ṣ in art. <span class="ar">وحش</span>:)</span> but Abu-l-ʼAbbás says that people differ respecting these two terms when relating to a man: that, accord. to some, they mean the same in this case as in the cases of horses and other beasts of carriage, and of camels: <span class="pb" id="Page_0115"></span>but some say, that in the case of a man, the latter term means the part next the shoulder-blade; and the former, the <em>part next the arm-pit.</em> <span class="auth">(TA in art.<span class="ar">وحش</span>.)</span> Of every double member of a man, as the upper half of each arm, and the two fore arms, and the two feet, it means <em>That</em> <span class="add">[side]</span> <em>which is towards the man;</em> and <span class="ar">وحشىّ</span>, that which turns away from him: <span class="auth">(Aṣ, Ṣ:)</span> or, of the foot, the former means <em>that</em> <span class="add">[side]</span> <em>which is towards the other foot;</em> <span class="add">[i. e., the <em>inner</em> side;]</span> and the latter, the contrary of the former. <span class="auth">(TA in art. <span class="ar">وحش</span>.)</span> Of a bow, <span class="auth">(Ṣ, M, Ḳ,)</span> or of a Persian bow, <span class="auth">(TA in art. <span class="ar">وحش</span>,)</span> <em>That</em> <span class="add">[side]</span> <em>which is towards thee;</em> <span class="auth">(Ṣ, Ḳ;)</span> and <span class="ar">وحشىّ</span>, the back: <span class="auth">(Ṣ and Ḳ in art. <span class="ar">وحش</span>:)</span> or the former, <em>that</em> <span class="add">[side]</span> <em>which is next to the archer;</em> and the latter, that which is next to the animal shot at: <span class="auth">(M, TA:)</span> or of a bow, whether Persian or not is not said, <span class="add">[the former means the side <em>against which the arrow lies;</em> and]</span> the latter, the side against which the arrow does not lie. <span class="auth">(TA in art. <span class="ar">وحش</span>.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OanasieBN">
				<h3 class="entry"><span class="ar">أَنَسِىٌّ</span></h3>
				<div class="sense" id="OanasieBN_A1">
					<p><span class="ar">أَنَسِىٌّ</span>: <a href="#IinosN">see <span class="ar">إِنْسٌ</span></a> <a href="#IinosieBN">and <span class="ar">إِنْسِىٌّ</span></a>, each in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinosaAnN">
				<h3 class="entry"><span class="ar">إِنْسَانٌ</span> / <span class="ar">إنْسَانَةٌ</span></h3>
				<div class="sense" id="IinosaAnN_A1">
					<p><span class="ar">إِنْسَانٌ</span> and <span class="ar">إنْسَانَةٌ</span>: <a href="#IinosN">see <span class="ar">إِنْسٌ</span></a>, passim; <a href="#IinosieBN">and <span class="ar">إِنْسِىٌّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">إِنْسَانٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IinosaAnN_A2">
					<p><span class="ar long">إِنْسَانُ العَيْنِ</span> ‡ <em>The image that is seen</em> <span class="add">[<em>reflected</em>]</span> <em>in the black of the eye;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>what is seen in the eye, like as is seen in a mirror, when a thing faces it:</em> <span class="auth">(Zj in his “Khalk el-Insán:”)</span> or <em>the pupil,</em> or <em>apple,</em> (<span class="ar">نَاظِر</span>,) <em>of the eye:</em> <span class="auth">(M:)</span> or <em>the black</em> (<span class="ar">حَدَقَة</span>) <em>of the eye:</em> <span class="auth">(Mṣb:)</span> pl. <span class="ar">أَنَاسِىُّ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> but not <span class="ar">أُنَاسٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IinosaAnieBN">
				<h3 class="entry"><span class="ar">إِنْسَانِىٌّ</span></h3>
				<div class="sense" id="IinosaAnieBN_A1">
					<p><span class="ar">إِنْسَانِىٌّ</span>: <a href="#IinosieBN">see <span class="ar">إِنْسِىٌّ</span></a>, first signification.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IinosaAniyBapN">
				<h3 class="entry"><span class="add">[<span class="ar">إِنْسَانِيَّةٌ</span>]</span></h3>
				<div class="sense" id="IinosaAniyBapN_A1">
					<p><span class="add">[<span class="ar">إِنْسَانِيَّةٌ</span> <em>Human nature; humanity;</em> as also <span class="ar">نَاسُوتٌ</span>, which is probably post-classical, <a href="#laAhuwtN">opposed to <span class="ar">لَاهُوتٌ</span>, q. v.</a>, <a href="index.php?data=23_l/197_lyh">in art. <span class="ar">ليه</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OanuwsN">
				<h3 class="entry"><span class="ar">أَنُوسٌ</span></h3>
				<div class="sense" id="OanuwsN_A1">
					<p><span class="ar">أَنُوسٌ</span> A <em>tame,</em> or <em>gentle,</em> dog; <em>contr. of</em> <span class="ar">عَقُورٌ</span>: pl. <span class="ar">أُنُسٌ</span>. <span class="auth">(M, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنُوسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OanuwsN_A2">
					<p><a href="#AnisapN">See also <span class="ar">آنِسَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaniysN">
				<h3 class="entry"><span class="ar">أَنِيسٌ</span></h3>
				<div class="sense" id="OaniysN_A1">
					<p><span class="ar">أَنِيسٌ</span> <em>i. q.</em><span class="arrow"><span class="ar">مُؤَانِسٌ↓</span></span> <span class="add">[generally used as an epithet in which the quality of a subst. is predominant, meaning, <em>A sociable, companionable, conversable, friendly,</em> or <em>familiar, person; a cheerful companion</em>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> <em>one with whom one is sociable, companionable, conversable, friendly, familiar,</em> or <em>cheerful:</em> <span class="auth">(Ḳ:)</span> <em>a person,</em> <span class="auth">(A,)</span> or <em>anything,</em> <span class="auth">(Ṣ,)</span> <em>by whose company,</em> or <em>converse,</em> or <em>presence, one is cheered, gladdened, solaced,</em> or <em>consoled.</em> <span class="auth">(Ṣ, A.)</span> You say, <span class="ar long">مَا بِالدَّارِ أنِيسْ</span> <span class="auth">(or, as in some copies of the Ḳ, <span class="ar long">مِنْ أَنِيسٍ</span>,)</span> <em>There is not in the house any one by whose company,</em> or <em>converse,</em> or <em>presence, one is cheered, gladdened, solaced,</em> or <em>consoled:</em> <span class="auth">(A:)</span> or <em>there is not in the house any one.</em> <span class="auth">(Ṣ, M, Ḳ.)</span> <span class="add">[<a href="#AnisapN">See also <span class="ar">آنِسَةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنِيسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaniysN_A2">
					<p><span class="ar">الأَنِيسُ</span> † <em>The domestic cock;</em> <span class="auth">(AA, Ḳ;)</span> also called <span class="ar">الشُّقَرُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">أَنِيسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="OaniysN_A3">
					<p><span class="ar">الأَنِيسَةُ</span> ‡ <em>The fire;</em> <span class="auth">(IAạr, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">مَأْنُوسَةُ↓</span></span>, <span class="add">[imperfectly decl., being a proper name and of the fem. gender,]</span> <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">المَأْنُوسَةُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> of which <span class="add">[says ISd]</span> I know no verb: <span class="auth">(M:)</span> because, when a man sees it in the night, he becomes cheerful and tranquil thereat, even if it be in a desert land. <span class="auth">(TA.)</span> You say, <span class="ar long">بَاتَتِ الأَنِيسَةُ أَنِيسَتَهُ</span> ‡ <span class="add">[<em>The fire was during night his cheerful companion,</em> or <em>his cheerer by its presence</em>]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Mnasu">
				<h3 class="entry"><span class="ar">آنَسُ</span></h3>
				<div class="sense" id="Mnasu_A1">
					<p><span class="ar">آنَسُ</span> <span class="add">[<em>More,</em> and <em>most, sociable,</em>, &amp;c.]</span>. Hence, <span class="ar long">آنَسُ مِنَ الحُمَّى</span> † <span class="add">[<em>A closer companion than fever</em>]</span>: a saying of the Arabs, meaning, that fever scarcely ever quits the patient; as though it were sociable with him. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="MnisapN">
				<h3 class="entry"><span class="ar">آنِسَةٌ</span></h3>
				<div class="sense" id="MnisapN_A1">
					<p><span class="ar long">جَارِيَةٌ آنِسَةٌ</span> <em>A girl of cheerful mind,</em> <span class="auth">(Lth, A, Ḳ, TA,)</span> <em>whose nearness,</em> and <em>conversation,</em> or <em>discourse, thou lovest,</em> <span class="auth">(Lth, TA,)</span> or <em>whose conversation,</em> or <em>discourse, and nearness, are loved:</em> <span class="auth">(A:)</span> or <em>a girl of pleasant conversation</em> or <em>discourse;</em> as also<span class="arrow"><span class="ar">أَنُوسٌ↓</span></span>: <span class="auth">(M:)</span> and <span class="ar long">آنِسَةُ الحَدِيثِ</span> <em>who becomes sociable, companionable, conversable, friendly, familiar,</em> or <em>cheerful, by means of thy conversation</em> or <em>discourse:</em> it does not mean who cheers thee <span class="add">[by conversation or discourse]</span>: <span class="auth">(Ṣ:)</span> pl. <span class="ar">أَوَانِسُ</span> <span class="auth">(Lth, A, TA)</span> and <span class="ar">آنِسَاتٌ</span>: <span class="auth">(Lth, TA:)</span> and <a href="#OanuwsN">the pl. of <span class="ar">أَنُوسٌ</span></a> is <span class="ar">أُنُسٌ</span>. <span class="auth">(M, TA.)</span> <span class="add">[<a href="#OaniysN">See also <span class="ar">أَنِيسٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOonasN">
				<h3 class="entry"><span class="ar">مَأْنَسٌ</span></h3>
				<div class="sense" id="maOonasN_A1">
					<p><span class="ar">مَأْنَسٌ</span> <span class="add">[app. <em>i. q.</em> <span class="ar long">مَكَانٌ مَأْنُوسٌ</span>, q. v.]</span> <span class="auth">(A.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWonisN">
				<h3 class="entry"><span class="ar">مُؤْنِسٌ</span></h3>
				<div class="sense" id="muWonisN_A1">
					<p><span class="ar">مُؤْنِسٌ</span> † A name which the Arabs, <span class="auth">(Ṣ, M,)</span> and the ancients, <span class="auth">(M,)</span> used to give to <em>Thursday;</em> <span class="auth">(Ṣ, M;)</span> because on that day they used to incline to places of pleasure; and ʼAlee is related to have said that God created <em>Paradise</em> on Thursday, and named it thus. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">مُؤْنِسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="muWonisN_A2">
					<p><span class="ar">المُؤْنِسَاتُ</span> ‡ <em>Weapons:</em> <span class="auth">(M, A:)</span> or <em>all weapons:</em> <span class="auth">(Ḳ:)</span> or <em>the spear and the</em> <span class="ar">مِغْفَر</span> <em>and the</em> <span class="ar">تِجْغَاف</span> <em>and the</em> <span class="ar">تَسْبِغَة</span> <em>and the</em> <span class="ar">تُرْس</span> <span class="auth">(Fr, Ḳ)</span> <em>and the sword and the helmet:</em> <span class="auth">(IḲṭṭ, TA:)</span> so called because they render their possessor at ease with his adversaries, and secure, or cause him to have a good opinion <span class="add">[of his safety, and thus, cheer him, or solace him, by their presence: <a href="#Ans_4">see 4</a>]</span>. <span class="auth">(M, A.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">مُؤْنِسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="muWonisN_A3">
					<p><a href="#baAbuwnajN">See also <span class="ar">بَابُونَجٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOonuwsN">
				<h3 class="entry"><span class="ar">مَأْنُوسٌ</span></h3>
				<div class="sense" id="maOonuwsN_A1">
					<p><span class="ar long">مَكَانٌ مَأْنُوسٌ</span>, <span class="auth">(M,)</span> and <span class="ar long">مَحَلٌّ مَأْنُوسٌ</span>, <span class="auth">(A,)</span> <span class="add">[<em>A place,</em> and]</span> <em>a place of alighting</em> or <em>abode, in which is</em> <span class="ar">أُنْس</span> <span class="add">[i. e. <em>sociableness,</em>, &amp;c.]</span>: <span class="auth">(A:)</span> <span class="ar">مأنوس</span> is a kind of possessive noun, because they did not say <span class="ar long">أَنَسْتُ المَكَانَ</span>, nor <span class="ar">أَنِسْتُهُ</span>. <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">انس</span> - Entry: <span class="ar">مَأْنُوسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOonuwsN_A2">
					<p><span class="ar">مَأْنُوسَةُ</span> and <span class="ar">المَأْنُوسَةُ</span>: <a href="#OaniysN">see <span class="ar">أَنِيسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="muWaAnisN">
				<h3 class="entry"><span class="ar">مُؤَانِسٌ</span></h3>
				<div class="sense" id="muWaAnisN_A1">
					<p><span class="ar">مُؤَانِسٌ</span>: <a href="#OaniysN">see <span class="ar">أَنِيسٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmutaOanBisu">
				<h3 class="entry"><span class="ar">المُتَأَنِّسُ</span></h3>
				<div class="sense" id="AlmutaOanBisu_A1">
					<p><span class="ar">المُتَأَنِّسُ</span> † <em>The lion;</em> <span class="auth">(TṢ, Ḳ;)</span> as also<span class="arrow"><span class="ar">المُسْتَأْنِسُ↓</span></span>: <span class="auth">(TṢ, TA:)</span> or <em>he that is sensible of the prey from afar,</em> <span class="auth">(Ḳ, TA,)</span> <em>and examines and looks about for it.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AlmusotaOonisu">
				<h3 class="entry"><span class="ar">المُسْتَأْنِسُ</span></h3>
				<div class="sense" id="AlmusotaOonisu_A1">
					<p><span class="ar">المُسْتَأْنِسُ</span>: <a href="#AlmutaOanBisu">see what next precedes</a>.</p>	
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0113.pdf" target="pdf">
							<span>Lanes Lexicon Page 113</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0114.pdf" target="pdf">
							<span>Lanes Lexicon Page 114</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0115.pdf" target="pdf">
							<span>Lanes Lexicon Page 115</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
