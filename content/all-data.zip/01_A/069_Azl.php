<article class="root" id="Root_Azl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/068_Azq">ازق</a></span>
				<span class="ar">ازل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/070_Azm">ازم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="Azl_1">
				<h3 class="entry">1. ⇒ <span class="ar">أزل</span></h3>
				<div class="sense" id="Azl_1_A1">
					<p><span class="ar">أَزَلَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْزِلُ</span>}</span></add>, inf. n. <span class="ar">أَزْلٌ</span>, <span class="auth">(Ṣ,)</span> <em>He</em> <span class="auth">(a man)</span> <em>became in a state of straitness,</em> or <em>narrowness, and suffering from dearth</em> or <em>drought</em> or <em>sterility.</em> <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[See also the pass. form of the verb here following; <a href="#Azl_5">and see 5</a>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Azl_1_B1">
					<p><span class="ar">أَزَلَهُ</span>, aor. as above, <span class="auth">(Ḳ,)</span> and so the inf. n., <span class="auth">(TA,)</span> <em>He confined, restricted, restrained, withheld, debarred, hindered,</em> or <em>prevented, him;</em> <span class="auth">(Ḳ,* TA;)</span> and <em>straitened him; in consequence of distress,</em> or <em>adversity,</em> and <em>fear.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="Azl_1_B2">
					<p><em>He shortened his</em> <span class="auth">(a horse's)</span> <em>rope,</em> <span class="add">[or <em>tether,</em>]</span> <em>and then left him to pasture at pleasure</em> <span class="auth">(Lth, Ḳ, <span class="add">[in the CK, <span class="ar">شَيَّبَهُ</span> is put for <span class="ar">سَيَّبَهُ</span>,]</span>)</span> <em>in the place of pasturage.</em> <span class="auth">(Lth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="Azl_1_B3">
					<p><span class="ar long">أَزَلُوا مَالَهُمْ</span>, <span class="auth">(Ṣ,)</span> or <span class="ar">أَمْوَالَهُمْ</span>, <span class="auth">(Ḳ,)</span> aor. as above, <span class="auth">(Ṣ,)</span> <em>They confined, restricted,</em> or <em>debarred, their cattle from the place of pasturage,</em> <span class="auth">(Ṣ,)</span> or <em>did not take,</em> or <em>send, them forth thereto,</em> <span class="auth">(Ḳ,)</span> <em>in consequence of fear,</em> <span class="auth">(Ṣ, Ḳ,)</span> or <em>dearth</em> or <em>drought</em> or <em>sterility.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="Azl_1_B4">
					<p>It is said in a trad. respecting Ed-Dejjál, and his besieging the Muslims in Beytel-Makdis, <span class="add">[or Jerusalem,]</span> <span class="ar long">فَيُؤْزَلُونَ أَزْلًا شَدِيدًا</span> <em>And they will be straitened with a vehement straitening.</em> <span class="auth">(TA.)</span> And <span class="ar long">أُزِلَ النَّاسُ</span> signifies <em>The people suffered,</em> or <em>were afflicted with, drought,</em> or <em>want of rain.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azl_4">
				<h3 class="entry">4. ⇒ <span class="ar">آزل</span></h3>
				<div class="sense" id="Azl_4_A1">
					<p><span class="ar long">آزَلَتِ السَّنَةُ</span> <em>The year became severe, distressful, calamitous,</em> or <em>adverse.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="Azl_4_B1">
					<p><span class="ar long">آزَلَهُمُ ٱللّٰهُ</span> <em>God afflicted them with drought,</em> or <em>want of rain.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Azl_5">
				<h3 class="entry">5. ⇒ <span class="ar">تأزّل</span></h3>
				<div class="sense" id="Azl_5_A1">
					<p><span class="ar">تأزّل</span> <em>It</em> <span class="auth">(a man's bosom or mind)</span> <em>became strait,</em> or <em>straitened;</em> <span class="auth">(Fr, Ṣ, Ḳ;)</span> as also <span class="ar">تأزّق</span>. <span class="auth">(Fr, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazolN">
				<span class="pb" id="Page_0054"></span>
				<h3 class="entry"><span class="ar">أَزْلٌ</span></h3>
				<div class="sense" id="OazolN_A1">
					<p><span class="ar">أَزْلٌ</span> <em>Straitness; distress; difficulty;</em> <span class="auth">(Ṣ,* Ḳ;)</span> and <em>drought,</em> or <em>want of rain.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: <span class="ar">أَزْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OazolN_A2">
					<p><em>Vehemence of might,</em> or <em>of strength, in war,</em> or <em>fight; of courage, valour,</em> or <em>prowess:</em> or <em>of war,</em> or <em>fight:</em> or <em>of fear:</em> or <em>of punishment:</em> syn. <span class="ar long">شِدَّةُ بَأْسٍ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: <span class="ar">أَزْلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OazolN_B1">
					<p>It is also used as an epithet, meaning <em>Strait; narrow; confined.</em> <span class="auth">(Ḥam p. 339.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IizolN">
				<h3 class="entry"><span class="ar">إِزْلٌ</span></h3>
				<div class="sense" id="IizolN_A1">
					<p><span class="ar">إِزْلٌ</span> <em>A calamity;</em> <span class="auth">(Ḳ;)</span> because of its distressing character. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: <span class="ar">إِزْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IizolN_A2">
					<p><em>Lying,</em> or <em>falsehood.</em> <span class="auth">(Yaạḳoob, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazalN">
				<h3 class="entry"><span class="ar">أَزَلٌ</span></h3>
				<div class="sense" id="OazalN_A1">
					<p><span class="ar">أَزَلٌ</span> <em>i. q.</em> <span class="ar">قِدَمٌ</span> <span class="add">[i. e. <em>Eternity, with respect to past time,</em> or <em>considered retrospectively; existence from eternity;</em> or <em>ancientness</em>]</span> <span class="auth">(Ṣ, Ḳ, TA)</span> <em>that is without beginning;</em> <span class="auth">(TA;)</span> or the <em>continuance of existence in decreed times interminable in respect of the past;</em> like as <span class="ar">أَبَدٌ</span> is the continuance of existence in decreed times interminable in respect of the future; <span class="auth">(KT;)</span> or <em>that</em> <span class="add">[<em>existence,</em> or <em>time,</em>]</span> <em>which has no extremity in its beginning;</em> like <span class="ar">قِدَمٌ</span>; and <span class="ar">أَبَدٌ</span> is that which has no extremity in its latter part; like <span class="ar">بَقَآءٌ</span>: the former is <em>existence without any beginning:</em> <span class="auth">(Kull p. 31:)</span> said to be from the phrase <span class="ar long">لَمْ يَزَلْ</span> <span class="add">[“he, or it, has not ceased” to be, &amp;c.; i. e. “has ever” been, &amp;c. (<a href="#OazalieBN">see <span class="ar">أَزَلِىٌّ</span></a>)]</span>: or, accord. to some, from <span class="ar">أَزْلٌ</span> signifying “narrowness;” because the intellect is prevented by its narrowness from perceiving its beginning: <span class="auth">(MF:)</span> <span class="ar">ازل</span> is a name for <em>that of which the mind is prevented by its narrowness from determining the limit of the beginning;</em> from <span class="ar">أَزْلٌ</span> meaning “narrowness;”; and <span class="ar">ابد</span> is a name for that of which the mind shrinks from, or shuns, the determining the limit of the end; from <span class="ar">أُبُودٌ</span> meaning the act of “shrinking” from a thing, or “shunning” it. <span class="auth">(Kull pp. 30 and 31.)</span> Hence the saying, <span class="ar long">كَانَ فِى الأَزَلِ قَادِرًا عَالِمًا</span> <span class="add">[<em>He was,</em> or <em>has been, ever, powerful, knowing</em>]</span>. <span class="auth">(A, TA.)</span> The phrase <span class="ar long">أَزَلَ الآزَالِ</span> <span class="add">[<em>During the space, without beginning, of all past times;</em> or <em>ever, in all past times;</em>]</span> is like the phrase <span class="ar long">أَبَدَ الآبَادِ</span>; said to be no evidence of the use of <span class="ar">آزَالٌ</span> <a href="#OazalN">as a pl. of <span class="ar">أَزَلٌ</span></a> in a general way by the Arabs of the classical ages, as it is here added merely as a corroborative. <span class="auth">(MF in art. <span class="ar">ابد</span>.)</span> <span class="add">[<a href="#OazalieBN">See also <span class="ar">أَزَلِىٌّ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OazilN">
				<h3 class="entry"><span class="ar">أَزِلٌ</span></h3>
				<div class="sense" id="OazilN_A1">
					<p><span class="ar">أَزِلٌ</span>: <a href="#AzilN">see <span class="ar">آزِلٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazalieBN">
				<h3 class="entry"><span class="ar">أَزَلِىٌّ</span></h3>
				<div class="sense" id="OazalieBN_A1">
					<p><span class="ar">أَزَلِىٌّ</span> <span class="add">[<em>Eternal, with respect to past time; existing from eternity;</em> or <em>ancient without beginning;</em> as is implied in the Ṣ and Ḳ, &amp;c.;]</span> a thing, or being, <em>which has not been preceded by non-existence:</em> it is applied to God: and to <span class="add">[his]</span> knowledge: that which exists must be one of three kinds only: <span class="ar long">أَزَلِىٌّ أَبَدِىٌّ</span> <span class="add">[<em>existing from eternity,</em> and consequently <em>existing to eternity</em>]</span>; and this is God <span class="add">[who is also called <span class="ar long">القَدِيمُ الأَزَلِىُّ</span> <em>the Ancient without beginning</em>]</span>: and <span class="ar long">لَا أَزَلِىٌّ وَلَا أَبَدِىٌّ</span> <span class="add">[<em>not existing from eternity nor existing to eternity</em>]</span>; and such is the present world: and <span class="ar long">أَبَدِىٌّ غَيْرُ أَزَلِىّ</span> <span class="add">[<em>existing to eternity without existing from eternity</em>]</span>; and such is the world to come; the reverse of which <span class="add">[last]</span> is impossible: <span class="auth">(TA:)</span> it is a rel. n. from <span class="ar">أَزَلٌ</span>: or, accord. to some, it is not <span class="add">[genuine]</span> Arabic: <span class="auth">(TA:)</span> or it is originally <span class="ar">يَزَلِىٌّ</span>, a rel. n. from <span class="ar long">لَمْ يَزَلْ</span>, <span class="auth">(Ṣ, Ḳ,)</span> a phrase applied to that which is <span class="ar">قَدِيم</span>; and is formed by contraction; <span class="auth">(Ṣ;)</span> then, the <span class="ar">ى</span> is changed into <span class="ar">ا</span>, as being easier of pronunciation; as in <span class="ar">أَزَنِىٌّ</span>, applied to a spear, in relation to <span class="ar long">ذُو يَزَن</span>; <span class="auth">(Ṣ, Ḳ,* Ṣgh, TA;)</span> and as in <span class="ar">أَثْرَبِىٌّ</span>, applied to a blade, <span class="auth">(Ṣ, Ṣgh, TA,)</span> in relation to <span class="ar">يَثْرِب</span>: <span class="auth">(TA:)</span> so say some of the learned. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazaliyBapN">
				<h3 class="entry"><span class="ar">أَزَلِيَّةٌ</span></h3>
				<div class="sense" id="OazaliyBapN_A1">
					<p><span class="ar">أَزَلِيَّةٌ</span> The <em>quality,</em> or <em>attribute, of</em> <span class="ar">أَزَلٌ</span> <span class="add">[<em>eternity, with respect to past time,</em>, &amp;c.]</span>: but it is a forged term, not of the <span class="add">[genuine]</span> language of the Arabs. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OazuwlN">
				<h3 class="entry"><span class="ar">أَزُولٌ</span></h3>
				<div class="sense" id="OazuwlN_A1">
					<p><span class="ar long">سَنَةٌ أَزُولٌ</span> <em>A severe, distressful, calamitous,</em> or <em>adverse, year:</em> pl. <span class="ar">أُزْلٌ</span>. <span class="auth">(Ḳ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MzilN">
				<h3 class="entry"><span class="ar">آزِلٌ</span></h3>
				<div class="sense" id="MzilN_A1">
					<p><span class="ar">آزِلٌ</span> A man <em>in a state of straitness, distress, adversity,</em> or <em>difficulty.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: <span class="ar">آزِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MzilN_A2">
					<p>A man <em>in a state of straitness in consequence of fever:</em> or <em>who is unable to go forth in consequence of pain:</em> or <em>confined, restricted, withheld,</em> or <em>prevented</em> <span class="add">[<em>from going forth</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: <span class="ar">آزِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MzilN_A3">
					<p><span class="ar long">لَبُونٌ آزِلَةٌ</span> <span class="add">[<em>A milch camel</em>]</span> <em>confined,</em> or <em>restricted, not pasturing at pleasure, having her shank tied up to her arm, on account of her owner's fear of a hostile incursion:</em> occurring in a poem of El-Aạshà. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ازل</span> - Entry: <span class="ar">آزِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="MzilN_A4">
					<p><span class="ar long">أَزْلٌ آزِلٌ</span>, in the Ḳ, erroneously, <span class="arrow"><span class="ar">أَزِلٌ↓</span></span>, <em>Severe,</em> or <em>vehement, straitness, distress,</em> or <em>difficulty.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOozilN">
				<h3 class="entry"><span class="ar">مَأْزِلٌ</span></h3>
				<div class="sense" id="maOozilN_A1">
					<p><span class="ar">مَأْزِلٌ</span> <em>A place of straitness,</em> or <em>a strait place;</em> <span class="auth">(Ṣ, Ḳ;)</span> like <span class="ar">مَأْزِقٌ</span>: <span class="auth">(Ṣ:)</span> or <em>a place of war</em> or <em>fight, when strait.</em> <span class="auth">(Lḥ.)</span> And <span class="ar long">مَأْزِلُ العَيْشِ</span> <em>The place where the means of subsistence are strait,</em> or <em>narrow.</em> <span class="auth">(Lḥ.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWozilapN">
				<h3 class="entry"><span class="ar">مُؤْزِلَةٌ</span></h3>
				<div class="sense" id="muWozilapN_A1">
					<p><span class="ar long">سُنَيَّةٌ حَمْرَآءُ مُؤْزِلَةٌ</span> <span class="add">[<em>A severe year of dearth,</em> or <em>sterility,</em>]</span> <em>afflicting with drought.</em> <span class="auth">(TA, from a trad.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOozuwlN">
				<h3 class="entry"><span class="ar">مَأْزُولٌ</span></h3>
				<div class="sense" id="maOozuwlN_A1">
					<p><span class="ar">مَأْزُولٌ</span> A horse <em>having his rope</em> <span class="add">[or <em>tether</em>]</span> <em>shortened, and then left to feed at pleasure in the place of pasturage.</em> <span class="auth">(Lth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0053.pdf" target="pdf">
							<span>Lanes Lexicon Page 53</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0054.pdf" target="pdf">
							<span>Lanes Lexicon Page 54</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
