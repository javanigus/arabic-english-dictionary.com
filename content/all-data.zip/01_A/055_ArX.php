<article class="root" id="Root_ArX">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/054_Arz">ارز</a></span>
				<span class="ar">ارش</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/056_ArD">ارض</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ArX_1">
				<h3 class="entry">1. ⇒ <span class="ar">أرش</span></h3>
				<div class="sense" id="ArX_1_A1">
					<p><span class="ar">أَرَشَهُ</span>, <span class="auth">(TA,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَأْرُشُ</span>}</span></add>, <span class="auth">(TḲ,)</span> inf. n. <span class="ar">أَرْشٌ</span>, <span class="auth">(Ḳ, TA,)</span> <em>He scratched with the nails,</em> or <em>lacerated, him,</em> <span class="add">[a man,]</span> or <em>it,</em> <span class="add">[the skin, or <span class="auth">(as in the TḲ)</span> the face,]</span> <em>little</em> or <em>much, so as to bring blood</em> or <em>not;</em> syn. <span class="ar">خَدَشَهُ</span>. <span class="auth">(Ḳ,* TA.)</span> <span class="add">[This signification is probably derived from <span class="ar">أَرْشٌ</span> as syn. with <span class="ar">تَأْرِيشٌ</span>, in which sense it seems to be the inf. n. of an obsolete verb.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ArX_1_B1">
					<p><span class="ar">أَرَشَهُ</span>, <span class="auth">(TA,)</span> inf. n. as above, <span class="auth">(Ḳ, TA,)</span> <em>He gave him</em> <span class="auth">(Ḳ,* TA)</span> <em>the fine,</em> or <em>mulct, for a wound.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="ArX_1_B2">
					<p><span class="ar">أَرَشُوهُ</span>, inf. n. as above, <em>They sold the milk of their camels for the water of his well.</em> <span class="auth">(Ṣgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="ArX_1_C1">
					<p><span class="ar">أُرِشَ</span>, like <span class="ar">عُنِىَ</span>, <span class="auth">(Ṣgh,)</span> inf. n. as above, <span class="auth">(Ṣgh, Ḳ,)</span> <em>He sought to obtain,</em> or <em>demanded, the fine,</em> or <em>mulct, for a wound.</em> <span class="auth">(Ṣgh, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArX_2">
				<h3 class="entry">2. ⇒ <span class="ar">أرّش</span></h3>
				<div class="sense" id="ArX_2_A1">
					<p><span class="ar long">أرّش بَيْنَ القَوْمِ</span>, <span class="auth">(Ṣ, L, Mṣb,)</span> and <span class="ar long">بَيْنَ الرَّجُلَيْنِ</span>, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَأْرِيشٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He made mischief;</em> or <em>excited disorder, disturbance, disagreement, discord, dissension, strife,</em> or <em>quarrelling;</em> <span class="auth">(Ṣ, L, Mṣb, TA;)</span> <em>between,</em> or <em>among, the people,</em> or <em>company of men,</em> <span class="auth">(Ṣ, L, Mṣb,)</span> and <em>between the two men:</em> <span class="auth">(TA:)</span> accord. to some, its original is <span class="ar">حَرَّشَ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ArX_2_A2">
					<p>And <span class="ar long">ارّش النَّارَ</span>, inf. n. as above, <em>He kindled the fire;</em> or <em>made it to burn:</em> <span class="auth">(Ṣ, Ḳ:)</span> and in like manner, <span class="ar">الحَرْبَ</span> † <em>war,</em> or <em>the war.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ArX_8">
				<h3 class="entry">8. ⇒ <span class="ar">ائترش</span></h3>
				<div class="sense" id="ArX_8_A1">
					<p><span class="ar long">ٱئْتَرِشْ مِنْهُ Xُمَاشَتَك</span> <span class="add">[written with the disjunctive alif <span class="ar">اِيتَرِشْ</span>]</span> <em>Take thou from him the fine,</em> or <em>mulct, for thy</em> <span class="ar">خُمَاشَة</span>, q. v. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: 8.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ArX_8_A2">
					<p><span class="ar long">ٱئْتَرَشَ لِلْخُمَاشَةِ</span> <span class="add">[<em>He surrendered himself to pay the fine,</em> or <em>mulct, for the injury termed</em> <span class="ar">خُمَاشَة</span>,]</span> is like <span class="ar long">اِسْتَسْلَمَ لِلْقِصَاصِ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OaroXN">
				<h3 class="entry"><span class="ar">أَرْشٌ</span></h3>
				<div class="sense" id="OaroXN_A1">
					<p><span class="ar">أَرْشٌ</span> The <em>making mischief;</em> or <em>exciting disorder, disturbance, disagreement, discord, dissension, strife,</em> or <em>quarrelling;</em> <span class="add">[like <span class="ar">تَأْرِيشٌ</span>; <a href="#ArX_2">see 2</a>, <a href="#ArX_1">and see also 1</a>;]</span> syn. <span class="ar">فَسَادٌ</span> <span class="add">[in the sense of <span class="ar">إِفْسَادٌ</span>]</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">إِغْرَآءٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: <span class="ar">أَرْشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="OaroXN_A2">
					<p><em>Disagreement, discord,</em> or <em>dissension; and contention,</em> or <em>altercation:</em> you say, <span class="ar long">بَيْنَهُمَا أَرْشٌ</span> <em>Between them two is disagreement,</em>, &amp;c. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: <span class="ar">أَرْشٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="OaroXN_B1">
					<p><em>A fine,</em> or <em>mulct, for a wound:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> from the first of the significations in this paragraph; <span class="auth">(Mṣb;)</span> or from its being one of the causes of contention, or altercation; or, accord. to AM, from the same word as inf. n. of <span class="ar">أَرُوشٌ</span> in the first of the senses explained in this art.; accord. to IF, originally <span class="ar">هَرْشٌ</span>: <span class="auth">(TA:)</span> pl. <span class="ar">أُرُوشٌ</span>. <span class="auth">(Mgh, Mṣb.)</span> Hence the saying mentioned by IAạr, <span class="ar long">اِنْتَظِرْنِى حَتَّى تَعْقِلَ فَلَيْسَ لَكَ عِنْدَنَا أَرْشٌ إِلَّا الأَسِنَّةُ</span> <span class="add">[<em>Wait thou for me until thou accept a fine for a wound in lieu of retaliation; for thou hast no compensation for a wound to receive from us except the spearheads</em>]</span>: meaning, thou shalt not slay a man for whom we will ever give bloodwit. <span class="auth">(L, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: <span class="ar">أَرْشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="OaroXN_B2">
					<p><em>What is diminished</em> <span class="add">[<em>of the price</em>]</span> <em>by reason of a defect in a garment</em> or <em>piece of cloth:</em> as being a cause of contention, or altercation. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: <span class="ar">أَرْشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="OaroXN_B3">
					<p><em>What is payed</em> <span class="add">[<em>by way of adjustment of the difference</em>]</span> <em>between freedom from defect and defect in an article of merchandise:</em> <span class="auth">(Ḳṭ, Ḳ:)</span> for when the purchaser of a garment or piece of cloth as being free from defect discovers in it a hole or other defect, contention ensues between him and the seller. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ارش</span> - Entry: <span class="ar">أَرْشٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="OaroXN_B4">
					<p><em>A bribe.</em> <span class="auth">(Aboo-Nahshal, Sh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoruwXN">
				<h3 class="entry"><span class="ar">مَأْرُوشٌ</span></h3>
				<div class="sense" id="maOoruwXN_A1">
					<p><span class="ar">مَأْرُوشٌ</span> <em>Scratched with the nails,</em> or <em>lacerated, little</em> or <em>much, so as to bleed</em> or <em>not.</em> Ru-beh says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَقُلْ لِذَاكَ المُزْعَجِ المَحْنُوشِ</span> *</div> 
						<div class="star">* <span class="ar long">أَصْبِحٌ فَمَا مِنْ بَشَرٍ مَأْرُوشِ</span> *</div> 
					</blockquote>
					<p><em>Then say thou to that</em> man who is <em>disquieted</em> by envy, and as though he were <em>stung, Act thou gently, for</em> <span class="add">[<em>there is no scarf-skin scratched;</em> meaning,]</span> my honour is uninjured, having in it no defect nor scratch. <span class="auth">(L,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0047.pdf" target="pdf">
							<span>Lanes Lexicon Page 47</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
