<article class="root" id="Root_ASr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=01_A/093_ASd">اصد</a></span>
				<span class="ar">اصر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=01_A/095_ASTbl">اصطبل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="ASr_1">
				<h3 class="entry">1. ⇒ <span class="ar">أصر</span></h3>
				<div class="sense" id="ASr_1_A1">
					<p><span class="ar">أَصَرَهُ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَأْصِرُ</span>}</span></add>, inf. n. <span class="ar">أَصْرٌ</span>, <em>He,</em> or <em>it,</em> <span class="auth">(a thing, Ks,)</span> <em>confined, restricted, limited, kept close, kept within certain bounds or limits, shut up, imprisoned, held in custody, detained, retained, restrained, withheld, debarred, hindered, impeded,</em> or <em>prevented, him</em> or <em>it:</em> <span class="auth">(Ks, Ṣ, M, A,* Ḳ:)</span> <em>it straitened him.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">أَصَرْتُ الرَّجُلَ عَلَى ذٰلِكَ</span> <em>I confined,</em> or <em>restricted, the man to that thing,</em> or <em>affair.</em> <span class="auth">(Ks.)</span> And <span class="ar long">أَصَرْتُهُ عَنْ حَاجَتَهُ</span>, and <span class="ar long">عَمَّا أَرَادَهُ</span>, <em>I withheld, restrained,</em> or <em>debarred, him from the thing that he wanted,</em> and <em>from the thing that he desired.</em> <span class="auth">(IAạr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="ASr_1_A2">
					<p><span class="ar long">أَصَرَ البَيْتَ</span>, aor. and inf. n. as above, <em>He made,</em> or <em>put, to the tent an</em> <span class="ar">إِصَار</span>. <span class="auth">(Ḳ,* TḲ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="ASr_1_B1">
					<p>Also, aor. and inf. n. as above, <em>He broke it.</em> <span class="auth">(El-Umawee, Ṣ, M, Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="ASr_1_B2">
					<p><em>He inclined,</em> or <em>bent, it.</em> <span class="auth">(M, Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="ASr_1_B3">
					<p><em>It inclined him,</em> <span class="auth">(Aṣ, Ṣ, Ḳ,)</span> <span class="ar long">عَلَى فُلَانٍ</span> <em>to such a one.</em> <span class="auth">(Aṣ, Ṣ.)</span> <a href="#ASirapN">See an ex. voce <span class="ar">آصِرَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ASr_3">
				<h3 class="entry">3. ⇒ <span class="ar">آصر</span></h3>
				<div class="sense" id="ASr_3_A1">
					<p><span class="add">[<span class="ar">آصرهُ</span>, inf. n. <span class="ar">مُؤَاصِرَةٌ</span>, <em>He was his neighbour, having the</em> <span class="ar">إصار</span> <em>of his tent by the side of the</em> <span class="ar">إِصَار</span> <em>of the tent of the other.</em> See the act. part. n. below.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="ASr_6">
				<h3 class="entry">6. ⇒ <span class="ar">تآصر</span></h3>
				<div class="sense" id="ASr_6_A1">
					<p><span class="add">[<span class="ar">تَآصَرُوا</span> <em>They were neighbours; they dwelt,</em> or <em>abode, near together.</em> See the act. part. n. below.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OaSorN">
				<h3 class="entry"><span class="ar">أَصْرٌ</span></h3>
				<div class="sense" id="OaSorN_A1">
					<p><span class="ar">أَصْرٌ</span> <a href="#IiSorN">see <span class="ar">إِصْرٌ</span></a>; each in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OuSorN">
				<h3 class="entry"><span class="ar">أُصْرٌ</span></h3>
				<div class="sense" id="OuSorN_A1">
					<p><span class="ar">أُصْرٌ</span> <a href="#IiSorN">see <span class="ar">إِصْرٌ</span></a>; each in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiSorN">
				<h3 class="entry"><span class="ar">إِصْرٌ</span></h3>
				<div class="sense" id="IiSorN_A1">
					<p><span class="ar">إِصْرٌ</span> <em>A covenant, compact,</em> or <em>contract;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">أُصْرٌ↓</span></span> and<span class="arrow"><span class="ar">أَصْرٌ↓</span></span>: <span class="auth">(Ḳ:)</span> <span class="add">[<a href="#wSorN">see also <span class="ar">وصْرٌ</span></a>:]</span> <em>any bond arising from relationship,</em> or <em>from a covenant</em> or <em>compact</em> or <em>contract,</em> <span class="auth">(Aboo-Is-ḥáḳ,)</span> and <em>from an oath:</em> <span class="auth">(ISh:)</span> <em>a covenant, compact,</em> or <em>contract, which one does not fulfil, and for the neglecting and breaking of which one is punished:</em> so in the Ḳur ii. 286: <span class="auth">(I’Ab:)</span> <span class="add">[see also what follows, in two places:]</span> or <em>a heavy,</em> or <em>burdensome, covenant, compact,</em> or <em>contract:</em> so in the Ḳur iii. 75: <span class="auth">(ISh, M:)</span> so, too, in the same vii. 156: <span class="auth">(T, M:)</span> pl. <span class="ar">آصَارٌ</span>, a pl. of pauc.: <span class="auth">(M:)</span> or <em>a heavy,</em> or <em>burdensome, command;</em> such as was given to the Children of Israel to slay one another: so in the Ḳur ii. 286, accord. to Zj. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiSorN_A2">
					<p><em>A weight,</em> or <em>burden;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أُصْرٌ↓</span></span> and<span class="arrow"><span class="ar">أَصْرٌ↓</span></span>: <span class="auth">(Ḳ:)</span> so called because it restrains one from motion: <span class="auth">(TA:)</span> pl. as above. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiSorN_A3">
					<p><em>A sin; a crime; an offence;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">أُصْرٌ↓</span></span> and<span class="arrow"><span class="ar">أَصْرٌ↓</span></span>: <span class="auth">(Ḳ:)</span> so called because of its weight, or burdensomeness: <span class="auth">(TA:)</span> or the <em>sin of breaking a compact,</em> or <em>covenant:</em> <span class="auth">(Fr, Sh:)</span> or <em>a grievous punishment of a sin:</em> so accord. to AM in the Ḳur ii. 286. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiSorN_A4">
					<p><em>A thing that inclines one to a thing.</em> <span class="auth">(M, Ḳ.)</span> <span class="add">[<a href="#ASirapN">See also <span class="ar">آصِرَةٌ</span></a>. It is said in the Ḥam <span class="auth">(p. 321)</span> that <span class="ar">أَوَاصِرُ</span> is pl. of the former word: but it is evidently pl. of the latter.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IiSorN_A5">
					<p><em>A swearing by an oath which obliges one to divorce</em> or <em>emancipate</em> or <em>to pay a vow.</em> <span class="auth">(Ḳ, TA.)</span> So in a trad., in which it is said, <span class="ar long">مَنْ حَلَفَ عَلَى يَمِينٍ إِصْرٌ فَلَا كَفَّارَةَ لَهَا</span> <span class="add">[<em>Whoso sweareth an oath in which is an obligation to divorce</em> or <em>emancipate</em> or <em>to pay a vow, for it there is no expiation</em>]</span>: for such is the heaviest of oaths, and that from which the way of escape, or evasion, is most strait: the original meaning of <span class="ar">اصر</span> being <em>a burden,</em> and <em>a binding.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصْرٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="IiSorN_B1">
					<p>The <em>ear-hole:</em> pl. <span class="ar">آصَارٌ</span> <span class="auth">(IAạr, Ḳ)</span> and <span class="ar">إِصْرَانٌ</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IiSaArN">
				<h3 class="entry"><span class="ar">إِصَارٌ</span></h3>
				<div class="sense" id="IiSaArN_A1">
					<p><span class="ar">إِصَارٌ</span> and<span class="arrow"><span class="ar">أَيْصَرٌ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">إِصَارَةٌ↓</span></span> and<span class="arrow"><span class="ar">آصِرَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <em>A short rope,</em> <span class="auth">(Ṣ,)</span> or <em>small rope,</em> <span class="auth">(Ḳ,)</span> <em>by which the lower part of the</em> <span class="add">[<em>kind of tent called</em>]</span> <span class="ar">خِبَآء</span> <em>is tied,</em> or <em>bound,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>to the peg:</em> <span class="auth">(Ṣ:)</span> or <em>a short peg, for the</em> <span class="add">[<em>ropes called</em>]</span> <span class="ar">أَطْنَاب</span>, <em>with which the lower part of the</em> <span class="add">[<em>kind of tent called</em>]</span> <span class="ar">خبآ</span> <em>is fastened:</em> <span class="auth">(M:)</span> <span class="add">[or]</span> <span class="ar">إِصَارٌ</span> signifies also the <em>peg,</em> <span class="auth">(Ḳ,)</span> or <em>short peg,</em> <span class="auth">(TA,)</span> <em>of the</em> <span class="add">[<em>kind of tent-rope called</em>]</span> <span class="ar">طُنُب</span>: <span class="auth">(Ḳ:)</span> or <em>a peg of the</em> <span class="ar">خبآء</span>: <span class="auth">(Ibn-Es-Seed, TA:)</span> pl. of the first <span class="ar">أُصُرٌ</span> <span class="auth">(Ṣ, M)</span> and <span class="ar">آصِرَةٌ</span>; <span class="auth">(M;)</span> and of the second <span class="ar">أَيَاصِرُ</span>. <span class="auth">(Ṣ.)</span> ISd thinks that <span class="arrow"><span class="ar">آصِرَات↓</span></span> is the pl. of<span class="arrow"><span class="ar">آصِرَةٌ↓</span></span> used in the first of the senses explained above in in the following verse:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">لَعَمْرُكَ لَا أَذْنُو لِوَصْلِ دَنِيَّةٍ</span> *</div> 
						<div class="star">* <span class="ar long">وَلَا أَتَصَبَى آصِرَاتِ خَلِيلِى</span> *</div> 
					</blockquote>
					<p>the poet meaning <span class="add">[<em>By thy life, I will not approach to hold loving communion,</em> or <em>intercourse, with an ignoble,</em> or <em>a low, female;</em>]</span> <em>nor will I direct my regard to the short ropes which bind</em> <span class="add">[<em>to the pegs</em>]</span> <em>the lower part of the tent of my friend,</em> coveting his wife, and the like: or he may mean <em>nor will I direct my regard to the female relations of my friend,</em> such as his paternal aunt, and his maternal aunt, and the like. <span class="auth">(TA.)</span> <span class="add">[<a href="#ASirapN">See <span class="ar">آصِرَةٌ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IiSaArN_A2">
					<p>Also, the first, <em>A thing by which things are tied firmly,</em> or <em>made firm</em> or <em>fast.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IiSaArN_A3">
					<p><em>A thong of untanned hide which binds together the</em> <span class="ar">عَضُدَانِ</span> <em>of a camel's saddle:</em> and <span class="ar">إِسَارٌ</span> is a dial. var. thereof. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="IiSaArN_A4">
					<p>Also, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">أَيْصَرٌ↓</span></span>, <span class="auth">(AZ, Aṣ, Ḳ,)</span> <em>A</em> <span class="add">[<em>garment of the kind called</em>]</span> <span class="ar">كِسَآء</span> <em>in which dry herbage,</em> or <em>fodder, is collected:</em> <span class="auth">(M, Ḳ:)</span> or <em>a</em> <span class="ar">كسآء</span> <em>filled with herbage, and tied:</em> <span class="auth">(AZ:)</span> or <em>a</em> <span class="ar">كسآء</span> <em>in which is dry herbage,</em> or <em>fodder:</em> otherwise it is not thus called: <span class="auth">(Aṣ:)</span> pl. <span class="add">[of the former]</span> <span class="ar">أُصُرٌ</span> and <span class="ar">آصِرَةٌ</span>; <span class="auth">(Ḳ;)</span> and of the latter <span class="ar">أَيَاصِرُ</span>. <span class="auth">(AZ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="IiSaArN_A5">
					<p>And both words, <span class="auth">(the former accord. to the Ṣ and M and Ḳ, and the latter accord. to Aṣ and the Ṣ and M and Ḳ,)</span> <em>Dry herbage,</em> or <em>fodder:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>dry herbage,</em> or <em>fodder, collected together:</em> <span class="auth">(TA:)</span> or <em>dry herbage,</em> or <em>fodder, in a</em> <span class="add">[<em>garment of the kind called</em>]</span> <span class="ar">كسآء</span>: otherwise it is not thus called: <span class="auth">(Aṣ:)</span> or <em>dry herbage,</em> or <em>fodder, contained in a</em> <span class="ar">مِحَشّ</span>. <span class="auth">(M.)</span> <span class="add">[The following saying is cited as an ex. of the first of these significations:]</span> <span class="arrow"><span class="ar long">لِفُلَانٍ مَحَشٌّ لَا يُجَزُّ أَيْصَرَهُ↓</span></span> <span class="add">[<em>To such a one belongs a place,</em> or <em>land, abounding with dry herbage,</em>]</span> <em>the dry herbage whereof will not be cut;</em> <span class="auth">(Ṣ;)</span> meaning, because of its abundance. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">إِصَارٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="IiSaArN_A6">
					<p>Also, the former, <em>A basket</em> (<span class="ar">زَبِيل</span> or <span class="ar">زنْبِيل</span>, as in different copies of the Ḳ) <em>in which goods,</em> or <em>commodities,</em> (<span class="ar">مَتَاع</span>,) <em>are carried:</em> so called as being likened to the thing in which dry herbage is put. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="IiSaArapN">
				<h3 class="entry"><span class="ar">إِصَارَةٌ</span></h3>
				<div class="sense" id="IiSaArapN_A1">
					<p><span class="ar">إِصَارَةٌ</span>: <a href="#IiSaArN">see <span class="ar">إِصَارٌ</span></a>.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MSirN">
				<h3 class="entry"><span class="ar">آصِرٌ</span></h3>
				<div class="sense" id="MSirN_A1">
					<p><span class="ar long">كَلَأٌ آصِرٌ</span> <em>Pasturage that detains those that are on it</em> <span class="add">[<em>by reason of its abundance</em>]</span>: <span class="auth">(M, TA:)</span> or, <em>to which one goes because of its abundance.</em> <span class="auth">(TA.)</span></p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="MSirapN">
				<h3 class="entry"><span class="ar">آصِرَةٌ</span> / <span class="ar">آصِرَاتٌ</span></h3>
				<div class="sense" id="MSirapN_A1">
					<p><span class="ar">آصِرَةٌ</span>, and its pl. <span class="ar">آصِرَاتٌ</span>: <a href="#A_SaArN">see <span class="ar">إصَارٌ</span></a>, in three places: of which last word, the first is also a pl.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">آصِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="MSirapN_A2">
					<p><em>The thing termed</em> <span class="ar">آخِيَّة</span> <em>and</em> <span class="ar">آرِىّ</span> <span class="add">[<em>to which a beast is tied</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">آصِرَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="MSirapN_A3">
					<p><em>A tie of kindred,</em> or <em>relationship,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> or <em>affinity,</em> <span class="auth">(Ṣ,)</span> or <em>a favour,</em> or <em>benefit,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>that inclines one to a man;</em> <span class="auth">(Ṣ;)</span> or because it inclines one: <span class="auth">(M:)</span> pl. <span class="ar">أَوَاصِرُ</span>. <span class="auth">(Ḳ.)</span> One says,<span class="arrow"><span class="ar long">مَا تَأْصِرُنِى↓ عَلَى فُلَانٍ آصِرَةٌ</span></span> <em>No tie of relationship, nor any favour,</em> or <em>benefit, inclines me to such a one.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">عَطَفَ عَلَىَّ بِغَيْرِ آصِرَهْ وَنَظَرَ فِى أَمْرِى بِغَيْرِ بَاصِرَهْ</span> <span class="add">[<em>He inclined to me without any tie of relationship, &amp;c., and examined my case without eye</em>]</span>. <span class="auth">(A.)</span> <span class="add">[<a href="#IiSorN">See also <span class="ar">إِصْرٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OayoSarN">
				<h3 class="entry"><span class="ar">أَيْصَرٌ</span></h3>
				<div class="sense" id="OayoSarN_A1">
					<p><span class="ar">أَيْصَرٌ</span>: <a href="#IiSaArN">see <span class="ar">إِصَارٌ</span></a>, in three places.</p>	
				</div>
			</section>
			<hr>
			<section class="entry main" id="maOoSirN">
				<h3 class="entry"><span class="ar">مَأْصِرٌ</span> / <span class="ar">مَأْصَرٌ</span></h3>
				<div class="sense" id="maOoSirN_A1">
					<p><span class="ar">مَأْصِرٌ</span> and <span class="ar">مَأْصَرٌ</span> <em>A place in which a person or thing is confined, shut up,</em> or <em>imprisoned:</em> pl. <span class="ar">مَآصِرٌ</span>; for which the vulgar say, <span class="ar">مَعَاصِرُ</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">اصر</span> - Entry: <span class="ar">مَأْصِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="maOoSirN_A2">
					<p>Also, the former, <span class="auth">(M, A,)</span> or <span class="ar">مَاصِرٌ</span>; <span class="auth">(TA;)</span> either of the measure <span class="ar">مَفْعِلٌ</span> from <span class="ar">الأَصْرُ</span>, or of the measure <span class="ar">فَاعِلٌ</span> from <span class="ar">المِصْرُ</span>; <em>A thing intervening between two other things and preventing the passage from one to the other; a barrier:</em> <span class="auth">(A:)</span> <em>a rope across a road or river, preventing the passage of travellers and ships</em> or <em>boats,</em> <span class="auth">(M, L,)</span> <em>for the taking of the tithes from them.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="muWaASirN">
				<h3 class="entry"><span class="ar">مُؤَاصِرٌ</span></h3>
				<div class="sense" id="muWaASirN_A1">
					<p><span class="ar">مُؤَاصِرٌ</span> <em>A neighbour:</em> <span class="auth">(Ḳ:)</span> <span class="add">[or <em>a close,</em> or <em>near, neighbour:</em> as in the saying,]</span> <span class="ar long">هُوَ جَارِى مُؤَاصِرِى</span> <em>He is my neighbour, having the</em> <span class="ar">إِصَار</span> <em>of his tent by the side of the</em> <span class="ar">إِصَار</span> <em>of my tent.</em> <span class="auth">(El-Aḥmar, Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaMSiruwna">
				<h3 class="entry"><span class="ar">مُتَآصِرُونَ</span></h3>
				<div class="sense" id="mutaMSiruwna_A1">
					<p><span class="ar long">حَىٌّ مُتَآصِرُونَ</span> <em>A tribe dwelling,</em> or <em>abiding, near together.</em> <span class="auth">(Ṣ, Ḳ.*)</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0063.pdf" target="pdf">
							<span>Lanes Lexicon Page 63</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
