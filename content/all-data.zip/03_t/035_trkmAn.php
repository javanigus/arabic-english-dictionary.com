<article class="root" id="Root_trkmAn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/034_trk">ترك</a></span>
				<span class="ar">تركمان</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/036_trmA">ترما</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AltBurokumaAnu">
				<h3 class="entry"><span class="ar">التُّرْكُمَانُ</span></h3>
				<div class="sense" id="AltBurokumaAnu_A1">
					<p><span class="ar">التُّرْكُمَانُ</span> <span class="add">[<em>The Turkumán;</em>]</span> <em>a certain people,</em> or <em>race, of the Turks;</em> <span class="add">[absurdly said to be]</span> so called because two hundred thousand of them became believers in one month; wherefore they said <span class="ar long">لَا تَرَمَا</span> <span class="add">[the Turks of belief]</span>; which was afterwards contracted into <span class="ar">تُرْكُمَانٌ</span>: <span class="auth">(Ḳ, TA:)</span> <span class="add">[a coll. gen. n.: n. un., and rel. n., <span class="ar">تُرْكُمَانِىٌّ</span>:]</span> pl. <span class="ar">تَرَاكِمَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0305.pdf" target="pdf">
							<span>Lanes Lexicon Page 305</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
