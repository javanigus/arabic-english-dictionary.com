<article class="root" id="Root_tbw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/011_tbh">تبه</a></span>
				<span class="ar">تبو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/013_ttr">تتر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="taAbuwtN">
				<h3 class="entry"><span class="ar">تَابُوتٌ</span></h3>
				<div class="sense" id="taAbuwtN_A1">
					<p><span class="ar">تَابُوتٌ</span>: <a href="index.php?data=03_t/084_twb">see art. <span class="ar">توب</span></a>. Accord. to some, it belongs to the present art., and was originally <span class="ar">تَابُوَةٌ</span>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0297.pdf" target="pdf">
							<span>Lanes Lexicon Page 297</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
