<article class="root" id="Root_tO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/001_tA">تا</a></span>
				<span class="ar">تأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/003_tOr">تأر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tO_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">تأتأ</span></h3>
				<div class="sense" id="tO_RQ1_A1">
					<p><span class="ar">تَأْتَأَ</span>, inf. n. <span class="ar">تأْتَأَةٌ</span>, <em>He reiterated the letter</em> <span class="ar">ت</span> <em>in speaking.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأ</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tO_RQ1_A2">
					<p><span class="ar long">تَأْتَأَ بِالتَّيْسِ</span>, <span class="auth">(T, M,)</span> inf. n. as above <span class="auth">(T, M, Ḳ)</span> and <span class="ar">تِئْتَآءٌ</span>, <span class="auth">(M,)</span> or <span class="ar">تَأْتَآءٌ</span>, <span class="auth">(Ḳ,)</span> <em>He called the he-goat to copulate,</em> <span class="auth">(T, M, Ḳ,)</span> or <em>to approach,</em> <span class="auth">(M,)</span> <em>saying</em> <span class="arrow"><span class="ar long">تَأْ تَأْ↓</span></span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taOo">
				<h3 class="entry"><span class="ar">تَأْ</span></h3>
				<div class="sense" id="taOo_A1">
					<p><span class="ar long">تَأْ تَأْ</span>: <a href="#tA_RQ1">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOotaOapN">
				<h3 class="entry"><span class="ar">تَأْتَأَةٌ</span></h3>
				<div class="sense" id="taOotaOapN_A1">
					<p><span class="ar">تَأْتَأَةٌ</span> <em>An onomatopœia</em> <span class="add">[<em>imitative of the sound made in reiterating the letter</em> <span class="ar">ت</span> <em>in speaking:</em> or, <em>in calling a he-goat to copulate,</em> or <em>to approach:</em> see the verb, above]</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taOotaMCN">
				<h3 class="entry"><span class="ar">تَأْتَآءٌ</span></h3>
				<div class="sense" id="taOotaMCN_A1">
					<p><span class="ar">تَأْتَآءٌ</span> A man <em>who reiterates the letter</em> <span class="ar">ت</span> <em>in speaking.</em> <span class="auth">(Ṣ, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0292.pdf" target="pdf">
							<span>Lanes Lexicon Page 292</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
