<article class="root" id="Root_tOm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/003_tOr">تأر</a></span>
				<span class="ar">تأم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/005_tb">تب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tOm_3">
				<h3 class="entry">3. ⇒ <span class="ar">تاأم</span> ⇒ <span class="ar">تآءم</span></h3>
				<div class="sense" id="tOm_3_A1">
					<p><span class="ar long">تَآءَمَ أَخَاهُ</span>, <span class="auth">(Ḳ, TA, <span class="add">[in the TT, as from the M, written <span class="ar">تَأَمَ</span>, and so by Golius,]</span>)</span> inf. n. <span class="ar">مُتَآءَمَةٌ</span>, <span class="auth">(TA,)</span> <em>He was twinborn with his brother.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tOm_3_A2">
					<p><span class="ar">تآءم</span>, <span class="auth">(Ṣ,)</span> or <span class="ar long">تآءم ثَوْبًا</span>, <span class="auth">(M, Ḳ, TA, <span class="add">[in the TT, again, written <span class="ar">تَأَمَ</span>,]</span>)</span> inf. n. as above, <span class="auth">(Ṣ, TA,)</span> † <em>He wove a piece of cloth of threads two and two together</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>in its warp and its woof.</em> <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#mitoAmN">See <span class="ar">مِتْآمٌ</span></a>, <a href="#niyrN">and see also <span class="ar">نِيرٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tOm_3_A3">
					<p><span class="ar long">تآءم الفَرَسُ</span>, <span class="auth">(Ḳ, <span class="add">[written by Golius <span class="ar">تَأَمَ</span>,]</span>)</span> inf. n. as above, <span class="auth">(TA,)</span> † <em>The horse fetched run after run.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tOm_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتأم</span></h3>
				<div class="sense" id="tOm_4_A1">
					<p><span class="ar">أَتْأَمَتْ</span> <em>She</em> <span class="auth">(a mother, Ḳ, or a woman, Ṣ, M, Mṣb, and any pregnant animal, M)</span> <em>twinned,</em> or <em>brought forth two at one birth.</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tOm_4_B1">
					<p><span class="ar">أَتْأَمَهَا</span> <em>i. q.</em> <span class="ar">أَفْضَاهَا</span> <span class="add">[<a href="#AtamahaA">like <span class="ar">آتَمَهَا</span>, q. v.</a> <a href="index.php?data=01_A/014_Atm">in art. <span class="ar">اتم</span></a>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[Golius and Freytag have rendered it as though it meant <span class="ar long">أَفْضَى إِلَيْهَا</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tiYomN">
				<h3 class="entry"><span class="ar">تِئْمٌ</span></h3>
				<div class="sense" id="tiYomN_A1">
					<p><span class="ar">تِئْمٌ</span>, whence <span class="ar long">هُوَ تِئْمُهُ</span>: <a href="#taWoCamN">see <span class="ar">تَوْءَمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taYiymN">
				<h3 class="entry"><span class="ar">تَئِيمٌ</span></h3>
				<div class="sense" id="taYiymN_A1">
					<p><span class="ar">تَئِيمٌ</span>, whence <span class="ar long">هُوَ تَئِيمُهُ</span>: <a href="#taWoCamN">see <span class="ar">تَوْءَمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tuWaAmiyBapN">
				<h3 class="entry"><span class="ar">تُؤَامِيَّةٌ</span></h3>
				<div class="sense" id="tuWaAmiyBapN_A1">
					<p><span class="ar">تُؤَامِيَّةٌ</span> <em>A pearl;</em> <span class="auth">(M, Ḳ;)</span> so called in relation to <span class="ar">تُؤَامٌ</span>, <span class="auth">(TA,)</span> which is a town twenty leagues from the metropolis of 'Omán, <span class="auth">(Ḳ, TA,)</span> in the tract next the sea, <span class="auth">(TA,)</span> a city of 'Omán whence pearls are purchased, <span class="auth">(M,)</span> erroneously called by J <span class="ar">تَوْءَمٌ</span>, <span class="add">[but in one copy of the Ṣ I find it written <span class="ar">تُوام</span>,]</span> and said by him to be the metropolis of 'Omán; <span class="auth">(Ḳ;)</span> as also<span class="arrow"><span class="ar">تَوْءَمِيَّةٌ↓</span></span>, <span class="auth">(TA, <span class="add">[and thus it is written in copies of the Ṣ, but in one copy I find it written <span class="ar">تُوامِيَّة</span>,]</span>)</span> thought by En-Nejeeremee to be thus called in relation to the oyster-shell, because this is always what is termed <span class="ar">تَوْءَمٌ</span>, q. v. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tawoCamN">
				<h3 class="entry"><span class="ar">تَوْءَمٌ</span></h3>
				<div class="sense" id="tawoCamN_A1">
					<p><span class="ar">تَوْءَمٌ</span> <em>A twin; one of two young,</em> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> and <em>of more,</em> <span class="auth">(M, Ḳ,)</span> <em>brought forth at one birth,</em> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ,)</span> <em>of any animals; whether a male or a female, or a male</em> <span class="add">[<em>brought forth</em>]</span> <em>with a female;</em> <span class="auth">(M, Ḳ;)</span> and <span class="ar">تَوْءَمَةٌ</span> is <span class="add">[also]</span> applied to <em>a female:</em> <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ:)</span> it occurs in poetry contracted into <span class="ar">تَوَمٌ</span>: <span class="auth">(M:)</span> the pl. is <span class="ar">تَوَائِمُ</span> and <span class="ar">تُؤَامٌ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> the latter of which is of a rare form, not without parallels, <span class="auth">(M,)</span> said by some to be a quasi-pl. n., and by some to be originally <span class="add">[<span class="ar">تِئَامٌ</span>,]</span> with kesr, but the assertion of these last is condemned by AḤei; <span class="auth">(MF;)</span> and <span class="ar">تَوْءَمُونَ</span> is allowable as applied to human beings: <span class="auth">(Ṣ, TA:)</span> you say, <span class="ar long">هُوَ تَوْءَمُهُ</span> <span class="add">[in the TA, erroneously, <span class="ar">تُؤْمُهُ</span>, with damm,]</span> and<span class="arrow"><span class="ar">تِئْمُهُ↓</span></span> and<span class="arrow"><span class="ar">تَئِيمُهُ↓</span></span> <span class="add">[in the CK <span class="ar">تَيْئمُهُ</span>]</span> <span class="auth">(AZ, M, Ḳ)</span> <span class="add">[meaning <em>He is his twin-brother</em>]</span>: and <span class="ar long">هُمَا تَوْءَمَانِ</span> <span class="auth">(Ṣ,* M, Mgh, Mṣb * Ḳ)</span> and <span class="ar">تَوْءَمٌ</span> <span class="auth">(M, Ḳ)</span> <span class="add">[<em>They two are twin-brothers</em>]</span>: or <span class="ar">تَوْءَمٌ</span> applies only to one of the two; <span class="auth">(Mṣb;)</span> it is a mistake to say <span class="ar long">هُمَا تَوْءَمٌ</span> and <span class="ar long">هُمَا زَوْجٌ</span>: <span class="auth">(Mgh:)</span> <span class="add">[<a href="#zaWojN">but see <span class="ar">زَوْجٌ</span></a>:]</span> Lth says that <span class="ar">تَوْءَمٌ</span> applies to <em>two sons,</em> or <em>young ones,</em> <span class="add">[<em>born</em>]</span> <em>together;</em> and that one should not say <span class="ar long">هُمَا تَوْءَمَانِ</span>, but <span class="ar long">هُمَا تَوْءَمٌ</span>: this, however, is a mistake: correctly, as ISk and Fr say, <span class="ar">تَوْءَمٌ</span> applies to one, and <span class="ar">تَوْءَمَانِ</span> to two. <span class="auth">(T, TA.)</span> <em>It</em> is of the measure <span class="ar">فَوْعَلٌ</span>, <span class="auth">(Kh, Ṣ, IB, Mṣb,)</span> in the opinion of some, <span class="auth">(IB,)</span> and originally <span class="ar">وَوْءَمٌ</span>, <span class="auth">(Kh, T, Ṣ, IB,)</span> like as <span class="ar">تَوْلَجٌ</span> is originally <span class="ar">وَوْلَجٌ</span>; <span class="auth">(Kh, T, Ṣ;)</span> from <span class="ar">الوِئَامُ</span>, <span class="auth">(T, IB,)</span> “the being mutually near,” <span class="auth">(T,)</span> “mutually agreeing,” <span class="auth">(T, IB,)</span> “being mutually conformable;” <span class="auth">(IB;)</span> so that it means <em>one that agrees with,</em> or <em>matches, another,</em> <span class="auth">(IB.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tawoCamN_A2">
					<p>It is metaphorically used in relation to all things resembling one another <span class="add">[so that it means ‡ <em>One of a pair</em>]</span>. <span class="auth">(M.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَالَتْ لَنَا وَدَمْعُهَا تُؤَامُ</span> *</div> 
						<div class="star">* <span class="ar long">كَٱلدُّرِّ إِذْ أَسْلَمَهُ ٱلنِّظَامُ</span> *</div> 
						<div class="star">* <span class="ar long">عَلَى ٱلَّذِينَ ٱرْتَحَلُوا ٱلسَّلَامُ</span> *</div> 
					</blockquote>
					<p>† <span class="add">[<em>She said to us, while her tears fell in pairs,</em> or <em>in close succession, like large pearls when the string lets them drop off, Upon those who have departed be peace</em>]</span>. <span class="auth">(Ṣ.)</span> <span class="add">[This citation, and what immediately follows it in the Ṣ, mentioning the pl. <span class="ar">تَوْءَمُونَ</span>, not <span class="ar">تُؤَامُونَ</span>, have been misunderstood by Golius; and Freytag has followed him in this case.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tawoCamN_A3">
					<p><span class="ar">التَّوْءَمُ</span> is also <span class="add">[a name of]</span> † <em>A certain Mansion</em> <span class="add">[<em>of the Moon;</em> namely, <em>the Sixth; more commonly called</em> <span class="ar">الهَنْعَةُ</span>;]</span> <em>pertaining to</em> <span class="ar">الجَوْزَآء</span> <span class="add">[here meaning <em>Gemini</em>]</span>; <span class="auth">(M, Ḳ;)</span> <em>one of two</em> <span class="add">[<em>asterisms</em>]</span> <em>called</em> <span class="ar">تَوْءَمَانِ</span>: <span class="auth">(M:)</span> <span class="ar">التَّوْءَمَانِ</span> is † <em>The Sign of Gemini.</em> <span class="auth">(Ḳzw.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tawoCamN_A4">
					<p><span class="add">[The pl.]</span> <span class="ar">تَوَائِمُ</span> also signifies † <em>Clusters,</em> or <em>what are clustered together,</em> (<span class="ar long">مَا تَشَابَكَ</span>,) of stars, and of pearls. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tawoCamN_A5">
					<p>And <span class="ar">تَوْءَمَانِ</span>, † <em>A pair of pearls,</em> or <em>large pearls, for the ear:</em> each of them is termed a <span class="ar">تَوْءَمَة</span> to the other. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tawoCamN_A6">
					<p><span class="ar">التَّوْءَمَانِ</span>, <span class="add">[in the CK <span class="ar">التَّوْءَمانُ</span>,]</span> † <em>A certain small herb,</em> <span class="auth">(AḤn, M, Ḳ,)</span> <em>having a fruit like cumin-seed,</em> <span class="auth">(AḤn, M, and Ḳ in art. <span class="ar">وأم</span>,)</span> <em>and many leaves, growing in the plains, spreading long and wide, and having a yellow flower.</em> <span class="auth">(AḤn, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="tawoCamN_A7">
					<p><span class="ar">التَّوْءَمُ</span> also signifies † <em>The arrow of the kind used in the game called</em> <span class="ar">المَيْسِر</span>: <span class="auth">(M:)</span> or <em>a certain arrow of those used in that game:</em> <span class="auth">(Ḳ:)</span> or <em>the second of those arrows;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> <em>said by</em> Lḥ <em>to have two notches, and to entitle to two portions</em> <span class="add">[<em>of the slaughtered camel</em>]</span> <em>if successful, and to subject to the payment for two portions if unsuccessful.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">تَوْءَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A8</span>
				</div>
				<div class="sense" id="tawoCamN_A8">
					<p>And <span class="ar">تَوْءَمَاتٌ</span>, † <em>A kind of women's vehicles</em> <span class="add">[<em>borne by camels</em>]</span>, <span class="auth">(T, Ḳ,)</span> <em>like the</em> <span class="ar">مَشَاجِر</span>, <span class="auth">(T, TA,)</span> erroneously said in the copies of the Ḳ to be like the <span class="ar">مَشَاجِب</span>, <span class="auth">(TA,)</span> <em>having no coverings,</em> or <em>canopies:</em> the sing. is <span class="ar">تَوْءَمَةٌ</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tawoCamiyBapN">
				<h3 class="entry"><span class="ar">تَوْءَمِيَّةٌ</span></h3>
				<div class="sense" id="tawoCamiyBapN_A1">
					<p><span class="ar">تَوْءَمِيَّةٌ</span>: <a href="#tuwaAmiyBapN">see <span class="ar">تُؤَامِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutoYimN">
				<h3 class="entry"><span class="ar">مُتْئِمٌ</span></h3>
				<div class="sense" id="mutoYimN_A1">
					<p><span class="ar">مُتْئِمٌ</span> <em>Twinning,</em> or <em>bringing forth two at one birth;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> applied to a mother, <span class="auth">(Ḳ,)</span> or a woman, <span class="auth">(Ṣ, M, Mṣb,)</span> and to any pregnant animal; <span class="auth">(M;)</span> without <span class="ar">ة</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mitoMmN">
				<h3 class="entry"><span class="ar">مِتْآمٌ</span></h3>
				<div class="sense" id="mitoMmN_A1">
					<p><span class="ar">مِتْآمٌ</span> <em>Accustomed to twin, or bring forth two at one birth;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> applied to a mother, <span class="auth">(Ḳ,)</span> or a woman, <span class="auth">(Ṣ, M,)</span> and to any pregnant animal: <span class="auth">(M:)</span> pl. <span class="ar">مَتَائِيمُ</span>. <span class="auth">(Ḥar p. 613.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">مِتْآمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mitoMmN_A2">
					<p>Hence, <span class="auth">(Ḥar ubi suprà,)</span> <span class="ar long">ثَوْبٌ مِتْآمٌ</span>, <span class="auth">(Ṣ, Ḥar,)</span> or<span class="arrow"><span class="ar">مُتَآءَمٌ↓</span></span>, <span class="auth">(TA, PṢ,)</span> <span class="add">[both app. correct,]</span> † <em>A piece of cloth woven of threads two and two together in its warp and its woof.</em> <span class="auth">(Ṣ, Ḥar, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تأم</span> - Entry: <span class="ar">مِتْآمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mitoMmN_A3">
					<p>Hence, also, <span class="ar long">أَبْيَاتٌ مَتَائِيمُ</span> ‡ <em>Verses consisting of words in pairs whereof each member resembles the other in writing.</em> <span class="auth">(Ḥar ubi suprà.)</span> <span class="add">[<a href="#mutaWoCamN">See also <span class="ar">مُتَوْءَمٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutaMCamN">
				<h3 class="entry"><span class="ar">مُتَآءَمٌ</span></h3>
				<div class="sense" id="mutaMCamN_A1">
					<p><span class="ar">مُتَآءَمٌ</span>: <a href="#mitoAmN">see <span class="ar">مِتْآمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaAYimN">
				<h3 class="entry"><span class="ar">مُتَائِمٌ</span></h3>
				<div class="sense" id="mutaAYimN_A1">
					<p><span class="ar long">فَرَسٌ مُتَائِمٌ</span> † <em>A horse fetching,</em> or <em>that fetches, run after run.</em> <span class="auth">(Ṣ, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutawoCamN">
				<h3 class="entry"><span class="ar">مُتَوْءَمٌ</span></h3>
				<div class="sense" id="mutawoCamN_A1">
					<p><span class="ar long">تَجْنِيسٌ مُتَوْءَمٌ</span> † <em>The using two words resembling each other in writing but not in expression;</em> <span class="pb" id="Page_0293"></span>as in the saying, <span class="ar long">غَرَّكَ عِزُّكَ فَصَارَ قُصَارُ ذٰلِكَ ذُلَّكَ فَٱخْشَ فَاحِشَ فِعْلِكَ فَعَلَّكَ تُهْدَا بِهٰذَا</span> <span class="add">[<em>Thy might,</em> or <em>elevated rank, hath deceived thee, and the end of that has become thine ignominy: fear then thine exorbitant deed, and may-be thou wilt be made to follow a right course by this</em>]</span>. <span class="auth">(Ḥar p. 269.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0292.pdf" target="pdf">
							<span>Lanes Lexicon Page 292</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0293.pdf" target="pdf">
							<span>Lanes Lexicon Page 293</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
