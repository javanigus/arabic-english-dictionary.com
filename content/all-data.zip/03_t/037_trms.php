<article class="root" id="Root_trms">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/036_trmA">ترما</a></span>
				<span class="ar">ترمس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/038_trn">ترن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="turomusN">
				<span class="pb" id="Page_0306"></span>
				<h3 class="entry"><span class="ar">تُرْمُسٌ</span> / <span class="ar">تُرْمُسَةٌ</span></h3>
				<div class="sense" id="turomusN_A1">
					<p><span class="ar">تُرْمُسٌ</span> <span class="add">[vulgarly pronounced in the present day <span class="ar">تِرْمِس</span>; from the Greek <span class="gr">θέρμος</span>, or Coptic <span class="gr">θαρμος</span>; <em>Lupines;</em> or the <em>lupine;</em>]</span> <em>a certain grain, well known, of the description termed</em> <span class="ar">قَطَانِىّ</span>; <span class="auth">(Mṣb;)</span> the <em>produce of a tree</em> <span class="add">[or <em>plant</em>]</span> <em>which has a grain ribbed and notched:</em> <span class="auth">(Lth, M,* Ḳ:)</span> or <em>i. q.</em> <span class="ar long">بَاقِلَّى مِصْرِىٌّ</span>: <span class="auth">(the Minháj and Ḳ:)</span> <span class="add">[but if this be the same as the <span class="ar long">بَاقِلَّى قِبْطِىّ</span>, it is a mistake, accord. to Ibn-Beytár, to identify it with the <span class="ar">ترمس</span>:]</span> AHn says that it is the <span class="ar long">جِرْجِير مِصْرِىّ</span>, and is <em>of the description termed</em> <span class="ar">قَطَانِىّ</span>; and under the head of the letter <span class="ar">ج</span>, he says that the <span class="ar">جِرْجِير</span> is the <span class="ar">بَاقِلِّى</span>: accord. to the Minháj, it is <em>a grain of an expanded shape, of bitter taste, hollowed in the middle; and the wild kind is smaller than the other, and stronger: and the</em> <span class="ar">ترمس</span> <em>approaches more to medicine than to food: the best is the white, large, and heavy:</em> <span class="auth">(TA:)</span> some say that the <span class="ar">ت</span> is augmentative, and that the word is from <span class="ar">رَمَسَ</span>, signifying “he concealed” a thing: <span class="auth">(MF, TA:)</span> the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تُرْمُسَةٌ</span>}</span></add> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0306.pdf" target="pdf">
							<span>Lanes Lexicon Page 306</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
