<article class="root" id="Root_tbE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/007_tbr">تبر</a></span>
				<span class="ar">تبع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/009_tbl">تبل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tbE_1">
				<h3 class="entry">1. ⇒ <span class="ar">تبع</span></h3>
				<div class="sense" id="tbE_1_A1">
					<p><span class="ar">تَبِعَهُ</span>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْبَعُ</span>}</span></add>, inf. n. <span class="ar">تَبَعٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">تَبَاعَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>He followed;</em> or <em>went,</em> or <em>walked, behind,</em> or <em>after;</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ;)</span> <em>him,</em> <span class="auth">(Mgh, Mṣb, Ḳ,)</span> or <em>it;</em> namely, a people, or company of men: <span class="auth">(Ṣ:)</span> or <span class="add">[in the CK “and”]</span> <em>he went with him,</em> or <em>it, when the latter had passed by him:</em> <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ:)</span> and<span class="arrow"><span class="ar">اِتَّبَعَهُ↓</span></span> signifies the same; <span class="auth">(Lth, Ṣ, Ḳ *)</span> and so does<span class="arrow"><span class="ar">أَتْبَعَهُ↓</span></span>: <span class="auth">(Lth, Mgh, Ḳ:)</span> or<span class="arrow"><span class="ar">أَتْبَعْتُهُمْ↓</span></span> signifies <em>I overtook them, they having gone before me;</em> <span class="auth">(Fr,* AʼObeyd, Ṣ, Mṣb,* Ḳ;)</span> as also <span class="ar">تَبِعْتُهُمْ</span>: <span class="auth">(Fr, Ḳ:)</span> Akh says that <span class="ar">تَبِعْتُهُ</span> and<span class="arrow"><span class="ar">أَتْبَعْتُهُ↓</span></span> signify the same: and hence the saying in the Ḳur <span class="add">[xxxvii. 10]</span>,<span class="arrow"><span class="ar long">فَأَتْبَعَهُ↓ شِهَابٌ ثَاقِبٌ</span></span> <span class="add">[<em>and a shooting star piercing the darkness by its light overtaketh him</em>]</span>: <span class="auth">(Ṣ:)</span> and the saying in the same <span class="add">[vii. 174]</span>,<span class="arrow"><span class="ar long">فَأَتْبَعَهُ↓ الشَّيْطَانُ</span></span> <em>and the devil overtook him:</em> <span class="auth">(TA:)</span> <span class="pb" id="Page_0294"></span>and the saying in the same <span class="add">[xx. 81]</span>,<span class="arrow"><span class="ar long">فَأَتْبَعَهُمْ↓ فِرْعَوْنُ بِجُنُودِهِ</span></span> <em>and Pharaoh overtook them with his troops:</em> or <em>almost did so:</em> <span class="auth">(Ibn-ʼArafeh, Ḳ:)</span> or this signifies <em>made his troops to follow them;</em> <span class="auth">(TA;)</span> the <span class="ar">ب</span>, accord. to some, being redundant: <span class="auth">(Bḍ:)</span> or<span class="arrow"><span class="ar">أَتْبَعَهُ↓</span></span> signifies <em>he followed his footsteps;</em> and <em>sought him, following him:</em> <span class="auth">(TA:)</span> but<span class="arrow"><span class="ar">اِتَّبَعَهُمْ↓</span></span> signifies <em>he went</em> <span class="add">[<em>after them,</em> or <em>followed them,</em>]</span> <em>when they had passed by him;</em> as also <span class="ar">تَبِعَهُمْ</span>, inf. n. <span class="ar">تَبَعٌ</span>: you say,<span class="arrow"><span class="ar long">مَا زِلْتُ أَتَّبِعُهُمْ↓ حَتَّى أَتْبَعْتُهُمْ↓</span></span>, i. e. <span class="add">[<em>I ceased not to follow them</em>]</span> <em>until I overtook them:</em> <span class="auth">(AʼObeyd:)</span> Fr says that<span class="arrow"><span class="ar">أَتْبَعَ↓</span></span> is better than<span class="arrow"><span class="ar">اِتَّبَعَ↓</span></span>; for the latter signifies <em>he went behind,</em> or <em>after, him, when the latter person was going along;</em> but when you say,<span class="arrow"><span class="ar">أَتْبَعْتُهُ↓</span></span>, it is as though <span class="add">[you meant that]</span> you followed his footsteps: <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">اِتَّبَعَ↓ فُلَانٌ فُلَانًا↓</span></span> <span class="add">[as in the L and TA, but perhaps a mistake for<span class="arrow"><span class="ar">أَتْبَعَ↓</span></span>,]</span> signifies also <em>he followed him, desiring to do evil to him;</em> like as Pharaoh followed Moses: <span class="auth">(L, TA:)</span> some say, <span class="ar long">تَبِعْتُ الشَّىْءَ</span>, inf. n. <span class="ar">تُبُوعٌ</span>, meaning <em>I went after the thing:</em> and <span class="ar long">تَبِعَ الشَّىْءَ</span>, inf. n. <span class="ar">تَبَعٌ</span> and <span class="ar">تَبَاعٌ</span>, † <span class="add">[<em>he followed the thing</em>]</span> <em>in respect of actions:</em> <span class="auth">(L, TA:)</span> you say, <span class="ar long">تَبِعَ الإِمَامَ</span> † <em>he followed the Imám</em> <span class="add">[<em>by doing as he did</em>]</span>: <span class="auth">(Mṣb:)</span> <span class="add">[but in this last sense, more commonly,]</span> one says,<span class="arrow"><span class="ar">اِتَّبَعَهُ↓</span></span>, meaning † <em>he did like as he</em> <span class="add">[another]</span> <em>did:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">اِتَّبَعَ↓ القُرْآنَ</span></span> † <em>he followed the Kurán as his guide; did according to what is in it:</em> <span class="auth">(TA:)</span> and you say also,<span class="arrow"><span class="ar long">تَابَعَهُ↓ عَلَى الأَمْرِ</span></span>; <span class="auth">(Mṣb;)</span> or <span class="ar long">على كَذَا</span>, inf. n. <span class="ar">مُتَابَعَةٌ</span> and <span class="ar">تِبَاعٌ</span>; <span class="auth">(Ṣ;)</span> † <span class="add">[<em>he followed him,</em> or <em>imitated him, in the affair;</em>]</span> <span class="auth">(Mṣb;)</span> <em>he followed him,</em> or <em>imitated him, in doing such a thing:</em> <span class="auth">(PṢ:)</span> <span class="add">[but this last phrase has another meaning: <a href="#tbE_3">see 3</a>.]</span> In the saying, <span class="ar long">لَا يُتْبَعُ بِنَارٍ إِلَى القَبْرِ</span>, <span class="add">[in which the verb may be pass. of <span class="ar">تَبِعَ</span> or of<span class="arrow"><span class="ar">أَتْبَعَ↓</span></span>,]</span> or, accord. to one relation,<span class="arrow"><span class="ar long">لا يُتَّبَعُ↓</span></span>, each in the pass. form, <span class="add">[<em>Fire shall not be made to follow to the grave,</em> though it may be rendered <em>one shall not follow with fire to the grave,</em> it is said that]</span> the <span class="ar">ب</span> is to render the verb transitive. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbE_1_A2">
					<p><span class="ar long">تَبِعْتُ الرَّجُلَ بِحَقِّى</span>; and<span class="arrow"><span class="ar long">تَابَعْتُهُ↓ بِهِ</span></span>, inf. n. <span class="ar">مُتَابَعَةٌ</span> <span class="add">[and probably <span class="ar">تبَاعٌ</span> also]</span>; and<span class="arrow"><span class="ar long">اِتَّبَعْتُهُ↓ به</span></span>; <em>I prosecuted,</em> or <em>sued, the man for my right,</em> or <em>due.</em> <span class="auth">(TA.)</span> The saying in the Ḳur <span class="add">[ii. 173]</span>,<span class="arrow"><span class="ar long">فَٱتِّبَاعٌ↓ بِٱلْمَعْرُوفِ</span></span> means <span class="add">[<em>Then</em>]</span> <em>prosecution</em> for the bloodwit <span class="add">[shall be made <em>with lenity</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tbE_1_A3">
					<p><span class="ar">تَبِعَ</span>, of which the aor., <span class="ar">يَتْبَع</span>, occurs in a trad., <span class="add">[<a href="#tbE_4">see 4</a>,]</span> <span class="auth">(Mgh, TA,)</span> pronounced by the relaters of trads. with teshdeed, <span class="add">[<span class="arrow"><span class="ar">يَتَّبِع↓</span></span>,]</span> <span class="auth">(TA,)</span> also signifies † <em>He accepted a reference from his debtor to another for the payment of what was owed to him.</em> <span class="auth">(Mgh, TA.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbE_2">
				<h3 class="entry">2. ⇒ <span class="ar">تبّع</span></h3>
				<div class="sense" id="tbE_2_A1">
					<p><span class="ar long">تَبَّعَ ٱللّٰهُ لِفُلَانٍ</span>, inf. n. <span class="ar">تَتْبِيعٌ</span>, <em>May God make a thing to be followed by another thing to such a one,</em> is said in relation to good and to evil; like <span class="ar long">سَبَّعَ لَهُ</span>. <span class="auth">(TA in art. <span class="ar">سبع</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tbE_2_B1">
					<p><a href="#tbE_5">See also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbE_3">
				<h3 class="entry">3. ⇒ <span class="ar">تابع</span></h3>
				<div class="sense" id="tbE_3_A1">
					<p><span class="ar">تِبَاعٌ</span> <span class="add">[and <span class="ar">مُتَابَعَةٌ</span>, the inf. ns. of <span class="ar">تَابَعَ</span>,]</span> <em>i. q.</em> <span class="ar">وِلَآءٌ</span> <span class="add">[The <em>making a consecution,</em> or <em>succession, of one to the other,</em> <span class="ar long">بَيْنَ أَمْرَيْنِ</span> <em>between two things,</em> or <em>affairs:</em> and the <em>making consecutive, successive,</em> or <em>uninterrupted, in its progressions,</em> or <em>gradations,</em> or <em>the like:</em> <a href="#tbE_6">see 6</a>]</span>. <span class="auth">(Ṣ, Ḳ.)</span> It is said in a trad., <span class="ar long">تَابِعُوا بَيْنَ الحَجِّ والعُمْرَةِ</span> <span class="add">[<em>Make ye a consecution between the</em> <span class="ar">حجّ</span> <em>and the</em> <span class="ar">عمرة</span>; meaning <em>make ye the performance of the</em> <span class="ar">حجّ</span> <em>and that of the</em> <span class="ar">عمرة</span> <em>to be consecutive</em>]</span>; <span class="auth">(TA;)</span> i. e. <em>when ye perform the</em> <span class="ar">حجّ</span>, <em>then perform ye the</em> <span class="ar">عمرة</span>; <em>and when ye perform the</em> <span class="ar">عمرة</span>, <em>then perform ye the</em> <span class="ar">حجّ</span>: or <em>when ye perform either of these, then perform ye after it the other, without any length of time</em> <span class="add">[<em>intervening</em>]</span>: but the former <span class="add">[meaning]</span> is the more obvious. <span class="auth">(Marginal note in a copy of the Jámi'-eṣ-Ṣagheer of Es-Suyootee.)</span> And you say, <span class="ar long">تَابِعْ بَيْنَنَا وَبَيْنَهُمْ عَلَى الخَيْرَاتِ</span> † <em>Make thou us to be followers,</em> or <em>imitators, of them in excellencies.</em> <span class="auth">(TA.)</span> And <span class="ar long">تابع الأَغَانِىَّ</span> <span class="add">[<em>He sang songs consecutively, successively,</em> or <em>uninterruptedly</em>]</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">جر</span>.)</span> And <span class="ar long">تابع إِسْقَاطَهُ</span> <span class="add">[<em>He made it to fall, fall down, drop, drop down,</em> or <em>tumble down, in consecutive portions</em> or <em>quantities</em>]</span>. <span class="auth">(M and Ḳ in art. <span class="ar">سقط</span>: in the CK <span class="ar">اَسْقاطَهُ</span>.)</span> And <span class="ar long">تابع الفَرَسُ الجَرْىَ</span> † <span class="add">[<em>The horse prosecuted,</em> or <em>continued, the course,</em> or <em>running, uninterruptedly</em>]</span>. <span class="auth">(Ḳ voce <span class="ar">هَلَبَ</span>;, &amp;c.)</span> And <span class="ar long">هُوَ يَتَابِعُ الحَدِيثَ</span> ‡ <em>He carries on the narrative,</em> or <em>discourse, by consecutive progressions,</em> or <em>uninterruptedly:</em> or, as Z says, <em>pursues it,</em> or <em>carries it on, well.</em> <span class="auth">(TA.)</span> <span class="add">[See also a similar phrase in what here follows.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbE_3_A2">
					<p><span class="ar long">تابع القَوْسَ</span> <em>He pared,</em> or <em>trimmed, the bow well, giving to each part thereof what was its due.</em> <span class="auth">(Ḳ, TA.)</span> Skr says that the phrase <span class="ar long">تُوبِعَ بَرْيُهَا</span>, used by Aboo-Kebeer El-Hudhalee in describing a bow, means <em>The paring,</em> or <em>trimming, of which has been executed with uniformity, part after part.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tbE_3_A3">
					<p>Hence, <span class="auth">(TA,)</span> the saying of Abu-l-Wákid El-Leythee, <span class="auth">(Ṣ, TA,)</span> in a trad., <span class="auth">(Ṣ,)</span> <span class="ar long">تَابَعْنَا الأَعْمَالَ فَلَمْ نَجِدْ شَيْئًا أَبْلَغَ فِى طَلَبِ الآخِرَةِ مِنَ الزُّهْدِ فِى الدُّنْيَا</span> <span class="auth">(Ṣ, TA)</span> † <em>We have practised works with diligence, and acquired a sound knowledge of them,</em> <span class="add">[<em>and we have not found anything more efficacious in the pursuit of the blessings of the world to come than abstinence in respect of the enjoyments of the present world.</em>]</span> <span class="auth">(Ṣ,* TA.)</span> You say also, <span class="ar long">تابع عَمَلَهُ</span>, meaning † <em>He made his work sound,</em> or <em>free from defect:</em> <span class="auth">(Kr, Ṣ:)</span> and in like manner, <span class="ar">كَلَامَهُ</span> <em>his language,</em> or <em>speech.</em> <span class="auth">(Kr.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tbE_3_A4">
					<p><span class="add">[Hence also,]</span> <span class="ar long">تابع المَرْعَى الإِبِلَ</span> ‡ <em>The pasture fattened the camels well and thoroughly.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tbE_3_A5">
					<p><span class="ar long">تابعهُ عَلَى الأَمْرِ</span> † <em>He aided, assisted,</em> or <em>helped, him to do the thing,</em> or <em>affair.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tbE_3_A6">
					<p><a href="#tbE_1">See also 1</a>, where another meaning of the same phrase is mentioned, in the latter half of the paragraph.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="tbE_3_A7">
					<p><span class="ar long">تَابَعْتُهُ بِحَقِّى</span>: <a href="#tbE_1">see 1</a>, near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbE_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتبع</span></h3>
				<div class="sense" id="tbE_4_A1">
					<p><span class="ar">اتبعهُ</span>: <a href="#tbE_1">see 1</a>, from the beginning nearly to the end.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tbE_4_B1">
					<p>Also <em>He made him to follow;</em> or <em>to overtake:</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>he made him to be a follower:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>he urged him,</em> or <em>induced him, to be a follower.</em> <span class="auth">(Mgh.)</span> You say, <span class="add">[making the verb doubly trans.,]</span> <span class="ar long">أَتْبَعْتُهُمْ غَيْرِى</span> <span class="add">[<em>I made them to follow,</em> or <em>overtake, another, not myself</em>]</span>. <span class="auth">(Ḳ.)</span> And <span class="ar long">أَتْبَعْتُهُ الشَّىْءَ فَتَبِعَهُ</span> <span class="add">[<em>I made him to follow,</em> or <em>overtake, the thing, and he followed it,</em> or <em>overtook it</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَتْبَعْتُ زَيْدًا عَمْرًا</span> <em>I made Zeyd to be a follower of ʼAmr:</em> <span class="auth">(Mgh, Mṣb:)</span> or <em>I urged,</em> or <em>induced, Zeyd to be a follower of ʼAmr.</em> <span class="auth">(Mgh.)</span> And <span class="ar long">أَتْبَعَهُ نَفْسَهُ مُتَحَسِّرًا عَلَى مَا فَاتَ</span> † <span class="add">[<em>He made his mind,</em> or <em>desire, to follow after it, regretting what had passed away</em>]</span>. <span class="auth">(TA in art. <span class="ar">عجز</span>.)</span> <span class="add">[<a href="#tbE_10">See also 10</a>.]</span> It is said in a prov., <span class="auth">(TA,)</span> <span class="ar long">أَتْبِعِ الفَرَسَ لِجَامَهَا</span> <span class="add">[<em>Make thou its bit and bridle to follow the horse</em>]</span>: or <span class="ar long">النَّاقَةَ زِمَامَهَا</span> <span class="add">[<em>her nose-rein, the she-camel</em>]</span>: or <span class="ar long">الدَّلْوَ رِشَآءَهَا</span> <span class="add">[<em>its rope, the bucket</em>]</span>: used in bidding to complete a favour, or benefaction: <span class="auth">(Ḳ, TA:)</span> AʼObeyd says, I think the meaning of the first prov. to be, Thou hast liberally given the horse, and the bit and bridle are a smaller matter; therefore satisfy thou completely the want, seeing that the horse is not without need of the bit and bridle. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tbE_4_B2">
					<p>Hence the trad., <span class="ar long">مَنْ أُتْبِعَ عَلَى مَلِىْءٍ فَلْيَتْبَعْ</span> ‡ <em>Whoso is referred, for the payment of what is owed to him, to a solvent man, let him accept the reference:</em> <span class="auth">(Mgh, TA:*)</span> <span class="add">[<a href="#tbE_1">see also 1</a>, last meaning:]</span> the verb being made trans. by means of <span class="ar">على</span> because it conveys the meaning of <span class="ar">إِحَالَةٌ</span>. <span class="auth">(Mgh.)</span> You say <span class="add">[also]</span>, <span class="ar long">أُتْبِعَ فُلَانٌ بِفُلَانٍ</span> ‡ <em>Such a one was referred, for the payment of what was owed to him, to such a one.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="ar long">أَتْبَعَهُ عَلَيْهِ</span> ‡ <em>He referred him, for the payment of what was owed to him, to him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="tbE_4_B3">
					<p><span class="add">[<a href="#IitobaAEN">See also <span class="ar">إِتْبَاعٌ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbE_5">
				<h3 class="entry">5. ⇒ <span class="ar">تتبّع</span></h3>
				<div class="sense" id="tbE_5_A1">
					<p><span class="ar">تتبّعهُ</span>, inf. n. <span class="ar">تَتَبُّعٌ</span>, <span class="auth">(Lth, Ṣ, Mṣb,* Ḳ,)</span> for which <span class="arrow"><span class="ar">اِتِّبَاعٌ↓</span></span> is used by El-Kutámee, tropically, <span class="auth">(Ṣ,)</span> or, accord. to Sb, because the same in meaning; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">تبعّه↓</span></span>, inf. n. <span class="ar">تَتْبِيعٌ</span>; <span class="auth">(Ṣ, Ḳ;*)</span> <em>He pursued it; investigated it; examined it; hunted after it; prosecuted a search after it; made successive,</em> or <em>repeated, endeavours to attain it, to reach it,</em> or <em>to obtain it;</em> or <em>sought it, sought for it,</em> or <em>sought after it, successively, time after time,</em> or <em>repeatedly,</em> or <em>in a leisurely manner, by degrees, gradually, step by step, bit by bit,</em> or <em>one thing after another,</em> <span class="auth">(Lth, Ṣ,* Mṣb, Ḳ,* TA,)</span> <em>following after it.</em> <span class="auth">(Ṣ.)</span> Hence the saying of Zeyd Ibn-Thábit, respecting the collecting of the Ḳur-án, <span class="ar long">فَعَلِقْتُ أَتَتَبَّعُهُ مِنَ اللِّخَافِ وَالعُسُبِ</span> <span class="add">[<em>And I set myself to seeking to collect it successively,</em>, &amp;c., <em>from the thin white stones and the leafless palm-branches</em> upon which it was written]</span>. <span class="auth">(TA.)</span> And <span class="ar long">تتبّع البِلَادَ يَخْرُجُ مِنْ أَرْضٍ إِلَى أَرْضٍ</span> <span class="add">[<em>He investigated the countries, going forth from land to land</em>]</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">قرى</span>.)</span> And <span class="ar long">فُلَانٌ يَتَتَبَّعُ أَثَرَ فُلَانٍ</span> <span class="add">[<em>Such a one pursues,</em>, &amp;c., <em>the track of such a one</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">يَتَتَبَّعُ مَسَاوِىَ فُلَانٍ</span> <span class="add">[<em>He seeks successively,</em>, &amp;c., <em>to discover the vices, faults,</em> or <em>evil qualities</em> or <em>actions, of such a one</em>]</span>. <span class="auth">(TA.)</span> And <span class="ar long">يَتَتَبَّعُ مَدَاقَّ الأُمُورِ وَنَحْوَ ذٰلِكَ</span> <span class="add">[<em>He pursues small,</em> or <em>little, affairs; and the like thereof:</em> or <em>he seeks successively,</em>, &amp;c., <em>to obtain a knowledge of the subtilties, niceties, abstrusities,</em> or <em>obscurities, of things,</em> or <em>affairs; and the like thereof</em>]</span>. <span class="auth">(TA.)</span> <span class="pb" id="Page_0295"></span>And <span class="ar long">تتبّع الحَبْلَ</span> <span class="add">[<em>He took successive holds of the rope</em>]</span>: said of a man descending from a part of a mountain such as is termed <span class="ar">شِيق</span>, by means of a rope tied to that part, to a place in which honey was deposited. <span class="auth">(TA in art. <span class="ar">شيق</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbE_6">
				<h3 class="entry">6. ⇒ <span class="ar">تتابع</span></h3>
				<div class="sense" id="tbE_6_A1">
					<p><span class="ar">تتابع</span> <em>It was,</em> or <em>became, consecutive, successive,</em> or <em>uninterrupted, in its progressions,</em> or <em>gradations,</em> or <em>the like;</em> syn. <span class="ar">تَوَالَى</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">تتابع سُقُوطُهُ</span> <span class="add">[<em>Its falling, falling down, dropping, dropping down,</em> or <em>tumbling down, was,</em> or <em>became, consecutive,</em>, &amp;c.; i. e. <em>it fell, fell down,</em>, &amp;c., <em>in consecutive portions</em> or <em>quantities</em>]</span>. <span class="auth">(M and Ḳ in art. <span class="ar">سقط</span>.)</span> And <span class="ar long">تتابع القَوْمُ</span> <em>The people,</em> or <em>company of men, followed one another.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">تَتَابَعَتِ الأَشْيَآءُ</span>, and <span class="ar">الأَمْطَارُ</span>, and <span class="ar">الأُمُورُ</span>, <em>The things,</em> and <em>the rains,</em> and <em>the events, came one after another, each following near upon another.</em> <span class="auth">(Lth.)</span> And it is said in a trad., <span class="ar long">تَتَابَعَتْ عَلَى قُرَيْشٍ سِنُو جَدْبٍ</span> <span class="add">[<em>Years of dearth, drought,</em> or <em>sterility, came consecutively upon Kureysh</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbE_6_A2">
					<p><span class="ar long">تتابع الفَرَسُ</span> ‡ <em>The horse ran evenly, not raising one of his limbs</em> <span class="add">[<em>above its fellow</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: 6.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tbE_6_A3">
					<p><span class="ar long">تتابعت الإِبِلُ</span> ‡ <em>The camels became fat and goodly.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tbE_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّبع</span></h3>
				<div class="sense" id="tbE_8_A1">
					<p><a href="#tbE_1">see 1</a>, throughout: <a href="#tbE_5">and see also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbE_10">
				<h3 class="entry">10. ⇒ <span class="ar">استتبع</span></h3>
				<div class="sense" id="tbE_10_A1">
					<p><span class="ar">استتبعهُ</span> <em>He desired,</em> or <em>demanded, of him that he should follow him:</em> <span class="auth">(TA:)</span> or <em>he made him to follow him.</em> <span class="auth">(L.)</span> <span class="add">[<a href="#tbE_4">See also 4</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiboEN">
				<h3 class="entry"><span class="ar">تِبْعٌ</span> / <span class="ar">تِبْعَةٌ</span></h3>
				<div class="sense" id="tiboEN_A1">
					<p><span class="ar">تِبْعٌ</span> <em>A follower</em> of women: <span class="auth">(Lḥ,* Az:)</span> or <em>a passionate lover, and follower,</em> of a woman, <span class="auth">(Ḳ,)</span> whithersoever she goes: <span class="auth">(TA:)</span> and with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تِبْعَةٌ</span>}</span></add>, of a man: <span class="auth">(Lḥ:)</span> and<span class="arrow"><span class="ar">تُبَّعٌ↓</span></span> <em>a sedulous seeker</em> of women. <span class="auth">(Ḳ.)</span> <span class="add">[<a href="#taAbiEN">See <span class="ar">تَابِعٌ</span></a>.]</span> You say also, <span class="ar long">هُوَ تِبْعُ ضِلَّةٍ</span>, meaning <em>He is a follower of women:</em> and <span class="ar long">تِبْعُ ضِلَّةٌ</span> <em>one in whom is no good, and with whom is no good:</em> or, accord. to Th, you only say <span class="ar long">تِبْعُ ضِلَّةٍ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تِبْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tiboEN_A2">
					<p><span class="ar long">هٰذَا تِبْعُ هٰذَا</span> <em>This is what follows this.</em> <span class="auth">(M in art. <span class="ar">تلو</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تِبْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tiboEN_A3">
					<p><a href="#tabiyEN">See also <span class="ar">تَبِيعٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabaEN">
				<h3 class="entry"><span class="ar">تَبَعٌ</span></h3>
				<div class="sense" id="tabaEN_A1">
					<p><span class="ar">تَبَعٌ</span>: <a href="#taAbiEN">see <span class="ar">تَابِعٌ</span></a>, in six places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tubaEN">
				<h3 class="entry"><span class="ar">تُبَعٌ</span></h3>
				<div class="sense" id="tubaEN_A1">
					<p><span class="ar long">رَجُلٌ تُبَعٌ لِلْكَلَامِ</span> <em>A man who makes his speech consecutive, one part to another.</em> <span class="auth">(Yoo, Ḳ.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taboEae">
				<h3 class="entry"><span class="ar">تَبْعَى</span></h3>
				<div class="sense" id="taboEae_A1">
					<p><span class="ar long">بَقَرَةٌ تَبْعَى</span> <em>A cow desiring</em> <span class="add">[<em>and therefore following</em>]</span> <em>the bull.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabiEapN">
				<h3 class="entry"><span class="ar">تَبِعَةٌ</span></h3>
				<div class="sense" id="tabiEapN_A1">
					<p><span class="ar">تَبِعَةٌ</span> and<span class="arrow"><span class="ar">تِبَاعَةٌ↓</span></span> signify the same; <span class="auth">(T, Ṣ, O, L, Ḳ;)</span> <span class="add">[The <em>consequence</em> of an action: and]</span> <em>a claim which one seeks to obtain for an injury,</em> or <em>injurious treatment,</em> and <em>the like:</em> <span class="auth">(T, O, L, Ḳ; and so the Mṣb in explanation of the former word:)</span> the former is also explained as signifying <em>a right,</em> or <em>due, annexed to property, claimed from the possessor of the property:</em> <span class="auth">(L:)</span> pl. <span class="add">[of the former]</span> <span class="ar">تَبِعَاتٌ</span> and <span class="add">[of the latter]</span> <span class="ar">تِبَاعَاتٌ</span>. <span class="auth">(TA.)</span> A poet says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَكَلَتْ حَنِيفَةُ رَبَّهَا</span> *</div> 
						<div class="star">* <span class="ar long">زَمَنَ التَّقَحُّمِ وَالمَجَاعَهْ</span> *</div> 
						<div class="star">* <span class="ar long">لَمْ يَحْذَرُوا مِنْ رَبِّهِمْ</span> *</div> 
						<div class="star">*<span class="arrow"><span class="ar long">سُوْءَ العَوَاقِبِ وَالتِّبَاعَهْ↓</span></span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Ḥaneefeh ate their lord, in the time of experiencing dearth,</em> or <em>drought,</em> or <em>sterility, and hunger: they did not fear, from their lord, the evil of the results, and the consequence</em> of their action]</span>: for they had taken to themselves a god consisting of <span class="ar">حَيْس</span>, <span class="add">[i. e. dates mixed with clarified butter and the preparation of milk called <span class="ar">أَقِط</span>, kneaded together,]</span> and worshipped it for some time; then famine befell them, and they ate it. <span class="auth">(Ṣ.)</span> And one says, <span class="ar long">مَا عَلَيْهِ مِنَ ٱللّٰهِ فِى هٰذَا تَبِعَةٌ</span>, and<span class="arrow"><span class="ar">تِبَاعَةٌ↓</span></span>, <em>There is not, against him, on the part of God, in this, any claim on account of wrong-doing.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabiyEN">
				<h3 class="entry"><span class="ar">تَبِيعٌ</span> / <span class="ar">تَبِيعَةٌ</span></h3>
				<div class="sense" id="tabiyEN_A1">
					<p><span class="ar">تَبِيعٌ</span> <span class="add">[One who is <em>prosecuted,</em> or <em>sued,</em> for a right, or due; of the measure <span class="ar">فَعِيلٌ</span> in the sense of the measure <span class="ar">مَفْعُولٌ</span>, from <span class="ar long">تَبِعْتُهُ بِحَقِّى</span>;]</span> one <em>who owes property to another,</em> <span class="auth">(Ṣ, Ḳ, TA,)</span> <em>and whom the latter prosecutes,</em> or <em>sues, for it.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَبِيعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tabiyEN_B1">
					<p>The <em>young one of a cow in the first year;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> so says Aboo-Fak'as El-Asadee: <span class="auth">(TA:)</span> or <em>that is a year old;</em> <span class="auth">(Az, Mgh, TA;)</span> not so called until he has completed the year; erroneously said by Lth to signify <em>a calf ripening to his perfect state:</em> <span class="auth">(Az, TA:)</span> thus called because he yet follows his mother; <span class="auth">(Mgh, Mṣb;)</span> the word in this sense being of the measure <span class="ar">فَعِيلٌ</span> in the sense of the measure <span class="ar">فَاعِلٌ</span>: <span class="auth">(Mṣb:)</span> and<span class="arrow"><span class="ar">تِبْعٌ↓</span></span> signifies the same: <span class="auth">(TA:)</span> fem. of the former with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَبِيعَةٌ</span>}</span></add>: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> pl. <span class="ar">تِبَاعٌ</span> and <span class="ar">تَبَائِعٌ</span>; <span class="auth">(AA, Ṣ, O, Ḳ;)</span> both pls. of <span class="ar">تَبِيعٌ</span>; <span class="auth">(AA, Ṣ, O;)</span> or the former <a href="#tabiyEapN">is pl. of <span class="ar">تَبِيعَةٌ</span></a>; <span class="auth">(Mṣb;)</span> and <a href="#tabiyEN">the pl. of <span class="ar">تَبِيعٌ</span></a> is <span class="ar">أَتْبِعَةٌ</span> <span class="add">[a pl. of pauc.]</span>; <span class="auth">(L, Mṣb;)</span> and <span class="ar">أَتَابِعُ</span> and <span class="ar">أَتَابِيعُ</span>, the latter of which is extr., are pls. of <span class="ar">أَتْبِعَةٌ</span>: <span class="auth">(L:)</span> the pl. of<span class="arrow"><span class="ar">تِبْعٌ↓</span></span> in the abovementioned sense is <span class="ar">أَتْبَاعٌ</span>. <span class="auth">(TA.)</span> Accord. to EshShaabee, <span class="auth">(IF,)</span> One <em>whose horns and ears are equal</em> <span class="add">[<em>in length</em>]</span>: <span class="auth">(IF, Ḳ:)</span> but this is a judicial explanation; not deduced from the rules of lexicology. <span class="auth">(IF.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَبِيعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tabiyEN_B2">
					<p><em>I. q.</em> <span class="arrow"><span class="ar">تَابِعٌ↓</span></span> <span class="add">[as signifying One <em>who prosecutes,</em> or <em>sues,</em> for a right, or due; and particularly for blood-revenge]</span>. <span class="auth">(Ṣ, Ḳ.)</span> Hence the saying in the Ḳur <span class="add">[xvii. 71]</span>, <span class="ar long">ثُمَّ لَا تَجِدُوا لَكُمْ عَلَيْنَا بِهِ تَبِيعًا</span> <em>Then ye shall not find for you any to prosecute for blood-revenge, nor any to sue, against us therein:</em> <span class="auth">(Fr. Ṣ, Ḳ:)</span> or <em>ye shall not find for you any to sue us for the disallowing of what hath befallen you, nor for our averting it from you:</em> <span class="auth">(Zj:)</span> <span class="add">[or <em>any aider against us;</em> for]</span> <span class="ar">تَبِيعٌ</span> also signifies <em>an aider;</em> and especially <em>against an enemy.</em> <span class="auth">(Lth, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَبِيعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="tabiyEN_B3">
					<p><a href="#taAbiEN">See also <span class="ar">تَابِعٌ</span></a>, latter half.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tibaAEapN">
				<h3 class="entry"><span class="ar">تِبَاعَةٌ</span></h3>
				<div class="sense" id="tibaAEapN_A1">
					<p><span class="ar">تِبَاعَةٌ</span>: <a href="#tabiEapN">see <span class="ar">تَبِعَةٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tubBaEN">
				<h3 class="entry"><span class="ar">تُبَّعٌ</span></h3>
				<div class="sense" id="tubBaEN_A1">
					<p><span class="ar">تُبَّعٌ</span> <em>An appellation of each of the Kings of El-Yemen</em> <span class="auth">(Ṣ, Ḳ)</span> <em>who possessed Himyer and Hadramowt,</em> <span class="auth">(Ḳ, TA,)</span> <em>and,</em> as some add, <em>Sebà;</em> <span class="auth">(TA;)</span> but not otherwise; <span class="auth">(Ḳ, TA;)</span> and the like of this is said in the ʼEyn: <span class="auth">(TA:)</span> so called because they followed one another; whenever one died, another took his place, following him in his course of acting: <span class="auth">(TA:)</span> pl. <span class="ar">تَبَابِعَةٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> with <span class="ar">ة</span> added as having the meaning of a rel. n.; <span class="add">[<a href="#tub~aEieBN">as though it were pl. of <span class="ar">تُبَّعِىٌّ</span></a>, like as <span class="ar">حَنَابِلَةٌ</span> <a href="#HanobalieBN">is pl. of <span class="ar">حَنْبَلِىٌّ</span></a>;]</span> erroneously written in some of the copies of the Ḳ <span class="ar">تتابعة</span>: <span class="auth">(TA:)</span> the <span class="ar">تبابعة</span> of Himyer were like the <span class="ar">أَكَاسِرَة</span> of the Persians and the <span class="ar">قَيَاصِرَة</span> of the Romans. <span class="auth">(Lth.)</span> In the Ḳur xliv. 36, it is said in a trad. to mean a particular king, who was a believer, and whose people were unbelievers. <span class="auth">(Zj.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تُبَّعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tubBaEN_A2">
					<p>And hence, <span class="auth">(TA,)</span> <em>A species of the</em> <span class="ar">يَعَاسِيب</span> <span class="add">[or <em>kings of the bees</em>]</span>, <span class="auth">(Ḳ,)</span> <em>the greatest and most beautiful thereof, whom the other bees follow:</em> <span class="auth">(TA:)</span> pl. <span class="ar">تَبَابِيعُ</span>; <span class="auth">(Ḳ;)</span> in the L, <span class="ar">تَتَابِعُ</span> <span class="add">[which is probably a mistranscription for <span class="ar">تَبَابِعُ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تُبَّعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tubBaEN_A3">
					<p><em>A species of</em> <span class="ar">طَيْر</span> <span class="add">[which means any <em>flying things,</em> as well as <em>birds;</em> and may therefore, perhaps, be meant to indicate what next precedes]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تُبَّعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tubBaEN_A4">
					<p>The <em>shade,</em> or <em>shadow;</em> <span class="auth">(Ṣ, Ḳ;)</span> because it follows the sun; as also<span class="arrow"><span class="ar">تُبُّعٌ↓</span></span>. <span class="auth">(Ḳ.)</span> A poet says, <span class="auth">(Ṣ,)</span> namely, Soadà El-Juhaneeyeh, <span class="auth">(TA,)</span> or Selmà El-Juhaneeyeh, <span class="auth">(marginal note in a copy of the Ṣ,)</span> bewailing her brother, As'ad,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَرِدُ المِيَاهُ حَضِيرَةٌ وَنَفِيضَةً</span> *</div> 
						<div class="star">* <span class="ar long">وِرْدَ القَطَاةِ إِذَا ٱسْمَأَلَّ التُّبَّعُ</span> *</div> 
					</blockquote>
					<p><span class="auth">(Ṣ)</span> <span class="add">[<em>He comes to the waters when people are dwelling,</em> or <em>staying, there,</em> <span class="auth">(but <a href="#HaDiyrapN">see <span class="ar">حَضِيرَةٌ</span></a>,)</span> <em>and when no one is there, as the</em> bird called <em>katáh comes to water</em>]</span> <em>when the shade has become contracted at mid-day:</em> or, accord. to Aboo-Leylà, the meaning is, <em>the shade of night;</em> i. e., this man comes to the waters in the last part of the night, before any one: though it means also the shade of day-time: <span class="auth">(TA:)</span> or, accord. to Aboo-Saʼeed Ed-Dareer, the meaning here is <span class="add">[<em>the star,</em> or <em>asterism, called</em>]</span> <span class="ar">الدَّبَرَان</span>; and this is very probably correct; for the bird above mentioned comes to the waters by night, and seldom by day; and hence the saying, <span class="ar long">أَدَلُّ مِنْ قَطَاةٍ</span>. <span class="auth">(Az, TA.)</span> <a href="#taAbiEN">See <span class="ar">تَابِعٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تُبَّعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tubBaEN_A5">
					<p><a href="#tiboEN">See also <span class="ar">تِبْعٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تُبَّعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tubBaEN_A6">
					<p><span class="ar long">مَا أَدْرِى أَىُّ تُبَّعٍ هُوَ</span> <em>I know not who of men he is.</em> <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تُبَّعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="tubBaEN_A7">
					<p><span class="ar">تُبَّعٌ</span> is also <a href="#taAbiEN">a pl. of <span class="ar">تَابِعٌ</span> <span class="add">[q. v.]</span></a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tubBuEN">
				<h3 class="entry"><span class="ar">تُبُّعٌ</span></h3>
				<div class="sense" id="tubBuEN_A1">
					<p><span class="ar">تُبُّعٌ</span>: <a href="#tubBaEN">see <span class="ar">تُبَّعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabBuwEu">
				<h3 class="entry"><span class="ar">تَبُّوعُ</span></h3>
				<div class="sense" id="tabBuwEu_A1">
					<p><span class="ar long">تَبُّوعُ الشَّمْسِ</span> <em>A certain wind,</em> <span class="auth">(Ḳ, TA,)</span> <em>also called</em> <span class="ar">النُّكَيْبَآءُ</span>, <span class="auth">(TA,)</span> <em>which blows</em> <span class="auth">(Ḳ, TA)</span> <em>in the early morning,</em> <span class="auth">(TA,)</span> <em>with the rising of the sun,</em> <span class="auth">(Ḳ, TA,)</span> <em>from the direction of the wind called</em> <span class="ar">الصَّبَا</span>, <em>unaccompanied by rising clouds,</em> <span class="auth">(TA,)</span> <em>and veers round through the various places whence winds blow until it returns to the place from which blows the wind called</em> <span class="ar">الصبا</span>, <span class="auth">(Ḳ, TA,)</span> <em>whence it commenced in the early morning:</em> <span class="auth">(TA:)</span> the Arabs dislike it. <span class="auth">(Z, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAbiEN">
				<h3 class="entry"><span class="ar">تَابِعٌ</span></h3>
				<div class="sense" id="taAbiEN_A1">
					<p><span class="ar">تَابِعٌ</span> <em>Following; a follower:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">تَبَعٌ↓</span></span> also signifies the same as <span class="ar">تَابِعٌ</span>; <span class="auth">(Ḳ;)</span> <em>a thing that follows in the track</em> of a thing; <span class="auth">(Lth, Az;)</span> or <em>that is at the kinder,</em> or <em>latter, part</em> of anything; <span class="auth">(TA;)</span> but is used alike as sing. and pl.: <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> <a href="#taAbiEN">the pl. of <span class="ar">تَابِعٌ</span></a> is <span class="ar">تُبَّعٌ</span> and <span class="ar">تُبَّاعٌ</span> <span class="auth">(TA)</span> <span class="add">[and, applied to rational beings, <span class="ar">تَابِعُونَ</span>]</span>: and the pl. of<span class="arrow"><span class="ar">تَبَعٌ↓</span></span> is <span class="ar">أَتْبَاعٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> or this may be used <a href="#tabaEN">as a pl. of <span class="ar">تَبَعٌ</span></a>; <span class="auth">(Mṣb;)</span> <span class="pb" id="Page_0296"></span>or it <a href="#taAbiEN">is pl. of <span class="ar">تَابِعٌ</span></a>, like as <span class="ar">خَدَمٌ</span> <a href="#xaAdimN">is pl. of <span class="ar">خَادِمٌ</span></a>, <span class="auth">(Kr, Mgh,)</span> and <span class="ar">طَلَبٌ</span> of <span class="ar">طَالِبٌ</span>, &amp;c.; <span class="auth">(Ḳ;)</span> or, correctly speaking, it is a quasi-pl. n. <span class="auth">(Sb, TA.)</span> You say,<span class="arrow"><span class="ar long">المُصَلِّى تَبَعٌ↓ لاِمَامِهِ</span></span> <span class="add">[<em>The person praying is a follower of his Imám</em>]</span>: and <span class="ar long">النَّاسُ تَبَعٌ لَهُ</span> <span class="add">[<em>The people are followers of him</em>]</span>. <span class="auth">(Mṣb.)</span> And it is said in the Ḳur <span class="add">[xiv. 24, and xl. 50]</span>, <span class="arrow"><span class="ar long">إِنَّا كُنَّا لَكُمْ تَبَعًا↓</span></span> <span class="add">[<em>Verily we were followers of you</em>]</span>: <span class="auth">(Ṣ, TA:)</span> in which the last word may be a quasi-pl. n. of <span class="ar">تَابِعٌ</span>; or it may be an inf. n., meaning <span class="ar long">ذَوِى تَبَعٍ</span>. <span class="auth">(TA.)</span> <span class="arrow"><span class="ar">تَبَعٌ↓</span></span> is applied as an epithet to the legs of a beast: <span class="auth">(Lth, T:)</span> and is also used as <span class="add">[an epithet in which the quality of a subst. is predominant,]</span> signifying The <em>legs of a beast.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAbiEN_A2">
					<p><em>A jinnee,</em> or <em>genie, that accompanies a woman and follows her whithersoever she goes,</em> <span class="auth">(Ḳ, TA,)</span> <em>loving her:</em> <span class="auth">(TA:)</span> and <span class="ar">تَابِعَةٌ</span> <em>a jinneeyeh,</em> or <em>female genie, that does the same to a man:</em> <span class="auth">(Ṣ,* Ḳ, TA:)</span> or the <span class="ar">ة</span> is added in the latter to give intensiveness to the signification, or to denote evilness of nature, or to convey the meaning of <span class="ar">دَاهِيَةٌ</span>, q. v.: the pl. is <span class="ar">تَوَابِعُ</span>: and this means <em>female associates.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taAbiEN_A3">
					<p><em>A servant;</em> as also<span class="arrow"><span class="ar">تَبِيعٌ↓</span></span>. <span class="auth">(TA.)</span> <span class="ar long">أَوِ التَّابِعِينَ غَيْرِ أُولِى الإِرْبَةِ</span>, in the Ḳur <span class="add">[xxiv. 31]</span>, accord. to Th, means <em>Or the servants</em> of the husband, <em>such as the old man who is perishing by reason of age, and the aged woman.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taAbiEN_A4">
					<p><a href="#tabiyEN">See also <span class="ar">تَبِيعٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="taAbiEN_A5">
					<p><span class="add">[Also <em>One next in the order of time after the</em> <span class="ar">صَحَابَة</span>; like<span class="arrow"><span class="ar">تَابِعِىٌّ↓</span></span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="taAbiEN_A6">
					<p><span class="add">[And in grammar, <em>An appositive.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">تَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="taAbiEN_A7">
					<p><span class="ar long">تَابِعُ النَّجْمِ</span> <span class="add">[<em>The follower of the asterism;</em> i. e., <em>of the Pleiades;</em>]</span> <em>a name of</em> <span class="ar">الدَّبَرَان</span> <span class="add">[<em>the Hyades;</em> or <em>the five chief stars thereof;</em> or <em>the brightest star among them, a of Taurus</em>]</span>: this name being given to it as ominous of good; <span class="auth">(Ḳ;)</span> or as ominous of evil: <span class="auth">(O:)</span> or so called because it follows the Pleiades: <span class="auth">(T:)</span> also called <span class="ar">التَّابِعُ</span>, <span class="auth">(T in art. <span class="ar">دبر</span>, Sh, IB, and others,)</span> and<span class="arrow"><span class="ar">تُوَيْبِعٌ↓</span></span>, <span class="auth">(Ḳ,)</span> which is the dim., <span class="auth">(TA,)</span> or <span class="ar">التُّوَيْبِعُ</span>, <span class="auth">(T in art. <span class="ar">دبر</span>,)</span> and<span class="arrow"><span class="ar">تُبَّعٌ↓</span></span>, <span class="auth">(Ḳ,)</span> or <span class="ar">التُّبَّعُ</span> <span class="add">[q. v.]</span>, <span class="auth">(Aboo-Saʼeed Ed-Dareer, T,)</span> and<span class="arrow"><span class="ar">التَّبَعُ↓</span></span>, <span class="auth">(IB, Z,)</span> and <span class="ar">التَّالِى</span>, and <span class="ar">الحَادِى</span>, <span class="auth">(IB,)</span> or <span class="ar long">حادى النُّجُومِ</span>, <span class="auth">(Ṣ in art. <span class="ar">جدح</span>,)</span> or <span class="ar long">حادى النَّجْمِ</span>. <span class="auth">(Ḳzw and others.)</span> <span class="add">[<a href="#AlmijodaHu">See also <span class="ar">المِجْدَحُ</span></a>.]</span> <span class="ar">تَابِعِىٌّ</span>: <a href="#taAbiEN">see <span class="ar">تَابِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuwayobiEN">
				<h3 class="entry"><span class="ar">تُوَيْبِعٌ</span></h3>
				<div class="sense" id="tuwayobiEN_A1">
					<p><span class="ar">تُوَيْبِعٌ</span>: <a href="#taAbiEN">see <span class="ar">تَابِعٌ</span></a>, last sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IitobaAEN">
				<h3 class="entry"><span class="ar">إِتْبَاعٌ</span></h3>
				<div class="sense" id="IitobaAEN_A1">
					<p><span class="ar">إِتْبَاعٌ</span> in language is when one says the like of <span class="ar long">حَسَنٌ بَسَنٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar long">قَبِيحٌ شَقِيحٌ</span>: <span class="auth">(Ṣ:)</span> The <em>putting, after a word, an imitative sequent,</em> i. e. <em>another word similar to the former in measure or in its</em> <span class="ar">رَوِىّ</span>, <em>by way of pleonasm, or for fulness of expression, and for corroboration;</em> <span class="auth">(Mz 28th <span class="ar">نوع</span>, and Kull p. 11;)</span> <em>the latter word being one not used alone, and having no meaning by itself, as in</em> <span class="ar long">حَسَنٌ بَسَنٌ</span>; <em>or being one which has a meaning of its own, as in</em> <span class="ar long">هَنِيْئًا مَرِيْئًا</span>. <span class="auth">(Kull ubi suprà.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">إِتْبَاعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="IitobaAEN_A2">
					<p><span class="add">[Also The <em>latter of such two words;</em> i. e. <em>an imitative sequent.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">إِتْبَاعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="IitobaAEN_A3">
					<p><span class="add">[And used in the former sense, as an inf. n., it denotes various other kinds of assimilation, i. e., of one word to another preceding or following it, and of one vowel to another preceding or following it in the same word.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutobiEN">
				<h3 class="entry"><span class="ar">مُتْبِعٌ</span></h3>
				<div class="sense" id="mutobiEN_A1">
					<p><span class="ar">مُتْبِعٌ</span> She <em>who has with her children,</em> or <em>young ones:</em> <span class="auth">(Lḥ:)</span> or a ewe, or she-goat, and a cow, and a girl, <em>having her offspring following her:</em> <span class="auth">(Ḳ:)</span> or a cow <em>having a</em> <span class="ar">تَبِيع</span>, q. v.: and IB mentions also <span class="ar">مُتْبِعَةٌ</span> as signifying the same: and a female servant <em>followed by her offspring whither she comes and goes.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matobuwEN">
				<h3 class="entry"><span class="ar">مَتْبُوعٌ</span></h3>
				<div class="sense" id="matobuwEN_A1">
					<p><span class="ar">مَتْبُوعٌ</span> <span class="add">[pass. part. n. of 1.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">مَتْبُوعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="matobuwEN_A2">
					<p><span class="add">[In grammar, The <em>antecedent of a</em> <span class="ar">تَابِع</span>, i. e., <em>of an appositive.</em>]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaAbaEN">
				<h3 class="entry"><span class="ar">مُتَابَعٌ</span></h3>
				<div class="sense" id="mutaAbaEN_A1">
					<p><span class="ar">مُتَابَعٌ</span> † Anything <em>made,</em> or <em>executed, soundly, thoroughly, well,</em> or <em>so as to be free from defect.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutataAbiEN">
				<h3 class="entry"><span class="ar">مُتَتَابِعٌ</span></h3>
				<div class="sense" id="mutataAbiEN_A1">
					<p><span class="ar">مُتَتَابِعٌ</span> <em>Consecutive, successive,</em> or <em>uninterrupted, in its progressions,</em> or <em>gradations,</em> or <em>the like.</em> <span class="auth">(TA.)</span> You say <span class="ar long">لُؤْلُؤٌ مُتَتَابِعٌ</span> <em>Pearls following one another,</em> or <em>doing so in uninterrupted order.</em> <span class="auth">(TA.)</span> And <span class="ar long">صِيَامُ شَهْرَيْنِ مُتَتَابِعَيْنِ</span> <em>The fasting of two consecutive months.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبع</span> - Entry: <span class="ar">مُتَتَابِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutataAbiEN_A2">
					<p><span class="ar long">غُصْنٌ مُتَتَابِعٌ</span> ‡ <em>An even,</em> or <em>a uniform, branch, in which are no knots.</em> <span class="auth">(Ḳ,* TA.)</span> And <span class="ar long">فَرَسٌ مُتَتَابِعُ الخَلْقِ</span> ‡ <em>A horse symmetrical in make,</em> <span class="auth">(A, Ḳ,)</span> <em>justly proportioned in his limbs</em> or <em>parts.</em> <span class="auth">(A, TA.)</span> And <span class="ar long">رَجُلٌ مُتَتَابِعُ العِلْمِ</span> ‡ <em>A man whose knowledge is uniform, consistent, without incongruity.</em> <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0293.pdf" target="pdf">
							<span>Lanes Lexicon Page 293</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0294.pdf" target="pdf">
							<span>Lanes Lexicon Page 294</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0295.pdf" target="pdf">
							<span>Lanes Lexicon Page 295</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0296.pdf" target="pdf">
							<span>Lanes Lexicon Page 296</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
