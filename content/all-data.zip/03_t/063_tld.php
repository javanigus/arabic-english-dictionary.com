<article class="root" id="Root_tld">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/062_tlj">تلج</a></span>
				<span class="ar">تلد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/064_tlE">تلع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tld_1">
				<h3 class="entry">1. ⇒ <span class="ar">تلد</span></h3>
				<div class="sense" id="tld_1_A1">
					<p><span class="ar">تَلَدَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْلِدُ</span>}</span></add>; <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> and <span class="ar">ـُ</span>, <span class="auth">(T, sudot;, M, Ḳ,)</span> inf. n. <span class="ar">تُلُودٌ</span>; <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> <span class="add">[and<span class="arrow"><span class="ar">اِتَّلَدَ↓</span></span>; <span class="auth">(see Ḥam p. 699;)</span>]</span> <em>It</em> <span class="auth">(property, consisting of camels or the like, syn. <span class="ar">مَالٌ</span>, T, Ṣ, M, &amp;c.)</span> <em>was,</em> or <em>became, old,</em> or <em>long-possessed;</em> <span class="auth">(Mṣb;)</span> <em>such as is termed</em> <span class="ar">تِلَاد</span>. <span class="auth">(T, Ṣ, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tld_1_A2">
					<p><span class="ar long">تَلَدَ فُلَانٌ عِنْدَنَا</span> <em>Such a one was born of parents at our abode,</em> or <em>home.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tld_1_A3">
					<p>And <span class="ar">تَلَدَ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُدُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> inf. n. as above; <span class="auth">(T, L;)</span> and <span class="ar">تَلِدَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْلَدُ</span>}</span></add>; <span class="auth">(Ḳ;)</span> <em>He remained, stayed, abode,</em> or <em>dwelt,</em> <span class="auth">(Aṣ, T, Ṣ, M, Ḳ,)</span> <span class="ar long">فِى بَنِى فُلَانٍ</span> <em>among the sons of such a one,</em> <span class="auth">(Ṣ,)</span> and <span class="ar">بَيْنَهُمْ</span> <em>among them,</em> <span class="auth">(M,)</span> and <span class="ar">بِمَكَانٍ</span> <em>in a place.</em> <span class="auth">(Aṣ, T, L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tld_1_B1">
					<p><a href="#tld_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tld_2">
				<h3 class="entry">2. ⇒ <span class="ar">تلّد</span></h3>
				<div class="sense" id="tld_2_A1">
					<p><span class="ar">تلّد</span>, <span class="auth">(IAạr, T, Ḳ,)</span> inf. n. <span class="ar">تَتْلِيدٌ</span>; <span class="auth">(Ḳ;)</span> or<span class="arrow"><span class="ar">تَلَدَ↓</span></span>; <span class="auth">(so in the L as on the authority of IAạr, and accord. to Lḥ as is said in the TA;)</span> <em>i. q.</em> <span class="ar">جَمَعَ</span> <em>and</em> <span class="ar">مَنَعَ</span> <span class="add">[app. as meaning <em>He collected and defended</em> property]</span>; <span class="auth">(IAạr, T, L, Ḳ;)</span> said of a man. <span class="auth">(IAạr, T, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tld_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتلد</span></h3>
				<div class="sense" id="tld_4_A1">
					<p><span class="ar">اتلد</span>, <span class="auth">(T, Ṣ, L.)</span> and <span class="ar long">اتلد مَالًا</span>, <span class="auth">(T, M, Mṣb, Ḳ,)</span> <em>He got, obtained,</em> or <em>acquired,</em> (<span class="ar">اِتَّخَذَ</span>,) <em>property</em> <span class="add">[<em>such as is termed</em> <span class="ar">تِلَاد</span>, as is implied in the T and M and Ḳ]</span>: <span class="auth">(T, Ṣ, L, Mṣb:)</span> or <em>he possessed property such as is termed</em> <span class="ar">تِلَاد</span>. <span class="auth">(So accord. to the explanation of the act. part. n., q. v., in the Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tld_8">
				<span class="pb" id="Page_0312"></span>
				<h3 class="entry">8. ⇒ <span class="ar">اتّلد</span></h3>
				<div class="sense" id="tld_8_A1">
					<p><a href="#tld_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="talodN">
				<h3 class="entry"><span class="ar">تَلْدٌ</span></h3>
				<div class="sense" id="talodN_A1">
					<p><span class="ar">تَلْدٌ</span>: <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tulodN">
				<h3 class="entry"><span class="ar">تُلْدٌ</span></h3>
				<div class="sense" id="tulodN_A1">
					<p><span class="ar">تُلْدٌ</span>: <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تُلْدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tulodN_A2">
					<p>Also The <em>young one of an eagle.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taladN">
				<h3 class="entry"><span class="ar">تَلَدٌ</span></h3>
				<div class="sense" id="taladN_A1">
					<p><span class="ar">تَلَدٌ</span>: <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تَلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taladN_A2">
					<p><a href="#taliydN">and <span class="ar">تَلِيدٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tilaAdN">
				<h3 class="entry"><span class="ar">تِلَادٌ</span></h3>
				<div class="sense" id="tilaAdN_A1">
					<p><span class="ar">تِلَادٌ</span>, applied to <span class="ar">مَال</span> <span class="add">[i. e. property, consisting of camels or the like]</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> <em>Old,</em> or <em>long-possessed;</em> as also<span class="arrow"><span class="ar">تَالِدٌ↓</span></span> and<span class="arrow"><span class="ar">تَلِيدٌ↓</span></span>, <span class="auth">(Mgh, Mṣb,)</span> both of these meaning <em>old, original,</em> property, <span class="auth">(A,)</span> and<span class="arrow"><span class="ar">مُتْلَدٌ↓</span></span>: <span class="auth">(L:)</span> or <em>original, old,</em> or <em>long-possessed, born at one's own abode,</em> or <em>home;</em> as also<span class="arrow"><span class="ar">تَالِدٌ↓</span></span> and<span class="arrow"><span class="ar">إِتْلَادٌ↓</span></span>: <span class="auth">(Ṣ:)</span> <em>contr. of</em> <span class="ar">طَارِفٌ</span> <span class="auth">(Ṣ, A, Mgh, Mṣb)</span> <em>and</em> <span class="ar">طَرِيفٌ</span>: <span class="auth">(Mgh, Mṣb:)</span> or <em>born at the owner's abode,</em> or <em>house;</em> or <em>that brings forth there;</em> <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَالِدٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">تَلْدٌ↓</span></span> and<span class="arrow"><span class="ar">تُلْدٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">تَلَدٌ↓</span></span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">تِليدٌ↓</span></span> and<span class="arrow"><span class="ar">إِتْلَادٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> like <span class="ar">إِسْنَامٌ</span>, <span class="auth">(M, <span class="add">[in the CK written <span class="ar">اَتْلأَد</span>, and so accord. to the MṢ,]</span>)</span> and<span class="arrow"><span class="ar">مُتْلَدٌ↓</span></span>; <span class="auth">(M, Ḳ; <span class="add">[written in a copy of the M <span class="ar">مُتَلّد</span>;]</span>)</span> wherefore, <span class="add">[i. e. because of the meaning,]</span> Yaakoob judges that the <span class="ar">ت</span> is a substitute for <span class="ar">و</span>; <span class="add">[as is said to be the case in the Ṣ;]</span> but this is not a valid decision; for, were it so, the word in some of its variations would be reduced to its original: <span class="auth">(M:)</span> or any <em>old,</em> or <em>long-possessed,</em> property, <span class="auth">(T, M, L,)</span> consisting of animals, &amp;c., <span class="auth">(M, L,)</span> <em>inherited from parents;</em> <span class="auth">(T, M, L;)</span> as also<span class="arrow"><span class="ar">تَالِدٌ↓</span></span> <span class="auth">(T, L)</span> and<span class="arrow"><span class="ar">تَلِيدٌ↓</span></span> and<span class="arrow"><span class="ar">مُتْلَدٌ↓</span></span> <span class="auth">(T, M, L <span class="add">[the last written in a copy of the T <span class="ar">مٌتْلِدٌ</span>, and in a copy of the M <span class="ar">مُتَلّد</span>,]</span>)</span> and<span class="arrow"><span class="ar">تَلْدٌ↓</span></span> and<span class="arrow"><span class="ar">تُلْدٌ↓</span></span> and<span class="arrow"><span class="ar">إِتْلَادٌ↓</span></span>, as above: <span class="auth">(M:)</span> or slaves, or pasturing beasts, <em>that breed at one's own abode,</em> or <em>home, and become old,</em> or <em>long possessed:</em> <span class="auth">(ISh, as related by Sh:)</span> or that <em>which you yourself breed,</em> or <em>rear.</em> <span class="auth">(Aṣ, T.)</span> <span class="add">[<a href="#taliydN">See also <span class="ar">تَلِيدٌ</span>, below</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تِلَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tilaAdN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">هُنَّ مِنْ تِلَادِى</span>, said by a man, <span class="auth">(namely, Ibn-Mesʼood, M,)</span> in reference to certain chapters (<span class="ar">سُوَر</span>) of the Ḳur-án, meaning ‡ <em>They are of those which I acquired</em> <span class="auth">(or <em>learned,</em> L)</span> <em>long ago</em> from the Ḳur-án: <span class="auth">(Ṣ, M, L:)</span> thus saying, he likened them to the property, or camels, &amp;c., called <span class="ar">تِلَادٌ</span>. <span class="auth">(M, L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تِلَادٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tilaAdN_A3">
					<p><span class="add">[Az says,]</span> I heard a man of Mekkeh say, <span class="ar">تِلَادِىبِمَكَّةَ</span>, i. e. <span class="ar">مِيلَادِى</span> <span class="add">[app. meaning <em>My birth was in Mekkeh</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taliydN">
				<h3 class="entry"><span class="ar">تَلِيدٌ</span> / <span class="ar">تَلِيدَةٌ</span></h3>
				<div class="sense" id="taliydN_A1">
					<p><span class="ar">تَلِيدٌ</span>: <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تَلِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taliydN_A2">
					<p>Also That <em>which is born at the abode,</em> or <em>home, of another than thyself, and which, while young, thou afterwards purchasest, and which remains with thee:</em> <span class="auth">(Aṣ, T.)</span> or one <em>who is born in a foreign country, and is carried away while young to the territory of the Arabs:</em> <span class="auth">(Mgh:)</span> or one <em>who is born in a foreign country, and then brought away while young, and who grows up in the territory of the Muslims;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَلَدٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or <em>i. q.</em> <span class="ar">مُوَلَّدٌ</span> and <span class="ar">مُوَلَّدَةٌ</span>, <span class="add">[masc. and fem.,]</span> meaning one <em>that is born at thine own abode,</em> or <em>home:</em> <span class="auth">(ISh, T: <span class="add">[<a href="#tilaAdN">see also <span class="ar">تِلَادٌ</span></a>:]</span>)</span> or one <em>who has parents at thine own abode,</em> or <em>home;</em> whereas <span class="ar">مُوَلَّدٌ</span> signifies one who has only one parent there: <span class="auth">(Mgh, from the Tekmileh <span class="add">[of the ʼEyn]</span>:)</span> the fem. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَلِيدَةٌ</span>}</span></add>; <span class="auth">(Ṣ;)</span> signifying a female slave <em>who is born in a foreign country, and is carried away, and grows up in the territory of the Arabs:</em> <span class="auth">(Ḳṭ, T:)</span> or a female slave <em>whose father and family and all her relations are in one country and who is herself in another:</em> <span class="auth">(ISh, L in art. <span class="ar">ولد</span>:)</span> or a female slave <em>born the property of a people with whom are her parents:</em> <span class="auth">(L in art. <span class="ar">ولد</span>:)</span> or a female slave <em>inherited by her owner;</em> if born at his own abode, or home, <span class="add">[of a mother already belonging to him,]</span> she is called <span class="ar">وَلِيدَةٌ</span>: <span class="auth">(T, L:)</span> you say <span class="ar long">رَجُلٌ تَلِيدٌ</span>; pl. <span class="ar">تُلَدَآءُ</span>: and <span class="ar long">اِمْرَأَةٌ تَلِيدٌ</span> <span class="add">[and <span class="ar">تَلِيدَةٌ</span>]</span>; pl. <span class="ar">تَلَائِدُ</span> <span class="auth">(Lḥ, M, L)</span> and <span class="ar">تُلُدٌ</span>. <span class="auth">(Lḥ, L.)</span> It is related in a trad. of Shureyh, that a man purchased a female slave, and the two parties made it a condition that she should be a <span class="ar">مُوَلَّدَة</span>; but the purchaser found her to be a <span class="ar">تَلِيدَة</span>, and therefore returned her: <span class="auth">(Ṣ, Mgh:)</span> a <span class="ar">مُوَلَّدَة</span> is like a <span class="ar">تِلَاد</span>, i. e. born at thine own abode, or home; <span class="auth">(Ṣ;)</span> or born in the territory of the Muslims. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تَلِيدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taliydN_A3">
					<p>Also, metaphorically, ‡ <em>A child,</em> absolutely. <span class="auth">(Ḥar p. 317.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taAlidN">
				<h3 class="entry"><span class="ar">تَالِدٌ</span></h3>
				<div class="sense" id="taAlidN_A1">
					<p><span class="ar">تَالِدٌ</span>: <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>, in four places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">تَالِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAlidN_A2">
					<p><span class="ar long">تَالِدٌ بَالِدٌ</span>: <a href="index.php?data=02_b/171_bld">see art. <span class="ar">بلد</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="IitolaAdN">
				<h3 class="entry"><span class="ar">إِتْلَادٌ</span></h3>
				<div class="sense" id="IitolaAdN_A1">
					<p><span class="ar">إِتْلَادٌ</span>, by some written <span class="ar">أَتْلَادٌ</span>: <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutoladN">
				<h3 class="entry"><span class="ar">مُتْلَدٌ</span></h3>
				<div class="sense" id="mutoladN_A1">
					<p><span class="ar">مُتْلَدٌ</span>, applied to <span class="ar">مَال</span>, <span class="auth">(Ṣ, Mṣb,)</span> pass. part. n. of 4: <span class="auth">(Mṣb:)</span> <a href="#tilaAdN">see <span class="ar">تِلَادٌ</span></a>, in three places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">مُتْلَدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutoladN_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">خُلُقٌ مُتْلَدٌ</span>, <span class="auth">(M, L, TA,)</span> in the Ḳ, <span class="ar">مُتَلَّدٌ</span>, said to be like <span class="ar">مُعَظَّمٌ</span>, but this is a mistake, <span class="auth">(TA,)</span> <span class="add">[and in the CK, <span class="ar">خَلْقٌ</span> is erroneously put for <span class="ar">خُلُقٌ</span>,]</span> † <em>An old,</em> or <em>a long-possessed, natural disposition,</em> or <em>quality.</em> <span class="auth">(M, L, Ḳ.)</span> IAạr cites as an ex. this verse:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">مَا ذَا رُزِينَا مِنْكِ أَمَّ مَعْبَدِ</span> *</div> 
						<div class="star">* <span class="ar long">مِنْ سَعَةِ الحِلْمِ وَخُلْقٍ مُتْلَد</span> *</div> 
					</blockquote>
					<p><span class="add">[app. meaning <em>What has been experienced from us, on thy part, Umm-Maabad, of largeness of forbearance, and of long-possessed good natural dispositions,</em> or <em>qualities?</em> <span class="ar">رُزِينَا</span> seems to be here used for <span class="ar">رُزِئْنَا</span>; or the latter may be the correct reading]</span>. <span class="auth">(M, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutolidN">
				<h3 class="entry"><span class="ar">مُتْلِدٌ</span></h3>
				<div class="sense" id="mutolidN_A1">
					<p><span class="ar">مُتْلِدٌ</span> <span class="add">[act. part. n. of 4:]</span> <em>A possessor of property such as is termed</em> <span class="ar">تِلَاد</span>: and hence,</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلد</span> - Entry: <span class="ar">مُتْلِدٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutolidN_A2">
					<p><em>A first owner</em> or <em>proprietor;</em> as the weaver of a piece of cloth, and the man who delivers his she-camel <span class="add">[and is owner of her young one]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0311.pdf" target="pdf">
							<span>Lanes Lexicon Page 311</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0312.pdf" target="pdf">
							<span>Lanes Lexicon Page 312</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
