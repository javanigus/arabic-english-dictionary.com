<article class="root" id="Root_trE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/030_trs">ترس</a></span>
				<span class="ar">ترع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/032_trf">ترف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trE_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترع</span></h3>
				<div class="sense" id="trE_1_A1">
					<p><span class="ar">تَرِعَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَعُ</span>}</span></add>, inf. n. <span class="ar">تَرَعٌ</span>, <em>It</em> <span class="auth">(a vessel, Ṣ, or a thing, TA)</span> <em>was,</em> or <em>became, full,</em> or <em>filled;</em> <span class="auth">(Ṣ, Z, Ḳ;)</span> as also<span class="arrow"><span class="ar">اِتَّرَعَ↓</span></span>: <span class="auth">(Ṣgh, Ḳ:)</span> or <em>it was,</em> or <em>became, very full,</em> or <em>much filled.</em> <span class="auth">(Lth, in TA. <span class="add">[But it is said in the TA, in one place, that Lth ignored the verb in this sense; and in another place, that he said, I have not heard them say, <span class="ar long">تَرِعَ الإِنَآءُ</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trE_1_B1">
					<p><em>He hastened to do evil,</em> or <em>mischief;</em> <span class="auth">(Ks, Ḳ;)</span> and <em>to do a thing:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar long">تترّع↓ بِهِ إِلَى الشَّرِّ</span></span>, accord. to the Ḳ; but accord. to the Ṣ and O and L, <span class="arrow"><span class="ar long">تترّع↓ إِلَيْهِ بِالشَّرِّ</span></span>; <span class="auth">(TA;)</span> <em>he hastened to him to do evil,</em> or <em>mischief.</em> <span class="auth">(Ṣ, O, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="trE_1_B2">
					<p><em>He rushed headlong into affairs by reason of excessive briskness, liveliness,</em> or <em>sprightliness.</em> <span class="auth">(Lth, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="trE_1_C1">
					<p><span class="ar">تَرَعَهُ</span>, inf. n. <span class="ar">تَرَعٌ</span>, <span class="add">[app. a mistake for <span class="ar">تَرْعٌ</span>,]</span> <em>He hastened to him, forbidding</em> <span class="add">[<em>him to do a thiug</em>]</span>. <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="trE_1_C2">
					<p><span class="ar long">تَرَعَهُ عَنْ وَجْهِهِ</span> <em>He averted him,</em> or <em>turned him back, from his course,</em> or <em>manner of acting</em> or <em>proceeding.</em> <span class="auth">(Ibn-ʼAbbád, Ṣgh, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trE_2">
				<h3 class="entry">2. ⇒ <span class="ar">ترّع</span></h3>
				<div class="sense" id="trE_2_A1">
					<p><span class="ar long">ترّع البَابَ</span>, inf. n. <span class="ar">تَتْرِيعٌ</span>, <em>He locked,</em> or <em>closed, the door;</em> syn. <span class="ar">أَغْلَقَهُ</span> <span class="add">[which has both these significations]</span>. <span class="auth">(Ḳ.)</span> In the Ḳur <span class="add">[xii. 23]</span>, some read, <span class="ar long">وَتَرَّعَتِ الأَبْوابَ</span> <em>And she locked,</em> or <em>closed, the doors,</em> instead of <span class="ar">غَلَّقَت</span>. <span class="auth">(O, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trE_4">
				<h3 class="entry">4. ⇒ <span class="ar">اترع</span></h3>
				<div class="sense" id="trE_4_A1">
					<p><span class="ar">اترعهُ</span> <em>He filled it;</em> <span class="auth">(Ṣ, Ḳ;)</span> namely, a. vessel. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trE_5">
				<h3 class="entry">5. ⇒ <span class="ar">تترّع</span></h3>
				<div class="sense" id="trE_5_A1">
					<p><a href="#trE_1">see 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trE_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّرع</span></h3>
				<div class="sense" id="trE_8_A1">
					<p><a href="#trE_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taraEN">
				<h3 class="entry"><span class="ar">تَرَعٌ</span></h3>
				<div class="sense" id="taraEN_A1">
					<p><span class="ar">تَرَعٌ</span> <em>Full;</em> applied to a watering-trough or tank for beasts, &amp;c.; <span class="auth">(Ṣ, Ḳ;)</span> and to a mug: <span class="auth">(Ṣ:)</span> an inf. n. used as an epithet: <span class="auth">(TA:)</span> the regular form is <span class="arrow"><span class="ar">تَرِعٌ↓</span></span>, which signifies the same. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tariEN">
				<h3 class="entry"><span class="ar">تَرِعٌ</span> / <span class="ar">تَرِعَةٌ</span></h3>
				<div class="sense" id="tariEN_A1">
					<p><span class="ar">تَرِعٌ</span>: <a href="#taraEN">see <span class="ar">تَرَعٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tariEN_A2">
					<p>Also A cloud <em>containing much rain.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tariEN_A3">
					<p><span class="ar long">عُشْبٌ تَرِعٌ</span> <em>Fresh, juicy,</em> or <em>sappy, herbs</em> or <em>herbage.</em> <span class="auth">(Ṣgh in art. <span class="ar">درع</span>, and L.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرِعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tariEN_B1">
					<p>A man <em>quick to do evil,</em> or <em>mischief,</em> <span class="auth">(Ks, Ṣ,)</span> <em>and to become angry:</em> <span class="auth">(Ṣ:)</span> <em>ready and quick to become angry:</em> and<span class="arrow"><span class="ar">مُتْتَرِعٌ↓</span></span> <em>evil,</em> or <em>mischievous, hastening to do what is not fit,</em> or <em>proper, for him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tariEN_B2">
					<p>One <em>who rushes headlong into affairs by reason of excessive briskness, liveliness,</em> or <em>sprightliness:</em> <span class="auth">(O, L, TA:)</span> thus correctly written; but in the copies of the Ḳ, <span class="arrow"><span class="ar">تَرِيعٌ↓</span></span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="tariEN_B3">
					<p><em>Lightwitted; weak and stupid; deficient in intellect;</em> or <em>light and hasty in disposition</em> or <em>deportment.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="tariEN_B4">
					<p>And, with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَرِعَةٌ</span>}</span></add>, A woman <em>who transgresses the proper bounds</em> or <em>limits, and is light</em> <span class="add">[<em>in conduct</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turoEapN">
				<h3 class="entry"><span class="ar">تُرْعَةٌ</span></h3>
				<div class="sense" id="turoEapN_A1">
					<p><span class="ar">تُرْعَةٌ</span> The <em>mouth of a streamlet</em> or <em>rivulet;</em> <span class="auth">(IB, Mṣb, Ḳ;)</span> i. e. <em>a place hollowed out by the water in the side of a river, whence it flows forth:</em> <span class="auth">(Mṣb:)</span> pl. <span class="ar">تُرَعٌ</span> <span class="auth">(IB, Mṣb)</span> and <span class="ar">تُرْعَاتٌ</span> and <span class="ar">تُرَعَاتٌ</span> and <span class="ar">تُرُعَاتٌ</span>: <span class="auth">(Mṣb:)</span> in the Ṣ it is said to signify the <em>mouths of streamlets</em> or <em>rivulets;</em> but correctly the sentence should be, <span class="ar">تُرَعٌ</span> <a href="#turoEapN">is pl. of <span class="ar">تُرْعَةٌ</span></a>, and has this signification. <span class="auth">(IB.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تُرْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="turoEapN_A2">
					<p><em>A canal,</em> or <em>channel of water, to a meadow</em> or <em>garden</em> or <em>the like:</em> <span class="auth">(L, TA:)</span> this is the meaning commonly known <span class="add">[in the present day: the general name in Egypt for a canal cut for the purpose of irrigation, conveying the water of the Nile through the adjacent fields]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تُرْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="turoEapN_A3">
					<p>The <em>opening,</em> or <em>gap,</em> of a wateringtrough or tank, <em>by which the water enters, and where the people draw it:</em> <span class="auth">(Az, Mgh,* Ḳ,* TA:)</span> and, <span class="auth">(Ḳ,)</span> accord. to AA, <span class="auth">(TA,)</span> the <em>station of the drinkers at the watering-trough</em> or <em>tank;</em> as in the O and Ḳ; or, as in the L, the <em>part</em> of the watering-trough or tank <em>which is the station of the drinkers.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تُرْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="turoEapN_A4">
					<p><em>A meadow,</em> or <em>garden,</em> or <em>the like,</em> <span class="auth">(Ṣ, Ḳ,)</span> <em>in an elevated place:</em> <span class="auth">(Ḳ:)</span> if in low land, it is called <span class="ar">رَوْضَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تُرْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="turoEapN_A5">
					<p><em>A stair;</em> or <em>a flight of steps by which one ascends;</em> syn. <span class="ar">دَرَجَةٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> so accord. to some in a trad., which see in what follows: <span class="auth">(Ṣ,* TA:)</span> and particularly the <em>flight of steps of a pulpit.</em> <span class="auth">(AA, Ṣgh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تُرْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="turoEapN_A6">
					<p>‡ <em>A door,</em> or <em>gate:</em> <span class="auth">(Ṣ, Ṣgh, Mṣb, Ḳ:)</span> pl. <span class="ar">تُرَعٌ</span>. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">فَتَحَ تُرْعَةَ الدَّارِ</span> ‡ <em>He opened the door of the house.</em> <span class="auth">(TA.)</span> And it is said in a trad., <span class="ar long">إِنَّ مِنْبَرِى هٰذَا عَلَى تُرْعَةٍ مِنْ تُرَعِ الجَنَّةِ</span>, <span class="auth">(Ṣ, TA,)</span> as though meaning, ‡ <em>Verily this my pulpit is at a gate of the gates of Paradise:</em> thus explained by Sahl Ibn-Saạd Es-Sá'idee, the relater of the trad.; and AʼObeyd says, <span class="ar long">وَهُوَ الوَجْهُ</span> <span class="add">[“and it is the proper,” or “the valid and obvious, way,” of explaining it]</span>, meaning that it is the preferable explanation: but the author of the Ḳ, mistaking his meaning, makes <span class="ar">وَجْهٌ</span> to be another signification of <span class="ar">تُرْعَةٌ</span>: or the meaning of this trad. is, he who acts according to the exhortations recited upon the steps of my pulpit will enter Paradise: or, accord. to Ḳṭ, prayer and praise in this place are means of attaining to Paradise; so that it is as though it were a portion of Paradise. <span class="auth">(TA.)</span> In the same manner Sahl explained his other trad,, <span class="ar long">إِنَّ قَدَمِى عَلَى تُرْعَةٍ مِنْ تُرَعِ الحَوْضِ</span> ‡ <span class="add">[<em>Verily my foot is at a gate of the gates of the pool</em> of Paradise]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tariyEN">
				<h3 class="entry"><span class="ar">تَرِيعٌ</span></h3>
				<div class="sense" id="tariyEN_A1">
					<p><span class="ar">تَرِيعٌ</span>: <a href="#tariEN">see <span class="ar">تَرِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarBaAEN">
				<h3 class="entry"><span class="ar">تَرَّاعٌ</span></h3>
				<div class="sense" id="tarBaAEN_A1">
					<p><span class="ar">تَرَّاعٌ</span> A torrent <em>filling the valley;</em> as also<span class="arrow"><span class="ar">أَتْرَعُ↓</span></span>: <span class="auth">(Ḳ:)</span> or a torrent <em>which fills the valley:</em> <span class="auth">(Ṣ:)</span> and<span class="arrow">↓</span> the latter, a <em>vehement</em> torrent. <span class="auth">(TA.)</span> J says, in the Ṣ, that <span class="arrow"><span class="ar long">سَيْرٌ أَنْزَعُ↓</span></span> signifies <span class="ar">شَدِيدٌ</span>; and he cites the words of a poet thus:</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَٱفْتَرَشَ الأَرْضَ بِسَيْرٍ أَتْرَعَا</span> *</div> 
					</blockquote>
					<p>ascribed by some to El-ʼAjjáj, but correctly, accord. to IB, the words of Ru-beh; making two mistakes, in saying <span class="ar">افترش</span>, in the sing., and <span class="ar">بسير</span>: moreover, the last word in the citation is a pret. verb: <span class="add">[the right reading is]</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَٱفْتَرَشُوا الأَرْضَ بِسَيْلٍ أَتْرَعَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And they travelled the land with</em> a multitude like <em>a torrent that filled</em> the valleys]</span>: the poet describes the Benoo-Temeem, and their travelling the land like the torrent by reason of multitude. <span class="auth">(Ṣgh, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترع</span> - Entry: <span class="ar">تَرَّاعٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tarBaAEN_B1">
					<p>† <em>A door-keeper.</em> <span class="auth">(Th, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OatoraEu">
				<h3 class="entry"><span class="ar">أَتْرَعُ</span></h3>
				<div class="sense" id="OatoraEu_A1">
					<p><span class="ar">أَتْرَعُ</span>: <a href="#tarBaAEN">see <span class="ar">تَرَّاعٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutoraEN">
				<h3 class="entry"><span class="ar">مُتْرَعٌ</span></h3>
				<div class="sense" id="mutoraEN_A1">
					<p><span class="ar long">حَوْضٌ مُتْرَعٌ</span> <em>A filled watering-trough</em> or <em>tank:</em> <span class="auth">(TA:)</span> and <span class="ar long">جَفْنَةٌ مُتْرَعَةٌ</span> <em>a filled bowl.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="munotariEN">
				<h3 class="entry"><span class="ar">مُنْتَرِعٌ</span></h3>
				<div class="sense" id="munotariEN_A1">
					<p><span class="ar">مُنْتَرِعٌ</span>: <a href="#tariEN">see <span class="ar">تَرِعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0303.pdf" target="pdf">
							<span>Lanes Lexicon Page 303</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
