<article class="root" id="Root_tOr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/002_tO">تأ</a></span>
				<span class="ar">تأر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/004_tOm">تأم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tOr_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتأر</span></h3>
				<div class="sense" id="tOr_4_A1">
					<p><span class="ar long">أَتْأَرْتُ إِلَيْهِ النَّظَرَ</span> <em>I continued to look at him time after time</em> (<span class="ar long">تَارَةً بَعْدَ تَارَةٍ</span>): <span class="auth">(T, TA:)</span> or <em>I looked at him sharply,</em> or <em>intently.</em> <span class="auth">(Fr, T, M, Ḳ.)</span> And <span class="ar long">أَتْأَرْتُهُ بَصَرِى</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar long">أَتْأَرْتُ إِلَيْهِ البَصَرَ</span>, <span class="auth">(Ḳ,)</span> <em>I followed him with my eye; made my eye to follow him.</em> <span class="auth">(Ṣ, M, Ḳ.)</span> <span class="add">[<a href="index.php?data=03_t/090_twr">See also art. <span class="ar">تور</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taArapN">
				<h3 class="entry"><span class="ar">تَارَةٌ</span></h3>
				<div class="sense" id="taArapN_A1">
					<p><span class="ar">تَارَةٌ</span>, without <span class="ar">ء</span> on account of frequent usage, <span class="auth">(IAạr, T, Mṣb in art. <span class="ar">تور</span>, and Ḳ,)</span> <em>A time; one time;</em> <span class="add">[in the sense of the French <em>fois;</em>]</span> syn. <span class="ar">مَرَّةٌ</span>: <span class="auth">(Mṣb, Ḳ:)</span> or <em>a time, whether long or short;</em> syn. <span class="ar">حِينٌ</span>: <span class="auth">(IAạr:)</span> sometimes, however, it is pronounced <span class="ar">تَأْرَةٌ</span>: <span class="auth">(Mṣb:)</span> pl. <span class="ar">تِئَرٌ</span> <span class="auth">(T, Mṣb, Ḳ)</span> and <span class="ar">تِئَارٌ</span>: <span class="auth">(Mṣb:)</span> these are pls. of <span class="ar">تَأْرَةٌ</span>; but <a href="#taArapN">the pl. of <span class="ar">تَارَةٌ</span></a> without <span class="ar">ء</span> is <span class="ar">تَارَاتٌ</span> <span class="auth">(Mṣb)</span> and <span class="ar">تِيَرٌ</span> <span class="auth">(Ṣ in art. <span class="ar">تير</span>, and Ḳ and Ḳ in art. <span class="ar">تور</span>,)</span> and <span class="ar">تِيَارٌ</span>. <span class="auth">(Ṣ in art. <span class="ar">تير</span>.)</span> <span class="add">[<a href="index.php?data=03_t/090_twr">See also art. <span class="ar">تور</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaArN">
				<h3 class="entry"><span class="ar">مُتَارٌ</span></h3>
				<div class="sense" id="mutaArN_A1">
					<p><span class="ar">مُتَارٌ</span> in the saying</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَصِرْتُ كَأَنَّنِى فَرَأٌ مُتَارُ</span> *</div> 
					</blockquote>
					<p>is <span class="add">[said by ISd to be]</span> for <span class="ar">مُتْأَرٌ</span> <span class="add">[pass. part. n. of <span class="ar">أَتْأَرَ</span>; so that the meaning is, <em>And I became as though I were a wild ass looked at sharply</em> or <em>intently,</em> or <em>followed by the eye,</em> in order to be captured or shot]</span>. <span class="auth">(M, TA. <span class="add">[<a href="index.php?data=03_t/090_twr">But see art. <span class="ar">تور</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0292.pdf" target="pdf">
							<span>Lanes Lexicon Page 292</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
