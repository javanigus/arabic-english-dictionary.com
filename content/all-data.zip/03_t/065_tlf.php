<article class="root" id="Root_tlf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/064_tlE">تلع</a></span>
				<span class="ar">تلف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/066_tlk">تلك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tlf_1">
				<h3 class="entry">1. ⇒ <span class="ar">تلف</span></h3>
				<div class="sense" id="tlf_1_A1">
					<p><span class="ar">تَلِفَ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْلَفُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَلَفٌ</span>, <span class="auth">(Lth, T, Ṣ, M, &amp;c.,)</span> <em>He,</em> or <em>it,</em> <span class="auth">(a thing, Lth, T, Ṣ, Mṣb, of any kind, Lth, T,)</span> <em>perished, passed away, was not, was no more, became nonexistent</em> or <em>annihilated;</em> or <em>went away, no one knew whither;</em> or <em>became in a bad,</em> or <em>corrupt, state; became corrupted, vitiated, marred,</em> or <em>spoiled;</em> <span class="add">[in this sense the verb is often used in the present day;]</span> or <em>he died:</em> syn. <span class="ar">هَلَكَ</span>; <span class="auth">(M, Ḳ;)</span> <span class="pb" id="Page_0313"></span>and of the inf. n., <span class="ar">عَطَبٌ</span> <span class="auth">(Lth, T,)</span> and <span class="ar">هَلَاكٌ</span>. <span class="auth">(Lth, T, Ṣ.)</span> <span class="add">[<a href="#talafN">See also <span class="ar">تَلَفٌ</span>, below</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlf_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتلف</span></h3>
				<div class="sense" id="tlf_4_A1">
					<p><span class="ar">اتلفهُ</span> <em>He caused him,</em> or <em>it,</em> <span class="auth">(a thing, Ṣ, Mṣb, or property, M,)</span> <em>to perish, pass away,</em> or <em>be no ore;</em> or <em>to go away, no one knew whither;</em> or <em>to become corrupted, vitiated, marred,</em> or <em>spoiled:</em> <span class="auth">(Ṣ, M:)</span> or <em>he made it</em> <span class="auth">(his property, T)</span> <em>to pass away, come to an end, come to nought,</em> or <em>be exhausted; destroyed, wasted, consumed,</em> or <em>exhausted, it;</em> <span class="auth">(T, Ḳ;)</span> <em>by prodigality.</em> <span class="auth">(T.)</span> <span class="add">[See an ex. in a verse of Ibn-Mukbil cited voce <span class="ar">أَخْلَفَ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلف</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlf_4_A2">
					<p>El-Farezdaḳ says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَقَوْمٍ كِرَامٍ قَدْ نَقَلْنَا إِلَيْهِمُ</span> *</div> 
						<div class="star">* <span class="ar long">قِرَاهُمْ فَأَتْلَفْنَا المَنَايَا وَأَتْلَفُوا</span> *</div> 
					</blockquote>
					<p><span class="auth">(so in the T and L,)</span> or</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَأَضْيَافِ لَيْلٍ قَدْ نَقَلْنَا قِرَاهُمُ</span> *</div> 
						<div class="star">* <span class="ar long">إِلَيْهِمْ وَأَتْلَفْنَا المَنَايَا وَأَتْلَفُوا</span> *</div> 
					</blockquote>
					<p><span class="auth">(so in some copies of the Ḳ,)</span> or <span class="ar long">قَدْ بَلَغْنَا قِرَاهُمُ</span>, <span class="auth">(so in other copies of the Ḳ and in the TA,)</span> or <span class="ar long">قد فَعَلْنَا قراهم</span>, <span class="auth">(so in the O,)</span> i. e., <span class="add">[accord. to the different readings, <em>How many a generous company of men</em> has there been, or <em>how many guests of the night</em> have there been, <em>to whom we have brought their entertainment, and</em>]</span> <em>we have found the fates to be destructive,</em> <span class="auth">(T, Ḳ,*)</span> <em>and they have found them to be so:</em> <span class="auth">(T:)</span> it is like the phrase <span class="ar long">أَتَيْنَا فُلَانًا فَأَبْخَلْنَاهُ</span> and <span class="ar">أَجْبَنَّاهُ</span>: <span class="auth">(TA:)</span> or <em>we found the fates to destroy us, and they found them to destroy them:</em> or <em>we made the fates to be destruction to them, and they made them to be destruction to us:</em> <span class="auth">(ISk, Ḳ:)</span> he means, we engaged with them in vehement fight, and slew them. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talafN">
				<h3 class="entry"><span class="ar">تَلَفٌ</span></h3>
				<div class="sense" id="talafN_A1">
					<p><span class="ar">تَلَفٌ</span> <em>A perishing, passing away,</em>, &amp;c. <span class="add">[<a href="#tlf_1">See 1</a>.]</span> <span class="auth">(Lth, T, Ṣ, &amp;c.)</span> It is said in a trad., <span class="auth">(TA,)</span> <span class="ar long">إِنَّ مِنَ القَرَفِ التَّلَفُ</span> <span class="auth">(T, TA)</span> <em>Verily, from the being near to pestilence,</em> or <em>epidemic disease, there results death,</em> or <em>perdition.</em> <span class="auth">(T.)</span> And in a prov., <span class="ar long">السَّلَفُ تَلَفٌ</span> <span class="add">[<em>The paying for a thing beforehand is a</em> cause of <em>perishing</em> to one's property]</span>. <span class="auth">(TA.)</span> And one says, <span class="ar long">ذَهَبَتْ نَفْسُهُ تَلَفًا</span> and <span class="ar">طَلَفًا</span>, <span class="auth">(Ṣ, Ḳ,)</span> both meaning the same, <span class="auth">(Ṣ,)</span> <em>His blood went for nothing,</em> or <em>as a thing of no account, unretaliated, and uncompensated by a mulct.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talifN">
				<h3 class="entry"><span class="ar">تَلِفٌ</span></h3>
				<div class="sense" id="talifN_A1">
					<p><span class="ar">تَلِفٌ</span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">تَالِفٌ↓</span></span>, <span class="auth">(Mṣb, TA,)</span> part. n. of 1, <em>Perishing,</em>, &amp;c.; <span class="auth">(M, Mṣb,* TA;)</span> as also<span class="arrow"><span class="ar">تَلْفَانٌ↓</span></span>, which is post-classical. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talofapN">
				<h3 class="entry"><span class="ar">تَلْفَةٌ</span></h3>
				<div class="sense" id="talofapN_A1">
					<p><span class="ar">تَلْفَةٌ</span> <em>A</em> <span class="add">[<em>hill, mountain,</em> or <em>mass of rock, such as is termed</em>]</span> <span class="ar">هَضْبَة</span>, <em>difficult of access, so that he who attempts it fears perdition,</em> or <em>death.</em> <span class="auth">(El-Hejeree, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="talofaAnN">
				<h3 class="entry"><span class="ar">تَلْفَانٌ</span></h3>
				<div class="sense" id="talofaAnN_A1">
					<p><span class="ar">تَلْفَانٌ</span>: <a href="#talifN">see <span class="ar">تَلِفٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taAlfN">
				<h3 class="entry"><span class="ar">تَالفٌ</span></h3>
				<div class="sense" id="taAlfN_A1">
					<p><span class="ar">تَالفٌ</span>: <a href="#talifN">see <span class="ar">تَلِفٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matolafN">
				<h3 class="entry"><span class="ar">مَتْلَفٌ</span></h3>
				<div class="sense" id="matolafN_A1">
					<p><span class="ar">مَتْلَفٌ</span> <em>A place of perishing</em> or <em>perdition:</em> <span class="auth">(Ḳ:)</span> <em>a</em> <span class="add">[<em>desert such as is termed</em>]</span> <span class="ar">مَفَازَة</span>; <span class="auth">(Ṣ, Ḳ;)</span> because most of those who traverse it perish; and so<span class="arrow"><span class="ar">مَتْلَفَةٌ↓</span></span>; <span class="auth">(TA;)</span> or the latter signifies <em>a</em> <span class="add">[<em>desert such as is termed</em>]</span> <span class="ar">قَفْر</span>: <span class="auth">(M:)</span> the pl. of the former <span class="add">[or of both]</span> is <span class="ar">مَتَالِفُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutolifN">
				<h3 class="entry"><span class="ar">مُتْلِفٌ</span></h3>
				<div class="sense" id="mutolifN_A1">
					<p><span class="ar long">رَجُلٌ مُتْلِفٌ لِمَالِهِ</span>, <span class="auth">(Mṣb,)</span> or<span class="arrow"><span class="ar long">رَجُلٌ مِتْلَفٌ↓</span></span>, and<span class="arrow"><span class="ar">مِتْلَافٌ↓</span></span>, <span class="auth">(M,)</span> <em>A man who destroys,</em> or <em>wastes, his property:</em> <span class="auth">(M:)</span> or the last has an intensive signification, <span class="auth">(Mṣb,)</span> meaning <em>who destroys,</em> or <em>wastes, his property much.</em> <span class="auth">(Ṣ.)</span> You say also, <span class="ar long">رَجُلٌ مُخْلِفٌ مُتْلِفٌ</span>, <span class="auth">(Ḳ, and Ḥar p. 312,)</span> or<span class="arrow"><span class="ar long">مِخْلَفٌ مِتْلَفٌ↓</span></span>, <span class="auth">(TA in art. <span class="ar">خلف</span>,)</span> and<span class="arrow"><span class="ar long">مِخْلَافٌ مِتْلَافٌ↓</span></span>, <span class="auth">(Ḳ, and Ḥar ubi suprà,)</span> meaning <em>A man of courage and liberality, who makes what he takes as spoil, of the property of his enemies, to supply the place of that which he consumes by expenditure to satisfy the claims of his friends.</em> <span class="auth">(Ḥar ubi suprà.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mitolafN">
				<h3 class="entry"><span class="ar">مِتْلَفٌ</span></h3>
				<div class="sense" id="mitolafN_A1">
					<p><span class="ar">مِتْلَفٌ</span>: <a href="#mutolifN">see the next preceding paragraph, in two places</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matolafapN">
				<h3 class="entry"><span class="ar">مَتْلَفَةٌ</span></h3>
				<div class="sense" id="matolafapN_A1">
					<p><span class="ar">مَتْلَفَةٌ</span>: <a href="#matolafN">see <span class="ar">مَتْلَفٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلف</span> - Entry: <span class="ar">مَتْلَفَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="matolafapN_A2">
					<p>Also <em>A deep hollow, cavity,</em> or <em>pit, where one looks down upon destruction.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mitolaAfN">
				<h3 class="entry"><span class="ar">مِتْلَافٌ</span></h3>
				<div class="sense" id="mitolaAfN_A1">
					<p><span class="ar">مِتْلَافٌ</span>: <a href="#mutolifN">see <span class="ar">مُتْلِفٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoluwfN">
				<h3 class="entry"><span class="ar">مَتْلُوفٌ</span></h3>
				<div class="sense" id="matoluwfN_A1">
					<p><span class="ar">مَتْلُوفٌ</span> <span class="add">[<em>i. q.</em> <span class="ar">مُنْكَرٌ</span>, q. v.; i. e.]</span> <em>contr. of</em> <span class="ar">مَعْرُوفٌ</span>: but this is post-classical. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0312.pdf" target="pdf">
							<span>Lanes Lexicon Page 312</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0313.pdf" target="pdf">
							<span>Lanes Lexicon Page 313</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
