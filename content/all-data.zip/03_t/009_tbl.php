<article class="root" id="Root_tbl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/008_tbE">تبع</a></span>
				<span class="ar">تبل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/010_tbn">تبن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tbl_1">
				<h3 class="entry">1. ⇒ <span class="ar">تبل</span></h3>
				<div class="sense" id="tbl_1_A1">
					<p><span class="ar">تَبَلَهُ</span>, <span class="auth">(Lth, T, M,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْبِلُ</span>}</span></add>, <span class="auth">(M,)</span> inf. n. <span class="ar">تَبْلٌ</span>, <span class="auth">(Lth, T, M,)</span> <em>He pursued him with enmity,</em> or <em>hostility:</em> <span class="auth">(Lth, T:)</span> or <em>he bore enmity,</em> or <em>was hostile, to him.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbl_1_A2">
					<p><span class="ar long">تَبَلَهُمُ الدَّهْرُ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَبْلٌ</span>, <span class="auth">(M,)</span> ‡ <em>Time,</em> or <em>fortune, smote them with its vicissitudes,</em> <span class="auth">(M, Ḳ,)</span> and <span class="auth">(Ḳ)</span> <em>destroyed them;</em> <span class="auth">(Ṣ, Ḳ;)</span> as also<span class="arrow"><span class="ar">أَتْبَلَهُمْ↓</span></span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tbl_1_A3">
					<p><span class="ar long">تَبَلَهُ الحُبُّ</span>, <span class="auth">(Ṣ, M,)</span> or <span class="ar">الهَوَى</span>, <span class="auth">(T,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْبِلُ</span>}</span></add>, <span class="auth">(M,)</span> inf. n. <span class="ar">تَبْلٌ</span>; <span class="auth">(T, Ḳ;)</span> and<span class="arrow"><span class="ar">اتبلهُ↓</span></span>, <span class="auth">(Ṣ, M,)</span> inf. n. <span class="ar">إِتْبَالٌ</span>; <span class="auth">(Ḳ, TA;)</span> <em>Love made him sick,</em> or <em>ill;</em> <span class="auth">(T, Ṣ, M, Ḳ; <span class="add">[in the CK, <span class="ar long">والاَسْقَامُ كالاَتْبَالِ</span> is erroneously put for <span class="ar long">والإِسْقَامُ كالإِتْبَالِ</span>;]</span>)</span> and <em>caused him to be in a bad,</em> or <em>unsound, state:</em> <span class="auth">(Ṣ:)</span> or, as some say, <span class="ar">تَبَلَهُ</span> signifies, <span class="auth">(M,)</span> or signifies also, <span class="auth">(Ḳ,)</span> <em>it took away his reason,</em> <span class="auth">(M, Ḳ,)</span> and <em>bewildered him.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tbl_1_A4">
					<p>You say also, of a woman, <span class="ar long">تَبَلَتْ فُؤَادَ الرَّجُلِ</span>, <span class="auth">(M, Ḳ,)</span> inf. n. as above, as though meaning, <span class="auth">(M,)</span> <em>She smote the man's heart with</em> <span class="arrow"><span class="ar">تَبْل↓</span></span> <span class="add">[app. meaning <em>love-sickness</em>]</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tbl_1_B1">
					<p><a href="#tbl_QQ1">See also Q. Q. 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tbl_2">
				<h3 class="entry">2. ⇒ <span class="ar">تبّل</span></h3>
				<div class="sense" id="tbl_2_A1">
					<p><a href="#tbl_QQ1">see Q. Q. 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tbl_3">
				<h3 class="entry">3. ⇒ <span class="ar">تبّل</span></h3>
				<div class="sense" id="tbl_3_A1">
					<p><a href="#tbl_QQ1">see Q. Q. 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbl_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتبل</span></h3>
				<div class="sense" id="tbl_4_A1">
					<p><span class="ar">اتبلهُ</span>, inf. n. <span class="ar">إِتْبَالٌ</span>, <em>He made him a victim of blood-revenge,</em> or <em>retaliation of murder or homicide.</em> <span class="auth">(Ṣ: the meaning is indicated there, but not expressed.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbl_4_A2">
					<p><a href="#tbl_1">See also 1</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbl_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">تَوْبَلَ</span></h3>
				<div class="sense" id="tbl_QQ1_A1">
					<p><span class="ar long">تَوْبَلَ القِدْرَ</span>, <span class="auth">(AʼObeyd, T, Ṣ, M, Mṣb, Ḳ,)</span> and <span class="ar">تَأْبَلَهَا</span>, with hemz, <span class="auth">(IJ, M,)</span> or<span class="arrow"><span class="ar">تَابَلَهَا↓</span></span>, <span class="add">[without <span class="ar">ء</span>,]</span> <span class="auth">(Ḳ,)</span> mentioned by Ibn-ʼAbbád in the Moḥeeṭ, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">تَبَّلَهَا↓</span></span>, <span class="auth">(T, M, Ḳ,)</span> said by Lth to be allowable, <span class="auth">(T,)</span> and<span class="arrow"><span class="ar">تَبَلَهَا↓</span></span>, <span class="auth">(Ḳ,)</span> <em>He seasoned</em> <span class="add">[<em>the contents of</em>]</span> <em>the cooking-pot with</em> <span class="ar">تَابَل</span>; <span class="auth">(Mṣb;)</span> <em>he put</em> <span class="ar">تَابَل</span> <em>into the cooking-pot;</em> <span class="auth">(Ḳ;)</span> <em>i. q.</em> <span class="ar">قَزَّحَهَا</span> and <span class="ar">فَحَّاهَا</span>: <span class="auth">(AʼObeyd, T:)</span> from <span class="ar">تَابَلٌ</span>. <span class="auth">(Ṣ, M.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: Q. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbl_QQ1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">تَوْبَلَ كَلَامَهُ</span> ‡ <em>He seasoned</em> <span class="add">[meaning <em>he embellished</em>]</span> <em>his speech,</em> or <em>language;</em> syn. <span class="ar">قَزَّحَهُ</span> <span class="auth">(TA)</span> and <span class="ar">بَزَّرَهُ</span>. <span class="auth">(A in art. <span class="ar">بزر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabolN">
				<h3 class="entry"><span class="ar">تَبْلٌ</span></h3>
				<div class="sense" id="tabolN_A1">
					<p><span class="ar">تَبْلٌ</span> <span class="add">[<a href="#tbl_1">originally inf. n. of 1, q. v.</a>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: <span class="ar">تَبْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tabolN_A2">
					<p><em>Enmity,</em> or <em>hostility,</em> <span class="auth">(Lth, T, M, Ḳ, TA,)</span> <em>in the heart,</em> <span class="auth">(TA,)</span> <em>with which one is pursued:</em> <span class="auth">(Lth, T:)</span> pl. <span class="ar">تُبُولٌ</span> <span class="auth">(Lth, T, M, Ḳ)</span> and<span class="arrow"><span class="ar">تَبَابِيلُ↓</span></span>, which latter is extr. <span class="auth">(Ḳ.)</span> You say, <span class="ar long">لِى عِنْدَهُ تَبْلٌ</span> <span class="add">[<em>He has enmity,</em> or <em>hostility, towards me, with which he pursues me</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: <span class="ar">تَبْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tabolN_A3">
					<p><em>I. q.</em> <span class="ar">تِرَةٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">ذَحْلٌ</span> <span class="auth">(Ṣ, M, Ḳ)</span> <span class="add">[by the former of which may be intended the meaning explained above, or, as appears to be meant by the latter, <em>blood-revenge;</em> or <em>retaliation of murder or homicide;</em> or <em>prosecution for blood;</em> or <em>a desire of,</em> or <em>seeking for, retaliation of a crime or of enmity</em>]</span>: pl. <span class="ar">تُبُولٌ</span>. <span class="auth">(Ṣ.)</span> <span class="ar">التَّبْلُ</span> as meaning <span class="ar">الذَّحْلُ</span> is likened by Yezeed Ibn-El-Hakam Eth-Thakafee to a debt which one should be paid. <span class="auth">(Ḥam p. 530.)</span> And one says, <span class="ar long">أُصِيبَ بِتَبْلٍ</span> <span class="add">[<em>He was made a victim of blood-revenge,</em> or <em>retaliation of murder or homicide:</em> or, perhaps, <em>of enmity,</em> or <em>hostility</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">بَيْنَهُمْ تُبُولٌ</span> <span class="add">[<em>Between them are blood-revenges,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: <span class="ar">تَبْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tabolN_A4">
					<p><em>Love-sickness.</em> <span class="auth">(Kull p. 167. <span class="add">[<a href="#HubBu">See <span class="ar">حُبُّ</span></a>.]</span>)</span> <a href="#tbl_1">See 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabila">
				<h3 class="entry"><span class="ar">تَبِلَ</span></h3>
				<div class="sense" id="tabila_A1">
					<p><span class="ar long">دَهْرٌ تَبِلَ</span>, <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">تَابِلٌ↓</span></span>, <span class="auth">(TA,)</span> ‡ <em>Time,</em> or <em>fortune, that smites people with its vicissitudes,</em> <span class="auth">(M, TA,)</span> <em>and destroys them.</em> <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">دَهْرٌ مُتْبِلٌ↓ خَبِلٌ</span></span>, occurring in a poem of El-Aạshà, † <em>Time,</em> or <em>fortune, that destroys,</em> or <em>carries off, family and children.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tabiylN">
				<h3 class="entry"><span class="ar">تَبِيلٌ</span></h3>
				<div class="sense" id="tabiylN_A1">
					<p><span class="ar">تَبِيلٌ</span>: <a href="#matobuwlN">see <span class="ar">مَتْبُولٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tabaAbiylu">
				<h3 class="entry"><span class="ar">تَبَابِيلُ</span></h3>
				<div class="sense" id="tabaAbiylu_A1">
					<p><span class="ar">تَبَابِيلُ</span>: <a href="#tabolN">see <span class="ar">تَبْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabBaAlN">
				<h3 class="entry"><span class="ar">تَبَّالٌ</span></h3>
				<div class="sense" id="tabBaAlN_A1">
					<p><span class="ar">تَبَّالٌ</span> <em>A possessor</em> <span class="add">[or <em>seller</em>]</span> <em>of</em> <span class="ar">تَوَابِل</span> <a href="#taAbalN">pl. of <span class="ar">تَابَلٌ</span></a>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAbalN">
				<h3 class="entry"><span class="ar">تَابَلٌ</span></h3>
				<div class="sense" id="taAbalN_A1">
					<p><span class="ar">تَابَلٌ</span>, <span class="auth">(AʼObeyd, T, Ṣ, M, Mṣb, Ḳ,)</span> also pronounced <span class="ar">تَأْبَلٌ</span>, with <span class="ar">ء</span>, <span class="auth">(IJ, M,)</span> and<span class="arrow"><span class="ar">تَابِلٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> and<span class="arrow"><span class="ar">تَوْبَلُ↓</span></span>, <span class="auth">(IAạr, T, Ḳ,)</span> <em>Seeds</em> (<span class="ar">أَبْزَارٌ</span> Mṣb and Ḳ) <em>that are used in cooking, for seasoning food;</em> <span class="auth">(T, Ṣ,* M, Mṣb, Ḳ;)</span> <em>i. q.</em> <span class="ar">فَحًا</span>; <span class="auth">(T, M;)</span> <em>such as cumin-seeds and coriander-seeds:</em> <span class="auth">(TA voce <span class="ar">قِزْحٌ</span>:)</span> said to be arabicized: Ibn-El-Jawá- leekee says that the vulgar distinguish between <span class="ar">تابل</span> and <span class="ar">ابزار</span>, <span class="add">[in the manner explained voce <span class="ar">بِزْرٌ</span>,]</span> but the <span class="add">[classical]</span> Arabs do not: <span class="auth">(Mṣb:)</span> pl. <span class="ar">تَوَابِلُ</span>. <span class="auth">(T, Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taAbilN">
				<h3 class="entry"><span class="ar">تَابِلٌ</span></h3>
				<div class="sense" id="taAbilN_A1">
					<p><span class="ar">تَابِلٌ</span>: <a href="#tabilN">see <span class="ar">تَبِلٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبل</span> - Entry: <span class="ar">تَابِلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="taAbilN_B1">
					<p><a href="#taAbalN">and see <span class="ar">تَابَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tawobalu">
				<h3 class="entry"><span class="ar">تَوْبَلُ</span></h3>
				<div class="sense" id="tawobalu_A1">
					<p><span class="ar">تَوْبَلُ</span>: <a href="#taAbalN">see <span class="ar">تَابَلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tuwbaAlN">
				<h3 class="entry"><span class="ar">تُوبَالٌ</span></h3>
				<div class="sense" id="tuwbaAlN_A1">
					<p><span class="ar">تُوبَالٌ</span> <span class="add">[from the Persian <span class="ar">تُوبَالْ</span> or <span class="ar">تُوپَالْ</span>?]</span> <em>What falls in consecutive portions,</em> or <em>particles, on the occasion of the hammering</em> of copper and of iron: <em>a</em> <span class="ar">مِثْقَال</span> <em>thereof, with hydromel, drunk, powerfully alleviates the</em> <span class="add">[<em>ejection of</em>]</span> <em>phlegm.</em> <span class="auth">(Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutobilN">
				<span class="pb" id="Page_0297"></span>
				<h3 class="entry"><span class="ar">مُتْبِلٌ</span></h3>
				<div class="sense" id="mutobilN_A1">
					<p><span class="ar">مُتْبِلٌ</span>: <a href="#tabilN">see <span class="ar">تَبِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matobuwlN">
				<h3 class="entry"><span class="ar">مَتْبُولٌ</span></h3>
				<div class="sense" id="matobuwlN_A1">
					<p><span class="ar">مَتْبُولٌ</span> A man <em>rendered love-sick;</em> <span class="auth">(T;)</span> as also<span class="arrow"><span class="ar">تَبِيلٌ↓</span></span>: <span class="auth">(M:)</span> and the former, <em>a lover who is not granted that which he wants.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0296.pdf" target="pdf">
							<span>Lanes Lexicon Page 296</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0297.pdf" target="pdf">
							<span>Lanes Lexicon Page 297</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
