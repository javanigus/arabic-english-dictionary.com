<article class="root" id="Root_tbt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/005_tb">تب</a></span>
				<span class="ar">تبت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/007_tbr">تبر</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="tabuwtN">
				<h3 class="entry"><span class="ar">تَبُوتٌ</span> / <span class="ar">تَابُوتٌ</span></h3>
				<div class="sense" id="tabuwtN_A1">
					<p><span class="ar">تَبُوتٌ</span> <em>i. q.</em> <span class="ar">تَابُوتٌ</span>; <span class="auth">(Ḳ;)</span> a dial. var. of the latter. <span class="auth">(TA.)</span> <a href="index.php?data=03_t/084_twb">See both in art. <span class="ar">توب</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0293.pdf" target="pdf">
							<span>Lanes Lexicon Page 293</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
