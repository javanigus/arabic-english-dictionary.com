<article class="root" id="Root_tEb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/044_tE">تع</a></span>
				<span class="ar">تعب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/046_tEs">تعس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tEb_1">
				<h3 class="entry">1. ⇒ <span class="ar">تعب</span></h3>
				<div class="sense" id="tEb_1_A1">
					<p><span class="ar">تَعِبَ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْعَبُ</span>}</span></add>, <span class="auth">(A, Ḳ,)</span> inf. n. <span class="ar">تَعَبٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> <em>He</em> <span class="add">[a man and a beast]</span> <em>was,</em> or <em>became, fatigued, tired, wearied</em> <span class="add">[<em>by labour</em> or <em>journeying</em>, &amp;c.]</span>, or <em>jaded;</em> <span class="auth">(Ṣ, A, Mṣb;)</span> <em>contr. of</em> <span class="ar">اِسْتَرَاحَ</span>. <span class="auth">(Ḳ.)</span> <span class="add">[<span class="ar">تَعَبٌ</span>, which, used as a simple subst., may be rendered <em>Fatigue, tiredness, weariness,</em> or the <em>state of being jaded,</em> is here said in the TA to be <em>contr. of</em> <span class="ar">رَاحَةٌ</span>; and to signify <span class="ar long">شِدَّةُ العَنَآءِ</span>, which may be rendered <em>much fatigue</em>, &amp;c.; but accord. to an explanation of the verb of <span class="ar">عَنَآءٌ</span> in the Ṣ and TA in art. <span class="ar">عنى</span>, this word and <span class="ar">تَعَبٌ</span> signify the same. <a href="#matoEabN">See also <span class="ar">مَتْعَبٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tEb_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتعب</span></h3>
				<div class="sense" id="tEb_4_A1">
					<p><span class="ar">اتعب</span> <em>He fatigued, tired, wearied,</em> or <em>jaded,</em> another; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and himself, in a work that he imposed upon himself, or in which he laboured; and his travelling-camels, by urging them quickly, or by hard journeying. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tEb_4_A2">
					<p>‡ <em>He broke</em> a bone <em>again after it had been set,</em> or <em>consolidated:</em> or <em>he caused</em> a bone <em>to have a defect in it, after it had been set, so that there remained in it a constant swelling,</em> or <em>resulted a lameness:</em> <span class="ar long">اتعب العَظْمَ</span> signifying <span class="ar long">أَعْنَتَهُ بَعْدَ الجَبْرِ</span>: <span class="auth">(so in the CK:)</span> or <span class="ar long">أَعْتَبَهُ بعد الجبر</span>. <span class="auth">(So in MṢ. copies of the Ḳ and in the TA. <span class="add">[In the latter, <a href="index.php?data=18_E/015_Etb">in art. <span class="ar">عتب</span></a>, this reading is confirmed; but a remark below, voce <span class="ar">مُتْعَبٌ</span>, rather favours the former reading, that of the CK.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tEb_4_A3">
					<p>‡ <em>He filled</em> a vessel; <span class="auth">(A, Ḳ;)</span> as, for instance, a drinking-cup, or bowl. <span class="auth">(A.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tEb_4_B1">
					<p><span class="ar long">اتعب القَوْمُ</span> <em>The people's cattle became fatigued, tired, wearied,</em> or <em>jaded.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taEibN">
				<h3 class="entry"><span class="ar">تَعِبٌ</span></h3>
				<div class="sense" id="taEibN_A1">
					<p><span class="ar">تَعِبٌ</span> <em>Fatigued, tired, wearied,</em> or <em>jaded;</em> as also<span class="arrow"><span class="ar">مُتْعَبٌ↓</span></span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> but not <span class="ar">مَتْعُوبٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<span class="arrow"><span class="ar">تَعْبَان↓</span></span>, for <span class="ar">تَعْبَانٌ</span>, fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَعْبَانَةٌ</span>}</span></add>, is used in this sense in the present day.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taEobaAn">
				<h3 class="entry"><span class="ar">تَعْبَان</span></h3>
				<div class="sense" id="taEobaAn_A1">
					<p><span class="ar">تَعْبَان</span>: <a href="#taEibN">see what next precedes</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoEabN">
				<h3 class="entry"><span class="ar">مَتْعَبٌ</span></h3>
				<div class="sense" id="matoEabN_A1">
					<p><span class="ar">مَتْعَبٌ</span> <em>A place of</em> <span class="ar">تَعَب</span> <span class="add">[or <em>fatigue,</em>, &amp;c.]</span>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: <span class="ar">مَتْعَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="matoEabN_A2">
					<p>and tropically, <em>syn. with</em> <span class="ar">تَعَبٌ</span>: pl. <span class="ar">مَتَاعِبُ</span>. <span class="auth">(Ḥar p. 431.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutoEabN">
				<h3 class="entry"><span class="ar">مُتْعَبٌ</span></h3>
				<div class="sense" id="mutoEabN_A1">
					<p><span class="ar">مُتْعَبٌ</span>: <a href="#taEibN">see <span class="ar">تَعِبٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: <span class="ar">مُتْعَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutoEabN_A2">
					<p>Also ‡ A camel <em>that has had a bone of one of his fore legs or hind legs broken and set, and has been fatigued beyond his power of endurance before the bone has consolidated, so that the fracture has become complete:</em> whence the phrase <span class="ar long">عَظْمٌ مُتْعَبٌ</span> <span class="add">[app. meaning ‡ <em>a bone broken again after its having been set,</em> or <em>consolidated:</em> <a href="#tEb_4">see 4</a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: <span class="ar">مُتْعَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mutoEabN_A3">
					<p>A vessel, as, for instance, a drinking-cup, or bowl, ‡ <em>filled.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعب</span> - Entry: <span class="ar">مُتْعَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="mutoEabN_A4">
					<p>Water ‡ <em>squeezed forth,</em> or <em>expressed, from the earth,</em> to be drunk. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoEabapN">
				<h3 class="entry"><span class="ar">مَتْعَبَةٌ</span></h3>
				<div class="sense" id="matoEabapN_A1">
					<p><span class="ar">مَتْعَبَةٌ</span> <span class="add">[<em>A cause of fatigue</em> or <em>weariness:</em> a word of the same class as <span class="ar">مَجْبَنَةٌ</span> and <span class="ar">مَبْخَلَةٌ</span>: loosely explained in Ḥar p. 475 as meaning <em>a place of fatigue</em>]</span>. One says, <span class="ar long">اِسْتِخْرَاجُ المُعَمَّى مَتْعَبَةٌ لِلْخَوَاطِرِ</span> <span class="add">[<em>The eliciting of the meaning of that which is made enigmatical is a cause of fatigue to minds</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0307.pdf" target="pdf">
							<span>Lanes Lexicon Page 307</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
