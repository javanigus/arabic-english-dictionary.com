<article class="root" id="Root_txt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/019_tx">تخ</a></span>
				<span class="ar">تخت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/021_txc">تخذ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="taxotN">
				<h3 class="entry"><span class="ar">تَخْتٌ</span></h3>
				<div class="sense" id="taxotN_A1">
					<p><span class="ar">تَخْتٌ</span> <em>A repository in which clothes are kept;</em> <span class="auth">(Ḳ;)</span> <span class="add">[<em>a chest for clothes; a wardrobe:</em> pl. <span class="ar">تُخُوتٌ</span>:]</span> a Persian word sometimes used by the Arabs. <span class="auth">(IDrd.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تخت</span> - Entry: <span class="ar">تَخْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taxotN_A2">
					<p><span class="add">[The following significations of the word seem to be post-classical.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تخت</span> - Entry: <span class="ar">تَخْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taxotN_A3">
					<p><span class="add">[<em>A throne: a seat: a seat of government: a moveable wooden bench,</em> or <em>sofa:</em> all which are Persian. Hence, <span class="ar">تَخْتَرَوَانٌ</span>, from the Persian, <em>A kind of covered litter, like a palanquin, borne by two camels or horses, one before and the other behind, or by two or four mules.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تخت</span> - Entry: <span class="ar">تَخْتٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taxotN_A4">
					<p><span class="add">[So too <span class="ar">تَخْتَةٌ</span> <em>A board,</em> or <em>plank:</em> likewise of Persian origin. Hence the verb <span class="ar">تَخَّتَ</span> <em>He boarded,</em> or <em>planked.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
