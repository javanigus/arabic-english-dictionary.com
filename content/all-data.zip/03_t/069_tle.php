<article class="root" id="Root_tle">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/068_tlw">تلو</a></span>
				<span class="ar">تلى</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/070_tm">تم</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="tle_1">
				<h3 class="entry">1. ⇒ <span class="ar">تلى</span></h3>
				<div class="sense" id="tle_1_A1">
					<p><span class="ar">تَلَيْتُهُ</span>: <a href="#tlw_1">see <span class="ar">تَلَوْتُهُ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="talieBN.1">
				<h3 class="entry"><span class="ar">تَلِىٌّ</span></h3>
				<div class="sense" id="talieBN.1_A1">
					<p><span class="ar">تَلِىٌّ</span>, &amp;c.: <a href="index.php?data=03_t/068_tlw">see art. <span class="ar">تلو</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0315.pdf" target="pdf">
							<span>Lanes Lexicon Page 315</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
