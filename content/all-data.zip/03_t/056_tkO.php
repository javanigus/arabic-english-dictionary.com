<article class="root" id="Root_tkO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/055_tk">تك</a></span>
				<span class="ar">تكأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/057_tkl">تكل</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">تكأ</span></h4>
			<hr>
			<section class="entry xref" id="takiYa">
				<h3 class="entry"><span class="ar">تَكِئَ</span></h3>
				<div class="sense" id="takiYa_A1">
					<p><span class="ar">تَكِئَ</span>, &amp;c.: <a href="../">see art. <span class="ar">وكأ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0310.pdf" target="pdf">
							<span>Lanes Lexicon Page 310</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
