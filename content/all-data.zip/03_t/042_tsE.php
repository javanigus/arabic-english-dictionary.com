<article class="root" id="Root_tsE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/041_trh">تره</a></span>
				<span class="ar">تسع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/043_tXryn">تشرين</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tsE_1">
				<h3 class="entry">1. ⇒ <span class="ar">تسع</span></h3>
				<div class="sense" id="tsE_1_A1">
					<p><span class="ar">تَسَعَهُمْ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْسَعُ</span>}</span></add> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْسِعُ</span>}</span></add> <span class="auth">(Yoo, Mṣb, Ḳ)</span> and <span class="ar">ـُ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">تَسْعٌ</span>, <span class="auth">(T Ḳ,)</span> <em>He took the ninth part of their possessions:</em> or <em>he became the ninth of them:</em> <span class="auth">(Ṣ, Mṣb, Ḳ:)</span> or <em>he made them to be nine with himself;</em> <span class="auth">(Ḳ;)</span> they having before been eight. <span class="auth">(TA.)</span> <span class="add">[<a href="#tsE_2">See also 2</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tsE_2">
				<h3 class="entry">2. ⇒ <span class="ar">تسّع</span></h3>
				<div class="sense" id="tsE_2_A1">
					<p><span class="ar">تسّعهُ</span> <em>He made it nine.</em> <span class="auth">(Esh-Sheybánee, and Ḳ voce <span class="ar">وَحَّدَ</span>.)</span> <span class="add">[<a href="#tsE_1">See also 1</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تسع</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tsE_2_A2">
					<p><span class="ar long">تسّع لِٱمْرَأَتِهِ</span>, or <span class="ar">عِنْدَهَا</span>, <em>He remained nine nights with his wife:</em> and in like manner the verb is used in relation to any saying or action. <span class="auth">(TA voce <span class="ar">سَبَّعَ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tsE_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتسع</span></h3>
				<div class="sense" id="tsE_4_A1">
					<p><span class="ar">اتسعوا</span> <em>They became nine:</em> <span class="auth">(Ṣ, Ḳ:)</span> and <em>they became ninety.</em> <span class="auth">(M and L in art. <span class="ar">ثلث</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تسع</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tsE_4_A2">
					<p><em>They were,</em> or <em>became, persons whose camels came to water</em> <span class="add">[<em>on the ninth day, counting the day of the next preceding watering as the first;</em> i. e.,]</span> <em>after an interval of nine days,</em> <span class="add">[<em>of which the first or last, or each of these, was not complete,</em>]</span> <em>and eight nights.</em> <span class="auth">(Ṣ,* Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tasoEN">
				<h3 class="entry"><span class="ar">تَسْعٌ</span></h3>
				<div class="sense" id="tasoEN_A1">
					<p><span class="ar">تَسْعٌ</span>: <a href="#tisoEapN">see <span class="ar">تِسْعَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tusoEN">
				<h3 class="entry"><span class="ar">تُسْعٌ</span></h3>
				<div class="sense" id="tusoEN_A1">
					<p><span class="ar">تُسْعٌ</span> <em>A ninth part; one of nine parts;</em> <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> as also<span class="arrow"><span class="ar">تُسُعٌ↓</span></span>; <span class="auth">(Mṣb;)</span> and<span class="arrow"><span class="ar">تَسِيعٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> agreeably with a rule which some hold to be applicable in the case of every similar fractional number; but Sh says, I have not heard <span class="ar">تَسِيعٌ</span> on any authority but that of AZ. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tisoEN">
				<h3 class="entry"><span class="ar">تِسْعٌ</span></h3>
				<div class="sense" id="tisoEN_A1">
					<p><span class="ar">تِسْعٌ</span> <a href="#tisoEapN">fem. of <span class="ar">تِسْعَةٌ</span>, q. v.</a></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تسع</span> - Entry: <span class="ar">تِسْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tisoEN_A2">
					<p>Also <em>A certain</em> <span class="ar">ظْمء</span> <em>of the</em> <span class="ar">أَظْمَآء</span> <em>of camels;</em> <span class="auth">(Ṣ, Ḳ, TA;)</span> i. e., <em>their coming to water</em> <span class="add">[<em>on the ninth day, counting the day of the next preceding watering as the first;</em> or, in other words,]</span> <em>after an interval of nine days,</em> <span class="add">[<em>of which the first or last, or each of these, is not complete,</em>]</span> <em>and eight nights.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تسع</span> - Entry: <span class="ar">تِسْعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tisoEN_A3">
					<p>Also The <em>ninth young one,</em> or <em>offspring.</em> <span class="auth">(A in art. <span class="ar">ثلث</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tusaEN">
				<h3 class="entry"><span class="ar">تُسَعٌ</span></h3>
				<div class="sense" id="tusaEN_A1">
					<p><span class="ar">تُسَعٌ</span> The <em>seventh and eighth and ninth nights of the</em> <span class="add">[<em>lunar</em>]</span> <em>month;</em> <span class="auth">(Ḳ;)</span> the <em>three nights of the month which are after the</em> <span class="ar">نُفَل</span>, <em>because the last night of these is the ninth;</em> <span class="auth">(Ṣ;)</span> among the nights of the month are three called <span class="ar">غُرَرٌ</span>, <span class="add">[<a href="#gurBapN">pl. of <span class="ar">غُرَّةٌ</span></a>,]</span> and after these are three called <span class="ar">نُفَلٌ</span>, and after these are three called <span class="ar">تُسَعٌ</span> because the last of them is the ninth night: <span class="auth">(Az, TA:)</span> or the <em>three nights of the commencement of the month,</em> as some say; but the first of these explanations is more agreeable with analogy. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tusuEN">
				<h3 class="entry"><span class="ar">تُسُعٌ</span></h3>
				<div class="sense" id="tusuEN_A1">
					<p><span class="ar">تُسُعٌ</span>: <a href="#tusoEN">see <span class="ar">تُسْعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tisoEapN">
				<h3 class="entry"><span class="ar">تِسْعَةٌ</span></h3>
				<div class="sense" id="tisoEapN_A1">
					<p><span class="ar">تِسْعَةٌ</span>, applied to denote a number, <span class="add">[namely <em>Nine,</em>]</span> is masc.; and<span class="arrow"><span class="ar">تِسْعٌ↓</span></span>, so applied, is fem.: <span class="auth">(Ṣ:)</span> the latter is also written <span class="arrow"><span class="ar">تَسْعٌ↓</span></span>, with fet-ḥ to the <span class="ar">ت</span>; and is thus pronounced in the Ḳur xxxviii. 22, <span class="auth">(Bḍ, MF,)</span> accord. to one reading. <span class="auth">(Bḍ.)</span> You say <span class="ar long">تِسْعَةُ رِجَالٍ</span> <span class="add">[<em>Nine men</em>]</span>, and <span class="ar long">تِسْعٌ نِسْوَةٍ</span> <span class="add">[<em>Nine women</em>]</span>. <span class="auth">(Ḳ.)</span> When it means the things numbered, not the amount of the number, <span class="ar">تسعة</span> is imperf. decl., being regarded as a proper name: thus you say, <span class="ar long">تِسْعَةُ أَكْثَرُ مِنْ ثَمَانِيَةَ</span> <span class="add">[<em>Nine things are more than eight things</em>]</span>. <span class="auth">(TA.)</span> It is said in the Ḳur <span class="add">[xvii. 103]</span>, <span class="ar long">وَلَقَدْ آتَيْنَا مُوسَى تِسْعَ آيَاتٍ بَيِّنَاتٍ</span> <span class="add">[<em>And we formerly gave unto Moses nine evident signs;</em> generally understood to mean the principal miracles which he was empowered to perform, and which are differently enumerated in the Ḳ and other works; but by some supposed to mean statutes]</span>. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تسع</span> - Entry: <span class="ar">تِسْعَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tisoEapN_A2">
					<p>In <span class="ar long">تِسْعَةَ عَشَرَ</span>, which is masc., and <span class="ar long">تِسْعَ عَشْرَةَ</span>, which is fem., <span class="add">[each signifying <em>Nineteen,</em>]</span> each of the two words ends with fet-ḥ in every case, because they are two nouns which are regarded as one noun. <span class="auth">(TA.)</span> The former is pronounced by some of the Arabs <span class="ar long">تِسْعَةَ عْشَرَ</span>: <span class="pb" id="Page_0307"></span>and the latter, thus in the dial. of El-Hijáz <span class="add">[and of most of the Arabs]</span>, is pronounced <span class="ar long">تِسْعَ عَشِرَةَ</span> in the dial. of Nejd. <span class="auth">(Ṣ in art. <span class="ar">عشر</span>.)</span> In the Ḳur lxxiv. 30, some read, <span class="ar long">تِسْعَةَ عْشَرَ</span>, making the <span class="ar">ع</span> in <span class="ar">عشر</span> quiescent, instead of <span class="ar long">تِسْعَهَ عَشَرَ</span>, from a dislike of this consecution of vowels in what is like one word. <span class="auth">(Bḍ, TA.*)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tisoEuwna">
				<h3 class="entry"><span class="add">[<span class="ar">تِسْعُونَ</span>]</span></h3>
				<div class="sense" id="tisoEuwna_A1">
					<p><span class="add">[<span class="ar">تِسْعُونَ</span>, <em>Ninety:</em> and <em>ninetieth.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tusaAEa">
				<h3 class="entry"><span class="ar">تُسَاعَ</span></h3>
				<div class="sense" id="tusaAEa_A1">
					<p><span class="add">[<span class="ar">تُسَاعَ</span>, as meaning <em>Nine and nine,</em> or <em>nine and nine together,</em> or <em>nine at a time and nine at a time,</em> seems not to have been in use.]</span> A'Obeyd says that more than <span class="ar">أُحَادَ</span> and <span class="ar">ثُنَآءَ</span> and <span class="ar">ثُلَاثَ</span> and <span class="ar">رُبَاعَ</span> has not been heard, except <span class="ar">عُشَارَ</span> occurring in a verse of El-Kumeyt. <span class="auth">(TA in art. <span class="ar">عشر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tasiyEN">
				<h3 class="entry"><span class="ar">تَسِيعٌ</span></h3>
				<div class="sense" id="tasiyEN_A1">
					<p><span class="ar">تَسِيعٌ</span>: <a href="#tusoEN">see <span class="ar">تُسْعٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAsiEN">
				<h3 class="entry"><span class="ar">تَاسِعٌ</span></h3>
				<div class="sense" id="taAsiEN_A1">
					<p><span class="ar">تَاسِعٌ</span> <span class="add">[<em>Making to be nine with himself,</em> or <em>itself:</em> and hence, <em>ninth</em>]</span>. You say, <span class="ar long">هُوَ تَاسِعُ تِسْعَةٍ</span> <span class="add">[<em>He is the ninth of nine</em>]</span>: and <span class="ar long">تَاسِعُ ثَمَانِيَةٍ</span> <span class="add">[He is <em>making eight to be nine with himself</em>]</span>: but it is not allowable to say, <span class="ar long">تَاسِعٌ تِسْعَةً</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تسع</span> - Entry: <span class="ar">تَاسِعٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAsiEN_A2">
					<p><span class="add">[<span class="ar long">تَاسِعَ عَشَرَ</span> and <span class="ar long">تَاسِعَةَ عَشْرَةَ</span>, the former masc. and the latter fem., meaning <em>Nineteenth,</em> are subject to the same rules as <span class="ar long">ثَالِثَ عَشَرَ</span> and its fem., <a href="index.php?data=04_v/045_vlv">explained in art. <span class="ar">ثلث</span>, q. v.</a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAsuwEaMCu">
				<h3 class="entry"><span class="ar">تَاسُوعَآءُ</span></h3>
				<div class="sense" id="taAsuwEaMCu_A1">
					<p><span class="ar">تَاسُوعَآءُ</span>, <span class="auth">(Mṣb, TA, &amp;c.,)</span> or <span class="ar">التَّاسُوعَآءُ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>The tenth day of</em> <span class="add">[<em>the month</em>]</span> <em>El-Moharram;</em> <span class="auth">(Mṣb, TA;)</span> <span class="add">[<em>the day</em>]</span> <em>before the day of</em> <span class="ar">العَاشُورَآءُ</span>, <span class="auth">(Ṣ,)</span> or <em>before the day of</em> <span class="ar">عَاشُورَآءُ</span>: <span class="auth">(Ḳ:)</span> or, accord. to some, <em>the same as the day of</em> <span class="ar">العاشوراء</span>: <span class="auth">(TA:)</span> <span class="add">[<a href="#EAXwrAC">see <span class="ar">عاشوراء</span></a>, where this is explained:]</span> it is a post-classical word: <span class="auth">(Ṣgh, Ḳ:)</span> J says, in the Ṣ, I think it post-classical: <span class="auth">(Mṣb, TA:)</span> but <span class="add">[SM says,]</span> this requires consideration; for it was used by the Prophet: <span class="auth">(TA:)</span> one ought to say, that, with <span class="ar">عاشوراء</span>, it has this form for the sake of resemblance; but as used alone, it must be conceded that it has not been heard <span class="add">[from the Arabs of the classical times]</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutasBaEN">
				<h3 class="entry"><span class="add">[<span class="ar">مُتَسَّعٌ</span>]</span></h3>
				<div class="sense" id="mutasBaEN_A1">
					<p><span class="add">[<span class="ar">مُتَسَّعٌ</span> pass. part. n. of 2, q. v. <a href="#muvalBavN">See also <span class="ar">مُثَلَّثٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matosuwEN">
				<h3 class="entry"><span class="ar">مَتْسُوعٌ</span></h3>
				<div class="sense" id="matosuwEN_A1">
					<p><span class="ar">مَتْسُوعٌ</span> A rope <em>consisting of nine strands.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0306.pdf" target="pdf">
							<span>Lanes Lexicon Page 306</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0307.pdf" target="pdf">
							<span>Lanes Lexicon Page 307</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
