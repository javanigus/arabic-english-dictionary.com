<article class="root" id="Root_tbn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/009_tbl">تبل</a></span>
				<span class="ar">تبن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/011_tbh">تبه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tbn_1">
				<h3 class="entry">1. ⇒ <span class="ar">تبن</span></h3>
				<div class="sense" id="tbn_1_A1">
					<p><span class="ar">تَبَنَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْبِنُ</span>}</span></add>, <span class="auth">(Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَبْنٌ</span>, <span class="auth">(Ṣ,)</span> <em>He fed</em> a beast <em>with</em> <span class="ar">تِبْن</span> <span class="add">[q. v.]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tbn_1_A2">
					<p>Also <em>He sold</em> <span class="add">[<span class="ar">تِبْن</span>, i. e.]</span> <em>straw.</em> <span class="auth">(KL.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tbn_1_B1">
					<p><span class="ar">تَبِنَ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْبَنُ</span>}</span></add>, <span class="auth">(Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَبَنٌ</span>, <span class="auth">(T, Ṣ,)</span> or <span class="ar">تَبْنٌ</span>, <span class="auth">(M, Ḳ,)</span> and <span class="ar">تَبَانَةٌ</span> <span class="auth">(T, Ṣ,* M, Ḳ)</span> and <span class="ar">تَبَانِيَةٌ</span>, <span class="auth">(M,)</span> <em>He was,</em> or <em>became, intelligent, sagacious, skilful,</em> or <em>knowing;</em> syn. <span class="ar">فَطِنَ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">صَارَ فَطِنًا</span>; <span class="auth">(Ṣ;)</span> <em>and nice,</em> or <em>minute, in inspection</em> <span class="auth">(Ṣ, Ḳ)</span> <em>into affairs:</em> <span class="auth">(Ṣ:)</span> or <span class="ar">تَبَانَةٌ</span> signifies the <em>being very intelligent</em> or <em>sagacious</em> or <em>skilful</em> or <em>knowing, and nice,</em> or <em>minute, in inspection;</em> as also <span class="ar">طَبَانَهٌ</span>; accord. to AO and AA: <span class="auth">(T:)</span> these two words signify the same <span class="auth">(T, Ṣ, M *)</span> accord. to <span class="add">[most of]</span> the leading authorities: <span class="auth">(T:)</span> and Yaạḳoob asserts that the <span class="ar">ت</span> is a substitute for <span class="ar">ط</span>: <span class="auth">(M:)</span> <span class="add">[or the reverse seems to be the case in the opinion of Az, who here remarks that there are many instances of the change of <span class="ar">ت</span> into <span class="ar">ط</span>:]</span> or the former is <em>in evil;</em> and the latter, in good: <span class="auth">(M:)</span> or, accord. to Lth, <span class="ar">طَبِنَ</span> means in evil; and <span class="ar">تَبِنَ</span>, <em>in good;</em> so that he makes <span class="ar">طبانة</span> to be in deceiving, or beguiling, and suddenly, or unexpectedly, attacking or destroying: but En-Naḍr says the contr.; and accord. to him, <span class="ar">طَبَنٌ</span> signifies the having knowledge of affairs, and intelligence, or sagacity, and science: <span class="auth">(T:)</span> and<span class="arrow"><span class="ar">تبّن↓</span></span>, inf. n. <span class="ar">تَتْبِينٌ</span> signifies the same as <span class="ar">تَبِنَ</span>: <span class="auth">(Ḳ:)</span> or <em>he inspected nicely,</em> or <em>minutely:</em> as in a trad. in which it is said, respecting a woman whose husband has died leaving her pregnant, <span class="ar long">يُنْفَقُ عَلَيْهَا مِنْ جَمِيعِ المَالِ حَتَّى تَبَّنْتُمْ مَا تَبَّنْتُمْ</span>, meaning <span class="add">[<em>She shall be expended upon from the whole of the property</em>]</span> <em>until ye make a nice,</em> or <em>minute, inspection</em> <span class="add">[into the circumstances of the case]</span>, and say otherwise, <span class="auth">(T, Ṣ,)</span> i. e., that she shall be expended upon from her own share: <span class="auth">(T:)</span> and so in another trad., in which it is said, <span class="ar long">إِنَّ الرَّجُلَ لَيَتَكَلَّمُ بِالكَلِمَةِ يُتَبِّنُ فِيهَا يَهْوِى بِهَا فِى النَّارِ</span>, <span class="auth">(AʼObeyd, T, M,)</span> i. e. <span class="add">[<em>Verily a man will say a saying</em>]</span> <em>in which he will be nice,</em> or <em>minute</em> <span class="add">[in expression, <em>whereby he will fall into the fire</em> of Hell]</span>: <span class="auth">(TA:)</span> here AʼObeyd thinks the meaning to be the making language obscure, or abstruse, and disputing in a matter of religion. <span class="auth">(T.)</span> You say also, <span class="ar long">تَبِنَ لَهُ</span> <span class="auth">(T, M, TA)</span> <em>He understood it;</em> or <em>knew it;</em> or <em>had knowledge,</em> or <em>was cognizant, of it;</em> <span class="auth">(TA;)</span> <em>i. q.</em> <span class="ar">طَبِنَ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbn_2">
				<h3 class="entry">2. ⇒ <span class="ar">تبّن</span></h3>
				<div class="sense" id="tbn_2_A1">
					<p><span class="ar">تبّن</span>, inf. n. <span class="ar">تَتْبِينٌ</span>: <a href="#tbn_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tbn_2_B1">
					<p><span class="ar">تَبْنّهُ</span>, inf. n. as before, <em>He clad him with a</em> <span class="ar">تُبَّان</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbn_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّبن</span></h3>
				<div class="sense" id="tbn_8_A1">
					<p><span class="ar">اِتَّبَنَ</span> <em>He clad himself with a</em> <span class="ar">تُبَّان</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tabonN">
				<h3 class="entry"><span class="ar">تَبْنٌ</span></h3>
				<div class="sense" id="tabonN_A1">
					<p><span class="ar">تَبْنٌ</span>: <a href="#tibonN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tibonN">
				<h3 class="entry"><span class="ar">تِبْنٌ</span> / <span class="ar">تِبْنَةٌ</span></h3>
				<div class="sense" id="tibonN_A1">
					<p><span class="ar">تِبْنٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ, &amp;c.)</span> and<span class="arrow"><span class="ar">تَبْنٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <em>Straw;</em> i. e. the <em>stalks,</em> or <em>stems,</em> (<span class="ar">عَصِيف</span>, M, Ḳ,) or the <em>stalk,</em> or <em>stem,</em> (<span class="ar">سَاق</span>, Mṣb,) <em>of seed-produce,</em> <span class="auth">(M, Mṣb, Ḳ,)</span> <em>such as wheat and the like,</em> <span class="auth">(M, Ḳ,)</span> <span class="add">[generally]</span> <em>after it has been trodden</em> or <em>thrashed</em> <span class="add">[<em>and cut</em>]</span>; <span class="auth">(Mṣb;)</span> <em>wheat when it has been trodden</em> or <em>thrashed</em> <span class="add">[<em>and cut</em>]</span> <em>by the feet of beasts</em> or <em>by repeatedly drawing over it the</em> <span class="add">[<em>machine called</em>]</span> <span class="ar">مِدْوَس</span> <span class="add">[q. v.]</span>: <span class="auth">(Mgh in art. <span class="ar">دوس</span>:)</span> <span class="add">[a coll. gen. n.:]</span> n. un. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تِبْنَةٌ</span>}</span></add> <span class="add">[signifying <em>a straw,</em> or <em>piece of straw</em>]</span>. <span class="auth">(Ṣ, M.)</span> You say <span class="ar long">أَقَلُّ مِنْ تِبْنَةٍ</span> <span class="add">[<em>Less than a straw,</em> or <em>piece of straw</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: <span class="ar">تِبْنٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tibonN_B1">
					<p>Also, the former, <em>A great bowl:</em> <span class="auth">(Ṣ:)</span> or <em>a bowl that satisfies the thirst of twenty:</em> <span class="auth">(Ḳ:)</span> or the <em>greatest of bowls, that almost satisfies the thirst of twenty:</em> <span class="auth">(Ks, Ṣ, M:)</span> next is the <span class="ar">صَحْن</span>, which is nearly equal thereto: then, the <span class="ar">عُسّ</span>, that satisfies the thirst of three and of four: then, the <span class="ar">قَدَح</span>, that satisfies the thirst of two men: then, the <span class="ar">قَعْب</span>, that satisfies the thirst of one man: then, the <span class="ar">غُمَر</span>: <span class="auth">(Ks, Ṣ:)</span> or <em>a bowl of rude,</em> or <em>rough, make; not made neatly,</em> or <em>skilfully.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: <span class="ar">تِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tibonN_B2">
					<p><span class="add">[Hence, probably,]</span> † <em>A liberal,</em> or <em>bountiful, and noble, chief.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: <span class="ar">تِبْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="tibonN_B3">
					<p>And <em>A wolf.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabinN">
				<h3 class="entry"><span class="ar">تَبِنٌ</span></h3>
				<div class="sense" id="tabinN_A1">
					<p><span class="ar">تَبِنٌ</span> <em>Intelligent, sagacious, skilful,</em> or <em>knowing; and nice,</em> or <em>minute, in inspection</em> <span class="auth">(Ṣ, M, Ḳ)</span> <em>into affairs;</em> <span class="auth">(Ṣ;)</span> as also <span class="ar">طَبِنٌ</span>: <span class="auth">(M:)</span> <span class="add">[or <em>very intelligent,</em>, &amp;c.: and accord. to some, <em>in evil:</em> or <em>in good:</em> <a href="#tabina">see <span class="ar">تَبِنَ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبن</span> - Entry: <span class="ar">تَبِنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tabinN_A2">
					<p>And One <em>who plays with his hand with everything.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabBaAnN">
				<h3 class="entry"><span class="ar">تَبَّانٌ</span></h3>
				<div class="sense" id="tabBaAnN_A1">
					<p><span class="ar">تَبَّانٌ</span> <em>A seller of</em> <span class="ar">تِبْن</span>: <span class="auth">(Ṣ, M, Ḳ:)</span> thus, perfectly decl., if of the measure <span class="ar">فَعَّال</span>, from <span class="ar">التِّبْنُ</span>: but if of the measure <span class="ar">فَعْلَان</span>, from <span class="ar">التَّبُّ</span> <span class="add">[the act of cutting <span class="auth">(for <span class="ar">تِبْن</span> is generally cut by the thrashingmachine)</span>]</span>, it is <span class="add">[<span class="ar">تَبَّانُ</span>,]</span> imperfectly decl. <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tubBaAnN">
				<h3 class="entry"><span class="ar">تُبَّانٌ</span></h3>
				<div class="sense" id="tubBaAnN_A1">
					<p><span class="ar">تُبَّانٌ</span> <em>Small</em> <span class="ar">سَرَاوِيل</span> <span class="add">[or <em>breeches</em>]</span>, <span class="auth">(Ṣ, Mgh, Ḳ,)</span> <em>without legs,</em> <span class="add">[i. e. <em>having only two holes through which to put the legs,</em>]</span> <span class="auth">(TA in art. <span class="ar">ثفر</span>,)</span> <span class="add">[<em>made of linen,</em> and <em>of leather,</em>]</span> <em>of the measure of a span,</em> <span class="auth">(Ṣ, Mgh,)</span> <em>such as to conceal the anterior and posterior pudenda</em> <span class="auth">(Ṣ, Mgh, Ḳ, TA)</span> <em>only;</em> <span class="auth">(TA;)</span> <em>worn by sailors</em> <span class="auth">(Ṣ, Mgh)</span> <span class="add">[<em>and by wrestlers</em>]</span>: or <em>a thing like</em> <span class="ar">سراويل</span>: <span class="auth">(M, Mṣb:)</span> or <em>a thing like small</em> <span class="ar">سراويل</span>: <span class="auth">(T:)</span> <span class="add">[it is an arabicized word, from the Persian <span class="ar">تُنْبَانٌ</span>:]</span> the Arabs make it masc. <span class="auth">(T, M, Mṣb)</span> and fem.: <span class="auth">(Mṣb:)</span> pl. <span class="ar">تَبَابِينُ</span>. <span class="auth">(T, Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabBaAnapN">
				<h3 class="entry"><span class="ar">تَبَّانَةٌ</span></h3>
				<div class="sense" id="tabBaAnapN_A1">
					<p><span class="ar">تَبَّانَةٌ</span> <span class="auth">(TA)</span> and<span class="arrow"><span class="ar">مَتْبَنَةٌ↓</span></span> <span class="auth">(Mgh, Mṣb, TA)</span> and<span class="arrow"><span class="ar">مَتْبَنٌ↓</span></span> <span class="auth">(Mgh, Mṣb)</span> The <em>place,</em> <span class="auth">(TA,)</span> or <em>house,</em> or <em>the like,</em> <span class="auth">(Mgh, Mṣb,)</span> <em>of</em> <span class="add">[or <em>for</em>]</span> <span class="ar">تِبْن</span>. <span class="auth">(Mgh, Mṣb, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="matobanN">
				<h3 class="entry"><span class="ar">مَتْبَنٌ</span></h3>
				<div class="sense" id="matobanN_A1">
					<p><span class="ar">مَتْبَنٌ</span>: <a href="#tabBaAnapN">see <span class="ar">تَبَّانَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="matobanapN">
				<h3 class="entry"><span class="ar">مَتْبَنَةٌ</span></h3>
				<div class="sense" id="matobanapN_A1">
					<p><span class="ar">مَتْبَنَةٌ</span>: <a href="#tabBaAnapN">see <span class="ar">تَبَّانَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matobuwnN">
				<h3 class="entry"><span class="ar">مَتْبُونٌ</span></h3>
				<div class="sense" id="matobuwnN_A1">
					<p><span class="ar">مَتْبُونٌ</span>, applied to a horse such as is termed <span class="ar">بِرْذَون</span>, <em>Of the colour of</em> <span class="ar">تِبْن</span> <span class="add">[or <em>straw</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0297.pdf" target="pdf">
							<span>Lanes Lexicon Page 297</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
