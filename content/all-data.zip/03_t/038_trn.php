<article class="root" id="Root_trn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/037_trms">ترمس</a></span>
				<span class="ar">ترن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/039_trnj">ترنج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="turonae">
				<h3 class="entry"><span class="ar">تُرْنَى</span></h3>
				<div class="sense" id="turonae_A1">
					<p><span class="ar">تُرْنَى</span> an appellation applied to <em>A female slave;</em> <span class="auth">(T, Ḳ)</span> and to <em>a fornicatress, an adulteress,</em> or <em>a prostitute;</em> <span class="auth">(M, Ḳ;)</span> as also <span class="ar">فَرْتَنَى</span>: <span class="auth">(T, Ḳ:)</span> and <span class="ar long">اِبْنُ تُرْنَى</span> means <em>the son of a fornicatress</em> or <em>an adulteress</em> or <em>a prostitute;</em> <span class="auth">(T, Ḳ;)</span> as also <span class="ar long">ابن فَرْتَنَى</span>: <span class="auth">(T:)</span> or <em>one that is base-born:</em> <span class="auth">(Ṣ in art. <span class="ar">رنو</span>:)</span> but it is said that <span class="ar">تُرْنَى</span> is of the measure <span class="ar">تُفعَلُ</span>, from <span class="ar">الرُّنُوُّ</span>: <span class="auth">(M:)</span> it may be from <span class="ar">رُنِيَتْ</span> meaning “she was looked at continuously.” <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0306.pdf" target="pdf">
							<span>Lanes Lexicon Page 306</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
