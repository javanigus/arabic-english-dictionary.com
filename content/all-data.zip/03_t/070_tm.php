<article class="root" id="Root_tm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/069_tle">تلى</a></span>
				<span class="ar">تم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/071_tmr">تمر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tm_1">
				<h3 class="entry">1. ⇒ <span class="ar">تمّ</span></h3>
				<div class="sense" id="tm_1_A1">
					<p><span class="ar long">تَمَّ الشَّىْءُ</span>, <span class="auth">(T, Ṣ, M, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْمِمُ</span>}</span></add>, <span class="auth">(T, M, Ḳ,)</span> inf. n. <span class="ar">تَمَامٌ</span>, <span class="auth">(T, Ṣ,)</span> or <span class="ar">تِمَامٌ</span>, <span class="auth">(M,)</span> or both, and <span class="ar">تُمَامٌ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar">تَمَامَةٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="ar">تِمَامَةٌ</span>, <span class="auth">(Ḳ,)</span> and <span class="ar">تمُّ</span> and <span class="ar">تَمٌّ</span> and <span class="ar">تُمٌّ</span>, <span class="auth">(M, Ḳ,)</span> of which last three forms the first is said to be the most chaste, <span class="auth">(TA,)</span> <span class="add">[<em>The thing was,</em> or <em>became, complete, entire, whole,</em> or <em>full;</em> i. e., <em>without,</em> or <em>free from, deficiency:</em> and sometimes, <em>the thing was,</em> or <em>became, consummate,</em> or <em>perfect;</em> which latter signification is more properly expressed by <span class="ar">كَمَلَ</span>:]</span> accord. to the author of the Ḳ, as is shown in art. <span class="ar">كمل</span>, and accord. to some others, <span class="ar">تَمَامٌ</span> and <span class="ar">كَمَالٌ</span> are syn.; but several authors make a distinction between them: the former is said to signify a thing's <em>being,</em> or <em>becoming, without,</em> or <em>free from, deficiency;</em> and the latter, to signify <span class="ar">تمام</span> and something more, as, for instance, goodliness, and excellence, essential or accidental; though each is sometimes used in the sense of the other: or, as some say, the former necessarily implies previous deficiency; but the latter does not: <span class="auth">(MF, TA:)</span> or, accord. to El-Harállee, the latter signifies the attaining to the utmost point, or degree, in every respect: or, as Ibn-El-Kemál says, when one says of a thing <span class="ar">كَمَلَ</span>, he means that what was desired of it became realized. <span class="auth">(TA.)</span> <span class="add">[<a href="#tamaAmN">See also <span class="ar">تَمَامٌ</span>, below</a>.]</span> You say, <span class="ar long">تَمَّ خَلْقُهُ</span> <span class="add">[<em>His make,</em> or <em>formation, was,</em> or <em>became, complete,</em> or <em>perfect; he</em> <span class="auth">(a child or the like, and a man,)</span> <em>was,</em> or <em>became, fully formed</em> or <em>developed,</em> or <em>complete in his members;</em> and <em>he</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, full-grown</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[whence, probably,]</span> <span class="ar long">تَمَّ الشَّىْءُ</span> <span class="add">[as meaning]</span> <em>The thing became strong and hard.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">تَمَّ القَمَرُ</span>, <span class="auth">(T, Ṣ, Mṣb,)</span> or<span class="arrow"><span class="ar">اتمّ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <em>The moon became full, so that it shone brightly.</em> <span class="auth">(M, Ḳ)</span> And, of her who is pregnant, <span class="ar long">تَمَّتْ أَيَّامُ حَمْلِهَا</span> <span class="add">[<em>The days of her gestation became complete</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tm_1_A2">
					<p><span class="ar long">تَمَّ إِلَى كَذَا</span> <em>He reached, attained, arrived at,</em> or <em>came to, such a thing;</em> as, for instance, eminence or nobility, or the means of acquiring eminence or nobility. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tm_1_A3">
					<p><span class="ar long">تَمَّ إِلَى مَوْضِعِ كَذَا</span>, and<span class="arrow"><span class="ar long">اتمّ↓ إِلَيْهِ</span></span>, <em>He repaired,</em> or <em>betook himself, to,</em> or <em>towards, such a place; he went to it.</em> <span class="auth">(Ḥar p. 508.)</span> Aboo-Dhu-eyb says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَبَاتَ بِجَمْعٍ ثُمَّ تَمَّ إِلَى مِنًى</span> *</div> 
					</blockquote>
					<p><span class="add">[which may be rendered <em>And he passed the night in Jema</em> <span class="auth">(a name of El-Muzdelifeh)</span>: <em>then he repaired,</em> or <em>went, to Minè;</em> there completing the ceremonies of the pilgrimage; wherefore ISd says,]</span> I think that, by <span class="ar">تمّ</span>, <span class="add">[or rather <span class="ar long">تمّ الى منى</span>,]</span> he means <em>he completed his pilgrimage.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tm_1_A4">
					<p><span class="ar long">تَمَّ بِهِ</span>, and <span class="ar long">تَمَّ عَلَيْهِ</span>: see their syn. <span class="ar">اتمّهُ</span> <span class="auth">(4)</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tm_1_A5">
					<p><span class="add">[Hence,]</span> <span class="ar long">تَمَّ عَلَيْهِ</span> <em>He performed it,</em> or <em>executed it; he accomplished it;</em> namely, an affair; a fast; a purpose, or an intention. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tm_1_A6">
					<p>And <em>He persevered in it;</em> <span class="auth">(Mgh, TA;)</span> as also <span class="ar long">تَمَمَ عَلَيْهِ</span>, without teshdeed, as in the phrase <span class="ar long">إِنْ تَمَمَتْ عَلَى مَا أُرِيدُ</span> <span class="add">[<em>If she persevere in what I desire</em>]</span>, occurring in a trad.; but IAth says that the verb here means <span class="arrow"><span class="ar">تَمَّمَتْ↓</span></span>. <span class="auth">(TA.)</span> You say, <span class="ar long">تَمَّ عَلَى الإبَآءِ</span> <em>He persevered in refusal,</em> or <em>dislike,</em> or <em>disapproval.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tm_1_B1">
					<p><span class="ar">تُمَّ</span> <em>It was broken.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tm_1_B2">
					<p>And <em>i. q.</em> <span class="ar">بلغ</span> <span class="add">[app. <span class="ar">بُلِغَ</span>, i. e. <em>He was jaded, harassed, distressed, fatigued,</em> or <em>wearied</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tm_2">
				<h3 class="entry">2. ⇒ <span class="ar">تمّم</span></h3>
				<div class="sense" id="tm_2_A1">
					<p><span class="ar">تَمَّمَهُ</span>: <a href="#tm_4">see its syn. <span class="ar">اتمّهُ</span></a>; <a href="#tm_1">and see also 1</a>, near the end of the paragraph.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tm_2_A2">
					<p><em>He,</em> or <em>it, destroyed it; made it to reach its appointed term of duration.</em> <span class="auth">(Sh, T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tm_2_A3">
					<p><span class="ar">تَمَّمَهُمْ</span> <em>He gave them the share of their arrow in the game called</em> <span class="ar">المَيْسِر</span>; <span class="auth">(IAạr, M, Ḳ;)</span> i. e. <em>he gave them to eat the flesh which was their share.</em> <span class="auth">(M.)</span> Accord. to Lḥ, <span class="ar">التَّتْمِيمُ</span> in the game called <span class="ar">الميسر</span> signifies A man's <em>taking what has remained, so as to complete the shares,</em> or <em>make up their full number, when the players have diminished from the slaughtered camel</em> <span class="add">[<em>by taking their shares</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tm_2_A4">
					<p><span class="ar long">تّمم عَلَى الجَرِيحِ</span> ‡ <em>He hastened and completed the slaughter of the wounded man:</em> or <em>made his slaughter sure,</em> or <em>certain.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tm_2_B1">
					<p><span class="ar long">تّمم الكَسْرُ</span>, <span class="auth">(M, Ḳ,)</span> and<span class="arrow"><span class="ar">تتمّم↓</span></span>, <span class="auth">(M, TA,)</span> in the copies of the Ḳ, erroneously, <span class="ar">تَمَّ</span>, <span class="auth">(TA,)</span> <span class="add">[in the CK, <span class="ar">تّمم</span> again,]</span> i. e. <span class="add">[<em>The fracture,</em> or <em>the broken bone,</em> or simply <em>the bone,</em>]</span> <em>cracked, without separating</em> (<span class="ar long">وَلَمْ يَبِنْ</span>): or <em>cracked, and then separated.</em> <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">تَمَّمَ الكَسْرَ فَتَمَّمَ</span> and<span class="arrow"><span class="ar">تَتَمَّمَ↓</span></span> <span class="add">[<em>He,</em> or <em>it, completed the fracture,</em> or <em>cracked the broken bone,</em> or <em>the bone, and it cracked,</em>, &amp;c.]</span>. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">ظَلَعَ فُلَانٌ ثُمَّ تَتَمَّمَ↓</span></span>, i. e. <span class="add">[<em>Such a one limped,</em> or <em>halted,</em> or <em>was slightly lame: then</em>]</span> <em>his lameness became complete by fracture:</em> from <span class="ar">تُمَّ</span> signifying “it was broken:” <span class="auth">(T:)</span> <span class="add">[or <span class="ar">تَتَمَّمَ</span> signifies <em>his lameness became complete by an increased fracture, after he had had a fracture with which he was able to walk:</em> this is what is meant by the following loose explanation:]</span> <span class="ar long">التَّتَمُّمُ مَنْ كَانَ بِهِ كَسْرٌ يَمْشِى بِهِ ثُمَّ أَبَتَّ فَتَتَمَّمَ</span>. <span class="auth">(Ḳ. <span class="add">[In the CK, <span class="ar">اَبَّتَ</span> is here erroneously put for <span class="ar">أَبَتَّ</span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="tm_2_C1">
					<p><span class="ar long">تمّم الَمَوْلُودَ</span> <em>He hung</em> <span class="ar">تَمَائِم</span>, <span class="auth">(Th, M,)</span> or <em>a</em> <span class="ar">تَمِيمَة</span>, <span class="auth">(Ḳ,)</span> <em>upon the new-born child,</em> or <em>young infant.</em> <span class="auth">(Th, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="tm_2_C2">
					<p><span class="ar long">تَمَّمْتُ عَنْهُ العَيْنَ</span> <em>I repelled from him the evil eye by hanging</em> <span class="add">[<em>upon him</em>]</span> <em>the</em> <span class="ar">تَمِيمَة</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="tm_2_D1">
					<p><span class="ar">تمّم</span> also signifies <em>He became, in the inclination of his mind,</em> <span class="auth">(Lth, T, M, Ḳ,)</span> <em>and in his opinion, and his place of abode</em> or <em>settlement,</em> <span class="auth">(Lth, T, Ḳ,)</span> <em>as one of the tribe of Temeem;</em> <span class="auth">(Lth, T, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تتمّم↓</span></span>; <span class="auth">(Ḳ, TA; <span class="add">[in the CK, <span class="ar">تمّم</span> again;]</span>)</span> or accord. to analogy it would be <span class="ar">تتمّم</span>, like <span class="ar">تمضّر</span> and <span class="ar">تنزّر</span>. <span class="auth">(T.)</span> And <em>He asserted himself to be related to the tribe of Temeem.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tm_3">
				<h3 class="entry">3. ⇒ <span class="ar">تامّ</span></h3>
				<div class="sense" id="tm_3_A1">
					<p><span class="ar">مُتَامّةٌ</span> <span class="add">[inf. n. of <span class="ar">تَامَّ</span>]</span> The <em>vying,</em> or <em>contending, with another in completeness,</em> or <em>perfection.</em> <span class="auth">(KL.)</span> <span class="add">[You say, <span class="ar">تامّهُ</span> <em>He vied,</em> or <em>contended, with him</em>, &amp;c.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tm_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتمّ</span></h3>
				<div class="sense" id="tm_4_A1">
					<p><span class="ar">اتمّ</span>, said of the moon: <a href="#tm_1">see 1</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tm_4_A2">
					<p>Said of a plant, <em>It became tall and full-grown;</em> or <em>became of its full height, and blossomed.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tm_4_A3">
					<p><span class="ar">أَتَمَّتْ</span>, said of one that is pregnant, <em>She completed the days of her gestation:</em> <span class="auth">(Ṣ:)</span> or, said of a woman and of a she-camel, <span class="auth">(M,)</span> <em>she became near to bringing forth.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tm_4_A4">
					<p><span class="ar long">اتّم إِلَى مَوْضِعِ كَذَا</span>: <a href="#tm_1">see 1</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tm_4_B1">
					<p><span class="ar long">اتمّ الشَّىْءَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> or <span class="ar">الأَمْرَ</span>, <span class="auth">(Mgh,)</span> and <span class="ar long">اتمّ بِهِ</span>, <span class="auth">(M,)</span> inf. n. <span class="ar">إِتْمَامٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">تمّمهُ↓</span></span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> inf. n. <span class="ar">تَتْمِيمٌ</span> and <span class="ar">تَتِمَّةٌ</span>; <span class="auth">(T, TA;)</span> and<span class="arrow"><span class="ar">استتمّهُ↓</span></span>; <span class="auth">(Ṣ, Mgh, Ḳ;)</span> and<span class="arrow"><span class="ar long">تَمَّ↓ بِهِ</span></span>, and<span class="arrow"><span class="ar long">تَمَّ↓ عَلَيْهِ</span></span>; <span class="auth">(M, Ḳ;)</span> signify the same; <span class="auth">(Ṣ Mgh;)</span> i. e. <span class="ar long">جَعَلَهُ تَامَّا</span> <span class="auth">(M in explanation of all but the last, and Ḳ in explanation of all that are mentioned therein,)</span> and <span class="ar">أَكْمَلَهُ</span> <span class="auth">(M in explanation of the last)</span> <span class="add">[<em>He made the thing,</em> or <em>the affair, complete, entire, whole,</em> or <em>full;</em> i. e., <em>without,</em> or <em>free from, deficiency; he completed it:</em> and sometimes, <em>he consummated,</em> or <em>perfected, it</em>]</span>. <span class="ar long">وَأَتِمُّو الحَجَّ وَالعُمْرَةَ</span>, in the Ḳur <span class="add">[ii. 192]</span>, means <em>And perform ye,</em> or <em>accomplish ye, completely, the rites and ceremonies</em> <span class="add">[<em>of the pilgrimage and the minor pilgrimage</em>]</span>; <span class="auth">(M,* Bḍ;)</span> accord. to some: or, as some say, <span class="ar long">إِتْمَامُ الحَجِّ</span> means that the money, or the like, that one expends in performing the pilgrimage should be lawfully obtained, and that one should refrain from doing what God has forbidden. <span class="auth">(M.)</span> And <span class="ar">فَأَتَمَّهُنَّ</span>, in the Ḳur <span class="add">[ii. 118]</span>, means <em>And he performed them,</em> or <em>accomplished them, completely,</em> <span class="auth">(Bḍ, Jel,)</span> <em>and rightly:</em> <span class="auth">(Bḍ:)</span> or <em>he did according to them.</em> <span class="auth">(Fr, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="tm_4_C1">
					<p><span class="ar">اتمّهُ</span> <em>He gave him what are termed</em> <span class="ar">تِمَم</span>, <a href="#timBapN">pl. of <span class="ar">تِمَّةٌ</span></a>, and meaning <span class="ar">جِزَز</span> <span class="add">[explained below, voce <span class="ar">تِمَّةٌ</span>]</span>, <span class="auth">(M, TA,)</span> <em>in order that he might complete therewith his web.</em> <span class="auth">(TA.)</span> <span class="add">[In consequence of its being misplaced in the Ḳ, this is there made to signify <em>He gave him a</em> <span class="ar">تِمّ</span>, meaning a <span class="ar">فَأْس</span> or a <span class="ar">مِسْحَاة</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tm_5">
				<h3 class="entry">5. ⇒ <span class="ar">تتمّم</span></h3>
				<div class="sense" id="tm_5_A1">
					<p><a href="#tm_2">see 2</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tm_6">
				<h3 class="entry">6. ⇒ <span class="ar">تتامّ</span></h3>
				<div class="sense" id="tm_6_A1">
					<p><span class="ar">تَتَامُّوا</span> <em>They came,</em> <span class="add">[and also, accord. to Golius, app. on the authority of a gloss in a copy of the KL, <em>they drank,</em>]</span> <em>all of them, and were complete.</em> <span class="auth">(Ṣ, Ḳ.)</span> One says, <span class="ar long">اِجْتَمَعُوا فَتَتَامُّوا عَشَرَةً</span> <span class="add">[<em>They collected themselves together, and came, all of them, making altogether ten</em>]</span>. <span class="auth">(TA.)</span> And it is said in a trad., <span class="ar long">تَتَامَّتْ إِلَيْهِ قُرَيْشٌ</span>, i. e. <em>Kureysh obeyed his call, and came to him, all of them, following one another.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tm_10">
				<h3 class="entry">10. ⇒ <span class="ar">استتمّ</span></h3>
				<div class="sense" id="tm_10_A1">
					<p><span class="ar">استتمّهُ</span>: <a href="#tm_4">see 4</a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tm_10_A2">
					<p><span class="ar long">استتّم النِّعْمَةَ</span> <em>He asked for the completion of the benefit, or boon,</em> or <em>favour.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tm_10_B1">
					<p><em>He sought, demanded,</em> or <em>requested, of him what are termed</em> <span class="ar">تِمّم</span>, <a href="#timBapN">pl. of <span class="ar">تِمَّةٌ</span></a>, and meaning <span class="ar">جِزَز</span> <span class="add">[explained below, voce <span class="ar">تِمَّةٌ</span>]</span>, <span class="auth">(M, TA,)</span> <em>in order that he might complete therewith his web.</em> <span class="auth">(TA.)</span> <span class="add">[In consequence of its being misplaced in the Ḳ, this is there made to signify <em>He sought, demanded,</em> or <em>requested, of him a</em> <span class="ar">تِمّ</span>, meaning a <span class="ar">فَأْس</span> or a <span class="ar">مِسْحَاة</span>.]</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="tm_RQ1">
				<span class="pb" id="Page_0316"></span>
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">تمتم</span></h3>
				<div class="sense" id="tm_RQ1_A1">
					<p><span class="ar">تَمْتَمَةٌ</span> is the inf. n. of <span class="ar">تَمْتَمَ</span>, <span class="auth">(Mṣb,)</span> and signifies The <em>reiterating in uttering the letter</em> <span class="ar">ت</span>: <span class="auth">(Mbr, Zj in his “Khalk el-Insán,” T, Ṣ, Mṣb:)</span> <span class="add">[if so, <em>syn. with</em> <span class="ar">تَأْتَأَةٌ</span>:]</span> or the <em>tongue's pronouncing indistinctly, missing the place of the letter,</em> <span class="add">[i. e. <em>the place of its pronunciation in the organs of speech,</em>]</span> <em>and recurring to an utterance like</em> <span class="ar">ت</span> <em>and</em> <span class="ar">م</span>, <em>though this be not distinct:</em> <span class="auth">(Lth, T:)</span> or the <em>making the speech</em> <span class="add">[or <em>tongue</em>]</span> <em>to revert</em> <span class="add">[<em>repeatedly</em>]</span> <em>to</em> <span class="ar">ت</span> <em>and</em> <span class="ar">م</span>: <span class="auth">(M, Ḳ:)</span> or the <em>jabbering,</em> or <em>hurrying in one's speech, so as hardly, or not at all, to make a person understand:</em> <span class="auth">(M:)</span> or the <em>uttering in such a manner that one's speech proceeds rapidly to the roof of his mouth.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tamBN">
				<h3 class="entry"><span class="ar">تَمٌّ</span></h3>
				<div class="sense" id="tamBN_A1">
					<p><span class="ar">تَمٌّ</span> <a href="#tm_1">an inf. n. of 1</a>, in the first of the senses explained above. <span class="auth">(M, Ḳ.)</span> <a href="#tamaAmN">See <span class="ar">تَمَامٌ</span></a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَمٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tamBN_B1">
					<p><a href="#timBapN">See also <span class="ar">تِمَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tumBN">
				<h3 class="entry"><span class="ar">تُمٌّ</span></h3>
				<div class="sense" id="tumBN_A1">
					<p><span class="ar">تُمٌّ</span> <a href="#tm_1">an inf. n. of 1</a>, in the first of the senses explained above. <span class="auth">(M, Ḳ.)</span> <a href="#tamaAmN">See <span class="ar">تَمَامٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="timBN">
				<h3 class="entry"><span class="ar">تِمٌّ</span></h3>
				<div class="sense" id="timBN_A1">
					<p><span class="ar">تِمٌّ</span> <a href="#tm_1">an inf. n. of 1</a>, in the first of the senses explained above. <span class="auth">(M, Ḳ.)</span> <a href="#tamaAmN">See <span class="ar">تَمَامٌ</span></a>, in five places:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تِمٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="timBN_A2">
					<p><a href="#taAmBN">and <span class="ar">تَامٌّ</span></a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تِمٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="timBN_B1">
					<p>Also <em>i. q.</em> <span class="ar">فَأْسٌ</span> <span class="add">[app. here meaning <em>A kind of hoe</em>]</span>: <span class="auth">(IAạr, T, Ḳ:)</span> or <em>i. q.</em> <span class="ar">مِسْحَاةٌ</span> <span class="add">[<em>a spade,</em> or <em>a shovel</em>]</span>: <span class="auth">(Ḳ:)</span> pl. <span class="ar">تِمَمَةٌ</span> <span class="auth">(IAạr, T,)</span> or <span class="ar">تِمَمٌ</span>. <span class="auth">(So in the TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tumBapN">
				<h3 class="entry"><span class="ar">تُمَّةٌ</span></h3>
				<div class="sense" id="tumBapN_A1">
					<p><span class="ar">تُمَّةٌ</span>: <a href="#timBapN">see what next follows</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="timBapN">
				<h3 class="entry"><span class="ar">تِمَّةٌ</span></h3>
				<div class="sense" id="timBapN_A1">
					<p><span class="ar">تِمَّةٌ</span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">تُمَّةٌ↓</span></span> <span class="auth">(TA)</span> <span class="add">[the former written in the CK <span class="ar">تَمَّةٌ</span>]</span> sings. of <span class="ar">تِمَمٌ</span> <span class="auth">(M, Ḳ, TA)</span> and <span class="ar">تُمَمٌ</span>, <span class="auth">(Ḳ, TA,)</span> or<span class="arrow"><span class="ar">تَمَمٌ↓</span></span>, which <span class="add">[ISd says]</span> I think to be a quasi-pl. n., <span class="auth">(M,)</span> or<span class="arrow"><span class="ar">تَمٌّ↓</span></span> is the quasi-pl. n.: <span class="auth">(Ḳ:)</span> these, i. e. the pls. and quasi-pl. n., signify <em>Shorn crops</em> (<span class="ar">جِزَز</span> <span class="add">[in the CK <span class="ar">جِزَر</span>, for which Golius appears to have found <span class="ar">حِرْز</span>, for he has rendered it by “<span class="la">amuletum</span>,” and Freytag has done the same,]</span>) <em>of</em> <span class="ar">شَعَر</span> <span class="add">[meaning <em>goats' hair</em>]</span>, and <em>of camels' hair,</em> and <em>of wool,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>of that wherewith a woman</em> <span class="add">[<em>or a man</em>]</span> <em>completes her</em> <span class="add">[<em>or his</em>]</span> <em>web:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">تُمَّةٌ↓</span></span> signifies <em>what is given, of wool,</em> or <em>camel's hair,</em> <span class="add">[or <em>goats' hair,</em>]</span> <span class="auth">(Ṣ, TA, <span class="add">[and mentioned also in the Ḳ, but there, by misplacement, made to relate to <span class="ar">تِمٌّ</span> instead of <span class="ar">تِمَّةٌ</span>,]</span>)</span> <em>for a man to complete therewith the weaving of his</em> <span class="ar">كِسَآء</span>; <span class="auth">(Ṣ;)</span> as also<span class="arrow"><span class="ar">تُمَّى↓</span></span>. <span class="auth">(Ḳ,* TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tumBae">
				<h3 class="entry"><span class="ar">تُمَّى</span></h3>
				<div class="sense" id="tumBae_A1">
					<p><span class="ar">تُمَّى</span>: <a href="#timBapN">see <span class="ar">تِمَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tamamN">
				<h3 class="entry"><span class="ar">تَمَمٌ</span></h3>
				<div class="sense" id="tamamN_A1">
					<p><span class="ar">تَمَمٌ</span>: <a href="#taAmBN">see <span class="ar">تَامٌّ</span></a>, in four places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَمَمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tamamN_B1">
					<p><a href="#timBapN">and see also <span class="ar">تِمَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamaAmN">
				<h3 class="entry"><span class="ar">تَمَامٌ</span></h3>
				<div class="sense" id="tamaAmN_A1">
					<p><span class="ar">تَمَامٌ</span> <span class="auth">(T, Ṣ, Ḳ)</span> and<span class="arrow"><span class="ar">تِمَامٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">تُمَامٌ↓</span></span> <span class="auth">(Ḳ)</span> inf. ns. of 1, in the first of the senses explained above; <span class="auth">(T, Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تِمٌّ↓</span></span> and<span class="arrow"><span class="ar">تَمٌّ↓</span></span> and<span class="arrow"><span class="ar">تُمٌّ↓</span></span>. <span class="auth">(M, Ḳ.)</span> <span class="add">[Hence,]</span><span class="arrow"><span class="ar long">وَلَدَتْهُ لِتِمٍّ↓</span></span> and<span class="arrow"><span class="ar">لِتِمَامٍ↓</span></span> and <span class="ar">لِتَمَامٍ</span> <em>She brought him forth at the completion of formation;</em> <span class="auth">(Ḳ, TA;)</span> i. e., <em>when his formation was complete:</em> <span class="auth">(TA:)</span> <span class="add">[or, <em>at the completion of gestation:</em>]</span> and, accord. to Aṣ, <span class="ar long">وَلَدَتْهُ التَّمَامَ</span>, with the art. <span class="ar">ال</span>; not indeterminate, except in poetry. <span class="auth">(IB, TA.)</span> And <span class="ar long">وَلَدَتْ لِتَمَامٍ</span> and<span class="arrow"><span class="ar">لِتِمَامٍ↓</span></span> <span class="add">[<em>She brought forth at the completion of formation;</em> or, <em>of gestation</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">أَلْقَتِ الوَلَدَ لِغَيْرِ تَمَامٍ</span> and<span class="arrow"><span class="ar">تِمَامٍ↓</span></span> <span class="add">[<em>She cast the child at a period not that of the completion of formation;</em> or, <em>of gestation;</em> i. e., <em>prematurely</em>]</span>. <span class="auth">(Mṣb.)</span> And <span class="ar long">وُلِدَ المَوْلُودُ لِتَمَامٍ</span> and<span class="arrow"><span class="ar">لِتِمَامٍ↓</span></span> <span class="add">[<em>The infant was born at the completion of formation;</em> or, <em>of gestation</em>]</span>. <span class="auth">(T,* Ṣ.)</span> And <span class="ar long">وُلِدَ الوَلَدُ لِتَمَامِ الحَمْلِ</span> and<span class="arrow"><span class="ar long">لِتِمَامِ↓ الحَمْلِ</span></span> <span class="add">[<em>The child was born at the completion of gestation</em>]</span>. <span class="auth">(Mṣb.)</span> <span class="add">[These exs., and others following, show that an assertion of IDrd, mentioned in the M, namely, that one says, <span class="arrow"><span class="ar long">وُلِدَ الغُلَامُ لِتِمٍّ↓</span></span> and<span class="arrow"><span class="ar">لِتِمَامٍ↓</span></span>, and<span class="arrow"><span class="ar long">بَدْرُ تِمَامٍ↓</span></span>, and that in every other case it is <span class="ar">تَمَام</span>, with fet-ḥ, requires consideration.]</span> You say also, <span class="ar long">بَدْرُ تَمَامٍ</span> and<span class="arrow"><span class="ar">تِمَامٍ↓</span></span> <span class="add">[lit. <em>The full moon of completion</em>]</span>: and<span class="arrow"><span class="ar long">بَدْرٌ تِمَامٌ↓</span></span> <span class="add">[lit. <em>A complete full moon</em>]</span>: all meaning <em>the moon,</em> or <em>a moon, when it is full, so that it shines brightly:</em> <span class="auth">(M, Ḳ:)</span> and <span class="ar long">قَمَرٌ تَمَامٌ</span> and<span class="arrow"><span class="ar">تِمَامٌ↓</span></span> <em>A complete,</em> or <em>full, moon.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">لَيْلَةُ التَّمَامِ</span> and <span class="ar long">لَيْلَةُ تَمَامِ القَمَرِ</span>, with fet-ḥ to the <span class="ar">ت</span>, <span class="auth">(ISh, T,)</span> or<span class="arrow"><span class="ar long">لَيلَةُ التِّمَامِ↓</span></span> with kesr, <span class="add">[which seems to be at variance with general usage,]</span> and sometimes with fet-ḥ, <span class="auth">(Mṣb,)</span> <span class="add">[<em>The night of the completion of the moon;</em> i. e.]</span> <em>the night of the full moon;</em> <span class="auth">(ISh, T, Mṣb;)</span> which is <em>the thirteenth night;</em> <span class="auth">(ISh, T;)</span> or <em>the fourteenth.</em> <span class="auth">(T.)</span> And<span class="arrow"><span class="ar long">لَيْلُ التِّمَامِ↓</span></span>, with kesr only, <span class="auth">(T, Ṣ, M, Ḳ, &amp;c.,)</span> thus distinguished from what next precedes, <span class="auth">(ISh, T,)</span> as also<span class="arrow"><span class="ar long">لَيْلُ تِمَامٍ↓</span></span>, and in like manner,<span class="arrow"><span class="ar long">لَيْلٌ تِمَامٌ↓</span></span> <span class="auth">(T)</span> and<span class="arrow"><span class="ar long">لَيْلٌ تِمَامِىٌّ↓</span></span>, <span class="auth">(T, Ḳ,)</span> <em>The longest night of the year;</em> <span class="auth">(Lth, T, Ṣ;)</span> <em>the longest night of winter;</em> <span class="auth">(Aṣ, ISh, T, M, Ḳ;)</span> <em>that in which our Lord Jesus was born:</em> <span class="auth">(Aṣ, T:)</span> or <em>each of three nights of which no deficiency is apparent:</em> <span class="auth">(Lth, T, M, Ḳ:)</span> or <em>the night that is from thirteen to fifteen hours in length:</em> <span class="auth">(Aboo-ʼAmr EshSheybánee, T:)</span> or <em>the night that is twelve hours or more in length:</em> <span class="auth">(AA, T, M, Ḳ:)</span> and <em>any night that is long,</em> or <em>tedious, to one, and in which one does not sleep,</em> is called<span class="arrow"><span class="ar long">لَيْلَةُ التِّمَامِ↓</span></span>, or said to be like the night thus called. <span class="auth">(IAạr, T.)</span> And<span class="arrow"><span class="ar long">رُئِىَ الهِلَالُ لِتِمِّ↓ الشَّهْرِ</span></span> <span class="add">[<em>The new moon was seen at the completion of the month;</em> showing that another month was commencing]</span>. <span class="auth">(T.)</span> And<span class="arrow"><span class="ar long">أَبَى قَائِلُهَا إِلَّا تِمًّا↓</span></span> and<span class="arrow"><span class="ar">تَمًّا↓</span></span> and<span class="arrow"><span class="ar">تُمًّا↓</span></span>, <span class="auth">(Ṣ, M,)</span> three dial. vars., of which the first is the most chaste, i. e., <span class="ar">تَمَامًا</span> <span class="add">[meaning <em>The sayer thereof refused,</em> or <em>did not consent to,</em> aught <em>save completion</em>]</span>; <em>he executed,</em> or <em>accomplished,</em> or <em>kept to, his saying; he did not go back from it.</em> <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tamaAmN_A2">
					<p><span class="ar">تَمَامٌ</span> <span class="auth">(with fet-ḥ only, AZ, AAF, M)</span> also signifies The <em>complement</em> of a thing; the <em>supplement</em> thereof; the <em>thing by the addition of which is effected the completion</em> or <em>perfection</em> of a thing; <span class="auth">(AZ, T, AAF, M, Ḳ;)</span> and so<span class="arrow"><span class="ar">تَمَامَةٌ↓</span></span> <span class="auth">(M, Ḳ)</span> and<span class="arrow"><span class="ar">تَتِمَّةٌ↓</span></span>. <span class="auth">(T, M, Ḳ.)</span> You say, <span class="ar long">هٰذِهِ الدَّرَاهِمُ تَمَامُ هٰذِهِ المِائَةِ</span>, and<span class="arrow"><span class="ar long">تَتِمَّةُ↓ هذه المائة</span></span>, <em>These dirhems are the complement of this hundred;</em> or, <em>what complete this hundred.</em> <span class="auth">(T.)</span> <span class="add">[And<span class="arrow"><span class="ar long">تَتِمَّةُ↓ كِتَابٍ</span></span> <em>The supplement of,</em> or <em>to, a book.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tamaAmN_A3">
					<p><a href="#taAmBN">See also <span class="ar">تَامٌّ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tumaAmN">
				<h3 class="entry"><span class="ar">تُمَامٌ</span></h3>
				<div class="sense" id="tumaAmN_A1">
					<p><span class="ar">تُمَامٌ</span>: <a href="#tamaAmN">see <span class="ar">تَمَامٌ</span></a>, first sentence.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="timaAmN">
				<h3 class="entry"><span class="ar">تِمَامٌ</span></h3>
				<div class="sense" id="timaAmN_A1">
					<p><span class="ar">تِمَامٌ</span>: <a href="#tamaAmN">see <span class="ar">تَمَامٌ</span></a>, throughout the greater part of the paragraph:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تِمَامٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="timaAmN_A2">
					<p><a href="#taAmBN">and see also <span class="ar">تَامٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamiymN">
				<h3 class="entry"><span class="ar">تَمِيمٌ</span></h3>
				<div class="sense" id="tamiymN_A1">
					<p><span class="ar">تَمِيمٌ</span> <em>Strong; firm; hard:</em> <span class="auth">(AʼObeyd, T, Ṣ, M, Mṣb, Ḳ:)</span> or <em>strong in make,</em> or <em>formation:</em> <span class="auth">(TA:)</span> or <em>complete,</em> or <em>perfect, in make,</em> or <em>formation, and strong:</em> <span class="auth">(M:)</span> applied to a man and to a horse: <span class="auth">(M, TA:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَمِيمَةٌ</span>}</span></add>. <span class="auth">(TA.)</span> <a href="#taAmBN">See also <span class="ar">تَامٌّ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَمِيمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tamiymN_A2">
					<p>Also <em>Tall;</em> <span class="auth">(T;)</span> applied to a man. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَمِيمٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tamiymN_B1">
					<p><a href="#tamiymapN">See also <span class="ar">تَمِيمَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tamaAmapN">
				<h3 class="entry"><span class="ar">تَمَامَةٌ</span></h3>
				<div class="sense" id="tamaAmapN_A1">
					<p><span class="ar">تَمَامَةٌ</span>: <a href="#tamaAmN">see <span class="ar">تَمَامٌ</span></a>, near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tumaAmapN">
				<h3 class="entry"><span class="ar">تُمَامَةٌ</span></h3>
				<div class="sense" id="tumaAmapN_A1">
					<p><span class="ar">تُمَامَةٌ</span> <em>A remainder,</em> or <em>remaining portion,</em> <span class="auth">(Ḳ,)</span> of anything. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamiymapN">
				<h3 class="entry"><span class="ar">تَمِيمَةٌ</span></h3>
				<div class="sense" id="tamiymapN_A1">
					<p><span class="ar">تَمِيمَةٌ</span> <em>A kind of amulet</em> (<span class="ar">عُوذَةٌ</span>, T, Ṣ) <em>which is hung upon a human being;</em> forbidden to be worn: <span class="auth">(Ṣ:)</span> or <em>a kind of bead:</em> <span class="auth">(Ṣ, Mgh:)</span> erroneously imagined by some to be the same as <span class="ar">مَعَاذَةٌ</span>: <span class="auth">(El-Ḳutabee, Mgh:)</span> but as to the <span class="ar">مَعَاذَات</span> that are inscribed with something from the Ḳur-án, or with the names of God, in these there is no harm: <span class="auth">(Ṣ, Mgh:)</span> <em>a speckled bead, black speckled with white,</em> or <em>the reverse, which is strung upon a thong, and tied to the neck:</em> <span class="auth">(M, Ḳ:)</span> <a href="#tamaAyimu">sing. of <span class="ar">تَمَائِمُ</span></a> and <span class="add">[n. un. of]</span> <span class="arrow"><span class="ar">تَمِيمٌ↓</span></span>: <span class="auth">(T, M, Ḳ:)</span> <span class="ar">تَمَائِمُ</span> signifies <em>certain beads which the Arabs of the desert used to hang upon their children, to repel, as they asserted, the evil eye:</em> <span class="auth">(T, Mgh:)</span> or the <span class="ar">تَمِيمَة</span> is, accord. to some, <em>a necklace</em> (<span class="ar">قِلَادَة</span>) <em>upon which are put thongs and amulets</em> (<span class="ar">عُوَذ</span>): <span class="auth">(M:)</span> or <em>a necklace</em> (<span class="ar">قِلَادَة</span>) <em>of thongs:</em> and is sometimes applied to the <em>amulet</em> (<span class="ar">عُوذَة</span>) <em>that is hung upon the necks of children:</em> <span class="auth">(T:)</span> but he who makes <span class="ar">تمائم</span> to signify <em>thongs</em> is in error: El-Farezdaḳ uses the phrase <span class="ar long">سُيُورُ التَّمَائِمِ</span> because they are <em>beads which are perforated, and into which are inserted thongs or strings whereby they are suspended:</em> <span class="auth">(T, Mgh:)</span> Az says, I have not found among the Arabs of the desert any difference of opinion respecting the <span class="ar">تميمة</span>, as to its being the bead itself: <span class="auth">(TA:)</span> but accord. to En-Nakha'ee, the Prophet disapproved of everything hung upon a child or grown person, and said that all such things were <span class="ar">تمائم</span>: <span class="auth">(Mgh:)</span> the <span class="ar">تميمة</span> is <span class="add">[said to be]</span> thus called because by it the condition of the child is rendered complete. <span class="auth">(Ḥar p. 22.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="timaAmieBN">
				<h3 class="entry"><span class="ar">تِمَامِىٌّ</span></h3>
				<div class="sense" id="timaAmieBN_A1">
					<p><span class="ar">تِمَامِىٌّ</span>: <a href="#tamaAmN">see <span class="ar">تَمَامٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamotaAmN">
				<h3 class="entry"><span class="ar">تَمْتَامٌ</span> / <span class="ar">تَمْتَامَةٌ</span></h3>
				<div class="sense" id="tamotaAmN_A1">
					<p><span class="ar">تَمْتَامٌ</span> One <em>whose utterance is such as is termed</em> <span class="ar">تَمْتَمَةٌ</span>: <span class="auth">(Ṣ, M, Mgh, Mṣb, Ḳ:)</span> <span class="add">[<a href="#tm_RQ1">see R. Q. 1</a>: accord. to most authorities,]</span> one <em>who reiterates in uttering the letter</em> <span class="ar">ت</span>: <span class="auth">(Ṣ, Mgh, Mṣb:)</span> or, accord. to AZ, one <em>who jabbers,</em> or <em>hurries in his speech, so as not to make another understand:</em> <span class="auth">(Mgh, Mṣb:)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَمْتَامَةٌ</span>}</span></add>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAmBN">
				<h3 class="entry"><span class="ar">تَامٌّ</span></h3>
				<div class="sense" id="taAmBN_A1">
					<p><span class="ar">تَامٌّ</span> <span class="add">[part. n. of 1 in the first of the senses explained above]</span>: <span class="auth">(T, M, Ḳ, &amp;c.:)</span> <em>Complete, entire, whole,</em> or <em>full; without,</em> or <em>free from, deficiency:</em> and <em>consummate,</em> or <em>perfect:</em> <span class="auth">(MF, TA:)</span> as also<span class="arrow"><span class="ar">تَمَامٌ↓</span></span>, <span class="add">[which see above,]</span> <span class="auth">(M,* KL,)</span> <span class="pb" id="Page_0317"></span><span class="add">[and<span class="arrow"><span class="ar">تِمَامٌ↓</span></span>, of which see three exs. voce <span class="ar">تَمَامٌ</span>,]</span> and<span class="arrow"><span class="ar">تِمٌّ↓</span></span>, <span class="auth">(Kh, T, Ḥar p. 82,)</span> and<span class="arrow"><span class="ar">تَمَمٌ↓</span></span>. <span class="auth">(TA.)</span> Thus <span class="ar long">تَامُّ الخَلْقِ</span> signifies <em>Complete,</em> or <em>perfect, in make,</em> or <em>formation; without any deficiency in his members;</em> applied to a man; <span class="auth">(MF, TA;)</span> <span class="add">[and, thus applied, signifying also <em>full-grown,</em> as does, sometimes, <span class="ar">تَامٌّ</span> alone: and likewise applied to a new-born child, meaning <em>fully formed</em> or <em>developed:</em>]</span> and<span class="arrow"><span class="ar">تَمِيمٌ↓</span></span> signifies the same, <span class="auth">(M, Ḳ,)</span> applied to a man and to a horse, <span class="auth">(M,)</span> and<span class="arrow"><span class="ar">تَمَمٌ↓</span></span> also; and in like manner is used the phrase <span class="arrow"><span class="ar long">خَلْقٌ تَمَمٌ↓</span></span> <span class="add">[<em>a complete,</em> or <em>perfect, make</em> or <em>formation</em>]</span>. <span class="auth">(TA.)</span> <span class="ar long">جَذَعٌ تَامٌّ</span> <span class="add">[applied to a goat]</span> signifies <em>That has completed the time in which he is termed</em> <span class="ar">جَذَع</span>, <em>and attained to that in which he is termed</em> <span class="ar">تَيْس</span>. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar">تَمَمٌ↓</span></span> is applied to a bull, or an ox, <em>That is in the stage of growth next before that in which all his teeth are grown;</em> in which latter stage he is termed <span class="ar">عَمَمٌ</span>. <span class="auth">(L voce <span class="ar">عَضْبٌ</span>, on the authority of Et-Táïfee.)</span> You say also <span class="ar long">كَلِمَةٌ تَامَّةٌ</span>, and <span class="ar long">دَعْوَهٌ تَامَّةٌ</span>; <span class="add">[meaning <em>A perfect,</em> or <em>faultless, sentence,</em> and <em>oath;</em>]</span> using the epithet <span class="ar">تامّة</span> in these instances because of the mention of God therein; for which reason there may not be in aught of either of them any deficiency or defect. <span class="auth">(TA.)</span> And<span class="arrow"><span class="ar long">جَعَلَهُ تِمًّا↓</span></span> i. e.<span class="arrow"><span class="ar">تَمَامًا↓</span></span> <span class="add">[<em>He made it complete,</em> or <em>perfect</em>]</span>. <span class="auth">(M.)</span> And<span class="arrow"><span class="ar long">جَعَلْتُهُ لَكَ تِمًّا↓</span></span> <em>I made it,</em> or <em>have made it, to be thine,</em> or <em>I assigned it,</em> or <em>have assigned it, to thee, completely,</em> or <em>wholly.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تم</span> - Entry: <span class="ar">تَامٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAmBN_A2">
					<p><span class="add">[Hence, <span class="ar long">فِعْلٌ تَامٌّ</span> meaning <em>A complete,</em> i. e. <em>an attributive, verb:</em> opposed to <span class="ar long">فِعْلٌ نَاقِصٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tatimBapN">
				<h3 class="entry"><span class="ar">تَتِمَّةٌ</span></h3>
				<div class="sense" id="tatimBapN_A1">
					<p><span class="ar">تَتِمَّةٌ</span>: <a href="#tamaAmN">see <span class="ar">تَمَامٌ</span></a>, in three places, at the close of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutamBN">
				<h3 class="entry"><span class="ar">مُتَمٌّ</span></h3>
				<div class="sense" id="mutamBN_A1">
					<p><span class="ar">مُتَمٌّ</span> The <em>place of cutting,</em> or <em>termination,</em> (<span class="ar">مُنْقَطَع</span>, in the CK <span class="ar">مُنْقَطِع</span>,) <em>of the vein</em> (<span class="ar">عِرْق</span> <span class="add">[app. meaning <em>chord</em>]</span>) <em>of the navel.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutimBN">
				<h3 class="entry"><span class="ar">مُتِمٌّ</span></h3>
				<div class="sense" id="mutimBN_A1">
					<p><span class="ar">مُتِمٌّ</span>, applied to one that is pregnant, <span class="auth">(Ṣ,)</span> or to a woman, <span class="auth">(M, TA,)</span> and a she-camel, <span class="auth">(M,)</span> <em>That has completed the days of her gestation:</em> <span class="auth">(Ṣ:)</span> or <em>that is near to bringing forth:</em> <span class="auth">(M:)</span> or <em>that is at the point of bringing forth.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutamBimN">
				<h3 class="entry"><span class="ar">مُتَمِّمٌ</span></h3>
				<div class="sense" id="mutamBimN_A1">
					<p><span class="ar">مُتَمِّمٌ</span> One <em>whose arrow wins time after time</em> <span class="add">[<em>in the game called</em> <span class="ar">المَيْسِر</span>]</span>, <em>and who feeds the poor with the flesh</em> <span class="add">[<em>of the camel which constitutes the shares</em>]</span> <em>thereof:</em> <span class="auth">(M, Ḳ:)</span> or <em>who, when players in the game called</em> <span class="ar">الميسر</span> <em>have diminished the slaughtered camel</em> <span class="add">[<em>by taking their shares</em>]</span>, <em>takes what has remained, so as to complete the shares,</em> or <em>make up their full number.</em> <span class="auth">(Ḳ. <span class="add">[<a href="#tm_2">See 2</a>. In the CK, <span class="ar long">نَقَصَ اِيْسارَ جَزُوْرِ المَيْسِرِ</span> is erroneously put for <span class="ar long">نَقَصَ أَيْسَارٌ جَزُورَ المَيْسِرِ</span>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AlmusotatamBapu">
				<h3 class="entry"><span class="ar">المُسْتَتَمَّةُ</span></h3>
				<div class="sense" id="AlmusotatamBapu_A1">
					<p><span class="ar long">الجَهَالَةُ المُسْتَتَمَّةُ</span> <em>Consummate ignorance:</em> improperly written <span class="ar">المُسْتَتِمَّةُ</span>, though this latter is explainable <span class="add">[as meaning <em>that completes</em> the extent to which it can go, or the like]</span>. <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotatimBN">
				<h3 class="entry"><span class="ar">مُسْتَتِمٌّ</span></h3>
				<div class="sense" id="musotatimBN_A1">
					<p><span class="ar">مُسْتَتِمٌّ</span> One <em>who seeks, demands,</em> or <em>requests, wool,</em> or <em>camels' hair, to complete therewith the weaving of his</em> <span class="ar">كِسَآء</span>: so in a poem of Aboo-Duwád, <span class="auth">(Ṣ,)</span> where he says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">فَهْىَ كَالبَيْضِ فِى الأَدَاحِىِّ لَا يُوْ</span> *</div> 
						<div class="star">* <span class="ar long">هَبُ مِنْهَا لِمُسْتَتِمٍّ عِصَامُ</span> *</div> 
					</blockquote>
					<p>i. e., <em>And they</em> <span class="auth">(referring to certain camels)</span> <em>are,</em> in respect of the care that is taken of them, and in smoothness, <em>like the eggs</em> <span class="add">[<em>in the places where the ostrich has deposited them in the sand</em>]</span>; <em>there may not be</em> found upon them to be <em>given from them, to one who demands a</em> <span class="ar">تِمَّة</span>, <span class="add">[even so much as]</span> <em>a tie for a water-skin;</em> for they have become fat, and cast their hair. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0315.pdf" target="pdf">
							<span>Lanes Lexicon Page 315</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0316.pdf" target="pdf">
							<span>Lanes Lexicon Page 316</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0317.pdf" target="pdf">
							<span>Lanes Lexicon Page 317</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
