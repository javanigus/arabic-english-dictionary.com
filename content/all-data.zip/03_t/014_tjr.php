<article class="root" id="Root_tjr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/013_ttr">تتر</a></span>
				<span class="ar">تجر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/015_tjh">تجه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tjr_1">
				<h3 class="entry">1. ⇒ <span class="ar">تجر</span></h3>
				<div class="sense" id="tjr_1_A1">
					<p><span class="ar">تَجَرَ</span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْجُرُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb,)</span> inf. n. <span class="ar">تَجْرٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ)</span> and <span class="ar">تِجَارَةٌ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> or the latter is a simple subst., <span class="auth">(Mṣb,)</span> or quasi-inf. n., <span class="auth">(Mgh,)</span> and <span class="ar">مَتْجَرٌ</span>; <span class="auth">(A;)</span> and<span class="arrow"><span class="ar">اِتَّجَرَ↓</span></span>, <span class="auth">(Ṣ, A, Mṣb, Ḳ,)</span> of the measure <span class="ar">اِفْتَعَلَ</span>; <span class="auth">(Ṣ;)</span> <em>He practised traffic, merchandise,</em> or <em>commerce; trafficked; traded; dealt; sold and bought;</em> <span class="auth">(Ḳ;)</span> <em>employed property for the purpose of gain.</em> <span class="auth">(A.)</span> You say, <span class="ar long">تَجَرَ تِجَارَةً رَابِحَةً</span> <span class="add">[<em>He practised a profitable,</em> or <em>lucrative, traffic</em>]</span>. <span class="auth">(A.)</span> And<span class="arrow"><span class="ar long">فُلَانٌ يَتَّجِرُ↓ فِى البَرِّ وَالبَحْرِ</span></span> <span class="add">[<em>Such a one traffics on land and sea</em>]</span>. <span class="auth">(A.)</span> There can hardly, if at all, be found any other instance of <span class="ar">ت</span> immediately followed by <span class="ar">ج</span> except <span class="ar">نتج</span> and <span class="ar">رتج</span>: the <span class="ar">ت</span> in <span class="ar">تُجَاهَ</span> is originally <span class="ar">و</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tjr_3">
				<h3 class="entry">3. ⇒ <span class="ar">تاجر</span></h3>
				<div class="sense" id="tjr_3_A1">
					<p><span class="ar">تاجرهُ</span>, <span class="auth">(A,)</span> inf. n. <span class="ar">مُتَاجَرَةٌ</span>, <span class="auth">(A, KL,)</span> <em>He practised with him</em> <span class="add">[and <span class="auth">(as is implied in the A)</span> <em>he vied with him in practising</em>]</span> <em>traffic,</em> or <em>selling and buying.</em> <span class="auth">(KL.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tjr_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّجر</span></h3>
				<div class="sense" id="tjr_8_A1">
					<p><span class="ar">اِتَّجَرَ</span>: <a href="#tjr_1">see 1</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تجر</span> - Entry: 8.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tjr_8_B1">
					<p><a href="#wjr_8">See also 8</a> <a href="index.php?data=27_w/042_wjr">in art. <span class="ar">وجر</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tajorN">
				<h3 class="entry"><span class="ar">تَجْرٌ</span></h3>
				<div class="sense" id="tajorN_A1">
					<p><span class="ar">تَجْرٌ</span>: <a href="#taAjirN">see <span class="ar">تَاجِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="AltBajiru">
				<h3 class="entry"><span class="ar">التَّجِرُ</span></h3>
				<div class="sense" id="AltBajiru_A1">
					<p><span class="ar">التَّجِرُ</span>: <a href="#taAjirN">see <span class="ar">تَاجِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tijaArapN">
				<h3 class="entry"><span class="ar">تِجَارَةٌ</span></h3>
				<div class="sense" id="tijaArapN_A1">
					<p><span class="ar">تِجَارَةٌ</span> a subst. from 1; <span class="auth">(Mṣb;)</span> or quasi-inf. n.; <span class="auth">(Mgh;)</span> <span class="add">[The <em>practice of traffic, merchandise,</em> or <em>commerce; traffic; trade; selling and buying;</em>]</span> the <em>trade of the</em> <span class="ar">تَاجِر</span>, i. e., <em>of him who sells and buys for gain;</em> <span class="auth">(Ksh in ii. 15;)</span> the <em>seeking of gain by selling and buying.</em> <span class="auth">(Bḍ ibid.)</span> <span class="add">[<a href="#tjr_1">See also 1</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تجر</span> - Entry: <span class="ar">تِجَارَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tijaArapN_A2">
					<p>Also <em>Merchandise,</em> meaning <em>what is sold and bought, of goods,</em> or <em>commodities,</em> or <em>householdfurniture,</em> and <em>the like;</em> a quasi-inf. n. used in the sense of a pass. part. n. <span class="auth">(Mgh.)</span> <span class="add">[Hence the saying,]</span> <span class="ar long">عَلَيْكُمْ بِتِجَارَةِ الآخِرَةِ</span> ‡ <span class="add">[<em>Keep ye to the merchandise of the life to come</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAjirN">
				<h3 class="entry"><span class="ar">تَاجِرٌ</span></h3>
				<div class="sense" id="taAjirN_A1">
					<p><span class="ar">تَاجِرٌ</span> <em>A merchant; one who practises traffic, merchandise,</em> or <em>commerce; a trafficker; a trader,</em> or <em>tradesman; a dealer; one who sells and buys;</em> <span class="auth">(Ḳ;)</span> <em>one who sells and buys for gain:</em> <span class="auth">(Ksh in ii. 15:)</span> and <em>a vintner,</em> or <em>seller of wine,</em> <span class="auth">(Ṣ, Ḳ,)</span> was also called thus by the Arabs: <span class="auth">(Ṣ:)</span> accord. to IAth, this latter is said to be the primary signification: and hence the saying in a trad., <span class="ar long">إِنَّ التَّاجِرَ فَاجِرٌ</span> <span class="add">[<em>Verily the vintner is a transgressor</em>]</span>: <span class="auth">(TA:)</span> pl. <span class="ar">تُجَّارٌ</span> and <span class="ar">تِجَارٌ</span> and<span class="arrow"><span class="ar">تَجْرٌ↓</span></span>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> <span class="add">[or rather this last is a quasi-pl. n.,]</span> like as <span class="ar">صَحْبٌ</span> is of <span class="ar">صَاحِبٌ</span>, <span class="auth">(Ṣ, Mṣb,)</span> and <span class="ar">تُجُرٌ</span>, <span class="auth">(Ḳ,)</span> or this may be <a href="#tijaArN">a pl. of <span class="ar">تِجَارٌ</span></a>. <span class="auth">(ISd, TA.)</span> <span class="pb" id="Page_0298"></span><span class="arrow"><span class="ar">التَّجِرُ↓</span></span>, occurring in a verse of El-Akhtal, <span class="add">[for <span class="ar">التَّاجِرُ</span>,]</span> is thought by ISd to be like <span class="ar">طَهِرٌ</span> <span class="add">[for <span class="ar">طَاهِرٌ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تجر</span> - Entry: <span class="ar">تَاجِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAjirN_A2">
					<p><span class="add">[Hence,]</span> ‡ A man <em>skilful in an affair.</em> <span class="auth">(Ḳ, TA.)</span> The Arabs say, <span class="ar long">إِنَّهُ لَتَاجِرٌ بِذٰلِكَ الأَمْرِ</span> ‡ <em>Verily he is skilful in that affair.</em> <span class="auth">(IAạr, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تجر</span> - Entry: <span class="ar">تَاجِرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taAjirN_A3">
					<p>And ‡ A she-camel <em>that is saleable,</em> or <em>easy of sale,</em> or <em>in much demand, in traffic,</em> and <em>in the market;</em> <span class="auth">(AʼObeyd, Ṣ, Ḳ;)</span> as also <span class="ar">تَاجِرَةٌ</span>: <span class="auth">(Ḳ:)</span> or the latter, a she-camel <em>that is goodly, and saleable,</em> or <em>in much demand:</em> <span class="auth">(A:)</span> or <em>that is easy of sale when offered, by reason of her excellence:</em> <span class="auth">(T:)</span> or simply, <em>that is easy of sale,</em> or <em>in much demand:</em> <span class="auth">(Ṣ:)</span> as though, by reason of her beauty, or goodliness, and fatness, she sold herself: <span class="auth">(Ksh in ii. 15:)</span> <em>contr. of</em> <span class="ar">كَاسِدَةٌ</span>: <span class="auth">(Ṣ,* TA:)</span> <a href="#tAjrp">the pl. of <span class="ar">تاجرة</span></a> is <span class="ar">تَوَاجِرُ</span>. <span class="auth">(T, A.)</span> You say also, <span class="ar long">عَلَيْكَ بِالسِّلَعِ التَّوَاجِرِ</span> ‡ <span class="add">[<em>Keep thou to the commodities</em>]</span> <em>that are saleable,</em> or <em>in much demand.</em> <span class="auth">(A.)</span> And <span class="ar long">هُوَ عَلَى أَكْرَمِ تَاجِرَةٍ</span> † <em>He is upon a most noble horse.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutojarapN">
				<h3 class="entry"><span class="ar">مُتْجَرَةٌ</span></h3>
				<div class="sense" id="mutojarapN_A1">
					<p><span class="ar long">أَرْضٌ مُتْجَرَةٌ</span> <span class="add">[in the TA, <span class="ar">مَتْجِرَةٌ</span>, but this is wrong,]</span> <em>A land in which traffic, merchandise,</em> or <em>commerce, is practised;</em> <span class="auth">(Ṣ, L, Ḳ;)</span> and <em>to which people go for the purpose of practising the same:</em> <span class="auth">(Ḳ:)</span> pl. <span class="ar">مَتَاجِرُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0297.pdf" target="pdf">
							<span>Lanes Lexicon Page 297</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
