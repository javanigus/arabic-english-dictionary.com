<article class="root" id="Root_trf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/031_trE">ترع</a></span>
				<span class="ar">ترف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/033_trq">ترق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trf_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترف</span></h3>
				<div class="sense" id="trf_1_A1">
					<p><span class="ar">تَرِفَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَفُ</span>}</span></add>, <span class="auth">(Ṣgh, Ḳ,)</span> inf. n. <span class="ar">تَرَفٌ</span>, <span class="auth">(M, TA,)</span> <em>He enjoyed,</em> or <em>led, a plentiful, and a pleasant</em> or <em>an easy, and a soft</em> or <em>delicate, life;</em> or <em>a life of ease and plenty;</em> <span class="auth">(M, Ṣgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">تترّف↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trf_1_A2">
					<p>And the former verb, † <em>It</em> <span class="auth">(a plant, or herbage,)</span> <em>was,</em> or <em>became, luxuriant, flourishing, succulent,</em> or <em>sappy;</em> or <em>bright and fresh, by reason of plentiful irrigation.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trf_2">
				<h3 class="entry">2. ⇒ <span class="ar">ترّف</span></h3>
				<div class="sense" id="trf_2_A1">
					<p><a href="#trf_4">see 4</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trf_2_A2">
					<p><span class="ar">تَتْرِيفٌ</span> <span class="add">[app. as the inf. n. of the pass. verb, <span class="ar">تُرِّفَ</span>, also signifies]</span> <em>Good feeding.</em> <span class="auth">(M.)</span></p>
				</div>
				<span class="pb" id="Page_0304"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="trf_2_A3">
					<p>And <span class="ar long">ترّف الرَّجُلَ</span>, and<span class="arrow"><span class="ar">اترفهُ↓</span></span>, <em>He rendered the man submissive;</em> or <em>made him to submit:</em> and <em>he made the man king,</em> or <em>prince:</em> <span class="add">[in both senses]</span> like <span class="ar">رَفَّلَهُ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trf_4">
				<h3 class="entry">4. ⇒ <span class="ar">اترف</span></h3>
				<div class="sense" id="trf_4_A1">
					<p><span class="ar long">أَتْرَفَتْهُ النِّعْمَةٌ</span> <span class="add">[<em>Wealth,</em> or <em>what God bestowed upon him,</em>]</span> <em>made him to behave exorbitantly; to be excessively disobedient</em> or <em>rebellious; to exalt himself, and be inordinate in infidelity;</em> or <em>to be extravagant in acts of disobedience and in wrongdoing:</em> <span class="auth">(Ṣ, Ḳ:)</span> and so <span class="ar long">سَعَةُ العَيْشِ</span> <span class="add">[<em>plentifulness and easiness of life</em>]</span>: and in like manner,<span class="arrow"><span class="ar">تَرَّفَتْهُ↓</span></span> <em>it caused him to exult,</em> or <em>to exult greatly,</em> or <em>excessively, and to behave insolently and unthankfully,</em> or <em>ungratefully.</em> <span class="auth">(TA.)</span> And <span class="add">[<em>Wealth,</em> or <em>what God bestowed upon him,</em>]</span> <em>made him to enjoy,</em> or <em>lead, a plentiful, and a pleasant</em> or <em>an easy, and a soft</em> or <em>delicate, life;</em> or <em>a life of ease and plenty;</em> as also<span class="arrow"><span class="ar">تَرَّفَتْهُ↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trf_4_A2">
					<p><span class="ar long">اترف الرَّجُلَ</span> <em>He gave the man the object of his eager desire;</em> or <em>of his yearning,</em> or <em>longing,</em> or <em>appetency.</em> <span class="auth">(Lḥ, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="trf_4_A3">
					<p><a href="#trf_2">See also 2</a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trf_4_B1">
					<p><span class="ar">اترف</span> also signifies <em>He persevered in,</em> or <em>persisted in,</em> or <em>resolved upon, transgression, wrongdoing,</em> or <em>deviation from the right way.</em> <span class="auth">(El-'Ozeyzee, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trf_5">
				<h3 class="entry">5. ⇒ <span class="ar">تترّف</span></h3>
				<div class="sense" id="trf_5_A1">
					<p><a href="#trf_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trf_10">
				<h3 class="entry">10. ⇒ <span class="ar">استترف</span></h3>
				<div class="sense" id="trf_10_A1">
					<p><span class="ar">استترف</span> <em>He magnified himself;</em> or <em>behaved proudly, haughtily,</em> or <em>insolently: he behaved exorbitantly; was excessively disobedient</em> or <em>rebel-lious; exalted himself, and was inordinate in infidelity;</em> or <em>was extravagant in acts of disobedience and in wrongdoing.</em> <span class="auth">(Z, Ṣgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turofapN">
				<h3 class="entry"><span class="ar">تُرْفَةٌ</span></h3>
				<div class="sense" id="turofapN_A1">
					<p><span class="ar">تُرْفَةٌ</span> <em>Plentifulness, and pleasantness</em> or <em>easiness, and softness</em> or <em>delicacy, of life; a life of softness</em> or <em>delicacy, and ease, comfort,</em> or <em>affluence;</em> or <em>ease and plenty;</em> syn. <span class="ar">نَعْمَةٌ</span>, <span class="auth">(T, Ḳ, TA,)</span> and <span class="ar long">سَعَةُ العَيْشِ</span>: <span class="auth">(TA:)</span> or <em>i. q.</em> <span class="ar">نِعْمَةٌ</span> <span class="add">[i. e. <em>wealth;</em> or <em>what God bestows upon one;</em>, &amp;c.]</span>. <span class="auth">(Mgh, and so in the CK. <span class="add">[But this I think a mistranscription, for <span class="ar">نَعْمة</span>.]</span>)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: <span class="ar">تُرْفَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="turofapN_A2">
					<p><em>Good, sweet,</em> or <em>pleasant, food.</em> <span class="auth">(IDrd, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: <span class="ar">تُرْفَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="turofapN_A3">
					<p><em>A new,</em> or <em>strange, thing,</em> (<span class="ar long">شَىْءٌ طَرِيفٌ</span>, <span class="add">[in some copies of the Ḳ, <span class="ar">ظَرِيف</span> is put in the place of <span class="ar">طَرِيف</span>,]</span>) <em>that one appropriates,</em> or <em>peculiarly assigns,</em> <span class="add">[<em>as a gift</em>]</span> <em>to a friend;</em> or <em>by</em> <span class="add">[<em>the gift of</em>]</span> <em>which one distinguishes a friend:</em> <span class="auth">(Ḳ:)</span> <em>any</em> <span class="ar">طُرْفَة</span> <span class="add">[i. e. <em>gift not given to any one before;</em> or <em>of which the recipient did not possess the like, and which pleases him;</em> or <em>novel,</em> or <em>rare, and pleasing, present</em>]</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: <span class="ar">تُرْفَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="turofapN_B1">
					<p><em>A thing protuberant in the middle of the upper lip, by nature.</em> <span class="auth">(Lth,* T,* Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: <span class="ar">تُرْفَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="turofapN_C1">
					<p><em>A</em> <span class="ar">مِسْقَاة</span> <span class="add">[q. v.]</span> <em>with which one drinks.</em> <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oatorafu">
				<h3 class="entry"><span class="ar">أَتْرَفُ</span></h3>
				<div class="sense" id="Oatorafu_A1">
					<p><span class="ar">أَتْرَفُ</span> <em>Having a natural protuberance in the middle of his upper lip, called</em> <span class="ar">تُرْفَة</span>. <span class="auth">(Lth,* T,* M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutorafN">
				<h3 class="entry"><span class="ar">مُتْرَفٌ</span></h3>
				<div class="sense" id="mutorafN_A1">
					<p><span class="ar">مُتْرَفٌ</span> <span class="add">[pass. part. n. of 4, q. v.]</span> One <em>left to do what he will; not prevented from doing so.</em> <span class="auth">(Ibn-ʼArafeh, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: <span class="ar">مُتْرَفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutorafN_A2">
					<p>And hence, <span class="auth">(Ibn-ʼArafeh, TA,)</span> One <em>enjoying,</em> or <em>leading, a plentiful; and a pleasant</em> or <em>an easy, and a soft</em> or <em>delicate, life;</em> or <em>a life of ease and plenty:</em> <span class="auth">(Ibn-ʼArafeh, M, Ḳ, TA:)</span> <em>luxurious,</em> or <em>indulging himself largely in the pleasures,</em> or <em>delights, of the present life, and in its appetites,</em> or <em>eager desires:</em> <span class="auth">(Ibn-ʼArafeh, TA:)</span> one <em>who is not prevented from enjoying himself:</em> <span class="auth">(Ḳ, TA:)</span> and one <em>whose means of subsistence are made ample,</em> or <em>plentiful;</em> as also<span class="arrow"><span class="ar">مُتَرَّفٌ↓</span></span>: <span class="auth">(M:)</span> one <em>whom plentifulness, and pleasantness</em> or <em>easiness, and softness</em> or <em>delicacy, of life,</em> or <em>whom a life of ease and plenty,</em> <span class="auth">(T,)</span> or <em>whom wealth,</em> or <em>what God has bestowed upon him, and plentifulness and easiness of life,</em> <span class="auth">(Mgh,)</span> <em>causes to exult,</em> or <em>to exult greatly,</em> or <em>excessively, and to behave insolently and unthankfully,</em> or <em>ungratefully:</em> <span class="auth">(T, Mgh:)</span> and <em>i. q.</em> <span class="ar">جَبَّارٌ</span> <span class="add">[i. e. one <em>who magnifies himself;</em> or <em>behaves proudly, haughtily,</em> or <em>insolently;</em>, &amp;c.]</span>: <span class="auth">(Ḳ:)</span> so says Ḳatádeh, in explaining the phrase <span class="ar long">أَمَرْنَا مُتْرَفِيهَا</span>, in the Ḳur <span class="add">[xvii. 17: <a href="#Oamara">see <span class="ar">أَمَرَ</span></a>]</span>: or, accord. to some, <span class="ar">مترفيها</span> here means <em>the worst of its chiefs; and the leaders in evil.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترف</span> - Entry: <span class="ar">مُتْرَفٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mutorafN_A3">
					<p>Also, <span class="auth">(TA,)</span> or<span class="arrow"><span class="ar">مُتَرَّفٌ↓</span></span>, <span class="auth">(T,)</span> A boy <em>made soft,</em> or <em>delicate, in body, and rendered submissive.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutarBafN">
				<h3 class="entry"><span class="ar">مُتَرَّفٌ</span></h3>
				<div class="sense" id="mutarBafN_A1">
					<p><span class="ar">مُتَرَّفٌ</span>: <a href="#mutorafN">see <span class="ar">مُتْرَفٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0303.pdf" target="pdf">
							<span>Lanes Lexicon Page 303</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0304.pdf" target="pdf">
							<span>Lanes Lexicon Page 304</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
