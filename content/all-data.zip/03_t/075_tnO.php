<article class="root" id="Root_tnO">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/074_tn">تن</a></span>
				<span class="ar">تنأ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/076_tnr">تنر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tnO_1">
				<h3 class="entry">1. ⇒ <span class="ar">تنأ</span></h3>
				<div class="sense" id="tnO_1_A1">
					<p><span class="ar">تَنَأَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْنَأُ</span>}</span></add>, inf. n. <span class="ar">تُنُوْءٌ</span>, <em>He remained, stayed, dwelt,</em> or <em>abode,</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> <span class="ar">بِهِ</span> <em>in it,</em> namely, a country, or town, <span class="auth">(Ṣ, Mṣb,)</span> or a place; <span class="auth">(M;)</span> <em>he settled</em> therein: <span class="auth">(Mṣb:)</span> as also <span class="ar">تنا</span>, <span class="auth">(M, Mṣb,)</span> not a dial. var., but formed by substitution <span class="add">[of <span class="ar">ا</span> for <span class="ar">أ</span>]</span>, <span class="auth">(M,)</span> <span class="add">[i. e.]</span> by suppression of the <span class="ar">ء</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنأ</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tnO_1_A2">
					<p><span class="ar long">تَنَأَ عَلَى كَذَا</span> <em>He kept,</em> or <em>adhered, to such a thing, inseparably.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تنأ</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tnO_1_B1">
					<p>Also, inf. n. as above, <em>He was,</em> or <em>became, rich, wealthy, possessed of much property.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tinaMCapN">
				<h3 class="entry"><span class="ar">تِنَآءَةٌ</span></h3>
				<div class="sense" id="tinaMCapN_A1">
					<p><span class="ar">تِنَآءَةٌ</span> a subst. from <span class="ar">تَنَأَ</span>, <span class="auth">(Ṣ, Ḳ,)</span> meaning <em>A remaining, staying, dwelling,</em> or <em>abiding</em> <span class="add">[in a country, or town, or place]</span>. <span class="auth">(TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAniYN">
				<h3 class="entry"><span class="ar">تَانِئٌ</span></h3>
				<div class="sense" id="taAniYN_A1">
					<p><span class="ar">تَانِئٌ</span> <em>Remaining, staying, dwelling,</em> or <em>abiding,</em> <span class="auth">(T, Mṣb,)</span> in a country, or town <span class="add">[&amp;c.]</span>; <em>settling</em> therein: also pronounced <span class="ar">تَانٍ</span>, by suppression of the <span class="ar">ء</span>: <span class="auth">(Mṣb:)</span> <em>one who remains, stays,</em> or <em>abides, in his country,</em> or <em>town;</em> <span class="auth">(Th, TA;)</span> <em>i. q.</em> <span class="ar">دِهْقَانٌ</span> <span class="add">[app. as meaning <em>a man having a fixed abode in a district of cultivated land,</em> or <em>in a village or town of such a district:</em> but see below]</span>: <span class="auth">(Th, Ḳ, TA:)</span> pl. <span class="ar">تُنَّآءٌ</span>. <span class="auth">(T, Ṣ, Mṣb, Ḳ.)</span> It is said in a trad., <span class="ar long">لَيْسَ لِلتَّانِئَةِ شَىْءٌ</span>, meaning <em>For those who remain in their abodes, and go not forth with the soldiers on expeditions against the enemy, there shall be nothing;</em> i. e., no share of the spoil. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنأ</span> - Entry: <span class="ar">تَانِئٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAniYN_A2">
					<p><em>Rich; wealthy; possessing much property.</em> <span class="auth">(Mṣb.)</span> <span class="add">[Or <em>A man possessing much land or other immoveable property:</em> for this is a signification assigned to <span class="ar">دِهْقَانٌ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0318.pdf" target="pdf">
							<span>Lanes Lexicon Page 318</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
