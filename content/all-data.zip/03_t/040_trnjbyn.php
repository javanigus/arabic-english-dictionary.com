<article class="root" id="Root_trnjbyn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/039_trnj">ترنج</a></span>
				<span class="ar">ترنجبين</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/041_trh">تره</a></span>
			</h2>
			<hr>
			<section class="entry main" id="taranojubiynN">
				<h3 class="entry"><span class="ar">تَرَنْجُبِينٌ</span></h3>
				<div class="sense" id="taranojubiynN_A1">
					<p><span class="ar">تَرَنْجُبِينٌ</span> and <span class="ar">تَرَنْجَبِينٌ</span> and <span class="ar">تُرَنْجَبِينٌ</span> <span class="add">[thus variously written, in the last manner in the TA, and there said to be “with damm;” from the Persian <span class="ar">تَرَنْگُبِينْ</span>; <em>A kind of manna;</em> the <em>manna of the thorny plant called by the Arabs the</em> <span class="ar">حَاج</span>, <em>and hence by European botanists “alhagi:”</em> accord. to Dr. Royle <span class="auth">(art. “Man” in Kitto's Cycl. of Bibl. Lit.)</span>, it is <em>a sweetish juice which exudes from the alhagi maurorum, concretes into small granular masses, and is usually distinguished by the name of Persian manna:</em> he also states that the alhagi maurorum and another species, alhagi desertorum, are ‘ called in Mesopotamia “agool,” according to some authorities, while by others this is thought to be the name of another plant: ’ by “agool” is meant <span class="ar">عَاقُول</span>, q. v.:]</span> <em>a kind of dew</em> (<span class="ar">طَلٌّ</span>), <em>that falls mostly in Khurásán and in Ma-waráli-n-nahr, and, in our country, mostly upon the</em> <span class="ar">حاج</span>: <em>the best thereof is that which is fresh,</em> or <em>moist, and white:</em> <span class="auth">(Ibn-Seenà, or “Avicenna,” vol. i. of the Arabic ed., p. 262:)</span> the <span class="ar">مَنّ</span> <span class="add">[or <em>manna</em>]</span> <em>mentioned in the Ḳur-án</em> <span class="add">[ii. 54]</span>. <span class="auth">(Ksh, Bḍ, Jel, TA.)</span> <span class="add">[See also “Ibn Baithar” <span class="auth">(Ibn-Beytár)</span>, vol. i. p. 207.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0306.pdf" target="pdf">
							<span>Lanes Lexicon Page 306</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
