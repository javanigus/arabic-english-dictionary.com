<article class="root" id="Root_tqd">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/051_tfh">تفه</a></span>
				<span class="ar">تقد</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/053_tqn">تقن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tiqodapN">
				<h3 class="entry"><span class="ar">تِقْدَةٌ</span></h3>
				<div class="sense" id="tiqodapN_A1">
					<p><span class="ar">تِقْدَةٌ</span> <span class="auth">(JK, Ṣ, L, Ḳ)</span> and <span class="ar">تَقْدَةٌ</span> <span class="auth">(Hr, L, Ḳ)</span> and <span class="ar">تَقِدَةٌ</span> <span class="auth">(JK, L)</span> <em>Coriander-seed;</em> syn. <span class="ar">كُزْبَرَةٌ</span>. <span class="auth">(IAạr, JK, Ṣ, L, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقد</span> - Entry: <span class="ar">تِقْدَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tiqodapN_A2">
					<p>And <em>Caraway-seed;</em> syn. <span class="ar">كَرَوْيَآء</span>. <span class="auth">(IAạr, Th, L, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0309.pdf" target="pdf">
							<span>Lanes Lexicon Page 309</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
