<article class="root" id="Root_tHf">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/016_tHt">تحت</a></span>
				<span class="ar">تحف</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/018_tHyn">تحين</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tHf_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتحف</span></h3>
				<div class="sense" id="tHf_4_A1">
					<p><span class="ar long">اتحفهُ بِهِ</span> <span class="add">[<em>He presented him with it;</em> or <em>gave it to him as a</em> <span class="ar">تُحْفَة</span>, q. v.]</span>: <span class="auth">(Ṣ, Mṣb:)</span> and <span class="ar long">اتحفهُ تُحْفَةً</span> <span class="add">[<em>He made a present to him;</em> or <em>gave him a</em> <span class="ar">تُحْفَة</span>; and so <span class="ar">اتحفهُ</span> alone, as in an ex. cited voce <span class="ar">أَتْفَحَ</span>]</span>: <span class="auth">(Ḳ, TA:)</span> <em>i. q.</em> <span class="ar long">أَطْرَفَهُ بِتُحْفَةٍ</span> <span class="add">[which properly means <em>He presented him with a novel,</em> or <em>rare, and pleasing present;</em> or <em>a gift not given to any one before;</em> or <em>a gift of which he</em> <span class="auth">(the recipient)</span> <em>did not possess the like, and which pleased him</em>]</span>: and<span class="arrow"><span class="ar">اِتَّحَفَهُ↓</span></span> signifies the same as <span class="ar">أَتْحَفَهُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tHf_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّحف</span></h3>
				<div class="sense" id="tHf_8_A1">
					<p><span class="ar">اِتَّحَفَهُ</span>: <a href="#tHf_4">see above <span class="new">{4}</span></a>. <span class="add">[Perhaps originally <span class="ar">اِوْتَحَفَهُ</span>: <a href="#tuHofapN">see what follows</a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tuHofapN">
				<h3 class="entry"><span class="ar">تُحْفَةٌ</span></h3>
				<div class="sense" id="tuHofapN_A1">
					<p><span class="ar">تُحْفَةٌ</span> and <span class="ar">تُحَفَةٌ</span> <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.)</span> <em>i. q.</em> <span class="ar">بِرٌّ</span> <span class="add">[as meaning <em>A gratuitous gift,</em> or <em>favour;</em> or <em>a bounty,</em> or <em>benefit</em>]</span>; and <span class="ar">لَطَفٌ</span> <span class="add">[meaning <em>a present;</em> i. e. <em>a thing sent to another in token of courtesy</em> or <em>honour</em>]</span>; <span class="auth">(Ḳ;)</span> in some copies of the Ḳ, <span class="ar">لُطْف</span>; <span class="auth">(TA;)</span> <span class="add">[i. e.]</span> <span class="ar">التحفة</span> signifies <span class="ar long">مَا أَتْحَفْتَ بِهِ الرَّجُلَ مِنَ البِرِّ وَاللَّطَفِ</span>; <span class="auth">(Ṣ;)</span> or <span class="add">[simply]</span> <span class="ar long">مَا أَتْحَفْتَ بِهِ غَيْرَكَ</span>: <span class="auth">(Mṣb:)</span> and <em>a</em> <span class="ar">طُرْفَة</span> <span class="add">[which properly signifies <em>a gift not given to any one before;</em> or <em>of which the recipient did not possess the like, and which pleases him;</em>]</span> <span class="auth">(Ḳ, TA;)</span> <em>of fruit,</em> and <em>of sweet-smelling flowers:</em> <span class="auth">(TA:)</span> <span class="add">[it generally means simply <em>a present;</em> or <em>a rare,</em> or <em>pleasing,</em> or <em>rare and pleasing, present:</em>]</span> pl. <span class="ar">تُحَفٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> Accord. to some, it is originally <span class="ar">وُحْفَةٌ</span>: <span class="auth">(Ḳ, TA:)</span> Az says that its <span class="ar">ت</span> is originally <span class="ar">و</span>: <span class="auth">(Mṣb:)</span> and <span class="ar">تَوَحَّفَ</span> <a href="#tHf_4">is quasi-pass. of <span class="ar">أَتْحَفَهُ</span></a>: <span class="auth">(Lth, TA:)</span> so that it should be mentioned in art. <span class="ar">وحف</span>: <span class="auth">(Ḳ, TA:)</span> being like <span class="ar">تُهَمَةٌ</span> and <span class="ar">تُخَمَةٌ</span>, &amp;c. <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">تُحْفَةُ الصَّائِمِ الدُّهْنُ وَالمِجْمَرُ</span> <span class="add">[<em>The pleasing present for the faster is oil, and aloes-wood</em> or <em>the like</em>]</span>; i. e., these dispel from him the grievousness and distress occasioned by the fasting. <span class="auth">(TA.)</span> And in another, respecting dates, <span class="ar long">تُحْفَةُ الكَبِيرِ وَصُمْتَةُ الصَّغِيرِ</span> <span class="add">[i. e. The date is <em>the pleasing gift for the big,</em> or <em>full-grown,</em> or <em>old, and the quieter of the little one,</em> or <em>child</em>]</span>. <span class="auth">(TA.)</span> And in another, <span class="ar long">تُحْفَةُ المُؤْمِنِ المَوْتُ</span> <span class="add">[<em>The boon for the believer is death</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
