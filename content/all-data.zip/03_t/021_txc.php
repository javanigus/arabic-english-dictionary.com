<article class="root" id="Root_txc">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/020_txt">تخت</a></span>
				<span class="ar">تخذ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/022_txrS">تخرص</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="txc_1">
				<h3 class="entry">1. ⇒ <span class="ar">تخذ</span></h3>
				<div class="sense" id="txc_1_A1">
					<p><span class="ar">تَخِذَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْخَذُ</span>}</span></add>, inf. n. <span class="ar">تَخَذٌ</span> and <span class="ar">تَخْذٌ</span>: <a href="#Axc_8">see 8</a> <a href="index.php?data=01_A/035_Axc">in art. <span class="ar">اخذ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="txc_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّخذ</span></h3>
				<div class="sense" id="txc_8_A1">
					<p><span class="ar">اتّخذ</span>: <a href="#Axc_8">see 8</a> <a href="index.php?data=01_A/035_Axc">in art. <span class="ar">اخذ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Aisotaxaca">
				<h3 class="entry"><span class="ar">اِسْتَخَذَ</span></h3>
				<div class="sense" id="Aisotaxaca_A1">
					<p><span class="ar">اِسْتَخَذَ</span>, an irregularly formed verb: <a href="#Axc_8">see 8</a> <a href="index.php?data=01_A/035_Axc">in art. <span class="ar">اخذ</span></a>.</p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
