<article class="root" id="Root_trj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/026_trv">ترث</a></span>
				<span class="ar">ترج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/028_trjm">ترجم</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="turunojN">
				<h3 class="entry"><span class="ar">تُرُنْجٌ</span> / <span class="ar">تُرُنْجَةٌ</span></h3>
				<div class="sense" id="turunojN_A1">
					<p><span class="ar">تُرُنْجٌ</span> and <span class="ar">تُرُنْجَةٌ</span>: <a href="#OutorujBu">see what follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OutorujBu">
				<h3 class="entry"><span class="ar">أُتْرُجُّ</span></h3>
				<div class="sense" id="OutorujBu_A1">
					<p><span class="ar">أُتْرُجُّ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> the most chaste of the forms here mentioned, <span class="auth">(Az, Mṣb, MF, TA,)</span> a pl., <span class="auth">(AḤát, MF, TA,)</span> <span class="add">[or rather a coll. gen. n.,]</span> and<span class="arrow"><span class="ar">تُرُنْجٌ↓</span></span>, <span class="auth">(AZ, Ṣ, Mṣb, Ḳ, &amp;c.,)</span> <span class="add">[which is Persian,]</span> <span class="pb" id="Page_0302"></span>a dial. var. of weak authority, <span class="auth">(Mṣb,)</span> by some disallowed, <span class="auth">(MF, TA,)</span> used by the vulgar, <span class="auth">(TA,)</span> the <span class="ar">ن</span> in which is by common consent held to be augmentative, <span class="auth">(MF, TA,)</span> likewise a pl., <span class="auth">(TA,)</span> <span class="add">[or coll. gen. n.,]</span> and<span class="arrow"><span class="ar">أُتْرُنْجٌ↓</span></span>, mentioned by Ibn-Hishám El-Lakhmee, in his Faṣeeḥ, and also used by the vulgar, <span class="auth">(TA,)</span> and by some of the people of Hims, <span class="auth">(Lth cited in the L voce <span class="ar">حَظٌّ</span>, q. v.,)</span> <span class="add">[and this is likewise a coll. gen. n.,]</span> and <span class="ar">أُتْرُجَّةٌ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, &amp;c.,)</span> which is the sing. of the first, <span class="auth">(AḤát, MF, TA,)</span> or its n. un., <span class="auth">(L, Mṣb,)</span> also pronounced <span class="ar">أُتْرُجَةٌ</span>, without teshdeed, <span class="auth">(TA,)</span> and<span class="arrow"><span class="ar">تُرُنْجَةٌ↓</span></span>, <span class="auth">(AZ, Ṣ, L, &amp;c.,)</span> likewise a n. un., <span class="auth">(L,)</span> <em>A certain fruit,</em> <span class="auth">(Mṣb,)</span> <em>well known,</em> <span class="auth">(L, Mṣb, Ḳ,)</span> <em>plentiful in the land of the Arabs, but not growing wild,</em> <span class="auth">(L, TA,)</span> <span class="add">[<em>of the species citrus medica,</em> or <em>citron; of which there are two varieties in Egypt; one, of the form of the lemon, but larger, there called</em> <span class="ar long">تُرُنْج بَلَدِىّ</span>; <em>the other, ribbed, and called</em> <span class="ar long">تُرُنْج مُصَبَّع</span>: accord. to Golius, <em>citrons of a large size, which have a sweeter peel than others, and are of a size nearly equal to that of a melon:</em>]</span> <em>the sour sort allays the lust of women, clears the complexion, and removes the</em> <span class="add">[<em>discoloration of the face termed</em>]</span> <span class="ar">كَلَف</span>, <span class="auth">(Ḳ, TA,)</span> <em>that arises from phlegm;</em> <span class="auth">(TA;)</span> <em>the peel thereof, put among clothes, preserves them from the moth-worm:</em> <span class="auth">(Ḳ, TA:)</span> <em>it is also beneficial as an antidote against the various kinds of poison; the smelling it in times of plague,</em> or <em>pestilence, is beneficial in the highest degree; and jinn,</em> or <em>genii, do not enter the house in which it is;</em> wherefore a reciter of the Ḳur-án is appropriately likened to it: <span class="auth">(TA:)</span> <a href="#OutorujBapN">the pl. of <span class="ar">أُتْرُجَّةٌ</span></a> is <span class="ar">أُتْرُجَّاتٌ</span> as well as <span class="ar">أُتْرُجٌّ</span>: <span class="add">[or rather the latter is a coll. gen. n., as stated above:]</span> but one should not say <span class="ar">تُرُنْجَاتٌ</span> <span class="add">[app. because it is vulgar; for it is agreeable with analogy <a href="#turunojapN">as pl. of <span class="ar">تُرُنْجَةٌ</span></a>; as is also <span class="ar">أُتْرُنْجَاتٌ</span> as pl. of<span class="arrow"><span class="ar">أُتْرُنْجَةٌ↓</span></span>]</span>. <span class="auth">(AḤát, MF, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="OutorunojN">
				<h3 class="entry"><span class="ar">أُتْرُنْجٌ</span> / <span class="ar">أُتْرُنْجَةٌ</span></h3>
				<div class="sense" id="OutorunojN_A1">
					<p><span class="ar">أُتْرُنْجٌ</span> and <span class="ar">أُتْرُنْجَةٌ</span>: <a href="#OutorujBu">see above</a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0301.pdf" target="pdf">
							<span>Lanes Lexicon Page 301</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0302.pdf" target="pdf">
							<span>Lanes Lexicon Page 302</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
