<article class="root" id="Root_trb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/024_tr">تر</a></span>
				<span class="ar">ترب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/026_trv">ترث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trb_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترب</span></h3>
				<div class="sense" id="trb_1_A1">
					<p><span class="ar">تَرِبَ</span>, <span class="auth">(Ṣ, M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَبُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَرَبٌ</span>, <span class="auth">(M,)</span> <em>It</em> <span class="auth">(a thing)</span> <em>became dusted,</em> or <em>dusty; dust lighted upon it:</em> <span class="auth">(Ṣ, TA:)</span> <em>it</em> <span class="auth">(a place, M,)</span> <em>had much dust,</em> or <em>earth; abounded with dust,</em> or <em>earth.</em> <span class="auth">(M, Ḳ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trb_1_A2">
					<p><em>He</em> <span class="auth">(a man, M)</span> <em>had dust,</em> or <em>earth, in his hand.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="trb_1_A3">
					<p>Also, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. as above, <span class="auth">(M,)</span> <em>He clave to the dust,</em> or <em>earth:</em> <span class="auth">(M, Ḳ:)</span> or <em>he clave to the dust,</em> or <em>earth, by reason of poverty;</em> <span class="auth">(M;)</span> <em>he became so poor that he clave to the dust,</em> or <em>earth:</em> <span class="auth">(AʼObeyd, T:)</span> or <em>he became poor,</em> <span class="auth">(T, Ṣ, Mṣb,)</span> <em>as though he clave to the dust,</em> or <em>earth:</em> <span class="auth">(Ṣ, Mṣb:)</span> and <em>he suffered loss, and became poor,</em> <span class="auth">(M, Ḳ,)</span> <em>so that he clave to the dust,</em> or <em>earth;</em> <span class="auth">(M;)</span> inf. n. as above, <span class="auth">(M, Ḳ,)</span> and <span class="ar">مَتْرَبَةٌ</span>, <span class="auth">(M,)</span> or <span class="ar">مَتْرَبٌ</span>, <span class="auth">(Ḳ,)</span> or both of these: <span class="auth">(TA:)</span> <em>his wealth became little;</em> <span class="auth">(A;)</span> as also<span class="arrow"><span class="ar">اترب↓</span></span>, <span class="auth">(M, A, Ḳ,)</span> and<span class="arrow"><span class="ar">ترّب↓</span></span>: <span class="auth">(Ḳ:)</span> or<span class="arrow"><span class="ar">اترب↓</span></span> signifies, <span class="auth">(T, Ṣ, M,)</span> or signifies also, <span class="auth">(A, Ḳ,)</span> and so <span class="ar">تَرِبَ</span>, <span class="auth">(A,)</span> and<span class="arrow"><span class="ar">ترّب↓</span></span>, <span class="auth">(Ḳ,)</span> <em>his wealth became much,</em> or <em>abundant,</em> <span class="auth">(T, M, A, Ḳ,)</span> <em>so that it was like the dust,</em> or <em>earth;</em> which is the more known meaning of the verb; <span class="auth">(M;)</span> or <em>he became rich;</em> <span class="auth">(Ṣ, Mṣb;)</span> <em>as though he became possessed of wealth equal in quantity to the dust,</em> or <em>earth:</em> <span class="auth">(Ṣ, A:)</span> accord. to Abu-l-ʼAbbás, <span class="arrow"><span class="ar">تَتْرِيبٌ↓</span></span> signifies <span class="add">[the <em>having</em>]</span> <em>much wealth;</em> and also <span class="add">[the <em>having</em>]</span> <em>little wealth.</em> <span class="auth">(T.)</span> You say,<span class="arrow"><span class="ar long">تَرِبَ بَعْدَ مَا أَتْرَبَ ↓</span></span>, meaning <em>He became poor after he had been rich.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="trb_1_A4">
					<p><span class="ar long">تَرِبَتْ يَدَاكَ</span>, <span class="auth">(T, Ṣ, A, Mṣb, in the M and Ḳ <span class="ar">يَدَاهُ</span>,)</span> a form of imprecation, <span class="auth">(Ṣ, Mṣb,)</span> meaning <span class="add">[<em>May thine arms,</em> or <em>thy hands, cleave to the dust,</em> or <em>earth, by reason of poverty;</em> as is implied in the T: or]</span> <em>may thy hands have in them dust,</em> or <em>earth:</em> <span class="auth">(Ḥam p. 275:)</span> or <em>mayest thou not obtain,</em> or <em>attain, good:</em> <span class="auth">(Ṣ, Ḳ:*)</span> or <em>mayest thou be unsuccessful,</em> or <em>fail of attaining thy desire, and suffer loss:</em> <span class="auth">(A:)</span> occurring in a trad., and as some relate, <span class="auth">(AʼObeyd, T,)</span> not meant as an imprecation; <span class="auth">(AʼObeyd, T, Mṣb;)</span> being a phrase current with the Arabs, who use it without desiring its fulfilment; <span class="auth">(AʼObeyd, T;)</span> but meant to incite, or instigate: <span class="auth">(Mṣb:)</span> some say that it means <em>may thy hands become rich;</em> but this is a mistake: <span class="auth">(AʼObeyd, T:)</span> and it is said to mean <span class="ar long">لِلّٰهِ دَرُّكَ</span> <span class="add">[<a href="#darBuka">which see</a> <a href="index.php?data=08_d/039_dr">in art. <span class="ar">در</span></a>]</span>: and some say that it is literally an imprecation: but the first assertion is the most worthy of respect, <span class="auth">(that it is not meant as an imprecation,)</span> and is corroborated by the saying, in a trad., <span class="ar long">اِنْعِمْ صَبَاحًا تَرِبَتْ يَدَاكَ</span> <span class="add">[<em>Mayest thou have a pleasant morning: may thine arms,</em> or <em>thy hands,</em>, &amp;c.]</span>. <span class="auth">(TA.)</span> <span class="ar long">تَرِبَتْ جَبِينُهُ</span> <span class="add">[<em>May his forehead</em> <span class="auth">(for so <span class="ar">جبين</span> here means, as it does in some other instances,)</span> <em>cleave to the dust,</em> or <em>earth,</em>]</span> was said by Moḥammad in reproving a man, and is said to mean a prayer that the man might be frequent in prostrating himself in prayer. <span class="auth">(TA from a trad.)</span> And he said to one of his companions, <span class="ar long">تَرِبَتْ نَحْرُكَ</span> <span class="add">[<em>May the uppermost part of thy breast cleave to the dust,</em> or <em>earth</em>]</span>, and the man was <span class="add">[afterwards]</span> slain a martyr: therefore this is to be understood in its obvious sense. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trb_1_B1">
					<p><a href="#trb_4">See also 4</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trb_2">
				<h3 class="entry">2. ⇒ <span class="ar">ترّب</span></h3>
				<div class="sense" id="trb_2_A1">
					<p><span class="ar">ترّب</span>, inf. n. <span class="ar">تَتْرِيبٌ</span>: <a href="#trb_1">see 1</a>, in three places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trb_2_B1">
					<p><a href="#trb_4">and see also 4</a>, in four places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trb_3">
				<h3 class="entry">3. ⇒ <span class="ar">تارب</span></h3>
				<div class="sense" id="trb_3_A1">
					<p><span class="ar">تَارَبَتْهَا</span> <em>She became her</em> <span class="ar">تِرْب</span>; <span class="auth">(M, Ḳ;)</span> <span class="add">[i. e.]</span> <em>she</em> <span class="auth">(a girl)</span> <em>matched her,</em> namely, another girl; <em>she was,</em> or <em>became, her match, fellow,</em> or <em>equal;</em> syn. <span class="ar">حَاذَتْهَا</span>. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trb_3_A2">
					<p><span class="add">[The inf. n.]</span> <span class="ar">مُتَارَبَةٌ</span> also signifies The <em>associating,</em> or <em>consorting, of</em> <span class="ar">أَتْرَابٌ</span> <span class="add">[<a href="#tirobN">pl. of <span class="ar">تِرْبٌ</span>, q. v.</a>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trb_4">
				<h3 class="entry">4. ⇒ <span class="ar">اترب</span></h3>
				<div class="sense" id="trb_4_A1">
					<p><span class="ar">اترب</span>: <a href="#trb_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trb_4_B1">
					<p><span class="ar">اتربهُ</span> <em>He put dust,</em> or <em>earth, upon it,</em> <span class="auth">(Ṣ, M, A, Ḳ,)</span> namely, a thing; <span class="auth">(Ṣ, M;)</span> as also<span class="arrow"><span class="ar">ترّبهُ↓</span></span>: <span class="auth">(A, Ḳ:)</span> or the latter, inf. n. <span class="ar">تَتْرِيبٌ</span>, signifies <em>he defiled it,</em> or <em>soiled it,</em> <span class="auth">(namely, a thing,)</span> <em>with dust,</em> or <em>earth:</em> <span class="auth">(Ṣ:)</span> or you say, <span class="arrow"><span class="ar">تَرَبَهُ↓</span></span>, <span class="auth">(TA,)</span> or <span class="ar long">تَرَبَهُ بِالتُّرَابِ</span>, <span class="auth">(Mṣb,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْرِبُ</span>}</span></add>, <span class="auth">(Mṣb, TA,)</span> inf. n. <span class="ar">تَرْبٌ</span>, <span class="auth">(TA,)</span> <span class="add">[meaning <em>he sprinkled it with dust,</em>]</span> namely, a writing <span class="add">[for the purpose of drying up the ink]</span>, <span class="auth">(Mṣb,)</span> or a paper; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">ترّبهُ↓</span></span>, <span class="auth">(T, Mṣb, TA,)</span> with teshdeed, <span class="auth">(Mṣb,)</span> <span class="add">[meaning <em>he sprinkled much dust upon it;</em> or <em>sprinkled it much with dust;</em>]</span> namely, a writing; <span class="auth">(T, Mṣb, TA;)</span> the latter having an intensive signification: <span class="auth">(Mṣb:)</span> or<span class="arrow">↓</span> the former of the last two verbs is used in speaking of anything that is improved, or put into a right or proper state <span class="add">[by means of dust or earth]</span>; and<span class="arrow">↓</span> the latter of them, in speaking of anything that is injured or marred or spoiled <span class="add">[thereby]</span>: you say,<span class="arrow"><span class="ar long">تَرَبَتِ↓ الإِهَابَ</span></span> <span class="add">[<em>She sprinkled,</em> or <em>put, dust,</em> or <em>earth, upon the hide</em>]</span>, to prepare it properly for use; and so of a skin for water or milk. <span class="auth">(TA.)</span> It is said in a trad., <span class="add">[accord. to one reading,]</span> <span class="ar long">اتْرِبُوا الكِتَابَ</span> <span class="add">[<em>Sprinkle ye the writing with dust</em>]</span>. <span class="auth">(Ṣ. <span class="add">[So in three copies of that work: probably <span class="ar">أَتْرِبُوا</span>; but perhaps<span class="arrow"><span class="ar">اِتْرِبُوا↓</span></span>: the reading commonly known is<span class="arrow"><span class="ar">تَرِّبُوا↓</span></span>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="trb_4_C1">
					<p><span class="ar">اترب</span> also signifies <em>He possessed a slave who had been possessed three times.</em> <span class="auth">(T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trb_5">
				<h3 class="entry">5. ⇒ <span class="ar">تترّب</span></h3>
				<div class="sense" id="trb_5_A1">
					<p><span class="ar">تترّب</span> <em>He,</em> <span class="auth">(T,)</span> or <em>it,</em> <span class="auth">(Ṣ,)</span> <em>became defiled,</em> or <em>soiled,</em> <span class="auth">(T, Ṣ,)</span> <em>in the dust,</em> or <em>earth,</em> <span class="auth">(T,)</span> or <em>with dust,</em> or <em>earth:</em> <span class="auth">(Ṣ:)</span> <em>it had dust,</em> or <em>earth, sticking to it.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tarobN">
				<h3 class="entry"><span class="ar">تَرْبٌ</span></h3>
				<div class="sense" id="tarobN_A1">
					<p><span class="ar">تَرْبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="turobN">
				<h3 class="entry"><span class="ar">تُرْبٌ</span></h3>
				<div class="sense" id="turobN_A1">
					<p><span class="ar">تُرْبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tirobN">
				<h3 class="entry"><span class="ar">تِرْبٌ</span></h3>
				<div class="sense" id="tirobN_A1">
					<p><span class="ar">تِرْبٌ</span> <em>One born at the same time with thee;</em> <span class="auth">(M, Ḳ;)</span> <em>a coëtanean; a contemporary in birth; an equal in age: an equal; a match; a fellow; a peer,</em> or <em>compeer:</em> syn. <span class="ar">لِدَةٌ</span>: <span class="auth">(T, Ṣ, M, A, Ḳ:)</span> and <span class="ar">سِنٌّ</span>: <span class="auth">(M, A, Ḳ:)</span> applied to a male and to a female; <span class="auth">(TA;)</span> but mostly to a female; <span class="auth">(M;)</span> or, accord. to an opinion confirmed by <span class="add">[most of]</span> the leading lexicologists, only to a female; and <span class="ar">سِنٌّ</span> is applied, as also <span class="ar">قَرْنٌ</span>, to a male; and <span class="ar">لِدَةٌ</span>, to a male and a female: <span class="auth">(TA:)</span> pl. <span class="ar">أَتْرَابٌ</span>. <span class="auth">(Ṣ, M, A.)</span> <span class="add">[The following exs. are given.]</span> You say, <span class="add">[applying it to a female,]</span> <span class="ar long">هٰذِهِ تِرْبُ هٰذِهِ</span>, <span class="auth">(T, Ṣ,)</span> and <span class="ar long">هِىَ تِرْبُهَا</span>, <span class="auth">(M,)</span> and <span class="ar long">هِىَ تِرْبِى</span>; <span class="auth">(Ḳ;)</span> and <span class="add">[applying it to females and males,]</span> <span class="ar long">هُمَا تِرْبَانِ</span>, <span class="auth">(T, A,)</span> and <span class="ar long">هُنَّ أَتْرَابٌ</span>, <span class="auth">(Ṣ, A,)</span> and <span class="ar long">هُمْ أَتْرَابٌ</span>. <span class="auth">(A.)</span> Accord. to Th, <span class="ar long">عُرُبًا أَتْرَبًا</span>, in the Ḳur <span class="add">[lvi. 36]</span>, means <span class="add">[<em>Showing love to their husbands;</em>]</span> <em>like,</em> or <em>equal, unto them,</em> or <em>resembling them:</em> which is a good rendering, as there is no begetting or bearing of children, <span class="add">[or rather as the latter word does not apply to females born or generated,]</span> in that case. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taribN">
				<h3 class="entry"><span class="ar">تَرِبٌ</span></h3>
				<div class="sense" id="taribN_A1">
					<p><span class="ar">تَرِبٌ</span>, applied to a place, <span class="auth">(M, TA,)</span> and to soil, <span class="auth">(TA,)</span> <em>Abounding with dust; dusty:</em> <span class="auth">(T, M, TA:)</span> and to food, <span class="auth">(T,)</span> or flesh-meat, <span class="auth">(A,)</span> <em>defiled,</em> or <em>soiled,</em> <span class="auth">(T, A,)</span> <em>in the dust,</em> <span class="auth">(T,)</span> or <em>with dust.</em> <span class="auth">(A.)</span> You say also<span class="arrow"><span class="ar long">أَرْضٌ تَرْبَآءُ↓</span></span> meaning <em>Land in which are dust and moist earth.</em> <span class="auth">(M.)</span> And <span class="ar long">رِيحٌ تَرِبَةٌ</span>, <span class="auth">(T, Ṣ, M,)</span> and <span class="ar">تَرِبٌ</span>, <span class="auth">(T,)</span> <em>A wind that carries with it dust:</em> <span class="auth">(T:)</span> or <em>that brings dust:</em> <span class="auth">(Ṣ:)</span> or <em>that drives along the dust:</em> <span class="add">[or <em>having dust:</em> for]</span> thus used it is a possessive epithet. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: <span class="ar">تَرِبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taribN_A2">
					<p>Also <em>Cleaving to the dust by reason of want; having nothing between him and the earth:</em> <span class="auth">(IAạr, T:)</span> <span class="add">[<em>cleaving to the dust by reason of poverty;</em> <a href="#trb_1">see 1</a>:]</span> <em>poor, as though cleaving to the dust:</em> <span class="auth">(Mṣb:)</span> and <span class="add">[simply,]</span> <em>poor:</em> <span class="auth">(IAạr, T, TA:)</span> or <em>needy,</em> or <em>in want.</em> <span class="auth">(M.)</span> <span class="add">[<a href="#mutoribN">See also <span class="ar">مُتْرِبٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turobapN">
				<h3 class="entry"><span class="ar">تُرْبَةٌ</span></h3>
				<div class="sense" id="turobapN_A1">
					<p><span class="ar">تُرْبَةٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, in seven places.</p>
				</div>
				<span class="pb" id="Page_0301"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: <span class="ar">تُرْبَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="turobapN_A2">
					<p>Also A man's <span class="ar">رَمْس</span> <span class="add">[i. e. his <em>grave:</em> so in the present day: pl. <span class="ar">تُربٌ</span>: or the <em>earth,</em> or <em>dust, thereof</em>]</span>: <span class="auth">(M:)</span> or <em>a cemetery, burial-place,</em> or <em>place of graves</em> or <em>of a grave:</em> <span class="add">[so, too, in the present day:]</span> pl. <span class="ar">تُرَبٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarabapN">
				<h3 class="entry"><span class="ar">تَرَبَةٌ</span></h3>
				<div class="sense" id="tarabapN_A1">
					<p><span class="ar">تَرَبَةٌ</span>: <a href="#taribapN">see the word next following</a></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taribapN">
				<h3 class="entry"><span class="ar">تَرِبَةٌ</span></h3>
				<div class="sense" id="taribapN_A1">
					<p><span class="ar">تَرِبَةٌ</span> The <em>end of a finger;</em> i. e. the <em>joint in which is the nail;</em> syn. <span class="ar">أَنْمَلَةٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> pl. <span class="ar">تَرِبَاتٌ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: <span class="ar">تَرِبَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="taribapN_B1">
					<p>Also, <span class="auth">(Ṣ, M, Ḳ,)</span> and<span class="arrow"><span class="ar">تَرَبَةٌ↓</span></span>, and<span class="arrow"><span class="ar">تَرْبَآءُ↓</span></span>, <span class="auth">(M, Ḳ,)</span> <em>A certain plant,</em> <span class="auth">(Ṣ, M, Ḳ,)</span> <em>growing in the plains,</em> or <em>in soft land, having serrated leaves:</em> or, as some say, <em>a certain thorny tree, of which the fruit is like a suspended unripe date, growing in the plains,</em> or <em>in soft land, and in rugged ground, and in Tihámeh:</em> accord. to AḤn, the <span class="ar">تَرِبَة</span> is <em>a green herb,</em> or <em>leguminous plant, that has a purging effect upon camels:</em> <span class="auth">(M:)</span> <span class="add">[accord. to Meyd, as stated by Golius, <em>what is called in Persian</em> <span class="fa">خنفج</span>; i. e. the plant <em>thlaspi;</em> and to this it is applied in the present day.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tarobaMCu">
				<h3 class="entry"><span class="ar">تَرْبَآءُ</span></h3>
				<div class="sense" id="tarobaMCu_A1">
					<p><span class="ar">تَرْبَآءُ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, in five places:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: <span class="ar">تَرْبَآءُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tarobaMCu_B1">
					<p><a href="#taribN">and see <span class="ar">تَرِبٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: <span class="ar">تَرْبَآءُ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="tarobaMCu_C1">
					<p><a href="#taribapN">and <span class="ar">تَرِبَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="turabaMCu">
				<h3 class="entry"><span class="ar">تُرَبَآءُ</span></h3>
				<div class="sense" id="turabaMCu_A1">
					<p><span class="ar">تُرَبَآءُ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarabuwtN">
				<h3 class="entry"><span class="ar">تَرَبُوتٌ</span></h3>
				<div class="sense" id="tarabuwtN_A1">
					<p><span class="ar">تَرَبُوتٌ</span> A <em>submissive,</em> or <em>tractable,</em> camel; applied to the male <span class="auth">(T, Ṣ, M, Ḳ)</span> and to the female: <span class="auth">(T, Ṣ, Ḳ:)</span> from <span class="ar">تُرَابٌ</span>, <span class="auth">(Ṣ, M,)</span> because of the abasement thereof; or, as Sb holds it to be, for <span class="ar">دَرَبُوتٌ</span>, by the change of <span class="ar">د</span> into <span class="ar">ت</span>: accord. to Lḥ, a <span class="add">[camel such as is termed]</span> <span class="ar">بَكْر</span> that is <em>trained,</em> or <em>rendered submissive</em> or <em>tractable;</em> and in like manner a she-camel, one <em>that will follow a person if he takes hold of her lip</em> or <em>her eyelash:</em> and Aṣ, who derives it from <span class="ar">تٌرَابٌ</span>, says that this epithet is applied to land, or ground, and any other thing, that is <span class="ar">ذَلُول</span> <span class="add">[i.e. <em>easy to walk</em> or <em>ride upon,</em>, &amp;c.]</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turaAbN">
				<h3 class="entry"><span class="ar">تُرَابٌ</span></h3>
				<div class="sense" id="turaAbN_A1">
					<p><span class="ar">تُرَابٌ</span> and<span class="arrow"><span class="ar">تُرْبٌ↓</span></span> <span class="auth">(Lth, T, Ṣ, M, A, Mṣb, Ḳ)</span> and<span class="arrow"><span class="ar">تَرْبٌ↓</span></span> <span class="auth">(CK <span class="add">[but this I do not find elsewhere]</span>)</span> and<span class="arrow"><span class="ar">تُرْبَةً↓</span></span> <span class="auth">(Ṣ, A,* Ḳ)</span> and<span class="arrow"><span class="ar">تَرْبَآءُ↓</span></span> <span class="auth">(Lth, T, Ṣ, A,* Ḳ)</span> and<span class="arrow"><span class="ar">تُرَبَآءُ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">تَوْرَابٌ↓</span></span> and<span class="arrow"><span class="ar">تَوْرَبٌ↓</span></span> and<span class="arrow"><span class="ar">تَيْرَابٌ↓</span></span> and<span class="arrow"><span class="ar">تَيْرَبٌ↓</span></span> <span class="add">[and<span class="arrow"><span class="ar">تَيرَبٌ↓</span></span> as will be seen below]</span> and<span class="arrow"><span class="ar">تَرِيبٌ↓</span></span> <span class="auth">(Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">تِرْيَبٌ↓</span></span>, <span class="auth">(M, Ḳ)</span> accord. to MF <span class="arrow"><span class="ar">تَرْيَبٌ↓</span></span>, which is perhaps a dial. var., and accord. to some <span class="arrow"><span class="ar">تِرْيِبٌ↓</span></span>, and<span class="arrow"><span class="ar">تَرْيَابٌ↓</span></span>, <span class="auth">(TA,)</span> signify the same, <span class="auth">(Lth, T, Ṣ, M, A, Ḳ,)</span> and are words of which the meaning is well known: <span class="auth">(A, Ḳ:)</span> <span class="add">[i. e. <em>Dust:</em> and <em>earth:</em> generally the former; i. e. <em>fine, dry, particles of earth;</em> as when we say, <span class="ar long">الرِّيحُ تَسُوقُ التُّرَابَ</span> <em>The wind drives along the dust:</em> but we also use the expression <span class="ar long">تُرَابٌ نَدٍ</span>, meaning <em>moist earth,</em> the explanation, in Lexicons, of the word <span class="ar">ثَرًى</span>:]</span> <span class="ar">?ثَرًى</span> is <span class="ar">تُرَابٌ</span>; and when it ceases to be moist, it is still <span class="ar">تراب</span>, but is not then called <span class="ar">ثرى</span>: <span class="auth">(Mṣb voce <span class="ar">ثرى</span>:)</span> accord. to Fr, <span class="ar">تُرَابٌ</span> is a gen. n., from which is formed neither dual nor pl.: and its rel. n. is <span class="arrow"><span class="ar">تُرَابِىٌّ↓</span></span>: <span class="auth">(TA:)</span> <span class="add">[but when it means <em>a kind of dust</em> or <em>earth,</em> as <span class="arrow"><span class="ar">تُرْبَةٌ↓</span></span> also does sometimes, it has a pl.: in this case,]</span> accord. to Lḥ, <span class="auth">(M,)</span> its pl. is <span class="ar">أَتْرِبَةٌ</span> <span class="add">[a pl. of pauc.]</span> and <span class="ar">تِرْبَانٌ</span> <span class="add">[a pl. of mult.]</span>; <span class="auth">(Ṣ, M, Ḳ)</span> and some add <span class="ar">تُرْبَانٌ</span>: <span class="auth">(TA:)</span> <span class="add">[and when <span class="arrow"><span class="ar">تُرْبَةٌ↓</span></span> has this, or a similar, meaning, it has for its pl. <span class="ar">تُرَبٌ</span>; as in the phrase <span class="ar long">أَطْيَبُ التُّرَبِ</span> <em>the best of the kinds of earth,</em> occurring in this art. in the A:]</span> but no pl. of any of the other syn. words mentioned above has been heard: <span class="auth">(M, Ḳ:)</span> AAF says that <span class="ar">تراب</span> <a href="#trb">is the pl. of <span class="ar">ترب</span></a>; <span class="add">[app. meaning that <span class="ar">تُرَابٌ</span> is a quasi-pl. n. <span class="auth">(which is often called in lexicons a pl.)</span> of <span class="ar">تُرْبٌ</span>;]</span> but MF observes that this requires consideration: <span class="auth">(TA:)</span> Lth says that <span class="arrow"><span class="ar">تُرْبٌ↓</span></span> and <span class="ar">تُرَابٌ</span> are syn.; but when the fem. forms of these words are used, they say, <span class="arrow"><span class="ar long">أَرْضٌ طَيّبَةُ التُّرْبَة↓</span></span> meaning <em>Land that is good in respect of the natural constitution of its dust</em> or <em>earth;</em> and<span class="arrow"><span class="ar">تُرَابَةٌ↓</span></span> when meaning <em>A layer,</em> or <em>lamina, of dust</em> or <em>earth, such as is not perceived by the sight, but only by the imagination:</em> <span class="auth">(T:)</span> or this last word and<span class="arrow"><span class="ar">تُرْبَةٌ↓</span></span> signify <em>a portion of dust</em> or <em>earth:</em> and<span class="arrow"><span class="ar long">تُرْبَةُ↓ الأَرْضِ</span></span> signifies <em>the exterior,</em> or <em>external part, of the earth:</em> <span class="auth">(M:)</span> and<span class="arrow"><span class="ar">التَّرْبَآءُ↓</span></span>, <em>the earth</em> <span class="auth">(Ṣ, Ḳ)</span> <em>itself.</em> <span class="auth">(Ṣ.)</span> The Arabs said, <span class="ar long">التُّرَابُ لَكَ</span> <span class="add">[<em>Dust,</em> or <em>earth, be thy lot</em>]</span>; using the nom. case, although meaning an imprecation, because the word is a simple subst., not an inf. n.: but Lḥ mentions the phrase <span class="ar long">التُّرَابَ لِلْأَبْعَدِ</span> <span class="add">[<em>Dust,</em> or <em>earth, be the lot of the remote from good</em>]</span>; saying that the accus. case is used, as though the phrase were an imprecation <span class="add">[of the ordinary kind, in which an inf. n. is used in the accus. case as the absolute complement of its own verb understood]</span>. <span class="auth">(M.)</span> And <span class="ar long">لَهُ التُّرَابُ</span> is a phrase used as meaning † <span class="add">[<em>He has,</em> or <em>shall have,</em> or <em>may he have,</em>]</span> <em>disappointment,</em> <span class="auth">(Mṣb in art. <span class="ar">عهر</span>,)</span> or, <em>nothing.</em> <span class="auth">(AʼObeyd, Mgh in art. <span class="ar">فرش</span>.)</span> <span class="arrow"><span class="ar long">تُرْبًا↓ لَهُ وَجَنْدَلًا</span></span> is also a form of imprecation, in which substs. in the proper sense of the term are used in the manner of inf. ns., put in the accus. case by reason of a verb unexpressed; as though it were for <span class="ar long">تَرِبَتْ يَدَاهُ وَجُنْدِلَتْ</span> <span class="add">[<em>May his arms,</em> or <em>his hands, cleave to the dust,</em> or <em>earth, and the stones,</em> by reason of poverty]</span>: and some of the Arabs put the nouns in the nom. case, still using the phrase in the same sense, as though they were in the accus. <span class="auth">(M.)</span> One says also,<span class="arrow"><span class="ar long">بِفِيهِ التَّوْرَبُ↓</span></span> and<span class="arrow"><span class="ar">التَّيْرَبُ↓</span></span> and<span class="arrow"><span class="ar">التِّيِرَبُ↓</span></span> and<span class="arrow"><span class="ar">التَّرْبَآءُ↓</span></span> and<span class="arrow"><span class="ar">التَّوْرَابُ↓</span></span> <span class="add">[<em>In his mouth is dust,</em> or <em>earth:</em> or <em>may dust,</em> or <em>earth, be in his mouth;</em> i. e. may he die, or be in his grave]</span>. <span class="auth">(T.)</span> It is said in a trad. that God created the<span class="arrow"><span class="ar">تُرْبَة↓</span></span> <span class="add">[meaning the <em>dust,</em> or <em>soil,</em> or, accord. to the TA the <em>earth</em> (<span class="ar">أَرْض</span>),]</span> on the seventh day of the week; and created upon it the mountains on the first day; and the trees, on the second day. <span class="auth">(T.)</span> And one says,<span class="arrow"><span class="ar long">لَأَضْرِبَنَّهُ حَتَّى يَعَضَّ بِالتَّرْبَآءِ↓</span></span>, <span class="auth">(Lth, T, A,)</span> meaning <span class="add">[<em>I will assuredly beat him so that he shall bite</em>]</span> <em>the dust,</em> or <em>earth.</em> <span class="auth">(Lth, T.)</span> And<span class="arrow"><span class="ar long">بَيْنَهُمَا مَا بَيْنَ الجَرْبَآءِ وَالتَّرْبَآءِ↓</span></span>, meaning <span class="add">[<em>Between them two is the space that is between</em>]</span> <em>the heaven and the earth.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tariybN">
				<h3 class="entry"><span class="ar">تَرِيبٌ</span></h3>
				<div class="sense" id="tariybN_A1">
					<p><span class="ar">تَرِيبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترب</span> - Entry: <span class="ar">تَرِيبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tariybN_B1">
					<p><a href="#tariybapN">and see also <span class="ar">تَرِيبَةٌ</span></a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taroyabN">
				<h3 class="entry"><span class="ar">تَرْيَبٌ</span></h3>
				<div class="sense" id="taroyabN_A1">
					<p><span class="ar">تَرْيَبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taroyabN.1">
				<h3 class="entry"><span class="ar">تَرْيَبٌ</span></h3>
				<div class="sense" id="taroyabN.1_A1">
					<p><span class="ar">تَرْيَبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tiroyibN">
				<h3 class="entry"><span class="ar">تِرْيِبٌ</span></h3>
				<div class="sense" id="tiroyibN_A1">
					<p><span class="ar">تِرْيِبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="turaAbapN">
				<h3 class="entry"><span class="ar">تُرَابَةٌ</span></h3>
				<div class="sense" id="turaAbapN_A1">
					<p><span class="ar">تُرَابَةٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tariybapN">
				<h3 class="entry"><span class="ar">تَرِيبَةٌ</span></h3>
				<div class="sense" id="tariybapN_A1">
					<p><span class="ar">تَرِيبَةٌ</span>, <span class="auth">(Ṣ, M, TA,)</span> or<span class="arrow"><span class="ar">تَرِيبٌ↓</span></span>, <span class="auth">(TA,)</span> <a href="#taraAyibu">sing. of <span class="ar">تَرَائِبُ</span></a>, <span class="auth">(Ṣ, M, TA,)</span> which signifies The <em>part of the breast which is the place of the collar,</em> or <em>necklace:</em> <span class="auth">(T, M, Ḳ:)</span> so by the common consent of the lexicologists: <span class="auth">(T:)</span> or the <em>bones of the breast:</em> <span class="auth">(M, A, Ḳ:)</span> or the <em>bones of the breast that are between the collar-bone and the pap:</em> <span class="auth">(Ṣ:)</span> or the <em>part of the breast,</em> or <em>chest, that is next to the two collar-bones:</em> or the <em>part that is between the two breasts and the collar-bones:</em> or <em>four ribs of the right side of the chest and four of the left thereof:</em> <span class="auth">(M, Ḳ:)</span> or the <em>two arms and two legs and two eyes:</em> <span class="auth">(T, M, Ḳ:)</span> it is also said that the <span class="ar">تَرِيبَتَانِ</span> are the <em>two ribs that are next to the two collar-bones:</em> IAth says that the <span class="ar">تَرِيبَة</span> is the <em>uppermost part of the human breast, beneath the chin;</em> and its pl. is as above: accord. to IF, in the Mj, the <span class="arrow"><span class="ar">تريب↓</span></span> is the <em>breast,</em> or <em>chest:</em> MF says that <span class="ar">ترائب</span> relates to males and females in common; but most of the authors on strange words affirm decidedly that it is peculiar to women: <span class="auth">(TA:)</span> the <span class="ar">تَرِيبَة</span> of the camel is the <em>part in which it is stabbed,</em> or <em>stuck;</em> syn. <span class="ar">مَنْحَر</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="turaAbeBu">
				<h3 class="entry"><span class="ar">تُرَابىُّ</span></h3>
				<div class="sense" id="turaAbeBu_A1">
					<p><span class="ar">تُرَابىُّ</span> <a href="#turaAbN">rel. n. of <span class="ar">تُرَابٌ</span>, q. v.</a> <span class="auth">(Fr, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taroyaAbN">
				<h3 class="entry"><span class="ar">تَرْيَابٌ</span></h3>
				<div class="sense" id="taroyaAbN_A1">
					<p><span class="ar">تَرْيَابٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taworabN">
				<h3 class="entry"><span class="ar">تَوْرَبٌ</span></h3>
				<div class="sense" id="taworabN_A1">
					<p><span class="ar">تَوْرَبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, first sentence, and near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tayorabN">
				<h3 class="entry"><span class="ar">تَيْرَبٌ</span></h3>
				<div class="sense" id="tayorabN_A1">
					<p><span class="ar">تَيْرَبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, first sentence, and near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tiyrabN">
				<h3 class="entry"><span class="ar">تِيرَبٌ</span></h3>
				<div class="sense" id="tiyrabN_A1">
					<p><span class="ar">تِيرَبٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, first sentence, and near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taworaAbN">
				<h3 class="entry"><span class="ar">تَوْرَابٌ</span></h3>
				<div class="sense" id="taworaAbN_A1">
					<p><span class="ar">تَوْرَابٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>, first sentence, and near the end of the paragraph.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tayoraAbN">
				<h3 class="entry"><span class="ar">تَيْرَابٌ</span></h3>
				<div class="sense" id="tayoraAbN_A1">
					<p><span class="ar">تَيْرَابٌ</span>: <a href="#turaAbN">see <span class="ar">تُرَابٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="Oatorabu">
				<h3 class="entry"><span class="ar">أَتْرَبُ</span></h3>
				<div class="sense" id="Oatorabu_A1">
					<p><span class="ar">أَتْرَبُ</span>: <a href="#mutoribN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutoribN">
				<h3 class="entry"><span class="ar">مُتْرِبٌ</span></h3>
				<div class="sense" id="mutoribN_A1">
					<p><span class="ar">مُتْرِبٌ</span> <em>Possessing much wealth;</em> <span class="auth">(T, Ḳ;)</span> <em>rich; without want;</em> or <em>having wealth like the dust,</em> or <em>earth:</em> <span class="auth">(Lḥ and M: <span class="add">[in the TA, <span class="ar">اترب</span> is mentioned as having this meaning; perhaps by a mistranscription: if not, it must be<span class="arrow"><span class="ar">أَتْرَبُ↓</span></span>:]</span>)</span> and <em>having little wealth:</em> thus it bears two contr. significations: <span class="auth">(Ḳ:)</span> but the former is the more known. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matorabapN">
				<h3 class="entry"><span class="ar">مَتْرَبَةٌ</span></h3>
				<div class="sense" id="matorabapN_A1">
					<p><span class="ar">مَتْرَبَةٌ</span> The <em>suffering loss, and becoming poor, so as to cleave to the dust,</em> or <em>earth;</em> <a href="#trb_1">an inf. n. of <span class="ar">تَرِبَ</span></a>: <span class="auth">(M:)</span> or <em>poverty,</em> or <em>neediness:</em> <span class="auth">(Ṣ, TA:)</span> <span class="add">[or <span class="auth">(as a word of the same class as <span class="ar">مَجْبَنَةُ</span> and <span class="ar">مَبْخَلَةٌ</span>)</span> <em>a cause of cleaving to the dust,</em> or <em>earth:</em> and hence,]</span> <span class="ar">ذُومَتْرَبَةٍ</span> <em>Poor, so as to be cleaving to the dust,</em> or <em>earth:</em> <span class="auth">(T:)</span> or <span class="add">[simply]</span> <em>cleaving to the dust,</em> or <em>earth.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0300.pdf" target="pdf">
							<span>Lanes Lexicon Page 300</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0301.pdf" target="pdf">
							<span>Lanes Lexicon Page 301</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
