<article class="root" id="Root_tXryn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/042_tsE">تسع</a></span>
				<span class="ar">تشرين</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/044_tE">تع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tiXoriynu">
				<h3 class="entry"><span class="ar">تِشْرِينُ</span></h3>
				<div class="sense" id="tiXoriynu_A1">
					<p><span class="ar">تِشْرِينُ</span> <span class="add">[in Chaldee <span class="he">תִשְרִי</span>]</span> <em>A Greek name of each of two months,</em> <span class="auth">(Ḳ,)</span> <em>of the months of Autumn, called</em> <span class="ar long">تِشْرِينُ الأَوَّلُ</span> <em>and</em> <span class="ar long">تِشْرِينُ الثَّانِى</span>, <span class="add">[<em>and both together</em> <span class="ar">تِشْرِينَانِ</span>, <em>the two Syrian months corresponding, respectively, to October and November O. Ṣ.,</em>]</span> <em>before the two months whereof each is called</em> <span class="ar">كَانُونُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0307.pdf" target="pdf">
							<span>Lanes Lexicon Page 307</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
