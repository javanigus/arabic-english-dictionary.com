<article class="root" id="Root_tb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/004_tOm">تأم</a></span>
				<span class="ar">تب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/006_tbt">تبت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tb_1">
				<h3 class="entry">1. ⇒ <span class="ar">تبّ</span></h3>
				<div class="sense" id="tb_1_A1">
					<p><span class="add">[<span class="ar">تَبَّ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْبِبُ</span>}</span></add>, inf. n. <span class="ar">تَبٌّ</span>, and perhaps <span class="arrow"><span class="ar">تَبَبٌ↓</span></span> and<span class="arrow"><span class="ar">تَبَابٌ↓</span></span> and<span class="arrow"><span class="ar">تَبِيبٌ↓</span></span>, <em>He,</em> or <em>it, suffered loss,</em> or <em>diminution;</em> or <em>became lost:</em> and <em>perished,</em> or <em>died:</em> as also<span class="arrow"><span class="ar">تبّب↓</span></span>, inf. n. <span class="ar">تَتْبِيبٌ</span>: and app. <span class="ar">تُبَّ</span> also.]</span> <span class="ar">تَبٌّ</span> <span class="auth">(M, A, Ḳ)</span> and<span class="arrow"><span class="ar">تَتْبِيبٌ↓</span></span> <span class="auth">(M, Ḳ)</span> <span class="add">[as inf. ns.]</span> signify The <em>suffering loss,</em> or <em>diminution;</em> or <em>being lost:</em> and <em>perishing,</em> or <em>dying:</em> or <span class="add">[used as substs.]</span> <em>loss,</em> or <em>diminution;</em> or the <em>state of being lost:</em> and <em>perdition, or death:</em> <span class="auth">(M,* A, Ḳ:*)</span> and so<span class="arrow"><span class="ar">تَبَابٌ↓</span></span>, <span class="auth">(T, Ṣ, A, Mṣb, Ḳ,)</span> <span class="add">[said to be]</span> a subst. from <span class="ar">تَبَّبَهُ</span>, with teshdeed, <span class="auth">(Mṣb,)</span> and<span class="arrow"><span class="ar">تَبَبٌ↓</span></span> and<span class="arrow"><span class="ar">تَبِيبٌ↓</span></span>: <span class="auth">(Ḳ:)</span> or the last three signify <span class="add">[simply]</span> <em>perdition,</em> or <em>death:</em> <span class="auth">(M:)</span> and<span class="arrow"><span class="ar">تَتْبِيبٌ↓</span></span> is explained as signifying <em>loss,</em> or <em>diminution, that brings,</em> or <em>leads, to perdition</em> or <em>death;</em> <span class="auth">(IAth, TA;)</span> and so<span class="arrow"><span class="ar">تَبَابٌ↓</span></span>; <span class="auth">(Bḍ in cxi. 1;)</span> and the <em>causing to perish.</em> <span class="auth">(T, TA.)</span> Hence you say, <span class="arrow"><span class="ar long">تَبَّ تَبَابًا↓</span></span> <span class="add">[meaning, in an emphatic manner, <em>May he suffer loss,</em> or <em>be lost,</em> or <em>perish</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">تَبًّا لَهُ</span> May God decree <em>to him loss,</em> or <em>perdition;</em> or cause <em>loss,</em> or <em>perdition,</em> to cleave <em>to him:</em> <span class="auth">(Ṣ, M,* Mṣb,* Ḳ:*)</span> <span class="ar">تَبًّا</span> being in the accus. case as an inf. n. governed by a verb understood. <span class="auth">(Ṣ.)</span> And<span class="arrow"><span class="ar long">تَبًّا تَبِيبًا↓</span></span>, <span class="add">[in the CK <span class="ar">تَتْبِيبًا</span>,]</span> meaning the same in an intensive, or emphatic, manner: <span class="auth">(M, Ḳ:)</span> and<span class="arrow"><span class="ar long">تَبًّا تَبَابًا↓</span></span>. <span class="auth">(TA.)</span> And <span class="ar long">تَبَّتْ يَدَاهُ</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> and <span class="ar long">تَبَّتْ يَدُهُ</span>,, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْبِبُ</span>}</span></add>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">تَبٌّ</span> and<span class="arrow"><span class="ar">تَبَابٌ↓</span></span>, but IDrd says that the former of these seems to be the inf. n., and the latter the simple subst., <span class="auth">(M,)</span> <em>May his arms,</em> or <em>hands,</em> and <em>his arm,</em> or <em>hand, suffer loss,</em> or <em>be lost,</em> or <em>perish:</em> <span class="auth">(T, M, Mṣb, Ḳ, and Bḍ in cxi. 1:)</span> or ‡ <em>may he himself suffer loss,</em>, &amp;c., <span class="auth">(Mṣb,* and Bḍ ubi suprà,)</span> i. e., ‡ <em>his whole person:</em> <span class="auth">(Jel in cxi. 1:)</span> or ‡ <em>his good in the present life and that in the life to come.</em> <span class="auth">(Bḍ ubi suprà.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تب</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tb_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">تَبَّ</span> <span class="auth">(A, TA)</span> and<span class="arrow"><span class="ar">تَبْتَبَ↓</span></span> <span class="auth">(T, Ḳ)</span> ‡ <em>He became an old man:</em> <span class="auth">(T, A, Ḳ:)</span> the loss of youth being likened to <span class="ar">تَبَابَ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تب</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tb_1_B1">
					<p><span class="ar">تَبَّ</span>, <span class="add">[aor., accord. to rule, <span class="ar">ـُ</span>,]</span> <em>He cut,</em> or <em>cut off,</em> a thing. <span class="auth">(Ḳ.)</span> And <span class="ar">تُبَّ</span> <em>It was cut,</em> or <em>cut off.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tb_2">
				<h3 class="entry">2. ⇒ <span class="ar">تبّب</span></h3>
				<div class="sense" id="tb_2_A1">
					<p><span class="ar">تبّب</span>, inf. n. <span class="ar">تَتْبِيبٌ</span>: <a href="#tb_1">see 1</a>, in three places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تب</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tb_2_B1">
					<p><span class="ar">تبّبهُ</span> <span class="auth">(inf. n. as above, Ṣ,)</span> <span class="add">[<em>He caused him to suffer loss,</em> or <em>to become lost:</em> or]</span> <em>he destroyed him,</em> or <em>killed him.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تب</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tb_2_B2">
					<p><em>He said to him</em> <span class="ar">تَبًّا</span>: <span class="auth">(M, Ḳ:*)</span> <span class="add">[i. e.]</span> <em>he imprecated loss,</em> or <em>perdition,</em> or <em>death, upon him.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tb_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتبّ</span></h3>
				<div class="sense" id="tb_4_A1">
					<p><span class="ar long">اتبّ ٱللّٰهُ قُوَّتَهُ</span> ‡ <em>God weakened,</em> or <em>impaired,</em> or <em>may God weaken,</em> or <em>impair, his strength.</em> <span class="auth">(Ḳ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tb_10">
				<h3 class="entry">10. ⇒ <span class="ar">استتبّ</span></h3>
				<div class="sense" id="tb_10_A1">
					<p><span class="ar">استتبّ</span> ‡ <em>It</em> <span class="auth">(a road)</span> <em>became beaten,</em> or <em>trodden, and rendered even, or easy to walk or ride upon,</em> or <em>easy and direct.</em> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تب</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tb_10_A2">
					<p>‡ <em>It</em> <span class="auth">(an affair)</span> <em>was,</em> or <em>became, rightly disposed</em> or <em>arranged; in a right state:</em> <span class="auth">(Ṣ, M, A, Mṣb:)</span> or <em>it followed a regular,</em> or <em>right, course; was in a right state; and clear,</em> or <em>plain:</em> from <span class="ar">مُسْتَتِبٌّ</span> applied to a road, explained below: <span class="auth">(T, TA:)</span> or <em>it became complete, and in a right state:</em> lit. <em>it demanded loss,</em> or <em>diminution,</em> or <em>destruction;</em> because these sometimes follow completeness: <span class="auth">(Ḥar p. 35:)</span> or the <span class="ar">ب</span> may be a substitute for <span class="ar">م</span>; the meaning being <span class="ar">استتمّ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tb_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">تبتب</span></h3>
				<div class="sense" id="tb_RQ1_A1">
					<p><span class="ar">تَبْتَبَ</span>: <a href="#tb_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tibBapN">
				<h3 class="entry"><span class="ar">تِبَّةٌ</span></h3>
				<div class="sense" id="tibBapN_A1">
					<p><span class="ar">تِبَّةٌ</span> <em>A difficult,</em> or <em>distressing, state</em> or <em>condition.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tababN">
				<h3 class="entry"><span class="ar">تَبَبٌ</span></h3>
				<div class="sense" id="tababN_A1">
					<p><span class="ar">تَبَبٌ</span>: <a href="#tb_1">see 1</a>, in several places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tabaAbN">
				<h3 class="entry"><span class="ar">تَبَابٌ</span></h3>
				<div class="sense" id="tabaAbN_A1">
					<p><span class="ar">تَبَابٌ</span>: <a href="#tb_1">see 1</a>, in several places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tabiybN">
				<h3 class="entry"><span class="ar">تَبِيبٌ</span></h3>
				<div class="sense" id="tabiybN_A1">
					<p><span class="ar">تَبِيبٌ</span>: <a href="#tb_1">see 1</a>, in several places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabBuwbN">
				<h3 class="entry"><span class="ar">تَبُّوبٌ</span></h3>
				<div class="sense" id="tabBuwbN_A1">
					<p><span class="ar">تَبُّوبٌ</span> <em>i. q.</em> <span class="ar">مَهْلَكَةٌ</span> <span class="add">[<em>A place of perdition,</em> or <em>destruction;</em> or <em>a desert;</em> or <em>a desert such as is termed</em> <span class="ar">مَفَازَة</span>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تب</span> - Entry: <span class="ar">تَبُّوبٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tabBuwbN_B1">
					<p><span class="add">[It is also said in the Ḳ to signify <em>What the ribs infold:</em> but I think it probable that this meaning has been assigned to it from its having been found erroneously written for <span class="ar">تَبُوتٌ</span>, <a href="#taAbuwtN">a dial. var. of <span class="ar">تَابُوتٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAbBN">
				<h3 class="entry"><span class="ar">تَابٌّ</span> / <span class="ar">تَابَّةٌ</span></h3>
				<div class="sense" id="taAbBN_A1">
					<p><span class="ar">تَابٌّ</span> ‡ An <em>old</em> man; <span class="auth">(AZ, T, M, A, Ḳ;)</span> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَابَّةٌ</span>}</span></add>: <span class="auth">(AZ, T, M, A:)</span> and † <em>weak:</em> pl. <span class="ar">أَتْبَابٌ</span>: of the dial. of Hudheyl; and extr. <span class="add">[with respect to analogy]</span>. <span class="auth">(M.)</span> You say, <span class="ar long">كُنْتُ شَابًّا فَصِرْتُ تَابًّا</span> <span class="add">[<em>I was a young man, and I have become an old man</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">أَشَابَّةٌ أَنْتِ أَمْ تَابَّةٌ</span> <span class="add">[<em>Art thou a young woman or an old woman?</em>]</span> <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تب</span> - Entry: <span class="ar">تَابٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAbBN_A2">
					<p>Also, <span class="auth">(T, Ḳ,)</span> or <span class="ar long">تَابُّ الظَّهْرِ</span>, <span class="auth">(T,)</span> † An ass, and a camel, <em>having galls,</em> or <em>sores, on his back:</em> <span class="auth">(T, Ḳ:)</span> pl. as above. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تب</span> - Entry: <span class="ar">تَابٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taAbBN_A3">
					<p><span class="add">[<a href="#baAtBN">See also <span class="ar">بَاتٌّ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotatibBN">
				<h3 class="entry"><span class="ar">مُسْتَتِبٌّ</span></h3>
				<div class="sense" id="musotatibBN_A1">
					<p><span class="ar">مُسْتَتِبٌّ</span>, applied to a road, ‡ <em>Furrowed by passengers, so that it is manifest to him who travels along it;</em> and to this is likened an affair that is clear, or plain, and in a right state. <span class="auth">(T.)</span> <span class="add">[See the verb, 10.]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0293.pdf" target="pdf">
							<span>Lanes Lexicon Page 293</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
