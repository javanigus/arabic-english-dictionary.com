<article class="root" id="Root_tbr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/006_tbt">تبت</a></span>
				<span class="ar">تبر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/008_tbE">تبع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tbr_1">
				<h3 class="entry">1. ⇒ <span class="ar">تبر</span></h3>
				<div class="sense" id="tbr_1_A1">
					<p><span class="ar">تَبِرَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْبَرُ</span>}</span></add>, <span class="auth">(Lth, T, M, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَبَارٌ</span>; <span class="auth">(Lth, T, M;)</span> and <span class="ar">تَبَرَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْبُرُ</span>}</span></add>; <span class="auth">(Mṣb;)</span> <em>He,</em> or <em>it,</em> <span class="auth">(a thing, Lth, T, M,)</span> <em>perished.</em> <span class="auth">(Lth, T, M, Mṣb, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تبر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tbr_1_B1">
					<p><a href="#tbr_2">See also 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tbr_2">
				<h3 class="entry">2. ⇒ <span class="ar">تبّر</span></h3>
				<div class="sense" id="tbr_2_A1">
					<p><span class="ar">تبّرهُ</span>, inf. n. <span class="ar">تَتْبِيرٌ</span>; <span class="auth">(Zj, T, Ṣ, M, Mṣb,* Ḳ;)</span> and<span class="arrow"><span class="ar">تَبَرَهُ↓</span></span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْبِرُ</span>}</span></add>, inf. n. <span class="ar">تَبْرٌ</span>; <span class="auth">(Ḳ;)</span> <em>He broke it:</em> <span class="auth">(Ḳ:)</span> or <em>he broke it in pieces;</em> <span class="auth">(Ṣ, M;)</span> <em>and did away with it:</em> <span class="auth">(M:)</span> or <em>he crumbled it,</em> or <em>broke it into small pieces, with his fingers:</em> <span class="auth">(Zj, T:)</span> and <em>he destroyed it:</em> <span class="auth">(Zj, T, Ṣ, Mṣb, Ḳ:)</span> <em>He</em> <span class="auth">(God)</span> <em>destroyed him.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiborN">
				<h3 class="entry"><span class="ar">تِبْرٌ</span> / <span class="ar">تِبْرَةٌ</span></h3>
				<div class="sense" id="tiborN_A1">
					<p><span class="add">[<span class="ar">تِبْرٌ</span> a coll. gen. n., of which the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تِبْرَةٌ</span>}</span></add>: <em>Native gold, in the form of dust</em> or <em>of nuggets:</em> this is the sense in which the word is generally used in the present day:]</span> <em>broken gold:</em> <span class="auth">(M:)</span> it is not so called unless <em>in the dust of its mine,</em> or <em>broken:</em> <span class="auth">(IJ, M:)</span> or <em>gold,</em> and <em>silver, before it is wrought:</em> <span class="auth">(Lth, T, IF, Mṣb:)</span> or <em>broken,</em> or <em>crumbled, particles of gold,</em> and <em>of silver, before they are wrought:</em> when they are wrought, they are called <span class="ar">ذَهَبٌ</span> and <span class="ar">فِضَّةٌ</span>: <span class="auth">(IAạr, T, Ḳ:)</span> or <em>uncoined gold</em> <span class="auth">(Ṣ, Mgh, Mṣb)</span> and <em>silver:</em> <span class="auth">(Mgh:)</span> when coined, it is called <span class="ar">عَيْنٌ</span>: <span class="auth">(Ṣ, Mṣb:)</span> <span class="add">[properly,]</span> the term <span class="ar">تبر</span> should not be employed save as applied to gold; but some apply it to silver also: <span class="auth">(Ṣ:)</span> the <span class="ar">تبر</span> of silver, as well as of gold, is mentioned in a trad.: <span class="auth">(TA:)</span> or <em>gold</em> <span class="auth">(M, Ḳ)</span> universally: <span class="auth">(M:)</span> and <em>silver:</em> <span class="auth">(Ḳ:)</span> or <em>what is extracted from the mine,</em> <span class="auth">(M, Ḳ,)</span> <em>of gold</em> and <em>silver</em> and <em>all</em> <span class="ar">جَوَاهِر</span> <span class="add">[here meaning <em>native ores</em>]</span> <em>of the earth,</em> <span class="auth">(M,)</span> <em>before it is wrought</em> <span class="auth">(M, Ḳ)</span> <em>and used:</em> <span class="auth">(M:)</span> or <em>any</em> <span class="ar">جَوْهَر</span> <span class="add">[or <em>native ore</em>]</span> <em>before it is used, of copper</em> <span class="auth">(Zj, T, Mgh, Mṣb)</span> and <em>brass</em> <span class="auth">(Zj, T, Mgh)</span> or <em>iron</em> <span class="auth">(Mṣb)</span> <em>&amp;c.:</em> <span class="auth">(Zj, Mgh, Mṣb:)</span> and <em>any</em> <span class="ar">جوهر</span> <span class="add">[or <em>native ore</em>]</span> <em>that is used, of copper and brass:</em> <span class="auth">(Ḳ:)</span> the word is sometimes applied to other minerals than gold and silver, as <em>copper</em> and <em>iron</em> and <em>lead,</em> but generally to <em>gold;</em> and some say that its primary application is to gold, and that the other applications are later, or tropical: <span class="auth">(TA:)</span> also <em>broken pieces of glass.</em> <span class="auth">(Zj, T, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiboriyapN">
				<h3 class="entry"><span class="ar">تِبْرِيَةٌ</span></h3>
				<div class="sense" id="tiboriyapN_A1">
					<p><span class="ar">تِبْرِيَةٌ</span> <a href="#hiboriyapN">a dial. var. of <span class="ar">هِبْرِيَةٌ</span></a>, <span class="auth">(AO, Ṣ,)</span> i. e. <span class="add">[<em>Scurf on the head;</em>]</span> <em>what is formed at the roots of the hair, like bran.</em> <span class="auth">(AO, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tabaArN">
				<h3 class="entry"><span class="ar">تَبَارٌ</span></h3>
				<div class="sense" id="tabaArN_A1">
					<p><span class="ar">تَبَارٌ</span> <em>Destruction,</em> or <em>perdition:</em> <span class="auth">(Zj, T, Ṣ, M, &amp;c.:)</span> <a href="#tbr_1">inf. n. of <span class="ar">تَبِرَ</span></a>. <span class="auth">(Lth, T, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutabBarN">
				<h3 class="entry"><span class="ar">مُتَبَّرٌ</span></h3>
				<div class="sense" id="mutabBarN_A1">
					<p><span class="ar">مُتَبَّرٌ</span> <em>Broken up</em> <span class="add">[<em>and</em>]</span> <em>destroyed:</em> so in <span class="add">[the saying in the Ḳur vii. 135,]</span> <span class="ar long">هٰؤُلَآءِ مُتَبَّرٌ مَا هُمْ فِيهِ</span> <span class="add">[As to <em>these</em> people, <em>that wherein they are</em> shall be <em>broken up and destroyed</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تبر</span> - Entry: <span class="ar">مُتَبَّرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutabBarN_A2">
					<p><span class="ar long">رَأْىٌ مُتَبَّرٌ</span> <em>Counsel destroyed,</em> or <em>brought to nought.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matobuwrN">
				<h3 class="entry"><span class="ar">مَتْبُورٌ</span></h3>
				<div class="sense" id="matobuwrN_A1">
					<p><span class="ar">مَتْبُورٌ</span> <span class="add">[<em>Destroyed;</em>]</span> <em>in a state of destruction:</em> <span class="auth">(IAạr, T, Ḳ:)</span> and <em>defective,</em> or <em>deficient.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0293.pdf" target="pdf">
							<span>Lanes Lexicon Page 293</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
