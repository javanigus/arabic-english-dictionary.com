<article class="root" id="Root_trq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/032_trf">ترف</a></span>
				<span class="ar">ترق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/034_trk">ترك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trq_QQ1">
				<h3 class="entry">Q. Q. 1. ⇒ <span class="ar">تَرْقَيْتُهُ</span></h3>
				<div class="sense" id="trq_QQ1_A1">
					<p><span class="ar">تَرْقَيْتُهُ</span>, <span class="auth">(ISk, JK, Ṣ, Ḳ,)</span> inf. n. <span class="ar">تَرْقَاةٌ</span>, <span class="auth">(ISk, Ṣ, Ḳ,)</span> <em>I hit,</em> or <em>hurt, his</em> <span class="auth">(a man's, ISk, JK, Ṣ)</span> <span class="ar">تَرْقُوَة</span> <span class="add">[or <em>collar-bone</em>]</span>. <span class="auth">(ISk, JK, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taroquwapN">
				<h3 class="entry"><span class="ar">تَرْقُوَةٌ</span></h3>
				<div class="sense" id="taroquwapN_A1">
					<p><span class="ar">تَرْقُوَةٌ</span> The <em>collar-bone;</em> the <em>bone between the pit at the uppermost part of the chest and the shoulder,</em> <span class="auth">(JK, Ṣ, Mgh, Ḳ,)</span> <em>on either side, connecting those two parts,</em> <span class="auth">(JK, Mgh,)</span> of a man, &amp;c.; <span class="auth">(TA;)</span> <em>each of the two prominent bones in the uppermost part of the chest, from the head of each shoulder to the edge of the pit above mentioned:</em> <span class="auth">(TA in art. <span class="ar">ترب</span>:)</span> <span class="add">[and sometimes, as in a phrase which see below,]</span> the <em>fore part of the</em> <span class="ar">حَلْق</span> <span class="add">[here app. meaning the <em>throat</em>]</span>, <em>at the uppermost part of the chest, the place into which the soul</em> <span class="add">[for <span class="ar">النَّفَسُ</span>, in copies of the Ḳ, I read <span class="ar">النَّفْسُ</span>]</span> <em>rises</em> <span class="add">[<em>when one is at the point of death</em>]</span>: <span class="auth">(Ḳ in art. <span class="ar">رقو</span>:)</span> pl. <span class="ar">تراقٍ</span> <span class="auth">(JK, Mgh, Ḳ)</span> and <span class="ar">ترائِق</span>; <span class="auth">(JK, Ḳ;)</span> the latter formed by transposition: <span class="auth">(JK:)</span> Fr says that the latter pl. is used by some for the former: <span class="auth">(TA:)</span> the sing. is of the measure <span class="ar">فَعْلُوَةٌ</span>, <span class="auth">(JK, Ṣ, Ḳ,)</span> as is shown by the verb mentioned above, <span class="auth">(Ḳ,)</span> though it is repeated in the Ḳ in art. <span class="ar">رقو</span>: <span class="auth">(TA:)</span> one should not say <span class="ar">تُرْقُوَةٌ</span>, with damm to the <span class="ar">ت</span>. <span class="auth">(Ṣ Ḳ.)</span> <span class="ar long">إِذَا بَلَغَتِ التَّرَاقِىَ</span>, in the Ḳur lxxv. 26, means <em>When it</em> <span class="auth">(the soul)</span> <em>reaches the uppermost parts of the chest;</em> <span class="add">[or, <em>the parts of the throat next the chest;</em>]</span> for <span class="ar">النَّفْسُ</span> is understood: <span class="auth">(Bḍ:)</span> said when one is at the point of death. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiroyaAqN">
				<h3 class="entry"><span class="ar">تِرْيَاقٌ</span></h3>
				<div class="sense" id="tiroyaAqN_A1">
					<p><span class="ar">تِرْيَاقٌ</span>, an arabicized word, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> from the Greek, <span class="auth">(Mṣb, Ḳ,)</span> <span class="add">[i. e. from <span class="gr">θηριακὰ</span>,]</span> or originally Persian, <span class="auth">(Ṣ, O,)</span> also written and pronounced <span class="ar">دِرْيَاقٌ</span>, <span class="auth">(JK, Mṣb,)</span> and <span class="ar">طِرْيَاقٌ</span>; <span class="auth">(Mṣb;)</span> or, as some say, from <span class="ar">الرِّيقُ</span>, because containing the spittle of serpents, and, if so, it is Arabic <span class="add">[in origin]</span>: <span class="auth">(Mṣb:)</span> <span class="add">[<em>Theriac;</em> also called <em>treacle;</em>]</span> <em>an antidote for poisons;</em> <span class="auth">(Ṣ, O;)</span> <em>a certain compound medicine,</em> <span class="auth">(Ḳ,)</span> <em>comprising many ingredients, at most ninety or ninety-six, and at least sixty-four,</em> <span class="auth">(TA,)</span> <em>sometimes including the flesh of vipers,</em> <span class="auth">(Ḳ, TA,)</span> <em>and that of asses, which cause it to be prohibited and impure, or, as some say, it is prohibited without restriction:</em> <span class="auth">(TA:)</span> <em>it is a remedy against the bite or sting of rapacious venomous reptiles and the like, and poisonous potions:</em> <span class="auth">(Ḳ: <span class="add">[I omit some unprofitable and absurd particulars respecting the compounds thus termed, in the Ḳ and other lexicons, &amp;c.:]</span>)</span> pl. <span class="ar">تَرَايِيقُ</span>. <span class="auth">(Ḳ in art. <span class="ar">فرق</span>.)</span> The best kind is called <span class="ar long">التِّرْيَاقُ الفَارُوقُ</span>, <span class="auth">(Ḳ in art. <span class="ar">فرق</span>,)</span> vulgarly <span class="ar long">تِرْيَاقٌ فَارُوقِىٌّ</span>. <span class="auth">(TA in that art.)</span> <span class="add">[A principal ingredient of this kind is the best sort of Jews-pitch, i. e. asphaltum, also called mumia, and in Arabic <span class="ar">مُومِيَا</span>: <span class="auth">(see De Sacy's “Rel. de l'Égypte par Abdallatif,”” p. 274:)</span> and this mumia, by itself, is called <span class="ar long">التِّرْيَاقُ التُّرْكِىُّ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترق</span> - Entry: <span class="ar">تِرْيَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tiroyaAqN_A2">
					<p><span class="add">[It is sometimes applied to <em>Treacle,</em> as meaning the <em>sirop that drains from sugar.</em>]</span> It is also said to be applied to the <span class="ar">فَادْزَهْر</span> <span class="add">[or <em>Bezoar-stone</em>]</span>, likewise termed <span class="ar">مَسُوسٌ</span>. <span class="auth">(TA in art. <span class="ar">مس</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترق</span> - Entry: <span class="ar">تِرْيَاقٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tiroyaAqN_A3">
					<p>Also, and<span class="arrow"><span class="ar">تِرْيَاقَةٌ↓</span></span>, † <em>Wine;</em> <span class="auth">(Ṣ, O, Ḳ;)</span> because it dispels anxiety; <span class="auth">(Ṣ;)</span> or because it is a remedy for anxieties; <span class="auth">(O;)</span> wherefore it is also termed <span class="ar long">صَابُونُ الهُمُومِ</span>. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tiroyaAqapN">
				<h3 class="entry"><span class="ar">تِرْيَاقَةٌ</span></h3>
				<div class="sense" id="tiroyaAqapN_A1">
					<p><span class="ar">تِرْيَاقَةٌ</span>: <a href="#tiroyaAqN">see the last sentence above</a>.</p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiroyaAqieBN">
				<h3 class="entry"><span class="add">[<span class="ar">تِرْيَاقِىٌّ</span>]</span></h3>
				<div class="sense" id="tiroyaAqieBN_A1">
					<p><span class="add">[<span class="ar long">بَاذِنْجَانُ تِرْيَاقِىٌّ</span> <em>Zanthium.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0304.pdf" target="pdf">
							<span>Lanes Lexicon Page 304</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
