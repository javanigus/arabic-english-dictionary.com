<article class="root" id="Root_trmA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/035_trkmAn">تركمان</a></span>
				<span class="ar">ترما</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/037_trms">ترمس</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="taramaA">
				<h3 class="entry"><span class="ar">تَرَمَا</span></h3>
				<div class="sense" id="taramaA_A1">
					<p><span class="ar long">لَا تَرَمَا</span> <em>i. q.</em> <span class="ar long">لا سِيَّمَا</span> <span class="add">[<a href="#siyBamaA">which see</a> <a href="index.php?data=12_s/258_swe">in art. <span class="ar">سوى</span></a>]</span>. <span class="auth">(Ḳ.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0305.pdf" target="pdf">
							<span>Lanes Lexicon Page 305</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
