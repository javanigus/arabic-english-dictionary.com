<article class="root" id="Root_tn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/073_tmwz">تموز</a></span>
				<span class="ar">تن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/075_tnO">تنأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tn_1">
				<h3 class="entry">1. ⇒ <span class="ar">تنّ</span></h3>
				<div class="sense" id="tn_1_A1">
					<p><span class="ar long">تَنَّ بِالمَكَانِ</span>, <span class="add">[aor., accord. to rule, <span class="ar">ـِ</span>, <em>i. q.</em> <span class="ar">تَنَأَ</span>,]</span> <em>He remained, stayed, dwelt,</em> or <em>abode, in the place.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tn_3">
				<h3 class="entry">3. ⇒ <span class="ar">تانّ</span></h3>
				<div class="sense" id="tn_3_A1">
					<p><span class="ar long">تانّ بَيْنَهُمَا</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">مُتَانَّةٌ</span>, <span class="auth">(TA,)</span> <em>He measured,</em> or <em>compared, them two together.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tn_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتنّ</span></h3>
				<div class="sense" id="tn_4_A1">
					<p><span class="ar">اتنّ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">إِتْنَانٌ</span>, <span class="auth">(TA,)</span> <em>He,</em> or <em>it, was,</em> or <em>became, distant,</em> or <em>remote.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تن</span> - Entry: 4.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tn_4_B1">
					<p><span class="ar">اتنّهُ</span> <em>It</em> <span class="auth">(a disease)</span> <em>stunted him,</em> <span class="auth">(AZ, IAạr, T, Ṣ, M, Ḳ,)</span> namely, a child, or boy, <span class="auth">(IAạr, T, Ṣ, M, Ḳ,)</span> <em>so that he did not attain to the stature of his equals in age,</em> <span class="auth">(AZ, T,)</span> or <em>so that he did not attain to full growth.</em> <span class="auth">(IAạr, T, Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tn_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">تنتن</span></h3>
				<div class="sense" id="tn_RQ1_A1">
					<p><span class="ar">تَنْتَنَ</span> <span class="add">[in the CK <span class="ar">تَتَنَّنَ</span>]</span> <em>He</em> <span class="auth">(a man, IAạr, T)</span> <em>left,</em> or <em>deserted, his friends, and associated with others.</em> <span class="auth">(IAạr, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tanBN">
				<h3 class="entry"><span class="ar">تَنٌّ</span></h3>
				<div class="sense" id="tanBN_A1">
					<p><span class="ar">تَنٌّ</span>: <a href="#tinBN">see <span class="ar">تِنٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تَنٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tanBN_B1">
					<p><a href="#tawBN">See also a poetical citation voce <span class="ar">تَوٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tunBN">
				<h3 class="entry"><span class="ar">تُنٌّ</span></h3>
				<div class="sense" id="tunBN_A1">
					<p><span class="ar">تُنٌّ</span> and <span class="ar">تُنَّةٌ</span> The <em>tunny-fish.</em> <span class="auth">(Golius on the authority of Ibn-Beytár; and so in the present day; but the former is a coll. gen. n., and the latter is a n. un.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tinBN">
				<h3 class="entry"><span class="ar">تِنٌّ</span></h3>
				<div class="sense" id="tinBN_A1">
					<p><span class="ar">تِنٌّ</span> <em>A like; an equal, a match,</em> or <em>a fellow;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَنِينٌ↓</span></span>; <span class="auth">(Ḳ, TA <span class="add">[in the CK <span class="ar">تِنِين</span>]</span>;)</span> <em>an equal in age;</em> <span class="auth">(T, M;)</span> <em>an equal in intellect,</em> or <em>in weakness,</em> or <em>in strength,</em> or <em>in manliness,</em> or <em>manly virtue:</em> <span class="auth">(ISk, Ṣ:)</span> or <em>a companion:</em> <span class="auth">(M:)</span> pl. <span class="ar">أَتْنَانٌ</span>. <span class="auth">(T, M.)</span> You say, <span class="ar long">فُلَانٌ تِنُّ فُلَانٍ</span> <span class="add">[<em>Such a one is the like,</em> or <em>equal,</em>, &amp;c., <em>of such a one</em>]</span>. <span class="auth">(Ṣ.)</span> And <span class="ar long">هُوَ سِنُّهُ</span> and <span class="ar">تِنُّهُ</span> and <span class="ar">حِتْنُهُ</span> <span class="add">[<em>He is his like,</em> or <em>equal,</em>, &amp;c.]</span>. <span class="auth">(T.)</span> And <span class="ar long">هُمَا تِنَّانِ</span> <em>They two are equals in intellect,</em> or <em>in weakness,</em> or <em>in strength,</em> or <em>in manliness,</em> or <em>manly virtue.</em> <span class="auth">(ISk, Ṣ.)</span> And <span class="ar long">صِبْوَةٌ أَتْنَانٌ</span> <span class="add">[<em>Boys that are like each other,</em> or <em>equals,</em>, &amp;c.]</span>. <span class="auth">(T.)</span> And <span class="ar long">هُمْ أَسْنَانٌ أَتْنَانٌ</span> <em>They are equals in age.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تِنٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tinBN_A2">
					<p><em>A boy stunted by disease,</em> <span class="auth">(Lth, T, M,)</span> <em>so that he does not attain to full growth;</em> <span class="auth">(Lth, T;)</span> as also<span class="arrow"><span class="ar">تَنٌّ↓</span></span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تِنٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tinBN_A3">
					<p>Also <em>i. q.</em> <span class="ar">شَخْصٌ</span> <span class="add">[The <em>body,</em> or <em>corporeal form, of a man</em> or <em>other thing, which one sees from a distance;</em> or <em>a person; an individual</em>]</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تِنٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tinBN_A4">
					<p>And <em>i. q.</em> <span class="ar">مِثَالٌ</span> <span class="add">[<em>A model; a pattern;</em>, &amp;c.]</span>: <span class="auth">(T:)</span> and<span class="arrow"><span class="ar">تِينَانٌ↓</span></span> <span class="add">[likewise]</span> signifies the <span class="ar">مثال</span> of a thing. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taniynN">
				<h3 class="entry"><span class="ar">تَنِينٌ</span></h3>
				<div class="sense" id="taniynN_A1">
					<p><span class="ar">تَنِينٌ</span>: <a href="#tinBN">see <span class="ar">تِنٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tinBiynN">
				<h3 class="entry"><span class="ar">تِنِّينٌ</span></h3>
				<div class="sense" id="tinBiynN_A1">
					<p><span class="ar">تِنِّينٌ</span> <span class="add">[in Hebr. <span class="he">תַּנִּין</span>]</span> <em>A great serpent;</em> <span class="auth">(Ḳ;)</span> <em>a kind of serpent,</em> <span class="auth">(Lth, T, Ṣ, M,)</span> <em>one of the greatest of serpents,</em> <span class="auth">(Lth, T,)</span> or <em>like the greatest thereof:</em> <span class="auth">(M:)</span> it is related that a company of soldiers, on the shore of the Sea of Syria, saw a cloud divide upon the sea, and then rise, and they saw the tail of the <span class="ar">تنّين</span> in a state of commotion in the fringe of the cloud: it is also related that a cloud carries the <span class="ar">تنّين</span> to the country of Yájooj and Májooj <span class="add">[or Gog and Magog]</span>, and casts it down there, and they assemble thereupon, and eat its flesh: <span class="auth">(T:)</span> <span class="add">[these stories are fanciful accounts of the natural phenomenon called <em>a water-spout,</em> to which this name is applied by the Arabs in the present day: but the word is generally understood to mean <em>a dragon:</em> and <em>a great sea-monster;</em>]</span> <em>an aquatic animal, great in make, terrible in appearance, long and broad in the body, large in the head, having very glistening eyes, wide mouth and inside, and many teeth: it swallows many animals; the animals of the land and of the sea fear it; and when it moves, the sea becomes agitated with waves by reason of its great strength: in its first state, it is a malignant serpent, that eats what it sees of the beasts of the land; and when its mischief becomes great, God sends an angel that carries it away, and throws it to Yájooj and Májooj: it is related of one that was seen to fall, that it was found to be about two leagues in length, of a colour like that of the leopard, with scales like those of a fish, two great fins in form like those of a fish, a head like a great hill, resembling the head of a man, two long and great ears, and two round eyes; and from its neck branched forth six other necks, every one of them nearly twenty cubits long, and every one of them having a head like that of the serpent.</em> <span class="auth">(Ḳzw.)</span> <span class="add">[Golius thinks it to mean The <em>shark</em> <span class="auth">(“<em>carcharias</em>”)</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تِنِّينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tinBiynN_A2">
					<p>Hence, <span class="ar">التِّنِّينُ</span> is † <em>A certain</em> <span class="ar">نَجْم</span> <span class="add">[or <em>constellation; the constellation of the Dragon</em>]</span>; thus named as being likened to the serpent so called; <span class="auth">(M;)</span> <em>a constellation containing thirty-one stars within the figure; among which are those called</em> <span class="ar">الرَّاقِصُ</span> <em>and</em> <span class="ar">العَوَائِذُ</span> <em>and</em> <span class="ar">الرُّبَعُ</span> <em>and</em> <span class="ar">الذِّئْبَانِ</span> <em>&amp;c.</em> <span class="auth">(Ḳzw, TA.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تِنِّينٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tinBiynN_A3">
					<p><span class="add">[Also, app., † <em>A certain imaginary figure in the heavens, extending along the line of the nodes of a planet, which are called the dragon's head and the dragon's tail, in Arabic</em> <span class="ar">الجَوْزَهَرُ</span> <span class="auth">(from the Persian <span class="fa">گَوْزِهْرْ</span>)</span>, or <span class="ar">الجَوْزَاهَرَانِ</span>, and also <span class="ar">العُقْدَتَانِ</span>, and, to distinguish each from the other, <span class="ar long">الرَّأْسُ وَالذَّنَبُ</span>: this line is supposed by Golius to be meant by the following description; but I incline to regard it as the result of a confusion of a description of this line with a description of the zodiacal light, a phenomenon supposed to have been unnoticed by the Arabs:]</span> <em>a slight whiteness in the sky,</em> <span class="auth">(Lth, T, Ḳ,)</span> <em>not an asterism,</em> <span class="auth">(Lth, T,)</span> <em>the body of which is in six signs of the zodiac, and the tail, which is slender, black, and twisted, in the seventh sign: it changes place like the planets; is called in Persian</em> <span class="fa">هَشْتَنْبَرْ</span>, <span class="auth">(Lth, T, Ḳ,)</span> <span class="add">[app. a mistranscription of <span class="ar">هَسْتَبُرْ</span>,]</span> <em>in astrological computation; and is inauspicious:</em> <span class="auth">(Lth, T:)</span> accord. to J, <em>a certain place in the sky;</em> which is a correct explanation, though said in the Ḳ to be a mistake. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiynaAnN">
				<h3 class="entry"><span class="ar">تِينَانٌ</span></h3>
				<div class="sense" id="tiynaAnN_A1">
					<p><span class="ar">تِينَانٌ</span>: <a href="#tinBN">see <span class="ar">تِنٌّ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تن</span> - Entry: <span class="ar">تِينَانٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tiynaAnN_B1">
					<p>Also <em>A wolf:</em> <span class="auth">(Ḳ, in this art. and in art. <span class="ar">تين</span>:)</span> but used only by El-Akhtal. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0318.pdf" target="pdf">
							<span>Lanes Lexicon Page 318</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
