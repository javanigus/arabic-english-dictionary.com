<article class="root" id="Root_tnr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/075_tnO">تنأ</a></span>
				<span class="ar">تنر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/077_tnf">تنف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tanBaArN">
				<h3 class="entry"><span class="ar">تَنَّارٌ</span></h3>
				<div class="sense" id="tanBaArN_A1">
					<p><span class="ar">تَنَّارٌ</span> <span class="add">[and<span class="arrow"><span class="ar">تَنُّورِىٌّ↓</span></span>]</span> <em>A maker of ovens of the kind called</em> <span class="ar">تَنُّور</span>. <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tanBuwrN">
				<h3 class="entry"><span class="ar">تَنُّورٌ</span></h3>
				<div class="sense" id="tanBuwrN_A1">
					<p><span class="ar">تَنُّورٌ</span> <em>A sort of</em> <span class="ar">كَانُون</span> <span class="add">[or <em>fire-place</em>]</span>; <span class="auth">(M;)</span> the <em>thing,</em> <span class="auth">(Ṣ, Mṣb,)</span> or <span class="ar">كانون</span>, <span class="auth">(Ḳ,)</span> <em>in which bread is baked;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>but different from the</em> <span class="ar">فُرْن</span>: <span class="auth">(Ṣ in art. <span class="ar">فرن</span>:)</span> <span class="add">[it is <em>a kind of oven, open at the top, in the bottom of which a fire is lighted, and in which the bread, in the form of flat cakes, is generally stuck against the sides; either portable, and made of baked clay, wide at the bottom, and narrow at the top, where it is open; and if so, the bread is sometimes stuck upon the outside, to bake; or fixed, and in this case made of baked clay likewise, or constructed of bricks; or it is a hole made in the ground, and lined with bricks or tiles or the like, against which the bread is stuck, to bake; and sometimes flesh-meat, cut into small pieces, is roasted in it, or upon it, on skewers:</em>]</span> such, accord. to some, is the meaning in the Ḳur xi. 42 and xxiii. 27; <span class="auth">(T;)</span> and the word is said to have the same meaning in every language; <span class="auth">(Lth, T, M;)</span> but this is not correct: <span class="auth">(Ḥam p. 793:)</span> it is an arabicized word; <span class="auth">(T, M;)</span> not genuine Arabic; <span class="auth">(AḤát, Mṣb;)</span> originally Persian: <span class="auth">(M:)</span> <span class="add">[in Hebrew <span class="he">תַּנּוּר</span>:]</span> Ahmad Ibn-Yaḥyà <span class="add">[i. e. Th, as is stated in Ḥam, ubi suprà,]</span> says that it is of the measure <span class="ar">تَفْعُولٌ</span> from <span class="ar">النَّار</span>, <span class="auth">(M, and Ḥam ubi suprà,)</span> or from <span class="ar">النُّور</span>; originally <span class="ar">تَنْوُورٌ</span>; <span class="auth">(Ḥam;)</span> but this is wrong: <span class="auth">(M:)</span> the pl. is <span class="ar">تَنَانِيرُ</span>. <span class="auth">(M, Mṣb.)</span> <span class="pb" id="Page_0319"></span>Moḥammad is related to have said to a man wearing a garment dyed with bastard-saffron, “If thy garment were in the <span class="ar">تنّور</span> of thy family, or beneath their cooking-pot, it were better:” whereupon he went away, and burned it: but he meant, “Wert thou to spend its price for flour to make bread, or for fire-wood with which to cook, it were better for thee:” as though he disliked a garment so dyed. <span class="auth">(IAth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنر</span> - Entry: <span class="ar">تَنُّورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tanBuwrN_A2">
					<p>The <em>surface of the ground:</em> <span class="auth">(T, Ṣ, M, Ḳ:)</span> so in the Ḳur ubi suprà, <span class="auth">(T, Ṣ,)</span> accord. to ʼAlee <span class="auth">(Ṣ)</span> and I’Ab. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنر</span> - Entry: <span class="ar">تَنُّورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tanBuwrN_A3">
					<p>The <em>highest part of the earth</em> or <em>ground:</em> so in the same passages of the Ḳur accord. to Ḳatádeh. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنر</span> - Entry: <span class="ar">تَنُّورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tanBuwrN_A4">
					<p><em>Any place from which water pours forth.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنر</span> - Entry: <span class="ar">تَنُّورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tanBuwrN_A5">
					<p><em>A place where the water of a valley collects.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تنر</span> - Entry: <span class="ar">تَنُّورٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tanBuwrN_A6">
					<p>The <em>shining of the dawn:</em> so accord. to some in the Ḳur ubi suprà: <span class="auth">(T:)</span> and ʼAlee is related to have said that <span class="ar long">وَفَارَ التَّنُّورُ</span> means <em>and daybreak rose</em> or <em>rises:</em> <span class="auth">(TA:)</span> or it relates to the welling forth of water from the place of the mosque of El-Koofeh: <span class="auth">(T:)</span> or <span class="ar">التّنّور</span> here signifies a well-known spring of water: <span class="auth">(Hr, TA:)</span> or a certain mountain near El-Maseesah; <span class="auth">(I’Ab, Ḳ, TA;)</span> i. e., <span class="auth">(TA,)</span> ʼEyn-el-Ward, in El-Jezeereh; <span class="auth">(I’Ab, T, TA;)</span> or ʼEyn-Wardeh. <span class="auth">(Bḍ in xi. 42.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tanBuwrieBN">
				<h3 class="entry"><span class="ar">تَنُّورِىٌّ</span></h3>
				<div class="sense" id="tanBuwrieBN_A1">
					<p><span class="ar">تَنُّورِىٌّ</span>: <a href="#tanBaArN">see <span class="ar">تَنَّارٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0318.pdf" target="pdf">
							<span>Lanes Lexicon Page 318</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0319.pdf" target="pdf">
							<span>Lanes Lexicon Page 319</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
