<article class="root" id="Root_tbh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/010_tbn">تبن</a></span>
				<span class="ar">تبه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/012_tbw">تبو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="taAbuwhN">
				<h3 class="entry"><span class="ar">تَابُوهٌ</span></h3>
				<div class="sense" id="taAbuwhN_A1">
					<p><span class="ar">تَابُوهٌ</span> <a href="#taAbuwtN">a dial. var. of <span class="ar">تَابُوتٌ</span></a>, of the dial. of the Ansár. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">توب</span>, q. v.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0297.pdf" target="pdf">
							<span>Lanes Lexicon Page 297</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
