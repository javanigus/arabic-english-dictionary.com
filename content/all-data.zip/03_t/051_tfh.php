<article class="root" id="Root_tfh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/050_tfl">تفل</a></span>
				<span class="ar">تفه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/052_tqd">تقد</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tfh_1">
				<h3 class="entry">1. ⇒ <span class="ar">تفه</span></h3>
				<div class="sense" id="tfh_1_A1">
					<p><span class="ar">تَفِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْفَهُ</span>}</span></add>, <span class="auth">(Ṣ, Mgh, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَفَهٌ</span>, <span class="auth">(JK, Mṣb, Ḳ, TA,)</span> or <span class="ar">تَفْهٌ</span>, <span class="auth">(Mgh, CK,)</span> and <span class="ar">تُفُوهٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">تَفَاهَةٌ</span>, <span class="auth">(Mṣb, TA,)</span> or this last is a mistake; <span class="auth">(Mgh;)</span> and <span class="ar">تَفَهَ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْفِهُ</span>}</span></add>, inf. n. <span class="ar">تُفُوهٌ</span>; <span class="auth">(JK;)</span> <em>It</em> <span class="auth">(a thing, JK, Mgh, Mṣb)</span> <em>was,</em> or <em>became, paltry, sorry, mean, contemptible,</em> or <em>inconsiderable;</em> <span class="auth">(JK, Ṣ, Mgh, Mṣb;)</span> and <em>little,</em> or <em>small, in quantity</em> or <em>number.</em> <span class="auth">(JK, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفه</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tfh_1_A2">
					<p><span class="ar">تَفِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْفَهُ</span>}</span></add>, inf. n. <span class="ar">تُفُوهٌ</span>, <em>He</em> <span class="auth">(a man)</span> <em>was,</em> or <em>became, stupid,</em> or <em>foolish.</em> <span class="auth">(JK, Ḳ.)</span> And <span class="ar long">تَفِهَتْ نَفْسُهُ</span> <em>His mind became weak.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفه</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tfh_1_A3">
					<p><span class="ar">تَفَهَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْفُهُ</span>}</span></add>; and <span class="ar">تَفِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْفَهُ</span>}</span></add>; <em>He,</em> or <em>it, was,</em> or <em>became, lean,</em> or <em>meagre;</em> syn. <span class="ar">غَثَّ</span>. <span class="auth">(Ḳ.)</span> It is said in a trad. <span class="auth">(Ṣ, Ḳ)</span> of Ibn-Mesʼood, <span class="auth">(Ḳ,)</span> <span class="ar long">القُرْآنُ لَا يَتْفَهُ وَلَا يَتَشَّانُ</span>, <span class="auth">(Ṣ, Ḳ, <span class="add">[in the CK, erroneously, <span class="ar">يُتْفَهُ</span> and <span class="ar">يُتَشانُّ</span>, and in some copies of the Ḳ, for the latter is put <span class="ar">ينتان</span>,]</span>)</span> i. e. <span class="ar long">لَا يَغِثُّ وَلَا يَخْلَقُ</span> † <span class="add">[<em>The Ḳur-án will not become meagre, nor will it become worn out</em>]</span>: <span class="auth">(Ḳ: <span class="add">[in the CK, erroneously, <span class="ar long">لا يُغَثُّ و لا يُخْلَقُ</span>:]</span>)</span> it is implied by the context in the Ṣ, that <span class="ar long">لا يتفه</span> means <em>will not become paltry,</em> or <em>mean:</em> <span class="ar">لايتشانّ</span> means <em>will not become worn out</em> by reason of much repetition; from <span class="ar">شَنُّ</span> signifying “a wornout water-skin.” <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tfh_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتفه</span></h3>
				<div class="sense" id="tfh_4_A1">
					<p><span class="ar long">اتفه فِى عَطَائِهِ</span> <span class="add">[<em>He was paltry, sorry, mean,</em> or <em>niggardly, in his gift;</em>]</span> <em>he made his gift little,</em> or <em>small.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tafihN">
				<h3 class="entry"><span class="ar">تَفِهٌ</span></h3>
				<div class="sense" id="tafihN_A1">
					<p><span class="ar">تَفِهٌ</span>: <a href="#taAfihN">see <span class="ar">تَافِهٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفه</span> - Entry: <span class="ar">تَفِهٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tafihN_A2">
					<p>Also <em>Insipid; tasteless;</em> and so<span class="arrow"><span class="ar">تَافِهٌ↓</span></span>. <span class="auth">(KL.)</span> You say <span class="ar long">أَطْعِمَةٌ تَفِهَةٌ</span> <em>Kinds of food having no taste of sweetness,</em> or <em>of sourness,</em> or <em>of bitterness;</em> and some include bread and flesh-meat among these. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAfihN">
				<h3 class="entry"><span class="ar">تَافِهٌ</span></h3>
				<div class="sense" id="taAfihN_A1">
					<p><span class="ar">تَافِهٌ</span> <span class="auth">(Ṣ, Mgh, Mṣb, KL, TA)</span> and<span class="arrow"><span class="ar">تَفِهٌ↓</span></span> <span class="auth">(Mgh, KL, TA)</span> applied to a thing, <span class="auth">(JK, Mgh, Mṣb,)</span> and the former to a man also, <span class="auth">(TA,)</span> <em>Paltry, sorry, mean, contemptible,</em> or <em>inconsiderable:</em> <span class="auth">(JK, Ṣ, Mgh, Mṣb, KL, TA:)</span> and <em>little,</em> or <em>small, in quantity</em> or <em>number.</em> <span class="auth">(JK, Ṣ, TA, and KL in explanation of the former.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفه</span> - Entry: <span class="ar">تَافِهٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAfihN_A2">
					<p><span class="ar long">تَافِهُ العَقْلِ</span> A man <em>having little sense,</em> or <em>intellect;</em> <span class="auth">(TA;)</span> <em>stupid,</em> or <em>foolish.</em> <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفه</span> - Entry: <span class="ar">تَافِهٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taAfihN_A3">
					<p><a href="#tafihN">See also <span class="ar">تَفِهٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفه</span> - Entry: <span class="ar">تَافِهٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taAfihN_A4">
					<p><span class="ar">تَافِهٌ</span> also signifies <em>Afflicted,</em> or <em>distressed, by reason of disease</em> and <em>fatigue.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutafBahapN">
				<h3 class="entry"><span class="ar">مُتَفَّهَةٌ</span></h3>
				<div class="sense" id="mutafBahapN_A1">
					<p><span class="ar">مُتَفَّهَةٌ</span>; <span class="auth">(JK, TA;)</span> so in the handwriting of Ṣgh; in the Ḳ, <span class="ar">مُتْفَهَةٌ</span>; <span class="auth">(TA;)</span> <em>Easy, submissive,</em> or <em>tractable;</em> applied to a she-camel. <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0309.pdf" target="pdf">
							<span>Lanes Lexicon Page 309</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
