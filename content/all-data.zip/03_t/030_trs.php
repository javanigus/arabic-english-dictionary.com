<article class="root" id="Root_trs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/029_trH">ترح</a></span>
				<span class="ar">ترس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/031_trE">ترع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trs_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترس</span></h3>
				<div class="sense" id="trs_1_A1">
					<p><span class="ar long">تَرَسَ البَابَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْرُسُ</span>}</span></add>, inf. n. <span class="ar">تَرْسٌ</span>, <em>He fastened,</em> or <em>closed, the door</em> <span class="add">[<em>with a bar</em> or]</span> <em>in any manner.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trs_2">
				<h3 class="entry">2. ⇒ <span class="ar">ترّس</span></h3>
				<div class="sense" id="trs_2_A1">
					<p><span class="ar">ترّس</span>, inf. n. <span class="ar">تَتْرِيسٌ</span>, <em>He made</em> a person <em>to arm himself with a shield.</em> <span class="auth">(KL.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترس</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trs_2_B1">
					<p><a href="#trs_5">See also 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trs_5">
				<h3 class="entry">5. ⇒ <span class="ar">تترّس</span></h3>
				<div class="sense" id="trs_5_A1">
					<p><span class="ar">تترّس</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> or <span class="ar long">تترّس بِتُرْسٍ</span>, <span class="auth">(M,)</span> <em>He defended himself with</em> a <span class="ar">تُرْس</span> <span class="add">[or <em>shield</em>]</span>; <span class="auth">(Ṣ, M, A,* Ḳ;)</span> as also<span class="arrow"><span class="ar">ترّس↓</span></span>, inf. n. <span class="ar">تَتْرِيسٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">اِتَّرَسَ↓</span></span>, <span class="auth">(Sb, M, A, TA,)</span> inf. n. <span class="ar">اِتِّرَاسٌ</span>, of the measure <span class="ar">اِفْتِعَالٌ</span>: <span class="auth">(TA:)</span> and <span class="ar long">تترّس بِشَىْءٍ</span> <em>he made a thing to be as a</em> <span class="ar">تُرْس</span>; <em>he defended,</em> or <em>protected, himself with it.</em> <span class="auth">(Mṣb.)</span> You say also, <span class="ar long">تَسَتَّرْتُ بِكَ مِنَ الحَدَثَانِ فَتَتَرَّسْتُ مِنْ نِبَالِ الزَّمَانِ</span> ‡ <span class="add">[<em>I protected myself by thee from calamities, and so shielded myself from the arrows of fortune</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">أَخَذَتٌ إِبِلِى سِلَاحَهَا وَتَتَرَّسَتْ بِتُرْسِهَا</span>, meaning ‡ <em>My camels became fat and goodly, and prevented their owner from slaughtering them.</em> <span class="auth">(A, TA.)</span> <span class="add">[<a href="#silaAHN">See <span class="ar">سِلَاحٌ</span></a>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trs_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّرس</span></h3>
				<div class="sense" id="trs_8_A1">
					<p><a href="#trs_5">see 5</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turosN">
				<span class="pb" id="Page_0303"></span>
				<h3 class="entry"><span class="ar">تُرْسٌ</span></h3>
				<div class="sense" id="turosN_A1">
					<p><span class="ar">تُرْسٌ</span> <span class="add">[<em>A shield;</em>]</span> <em>a certain piece of defensive armour;</em> <span class="auth">(M, TA;)</span> <em>a thing well known:</em> <span class="auth">(A, Mṣb, Ḳ:)</span> pl. <span class="ar">تِرَسَةٌ</span> and <span class="ar">تِرَاسٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">تِرَاسَةٌ</span> <span class="auth">(Ṣ)</span> and <span class="ar">تُرُوسٌ</span>, <span class="add">[all pls. of mult.,]</span> and <span class="ar">أَتْرَاسٌ</span>, <span class="add">[a pl. of pauc.,]</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> but not <span class="ar">أَتْرِسَةٌ</span>. <span class="auth">(ISk, Ṣ, Mṣb.)</span> A <span class="ar">تُرْس</span> that is made of skins, without wood and without sinews in it, is called <span class="ar">حَجَفَةٌ</span> and <span class="ar">دَرَقَةٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترس</span> - Entry: <span class="ar">تُرْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="turosN_A2">
					<p>Also ‡ The <em>disk</em> of the sun. <span class="auth">(A,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترس</span> - Entry: <span class="ar">تُرْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="turosN_A3">
					<p>And ‡ <em>A smooth, round, level piece</em> of ground: <span class="auth">(A, TA:)</span> or <em>a rugged piece</em> of hard, or hard and level, ground. <span class="auth">(Ibn-ʼAbbád, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترس</span> - Entry: <span class="ar">تُرْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="turosN_A4">
					<p><a href="#matarosN">See also <span class="ar">مَتَرْسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiraAsapN">
				<h3 class="entry"><span class="ar">تِرَاسَةٌ</span></h3>
				<div class="sense" id="tiraAsapN_A1">
					<p><span class="ar">تِرَاسَةٌ</span> The <em>art of making shields.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarBaAsN">
				<h3 class="entry"><span class="ar">تَرَّاسٌ</span></h3>
				<div class="sense" id="tarBaAsN_A1">
					<p><span class="ar">تَرَّاسٌ</span> A man <em>having a shield;</em> <span class="auth">(Ṣ, M, A, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَارِسٌ↓</span></span>. <span class="auth">(Ṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترس</span> - Entry: <span class="ar">تَرَّاسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tarBaAsN_A2">
					<p>And <em>A maker of shields.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taArisN">
				<h3 class="entry"><span class="ar">تَارِسٌ</span></h3>
				<div class="sense" id="taArisN_A1">
					<p><span class="ar">تَارِسٌ</span>: <a href="#tarBaAsN">see <span class="ar">تَرَّاسٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matarosN">
				<h3 class="entry"><span class="ar">مَتَرْسٌ</span></h3>
				<div class="sense" id="matarosN_A1">
					<p><span class="ar">مَتَرْسٌ</span>; so accord. to El-Háfidh Ibn-Hajar, and this is the correct form; written in the T and the Towsheeh <span class="ar">مَتَّرْسٌ</span>; and by some, <span class="ar">مَتْرَسٌ</span> <span class="add">[as in the CK]</span>; and by some, <span class="ar">مَتْرَسٌ</span> <span class="add">[as I find it in two copies of the Ṣ and in a copy of the Ḳ]</span>; <span class="auth">(TA;)</span> <span class="add">[<em>A wooden door-bar;</em>]</span> <em>a piece of wood that is put behind the door;</em> <span class="auth">(Ṣ, Ḳ)</span> the <span class="ar">شِجَار</span> <span class="add">[or <em>wooden bar</em>]</span> <em>that is put against the door as a stay:</em> <span class="auth">(T, L, TA:)</span> <span class="add">[<span class="fa">مَتَرْسْ</span> is]</span> a Persian word, <span class="add">[having the above-mentioned signification, but originally a contraction of <span class="fa long">مَهْ تَرْسْ</span>, and]</span> meaning “fear not thou,” with it <span class="add">[being here understood]</span>: <span class="auth">(T, Ḳ, TA:)</span> or the name of this piece of wood in Arabic is <span class="arrow"><span class="ar">تُرْسٌ↓</span></span>: <span class="auth">(M, TA:)</span> which also signifies <em>a piece of wood with which a couch-frame</em> (<span class="ar">سَرِير</span>) <em>is repaired, by its being affixed as a</em> <span class="ar">ضَبَّة</span>: <span class="auth">(M:)</span> <span class="add">[and the Arabic word <span class="ar">شِجَارٌ</span> has this latter signification also:]</span> the Persian word is <span class="fa">مَتَرْسْ</span>. <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترس</span> - Entry: <span class="ar">مَتَرْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="matarosN_A2">
					<p>Their saying <span class="ar">مَتَرْس</span>, with fet-ḥ to the <span class="ar">م</span> and <span class="ar">ت</span>, and sukoon to the <span class="ar">ر</span> means <span class="add">[also]</span> <em>Security</em> <span class="add">[<em>is given</em>]</span> <em>to thee, therefore fear thou not:</em> it is said to be Persian. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matorasapN">
				<h3 class="entry"><span class="ar">مَتْرَسَةٌ</span></h3>
				<div class="sense" id="matorasapN_A1">
					<p><span class="ar">مَتْرَسَةٌ</span>, <span class="auth">(M, A,)</span> or <span class="ar">متْرَسَةٌ</span>, <span class="auth">(Ḳ, accord. to the TA, <span class="add">[and so I find in a MṢ. copy of that work, and in the CK, but the former is probably the correct form, being agreeable with analogy, like <span class="ar">مَبْخَلَةٌ</span> and <span class="ar">مَجْبَنَةٌ</span>, &amp;c.,]</span>)</span> <em>Anything by which one is defended,</em> or <em>protected.</em> <span class="auth">(M, Mṣb, Ḳ.)</span> You say also <span class="ar long">هُوَ مَتْرَسَةٌ لَكَ</span> ‡ <span class="add">[<em>He is a cause of defence,</em> or <em>protection, to thee</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoruwsN">
				<h3 class="entry"><span class="ar">مَتْرُوسٌ</span></h3>
				<div class="sense" id="matoruwsN_A1">
					<p><span class="ar long">بَابٌ مَتْرُوسٌ</span> <em>A door fastened,</em> or <em>closed,</em> <span class="add">[<em>with a bar,</em> or]</span> <em>in any manner.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0302.pdf" target="pdf">
							<span>Lanes Lexicon Page 302</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0303.pdf" target="pdf">
							<span>Lanes Lexicon Page 303</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
