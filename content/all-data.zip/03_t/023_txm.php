<article class="root" id="Root_txm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/022_txrS">تخرص</a></span>
				<span class="ar">تخم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/024_tr">تر</a></span>
			</h2>
			<h4 class="root"><span class="ar">تخم</span> and quasi <span class="ar">تخم</span></h4>
			<hr>
			<section class="entry main" id="txm_1">
				<h3 class="entry">1. ⇒ <span class="ar">تخم</span></h3>
				<div class="sense" id="txm_1_A1">
					<p><span class="ar">تَخِمَ</span>, <span class="add">[originally <span class="ar">وَخِمَ</span>,]</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْخَمُ</span>}</span></add>, <span class="auth">(Mṣb, and Ḳ in art. <span class="ar">وخم</span>,)</span> inf. n. <span class="ar">تَخَمٌ</span>; <span class="auth">(Mṣb;)</span> and <span class="ar">تَخَمَ</span>, aor. <span class="ar">ِ</span>; <span class="auth">(Ḳ ubi suprà;)</span> and<span class="arrow"><span class="ar long">اِتَّخَمَ ↓</span></span>; <span class="auth">(Mṣb, and Ṣ and Ḳ, &amp;c. in art. <span class="ar">وخم</span>;)</span> <em>He suffered from indigestion,</em> or <em>heaviness of the stomach arising from food which it was too weak to digest;</em> <span class="auth">(Mṣb in art. <span class="ar">وخم</span>;)</span> <em>he suffered from a disease produced by unsuitable</em> <span class="add">[or <em>unwholesome</em>]</span> <em>food,</em> <span class="auth">(Ḳ and TA in art. <span class="ar">وخم</span>,)</span> or <em>by fulness of the stomach:</em> <span class="auth">(TA in that art.:)</span> followed by <span class="ar long">مِنَ الطَّعَامِ</span> and <span class="ar long">عَنِ الطَّعَامِ</span>. <span class="auth">(Ṣ and TA in that art.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="txm_3">
				<h3 class="entry">3. ⇒ <span class="ar">تاخم</span></h3>
				<div class="sense" id="txm_3_A1">
					<p><span class="ar">تاخم</span>, <span class="add">[inf. n. <span class="ar">مُتَاخَمَةٌ</span>,]</span> <em>It</em> <span class="auth">(a land or country)</span> <em>bordered upon,</em> or <em>was conterminous with</em> or <em>to,</em> another land or country. <span class="auth">(AHeyth, Mgh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="txm_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتخم</span></h3>
				<div class="sense" id="txm_4_A1">
					<p><span class="ar">اتخمهُ</span>, <span class="auth">(Ṣ and Ḳ in art. <span class="ar">وخم</span>,)</span> originally <span class="ar">أَوْخَمَهُ</span>; <span class="auth">(Ṣ in that art.,)</span> or formed from <span class="ar">تُخَمَةٌ</span>, in consequence of imagining the <span class="ar">ت</span> in this word to be radical; <span class="auth">(MF;)</span> said of food, <em>It caused him to suffer from</em> <span class="ar">تُخَمَة</span> <span class="add">[or <em>indigestion</em>]</span>. <span class="auth">(Ṣ and Ḳ in art. <span class="ar">وخم</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="txm_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّخم</span></h3>
				<div class="sense" id="txm_8_A1">
					<p><a href="#txm_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taxomN">
				<h3 class="entry"><span class="ar">تَخْمٌ</span></h3>
				<div class="sense" id="taxomN_A1">
					<p><span class="ar">تَخْمٌ</span> The <em>limit,</em> or <em>boundary,</em> <span class="auth">(Ṣ, Mṣb,)</span> of any town <span class="auth">(Ṣ)</span> or land: <span class="auth">(Ṣ, Mṣb:)</span> pl. <span class="ar">تُخُومٌ</span>: <span class="auth">(Ṣ, Mṣb:)</span> a poet <span class="auth">(Aboo-Keys Ibn-El-Aslat, TA)</span> says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَا بَنِىَّ التُّخُومُ لَا تَظْلِمُوهَا</span> *</div> 
					</blockquote>
					<p><span class="auth">(Fr, Ṣ,)</span> or, as some relate it, <span class="arrow"><span class="ar">التَّخُومُ↓</span></span>: <span class="auth">(TA:)</span> accord. to the former reading, Fr says, the meaning is, <span class="add">[<em>O my sons,</em>]</span> <em>the limits,</em> or <em>boundaries,</em> <span class="add">[<em>misplace ye not them</em>]</span>, for he does not say <span class="ar">تَظْلِمُوهُ</span>: but ISK says, I heard AA say, it is <span class="arrow"><span class="ar">تَخُوم↓</span></span>, and the pl. is <span class="ar">تُخُمٌ</span>; like <span class="ar">صَبُورٌ</span> and <span class="ar">صُبُرٌ</span>: <span class="auth">(Ṣ:)</span> both IAạr and ISk say that the sing and pl. are like <span class="ar">رَسُولٌ</span> and <span class="ar">رُسُلٌ</span>: <span class="auth">(Mṣb:)</span> but the latter mentions also <span class="ar">تُخُومٌ</span>, with damm, as a pl. form, having no sing.: <span class="auth">(TA:)</span> or<span class="arrow"><span class="ar">تَخُومٌ↓</span></span> signifies <em>a sign,</em> or <em>mark</em> <span class="add">[<em>of a boundary</em> or <em>of a way</em>]</span>: and <em>limits,</em> or <em>boundaries:</em> and is sometimes with <span class="add">[to the <span class="ar">ت</span>]</span>: <span class="auth">(Mgh:)</span> Lth says that <span class="ar">تخوم</span> <span class="add">[written without any vowel-sign]</span> signifies <em>a division,</em> or <em>place of division, between two districts</em> and <em>two towns</em> or <em>villages;</em> and the <em>limit,</em> or <em>boundary, of the land of any district</em> and <em>town</em> or <em>village</em> is its <span class="ar">تخوم</span>: and AHeyth says that this word signifies <em>limits,</em> or <em>boundaries:</em> <span class="auth">(TA:)</span> or <span class="ar">تُخُومٌ</span>, with damm, signifies <em>a sign,</em> or <em>mark,</em> and <em>a limit,</em> or <em>boundary, that is a division between two lands;</em> and is of the fem. gender: and the pl. is <span class="ar">تُخُومٌ</span> also, and <span class="ar">تُخُمٌ</span>: <span class="auth">(Ḳ:)</span> this app. means that these are pls. of <span class="ar">تُخُومٌ</span>; but the former is a word that is used as a sing. and as a pl.; and the latter <a href="#taxuwmN">is pl. of <span class="ar">تَخُومٌ</span></a>, like as <span class="ar">صُبُرٌ</span> is of <span class="ar">صَبُورٌ</span>, and <span class="ar">غُفُرٌ</span> of <span class="ar">غَفُورٌ</span>: <span class="auth">(TA:)</span> or <span class="auth">(as ISk says, TA)</span> the sing. is <span class="arrow"><span class="ar">تُخْمٌ↓</span></span> and <span class="ar">تَخْمٌ</span> <span class="auth">(Ḳ)</span> and<span class="arrow"><span class="ar">تَخُومَةٌ↓</span></span>: <span class="auth">(AḤn, Ṣ,* Ḳ:)</span> accord. to AʼObeyd, the Arabic linguists say <span class="arrow"><span class="ar">تَخُومٌ↓</span></span>, like <span class="ar">صَبُورٌ</span>, making it fem. and sing.; but the people of Syria say <span class="ar">تُخُومٌ</span>, with damm to the <span class="ar">ت</span>, making it pl., and the sing. is <span class="ar">تَخْمٌ</span>: accord. to IB, one says <span class="arrow"><span class="ar">تَخُومٌ↓</span></span> and <span class="ar">تُخُومٌ</span>, and <span class="ar">زَبُورٌ</span> and <span class="ar">زُبُورٌ</span>, and <span class="ar">عَذُوبٌ</span> and <span class="ar">عُذُوبٌ</span>; and no fourth instance of the kind is known; <span class="add">[<a href="#EacuwbN">but see <span class="ar">عَذُوبٌ</span></a>;]</span> and the Basrees pronounce it with damm <span class="add">[to the <span class="ar">ت</span>]</span>, and the Koofees with fet-ḥ. <span class="auth">(TA.)</span> It is said in a trad., <span class="ar long">مَلْعُونٌ مَنْ غَيَّرَ تُخُومَ الأَرْضِ</span>, meaning, accord. to AʼObeyd, <span class="add">[<em>Cursed is he who alters</em>]</span> <em>the limits,</em> or <em>boundaries, of land;</em> and <em>the signs,</em> or <em>marks, of the way:</em> or, as some say, <em>the limits,</em> or <em>boundaries, of the sacred territory.</em> <span class="auth">(TA.)</span> And <span class="ar long">اجعل همّك تخومًا</span>, <span class="add">[or rather<span class="arrow"><span class="ar long">اِجْعَلْ لِهَمِّكَ تَخُومًا↓</span></span>,]</span> means ‡ <span class="add">[<em>Set thou to thy purpose</em>]</span> <em>a limit,</em> to which go thou, and pass not beyond it. <span class="auth">(TA.)</span> And <span class="ar long">هُوَ طَيِّبُ التُّخُومِ</span> † <em>He is good in respect of ancestry,</em> or <em>origin:</em> <span class="auth">(JK:)</span> or <em>in respect of natural dispositions;</em> or, as some relate the saying, <span class="arrow"><span class="ar">التَّخُومِ↓</span></span>. <span class="auth">(TA.)</span> <span class="ar">تُخُومٌ</span> also signifies † <em>A state,</em> or <em>condition, that one desires</em> <span class="add">[app. as the limit of his wish]</span>. <span class="auth">(IAạr, Sh, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuxomN">
				<h3 class="entry"><span class="ar">تُخْمٌ</span></h3>
				<div class="sense" id="tuxomN_A1">
					<p><span class="ar">تُخْمٌ</span>: <a href="#taxomN">see <span class="ar">تَخْمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tuxamapN">
				<h3 class="entry"><span class="ar">تُخَمَةٌ</span></h3>
				<div class="sense" id="tuxamapN_A1">
					<p><span class="ar">تُخَمَةٌ</span>, <span class="auth">(Mṣb in the present art., and Ṣ and Ḳ in art. <span class="ar">وخم</span>,)</span> originally <span class="ar">وُخْمَةٌ</span>, <span class="auth">(Mṣb, and Ṣ in art. <span class="ar">وخم</span>,)</span> and <span class="ar">تُخْمَةٌ</span>, <span class="auth">(Mṣb, and Ṣ and Ḳ in art. <span class="ar">وخم</span>,)</span> the latter vulgar, <span class="auth">(Ṣ in art. <span class="ar">وخم</span>,)</span> but occurring in poetry, <span class="auth">(Ṣ and Ḳ in that art.,)</span> <em>Indigestion,</em> or <em>heaviness of the stomach arising from food which it is too weak to digest;</em> <span class="auth">(Mṣb in art. <span class="ar">وخم</span>;)</span> <em>a disease produced by unsuitable</em> <span class="add">[or <em>unwholesome</em>]</span> <em>food,</em> <span class="auth">(Ḳ and TA in that art.,)</span> or <em>by fulness of the stomach:</em> <span class="auth">(TA ibid.:)</span> pl. <span class="ar">تُخَمَاتٌ</span> <span class="auth">(Ṣ and Ḳ ibid.)</span> and <span class="ar">تُخَمٌ</span>. <span class="auth">(Mṣb, and Ṣ and Ḳ in art. <span class="ar">وخم</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taxuwmN">
				<h3 class="entry"><span class="ar">تَخُومٌ</span></h3>
				<div class="sense" id="taxuwmN_A1">
					<p><span class="ar">تَخُومٌ</span>: <a href="#taxomN">see <span class="ar">تَخْمٌ</span></a>, in seven places.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuxuwmN">
				<h3 class="entry"><span class="ar">تُخُومٌ</span></h3>
				<div class="sense" id="tuxuwmN_A1">
					<p><span class="ar">تُخُومٌ</span> <a href="#taxomN">pl. of <span class="ar">تَخْمٌ</span></a>, <a href="#taxomN">which see throughout</a>: and also used as a sing.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taxuwmapN">
				<h3 class="entry"><span class="ar">تَخُومَةٌ</span></h3>
				<div class="sense" id="taxuwmapN_A1">
					<p><span class="ar">تَخُومَةٌ</span>: <a href="#taxomN">see <span class="ar">تَخْمٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoxamapN">
				<h3 class="entry"><span class="ar">مَتْخَمَةٌ</span></h3>
				<div class="sense" id="matoxamapN_A1">
					<p><span class="ar long">طَعَامٌ مَتْخَمَةٌ</span>, <span class="auth">(JK, and Ṣ and Ḳ in art. <span class="ar">وخم</span>,)</span> originally <span class="ar">مَوْخَبَةٌ</span>, <span class="auth">(Ṣ in art. <span class="ar">وخم</span>,)</span> <em>Food that causes one to suffer from</em> <span class="ar">تُخَمَة</span> <span class="add">[or <em>indigestion</em>]</span>. <span class="auth">(JK, and Ḳ in art. <span class="ar">وخم</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaAximN">
				<h3 class="entry"><span class="ar">مُتَاخِمٌ</span></h3>
				<div class="sense" id="mutaAximN_A1">
					<p><span class="ar">مُتَاخِمٌ</span> <em>Conterminous</em> to a land (<span class="ar">لِأَرْضٍ</span>). <span class="auth">(Mgh.)</span> You say also, <span class="ar long">هُوَ مُتَاخِمِى</span> <em>He is my neighbour, his house,</em> or <em>tent, adjoining mine.</em> <span class="auth">(TA in art. <span class="ar">جمد</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0299.pdf" target="pdf">
							<span>Lanes Lexicon Page 299</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
