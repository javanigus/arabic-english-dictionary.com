<article class="root" id="Root_tmr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/070_tm">تم</a></span>
				<span class="ar">تمر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/072_tmk">تمك</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tmr_1">
				<h3 class="entry">1. ⇒ <span class="ar">تمر</span></h3>
				<div class="sense" id="tmr_1_A1">
					<p><span class="ar">تَمَرَ</span>, <span class="auth">(Ṣ, M, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْمُرُ</span>}</span></add>, <span class="auth">(M, TA,)</span> or <span class="ar">ـِ</span>, <span class="auth">(Mṣb,)</span> inf. n. <span class="ar">تَمْرٌ</span>; <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">تمّر↓</span></span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَتْمِيرٌ</span>; <span class="auth">(TA;)</span> and<span class="arrow"><span class="ar">اتمر↓</span></span>; <span class="auth">(M, Ḳ;)</span> <em>He fed</em> people <em>with,</em> or <em>gave</em> them <em>to eat,</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dried dates</em>]</span>. <span class="auth">(Ṣ, M, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tmr_2">
				<h3 class="entry">2. ⇒ <span class="ar">تمّر</span></h3>
				<div class="sense" id="tmr_2_A1">
					<p><span class="ar">تمّر</span>, inf. n. <span class="ar">تَتْمِيرٌ</span>, <em>He dried</em> <span class="auth">(Ṣ, M, Ḳ)</span> dates. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tmr_2_A2">
					<p>‡ <em>He dried</em> flesh-meat: <span class="auth">(T, Ṣ:)</span> or <em>he cut</em> flesh-meat <em>into small pieces,</em> <span class="auth">(M, A,* IAth, Ḳ,)</span> <em>like dates,</em> <span class="auth">(IAth,)</span> <em>and dried it.</em> <span class="auth">(M, A, IAth, Ḳ.)</span> It is said in a trad., <span class="ar long">كَانَ لَا يَرَى بِالتَّتْمِيرِ بَأْسًا</span> ‡ <em>He used not to see any harm in cutting flesh-meat into small pieces, like dates, and drying it:</em> meaning, in a Mohrim's thus preparing flesh-meat for travelling-provision; or in one's drying the flesh of wild animals before the state of ihrám. <span class="auth">(IAth.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tmr_2_A3">
					<p><a href="#tmr_1">See also 1</a>:</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tmr_2_A4">
					<p>and 4, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tmr_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتمر</span></h3>
				<div class="sense" id="tmr_4_A1">
					<p><span class="ar">اتمر</span> <em>He possessed many,</em> or <em>a large quantity of,</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dried dates</em>]</span>. <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tmr_4_A2">
					<p><span class="ar long">اتمرت النَّخْلَةُ</span>, <span class="auth">(T, M, A, Ḳ,)</span> and<span class="arrow"><span class="ar">تمّرت↓</span></span>, <span class="auth">(M, Ḳ,)</span> <em>The palm-tree bore</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dry dates</em>]</span>: <span class="auth">(M, Ḳ:)</span> or <em>had ripe dates upon it.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tmr_4_A3">
					<p><span class="ar long">اتمر الرُّطَبُ</span>; <span class="auth">(T, Ḳ;)</span> and<span class="arrow"><span class="ar">تمّر↓</span></span>, inf. n. <span class="ar">تَتْمِيرٌ</span>; <span class="auth">(Ḳ;)</span> <em>The ripe dates became in the state in which they are termed</em> <span class="ar">تَمْر</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tmr_4_A4">
					<p><a href="#tmr_1">See also 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tmr_5">
				<h3 class="entry">5. ⇒ <span class="ar">تتمّر</span></h3>
				<div class="sense" id="tmr_5_A1">
					<p><span class="ar">تتمّر</span> <em>It</em> <span class="auth">(flesh-meat)</span> <em>was cut into strips,</em> or <em>small pieces, and dried.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamorN">
				<h3 class="entry"><span class="ar">تَمْرٌ</span> / <span class="ar">تَمْرَةٌ</span></h3>
				<div class="sense" id="tamorN_A1">
					<p><span class="ar">تَمْرٌ</span>, a coll. gen. n.; <span class="auth">(Ṣ, A;)</span> masc. in one dial. and fem. in another <span class="add">[like other nouns of the same class]</span>; <span class="auth">(Mṣb;)</span> <em>Dates,</em> or the <em>fruit of the palmtree:</em> <span class="auth">(M:)</span> or <em>dried dates,</em> like <span class="ar">زَبِيبٌ</span> as applied to grapes, by general consent of the lexicologists: <span class="auth">(Mgh, Mṣb:)</span> the dates are left upon the palmtree, after they have become ripe, until they are dry, or nearly so, when they are cut, and left in the sun to dry thoroughly; and sometimes, as AḤát says, the fruit of the palm-tree is cut when full-grown but unripe, to lighten the tree, or from fear of theft, and left until it becomes <span class="ar">تَمْر</span>: <span class="auth">(Mṣb:)</span> the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَمْرَةٌ</span>}</span></add>: <a href="#tamorN">and the pl. of <span class="ar">تَمْرٌ</span></a> is <span class="ar">تُمُورٌ</span> and <span class="ar">تُمْرَانٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> meaning <em>sorts</em> or <em>varieties</em> <span class="add">[<em>of</em> <span class="ar">تَمْر</span>]</span>; for a coll. gen. n. has not a pl. in the proper sense: <span class="auth">(Ṣ:)</span> and in like manner the dual <span class="ar">تَمْرَانِ</span> means <em>two sorts</em> <span class="add">[<em>of</em> <span class="ar">تَمْر</span>]</span>: <span class="auth">(Sb cited in the M in art. <span class="ar">بسر</span>:)</span> <a href="#tamorapN">the pl. of <span class="ar">تَمْرَةٌ</span></a> is <span class="ar">تَمَرَاتٌ</span>. <span class="auth">(Ṣ, Ḳ.)</span> <span class="add">[<a href="#busorN">See also <span class="ar">بُسْرٌ</span></a>.]</span> Hence the prov., <span class="ar long">أَعْطِ أَخَاكَ تَمْرَةً فَإِنْ أَبَى فَجَمْرَةً</span> <span class="add">[<em>Give thou thy brother a dried date; and if he refuse</em> it, <em>a live coal</em>]</span>. <span class="auth">(A, TA.)</span> And <span class="ar long">التَّمْرُ بِالسَّوِيقِ</span> <span class="add">[<em>Dried dates with meal of parched barley</em> or <em>wheat</em>]</span> is another prov., used in allusion to requital. <span class="auth">(Lḥ.)</span> And one says, <span class="ar long">وَجَدَ عِنْدَهُ تَمْرَةَ الغُرَابِ</span>, meaning ‡ <em>He found with him,</em> or <em>at his abode, what he approved.</em> <span class="auth">(A.)</span> And <span class="ar long">نَفْسُهُ تَمْرَةٌ بِكَذَا</span> ‡ <em>His mind is pleased,</em> or <em>agreeably affected, with,</em> or <em>by, such a thing;</em> or <em>consents to such a thing.</em> <span class="auth">(A, Ḳ.* <span class="add">[Accord. to the TA, it is here like <span class="ar">فَرِحَةٌ</span>; but this seems to be true as to the meaning; not as to the form of the word. <a href="index.php?data=04_v/052_vmr">See also art. <span class="ar">ثمر</span></a>, <a href="#vamirN">voce <span class="ar">ثَمِرٌ</span></a>.]</span>)</span> And <span class="ar long">دَعْنِى إِنَّ نَفْسِى غَيْرُ تَمْرَةٍ</span> ‡ <span class="add">[<em>Leave thou me,</em> or <em>let me alone: verily my mind is not pleased,</em> or <em>happy</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمر</span> - Entry: <span class="ar">تَمْرٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tamorN_A2">
					<p><span class="ar long">تَمْرٌ هِنْدِىٌّ</span> <span class="add">[The <em>fruit of the tamarindtree;</em> thus called in the present day;]</span> <em>i. q.</em> <span class="ar">حُمَرٌ</span> and <span class="ar">حَوْمَرٌ</span>. <span class="auth">(Ḳ in art. <span class="ar">حمر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamorieBN">
				<h3 class="entry"><span class="ar">تَمْرِىٌّ</span></h3>
				<div class="sense" id="tamorieBN_A1">
					<p><span class="ar">تَمْرِىٌّ</span> <em>One who loves</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dried dates</em>]</span>. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tamBaArN">
				<h3 class="entry"><span class="ar">تَمَّارٌ</span></h3>
				<div class="sense" id="tamBaArN_A1">
					<p><span class="ar">تَمَّارٌ</span> <em>A seller of</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dried dates</em>]</span>. <span class="auth">(Ṣ, A, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAmirN">
				<h3 class="entry"><span class="ar">تَامِرٌ</span></h3>
				<div class="sense" id="taAmirN_A1">
					<p><span class="ar">تَامِرٌ</span> <em>Possessing</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dried dates</em>]</span>; <span class="auth">(Ṣ, M, A, Mṣb;)</span> like <span class="ar">لَابِنٌ</span> “possessing milk:” <span class="auth">(Ṣ, Mṣb:)</span> or <span class="ar">تَامِرٌ</span>, <span class="auth">(Lḥ, M, Ḳ,)</span> or<span class="arrow"><span class="ar">مُتْمِرٌ↓</span></span>, <span class="auth">(Ṣ, A,)</span> signifies <em>possessing many,</em> or <em>a large quantity of,</em> <span class="ar">تَمْر</span>: <span class="auth">(Lḥ, Ṣ, M, A, Ḳ:)</span> the former of these two words is held by ISd to be a possessive epithet: <span class="auth">(TA:)</span> and sometimes it may signify <em>feeding</em> people <em>with,</em> or <em>giving</em> them <em>to eat,</em> <span class="ar">تَمْر</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taAmuwrN">
				<h3 class="entry"><span class="ar">تَامُورٌ</span> / 
							<span class="ar">تَامُورَةٌ</span> /
							<span class="ar">تُومُورٌ</span> / 
							<span class="ar">تُومُرِىٌّ</span></h3>
				<div class="sense" id="taAmuwrN_A1">
					<p><span class="ar">تَامُورٌ</span> and <span class="ar">تَامُورَةٌ</span> and <span class="ar">تُومُورٌ</span> and <span class="ar">تُومُرِىٌّ</span>, &amp;c.: <a href="index.php?data=01_A/132_Amr">see art. <span class="ar">امر</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mutomirN">
				<h3 class="entry"><span class="ar">مُتْمِرٌ</span></h3>
				<div class="sense" id="mutomirN_A1">
					<p><span class="ar">مُتْمِرٌ</span>: <a href="#taAmirN">see <span class="ar">تَامِرٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matomuwrN">
				<h3 class="entry"><span class="ar">مَتْمُورٌ</span></h3>
				<div class="sense" id="matomuwrN_A1">
					<p><span class="ar">مَتْمُورٌ</span> <em>Furnished with</em> <span class="ar">تَمْر</span> <span class="add">[or <em>dried dates</em>]</span> <em>for travelling-provision.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0317.pdf" target="pdf">
							<span>Lanes Lexicon Page 317</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
