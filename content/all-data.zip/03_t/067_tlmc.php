<article class="root" id="Root_tlmc">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/066_tlk">تلك</a></span>
				<span class="ar">تلمذ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/068_tlw">تلو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tlmc_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">تلمذ</span></h3>
				<div class="sense" id="tlmc_Q1_A1">
					<p><span class="ar">تَلْمَذَ</span> <em>He was,</em> or <em>became, a</em> <span class="ar">تِلْمِيذ</span> <span class="add">[or <em>disciple,</em>, &amp;c.]</span>, <span class="ar">لِفُلَانٍ</span> <em>to such a one.</em> <span class="auth">(TA, passim.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tilomiycN">
				<h3 class="entry"><span class="ar">تِلْمِيذٌ</span></h3>
				<div class="sense" id="tilomiycN_A1">
					<p><span class="ar">تِلْمِيذٌ</span> <em>A disciple; a pupil; a learner:</em> or <em>a special servant of a teacher:</em> so says ʼAbd-El-Kádir El-Baghdádee, who composed a treatise solely on this word: <span class="auth">(MF, TA:)</span> or simply <em>a servant; a follower; a dependant:</em> pl. <span class="ar">تَلَامِيذُ</span> <span class="auth">(L, TA)</span> <span class="add">[and <span class="ar">تَلَامِذَةٌ</span>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0313.pdf" target="pdf">
							<span>Lanes Lexicon Page 313</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
