<article class="root" id="Root_tlOb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/058_tl">تل</a></span>
				<span class="ar">تلأب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/060_tlAn">تلان</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="tlOb_Q4">
				<h3 class="entry">Q. 4. ⇒ <span class="ar">اتلأبّ</span></h3>
				<div class="sense" id="tlOb_Q4_A1">
					<p><span class="ar">اِتْلَأَبَّ</span>:, &amp;c.: <a href="index.php?data=03_t/061_tlb">see art. <span class="ar">تلب</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0311.pdf" target="pdf">
							<span>Lanes Lexicon Page 311</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
