<article class="root" id="Root_tl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/057_tkl">تكل</a></span>
				<span class="ar">تل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/059_tlOb">تلأب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tl_1">
				<h3 class="entry">1. ⇒ <span class="ar">تلّ</span></h3>
				<div class="sense" id="tl_1_A1">
					<p><span class="ar">تَلَّهُ</span>, <span class="auth">(T, Ṣ,* M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُلُ</span>}</span></add>, inf. n. <span class="ar">تَلٌّ</span>, <span class="auth">(M, Mṣb,)</span> <em>He prostrated him,</em> or <em>threw him down;</em> <span class="auth">(T, Ṣ, M, Mṣb, Ḳ;)</span> <span class="add">[as some say,]</span> <em>upon the</em> <span class="ar">تَلّ</span>: <span class="auth">(TA:)</span> or <em>he threw him down</em> <span class="auth">(M, Ḳ, TA)</span> <em>upon his</em> <span class="ar">تَلِيل</span>, i. e., <span class="auth">(TA,)</span> <em>upon his neck,</em> and <em>his cheek:</em> <span class="auth">(M, Ḳ TA:)</span> but the former is the more approved; and thus it is explained as used in the phrase <span class="ar long">وَتَلَّهُ لِلْجَبِينِ</span> <span class="add">[in the Ḳur xxxvii. 103]</span>, <span class="auth">(M,)</span> <em>and he prostrated him,</em> or <em>threw him down,</em> <span class="auth">(Aboo-Is-ḥáḳ, T, Ṣ, Bḍ,)</span> <em>upon his side, so that the side of his forehead fell upon the ground;</em> <span class="auth">(Bḍ;)</span> or <em>upon his mouth;</em> <span class="auth">(Katá- deh, T;)</span> or <em>upon his face.</em> <span class="auth">(Bḍ.)</span> And <span class="ar long">تَلَّ النَّاقَةَ</span> <em>He made the she-camel to lie down upon her breast.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tl_1_A2">
					<p><em>He threw it upon the ground:</em> said of any corporeal thing. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tl_1_A3">
					<p><span class="ar">تَلَّ</span>,, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُلُ</span>}</span></add> <span class="auth">(IAạr, T, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْلِلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> <span class="add">[the latter anomalous in this case, and doubtful,]</span> also signifies <em>He poured</em> <span class="auth">(IAạr, T, Ḳ, TA)</span> into the hand of another. <span class="auth">(TA.)</span> And <span class="ar long">تَلَّ الشَّىْءَ فِى يَدِهِ</span> <em>He gave,</em> or <em>delivered, the thing to him:</em> <span class="auth">(M, Ḳ *:)</span> or <em>he threw,</em> or <em>put, the thing into his hand.</em> <span class="auth">(Ḳ.)</span> The Prophet says, <span class="ar long">بَيْنَا أَنَا نَائِمٌ أُتِيتُ بِمَفَاتِيحِ خَزَائِنِ الأَرْضِ فَتُلَّتْ فِى يَدِى</span>, i. e. <span class="add">[<em>While I was sleeping, I had the keys of the treasures of the earth brought to me,</em>]</span> <em>and they were poured into my hand:</em> <span class="auth">(IAạr, T, M:)</span> or <em>were thrown,</em> or <em>put, into my hand.</em> <span class="auth">(IAmb, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tl_1_A4">
					<p>Also, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَلٌّ</span>, <span class="auth">(M,)</span> <em>He lowered,</em> or <em>let down, the rope into the well,</em> <span class="auth">(M, Ḳ,)</span> <em>with the hand, on the occasion of drawing water.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tl_1_A5">
					<p><span class="arrow"><span class="ar long">تَلَّهُ بِتِلَّةِ↓ سَوْءٍ</span></span>, <span class="add">[aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُلُ</span>}</span></add>, accord. to rule,]</span> <em>He charged him,</em> or <em>upbraided him, with an evil,</em> or <em>a foul, thing.</em> <span class="auth">(Th, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tl_1_B1">
					<p><span class="ar">تَلَّ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْلِلُ</span>}</span></add> <span class="auth">(IAạr, T, M, Ḳ)</span> and <span class="ar">ـُ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[the latter anomalous in this case, and doubtful,]</span> <em>He was,</em> or <em>became, prostrated,</em> or <em>thrown down;</em> <span class="auth">(M, Ḳ)</span> <em>he fell,</em> or <em>fell down.</em> <span class="auth">(IAạr, T, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="tl_1_C1">
					<p><span class="ar long">تَلَّ جَبِينُهُ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْلِلُ</span>}</span></add> <span class="auth">(T, M, Ḳ)</span> and <span class="ar">ـُ</span>, <span class="auth">(Ḳ,)</span> <span class="add">[the latter anomalous in this case also, and doubtful,]</span> inf. n. <span class="ar">تَلٌّ</span>, <span class="auth">(T, M,)</span> <em>The side of his forehead sweated,</em> or <em>exuded sweat.</em> <span class="auth">(M, Ḳ.)</span> And in like manner the verb is used in relation to a wateringtrough. <span class="auth">(Lḥ, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="tl_1_D1">
					<p><span class="ar">تَلِلْت</span> is an imitative sequent to <span class="ar">ضَلِلْت</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tl_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتلّ</span></h3>
				<div class="sense" id="tl_4_A1">
					<p><span class="ar long">اتلّ المَائِعَ</span> <em>He made the fluid,</em> or <em>liquid, to drop,</em> or <em>fall in drops.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tl_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">تلتل</span></h3>
				<div class="sense" id="tl_RQ1_A1">
					<p><span class="ar">تَلْتَلَهُ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">تَلْتَلَةٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>He moved him, agitated him, shook him, put him into a state of motion</em> or <em>commotion;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> or <em>did so vehemently:</em> <span class="auth">(Ṣ, Ḳ, and Mgh in art. <span class="ar">تر</span>:)</span> <em>he shook him,</em> or <em>shook him violently,</em> <span class="auth">(namely, a drinker,)</span> <em>and ordered him to breathe in his face, that he might know whether he had drunk</em> <span class="add">[<em>wine or the like</em>]</span>, <em>or not;</em> <span class="auth">(TA in this art. and art. <span class="ar">تر</span>;)</span> as also <span class="ar">تَرْتَرَهُ</span>, and <span class="ar">مَزْمَزَهُ</span>. <span class="auth">(TA in the latter art.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tl_RQ1_A2">
					<p><span class="ar">تَلْتَلَةٌ</span> also signifies <em>Hard journeying:</em> and <em>rough,</em> or <em>severe,</em> or <em>vehement, driving.</em> <span class="auth">(Ḳ.)</span> You say, <span class="ar long">تَلْتَلَ الرَّجُلُ</span> <em>The man was rough,</em> or <em>severe,</em> or <em>vehement, in his driving.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: R. Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tl_RQ1_B1">
					<p><span class="ar long">تَلْتَلَةُ بَهْرَآءَ</span> is <span class="add">[The tribe of]</span> <em>Bahrà's pronouncing the</em> <span class="ar">ت</span> <em>of</em> <span class="ar">تَفْعَلُونَ</span> <em>with kesr;</em> <span class="auth">(M, Ḳ;)</span> <em>saying</em> <span class="ar">تِفْعَلُونَ</span>, <em>and</em> <span class="ar">تِشْهَدُونَ</span>, <em>and the like.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talBN">
				<span class="pb" id="Page_0311"></span>
				<h3 class="entry"><span class="ar">تَلٌّ</span></h3>
				<div class="sense" id="talBN_A1">
					<p><span class="ar">تَلٌّ</span>, accord. to Lth, <span class="add">[and accord. to general present usage,]</span> <em>A mound,</em> or <em>hill, of dust,</em> or <em>earth,</em> <span class="add">[or <em>rubbish,</em>]</span> <em>pressed together, not natural:</em> but this is a mistake <span class="add">[if meant as an explanation of the proper application]</span>, for with the Arabs it signifies <em>a natural hill:</em> En-Naḍr says that <em>it is of the smaller sort of</em> <span class="ar">إِكَام</span> <span class="add">[<a href="#OakamapN">pl. of <span class="ar">أَكَمَةٌ</span></a>]</span>; <em>it is of the height of a house,</em> or <em>tent, and the breadth of its back is about ten cubits; it is smaller than the</em> <span class="ar">أَكَمَة</span>, <em>has fewer stones, gives growth to nothing good, and its stones are compacted together exactly like those of the</em> <span class="ar">أَكَمَة</span>: <span class="auth">(T:)</span> <span class="add">[the mound, or artificial hill, above mentioned, is what is meant by its being said,]</span> the <span class="ar">تَلّ</span> of dust, or earth, is well known: and the word signifies also a <em>heap</em> of sand: <span class="auth">(M, Ḳ:*)</span> in both of these senses from <span class="ar">التَّلُّ</span> signifying “the throwing upon the ground” anything of a corporeal kind: <span class="auth">(M:)</span> also <em>a hill</em> <span class="auth">(M, Ḳ, TA)</span> <em>overtopping what is adjacent to it:</em> <span class="auth">(TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَتْلَالٌ</span> <span class="auth">(M, TA)</span> and <span class="ar">أَتُلٌّ</span> <span class="auth">(TA)</span> and <span class="add">[of mult.]</span> <span class="ar">تِلَالٌ</span> <span class="auth">(T, Ṣ, Mṣb, Ḳ)</span> and <span class="ar">تُلُولٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تَلٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="talBN_B1">
					<p>Also <em>A pillow:</em> pl. <span class="ar">أَتْلَالٌ</span>, which is extr.: or the pl. signifies <em>certain sorts of cloths,</em> or <em>of garments:</em> <span class="auth">(Ḳ, TA:)</span> or, as some say, <em>of pillows.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talBapN">
				<h3 class="entry"><span class="ar">تَلَّةٌ</span></h3>
				<div class="sense" id="talBapN_A1">
					<p><span class="add">[<span class="ar">تَلَّةٌ</span> inf. n. un. of 1, by Golius erroneously written <span class="ar">تُلَّةٌ</span>, and wrongly explained by him,]</span> <em>A single act of pouring</em> <span class="add">[&amp;c.]</span>. <span class="auth">(T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تَلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="talBapN_A2">
					<p><em>A single act of lying upon the side.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تَلَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="talBapN_B1">
					<p><a href="#talotalapN">See also <span class="ar">تَلْتَلَةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tilBapN">
				<h3 class="entry"><span class="ar">تِلَّةٌ</span></h3>
				<div class="sense" id="tilBapN_A1">
					<p><span class="ar">تِلَّةٌ</span> <em>A mode,</em> or <em>manner, of lying upon the side.</em> <span class="auth">(Fr, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tilBapN_A2">
					<p><em>Sluggishness, laziness,</em> or <em>indolence.</em> <span class="auth">(Fr, T, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tilBapN_A3">
					<p><em>A state,</em> or <em>condition.</em> <span class="auth">(Ṣ, M, Ḳ)</span> You say, <span class="ar long">هُوَ بِتِلَّةِ سَوْءٍ</span> <em>He is in an evil state</em> or <em>condition;</em> like as you say <span class="ar long">بِبِيْئَةِ سوء</span>: <span class="auth">(Ṣ:)</span> and <span class="ar long">بَاتَ بِتِلَّةِ سَوْءٍ</span> <em>He passed the night in an evil state</em> or <em>condition.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تِلَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tilBapN_A4">
					<p><em>A thing;</em> as in the saying, <span class="ar long">تَلَّهُ بِتِلَّةِ سَوْءٍ</span> <span class="add">[explained above]</span>: <a href="#tl_1">see 1</a>. <span class="auth">(Th, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تِلَّةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tilBapN_B1">
					<p><em>I. q.</em> <span class="ar">بِلَّةٌ</span>, <span class="auth">(T, M,)</span> or <span class="ar">بَلَلٌ</span>, as also<span class="arrow"><span class="ar">تَلَلٌ↓</span></span>: <span class="auth">(Ḳ:)</span> Abu-s-Semeyda' says that <span class="ar">تِلَّةٌ</span> and <span class="ar">بِلَّةٌ</span> and <span class="ar">تَلَلٌ</span> and <span class="ar">تَلَّةٌ</span> are all one <span class="add">[i. e. <em>Moisture</em>]</span>. <span class="auth">(T.)</span> One says, <span class="add">[app. to a person suspected of having drunk wine or the like,]</span> <span class="ar long">مَا هٰذِهِ التِّلَّةُ بِفِيكَ</span> i. e. <span class="ar">البَلَّةُ</span> <span class="add">[<em>What is this moisture in thy mouth?</em>]</span>. <span class="auth">(T, M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="talalN">
				<h3 class="entry"><span class="ar">تَلَلٌ</span></h3>
				<div class="sense" id="talalN_A1">
					<p><span class="ar">تَلَلٌ</span>: <a href="#tilBapN">see <span class="ar">تِلَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AltBalaAl">
				<h3 class="entry"><span class="ar">التَّلَال</span></h3>
				<div class="sense" id="AltBalaAl_A1">
					<p><span class="ar">التَّلَال</span> in the phrase <span class="ar long">هُوَ الضَّلَالُ بْنُ التَّلَالِ</span> is an imitative sequent. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taliylN">
				<h3 class="entry"><span class="ar">تَلِيلٌ</span></h3>
				<div class="sense" id="taliylN_A1">
					<p><span class="ar">تَلِيلٌ</span> <em>Prostrated,</em> or <em>thrown down;</em> as also<span class="arrow"><span class="ar">مَتْلُولٌ↓</span></span>: <span class="auth">(IAạr, T, M, Ḳ:)</span> <span class="add">[pl. of the former <span class="ar">تَلَّى</span>, like as <span class="ar">صَرْعَى</span> <a href="#SariyEN">is pl. of <span class="ar">صَرِيعٌ</span></a>, and <span class="ar">قَتْلَى</span> of <span class="ar">قَتِيلٌ</span>, &amp;c.; as in the phrase]</span> <span class="ar long">قَوْمٌ تَلَّى</span> <em>A company of men prostrated,</em> or <em>thrown down.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تَلِيلٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="taliylN_B1">
					<p>The <em>neck:</em> <span class="auth">(T, M, Ḳ:)</span> and the <em>cheek:</em> <span class="auth">(TA:)</span> pl. <span class="add">[of pauc.]</span> <span class="ar">أَتِلَّةٌ</span> and <span class="add">[of mult.]</span> <span class="ar">تُلُلٌ</span> and <span class="ar">تَلَائِلُ</span>. <span class="auth">(M, Ḳ.)</span> You say, <span class="ar long">لَهُ تَلِيلٌ كَجِذْعِ السَّحُوقِ</span> <span class="add">[<em>He has a neck like the trunk of the tall palm-tree</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AltBalaAlapu">
				<h3 class="entry"><span class="ar">التَّلَالَةُ</span></h3>
				<div class="sense" id="AltBalaAlapu_A1">
					<p><span class="ar">التَّلَالَةُ</span> is an imitative sequent to <span class="ar">الضَّلَالَةُ</span>. <span class="auth">(T,* Ṣ, M,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talotalapN">
				<h3 class="entry"><span class="ar">تَلْتَلَةٌ</span></h3>
				<div class="sense" id="talotalapN_A1">
					<p><span class="ar">تَلْتَلَةٌ</span> <a href="#tl_RQ1">inf. n. of R. Q. 1 <span class="add">[q. v.]</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تَلْتَلَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="talotalapN_A2">
					<p>Also <em>Hardship, difficulty, distress,</em> or <em>adversity:</em> <span class="auth">(M, Ḳ:)</span> pl. <span class="ar">تَلَاتِلُ</span>, <span class="auth">(TA,)</span> signifying <em>hardships, difficulties,</em>, &amp;c. <span class="auth">(Aboo-Turáb, T, Ṣ, M.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">تَلْتَلَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="talotalapN_B1">
					<p><em>A drinking-vessel that is made of the envelope</em> (<span class="ar">قِيقَآءَة</span>, Ṣ, or <span class="ar">قِيقَآء</span>, M and Ḳ) <em>of the spadix of a palm-tree;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> so called because what it contains is poured into the throat; <span class="auth">(T;)</span> as also<span class="arrow"><span class="ar">تَلَّةٌ↓</span></span>: <span class="auth">(M, Ḳ:)</span> it is said that <span class="ar">نَبِيذ</span> is drunk with it. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talBN.1">
				<h3 class="entry"><span class="ar">تَلٌّ</span></h3>
				<div class="sense" id="talBN.1_A1">
					<p><span class="ar">تَلٌّ</span> is an imitative sequent to <span class="ar">ضَالٌّ</span>. <span class="auth">(T,* Ṣ, M,* Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matalBN">
				<h3 class="entry"><span class="ar">مَتَلٌّ</span></h3>
				<div class="sense" id="matalBN_A1">
					<p><span class="ar">مَتَلٌّ</span> <em>A place of prostrating.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matalBN.1">
				<h3 class="entry"><span class="ar">مَتَلٌّ</span></h3>
				<div class="sense" id="matalBN.1_A1">
					<p><span class="ar">مَتَلٌّ</span> <span class="add">[as a subst.]</span> <em>A thing with which one prostrates:</em> <span class="auth">(M, Ḳ:)</span> and hence <em>a spear:</em> <span class="auth">(Mṣb:)</span> and <span class="add">[as an epithet]</span>, applied to a spear, <em>with which one prostrates:</em> <span class="auth">(T,* Ṣ, M:)</span> or, applied to a spear, <em>erect;</em> or <em>even and erect.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">مَتَلٌّ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="matalBN.1_A2">
					<p><em>Strong;</em> <span class="auth">(Ṣ, M, Ḳ;)</span> applied to a man and to a camel <span class="auth">(M, Ḳ, TA)</span>, &amp;c. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تل</span> - Entry: <span class="ar">مَتَلٌّ.1</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="matalBN.1_A3">
					<p>A man <em>erect in prayer:</em> <span class="auth">(T, M, Ḳ:)</span> so accord. to Lth, who cites the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">رِجَالٌ يُتِلُّونَ الصَّلَاةَ قِيَامُ</span> *</div> 
					</blockquote>
					<p>but this is a mistake; for <span class="ar">يُتِلُّونَ</span> is from <span class="ar">تَلَّى</span>, and means, who make prayer to follow prayer. <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutalBilN">
				<h3 class="entry"><span class="ar">مُتَلِّلٌ</span></h3>
				<div class="sense" id="mutalBilN_A1">
					<p><span class="ar">مُتَلِّلٌ</span> One <em>who prostrates much,</em> or <em>often; who does so by twisting his leg with the leg of another.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="matoluwlN">
				<h3 class="entry"><span class="ar">مَتْلُولٌ</span></h3>
				<div class="sense" id="matoluwlN_A1">
					<p><span class="ar">مَتْلُولٌ</span>: <a href="#taliylN">see <span class="ar">تَلِيلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0310.pdf" target="pdf">
							<span>Lanes Lexicon Page 310</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0311.pdf" target="pdf">
							<span>Lanes Lexicon Page 311</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
