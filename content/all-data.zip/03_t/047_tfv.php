<article class="root" id="Root_tfv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/046_tEs">تعس</a></span>
				<span class="ar">تفث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/048_tfH">تفح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tfv_1">
				<h3 class="entry">1. ⇒ <span class="ar">تفث</span></h3>
				<div class="sense" id="tfv_1_A1">
					<p><span class="ar">تَفِثَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْفَثُ</span>}</span></add>, inf. n. <span class="ar">تَفَثٌ</span>, <em>He left off,</em> or <em>abstained from, anointing himself, and shaving his pubes, and in consequence became dirty:</em> <span class="auth">(Mṣb:)</span> or <span class="ar">تَفَثٌ</span> signifies the <em>state of being dirty;</em> <span class="auth">(Mgh;)</span> the <em>state of having matted and dusty hair,</em> or <em>a dusty head, long left unanointed:</em> <span class="auth">(T, Mgh, Ḳ:)</span> so in relation to the rites and ceremonies of the pilgrimage: <span class="auth">(T, Ḳ:)</span> thus explained by ISh; but not by any <span class="add">[other]</span> of the lexicologists: he says that it is <em>one of the rites and ceremonies of the pilgrimage;</em> <span class="auth">(T;)</span> which is a conventional term of the professors, or lecturers, of the colleges: <span class="auth">(Mgh:)</span> accord. to I’Ab, it signifies the <em>shaving, and shortening,</em> or <em>clipping, of the beard and mustache and</em> <span class="add">[<em>the hair of</em>]</span> <em>the armpit, and slaughtering</em> <span class="add">[<em>of the victims</em>]</span>, <em>and casting</em> <span class="add">[<em>of the pebbles</em>]</span>: accord. to Fr, the <em>slaughtering of the</em> <span class="add">[<em>victims termed</em>]</span> <span class="ar">بُدْن</span>, <em>and other victims, namely, kine, and sheep</em> or <em>goats, and shaving the head, and paring the nails, and the like:</em> <span class="auth">(T:)</span> AO says that no poem is adduced as presenting an ex. of it: <span class="auth">(Mṣb, TA:)</span> and Zj says that it is not known by the lexicologists except from the expositors of the Ḳur-án; <span class="auth">(T, M;)</span> who say that it is the <em>clipping the mustache, and paring the nails, and plucking out the hair of the armpit, and shaving the pubes, and clipping the hair</em> <span class="add">[<em>of the head</em>]</span>: <span class="auth">(T:)</span> or the <em>plucking out the hair, and paring of the nails, and deviating from all that is prohibited to the</em> <span class="ar">مُحْرِم</span>: <span class="auth">(M:)</span> as though it were a passing from the state of <span class="ar">إِحْرَام</span> to the state of <span class="ar">إِحْلَال</span>: <span class="auth">(T, M:)</span> or, in the rites and ceremonies of the pilgrimage, the <em>doing such things as paring the nails, and clipping the mustache, and shaving the pubes</em> <span class="auth">(Ṣ, Ḳ)</span> <em>and the head, and casting the pebbles, and slaughtering the</em> <span class="ar">بُدْن</span>, <span class="auth">(Ṣ,)</span> <em>&amp;c.:</em> <span class="auth">(Ṣ, Ḳ: <span class="add">[but in two copies of the Ṣ, this art. is omitted:]</span>)</span> or the <em>doing away with the matted and dusty state of the hair, and pollution and dirt, absolutely.</em> <span class="auth">(TA.)</span> Accord. to ISh, <span class="ar long">قَضَآءُ التَّفَثِ</span> means <em>The doing away with the matted and dusty state of the hair by shaving, and paring the nails, and the like:</em> <span class="auth">(T:)</span> or it means <em>the doing away with the state of</em> <span class="ar">تَفَث</span>, <em>by clipping the mustache, and paring the nails, and plucking out the hair of the armpit, and shaving the pubes.</em> <span class="auth">(Mgh.)</span> Accord. to IAạr, <span class="ar long">ثُمَّ لِيَقْضُوا تَفَثَهُمْ</span> <span class="add">[in the Ḳur xxii. 30]</span> means <em>Then let them accomplish their needful acts of shaving and cleansing:</em> <span class="auth">(T:)</span> or it means <em>then let them do away with their dirtiness, by clipping the mustache, and paring the nails, and plucking out the hair of the armpit, and shaving the pubes, on the occasion of</em> <span class="ar">إِحْلَال</span>: <span class="auth">(Bḍ:)</span> it is an allowance, after entering the state of <span class="ar">إِحْلَال</span>, of that which was forbidden them in the state of <span class="ar">إِحْرَام</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفث</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tfv_1_A2">
					<p><span class="ar long">فَتَفَثَتِ الدِمَآءُ مَكَانَهُ</span> occurs in a trad., meaning <em>And the blood</em> <span class="auth">(lit. <em>bloods</em>)</span> <em>contaminated the place thereof.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tafivN">
				<h3 class="entry"><span class="ar">تَفِثٌ</span></h3>
				<div class="sense" id="tafivN_A1">
					<p><span class="ar">تَفِثٌ</span>, <span class="auth">(T, Mgh, Ḳ,)</span> accord. to ISh, applied to a man, <span class="auth">(T, Mgh,)</span> <em>Altered</em> <span class="add">[<em>in odour or the like</em>]</span>, (<span class="ar">مُغَيَّرٌ</span>, T,) or <em>dusty,</em> (<span class="ar">مُغْبَرٌّ</span>, Mgh, Ḳ, or <span class="ar">مُتَغِبِّرٌ</span>, TA,) <em>having matted and dusty hair, not having anointed himself,</em> <span class="auth">(T, Mgh, Ḳ,*)</span> <em>nor shaven his pubes.</em> <span class="auth">(T, Mgh. <span class="add">[In the former it is implied that this explanation is doubtful.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0308.pdf" target="pdf">
							<span>Lanes Lexicon Page 308</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
