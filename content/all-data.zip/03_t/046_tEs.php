<article class="root" id="Root_tEs">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/045_tEb">تعب</a></span>
				<span class="ar">تعس</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/047_tfv">تفث</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tEs_1">
				<h3 class="entry">1. ⇒ <span class="ar">تعس</span></h3>
				<div class="sense" id="tEs_1_A1">
					<p><span class="ar">تَعَسَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْعَسُ</span>}</span></add>, inf. n. <span class="ar">تَعْسٌ</span>; <span class="auth">(Ṣ, A, Mṣb, Ḳ, &amp;c.;)</span> and <span class="ar">تَعسَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْعَسُ</span>}</span></add>; <span class="auth">(Sh, AHeyth, A, IAth, Ḳ;)</span> but the latter is not chaste; <span class="auth">(A, TA;)</span> or the former is used in addressing a person, saying <span class="ar">تَعَسْتَ</span>; and the latter, in narration; <span class="auth">(Ḳ;)</span> accord. to Sh; but ISd says that this is strange; <span class="auth">(TA;)</span> <em>He fell, having stumbled; contr. of</em> <span class="ar">اِنْتَعَشَ</span>: this is the primary signification: <span class="auth">(Ṣ:)</span> or <em>he stumbled and fell</em> <span class="auth">(AHeyth, A, IAth, Ḳ)</span> <em>upon his hands and mouth,</em> <span class="auth">(AHeyth, TA,)</span> or <em>upon his face:</em> <span class="auth">(IAth, TA:)</span> or <em>he fell upon his face:</em> <span class="auth">(Er-Rustamee, Mṣb, TA:)</span> <span class="add">[and this may also be meant by one of the explanations of the inf. n. in the TA, which is <span class="ar long">نُكْسٌ فِى سَفَالٍ</span>:]</span> or <em>he fell in any manner.</em> <span class="auth">(TA.)</span> You say, by way of imprecation, <span class="ar long">تَعَسَ وَٱنْتَكَسَ</span>, meaning <em>May he fall upon his face, and not rise after his fall until he fall a second time.</em> <span class="auth">(Mṣb.)</span> And <span class="ar long">تَعَسَ فَمَا ٱنْتَعَشَ وَشِيكَ فَلَا ٱنْتَقَشَ</span> <span class="add">[<em>May he fall, having stumbled,</em> or <em>stumble and fall,</em>, &amp;c., <em>and not rise again; and may he be pricked with a thorn, and not extract the thorn</em>]</span>. <span class="auth">(TA.)</span> And accord. to certain of the Kilábees, <span class="ar">تَعَسَ</span> signifies <em>He missed his proof in litigation,</em> and <em>the object of his search in seeking.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tEs_1_A2">
					<p><em>He perished.</em> <span class="auth">(Aboo-ʼAmr Ibn-El-ʼAlà, Ṣ, Ḳ.)</span> You say, <span class="ar">تَعَسْتَ</span>, as though meaning <em>Mayest thou perish.</em> <span class="auth">(ISh, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tEs_1_A3">
					<p><em>He became far removed.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tEs_1_A4">
					<p><em>He became lowered,</em> or <em>degraded.</em> <span class="auth">(A, Ḳ.)</span> You say also, <span class="ar long">تَعَسَ جَدُّهُ</span> <span class="add">[<em>His fortune,</em> or <em>good fortune, fell:</em> or <em>may his fortune,</em> or <em>good fortune, fall</em>]</span>. <span class="auth">(Ḳ in art. <span class="ar">عثر</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tEs_1_B1">
					<p><span class="ar long">تَعَسَهُ ٱللّٰهُ</span>, <span class="add">[aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْعَسُ</span>}</span></add>, inf. n. <span class="ar">تَعْسٌ</span>;]</span> <span class="auth">(AʼObeyd, A, Mṣb, Ḳ;)</span> and<span class="arrow"><span class="ar">اتعسهُ↓</span></span>; <span class="auth">(AHeyth, Ṣ, A, Mṣb, Ḳ;)</span> the former unknown to Sb; <span class="auth">(Az, TA;)</span> <em>God made him to fall, having stumbled:</em> <span class="auth">(Ṣ:)</span> or <em>to stumble and fall</em> <span class="auth">(AHeyth, A, Ḳ)</span> <em>upon his hands and mouth,</em> <span class="auth">(AHeyth, TA,)</span> or <em>upon his face:</em> <span class="auth">(TA:)</span> or <em>to fall upon his face:</em> <span class="auth">(Mṣb:)</span> or <em>to fall in any manner.</em> <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0308"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tEs_1_B2">
					<p><em>God destroyed him;</em> or <em>made him to perish.</em> <span class="auth">(AʼObeyd, Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="tEs_1_B3">
					<p><em>God made him to become far removed.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B4</span>
				</div>
				<div class="sense" id="tEs_1_B4">
					<p><em>God lowered,</em> or <em>degraded, him.</em> <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B5</span>
				</div>
				<div class="sense" id="tEs_1_B5">
					<p>You say, by way of imprecation, <span class="ar long">تَعْسًا لَهُ</span> <em>May he</em> <span class="add">[<em>fall, having stumbled:</em> or, <em>stumble and fall:</em> or, <em>stumble and fall upon his hands and mouth:</em> or, <em>upon his face:</em> or]</span> <em>fall upon his face:</em> <span class="auth">(Mṣb:)</span> or <em>may God make destruction to cleave to him:</em> <span class="auth">(Ṣ, TA:)</span> <span class="add">[or <em>may God destroy him.</em>]</span> Aboo-Is-ḥáḳ says, in explanation of the phrase <span class="ar long">فَتَعْسًا لَهُمْ</span>, in the Ḳur xlvii. 9, that it may be in the accus. case as meaning<span class="arrow"><span class="ar long">أَتْعَسَهُمُ↓ ٱللّٰهُ</span></span>. <span class="auth">(TA.)</span> A man also says, by way of imprecation, to his swift and excellent camel, when it stumbles, <span class="ar">تَعْسًا</span>, meaning <em>May God throw thee down upon thy nostrils:</em> expressing his disapproval of the stumbling of a beast of such age and strength: but if it be not a swift and excellent beast, and stumble, he says to it <span class="ar">لَعًا</span>. <span class="auth">(TA.)</span> You say also,<span class="arrow"><span class="ar long">أَتْعَسَ↓ ٱللّٰهُ جَدَّهُ</span></span> <span class="add">[<em>May God make his fortune,</em> or <em>good fortune, to sink!</em>]</span> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tEs_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتعس</span></h3>
				<div class="sense" id="tEs_4_A1">
					<p><a href="#tEs_1">see <span class="ar">تَعَسَهُ</span></a>, in three places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taEosN">
				<h3 class="entry"><span class="ar">تَعْسٌ</span></h3>
				<div class="sense" id="taEosN_A1">
					<p><span class="ar">تَعْسٌ</span> <a href="#tEs_1">inf. n. of 1</a> <span class="add">[which see, throughout]</span>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تعس</span> - Entry: <span class="ar">تَعْسٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taEosN_A2">
					<p>Also <em>Evil; mischief.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taEisN">
				<h3 class="entry"><span class="ar">تَعِسٌ</span></h3>
				<div class="sense" id="taEisN_A1">
					<p><span class="ar">تَعِسٌ</span>: <a href="#taAEisN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAEisN">
				<h3 class="entry"><span class="ar">تَاعِسٌ</span></h3>
				<div class="sense" id="taAEisN_A1">
					<p><span class="ar">تَاعِسٌ</span> <span class="auth">(A, Ḳ)</span> and<span class="arrow"><span class="ar">تَعِسٌ↓</span></span> <span class="auth">(Mṣb, Ḳ)</span> act. part. ns. of 1, <span class="add">[i. e., respectively, of <span class="ar">تَعَسَ</span> and <span class="ar">تَعِسَ</span>, accord. to rule, used intransitively,]</span> <span class="auth">(A, Mṣb, Ḳ,)</span> both applied to a man: <span class="auth">(Ḳ:)</span> and the former, to fortune, or good fortune. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoEasapN">
				<h3 class="entry"><span class="ar">مَتْعَسَةٌ</span></h3>
				<div class="sense" id="matoEasapN_A1">
					<p><span class="ar">مَتْعَسَةٌ</span> <span class="add">[<em>A cause of falling after stumbling:</em> or <em>of stumbling and falling</em>, &amp;c. (<a href="#tEs_1">See 1</a>.)]</span> You say, <span class="ar long">هٰذَا الأَمْرُ مَنْحَسَةٌ مَتْعَسَةٌ</span> <span class="add">[<em>This affair is a cause of ill luck; a cause of falling</em>, &amp;c.]</span>. <span class="auth">(A, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0307.pdf" target="pdf">
							<span>Lanes Lexicon Page 307</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0308.pdf" target="pdf">
							<span>Lanes Lexicon Page 308</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
