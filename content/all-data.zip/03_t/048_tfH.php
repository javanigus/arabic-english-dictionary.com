<article class="root" id="Root_tfH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/047_tfv">تفث</a></span>
				<span class="ar">تفح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/049_tfrq">تفرق</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tfH_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتفح</span></h3>
				<div class="sense" id="tfH_4_A1">
					<p><span class="ar">اتفحهُ</span> <span class="add">[<em>He gave him an apple</em>]</span>. You say, <span class="ar long">أَتْحَفَكَ مَنْ أَتْفَحَكَ</span> <span class="add">[<em>He makes a present to thee who gives thee an apple</em>]</span>. <span class="auth">(A: there immediately following the saying, <span class="ar long">فُلَانٌ تُحْفَتُهُ تُفَّاحَةٌ</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tafoHapN">
				<h3 class="entry"><span class="ar">تَفْحَةٌ</span></h3>
				<div class="sense" id="tafoHapN_A1">
					<p><span class="ar">تَفْحَةٌ</span> <em>A sweet odour.</em> <span class="auth">(Abu-l-Khattáb, L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tufBaAHN">
				<h3 class="entry"><span class="ar">تُفَّاحٌ</span> / <span class="ar">تُفَّاحَةٌ</span></h3>
				<div class="sense" id="tufBaAHN_A1">
					<p><span class="ar">تُفَّاحٌ</span>, of the measure <span class="ar">فُعَّالٌ</span>; an Arabic word; <span class="add">[not arabicized;]</span> <span class="auth">(Mṣb;)</span> <span class="add">[The <em>apple,</em> or <em>apples;</em>]</span> <em>a certain fruit,</em> <span class="auth">(L, Mṣb,)</span> <em>well known,</em> <span class="auth">(Ṣ, L, Mṣb, Ḳ,)</span> <em>plentiful in</em> <span class="add">[<em>the cooler parts of</em>]</span> <em>the land of the Arabs:</em> <span class="auth">(AḤn, TA:)</span> the word is said by Abu-l-Khattáb to be derived from <span class="ar">تَفْحَةٌ</span> “a sweet odour:” <span class="auth">(L:)</span> the n. un. is with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تُفَّاحَةٌ</span>}</span></add>: <span class="auth">(Ṣ, L, Mṣb:)</span> the pl. is <span class="ar">تَفَافِيحُ</span>: <span class="auth">(T:)</span> and the dim. of the n. un. is<span class="arrow"><span class="ar">تُفَيْفيحَةٌ↓</span></span>. <span class="auth">(L.)</span> You say, <span class="ar long">فُلَانٌ تُحْفَتُهُ تُفَّاحَةٌ</span> <span class="add">[<em>Such a one, his present is an apple</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفح</span> - Entry: <span class="ar">تُفَّاحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tufBaAHN_A2">
					<p><span class="ar long">تُفَّاحُ الحُبِّ</span> and <span class="ar long">تُفَّاحٌ ذَهَبِىٌّ</span>: <a href="#baAcanojaAnN">see <span class="ar">بَاذَنْجَانٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفح</span> - Entry: <span class="ar">تُفَّاحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tufBaAHN_A3">
					<p><span class="ar long">تُفَّاحُ البَرِّ</span>: <a href="#yaboruwHN">see <span class="ar">يَبْرُوحٌ</span></a>, <a href="index.php?data=02_b/064_brH">in art. <span class="ar">برح</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفح</span> - Entry: <span class="ar">تُفَّاحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tufBaAHN_A4">
					<p><span class="ar">التُّفَّاحَةُ</span> also signifies ‡ <em>The head of the thigh-bone, which is in the haunch-bone.</em> <span class="auth">(Kr, A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفح</span> - Entry: <span class="ar">تُفَّاحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tufBaAHN_A5">
					<p><span class="ar long">لَطَمْنَ بِالعُنَّابِ التُّفَّاحَ</span> <span class="add">[lit. <em>They</em> <span class="auth">(women)</span> <em>slapped, with the jujubes, the apples</em>]</span> means, ‡ <em>with the fingers,</em> or <em>the ends of the fingers, the cheeks.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tufayofiyHapN">
				<h3 class="entry"><span class="ar">تُفَيْفِيحَةٌ</span></h3>
				<div class="sense" id="tufayofiyHapN_A1">
					<p><span class="ar">تُفَيْفِيحَةٌ</span>: <a href="#tufBaAHN">see <span class="ar">تُفَّاحٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matofaHapN">
				<h3 class="entry"><span class="ar">مَتْفَحَةٌ</span></h3>
				<div class="sense" id="matofaHapN_A1">
					<p><span class="ar">مَتْفَحَةٌ</span> <em>A place where apples grow</em> <span class="auth">(L, Ḳ)</span> <em>in abundance.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0308.pdf" target="pdf">
							<span>Lanes Lexicon Page 308</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
