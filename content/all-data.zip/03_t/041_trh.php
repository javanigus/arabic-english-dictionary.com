<article class="root" id="Root_trh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/040_trnjbyn">ترنجبين</a></span>
				<span class="ar">تره</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/042_tsE">تسع</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trh_1">
				<h3 class="entry">1. ⇒ <span class="ar">تره</span></h3>
				<div class="sense" id="trh_1_A1">
					<p><span class="ar">تَرِهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَهُ</span>}</span></add>, <em>He fell into what are termed</em> <span class="ar">تُرَّهَات</span>, said to signify, originally, <span class="add">[<em>deserts, such as are termed</em>]</span> <span class="ar">قِفَار</span>, and to be metaphorically applied to ‡ <em>false,</em> or <em>vain, sayings</em> or <em>actions</em> or <em>affairs; unprofitable sayings:</em> <span class="auth">(Ḳ,* TA:)</span> or † <em>he uttered false and confused and vain speech, with somewhat of embellishment,</em> <span class="auth">(Lth, TA,)</span> or <em>without foundation,</em> or <em>order,</em> or <em>method.</em> <span class="auth">(Akh, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="turBahN">
				<h3 class="entry"><span class="ar">تُرَّهٌ</span></h3>
				<div class="sense" id="turBahN_A1">
					<p><span class="ar">تُرَّهٌ</span>: <a href="#turBahapN">see what next follows</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turBahapN">
				<h3 class="entry"><span class="ar">تُرَّهَةٌ</span></h3>
				<div class="sense" id="turBahapN_A1">
					<p><span class="ar">تُرَّهَةٌ</span> <em>A small road branching off from a main road:</em> <span class="auth">(Aṣ, Ṣ, Ḳ:)</span> a Persian word, arabicized: <span class="auth">(Aṣ, Ṣ:)</span> pl. <span class="ar">تُرَّهَاتٌ</span> <span class="auth">(Aṣ, Ṣ, Ḳ)</span> and <span class="ar">تُرُّهَاتٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تره</span> - Entry: <span class="ar">تُرَّهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="turBahapN_A2">
					<p><em>A</em> <span class="add">[<em>desert, such as is termed</em> <span class="ar">قَفْرٌ</span>, (<a href="#trh_1">see 1</a>,) or]</span> <span class="ar">مَفَازَةٌ</span>, <em>and</em> <span class="ar">صَحْرَآءُ</span>. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تره</span> - Entry: <span class="ar">تُرَّهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="turBahapN_A3">
					<p>The first in this paragraph is the primary signification: <span class="auth">(TA:)</span> and hence, metaphorically, <span class="auth">(Aṣ, Ṣ,)</span> ‡ <em>A false,</em> or <em>vain, saying</em> or <em>action</em> or <em>affair;</em> <span class="auth">(Aṣ, JK, Ṣ Ḳ;)</span> as also<span class="arrow"><span class="ar">تُرَّهٌ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> pl. of the former, <span class="ar">تُرَّهَاتٌ</span> <span class="auth">(JK, Ṣ, Ḳ *)</span> <span class="add">[and <span class="ar">تُرُّهَاتٌ</span>, as above]</span>; and of the latter, <span class="ar">تَرَارِيَهُ</span>: <span class="auth">(Ṣ, Ḳ:*)</span> or the primary signification of <span class="ar">تُرَّهَاتٌ</span> is <span class="ar">قِفَارٌ</span>: <span class="add">[<a href="#trh_1">see 1</a>:]</span> and it is metaphorically applied to ‡ <em>false,</em> or <em>vain, sayings</em> or <em> actions</em> or <em>affairs;</em> <span class="auth">(Ḳ;)</span> and <em>unprofitable sayings:</em> <span class="auth">(Z, Ḳ, TA:)</span> or, accord. to Az, <em>false,</em> or <em>vain, affairs:</em> and the sing. is <span class="arrow"><span class="ar">تُرَّهٌ↓</span></span>: or, accord. to IB, this last <a href="#turBahapN">is pl. of <span class="ar">تُرَّهَةٌ</span></a>: <span class="add">[or rather a coll. gen. n.:]</span> or, as some say, it is a sing.: <span class="auth">(TA:)</span> and accord. to Lth it signifies the act of <em>lying,</em> and <em>confusing</em> <span class="add">[<em>truth and falsehood</em>]</span>. <span class="auth">(Ḥar p. 165.)</span> <span class="add">[Sometimes it is followed by a syn., to give greater force to the signification:]</span> one says <span class="ar long">التُرَّهَاتُ البَسَابِسُ</span> and <span class="ar long">التُرَّهَاتُ الصَّحَاصِحُ</span>: and sometimes the former word is used as a prefixed noun governing the gen. case <span class="add">[so that one says <span class="ar long">تُرَّهَاتُ البَسَابِسُ</span> and <span class="ar">ترّهاتُ الصَّحَاصِحِ</span>: <span class="ar">الصَّحْصَحُ</span> is mentioned in the Ḳ, in this art., as a syn. of <span class="ar">التُّرَّهَةُ</span>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تره</span> - Entry: <span class="ar">تُرَّهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="turBahapN_A4">
					<p>Also <em>A calamity; a misfortune; an evil accident:</em> <span class="auth">(JK,* Ḳ:)</span> pl. <span class="add">[<span class="ar">تُرَّهَاتٌ</span> and]</span> <span class="ar">تَرَارِيَهُ</span>. <span class="auth">(JK.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تره</span> - Entry: <span class="ar">تُرَّهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="turBahapN_A5">
					<p><em>Wind.</em> <span class="auth">(JK, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تره</span> - Entry: <span class="ar">تُرَّهَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="turBahapN_A6">
					<p><em>Clouds,</em> or <em>a collection of clouds.</em> <span class="auth">(JK,* Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تره</span> - Entry: <span class="ar">تُرَّهَةٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="turBahapN_B1">
					<p><em>A certain small creeping thing</em> (<span class="ar">دُوَيْبَّة</span>) <span class="add">[<em>found</em>]</span> <em>in the sand.</em> <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0306.pdf" target="pdf">
							<span>Lanes Lexicon Page 306</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
