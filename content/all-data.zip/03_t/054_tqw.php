<article class="root" id="Root_tqw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/053_tqn">تقن</a></span>
				<span class="ar">تقى</span> / <span class="ar">تقو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/055_tk">تك</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">تقى</span>: or, accord. to some, <span class="ar">تقو</span></h4>
			<hr>
			<section class="entry main" id="tqw_1">
				<h3 class="entry">1. ⇒ <span class="ar">تقو</span> ⇒ <span class="ar">تقى</span></h3>
				<div class="sense" id="tqw_1_A1">
					<p><span class="ar">تَقَى</span>, aor. <span class="ar">ـِ</span> <span class="auth">(T, Ṣ, Ḳ, in art. <span class="ar">وقى</span>)</span> and <span class="ar">ـَ</span>, <span class="auth">(T, TA,)</span> or <span class="ar">تَقِىَ</span>, aor. <span class="ar">ـَ</span> <span class="auth">(Mṣb, <span class="add">[but the correctness of this I greatly doubt, unless, as appears to be the case, it is meant to be understood as an intrans. verb,]</span>)</span> inf. n. <span class="ar">تَقْىٌ</span>, <span class="auth">(Ṣ and TA in art. <span class="ar">تقى</span>, <span class="add">[which art. I find in only one copy of the Ṣ,]</span>)</span> or <span class="ar">تُقًى</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">تُقَاةٌ</span>, <span class="auth">(Mṣb, and also mentioned in the TA,)</span> of which <span class="ar">تُقًى</span> is pl., or coll. n., <span class="auth">(Kzz, IB, Mṣb,)</span> and <span class="ar">تَقِيَّةٌ</span> <span class="auth">(Ḳ)</span> and <span class="ar">تِقَآءٌ</span>; <span class="auth">(Lḥ, Ḳ;)</span> and<span class="arrow"><span class="ar">اِتَقَّى↓</span></span>, <span class="auth">(T, Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">اِتِّقَآءٌ</span> <span class="auth">(Mṣb)</span> and <span class="add">[quasi-inf. n.]</span> <span class="ar">تَقِيَّةٌ</span> and <span class="ar">تُقَاةٌ</span>; <span class="auth">(Ṣ, art. <span class="ar">وقى</span>;)</span> <em>He feared</em> God: <span class="auth">(Ṣ and TA in art. <span class="ar">تقى</span>: all else that follows is from art. <span class="ar">وقى</span> except where reference is made to another art.:)</span> or <em>he was cautious of</em> a thing; <em>guarded,</em> or <em>was on his guard, against</em> it; <em>prepared, prepared himself,</em> or <em>was in a state of preparation, against</em> it; or <em>feared</em> it: <span class="auth">(Ḳ:)</span> or <em>he looked forward to</em> a thing, <em>and guarded against</em> it, <em>sought to avoid</em> it, or <em>was cautious of</em> it. <span class="auth">(T, TA.)</span> <span class="add">[For other explanations of the latter verb, which apply also to the former, <a href="index.php?data=27_w/189_wqe">see art. <span class="ar">وقى</span></a>.]</span> <span class="arrow"><span class="ar">اِتَّقَى↓</span></span> is originally <span class="ar">اِوْتَقَى</span>; <span class="auth">(T, Ṣ;)</span> then <span class="ar">اِيتَقَى</span>; then <span class="ar">اِتَّقَى</span>; and when this came to be much in use, they imagined the <span class="ar">ت</span> to be a radical part of the word, and made the word <span class="ar">اِتَقَى</span>, aor. <span class="ar">يَتَقِى</span>, with fet-ḥ to the <span class="ar">ت</span> in each case, and without teshdeed; and not finding any analogue to it in their language, they said <span class="ar">تَقَى</span>, aor. <span class="ar">يَتْقِى</span>, like <span class="ar">قَضَى</span>, aor. <span class="ar">يَقْضِى</span>: <span class="auth">(Ṣ:)</span> or, as is said in the T, they suppressed the <span class="ar">ت</span>, and the <span class="ar">اِتَّقَى</span> changed into <span class="ar">ت</span>, in <span class="ar">اِتَّقَى</span>, and said <span class="ar">تَقَى</span>, aor. <span class="ar">يَتْقِى</span>. <span class="auth">(TA.)</span> A poet says, <span class="auth">(namely, Khufáf Ibn-Nudbeh, TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">جَلَاهَا الصَّيْقَلُونَ فَأَخْلَصُوهَا</span> *</div> 
						<div class="star">* <span class="ar long">خِفَافًا كُلُّهَا يَتْقِى بِأَثْرِ</span> *</div> 
					</blockquote>
					<p>or, as some read it, <span class="ar">يَتَقِى</span>, with the <span class="ar">ت</span> movent, but without teshdeed; <span class="auth">(Ṣ;)</span> <span class="pb" id="Page_0310"></span>and this latter, accord. to IB, is the right reading. <span class="auth">(TA.)</span> <span class="add">[<a href="index.php?data=01_A/019_Avr">See this verse explained in art. <span class="ar">اثر</span></a>.]</span> IB adds that Aboo-Saʼeed <span class="add">[app. meaning Aṣ]</span> disallowed <span class="ar">تَقَى</span>, aor. <span class="ar">يَتْقِى</span>, inf. n. <span class="ar">تَقْىٌ</span>; saying that it would require the imperative to be <span class="ar">اِتْقِ</span>, which is not said; and this, he states, is right: <span class="add">[for]</span> J says that the imperative used is <span class="ar">تَقِ</span> <span class="add">[<em>Fear thou,</em> or <em>beware thou,</em>, &amp;c.]</span>, as in <span class="ar long">تَقِ ٱللّٰهِ</span> <span class="add">[<em>Fear thou God</em>]</span>; and to a woman, <span class="ar">تَقِى</span>; formed from the verb <span class="ar">اِتَقَى</span>, without teshdeed, by the suppression of the <span class="ar">ا</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tqw_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتقو</span> ⇒ <span class="ar">اتقى</span></h3>
				<div class="sense" id="tqw_4_A1">
					<p><span class="ar long">مَا اَتْقَاهُ لِلّٰهِ</span> <span class="auth">(Ṣ, TA)</span> <em>How great is his reverential,</em> or <em>pious, fear of God!</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tqw_4_A2">
					<p><span class="ar long">ما اتقاهُ</span> is also said of a saddle, as meaning <em>How good is it for not galling the back!</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tqw_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّقو</span> ⇒ <span class="ar">اتّقى</span></h3>
				<div class="sense" id="tqw_8_A1">
					<p><a href="#tqw_1">see 1</a>, in two places; <a href="index.php?data=27_w/189_wqe">and see also art. <span class="ar">وقى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuqFe">
				<h3 class="entry"><span class="ar">تُقًى</span></h3>
				<div class="sense" id="tuqFe_A1">
					<p><span class="ar">تُقًى</span>: <a href="#taqowae">see <span class="ar">تَقْوَى</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tuqaApN">
				<h3 class="entry"><span class="ar">تُقَاةٌ</span></h3>
				<div class="sense" id="tuqaApN_A1">
					<p><span class="ar">تُقَاةٌ</span>: <a href="#taqowae">see <span class="ar">تَقْوَى</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقو</span> - Entry: <span class="ar">تُقَاةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tuqaApN_A2">
					<p>In the phrase in the Ḳur <span class="add">[iii. 27]</span>, <span class="ar long">إِلَّا أَنْ تَتَّقُوا مِنْهُمْ تُقَاةً</span>, it may be an inf. n. <span class="add">[so that the meaning may be <em>Unless ye fear from them with</em> a great <em>fearing</em> (<a href="#tqw_1">see 1</a>)]</span>: or it may be a pl. <span class="add">[app. of <span class="ar">تَقِىٌّ</span>, like as <span class="ar">كُمَاةٌ</span> <a href="#kamieBN">is pl. of <span class="ar">كَمِىٌّ</span></a>, so that the meaning may be <em>unless ye fear from them, being fearful</em>]</span>: but it is better to regard it as an inf. n. because another reading is <span class="ar">تَقِيَّةً</span>. <span class="auth">(M, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taqieBN">
				<h3 class="entry"><span class="ar">تَقِىٌّ</span></h3>
				<div class="sense" id="taqieBN_A1">
					<p><span class="ar">تَقِىٌّ</span>, applied to a man, <span class="auth">(Mṣb, Ḳ, TA,)</span> <em>i. q.</em> <span class="ar">وَقِىٌّ</span> <span class="auth">(TA)</span> and <span class="ar">مُتَّقٍ</span> <span class="auth">(Ṣ)</span> <span class="add">[<em>Fearing; cautious;</em>, &amp;c.: (<a href="#tqw_1">see 1</a>:) and particularly <em>having a reverential,</em> or <em>pious, fear of God:</em> or simply <em>pious:</em> or <em>one who preserves,</em> or <em>guards, himself,</em> accord. to some, <em>exceedingly,</em> or <em>extraordinarily, from sin, either of commission or of omission:</em> (<a href="#wqe_8">see 8</a> <a href="index.php?data=27_w/189_wqe">in art. <span class="ar">وقى</span></a>:)]</span> accord. to IDrd, one <em>who preserves,</em> or <em>guards, himself from punishment</em> <span class="add">[<em>in the world to come</em>]</span>, <em>and from acts of disobedience, by righteous conduct:</em> from <span class="ar long">وَقَيْتُ نَفْسِى</span>: said by the grammarians to be originally <span class="ar">وَقُوىٌ</span>; then, <span class="ar">تَقُوىٌ</span>: or, accord. to Aboo-Bekr, <span class="add">[originally]</span> of the measure <span class="ar">فَعِيلٌ</span>, as is indicated by the first of its pls. mentioned below: but he who says that it is <span class="add">[originally]</span> of the measure <span class="ar">فَعُولٌ</span> says that it has that pl. because it has become like a word <span class="add">[originally]</span> of the measure <span class="ar">فَعِيلٌ</span>: <span class="auth">(TA:)</span> or <em>righteous, virtuous, just,</em> or <em>honest;</em> <span class="auth">(Mṣb in art. <span class="ar">تقى</span>;)</span> <em>contr. of</em> <span class="ar">فَاجِرٌ</span>: <span class="auth">(Idem in art. <span class="ar">بر</span>:)</span> pl. <span class="ar">أَتْقِيَآءُ</span> <span class="auth">(Mṣb in art. <span class="ar">تقى</span>, and Ḳ)</span> and <span class="ar">تُقَوَآءُ</span>, <span class="auth">(Ḳ,)</span> which is extr., and of a class disallowed by Sb, <span class="auth">(TA,)</span> <span class="add">[and app. also <span class="ar">تُقَاةٌ</span>, q. v. suprà.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="taqiyBapN">
				<h3 class="entry"><span class="ar">تَقِيَّةٌ</span></h3>
				<div class="sense" id="taqiyBapN_A1">
					<p><span class="ar">تَقِيَّةٌ</span>: <a href="#taqowae">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taqowae">
				<h3 class="entry"><span class="ar">تَقْوَى</span></h3>
				<div class="sense" id="taqowae_A1">
					<p><span class="ar">تَقْوَى</span>, or <span class="ar">تَقْوًى</span>, accord. to different readings in the Ḳur ix. 110, <span class="auth">(Bḍ,)</span> <span class="add">[of which readings the former is the more common,]</span> is originally <span class="ar">تَقْيَا</span>, <span class="auth">(Ḳ,)</span> <span class="add">[or <span class="ar">تَقْيًا</span>,]</span> or <span class="add">[rather <span class="ar">وَقْيَا</span>, or <span class="ar">وَقْيًا</span>, and then]</span> <span class="ar">وَقْوَى</span>, of the measure <span class="ar">فَعْلَى</span>, from <span class="ar">وَقَيْتُ</span>, <span class="auth">(ISd, TA,)</span> or, accord. to MF, the right opinion is that it is <span class="add">[<span class="ar">وَقْوًى</span>,]</span> of the measure <span class="ar">فَعْوَلٌ</span>, <span class="auth">(TA,)</span> and is thus transformed in order to make a distinction between the subst. and the epithet such as <span class="ar">خَزْيَا</span> and <span class="ar">صَدْيَا</span>: <span class="auth">(Ḳ:)</span> it is a subst. from <span class="ar">اِتَّقَى</span> or <span class="ar">وَقَى</span>; <span class="auth">(Mṣb, Ḳ;)</span> <span class="add">[and signifies <em>Fear; caution;</em>, &amp;c.: (<a href="#tqw_1">see 1</a>:) and particularly <em>reverential,</em> or <em>pious, fear of God:</em> or simply <em>piety:</em> or the <em>preservation,</em> or <em>guarding, of oneself,</em> accord. to some, <em>exceedingly,</em> or <em>extraordinarily, from sin, either of commission or of omission:</em> or the <em>preservation,</em> or <em>guarding, of oneself from punishment in the world to come, and from acts of disobedience, by righteous conduct:</em> or <em>righteousness, virtue, justice,</em> or <em>honesty:</em> (<a href="#taqieBN">see <span class="ar">تَقِىٌّ</span></a>:) its explanations in relation to religion are many and various, but are all resolvable into <em>fear of God,</em> or <em>of sin;</em> or the <em>preservation,</em> or <em>guarding, of oneself from sin:</em>]</span> and<span class="arrow"><span class="ar">تَقِيَّةٌ↓</span></span> and<span class="arrow"><span class="ar">تُقَاةٌ↓</span></span> are syn. with each other <span class="auth">(Ṣ)</span> and with <span class="ar">تَقْوَى</span>, <span class="auth">(Mṣb,)</span> and are used as inf. ns. of <span class="ar">اِتَّقَى</span>: <span class="auth">(Ṣ:)</span> and<span class="arrow"><span class="ar">تُقًى↓</span></span> <span class="add">[also]</span> is syn. with <span class="ar">تَقْوَى</span>; <span class="auth">(Ṣ;)</span> or it is pl. of<span class="arrow"><span class="ar">تُقَاةٌ↓</span></span>, or a coll. n., <span class="auth">(Kzz, IB, Mṣb,)</span> like as <span class="ar">طُلًى</span> is of <span class="ar">طُلَاةٌ</span>, <span class="auth">(Kzz, IB,)</span> and as <span class="ar">رُطَبٌ</span> is of <span class="ar">رُطَبَةٌ</span>. <span class="auth">(Mṣb.)</span> <span class="ar long">وَآتَاهُمْ تَقْوَاهُمْ</span>, in the Ḳur xlvii. 19, means <em>And hath explained to them,</em> <span class="auth">(Bḍ,)</span> or <em>suggested to them,</em> <span class="auth">(Jel, TA,)</span> <em>what they should fear,</em> or <em>that from which they should preserve themselves:</em> <span class="auth">(Bḍ, Jel, TA:)</span> or <em>hath aided them to practise their</em> <span class="ar">تَقْوَى</span>: <span class="auth">(Bḍ:)</span> or <em>hath given them the recompense of their</em> <span class="ar">تقوى</span>. <span class="auth">(Bḍ, TA.)</span> And <span class="ar long">هُوَ أَهْلُ التَّقْوَى</span>, in the Ḳur lxxiv. last verse, means <em>He is entitled,</em> or <em>worthy, to be feared;</em> or <em>to be reverentially,</em> or <em>piously, feared.</em> <span class="auth">(Bḍ, Jel, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="Oatoqae">
				<h3 class="entry"><span class="ar">أَتْقَى</span></h3>
				<div class="sense" id="Oatoqae_A1">
					<p><span class="ar long">هُوَ أَتْقَى مِنْ فُلَانٍ</span> <span class="add">[<em>He is more fearing,</em> or <em>cautious,</em>, &amp;c., <em>than such a one; more reverentially,</em> or <em>piously, fearful of God;</em> or <em>more pious;</em>, &amp;c.;]</span> <em>he has more</em> <span class="ar">تَقْوَى</span> <em>than such a one.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0309.pdf" target="pdf">
							<span>Lanes Lexicon Page 309</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0310.pdf" target="pdf">
							<span>Lanes Lexicon Page 310</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
