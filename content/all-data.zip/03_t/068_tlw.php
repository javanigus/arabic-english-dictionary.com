<article class="root" id="Root_tlw">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/067_tlmc">تلمذ</a></span>
				<span class="ar">تلو</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/069_tle">تلى</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tlw_1">
				<h3 class="entry">1. ⇒ <span class="ar">تلو</span> ⇒ <span class="ar">تلى</span></h3>
				<div class="sense" id="tlw_1_A1">
					<p><span class="ar">تَلَا</span> <em>He followed;</em> or <em>went,</em> or <em>walked, behind,</em> or <em>after.</em> <span class="auth">(IAạr, T.)</span> You say, <span class="ar">تَلَوْتُهُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُوُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تُلُوٌّ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">تَلْوٌ</span>, <span class="auth">(Er-Rághib, MF,)</span> <em>I followed him</em> or <em>it;</em> or <em>went,</em> or <em>walked, behind,</em> or <em>after, him</em> or <em>it;</em> <span class="auth">(Ṣ, M, Mṣb, Ḳ;)</span> namely, a man <span class="add">[&amp;c.]</span>; <span class="auth">(Ṣ, Mṣb;)</span> <em>immediately,</em> or <em>without intervention;</em> and sometimes it means <em>bodily</em> <span class="add">[or <em>in reality</em>]</span>; and sometimes, <em>virtually,</em> or <em>in effect:</em> <span class="auth">(Er-Rághib:)</span> and so <span class="ar">تَلَيْتُهُ</span>; <span class="auth">(Ḳ;)</span> and<span class="arrow"><span class="ar">تَلَّيْتُهُ↓</span></span>, <span class="auth">(Aṣ,* T,* Ḳ,)</span> inf. n. <span class="ar">تَتْلِيَةٌ</span>. <span class="auth">(Ḳ.)</span> The phrase, in the Ḳur xci. 2, <span class="ar long">وَالقَمَرِ إِذَا تَلَاهَا</span> means <em>By the moon when its rising follows the rising thereof;</em> i. e., the rising of the sun; at the beginning of the lunar month: <span class="auth">(Bḍ:)</span> or, <em>when it follows in rising the setting thereof,</em> <span class="auth">(Bḍ, Jel,)</span> on the night of the full moon: <span class="auth">(Bḍ:)</span> or, <em>when it follows it in becoming round, and in fullness of light;</em> <span class="auth">(M,* Bḍ;)</span> i. e., <em>when it follows it in the way of imitation, and in respect of rank;</em> for the moon borrows its light of the sun, and is to it in the place of a successor. <span class="auth">(Er-Rághib.)</span> Here, Ks pronounced <span class="ar">تلاها</span> with imáleh, <span class="add">[either because <span class="ar">تَلَيْتُ</span> <a href="#talaWotu">is a dial. var. of <span class="ar">تَلَوْتُ</span></a>, or]</span> because, although it has <span class="ar">و</span> for its last radical letter, it occurs with words that may be so pronounced, namely, <span class="ar">يَغْشَاهَا</span> and <span class="ar">بَنَاهَا</span>. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlw_1_A2">
					<p><span class="ar long">تَلَوْتُ الأِبِلَ</span> ‡ <em>I drove,</em> or <em>brought,</em> or <em>gathered, the camels together, from their several quarters:</em> because the driver follows the driven. <span class="auth">(A, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tlw_1_A3">
					<p><span class="ar long">هُوَ يَتْلُو فُلَانًا</span> <em>He imitates such a one, and follows what he does; he follows him in action.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tlw_1_A4">
					<p><span class="ar">تَلَا</span>, <span class="auth">(T,)</span> first pers. <span class="ar">تَلَوْتُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُوُ</span>}</span></add>, <span class="auth">(T,)</span> inf. n. <span class="ar">تِلَاوَةٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> <em>He read,</em> or <em>perused,</em> or <em>he recited,</em> <span class="auth">(T, M, Ḳ,)</span> the Ḳur-án, <span class="auth">(Ṣ, M, Mṣb, Ḳ,)</span> or any discourse, or piece of language: <span class="auth">(M, Ḳ:)</span> or <em>he followed</em> it, <span class="auth">(I’Ab, T, Ṣ,* M,)</span> <em>and did according to it;</em> <span class="auth">(I’Ab, Mujáhid, T;)</span> namely, the Scripture: <span class="auth">(I’Ab, Mujáhid, T, M:)</span> or the inf. n. specially signifies the <em>following</em> God's revealed Scriptures, sometimes <em>by reading,</em> or <em>perusing,</em> or <em>by reciting,</em> and sometimes <em>by conforming therewith</em> <span class="add">[as well as by reading, &amp;c., but not otherwise, for]</span> every <span class="ar">تِلَاوَة</span> is <span class="ar">قِرَآءَة</span>, but the reverse is not the case. <span class="auth">(Er-Rághib, TA.)</span> <span class="add">[You say also, <span class="ar long">تَلَا عَلَيْهِ</span> <em>He recited,</em> or <em>related, to him</em> a narrative, &amp;c.: see Ḳur v. 30, &amp;c.]</span> And <span class="ar long">فُلَانٌ يَتْلُو عَلَى فُلَانٍ</span>, and <span class="ar long">يَقُولُ عَلَيْهِ</span>, <em>Such a one lies,</em> or <em>says what is false, against such a one.</em> <span class="auth">(TA.)</span> <span class="ar long">وَٱتَّبَعُوا مَا تَتْلُوالشَّيَاطِينُ</span>, in the Ḳur ii. 96, means <span class="add">[<em>And they followed</em>]</span> <em>what the devils related,</em> or <em>rehearsed,</em> <span class="auth">(ʼAṭà, T,)</span> or <em>spoke;</em> <span class="auth">(AʼObeyd, T;)</span> or, <em>what the devils</em> of the Jinn, or of mankind, or of both, <em>read,</em> or <em>recited,</em> or what they <em>followed,</em> of the writings of enchantment: <span class="auth">(Bḍ:)</span> some here read <span class="arrow"><span class="ar">تُتَلِّى↓</span></span>. <span class="auth">(T.)</span> Hence the saying, <span class="ar long">لَا دَرَيْتَ وَلَا تَلَيْتَ</span>: <span class="auth">(T:)</span> or, accord. to Yoo, it is <span class="arrow"><span class="ar long">ولا أَتْلَيْتَ↓</span></span>: <span class="auth">(T, Ṣ:)</span> and others say that it is <span class="ar long">ولا ٱئْتَلَيْتَ</span>, from <span class="ar">أَلَوْتُ</span>. <span class="auth">(T. <span class="add">[<a href="#Alw_1">See these three readings explained in the latter part of the first paragraph <span class="new">{1}</span></a> <a href="index.php?data=01_A/126_Alw">of art. <span class="ar">الو</span></a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tlw_1_B1">
					<p><em>He remained behind,</em> or <em>held back.</em> <span class="auth">(IAạr, ISk, T.)</span> You say, <span class="ar long">تَلَا بَعْدَ قَوْمِهِ</span> <em>He held back,</em> or <em>lagged behind, after his people,</em> or <em>company, and remained.</em> <span class="auth">(TA.)</span> And <span class="ar">تَلَوْتُهُ</span>, <span class="auth">(AZ, AʼObeyd, T, Ṣ, M, Ḳ,)</span> and <span class="ar long">تَلَوْتُ عَنْهُ</span>, <span class="auth">(AZ, T, M, Ḳ,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْلُوُ</span>}</span></add>, <span class="auth">(AZ, T,)</span> inf. n. <span class="ar">تُلُوٌّ</span>, <span class="auth">(AZ, T, M,)</span> <em>I left him, and held back from going with him:</em> <span class="auth">(AZ, T:)</span> <em>I held back from him,</em> or <em>from aiding him, and left him:</em> <span class="auth">(AZ, AʼObeyd, T, Ṣ, M, Ḳ:)</span> thus the verb bears two contr. significations. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="tlw_1_C1">
					<p><em>He bought a</em> <span class="ar">تِلْو</span>, meaning the <em>young one of a mule.</em> <span class="auth">(IAạr, T, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="tlw_1_D1">
					<p><span class="ar long">تَلِيَتْ لِى مِنْ حَقِّى تَلِيَّةٌ</span>, and <span class="ar">تُلَاوَةٌ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْلَوُ</span>}</span></add>, <span class="auth">(ISk, Ṣ,)</span> inf. n. <span class="ar">تَلًا</span>, <span class="auth">(TA,)</span> <em>There remained to me, of my right,</em> or <em>due, a remainder.</em> <span class="auth">(ISk, Ṣ.)</span> And <span class="ar long">تَلِيَتْ لِى عِنْدَهُ تَلِيَّةٌ</span> <em>There remained to me, with him,</em> or <em>there remained owing to me by him, a remainder.</em> <span class="auth">(Aṣ, T.)</span> And <span class="ar long">تَلِىَ مِنَ الشَّهْرِ كَذَا</span>, <span class="auth">(M, Ḳ,)</span> inf. n. <span class="ar">تَلًا</span>, <span class="auth">(M,)</span> <em>There remained, of the month, such a portion.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlw_2">
				<h3 class="entry">2. ⇒ <span class="ar">تلّو</span> ⇒ <span class="ar">تلّى</span></h3>
				<div class="sense" id="tlw_2_A1">
					<p><a href="#tlw_1">see 1</a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlw_2_A2">
					<p><span class="ar long">هُوَ يُتَلَّى بَقِيَّةَ حَاجَتِهِ</span> <em>He demands, and seeks to obtain, the remainder of that which he wants.</em> <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tlw_2_A3">
					<p><span class="ar long">تلّى صَلَاتَهُ</span>, <span class="auth">(T, M, Ḳ,)</span> inf. n. <span class="ar">تَتْلِيَةٌ</span>, <span class="auth">(Ḳ,)</span> <em>He made his prayer to be followed by other prayer:</em> <span class="auth">(T:)</span> or <em>he made his prescribed prayer to be followed by supererogatory prayer.</em> <span class="auth">(Sh, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tlw_2_A4">
					<p><span class="ar">تلّىِ</span>, inf. n. as above, <span class="add">[is also said to signify]</span> <em>He stood erect for prayer.</em> <span class="auth">(TA.)</span> <span class="add">[<a href="#mitalBN">But see <span class="ar">مِتَلٌّ</span></a>, <a href="index.php?data=03_t/058_tl">in art. <span class="ar">تل</span></a>.]</span></p>
				</div>
				<span class="pb" id="Page_0314"></span>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tlw_2_A5">
					<p>Also <em>He accomplished,</em> or <em>fulfilled, his vow.</em> <span class="auth">(IAạr, M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 2.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tlw_2_A6">
					<p>And <em>He was at the last gasp.</em> <span class="auth">(AZ, Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 2.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tlw_2_B1">
					<p><a href="#tlw_4">See also 4</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlw_3">
				<h3 class="entry">3. ⇒ <span class="ar">تالو</span> ⇒ <span class="ar">تالى</span></h3>
				<div class="sense" id="tlw_3_A1">
					<p><span class="ar">تالاهُ</span>, inf. n. <span class="ar">مُتَالَاةٌ</span>, <em>i. q.</em> <span class="ar">رَاسَلَهُ</span> <span class="add">[meaning, <span class="ar long">فِى الغِنَآءِ</span>, i. e. <em>He relieved him,</em> or <em>aided him, in singing, by taking up the strain when the latter was unable to prolong his voice sufficiently for the accomplishing of the cadence;</em> or <em>he did so with a high voice:</em> <a href="#mutaAlK">see <span class="ar">مُتَالٍ</span>, below</a>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlw_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتلو</span> ⇒ <span class="ar">اتلى</span></h3>
				<div class="sense" id="tlw_4_A1">
					<p><span class="ar long">أَتْلَيْتُهُ إِيَّاهُ</span> <em>I made him to follow him;</em> or, <em>it to follow it.</em> <span class="auth">(M, Ḳ.)</span> Hence, <span class="auth">(TA,)</span> <span class="ar long">اتلاهُ ٱللّٰهُ أَطْفَالًا</span> <em>God made him,</em> or <em>may God make him, to have little children following him.</em> <span class="auth">(Ṣ, TA.)</span> And <span class="ar">أَتْلَتْ</span> <em>She</em> <span class="auth">(a camel)</span> <em>had her young one following her:</em> <span class="auth">(Ṣ, Ḳ:)</span> whence the saying, <span class="ar long">لَا دَرَيْتَ وَلَا أَتْلَيْتَ</span>; accord. to Yoo: <span class="auth">(Ṣ:)</span> but <a href="#tlw_1">see 1</a>, where two other readings are mentioned, with a reference to the explanations.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlw_4_A2">
					<p><span class="add">[Hence also,]</span> <span class="ar">أَتْلَيْتُهُ</span> <em>I preceded him, outwent him, outstripped him,</em> or <em>got before him.</em> <span class="auth">(Ṣ.)</span> And <span class="ar long">مَا زِلْتُ أَتْلُوهُ حَتَّى أَتْلَيْتُهُ</span> <em>I ceased not to follow him until I became before him.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tlw_4_A3">
					<p><span class="ar long">أَتْلَيْتُ حَقِّى عِنْدَهُ</span> <em>I left a remainder of my due with him.</em> <span class="auth">(Ṣ, Ḳ.)</span> And <span class="ar long">أَتْلَيْتُ عِنْدَهُ تَليَّةً</span> <em>I left with him a remainder</em> <span class="auth">(T, M)</span> <em>of a thing,</em> or <em>of a debt,</em> or <em>of a needful thing.</em> <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tlw_4_A4">
					<p><span class="ar long">أَتْلَيْتُهُ عَلَى فُلَانٍ</span> <em>I referred him,</em> or <em>turned him over, for the payment of what was owing to him, to such a one, transferring the responsibility for the debt to the latter.</em> <span class="auth">(T, Ṣ,* Ḳ.*)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tlw_4_A5">
					<p><span class="ar long">اتلاهُ ذِمَّةً</span> <em>He gave him a bond,</em> or <em>an obligation, whereby he became responsible for his safety:</em> <span class="auth">(Ṣ, Ḳ:)</span> and <span class="ar">اتلاهُ</span> alone <span class="auth">(T, M, Ḳ)</span> signifies the same; <span class="auth">(T;)</span> <em>he gave him what is termed</em> <span class="ar">تَلَآء</span>, <span class="auth">(M, Ḳ,)</span> i. e. <span class="ar">ذِمَّةً</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">جِوَارًا</span>, <span class="auth">(M, Ḳ,)</span> and meaning also <em>an arrow on which was written his</em> (<em>the giver's</em>) <em>name,</em> <span class="auth">(Ḳ,* TA,)</span> <em>in order that, when he went to a tribe, he might show it to them, and they would not harm him:</em> <span class="auth">(TA:)</span> and <span class="ar long">اتلاهُ سَهْمًا</span> † <em>he gave him an arrow whereby to demand protection,</em> <span class="auth">(M, Ḳ, TA,)</span> <em>in order that he might not be harmed:</em> and <span class="ar long">اتلاهُ نَعْلًا</span> <em>he gave him a sandal for that purpose:</em> <span class="auth">(TA:)</span> and it means ‡ <em>he made him his</em> <span class="ar">تِلْو</span> <span class="add">[or <em>follower</em>]</span>, <em>and his companion.</em> <span class="auth">(TA.)</span> <span class="arrow"><span class="ar">تلّى↓</span></span>, also, signifies, like <span class="ar">أَتْلَى</span>, <em>He gave him his bond,</em> or <em>obligation, by which he became responsible for his safety.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlw_5">
				<h3 class="entry">5. ⇒ <span class="ar">تتلّو</span> ⇒ <span class="ar">تتلّى</span></h3>
				<div class="sense" id="tlw_5_A1">
					<p><span class="ar">تتلّى</span> <em>He sought repeatedly,</em> or <em>in a leisurely manner,</em> or <em>by degrees,</em> <span class="auth">(T, Ṣ, M, Ḳ,)</span> <em>to obtain</em> his right, or due, <em>until he received it fully,</em> or <em>wholly,</em> <span class="auth">(T, Ṣ,)</span> or <em>to obtain</em> a thing. <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlw_5_A2">
					<p><em>He collected much wealth.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 5.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tlw_5_A3">
					<p><span class="ar long">تَتَلَّيْتُ حَقِّى عِنْدَهُ</span> <em>I left with him,</em> or <em>in his possession, somewhat remaining of my right,</em> or <em>due.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 5.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tlw_5_B1">
					<p><em>Somewhat remained of his debt.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlw_6">
				<h3 class="entry">6. ⇒ <span class="ar">تتالو</span> ⇒ <span class="ar">تتالى</span></h3>
				<div class="sense" id="tlw_6_A1">
					<p><span class="ar long">تَتَالَتِ الأُمُورُ</span> <em>The things,</em> or <em>events, were consecutive; they followed one another.</em> <span class="auth">(M, Ḳ.)</span> And <span class="ar long">جَآءَتِ الخَيْلُ تَتَالِيًا</span> <em>The horses,</em> or <em>horsemen, came consecutively.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tlw_10">
				<h3 class="entry">10. ⇒ <span class="ar">استتلو</span> ⇒ <span class="ar">استتلى</span></h3>
				<div class="sense" id="tlw_10_A1">
					<p><span class="ar long">استتلاهُ الشَّىْءَ</span> <em>He,</em> or <em>it, invited him to follow the thing.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlw_10_A2">
					<p><span class="ar long">اِسْتَتْلَيْتُ فُلَانًا</span> <em>I made such a one to follow me.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 10.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tlw_10_A3">
					<p>And <em>I looked for, expected, awaited,</em> or <em>waited for, such a one.</em> <span class="auth">(IAạr, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: 10.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tlw_10_B1">
					<p><span class="ar long">استتلى فُلَانًا</span> also signifies ‡ <em>He sought,</em> or <em>demanded, of such a one, the arrow of protection</em> <span class="add">[<em>called</em> <span class="ar">تَلَآء</span>, q. v.]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talFA">
				<h3 class="entry"><span class="ar">تَلًا</span></h3>
				<div class="sense" id="talFA_A1">
					<p><span class="ar">تَلًا</span>: <a href="#taliyBapN">see <span class="ar">تَلِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tilowN">
				<h3 class="entry"><span class="ar">تِلْوٌ</span> / <span class="ar">تِلْوَةٌ</span></h3>
				<div class="sense" id="tilowN_A1">
					<p><span class="ar">تِلْوٌ</span> <em>A thing that follows another thing:</em> <span class="auth">(Ḳ:)</span> and <em>a follower</em> of another man. <span class="auth">(TA.)</span> <a href="#tiloWu">See also <span class="ar long">تِلْوُ الشَّىْءِ تَالٍ</span></a> means <em>That which follows the thing:</em> <span class="auth">(Ṣ:)</span> and <span class="ar long">هٰذَا تِلْوُ هٰذَا</span> <em>This is what follows this.</em> <span class="auth">(M.)</span> <span class="add">[Hence,]</span> <span class="ar long">تِلْوُ النَّاقَةِ</span> <em>The she-camel's young one that follows her:</em> <span class="auth">(Ṣ:)</span> and <span class="ar">تِلْوٌ</span> <span class="add">[alone]</span> <em>a ewe's,</em> or <em>she-goat's,</em> <span class="auth">(M,)</span> or <em>she-camel's,</em> <span class="auth">(Ḳ,)</span> <em>young one when weaned, and following the mother;</em> pl. <span class="ar">أَتْلَآءٌ</span>; and fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تِلْوَةٌ</span>}</span></add>: <span class="auth">(M, Ḳ:)</span> and the <em>young one of the ass;</em> <span class="auth">(M, Ḳ;)</span> because he follows his mother: <span class="auth">(M:)</span> and the <em>young one of a mule:</em> <span class="auth">(IAạr, T, Ḳ:)</span> and, accord. to En-Naḍr, <em>a kid,</em> and <em>a lamb, that has become large in the stomach</em> or <em>belly</em> (<span class="ar">استكرش</span>) <em>and in no need of his mother;</em> fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تِلْوَةٌ</span>}</span></add>: <span class="auth">(T:)</span> or the fem. signifies <em>a she-kid that has passed beyond the limit of those that are termed</em> <span class="ar">أَجْفَار</span> <span class="add">[<a href="#jaforN">pl. of <span class="ar">جَفْرٌ</span>, q. v.</a>]</span>, <span class="auth">(M, Ḳ,)</span> <em>until she has completed a year</em> <span class="add">[<em>from her birth</em>]</span> <em>and so become a</em> <span class="ar">جَذَع</span>. <span class="auth">(M.)</span> And a <span class="ar">تِلْوَة</span> of sheep or goats is <em>One that is brought forth,</em> or <em>that brings forth,</em> <span class="add">[the verb is <span class="ar">تُنْتَجُ</span>, which has both of these meanings,]</span> <em>before the</em> <span class="ar">صَفَرِيَّة</span> <span class="add">[q. v.]</span>. <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تِلْوٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tilowN_B1">
					<p>Also <em>High,</em> or <em>lofty.</em> <span class="auth">(Ḳ.)</span> One says, <span class="ar long">إِنَّهُ لَتِلْوُ المِقْدَارِ</span> <em>Verily he,</em> or <em>it, is high,</em> or <em>lofty, in measure.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talaMCN">
				<h3 class="entry"><span class="ar">تَلَآءٌ</span></h3>
				<div class="sense" id="talaMCN_A1">
					<p><span class="ar">تَلَآءٌ</span> <em>A bond,</em> or <em>an obligation, by which one becomes responsible for the safety of another:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> and <em>an arrow upon which the giver writes his name,</em> <span class="auth">(M, Ḳ, <span class="add">[in the CK, <span class="ar">المَتْلِىْ</span> is erroneously put for <span class="ar">المُتْلِى</span>,]</span>)</span> <em>and which he gives to a man, who, when he goes to a tribe, and shows it to them, passes unmolested:</em> <span class="auth">(M:)</span> and, accord. to IAmb, <em>responsibility,</em> or <em>suretiship.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَلَآءٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="talaMCN_A2">
					<p>Also The <em>transfer of a debt,</em> or <em>of a claim, by shifting the responsibility from one person to another.</em> <span class="auth">(Z, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taluwBN">
				<h3 class="entry"><span class="ar">تَلُوٌّ</span></h3>
				<div class="sense" id="taluwBN_A1">
					<p><span class="ar">تَلُوٌّ</span> A man <em>incessantly following:</em> <span class="auth">(IAạr, M, Ḳ:)</span> not mentioned by Yaạḳoob among the instances of this measure which he has limited; as <span class="ar">حَسُوٌّ</span> and <span class="ar">فَسُوٌّ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talieBN">
				<h3 class="entry"><span class="ar">تَلِىٌّ</span></h3>
				<div class="sense" id="talieBN_A1">
					<p><span class="ar">تَلِىٌّ</span> <span class="add">[accord. to the CK, erroneously, <span class="ar">تِلْىٌ</span>,]</span> <em>Using many oaths</em> (<span class="ar long">كَثِيرُ الأَيْمَانِ</span>): and <em>Having much wealth.</em> <span class="auth">(IAạr, T, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taliyBapN">
				<h3 class="entry"><span class="ar">تَلِيَّةٌ</span></h3>
				<div class="sense" id="taliyBapN_A1">
					<p><span class="ar">تَلِيَّةٌ</span> <span class="add">[accord. to the CK, erroneously, <span class="ar">تِلْيَةق</span>,]</span> and<span class="arrow"><span class="ar">تُلَاوَةٌ↓</span></span> <span class="auth">(ISk, T, Ṣ, M, Ḳ)</span> and<span class="arrow"><span class="ar">تَلًا↓</span></span> <span class="auth">(M, TA)</span> <em>A remainder</em> <span class="auth">(ISk, T, Ṣ, M, Ḳ)</span> of a thing, <span class="auth">(M,)</span> or of a right or due, <span class="auth">(ISk, Ṣ,)</span> or of a debt, <span class="auth">(Ṣ, M, Ḳ,)</span> and of a thing wanted, <span class="auth">(ISk and T in explanation of the second word, and M,)</span>, &amp;c. <span class="auth">(Ḳ.)</span> One says also, <span class="ar long">ذَهَبَتْ تَلِيَّةُ الشَّبَابِ</span> ‡ <em>The remainder of youthfulness,</em> or <em>youthful vigour, departed.</em> <span class="auth">(TA.)</span> And <span class="ar long">فُلَانٌ تَلِيَّةُ الأَحْرَارِ</span> ‡ <span class="add">[<em>Such a one is the last remaining of the ingenuous</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَلِيَّةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taliyBapN_A2">
					<p><span class="ar long">وَقَعَ كَذَا تَلِيَّةَ كَذَا</span> <em>Such a thing happened after such a thing.</em> <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tulaAwapN">
				<h3 class="entry"><span class="ar">تُلَاوَةٌ</span></h3>
				<div class="sense" id="tulaAwapN_A1">
					<p><span class="ar">تُلَاوَةٌ</span>: <a href="#taliyBapN">see <span class="ar">تَلِيَّةٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talawBae">
				<h3 class="entry"><span class="ar">تَلَوَّى</span></h3>
				<div class="sense" id="talawBae_A1">
					<p><span class="ar">تَلَوَّى</span> <em>A kind of boat:</em> <span class="auth">(M, Ḳ:)</span> of the measure <span class="ar">فَعَوَّلٌ</span>, <span class="auth">(M, TA,)</span> or <span class="ar">فَعَلْوَلٌ</span>: <span class="auth">(TA:)</span> so called because it follows the larger vessel: mentioned by Aboo-ʼAlee in the Tedhkireh. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talBaMCN">
				<h3 class="entry"><span class="ar">تَلَّآءٌ</span></h3>
				<div class="sense" id="talBaMCN_A1">
					<p><span class="ar long">تَلَّآءٌ لِلْقُرْآنِ</span> One <em>who reads, peruses,</em> or <em>recites, the Ḳur-án,</em> or <em>who follows it,</em> or <em>acts according to it, much,</em> or <em>often.</em> <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAlK">
				<h3 class="entry"><span class="ar">تَالٍ</span></h3>
				<div class="sense" id="taAlK_A1">
					<p><span class="ar">تَالٍ</span> act. part. n. of <span class="ar">تَلَا</span>; <em>Following; going,</em> or <em>walking, behind,</em> or <em>after;</em> <span class="add">[<em>immediately,</em> or <em>without intervention;</em> either <em>in reality,</em> or only <em>in effect;</em> (<a href="#tlw_1">see 1</a>;)]</span> <span class="auth">(T, Mṣb;)</span> as also<span class="arrow"><span class="ar">تِلْوٌ↓</span></span>. <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAlK_A2">
					<p><span class="ar">التَّالِى</span> <em>The fourth of the ten horses that are started together in a race.</em> <span class="auth">(TA voce <span class="ar">سُكَّيْت</span>, &amp;c., and Ḥam p. 46.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taAlK_A3">
					<p>Also, <span class="auth">(Sh, TA voce <span class="ar">مِجْدَحٌ</span>,)</span> and <span class="ar long">تَالِى النَّجْمٍ</span> <span class="add">[meaning <em>The follower of the Pleiades</em>]</span>, <span class="auth">(Ḳzw,)</span> <em>the star called</em> <span class="ar">الدَّبَرَانُ</span>. <span class="auth">(Sh, Ḳzw.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taAlK_A4">
					<p>And <span class="ar long">تَالِيَاتُ النُّجُومِ</span> <em>The last of the stars;</em> <span class="add">[app. <em>the last that are seen in the morningtwilight;</em>]</span> <span class="auth">(TA;)</span> as also <span class="ar">التَّوَالِى</span>. <span class="auth">(M, TA.)</span> <span class="add">[<span class="ar">تَالِيَاتٌ</span> and <span class="ar">تَوَال</span> are both pls. of <span class="ar">تَالِيَةٌ</span>, <a href="#taAlK">fem. of <span class="ar">تَالٍ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="taAlK_A5">
					<p><span class="ar">التَّوَالِى</span> also signifies <em>The last</em> of women journeying in vehicles upon camels; <span class="auth">(M, Ḳ;)</span> and in like manner, of camels. <span class="auth">(M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="taAlK_A6">
					<p>Also <em>Hinder parts, posteriors,</em> or <em>rumps:</em> and <em>the hinder parts</em> of horses: or <span class="auth">(of a horse, M)</span> <em>the tail and hind legs.</em> <span class="auth">(M, Ḳ.)</span> One says, <span class="ar long">إِنَّهُ لَحَثِيثُ التَّوَالِى</span> and <span class="ar long">سَرِيعُ التَّوَالِى</span> <span class="add">[app. meaning <em>Verily he is quick in the hind legs</em>]</span>. <span class="auth">(M.)</span> And the Arabs say, <span class="ar long">لَيْسَ هَوَادِى الخَيْلِ كَالتَّوَالِى</span>, i. e., <em>The necks of horses are not like their hinder parts.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">تَالٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="taAlK_A7">
					<p><span class="ar long">فَالتَّالَياتِ ذِكْرًا</span> <span class="add">[in the Ḳur xxxvii. 3]</span> means <em>And those</em> angels, or angels and others, <em>that recite</em> the <em>praise</em> of God. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutolK">
				<h3 class="entry"><span class="ar">مُتْلٍ</span></h3>
				<div class="sense" id="mutolK_A1">
					<p><span class="ar">مُتْلٍ</span> and <span class="ar">مُتْلِيَةٌ</span> <span class="auth">(T, M)</span> A mother, <span class="auth">(T,)</span> or a she-camel, and a female wild animal, <span class="auth">(M,)</span> <em>having her young one following her:</em> pl. <span class="ar">مَتَالٍ</span>. <span class="auth">(T, M.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلو</span> - Entry: <span class="ar">مُتْلٍ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutolK_A2">
					<p>Also, both sings., A she-camel <em>that brings forth in the last portion of the breeding-time:</em> or the latter sing. signifies one <em>that is late in bringing forth;</em> and the former sing. has the first of the meanings explained in this paragraph: <span class="auth">(M:)</span> or, as some say, the latter sing. signifies one <em>that has become heavy by pregnancy, so that the head of her fœtus has turned towards the tail and the vulva;</em> a meaning not agreeing with the derivation: <span class="auth">(IJ, M:)</span> or, as some say, this word signifies <span class="add">[simply]</span> <em>pregnant:</em> <span class="auth">(Ḥam p. 688:)</span> accord. to El-Báhilee, the pl. signifies she-camels <em>of which some have brought forth, and others have not.</em> <span class="auth">(TA.)</span> You say, <span class="ar long">إِبِلُهُمْ مَتَالٍ</span>, meaning <em>Their camels have not brought forth until the season called the</em> <span class="ar">صَيْف</span>, <span class="auth">(Ḳ, TA,)</span> which is the last part of the breeding-time. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaAlK">
				<h3 class="entry"><span class="ar">مُتَالٍ</span></h3>
				<div class="sense" id="mutaAlK_A1">
					<p><span class="ar">مُتَالٍ</span> One <em>who relieves,</em> or <em>aids, another, in singing,</em> and <em>in work, by taking up the strain,</em> or <em>the work, when the latter is unable to continue it:</em> <span class="auth">(IAạr, T:)</span> or one <em>who so relieves,</em> or <em>aids, the singer, with a high voice:</em> <span class="auth">(Ṣ, TA:)</span> and one <em>who sings to camels to urge them on,</em> or <em>excite them.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="musotatolK">
				<span class="pb" id="Page_0315"></span>
				<h3 class="entry"><span class="ar">مُسْتَتْلٍ</span></h3>
				<div class="sense" id="musotatolK_A1">
					<p><span class="ar">مُسْتَتْلٍ</span> <span class="add">[act. part. n. of 10, q. v. It is said in the T to have a signification derived from <span class="ar">تَلَآءٌ</span> in the last of the senses assigned to the latter word above; so that it seems to mean <em>Seeking,</em> or <em>demanding, the transfer of a debt,</em> or <em>claim,</em> or <em>the like, by shifting the responsibility from one person to another</em>]</span>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0313.pdf" target="pdf">
							<span>Lanes Lexicon Page 313</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0314.pdf" target="pdf">
							<span>Lanes Lexicon Page 314</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0315.pdf" target="pdf">
							<span>Lanes Lexicon Page 315</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
