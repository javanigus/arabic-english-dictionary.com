<article class="root" id="Root_tE">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/043_tXryn">تشرين</a></span>
				<span class="ar">تع</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/045_tEb">تعب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tE_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">تعتع</span></h3>
				<div class="sense" id="tE_RQ1_A1">
					<p><span class="ar long">تَعْتَعَ فِى الكَلَامِ</span>, <span class="auth">(Mgh, Ḳ,)</span> inf. n. <span class="ar">تَعْتَعَةٌ</span>, <span class="auth">(Ṣ, Mgh,)</span> <em>He reiterated in speech, by reason of an impediment,</em> or <em>inability to say what he would;</em> <span class="auth">(Ṣ, Mgh, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَتَعْتَعَ↓</span></span>: <span class="auth">(Ḳ:)</span> and <em>he was unable to say what he would,</em> or <em>to find words to express what he would say:</em> <span class="auth">(El-Ghooree, Mgh:)</span> <span class="ar">تَعْتَعَةٌ</span> is the <em>speech of him who is termed</em> <span class="ar">أَلْثَغ</span>. <span class="auth">(TA.)</span> And <span class="ar long">تعتع فِى القُرْآنِ</span> <em>He reiterated in reciting the Ḳur-án, and his tongue stuck fast in his doing so.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تع</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tE_RQ1_A2">
					<p><span class="ar long">تَعْتَعَتِ الدَّابَّةُ</span>, <span class="auth">(Ḳ,)</span> inf. n. as above, <span class="auth">(Ṣ,)</span> <em>The beast stuck fast</em> in the sand, <span class="auth">(Ṣ, Ḳ,)</span> or soft soil, <span class="auth">(Ṣ,)</span> or mire: <span class="auth">(TA:)</span> sometimes the verb is thus used. <span class="auth">(Ṣ.)</span> And <span class="ar">تعتع</span> said of a camel, &amp;c. signifies <em>His feet sank</em> into the soft soil, or soft sands. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تع</span> - Entry: R. Q. 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tE_RQ1_B1">
					<p><span class="ar">تَعْتَعَهُ</span> <em>He dragged him</em> <span class="auth">(namely another man)</span> <em>roughly,</em> or <em>vehemently, and agitated him:</em> <span class="auth">(Ṣ:)</span> or <em>he shook him,</em> or <em>shook him vehemently,</em> <span class="auth">(AA, Ḳ,)</span> <em>backwards and forwards, and treated him roughly:</em> <span class="auth">(AA:)</span> <em>he shook him roughly:</em> <span class="auth">(IDrd, Ḳ:)</span> or <em>he compelled him against his will, in an affair, so that he became disquieted, or agitated.</em> <span class="auth">(IF, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تع</span> - Entry: R. Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tE_RQ1_B2">
					<p><span class="ar long">تُعْتِعَ فُلَانٌ</span> <em>Such a one had his saying rebutted, rejected,</em> or <em>repudiated, as wrong,</em> or <em>erroneous.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tE_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تتعتع</span></h3>
				<div class="sense" id="tE_RQ2_A1">
					<p><span class="ar">تَتَعْتَعَ</span>: <a href="#tE_RQ1">see R. Q. 1</a>, first signification.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taEotaEN">
				<h3 class="entry"><span class="ar">تَعْتَعٌ</span></h3>
				<div class="sense" id="taEotaEN_A1">
					<p><span class="ar">تَعْتَعٌ</span> <em>i. q.</em> <span class="ar">فَأْفَآءٌ</span> or <span class="ar">فَأْفَأٌ</span> <span class="add">[accord. to different MSS., as meaning One <em>who reiterates his words much in speaking</em>]</span>. <span class="auth">(AA, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taEaAtiEa">
				<h3 class="entry"><span class="ar">تَعَاتِعَ</span></h3>
				<div class="sense" id="taEaAtiEa_A1">
					<p><span class="ar long">وَقَعُوا فِى تَعَاتِعَ</span>, <span class="add">[app. pl. of the inf. n. <span class="ar">تَعْتَعَةٌ</span>,]</span> <em>They fell into convulsing perplexities, arising from evil and discordant and false rumours or the like,</em> (<span class="ar long">فى أَرَاجِيفَ</span>, q. v.,) <em>and confusion.</em> <span class="auth">(AA, Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutaEotaEN">
				<h3 class="entry"><span class="ar">مُتَعْتَعٌ</span></h3>
				<div class="sense" id="mutaEotaEN_A1">
					<p><span class="ar">مُتَعْتَعٌ</span> <em>Afflicted by an injury which disquiets</em> or <em>agitates.</em> <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0307.pdf" target="pdf">
							<span>Lanes Lexicon Page 307</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
