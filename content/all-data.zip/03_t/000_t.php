<article class="root" id="Root_t">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=02_b/239_byh">بيه</a></span> 
				<span class="ar">ت</span>
				 <span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/001_tA">تا</a></span>
			</h2>
			<hr>
			<section class="entry main" id="t">
				<span class="pb" id="Page_0291"></span>
				<h3 class="entry"><span class="ar">ت</span></h3>
				<h4 class="entry">Arabic Letter <span class="ar">ت</span></h4>
				<div class="sense" id="t_A1">
					<p><em>The third letter of the alphabet:</em> called <span class="ar">تَآءٌ</span> and <span class="ar">تَا</span> <span class="add">[respecting which latter see the letter <span class="ar">ب</span>]</span>: the pl. <span class="add">[of the former is <span class="ar">تَآءَاتٌ</span>; and of the latter,]</span> <span class="ar">أَتْوَآءُ</span>. <span class="auth">(TA in <span class="ar long">باب الالف الليِنّة</span>.)</span> It is one of the letters termed <span class="ar">مَهْمُوسَة</span> <span class="add">[or non-vocal, i. e. pronounced with the breath only, without the voice]</span>, and of those termed <span class="ar">نِطَعِيَّة</span> <span class="add">[and <span class="ar">نِطْعِيَّة</span> and <span class="ar">نَطَعِيَّة</span> and <span class="ar">نَطْعِيَّة</span> pronounced by pressing the tip of the tongue against the upper gums and suddenly withdrawing it with an emission of the breath]</span>: these latter are <span class="ar">ط</span> and <span class="ar">د</span> and <span class="ar">ت</span>, three letters that are among those which are changed into other letters. <span class="auth">(TA at the commencement of <span class="ar long">باب التآء</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="t_B1">
					<p>It is one of the augmentative letters: <span class="auth">(Ṣ:)</span> and is movent when added at the beginning of a noun, and at the end of a noun, <span class="add">[and at the beginning of a verb,]</span> and at the end of a verb, and is also quiescent at the end of a verb. <span class="auth">(Mughnee, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="t_C1">
					<p>Added at the beginning of a noun, it is a preposition, or particle governing the gen. case, significant of swearing, <span class="auth">(Ṣ,* Mughnee, Ḳ,)</span> and denoting wonder; <span class="auth">(Mughnee, Ḳ;)</span> and <span class="add">[accord. to general usage]</span> it is peculiarly prefixed to the name <span class="ar">ٱللّٰه</span>; <span class="auth">(Ṣ, Mughnee, Ḳ;)</span> as in <span class="ar long">تَٱللّٰهِ لَقَدْ كَانَ كَذَا</span> <span class="add">[<em>By God, verily it was thus,</em> or <em>verily such a thing was</em>]</span>; <span class="auth">(Ṣ;)</span> and <span class="ar long">تَٱللّٰهِ لَأَفْعَلَنَّ كَذَا</span> <span class="add">[<em>By God, I will assuredly do such a thing</em>]</span>: <span class="auth">(TA:)</span> but sometimes they said, <span class="ar">تَرَبِّى</span> <span class="add">[<em>By my Lord</em>]</span>, and <span class="ar long">تَرَبِّ الكَعْبَةِ</span> <span class="add">[<em>By the Lord of the Kaabeh</em>]</span>, and <span class="ar">تَٱلرَّحْمَانِ</span> <span class="add">[<em>By the Compassionate</em>]</span>, <span class="auth">(Mughnee, Ḳ,)</span> as is related on the authority of Akh; deviating from common usage. <span class="auth">(TA.)</span> Thus used, it is a substitute for <span class="ar">و</span>, <span class="auth">(Ṣ, Mughnee,)</span> as it is also in <span class="ar">تَتْرَى</span> and <span class="ar">تُرَاثٌ</span> and <span class="ar">تُجَاهَ</span> and <span class="ar">تُخَمَةٌ</span> <span class="add">[&amp;c.]</span>; <span class="auth">(Ṣ;)</span> and the <span class="ar">و</span> is a substitute for <span class="ar">ب</span>; <span class="auth">(Ṣ, Mughnee;)</span> but the <span class="ar">ت</span> has the additional meaning of denoting wonder: so says Z. <span class="auth">(Mughnee.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: D</span>
				</div>
				<div class="sense" id="t_D1">
					<p>Added at the end of a noun, it is a particle of allocution: <span class="auth">(Mughnee, Ḳ:)</span> it is thus added in <span class="ar">أَنْتَ</span> <span class="add">[<em>Thou</em>]</span>, <span class="auth">(Ṣ, Mughnee, Ḳ,)</span> addressed to a male, <span class="auth">(TA,)</span> and <span class="ar">أَنْتِ</span> <span class="add">[<em>Thou</em>]</span>, <span class="auth">(Mughnee, Ḳ,)</span> addressed to a female; <span class="auth">(TA;)</span> uniting with the noun, as though the two became one; not being an affixed noun governed in the gen. case. <span class="auth">(Ṣ. <span class="add">[<a href="#Oano">See <span class="ar">أَنْ</span></a>.]</span>)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: E</span>
				</div>
				<div class="sense" id="t_E1">
					<p>It is added in <span class="add">[the beginning of]</span> the second person of the future, <span class="auth">(Ṣ,)</span> <span class="add">[i. e.,]</span> in the beginning of the aor., <span class="auth">(TA,)</span> <span class="add">[as a particle of allocution,]</span> as in <span class="ar long">أَنْتَ تَفْعَلُ</span> <span class="add">[<em>Thou dost,</em> or <em>wilt do</em>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E2</span>
				</div>
				<div class="sense" id="t_E2">
					<p>It is also added, as a sign of the fem. gender, in the beginning of the future, <span class="add">[or aor.,]</span> as in <span class="ar long">هِىَ تَفْعَلُ</span> <span class="add">[<em>She does,</em> or <em>will do</em>]</span>. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E3</span>
				</div>
				<div class="sense" id="t_E3">
					<p>It is also added in the beginning of the third person <span class="add">[fem.]</span> of the <span class="add">[aor. used as an]</span> imperative, <span class="add">[as a sign of the fem. gender,]</span> as in <span class="ar long">لِتَقُمْ هِنْدُ</span> <span class="add">[<em>Let Hind stand</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: E4</span>
				</div>
				<div class="sense" id="t_E4">
					<p>And sometimes it is added in the beginning of the second person of the <span class="add">[aor. used as an]</span> imperative, <span class="add">[as a particle of allocution,]</span> as in the phrase in the Ḳur <span class="add">[x. 59, accord. to one reading]</span>, <span class="ar long">فَبِذٰلِكَ فَلْتَفْرَحُوا</span> <span class="add">[<em>Therefore therein rejoice ye</em>]</span>: and in the saying of the rájiz,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قُلْتُ لِبَوَّابٍ لَدَيْهِ دَارُهَا</span> *</div> 
						<div class="star">* <span class="ar long">تِئْذَنْ فَإِنِّى حَمْؤُهَا وَجَارُهَا</span> *</div> 
					</blockquote>
					<p><span class="add">[<a href="index.php?data=01_A/047_Acn">explained in art.<span class="ar">اذن</span></a>]</span>: and <span class="add">[thus]</span> it is added in the beginning of <span class="add">[the second person of]</span> the <span class="add">[aor. used as an]</span> imperative of a verb of which the agent is not named, as in <span class="ar long">لِتُزْهَ يَا رَجُلُ</span> <span class="add">[<em>Be thou proud, vain, boastful,</em> or <em>self-conceited, O man</em>]</span>, from <span class="ar">زُهِىَ</span>: but Akh says that the adding of the <span class="ar">ل</span> in the beginning of the second person of the <span class="add">[aor. used as an]</span> imperative <span class="add">[except in the case of a pass. verb or a verb of which the agent is not named]</span> is a bad idiom, because the <span class="ar">ل</span> is not needed. <span class="auth">(Ṣ, TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: F</span>
				</div>
				<div class="sense" id="t_F1">
					<p>The movent <span class="ar">ت</span> added at the end of a verb is a pronoun, as in <span class="ar">قُمْتُ</span> <span class="add">[<em>I stood</em>]</span>, <span class="auth">(Mughnee, Ḳ,)</span> and <span class="ar">قُمْتَ</span> <span class="add">[<em>Thou stoodest,</em> addressed to a male]</span>, and <span class="ar">قُمْتِ</span> <span class="add">[<em>Thou stoodest, addressed to a female</em>]</span>: <span class="auth">(Mughnee:)</span> thus added in the first and second persons of the pret., it is a pronoun denoting the agent. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: F2</span>
				</div>
				<div class="sense" id="t_F2">
					<p>The quiescent <span class="ar">ت</span> added at the end of a verb is a sign of the fem. gender, <span class="auth">(Mughnee, Ḳ,)</span> i. e., a particle applied to denote the fem. gender, <span class="auth">(Mughnee,)</span> as in <span class="ar">قَامَتْ</span> <span class="add">[<em>She stood</em>]</span>. <span class="auth">(Mughnee, Ḳ.)</span> J says <span class="add">[in the Ṣ]</span> that, when thus added at the end of the pret., it is a pronoun: but IB says <span class="add">[correctly]</span> that it is a particle. <span class="auth">(TA.)</span></p>
				</div>
						<span type="dis">＝</span>
				<div class="sense" id="t_g1">
					<p>It is also, sometimes, affixed to <span class="ar">ثُمَّ</span> and <span class="ar">رُبَّ</span>; and in these cases it is most commonly movent with fet-ḥ, <span class="auth">(Mughnee, Ḳ,)</span> so that one says <span class="ar">ثُمَّتَ</span> and <span class="ar">رُبَّتَ</span>. <span class="auth">(TA.)</span> <span class="add">[See arts. <span class="ar">ثم</span> and <span class="ar">رب</span>.]</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: H</span>
				</div>
				<div class="sense" id="t_H1">
					<p><span class="ar">تِ</span> is an imperative of <span class="ar">أَتَى</span>. <span class="auth">(M in art. <span class="ar">اتى</span>.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ت</span> - Entry: <span class="ar">ت</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: I</span>
				</div>
				<div class="sense" id="t_I1">
					<p><span class="add">[As a numeral, <span class="ar">ت</span> denotes <em>Four hundred.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0291.pdf" target="pdf">
							<span>Lanes Lexicon Page 291</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
