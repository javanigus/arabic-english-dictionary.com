<article class="root" id="Root_tfrq">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/048_tfH">تفح</a></span>
				<span class="ar">تفرق</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/050_tfl">تفل</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tuforuwqN">
				<h3 class="entry"><span class="ar">تُفْرُوقٌ</span></h3>
				<div class="sense" id="tuforuwqN_A1">
					<p><span class="ar">تُفْرُوقٌ</span> The <span class="ar">قِمَع</span> <span class="add">[or <em>base</em>]</span> <em>of a date;</em> <span class="auth">(Ibn-ʼAbbád, Ḳ;)</span> <a href="#vuforuwqN">a dial. var. of <span class="ar">ثُفْرُوقٌ</span> <span class="add">[q. v.]</span></a>: pl. <span class="ar">تَفَارِيقُ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0308.pdf" target="pdf">
							<span>Lanes Lexicon Page 308</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
