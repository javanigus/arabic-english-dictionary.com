<article class="root" id="Root_ttr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/012_tbw">تبو</a></span>
				<span class="ar">تتر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/014_tjr">تجر</a></span>
			</h2>
			<hr>
			<section class="entry main" id="AltBataru">
				<h3 class="entry"><span class="ar">التَّتَرُ</span></h3>
				<div class="sense" id="AltBataru_A1">
					<p><span class="ar">التَّتَرُ</span> <span class="add">[and <span class="ar">التَّتَارُ</span> and <span class="ar">التَاتَارُ</span>]</span> <em>A certain people,</em> or <em>nation,</em> <span class="auth">(Ḳ,)</span> <span class="add">[called by us <em>the Tartars,</em>]</span> <em>in the furthest countries of the East, in the mountains of</em> <span class="ar">طغماج</span>, <em>on the confines of China,</em> <span class="auth">(TA,)</span> <em>bordering upon the Turks,</em> <span class="auth">(Ḳ,)</span> <em>more than six months' journey from Má-waráä-n-nahr:</em> so in the Murooj edh-Dhahab. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tatorae">
				<h3 class="entry"><span class="ar">تَتْرَى</span> / <span class="ar">تَتْرًى</span></h3>
				<div class="sense" id="tatorae_A1">
					<p><span class="ar">تَتْرَى</span> and <span class="ar">تَتْرًى</span>: <a href="index.php?data=27_w/024_wtr">see art. <span class="ar">وتر</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0297.pdf" target="pdf">
							<span>Lanes Lexicon Page 297</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
