<article class="root" id="Root_tfl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/049_tfrq">تفرق</a></span>
				<span class="ar">تفل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/051_tfh">تفه</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tfl_1">
				<h3 class="entry">1. ⇒ <span class="ar">تفل</span></h3>
				<div class="sense" id="tfl_1_A1">
					<p><span class="ar">تَفَلَ</span>, <span class="add">[in the CK, erroneously, <span class="ar">تَفِلَ</span>,]</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْفِلُ</span>}</span></add> <span class="auth">(Ṣ, M, Mṣb, Ḳ)</span> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْفُلُ</span>}</span></add>, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> inf. n. <span class="ar">تَفْلٌ</span>, <span class="auth">(T, Ṣ, M, Mṣb,)</span> <em>He spat;</em> syn. <span class="ar">بَصَقَ</span>: <span class="auth">(M, Ḳ:)</span> <span class="add">[or rather, <em>he spat, emitting a small quantity of saliva,</em> generally <em>in scattered portions, as when one spits forth some minute thing:</em>]</span> <span class="ar">التَّفْلُ</span> is <em>similar to</em> <span class="ar">البَزْقُ</span>, <em>but less in degree:</em> <span class="auth">(Ṣ, Mṣb:*)</span> the first degree is <span class="ar">البَزْقُ</span>; then, <span class="ar">التَّفْلُ</span>; then, <span class="ar">النَّفْثُ</span>; and then, <span class="ar">النَّفْخُ</span>: <span class="auth">(Ṣ:)</span> <span class="ar">التَّفْلُ</span> with the mouth is <span class="add">[<em>an action</em>]</span> <em>never without somewhat of spittle:</em> a blowing without spittle is <span class="add">[said to be]</span> termed <span class="ar">نَفْثٌ</span>. <span class="auth">(T.)</span> Hence, <span class="ar long">تَفْلُ الرَّاقِى</span> <span class="add">[<em>The spitting of the charmer, in which he emits a small quantity of saliva at a time, in scattered portions:</em> <a href="#nafava">see also <span class="ar">نَفَثَ</span></a>]</span>. <span class="auth">(Ṣ.)</span> One says also, <span class="ar long">ذَاقَ مَآءَ البَحْرِ فَتَفَلَهُ</span>, i. e. <span class="add">[<em>He tasted the water of the sea, and</em>]</span> <em>spirted it forth,</em> by reason of dislike thereof. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تفل</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tfl_1_B1">
					<p><span class="ar">تَفِلَ</span>, <span class="auth">(M, Ḳ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْفَلُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَفَلٌ</span>, <span class="auth">(Ṣ, M, Mgh, Ḳ,)</span> <em>He,</em> or <em>it,</em> <span class="auth">(a thing, M,)</span> <em>became altered for the worse in odour, ill-smelling,</em> or <em>frouzy:</em> <span class="auth">(M, Ḳ:)</span> <em>he neglected,</em> or <em>left off the use of, perfume:</em> <span class="auth">(M:)</span> <em>he was unperfumed:</em> <span class="auth">(Ṣ:)</span> <em>he neglected,</em> or <em>left off the use of, perfume, and so became altered for the worse in odour, ill-smelling,</em> or <em>frouzy:</em> <span class="auth">(Mgh, TA:)</span> and <span class="ar">تَفِلَتْ</span>, aor. and inf. n. as above, <em>she</em> <span class="auth">(a woman)</span> <em>stank, by reason of having neglected,</em> or <em>left off the use of, perfume and ointments:</em> and also <em>she perfumed herself:</em> thus bearing two contr. significations. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tfl_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتفل</span></h3>
				<div class="sense" id="tfl_4_A1">
					<p><span class="ar">اتفلهُ</span> <em>He,</em> or <em>it, made him,</em> or <em>it, to be altered for the worse in odour, ill-smelling,</em> or <em>frouzy,</em> <span class="auth">(Ḳ,)</span> or <em>unperfumed.</em> <span class="auth">(Ṣ.)</span> The rájiz says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">وَتُتْفِلُ العَنْبَرَ وَالصِّوَارَ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>And she makes ambergris and musk,</em> or <em>the vesicle of musk, to have a bad odour,</em> or <em>to lose their fragrance</em>]</span>. <span class="auth">(Ṣ.)</span> And it is said of the sun, <span class="ar long">تُتْفِلُ الرِّيحَ</span> <span class="add">[<em>It makes the odour</em> of the person <em>to be bad</em>]</span>. <span class="auth">(TA, from a trad.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tafolN">
				<h3 class="entry"><span class="ar">تَفْلٌ</span></h3>
				<div class="sense" id="tafolN_A1">
					<p><span class="ar">تَفْلٌ</span>: <a href="#tufolN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tufolN">
				<h3 class="entry"><span class="ar">تُفْلٌ</span></h3>
				<div class="sense" id="tufolN_A1">
					<p><span class="ar">تُفْلٌ</span>, <span class="auth">(Ḳ,)</span> or<span class="arrow"><span class="ar">تَفْلٌ↓</span></span>, <span class="auth">(M, accord. to the TT,)</span> and<span class="arrow"><span class="ar">تُفَالٌ↓</span></span>, <span class="auth">(M, Ḳ,)</span> vulgarly <span class="arrow"><span class="ar">تِفْلٌ↓</span></span> and<span class="arrow"><span class="ar">تِفَالٌ↓</span></span>, <span class="auth">(TA,)</span> <em>Spittle,</em> or <em>saliva, ejected from the mouth;</em> syn. <span class="ar">بُصَاقٌ</span>; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">تَفَلٌ↓</span></span>: <span class="auth">(Ibn-Abi-l- Hadeed, TA:)</span> or it is <em>similar to</em> <span class="ar">بُصَاق</span>. <span class="auth">(TA.)</span> <span class="add">[<a href="#tfl_1">See 1</a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفل</span> - Entry: <span class="ar">تُفْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tufolN_A2">
					<p>And <em>Froth,</em> or <em>foam,</em> <span class="auth">(M, Ḳ,)</span> of the sea; <span class="auth">(TA;)</span> and <em>the like thereof.</em> <span class="auth">(M.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry main" id="tifolN">
				<span class="pb" id="Page_0309"></span>
				<h3 class="entry"><span class="ar">تِفْلٌ</span></h3>
				<div class="sense" id="tifolN_A1">
					<p><span class="ar">تِفْلٌ</span>: <a href="#tufolN">see <span class="ar">تُفْلٌ</span></a>.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفل</span> - Entry: <span class="ar">تِفْلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tifolN_A2">
					<p><span class="ar long">مَا أَصَابَ فُلَانٌ مِنْ فُلَانٍ إِلَّا تِفْلًا طَفِيفًا</span> <em>Such a one obtained not from such a one save a little.</em> <span class="auth">(T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tafalN">
				<h3 class="entry"><span class="ar">تَفَلٌ</span></h3>
				<div class="sense" id="tafalN_A1">
					<p><span class="ar">تَفَلٌ</span>: <a href="#tufolN">see <span class="ar">تُفْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tafilN">
				<h3 class="entry"><span class="ar">تَفِلٌ</span></h3>
				<div class="sense" id="tafilN_A1">
					<p><span class="ar">تَفِلٌ</span>, applied to a man; <span class="auth">(Ṣ, M, Ḳ;)</span> and <span class="ar">تَفِلَةٌ</span>, applied to a woman, <span class="auth">(T, M, Mgh, Mṣb, Ḳ,)</span> as also<span class="arrow"><span class="ar">مِتْفَالٌ↓</span></span>, <span class="auth">(T, Ṣ, M, Mṣb, Ḳ,)</span> which is a possessive epithet, <span class="auth">(M,)</span> or an intensive epithet, <span class="auth">(Mṣb,)</span> <em>Altered for the worse in odour, ill-smelling,</em> or <em>frouzy:</em> <span class="auth">(M, Ḳ:)</span> <em>who has neglected,</em> or <em>left off the use of, perfume:</em> <span class="auth">(M:)</span> <em>unperfumed:</em> <span class="auth">(T, Ṣ:)</span> <em>who has neglected,</em> or <em>left off the use of, perfume, and so become altered for the worse in odour, illsmelling,</em> or <em>frouzy:</em> <span class="auth">(Mgh, TA:)</span> <em>stinking,</em> <span class="auth">(T, Mṣb,)</span> <em>by reason of having neglected,</em> or <em>left off the use of, perfume and ointments:</em> <span class="auth">(Mṣb:)</span> <a href="#tafilapN">the pl. of <span class="ar">تَفِلَةٌ</span></a> is <span class="ar">تَفِلَاتٌ</span>; <span class="auth">(T, Mgh, Mṣb;)</span> applied to such women as are not to be prevented from going to the mosque, and in this case meaning <em>unperfumed.</em> <span class="auth">(T,* Mgh,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تفل</span> - Entry: <span class="ar">تَفِلٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tafilN_A2">
					<p><span class="ar long">قَوْمٌ سَفِلَةٌ تَفِلَةٌ</span> <span class="add">[<em>A company of men of the lowest and vilest sort</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tufaAlN">
				<h3 class="entry"><span class="ar">تُفَالٌ</span> / <span class="ar">تِفَالٌ</span></h3>
				<div class="sense" id="tufaAlN_A1">
					<p><span class="ar">تُفَالٌ</span> and <span class="ar">تِفَالٌ</span>: <a href="#tufolN">see <span class="ar">تُفْلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutofilapN">
				<h3 class="entry"><span class="ar">مُتْفِلَةٌ</span></h3>
				<div class="sense" id="mutofilapN_A1">
					<p><span class="ar long">الشَّمْسُ مُتْفِلَةٌ</span> <span class="add">[<em>The sun makes the odour of the person to be bad</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mitofalapN">
				<h3 class="entry"><span class="ar">مِتْفَلَةٌ</span></h3>
				<div class="sense" id="mitofalapN_A1">
					<p><span class="ar">مِتْفَلَةٌ</span> <em>A spittoon,</em> or <em>vessel in which to spit;</em> syn. <span class="ar">مِبْزَقَةٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="mitofaAlN">
				<h3 class="entry"><span class="ar">مِتْفَالٌ</span></h3>
				<div class="sense" id="mitofaAlN_A1">
					<p><span class="ar">مِتْفَالٌ</span>: <a href="#tafilN">see <span class="ar">تَفِلٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0308.pdf" target="pdf">
							<span>Lanes Lexicon Page 308</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0309.pdf" target="pdf">
							<span>Lanes Lexicon Page 309</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
