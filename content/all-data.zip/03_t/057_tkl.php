<article class="root" id="Root_tkl">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/056_tkO">تكأ</a></span>
				<span class="ar">تكل</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/058_tl">تل</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">تكل</span></h4>
			<hr>
			<section class="entry main" id="tkl_1">
				<h3 class="entry">1. ⇒ <span class="ar">تكل</span></h3>
				<div class="sense" id="tkl_1_A1">
					<p><span class="ar long">تَكِلَ عَلَيْهِ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْكَلُ</span>}</span></add> <a href="#IitBakala">a dial. var. of <span class="ar">اِتَّكَلَ</span></a>. <span class="auth">(Ibn-ʼAbbád, Ḳ)</span> <a href="index.php?data=27_w/203_wkl">See art. <span class="ar">وكل</span></a>; where, also, <a href="#tukalapN">see <span class="ar">تُكَلَةٌ</span></a>, &amp;c.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0310.pdf" target="pdf">
							<span>Lanes Lexicon Page 310</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
