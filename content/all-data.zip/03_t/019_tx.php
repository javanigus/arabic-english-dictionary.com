<article class="root" id="Root_tx">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/018_tHyn">تحين</a></span>
				<span class="ar">تخ</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/020_txt">تخت</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tx_1">
				<h3 class="entry">1. ⇒ <span class="ar">تخّ</span></h3>
				<div class="sense" id="tx_1_A1">
					<p><span class="ar">تَخَّ</span>, <span class="auth">(JK, Ṣ, L, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْخِخُ</span>}</span></add>, <span class="auth">(JK, L,)</span> inf. n. <span class="ar">تُخُوخٌ</span>, <span class="auth">(JK, L, and so in a copy of the Ṣ,)</span> or <span class="ar">تُخُوخَةٌ</span>, <span class="auth">(Ḳ, and so in a copy of the Ṣ,)</span> or both, <span class="auth">(TA,)</span> <em>It</em> <span class="auth">(dough)</span> <em>became sour:</em> <span class="auth">(JK, Ṣ, L, Ḳ:)</span> <em>it became soft by reason of too much water:</em> and in like manner, clay, or mud, <em>so that one could not plaster with it.</em> <span class="auth">(L.)</span> Also, said of dough, <em>It became leavened;</em> or <em>mature.</em> <span class="auth">(JK.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tx_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتخّ</span></h3>
				<div class="sense" id="tx_4_A1">
					<p><span class="ar">اتخّهُ</span> <em>He made it sour;</em> namely, dough: <span class="auth">(JK, Ṣ, L, Ḳ:)</span> <em>he made it soft by putting into it too much water;</em> namely, dough: and in like manner, clay, or mud, <em>so that he could not plaster with it.</em> <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taxBN">
				<h3 class="entry"><span class="ar">تَخٌّ</span></h3>
				<div class="sense" id="taxBN_A1">
					<p><span class="ar">تَخٌّ</span> <em>Sour dough:</em> <span class="auth">(JK, Ṣ, A, L, Ḳ:)</span> <em>such as is soft by reason of too much water.</em> <span class="auth">(L.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تخ</span> - Entry: <span class="ar">تَخٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taxBN_A2">
					<p>Also <em>Dregs of sesame-grain from which the oil has been expressed;</em> <span class="auth">(JK, L, Ḳ;)</span> <em>also called</em> <span class="ar">كُسْبٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAxBN">
				<h3 class="entry"><span class="ar">تَاخٌّ</span></h3>
				<div class="sense" id="taAxBN_A1">
					<p><span class="ar">تَاخٌّ</span> <em>Having no desire for food</em> <span class="add">[app. <em>by reason of acidity in the stomach</em>]</span>. <span class="auth">(JK, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
