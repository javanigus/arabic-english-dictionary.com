<article class="root" id="Root_tHyn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/017_tHf">تحف</a></span>
				<span class="ar">تحين</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/019_tx">تخ</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="taHiyna">
				<h3 class="entry"><span class="ar">تَحِينَ</span></h3>
				<div class="sense" id="taHiyna_A1">
					<p><span class="ar">تَحِينَ</span>: <a href="index.php?data=06_H/244_Hyn">see arts. <span class="ar">حين</span></a> <a href="index.php?data=23_l/187_lyt">and <span class="ar">ليت</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
