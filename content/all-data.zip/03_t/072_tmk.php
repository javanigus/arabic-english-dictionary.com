<article class="root" id="Root_tmk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/071_tmr">تمر</a></span>
				<span class="ar">تمك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/073_tmwz">تموز</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tmk_1">
				<h3 class="entry">1. ⇒ <span class="ar">تمك</span></h3>
				<div class="sense" id="tmk_1_A1">
					<p><span class="ar">تَمَكَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْمُكُ</span>}</span></add> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْمِكُ</span>}</span></add>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَمُكٌ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">تُمُوكٌ</span>, <span class="auth">(Ḳ,)</span> <em>It</em> <span class="auth">(a camel's hump)</span> <em>was,</em> or <em>became, tall,</em> or <em>long and high:</em> <span class="auth">(Ṣ, Ḳ:)</span> <em>it was,</em> or <em>became, juicy, and compact,</em> <span class="auth">(O, Ḳ,)</span> <em>and plump.</em> <span class="auth">(M, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tmk_1_A2">
					<p><span class="add">[Hence,]</span> <span class="ar long">تَمَكَ فِيهِ الحُسْنُ</span> <span class="add">[app. † <em>Beauty became fully developed,</em> or <em>consummate, in him</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tmk_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتمك</span></h3>
				<div class="sense" id="tmk_4_A1">
					<p><span class="ar long">اتمك سَنَامَهُ</span> <span class="add">[<em>It made his</em> <span class="auth">(a camel's)</span> <em>hump to become tall,</em> or <em>long and high,</em> or <em>juicy and compact, and plump</em>]</span>; said of the <span class="add">[herbage called]</span> <span class="ar">رَبِيع</span>. <span class="auth">(A, TA.)</span> And <span class="ar long">اتمك النَّاقَةَ</span> <em>It</em> <span class="auth">(herbage)</span> <em>made the she-camel fat.</em> <span class="auth">(IDrd, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taAmikN">
				<h3 class="entry"><span class="ar">تَامِكٌ</span></h3>
				<div class="sense" id="taAmikN_A1">
					<p><span class="ar">تَامِكٌ</span>, applied to a camel's hump, <em>Tall,</em> or <em>long and high:</em> <span class="auth">(Ṣ, TA:)</span> or <em>high:</em> or <em>juicy, and compact, and plump:</em> <span class="auth">(TA:)</span> or <em>a camel's hump, in whatever state it be.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمك</span> - Entry: <span class="ar">تَامِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taAmikN_A2">
					<p>A she-camel <em>having a large hump:</em> <span class="auth">(ISd, Ḳ:)</span> pl. <span class="ar">تَوَامِكُ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمك</span> - Entry: <span class="ar">تَامِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taAmikN_A3">
					<p>A <em>high,</em> or <em>lofty,</em> building. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمك</span> - Entry: <span class="ar">تَامِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taAmikN_A4">
					<p>You say also, <span class="ar long">إِنَّهُ لَتَامِكُ الجَمَالِ</span> <span class="add">[app. meaning † <em>Verily he is a person of fully-developed,</em> or <em>consummate, beauty</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تمك</span> - Entry: <span class="ar">تَامِكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="taAmikN_A5">
					<p>And <span class="ar long">شَرَفُكَ تَامِكٌ وَإِقْبَالُكَ سَامِكٌ</span> ‡ <span class="add">[<em>Thy nobility is lofty, and thy good fortune is high</em>]</span>. <span class="auth">(A, TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0317.pdf" target="pdf">
							<span>Lanes Lexicon Page 317</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
