<article class="root" id="Root_tA">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/000_t">ت</a></span>
				<span class="ar">تا</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/002_tO">تأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="taA">
				<h3 class="entry"><span class="ar">تَا</span></h3>
				<div class="sense" id="taA_A1">
					<p><span class="ar">تَا</span> <a href="#caA">fem. of <span class="ar">ذَا</span></a>; <span class="auth">(M;)</span> <em>i. q.</em> <span class="ar">ذِهْ</span> <span class="add">[<em>This and that</em>]</span>; <span class="auth">(T;)</span> a noun of indication, denoting that which is female or feminine; like <span class="ar">ذَا</span> <span class="auth">(Ṣ, Ḳ)</span> applied to that which is male or masculine; <span class="auth">(Ṣ;)</span> and you say also <span class="ar">تِهْ</span>, like <span class="ar">ذِهْ</span>: <span class="auth">(Ṣ, Ḳ:)</span> the dual is <span class="ar">تَانِ</span>: and the pl., <span class="ar">أُولَآءِ</span>. <span class="auth">(Ṣ, Ḳ.)</span> En-Nábighah <span class="add">[Edh-Dhubyánee]</span> says, <span class="auth">(T, Ṣ,)</span> excusing himself to En-Noamán <span class="add">[Aboo-Káboos]</span>, whom he had satirized, <span class="auth">(TA,)</span></p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">هَا إِنَّ تَا عِذْرَةٌ إِنْ لَمْ تَكُنْ نَفَعَتْ</span> *</div> 
						<div class="star">* <span class="ar long">فَإِنَّ صَاحِبَهَا قَدْ تَاهَ فِى البَلَدِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Now verily this is an excuse: if it profit not, then verily its author has lost his way in the desert, or in the waterless desert</em>]</span>: <span class="auth">(T, Ṣ: but in the latter, <span class="ar">لا</span> is put in the place of <span class="ar">لم</span>:)</span> <span class="ar">تا</span> here points to the <span class="ar">قَصِيدَة</span> <span class="add">[or ode]</span>; and <span class="ar">عذرة</span> is a subst from <span class="ar">اِعْتِذَارٌ</span>; and <span class="ar">تاه</span> means <span class="ar">تَحَيَّرَ</span>; and <span class="ar">البلد</span> means <span class="ar">المَفَازَة</span>. <span class="auth">(TA.)</span> <a href="#taA">The dim. of <span class="ar">تَا</span></a> is <span class="ar">تَيَّا</span>, <span class="auth">(T, Ṣ, M, Ḳ,)</span> which is anomalous, like <span class="ar">ذَيَّا</span> <a href="#caA">the dim. of <span class="ar">ذَا</span></a>, &amp;c. <span class="auth">(I’Aḳ p. 343.)</span> <span class="add">[Much has been written respecting the formation of this dim. to reduce it to something like rule, but I pass it over as, in my opinion, unprofitable and unsatisfactory; <a href="#OulayBaA">and only refer to what is said respecting the duals <span class="ar">أُلَيَّا</span></a> <a href="#OulayBaACi">and <span class="ar">أُلَيَّآءِ</span></a> <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>. <a href="#mirBapN">See an ex. voce <span class="ar">مِرَّةٌ</span></a>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تا</span> - Entry: <span class="ar">تَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taA_A2">
					<p><span class="ar">هَا</span> is prefixed to it <span class="auth">(T, Ṣ, Ḳ)</span> <span class="add">[as an inceptive particle]</span> to give notice of what is about to be said, <span class="auth">(Ṣ,)</span> so that one says <span class="ar">هَاتَا</span> <span class="add">[meaning <em>This</em>]</span>, <span class="auth">(T, Ṣ, Ḳ,)</span> as in <span class="ar long">هَاتَا فُلَانَةُ</span> <span class="add">[<em>This is such a woman</em>]</span>; <span class="auth">(T;)</span> and <span class="add">[in the dual]</span> <span class="ar">هَاتَانِ</span>; and <span class="add">[in the pl.]</span> <span class="ar">هٰؤُلَآءِ</span>: and the dim. is <span class="ar">هَاتَيَّا</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تا</span> - Entry: <span class="ar">تَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taA_A3">
					<p>When you use it in addressing another person, you add to it <span class="ar">ك</span> <span class="add">[as a particle of allocution]</span>, and say <span class="ar">تَاكَ</span> <span class="auth">(Ṣ, Ḳ)</span> and <span class="ar">تِيكَ</span> and <span class="ar">تِلْكَ</span> <span class="auth">(T, Ṣ, Ḳ)</span> and <span class="ar">تَلْكَ</span>, which is a bad dial. var., <span class="auth">(Ṣ, Ḳ,)</span> and <span class="ar">تَالِكَ</span>, <span class="auth">(T, Ṣ,)</span> which is the worst of these: <span class="auth">(T:)</span> <span class="add">[all meaning <em>That:</em>]</span> the dual is <span class="ar">تَانِكَ</span> and <span class="ar">تَانِّكَ</span>, the latter with teshdeed, <span class="auth">(Ṣ, Ḳ, <span class="add">[but in some copies of the Ṣ, only the latter is mentioned,]</span>)</span> and <span class="ar">تَالِكَ</span> <span class="add">[which, like <span class="ar">تَانِّكَ</span>, is dual of <span class="ar">تِلْكَ</span> or <span class="ar">تَلْكَ</span>, which are contractions of <span class="ar">تَالِكَ</span>; these two duals being for <span class="ar">تَانِلِكَ</span>, the original, but unused, form]</span>: <span class="auth">(Ḳ:)</span> the pl. is <span class="ar">أُولٰئِكَ</span> <span class="add">[or <span class="ar">أُولَآئِكَ</span>]</span> and <span class="ar">أُولَاكَ</span> and <span class="ar">أُولَالِكَ</span> <span class="add">[respecting all of which <a href="#Oulae">see <span class="ar">أُلَى</span></a>, <a href="index.php?data=01_A/127_Ale">in art. <span class="ar">الى</span></a>]</span>: <span class="auth">(Ṣ, Ḳ:)</span> and the dim. is <span class="ar">تَيَّاكَ</span> and <span class="ar">تَيَّالِكَ</span>: <span class="auth">(Ḳ: <span class="add">[in the TA, the latter is erroneously written <span class="ar">تَيّانِكَ</span>:]</span>)</span> the <span class="ar">ك</span> relates to the person or persons whom you address, masc. and fem. and dual and pl.: <span class="add">[but in addressing a female, you may say <span class="ar">تَاكِ</span>, &amp;c.; in addressing two persons, <span class="ar">تَاكُمَا</span>, &amp;c.; in addressing more than two males, <span class="ar">تَاكُمْ</span>, &amp;c.; and in addressing more than two females, <span class="ar">تَاكُنَّ</span>, &amp;c.:]</span> what precedes the <span class="ar">ك</span> relates to the person <span class="add">[or thing]</span> indicated, masc. and fem. and dual and pl. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تا</span> - Entry: <span class="ar">تَا</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="taA_A4">
					<p><span class="ar">هَا</span> is also prefixed to <span class="ar">تِيكَ</span> and <span class="ar">تَاكَ</span>, so that one says, <span class="ar long">هَاتِيكَ هِنْدُ</span> and <span class="ar long">هَاتَاكَ هِنْدُ</span> <span class="add">[<em>This,</em> or <em>that, is Hind</em>]</span>. <span class="auth">(Ṣ, Ḳ.*)</span> Abu-n-Nejm says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">جِئْنَا نُحَيِّيكَ وَنَسْتَجْدِيكَا</span> *</div> 
						<div class="star">* <span class="ar long">فَٱفْعَلْ بِنَا هَاتَاكَ أَوْ هَاتِيكَا</span> *</div> 
					</blockquote>
					<p>meaning <span class="add">[<em>We have come saluting thee and seeking of thee a gift: then do thou to us</em>]</span> <em>this or that:</em> <span class="add">[give us]</span> a salutation or a gift. <span class="auth">(Ṣ.)</span> The <span class="ar">هَا</span> that is used to give notice of what is about to be said is not prefixed to <span class="ar">تلك</span> because the <span class="ar">ل</span> is made a substitute for that <span class="ar">ها</span>: <span class="auth">(Ṣ, TA:)</span> or, as IB says, they do not prefix that <span class="ar">ها</span> to <span class="ar">ذٰلِكَ</span> and <span class="ar">تِلْكَ</span> because the <span class="ar">ل</span> denotes the remoteness of that which is indicated and the <span class="ar">ها</span> denotes its nearness, so that the two are incompatible. <span class="auth">(TA.)</span></p>
				</div>
				<span class="pb" id="Page_0292"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تا</span> - Entry: <span class="ar">تَا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="taA_B1">
					<p><span class="ar">تَا</span> and <span class="ar">تآءٌ</span> <em>Names of the letter</em> <span class="ar">ت</span>: see that letter, and see arts. <span class="ar">توأ</span> and <span class="ar">تى</span>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تا</span> - Entry: <span class="ar">تَا</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="taA_C1">
					<p><span class="ar">تَا</span> and <span class="ar">تَأَا</span> or <span class="ar">تَآ</span> for <span class="ar">تَشَآء</span>: see <span class="auth">(near its end)</span> art. <span class="ar">ا</span>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0291.pdf" target="pdf">
							<span>Lanes Lexicon Page 291</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0292.pdf" target="pdf">
							<span>Lanes Lexicon Page 292</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
