<article class="root" id="Root_trH">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/028_trjm">ترجم</a></span>
				<span class="ar">ترح</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/030_trs">ترس</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trH_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترح</span></h3>
				<div class="sense" id="trH_1_A1">
					<p><span class="ar">تَرِحَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَحُ</span>}</span></add>, inf. n. <span class="ar">تَرَحٌ</span>, <em>He grieved; he was,</em> or <em>became, sorrowful, unhappy,</em> or <em>anxious;</em> <span class="auth">(Mṣb, Ḳ;)</span> syn. <span class="ar">حَزِنَ</span>; <span class="auth">(Mṣb;)</span> <span class="add">[<em>contr. of</em> <span class="ar">فَرِحَ</span>; (<a href="#taraHN">see <span class="ar">تَرَحٌ</span>, below</a>;)]</span> as also<span class="arrow"><span class="ar">تترّح↓</span></span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترح</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trH_1_A2">
					<p><span class="add">[Also <em>He perished,</em> or <em>died: became cut off; was put an end to;</em> or <em>came to an end:</em> so accord. to explanations of <span class="ar">تَرَحٌ</span> given below on the authority of IAth.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trH_2">
				<h3 class="entry">2. ⇒ <span class="ar">ترّح</span></h3>
				<div class="sense" id="trH_2_A1">
					<p><span class="ar">ترّحهُ</span>, <span class="auth">(Ṣ, A, Ḳ,)</span> inf. n. <span class="ar">تَتْرِيحٌ</span>; <span class="auth">(Ṣ, Ḳ;)</span> and<span class="arrow"><span class="ar">اترحهُ↓</span></span>; <span class="auth">(A, Mṣb;)</span> <em>It</em> <span class="auth">(an affair, or an event, &amp;c., TA,)</span> <em>grieved him; it made him sorrowful, unhappy,</em> or <em>anxious.</em> <span class="auth">(Ṣ, A, Mṣb, Ḳ.)</span> A poet cited by IAạr says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">قَد طَالَ مَا تَرَّحَهَا المُتَرِّحُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Long did that which made unhappy make her,</em> or <em>them, unhappy</em>]</span>; meaning that the pasturage rendered troublesome her, or their, state. <span class="auth">(Th, AZ, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trH_4">
				<h3 class="entry">4. ⇒ <span class="ar">اترح</span></h3>
				<div class="sense" id="trH_4_A1">
					<p><a href="#trH_2">see 2</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trH_5">
				<h3 class="entry">5. ⇒ <span class="ar">تترّح</span></h3>
				<div class="sense" id="trH_5_A1">
					<p><a href="#trH_1">see 1</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taroHN">
				<h3 class="entry"><span class="ar">تَرْحٌ</span></h3>
				<div class="sense" id="taroHN_A1">
					<p><span class="ar">تَرْحٌ</span> <em>Poverty; need; indigence.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taraHN">
				<h3 class="entry"><span class="ar">تَرَحٌ</span></h3>
				<div class="sense" id="taraHN_A1">
					<p><span class="ar">تَرَحٌ</span> <em>Grief, sorrow, unhappiness,</em> or <em>anxiety;</em> syn. <span class="ar">حُزْنٌ</span>, <span class="auth">(Mṣb,)</span> or <span class="ar">هَمٌّ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar">غَمٌّ</span>; <span class="auth">(Ḥar p. 141;)</span> <em>contr. of</em> <span class="ar">فَرَحٌ</span>. <span class="auth">(Ṣ, A.)</span> <span class="add">[<a href="#trH_1">It is the inf. n. of 1</a>; but used as a subst., it has a pl., namely, <span class="ar">أَتْرَاحٌ</span>, like <span class="ar">أَفْرَاحٌ</span>. Hence the saying,]</span> <span class="ar long">مَا الدُّنْيَا إِلَّا فَرَحٌ وَتَرَحٌ</span> <span class="add">[<em>The present world,</em> or <em>life, is nothing but a scene,</em> or <em>state, of joy and grief</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترح</span> - Entry: <span class="ar">تَرَحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taraHN_A2">
					<p><em>A perishing,</em> or <em>dying: becoming cut off; being put an end to;</em> or <em>coming to an end.</em> <span class="auth">(IAth, TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترح</span> - Entry: <span class="ar">تَرَحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="taraHN_A3">
					<p><em>A descending, going down,</em> or <em>going down a declivity;</em> syn. <span class="ar">هُبُوطٌ</span>. <span class="auth">(Ibn-Munádhir, Ḳ.)</span> One says, <span class="ar long">مَا زِلْنَا مُذُ الَّيْلَةِ فِى تَرَحٍ</span> i. e. <span class="add">[<em>We have not ceased from the beginning of this night to be</em>]</span> <em>in a state of descending,</em>, &amp;c. <span class="auth">(Ibn-Munádhir.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tariHN">
				<h3 class="entry"><span class="ar">تَرِحٌ</span></h3>
				<div class="sense" id="tariHN_A1">
					<p><span class="ar">تَرِحٌ</span> <em>Grieving; sorrowing; unhappy.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترح</span> - Entry: <span class="ar">تَرِحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tariHN_A2">
					<p>A man <span class="auth">(A)</span> <em>who possesses,</em> or <em>does, little,</em> or <em>no, good,</em> <span class="auth">(A, Ḳ,)</span> <em>so that he who asks of him grieves.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taroHapN">
				<h3 class="entry"><span class="ar">تَرْحَةٌ</span></h3>
				<div class="sense" id="taroHapN_A1">
					<p><span class="ar">تَرْحَةٌ</span> <em>A grief; a sorrow; an unhappiness.</em> <span class="auth">(L.)</span> <span class="add">[Hence the saying,]</span> <span class="ar long">مَامِنْ فَرَحَهْ إِلَّا وَبَعْدَهَا تَرْحَهْ</span> <span class="add">[<em>There is no joy but there is after it a grief</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutoriHN">
				<h3 class="entry"><span class="ar">مُتْرِحٌ</span></h3>
				<div class="sense" id="mutoriHN_A1">
					<p><span class="ar">مُتْرِحٌ</span>, or <span class="ar">مُتْرَحٌ</span>, accord. to different copies of the Ḳ, <span class="auth">(TA,)</span> One <em>who ceases not to hear and see that which does not please him.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoraHapN">
				<h3 class="entry"><span class="ar">مَتْرَحَةٌ</span></h3>
				<div class="sense" id="matoraHapN_A1">
					<p><span class="add">[<span class="ar">مَتْرَحَةٌ</span> <em>A cause of grief, sorrow, unhappiness,</em> or <em>anxiety:</em> pl. <span class="ar">مَتَارِحُ</span>. Hence the saying,]</span> <span class="ar long">تَرَّحَتْهُ المَتَارِحُ</span> <span class="add">[<em>Misfortunes</em> <span class="auth">(lit. <em>the causes of grief,</em>, &amp;c.,)</span> <em>grieved him,</em> or <em>made him sorrowful,</em>, &amp;c.]</span>. <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutarBaHN">
				<h3 class="entry"><span class="ar">مُتَرَّحٌ</span></h3>
				<div class="sense" id="mutarBaHN_A1">
					<p><span class="ar">مُتَرَّحٌ</span> <em>Strait, difficult,</em> or <em>distressful,</em> life. <span class="auth">(A, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترح</span> - Entry: <span class="ar">مُتَرَّحٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutarBaHN_A2">
					<p>A <em>scanty</em> torrent, or flow of water, <em>in which is a stopping,</em> or <em>an interruption.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترح</span> - Entry: <span class="ar">مُتَرَّحٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="mutarBaHN_B1">
					<p>A garment, or piece of cloth, <em>dyed so as to be saturated with the dye.</em> <span class="auth">(Az, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoraAHN">
				<h3 class="entry"><span class="ar">مَتْرَاحٌ</span></h3>
				<div class="sense" id="matoraAHN_A1">
					<p><span class="ar">مَتْرَاحٌ</span> A she-camel <em>whose milk soon comes to an end,</em> or <em>stops:</em> <span class="auth">(Ṣ, L:)</span> pl. <span class="ar">مَتَارِيحُ</span>. <span class="auth">(L.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0302.pdf" target="pdf">
							<span>Lanes Lexicon Page 302</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
