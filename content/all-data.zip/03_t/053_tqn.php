<article class="root" id="Root_tqn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/052_tqd">تقد</a></span>
				<span class="ar">تقن</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/054_tqw">تقو</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tqn_2">
				<h3 class="entry">2. ⇒ <span class="ar">تقّن</span></h3>
				<div class="sense" id="tqn_2_A1">
					<p><span class="ar long">تَقَّنُوا أَرْضَهُمْ</span>, <span class="auth">(JK, Ḳ,)</span> inf. n. <span class="ar">تَتْقِينَ</span>, <span class="auth">(Ḳ,)</span> <em>They watered their land with thick,</em> or <em>muddy, water,</em> <span class="add">[or <em>water containing</em> <span class="ar">تِقْن</span>,]</span> <span class="auth">(JK,* Ḳ,)</span> <em>in order that it might become good.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tqn_4">
				<h3 class="entry">4. ⇒ <span class="ar">اتقن</span></h3>
				<div class="sense" id="tqn_4_A1">
					<p><span class="ar">اتقنهُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">إِتْقَانٌ</span>, <span class="auth">(JK, Ṣ,)</span> <em>i. q.</em> <span class="ar">أَحْكَمَهُ</span> <span class="add">[<em>He made it,</em> or <em>rendered it,</em> <span class="auth">(namely, a thing, JK, or an affair, Ṣ and Ḳ,)</span> <em>firm, stable, strong, solid, compact, sound,</em> or <em>free from defect</em> or <em>imperfection, by the exercise of skill; he made it firmly, strongly, solidly, compactly, so that it was firmly and closely joined</em> or <em>knit together, soundly, thoroughly, skilfully, judiciously,</em> or <em>well; he so constructed, constituted, established, settled, arranged, did, performed,</em> or <em>executed, it; he put it into a firm, solid, sound,</em> or <em>good, state,</em> or <em>on a firm, solid, sound,</em> or <em>good, footing</em>]</span>. <span class="auth">(JK, Ṣ, Ḳ.)</span> <span class="add">[And <span class="ar long">اتقن لَهُ</span> signifies the same as <span class="ar">اتقنهُ</span>: or <em>he exercised,</em> or <em>possessed, the skill requisite for it;</em> namely, an affair.]</span> <span class="ar long">الَّذِى أَتْقَنَ كُلَّ شَّىْءٍ</span>, in the Ḳur xxvii. 90, means <em>Who hath created everything firmly, strongly, solidly,</em>, &amp;c., (<span class="ar long">أَحْكَمَ خَلْقَهُ</span>,) <em>and made it, fashioned it,</em> or <em>disposed it, in the fit, proper,</em> or <em>right, manner.</em> <span class="auth">(Bḍ.)</span> <span class="add">[You say also, <span class="ar long">اتقن عِلْمَهُ</span>, meaning <em>He made his knowledge sound;</em> or <em>made himself thoroughly learned.</em>]</span> And <span class="ar long">اتقن عَنْهُ</span> <em>He knew it,</em> or <em>learned it,</em> <span class="auth">(namely, a tradition <span class="add">[&amp;c.]</span>,)</span> <em>soundly, thoroughly,</em> or <em>well, from him.</em> <span class="auth">(TA in art. <span class="ar">ذبر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tiqonN">
				<h3 class="entry"><span class="ar">تِقْنٌ</span></h3>
				<div class="sense" id="tiqonN_A1">
					<p><span class="ar">تِقْنٌ</span> The <span class="ar">رُسَابَة</span> <em>of water,</em> <span class="auth">(JK, Mgh, Ḳ,)</span> <em>in a rivulet or in the channel of a torrent,</em> <span class="auth">(Ḳ,)</span> <em>in the</em> <span class="add">[<em>season called</em>]</span> <span class="ar">رَبِيع</span>; <span class="auth">(Lth, JK, Mgh;)</span> i. e., <span class="auth">(Mgh,)</span> <span class="add">[<em>its sediment,</em> or]</span> the <em>thick matter that is borne by it</em> <span class="add">[<em>and that sinks to the bottom; used for improving land</em>]</span>: <span class="auth">(Lth, JK, Mgh:)</span> and <span class="auth">(Ḳ)</span> the <span class="ar">تُرْنُوق</span> <em>of a well</em> <span class="auth">(Mgh, Ḳ)</span> and <em>of the channel of a torrent;</em> i. e., the <em>slime, mixed with black,</em> or <em>black and fetid, mud;</em> accord. to the Jámiʼ of El-Ghooree. <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقن</span> - Entry: <span class="ar">تِقْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tiqonN_A2">
					<p><em>A thing by means of which one subsists, and makes good,</em> or <em>improves, the performance,</em> or <em>execution,</em> or <em>management, of an affair; as iron, and other things, of the</em> <span class="ar">جَوَاهِر</span> <span class="add">[i. e. <em>precious stones,</em> or <em>native ores,</em>]</span> <em>of the earth:</em> and <em>anything by means of which a thing is made good,</em> or <em>improved,</em> is called its <span class="ar">تِقْن</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقن</span> - Entry: <span class="ar">تِقْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tiqonN_A3">
					<p>A <em>skilful</em> man: <span class="auth">(JK, Ṣ, Ḳ:)</span> pl. <span class="ar">أَتْقَانٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقن</span> - Entry: <span class="ar">تِقْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tiqonN_A4">
					<p><span class="add">[Hence, probably,]</span> <span class="ar">تِقْنٌ</span> <span class="add">[or <span class="ar long">اِبْنُ تِقْنٍ</span>]</span> is also the name <span class="add">[or surname]</span> of a certain man proverbial for his excellence in shooting. <span class="auth">(Ṣ, Ḳ. <span class="add">[In the latter it is implied that this name or surname is <span class="ar">التِّقْنُ</span>.]</span>)</span> The rájiz says,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">يَرَمِى بِهَا أَرْمَى مِنِ ٱبْنِ تِقْنِ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>One more skilled in shooting than Ibn-Tikn shoots it</em>]</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تقن</span> - Entry: <span class="ar">تِقْنٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tiqonN_A5">
					<p><em>Nature,</em> or <em>natural disposition.</em> <span class="auth">(JK, Ṣ, Ḳ.)</span> You say, <span class="ar long">الفَصَاحَةُ مِنْ تِقْنِهِ</span> <em>Chasteness of speech,</em> or <em>eloquence, is</em> <span class="add">[a quality]</span> <em>of his nature.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0309.pdf" target="pdf">
							<span>Lanes Lexicon Page 309</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
