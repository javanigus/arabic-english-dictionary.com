<article class="root" id="Root_txrS">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/021_txc">تخذ</a></span>
				<span class="ar">تخرص</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/023_txm">تخم</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tixoriySN">
				<span class="pb" id="Page_0299"></span>
				<h3 class="entry"><span class="ar">تِخْرِيصٌ</span></h3>
				<div class="sense" id="tixoriySN_A1">
					<p><span class="ar">تِخْرِيصٌ</span> and <span class="ar">تِخْرِيصَةٌ</span> <span class="auth">(Lth, Ḳ)</span> dial. vars. of <span class="ar">دِخْرِيصٌ</span> and <span class="ar">دِخْرِيصَةٌ</span>, <span class="auth">(Lth,)</span> <em>A</em> <span class="ar">بَنِيقَة</span> <span class="add">[or <em>gore</em>]</span> of a garment: arabicized words, from <span class="ar">تِيرِيزْ</span>, <span class="auth">(Lth, Ḳ,)</span> which is Persian. <span class="auth">(Lth.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0299.pdf" target="pdf">
							<span>Lanes Lexicon Page 299</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
