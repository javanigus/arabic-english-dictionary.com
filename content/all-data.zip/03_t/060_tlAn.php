<article class="root" id="Root_tlAn">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/059_tlOb">تلأب</a></span>
				<span class="ar">تلان</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/061_tlb">تلب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="talaAna">
				<h3 class="entry"><span class="ar">تَلَانَ</span></h3>
				<div class="sense" id="talaAna_A1">
					<p><span class="ar">تَلَانَ</span> <em>i. q.</em> <span class="ar">ٱلْآنَ</span> <span class="add">[<em>At the present time; now</em>]</span>: <span class="auth">(Aṣ, Ḳ:)</span> the <span class="ar">ت</span> is added, as in <span class="ar">تَحِينَ</span>. <span class="auth">(AʼObeyd, &amp;c.)</span> <a href="index.php?data=01_A/181_Ayn">See art. <span class="ar">اين</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0311.pdf" target="pdf">
							<span>Lanes Lexicon Page 311</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
