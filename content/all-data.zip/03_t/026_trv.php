<article class="root" id="Root_trv">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/025_trb">ترب</a></span>
				<span class="ar">ترث</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/027_trj">ترج</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">ترث</span></h4>
			<hr>
			<section class="entry xref" id="turaAvN">
				<h3 class="entry"><span class="ar">تُرَاثٌ</span></h3>
				<div class="sense" id="turaAvN_A1">
					<p><span class="ar">تُرَاثٌ</span>: <a href="#wariva">see <span class="ar">وَرِثَ</span></a> <a href="#wirovN">and <span class="ar">وِرْثٌ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0301.pdf" target="pdf">
							<span>Lanes Lexicon Page 301</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
