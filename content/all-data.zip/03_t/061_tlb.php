<article class="root" id="Root_tlb">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/060_tlAn">تلان</a></span>
				<span class="ar">تلب</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/062_tlj">تلج</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tlb_QQ4">
				<h3 class="entry">Q. Q. 4. ⇒ <span class="ar">اِتْلَأَبَّ</span></h3>
				<div class="sense" id="tlb_QQ4_A1">
					<p><span class="ar">اِتْلَأَبَّ</span>, <span class="auth">(T, Ṣ, M, &amp;c.,)</span> inf. n. <span class="ar">اِتْلِئْبَابٌ</span>, <span class="auth">(Ṣ, Ḳ,)</span> <em>It</em> <span class="auth">(a thing, M, or an affair, or a case, Ṣ, Ḳ, or a road, A)</span> <em>was,</em> or <em>became, uniform</em> or <em>undeviating,</em> <span class="auth">(A,)</span> <em>right,</em> or <em>rightly directed</em> or <em>ordered:</em> <span class="auth">(Ṣ, M, A, Ḳ:)</span> or <span class="auth">(M)</span> <em>it</em> <span class="auth">(a thing, M, or a road, Ṣ, Ḳ)</span> <em>was,</em> or <em>became, extended,</em> <span class="auth">(Fr, T, Ṣ, M, A, Ḳ,)</span> and <em>right, direct, even,</em> or <em>uniform:</em> <span class="auth">(Ṣ, M, Ḳ:*)</span> or <span class="auth">(M)</span> <em>it</em> <span class="auth">(a thing, M)</span> <em>was,</em> or <em>became, set up,</em> or <em>erect.</em> <span class="auth">(M, A, Ḳ.)</span> You say, <span class="ar long">مَرُّوا فَٱنْلَأَبَّ بِهِمُ الطَّرِيقُ</span> <span class="add">[<em>They went along, and the road was,</em> or <em>became, uniform,</em>, &amp;c., <em>with them;</em> i. e., <em>their road was,</em> or <em>became, uniform,</em>, &amp;c.]</span>. <span class="auth">(A.)</span> And <span class="ar long">اتلأبّ أَمْرُهُمْ</span> <span class="add">[<em>Their affair,</em> or <em>case, was,</em> or <em>became, right,</em> or <em>rightly directed</em> or <em>ordered</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلب</span> - Entry: Q. Q. 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tlb_QQ4_A2">
					<p><em>He</em> <span class="auth">(an ass)</span> <em>raised his breast and head.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلب</span> - Entry: Q. Q. 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tlb_QQ4_A3">
					<p>This verb and its derivatives are mentioned in the <span class="add">[T and]</span> Ṣ and Ḳ in the present art.; but they are held by <span class="add">[ISd and]</span> IB to be radically quadriliteral. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="talobN">
				<h3 class="entry"><span class="ar">تَلْبٌ</span></h3>
				<div class="sense" id="talobN_A1">
					<p><span class="ar">تَلْبٌ</span> <em>Loss;</em> or the <em>state of being lost;</em> or <em>perdition.</em> <span class="auth">(A, Ḳ.)</span> One says, <span class="ar long">تَبًّا لَهُ تَلْبًا</span>, <span class="auth">(Lth, T,)</span> or <span class="ar long">تَبًّا لَهُ وَتَلْبًا</span> <span class="add">[which may be rendered May God decree <em>loss and perdition to him</em>]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tulaOobiybapN">
				<h3 class="entry"><span class="ar">تُلَأْبِيبَةٌ</span></h3>
				<div class="sense" id="tulaOobiybapN_A1">
					<p><span class="ar">تُلَأْبِيبَةٌ</span> a subst. <span class="auth">(Ṣ, M, Ḳ)</span> from <span class="ar">اِتْلَأَبَّ</span>; <span class="auth">(Fr, T, Ṣ, M, Ḳ;)</span> <span class="add">[signifying The <em>state of being uniform</em> or <em>undeviating, right,</em>, &amp;c.;]</span> like <span class="ar">طُمَأْنِينَةٌ</span> <span class="add">[from <span class="ar">اِطْمَأَنَّ</span>]</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tawolabN">
				<h3 class="entry"><span class="ar">تَوْلَبٌ</span></h3>
				<div class="sense" id="tawolabN_A1">
					<p><span class="ar">تَوْلَبٌ</span>, perfectly decl. <span class="add">[when used as a proper name as well as when used as an appellative]</span>, because it is of the measure <span class="ar">فَوْعَلٌ</span>; <span class="auth">(Sb, Ṣ;)</span> for we judge its <span class="ar">ت</span> to be a radical, and its <span class="ar">و</span> to be augmentative, because <span class="ar">فَوْعَل</span> is more common <span class="add">[as the measure of a noun]</span> than <span class="ar">تَفْعَل</span>; <span class="auth">(M;)</span> but accord. to Suh, the <span class="ar">ت</span> is a substitute for <span class="ar">و</span>, and, if so, it should be mentioned in art. <span class="ar">ولب</span>; <span class="auth">(TA;)</span> <em>A young ass;</em> syn. <span class="ar">جَحْشٌ</span>: <span class="auth">(Ṣ, Ḳ:)</span> or the <em>foal of a wild ass, when he has completed a year.</em> <span class="auth">(M.)</span> And <span class="ar long">أُمُّ تَوْلَب</span> is an appellation given to <em>The she-ass.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تلب</span> - Entry: <span class="ar">تَوْلَبٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tawolabN_A2">
					<p>The former is sometimes metaphorically applied to ‡ <em>A</em> <span class="add">[<em>young</em>]</span> <em>man:</em> <span class="auth">(M:)</span> or <em>a boy.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutolaYibBN">
				<h3 class="entry"><span class="ar">مُتْلَئِبٌّ</span></h3>
				<div class="sense" id="mutolaYibBN_A1">
					<p><span class="ar">مُتْلَئِبٌّ</span> <span class="add">[<em>Uniform</em> or <em>undeviating,</em>]</span> <em>right,</em> or <em>rightly directed</em> or <em>ordered</em> <span class="add">[&amp;c.: see the verb]</span>; as also <span class="ar">مُسْلَحِبٌّ</span>. <span class="auth">(Asudot;, T)</span> Also applied to a rule, <span class="auth">(A, TA,)</span> as meaning <em>Uniform, undeviating,</em> or <em>of general application; uniformly,</em> or <em>constantly, obtaining.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mataAlibu">
				<h3 class="entry"><span class="ar">مَتَالِبُ</span></h3>
				<div class="sense" id="mataAlibu_A1">
					<p><span class="ar">مَتَالِبُ</span> <span class="add">[app. <a href="#matolabN">pl. of <span class="ar">مَتْلَبٌ</span></a> or <span class="ar">مَتْلِبٌ</span>]</span> The <em>places where a wound causes</em> death; syn. <span class="ar">مَقَاتِلُ</span>. <span class="auth">(IAạr, T.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0311.pdf" target="pdf">
							<span>Lanes Lexicon Page 311</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
