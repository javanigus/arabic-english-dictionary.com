<article class="root" id="Root_tr">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/023_txm">تخم</a></span>
				<span class="ar">تر</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/025_trb">ترب</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tr_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترّ</span></h3>
				<div class="sense" id="tr_1_A1">
					<p><span class="ar">تَرَّ</span>, <span class="auth">(T, M, A, Ḳ,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْرِرُ</span>}</span></add> and <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْرُرُ</span>}</span></add>, <span class="auth">(M, Ḳ,)</span> the latter irregular, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَرٌّ</span> and <span class="ar">تُرُورٌ</span>, <span class="auth">(M, Ḳ,)</span> <em>It</em> <span class="auth">(a bone, M, Ḳ, or anything, M,)</span> <em>became severed, separated,</em> or <em>cut off,</em> <span class="auth">(T, M, Ḳ,)</span> by a blow, or stroke <span class="add">[of a sword, &amp;c.]</span>. <span class="auth">(M, A.)</span> And <span class="ar long">تَرَّتْ يَدُهُ</span>, inf. n. <span class="ar">تُرُورٌ</span>, <em>His arm,</em> or <em>hand, became cut off;</em> <span class="auth">(M;)</span> and in like manner, any member: <span class="auth">(TA:)</span> or <em>fell off;</em> as also <span class="ar">طَرَّتْ</span>. <span class="auth">(Ṣ in art. <span class="ar">طر</span>.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tr_1_A2">
					<p><span class="ar long">تَرَّتِ النَّوَاةُ</span>, <span class="auth">(Ṣ, M, A,)</span>) aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْرِرُ</span>}</span></add>, <span class="auth">(Ṣ, M,)</span> and <span class="ar">ـُ</span>, <span class="auth">(Ṣ,)</span> inf. n. <span class="ar">تُرُورٌ</span>, <span class="auth">(T, M,)</span> <em>The date-stone leaped,</em> <span class="auth">(T, M,)</span> or <em>went forth,</em> <span class="auth">(Ṣ, A,)</span> from the <span class="add">[mess called]</span> <span class="ar">حَيْس</span> <span class="add">[in the process of kneading]</span>, <span class="auth">(T,)</span> or from the stone with which it was to be broken. <span class="auth">(Ṣ, A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tr_1_A3">
					<p><span class="ar long">تَرَّ عَنْ قَوْمِهِ</span> <em>He was,</em> or <em>became, apart,</em> or <em>separated, from his people.</em> <span class="auth">(Aṣ, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tr_1_A4">
					<p><span class="ar long">تَرَّ عَنْ بَلَدِهِ</span> <em>He was,</em> or <em>became,</em> or <em>went, far from his country,</em> or <em>town.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tr_1_B1">
					<p><span class="ar">تَرَّ</span>, <span class="auth">(M,)</span> aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْرِرُ</span>}</span></add>, <span class="auth">(TA,)</span> inf. n. <span class="ar">تَرٌّ</span>, <span class="auth">(Ḳ,)</span> <em>He</em> <span class="auth">(an ostrich)</span> <em>ejected what was in his belly.</em> <span class="auth">(M, Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="tr_1_B2">
					<p><span class="ar long">تَرَّ بِسَلْحِهِ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْرُرُ</span>}</span></add> and <span class="ar">ـِ</span>, <em>He ejected his excrement.</em> <span class="auth">(AA, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="tr_1_B3">
					<p><a href="#tr_4">See also 4</a>, in two places.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: C</span>
				</div>
				<div class="sense" id="tr_1_C1">
					<p><span class="ar">تَرَّ</span>, <span class="auth">(T, M, Ḳ,)</span> sec. pers. <span class="ar">تَرِرْتَ</span>, <span class="auth">(Ṣ,)</span> aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَرُ</span>}</span></add>, <span class="auth">(T, M,)</span> and <span class="add">[sec. pers. <span class="ar">تَرَرْتَ</span>, aor.]</span> <span class="ar">ـِ</span>, <span class="auth">(M,)</span> <span class="add">[and app. sec. pers. <span class="ar">تَرُرْتَ</span>, aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْرُرُ</span>}</span></add>,]</span> inf. n. <span class="add">[of <span class="ar">تَرِرْتَ</span> or <span class="ar">تَرَرْتَ</span>]</span> <span class="ar">تَرٌّ</span> and <span class="add">[of <span class="ar">تَرَرْتَ</span>]</span> <span class="ar">تُرُورٌ</span> <span class="auth">(M, Ḳ)</span> and <span class="add">[of <span class="ar">تَرُرْتَ</span>]</span> <span class="ar">تَرَارَةٌ</span>, <span class="add">[which last is the most common,]</span> <span class="auth">(Lth, T, Ṣ, M, Ḳ,)</span> <em>He was,</em> or <em>became, plump:</em> <span class="auth">(T in explanation of the first verb:)</span> or <em>his body became plump, and his bones full of moisture:</em> <span class="auth">(Lth, T, M, Ḳ:)</span> or <em>he became fat, soft, thin-skinned, and plump.</em> <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: C2</span>
				</div>
				<div class="sense" id="tr_1_C2">
					<p>And <span class="ar">تَرَّ</span>, aor. <span class="ar">ـِ</span> <add><span class="new">{<span class="ar">يَتْرِرُ</span>}</span></add>, <em>He was,</em> or <em>became, relaxed,</em> or <em>flaccid, from impatience or some other cause.</em> <span class="auth">(T. <span class="add">[<a href="#taArBu">See <span class="ar">تَارُّ</span></a>.]</span>)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tr_4">
				<h3 class="entry">4. ⇒ <span class="ar">اترّ</span></h3>
				<div class="sense" id="tr_4_A1">
					<p><span class="ar">اترّ</span>; <span class="auth">(T, Ṣ, M, A, Ḳ;)</span> and<span class="arrow"><span class="ar">تَرَّ↓</span></span>, <span class="auth">(IDrd, M, Ḳ,)</span> inf. n. <span class="ar">تَرٌّ</span>; <span class="auth">(IDrd, M;)</span> or the former only; <span class="auth">(M;)</span> <em>He cut off</em> <span class="auth">(T, Ṣ, M, Ḳ)</span> a man's arm, or hand, by a blow, or stroke, <span class="auth">(T, Ṣ, M, A,)</span> of a sword; <span class="auth">(T, Ṣ, A;)</span> <em>made</em> it <em>to fall off:</em> <span class="auth">(Ṣ:)</span> and in like manner, any member: <span class="auth">(M:)</span> as also <span class="ar">اطرّ</span> and <span class="ar">اطنّ</span>. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tr_4_A2">
					<p>And the former, <span class="auth">(Ṣ, A, TA,)</span> or<span class="arrow">↓</span> the latter, <span class="auth">(M, as in the TT,)</span> <em>He</em> <span class="auth">(a boy)</span> <em>made the piece of wood called</em> <span class="ar">قُلَة</span> <em>to fly away</em> <span class="add">[<em>by striking it</em>]</span> <em>with the</em> <span class="ar">مِقْلَآء</span>. <span class="auth">(T, Ṣ,* M,* A,* TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tr_4_A3">
					<p><span class="ar long">اترّهُ قَوْمُهُ</span> <em>His people separated him from themselves.</em> <span class="auth">(Aṣ, T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: 4.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tr_4_A4">
					<p><span class="ar long">اترّهُ القَضَآءُ</span> <em>Fate drove him far away from his country,</em> or <em>town.</em> <span class="auth">(Ṣ, M, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tr_RQ1">
				<h3 class="entry">R. Q. 1. ⇒ <span class="ar">ترتر</span></h3>
				<div class="sense" id="tr_RQ1_A1">
					<p><span class="ar">تَرْتَرَهُ</span>, inf. n. <span class="ar">تَرْتَرَةٌ</span>, <em>He moved, put in motion, put into a state of commotion, agitated,</em> or <em>shook, him,</em> or <em>it:</em> <span class="auth">(Ṣ, M, Ḳ:)</span> <em>he shook him vehemently:</em> <span class="auth">(M:)</span> <em>he seized his</em> <span class="auth">(a man's)</span> <em>arms,</em> or <em>hands, and shook him:</em> <span class="auth">(Lth, T:)</span> <em>he shook him</em> <span class="auth">(a drunken man)</span> <em>violently, and ordered him to breath in his face, that he might know what he had drunk;</em> <span class="auth">(AA, T, Ḳ;)</span> as also <span class="ar">تَلْتَلَهُ</span>, and <span class="ar">مَزْمَزَهُ</span>: <span class="auth">(TA:)</span> or <span class="ar">تَرْتَرَةٌ</span> and <span class="ar">تَلْتَلَةٌ</span> and <span class="ar">مَزْمَزَةٌ</span> all signify the act of <em>shaking, agitating,</em> or <em>putting in motion, vehemently.</em> <span class="auth">(Mgh.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tr_RQ2">
				<h3 class="entry">R. Q. 2. ⇒ <span class="ar">تترتر</span></h3>
				<div class="sense" id="tr_RQ2_A1">
					<p><span class="ar">تَتَرْتَرَ</span> <em>He became moved, put in motion, put into a state of commotion, agitated,</em> or <em>shaken.</em> <span class="auth">(Ṣ, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tarBN">
				<h3 class="entry"><span class="ar">تَرٌّ</span></h3>
				<div class="sense" id="tarBN_A1">
					<p><span class="ar">تَرٌّ</span>: <a href="#taArBN">see <span class="ar">تَارٌّ</span></a>:</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تر</span> - Entry: <span class="ar">تَرٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tarBN_B1">
					<p><a href="#turBN">and <span class="ar">تُرٌّ</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="turBN">
				<h3 class="entry"><span class="ar">تُرٌّ</span></h3>
				<div class="sense" id="turBN_A1">
					<p><span class="ar">تُرٌّ</span> The <em>string,</em> or <em>line, which is extended upon,</em> or <em>against, a building,</em> <span class="auth">(Aṣ, Ṣ, M,)</span> <em>and according to which one builds, called in Arabic the</em> <span class="ar">إِمَام</span>; <span class="auth">(Aṣ, M;)</span> the <em>string,</em> or <em>line, by which a building is proportioned:</em> <span class="auth">(Aṣ, T, M, Ḳ:)</span> a Persian word, <span class="auth">(T, M,)</span> arabicized; <span class="auth">(M;)</span> not Arabic: <span class="auth">(IAạr:)</span> <em>it is called in Arabic the</em> <span class="ar">مِطْمَر</span>. <span class="auth">(Aṣ, T.)</span> A man, when angry, says to another, <span class="ar long">لَأُقِيمَنَّكَ عَلَى التُرِّ</span> ‡ <span class="add">[<em>I will assuredly make thee to conform to the rule of right behaviour</em>]</span>. <span class="auth">(Lth, T, Ṣ, A.)</span></p>
				</div>
				<span class="pb" id="Page_0300"></span>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تر</span> - Entry: <span class="ar">تُرٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="turBN_B1">
					<p><em>I. q.</em> <span class="ar">أَصْلٌ</span>: <span class="auth">(IAạr, T, Ḳ:)</span> so in the saying, <span class="ar long">لَأَضْطَرَّنَّكَ إِلَى تُرِّكَ وَقُحَاحِكَ</span> <span class="add">[<em>I will assuredly impel thee,</em> or <em>drive thee, against thy will, to the utmost point to which thou canst go,</em> or <em>be brought</em> or <em>reduced:</em> or <em>constrain thee to do thine utmost</em>]</span>: <span class="auth">(IAạr, T, and L in art. <span class="ar">قح</span>: <a href="#quHaAHN">see <span class="ar">قُحَاحٌ</span></a>:)</span> <span class="add">[accord. to ISd,]</span> <span class="ar long">لَأَضْطَرَّنَّكَ إِلَى تُرِّكَ</span> means <span class="ar long">إِلَى مَجْهُودِكَ</span> <span class="add">[i. e. <em>I will assuredly make thee to have recourse to thine utmost effort,</em> or <em>endeavour</em>]</span>. <span class="auth">(M. <span class="add">[In the Ḳ, the signification of <span class="ar">المَجْهُودُ</span> is erroneously assigned to<span class="arrow"><span class="ar">التَّرُّ↓</span></span>. See also the saying <span class="ar long">لَأُلْجِئَنَّكَ إِلَى قُرِّ قَرَارِكَ</span> explained voce <span class="ar">قَرَارٌ</span>.]</span>)</span> <span class="ar">تُرَّى</span> An arm, or a hand, <em>cut off.</em> <span class="auth">(Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taraAtiru">
				<h3 class="entry"><span class="ar">تَرَاتِرُ</span></h3>
				<div class="sense" id="taraAtiru_A1">
					<p><span class="ar">تَرَاتِرُ</span> <span class="add">[a pl. of which the sing. is not mentioned]</span> <em>Great,</em> or <em>formidable,</em> or <em>terrible, things</em> or <em>events</em> or <em>affairs:</em> <span class="auth">(Ṣ:)</span> <em>distresses, afflictions,</em> or <em>calamities;</em> <span class="auth">(M, A, Ḳ;)</span> <em>such as are in war.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taArBN">
				<h3 class="entry"><span class="ar">تَارٌّ</span> / <span class="ar">تَارَّةٌ</span></h3>
				<div class="sense" id="taArBN_A1">
					<p><span class="ar">تَارٌّ</span> A man <em>apart,</em> or <em>separate, from his people.</em> <span class="auth">(Aṣ, T.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">تر</span> - Entry: <span class="ar">تَارٌّ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="taArBN_B1">
					<p><em>Plump</em> <span class="auth">(Lth, T, Ṣ, A)</span> <em>in body,</em> <span class="auth">(Lth, T,)</span> <em>and having the bones full of moisture;</em> <span class="auth">(Lth, T, A;)</span> <em>fat, soft, thin-skinned, and plump:</em> <span class="auth">(Ṣ, TA:)</span> applied to a youth: fem. with <span class="ar">ة</span> <add><span class="new">{<span class="ar">تَارَّةٌ</span>}</span></add>, applied to a girl; <span class="auth">(A, TA;)</span> meaning <span class="add">[<em>plump</em>, &amp;c.: or]</span> <em>beautiful and foolish and soft</em> or <em>weak.</em> <span class="auth">(T.)</span> You say, <span class="ar long">غُلَامٌ تَارٌّ طَارٌّ</span> <span class="add">[<em>A boy that is plump, and with bones full of moisture, whose mustache is growing forth</em>]</span>. <span class="auth">(A.)</span> And <span class="ar long">قَصَبَةٌ تَارَّةٌ</span> <span class="add">[<em>A bone of the kind called</em> <span class="ar">قصبة</span> <em>full of moisture</em>]</span>. <span class="auth">(A.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: <span class="ar">تَارٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B2</span>
				</div>
				<div class="sense" id="taArBN_B2">
					<p><em>Relaxed,</em> or <em>flaccid, by reason of impatience</em> (<span class="ar">جَزَع</span> T) or <em>hunger</em> (<span class="ar">جَوْع</span> Ḳ) <span class="add">[or the contrary (<a href="#OatarBa">see <span class="ar long">أَتَرَّ شَىْءٍ</span>, below</a>,)]</span> <em>or some other cause:</em> <span class="auth">(T, Ḳ:)</span> so says Abu-l-ʼAbbás. <span class="auth">(T.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تر</span> - Entry: <span class="ar">تَارٌّ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: B3</span>
				</div>
				<div class="sense" id="taArBN_B3">
					<p>A <em>tall</em> man; as also<span class="arrow"><span class="ar">تَرٌّ↓</span></span>, which is app. <span class="add">[a contraction of <span class="ar">تَرِرٌ</span>,]</span> of the measure <span class="ar">فَعِلٌ</span>. <span class="auth">(M.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OatarBa">
				<h3 class="entry"><span class="ar">أَتَرَّ</span></h3>
				<div class="sense" id="OatarBa_A1">
					<p><span class="ar long">أَتَرَّ شَىْءٍ</span> A man <em>in the most relaxed state by reason of fullness of the belly:</em> <span class="auth">(TA:)</span> or, accord. to Abu-l-ʼAbbás, <em>by reason of fatigue.</em> <span class="auth">(T, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0299.pdf" target="pdf">
							<span>Lanes Lexicon Page 299</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0300.pdf" target="pdf">
							<span>Lanes Lexicon Page 300</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
