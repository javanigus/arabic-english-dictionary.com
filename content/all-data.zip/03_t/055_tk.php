<article class="root" id="Root_tk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/054_tqw">تقو</a></span>
				<span class="ar">تك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/056_tkO">تكأ</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tk_10">
				<h3 class="entry">10. ⇒ <span class="ar">استتكّ</span></h3>
				<div class="sense" id="tk_10_A1">
					<p><span class="ar long">استتكّ التِّكَّةَ</span>, <span class="auth">(IDrd, Ḳ,)</span> or <span class="ar">بِالتِّكَّةِ</span>, <span class="auth">(Mṣb,)</span> <em>He inserted the</em> <span class="ar">تِكَّة</span> <em>in</em> <span class="add">[<em>the double upper border of</em>]</span> <em>the drawers,</em> or <em>trousers.</em> <span class="auth">(IDrd, Mṣb, Ḳ.)</span> You say also, <span class="ar long">هُوَ يَسْتَتِكُ بِالحَرِيرِ</span> <em>He makes use of a</em> <span class="ar">تِكَّة</span> <em>of silk.</em> <span class="auth">(A.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tikBapN">
				<h3 class="entry"><span class="ar">تِكَّةٌ</span></h3>
				<div class="sense" id="tikBapN_A1">
					<p><span class="ar">تِكَّةٌ</span> The <em>band</em> <span class="add">[<em>that is inserted in the double upper border</em>]</span> <em>of the drawers,</em> or <em>trousers;</em> <span class="auth">(IDrd, Ḳ;)</span> <span class="add">[<em>generally, a strip of cotton, which is often embroidered at each end; sometimes, of net-work; and</em>]</span> <em>sometimes, of silk:</em> <span class="auth">(A:)</span> IDrd thinks it to be an adventitious word, though used in ancient times; <span class="auth">(TA;)</span> and IAmb says, I think it to be arabicized: <span class="auth">(Mṣb:)</span> pl. <span class="ar">تِكَكٌ</span>. <span class="auth">(Ṣ, Mṣb, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mitakBu">
				<h3 class="entry"><span class="ar">مِتَكُّ</span></h3>
				<div class="sense" id="mitakBu_A1">
					<p><span class="ar">مِتَكُّ</span> The <em>thing by means of which the</em> <span class="ar">تِكَّة</span> <em>is inserted in</em> <span class="add">[<em>the double upper border of</em>]</span> <em>the drawers,</em> or <em>trousers.</em> <span class="auth">(TA.)</span> <span class="add">[It is generally <em>a slender piece of wood, having at one end a loop through which a portion of the</em> <span class="ar">تكّة</span> <em>is passed.</em>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0310.pdf" target="pdf">
							<span>Lanes Lexicon Page 310</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
