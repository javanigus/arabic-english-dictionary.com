<article class="root" id="Root_tmwz">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/072_tmk">تمك</a></span>
				<span class="ar">تموز</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/074_tn">تن</a></span>
			</h2>
			<hr>
			<section class="entry main" id="tamBuwzu">
				<span class="pb" id="Page_0318"></span>
				<h3 class="entry"><span class="ar">تَمُّوزُ</span></h3>
				<div class="sense" id="tamBuwzu_A1">
					<p><span class="ar">تَمُّوزُ</span> <span class="add">[sometimes written <span class="ar">تَمُوزُ</span>, without teshdeed,]</span> <em>The</em> <span class="add">[<em>Syrian</em>]</span> <em>month</em> <span class="add">[<em>sacred,</em> in ancient times, <em>to the god of that name,</em> <span class="auth">(mentioned in Ezek. viii. 14,)</span> <em>corresponding to July, O. Ṣ.,</em>]</span> <em>after</em> <span class="ar">حَزِيرانُ</span>. <span class="auth">(Ṣ in art. <span class="ar">حزر</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0318.pdf" target="pdf">
							<span>Lanes Lexicon Page 318</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
