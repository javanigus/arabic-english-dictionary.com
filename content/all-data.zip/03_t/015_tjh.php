<article class="root" id="Root_tjh">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/014_tjr">تجر</a></span>
				<span class="ar">تجه</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/016_tHt">تحت</a></span>
			</h2>
			<h4 class="root">Quasi <span class="ar">تجه</span></h4>
			<hr>
			<section class="entry main" id="tjh_1">
				<h3 class="entry">1. ⇒ <span class="ar">تجه</span></h3>
				<div class="sense" id="tjh_1_A1">
					<p><span class="ar">تَجَهَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْجَهُ</span>}</span></add>, <span class="auth">(AZ, Ḳ, art. <span class="ar">وجه</span>,)</span> inf. n. <span class="ar">تَجْهٌ</span>; <span class="auth">(AZ, TA, in that art.;)</span> or, as Aṣ says, <span class="ar">تَجُهَ</span>, with damm; <span class="auth">(TA in that art.;)</span> <em>i. q.</em> <span class="ar">تَوَجَّهَ</span> and <span class="ar">وَجَّهَ</span> <span class="auth">(Ḳ in that art.)</span> and <span class="ar">اِتَّجَهَ</span>. <span class="auth">(Ḳ in art. <span class="ar">تجه</span>.)</span> <a href="index.php?data=27_w/047_wjh">See art. <span class="ar">وجه</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tujaAha">
				<h3 class="entry"><span class="ar">تُجَاهَ</span></h3>
				<div class="sense" id="tujaAha_A1">
					<p><span class="ar">تُجَاهَ</span> <span class="auth">(Ṣ, Mṣb, Ḳ, in art. <span class="ar">وجه</span>)</span> and <span class="ar">تِجَاهَ</span> <span class="auth">(Ṣ, Ḳ, in that art.)</span> and <span class="ar">تَجَاهَ</span> <span class="auth">(Ḳ in that art.)</span> <em>i. q.</em> <span class="ar">وُجَاهَ</span>, <span class="auth">(Ṣ, Mṣb, Ḳ, in that art.,)</span> which is seldom used; the <span class="ar">و</span> being generally changed into <span class="ar">ت</span>. <span class="auth">(Mṣb, ibid.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
