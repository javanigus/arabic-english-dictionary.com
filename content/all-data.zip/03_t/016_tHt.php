<article class="root" id="Root_tHt">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/015_tjh">تجه</a></span>
				<span class="ar">تحت</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/017_tHf">تحف</a></span>
			</h2>
			<hr>
			<section class="entry main" id="taHot">
				<h3 class="entry"><span class="ar">تَحْت</span></h3>
				<div class="sense" id="taHot_A1">
					<p><span class="ar">تَحْت</span> is the <em>contr. of</em> <span class="ar">فَوْق</span>: <span class="auth">(Mṣb, Ḳ:)</span> and <span class="ar">التَّحْتُ</span> <span class="add">[signifying <em>The location that is beneath, below,</em> or <em>under,</em>]</span> is opposed to <span class="ar">الفَوْقُ</span>, and is used in relation to that which is separate from another thing; <span class="ar">الأَسْفَلُ</span> being used in relation to that which is united with <span class="add">[or a part of]</span> another thing. <span class="auth">(Kull.)</span> Sometimes, <span class="auth">(Ḳ,)</span> <span class="ar">تَحْت</span> is an adv. n., <span class="auth">(Mṣb, Ḳ,)</span> having a vague signification, its meaning not being clear unless it is prefixed to another word, as in the phrase <span class="ar long">هٰذَا تَحْتَ هٰذَا</span> <span class="add">[<em>This is beneath, below,</em> or <em>under, this</em>]</span>. <span class="auth">(Mṣb.)</span> And sometimes, it is a simple noun; <span class="auth">(Ḳ;)</span> in which case, <span class="add">[not having the article <span class="ar">ال</span>,]</span> it is indecl., with ḍammeh for its termination, <span class="auth">(Ḳ, and I’Aḳ p. 204,)</span> provided that the noun to which it should be prefixed is suppressed, and the meaning of this is intended to be understood, but not the word itself; <span class="auth">(I’Aḳ ubi suprà;)</span> as in <span class="ar long">مِنْ تَحْتُ</span> <span class="add">[<em>Beneath, below,</em> or <em>under</em>]</span>; <span class="auth">(Ḳ;)</span> and in the saying,</p> 
					<blockquote class="quote">
						<div class="star">* <span class="ar long">أَقَبٌ مِنْ تَحْتُ عَرِيضٌ مِنْ عَلُ</span> *</div> 
					</blockquote>
					<p><span class="add">[<em>Lean beneath; broad above</em>]</span>: otherwise, it is decl.; <span class="auth">(I’Aḳ ibid.;)</span> as in <span class="ar long">تَجْرِى مِنْ تَحْتِهَا الأَنْهَارُ</span> <span class="add">[<em>Rivers running beneath them</em>]</span>; <span class="auth">(Ḳur ii. 23, &amp;c.;)</span> i.e., beneath their trees, <span class="auth">(Bḍ, Jel,)</span> and their pavilions. <span class="auth">(Jel.)</span> <span class="add">[You say also, <span class="ar long">فُلَانٌ تَحْتَ أَمْرِ فُلَانٍ</span> † <em>Such a one is under the command, rule,</em> or <em>authority, of such a one.</em> And <span class="ar long">فُلَانٌ تَحْتَهُ فُلَانَةُ</span> † <em>Such a one has as his wife such a woman:</em> see an ex. in a verse cited voce <span class="ar">إِذَا</span>. The dim. is<span class="arrow"><span class="ar">تُحَيْت↓</span></span>: you say, <span class="ar long">هٰدَا تُحَيْتَ هٰذَا</span>, and <span class="ar long">مِنْ تُحَيْتِ هٰذَا</span>, <em>This is a little beneath, below,</em> or <em>under, this.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">تحت</span> - Entry: <span class="ar">تَحْت</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="taHot_A2">
					<p><span class="ar">التَّحْتُ</span> is also <a href="#AltBuHuwtu">the sing. of <span class="ar">التُّحُوتُ</span></a>, <span class="auth">(IAth, TA,)</span> which latter <span class="add">[in the CK erroneously written <span class="ar">التُّحُتُ</span>]</span> signifies <em>The low, base, vile,</em> or <em>ignoble, persons.</em> <span class="auth">(A, IAth, Ḳ.)</span> It is said in a trad., <span class="ar long">لَا تَقُومُ السَّاعَةُ حَتَّى تَظْهَرَ التُّحُوتُ وَتَهْلِكَ الوُعُولُ</span>, i. e. <span class="add">[<em>The hour</em> of resurrection <em>will not come until</em>]</span> <em>the low,</em> or <em>ignoble, persons</em> <span class="add">[<em>shall prevail</em>]</span>, <em>and the noble persons</em> <span class="add">[<em>shall perish</em>]</span>: <span class="auth">(A, IAth, TA:)</span> or, as some say, <em>until the treasures that are beneath the earth appear.</em> <span class="auth">(TA.)</span> And in another trad. it is said that among the signs of the resurrection shall be this: <span class="ar long">أَنْ يَعْلُو التُّحُوتُ الوُعُولَ</span> <em>That the weak of mankind shall have ascendency over the strong.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taHotaAnieBN">
				<h3 class="entry"><span class="ar">تَحْتَانِىٌّ</span></h3>
				<div class="sense" id="taHotaAnieBN_A1">
					<p><span class="ar">تَحْتَانِىٌّ</span> <span class="add">[<em>Of,</em> or <em>relating to, the location that is beneath, below,</em> or <em>under; inferior; lower;</em>]</span> <a href="#taHot">rel. n. of <span class="ar">تَحْت</span></a>, like as <span class="ar">فَوْقَانِىٌّ</span> is of <span class="ar">فَوْق</span>: <span class="ar">ا</span> and <span class="ar">ن</span> being very often added in the rel. n. <span class="auth">(TA.)</span></p> 
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tuHayot">
				<h3 class="entry"><span class="add">[<span class="ar">تُحَيْت</span>]</span></h3>
				<div class="sense" id="tuHayot_A1">
					<p><span class="add">[<span class="ar">تُحَيْت</span> <a href="#tHot">dim. of <span class="ar">تَحْت</span>, q. v.</a>]</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0298.pdf" target="pdf">
							<span>Lanes Lexicon Page 298</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
