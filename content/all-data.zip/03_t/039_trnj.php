<article class="root" id="Root_trnj">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/038_trn">ترن</a></span>
				<span class="ar">ترنج</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/040_trnjbyn">ترنجبين</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="turunojN.1">
				<h3 class="entry"><span class="ar">تُرُنْجٌ</span> / <span class="ar">تُرُنْجَةٌ</span></h3>
				<div class="sense" id="turunojN.1_A1">
					<p><span class="ar">تُرُنْجٌ</span> and <span class="ar">تُرُنْجَةٌ</span>: <a href="index.php?data=03_t/027_trj">see art. <span class="ar">ترج</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="OutorunojN.1">
				<h3 class="entry"><span class="ar">أُتْرُنْجٌ</span></h3>
				<div class="sense" id="OutorunojN.1_A1">
					<p><span class="ar">أُتْرُنْجٌ</span> and <span class="ar">أُتْرُنْجَةٌ</span>: <a href="index.php?data=03_t/027_trj">see art. <span class="ar">ترج</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0306.pdf" target="pdf">
							<span>Lanes Lexicon Page 306</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
