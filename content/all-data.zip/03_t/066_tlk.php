<article class="root" id="Root_tlk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/065_tlf">تلف</a></span>
				<span class="ar">تلك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/067_tlmc">تلمذ</a></span>
			</h2>
			<hr>
			<section class="entry xref" id="tiloka">
				<h3 class="entry"><span class="ar">تِلْكَ</span> /
							<span class="ar">تَلْكَ</span> /
							<span class="ar">تَالِكَ</span></h3>
				<div class="sense" id="tiloka_A1">
					<p><span class="ar">تِلْكَ</span> and <span class="ar">تَلْكَ</span> and <span class="ar">تَالِكَ</span>: <a href="index.php?data=03_t/001_tA">see art. <span class="ar">تا</span></a>.</p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0313.pdf" target="pdf">
							<span>Lanes Lexicon Page 313</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
