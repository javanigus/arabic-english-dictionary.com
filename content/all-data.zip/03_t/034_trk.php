<article class="root" id="Root_trk">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/033_trq">ترق</a></span>
				<span class="ar">ترك</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/035_trkmAn">تركمان</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trk_1">
				<h3 class="entry">1. ⇒ <span class="ar">ترك</span></h3>
				<div class="sense" id="trk_1_A1">
					<p><span class="ar">تَرَكَهُ</span>, <span class="auth">(Ṣ, M, Mṣb, Ḳ, &amp;c.,)</span> aor. <span class="ar">ـُ</span> <add><span class="new">{<span class="ar">يَتْرُكُ</span>}</span></add>, <span class="auth">(Ṣ, M,)</span> inf. n. <span class="ar">تَرْكٌ</span> <span class="auth">(Ṣ, M, Mṣb, Ḳ, &amp;c.)</span> and <span class="ar">ترْكَانٌ</span>, with kesr, <span class="auth">(Fr, Ḳ,)</span> <em>He left it, forsook it, relinquished it, abandoned it, deserted it,</em> or <em>quitted it;</em> either <em>intentionally, and by choice,</em> or <em>by constraint, and of necessity:</em> <span class="auth">(Er-Rághib, TA:)</span> <em>he left it, forsook it,</em>, &amp;c., as above; namely, a thing that he desired, or wished for, and also a thing that he did not desire, or did not wish for: <span class="auth">(Ibn-ʼArafeh, TA:)</span> <em>he left it, quitted it, went away from it,</em> or <em>departed from it;</em> namely, a place: and <em>he left him, forsook him, relinquished him, abandoned him, deserted him, quitted him,</em> or <em>separated himself from him:</em> <span class="auth">(Mṣb:)</span> <em>he cast it,</em> or <em>threw it, away, as a thing of no account; rejected it; discarded it; cast it off; left it off:</em> <span class="auth">(MF, TA:)</span> <em>he left it, left it alone, let it alone; ceased, desisted, forbore,</em> or <em>abstained, from it; neglected it, omitted it,</em> or <em>left it undone;</em> syn. <span class="ar">خَلَّاهُ</span>; <span class="auth">(Ṣ, A, O;)</span> or <span class="ar">وَدَعَهُ</span>; <span class="auth">(M, Ḳ;)</span> as also<span class="arrow"><span class="ar">اتّركهُ↓</span></span>. <span class="auth">(Ḳ. <span class="add">[But respecting this latter verb, see what follows.]</span>)</span> <span class="ar long">وَٱتْرُكِ البَحْرَ رَهْوًا</span>, in the Ḳur xliv. 23, <em>And leave thou the sea opened with a wide interval;</em> or <em>motionless,</em> in the same state as before thy passing through it, and strike it not with thy rod, nor alter anything thereof; <span class="auth">(Bḍ;)</span> or <em>motionless, parted asunder;</em> <span class="auth">(Jel;)</span> so that the Egyptians may enter it; <span class="auth">(Bḍ, Jel;)</span> is an instance of the verb meaning leaving intentionally, and by choice: <span class="auth">(Er-Rághib, TA:)</span> and <span class="ar long">كَمْ تَرَكُوا مِنْ جَنَّاتٍ وَعُيُونٍ</span>, in the next verse, <em>How many gardens and springs did they leave!</em> <span class="auth">(Jel,)</span> is an instance of the verb meaning leaving by constraint, and of necessity. <span class="auth">(Er-Rághib, TA.)</span> In a phrase such as <span class="ar long">تَرَكَ حَقَّهُ</span>, meaning <em>He made his right,</em> or <em>due,</em> or <em>claim, to be null,</em> or <em>he rejected it,</em> and such as <span class="ar long">تَرَكَ رَكْعَةٌ مِنَ الصَّلَاةِ</span>, meaning <em>He neglected, omitted,</em> or <em>left unperformed, a</em> <span class="ar">ركعة</span>, <em>of the prayer,</em> <span class="pb" id="Page_0305"></span><span class="add">[it is said <span class="auth">(but I think it doubtful)</span> that]</span> the verb, having an ideal substantive for its objective complement, is used metaphorically. <span class="auth">(Mṣb.)</span> <span class="arrow"><span class="ar long">قَالَ فِيهِ فَمَا ٱتَّرَكَ↓</span></span> means <span class="ar long">مَا تَرَكَ شَيْئًا</span> <span class="add">[i. e. <em>He strove, laboured,</em> or <em>exerted himself,</em> (<span class="ar">اِجْتَهَدَ</span>,) <em>in it, and neglected not,</em> or <em>omitted not, anything</em> in his power]</span>: the verb is of the measure <span class="ar">اِفْتَعَلَ</span>. <span class="auth">(Ṣ.)</span> <span class="arrow"><span class="ar long">مَنْ أَوْصَى بِالثُّلُثِ وَلَمْ يَتَّرِكْ↓ شَيْئًا</span></span> is a mistake for <span class="ar long">ولم يَتْرُكْ شَيْئًا</span>, or<span class="arrow"><span class="ar long">ولم يَتَّرِكْ↓</span></span> without <span class="ar">شَيْئًا</span>, or <span class="ar long">فَمَا ٱتَّرَكَ</span>; for this verb is not trans., except, sometimes, in poetry; and the meaning is, <span class="ar long">وَلَمْ يَتْرُكْ فِيمَاأُذِنَ لَهُ فِيهِ شَيْئًا</span> <span class="add">[i. e. <em>He who bequeaths the third</em> of his property, <em>and does not omit anything</em> of what he is allowed <span class="auth">(to leave, or anything of the third part, for this is all that he is allowed to bequeath)</span>]</span>: it is from the saying <span class="arrow"><span class="ar long">فَعَلَ فَمَا ٱتَّرَكَ↓</span></span> <span class="add">[<em>He did</em> such a thing, <em>and neglected not,</em> or <em>omitted not, anything</em>]</span>. <span class="auth">(Mgh.)</span> You say also, <span class="ar long">تَرَكَ المَيِّتُ مَالًا</span>, i. e. <em>The deceased left property.</em> <span class="auth">(Mṣb.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trk_1_A2">
					<p><span class="ar long">وَتَرَكْنَا عَلَيْهِ فِى الآخِرِينَ</span>, <span class="auth">(Ḳ,)</span> in the Ḳur <span class="add">[xxxvii. 76, &amp;c.]</span>, <span class="auth">(TA,)</span> means <em>And we have perpetuated</em> <span class="auth">(Ḳ, Jel, TA)</span> <em>to him</em> a eulogy <em>among the later generations</em> <span class="auth">(Jel, TA)</span> of the prophets and peoples to the day of resurrection, <span class="add">[namely,]</span> Salutation, &amp;c. <span class="auth">(Jel.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="trk_1_A3">
					<p><span class="ar">التَّرْكُ</span> is also <em>syn. with</em> <span class="ar">الجَعْلُ</span>, <span class="auth">(Lth, Ḳ, TA,)</span> in some instances; <span class="auth">(Lth, TA;)</span> as though it had two contr. significations: <span class="auth">(Ḳ:)</span> <span class="add">[i. e.,]</span> when <span class="ar">تَرَكَ</span> is doubly trans., it has the meaning of <span class="ar">صَيَّرَ</span>, <span class="auth">(MF, TA,)</span> or <span class="ar">جَعَلَ</span>. <span class="auth">(TA.)</span> So in the saying, <span class="ar long">تَرَكْتُ الحَبْلَ شَدِيدًا</span> <em>I made,</em> or <em>rendered, the rope strong;</em> or <em>made it,</em> or <em>caused it, to be,</em> or <em>become, strong.</em> <span class="auth">(TA.)</span> So too in the Ḳur ii. 16, <span class="ar long">وَتَرَكَهُمْ فِى ظُلُمَاتٍ</span> <em>And maketh,</em> or <em>causeth, them to be in darknesses.</em> <span class="auth">(Ksh, Bḍ, MF.)</span> And sometimes one says of any action that has come at last to a certain state, <span class="ar long">مَا تَرَكْتُهُ كَذَا</span> <span class="add">[<em>I did not make it,</em> or <em>cause it, to be thus</em>]</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: 1.</span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="trk_1_B1">
					<p><span class="ar">تَرِكَ</span>, aor. <span class="ar">ـَ</span> <add><span class="new">{<span class="ar">يَتْرَكُ</span>}</span></add>, <span class="auth">(IAạr, Ḳ,)</span> inf. n. <span class="ar">تَرْكٌ</span>, <span class="auth">(TḲ,)</span> <em>He</em> <span class="auth">(a man, IAạr)</span> <em>married,</em> i. e. <em>took to wife, a</em> <span class="ar">تَرِيكَة</span>, <span class="auth">(IAạr, Ḳ,)</span> meaning <em>a woman that had remained a virgin, unmarried, until she had become of middle age,</em> or <em>long after she had attained to puberty, in the house,</em> or <em>tent, of her parents.</em> <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trk_3">
				<h3 class="entry">3. ⇒ <span class="ar">تارك</span></h3>
				<div class="sense" id="trk_3_A1">
					<p><span class="ar">تاركهُ</span> <span class="add">[inf. n. <span class="ar">مُتَارَكَةٌ</span>]</span> is <em>syn. with</em> <span class="ar">خَالَاهُ</span> <span class="auth">(Ṣ in art. <span class="ar">خلو</span>)</span> <span class="add">[which is explained in the Ḳ, in art. <span class="ar">خلو</span>, as <em>syn. with</em> <span class="ar">تَرَكَهُ</span>, <em>He left, forsook, relinquished, abandoned,</em>, &amp;c., <em>him</em> or <em>it;</em> and thus it may often be well rendered: but it properly signifies <em>he left him, forsook him,</em>, &amp;c., <em>being left,</em>, &amp;c., <em>by him;</em> whence it is said in the Mgh, in art. <span class="ar">ودع</span>, that <span class="ar">مُوَادَعَةُ</span> is syn. with <span class="ar">مُصَالَحَةٌ</span> because it is <span class="ar">مُتَارَكَةٌ</span>: Golius, as on the authority of Ibn-Maạroof, explains <span class="ar">تاركهُ</span> as signifying <em>he dismissed him, and did not molest him: he left him unmolested</em> is one of its meanings, but is not the primary signification: accord. to the TḲ, <span class="ar">متاركة</span> signifies the <em>leaving,</em>, &amp;c., <em>anything in the state in which it is:</em> and the <em>leaving,</em>, &amp;c., <em>one another</em>]</span>. One says also, <span class="ar long">تَارَكْتُهُ البَيْعَ</span>, <span class="auth">(Ṣ, Mgh, but in the latter <span class="ar">تَارَكَهُ</span>, and in the TA <span class="ar long">فِى البَيْعِ</span>,)</span> <span class="ar">وَغَيْرَهُ</span>, <span class="auth">(Mgh,)</span> inf. n. <span class="ar">مُتَارَكَةٌ</span>, <span class="auth">(Ṣ,)</span> <span class="add">[app. meaning <em>I relinquished with him,</em> i. e. <em>concurrently with him, the sale, &amp;c.:</em> <a href="#trk_6">see 6</a>, by which this rendering is confirmed: Golius, as on the authority of J, who has not explained it, says that it means <em>I relinquished to him the merchandise,</em> or <em>commodity;</em> and Freytag follows him.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trk_3_A2">
					<p><span class="add">[Hence,]</span> <span class="ar">مُتَارَكَةٌ</span> is metonymically used as meaning The <em>making peace</em> <span class="add">[or <em>a truce</em>]</span>, or <em>reconciling oneself, with another</em> or <em>others.</em> <span class="auth">(Mgh.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: 3.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="trk_3_A3">
					<p>In the saying, <span class="ar long">لَا بَارَكَ ٱللّٰهُ فِيِهِ وَلَا تَارَكَ وَلَا دَارَكَ</span>, it is an imitative sequent, <span class="auth">(Ḳ,)</span> all of these verbs having the same meaning <span class="add">[so that the saying may be rendered <em>May God not bless him nor felicitate him nor make him happy</em>]</span>: <span class="auth">(TA:)</span> <span class="add">[or the meaning may be, <em>nor preserve him,</em> or <em>prolong his life;</em> for]</span> IAạr says that <span class="ar">تَارَكَ</span> means <span class="ar">أَبْقَى</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="trk_6">
				<h3 class="entry">6. ⇒ <span class="ar">تتارك</span></h3>
				<div class="sense" id="trk_6_A1">
					<p><span class="ar long">تَتَارَكُوا الأَمْرَ بَيْنَهُمْ</span>, <span class="auth">(Ḳ,)</span> or <span class="ar long">الأَمْرَ فِيمَا بَيْنَهُمْ</span>, <span class="auth">(Mgh,)</span> <em>They relinquished</em> <span class="add">[<em>concurrently</em>]</span>, <em>one with another, the affair that was between them.</em> <span class="auth">(TḲ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="trk_8">
				<h3 class="entry">8. ⇒ <span class="ar">اتّرك</span></h3>
				<div class="sense" id="trk_8_A1">
					<p><span class="ar">اِتَّرَكَ</span>: <a href="#trk_1">see 1</a>, in five places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarokN">
				<h3 class="entry"><span class="ar">تَرْكٌ</span></h3>
				<div class="sense" id="tarokN_A1">
					<p><span class="ar">تَرْكٌ</span>: <a href="#tariykapN">see <span class="ar">تَرِيكَةٌ</span></a>.</p>
				</div>
				<div class="dissociation">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرْكٌ</span></span>
					<span class="middle">＝</span>
					<span class="right">Dissociation: B</span>
				</div>
				<div class="sense" id="tarokN_B1">
					<p>Also <em>A</em> <span class="add">[<em>drinking-cup or bowl such as is called</em>]</span> <span class="ar">قَدَح</span> <em>which a man lifts,</em> or <em>carries, with his two hands.</em> <span class="auth">(Ibn-ʼAbbád, TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="AltBuroku">
				<h3 class="entry"><span class="ar">التُّرْكُ</span></h3>
				<div class="sense" id="AltBuroku_A1">
					<p><span class="ar">التُّرْكُ</span> <em>A certain nation;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <span class="add">[namely, <em>the Turks:</em>]</span> <span class="ar">تُرْكِىٌّ</span> is its n. un.: <span class="auth">(Mṣb, TA:)</span> <span class="add">[and signifies also <em>Turkish:</em>]</span> pl. <span class="ar">أَتْرَاكٌ</span>. <span class="auth">(Mṣb, Ḳ.)</span> It is said in a trad., <span class="ar long">اُتْرُكُوا التَّرْكَ مَا تَرَكُو كُمْ</span> <span class="add">[<em>Leave ye alone the Turks as long as they leave you alone</em>]</span>. <span class="auth">(TA.)</span> <span class="add">[<span class="ar long">تُرْكِىُّ الوَجْهِ</span> often occurs in post-classical works as meaning <em>Having a Turkish face;</em> i. e. <em>round-faced,</em> or <em>broad-faced;</em> opposed to <span class="ar long">عَرَبِىُّ الوَجْهِ</span>.]</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarokapN">
				<h3 class="entry"><span class="ar">تَرْكَةٌ</span></h3>
				<div class="sense" id="tarokapN_A1">
					<p><span class="ar">تَرْكَةٌ</span>: <a href="#tariykapN">see <span class="ar">تَرِيكَةٌ</span></a>, in two places.</p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرْكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tarokapN_A2">
					<p>Also † <em>A woman such as is termed</em> <span class="ar">رَبْعَةٌ</span> <span class="add">[i. e. <em>of middling stature</em>]</span>: <span class="auth">(Ibn-ʼAbbád, Ḳ:)</span> pl. <span class="ar">تَرْكَاتٌ</span>. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرْكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tarokapN_A3">
					<p>It is said in a trad., <span class="ar long">جَآءَ الخَلِيلُ إِلَى مَكَّةَ يُطَالِعُ تَرْكَتَهُ</span> † <span class="add">[<em>El-Khaleel</em> <span class="auth">(i. e. Abraham)</span> <em>came to Mekkeh to get knowledge of his</em> <span class="ar">تركة</span>]</span>, meaning Hagar, and her son Ishmael: <span class="auth">(Ḳ:)</span> the word originally means an ostrich's egg, and is here used metaphorically; for the ostrich lays but one egg in the year, and then leaves it and goes away: <span class="auth">(TA:)</span> Z says, in the Fáïk, that it is thus related, with the <span class="ar">ر</span> quiescent; <span class="auth">(Nh, O, TA;)</span> but it would be a proper way if it were with kesr to the <span class="ar">ر</span> <span class="add">[<span class="arrow"><span class="ar">تَرِكَتَهُ↓</span></span>,]</span> as meaning <em>the thing that he had left,</em> or <em>forsaken,</em>, &amp;c. <span class="auth">(Nh, O, Ḳ.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tirokapN">
				<h3 class="entry"><span class="ar">تِرْكَةٌ</span></h3>
				<div class="sense" id="tirokapN_A1">
					<p><span class="ar">تِرْكَةٌ</span>: <a href="#tarikapN">see what next follows</a>.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarikapN">
				<h3 class="entry"><span class="ar">تَرِكَةٌ</span></h3>
				<div class="sense" id="tarikapN_A1">
					<p><span class="ar">تَرِكَةٌ</span> <em>A thing that is left, forsaken, relinquished, abandoned, deserted,</em> or <em>quitted;</em> like <span class="ar">طَلِبَةٌ</span> meaning “a thing desired, or sought;” <span class="auth">(TA;)</span> <a href="#tarokapN">see also <span class="ar">تَرْكَةٌ</span></a>: particularly, the <em>inheritance,</em> or <em>property that is left,</em> of a person deceased; <span class="auth">(Ṣ, Mṣb, Ḳ;*)</span> also pronounced <span class="arrow"><span class="ar">تِرْكَةٌ↓</span></span>: pl. <span class="ar">تَرِكَاتٌ</span>. <span class="auth">(Mṣb.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="taraAki">
				<h3 class="entry"><span class="ar">تَرَاكِ</span></h3>
				<div class="sense" id="taraAki_A1">
					<p><span class="ar">تَرَاكِ</span> an imperative verbal noun, meaning <span class="ar">اُتْرُكْ</span> <span class="add">[<em>Leave thou,</em>, &amp;c.]</span>. <span class="auth">(Ṣ, TA.)</span> Hence the saying, <span class="ar long">تَرَاكِ تَرَاكِ صُحْبَةَ الأَتْرَاكِ</span> <span class="add">[<em>Leave thou, leave thou, the companionship of the Turks</em>]</span>. <span class="auth">(TA.)</span> Yoo says that <span class="ar">تَرَاكَ</span> is a dial. var. of the same; but this is only when it is used as a prefixed noun, as in <span class="ar">تَرَاكَهَا</span> for <span class="ar">تَرَاكِهَا</span>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry xref" id="tariykN">
				<h3 class="entry"><span class="ar">تَرِيكٌ</span></h3>
				<div class="sense" id="tariykN_A1">
					<p><span class="ar">تَرِيكٌ</span>: <a href="#tariykapN">see the next paragraph</a>, in two places.</p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tariykapN">
				<h3 class="entry"><span class="ar">تَرِيكَةٌ</span></h3>
				<div class="sense" id="tariykapN_A1">
					<p><span class="ar">تَرِيكَةٌ</span> <em>A woman that is left unmarried;</em> <span class="auth">(Ṣ, Ḳ;)</span> <em>that has remained a virgin, unmarried, until she has become of middle age,</em> or <em>long after she has attained to puberty, in the house,</em> or <em>tent, of her parents:</em> <span class="auth">(TA:)</span> it is not applied to a male: <span class="auth">(Lḥ, TA:)</span> pl. <span class="ar">تَرَائِكُ</span>. <span class="auth">(Ṣ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tariykapN_A2">
					<p><em>A meadow the depasturing of which has been neglected:</em> <span class="auth">(Ṣ, Ḳ:)</span> or <em>a pasture-land where people have pastured their beasts, either in a desert or upon a mountain, and of which the beasts have eaten until there remain</em> <span class="add">[<em>only</em>]</span> <em>some relics of wood.</em> <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tariykapN_A3">
					<p><em>Water left by a torrent:</em> <span class="auth">(IB, Ḳ:)</span> used in this sense by El-Farezdaḳ. <span class="auth">(IB.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A4</span>
				</div>
				<div class="sense" id="tariykapN_A4">
					<p><em>An egg after the young bird has gone forth from it:</em> <span class="auth">(Ḳ:)</span> or <em>an ostrich's egg</em> <span class="auth">(Ṣ, Ḳ)</span> <em>which she forsakes</em> <span class="auth">(Ṣ, TA)</span> <em>in the desert after it has become empty:</em> <span class="auth">(TA:)</span> or, as some say, <em>an ostrich's eggs left solitary:</em> <span class="auth">(TA:)</span> and<span class="arrow"><span class="ar">تَرْكَةٌ↓</span></span> signifies the same. <span class="auth">(Ḳ.)</span> <span class="add">[For the pl., see the next sentence.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A5</span>
				</div>
				<div class="sense" id="tariykapN_A5">
					<p>† <em>An iron helmet;</em> <span class="auth">(Ḳ;)</span> in the opinion of ISd, as being likened to the egg thus termed; <span class="auth">(TA;)</span> and so<span class="arrow"><span class="ar">تَرْكَةٌ↓</span></span>: <span class="auth">(Ṣ, Ḳ:)</span> the pl. <span class="add">[of the former]</span> is <span class="ar">تَرَائِكُ</span> <span class="add">[mentioned in the Ṣ as pl. of the former applied to an ostrich's egg]</span> and<span class="arrow"><span class="ar">تَرِيكٌ↓</span></span> and<span class="arrow"><span class="ar">تَرْكٌ↓</span></span> <span class="add">[the latter of which is termed in the Ṣ <a href="#tarokapN">pl. of <span class="ar">تَرْكَةٌ</span></a> are coll. gen. ns. of which <span class="ar">تَرِيكَةٌ</span> and <span class="ar">تَرْكَةٌ</span> are the ns. un.]</span>. <span class="auth">(Ḳ.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A6</span>
				</div>
				<div class="sense" id="tariykapN_A6">
					<p><em>A raceme of dates</em> (<span class="ar">كِبَاسَة</span> <span class="add">[in the CK, erroneously, <span class="ar">كُناسة</span>]</span>) <em>after it has had what was upon it shaken off,</em> <span class="auth">(AḤn, Ḳ, TA,)</span> <em>and is left:</em> pl. <span class="ar">تَرَائِكُ</span>: <span class="auth">(AḤn, TA:)</span> and<span class="arrow"><span class="ar">تَرِيكٌ↓</span></span> signifies <em>a raceme</em> (<span class="ar">عُنْقُود</span>) <em>when what was upon it has been eaten;</em> <span class="auth">(AḤn, Ḳ, TA;)</span> and <em>a raceme of dates</em> (<span class="ar">عِذْق</span>) <em>that has had what was upon it shaken off,</em> <span class="auth">(Ḳ, TA,)</span> <em>so that nothing remains upon it:</em> so AḤn says in one place. <span class="auth">(TA.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">تَرِيكَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A7</span>
				</div>
				<div class="sense" id="tariykapN_A7">
					<p>It is said in a trad., <span class="ar long">إِنَّ لِلّهِ تَرَائِكَ فِى خَلْقِهِ</span>, meaning <span class="add">[<em>Verily to God are referrible</em>]</span> <em>conditions which He hath perpetuated in mankind,</em> of hope and heedlessness, so that they apply themselves thereby with boldness, forwardness, presumptuousness, or arrogance, to the things of the present world. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="matoruwkN">
				<h3 class="entry"><span class="ar">مَتْرُوكٌ</span></h3>
				<div class="sense" id="matoruwkN_A1">
					<p><span class="ar">مَتْرُوكٌ</span> <span class="add">[pass. part. n. of <span class="ar">تَرَكَ</span>, <em>Left, forsaken,</em>, &amp;c.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترك</span> - Entry: <span class="ar">مَتْرُوكٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="matoruwkN_A2">
					<p>In lexicology, <em>Obsolete.</em> <span class="auth">(Mz 10th <span class="ar">نوع</span>.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0304.pdf" target="pdf">
							<span>Lanes Lexicon Page 304</span>
						</a>
					</li>
					<li>
						<a href="/pdf/Page_0305.pdf" target="pdf">
							<span>Lanes Lexicon Page 305</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
