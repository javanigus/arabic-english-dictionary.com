<article class="root" id="Root_trjm">
			<h2 class="root">
				<span class="prev"><img src="../left.png" alt=""><a href="index.php?data=03_t/027_trj">ترج</a></span>
				<span class="ar">ترجم</span>
				<span class="next"><img src="../right.png" alt=""><a href="index.php?data=03_t/029_trH">ترح</a></span>
			</h2>
			<hr>
			<section class="entry main" id="trjm_Q1">
				<h3 class="entry">Q. 1. ⇒ <span class="ar">ترجم</span></h3>
				<div class="sense" id="trjm_Q1_A1">
					<p><span class="ar">تَرْجَمَهُ</span>, <span class="auth">(Ṣ in art. <span class="ar">رجم</span>, and Mṣb and Ḳ in the present art.,)</span> and <span class="ar long">تَرْجَمَ عَنْهُ</span>, <span class="auth">(Ḳ,)</span> inf. n. <span class="ar">تَرْجَمَةٌ</span>, <span class="auth">(KL,)</span> <em>He interpreted it,</em> <span class="auth">(Ṣ, Mṣb, KL, Ḳ,)</span> or <em>explained it in another language;</em> <span class="auth">(Ṣ, Mṣb, KL;)</span> namely, the speech, or language, <span class="auth">(Ṣ, Mṣb, Ḳ,)</span> of another person: <span class="auth">(Mṣb:)</span> or, as some say, <em>translated it from one language into another:</em> <span class="auth">(TA:)</span> and <em>he explained it;</em> namely, his own speech. <span class="auth">(Mṣb.)</span> <span class="add">[This verb is essentially the same in Arabic, Chaldee, and Ethiopic.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترجم</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="trjm_Q1_A2">
					<p><span class="ar">تَرْجَمَهُ</span>, inf. n. as above, also signifies <em>He wrote his life; wrote a biography,</em> or <em>biographical notice, of him.</em> <span class="auth">(TA, passim; and other works of post-classical times.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترجم</span> - Entry: Q. 1.</span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="trjm_Q1_A3">
					<p>Accord. to the Ḳ, the <span class="ar">ت</span> in this verb is a radical: but <a href="#tarojumaAnN">see <span class="ar">تَرْجُمَانٌ</span>, below</a>. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarojamapN">
				<h3 class="entry"><span class="ar">تَرْجَمَةٌ</span></h3>
				<div class="sense" id="tarojamapN_A1">
					<p><span class="ar">تَرْجَمَةٌ</span> <span class="add">[inf. n. of the verb above: used as a simple subst., <em>An interpretation: a translation:</em> pl. <span class="ar">تَرَاجِمُ</span>.]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترجم</span> - Entry: <span class="ar">تَرْجَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="tarojamapN_A2">
					<p><span class="add">[Also]</span> <em>A life,</em> or <em>biography,</em> or <em>biographical notice,</em> of any person: pl. as above. <span class="auth">(TA, passim; and other works of post-classical times.)</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترجم</span> - Entry: <span class="ar">تَرْجَمَةٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="tarojamapN_A3">
					<p>And <em>An article, a head, chapter, section,</em> or <em>paragraph,</em> of a book. <span class="auth">(TA, passim; and other works of post-classical times.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="tarojumaAnN">
				<h3 class="entry"><span class="ar">تَرْجُمَانٌ</span></h3>
				<div class="sense" id="tarojumaAnN_A1">
					<p><span class="ar">تَرْجُمَانٌ</span> and <span class="ar">تُرْجُمَانٌ</span> and <span class="ar">تَرْجَمَانٌ</span>, <span class="auth">(Ṣ in art. <span class="ar">رجم</span>, and Mṣb and Ḳ in the present art.,)</span> of which three dial. vars. the first is the best, <span class="auth">(Mṣb,)</span> and is that which commonly obtains, <span class="auth">(TA,)</span> <em>An interpreter;</em> <span class="auth">(Ṣ, Mṣb, Ḳ;)</span> <em>an explainer of speech in another language:</em> <span class="auth">(Ṣ, Mṣb:)</span> <span class="add">[<em>a translator:</em> <span class="auth">(see the verb, above:)</span>]</span> pl. <span class="ar">تَرَاجِمُ</span> and <span class="ar">تَرَاجِمَةٌ</span>; which latter favours the opinion of those who hold the word to be of foreign origin. <span class="auth">(Ṣ, Mṣb.)</span> The <span class="ar">ت</span> and <span class="ar">م</span> are <span class="add">[said to be]</span> radicals; but J makes the <span class="ar">ت</span> to be augmentative, and <span class="ar">ترجمان</span> is mentioned in the T <span class="add">[as well as in the Ṣ]</span> in art. <span class="ar">رجم</span>, though the author of the T has mentioned the verb among quadriliteral-radical words; and there is a reason <span class="add">[for deriving it from <span class="ar">رَجَمَ</span>]</span>, for one says <span class="ar long">لِسَانٌ يَرْجُمُ</span> meaning “a tongue that is chaste, or perspicuous, and copious, in speech:” most, however, hold the <span class="ar">ت</span> to be a radical. <span class="auth">(Mṣb.)</span> It is said in the Ḳ that the verb shows the <span class="ar">ت</span> to be radical; whereas J and AḤei and IḲt hold it to be augmentative; but there is a difference of opinion whether it be from <span class="ar long">الرَّجْمُ بِالحِجَارَةِ</span> <span class="add">[the throwing stones]</span>, or from <span class="ar long">الرَّجْمُ بِالغَيْبِ</span> <span class="add">[the conjecturing, or speaking conjecturally]</span>; and also whether it be Arabic, or arabicized from <span class="ar">درغمان</span> <span class="add">[a word which I do not know in Persian nor in any other language]</span>: <span class="auth">(MF, TA:)</span> if arabicized, the present is its proper place. <span class="auth">(TA.)</span></p>
				</div>
			</section>
			<hr>
			<section class="entry main" id="mutarojamN">
				<h3 class="entry"><span class="ar">مُتَرْجَمٌ</span></h3>
				<div class="sense" id="mutarojamN_A1">
					<p><span class="ar">مُتَرْجَمٌ</span> <span class="add">[<em>Interpreted:</em> or <em>translated.</em>]</span></p>
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترجم</span> - Entry: <span class="ar">مُتَرْجَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A2</span>
				</div>
				<div class="sense" id="mutarojamN_A2">
					<p><span class="add">[And also The <em>subject of a biography,</em> or <em>biographical notice.</em>]</span></p> 
				</div>
				<div class="signification">
					<span class="left">Root: <span class="ar">ترجم</span> - Entry: <span class="ar">مُتَرْجَمٌ</span></span>
					<span class="middle">―</span>
					<span class="right">Signification: A3</span>
				</div>
				<div class="sense" id="mutarojamN_A3">
					<p><span class="add">[And]</span> † <em>Confused,</em> or <em>dubious.</em> <span class="auth">(Ḥar p. 537.)</span></p>
				</div>
			</section>
			<hr>
			<section class="pdflink">
				<h3>PDF files digitized by Google:</h3>
				<ul>
					<li>
						<a href="/pdf/Page_0302.pdf" target="pdf">
							<span>Lanes Lexicon Page 302</span>
						</a>
					</li>
				</ul>
			</section>
		</article>
